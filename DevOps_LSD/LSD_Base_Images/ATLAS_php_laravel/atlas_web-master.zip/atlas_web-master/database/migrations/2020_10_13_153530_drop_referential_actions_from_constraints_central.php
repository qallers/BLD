<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class DropReferentialActionsFromConstraintsCentral extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('domains', function (Blueprint $table)
        {
            $table->dropForeign('domains_tenant_id_foreign');
        });

        Schema::table('domains', function (Blueprint $table)
        {
            $table->foreign('tenant_id')->references('id')->on('tenants');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('domains', function (Blueprint $table)
        {
            $table->dropForeign('domains_tenant_id_foreign');
        });

        Schema::table('domains', function (Blueprint $table)
        {
            $table->foreign('tenant_id')->references('id')->on('tenants')->onUpdate('cascade')->onDelete('cascade');
        });
    }
}
