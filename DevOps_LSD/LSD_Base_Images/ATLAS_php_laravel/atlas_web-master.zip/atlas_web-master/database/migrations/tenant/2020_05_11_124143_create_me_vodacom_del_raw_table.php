<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeVodacomDelRawTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_vodacom_del_raw', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('network_id');
			$table->string('serial_no', 35);
			$table->dateTime('del_month');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_vodacom_del_raw');
	}

}
