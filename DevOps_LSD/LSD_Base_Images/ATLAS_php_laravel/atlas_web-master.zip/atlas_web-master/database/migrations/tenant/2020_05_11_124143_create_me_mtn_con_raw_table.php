<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeMtnConRawTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_mtn_con_raw', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('network_id');
			$table->string('primary_grp', 30);
			$table->string('prov_first_conn', 30)->nullable();
			$table->string('city_first_conn', 30)->nullable();
			$table->string('customer_name', 30)->nullable();
			$table->string('address1', 30)->nullable();
			$table->string('province', 30)->nullable();
			$table->string('region_name', 30)->nullable();
			$table->string('category_set_name', 30)->nullable();
			$table->string('description', 30)->nullable();
			$table->string('cat_segment2', 30)->nullable();
			$table->string('cat_segment3', 30)->nullable();
			$table->string('distribution_date', 30)->nullable();
			$table->string('msisdn', 30)->nullable();
			$table->string('serial_number', 30)->nullable();
			$table->string('trx_number', 30)->nullable();
			$table->string('box_serial_number', 30)->nullable();
			$table->string('brick_serial_number', 30)->nullable();
			$table->string('activation_date', 30)->nullable();
			$table->string('act_inc_prt', 30)->nullable();
			$table->string('port_in_flag', 30)->nullable();
			$table->string('usage_spent_4mths', 30)->nullable();
			$table->string('usage_spent_7mths', 30)->nullable();
			$table->string('list_price', 30)->nullable();
			$table->string('selling_price', 30)->nullable();
			$table->string('cps135_sim', 30)->nullable();
			$table->string('comms_category', 30)->nullable();
			$table->string('comm_excl', 30)->nullable();
			$table->string('vat', 30)->nullable();
			$table->string('comm_incl', 30)->nullable();
			$table->string('agents_company_name', 30)->nullable();
			$table->string('rica_date', 30)->nullable();
			$table->string('officers_identity_number', 30)->nullable();
			$table->string('officers_company_name', 30)->nullable();
			$table->string('officers_name', 30)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_mtn_con_raw');
	}

}
