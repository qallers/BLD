<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreatePurchaseOrderTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('purchase_order', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('warehouse_id');
			$table->integer('supplier_id');
			$table->integer('product_id');
			$table->integer('qty');
			$table->integer('import_qty')->default(0);
			$table->integer('scanned_qty')->nullable()->default(0);
			$table->boolean('approval_id')->nullable();
			$table->boolean('priority')->default(0);
			$table->string('external_reference', 20)->nullable();
			$table->dateTime('order_date')->default('2000-01-01 00:00:00');
			$table->integer('status_id');
			$table->integer('user_id');
			$table->boolean('is_rep')->default(0);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('purchase_order');
	}

}
