<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToBulkOrderTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('bulk_order', function(Blueprint $table)
		{
			$table->foreign('delivery_method_id', 'fk_delivery_id')->references('id')->on('status')->onUpdate('CASCADE')->onDelete('CASCADE');
			$table->foreign('payment_status_id', 'fk_payment_id')->references('id')->on('status')->onUpdate('CASCADE')->onDelete('CASCADE');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('bulk_order', function(Blueprint $table)
		{
			$table->dropForeign('fk_delivery_id');
			$table->dropForeign('fk_payment_id');
		});
	}

}
