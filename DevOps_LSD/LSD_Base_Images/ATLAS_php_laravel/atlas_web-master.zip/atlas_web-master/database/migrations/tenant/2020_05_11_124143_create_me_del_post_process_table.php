<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeDelPostProcessTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_del_post_process', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('customer_id');
			$table->integer('network_id');
			$table->string('invoice_number', 25);
			$table->integer('sales_order_detail_id');
			$table->integer('product_id');
			$table->string('serial_no', 35)->index('serial_no');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_del_post_process');
	}

}
