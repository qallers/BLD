<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeMtnRetailRawTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_mtn_retail_raw', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('network_id');
			$table->string('primary_grp', 30);
			$table->string('customer_number', 10);
			$table->string('description', 100);
			$table->string('store', 30);
			$table->string('demand_class_code', 30);
			$table->string('branded_store_code', 20);
			$table->string('customer_name', 30)->nullable();
			$table->string('province', 30)->nullable();
			$table->string('region_name', 30)->nullable();
			$table->string('category_set_name', 30)->nullable();
			$table->string('cat_segment2', 30)->nullable();
			$table->string('cat_segment3', 30)->nullable();
			$table->string('distribution_date', 30)->nullable();
			$table->string('msisdn', 30)->nullable();
			$table->string('sim', 30)->nullable();
			$table->string('serial_number', 30)->nullable();
			$table->string('activation_date', 30)->nullable();
			$table->string('comm_excl', 30)->nullable();
			$table->string('vat', 30)->nullable();
			$table->string('comm_incl', 30)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_mtn_retail_raw');
	}

}
