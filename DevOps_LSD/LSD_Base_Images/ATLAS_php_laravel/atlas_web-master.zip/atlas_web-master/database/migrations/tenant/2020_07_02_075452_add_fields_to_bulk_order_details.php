<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldsToBulkOrderDetails extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('bulk_order_details', function (Blueprint $table) {
            $table->integer('price')->nullable()->after('qty');
            $table->integer('warehouse_id')->nullable()->after('price');
            $table->integer('payment_status_id')->nullable()->after('warehouse_id');
            $table->integer('delivery_method_id')->nullable()->after('payment_status_id');
            $table->boolean('bill_to_headoffice')->nullable()->after('delivery_method_id');
            $table->boolean('deliver_to_headoffice')->nullable()->after('bill_to_headoffice');
            $table->integer('parent_id')->nullable()->after('deliver_to_headoffice');
           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('bulk_order_details', function (Blueprint $table) {
            //
        });
    }
}
