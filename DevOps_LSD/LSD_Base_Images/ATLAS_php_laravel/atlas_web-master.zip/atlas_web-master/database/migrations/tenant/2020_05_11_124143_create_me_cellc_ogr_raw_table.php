<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeCellcOgrRawTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_cellc_ogr_raw', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('network_id');
			$table->string('serial_no', 35);
			$table->decimal('denom', 13, 4);
			$table->integer('recharge_count');
			$table->string('msisdn', 15);
			$table->decimal('denom_duplicate', 13, 4);
			$table->decimal('revenue_percentage', 13, 4);
			$table->string('cust_code', 20);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_cellc_ogr_raw');
	}

}
