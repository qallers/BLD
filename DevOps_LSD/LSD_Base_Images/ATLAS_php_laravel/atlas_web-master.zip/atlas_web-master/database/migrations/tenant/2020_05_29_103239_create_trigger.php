<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTrigger extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        DB::unprepared("CREATE TRIGGER `changeStatusSaleOrder` AFTER UPDATE ON `sales_order_detail` FOR EACH ROW BEGIN
DECLARE P1,P2 int(11);
SELECT COUNT(id) INTO P1 FROM sales_order_detail WHERE sales_order_id = new.sales_order_id AND is_dispatch = 0;
IF P1 = 0 THEN
SELECT id INTO P2 FROM `status` WHERE process = 'sale_order_dispatch';
UPDATE sales_order SET status_id = P2 WHERE id = new.sales_order_id;
END IF;
END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        DB::unprepared('DROP TRIGGER `changeStatusSaleOrder`');
    }

}
