<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProductDealTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('product_deal', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('name', 35);
			$table->integer('product_id');
			$table->integer('customer_group_id')->nullable();
			$table->integer('customer_id')->nullable();
			$table->decimal('ogr', 13, 4);
			$table->decimal('sim', 13, 4);
			$table->decimal('act', 13, 4);
			$table->boolean('is_active')->default(1);
			$table->dateTime('start_date');
			$table->dateTime('end_date');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('product_deal');
	}

}
