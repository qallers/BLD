<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldsToSalesOrder extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('sales_order', function (Blueprint $table) {
            $table->boolean('bill_to_headoffice')->nullable()->after('delivery_method_id');
            $table->boolean('deliver_to_headoffice')->nullable()->after('bill_to_headoffice');
            $table->integer('parent_id')->nullable()->after('deliver_to_headoffice')->default(-1);
            $table->boolean('is_bulk')->default(0)->after('parent_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('sales_order', function (Blueprint $table) {
            //
        });
    }
}
