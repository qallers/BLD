<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateGrvImportFileTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('grv_import_file', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_config_id');
			$table->integer('purchase_order_id');
			$table->string('supplier_invoice_id', 20);
			$table->string('file_name', 50);
			$table->integer('qty')->default(0);
			$table->boolean('status')->default(0);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('grv_import_file');
	}

}
