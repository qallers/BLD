<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterMeMtnActRawTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('me_mtn_act_raw', function (Blueprint $table) {
            $table->string('xtratime_sfee_repay_4mths', 30)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('me_mtn_act_raw', function (Blueprint $table) {
            $table->dropColumn('xtratime_sfee_repay_4mths');
        });
    }
}
