<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSpCalculateBaseSummary extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('
        CREATE PROCEDURE calculateBaseSummary(
                IN month_to_process DATE)
        BEGIN
            DELETE FROM base_summary
                WHERE rep_month = month_to_process;
                
            INSERT INTO base_summary (
                customer_id
                , rep_month
                , network_id
                , product_id
                , sales_qty
                , rev_income
                , rev_expense
                , conn_qty
                , comm_qty
                , swp_qty
                , del_qty
                , opening_balance
                , closing_balance
                , percentage_vabs
                , active_base
                , comm_income
                , comm_expense
                , swp_income
                , swp_expense
                , sales_income
                , cost_of_sales
                , total_recharge
            ) (
            SELECT c.id AS \'customer_id\'
                ,month_to_process AS \'rep_month\'
                ,p.network_id AS \'network_id\'
                ,p.id AS \'product_id\'
                ,SUM(IFNULL(sod.qty, 0)) AS \'sales_qty\'
                ,SUM(IFNULL(ogr.rev_income, 0)) AS \'rev_income\'
                ,SUM(IFNULL(ogr.rev_expense, 0)) AS \'rev_expense\'
                ,SUM(IFNULL(con.conn_qty, 0)) AS \'conn_qty\'
                ,SUM(IFNULL(act.comm_qty, 0)) AS \'comm_qty\'
                ,SUM(IFNULL(swp.swp_qty, 0)) AS \'swp_qty\'
                ,SUM(IFNULL(del.del_qty, 0)) AS \'del_qty\'
                ,IFNULL(prev_bal.closing_balance, 0) AS \'opening_balance\'
                ,IFNULL(prev_bal.closing_balance, 0) + SUM(IFNULL(con.conn_qty, 0)) - SUM(IFNULL(del.del_qty, 0)) AS \'closing_balance\'
                ,CASE
                    WHEN SUM(IFNULL(con.conn_qty, 0)) > 0
                    THEN (SUM(IFNULL(act.comm_qty, 0)) * 100 / SUM(IFNULL(con.conn_qty, 0)))
                    ELSE 0
                END AS \'percentage_vabs\'
                ,SUM(IFNULL(base.active_base, 0)) AS \'active_base\'
                ,SUM(IFNULL(act.comm_income, 0)) AS \'comm_income\'
                ,SUM(IFNULL(act.comm_expense, 0)) AS \'comm_expense\'
                ,SUM(IFNULL(swp.swp_income, 0)) AS \'swp_income\'
                ,SUM(IFNULL(swp.swp_expense, 0)) AS \'swp_expense\'
                ,SUM(IFNULL(sod.sales_price, 0)) * SUM(IFNULL(sod.qty, 0)) AS \'sales_income\'
                ,SUM(IFNULL(sod.cost, 0)) * SUM(IFNULL(sod.qty, 0)) AS \'cost_of_sales\'
                ,SUM(IFNULL(ogr.total_recharge, 0)) AS \'total_recharge\'
            FROM customer c
            LEFT JOIN sales_order so ON so.customer_id = c.id
            LEFT JOIN sales_order_detail sod ON sod.sales_order_id = so.id
            LEFT JOIN product p ON p.id = sod.product_id
            LEFT JOIN (
                SELECT t1.customer_id AS \'customer_id\'
                ,t1.product_id AS \'product_id\'
                ,SUM(IFNULL(t1.income, 0)) AS \'rev_income\'
                ,CASE
                    WHEN t4.customer_id IS NOT NULL AND t4.stop_revenue = 1 THEN 0 
                    ELSE SUM(IFNULL(t1.expense, 0))
                END AS \'rev_expense\'
                ,SUM(IFNULL(t3.total_recharge, 0)) AS \'total_recharge\'
                FROM me_ogr_post_process t1
                INNER JOIN me_import_file t2 ON t2.id = t1.file_id
                INNER JOIN me_ogr_pre_process t3 ON t3.serial_no = t1.serial_no
                    AND t3.file_id = t2.id
                LEFT JOIN stop_revenue t4 ON t4.customer_id = t1.customer_id
                    AND DATE_SUB(LAST_DAY(t4.from_date),INTERVAL DAY(LAST_DAY(t4.from_date))-1 DAY) <= month_to_process
                    AND month_to_process <= LAST_DAY(t4.to_date)
                WHERE t2.process_month = month_to_process
                GROUP BY t1.customer_id
                    ,t1.product_id
            ) AS ogr ON ogr.customer_id = c.id
                AND ogr.product_id = p.id
            LEFT JOIN (
                SELECT t1.customer_id AS \'customer_id\'
                ,t1.product_id AS \'product_id\'
                ,COUNT(IFNULL(t1.serial_no, 0)) AS \'conn_qty\'
                FROM me_con_post_process t1
                INNER JOIN me_import_file t2 ON t2.id = t1.file_id
                WHERE t2.process_month = month_to_process
                GROUP BY t1.customer_id
                    ,t1.product_id
            ) AS con ON con.customer_id = c.id
                AND con.product_id = p.id
            LEFT JOIN (
                SELECT t1.customer_id AS \'customer_id\'
                ,t1.product_id AS \'product_id\'
                ,COUNT(IFNULL(t1.serial_no, 0)) AS \'comm_qty\'
                ,SUM(IFNULL(t1.income, 0)) AS \'comm_income\'
                ,CASE
                    WHEN t3.customer_id IS NOT NULL AND t3.stop_rebate = 1 THEN 0
                    ELSE SUM(IFNULL(t1.expense, 0))
                END AS \'comm_expense\'
                FROM me_act_post_process t1
                INNER JOIN me_import_file t2 ON t2.id = t1.file_id
                LEFT JOIN stop_revenue t3 ON t3.customer_id = t1.customer_id
                    AND DATE_SUB(LAST_DAY(t3.from_date),INTERVAL DAY(LAST_DAY(t3.from_date))-1 DAY) <= month_to_process
                    AND month_to_process <= LAST_DAY(t3.to_date)
                WHERE t2.process_month = month_to_process
                GROUP BY t1.customer_id
                    ,t1.product_id
            ) AS act ON act.customer_id = c.id
                AND act.product_id = p.id
            LEFT JOIN (
                SELECT t1.customer_id AS \'customer_id\'
                ,t1.product_id AS \'product_id\'
                ,COUNT(IFNULL(t1.serial_no, 0)) AS \'swp_qty\'
                ,SUM(IFNULL(t1.income, 0)) AS \'swp_income\'
                ,CASE
                    WHEN t3.customer_id IS NOT NULL AND t3.stop_simswap = 1 THEN 0
                    ELSE SUM(IFNULL(t1.expense, 0))
                END AS \'swp_expense\'
                FROM me_swp_post_process t1
                INNER JOIN me_import_file t2 ON t2.id = t1.file_id
                LEFT JOIN stop_revenue t3 ON t3.customer_id = t1.customer_id
                    AND DATE_SUB(LAST_DAY(t3.from_date),INTERVAL DAY(LAST_DAY(t3.from_date))-1 DAY) <= month_to_process
                    AND month_to_process <= LAST_DAY(t3.to_date)
                WHERE t2.process_month = month_to_process
                GROUP BY t1.customer_id
                    ,t1.product_id
            ) AS swp ON swp.customer_id = c.id
                AND swp.product_id = p.id
            LEFT JOIN (
                SELECT t1.customer_id AS \'customer_id\'
                ,t1.product_id AS \'product_id\'
                ,COUNT(IFNULL(t1.serial_no, 0)) AS \'del_qty\'
                FROM me_del_post_process t1
                INNER JOIN me_import_file t2 ON t2.id = t1.file_id
                WHERE t2.process_month = month_to_process
                GROUP BY t1.customer_id
                    ,t1.product_id
            ) AS del ON del.customer_id = c.id
                AND del.product_id = p.id
            LEFT JOIN (
                SELECT t1.customer_id AS \'customer_id\'
                ,t1.product_id AS \'product_id\'
                ,COUNT(t1.serial_no) AS \'active_base\'
                FROM me_ogr_post_process t1
                INNER JOIN me_import_file t2 ON t2.id = t1.file_id
                INNER JOIN me_ogr_pre_process t3 ON t3.serial_no = t1.serial_no
                WHERE t2.process_month = month_to_process
                    AND t3.revenue_percentage > 0
                GROUP BY t1.customer_id
                ,t1.product_id
            ) AS base ON base.customer_id = c.id
                AND base.product_id = p.id
            LEFT JOIN (
                SELECT customer_id AS \'customer_id\'
                ,product_id AS \'product_id\'
                ,MAX(rep_month) AS \'rep_month\'
                ,IFNULL(closing_balance, 0) AS \'closing_balance\'
                FROM base_summary
                GROUP BY customer_id
                ,product_id
                ORDER BY rep_month DESC
            ) AS prev_bal ON prev_bal.customer_id = c.id
                AND prev_bal.product_id = p.id
            WHERE so.created_at BETWEEN DATE_SUB(LAST_DAY(month_to_process),INTERVAL DAY(LAST_DAY(month_to_process))-1 DAY) AND LAST_DAY(month_to_process)
                AND sod.id IS NOT NULL
            GROUP BY c.id
                ,p.network_id
                ,p.id
            ORDER BY c.id
                ,p.network_id
                ,p.id
            );
        END;
        ');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS calculateBaseSummary');
    }
}
