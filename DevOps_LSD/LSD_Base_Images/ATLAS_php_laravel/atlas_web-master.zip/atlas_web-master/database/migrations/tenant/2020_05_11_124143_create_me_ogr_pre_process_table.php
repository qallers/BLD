<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeOgrPreProcessTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_ogr_pre_process', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id')->index('file_id');
			$table->integer('network_id');
			$table->string('serial_no', 35)->index('serial_no');
			$table->decimal('total_recharge', 13, 4);
			$table->decimal('revenue_percentage', 13, 4);
			$table->boolean('status');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_ogr_pre_process');
	}

}
