<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeTelkomActRawTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_telkom_act_raw', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('network_id');
			$table->string('dealer_code', 5);
			$table->string('dealer_name', 50);
			$table->string('msisdn', 15);
			$table->string('iccid', 30);
			$table->string('imei', 30);
			$table->string('tariff_plan', 10);
			$table->date('connection_date');
			$table->date('billing_period');
			$table->string('commission_code', 40);
			$table->string('subscriber_type', 10);
			$table->decimal('commission_amount', 13, 4);
			$table->decimal('commission_amount_excl_vat', 13, 4);
			$table->string('deal_id', 10);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_telkom_act_raw');
	}

}
