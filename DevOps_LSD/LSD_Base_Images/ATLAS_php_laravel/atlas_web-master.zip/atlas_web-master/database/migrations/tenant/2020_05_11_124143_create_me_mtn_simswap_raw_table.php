<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeMtnSimswapRawTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_mtn_simswap_raw', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('network_id');
			$table->string('primary_grp', 30);
			$table->string('prov_first_conn', 20);
			$table->string('city_first_conn', 20);
			$table->string('customer_name', 50);
			$table->string('address1', 30);
			$table->string('category_set_name', 20);
			$table->string('description', 50);
			$table->string('serial_number', 30);
			$table->decimal('usage', 13, 4);
			$table->decimal('comm_excl', 13, 4);
			$table->decimal('vat', 13, 4);
			$table->decimal('comm_incl', 13, 4);
			$table->string('sim_flag', 5);
			$table->string('sim_flag_month', 5);
			$table->string('donor_sim', 30);
			$table->date('donor_sim_swap_date');
			$table->string('donor_kit_sim', 30);
			$table->string('donor_msisdn', 15);
			$table->string('donor_trans_date', 15);
			$table->string('customer_category_code', 5);
			$table->decimal('accumulated_usage', 13, 4);
			$table->string('category', 10);
			$table->string('customer_number', 20);
			$table->string('site_use_id', 20);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_mtn_simswap_raw');
	}

}
