<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateSalesDealTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('sales_deal', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('sales_order_detail_id')->index('sales_order_detail_id');
			$table->string('invoice_number', 25)->nullable();
			$table->integer('customer_id');
			$table->decimal('act', 13, 4)->default(0.0000);
			$table->decimal('ogr', 13, 4)->default(0.0000);
			$table->decimal('sim', 13, 4)->default(0.0000);
			$table->integer('ogr_tier')->nullable();
			$table->integer('act_tier')->nullable();
			$table->integer('sim_tier')->nullable();
			$table->boolean('is_split');
			$table->boolean('is_tiered');
			$table->boolean('split_customer');
			$table->date('start_date');
			$table->date('end_date');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('sales_deal');
	}

}
