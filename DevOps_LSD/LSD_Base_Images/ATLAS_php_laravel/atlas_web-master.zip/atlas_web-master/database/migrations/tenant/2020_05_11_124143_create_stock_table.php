<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateStockTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('stock', function(Blueprint $table)
		{
			$table->string('serial_no', 35)->primary();
			$table->string('imsi_no', 15)->nullable();
			$table->integer('network_id')->nullable()->index('network_id');
			$table->integer('product_id')->nullable()->index('product_id');
			$table->integer('box_id')->nullable()->index('box_id');
			$table->integer('customer_id')->nullable()->index('customer_id');
			$table->integer('sales_order_detail_id')->nullable()->index('sales_order_detail_id');
			$table->integer('warehouse_id')->nullable()->index('warehouse_id');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('stock');
	}

}
