<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStockLedgerTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('stock_ledger', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->enum('order_name', array('SALES','PURCHASE','REP'));
			$table->string('process_name', 20);
			$table->integer('order_id')->nullable();
			$table->integer('qty')->nullable();
			$table->integer('status_id')->default(0);
			$table->integer('user_id');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('stock_ledger');
	}

}
