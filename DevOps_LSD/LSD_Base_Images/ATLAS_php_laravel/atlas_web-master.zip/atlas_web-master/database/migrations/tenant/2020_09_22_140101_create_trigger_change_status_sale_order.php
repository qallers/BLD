<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class CreateTriggerChangeStatusSaleOrder extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        DB::unprepared('DROP TRIGGER IF EXISTS `changeStatusSaleOrder`');
        
        DB::unprepared("CREATE TRIGGER `changeStatusSaleOrder` AFTER UPDATE ON `sales_order_detail`
 FOR EACH ROW BEGIN
DECLARE P1,P2 int(11);
DECLARE P3,P4 int(11);
SELECT COUNT(id) INTO P1 FROM sales_order_detail WHERE sales_order_id = new.sales_order_id AND is_dispatch = 0;

SELECT COUNT(id) INTO P3 FROM sales_order_detail WHERE sales_order_id = new.sales_order_id AND is_allocate = 0;

IF P1 = 0 THEN
SELECT id INTO P2 FROM `status` WHERE process = 'sale_order_dispatch';
UPDATE sales_order SET status_id = P2 WHERE id = new.sales_order_id;
END IF;

IF P3 = 0 THEN
SELECT id INTO P4 FROM `status` WHERE process = 'sales_order' AND `status` = 'allocated';
UPDATE sales_order SET status_id = P4 WHERE id = new.sales_order_id;
END IF;
END");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        DB::unprepared('DROP TRIGGER IF EXISTS `changeStatusSaleOrder`');
    }

}
