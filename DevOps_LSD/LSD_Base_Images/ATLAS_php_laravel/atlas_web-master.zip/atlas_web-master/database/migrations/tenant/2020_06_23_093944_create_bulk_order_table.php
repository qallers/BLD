<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateBulkOrderTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('bulk_order', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('warehouse_id');
			$table->integer('user_id')->index('user_id');
			$table->integer('customer_id')->index('customer_id');
			$table->integer('payment_status_id')->index('fk_payment_id');
			$table->integer('delivery_method_id')->index('fk_delivery_id');
			$table->integer('product_id');
			$table->integer('qty');
			$table->integer('price');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('bulk_order');
	}

}
