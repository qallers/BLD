<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeMtnOgrRawTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_mtn_ogr_raw', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('network_id');
			$table->string('primary_grp', 30);
			$table->string('prov_first_conn', 30)->nullable();
			$table->string('city_first_conn', 30)->nullable();
			$table->string('customer_group', 30)->nullable();
			$table->string('customer_name', 30)->nullable();
			$table->string('address1', 30)->nullable();
			$table->string('province', 30)->nullable();
			$table->string('region_name', 30)->nullable();
			$table->string('category_set_name', 30)->nullable();
			$table->string('description', 30)->nullable();
			$table->string('cat_segment2', 30)->nullable();
			$table->string('cat_segment3', 30)->nullable();
			$table->string('distribution_date', 30)->nullable();
			$table->string('msisdn', 15)->nullable();
			$table->string('serial_number', 30)->nullable();
			$table->string('trx_number', 30)->nullable();
			$table->string('box_serial_number', 30)->nullable();
			$table->string('brick_serial_number', 30)->nullable();
			$table->string('cps135_imei_number', 30)->nullable();
			$table->string('activation_date', 30)->nullable();
			$table->date('comm_mth')->nullable();
			$table->string('comms_category', 30)->nullable();
			$table->string('comm_excl', 30)->nullable();
			$table->string('vat', 30)->nullable();
			$table->string('comm_incl', 30)->nullable();
			$table->string('base', 10)->nullable();
			$table->float('percentage', 10, 0)->nullable();
			$table->string('revenue_mth_0', 30)->nullable();
			$table->string('revenue_mth_1', 30)->nullable();
			$table->string('revenue_mth_2', 30)->nullable();
			$table->string('revenue_mth_3', 30)->nullable();
			$table->string('total_recharge_amt', 30)->nullable();
			$table->string('pre_loaded', 30)->nullable();
			$table->string('billdur', 30)->nullable();
			$table->string('callcost', 30)->nullable();
			$table->string('smscost', 30)->nullable();
			$table->string('mmsamt', 30)->nullable();
			$table->string('gprsamt', 30)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_mtn_ogr_raw');
	}

}
