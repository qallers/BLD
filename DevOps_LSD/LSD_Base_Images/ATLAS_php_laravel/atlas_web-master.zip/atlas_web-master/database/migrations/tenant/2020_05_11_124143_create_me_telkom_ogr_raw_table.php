<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeTelkomOgrRawTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_telkom_ogr_raw', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('network_id');
			$table->string('dealer_code', 5);
			$table->string('dealer_name', 50);
			$table->string('msisdn', 15);
			$table->string('sim_seq_num', 30);
			$table->string('imei', 30);
			$table->date('connection_date');
			$table->date('billing_period');
			$table->string('commission_code', 40);
			$table->string('subscriber_type', 10);
			$table->string('deal_id', 10);
			$table->decimal('commissionable_amount', 13, 4);
			$table->decimal('commission_amount', 13, 4);
			$table->decimal('commission_amount_excl_vat', 13, 4);
			$table->decimal('commissionable_percent', 13, 4);
			$table->string('sub_dealer_code', 10);
			$table->string('comm_rocode', 10);
			$table->string('retail_outlet_name', 50);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_telkom_ogr_raw');
	}

}
