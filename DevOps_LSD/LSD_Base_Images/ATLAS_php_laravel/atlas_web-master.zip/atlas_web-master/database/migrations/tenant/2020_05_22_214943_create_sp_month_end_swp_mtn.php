<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSpMonthEndSwpMtn extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('
        CREATE PROCEDURE MonthEndSWPMTN(
            IN me_file_id INT (10) UNSIGNED
            ,IN recal INT (10) UNSIGNED
        )
        BEGIN
        UPDATE me_import_file
        SET cal_status = 1
        WHERE id = me_file_id;
        
        IF recal = 1
            THEN
            DELETE FROM me_swp_pre_process
            WHERE file_id = me_file_id;
        END IF;
        
        INSERT INTO me_swp_pre_process (
            file_id
            ,network_id
            ,serial_no
            ,price
            ,STATUS
        )
        (SELECT
            file_id
            ,network_id
            ,serial_number
            ,SUM(comm_incl)
            ,0
        FROM me_mtn_simswap_raw
        WHERE file_id = me_file_id
        GROUP BY file_id
            ,network_id
            ,serial_number);
            
        CALL calculationPostProcessSimswap (me_file_id, recal);
        
        UPDATE me_import_file
        SET cal_status = 2
        WHERE id = me_file_id;
        END;
        ');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS MonthEndSWPMTN');
    }
}
