<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeImportFileTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_import_file', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('file_name', 60);
			$table->date('process_month');
			$table->integer('network_id');
			$table->integer('file_config_id');
			$table->boolean('status')->default(0);
			$table->boolean('cal_status')->default(0);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_import_file');
	}

}
