<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeOgrPostProcessTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_ogr_post_process', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('customer_id');
			$table->integer('network_id');
			$table->string('invoice_number', 25)->default('0');
			$table->integer('sales_order_detail_id');
			$table->integer('product_id');
			$table->string('serial_no', 35)->index('serial_no');
			$table->decimal('income', 13, 4);
			$table->decimal('expense', 13, 4);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_ogr_post_process');
	}

}
