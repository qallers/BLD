<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeVodacomConRawTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_vodacom_con_raw', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('network_id');
			$table->string('serial_no', 35);
			$table->date('conn_month');
			$table->string('msisdn', 15);
			$table->float('denom', 10, 0);
			$table->string('cust_code', 20);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_vodacom_con_raw');
	}

}
