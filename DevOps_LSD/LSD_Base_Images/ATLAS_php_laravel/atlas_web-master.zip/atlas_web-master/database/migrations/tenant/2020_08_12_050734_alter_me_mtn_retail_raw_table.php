<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterMeMtnRetailRawTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('me_mtn_retail_raw', function (Blueprint $table) {
            $table->string('report_month', 6)->after('network_id');
            $table->string('simFlag', 5)->after('report_month');
            $table->string('simFlagMonth', 6)->after('simFlag');
            $table->string('simFlagQtr', 5)->after('simFlagMonth');
			$table->string('deactivation_date', 30)->after('distribution_date');
			$table->string('customer_class_code', 30)->after('store');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('me_mtn_retail_raw', function (Blueprint $table) {
            $table->dropColumn('report_month');
            $table->dropColumn('simFlag');
            $table->dropColumn('simFlagMonth');
            $table->dropColumn('simFlagQtr');
            $table->dropColumn('deactivation_date');
            $table->dropColumn('customer_class_code');
        });
    }
}
