<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddIndexesToSerial extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('me_cellc_act_raw', function (Blueprint $table) {
            $table->index('serial_no');
        });
        Schema::table('me_cellc_con_raw', function (Blueprint $table) {
            $table->index('serial_no');
        });
        Schema::table('me_cellc_ogr_raw', function (Blueprint $table) {
            $table->index('serial_no');
        });
        Schema::table('me_con_pre_process', function (Blueprint $table) {
            $table->index('serial_no');
        });
        Schema::table('me_mtn_act_raw', function (Blueprint $table) {
            $table->index('serial_number');
        });
        Schema::table('me_mtn_con_raw', function (Blueprint $table) {
            $table->index('serial_number');
        });
        Schema::table('me_mtn_del_raw', function (Blueprint $table) {
            $table->index('serial_number');
        });
        Schema::table('me_mtn_ogr_raw', function (Blueprint $table) {
            $table->index('serial_number');
        });
        Schema::table('me_mtn_retail_raw', function (Blueprint $table) {
            $table->index('serial_number');
        });
        Schema::table('me_mtn_simswap_raw', function (Blueprint $table) {
            $table->index('serial_number');
        });
        Schema::table('me_telkom_act_raw', function (Blueprint $table) {
            $table->index('iccid');
        });
        Schema::table('me_telkom_ogr_raw', function (Blueprint $table) {
            $table->index('sim_seq_num');
        });
        Schema::table('me_vodacom_act_raw', function (Blueprint $table) {
            $table->index('serial_no');
        });
        Schema::table('me_vodacom_con_raw', function (Blueprint $table) {
            $table->index('serial_no');
        });
        Schema::table('me_vodacom_del_raw', function (Blueprint $table) {
            $table->index('serial_no');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('me_cellc_act_raw', function (Blueprint $table) {
            $table->dropIndex('serial_no');            
        });
        Schema::table('me_cellc_con_raw', function (Blueprint $table) {
            $table->dropIndex('serial_no');            
        });
        Schema::table('me_cellc_ogr_raw', function (Blueprint $table) {
            $table->dropIndex('serial_no');            
        });
        Schema::table('me_con_pre_process', function (Blueprint $table) {
            $table->dropIndex('serial_no');            
        });
        Schema::table('me_mtn_act_raw', function (Blueprint $table) {
            $table->dropIndex('serial_number');            
        });
        Schema::table('me_mtn_con_raw', function (Blueprint $table) {
            $table->dropIndex('serial_number');            
        });
        Schema::table('me_mtn_del_raw', function (Blueprint $table) {
            $table->dropIndex('serial_number');            
        });
        Schema::table('me_mtn_ogr_raw', function (Blueprint $table) {
            $table->dropIndex('serial_number');            
        });
        Schema::table('me_mtn_retail_raw', function (Blueprint $table) {
            $table->dropIndex('serial_number');            
        });
        Schema::table('me_mtn_simswap_raw', function (Blueprint $table) {
            $table->dropIndex('serial_number');            
        });
        Schema::table('me_telkom_act_raw', function (Blueprint $table) {
            $table->dropIndex('iccid');            
        });
        Schema::table('me_telkom_ogr_raw', function (Blueprint $table) {
            $table->dropIndex('sim_seq_num');            
        });
        Schema::table('me_vodacom_act_raw', function (Blueprint $table) {
            $table->dropIndex('serial_no');            
        });
        Schema::table('me_vodacom_con_raw', function (Blueprint $table) {
            $table->dropIndex('serial_no');            
        });
        Schema::table('me_vodacom_del_raw', function (Blueprint $table) {
            $table->dropIndex('serial_no');            
        });
    }
}
