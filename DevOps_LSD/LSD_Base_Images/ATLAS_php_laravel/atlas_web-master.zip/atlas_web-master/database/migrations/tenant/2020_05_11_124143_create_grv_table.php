<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateGrvTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('grv', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id')->index('file_id');
			$table->integer('purchase_order_id')->default(0)->index('purchase_order_id');
			$table->string('serial_no', 35)->index('serial_no');
			$table->string('imsi_no', 15)->nullable();
			$table->string('pallet', 10)->index('pallet');
			$table->string('carton', 15)->index('carton');
			$table->string('box', 20)->index('box');
			$table->string('brick', 25)->index('brick');
			$table->string('file_date', 15);
			$table->boolean('status');
			$table->boolean('is_available')->default(0);
			$table->boolean('is_transfer')->default(0);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('grv');
	}

}
