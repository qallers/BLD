<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateSalesOrderTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('sales_order', function(Blueprint $table) {
            $table->integer('id', true);
            $table->integer('customer_id')->index('customer_id');
            $table->integer('user_id');
            $table->integer('status_id')->default(0)->index('status_id');
            $table->integer('warehouse_id');
            $table->integer('approval_id')->nullable();
            $table->integer('priority')->nullable();
            $table->integer('payment_status_id')->index('fkpayment_status');
            $table->integer('delivery_method_id')->index('fkdelivery_mode');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::drop('sales_order');
    }

}
