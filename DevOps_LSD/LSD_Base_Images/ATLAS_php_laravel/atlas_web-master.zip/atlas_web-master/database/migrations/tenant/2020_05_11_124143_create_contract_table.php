<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateContractTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('contract', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('customer_id')->nullable();
			$table->string('name', 20);
			$table->boolean('is_tiered')->default(0);
			$table->integer('tier_id')->nullable();
			$table->decimal('ogr', 13, 4)->nullable();
			$table->decimal('act', 13, 4)->nullable();
			$table->decimal('sim', 13, 4)->nullable();
			$table->integer('network_id');
			$table->boolean('is_split')->default(0);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('contract');
	}

}
