<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBaseSummaryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('base_summary', function (Blueprint $table) {
            $table->integer('customer_id');
            $table->date('rep_month');
            $table->integer('network_id');
            $table->integer('product_id');
            $table->integer('sales_qty');
            $table->decimal('rev_income', 13, 4);
            $table->decimal('rev_expense', 13, 4);
            $table->integer('conn_qty');
            $table->integer('comm_qty');
            $table->integer('swp_qty');
            $table->integer('del_qty');
            $table->integer('opening_balance');
            $table->integer('closing_balance');
            $table->decimal('percentage_vabs', 13, 4);
            $table->integer('active_base');
            $table->decimal('comm_income', 13, 4);
            $table->decimal('comm_expense', 13, 4);
            $table->decimal('swp_income', 13, 4);
            $table->decimal('swp_expense', 13, 4);
            $table->decimal('sales_income', 13, 4);
            $table->decimal('cost_of_sales', 13, 4);
            $table->decimal('total_recharge', 13, 4);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('base_summary');
    }
}
