<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAddressTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('address', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('customer_id')->nullable();
			$table->integer('address_type_id')->index('address_ibfk_1');
			$table->boolean('address_entity_id');
			$table->string('address_line_1', 30);
			$table->string('address_line_2', 30)->nullable();
			$table->string('city', 50)->nullable();
			$table->string('province', 20)->nullable();
			$table->string('postal_code', 10);
			$table->string('gps_coordinates', 64);
			// $table->point('gps_spatial');
			// $table->spatialIndex('gps_spatial');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('address');
	}

}
