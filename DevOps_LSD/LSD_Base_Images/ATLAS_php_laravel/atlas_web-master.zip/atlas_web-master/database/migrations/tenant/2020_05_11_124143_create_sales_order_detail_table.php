<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateSalesOrderDetailTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('sales_order_detail', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('sales_order_id')->index('sales_order_id');
			$table->integer('product_id')->index('product_id');
			$table->integer('product_deal_id')->nullable();
			$table->integer('split_deal_id')->nullable();
			$table->integer('qty')->default(0);
			$table->decimal('cost', 13, 4)->default(0.0000);
			$table->decimal('sales_price', 13, 4)->default(0.0000);
			$table->string('invoice_number', 25)->nullable();
                        $table->boolean("is_dispatch")->default(0);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('sales_order_detail');
	}

}
