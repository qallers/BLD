<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateDispatchTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('dispatch', function(Blueprint $table)
		{
			$table->integer('id')->nullable();
			$table->integer('invoice_id')->nullable();
			$table->integer('qty')->nullable();
			$table->integer('warehouse_id')->nullable();
			$table->integer('status_id')->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('dispatch');
	}

}
