<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProductTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('product', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('description', 100);
			$table->string('product_code', 25)->index('code');
			$table->integer('supplier_id')->index('supplier');
			$table->integer('network_id')->index('network_id');
			$table->integer('manufacture_id')->nullable()->index('manufacture_id');
			$table->integer('product_type_id')->nullable()->index('product_type');
			$table->decimal('cost_price', 13, 4)->nullable();
			$table->decimal('sale_price', 13, 4)->nullable();
			$table->boolean('is_active')->default(1);
			$table->boolean('has_preloaded_airtime')->nullable();
			$table->decimal('preloaded_amount', 13, 4)->nullable();
			$table->boolean('is_benefit_pack')->nullable();
			$table->string('ussd', 10)->nullable();
			$table->string('import_code', 10)->nullable();
			$table->string('act_expense_code', 20);
			$table->string('ogr_expense_code', 20);
			$table->string('sim_expense_code', 20)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('product');
	}

}
