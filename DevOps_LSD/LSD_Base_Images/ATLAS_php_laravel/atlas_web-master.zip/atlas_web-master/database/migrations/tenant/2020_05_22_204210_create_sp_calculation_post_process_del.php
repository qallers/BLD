<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSpCalculationPostProcessDel extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('
        CREATE PROCEDURE calculationPostProcessDel (
            IN me_file_id INT UNSIGNED
            ,IN recal TINYINT UNSIGNED
            ,IN raw_table VARCHAR(20)
        )
        BEGIN
        DECLARE proc_month DATETIME;
        
        SELECT process_month
        INTO proc_month
        FROM me_import_file
        WHERE id = me_file_id;
        
        IF recal = 1
            THEN
            DELETE FROM me_del_post_process
            WHERE file_id = me_file_id;
        END IF;
        
        CREATE TEMPORARY TABLE IF NOT EXISTS
            valid_deals AS (
                SELECT sales_order_detail_id
                    ,MAX(id) AS \'id\'
                    ,customer_id
                    FROM sales_deal
                    WHERE DATE_SUB(LAST_DAY(start_date),INTERVAL DAY(LAST_DAY(start_date))-1 DAY) <= proc_month
                        AND proc_month <= end_date
                    GROUP BY sales_order_detail_id, customer_id
                    ORDER BY id DESC
            );
        
        IF raw_table = \'me_vodacom_del_raw\'
            THEN
            INSERT INTO me_del_post_process (
                file_id
                ,customer_id
                ,network_id
                ,invoice_number
                ,sales_order_detail_id
                ,product_id
                ,serial_no
            )
            (SELECT t2.id
            ,CASE
                WHEN t3.serial_no IS NULL THEN -2
                WHEN t3.customer_id IS NULL THEN -1
                WHEN t5.customer_id IS NULL AND t3.customer_id IS NOT NULL THEN t3.customer_id
                ELSE t5.customer_id
            END AS \'customer_id\'
                ,CASE
                    WHEN t3.serial_no IS NULL THEN -2
                    WHEN t3.network_id IS NULL THEN -1
                    ELSE t3.network_id
                END AS \'network_id\'
                ,CASE
                    WHEN t3.serial_no IS NULL THEN -2
                    WHEN t3.sales_order_detail_id IS NULL THEN -1
                    WHEN t5.invoice_number IS NOT NULL THEN t5.invoice_number
                    ELSE t5.sales_order_detail_id
                END AS \'invoice_number\'
                ,CASE
                    WHEN t3.serial_no IS NULL THEN -2
                    WHEN t3.sales_order_detail_id IS NULL THEN -1
                    ELSE t5.sales_order_detail_id
                END AS \'sales_order_detail_id\'
                ,CASE
                    WHEN t3.serial_no IS NULL THEN -2
                    ELSE t3.product_id
                END AS \'product_id\'
                ,t1.serial_no
            FROM me_vodacom_del_raw t1
            INNER JOIN me_import_file t2 ON t2.id = t1.file_id
            LEFT JOIN stock t3 ON t3.serial_no = t1.serial_no
            LEFT JOIN valid_deals t4 ON t4.sales_order_detail_id = t3.sales_order_detail_id
            LEFT JOIN sales_deal t5 ON t5.id = t4.id AND t5.customer_id = t4.customer_id
            LEFT JOIN stop_revenue t6 ON t6.customer_id = t3.customer_id
                AND DATE_SUB(LAST_DAY(t6.from_date),INTERVAL DAY(LAST_DAY(t6.from_date))-1 DAY) <= proc_month
                AND proc_month <= t6.to_date
            WHERE t2.id = me_file_id);
        END IF;
        
        IF raw_table = \'me_mtn_del_raw\'
            THEN
            INSERT INTO me_del_post_process (
                file_id
                ,customer_id
                ,network_id
                ,invoice_number
                ,sales_order_detail_id
                ,product_id
                ,serial_no
            )
            (SELECT t2.id
            ,CASE
                WHEN t3.serial_no IS NULL THEN -2
                WHEN t3.customer_id IS NULL THEN -1
                WHEN t5.customer_id IS NULL AND t3.customer_id IS NOT NULL THEN t3.customer_id
                ELSE t5.customer_id
            END AS \'customer_id\'
                ,CASE
                    WHEN t3.serial_no IS NULL THEN -2
                    WHEN t3.network_id IS NULL THEN -1
                    ELSE t3.network_id
                END AS \'network_id\'
                ,CASE
                    WHEN t3.serial_no IS NULL THEN -2
                    WHEN t3.sales_order_detail_id IS NULL THEN -1
                    WHEN t5.invoice_number IS NOT NULL THEN t5.invoice_number
                    ELSE t5.sales_order_detail_id
                END AS \'invoice_number\'
                ,CASE
                    WHEN t3.serial_no IS NULL THEN -2
                    WHEN t3.sales_order_detail_id IS NULL THEN -1
                    ELSE t5.sales_order_detail_id
                END AS \'sales_order_detail_id\'
                ,CASE
                    WHEN t3.serial_no IS NULL THEN -2
                    ELSE t3.product_id
                END AS \'product_id\'
                ,t1.serial_number
            FROM me_mtn_del_raw t1
            INNER JOIN me_import_file t2 ON t2.id = t1.file_id
            LEFT JOIN stock t3 ON t3.serial_no = t1.serial_number
            LEFT JOIN valid_deals t4 ON t4.sales_order_detail_id = t3.sales_order_detail_id
            LEFT JOIN sales_deal t5 ON t5.id = t4.id AND t5.customer_id = t4.customer_id
            LEFT JOIN stop_revenue t6 ON t6.customer_id = t3.customer_id
                AND DATE_SUB(LAST_DAY(t6.from_date),INTERVAL DAY(LAST_DAY(t6.from_date))-1 DAY) <= proc_month
                AND proc_month <= t6.to_date
            WHERE t2.id = me_file_id);
        END IF;
        
        UPDATE me_import_file
        SET cal_status = 2
        WHERE id = me_file_id;
        
        DROP TABLE IF EXISTS valid_deals;
        END;
        ');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS calculationPostProcessDel');
    }
}
