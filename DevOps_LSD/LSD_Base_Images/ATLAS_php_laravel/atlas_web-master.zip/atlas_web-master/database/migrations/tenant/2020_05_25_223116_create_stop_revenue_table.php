<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateStopRevenueTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('stop_revenue', function(Blueprint $table)
		{
			$table->integer('customer_id', true);
			$table->date('from_date');
			$table->date('to_date');
			$table->boolean('stop_revenue')->default(0);
			$table->boolean('stop_rebate')->default(0);
			$table->boolean('stop_simswap')->default(0);
			$table->boolean('is_active')->default(1);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('stop_revenue');
	}

}
