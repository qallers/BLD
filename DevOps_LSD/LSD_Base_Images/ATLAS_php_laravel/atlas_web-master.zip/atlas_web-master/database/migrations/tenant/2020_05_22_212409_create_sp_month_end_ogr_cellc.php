<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSpMonthEndOgrCellc extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('
        CREATE PROCEDURE MonthEndOGRCELLC(
            IN me_file_id INT UNSIGNED
            ,IN recal TINYINT UNSIGNED
        )
        BEGIN
        IF recal = 1
            THEN
            DELETE FROM me_ogr_pre_process
            WHERE file_id = me_file_id;
        END IF;
        
        UPDATE me_import_file
        SET cal_status = 1
        WHERE id = me_file_id;
        
        INSERT INTO me_ogr_pre_process (
            file_id
            ,network_id
            ,serial_no
            ,total_recharge
            ,revenue_percentage
            ,STATUS
        )
        (SELECT
            file_id
            ,network_id
            ,serial_no
            ,SUM(denom * recharge_count)
            ,revenue_percentage
            ,0
        FROM me_cellc_ogr_raw
        WHERE file_id = me_file_id
        GROUP BY file_id
            ,network_id
            ,serial_no
            ,revenue_percentage);
            
        CALL calculationPostProcessOgr (me_file_id, recal);
        
        UPDATE me_import_file
        SET cal_status = 2
        WHERE id = me_file_id;
        END;
        ');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS MonthEndOGRCELLC');
    }
}
