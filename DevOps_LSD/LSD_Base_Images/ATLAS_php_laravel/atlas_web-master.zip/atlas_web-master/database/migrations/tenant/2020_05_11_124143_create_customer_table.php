<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCustomerTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('customer', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('parent_id')->nullable();
			$table->string('cust_code', 20)->unique('cust_code');
			$table->string('name', 50);
			$table->integer('active_base')->nullable()->default(0);
			$table->integer('group_id')->index('group_id');
			$table->integer('identity_type_id');
			$table->string('identity_reference', 20)->nullable();
			$table->date('identity_reference_expiry_date')->nullable();
			$table->boolean('vat_registered');
			$table->string('vat_reg_no', 20)->nullable();
			$table->integer('user_id')->nullable();
			$table->boolean('is_active')->default(1);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('customer');
	}

}
