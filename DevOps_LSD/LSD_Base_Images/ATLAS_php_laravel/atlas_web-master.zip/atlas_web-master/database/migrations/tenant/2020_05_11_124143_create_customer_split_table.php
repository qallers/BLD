<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCustomerSplitTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('customer_split', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('name', 30);
			$table->integer('customer_id');
			$table->integer('split_customer');
			$table->integer('network_id');
			$table->integer('product_deal_id')->nullable();
			$table->integer('product_id')->nullable();
			$table->integer('split_deal_id')->nullable();
			$table->decimal('ogr', 13, 4)->nullable();
			$table->decimal('act', 13, 4)->nullable();
			$table->decimal('sim', 13, 4)->nullable();
			$table->boolean('is_eligible_tier')->nullable();
			$table->decimal('ogr_tier', 13, 4)->nullable();
			$table->decimal('act_tier', 13, 4)->nullable();
			$table->decimal('sim_tier', 13, 4)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('customer_split');
	}

}
