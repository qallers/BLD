<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSpMonthEndActMtn extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::unprepared('
        CREATE PROCEDURE MonthEndACTMTN(
            IN me_file_id INT UNSIGNED
            ,IN recal INT UNSIGNED
        )
        BEGIN
        UPDATE me_import_file
        SET cal_status = 1
        WHERE id = me_file_id;
        
        IF recal = 1
            THEN
            DELETE FROM me_act_pre_process
            WHERE file_id = me_file_id;
        END IF;
        
        INSERT INTO me_act_pre_process (
            file_id
            ,network_id
            ,serial_no
            ,price
            ,STATUS
        )
        (SELECT
            file_id
            ,network_id
            ,serial_number
            ,SUM(comm_incl)
            ,0
        FROM me_mtn_act_raw
        WHERE file_id = me_file_id
        GROUP BY file_id
            ,network_id
            ,serial_number);
            
    	UPDATE me_mtn_act_raw t1
	    INNER JOIN stock t2
	    SET t2.msisdn = t1.msisdn
	    WHERE t2.serial_no = t1.serial_number
	    AND t1.file_id = me_file_id;
            
        CALL calculationPostProcessAct(me_file_id, recal);
        
        UPDATE me_import_file
        SET cal_status = 2
        WHERE id = me_file_id;
        END;
        ');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::unprepared('DROP PROCEDURE IF EXISTS MonthEndACTMTN');
    }
}
