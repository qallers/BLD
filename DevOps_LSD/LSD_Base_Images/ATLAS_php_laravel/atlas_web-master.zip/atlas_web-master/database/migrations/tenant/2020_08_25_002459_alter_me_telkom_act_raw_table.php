<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterMeTelkomActRawTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('me_telkom_act_raw', function (Blueprint $table) {
            $table->string('sub_dealer_code', 30);
            $table->string('comm_rocode', 30);
            $table->string('retail_outlet_name', 30);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('me_telkom_act_raw', function (Blueprint $table) {
            $table->dropColumn('sub_dealer_code');
            $table->dropColumn('comm_rocode');
            $table->dropColumn('retail_outlet_name');
        });
    }
}
