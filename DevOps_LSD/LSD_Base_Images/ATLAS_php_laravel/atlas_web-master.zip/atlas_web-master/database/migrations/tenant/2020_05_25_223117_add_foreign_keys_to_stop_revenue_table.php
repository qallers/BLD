<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class AddForeignKeysToStopRevenueTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('stop_revenue', function(Blueprint $table)
		{
			$table->foreign('customer_id', 'stop_revenue_ibfk_1')->references('id')->on('customer')->onUpdate('NO ACTION')->onDelete('NO ACTION');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('stop_revenue', function(Blueprint $table)
		{
			$table->dropForeign('stop_revenue_ibfk_1');
		});
	}

}
