<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMeSwpPreProcessTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('me_swp_pre_process', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('file_id');
			$table->integer('network_id');
			$table->string('serial_no', 35);
			$table->float('price', 10, 0);
			$table->boolean('status')->default(0);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('me_swp_pre_process');
	}

}
