<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateReturnStockTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('return_stock', function(Blueprint $table) {
            $table->integer('id', true);
            $table->integer('sales_order_detail_id')->nullable()->default(0);
            $table->string('serial_no', 35)->nullable()->default('0');
            $table->string('nav_id', 35)->nullable()->default('0');
            $table->string('return_type', 35)->nullable()->default('0');
            $table->integer('user_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::drop('return_stock');
    }

}
