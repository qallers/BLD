<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTierStageTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('tier_stage', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('customer_id');
			$table->integer('network_id');
			$table->integer('from_cab');
			$table->integer('to_cab');
			$table->decimal('ogr', 13, 4);
			$table->decimal('act', 13, 4);
			$table->decimal('sim', 13, 4);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('tier_stage');
	}

}
