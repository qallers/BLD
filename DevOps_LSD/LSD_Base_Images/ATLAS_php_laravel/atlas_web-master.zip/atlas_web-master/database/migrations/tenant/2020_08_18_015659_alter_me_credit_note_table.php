<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterMeCreditNoteTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('me_credit_note', function (Blueprint $table) {
            $table->integer('network_id')->after('id');
            $table->date('process_month')->after('network_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('me_credit_note', function (Blueprint $table) {
            $table->dropColumn('network_id');
            $table->dropColumn('process_month');
        });
    }
}
