<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateContactTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('contact', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('customer_id')->nullable();
			$table->string('name', 50);
			$table->string('mail_address', 50)->nullable();
			$table->string('tel_no', 15)->nullable();
			$table->string('fax_no', 15)->nullable();
			$table->string('cell_no', 15)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('contact');
	}

}
