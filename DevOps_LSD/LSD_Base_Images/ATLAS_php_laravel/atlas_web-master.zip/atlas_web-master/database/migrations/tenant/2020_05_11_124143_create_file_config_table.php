<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateFileConfigTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() {
        Schema::create('file_config', function(Blueprint $table) {
            $table->integer('id', true);
            $table->string('name', 50)->nullable()->default('');
            $table->boolean('network_id')->nullable();
            $table->integer('file_type_id')->nullable();
            $table->string('path', 100)->nullable()->default('');
            $table->string('ft', 5)->nullable()->default('');
            $table->string('lt', 5)->nullable()->default('');
            $table->boolean('ignore_line')->default(0);
            $table->boolean('is_active')->default(1);
            $table->timestamps();
            $table->float('percentage', 5, 4);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        Schema::drop('file_config');
    }

}
