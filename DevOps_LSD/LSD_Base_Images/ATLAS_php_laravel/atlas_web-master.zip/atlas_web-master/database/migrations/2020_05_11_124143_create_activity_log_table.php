<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateActivityLogTableAdmin extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('activity_log', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('log_name', 20)->nullable()->index();
			$table->string('description', 30);
			$table->integer('subject_id')->unsigned()->nullable();
			$table->string('subject_type', 20)->nullable();
			$table->integer('causer_id')->unsigned()->nullable();
			$table->string('causer_type', 20)->nullable();
			$table->text('properties', 65535)->nullable();
			$table->timestamps();
			$table->index(['subject_id','subject_type'], 'subject');
			$table->index(['causer_id','causer_type'], 'causer');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('activity_log');
	}

}
