<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Models\Role;
use Spatie\Activitylog\Traits\LogsActivity;

class StagesRoles extends Model
{
    use LogsActivity;
    
    public $table = "stages_has_roles";

    protected $fillable = ['stage_id','role_id'];
    protected static $logAttributes = ['stage_id','role_id'];

    public function roles()
    {
        return $this->belongsTo("Spatie\Permission\Models\Role","role_id");
    }

    public function stages()
    {
        return $this->belongsTo("App\ApprovalStages","stage_id");
    }
    

}