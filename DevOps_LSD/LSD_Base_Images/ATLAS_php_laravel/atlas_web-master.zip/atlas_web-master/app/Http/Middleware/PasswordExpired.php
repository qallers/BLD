<?php

namespace App\Http\Middleware;

use App\Config;
use Carbon\Carbon;
use Closure;

class PasswordExpired
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = $request->user();
        $password_changed_at = $user->password_changed_at;
        $config=Config::where("key","password_expires_days")->first();
        if(!$config){
            $config=365;
        }else{
            $config=$config->value;
        }
        if (Carbon::now()->diffInDays(new Carbon(($user->password_changed_at))) >= (int)$config || $password_changed_at==null) {
            return redirect('password/expired');
        }

        return $next($request);
    }
}
