<?php

namespace App\Http\Controllers\Admin;

use App\Box;
use App\Stock;
use App\Network;
use Milon\Barcode\DNS1D;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\ParentChildTrait;
use Illuminate\Support\Facades\Gate;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\StoreBoxRequest;
use App\Http\Requests\Admin\UpdateNetworkRequest;
use Illuminate\Support\Arr;
use App\Http\Controllers\Traits\ActivityLogTrait;

class BoxController extends Controller
{

    use ParentChildTrait;
    use ActivityLogTrait;

    public function index()
    {
        if (!Gate::allows('view_box'))
        {
            return abort(401);
        }
        $reprint = false;
        if (Gate::allows('reprint_box'))
        {
            $reprint = true;
        }
        $box = Box::all();
        return view('admin.box.index', compact('box', 'reprint'));
    }

    function buildTree($elements, $parentId = '')
    {
        $branch = array();

        foreach ($elements as $element)
        {
            if ($element->parent_id == $parentId)
            {
                $children = $this->buildTree($elements, $element->id);

                if ($children)
                {
                    $element->children = $children;
                }

                $branch[] = $element;
            }
        }

        return $branch;
    }

    public function find(StoreBoxRequest $request)
    {

        $input = str_replace(' ', '', $request->input("serial_no"));

        $stock = DB::table('box')->where("barcode", $input)->first();

        if (empty($stock->id))
        {

            return response()->json([
                'status' => "400",
                'msg' => "Box or Starter Pack not found"
            ]);
        }


        $getChild = $this->getChildBox($stock->id);
        if (count($getChild) == 1 && $getChild[0] == $stock->id)
        {
            $data = DB::table('box')->select('id', 'barcode as name', 'parent_id')->where('id', $stock->id)->get();
        }
        else
        {
            //$getChild=Arr::prepend($getChild, $stock->id);
            $data = DB::table('box')->select('id', 'barcode as name', 'parent_id')->whereIn('id', $getChild)->get();
        }


        $cnt = 1;
        foreach ($data as $k => $v)
        {
            if ($v->id == $stock->id)
            {
                $data[$k]->parent_id = 0;
            }

            $b = DB::select("select serial_no as name,box_id as parent_id from stock where box_id = $v->id");
            if (!empty($b[0]))
            {

                foreach ($b as $c)
                {
                    if ($cnt == $v->id)
                    {
                        $cnt++;
                    }
                    $c->id = $cnt . $v->id;
                    $data[] = $c;
                    $cnt++;
                }
            }
        }

        $result = $this->buildTree($data);
        if (!empty($result[0]))
        {
            echo json_encode($result[0]);
        }
        else
        {
            echo json_encode(array());
        }
    }

    /**
     * Show the form for creating new network.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //        echo '<b style="font-size:10px">MTNSP001&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Qty:- 5</b><br/><span style="font-size:10px">Prepaid LTE Blister Multi-Sim Bonanza</span><br/><b>1584096343</b><img style="margin-top:5px;" src="data:image/png;base64,' . \Milon\Barcode\DNS1D::getBarcodePNG("1584096343", "C128A", 1, 33, 0) . '" alt="barcode" />';
        //        die;
        if (!Gate::allows('create_box'))
        {
            return abort(401);
        }
        $config = DB::table('config')->where("key", "default_box_size")->first();
        return view('admin.box.create', compact('config'));
    }

    public function scan_serial(StoreBoxRequest $request)
    {
        $input = str_replace(' ', '', $request->input("serial_no"));
        $option = str_replace(' ', '', $request->input("scan_option"));
        $pid = str_replace(' ', '', $request->input("product_id"));
        $countQty = 0;

        if ($option == 'box')
        {

            $boxdata = Box::where('barcode', $input)->first();
            // dd($boxdata);
            if (empty($boxdata))
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Box not found",
                    'count' => 0
                ]);
            }

            if ($boxdata->parent_id != 0)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Internal box number belongs to another big box"
                ]);
            }



            $getChild = $this->getChildBox($boxdata->id);

            if ($pid != $boxdata->product_id)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Product don't match",
                    'count' => 0
                ]);
            }

            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $box = $boxdata->id;
                $countQty = DB::table('stock')
                    ->where('product_id', $pid)
                                ->whereNull('sales_order_detail_id')
                    ->where("box_id", $box)->count();
            }
            else
            {
                $countQty = DB::table('stock')
                    ->where('product_id', $pid)
                                ->whereNull('sales_order_detail_id')
                    ->whereIn("box_id", $getChild)->count();
            }

            if ($countQty <= 0)
            {
                return response()->json([
                    'status' => "400",
                            'msg' => "Box Already Sold",
                    'count' => 0
                ]);
            }
        }
        else
        {
            $isdup = \App\Grvdata::where("serial_no", $input)->where("is_available", 1)->where("is_transfer", 0)->first();
            if (empty($isdup))
            {
                $data = array("serial_no" => $input, "Process" => "Scan serial number");
                $description = "Box create,Starter pack already used";
                $this->setActivityLog('', $isdup, $data, $description);

                return response()->json([
                    'status' => "400",
                    'msg' => "Starter pack already used",
                    'count' => 0
                ]);
            }
            $stock = DB::table('stock')->where("serial_no", $input)->first();
            $parent = !empty($stock->box_id) ? $stock->box_id : '';
            if (!empty($stock->sales_order_detail_id))
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Starter pack already sold",
                    'count' => 0
                ]);
            }
            if (empty($stock))
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Starter pack not found in stock",
                    'count' => 0
                ]);
            }
            else
            {
                $main_warehouse = \App\Config::where("key", "main_warehouse")->first()->value;
                if ($stock->warehouse_id != $main_warehouse)
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "Starter pack is not belong to main warehouse",
                        'count' => 0
                    ]);
                }
            }
            if (empty($stock->product_id))
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Scanned starter pack is not the correct product",
                    'count' => 0
                ]);
            }
        }

        if (!empty($stock) || !empty($countQty))
        {
            if ($option != 'box')
            {
                if ($stock->product_id != $pid)
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "Scanned starter pack is not the correct product",
                        'count' => 0
                    ]);
                }
                if (!empty($parent))
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "This starter pack has already been assigned to the box",
                        'count' => 0
                    ]);
                }
            }

            return response()->json([
                'status' => "200",
                'msg' => "",
                'count' => $countQty
            ]);
        }
    }

    public function reprint(StoreBoxRequest $request)
    {
        $box_id = $request->input("id");
        $input = $request->input("barcode");
        $password = !empty($request->input("str")) ? $request->input("str") : '';
        if (!Gate::allows('reprint'))
        {
            $config = \App\Config::where("key", "reprint_password")->get()->first();
            if ($config->value != md5($password))
            {
                return response()->json([
                    'status' => "402",
                    'msg' => "Password does not match"
                ]);
            }
        }
        if ($box_id == $input)
        {
            return 0;
        }
        $getChild = $this->getChildBox($box_id);
        if (count($getChild) == 1 && $getChild[0] == $box_id)
        {
            $cntQty = DB::table('stock')->where("box_id", $box_id)->count();
            $stock = Stock::where('box_id', $box_id)->first();
        }
        else
        {
            $cntQty = DB::table('stock')->whereIn("box_id", $getChild)->count();
            $stock = Stock::whereIn('box_id', $getChild)->first();
        }

        $b = new DNS1D();
        $c = $b->getBarcodePNG("$input", "C128A", 1, 32, array(0, 0, 0));
        return response()->json([
            'status' => "200",
            'msg' => $c,
            'product_code' => !empty($stock->product->product_code) ? $stock->product->product_code : '',
            'product_desc' => !empty($stock->product->description) ? $stock->product->description : '',
            'box_no' => $input,
            'qty' => $cntQty
        ]);
    }

    /**
     * Store a newly created product in storage.
     *
     * @param  \App\Http\Requests\StoreNetworkRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreBoxRequest $request)
    {
        $serial_nos = $request->input("serial_nos");
        $pcode = $request->input("product_code");
        $pdesc = $request->input("product_desc");
        $option = str_replace(' ', '', $request->input("scan_option"));
        $pid = str_replace(' ', '', $request->input("product_id"));

        $input = time() . rand(10, 99) . rand(0, 9);

        $isavail = Box::where('barcode', $input)->first();
        if (!empty($isavail->barcode))
        {
            $input = time() . rand(10, 99) . rand(0, 9);
        }

        $box = array();
        $box['barcode'] = $input;
        $box['parent_id'] = 0;
        $box['product_id'] = $pid;
        $box_id = Box::create($box);

        if ($option == 'box')
        {
            $boxqty = 0;
            $affected = Box::whereIn('barcode', explode(',', $serial_nos))
                ->update(['parent_id' => $box_id->id]);

            $getChild = $this->getChildBox($box_id->id);

            foreach ($getChild as $b)
            {
                $cnt = DB::table('stock')->where("box_id", $b)->count();

                $boxqty = $boxqty + $cnt;
            }
            $cntQty = $boxqty;

            $data = array("box_id" => $box_id->id, "qty" => $cntQty, "child_boxes" => $getChild, "Process" => "Create parent box");
            $description = "Parent Box created";
            $this->setActivityLog('', '', $data, $description);
        }
        else
        {

            $affected_qty = 0;
            $numberOfkits = 0;
            foreach (explode(',', $serial_nos) as $s)
            {

                $affected = Stock::where('serial_no', $s)
                    ->update(['box_id' => $box_id->id]);

                DB::table('grv')
                    ->where('serial_no', $s)
                    ->update(['is_available' => 0]);

                $affected_qty = $affected_qty + $affected;
                $numberOfkits++;
            }

            $data = array("box_id" => $box_id->id, "box_qty" => $numberOfkits, "serial_nos" => $serial_nos, "scanned_qty" => $affected_qty, "Process" => "Create box");
            $description = "There is $affected_qty starter pack assign to box";
            $this->setActivityLog('', $box_id, $data, $description);

            if ($numberOfkits != $affected_qty)
            {


                foreach (explode(',', $serial_nos) as $s)
                {
                    $affected = Stock::where('serial_no', $s)
                        ->update(['box_id' => NULL]);

                    DB::table('grv')
                        ->where('serial_no', $s)
                        ->update(['is_available' => 1]);
                }

                DB::table('box')
                    ->where('id', $box_id->id)
                    ->delete();


                $data = array("box_id" => $box_id->id, "qty" => $affected_qty, "Process" => "Revert box");
                $description = "Failed to create full box qty only $affected_qty affected";
                $this->setActivityLog('', $box_id, $data, $description);

                return response()->json([
                    'status' => "500",
                    'msg' => "Failed to create full box qty only $affected_qty affected",
                    'count' => 0
                ]);
            }

            $cntQty = $affected_qty;
        }

        $b = new DNS1D();
        $c = $b->getBarcodePNG("$input", "C128A", 1, 32, array(0, 0, 0));
        return response()->json([
            'status' => "200",
            'msg' => $c,
            'product_code' => $pcode,
            'product_desc' => $pdesc,
            'box_no' => $input,
            'qty' => $cntQty
        ]);
    }
}
