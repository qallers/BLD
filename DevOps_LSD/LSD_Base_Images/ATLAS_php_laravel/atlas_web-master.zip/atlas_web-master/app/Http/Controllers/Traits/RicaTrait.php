<?php

namespace App\Http\Controllers\Traits;

use App\Config;
use Exception;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use SimpleXMLElement;

trait RicaTrait
{
    public function sendRicaCredential($customer, $user, $password)
    {
        

        $config = Config::whereIn("key", ["tcp_host", "tcp_port", "device_id", "user_pin", "serial_number", "rica_agent", "rica_agent_password"])->pluck("value", "key");
        $tcpHost =  $config["tcp_host"];
        $tcpPort =  $config["tcp_port"];
        $deviceId = $config["device_id"];
        $userPin =  $config["user_pin"];
        $serialNumber = $config["serial_number"];
  
        try{
            $fp = pfsockopen($tcpHost, $tcpPort, $errno, $errstr, 30);
        }catch(Exception $e){
            return false;
        }
       
        if (!$fp) {
            return false;
        } else {
            $authenticateRequest = '<request><EventType>Authentication</EventType><event><UserPin>' . $userPin . '</UserPin><DeviceId>' . $deviceId . '</DeviceId><DeviceSer>' . $serialNumber . '</DeviceSer></event></request>' . PHP_EOL;
            fwrite($fp, $authenticateRequest);
            $response = "";
            while ($buffer = fgets($fp, 1024)) {
                $response = isset($response) ? $response . $buffer : $buffer;
                if (preg_match('/<\/response>/', $buffer)) {
                    break;
                }
            }
            if ($response != "") {

                $response = new SimpleXMLElement($response);

                // $log  = "Authentication Request" . PHP_EOL .
                //     "Customer ID: " . $customer_Id . ' - ' . date("F j, Y, g:i a") . PHP_EOL .
                //     "Result: " . json_encode($response) . PHP_EOL .

                //     "-------------------------" . PHP_EOL;
                // file_put_contents('./log_' . date("j.n.Y") . '.log', $log, FILE_APPEND);


                if (isset($response->data->errorCode) && isset($response->data->message)) {
                    $callStatus = 'ERROR';
                    return $response;
                } else {

                    if ($response->SessionId && $response->SessionId != "") {
                        $sessionId = $response->SessionId;

                        $customer_Id = $customer->id;
                        $Customer_Name = $customer->name;
                        $title = $customer->name;
                        $firstname = $user->first_name;
                        $lastname = $user->last_name;
                        $idnum = $customer->identity_type_id == 24 ? $customer->identity_reference : '';
                        $passport =  $customer->identity_type_id == 25 ? $customer->identity_reference : '';
                        $workpermit =  $customer->identity_type_id == 26 ? $customer->identity_reference : '';
                        $otherid =  $customer->identity_type_id == 27 ? $customer->identity_reference : '';
                        $nationality = $customer->identity_reference_origin_country;
                        $birthdate = '';
                        $addressline1 = $customer->addresses[0]->address_line_1 ?? '';
                        $addressline2 = $customer->addresses[0]->address_line_2 ?? '';
                        $countrycode = '27';
                        $postalcode = $customer->addresses[0]->postal_code ?? '';
                        $region = "";
                        $suburb = "";
                        $citytown = "";
                        $city = $customer->addresses[0]->city ?? '';
                        $postaladdressline1 = $customer->addresses[0]->address_line_1 ?? '';
                        $postaladdressline2 = $customer->addresses[0]->address_line_2 ?? '';
                        $postalcountrycode = '';
                        $postalcode = $customer->addresses[0]->postal_code ?? '';
                        $postalregion = $customer->addresses[0]->province ?? '';
                        $postalsuburb = "";
                        $postalcitytown = $customer->addresses[0]->city ?? '';
                        $cellNo = $customer->contacts[0]->cell_no ?? '';
                        $areacode = "";
                        $dialingno =  $cellNo;

                        //$_force_password = $request->password;
                        $_force_password = $password;
                        $_force_username = $user->username;

                        $agent =$config["rica_agent"];
                        $password =$config["rica_agent_password"];

                        if (substr($dialingno, 0, 2) == '27') {
                            $dialingno1 = substr($dialingno, 2);
                            $dialingno = $dialingno1;
                        }



                        $position = '';
                        $supervisor = '';
                        $supervisorcontactno = '';
                        $supervisorcountrycode = '';
                        $supervisorareacode = '';
                        $supervisordialingno = '';
                        $proofOfAddress = 'True';

                        $ricaRequest = '<request><SessionId>' . $sessionId . '</SessionId><EventType>RegisterAgent</EventType><event><User>' .
                            '<Username>' . $agent . '</Username><Password>' . $password . '</Password><sourceDevice>' . $deviceId . '</sourceDevice><sourceRef></sourceRef></User>' .
                            '<Registration><title>Mr</title><firstName>' . $firstname . '</firstName><lastName>' . $lastname . '</lastName><idNum>' . $idnum . '</idNum><passport>' . $passport . '</passport><workPermit>' . $workpermit . '</workPermit>' .
                            '<otherId>' . $otherid . '</otherId><nationality>' . $nationality . '</nationality><birthDate>' . $birthdate . '</birthDate>' .
                            '<physicalAddress><addressLine1>' . $addressline1 . '</addressLine1><addressLine2>' . $addressline2 . '</addressLine2><countryCode>' . $countrycode . '</countryCode>' .
                            '<postalCode>' . $postalcode . '</postalCode><region>' . $region . '</region><suburb>' . $suburb . '</suburb><cityTown>' . $city . '</cityTown></physicalAddress>' .
                            '<postalAddress><addressLine1>' . $postaladdressline1 . '</addressLine1><addressLine2>' . $postaladdressline2 . '</addressLine2><countryCode>' . $postalcountrycode . '</countryCode><postalCode>' . $postalcode . '</postalCode>' .
                            '<region>' . $postalregion . '</region><suburb>' . $postalsuburb . '</suburb><cityTown>' . $postalcitytown . '</cityTown></postalAddress><cellNo><countryCode>' . $countrycode . '</countryCode><areaCode>' . $areacode . '</areaCode>' .
                            '<dialingNo>' . $dialingno . '</dialingNo></cellNo><position>' . $position . '</position><supervisor>' . $supervisor . '</supervisor><supervisorContactNo>' . $supervisorcontactno . '<countryCode></countryCode>' .
                            '<areaCode>' . $supervisorareacode . '</areaCode><dialingNo>' . $supervisordialingno . '</dialingNo></supervisorContactNo><proofOfAddress>' . $proofOfAddress . '</proofOfAddress>' .
                            '<_forcePassword>' . $_force_password . '</_forcePassword><_forceUsername>' . $_force_username . '</_forceUsername></Registration></event></request>' . PHP_EOL;

                        //echo '<pre>', htmlentities($ricaRequest), '</pre>';

                        fwrite($fp, $ricaRequest);
                        $response = "";
                        while ($buffer = fgets($fp, 1024)) {
                            $response = isset($response) ? $response . $buffer : $buffer;
                            if (preg_match('/<\/response>/', $buffer)) {
                                break;
                            }
                        }




                        //  echo '<pre>', htmlentities($response), '</pre>';
                        $response = new SimpleXMLElement($response);

                        // $log  = "Registration Result" . PHP_EOL .
                        //     "Customer ID: " . $customer_Id . ' - ' . date("F j, Y, g:i a") . PHP_EOL .
                        //     "Cell No : " . $cellNo . PHP_EOL .
                        //     "Nav Code: " . $_force_username . PHP_EOL;
                        // if ($idnum == '') {
                        //     $log  .=  "ID / Passport: " . $passport . PHP_EOL;
                        // } else {
                        //     $log  .=  "ID / Passport: " . $idnum . PHP_EOL;
                        // }

                        // $log  .= "Result: " . json_encode($response) . PHP_EOL .
                        //     "-------------------------" . PHP_EOL;
                        // //Save string to log, use FILE_APPEND to append.
                        // file_put_contents('./log_' . date("j.n.Y") . '.log', $log, FILE_APPEND);
                        //dd($response);
                        try {
                            activity()
                                ->causedBy(Auth::user())
                                ->withProperties(['request' => $ricaRequest, 'response' => json_encode($response)])
                                ->log('RICA');
                        } catch (Exception $th) {
                            //throw $th;
                        }
                        if ($response->event->EventCode != '0') {
                            try{
                                Alert::error('Error!', $response->data->messageDetails);
                            }catch(Exception $e){

                            }
                            return false;
                        } else {
                            return true;
                        }
                    }
                }
            }
        }
    }
}
