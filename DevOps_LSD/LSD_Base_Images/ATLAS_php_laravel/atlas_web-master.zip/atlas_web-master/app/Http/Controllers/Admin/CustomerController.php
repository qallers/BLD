<?php

namespace App\Http\Controllers\Admin;

use App\Customer;
use App\Address;
use App\Config;
use App\Contact;
use App\Group;
use App\Contract;
use App\Country;
use App\CustomerSplit;
use App\ExternalSystem;
use App\ExternalSystemReference;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\NavisionHelperTraits;
use App\Http\Controllers\Traits\RicaTrait;
use App\Http\Controllers\Traits\Safe4Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Requests\Admin\UpdateCustomerRequest;
use App\Http\Requests\Admin\StoreCustomerRequest;
use App\Status;
use App\User;
use App\TierStage;
use App\Network;
use Exception;
use Illuminate\Support\Facades\Auth;
use RealRashid\SweetAlert\Facades\Alert;
use App\Notifications\NewcustomerProcess;
use App\Notifications\NewUserCreated;
use Illuminate\Support\Facades\Config as FacadesConfig;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class CustomerController extends Controller
{

    use NavisionHelperTraits;
    use Safe4Controller;
    use RicaTrait;
    use \App\Http\Controllers\Traits\NotificationTraits;

    public function index()
    {
        if (!Gate::allows('view_customers')) {
            return abort(401);
        }
        $users = User::all();
        $customer = Customer::where('is_active', 1)->get();

        return view('admin.customer.index', compact('users', 'customer'));
    }

    public function list(Request $request)
    {
        if (!Gate::allows('view_customers')) {
            return abort(401);
        }
        $ut = Auth::user();
        if ($ut->user_type_id == 2) {
            $data = Customer::whereRepUserId($ut->id);
        } else {
            $data = Customer::query();
        }
        if ($request->filled("users")) {
            if (!in_array("-1", $request->input("users"))) {
                $data->whereIn('rep_user_id', $request->input("users"));  //changed from user_id to rep_user_id becuase we store rep user id in rep_user_id from now
            }
        }
        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }
        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }
        return datatables()->of($data)
            ->make();
    }

    public function list_fica(Request $request)
    {
        if (!Gate::allows('view_fica')) {
            return abort(401);
        }
        $ut = Auth::user();
        if ($ut->user_type_id == 2) {
            $data = Customer::with("status")->whereRepUserId($ut->id);
        } else {
            $data = Customer::with("status");
        }
        $status = Status::whereProcess("new_customer")->whereIn("status", ["fica_approval", "fica_approved"])->pluck("id");
        $data->whereIn("status_id", $status);
        return datatables()->of($data)
            ->make();
    }

    //Edit Function
    public function edit(Customer $customer)
    {

        if (!Gate::allows('edit_customers')) {
            return abort(401);
        }

        $addresstype = Status::whereProcess('address_type')->get();
        $identity = Status::whereProcess('identity_type')->get();
        $paymentmethod = Status::whereProcess('payment_method')->get();
        $group = Group::where('is_active', 1)->get();
        $users = User::all();
        $country = Country::all();
        $repuser = User::where('user_type_id', 2)->get();
        $customers = Customer::where('parent_id', -1)->get();
        $parentcustomer = Customer::find($customer->parent_id);

        return view('admin.customer.edit', compact('customer', 'identity', 'group', 'addresstype', 'users', 'repuser', 'customers', 'parentcustomer', 'country', 'paymentmethod'));
    }

    //Create Customer
    public function create()
    {
        if (!Gate::allows('add_customers')) {
            return abort(401);
        }
        $addresstype = Status::whereProcess('address_type')->get();
        $identity = Status::whereProcess('identity_type')->get();
        $paymentmethod = Status::whereProcess('payment_method')->get();
        $group = Group::where('is_active', 1)->get();
        $country = Country::all();
        $users = User::all();
        $repuser = User::where('user_type_id', 2)->get();
        $customers = Customer::where('parent_id', -1)->get();

        return view('admin.customer.create', compact('identity', 'group', 'addresstype', 'users', 'repuser', 'customers', 'country', 'paymentmethod'));
    }

    public function update_parent(Request $request)
    {
        //dd($request->all());
        $customer = Customer::find($request->input("id"));
        $customer->parent_id = $request->input("parent_id");
        $customer->save();
        return back();
    }

    //Update Customer
    public function update(UpdateCustomerRequest $request, Customer $customer)
    {
        $customer->update($request->except(['contact', 'address']));
        if (!Gate::allows('add_customers')) {
            return abort(401);
        }
        $custcode = $request->input("custcode");
        $customer->update($request->all());

        if ($request->filled('address')) {
            foreach ($request->address as $key => $id) {
                $address = Address::find($id);
                $address->customer_id = $customer->id;
                $address->save();
            }
        }
        if ($request->filled('contact')) {
            foreach ($request->contact as $key => $id) {
                $contact = Contact::find($id);
                $contact->customer_id = $customer->id;
                $contact->save();
            }
        }
        Alert::success('Success', "The customer has been updated.");
        return redirect()->route('admin.customer.index');
    }

    public function store(StoreCustomerRequest $request)
    {
        if (!Gate::allows('add_customers')) {
            return abort(401);
        }
        Customer::create($request->all());

        return redirect()->route('admin.customer.index');
    }

    //View Customer Details
    public function show(Customer $customer)
    {

        if (!Gate::allows('view_customers')) {
            return abort(401);
        }

        $country = Country::find($customer->identity_reference_origin_country);
        $createduser = User::find($customer->user_id);
        $parentcustomer =  Customer::find($customer->parent_id);
        $currentrepuser =  User::find($customer->rep_user_id);
        $AeonExtSysId = ExternalSystem::whereDescription('Aeon')->first();
        $bydnumber =  ExternalSystemReference::whereCustomerId($customer->id)->whereExternalSystemId($AeonExtSysId->id)->first();
        return view('admin.customer.show', compact('customer', 'country', 'createduser', 'parentcustomer', 'currentrepuser','bydnumber'));
    }

    public function fica_show($id)
    {
        if (!Gate::allows('view_fica')) {
            return abort(401);
        }
        $customer = Customer::find($id);
        $status = Status::whereProcess("new_customer")->whereStatus("fica_approval")->first()->id;
        $ficaNeeded = 0;
        $fica_images = [];
        if ($status == $customer->status_id) {
            $ficaNeeded = 1;
        }
        $safe4ExtSysId = ExternalSystem::whereDescription('Safe-4')->first();
            $safe4 = ExternalSystemReference::whereCustomerId($customer->id)->whereExternalSystemId($safe4ExtSysId->id)->first();
            $sessionKey = null;
            if ($safe4) {
                foreach (json_decode($safe4->data)->folders->folder as $key => $value) {
                    if ($value->url != null) {
                        $p = "/safe4/" . $customer->id . "/" . $value->type . "_" . basename($value->url) . ".jpg";

                        if (!File::exists(storage_path($p)) && !File::exists(storage_path("/safe4/" . $customer->id . "/" . $value->type . "_" . basename($value->url) . ".pdf"))) {
                            if ($sessionKey == null) {
                                $this->initSafe4();
                                $sessionKey = $this->getSessionKey();
                            }
                            $doc = $this->downloadFile($value->url, $sessionKey);
                            Storage::put($p, $doc);
                        }
                        try {
                            if (File::mimeType(storage_path($p)) == "application/pdf") {
                                try {
                                    if (File::exists(storage_path("/safe4/" . $customer->id . "/" . $value->type . "_" . basename($value->url) . ".pdf"))) {
                                        $fica_images[array_key_exists($value->type, $fica_images) ? $value->type . "_1" : $value->type] = "/safe4/" . $customer->id . "/" . $value->type . "_" . basename($value->url) . ".pdf";
                                    } else {
                                        Storage::move($p, "/safe4/" . $customer->id . "/" . $value->type . "_" . basename($value->url) . ".pdf");
                                        $fica_images[array_key_exists($value->type, $fica_images) ? $value->type . "_1" : $value->type] = "/safe4/" . $customer->id . "/" . $value->type . "_" . basename($value->url) . ".pdf";
                                    }
                                } catch (Exception $e) {
                                }
                            } else {
                                $fica_images[array_key_exists($value->type, $fica_images) ? $value->type . "_1" : $value->type] = $p;
                            }
                        } catch (Exception $e) {
                            $fica_images[array_key_exists($value->type, $fica_images) ? $value->type . "_1" : $value->type] = "/safe4/" . $customer->id . "/" . $value->type . "_" . basename($value->url) . ".pdf";
                        }
                    }
                }
            }
        $customer->images = $fica_images;
        return view('admin.customer.fica_show', compact('customer', 'ficaNeeded'));
    }

    public function approve_fica(Request $request)
    {
        if (!Gate::allows('approve_fica')) {
            return response()->json([
                "status" => 401,
                "message" => "You don't have permission to approve FICA."
            ]);
        }
        $id = Status::whereProcess("new_customer")->whereStatus("fica_approved")->first()->id;
        $affected = Customer::find($request->customer_id)->update(['status_id' => $id, 'is_active' => 1]);
        $customer = Customer::find($request->customer_id);
        $user = User::find($customer->user_id);
        $passwrod = Str::random(8);

        $res = $this->sendRicaCredential($customer, $user, $passwrod);
        if ($res) {
            $user->password = Hash::make($passwrod);
            $user->save();
            $data = json_encode([
                "rica_username" => $customer->cust_code,
                "rica_password" => $passwrod
            ]);
            $e = ExternalSystem::whereDescription("RICA")->first();
            ExternalSystemReference::create([
                "external_system_id" => $e->id,
                "reference" => "RICA",
                "data" => $data,
                "customer_id" => $customer->id
            ]); 
            
            $company=FacadesConfig::get('company_name', 'Track n Trace');
            $msg = "Hi, $customer->name ,\nYour Username : $user->username\nYour Password : $passwrod\n\n$company Support.";
           
            $this->sendSMS($customer->contacts[0]->cell_no, $msg);
            $user->notify(new NewUserCreated([
                'password' => $passwrod,
                'username' => $user->username
            ]));
        } else {
            return response()->json([
                "status" => 200,
                "message" => "Error creating Rica account."
            ]);
        }
        if ($affected) {
            return response()->json([
                "status" => 200,
                "message" => "FICA approved successfully."
            ]);
        } else {
            return response()->json([
                "status" => 500,
                "message" => "Error approving FICA status."
            ]);
        }
    }

    //Delete Multiple Customers
    public function massDestroy(Request $request)
    {
        if (!Gate::allows('edit_customers')) {
            return abort(401);
        }
        User::whereIn('id', request('ids'))->delete();

        return response()->noContent();
    }

    function identity_type_ref_validation(Request $request)
    {
        $idNumber = $request->input('id');
        $correct = 1;
        if (strlen($idNumber) !== 13 || !is_numeric($idNumber)) {
            //echo 'ID number does not appear to be authentic - input not a valid number';
            $correct = 0;
            // die();
        }

        $year = substr($idNumber, 0, 2);
        $currentYear = date('Y') % 100;
        $prefix = '19';
        if ($year < $currentYear) {
            $prefix = '20';
        }
        $id_year = $prefix . $year;

        $id_month = substr($idNumber, 2, 2);
        $id_date = substr($idNumber, 4, 2);

        $fullDate = $id_year . '-' . $id_month . '-' . $id_date;

        global $dateOfBirth;


        $dateOfBirth = $fullDate;
        if (!$id_year == substr($idNumber, 0, 2) && $id_month == substr($idNumber, 2, 2) && $id_date == substr($idNumber, 4, 2)) {
            ///  echo 'ID number does not appear to be authentic - date part not valid';
            $correct = 0;
        }
        $genderCode = substr($idNumber, 6, 4);
        $gender = (int) $genderCode < 5000 ? 'Female' : 'Male';

        global $genders;

        $genders = $gender;

        $citzenship = (int) substr($idNumber, 10, 1) === 0 ? 'citizen' : 'resident'; //0 for South African citizen, 1 for a permanent resident

        $total = 0;
        $count = 0;
        for ($i = 0; $i < strlen($idNumber); ++$i) {
            $multiplier = $count % 2 + 1;
            ++$count;
            $temp = $multiplier * (int) $idNumber[$i];
            $temp = floor($temp / 10) + ($temp % 10);
            $total += $temp;
        }
        $total = ($total * 9) % 10;

        if ($total % 10 != 0) {
            //  echo 'ID number does not appear to be authentic - check digit is not valid';
            $correct = 0;
        }
        return response()->json([
            'status' => "200",
            'value' => $correct
        ]);
    }

    public function destroyaddress($addressID)
    {
        if (!Gate::allows('edit_customers')) {
            return abort(401);
        }

        $address = Address::find($addressID);

        if (isset($address)) {
            $address->deleteAddressWithLink($address->id);
            $address->delete();
        }
        return back();
    }

    public function editaddress(Request $request)
    {

        $newaddress = Address::find($request->input("address_id"));
        $newaddress->address_type_id = $request->input("address_type_id");
        // $newaddress->province_id = $request->input('province');
        $newaddress->address_line_1 = $request->input('address_line_1');
        $newaddress->address_line_2 = $request->input('address_line_2');
        $newaddress->region_id = $request->input('region_id');
        $newaddress->postal_code = $request->input('postal_code');
        $c = $request->input("gps_coordinates");
        $newaddress->gps_coordinates = DB::raw("ST_GeomFromText('POINT($c)')");
        $newaddress->save();
        Alert::success('Success', "The customer address has been updated.");
        $response = array('status' => 'success');

        return back();
    }

    public function editcontact(Request $request)
    {
        echo ("Edit Contact Function in controller");
        $newcontact = Contact::find($request->input("contact_id"));
        $newcontact->name = $request->input("name");
        $newcontact->mail_address = $request->input('mail_address');
        $newcontact->tel_no = $request->input('tel_no');
        $newcontact->fax_no = $request->input('fax_no');
        $newcontact->cell_no = $request->input('cell_no');

        $newcontact->save();

        Alert::success('Success', "The customer contact has been updated.");
        $response = array('status' => 'success');

        return back();
    }

    public function destroycontact($contactID)
    {
        if (!Gate::allows('edit_customers')) {
            return abort(401);
        }
        $contact = Contact::find($contactID);

        if (isset($contact)) {
            $contact->deleteContactWithLink($contact->id);
            $contact->delete();
        }
        return back();
    }

    public function addcustomer(StoreCustomerRequest $request)
    {
        if (!Gate::allows('add_customers')) {
            return abort(401);
        }
        if ($this->isEnabled()) {
            try {
                $address = null;
                if ($request->filled('address')) {
                    $address = Address::find($request->address[0]);
                }
                $this->nav_post("Cust_Card", [
                    "No" => $request->cust_code,
                    "Name" => $request->name,
                    "Salesperson_Code" => $request->rep_user_id == -1 ? "" : $request->rep_user_id,
                    "Address" => $address != null ? $address->address_line_1 : "",
                    "Address_2" => $address != null ? $address->address_line_2 : "",
                    "Post_Code" => $address != null ? $address->postal_code : "",
                    "City" => $address != null ? $address->postal_code : "",

                ]);
            } catch (Exception $exception) {
                Alert::error('Error.', "User is already available in Navision.\n" . $exception->getMessage());
                return redirect()->route('admin.customer.index');
            }
        }
     
        if($request->vat_registered==null){
           
                    $request->request->add(["vat_registered"=>0]);
        }
       
        $customer = Customer::create($request->except(['contact', 'address']));
        if ($request->filled('address')) {
            foreach ($request->address as $key => $id) {
                $address = Address::find($id);
                $address->customer_id = $customer->id;
                $address->save();
            }
        }
        if ($request->filled('contact')) {
            foreach ($request->contact as $key => $id) {
                $contact = Contact::find($id);
                $contact->customer_id = $customer->id;
                $contact->save();
            }
        }

        if ($request->input('rep_user_id') != '-1') {
            $data = array();
            $data['customer_name'] = $request->input('rep_user_id');
            $data['id'] = $customer->id;
            $u = \App\User::find($request->input('rep_user_id'));
            $u->notify(new NewcustomerProcess($data));
        }
        Alert::success('Success', "The customer has been created.");
        return redirect()->route('admin.customer.index');
    }

    public function assign()
    {
        $data = Customer::whereIsActive(1)->get();
        return view('admin.customer.assign', compact('data'));
    }
    public function fica_list()
    {
        $data = Customer::whereIsActive(1)->get();
        return view('admin.customer.fica', compact('data'));
    }

    public function change_status(Request $request)
    {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Customer::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
            'status' => "200",
            'msg' => "The customer has been $msg successfully"
        ]);
    }
}
