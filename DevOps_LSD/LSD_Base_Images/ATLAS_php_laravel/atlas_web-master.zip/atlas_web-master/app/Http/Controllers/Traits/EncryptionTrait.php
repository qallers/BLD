<?php

namespace App\Http\Controllers\Traits;

use App\Config;
use Illuminate\Support\Facades\Crypt;

trait EncryptionTrait
{
    /**
     * If the attribute is in the encryptable array
     * then decrypt it.
     *
     * @param  $key
     *
     * @return $value
     */
    public function getAttribute($key)
    {
        $value = parent::getAttribute($key);
        if (!empty(Config::where('key', 'enable_ext_sys_ref_encryption')->first()->value))
        {
            if (in_array($key, $this->encryptable) && $value !== '')
            {
               
                $v = json_decode($value, true);
               
                if ($v!=null && array_key_exists($this->passwordField, $v))
                {
                    $v[$this->passwordField] = Crypt::decrypt($v[$this->passwordField]);
                    $value = json_encode($v);
                }
            }
        }
        return $value;
    }
    /**
     * If the attribute is in the encryptable array
     * then encrypt it.
     *
     * @param $key
     * @param $value
     */
    public function setAttribute($key, $value)
    {
        if (!empty(Config::where('key', 'enable_ext_sys_ref_encryption')->first()->value))
        {
            if (in_array($key, $this->encryptable))
            {
                $v = json_decode($value, true);
                if ($v!=null && array_key_exists($this->passwordField, $v))
                {
                    $v[$this->passwordField] = Crypt::encrypt($v[$this->passwordField]);
                    $value = json_encode($v);
                }
            }
        }
        return parent::setAttribute($key, $value);
    }
    /**
     * When need to make sure that we iterate through
     * all the keys.
     *
     * @return array
     */
    public function attributesToArray()
    {
        $attributes = parent::attributesToArray();
        if (!empty(Config::where('key', 'enable_ext_sys_ref_encryption')->first()->value))
        {
            foreach ($this->encryptable as $key)
            {
                if (isset($attributes[$key]))
                {
                    $value = $attributes[$key];
                    $v = json_decode($value, true);
                    if (isset($v[$this->passwordField]))
                    {
                        $v[$this->passwordField] = Crypt::decrypt($v[$this->passwordField]);
                    }
                    $attributes[$key] = json_encode($v);
                }
            }
        }
        return $attributes;
    }
}
