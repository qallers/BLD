<?php

namespace App\Http\Controllers\Admin;

use App\Box;
use App\Grv;
use App\User;
use App\Stock;
use Exception;
use App\Config;
use App\Status;
use App\Product;
use App\Customer;
use App\Dispatch;
use App\Warehouse;
use App\SalesOrder;
use App\RepTransfer;
use App\ReturnStock;
use App\StockLedger;
use App\PurchaseOrder;
use App\ManufactureStock;
use App\Returnstockmaster;
use App\SalesOrderDetails;
use App\RepTransferDetails;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;
use App\Notifications\ReturnStockApproved;
use App\Notifications\ReturnStockRejected;
use App\Http\Requests\Admin\StoreOgrRequest;
use App\Http\Controllers\Traits\PDFExportTrait;
use App\Http\Controllers\Traits\ActivityLogTrait;
use App\Http\Controllers\Traits\ParentChildTrait;
use App\Http\Controllers\Traits\ReturnstockTrait;
use App\Http\Controllers\Traits\NotificationTraits;
use App\Http\Controllers\Traits\NavisionHelperTraits;

class StockController extends Controller
{
    use NavisionHelperTraits;
    use ReturnstockTrait;
    use NotificationTraits;
    use PDFExportTrait;
    use ParentChildTrait;
    use ActivityLogTrait;

    public function index()
    {
        $grv = Grv::with('purchaseOrder')->get();
        return view('admin.stock.index', compact('grv'));
    }

    public function create()
    {
        $purchase = DB::select('select purchase_order.* from purchase_order join `status` on `status`.id = purchase_order.status_id where status.name = "pending"');
        return view('admin.stock.create', compact('purchase'));
    }

    public function allocate($id = null, $wid = 0)
    {
        $wData = "";
        if ($id == 'rep')
        {
            if (!Gate::allows('allocate_rep_order'))
            {
                return abort(401);
            }
            $order = RepTransfer::with('warehouse', 'status', 'user')->find($wid);
            if (empty($order->external_reference))
            {
                Alert::error("The external reference must be set before allocation is enabled.");
                return back();
            }

            $od = RepTransferDetails::with('product', 'stock')->where("rep_transfer_id", $wid)->get();
            $status_rep = Status::where('process', 'rep_order')->get();

            return view('admin.stock.allocate_rep', compact('order', 'od', 'status_rep'));
        }
        else
        {
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->find($id);

            $od = SalesOrderDetails::with('product', 'deal', 'stock')->where("sales_order_id", $id)->get();
            $isInvoiced = SalesOrderDetails::where('sales_order_id', $id)->whereNull('invoice_number')->count();
            return view('admin.stock.allocate', compact('order', 'od', 'isInvoiced'));
        }
    }

    public function allocate_view()
    {
        $status = Status::where('process', 'rep_order')->get();
        return view('admin.rep.approve', compact('status'));
    }

    public function dispatch_order($id = null, $wid = 0)
    {
        $wData = "";
        if ($id == 'rep')
        {
            if (!Gate::allows('allocate_rep_order'))
            {
                return abort(401);
            }
            if (!empty($wid))
            {
                $wid = explode('_', $wid);
                $od = PurchaseOrder::with('supplier', 'warehouse', 'product', 'status', 'user')->where("warehouse_id", $wid[0])->where("status_id", $wid[1])->get();
                $wData = Warehouse::where("id", $wid[0])->get()->first();
            }
            else
            {
                $od = PurchaseOrder::with('supplier', 'warehouse', 'product', 'status', 'user')->get();
            }
            $status_rep = Status::where('process', 'rep_order')->get();

            return view('admin.stock.allocate_rep', compact('od', 'status_rep', 'wid', 'wData'));
        }
        else
        {
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->find($id);
            $od = SalesOrderDetails::with('product', 'deal')->where("sales_order_id", $id)->get();
            $isInvoiced = SalesOrderDetails::where('sales_order_id', $id)->whereNull('invoice_number')->count();
            return view('admin.stock.dispatch', compact('order', 'od', 'isInvoiced'));
        }
    }

    public function download_file($id, $name = NULL)
    {
        $d = SalesOrderDetails::with('product', 'order')->where("id", $id)->get()->first();
        if ($name == 'manufacture')
        {
            $m = ManufactureStock::where("id", $d->product->manufacture_id)->get()->first();
            $fname = 'TPCS_' . $m->reference . '_' . strtoupper(substr($d->product->network->name, 0, 1)) . $d->product->preloaded_amount . '_' . $d->product->ussd . '_' . $d->product->import_code . '_' . $d->qty;
            if (!File::exists(storage_path(strtolower($d->product->network->name) . '/dispatch/manufacture/' . $fname . '.txt')))
            {
                Alert::error("File is not yet generated.");
                return back();
            }
            return Storage::download(strtolower($d->product->network->name) . '/dispatch/manufacture/' . $fname . '.txt');
        }
        else if ($name == 'rep')
        {
            $OrderData = RepTransferDetails::with('reptransfer', 'product')->where("id", $id)->first();
            $fname = $OrderData->reptransfer->warehouse->description . '_' . $OrderData->reptransfer->external_reference . '_' . $OrderData->product->product_code . '_' . str_replace('-', '', date('Y-m-d', strtotime($OrderData->created_at)));

            if (strtoupper($OrderData->product->network->name) == 'CELLC')
            {
                if (!File::exists(storage_path('cellc/dispatch/' . $fname . '.csv')))
                {
                    Alert::error("File is not yet generated.");
                    return back();
                }
                return Storage::download('cellc/dispatch/' . $fname . '.csv');
            }
            if (strtoupper($OrderData->product->network->name) == 'MTN')
            {
                if (!File::exists(storage_path('mtn/dispatch/' . $fname . '.csv')))
                {
                    Alert::error("File is not yet generated.");
                    return back();
                }
                return Storage::download('mtn/dispatch/' . $fname . '.csv');
            }
            if (strtoupper($OrderData->product->network->name) == 'VODACOM')
            {
                if (!File::exists(storage_path('voda/dispatch/' . $fname . '.csv')))
                {
                    Alert::error("File is not yet generated.");
                    return back();
                }
                return Storage::download('voda/dispatch/' . $fname . '.csv');
            }
            if (strtoupper($OrderData->product->network->name) == 'TELKOM')
            {
                if (!File::exists(storage_path('tel/dispatch/' . $fname . '.csv')))
                {
                    Alert::error("File is not yet generated.");
                    return back();
                }
                return Storage::download('tel/dispatch/' . $fname . '.csv');
            }
        }
        else
        {
            $fname = $d->order->customer->cust_code . '_' . $d->invoice_number . '_' . $d->product->product_code . '_' . str_replace('-', '', date('Y-m-d', strtotime($d->created_at)));
            if (strtoupper($d->product->network->name) == 'CELLC')
            {
                if (!File::exists(storage_path('cellc/dispatch/' . $fname . '.csv')))
                {
                    Alert::error("File is not yet generated.");
                    return back();
                }
                return Storage::download('cellc/dispatch/' . $fname . '.csv');
            }
            if (strtoupper($d->product->network->name) == 'MTN')
            {
                if (!File::exists(storage_path('mtn/dispatch/' . $fname . '.csv')))
                {
                    Alert::error("File is not yet generated.");
                    return back();
                }
                return Storage::download('mtn/dispatch/' . $fname . '.csv');
            }
            if (strtoupper($d->product->network->name) == 'VODACOM')
            {
                if (!File::exists(storage_path('voda/dispatch/' . $fname . '.csv')))
                {
                    Alert::error("File is not yet generated.");
                    return back();
                }
                return Storage::download('voda/dispatch/' . $fname . '.csv');
            }
            if (strtoupper($d->product->network->name) == 'TELKOM')
            {
                if (!File::exists(storage_path('tel/dispatch/' . $fname . '.csv')))
                {
                    Alert::error("File is not yet generated.");
                    return back();
                }
                return Storage::download('tel/dispatch/' . $fname . '.csv');
            }
        }
    }

    public function dispatch_stock(StoreOgrRequest $request)
    {
        $ids = str_replace(' ', '', $request->input("ids"));
        $ids = explode(',', $ids);
        if (!empty($request->input("rep")))
        {
            if (!empty($ids))
            {
                $affected = RepTransferDetails::whereIn('id', $ids)
                    ->update(['is_dispatch' => 1]);

                if (!empty($ids))
                {
                    $wid = Config::where("key", "warehouse_in_transit_id")->first()->value;
                    foreach ($ids as $id)
                    {
                        Stock::where('rep_transfer_detail_id', $id)
                            ->update(['warehouse_id' => $wid]);
                    }
                }
                $user = auth()->user();

                $order = RepTransferDetails::with('reptransfer')->where("id", $ids[0])->first();

                $sl = array();
                $sl['user_id'] = $user->id;
                $sl['order_id'] = $order->rep_transfer_id;
                $sl['qty'] = $order->qty;

                $sl['order_name'] = "REP";
                $sl['process_name'] = "dispatched_order";

                StockLedger::create($sl);
                return response()->json([
                    'status' => "200",
                    'msg' => "Stock has been dispatched successfully"
                ]);
            }
        }
        else
        {
            foreach ($ids as $i)
            {
                $d = SalesOrderDetails::with('product', 'order')->where("id", $i)->first();
                if (!empty($d->product->manufacture_id))
                {
                    $m = ManufactureStock::where("id", $d->product->manufacture_id)->first();
                    $fname = 'TPCS_' . $m->reference . '_' . strtoupper(substr($d->product->network->name, 0, 1)) . $d->product->preloaded_amount . '_' . $d->product->ussd . '_' . $d->product->import_code . '_' . $d->qty;
                    $getData = Stock::where('sales_order_detail_id', $i)->get();
                    $content = "H|" . $m->reference . "|" . $m->created_at . "|" . $fname . "|" . $d->product->preloaded_amount . "|" . $m->qty . "|" . $d->product->product_code . "|" . $d->order->customer->cust_code . PHP_RN;
                    $cnt = 0;
                    foreach ($getData as $v)
                    {
                        $content .= $v->serial_no . PHP_RN;
                        $cnt++;
                    }
                    $content .= 'F|' . $cnt . '|R ' . ($d->product->qty * $d->product->preloaded_amount) . '|20212';
                    Storage::disk('local')->put(strtolower($d->product->network->name) . '/dispatch/manufacture/' . $fname . '.txt', $content);
                }
                //$dbh = 0;
                $eData = \App\ExternalSystemReference::where("customer_id", $d->order->customer_id)->where("external_system_id", 5)->first();

                if (!empty($eData->data))
                {
                    $ref = json_decode($eData->data);
                    if (!empty($ref))
                    {
                        if (!empty($ref->database))
                        {
                            $db = Crypt::decrypt($ref->database);
                            try
                            {
                                $dbh = new \PDO('mysql:host=' . env("DB_HOST") . ';dbname=' . $db . '', env("DB_USERNAME"), env("DB_PASSWORD"), array(\PDO::MYSQL_ATTR_LOCAL_INFILE => true, \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION));
                            }
                            catch (\PDOException $ex)
                            {
                                $dbh = 0;
                            }
                        }
                    }
                }
                $fname = $d->order->customer->cust_code . '_' . $d->invoice_number . '_' . $d->product->product_code . '_' . str_replace('-', '', date('Y-m-d', strtotime($d->created_at)));
                $fnamet = 'tenant_' . $d->order->customer->cust_code . '_' . $d->invoice_number . '_' . $d->product->product_code . '_' . str_replace('-', '', date('Y-m-d', strtotime($d->created_at)));

                $tenant_cnt = 0;
                $file_id = 0;
                $path_for_delete = '';
                if (strtoupper($d->product->network->name) == 'CELLC')
                {
                    $getData = DB::select("SELECT s.serial_no,
                            IF(s.box_id IS NULL, g.brick, b.barcode) brick,
                            IF(s.box_id IS NULL, concat(carton,'-',SPLIT_STRING(g.brick,'-',3)), b2.barcode) box,
                            IF(s.box_id IS NULL, concat(pallet,'-',SPLIT_STRING(g.brick,'-',2)), b3.barcode) carton,
                            IF(s.box_id IS NULL, SPLIT_STRING(g.brick,'-',1), b4.barcode) pallet,
                            p.description,
                            c.name,
                            so.invoice_number,
                            so.created_at,
                            gp.description as gp_description 
                            FROM stock s
                            LEFT JOIN grv g ON s.serial_no = g.serial_no 
                            LEFT JOIN box b ON s.box_id = b.id
                            LEFT JOIN product p ON s.product_id = p.id
                            LEFT JOIN customer c ON s.customer_id = c.id
                            LEFT JOIN sales_order_detail so ON s.sales_order_detail_id = so.id
                            LEFT JOIN `group` gp ON c.group_id = gp.id
                            LEFT JOIN box b2 ON b.parent_id = b2.id
                            LEFT JOIN box b3 ON b2.parent_id = b3.id
                            LEFT JOIN box b4 ON b3.parent_id = b4.id
                            WHERE s.sales_order_detail_id = $i");
                    //$content = "ICCID,brick,box,carton,pallet,ProductName,BranchName,InvoiceNo,InvoiceDate,JV" . PHP_RN;
                    $content = "ICCID,BoxNo,ProductName,BranchName,InvoiceNo,InvoiceDate,JV" . PHP_RN;
                    $cnt = count($getData);

                    if (!empty($dbh))
                    {
                        $dbh->query('insert into grv_import_file(file_config_id,purchase_order_id,supplier_invoice_id,file_name,qty,status)values(8,0,0,"' . $fname . '.csv",' . $cnt . ',2)');
                        $file_id = $dbh->lastInsertId();

                        $col = '(@col1,@col2,@col3,@col4,@col5,@col6,@col7) set file_id = ' . $file_id . ',purchase_order_id = 0,pallet = REPLACE(@col2, "\r", ""),carton = REPLACE(@col3, "\r", ""),box = REPLACE(@col4, "\r", ""),brick = REPLACE(@col5, "\r", ""),serial_no=@col1,file_date=@col6';
                        $filePath = Storage::disk('local')->path('cellc/dispatch/' . $fnamet . '.csv');
                        $path_for_delete = 'cellc/dispatch/' . $fnamet . '.csv';
                    }
                    $content_tenant = "ICCID,BoxNo,ProductName,BranchName,InvoiceNo,InvoiceDate,JV" . PHP_RN;
                    foreach ($getData as $sub)
                    {
                        $implode = array();
                        //$sub = (array) $sub;
                        $implode[] = $sub->serial_no;
                        $implode[] = $sub->pallet;
                        $implode[] = $sub->carton;
                        $implode[] = $sub->box;
                        $implode[] = $sub->brick;
                        $implode[] = $sub->description;
                        $implode[] = $sub->name;
                        $implode[] = $sub->invoice_number;
                        $implode[] = date('Y-m-d', strtotime($sub->created_at));
                        $implode[] = $sub->gp_description;
                        $content_tenant .= implode(',', $implode) . PHP_RN;
                        $content .= $sub->serial_no . ',' . $sub->brick . ',' . $sub->description . ',' . $sub->name . ',' . $sub->invoice_number . ',' . date('Y-m-d', strtotime($sub->created_at)) . ',' . $sub->gp_description . PHP_RN;
                    }

                    Storage::disk('local')->append('cellc/dispatch/' . $fname . '.csv', $content);
                    if (!empty($dbh))
                    {
                        Storage::disk('local')->append('cellc/dispatch/' . $fnamet . '.csv', $content_tenant);
                    }
                }
                if (strtoupper($d->product->network->name) == 'MTN')
                {
                    //$content = "kit,barcode,kit sim,kit pallet,kit carton,kit box,kit brick" . PHP_RN;
                    $getData = DB::select("SELECT s.serial_no,'',
                            s.alt_serial_no,
                            IF(s.box_id IS NULL, g.pallet, b4.barcode) pallet,
                            IF(s.box_id IS NULL, g.carton, b3.barcode) carton,
                            IF(s.box_id IS NULL, g.box, b2.barcode) box,
                            IF(s.box_id IS NULL, g.brick, b.barcode) brick
                            FROM stock s
                            LEFT JOIN grv g ON s.serial_no = g.serial_no 
                            LEFT JOIN box b ON s.box_id = b.id
                            LEFT JOIN box b2 ON b.parent_id = b2.id
                            LEFT JOIN box b3 ON b2.parent_id = b3.id
                            LEFT JOIN box b4 ON b3.parent_id = b4.id
                            WHERE s.sales_order_detail_id = $i");
                    $cnt = count($getData);
                    if (!empty($dbh))
                    {
                        $dbh->query('insert into grv_import_file(file_config_id,purchase_order_id,supplier_invoice_id,file_name,qty,status)values(20,0,0,"' . $fname . '.csv",' . $cnt . ',2)');
                        $file_id = $dbh->lastInsertId();

                        $col = '(@col1,@col2,@col3,@col4,@col5,@col6,@col7) set file_id = ' . $file_id . ',purchase_order_id = 0,serial_no=@col1,alt_serial_no=@col3,pallet = REPLACE(@col4, "\r", ""),carton = REPLACE(@col5, "\r", ""),box = REPLACE(@col6, "\r", ""),brick = REPLACE(@col7, "\r", "")';
                        $filePath = Storage::disk('local')->path('mtn/dispatch/' . $fnamet . '.csv');
                        $path_for_delete = 'mtn/dispatch/' . $fnamet . '.csv';
                    }
                    $content = "kit,barcode,kit sim,kit box,kit brick" . PHP_RN;
                    $content_tenant = "kit,barcode,kit sim,kit box,kit brick" . PHP_RN;
                    foreach ($getData as $sub)
                    {
                        $implode = array();
                        //$sub = (array) $sub;
                        $implode[] = $sub->serial_no;
                        $implode[] = '';
                        $implode[] = $sub->alt_serial_no;
                        $implode[] = $sub->pallet;
                        $implode[] = $sub->carton;
                        $implode[] = $sub->box;
                        $implode[] = $sub->brick;
                        $content_tenant .= implode(',', $implode) . PHP_RN;
                        $content .= $sub->serial_no . ',' . ',' . $sub->alt_serial_no . ',' . $sub->box . ',' . $sub->brick . PHP_RN;
                    }
                    Storage::disk('local')->append('mtn/dispatch/' . $fname . '.csv', $content);
                    if (!empty($dbh))
                    {
                        Storage::disk('local')->append('mtn/dispatch/' . $fnamet . '.csv', $content_tenant);
                    }
                }
                if (strtoupper($d->product->network->name) == 'VODACOM')
                {
                    //$content = "ICCID,pallet,carton,box,brick,ProductName,BranchName,InvoiceNo,InvoiceDate,JV" . PHP_RN;
                    $getData = DB::select("SELECT s.serial_no,
                                    IF(s.box_id IS NULL, g.pallet, b4.barcode) pallet,
                                    IF(s.box_id IS NULL, g.carton, b3.barcode) carton,
                                    IF(s.box_id IS NULL, g.box, b2.barcode) box,
                                    IF(s.box_id IS NULL, g.brick, b.barcode) brick,
                                    p.description,
                                    c.name,
                                    so.invoice_number,
                                    so.created_at,
                                    gp.description as gp_description 
                                    FROM stock s
                                    LEFT JOIN grv g ON s.serial_no = g.serial_no 
                                    LEFT JOIN box b ON s.box_id = b.id
                                    LEFT JOIN product p ON s.product_id = p.id
                                    LEFT JOIN customer c ON s.customer_id = c.id
                                    LEFT JOIN sales_order_detail so ON s.sales_order_detail_id = so.id
                                    LEFT JOIN `group` gp ON c.group_id = gp.id
                                    LEFT JOIN box b2 ON b.parent_id = b2.id
                                    LEFT JOIN box b3 ON b2.parent_id = b3.id
                                    LEFT JOIN box b4 ON b3.parent_id = b4.id
                                    WHERE s.sales_order_detail_id = $i");
                    $cnt = count($getData);
                    if (!empty($dbh))
                    {
                        $dbh->query('insert into grv_import_file(file_config_id,purchase_order_id,supplier_invoice_id,file_name,qty,status)values(21,0,0,"' . $fname . '.csv",' . $cnt . ',2)');
                        $file_id = $dbh->lastInsertId();

                        $col = '(@col1,@col2,@col3,@col4,@col5,@col6,@col7) set file_id = ' . $file_id . ',purchase_order_id = 0,serial_no=@col1,pallet=REPLACE(@col2, "\r", ""),carton=REPLACE(@col3, "\r", ""),box=REPLACE(@col4, "\r", ""),brick=REPLACE(@col5, "\r", ""),file_date=@col6';
                        $filePath = Storage::disk('local')->path('voda/dispatch/' . $fnamet . '.csv');
                        $path_for_delete = 'voda/dispatch/' . $fnamet . '.csv';
                    }
                    $content = "ICCID,BoxNo,ProductName,BranchName,InvoiceNo,InvoiceDate,JV" . PHP_RN;
                    $content_tenant = "ICCID,BoxNo,ProductName,BranchName,InvoiceNo,InvoiceDate,JV" . PHP_RN;
                    foreach ($getData as $sub)
                    {
                        $implode = array();
                        $implode[] = $sub->serial_no;
                        $implode[] = $sub->pallet;
                        $implode[] = $sub->carton;
                        $implode[] = $sub->box;
                        $implode[] = $sub->brick;
                        $implode[] = $sub->description;
                        $implode[] = $sub->name;
                        $implode[] = $sub->invoice_number;
                        $implode[] = date('Y-m-d', strtotime($sub->created_at));
                        $implode[] = $sub->gp_description;
                        $content_tenant .= implode(',', $implode) . PHP_RN;
                        $content .= $sub->serial_no . ',' . $sub->brick . ',' . $sub->description . ',' . $sub->name . ',' . $sub->invoice_number . ',' . date('Y-m-d', strtotime($sub->created_at)) . ',' . $sub->gp_description . PHP_RN;
                    }
                    Storage::disk('local')->put('voda/dispatch/' . $fname . '.csv', $content);
                    if (!empty($dbh))
                    {
                        Storage::disk('local')->put('voda/dispatch/' . $fnamet . '.csv', $content_tenant);
                    }
                }
                if (strtoupper($d->product->network->name) == 'TELKOM')
                {
                    //$content = "Order Date,Order Time,Invoice Date,Invoice Time,Customer PO Number,Part No,Part Description,Serial Number,Carton 1,Carton 2,Carton 3,Carton 4,Extra Number,Supplier Name,Bought,Waybill Number,Commodity Group,Date Received,Receiver Name,Signed By" . PHP_RN;
                    $getData = DB::select("SELECT DATE(so.created_at) as c_date,
                            TIME(so.created_at) as c_time,
                            DATE(so.updated_at) as u_date,
                            TIME(so.updated_at) as u_time,
                            '' AS po,
                            '' AS part,
                            p.description,
                           s.serial_no,
                           IF(s.box_id IS NULL, g.pallet, b4.barcode) pallet,
                           IF(s.box_id IS NULL, g.carton, b3.barcode) carton,
                           IF(s.box_id IS NULL, g.box, b2.barcode) box,
                           IF(s.box_id IS NULL, g.brick, b.barcode) brick,
                           '' AS extra,
                           '' AS supplier_name,
                           c.name,
                           so.invoice_number,
                           'SIM CARDS',
                           so.created_at,
                           '' as reciver_name,
                           '' as singrd_by
                           FROM stock s
                           LEFT JOIN grv g ON s.serial_no = g.serial_no 
                           LEFT JOIN box b ON s.box_id = b.id
                           LEFT JOIN product p ON s.product_id = p.id
                           LEFT JOIN customer c ON s.customer_id = c.id
                           LEFT JOIN sales_order_detail so ON s.sales_order_detail_id = so.id
                           LEFT JOIN box b2 ON b.parent_id = b2.id
                           LEFT JOIN box b3 ON b2.parent_id = b3.id
                           LEFT JOIN box b4 ON b3.parent_id = b4.id
                           WHERE s.sales_order_detail_id = $i");
                    $cnt = count($getData);
                    if (!empty($dbh))
                    {
                        $dbh->query('insert into grv_import_file(file_config_id,purchase_order_id,supplier_invoice_id,file_name,qty,status)values(22,0,0,"' . $fname . '.csv",' . $cnt . ',2)');
                        $file_id = $dbh->lastInsertId();

                        $col = '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19) set file_id = ' . $file_id . ',purchase_order_id = 0,serial_no=@col8,pallet=REPLACE(@col9, "\r", ""),carton=REPLACE(@col10, "\r", ""),box=REPLACE(@col11, "\r", ""),brick=REPLACE(@col12, "\r", "")';
                        $filePath = Storage::disk('local')->path('tel/dispatch/' . $fnamet . '.csv');
                        $path_for_delete = 'tel/dispatch/' . $fnamet . '.csv';
                    }
                    $content = "Order Date,Order Time,Invoice Date,Invoice Time,Customer PO Number,Part No,Part Description,Serial Number,Carton 1,Carton 2,Carton 3,Extra Number,Supplier Name,Bought,Waybill Number,Commodity Group,Date Received,Receiver Name,Signed By" . PHP_RN;
                    $content_tenant = "Order Date,Order Time,Invoice Date,Invoice Time,Customer PO Number,Part No,Part Description,Serial Number,Carton 1,Carton 2,Carton 3,Extra Number,Supplier Name,Bought,Waybill Number,Commodity Group,Date Received,Receiver Name,Signed By" . PHP_RN;
                    foreach ($getData as $sub)
                    {
                        //$sub = (array) $sub;
                        $implode = array();
                        $implode[] = $sub->c_date;
                        $implode[] = $sub->c_time;
                        $implode[] = $sub->u_date;
                        $implode[] = "";
                        $implode[] = "";
                        $implode[] = "";
                        $implode[] = $sub->description;
                        $implode[] = $sub->serial_no;
                        $implode[] = $sub->pallet;
                        $implode[] = $sub->carton;
                        $implode[] = $sub->box;
                        $implode[] = $sub->brick;
                        $implode[] = "";
                        $implode[] = "";
                        $implode[] = $sub->name;
                        $implode[] = 1;
                        $implode[] = $sub->invoice_number;
                        $implode[] = "SIM CARDS";
                        $implode[] = date('Y-m-d h:i:s', strtotime($sub->created_at));
                        $implode[] = "";
                        $implode[] = "";
                        $content_tenant .= implode(',', $implode) . PHP_RN;

                        $implode = array();
                        $implode[] = $sub->c_date;
                        $implode[] = $sub->c_time;
                        $implode[] = $sub->u_date;
                        $implode[] = "";
                        $implode[] = "";
                        $implode[] = "";
                        $implode[] = $sub->description;
                        $implode[] = $sub->serial_no;
                        $implode[] = $sub->box;
                        $implode[] = $sub->brick;
                        $implode[] = "";
                        $implode[] = "";
                        $implode[] = $sub->name;
                        $implode[] = 1;
                        $implode[] = $sub->invoice_number;
                        $implode[] = "SIM CARDS";
                        $implode[] = date('Y-m-d h:i:s', strtotime($sub->created_at));
                        $implode[] = "";
                        $implode[] = "";
                        $content .= implode(',', $implode) . PHP_RN;
                    }
                    Storage::disk('local')->put('tel/dispatch/' . $fname . '.csv', $content);
                    if (!empty($dbh))
                    {
                        Storage::disk('local')->put('tel/dispatch/' . $fnamet . '.csv', $content_tenant);
                    }
                }

                if (!empty($dbh))
                {

                    $filePath = str_replace("\\", "/", $filePath);
                    $filePath = str_replace(':', ':/', $filePath);

                    $q = 'LOAD DATA LOCAL INFILE  \'' . $filePath . '\'
                INTO TABLE grv
                FIELDS TERMINATED by \',\' LINES TERMINATED BY \'\n\' IGNORE 1 LINES ' . $col . '';

                    $affected = $dbh->query($q);
                    $t = Storage::disk('local')->path($path_for_delete);
                    if (file_exists($t))
                    {
                        Storage::delete($path_for_delete);
                    }
                }

                $order = SalesOrder::where("id", $d->sales_order_id)->first();
                $dispatch = Dispatch::create([
                    'invoice_id' => $d->id,
                    'qty' => $d->qty,
                    'warehouse_id' => $order->warehouse_id,
                    'status_id' => $order->status_id,
                ]);

                if (!empty($dbh))
                {
                    $statement = $dbh->prepare("select count(id) as cnt from grv where file_id = :file_id");
                    $statement->execute(array(':file_id' => $file_id));
                    $row = $statement->fetch();
                    if ($cnt != $row['cnt'])
                    {
                        $dbh->query("delete from grv_import_file where id = $file_id");
                        $dbh->query("delete from grv where file_id = $file_id");
                        $d = Status::where("process", "dispatch")->where("status", "stock_move_fail")->first();
                        Dispatch::where('id', $dispatch->id)
                            ->update(['status_id' => $d->id]);

                        $data = array("data" => $request, "process" => "stock dispatch");
                        $description = "Tenant Transfer fail";
                        $this->setActivityLog('', '', $data, $description);
                    }
                    else
                    {
                        $d = Status::where("process", "dispatch")->where("status", "stock_move_done")->first();
                        Dispatch::where('id', $dispatch->id)
                            ->update(['status_id' => $d->id]);

                        $data = array("data" => $request, "process" => "stock dispatch");
                        $description = "Tenant Transfer Success";
                        $this->setActivityLog('', '', $data, $description);
                    }
                }
                $this->generatePDFSales($order);

                $sl = array();
                $sl['user_id'] = Auth::user()->id;
                $sl['order_id'] = $d->id;
                $sl['qty'] = $d->qty;
                $sl['order_name'] = "SALES";
                $sl['process_name'] = "dispatched_order";

                StockLedger::create($sl);
            }

            $data = array("data" => $request, "process" => "stock dispatch");
            $description = "Stock has been dispatched successfully";
            $this->setActivityLog('', '', $data, $description);

            $affected = SalesOrderDetails::whereIn('id', $ids)
                ->update(['is_dispatch' => 1]);

            return response()->json([
                'status' => "200",
                'msg' => "Stock has been dispatched successfully"
            ]);
        }
    }

    public function allocate_stock_rep(StoreOgrRequest $request)
    {
        if (!Gate::allows('transfer_rep_orders'))
        {
            return response()->json([
                'status' => "401",
                'msg' => "Unauthorized access",
                'count' => 0
            ]);
        }
        $input = str_replace(' ', '', $request->input("input"));
        $qty = str_replace(' ', '', $request->input("qty"));
        $box_type = str_replace(' ', '', $request->input("box_type"));
        $po = $request->input('sales_order_id');
        $pid = $request->input('p_id');
        $affected = 0;
        $qtyValidate = 0;
        $cnt = 0;

        $boxdata = Box::where('barcode', $input)->first();

        $OrderData = RepTransferDetails::with('reptransfer', 'product')->where("id", $po)->first();

        if ($box_type == 'internal')
        {

            if (empty($boxdata->id))
            {

                $data = array("data" => $request, "process" => "Rep stock allocate");
                $description = "Box not found or you select wrong box type";
                $this->setActivityLog('', '', $data, $description);

                return response()->json([
                    'status' => "400",
                    'msg' => "Box not found or you select wrong box type",
                    'count' => 0
                ]);
            }

            if ($boxdata->parent_id != 0)
            {
                $data = array("data" => $request, "process" => "Rep stock allocate");
                $description = "Box belong to a bigger box can't be allocated as single box";
                $this->setActivityLog('', $boxdata, $data, $description);
                return response()->json([
                    'status' => "400",
                    'msg' => $description,
                    'count' => 0
                ]);
            }

            $getChild = $this->getChildBox($boxdata->id);
            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $box = $boxdata->id;
                $cntQty = DB::table('stock')->where("box_id", $box)->count();
            }
            else
            {
                $cntQty = DB::table('stock')->whereIn("box_id", $getChild)->count();
            }

            $cntAllocateQty = DB::table('stock')->where("rep_transfer_detail_id", $po)->count();
            $qtyValidate = $OrderData->qty - $cntAllocateQty;
            if ((int) $cntQty > (int) $qtyValidate)
            {
                $data = array("data" => $request, "process" => "Rep stock allocate");
                $description = "Allocated quantity is more than order quantity";
                $this->setActivityLog('', '', $data, $description);

                return response()->json([
                    'status' => "400",
                    'msg' => "Allocated quantity is more than order quantity",
                    'count' => 0
                ]);
            }
            if ($cntQty <= 0)
            {
                $data = array("data" => $request, "process" => "Rep stock allocate");
                $description = "Stock is not available for this box number";
                $this->setActivityLog('', '', $data, $description);
                return response()->json([
                    'status' => "400",
                    'msg' => "Stock is not available for this box number",
                    'count' => 0
                ]);
            }

            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $s = Stock::where("box_id", $box)->first();
                if (!empty($s->rep_transfer_detail_id))
                {
                    $data = array("data" => $request, "process" => "Rep stock allocate");
                    $description = "Stock is already transferred or allocated";
                    $this->setActivityLog('', '', $data, $description);

                    return response()->json([
                        'status' => "400",
                        'msg' => "Stock is already transferred or allocated",
                        'count' => 0
                    ]);
                }

                if(!empty($s->customer_id))
                {
                    $data = array("data" => $request, "process" => "Rep stock allocate");
                    $description = "Stock is already sold to a customer ";
                    $this->setActivityLog('', '', $data, $description);

                    return response()->json([
                        'status' => "400",
                        'msg' => $description,
                        'count' => 0
                    ]);
                }

                $affected = Stock::where('box_id', $box)->where("product_id", $pid)
                    ->update(['rep_transfer_detail_id' => $po]);

                $allSerial = Stock::where('box_id', $box)->get();
            }
            else
            {
                $affected = 0;
                foreach ($getChild as $bx)
                {
                    $s = Stock::where("box_id", $bx)->first();
                    if (!empty($s->rep_transfer_detail_id))
                    {
                        return response()->json([
                            'status' => "400",
                            'msg' => "Stock is already transferred or allocated",
                            'count' => 0
                        ]);
                    }

                    if(!empty($s->customer_id))
                    {
                        $data = array("data" => $request, "process" => "Rep stock allocate");
                        $description = "Stock is already sold to a customer ";
                        $this->setActivityLog('', '', $data, $description);
    
                        return response()->json([
                            'status' => "400",
                            'msg' => $description,
                            'count' => 0
                        ]);
                    }

                    $cnt = Stock::where('box_id', $bx)->where("product_id", $pid)
                        ->update(['rep_transfer_detail_id' => $po]);
                    $affected = $affected + $cnt;
                }

                $allSerial = Stock::whereIn('box_id', $getChild)->get();
            }

            $data = array("data" => $request, "barcode" => $input, "serial_nos" => $allSerial, "qty" => $qty, "box_qty" => $cntQty, "allocate_qty" => $affected, "box_type" => $box_type, "po" => $po, "product_id" => $pid, "Process" => "Allocate stock REP");
            $description = "Rep allocation process";
            $this->setActivityLog('', $s, $data, $description);

            if (!empty($allSerial))
            {
                foreach ($allSerial as $sr)
                {
                    DB::update("UPDATE grv SET is_transfer = 1 where serial_no = '$sr->serial_no'");
                }
            }

            $cntAllocateQty = DB::table('stock')->where("rep_transfer_detail_id", $po)->count();

            if ((int) $qty == $cntAllocateQty)
            {
                RepTransferDetails::where('id', $po)
                    ->update(['is_allocate' => 1]);

                $data = array("barcode" => $input, "qty" => $qty, "allocate_qty" => $cntAllocateQty, "box_type" => $box_type, "po" => $po, "product_id" => $pid, "Process" => "Allocate stock REP");
                $description = "Fully allocated";
                $this->setActivityLog('', $s, $data, $description);
            }
            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $po;
            $sl['qty'] = $affected;
            $sl['order_name'] = "REP";
            $sl['barcode'] = $input;
            $sl['process_name'] = "allocate_order";

            StockLedger::create($sl);

            try
            {
                $this->nav_patch_transfer($OrderData->reptransfer->external_reference, "10000", [
                    "Qty_to_Ship" => (string) $affected
                ]);
            }
            catch (Exception $e)
            {
            }
        }
        if ($box_type == 'external')
        {
            $cntQty = DB::table('grv')->where(function ($query) use ($input)
            {
                $query->where("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input);
            })->where(function ($query)
            {
                $query->where("is_available", 0)
                    ->orWhere("is_transfer", 1);
            })->count();

            if ($cntQty > 0)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "This box starter pack has been used for internal box or already transferred",
                    'count' => 0
                ]);
            }

            $cntQty = DB::table('grv')->where("is_available", 1)->where(function ($query) use ($input)
            {
                $query->where("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input);
            })->count();

            $OrderData = RepTransferDetails::where("id", $po)->first();
            $cntAllocateQty = DB::table('stock')->where("rep_transfer_detail_id", $po)->count();

            $qtyValidate = $OrderData->qty - $cntAllocateQty;

            if ((int) $cntQty > (int) $qtyValidate)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Allocated quantity is more than order quantity",
                    'count' => 0
                ]);
            }
            if ($cntQty <= 0)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Stock is not available for this ",
                    'count' => 0
                ]);
            }

            $allSerial = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->get();

            $wid = Config::where("key", "warehouse_in_transit_id")->first()->value;
            $affected = 0;
            foreach ($allSerial as $sr)
            {
                $chk = Stock::where("product_id", $pid)->where("serial_no", $sr->serial_no)->first();
                if (empty($chk->product_id))
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "Product mismatch with order"
                    ]);
                }


                $cnt = Stock::where('serial_no', $sr->serial_no)
                    ->update(['rep_transfer_detail_id' => $po]);
                DB::update("UPDATE grv SET is_transfer = 1 where serial_no = '$sr->serial_no'");
                $affected = $affected + $cnt;
            }

            $data = array("data" => $request, "barcode" => $input, "qty" => $qty, "box_qty" => $cntQty, "allocate_qty" => $affected, "box_type" => $box_type, "po" => $po, "product_id" => $pid, "Process" => "Allocate stock REP");
            $description = "Rep allocation process";
            $this->setActivityLog('', $OrderData, $data, $description);

            $cntAllocateQty = DB::table('stock')->where("rep_transfer_detail_id", $po)->count();
            if ((int) $qty == ((int) $cntAllocateQty))
            {
                RepTransferDetails::where('id', $po)
                    ->update(['is_allocate' => 1]);

                $data = array("barcode" => $input, "qty" => $qty, "allocate_qty" => $cntAllocateQty, "box_type" => $box_type, "po" => $po, "product_id" => $pid, "Process" => "Allocate stock REP");
                $description = "Rep allocation done";
                $this->setActivityLog('', $OrderData, $data, $description);
            }

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $po;
            $sl['qty'] = $cnt;
            $sl['order_name'] = "REP";
            $sl['barcode'] = $input;
            $sl['process_name'] = "allocate_order";

            StockLedger::create($sl);
            try
            {
                $this->nav_patch_transfer($OrderData->reptransfer->external_reference, "10000", [
                    "Qty_to_Ship" => (string) $cnt
                ]);
            }
            catch (Exception $e)
            {
            }
        }

        /*
        *Generating files for rep
        */
        if ($cntAllocateQty == $OrderData->qty)
        {
            $fname = $OrderData->reptransfer->warehouse->description . '_' . $OrderData->reptransfer->external_reference . '_' . $OrderData->product->product_code . '_' . str_replace('-', '', date('Y-m-d', strtotime($OrderData->created_at)));

            if (strtoupper($OrderData->product->network->name) == 'CELLC')
            {
                $getData = DB::select("SELECT s.serial_no,
                            IF(s.box_id IS NULL, g.brick, b.barcode) brick,
                            IF(s.box_id IS NULL, g.box, b2.barcode) box,
                            IF(s.box_id IS NULL, g.carton, b3.barcode) carton,
                            IF(s.box_id IS NULL, g.pallet, b4.barcode) pallet,
                            p.description,
                            w.description name,
                            r.external_reference invoice_number,
                            rd.created_at,
                            '' as gp_description 
                            FROM stock s
                            LEFT JOIN grv g ON s.serial_no = g.serial_no 
                            LEFT JOIN box b ON s.box_id = b.id
                            LEFT JOIN product p ON s.product_id = p.id
                            LEFT JOIN rep_transfer_detail rd ON rd.id = s.rep_transfer_detail_id
                            LEFT JOIN rep_transfer r ON r.id=rd.rep_transfer_id
                            LEFT JOIN warehouse w ON w.id =r.warehouse_id
                            LEFT JOIN box b2 ON b.parent_id = b2.id
                            LEFT JOIN box b3 ON b2.parent_id = b3.id
                            LEFT JOIN box b4 ON b3.parent_id = b4.id
                            WHERE s.rep_transfer_detail_id= $OrderData->id");
                //$content = "ICCID,brick,box,carton,pallet,ProductName,BranchName,InvoiceNo,InvoiceDate,JV" . PHP_RN;
                $content = "ICCID,BoxNo,ProductName,BranchName,InvoiceNo,InvoiceDate,JV" . PHP_RN;
                $cnt = count($getData);

                foreach ($getData as $sub)
                {
                    $implode = array();
                    //$sub = (array) $sub;
                    $implode[] = $sub->serial_no;
                    $implode[] = $sub->brick;
                    $implode[] = $sub->description;
                    $implode[] = $sub->name;
                    $implode[] = $sub->invoice_number;
                    $implode[] = date('Y-m-d', strtotime($sub->created_at));
                    $implode[] = $sub->gp_description;
                    $content .= implode(',', $implode) . PHP_RN;
                }
                Storage::disk('local')->append('cellc/dispatch/' . $fname . '.csv', $content);
            }

            if (strtoupper($OrderData->product->network->name) == 'MTN')
            {
                //$content = "kit,barcode,kit sim,kit pallet,kit carton,kit box,kit brick" . PHP_RN;
                $getData = DB::select("  SELECT s.serial_no,'',
                            s.alt_serial_no,
                            IF(s.box_id IS NULL, g.pallet, b4.barcode) pallet,
                            IF(s.box_id IS NULL, g.carton, b3.barcode) carton,
                            IF(s.box_id IS NULL, g.box, b2.barcode) box,
                            IF(s.box_id IS NULL, g.brick, b.barcode) brick
                            FROM stock s
                            LEFT JOIN grv g ON s.serial_no = g.serial_no 
                            LEFT JOIN box b ON s.box_id = b.id
                            LEFT JOIN box b2 ON b.parent_id = b2.id
                            LEFT JOIN box b3 ON b2.parent_id = b3.id
                            LEFT JOIN box b4 ON b3.parent_id = b4.id
                            WHERE s.rep_transfer_detail_id = $OrderData->id");

                $cnt = count($getData);

                $content = "kit,barcode,kit sim,kit box,kit brick" . PHP_RN;

                foreach ($getData as $sub)
                {
                    $implode = array();
                    //$sub = (array) $sub;
                    $implode[] = $sub->serial_no;
                    $implode[] = '';
                    $implode[] = $sub->alt_serial_no;
                    $implode[] = $sub->box;
                    $implode[] = $sub->brick;
                    $content .= implode(',', $implode) . PHP_RN;
                }


                Storage::disk('local')->append('mtn/dispatch/' . $fname . '.csv', $content);
            }

            if (strtoupper($OrderData->product->network->name) == 'VODACOM')
            {
                //$content = "ICCID,pallet,carton,box,brick,ProductName,BranchName,InvoiceNo,InvoiceDate,JV" . PHP_RN;
                $getData = DB::select(" SELECT s.serial_no,
                            IF(s.box_id IS NULL, g.pallet, b4.barcode) pallet,
                            IF(s.box_id IS NULL, g.carton, b3.barcode) carton,
                            IF(s.box_id IS NULL, g.box, b2.barcode) box,
                            IF(s.box_id IS NULL, g.brick, b.barcode) brick,
                            p.description,
                            w.description name,
                            r.external_reference invoice_number,
                            rd.created_at,
                            '' as gp_description 
                            FROM stock s
                            LEFT JOIN grv g ON s.serial_no = g.serial_no 
                            LEFT JOIN box b ON s.box_id = b.id
                            LEFT JOIN product p ON s.product_id = p.id
                            LEFT JOIN rep_transfer_detail rd ON rd.id = s.rep_transfer_detail_id
                            LEFT JOIN rep_transfer r ON r.id=rd.rep_transfer_id
                            LEFT JOIN warehouse w ON w.id =r.warehouse_id
                            LEFT JOIN box b2 ON b.parent_id = b2.id
                            LEFT JOIN box b3 ON b2.parent_id = b3.id
                            LEFT JOIN box b4 ON b3.parent_id = b4.id
                            WHERE s.rep_transfer_detail_id=$OrderData->id");

                $cnt = count($getData);

                $content = "ICCID,BoxNo,ProductName,BranchName,InvoiceNo,InvoiceDate,JV" . PHP_RN;

                foreach ($getData as $sub)
                {
                    $implode = array();
                    $implode[] = $sub->serial_no;
                    $implode[] = $sub->brick;
                    $implode[] = $sub->description;
                    $implode[] = $sub->name;
                    $implode[] = $sub->invoice_number;
                    $implode[] = date('Y-m-d', strtotime($sub->created_at));
                    $implode[] = $sub->gp_description;
                    $content .= implode(',', $implode) . PHP_RN;
                }

                Storage::disk('local')->put('voda/dispatch/' . $fname . '.csv', $content);
            }

            if (strtoupper($OrderData->product->network->name) == 'TELKOM')
            {
                //$content = "Order Date,Order Time,Invoice Date,Invoice Time,Customer PO Number,Part No,Part Description,Serial Number,Carton 1,Carton 2,Carton 3,Carton 4,Extra Number,Supplier Name,Bought,Waybill Number,Commodity Group,Date Received,Receiver Name,Signed By" . PHP_RN;
                $getData = DB::select("SELECT DATE(rd.created_at) as c_date,
                            TIME(rd.created_at) as c_time,
                            DATE(rd.updated_at) as u_date,
                            TIME(rd.updated_at) as u_time,
                            '' AS po,
                            '' AS part,
                            p.description,
                            s.serial_no,
                            IF(s.box_id IS NULL, g.pallet, b4.barcode) pallet,
                            IF(s.box_id IS NULL, g.carton, b3.barcode) carton,
                            IF(s.box_id IS NULL, g.box, b2.barcode) box,
                            IF(s.box_id IS NULL, g.brick, b.barcode) brick,
                            '' AS extra,
                            '' AS supplier_name,
                            w.description name,
                            r.external_reference invoice_number,
                            'SIM CARDS',
                            rd.created_at,
                            '' as reciver_name,
                            '' as singrd_by
                            FROM stock s
                            LEFT JOIN grv g ON s.serial_no = g.serial_no 
                            LEFT JOIN box b ON s.box_id = b.id
                            LEFT JOIN product p ON s.product_id = p.id
                            LEFT JOIN rep_transfer_detail rd ON rd.id = s.rep_transfer_detail_id
                            LEFT JOIN rep_transfer r ON r.id=rd.rep_transfer_id
                            LEFT JOIN warehouse w ON w.id =r.warehouse_id
                            LEFT JOIN box b2 ON b.parent_id = b2.id
                            LEFT JOIN box b3 ON b2.parent_id = b3.id
                            LEFT JOIN box b4 ON b3.parent_id = b4.id
                            WHERE s.rep_transfer_detail_id=$OrderData->id");
                $cnt = count($getData);

                $content = "Order Date,Order Time,Invoice Date,Invoice Time,Customer PO Number,Part No,Part Description,Serial Number,Carton 1,Carton 2,Carton 3,Extra Number,Supplier Name,Bought,Waybill Number,Commodity Group,Date Received,Receiver Name,Signed By" . PHP_RN;
                foreach ($getData as $sub)
                {
                    //$sub = (array) $sub;
                    $implode = array();
                    $implode[] = $sub->c_date;
                    $implode[] = $sub->c_time;
                    $implode[] = $sub->u_date;
                    $implode[] = "";
                    $implode[] = "";
                    $implode[] = "";
                    $implode[] = $sub->description;
                    $implode[] = $sub->serial_no;
                    $implode[] = $sub->box;
                    $implode[] = $sub->brick;
                    $implode[] = "";
                    $implode[] = "";
                    $implode[] = $sub->name;
                    $implode[] = 1;
                    $implode[] = $sub->invoice_number;
                    $implode[] = "SIM CARDS";
                    $implode[] = date('Y-m-d h:i:s', strtotime($sub->created_at));
                    $implode[] = "";
                    $implode[] = "";
                    $content .= implode(',', $implode) . PHP_RN;
                }
                Storage::disk('local')->put('tel/dispatch/' . $fname . '.csv', $content);
            }
        }

        /**
         * success response
         */
        if ($box_type == 'internal')
        {
            return response()->json([
                'status' => "200",
                'msg' => "Total $affected starter pack assign to warehouse",
                'count' => $affected,
                'qty_remain' => $qtyValidate
            ]);
        }
        else
        {
            return response()->json([
                'status' => "200",
                'msg' => "Total count of $cnt starter packs allocated to order",
                'count' => $cnt,
                'qty_remain' => $qtyValidate
            ]);
        }
    }

    public function allocate_stock(StoreOgrRequest $request)
    {
        $input = str_replace(' ', '', $request->input("input"));
        $customer_id = str_replace(' ', '', $request->input("customer_id"));
        $qty = str_replace(' ', '', $request->input("qty"));
        $box_type = str_replace(' ', '', $request->input("box_type"));
        $so = $request->input('sales_order_id');
        $pid = $request->input('p_id');
        $wid = SalesOrderDetails::find($so)->order->warehouse_id;
        $boxdata = Box::where('barcode', $input)->first();

        if ($box_type == 'internal')
        {
            if (empty($boxdata->id))
            {
                $data = array("sales_order_detail_id" => $so, "barcode" => $input, "order_qty" => $qty, "box_type" => $box_type, "customer_id" => $customer_id, "Process" => "Allocate stock");
                $description = "Box not found or you select wrong box type";
                $this->setActivityLog('', $boxdata, $data, $description);
                return response()->json([
                    'status' => "400",
                    'msg' => "Box not found or you select wrong box type",
                    'count' => 0
                ]);
            }

            if ($boxdata->parent_id != 0)
            {
                $data = array("sales_order_detail_id" => $so, "barcode" => $input, "order_qty" => $qty, "box_type" => $box_type, "customer_id" => $customer_id, "Process" => "Allocate stock");
                $description = "Box belong to a bigger box can't be allocated as single box";
                $this->setActivityLog('', $boxdata, $data, $description);
                return response()->json([
                    'status' => "400",
                    'msg' => $description,
                    'count' => 0
                ]);
            }
            $getChild = $this->getChildBox($boxdata->id);
            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $box = $boxdata->id;
                $cntQty = DB::table('stock')->where("box_id", $box)->whereWarehouseId($wid)->count();
            }
            else
            {
                $cntQty = DB::table('stock')->whereIn("box_id", $getChild)->whereWarehouseId($wid)->count();
            }
            $cntAllocateQty = DB::table('stock')->where("sales_order_detail_id", $so)->whereWarehouseId($wid)->where("customer_id", $customer_id)->count();

            $qtyValidate = $qty - $cntAllocateQty;
            if ((int) $cntQty > (int) $qtyValidate)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Allocated quantity is more than order quantity",
                    'count' => 0
                ]);
            }
            if ($cntQty <= 0)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Stock not available for this input",
                    'count' => 0
                ]);
            }
            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $checkBx = Stock::where('box_id', $box)
                ->whereNull("sales_order_detail_id")->count();
                if ($checkBx <= 0)
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "Box already allocated",
                        'count' => 0
                    ]);
                }
                $affected = Stock::where('box_id', $box)->where("product_id", $pid)->whereWarehouseId($wid)
                    ->update(['sales_order_detail_id' => $so, "customer_id" => $customer_id]);

                if (empty($affected))
            {
                    $data = array("sales_order_detail_id" => $so, "barcode" => $input, "order_qty" => $qty, "allocate_qty" => 0, "box_type" => $box_type, "customer_id" => $customer_id, "Process" => "Allocate stock");
                    $description = "Scanned box does not contain the correct product or warehouse for the order";
                    $this->setActivityLog('', $boxdata, $data, $description);
                    //scanned box does not contain the correct product for the order
                    return response()->json([
                        'status' => "400",
                        'msg' => "Scanned box does not contain the correct product or warehouse for the order",
                        'count' => 0
                    ]);
                }
                $data = array("data" => $request, "sales_order_detail_id" => $so, "barcode" => $input, "order_qty" => $qty, "allocate_qty" => $affected, "box_type" => $box_type, "customer_id" => $customer_id, "Process" => "Allocate stock");
                $description = "Allocation done";
                $this->setActivityLog('', $checkBx, $data, $description);
            }
            else
            {
                $affected = 0;
                foreach ($getChild as $bx)
                {
                    $checkBx = Stock::where('box_id', $bx)
                   ->whereNull("sales_order_detail_id")->count();
                 
                    if ($checkBx > 0)
                     { 
                        $cnt = Stock::where('box_id', $bx)->where("product_id", $pid)->whereWarehouseId($wid)
                            ->update(['sales_order_detail_id' => $so, "customer_id" => $customer_id]);
                        $affected = $affected + $cnt;
                     } 
                    }

                if ($affected <= 0)
                {
                    $data = array("data" => $request, "sales_order_detail_id" => $so, "barcode" => $input, "order_qty" => $qty, "box_type" => $box_type, "customer_id" => $customer_id, "Process" => "Allocate stock");
                    $description = "Box already allocated";
                    $this->setActivityLog('', $boxdata, $data, $description);
                    return response()->json([
                        'status' => "400",
                        'msg' => "Box already allocated",
                        'count' => 0
                    ]);
                }
                $data = array("data" => $request, "sales_order_detail_id" => $so, "barcode" => $input, "order_qty" => $qty, "allocate_qty" => $affected, "box_type" => $box_type, "customer_id" => $customer_id, "Process" => "Allocate stock");
                $description = "Allocation done";
                $this->setActivityLog('', $boxdata, $data, $description);
            }

            $cntAllocateQty = DB::table('stock')->where("sales_order_detail_id", $so)->whereWarehouseId($wid)->where("customer_id", $customer_id)->count();
            if ((int) $qty == ((int) $cntAllocateQty))
            {
                $s = Status::where("process", "sales_order")->where("status", "allocated")->first();
                SalesOrderDetails::where('id', $so)
                    ->update(['is_allocate' => 1]);

                $data = array("sales_order_detail_id" => $so, "barcode" => $input, "order_qty" => $qty, "allocate_qty" => $cntAllocateQty, "box_type" => $box_type, "customer_id" => $customer_id, "Process" => "Allocate stock");
                $description = "Order fully allocated, so now is_allocate is 1";
                $this->setActivityLog('', $boxdata, $data, $description);
            }

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $so;
            $sl['qty'] = $affected;
            $s1['status_id'] = !empty($s->id) ? $s->id : '';
            $sl['order_name'] = "SALES";
            $sl['barcode'] = $input;
            $sl['process_name'] = "allocate_order";

            StockLedger::create($sl);
            return response()->json([
                'status' => "200",
                'msg' => "Total $affected starter pack assign to customer",
                'count' => $affected,
                'qty_remain' => $qtyValidate
            ]);
        }
        if ($box_type == 'external')
        {
            $cntQty = DB::table('grv')->where("is_available", 0)->where(function ($query) use ($input)
            {
                $query->where("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input);
            })->count();

            if ($cntQty > 0)
            {
                $data = array("sales_order_detail_id" => $so, "barcode" => $input, "order_qty" => $qty, "box_type" => $box_type, "customer_id" => $customer_id, "Process" => "Allocate stock");
                $description = "This box starter pack has been used for internal box OR allocated";
                $this->setActivityLog('', $boxdata, $data, $description);

                return response()->json([
                    'status' => "400",
                    'msg' => "This box starter pack has been used for internal box OR allocated",
                    'count' => 0
                ]);
            }

            $cntQty = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->count();

            $cntAllocateQty = DB::table('stock')->where("sales_order_detail_id", $so)->whereWarehouseId($wid)->where("customer_id", $customer_id)->count();

            $qtyValidate = $qty - $cntAllocateQty;

            if ((int) $cntQty > (int) $qtyValidate)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Allocated quantity is more than order quantity",
                    'count' => 0
                ]);
            }

            if ($cntQty <= 0)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Stock not available for this input",
                    'count' => 0
                ]);
            }

            /*
            check if box already allocated 
            */
            $checkBox = DB::select("Select count(t1.serial_no) tot from stock t1 left join grv t2 on t2.serial_no=t1.serial_no
             where (t2.pallet in ('$input') OR t2.carton in ('$input') OR  t2.box in ('$input') OR t2.brick in ('$input'))
             and t1.sales_order_detail_id is null");
            
           if( $checkBox[0]->tot ==0 )
           {
            return response()->json([
                'status' => "400",
                 'msg' => "Box already allocated",
                 'count' => 0
            ]);
           }
             

            $allSerial = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->get();
            $cnt = 0;

            foreach ($allSerial as $sr)
            {
                if (empty($sr->purchase_order_id))
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "Purchase Order not found for this stock",
                        'count' => 0
                    ]);
                }
                if ($cnt == 0)
                {
                    $chk = PurchaseOrder::with("product")->where("id", $sr->purchase_order_id)->get()->first();
                    $p = Product::where("id", $pid)->get()->first();
                    if (empty($chk->product_id))
                    {
                        return response()->json([
                            'status' => "400",
                            'msg' => "Product not found",
                            'count' => 0
                        ]);
                    }
                    if (empty($p->manufacture_id))
                    {
                        if ($chk->product_id != $pid)
                        {
                            Box::where("barcode", $input)->delete();
                            return response()->json([
                                'status' => "400",
                                'msg' => "The boxed product does not match the product specified on the order",
                                'count' => 0
                            ]);
                        }
                    }
                }

                DB::update("UPDATE grv SET is_available = 0 where serial_no = '$sr->serial_no'");
                $aff = Stock::where('serial_no', $sr->serial_no)->where("product_id", $pid)->whereWarehouseId($wid)
                    ->update(['sales_order_detail_id' => $so, "customer_id" => $customer_id]);
                $cnt = $cnt + $aff;
            }
            $data = array("data" => $request, "sales_order_detail_id" => $so, "barcode" => $input, "order_qty" => $qty, "allocate_qty" => $cnt, "box_type" => $box_type, "customer_id" => $customer_id, "Process" => "Allocate stock");
            $description = "Allocation done";
            $this->setActivityLog('', $boxdata, $data, $description);

            $cntAllocateQty = DB::table('stock')->where("sales_order_detail_id", $so)->whereWarehouseId($wid)->where("customer_id", $customer_id)->count();

            if ((int) $qty <= ((int) $cntAllocateQty))
            {
                $s = Status::where("process", "sales_order")->where("status", "allocated")->first();
                SalesOrderDetails::where('id', $so)
                    ->update(['is_allocate' => 1]);
            }

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $so;
            $sl['qty'] = $cnt;
            $s1['status_id'] = !empty($s->id) ? $s->id : '';
            $sl['order_name'] = "SALES";
            $sl['barcode'] = $input;
            $sl['process_name'] = "allocate_order";

            StockLedger::create($sl);

            return response()->json([
                'status' => "200",
                'msg' => "Total count of $cnt starter packs allocated to order",
                'count' => $cnt,
                'qty_remain' => $qtyValidate
            ]);
        }
    }

    public function scan_stock_rep(StoreOgrRequest $request)
    {
        $input = str_replace(' ', '', $request->input("input"));
        $qty = str_replace(' ', '', $request->input("qty"));
        $box_type = str_replace(' ', '', $request->input("box_type"));
        $po = $request->input('rep_transfer_id');
        $pid = $request->input('p_id');

        $boxdata = Box::where('barcode', $input)->first();

        if ($box_type == 'internal')
        {
            $OrderData = RepTransferDetails::with('reptransfer')->where("id", $po)->first();
            $getChild = $this->getChildBox($boxdata->id);
            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $box = $boxdata->id;
                $cntQty = DB::table('stock')->where("box_id", $box)->count();
                $affected = Stock::where('box_id', $box)->where("rep_transfer_detail_id", $po)
                    ->update(["warehouse_id" => $OrderData->reptransfer->warehouse_id]);
            }
            else
            {
                $cntQty = DB::table('stock')->whereIn("box_id", $getChild)->count();
                $affected = Stock::whereIn('box_id', $getChild)->where("rep_transfer_detail_id", $po)
                    ->update(["warehouse_id" => $OrderData->reptransfer->warehouse_id]);
            }

            if ($affected <= 0)
            {
                return response()->json([
                    'status' => "200",
                    'msg' => "Box is mismatch with rep transfer request",
                    'count' => 0
                ]);
            }

            $cntQty = Stock::where("rep_transfer_detail_id", $po)->where("warehouse_id", $OrderData->reptransfer->warehouse_id)->count();

            if ((int) $OrderData->qty == $cntQty)
            {
                RepTransferDetails::where('id', $po)
                    ->update(['is_verify' => 1]);
            }

            $qtyValidate = $qty - $OrderData->scanned_qty;

            try
            {
                $this->nav_patch_transfer($OrderData->reptransfer->external_reference, "10000", [
                    "Qty_to_Ship" => (string) $affected
                ]);
            }
            catch (Exception $e)
            {
            }
            return response()->json([
                'status' => "200",
                'msg' => "Total count of $affected starter packs allocated to order",
                'count' => $affected,
                'qty_remain' => $qtyValidate
            ]);
        }
        if ($box_type == 'external')
        {
            $cntQty = DB::table('grv')->where(function ($query) use ($input)
            {
                $query->where("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input);
            })->count();

            $OrderData = RepTransferDetails::with('reptransfer')->where("id", $po)->first();
            $cntStock = Stock::where("rep_transfer_detail_id", $po)->where("warehouse_id", $OrderData->reptransfer->warehouse_id)->count();


            $qtyValidate = $qty - $cntStock;

            if ((int) $cntQty > (int) $qtyValidate)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Allocated quantity is more than order quantity",
                    'count' => 0
                ]);
            }
            if ($cntQty <= 0)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Stock is not available for this ",
                    'count' => 0
                ]);
            }

            $allSerial = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->get();

            $cnt = 0;
            foreach ($allSerial as $sr)
            {
                $affected = DB::update("UPDATE stock SET warehouse_id = " . $OrderData->reptransfer->warehouse_id . " where rep_transfer_detail_id = $po and serial_no = '$sr->serial_no'");
                if ($affected > 0)
                {
                    $cnt++;
                }
            }
            if (empty($cnt))
            {
                return response()->json([
                    'status' => "201",
                    'msg' => "The boxed product does not match the product specified on the order",
                    'count' => 0
                ]);
            }
            $cntQty = Stock::where("rep_transfer_detail_id", $po)->where("warehouse_id", $OrderData->reptransfer->warehouse_id)->count();

            if ((int) $OrderData->qty == ((int) $cntQty))
            {
                RepTransferDetails::where('id', $po)
                    ->update(['is_verify' => 1]);
            }

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $po;
            $sl['qty'] = $cnt;
            $sl['order_name'] = "REP";
            $sl['process_name'] = "verify_order";

            StockLedger::create($sl);
            try
            {
                $this->nav_patch_transfer($OrderData->reptransfer->external_reference, "10000", [
                    "Qty_to_Ship" => (string) $cnt
                ]);
            }
            catch (Exception $e)
            {
            }
            return response()->json([
                'status' => "200",
                'msg' => "Total count of $cnt starter packs allocated to order",
                'count' => $cnt,
                'qty_remain' => $qtyValidate
            ]);
        }
    }

    public function scan_stock(StoreOgrRequest $request)
    {
        $input = str_replace(' ', '', $request->input("input"));
        $scan_opt = str_replace(' ', '', $request->input("scan_option"));
        $po = $request->input('purchase_order_id');

        $checkPo = DB::table('grv')->where("purchase_order_id", $po)->count();

        $po = PurchaseOrder::with('product')->where('id', $po)->first();
        if (empty($checkPo))
        {
            return response()->json([
                'status' => "200",
                'msg' => "Purchase Order stock file not found in grv. Please import file first",
                'count' => 0
            ]);
        }

        $cntQty = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->first();
        if (empty($cntQty))
        {
            return response()->json([
                'status' => "400",
                'msg' => "Box not found",
                'count' => 0
            ]);
        }
        else
        {
            $chkDup = Stock::where("serial_no", $cntQty->serial_no)->first();
            if (!empty($chkDup))
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Box already scanned",
                    'count' => 0
                ]);
            }
        }

        $affected = DB::update(
            "INSERT INTO stock (
                serial_no
                , alt_serial_no
                , msisdn
                , imsi_no
                , network_id
                , product_id
                , box_id
                , customer_id
                , sales_order_detail_id
                , warehouse_id
                , created_at
                , updated_at
            )(
            SELECT
                serial_no
                , alt_serial_no
                , NULL
                , imsi_no
                , " . $po->product->network->id . "
                , " . $po->product->id . "
                , NULL
                , NULL
                , NULL
                , " . $po->warehouse_id . "
                , NOW()
                , NOW()
            FROM
                grv
            WHERE purchase_order_id = " . $po->id . "
            AND (
                pallet = '" . $input . "'
                OR carton = '" . $input . "'
                OR box = '" . $input . "'
                OR brick = '" . $input . "'
                )
            )"
        );

        if ($affected > 0)
        {
            PurchaseOrder::where('id', $request->input('purchase_order_id'))
                ->update(['scanned_qty' => DB::raw('scanned_qty + ' . $affected)]);

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $request->input('purchase_order_id');
            $sl['qty'] = $affected;
            $sl['order_name'] = "PURCHASE";
            $sl['process_name'] = "verify_order";

            StockLedger::create($sl);

            try
            {
                $this->nav_patch_order("Purchase_OrderPurchLines", $po->external_reference, "10000", [
                    "Qty_to_Receive" => (string) $affected
                ]);
            }
            catch (Exception $e)
            {
            }

            return response()->json([
                'status' => "200",
                'msg' => "Total count of $affected starter packs received",
                'count' => $affected
            ]);
        }
        else
        {
            return response()->json([
                'status' => "200",
                'msg' => "This stock has already been received",
                'count' => $affected
            ]);
        }

        return response()->json([
            'status' => "200",
            'msg' => "Total count of $affected starter packs received",
            'count' => $affected
        ]);
    }

    public function return_show($id)
    {
        $status = $this->check_order_return($id);
        if ($status->isMine)
        {
            $order = Returnstockmaster::with('status', 'user')->find($id);
            $arr = array();
            if ($order->box_type == 'single')
            {
                foreach (explode(',', $order->box_ids) as $id)
                {
                    $arr[$id] = $id;
                }
            }

            if ($order->box_type == 'external')
            {
                foreach (explode(',', $order->box_ids) as $id)
                {
                    $stockArray = DB::table('grv')->orWhere("pallet", $id)->orWhere("carton", $id)->orWhere("box", $id)->orWhere("brick", $id)
                        ->leftjoin('stock', 'grv.serial_no', '=', 'stock.serial_no')
                        ->select('stock.*')
                        ->first();
                    $arr[$id] = $stockArray->serial_no;
                }
            }

            if ($order->box_type == 'internal')
            {

                foreach (explode(',', $order->box_ids) as $id)
                {
                    $box = Box::where("barcode", $id)->get()->first();
                    $getChild = $this->getChildBox($box->id);
                    $cntQty = 0;

                    if (count($getChild) == 1 && $getChild[0] == $box->id)
                    {
                        $box = Box::where("barcode", $id)->get()->first()->id;
                        $cntQty = Stock::where("box_id", $box)->count();
                    }
                    else
                    {

                        $cntQty = Stock::whereIn("box_id", $getChild)->count();
                        $box = $getChild[0];
                    }

                    $stock = Stock::where("box_id", $box)->get()->first();
                    $arr[$id . '-' . $cntQty] = $stock->serial_no;
                }
            }
            $data = array();
            foreach ($arr as $k => $v)
            {
                if ($order->box_type == 'single')
                {
                    $stock = Stock::with("network", "product", "customer", "warehouse")->where("serial_no", $v)->first();
                    $stock->box_number = $k;
                    $stock->qty = 1;
                    $data[] = $stock;
                }
                if ($order->box_type == 'external')
                {
                    $stock = Stock::with("network", "product", "customer", "warehouse")->where("serial_no", $v)->first();
                    $stock->box_number = $k;
                    $stock->qty = DB::table('grv')->orWhere("pallet", $k)->orWhere("carton", $k)->orWhere("box", $k)->orWhere("brick", $k)->count();
                    $data[] = $stock;
                }
                if ($order->box_type == 'internal')
                {
                    $stock = Stock::with("network", "product", "customer", "warehouse")->where("serial_no", $v)->first();
                    $k = explode('-', $k);
                    $stock->box_number = $k[0];

                    $stock->qty = $k[1];
                    $data[] = $stock;
                }
            }

            $od_status = Status::where('process', 'return_stock')->get();
            return view('admin.warehouse.return_stock_show', compact('order', 'data', 'status', 'od_status'));
        }
        else
        {
            abort(401);
        }
    }

    public function return_view()
    {
        $customers = Customer::whereIsActive(1)->get();
        return view('warehouse.stock.return', compact('customers'));
    }

    public function check_scan($id, $valrad)
    {
        if ($valrad == "single")
        {
            $stock = Stock::where("serial_no", $id)->first();
            if (!empty($stock->sales_order_detail_id))
            {
                if ($stock->sales_order_detail_id == null || $stock->sales_order_detail_id == 0)
                {
                    $msg = 'Stock cannot be returned as the stock has not been sold';
                    $code = 400;
                }
            }
            else
            {
                return response()->json([
                    "message" => "Starter Pack not found",
                    "code" => 400
                ]);
            }
        }
        else if ($valrad == "internal")
        {
            $box = Box::where("barcode", $id)->get()->first();

            if (empty($box->id))
            {
                $msg = 'Internal Box Number not found';
                $code = 201;
                return response()->json([
                    "message" => $msg,
                    "code" => $code
                ]);
            }
            $query = DB::table('return_stock_master')
                ->whereRaw('FIND_IN_SET("' . $id . '",box_ids)')
                ->first();
            if (!empty($query->id))
            {
                return response()->json([
                    "message" => "Box already returned",
                    "code" => 201
                ]);
            }
        }
        else if ($valrad == "external")
        {
            $box = DB::table('grv')->orWhere("pallet", $id)->orWhere("carton", $id)->orWhere("box", $id)->orWhere("brick", $id)->get()->first();
            if (empty($box->id))
            {
                $msg = 'External Box Number not found';
                $code = 201;
                return response()->json([
                    "message" => $msg,
                    "code" => $code
                ]);
            }
            $query = DB::table('return_stock_master')
                ->whereRaw('FIND_IN_SET("' . $id . '",box_ids)')
                ->first();
            if (!empty($query->id))
            {
                return response()->json([
                    "message" => "Box already returned",
                    "code" => 201
                ]);
            }
        }
        return response()->json([
            "message" => "",
            "code" => 200
        ]);
    }

    public function approve($id)
    {
        /** @var Admin/audits $admin/audits */
        $res = $this->approveOrder_return($id);

        $return_id = $id;
        if (!empty($res))
        {
            if ($res == 'done')
            {
                $order = Returnstockmaster::where("id", $id)->first();

                try
                {
                    $data = $this->nav_post("Sales_Cr_Memo", [
                        "Sell_to_Customer_No" => $order->customer->cust_code
                    ]);
                }
                catch (Exception $ex)
                {
                }
                $p = array();
                $c = array();
                if ($order->box_type == 'external')
                {

                    foreach (explode(',', $order->box_ids) as $id)
                    {

                        $stock = DB::select("select count(s.serial_no) as cnt,product_id from grv g join stock s on g.serial_no = s.serial_no where (carton = '$id' OR pallet = '$id' OR box = '$id' OR brick = '$id') group by product_id");
                        $stock = $stock[0];
                        if (in_array($stock->product_id, $p))
                        {
                            $c[$stock->product_id] = $c[$stock->product_id] + $stock->cnt;
                        }
                        else
                        {
                            $p[] = $stock->product_id;
                            $c[$stock->product_id] = $stock->cnt;
                        }
                        if (!empty($c))
                        {
                            foreach ($c as $k => $v)
                            {
                                $product = Product::where("id", $k)->first();
                                try
                                {
                                    $this->nav_post("Sales_Cr_Memo(Document_Type='Credit Memo',No='" . $data[0]->No . "')/Sales_Cr_MemoSalesLines", [
                                        "Document_No" => $data[0]->No,
                                        "No" => $product->product_code,
                                        "Quantity" => $v
                                    ]);
                                }
                                catch (Exception $ex)
                                {
                                }
                            }
                        }
                        $stockArray = DB::table('grv')->orWhere("pallet", $id)->orWhere("carton", $id)->orWhere("box", $id)->orWhere("brick", $id)
                            ->leftjoin('stock', 'grv.serial_no', '=', 'stock.serial_no')
                            ->select('stock.*')
                            ->get();
                        $sid = '';
                        $cnt_serial = 0;
                        foreach ($stockArray as $obj)
                        {
                            $sid = $obj->sales_order_detail_id;
                            ReturnStock::create([
                                'sales_order_detail_id' => $obj->sales_order_detail_id,
                                'return_stock_master_id' => $return_id,
                                'serial_no' => $obj->serial_no,
                                'return_type' => 0,
                                'user_id' => Auth::user()->id
                            ]);
                            DB::update("UPDATE grv SET is_available = 1 where serial_no = '$obj->serial_no'");
                            Stock::where('serial_no', $obj->serial_no)
                                ->update(['sales_order_detail_id' => NULL, "customer_id" => NULL, "warehouse_id" => 1]);
                            $cnt_serial++;
                        }

                        $sl = array();
                        $sl['user_id'] = Auth::user()->id;
                        $sl['order_id'] = $sid;
                        $sl['qty'] = $cnt_serial;
                        $sl['status_id'] = $order->status_id;
                        $sl['order_name'] = "SALES";
                        $sl['process_name'] = "return_stock";
                        StockLedger::create($sl);
                    }
                }
                if ($order->box_type == 'single')
                {
                    foreach (explode(',', $order->box_ids) as $id)
                    {

                        $stockarray = Stock::where("serial_no", $id)->first();
                        $stock = DB::select("select count(s.serial_no) as cnt,product_id from stock s where serial_no = $id group by product_id");
                        $stock = $stock[0];


                        if (in_array($stock->product_id, $p))
                        {
                            $c[$stock->product_id] = $c[$stock->product_id] + $stock->cnt;
                        }
                        else
                        {
                            $p[] = $stock->product_id;
                            $c[$stock->product_id] = $stock->cnt;
                        }

                        foreach ($c as $k => $v)
                        {
                            $product = Product::where("id", $k)->first();
                            try
                            {
                                $this->nav_post("Sales_Cr_Memo(Document_Type='Credit Memo',No='" . $data[0]->No . "')/Sales_Cr_MemoSalesLines", [
                                    "Document_No" => $data[0]->No,
                                    "No" => $product->product_code,
                                    "Quantity" => $v
                                ]);
                            }
                            catch (Exception $ex)
                            {
                            }
                        }


                        $sid = $stockarray->sales_order_detail_id;
                        ReturnStock::create([
                            'sales_order_detail_id' => $stockarray->sales_order_detail_id,
                            'return_stock_master_id' => $order->id,
                            'serial_no' => $stockarray->serial_no,
                            'return_type' => 0,
                            'user_id' => Auth::user()->id
                        ]);

                        DB::update("UPDATE grv SET is_available = 1 where serial_no = '$stockarray->serial_no'");
                        Stock::where('serial_no', $stockarray->serial_no)
                            ->update(['sales_order_detail_id' => NULL, "customer_id" => NULL, "warehouse_id" => 1]);



                        $sl = array();
                        $sl['user_id'] = Auth::user()->id;
                        $sl['order_id'] = $sid;
                        $sl['qty'] = 1;
                        $sl['status_id'] = $order->status_id;
                        $sl['order_name'] = "SALES";
                        $sl['process_name'] = "return_stock";
                        StockLedger::create($sl);
                    }
                }
                if ($order->box_type == 'internal')
                {
                    foreach (explode(',', $order->box_ids) as $id)
                    {
                        $box = Box::where("barcode", $id)->get()->first();

                        $getChild = $this->getChildBox($box->id);

                        $cntQty = 0;
                        if (count($getChild) == 1 && $getChild[0] == $box->id)
                        {
                            $stockarray = Stock::where("box_id", $box->id)->get();
                            $stock = DB::select("select count(s.serial_no) as cnt,product_id from stock s where box_id = $box->id group by product_id");
                            $stock = $stock[0];
                        }
                        else
                        {
                            $stockarray = Stock::whereIn("box_id", $getChild)->get();
                            $stock = DB::select("select count(s.serial_no) as cnt,product_id from stock s where box_id in($getChild) group by product_id");
                            $stock = $stock[0];
                        }

                        if (in_array($stock->product_id, $p))
                        {
                            $c[$stock->product_id] = $c[$stock->product_id] + $stock->cnt;
                        }
                        else
                        {
                            $p[] = $stock->product_id;
                            $c[$stock->product_id] = $stock->cnt;
                        }

                        foreach ($c as $k => $v)
                        {
                            $product = Product::where("id", $k)->first();
                            try
                            {
                                $this->nav_post("Sales_Cr_Memo(Document_Type='Credit Memo',No='" . $data[0]->No . "')/Sales_Cr_MemoSalesLines", [
                                    "Document_No" => $data[0]->No,
                                    "No" => $product->product_code,
                                    "Quantity" => $v
                                ]);
                            }
                            catch (Exception $ex)
                            {
                            }
                        }

                        $sid = '';
                        $cnt = 0;
                        foreach ($stockarray as $v)
                        {
                            $sid = $v->sales_order_detail_id;
                            ReturnStock::create([
                                'sales_order_detail_id' => $v->sales_order_detail_id,
                                'return_stock_master_id' => $order->id,
                                'serial_no' => $v->serial_no,
                                'return_type' => 0,
                                'user_id' => Auth::user()->id
                            ]);

                            DB::update("UPDATE grv SET is_available = 1 where serial_no = '$v->serial_no'");
                            Stock::where('serial_no', $v->serial_no)
                                ->update(['sales_order_detail_id' => NULL, "customer_id" => NULL, "warehouse_id" => 1]);
                            $cnt++;
                        }

                        $sl = array();
                        $sl['user_id'] = Auth::user()->id;
                        $sl['order_id'] = $sid;
                        $sl['qty'] = !empty($cnt) ? $cnt : '';
                        $sl['status_id'] = $order->status_id;
                        $sl['order_name'] = "SALES";
                        $sl['process_name'] = "return_stock";
                        StockLedger::create($sl);
                    }
                }
            }
            $order = Returnstockmaster::find($return_id)->load("user");

            $u = User::find($order->user_id);
            $u->notify(new ReturnStockApproved($order));
            Alert::success('Success', 'The return stock has been approved.');
        }
        else
        {
            Alert::error('Error', 'There is an issue approving your order. Please contact administrator.');
        }
        return back();
    }

    public function return_stock_index()
    {
        return view('admin.warehouse.return_index');
    }

    public function return_stock_approve_index()
    {
        return view('admin.warehouse.return_index_approve');
    }

    public function listdata(Request $request)
    {
        $order = $this->getMyOrder_return()["orders"]->with('customer', 'status', 'user')->get();

        return datatables()->of($order)
            ->make();
    }

    public function listdata_approve(Request $request)
    {
        if (Auth::user()->user_type_id == 1)
        {
            $order = Returnstockmaster::with('customer', 'user', 'status')->get();
        }
        else
        {
            $order = Returnstockmaster::with('customer', 'user', 'status')->whereUserId(Auth::user()->id)->get();
        }
        return datatables()->of($order)
            ->make();
    }

    public function return_request(Request $request)
    {
        $box_ids = $request->input('box_ids');
        if (!empty($box_ids))
        {
            $exist = array();
            $new = array();
            $cust = array();
            $boxes = array();
            $box_comma = "";
            foreach (explode(',', $box_ids) as $val)
            {
                $query = DB::table('return_stock_master')
                    ->whereRaw('FIND_IN_SET("' . $val . '",box_ids)')
                    ->first();
                if (!empty($query->id))
                {
                    $exist[] = $val;
                }
                else
                {
                    $new[] = $val;
                    if ($request->input('box_type') == 'single')
                    {
                        $stock = Stock::where("serial_no", $val)->first();
                    }
                    if ($request->input('box_type') == 'internal')
                    {
                        $box = Box::where("barcode", $val)->first();
                        $getChild = $this->getChildBox($box->id);
                        $stock = Stock::whereIn("box_id", $getChild)->first();
                    }
                    if ($request->input('box_type') == 'external')
                    {
                        $stock = DB::table('grv')->orWhere("pallet", $val)->orWhere("carton", $val)->orWhere("box", $val)->orWhere("brick", $val)
                            ->leftjoin('stock', 'grv.serial_no', '=', 'stock.serial_no')
                            ->select('stock.*')
                            ->first();
                    }

                    if (!empty($stock->customer_id))
                    {
                        if (in_array($stock->customer_id, $cust))
                        {
                            $box_comma = $box_comma . ',' . $val;

                            $boxes[$stock->customer_id] = $box_comma;
                        }
                        else
                        {
                            $cust[] = $stock->customer_id;
                            $boxes[$stock->customer_id] = $val;
                            $box_comma = $val;
                        }
                    }
                }
            }
        }

        if (empty($new[0]))
        {
            return response()->json([
                "message" => "Boxes already returned",
                "code" => 400
            ]);
        }

        if (empty($boxes))
        {
            return response()->json([
                "message" => "Boxes should not be returned OR ordered",
                "code" => 400
            ]);
        }

        foreach ($boxes as $k => $v)
        {
            $arr = array();
            $arr['user_id'] = Auth::user()->id;
            $arr['box_ids'] = $v;
            $arr['box_type'] = $request->input('box_type');
            $arr['customer_id'] = $k;

            $order = Returnstockmaster::create($arr);

            $sos = Config::where("key", "return_stock_status")->first();
            $order->status_id = $sos->value;
            $order->save();
            $this->generatePDFReturn($order);
            $this->check_approval_return($order);
        }
        return response()->json([
            "message" => "Return stock request has been generated",
            "code" => 200,
            "exist" => implode(',', $exist)
        ]);
    }

    public function reject_return($id)
    {
        $order = Returnstockmaster::with("status")->where("id", $id)->get()->first();
        $soaa = Config::where("key", "return_stock_apply_approval")->first();
        if ($order->status->id != $soaa->value)
        {
            Alert::error('Error!', 'You cannot reject an approved order');
        }
        else
        {
            $status = Status::where('process', 'return_stock')->where('status', 'rejected')->first();
            Returnstockmaster::where('id', $id)
                ->update(['status_id' => $status->id]);
            if (!empty($order->user_id))
            {
                $u = User::find($order->user_id);
                $u->notify(new ReturnStockRejected($order));
            }
            $order = Returnstockmaster::find($id);
            $this->generatePDFReturn($order);
            Alert::success('Success', 'Return stock approval has been rejected.');
        }
        return back();
    }

    public function do_return($id, $valrad)
    {
        if ($valrad == "single")
        {
            $msg = '';
            $code = '';
            $stock = Stock::where("serial_no", $id)->first();

            if (!empty($stock->sales_order_detail_id))
            {
                $isavail = SalesOrderDetails::where("id", $stock->sales_order_detail_id)->first();
                if (!empty($isavail->id))
                {
                    $order = SalesOrder::where("id", $stock->sales_order_detail_id)->first();

                    $sl = array();
                    $sl['user_id'] = Auth::user()->id;
                    $sl['order_id'] = $stock->sales_order_detail_id;
                    $sl['qty'] = 1;
                    $sl['status_id'] = $order->status_id;
                    $sl['order_name'] = "SALES";
                    $sl['process_name'] = "return_stock";
                    StockLedger::create($sl);
                    DB::update("UPDATE grv SET is_available = 1 where serial_no = '$stock->serial_no'");
                    $return = ReturnStock::create([
                        'sales_order_detail_id' => $stock->sales_order_detail_id,
                        'box_id' => NULL,
                        'serial_no' => $stock->serial_no,
                        'return_type' => 0,
                        'user_id' => Auth::user()->id
                    ]);

                    $stock->sales_order_detail_id = null;
                    $stock->customer_id = null;
                    $stock->warehouse_id = 1;
                    $stock->save();

                    $msg = 'Stock has been returned successfully';
                    $code = 200;
                }
                else
                {
                    if ($stock->sales_order_detail_id == null || $stock->sales_order_detail_id == 0)
                    {
                        $msg = 'Stock cannot be returned as the stock has not been sold';
                        $code = 201;
                    }
                    else
                    {
                        $msg = 'Starter pack not found in stock';
                        $code = 201;
                    }
                }
                return response()->json([
                    "message" => $msg,
                    "code" => $code
                ]);
            }
            return response()->json([
                "message" => "Stock cannot be returned as the stock has not been sold",
                "code" => 201
            ]);
        }
        else if ($valrad == "internal")
        {
            $msg = '';
            $code = '';
            $user = auth()->user();

            return response()->json([
                "message" => $msg,
                "code" => $code
            ]);
        }
        else if ($valrad == "external")
        {
            $msg = '';
            $code = '';
            $user = auth()->user();

            $box = DB::table('grv')->orWhere("pallet", $id)->orWhere("carton", $id)->orWhere("box", $id)->orWhere("brick", $id)->get()->first();
            if (empty($box->id))
            {
                $msg = 'External Box Number not found';
                $code = 201;
                return response()->json([
                    "message" => $msg,
                    "code" => $code
                ]);
            }

            $stockItem = DB::table('grv')->orWhere("pallet", $id)->orWhere("carton", $id)->orWhere("box", $id)->orWhere("brick", $id)
                ->leftjoin('stock', 'grv.serial_no', '=', 'stock.serial_no')
                ->select('stock.*')
                ->get()
                ->first();

            if (!empty($stockItem->sales_order_detail_id))
            {
                $order = SalesOrder::where("id", $stockItem->sales_order_detail_id)->get()->first();
                $orderdetail = SalesOrderDetails::where("id", $order->id)->get()->first();
                $stockArray = DB::table('grv')->orWhere("pallet", $id)->orWhere("carton", $id)->orWhere("box", $id)->orWhere("brick", $id)
                    ->leftjoin('stock', 'grv.serial_no', '=', 'stock.serial_no')
                    ->select('stock.*')
                    ->get();

                foreach ($stockArray as $obj)
                {
                    ReturnStock::create([
                        'sales_order_detail_id' => $obj->sales_order_detail_id,
                        'serial_no' => $obj->serial_no,
                        'return_type' => 0,
                        'user_id' => Auth::user()->id
                    ]);
                }

                $serialNoArray = NULL;
                foreach ($stockArray as $obj)
                {
                    $serialNoArray[] = $obj->serial_no;
                }

                $serialNoList = implode('\',\'', $serialNoArray);
                Stock::whereIn('serial_no', explode(',', $serialNoList))
                    ->update(['sales_order_detail_id' => NULL, "customer_id" => NULL, "warehouse_id" => 1]);

                $sl = array();
                $sl['user_id'] = Auth::user()->id;
                $sl['order_id'] = $stockItem->sales_order_detail_id;
                $sl['qty'] = count($stockArray, 0);
                $sl['status_id'] = $order->status_id;
                $sl['order_name'] = "SALES";
                $sl['process_name'] = "return_stock";
                StockLedger::create($sl);

                $msg = 'Stock has been returned successfully';
                $code = 200;
            }
            else
            {
                if (empty($stockItem->sales_order_detail_id))
                {
                    $msg = 'Stock cannot be returned as the stock has not been sold';
                    $code = 201;
                }
                else
                {
                    $msg = 'Starter pack not found in stock';
                    $code = 201;
                }
            }
            return response()->json([
                "message" => $msg,
                "code" => $code
            ]);
        }
    }
}
