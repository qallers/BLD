<?php

namespace App\Http\Controllers\Admin;

use App\Warehouse;
use App\Group;
use App\Http\Requests\Admin\StoreWarehouseRequest;
use App\Http\Requests\Admin\UpdateWarehouseRequest;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Status;
use Illuminate\Support\Facades\Auth;
use App\Address;
use App\Contact;
use App\Http\Controllers\Traits\NavisionHelperTraits;
use RealRashid\SweetAlert\Facades\Alert;
use App\SalesOrder;
use Exception;
use phpDocumentor\Reflection\Types\This;
use App\Http\Controllers\Traits\PDFExportTrait;

class WarehouseController extends Controller {

    use NavisionHelperTraits;
    use PDFExportTrait;

    public function index() {
        if (!Gate::allows('view_warehouse')) {
            return abort(401);
        }
        $warehouse = Warehouse::all();
        return view('admin.warehouse.index', compact('warehouse'));
    }

//show
    public function show(Warehouse $warehouse) {

        if (!Gate::allows('view_warehouse')) {
            return abort(401);
        }

        //  $warehouse->load('warehouse');

        $addresses = $warehouse->addresses($warehouse->id);

        $contacts = $warehouse->contacts($warehouse->id);


        return view('admin.warehouse.show', compact('warehouse', 'addresses', 'contacts'));

        // return view('admin.warehouse.show', compact('warehouse'));
        }

        public function list(Request $request) {
        if (!Gate::allows('view_warehouse')) {
            return abort(401);
        }

        $data = Warehouse::select("id", "description", "warehouse_code", "is_active", "created_at");

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }


        return datatables()->of($data)
                        ->make();
    }

    /**
     * Show the form for creating new Warehouse.
     *
     * @return \Illuminate\Http\Response    
     */
    public function create() {
        if (!Gate::allows('add_warehouse')) {
            return abort(401);
        }
        $addresstype = Status::whereProcess('address_type')->get();
        $identity = Status::whereProcess('identity_type')->get();
        $group = Group::all();

        return view('admin.warehouse.create', compact('identity', 'group', 'addresstype'));
    }

    public function returnupdatenav(Request $request) {
        \App\Returnstockmaster::where('id', $request->input("id"))
                ->update(['external_reference' => $request->input("nav_id")]);
        $order = \App\Returnstockmaster::find($request->id);
        $this->generatePDFReturn($order);
        return response()->json([
                    "msg" => "External Reference has been updated successfully.",
                    "code" => 200
        ]);
    }

    /**
     * Store a newly created warehouse in storage.
     *
     * @param  \App\Http\Requests\StoreWarehouseRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreWarehouseRequest $request) {
        if (!Gate::allows('view_warehouse')) {
            return abort(401);
        }
        Warehouse::create($request->all());

        return redirect()->route('admin.warehouse.index');
    }

    function addwarehouse(StoreWarehouseRequest $request) {
        $user_id = Auth::user()->user_type_id == 2 ? Auth::user()->id : -1;
        $request->request->add(['user_id' => $user_id]);
        if ($this->isEnabled()) {
            try {
                $this->nav_post("Location_Card", [
                    "Code" => $request->warehouse_code,
                    "Name" => $request->description
                ]);
            } catch (Exception $exception) {
                Alert::error('Error.', "Warehouse is already available in Navision.\n" . $exception->getMessage());
                return redirect()->route('admin.warehouse.index');
            }
        }

        $warehouse = Warehouse::create($request->except(['contact', 'address']));
        if ($request->filled('address')) {
            foreach ($request->address as $key => $id) {
                $address = Address::find($id);
                $address->customer_id = $warehouse->id;
                $address->save();
            }
        }
        if ($request->filled('contact')) {
            foreach ($request->contact as $key => $id) {
                $contact = Contact::find($id);
                $contact->customer_id = $warehouse->id;
                $contact->save();
            }
        }
        Alert::success('Success', "The warehouse has been created.");
        return redirect()->route('admin.warehouse.index');
    }

    /**
     * Show the form for editing User.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Warehouse $warehouse) {
        if (!Gate::allows('edit_warehouse')) {
            return abort(401);
        }

        $addresstype = Status::whereProcess('address_type')->get();
        $identity = Status::whereProcess('identity_type')->get();
        $group = Group::all();

        return view('admin.warehouse.edit', compact('warehouse', 'identity', 'group', 'addresstype'));
    }

    /**
     * Update Warehouse in storage.
     *
     * @param  \App\Http\Requests\UpdateWarehouseRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateWarehouseRequest $request, Warehouse $warehouse) {
        $warehouse->update($request->except(['contact', 'address']));
        if ($request->filled('address')) {
            foreach ($request->address as $key => $id) {
                $address = Address::find($id);
                $address->customer_id = $warehouse->id;
                $address->save();
            }
        }
        if ($request->filled('contact')) {
            foreach ($request->contact as $key => $id) {
                $contact = Contact::find($id);
                $contact->customer_id = $warehouse->id;
                $contact->save();
            }
        }
        Alert::success('Success', "The warehouse has been updated.");
        return redirect()->route('admin.warehouse.index');
    }

    /**
     * Remove User from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    //Delete Multiple warehouses
    public function massDestroy(Request $request) {
        if (!Gate::allows('edit_warehouse')) {
            return abort(401);
        }
        Warehouse::whereIn('id', request('ids'))->delete();

        return response()->noContent();
    }

    public function destroy(Warehouse $warehouse) {
        if (!Gate::allows('edit_warehouse')) {
            return abort(401);
        }

        if (isset($warehouse)) {
            $warehouse->deletewarehouse($warehouse->id);
        }
        return redirect()->route('admin.warehouse.index');
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Warehouse::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The warehouse has been $msg successfully"
        ]);
    }

    public function assign() {
        $data = Warehouse::all();
        return view('admin.warehouse.assign', compact('data'));
    }

    public function allocate() {

        $payment = Status::where('process', 'payment_status')->get();
        $delivery = Status::where('process', 'delivery_mode')->get();


        return view('admin.warehouse.allocate', compact('payment', 'delivery'));
    }

    public function dispatch_order() {

        $payment = Status::where('process', 'payment_status')->get();
        $delivery = Status::where('process', 'delivery_mode')->get();


        return view('admin.warehouse.dispatch', compact('payment', 'delivery'));
    }

    public function list_sales_order_dispatch(Request $request) {
        $status = 'allocated';
        /** @var Admin/audits $admin/audits */
        if (!empty($request->input('cid'))) {
            $ids = [$request->input("cid")];
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->whereIn('customer_id', $ids);
        } else if (!empty($request->input('ps'))) {
            $ids = [$request->input("ps")];
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->whereIn('customer_id', $ids);
        } else {
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user', 'status')->whereHas('status', function($query)use ($status) {
                $query->where('status', '=', $status)->where("process", '=', 'sales_order');
            });
            ;
        }

        return datatables()->of($order)
                        ->make();
    }

    public function list_sales_order(Request $request) {
        /** @var Admin/audits $admin/audits */
        $status = 'approved';
        if (!empty($request->input('cid'))) {
            $ids = [$request->input("cid")];
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->whereIn('customer_id', $ids);
        } else if (!empty($request->input('ps'))) {
            $ids = [$request->input("ps")];
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->whereIn('customer_id', $ids);
        } else {
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user', 'status')->whereHas('status', function($query)use ($status) {
                $query->where('status', '=', $status)->where("process", '=', 'sales_order');
            });
        }

        return datatables()->of($order)
                        ->make();
    }

}
