<?php

namespace App\Http\Controllers\Admin;

use App\Product_Type;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Gate;
use Illuminate\Http\Request;
use App\Http\Requests\Admin\StoreProductTypeRequest;
use App\Http\Requests\Admin\UpdateProductTypeRequest;
use Illuminate\Support\Facades\Session;
use RealRashid\SweetAlert\Facades\Alert;

class ProductTypeController extends Controller {

    //

    public function index() {
        if (!Gate::allows('view_product_type')) {
            return abort(401);
        }

        $product_type = Product_Type::all();

        return view('admin.product_type.index', compact('product_type'));
    }

    /**
     * Show the form for creating new product.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        if (!Gate::allows('add_product_type')) {
            return abort(401);
        }
        $product_type = Product_Type::all();

        return view('admin.product_type.create');
    }

    /**
     * Store a newly created product in storage.
     *
     * @param  \App\Http\Requests\StoreProductRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreProductTypeRequest $request) {
        if (!Gate::allows('add_product_type')) {
            return abort(401);
        }
        Product_Type::create($request->all());
        Alert::success('Success', 'The product type has been created.');

        return redirect()->route('admin.product_type.index');
    }

    public function show(Product_Type $product_type) {
        if (!Gate::allows('view_product_type')) {
            return abort(401);
        }

        return view('admin.product_type.show', compact('product_type'));
    }

    /* update network */

    public function edit(Product_Type $product_type) {
        if (!Gate::allows('edit_product_type')) {
            return abort(401);
        }
        //  $product_type = Product_Type();
        return view('admin.product_type.edit', compact('product_type'));
    }

    public function list(Request $request) {
       
        $data = Product_Type::select('id','name','is_active', 'created_at', 'updated_at');
       

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }
        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }
        return datatables()->of($data)
                        ->make();
    }

    public function update(UpdateProductTypeRequest $request, Product_Type $product_type) {

        if (!Gate::allows('edit_product_type')) {

            return abort(401);
        }


        $product_type->update($request->all());
        Alert::success('Success', 'The product type has been updated.');

        return redirect()->route('admin.product_type.index');
    }

    /**
     * Remove User from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product_Type $product_type) {
        if (!Gate::allows('edit_product_type')) {
            return abort(401);
        }

        $product_type->delete();

        return redirect()->route('admin.product_type.index');
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Product_Type::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The product type has been $msg successfully"
        ]);
    }

    /**
     * Delete all selected User at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request) {
        if (!Gate::allows('edit_product_type')) {
            return abort(401);
        }
        Product_Type::whereIn('id', request('ids'))->update(['is_active' => 1]);

        return response()->noContent();
    }

}
