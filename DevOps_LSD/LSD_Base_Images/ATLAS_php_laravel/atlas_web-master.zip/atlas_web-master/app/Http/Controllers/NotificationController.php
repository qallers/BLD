<?php

namespace App\Http\Controllers;

use Response;
use App\Status;
use App\Notification;
use App\ApprovalStages;
use App\NotificationConfig;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use RealRashid\SweetAlert\Facades\Alert;
use App\Notifications\TestEmailNotification;
use Illuminate\Support\Facades\Notification as FacadesNotification;
use Illuminate\Notifications\Notification as NotificationsNotification;

class NotificationController extends Controller
{
    /**
     * Display a listing of the Admin/audits.
     *
     * @param Request $request
     *
     * @return Response
     */

    public function list()
    {
        /** @var Admin/audits $admin/audits */

        $data = Auth::user()->unreadNotifications()->take(5)->get();
        $unread = Auth::user()->unreadNotifications->count();

        return view("ajax.notification_list", compact('data', 'unread'));
    }

    public function list_index()
    {
        /** @var Admin/audits $admin/audits */

        $data = Auth::user()->unreadNotifications();

      return datatables()->of($data)
        ->make();
    }

    public function view($id)
    {
        $noty = Auth::user()->notifications->find($id);
        $noty->markAsRead();
        return redirect($noty->data["link"]);
    }
    public function mark_all_read()
    {
        Auth::user()->unreadNotifications->markAsRead();
        return response()->json([
            "status"=>200,
            "message"=>"Notifications successfully marked as read."
        ]);
    }

    public function index(Request $request)
    {
        return view('admin.notification.index');
    }

    public function create(Request $request)
    {
        $process = Status::groupBy("process")->get();
        return view('admin.notification.create', compact('process'));
    }

    public function edit($id)
    {
        $process = Status::groupBy("process")->get();
        $notification = NotificationConfig::find($id);
        $notification->load('status_obj');
        return view('admin.notification.edit', compact('notification', 'process'));
    }

    public function store(Request $request)
    {
        $request->request->add(["emails" => implode(", ", $request->emails)]);
        $n = NotificationConfig::whereStatus($request->status)->first();
        if ($n)
        {
            $n->update($request->all());
            $n->save();
        }
        else
        {
            NotificationConfig::create($request->all());
        }
        if ($n)
        {
            Alert::success("Notification configuration has been updated.");
            return redirect("admin/notification");
        }
        else
        {
            Alert::success("Notification configuration has been created.");
            return redirect("admin/notification");
        }
    }

    public function test_mail(Request $request)
    {
        $details = [
            'greeting' => 'Hi',
            'body' => 'This is a test email notification from the Track n Trace System',
            'thanks' => 'Thank you for using the TnT system.',
            'actionText' => 'Please visit the TnT site',
            'actionURL' => url('/'),
            'order_id' => 101
        ];
        
        FacadesNotification::route('mail', $request->email)
            ->notify(new TestEmailNotification($details));

        return response()->json([
            "status" => 200,
            "message" => "Email has been sent succesfully."
        ]);
    }

    public function test_sms(Request $request)
    {
        $host = $request->sms_uri;
        $endpoint = $host . "/gatewaywebservice/Service.asmx/LogIn";

        $curl = curl_init();
        $data = http_build_query([
            'UserName' => $request->sms_username,
            'password' => $request->sms_password,
        ]);

        print_r(" request body   : " . $data);

        curl_setopt_array($curl, array(
            CURLOPT_URL => $endpoint . '?' . $data,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_CIPHER_LIST => 'DEFAULT@SECLEVEL=1',
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "authorization: Basic CAA9D4CBDAED735FBA222CC42201F9C4",
                "cache-control: no-cache",
                "cookie: mac=00:1A:79:CB:7B:96",
                "postman-token: a3f4d173-891c-6c9e-6aac-7140352bceb0"
            ),
        ));

        $response = curl_exec($curl);

        if ($response === false)
        {
            print_r("curl error: " . curl_error($curl));
            die;
        }

        $info = curl_getinfo($curl);
        print_r("Request Header :  " . json_encode($info));

        $err = curl_error($curl);

        print_r(json_encode("session ID  : " .  $response));

        curl_close($curl);
        $xml = simplexml_load_string($response);
        $json = json_encode($xml);
        $token = json_decode($json, TRUE);

        $curl = curl_init();

        $msg = str_replace(" ", "%20", "This is test SMS message sent from Track n Trace system.");
        $mobile = str_replace(" ", "", $request->mobile);
        $data = http_build_query([
            'session_token' => $token[0],
            'mobile' => $request->mobile,
            'message' => $msg
        ]);

        print_r(json_encode("message Body  : " . $data));

        $endpoint = $host . "/gatewaywebservice/Service.asmx/SendSMSMessageSingleHttpGet";
        curl_setopt_array($curl, array(
            CURLOPT_URL => $endpoint . '?' . $data,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_CIPHER_LIST => 'DEFAULT@SECLEVEL=1',
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "Cache-Control: no-cache",
                "Postman-Token: 9c63eea8-6933-4629-b85a-31f81404856a"
            ),
        ));

        $response = curl_exec($curl);

        print_r(json_encode("message response  : " . $data));

        $err = curl_error($curl);
        curl_close($curl);
        $xml = simplexml_load_string($response);
        $json = json_encode($xml);
        $token = json_decode($json, TRUE);
        $int = (int)$token[0];
        if ($int)
        {
            return response()->json([
                "status" => 200,
                "message" => "SMS has been sent succesfully."
            ]);
        }
        else
        {
            return response()->json([
                "status" => 403,
                "message" => $token[0]
            ]);
        }
    }
}