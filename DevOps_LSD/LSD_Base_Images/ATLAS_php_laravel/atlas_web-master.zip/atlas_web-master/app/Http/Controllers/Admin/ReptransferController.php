<?php

namespace App\Http\Controllers\Admin;

use App\User;
use Response;
use App\Stock;
use App\Config;
use App\Status;
use App\Warehouse;
use App\RepTransfer;
use App\Notification;
use App\RepTransferDetails;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use App\Notifications\RepOrderCreated;
use App\Notifications\RepOrderDeleted;
use RealRashid\SweetAlert\Facades\Alert;
use \App\Http\Controllers\Traits\RepOrderTrait;
use Illuminate\Support\Facades\Config as FacadesConfig;

class ReptransferController extends Controller
{
    use RepOrderTrait;
    use \App\Http\Controllers\Traits\NavisionHelperTraits;
    use \App\Http\Controllers\Traits\NotificationTraits;
    use \App\Http\Controllers\Traits\PDFExportTrait;

    /**
     * Show the form for creating a new Admin/audits.
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $status = Status::where('process', 'rep_order')->get();
        return view('admin.rep.index', compact('status'));
    }

    public function index_approve(Request $request)
    {
        $status_rep = \App\Status::where('process', 'rep_order')->get();
        return view('admin.rep.index_approve', compact('status_rep'));
    }

    public function updateorder(Request $request)
    {
        $input = $request->data;
        $input = json_decode($input, true);

        $user = auth()->user();
        $oid = $input[0]["rep_transfer_id"];

        $owarehouse =  $request->input('warehouse_id');

        $order = RepTransfer::find($oid);

        foreach ($input as $key => $p)
        {
            $or = (object) $p;
            if (!empty($or->type))
            {
                if ($or->type == "edit" || $or->type == "add")
                {
                    $o["qty"] = $or->qty;
                    $o["product_id"] = $or->product_id;

                    if ($or->type == "edit")
                    {
                        $deal = RepTransferDetails::find($or->id);
                        $deal->update($o);
                    }
                    else
                    {
                        $o["rep_transfer_id"] = $oid;
                        $deal = RepTransferDetails::create($o);
                    }
                }
                elseif ($or->type == "remove")
                {
                    RepTransferDetails::destroy($or->id);
                }
            }
        }
        /* change warehouse */
        if (isset($request->warehouse_id))
        {
            $owarehouse =  $request->warehouse_id;

            if ($owarehouse !=  $order->warehouse_id)
            {
                DB::table('rep_transfer')
                    ->where('id', $oid)
                    ->update(['warehouse_id' => $owarehouse]);
            }
        }

        return response()->json([
            "msg" => "The order has been updated successfully.",
            "id" => $oid
        ]);
    }

    public function add_product(Request $request)
    {
        $type = $request->type;

        $product = new \stdClass();
        $product->warehouse_id = $request->input('warehouse_id');
        $pdata = \App\Product::where("id", $request->input('product_id'))->first();
        $product->description = $pdata->description;
        $product->id = $request->input('rep_transfer_id');
        $product->sale_price = $pdata->sale_price;
        $product->product_code = $pdata->product_code;
        $product->product_id = $pdata->id;
        $product->qty = $request->input('qty');
        $product->rep_transfer_id = $request->input('rep_transfer_id');
        $product->type = $request->input('type');
        $product->rep_order_id = $request->input('rep_order_id');
        return view('ajax.reporder_product_row', compact('product'));
    }

    public function edit($id)
    {
        $order = RepTransfer::find($id);
        $order_details = RepTransferDetails::with('product')->where('rep_transfer_id', $id)->get();

        $product = \App\Product::all();
        $warehouse = Warehouse::all();
        return view('admin.rep.edit', compact('warehouse', 'product', 'order', 'order_details'));
    }

    public function store(Request $request)
    {
        $user = auth()->user();

        $request->request->add(['user_id' => $user->id]);
        RepTransfer::create($request->input());
        return redirect()->route('admin.purchase.create');
    }

    public function reject($id)
    {
        $order = RepTransfer::with("status")->where("id", $id)->get()->first();
        $soaa = Config::where("key", "rep_order_apply_approval")->first();
        if ($order->status->id != $soaa->value)
        {
            Alert::error('Error!', 'You cannot reject an approved order');
        }
        else
        {
            $status = Status::where('process', 'rep_order')->where('status', 'rejected')->get()->first();
            RepTransfer::where('id', $id)
                ->update(['status_id' => $status->id]);
            if (!empty($order->user_id))
            {
                $u = \App\User::find($order->user_id);
                $u->notify(new \App\Notifications\RepOrderRejected($order));
            }
            Alert::success('Success', 'Rep Order has been rejected.');
        }
        return back();
    }

    public function remove(Request $request)
    {
        if (Gate::allows('delete_sales_order'))
        {
            $order = RepTransfer::with("status")->where("id", $request->id)->get()->first();
            if ($order->status->status == "pending")
            {
                return response()->json([
                    "status" => 500,
                    "message" => "You can not delete an order which is still in approval. try Rejecting order."
                ]);
            }
            else
            {
                $status = Status::where('process', 'order')->where('status', 'deleted')->get()->first();
                RepTransfer::where('id', $request->id)
                    ->update(['status_id' => $status->id]);
                $this->generatePDFRep($order);
                if (!empty($order->user_id))
                {
                    $u = User::find($order->user_id);
                    $u->notify(new RepOrderDeleted($order));
                }
                return response()->json([
                    "status" => 200,
                    "message" => "Order has been deleted."
                ]);
            }
        }
        return response()->json([
            "status" => 403,
            "message" => "You are not authorized to do this action."
        ]);
    }
    public function update_status(Request $request)
    {
        RepTransfer::where('id', $request->input("id"))
            ->update(['status_id' => $request->input("status")]);

        $user = auth()->user();

        $order = RepTransfer::with("product", "warehouse")->where("id", $request->input("id"))->get()->first();

        $sl = array();
        $sl['user_id'] = Auth::user()->id;
        $sl['order_id'] = $request->input("id");
        $sl['qty'] = 0;
        $sl['status_id'] = $request->input("status");

        $sl['order_name'] = "REP";
        $sl['process_name'] = "update_status";

        \App\StockLedger::create($sl);

        Notification::create([
            'from_user' => $user->id,
            'to_user' => 1,
            'title' => $order->warehouse->description . ' has received your order',
            'message' => $order->product->description . " product received by " . $order->warehouse->description . ' warehouse',
            'type' => "Received",
            "url" => "admin/purchase/"
        ]);

        return response()->json([
            "msg" => "Status has been updated successfully.",
            "code" => 200
        ]);
    }

    public function listdata(Request $request)
    {
        $status = Status::where('process', 'rep_order')->get();
        $check = $request->input("cid");
        $user = Auth::user();
        if ($user->user_type_id == 2)
        {
            $order = RepTransfer::with('warehouse', 'status', 'user')->whereWarehouseId($user->warehouse_id);
            if ($check != 0)
            {
                $order = RepTransfer::with('warehouse', 'status', 'user')->whereWarehouseId($user->warehouse_id)
                    ->whereHas('status', function ($q) use ($check)
                    {
                        $q->where("id", "=", $check);
                    });
            }

            if (!Gate::allows("view_deleted_orders"))
            {
                $order = $order->whereHas('status', function ($q)
                {
                    $q->where("status", "<>", "deleted");
                });
            }
        }
        else
        {
            $order = RepTransfer::with('warehouse', 'status', 'user');
            if ($check != 0)
            {
                $order = RepTransfer::with('warehouse', 'status', 'user')
                    ->whereHas('status', function ($q) use ($check)
                    {
                        $q->where("id", "=", $check);
                    });
            }

            if (!Gate::allows("view_deleted_orders"))
            {
                $order = $order->whereHas('status', function ($q)
                {
                    $q->where("status", "<>", "deleted");
                });
            }
        }

        return datatables()->of($order)
            ->make();
    }

    public function listdata_approve(Request $request)
    {
        $order = $this->getMyOrder()["orders"]->with('warehouse', 'status', 'user', 'reptransferdetail');
        if (!Gate::allows("view_deleted_orders"))
        {
            $order = $order->whereHas('status', function ($q)
            {
                $q->where("status", "<>", "deleted");
            });
        }

        return datatables()->of($order)
            ->make();
    }

    public function approve($id)
    {
        /** @var Admin/audits $admin/audits */
        if ($this->approveOrder($id))
        {
            $order = RepTransfer::find($id)->load("user");

            $u = \App\User::find($order->user_id);
            $u->notify(new \App\Notifications\RepOrderApproved($order));

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $order->id;
            $sl['status_id'] = $order->status_id;
            $sl['qty'] = 0;

            $sl['order_name'] = "REP";
            $sl['process_name'] = "approve_order";

            \App\StockLedger::create($sl);
            Alert::success('Success', 'Order has been approved.');
        }
        else
        {
            Alert::error('Error!', 'There is an issue approving your order. Please contact the administrator.');
        }
        return back();
    }

    public function update_nav(Request $request)
    {
        RepTransfer::where('id', $request->input("id"))
            ->update(['external_reference' => $request->input("nav_id")]);

        return response()->json([
            "msg" => "Transfer order has been updated successfully.",
            "code" => 200
        ]);
    }

    public function update(Request $request, RepTransfer $purchase)
    {
        Alert::success('Success', "The Purchase Order has been updated.");
        $purchase->update($request->all());

        return redirect()->route('admin.purchase.index');
    }

    /**
     * Display the specified Admin/audits.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        if (!Gate::allows('view_rep_orders'))
        {
            return abort(401);
        }
        $order = RepTransfer::with('warehouse', 'status', 'user')->find($id);
        $od = RepTransferDetails::with('product')->where("rep_transfer_id", $id)->get();
        $isAllocated = Stock::whereIn('rep_transfer_detail_id', $od->pluck("id"))->count();
        return view('admin.rep.show', compact('order', 'od', 'isAllocated'));

        //dd($od);
        //print_r($od[0]->product->sale_price);die;
    }

    public function show_approve($id)
    {
        /** @var Admin/audits $admin/audits */
        $status = $this->check_order($id);
        if ($status->isMine)
        {
            $order = RepTransfer::with('warehouse', 'status', 'user')->find($id);
            $od = RepTransferDetails::with('product')->where("rep_transfer_id", $id)->get();
            $isAllocated = Stock::whereIn('rep_transfer_detail_id', $od->pluck("id"))->count();
            return view('admin.rep.show_approve', compact('order', 'od', 'status', 'isAllocated'));
        }
        else
        {
            abort(401);
        }

        //dd($od);
        //print_r($od[0]->product->sale_price);die;
    }

    public function get_supplier_order(Request $request)
    {
        $purchaseOrder = RepTransfer::find($request->input("id"));

        return response()->json([
            "msg" => "Order has been succesfully created.",
            "id" => $purchaseOrder
        ]);
    }

    public function createorder(Request $request)
    {
        $input = $request->all();

        $user = auth()->user();

        $order['user_id'] = $user->id;
        $order['warehouse_id'] = empty($input['warehouse_id']) ? $user->warehouse_id : $input['warehouse_id'];
        $order = RepTransfer::create($order);

        $orderdetail = json_decode($request->input('order'));

        $sos = Config::where("key", "rep_order_status")->first();
        $order->status_id = $sos->value;
        $order->save();
        $this->generatePDFRep($order);
        $order = $this->check_approval($order);

        foreach ($orderdetail as $key => $or)
        {

            $p = \App\Product::where("product_code", $or->product_code)->first();
            $o["rep_transfer_id"] = $order->id;
            $o["qty"] = $or->qty;
            $o["product_id"] = $p->id;

            RepTransferDetails::create($o);
        }

        return response()->json([
            "msg" => "Rep Transfer has been succesfully created."
        ]);
    }

    //get_supplier_order

    /**
     * Show the form for editing the specified Admin/audits.
     *
     * @param int $id
     *
     * @return Response
     */
    public function create()
    {
        $product = \App\Product::all();
        $supplier = \App\Supplier::all();
        $warehouse = Auth::user()->user_type_id == 2 ? Warehouse::whereId(Auth::user()->warehouse_id)->get() : Warehouse::all();
        $status = Status::where('process', 'purchase_order')->get();

        return view('admin.rep.create', compact('product', 'supplier', 'status', 'warehouse'));
    }
}
