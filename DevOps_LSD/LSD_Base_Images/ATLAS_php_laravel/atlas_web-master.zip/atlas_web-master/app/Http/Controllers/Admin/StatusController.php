<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Gate;
use App\Http\Requests\Admin\StoreStatusRequest;
use App\Http\Requests\Admin\UpdateStatusRequest;
use Flash;
use Response;
use App\Status;
use Spatie\Activitylog\Models\Activity;
use DataTables;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Session;
use RealRashid\SweetAlert\Facades\Alert;

class StatusController extends Controller {

    public function index() {
        if (!Gate::allows('view_status')) {
            return abort(401);
        }

        $status = Status::all();

        return view('admin.status.index', compact('status'));
        }

        public function list(Request $request) {

        $data = Status::select('id','name','status','process', 'is_active');

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }
        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }

        return datatables()->of($data)
                        ->make();
    }

    /**
     * Display a listing of the Admin/audits.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function status_byname(Request $request) {
        /** @var Admin/audits $admin/audits */
        $data = Status::where('process', $request->input("process"))->get();

        return view("ajax.status_by_name", compact('data'));
    }

    /**
     * Show the form for creating new Status.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        if (!Gate::allows('add_status')) {
            return abort(401);
        }
        $process=Status::groupBy("process")->get();
        return view('admin.status.create',compact('process'));
    }

    public function store(StoreStatusRequest $request) {
        if (!Gate::allows('add_status')) {
            return abort(401);
        }
        Status::create($request->all());
        Alert::success('Success', "The status has been created.");
        return redirect()->route('admin.status.index');
    }

    public function show(Status $status) {
        if (!Gate::allows('view_status')) {
            return abort(401);
        }
        return view('admin.status.show', compact('status'));
    }

    /* update Status */

    public function edit(Status $status) {
        if (!Gate::allows('edit_status')) {
            return abort(401);
        }
        $process=Status::groupBy("process")->get();
        return view('admin.status.edit', compact('status','process'));
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Status::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The status has been $msg successfully"
        ]);
    }

    public function update(UpdateStatusRequest $request, Status $status) {

        if (!Gate::allows('edit_status')) {

            return abort(401);
        }


        $status->update($request->all());
        Alert::success('Success', "The status has been updated.");
        return redirect()->route('admin.status.index');
    }

}
