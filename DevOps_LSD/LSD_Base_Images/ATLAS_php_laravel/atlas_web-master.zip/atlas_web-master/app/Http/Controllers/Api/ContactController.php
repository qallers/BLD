<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Flash;
use Response;
use App\Address;
use App\Contact;
use App\Status;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Spatie\Activitylog\Models\Activity;
use Spatie\Permission\Models\Role;

class ContactController extends Controller {

    /**
     * @OA\Post(
     ** path="/api/v1/contact/add",
     *   tags={"Contact"},
     *   summary="register new contact for customers",
     *   operationId="agentContact",
     *   security={
     *      {"passport": {}},
     *   },
     *   @OA\Parameter(
     *      name="customer_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="number"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="type",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="name",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string",
     *          format="email"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="mail_address",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string",
     *          format="lat,lng"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="tel_no",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="fax_no",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="cell_no",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     */

    public function store(Request $request) {
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'type' => 'required',
            'mail_address' => 'required',
            'cell_no' => 'required|min:9|max:11',
        ]);

        if ($validator->fails()) {
            return responder()->error(400,"vaidation_error")->data(['data'=>$validator->errors()])->respond(400);
        }
        $cell=$request->cell_no;
        if(strlen($cell)==10){
            $cell=substr($cell,1);
            $cell="27".$cell;
            $request->request->add(["cell_no"=>$cell]);
        }else if(strlen($cell)==11){
            $cell=substr($cell,2);
            $cell="27".$cell;
            $request->request->add(["cell_no"=>$cell]);
        }else{
            $cell="27".$cell;
            $request->request->add(["cell_no"=>$cell]);
        }
        if ($request->filled("id")) {
            $contact = Contact::find($request->id);
            $contact->update($request->except(['type']));
        } else {
            $status = Status::whereProcess("address_entity_type")
                            ->whereStatus($request->type)->first();
            $request->request->add(['contact_entity_id' => $status->id]);
            $contact = Contact::create($request->except(['type']));
        }
        if(!$contact->id){
            responder()->error(500,"Contact is not creating. Please contact admin.")->respond(500);
        }else{
            return responder()->success($contact)->respond(200);
        }
    }

    /**
     * @OA\Put(
     ** path="/api/v1/contact/update",
     *   tags={"Contact"},
     *   summary="Update contact for customers",
     *   operationId="UpdateContact",
     *   security={
     *      {"passport": {}},
     *   },
     * *   @OA\Parameter(
     *      name="id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="number"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="customer_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="number"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="type",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="name",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string",
     *          format="email"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="mail_address",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string",
     *          format="lat,lng"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="tel_no",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="fax_no",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="cell_no",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     */

    public function update(Request $request) {
        $validator = Validator::make($request->all(),[
            'id' => 'required',
            'name' => 'required',
            'type' => 'required',
            'mail_address' => 'required',
            'cell_no' => 'required|digits:11',
        ]);

        if ($validator->fails()) {
            return responder()->error(400,"vaidation_error")->data(['data'=>$validator->errors()])->respond(400);
        }
        $contact=Contact::find($request->id);
        if($contact===null){
            return responder()->error("No contact found.")->respond(404);
        }
        if($request->type=="customer"){
            if($contact->customer_id==Auth::user()->id){
                $contact->update($request->except(['type']));
                return responder()->success()->respond(200);
            }else{
                return responder()->error(500,"You cannot update other users contact.")->respond(500);
            }
        }else if($request->type=="warehouse"){
            if($contact->customer_id==Auth::user()->warehouse_id){
                $contact->update($request->except(['type']));
                return responder()->success()->respond(200);
            }else{
                return responder()->error(500,"You cannot update other users warehouse contact.")->respond(500);
            }
        }else{
            $contact->update($request->except(['type']));
            return responder()->success()->respond(200);
        }
       
    }

    /**
     * @OA\Delete(
     ** path="/api/v1/contact/delete",
     *   tags={"Contact"},
     *   summary="remove contact for customers,warehouse,supplier",
     *   operationId="deleteContact",
     *   security={
     *      {"passport": {}},
     *   },
      *   @OA\Parameter(
     *      name="id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="number"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="type",
     *      in="query",
     *      description="Must be type of 'customer', 'warehouse', 'supplier'",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     */

    public function destroy(Request $request) {
        $validator = Validator::make($request->all(),[
            'id' => 'required',
            'type' => 'in:customer,warehouse,supplier'
        ]);

        if ($validator->fails()) {
            return responder()->error(400,"vaidation_error")->data(['data'=>$validator->errors()])->respond(400);
        }
        $contact=Contact::find($request->id);
        if($contact===null){
            return responder()->error(404,"No contact found.")->respond(404);
        }
        if($request->type=="customer"){
            if($contact->customer_id==Auth::user()->id){
                $contact->delete();
                return responder()->success()->respond(200);
            }else{
                return responder()->error(500,"You cannot delete other users contact.")->respond(500);
            }
        }else if($request->type=="warehouse"){
            if($contact->customer_id==Auth::user()->warehouse_id){
                $contact->delete();
                return responder()->success()->respond(200);
            }else{
                return responder()->error(500,"You cannot delete other users warehouse contact.")->respond(500);
            }
        }else{
            $contact->delete();
            return responder()->success()->respond(200);
        }
    }

}
