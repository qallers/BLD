<?php

namespace App\Http\Controllers\Admin;

use App\Config;
use App\Grv;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\PDFExportTrait;
use App\Http\Controllers\Traits\PurchaseOrderTrait;
use \App\Http\Controllers\Traits\RepOrderTrait;
use Illuminate\Support\Facades\Auth;
use App\Notification;
use Response;
use App\Status;
use App\PurchaseOrder;
use RealRashid\SweetAlert\Facades\Alert;
use App\Notifications\PurchaseOrderApproved;
use App\Notifications\PurchaseOrderCreated;
use App\Notifications\PurchaseOrderDeleted;
use App\Notifications\RepOrderApproved;
use App\Notifications\RepOrderCreated;
use App\User;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\Config as FacadesConfig;
use Illuminate\Support\Facades\Gate;

class PurchaseOrderController extends Controller
{

    use PurchaseOrderTrait;
    use \App\Http\Controllers\Traits\NotificationTraits;
    use PDFExportTrait;

    /**
     * Show the form for creating a new Admin/audits.
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $status_rep = \App\Status::where('process', 'rep_order')->get();
        return view('admin.purchase.index', compact('status_rep'));
    }

    public function rep(Request $request)
    {
        $status_rep = \App\Status::where('process', 'rep_order')->get();
        return view('admin.purchase.rep', compact('status_rep'));
    }

    public function edit(PurchaseOrder $purchase)
    {

        $product = \App\Product::all();
        $supplier = \App\Supplier::all();
        $warehouse = \App\Warehouse::all();
        $costprice = \App\Product::where('id', $purchase->product_id)->get();
        return view('admin.purchase.edit', compact('purchase', 'product', 'supplier', 'warehouse', 'costprice'));
    }

    public function store(Request $request)
    {
        $user = auth()->user();

        $request->request->add(['user_id' => $user->id]);
        PurchaseOrder::create($request->input());
        return redirect()->route('admin.purchase.create');
    }

    public function reject($id)
    {
        $order = PurchaseOrder::with("status")->where("id", $id)->first();
        $soaa = Config::where("key", "purchase_order_apply_approval")->first();
        if ($order->status->id != $soaa->value) {
            Alert::error('Error!', 'You cannot reject an approved order');
        } else {
            $status = Status::where('process', 'purchase_order')->where('status', 'rejected')->first();
            PurchaseOrder::where('id', $id)
                ->update(['status_id' => $status->id]);
            $this->generatePDFPurchase($order);
            if (!empty($order->user_id)) {
                $u = \App\User::find($order->user_id);
                $u->notify(new \App\Notifications\PurchaseOrderRejected($order));
            }
            Alert::success('Success', 'Purchase Order has been rejected.');
        }
        return back();
    }

    public function remove(Request $request)
    {
        if (Gate::allows('delete_purchase_order')) {
            $order = PurchaseOrder::with("status")->where("id", $request->id)->get()->first();
            if ($order->status->status == "approval") {
                return response()->json([
                    "status" => 500,
                    "message" => "You can not delete an order which is in approval. Try Rejecting order."
                ]);
            } else {
                $status = Status::where('process', 'order')->where('status', 'deleted')->get()->first();
                PurchaseOrder::where('id', $request->id)
                    ->update(['status_id' => $status->id]);
                $this->generatePDFPurchase($order);
                if (!empty($order->user_id)) {
                    $u = User::find($order->user_id);
                    $u->notify(new PurchaseOrderDeleted($order));
                }
                return response()->json([
                    "status" => 200,
                    "message" => "Order has been deleted."
                ]);
            }
        }
        return response()->json([
            "status" => 403,
            "message" => "You are not authorized to do this action."
        ]);
    }

    public function reject_rep($id)
    {
        $order = PurchaseOrder::with("status")->where("id", $id)->get()->first();
        $soaa = Config::where("key", "rep_order_apply_approval")->first();
        if ($order->status->id != $soaa->value) {
            Alert::error('Error!', 'You cannot reject an approved order');
        } else {
            $status = Status::where('process', 'rep_order')->where('status', 'rejected')->get()->first();
            PurchaseOrder::where('id', $id)
                ->update(['status_id' => $status->id]);
            $this->generatePDFRep($order);
            if (!empty($order->user_id)) {
                $u = \App\User::find($order->user_id);
                $u->notify(new \App\Notifications\RepOrderRejected($order));
            }
            Alert::success('Success', 'Order has been rejected.');
        }
        return back();
    }

    public function listdata_rep(Request $request)
    {
        if (!empty($request->input('cid'))) {
            $ids = [$request->input("cid")];
            $order = PurchaseOrder::with('supplier', 'warehouse', 'product', 'status', 'user')->whereIn('supplier_id', $ids);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        } else if (!empty($request->input('ps'))) {
            $ids = [$request->input("cid")];
            $order = PurchaseOrder::with('supplier', 'warehouse', 'product', 'status', 'user')->whereIn('supplier_id', $ids);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        } else {
            $order = $this->getMyOrder()["orders"]->with('supplier', 'warehouse', 'product', 'status', 'user')->where("is_rep", 1);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        }
        return datatables()->of($order)
            ->make();
    }

    public function listdata(Request $request)
    {
       if (!empty($request->input('cid'))) {
            $ids = [$request->input("cid")];
            $order = PurchaseOrder::with('supplier', 'warehouse', 'product', 'status', 'user')->whereIn('supplier_id', $ids);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        } else if (!empty($request->input('ps'))) {
            $ids = [$request->input("cid")];
            $order = PurchaseOrder::with('supplier', 'warehouse', 'product', 'status', 'user')->whereIn('supplier_id', $ids);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        } else {
            $order = PurchaseOrder::with('supplier', 'warehouse', 'product', 'status', 'user');
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
         }

        return datatables()->of($order)
            ->make();
    }

    public function listdata_approve(Request $request)
    {

        if (!empty($request->input('cid'))) {
            $ids = [$request->input("cid")];
            $order = PurchaseOrder::with('supplier', 'warehouse', 'product', 'status', 'user')->whereIn('supplier_id', $ids);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        } else if (!empty($request->input('ps'))) {
            $ids = [$request->input("cid")];
            $order = PurchaseOrder::with('supplier', 'warehouse', 'product', 'status', 'user')->whereIn('supplier_id', $ids);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        } else {

            $order = $this->getMyOrder()["orders"]->with('supplier', 'warehouse', 'product', 'status', 'user');
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }

        }

        return datatables()->of($order)
            ->make();
    }

    public function approve_rep($id)
    {
        /** @var Admin/audits $admin/audits */
        if ($this->approveOrder_rep($id)) {
            $order = PurchaseOrder::find($id)->load("user");
            $u = \App\User::find($order->user_id);
            $u->notify(new RepOrderApproved($order));
            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $order->id;
            $sl['status_id'] = $order->status_id;
            $sl['qty'] = 0;

            $sl['order_name'] = "REP";
            $sl['process_name'] = "approve_order";

            \App\StockLedger::create($sl);
            Alert::success('Success', 'Order has been approved.');
        } else {
            Alert::error('Error!', 'There is an issue approving your order. Please contact administrator.');
        }
        return back();
    }

    public function approve($id)
    {
        /** @var Admin/audits $admin/audits */
        if ($this->approveOrder($id)) {
            $order = PurchaseOrder::find($id)->load("user");
            $this->generatePDFPurchase($order);
            $u = \App\User::find($order->user_id);
            $u->notify(new PurchaseOrderApproved($order));

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $order->id;
            $sl['status_id'] = $order->status_id;
            $sl['qty'] = 0;

            $sl['order_name'] = "PURCHASE";
            $sl['process_name'] = "approve_order";

            \App\StockLedger::create($sl);
            Alert::success('Success', 'Order has been approved.');
        } else {
            Alert::error('Error!', 'There is an issue approving your order. Please contact the administrator.');
        }
        return back();
    }

    public function update_nav(Request $request)
    {
        PurchaseOrder::where('id', $request->input("id"))
            ->update(['external_reference' => $request->input("nav_id")]);
        $order=PurchaseOrder::find($request->id);
        $this->generatePDFPurchase($order);
        return response()->json([
            "msg" => "Purchase order has been updated successfully.",
            "code" => 200
        ]);
    }

    public function update_rep_nav(Request $request)
    {
        $order=PurchaseOrder::where('id', $request->input("id"))
            ->update(['external_reference' => $request->input("nav_id")]);
        $order=PurchaseOrder::find($request->id);
        $this->generatePDFRep($order);
        return response()->json([
            "msg" => "Rep Request for Stock has been updated successfully.",
            "code" => 200
        ]);
    }

    public function update(Request $request, PurchaseOrder $purchase)
    {


        Alert::success('Success', "The Purchase Order has been updated.");
        $purchase->update($request->all());

        return redirect()->route('admin.purchase.index');
    }

    /**
     * Display the specified Admin/audits.
     *
     * @param int $id
     *
     * @return Response
     */
    public function rep_show(Request $request, $id)
    {
        $status = $this->check_order_rep($id);
        if ($status->isMine) {
            $purchaseOrder = PurchaseOrder::with('product', 'supplier', 'status', 'user', 'warehouse')->find($id);
            if (!empty($request->input('ajax'))) {
                return response()->json([
                    "status" => 200,
                    "res" => $purchaseOrder
                ]);
            } else {
                $od_status = Status::where('process', 'rep_order')->get();
                $status_rep = Status::where('process', 'rep_order')->get();
                return view('admin.purchase.show_rep', compact('purchaseOrder', 'status', 'status_rep', 'od_status'));
            }
        } else {
            abort(401);
        }
    }

    public function show(Request $request, $id)
    {
        $purchaseOrder = PurchaseOrder::with('product', 'supplier', 'status', 'user', 'warehouse')->find($id);
        if (!empty($request->input('ajax'))) {
            return response()->json([
                "status" => 200,
                "res" => $purchaseOrder
            ]);
        } else {
            $od_status = Status::where('process', 'purchase_order')->get();
            $isReceived=Grv::wherePurchaseOrderId($id)->count();
            return view('admin.purchase.show', compact('purchaseOrder', 'od_status','isReceived'));
        }
    }
    public function show_approve(Request $request, $id)
    {
        $status = $this->check_order($id);
        if ($status->isMine) {
            $purchaseOrder = PurchaseOrder::with('product', 'supplier', 'status', 'user', 'warehouse')->find($id);
            if (!empty($request->input('ajax'))) {
                return response()->json([
                    "status" => 200,
                    "res" => $purchaseOrder
                ]);
            } else {
                $od_status = Status::where('process', 'purchase_order')->get();
                $isReceived=Grv::wherePurchaseOrderId($id)->count();
                return view('admin.purchase.show_approve', compact('purchaseOrder', 'status', 'od_status','isReceived'));
            }
        } else {
            Alert::error("You don't have permisison to approve this order");
            return back();
        }
    }

    public function get_supplier_order(Request $request)
    {
        $purchaseOrder = PurchaseOrder::find($request->input("id"));

        return response()->json([
            "msg" => "Order has been succesfully created.",
            "id" => $purchaseOrder
        ]);
    }

    public function createorder(Request $request)
    {
        $obj = json_decode($request->input("order"));
        $o = array();
        $user = auth()->user();

        $o['user_id'] = $user->id;
        $o['warehouse_id'] = empty($request->input("warehouse_id")) ? $user->warehouse_id : $request->input("warehouse_id");
        $o['supplier_id'] = empty($request->input("supplier_id")) ? 0 : $request->input("supplier_id");
        // $o['status_id'] = empty($request->input("status_id")) ? $status->id : $request->input("status_id");
        foreach ($obj as $key => $value) {
            $o["qty"] = $value->qty;
            $o["product_id"] = $value->id;
            $order = PurchaseOrder::create($o);
           
              $sos = Config::where("key", "purchase_order_status")->first();
                $order->status_id = $sos->value;
                $order->save();
                $order = PurchaseOrder::with('product', 'supplier', 'status', 'user', 'warehouse')->find($order->id);
                $this->generatePDFPurchase($order);
                $order = $this->check_approval($order);
                $sl = array();
                $sl['user_id'] = $user->id;
                $sl['order_id'] = $order->id;
                $sl['qty'] = $value->qty;
                $sl['status_id'] = $order->status_id;
                $sl['order_name'] = "PURCHASE";
                $sl['process_name'] = "create_order";
                $this->sendEmails($sos->value, new PurchaseOrderCreated($order));
            
            \App\StockLedger::create($sl);
        }

        return response()->json([
            "msg" => "Order has been succesfully created."
        ]);
    }

    //get_supplier_order

    /**
     * Show the form for editing the specified Admin/audits.
     *
     * @param int $id
     *
     * @return Response
     */
    public function create()
    {

        $product = \App\Product::all();
        $supplier = \App\Supplier::all();
        $warehouse = \App\Warehouse::all();
        $status = Status::where('process', 'purchase_order')->get();

        return view('admin.purchase.create', compact('product', 'supplier', 'status', 'warehouse'));
    }
}
