<?php

namespace App\Http\Controllers;

use App\User;
use App\Warehouse;
use App\Customer;
use App\Http\Controllers\Traits\SalesOrderTrait;
use App\Product;
use App\PurchaseOrder;
use App\SalesOrder;
use App\SalesOrderDetails;
use App\Supplier;
use App\Network;
use App\Status;
use App\Group;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use stdClass;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\ParentChildTrait;
use App\Reports\Supplieractivationrecon;
use App\Reports\Supplierconnection;
use App\Reports\Supplierogrrecon;
use App\Reports\Supplierdeletion;
use App\Reports\Suppliersimswaprecon;
use App\Reports\Customer\Customeractivationpipe;
use App\Reports\Customer\Customerconnectionpipe;
use App\Reports\Customer\Customersalesdeal;
use App\Reports\Customer\Customerogrrecon;
use App\Reports\Customer\Customeractivationrecon;
use App\Reports\Customer\Customersimswap;
use App\Reports\Warehouse\Warehousedashboard;
use App\Reports\Customer\Returnstock;
use App\Reports\Customer\Repsalesdaily;
use App\Reports\Customer\Customerconnection;
use App\Reports\Customer\Customerdeletion;
use App\Reports\Warehouse\Dispatchreport;
use App\StockLedger;

class ReportingController extends Controller {

    use SalesOrderTrait;
    use ParentChildTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    public function stock_ledger() {
        $users = User::all();
        return view("reporting.warehouse.stock_ledger", compact('users'));
    }

    public function stock_ledger_list(Request $request) {
        $data = StockLedger::with("user", "status", "purchaseOrder", "saleOrder");

        if ($request->filled("users")) {
            if (!in_array("-1", $request->input("users"))) {
                $data->whereIn('user_id', $request->input("users"));
            }
        }
        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }
        if ($request->filled("order_name")) {
            $data->where('order_name', $request->input("order_name"));
        }

        return datatables()->of($data)
                        ->make();
    }

    public function warehouse_dashboard() {
        $report = new Warehousedashboard();
        $report->run();
        return view("reporting.warehouse.dashboard", ["report" => $report]);
    }

    public function warehouse_dashboard_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Warehousedashboard();

        $report->run();
        $report->exportToExcel('Warehousedashboardeexcel')->toBrowser("Customeractivationpipe_" . date('Y-m-d') . ".xlsx");
    }

    public function warehouse_dashboard_export_pdf() {
        $report = new Warehousedashboard();
        $report->run()
                ->export('WarehousedashboardPdf')
                ->pdf(array(
                    "format" => "A3",
                    "orientation" => "portrait",
                        //"zoom"=>2
                ))
                ->toBrowser("Customer_activation_pipe_" . date('Y-m-d') . ".pdf");
    }
    /**
     * Dispatch report 
     */
    public function warehouse_dispatch() {
        $report = new Dispatchreport();
        $report->run();
        return view("reporting.dispatch.dispatchreport", ["report" => $report]);
    }

    public function warehouse_dispatch_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Dispatchreport();
        //dd($report);
        $report->run();
        $report->exportToExcel('Dispatchreportexcel')->toBrowser("warehouse_dispatch_report_" . date('Y-m-d') . ".xlsx");
    }


    public function warehouse_dispatch_export_pdf() {
          $report = new Dispatchreport();
          // dd($report);
               $report->run()
                ->export('DispatchreportPdf')
                ->settings(array(
                    "useLocalTempFolder"=>true,
                    ))
                ->pdf()
                ->toBrowser("warehouse_dispatch_report_" . date('Y-m-d') . ".pdf");
    }
    /**
     * End Dispatch report 
     */

    //rep sales deal

    public function rep_sales_daily() {
        $report = new Repsalesdaily();
        $report->run();
        return view("reporting.customer.salesdeal", ["report" => $report]);
    }

    public function rep_sales_daily_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Repsalesdaily();

        $report->run();
        $report->exportToExcel('Repsalesdailyexcel')->toBrowser("Rep_sales_deal_" . date('Y-m-d') . ".xlsx");
    }

    public function rep_sales_daily_export_pdf() {
        $report = new Repsalesdaily();
        $report->run()
                ->export('ReturnstockPdf')
                ->pdf(array(
                    "format" => "A3",
                    "orientation" => "portrait",
                        //"zoom"=>2
                ))
                ->toBrowser("Rep_sales_deal_" . date('Y-m-d') . ".pdf");
    }

    //return stock reporting functions

    public function returnstock() {
        $report = new Returnstock();
        $report->run();
        return view("reporting.customer.salesdeal", ["report" => $report]);
    }

    public function returnstock_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Returnstock();

        $report->run();
        $report->exportToExcel('Returnstockexcel')->toBrowser("customer_salesdeal_" . date('Y-m-d') . ".xlsx");
    }

    public function returnstock_export_pdf() {
        $report = new Returnstock();
        $report->run()
                ->export('ReturnstockPdf')
                ->pdf(array(
                    "format" => "A3",
                    "orientation" => "portrait",
                        //"zoom"=>2
                ))
                ->toBrowser("Customer_salesDeal" . date('Y-m-d') . ".pdf");
    }

// customer sales deal report functions start
    public function customer_salesdeal() {
        $report = new Customersalesdeal();
        $report->run();
        return view("reporting.customer.salesdeal", ["report" => $report]);
    }

    public function customer_salesdeal_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Customersalesdeal();

        $report->run();
        $report->exportToExcel('Customersalesdealexcel')->toBrowser("customer_salesdeal_" . date('Y-m-d') . ".xlsx");
    }

    public function customer_salesdeal_export_pdf() {
        $report = new Customersalesdeal();
        $report->run()
                ->export('CustomersalesdealPdf')
                ->pdf(array(
                    "format" => "A3",
                    "orientation" => "portrait",
                        //"zoom"=>2
                ))
                ->toBrowser("Customer_salesDeal" . date('Y-m-d') . ".pdf");
    }

    // end sales deal   
    // customer activation pipe report functions start
    public function customer_activation_pipe() {
        $report = new Customeractivationpipe();
        $report->run();
        return view("reporting.customer.activation_pipe", ["report" => $report]);
    }

    public function customer_activation_pipe_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Customeractivationpipe();

        $report->run();
        $report->exportToExcel('Customeractivationpipeexcel')->toBrowser("Customeractivationpipe_" . date('Y-m-d') . ".xlsx");
    }

    public function customer_activation_pipe_export_pdf() {
        $report = new Customeractivationpipe();
        $report->run()
                ->export('CustomeractivationpipePdf')
                ->pdf(array(
                    "format" => "A3",
                    "orientation" => "portrait",
                        //"zoom"=>2
                ))
                ->toBrowser("Customer_activation_pipe_" . date('Y-m-d') . ".pdf");
    }

    //end customer activation pipe


    public function customer_connection_pipe() {
        $report = new Customerconnectionpipe();
        $report->run();
        return view("reporting.customer.activation_pipe", ["report" => $report]);
    }

    public function customer_connection_pipe_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Customerconnectionpipe();

        $report->run();
        $report->exportToExcel('Customeractivationpipeexcel')->toBrowser("Customeractivationpipe_" . date('Y-m-d') . ".xlsx");
    }

    public function customer_connection_pipe_export_pdf() {
        $report = new Customerconnectionpipe();
        $report->run()
                ->export('CustomerconnectionpipePdf')
                ->pdf(array(
                    "format" => "A3",
                    "orientation" => "portrait",
                        //"zoom"=>2
                ))
                ->toBrowser("Customer_connection_pipe_" . date('Y-m-d') . ".pdf");
    }

    public function supplier_ogr_recon() {
        $report = new Supplierogrrecon();
        $report->run();
        return view("reporting.supplier.ogr_recon", ["report" => $report]);
    }

    public function customer_connection() {
        $report = new Customerconnection();
        $report->run();
        return view("reporting.customer.common_reporting", ["report" => $report]);
    }
    public function customer_connection_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Customerconnection();

        $report->run();
        $report->exportToExcel('Customerconnectionexcel')->toBrowser("customer_connection_" . date('Y-m-d') . ".xlsx");
    }

    public function customer_connection_export_pdf() {
        $report = new Customerconnection();
        $report->run()->export('CustomerconnectionPdf')->settings(array(
            "useLocalTempFolder" => true
        ))->pdf(array(
            "format" => "A4",
            "orientation" => "landscap"
        ))->toBrowser("customer_connection_" . date('Y-m-d') . ".pdf", true);
    }

    public function customer_deletion() {
        $report = new Customerdeletion();
        $report->run();
        return view("reporting.customer.common_reporting", ["report" => $report]);
    }
    public function customer_deletion_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Customerdeletion();

        $report->run();
        $report->exportToExcel('Customerdeletionexcel')->toBrowser("customer_deletion_" . date('Y-m-d') . ".xlsx");
    }

    public function customer_deletion_export_pdf() {
        $report = new Customerdeletion();
        $report->run()->export('CustomerdeletionPdf')->settings(array(
            "useLocalTempFolder" => true
        ))->pdf(array(
            "format" => "A4",
            "orientation" => "landscap"
        ))->toBrowser("customer_deletion_" . date('Y-m-d') . ".pdf", true);
    }
    public function supplier_ogr_recon_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Supplierogrrecon();

        $report->run();
        $report->exportToExcel('Supplierogrreconexcel')->toBrowser("Supplier_ogr_recon_" . date('Y-m-d') . ".xlsx");
    }

    public function supplier_ogr_recon_export_pdf() {
        ini_set('max_execution_time', 3000);

        $report = new Supplierogrrecon();
        $report->run()->export('SupplierogrreconPdf')->pdf(array(
            "format" => "A3",
            "orientation" => "portrait"
        ))->toBrowser("Supplier_ogr_recon_" . date('Y-m-d') . ".pdf", true);
    }

    public function customer_ogr_recon() {
        $report = new Customerogrrecon();
        $report->run();
        return view("reporting.customer.ogr_recon", ["report" => $report]);
    }

    public function customer_ogr_recon_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Customerogrrecon();

        $report->run();
        $report->exportToExcel('Customerogrreconexcel')->toBrowser("Customer_ogr_recon_" . date('Y-m-d') . ".xlsx");
    }

    public function customer_ogr_recon_export_pdf() {
        ini_set('max_execution_time', 3000);

        $report = new Customerogrrecon();
        $report->run()->export('CustomerogrreconPdf')->pdf(array(
            "format" => "A3",
            "orientation" => "portrait"
        ))->toBrowser("Customer_ogr_recon_" . date('Y-m-d') . ".pdf", true);
    }

    public function customer_activation_recon() {
        $report = new Customeractivationrecon();
        $report->run();
        return view("reporting.customer.activation_recon", ["report" => $report]);
    }

    public function customer_activation_recon_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Customeractivationrecon();

        $report->run();
        $report->exportToExcel('Customeractivationreconexcel')->toBrowser("Customer_activation_recon_" . date('Y-m-d') . ".xlsx");
    }

    public function customer_activation_recon_export_pdf() {
        $report = new Customeractivationrecon();
        $report->run()->export('CustomeractivationreconPdf')->pdf(array(
            "format" => "A3",
            "orientation" => "portrait"
        ))->toBrowser("Customer_activation_recon_" . date('Y-m-d') . ".pdf", true);
    }

    public function customer_simswap() {
        $report = new Customersimswap();
        $report->run();
        return view("reporting.customer.simswap", ["report" => $report]);
    }

    public function customer_simswap_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Customersimswap();

        $report->run();
        $report->exportToExcel('Customersimswapexcel')->toBrowser("Customer_simswap_" . date('Y-m-d') . ".xlsx");
    }

    public function customer_simswap_export_pdf() {
        $report = new Customersimswap();
        $report->run()->export('CustomersimswapPdf')->pdf(array(
            "format" => "A3",
            "orientation" => "portrait"
        ))->toBrowser("Customer_simswap_" . date('Y-m-d') . ".pdf", true);
    }

    public function supplier_simswap_recon() {
        $report = new Suppliersimswaprecon();
        $report->run();
        return view("reporting.supplier.simswap_recon", ["report" => $report]);
    }

    public function supplier_simswap_recon_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Suppliersimswaprecon();

        $report->run();
        $report->exportToExcel('Suppliersimswapreconexcel')->toBrowser("Supplier_simswap_recon_" . date('Y-m-d') . ".xlsx");
    }

    public function supplier_simswap_recon_export_pdf() {
        $report = new Suppliersimswaprecon();
        $report->run()->export('SuppliersimswapreconPdf')->settings(array(
            "useLocalTempFolder" => true,
        ))->pdf(array(
            "format" => "A4",
            "orientation" => "landscape"
        ))->toBrowser("supplier_simswap_" . date('Y-m-d') . ".pdf", true);
    }

    public function supplier_activation_recon() {
        $report = new Supplieractivationrecon();
        $report->run();
        return view("reporting.supplier.activation_recon", ["report" => $report]);
    }

    public function supplier_activation_recon_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Supplieractivationrecon();

        $report->run();
        $report->exportToExcel('Supplieractivationreconexcel')->toBrowser("Supplier_activation_recon_" . date('Y-m-d') . ".xlsx");
    }

    public function supplier_activation_recon_export_pdf() {
//        return "Hello world";
        $report = new Supplieractivationrecon();
        $report->run()->render('SupplieractivationreconPdf');
        return;
        $report->run()->export('SupplieractivationreconPdf')->settings(array(
            "useLocalTempFolder" => true
        ))->pdf(array(
            "format" => "A4",
            "orientation" => "landscape"
        ))->toBrowser("supplier_activation_recon_" . date('Y-m-d') . ".pdf", true);
    }

    public function supplier_connection() {
        $report = new Supplierconnection();
        $report->run();
        return view("reporting.supplier.connection", ["report" => $report]);
    }

    public function supplier_connection_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Supplierconnection();

        $report->run();
        $report->exportToExcel('Supplierconnectionexcel')->toBrowser("Supplier_connection_" . date('Y-m-d') . ".xlsx");
    }

    public function supplier_connection_export_pdf() {
        $report = new Supplierconnection();
        $report->run()->export('SupplierconnectionPdf')->settings(array(
            "useLocalTempFolder" => true
        ))->pdf(array(
            "format" => "A4",
            "orientation" => "landscap"
        ))->toBrowser("supplier_connection_" . date('Y-m-d') . ".pdf", true);
    }

    public function supplier_deletion() {
        $report = new Supplierdeletion();
        $report->run();
        return view("reporting.supplier.deletion", ["report" => $report]);
    }

    public function supplier_deletion_export_excel() {
        ini_set('max_execution_time', 300);
        $report = new Supplierdeletion();

        $report->run();
        $report->exportToExcel('Supplierdeletionexcel')->toBrowser("Supplier_deletion_" . date('Y-m-d') . ".xlsx");
    }

    public function supplier_deletion_export_pdf() {
        ini_set('max_execution_time', 300);

        $report = new Supplierdeletion();
        $report->run()
                ->export('SupplierdeletionPdf')
                ->pdf(array(
                    "format" => "A3",
                    "orientation" => "landscape"
                ))
                ->toBrowser("Supplier_deletion_" . date('Y-m-d') . ".pdf");
    }

//    public function warehouse() {
//        
//    }

    public function starter_pack_history($input) {
        $data = array();
        if (!empty($input)) {
            $boxdata = \App\Box::where('barcode', $input)->first();
            if (!empty($boxdata->id)) {
               $getChild = $this->getChildBox($boxdata->id); 
                if (count($getChild)==1 && $getChild[0]==$boxdata->id){
                    $box = $boxdata->id;
                    $data = \Illuminate\Support\Facades\DB::select("SELECT DISTINCT c.name as customer_name,c.cust_code,w.description as warehouse_name,w.warehouse_code,n.name,p.description as pname,p.product_code,po.external_reference,gf.supplier_invoice_id,g.*,count(g.serial_no) as cnt,sd.sales_order_id,sd.invoice_number,so.external_reference as external_reference_sales FROM stock s LEFT JOIN grv g ON g.serial_no = s.serial_no LEFT JOIN grv_import_file gf ON g.file_id = gf.id LEFT JOIN purchase_order po ON g.purchase_order_id = po.id LEFT JOIN customer c ON s.customer_id = c.id LEFT JOIN warehouse w ON s.warehouse_id = w.id LEFT JOIN sales_order_detail sd ON s.sales_order_detail_id = sd.id LEFT JOIN sales_order so ON so.id = sd.sales_order_id LEFT JOIN network n ON s.network_id = n.id LEFT JOIN product p ON s.product_id = p.id WHERE s.box_id = '$box'");
                } else {
                    $data = \Illuminate\Support\Facades\DB::select("SELECT DISTINCT c.name as customer_name,c.cust_code,w.description as warehouse_name,w.warehouse_code,n.name,p.description as pname,p.product_code,po.external_reference,gf.supplier_invoice_id,g.*,count(g.serial_no) as cnt,sd.sales_order_id,sd.invoice_number,so.external_reference as external_reference_sales FROM stock s LEFT JOIN grv g ON g.serial_no = s.serial_no LEFT JOIN grv_import_file gf ON g.file_id = gf.id LEFT JOIN purchase_order po ON g.purchase_order_id = po.id LEFT JOIN customer c ON s.customer_id = c.id LEFT JOIN warehouse w ON s.warehouse_id = w.id LEFT JOIN sales_order_detail sd ON s.sales_order_detail_id = sd.id LEFT JOIN sales_order so ON so.id = sd.sales_order_id LEFT JOIN network n ON s.network_id = n.id LEFT JOIN product p ON s.product_id = p.id WHERE s.box_id in($getChild)");
                }
            } else {
                $data = \Illuminate\Support\Facades\DB::select("SELECT DISTINCT c.name as customer_name,c.cust_code,w.description as warehouse_name,w.warehouse_code,n.name,p.description as pname,p.product_code,po.external_reference,gf.supplier_invoice_id,g.*,count(g.serial_no) as cnt,sd.sales_order_id,sd.invoice_number,so.external_reference as external_reference_sales, b.barcode as internal_box FROM stock s LEFT JOIN grv g ON g.serial_no = s.serial_no LEFT JOIN grv_import_file gf ON g.file_id = gf.id LEFT JOIN purchase_order po ON g.purchase_order_id = po.id LEFT JOIN customer c ON s.customer_id = c.id LEFT JOIN warehouse w ON s.warehouse_id = w.id LEFT JOIN sales_order_detail sd ON s.sales_order_detail_id = sd.id LEFT JOIN box b ON s.box_id = b.id LEFT JOIN sales_order so ON so.id = sd.sales_order_id LEFT JOIN network n ON s.network_id = n.id LEFT JOIN product p ON s.product_id = p.id WHERE (g.brick = '$input' OR g.box = '$input' OR g.pallet = '$input' OR g.serial_no = '$input')");
            }
            return response()->json([
                        'status' => "200",
                        'res' => $data[0]
            ]);
        }
        return view('reporting.sim_history', compact('data'));
    }

    public function purchase_history(Request $request) {
        $users = User::all();
        $suppliers = Supplier::all();
        return view('reporting.purchase.index', compact('users', 'suppliers'));
    }

    public function sales_history(Request $request) {
        $users = User::all();
        $customers = Customer::whereIsActive(1)->get();
        return view('reporting.sales.index', compact('users', 'customers'));
    }

    public function ajax_purchase(Request $request) {
        $data = PurchaseOrder::with('user', 'status', 'product', 'product.network', 'supplier');
        //DB::enableQueryLog();
        if ($request->filled("ids")) {
            $data->whereIn('rep_user_id', $request->input("ids"));
        }
        if ($request->filled("suppliers")) {
            $data->whereIn('supplier_id', $request->input("suppliers"));
        }
        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }
        // $data->get();
        // dd(DB::getQueryLog());

        return datatables()->of($data)
                        ->make();
    }

    public function ajax_sales(Request $request) {
        $data = SalesOrder::with('user', 'status', 'paymentStatus', 'deliveryMode', 'customer');
        //DB::enableQueryLog();
        if ($request->filled("ids")) {
            $data->whereIn('rep_user_id', $request->input("ids"));
        }
        if ($request->filled("customers")) {
            $data->whereIn('customer_id', $request->input("customers"));
        }
        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }
        // $data->get();
        // dd(DB::getQueryLog());

        return datatables()->of($data)
                        ->make();
    }

    public function ajax_dispatch(Request $request) {
        
        $data = SalesOrder::with('user', 'customer', 'status', 'paymentStatus', 'deliveryMode')
        ->select("sales_order.*","sales_order_detail.qty","sales_order_detail.invoice_number","product.product_code")
        ->join('sales_order_detail', 'sales_order.id', '=', 'sales_order_detail.sales_order_id')
        ->join('product', 'product.id', '=', 'sales_order_detail.product_id')
        ->where('sales_order_detail.is_dispatch', 1);

        if ($request->filled("ids")) {
            $data->whereIn('sales_order.user_id', $request->input("ids"));
        }
        if ($request->filled("customers")) {
            $data->whereIn('sales_order.customer_id', $request->input("customers"));
        }
        if ($request->filled("start_date")) {
            if (empty($request->end_date)) {
                $request->end_date = '2099-12-30';
            }
            if (empty($request->end_date)) {
                $request->start_date = '2000-12-30';
            }
            $data->whereBetween('sales_order.created_at', [$request->start_date, $request->end_date]);
        }

        $data->groupBy('sales_order_detail.sales_order_id');
        $data->orderBy('sales_order.created_at', 'DESC');
        return datatables()->of($data)
                        ->make();
    }

    public function ajax_transfer(Request $request) {
        $data = PurchaseOrder::with('user', 'status', 'warehouse', 'product')->where("is_rep", 1);
        //DB::enableQueryLog();
        if ($request->filled("ids")) {
            $data->whereIn('rep_user_id', $request->input("ids"));
        }
        if ($request->filled("customers")) {
            $data->whereIn('warehouse_id', $request->input("customers"));
        }
        if ($request->filled("products")) {
            $data->whereIn('product_id', $request->input("products"));
        }

        if ($request->filled("start_date")) {
            if (empty($request->end_date)) {
                $request->end_date = '2099-12-30';
            }
            if (empty($request->end_date)) {
                $request->start_date = '2000-12-30';
            }
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }
        // $data->get();
        // dd(DB::getQueryLog());

        return datatables()->of($data)
                        ->make();
    }

    public function ajax_return(Request $request) {
        //$data = \App\ReturnStock::with('salesOrderDetail', 'salesOrderDetail.order.customer', 'salesOrderDetail.product', 'user');
        $where = "where 1=1";
        if ($request->filled("customers")) {
            // print_r($request->input("customers")); die;
            $cids = implode(',', $request->input("customers"));
            $where .= " AND s.customer_id in($cids)";
        }
        if ($request->filled("start_date")) {
            if (empty($request->end_date)) {
                $request->end_date = '2099-12-30';
            }
            if (empty($request->end_date)) {
                $request->start_date = '2000-12-30';
            }
            $where .= " AND r.created_at between '$request->start_date' AND '$request->end_date'";
            // $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }
        $data = \Illuminate\Support\Facades\DB::select("SELECT sd.qty,p.description,c.name,n.name as network,sd.invoice_number FROM return_stock r JOIN sales_order_detail sd ON r.sales_order_detail_id = sd.id JOIN product p ON sd.product_id = p.id JOIN sales_order s ON sd.sales_order_id = s.id JOIN customer c ON c.id = s.customer_id JOIN network n ON p.network_id = n.id $where group BY sales_order_detail_id");
        return datatables()->of($data)
                        ->make();
    }

    public function ajax_sales_details(Request $request) {
        $order = SalesOrder::find($request->id);
        $order_details = SalesOrderDetails::where('sales_order_id', $request->id)->get();
        $deal = [];
        foreach ($order_details as $key => $od) {
            $data = new stdClass();
            $data->customer_id = $order->customer_id;
            $data->product_id = $od->product_id;
            $data->product_deal = $od->product_deal_id;
            $data->split_deal_id = $od->split_deal_id;
            $data->is_dispatch = $od->is_dispatch;
            $data->qty = $od->qty;
            $data->type = "none";
            $data->order_detail_id = $od->id;
            $data->sales_order_id = $od->sales_order_id;
            $deal[] = array_merge($this->get_product_entry($data), array("data" => $data, "type" => "edit", 'isReporting' => 1));
        }
        return view('ajax.reporting_salesdetils', compact('deal'));
    }

    public function transfer_history() {
        $users = User::all();
        $warehouse = Warehouse::all();
        $product = Product::all();
        return view('reporting.transfer.index', compact('users', 'warehouse', 'product'));
    }

    public function return_history() {
        $users = User::all();
        $product = Product::all();
        $customer = Customer::whereIsActive(1)->get();
        return view('reporting.return.index', compact('users', 'product', 'customer'));
    }

    public function dispatch_history() {
        $users = User::all();
        $customers = Customer::whereIsActive(1)->get();
        return view('reporting.dispatch.index', compact('users', 'customers'));
    }

  /**
     * stock_movement
     */

    public function stock_movement() {
        $users = User::all();
        $warehouse = Warehouse::all();
        return view('reporting.stock_movement.index', compact('users', 'warehouse'));
    }
    public function ajax_stock_movement(Request $request) {
        $dataSql="SELECT t1.id AS 'Transfer ID' ,t2.id AS 'Detail ID' ,t2.created_at  ,t7.name  ,t5.description AS 'UserType'
                ,t4.username  ,t3.warehouse_code,t3.description ,t9.description AS 'Current_Warehouse' ,t6.product_code 
                ,t2.qty  ,COUNT(t8.serial_no) as allocated
                FROM rep_transfer t1
                LEFT JOIN rep_transfer_detail t2 ON t2.rep_transfer_id = t1.id
                LEFT JOIN warehouse t3 ON t3.id = t1.warehouse_id
                LEFT JOIN users t4 ON t4.warehouse_id = t1.warehouse_id
                LEFT JOIN user_type t5 ON t5.id = t4.user_type_id
                LEFT JOIN product t6 ON t6.id = t2.product_id
                LEFT JOIN `status` t7 ON t7.id = t1.status_id
                LEFT JOIN stock t8 ON t8.rep_transfer_detail_id = t2.id
                LEFT JOIN warehouse t9 ON t9.id = t8.warehouse_id
                WHERE t1.warehouse_id <> 1 AND t7.name <> 'Rejected' AND ";
       if (empty($request->end_date)) {
                $e_date=date("Y-m-d");
                 $request->end_date =$e_date;
              }
          if (empty($request->start_date)) {
                 $s_date=date("Y-m-d", strtotime("-1 months", strtotime(date("Y-m-d"))));
                 $request->start_date = $s_date;
          }
          $dataSql.= "t1.created_at Between '$request->start_date' And '$request->end_date' ";
  
            if ($request->filled("warehouses")) {
                 
                $cids = implode(',', $request->input("warehouses"));
                 $dataSql.=" AND t3.id IN ($cids) ";
             }
            
            $dataSql.= " group  BY t1.id
                        ,t2.id
                        ,t5.description
                        ,t4.username
                        ,t3.description
                        ,t3.warehouse_code
                        ,t9.warehouse_code
                        ,t6.product_code
                        ,t8.warehouse_id
                        ORDER BY t1.id,t2.id";
        
        $data=\Illuminate\Support\Facades\DB::select($dataSql);
       
        return datatables()->of($data)
                        ->make();
    }
    
    /**
     * End stock_movement
     */
    /**
      * Customer list report 
      */

      public function customer(Request $request) {
        $group = Group::whereIsActive(1)->get();
        $users = User::whereIsActive(1)->get();
        $repuser = User::where('user_type_id', 2)->get();
        $parent = Customer::where('parent_id', -1)->get();
       // $parentcustomer = Customer::find($customer->parent_id);
       return view('reporting.customer.customer_list', compact( 'group','users','repuser','parent'));
      }


      public function customer_list(Request $request) {

        $dataSql="SELECT t1.id,t1.cust_code,t1.name 'cust_name',t2.cust_code 'parent_code',
                 t3.description,t4.username,
                 Case 
                 when t1.is_active=1
                 Then 'Active'
                 ELSE 
                 'Not Active' 
                 END AS status,Date_Format(t1.created_at,'%Y-%m-%d') date_created
                 FROM customer t1 
                 LEFT JOIN customer t2 ON t2.id = t1.parent_id
                 LEFT JOIN `group` t3 ON t3.id=t1.group_id
                 LEFT JOIN users t4 ON t4.id = t1.rep_user_id
                 LEFT JOIN status t5 ON t5.id=t1.status_id
                 LEFT JOIN users t6 ON t6.id=t1.user_id 
                 Where   ";
 
                if (empty($request->end_date)) {
                        $e_date=date("Y-m-d");
                        $request->end_date=$e_date;
                    }
                if (empty($request->start_date)) {
                        $s_date=date("Y-m-d", strtotime("-3 months", strtotime(date("Y-m-d"))));
                        $request->start_date = $s_date;
                }
                    $end_date=date('Y-m-d', strtotime($request->end_date)); 
                    $start_date=date('Y-m-d', strtotime($request->start_date)); 

                $dataSql.= "t1.created_at >= '$start_date 00:00:00' AND  t1.created_at<= '$end_date 23:59:59' ";
           
            
                if ($request->filled("group")) {
                    
                    $groups = implode(',', $request->input("group"));
                    $dataSql.=" AND t3.id IN ($groups) ";
                }

                if ($request->filled("parent")) {
                    
                    $parents = implode(',', $request->input("parent"));
                    $dataSql.=" AND t1.parent_id IN ($parents) ";
                }

                if ($request->filled("repuser")) {
                    
                    $reps = implode(',', $request->input("repuser"));
                    $dataSql.=" AND t1.rep_user_id IN ($reps) ";
                }
          

        $data=\Illuminate\Support\Facades\DB::select($dataSql);
        
        return datatables()->of($data)
        ->make();
    }

    public function export_customer_list(Request $request)
    {
 
        $dataSql="SELECT  t1.id,t1.cust_code,t1.name 'cust_name'
                ,t9.reference byd,t2.cust_code 'parent_code'
                ,t4.username rep,t3.description 'group'
                ,t10.name 'IdentyType'
                ,t1.identity_reference,t1.identity_reference_expiry_date
                ,t5.name 'country',
                Case 
                when t1.vat_registered=1
                Then 'Yes'
                ELSE 
                    'No' 
                END AS vat_reg,t1.vat_reg_no, t11.name 'payment_method',
                Case 
                when t1.is_active=1
                Then 'Active'
                ELSE 
                    'Not Active' 
                END AS status,t7.mail_address,t7.cell_no,
                t8.address_line_1,t8.address_line_2,t8.city,t8.province,t8.postal_code
                FROM customer t1
                LEFT JOIN customer t2 ON t2.id = t1.parent_id
                LEFT JOIN `group` t3 ON t3.id=t1.group_id
                LEFT JOIN users t4 ON t4.id = t1.rep_user_id
                LEFT JOIN country t5 ON t5.id=t1.identity_reference_origin_country
                LEFT JOIN users t6 ON t6.id=t1.user_id
                LEFT JOIN contact t7 ON t7.customer_id=t1.id
                LEFT JOIN address t8 ON t8.customer_id=t1.id
                LEFT JOIN  
                (SELECT  MIN(id) AS 'id',customer_id 
                FROM  `external_system_reference`  
                WHERE  external_system_id=1
                GROUP BY  customer_id) 
                ext ON ext.customer_id=t1.id
                LEFT JOIN external_system_reference t9 ON t9.customer_id=t1.id AND ext.id=t9.id
                LEFT JOIN  
                (SELECT  MIN(id) AS 'id' 
                FROM  `status`  
                WHERE  `status`.process='identity_type' group BY status.id
                ) 
                stat ON stat.id=t1.identity_type_id
                LEFT JOIN status t10 ON t10.id=t1.identity_type_id AND stat.id=t10.id
                LEFT JOIN  
                (SELECT  MIN(id) AS 'id' 
                FROM  `status`  
                WHERE  `status`.process='payment_method' group BY status.id
                ) 
                stat2 ON stat2.id=t1.payment_method_id
                LEFT JOIN status t11 ON t11.id=t1.payment_method_id AND stat2.id=t11.id
                Where   ";

                if (empty($request->end_date)) {
                    $e_date=date("Y-m-d");
                    $request->end_date=$e_date;
                }
                if (empty($request->start_date)) {
                    $s_date=date("Y-m-d", strtotime("-3 months", strtotime(date("Y-m-d"))));
                    $request->start_date = $s_date;
                }

                $end_date=date('Y-m-d', strtotime($request->end_date)); 
                $start_date=date('Y-m-d', strtotime($request->start_date)); 

                $dataSql.= "t1.created_at >= '$start_date 00:00:00' AND  t1.created_at<= '$end_date 23:59:59' ";

                if ($request->filled("group")) {
                 $groups = implode(',', $request->input("group"));
                 $dataSql.=" AND t3.id IN ($groups) ";
                }

                if ($request->filled("parent")) {
                
                 $parents = implode(',', $request->input("parent"));
                 $dataSql.=" AND t1.parent_id IN ($parents) ";
                }

                if ($request->filled("repuser")) {
                 $reps = implode(',', $request->input("repuser"));
                 $dataSql.=" AND t1.rep_user_id IN ($reps) ";
                 }
        
               
               
            $data=\Illuminate\Support\Facades\DB::select($dataSql);
      
            $fileData = '';
            $order_id = "";
            $content = "Customer Code,Customer Name,BYD Number,Parent Customer,Customer Rep,Customer Group,Identity Type,Identity Reference Number,Document Expiry Date,";
            $content .="Country of Origin,Vat Registered,Vat Registration No,Payment Method,Status,Email,Cellphone,Address1,Address2,City,Province,Postal Code" . PHP_RN;
            foreach ($data as $v) {
                $detail = array();
                $detail[] = !empty($v->cust_code) ? $v->cust_code:'';
                $detail[] = !empty($v->cust_name) ? $v->cust_name:'';
                $detail[] = !empty($v->byd) ? $v->byd : "";
                $detail[] = !empty($v->parent_code) ? $v->parent_code : '';
                $detail[] = !empty($v->rep) ? $v->rep : '';
                $detail[] = !empty($v->group) ? $v->group : '';
                $detail[] = !empty($v->IdentyType) ? $v->IdentyType : '';
                $detail[] = !empty($v->identity_reference) ? $v->identity_reference : '';
                $detail[] = !empty($v->identity_reference_expiry_date) ? $v->identity_reference_expiry_date : '';
                $detail[] = !empty($v->country) ? $v->country : '';
                $detail[] = !empty($v->vat_reg) ? $v->vat_reg : '';
                $detail[] = !empty($v->vat_reg_no) ? $v->vat_reg_no : '';
                $detail[] = !empty($v->payment_method) ? $v->payment_method : '';
                $detail[] = !empty($v->status) ? $v->status : '';
                $detail[] = !empty($v->mail_address) ? $v->mail_address : '';
                $detail[] = !empty($v->cell_no) ? $v->cell_no : '';
                $detail[] = !empty($v->address_line_1) ? $v->address_line_1 : '';
                $detail[] = !empty($v->address_line_2) ? $v->address_line_2 : '';
                $detail[] = !empty($v->city) ? $v->city : '';
                $detail[] = !empty($v->province) ? $v->province : '';
                $detail[] = !empty($v->postal_code) ? $v->postal_code : '';


                $content .= implode(',', $detail) . PHP_RN;
            }

        $fileName = 'customerlist' . date('YmdHis') . '.csv';

        Storage::disk('local')->put('customer_list/' . $fileName, $content);
        return Storage::download('customer_list/' . $fileName);
    }

     /**
      * END
      *  Customer list report 
      */
}
