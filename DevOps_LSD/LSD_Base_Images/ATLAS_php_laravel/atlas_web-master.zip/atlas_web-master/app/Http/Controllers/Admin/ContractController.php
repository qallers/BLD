<?php

namespace App\Http\Controllers\Admin;

use App\Config;
use App\Contract;
use App\Customer;
use App\CustomerSplit;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ContractStoreRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\Admin\UpdateCustomerRequest;
use App\Http\Requests\Admin\StoreCustomerRequest;
use App\Network;
use App\Status;
use App\TierStage;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use RealRashid\SweetAlert\Facades\Alert;

class ContractController extends Controller {

    public function index() {

        $contracts = Contract::with("network")->get();
        return view('admin.contract.index', compact('contracts'));
    }

    public function edit(Contract $contract) {
        $network = Network::all();
        return view('admin.contract.edit', compact('contract', 'network'));
    }

    public function assign() {

        $contracts = Contract::with("network")->get();
        $data = Customer::whereIsActive(1)->get();
        return view('admin.contract.assign', compact('contracts', 'data'));
    }

    public function assign_contract(Request $request) {
        $data = $request->all();
        unset($data["customer_id"]);
        data_fill($data, "splits.*.customer_id", $request->input("customer_id"));
        CustomerSplit::where('customer_id', $request->input("customer_id"))->delete();
        CustomerSplit::insert($data["splits"]);
        return response()->json([
                    "Success" => "The customer's tiers has been successfuly added.",
                    "code" => 200
                        ], 200);
    }

    public function add_split($request) {
        $data = $request->all();
        
        unset($data["customer_id"]);
        unset($data["is_child"]);
        unset($data["network_id"]);
        unset($data["name"]);
        unset($data["ogr"]);
        unset($data["act"]);
        unset($data["sim"]);
        unset($data["is_split"]);
        unset($data["is_tiered"]);
        CustomerSplit::where('customer_id', $request->input("customer_id"))
                ->where('network_id', $request->input("network_id"))->delete();
        $data["splits"]=json_decode($data["splits"],true);
        if ($request->is_child == "true") {
            data_fill($data, "splits.*.customer_id", $request->input("customer_id"));
            data_fill($data, "splits.*.network_id", $request->input("network_id"));
            CustomerSplit::insert($data["splits"]);

            $childs = Customer::whereParentId($request->customer_id)->get();
            if ($childs->count() > 0) {
                foreach ($childs as $child) {
                    CustomerSplit::whereCustomerId($child->id)
                            ->whereNetworkId($request->network_id)->delete();
                    foreach ($data["splits"] as $split) {
                        if ($split["split_customer"] == "-1") {
                            $split["split_customer"] = $child->id;
                            $split["customer_id"] = $child->id;

                            Contract::whereCustomerId($split["customer_id"])
                                    ->whereNetworkId($split["network_id"])->delete();
                            Contract::create([
                                "name" => "Contract from Head Office",
                                "customer_id" => $child->id,
                                "is_tiered" => 0,
                                "ogr" => $split["ogr"],
                                "sim" => $split["sim"],
                                "act" => $split["act"],
                                "network_id" => $split["network_id"],
                                "is_split" => 1
                            ]);
                        } else {
                            $split["customer_id"] = $child->id;
                        }
                        CustomerSplit::insert($split);
                    }
                }
            }
        } else {
            data_fill($data, "splits.*.customer_id", $request->input("customer_id"));
            data_fill($data, "splits.*.network_id", $request->input("network_id"));
            CustomerSplit::insert($data["splits"]);
        }
    }

    public function add_tiers($request)
    {
        $data=$request->all();
        $data["tiers"]=json_decode($data["tiers"],true);
        data_fill($data,"tiers.*.customer_id",$request->input("customer_id"));
        data_fill($data,"tiers.*.network_id",$request->input("network_id"));
        TierStage::where('customer_id',$request->input("customer_id"))
                    ->where('network_id',$request->input("network_id"))
                    ->delete();
        TierStage::insert($data["tiers"]);
    }

    public function create() {

        $network = Network::all();
        return view('admin.contract.create', compact('network'));
    }

    public function update(ContractStoreRequest $request, Contract $contract) {
        if (!$request->has("is_tiered")) {
            $request->request->add(["is_tiered" => 0]);
        }
        if (!$request->has("is_split")) {
            $request->request->add(["is_split" => 0]);
        }
        $contract->update($request->all());
        if($request->filled("splits")){
            $this->add_split($request);
        }
        if($request->filled("tiers")){
            $this->add_tiers($request);
        }
        Alert::success("Success", "The contract has been updated.");
        return back();
    }

    public function show(Contract $contract) {
        if (!Gate::allows('view_contract')) {
            return abort(401);
        }

        return view('admin.contract.show', compact('customer'));
    }

    public function massDestroy(Request $request) {
        if (!Gate::allows('edit_customers')) {
            return abort(401);
        }
        User::whereIn('id', request('ids'))->delete();

        return response()->noContent();
    }

    public function store(ContractStoreRequest $request) {
        Contract::create($request->all());
        if($request->filled("splits")){
            $this->add_split($request);
        }
        if($request->filled("tiers")){
            $this->add_tiers($request);
        }
        Alert::success("Success", "The contract has been created.");
        return redirect()->back();
    }

    public function destroy(Contract $contract) {
        $contract->delete();
        return redirect()->route('admin.contract.index');
    }

    public function customer_contract($id) {
        $data = Customer::find($id);
        $contracts = Contract::all();
        $customer = Customer::whereIsActive(1)->get();
        $network = Network::all();
        $contract = null;
        $isContract = false;
        return view('admin.customer.contract', compact('data', 'contracts', 'customer', 'network', 'contract', 'isContract'));
    }

    public function customer_contract_network($id, $network_id) {
        $data = Customer::find($id);
        $customer = Customer::whereIsActive(1)->get();
        $network = Network::all();
        $contract = Contract::where('customer_id', $id)
                        ->where('network_id', $network_id)->first();
        $tiers = TierStage::where('customer_id', $id)
                        ->where('network_id', $network_id)->get();
        $split = CustomerSplit::with("splitCustomer")->where('customer_id', $id)
                ->where('network_id', $network_id)
                ->where('product_deal_id', null)
                ->where('product_id', null)
                ->where('split_deal_id', null)
                ->get();
        $current_network = $network->find($network_id);
        $isContract = true;
        $hasChild = Customer::whereParentId($id)->count();
        return view('admin.customer.contract', compact('data', 'hasChild', 'customer', 'network', 'tiers', 'contract', 'split', 'isContract', 'current_network'));
    }

    public function customer_contract_network_show($id, $network_id) {
        $customer = Customer::where("id", $id)->get()->first();

        $customer_child = Customer::whereIsActive(1)->get();
        $network = Network::all();
        $contract = Contract::where('customer_id', $id)
                        ->where('network_id', $network_id)->first();
        $tiers = TierStage::where('customer_id', $id)
                        ->where('network_id', $network_id)->get();
        $split = CustomerSplit::with("splitCustomer")->where('customer_id', $id)
                ->where('network_id', $network_id)
                ->where('product_deal_id', null)
                ->where('product_id', null)
                ->get();
        $current_network = $network->find($network_id);
        $isContract = true;
        $hasChild = Customer::whereParentId($id)->count();
        return view('admin.customer.show', compact('hasChild', 'customer', 'customer_child', 'network', 'tiers', 'contract', 'split', 'isContract', 'current_network'));
    }
}
