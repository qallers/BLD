<?php

namespace App\Http\Controllers\Traits;

use App\Config;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
//use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Document;
use App\ExternalSystem;
use App\ExternalSystemReference;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Exception\ServerException;
use GuzzleHttp\Exception\ClientException;


use App\Http\Controllers\Traits\HttpController;
use App\Status;
use Exception;
use Illuminate\Support\Facades\Auth;

global $SignatureID;
global $popFolderID;
global $PersonPicFolderID;
global $idFolderID;
global $contractFolderID;

trait Safe4Controller
{

    //use HttpControllerModified;
    use HttpController;

    //Configuration



    private $safe4_username = "T3T_ADMIN";
    private $safe4_api_key = "97e31740d11523a8f0a037898d3fc0f34c6c22373f249265288a89d08681256b";
    //private $safe4_base_url = "https://safe-4.com/api/version";
    private $safe4_base_url = "https://www.safe-4.com/api/version";
    private $safe4_vault_to_copy = "45639";

    public function __construct()
    {
    }

    function initSafe4()
    {
        $config = Config::select("value", "key")->whereIn('key', ['safe4_username', 'safe4_api_key', 'safe4_base_url', 'safe4_vault_to_copy'])->get()->pluck('value', 'key');
        $this->safe4_username = $config["safe4_username"];
        $this->safe4_api_key = $config["safe4_api_key"];
        $this->safe4_base_url = $config["safe4_base_url"];
        $this->safe4_vault_to_copy = $config["safe4_vault_to_copy"];
    }

    public function uploadToSafe4($customer, $user, $request)
    {
        try{
        $this->initSafe4();
        $customer_id = $customer->id;
        if($request->hasFile('id_proof') && $request->hasFile('contract') && $request->hasFile('residence') && $request->hasFile('selfie')){
            $request->file("id_proof")->move(storage_path("/safe4/" . $customer_id), $request->file("id_proof")->getClientOriginalName());
            $request->file("contract")->move(storage_path("/safe4/" . $customer_id), $request->file("contract")->getClientOriginalName());
            $request->file("residence")->move(storage_path("/safe4/" . $customer_id), $request->file("residence")->getClientOriginalName());
            $request->file("selfie")->move(storage_path("/safe4/" . $customer_id), $request->file("selfie")->getClientOriginalName());    
            $data=[
                "id_proof"=>"/safe4/" . $customer_id."/".$request->file("id_proof")->getClientOriginalName(),
                "id_proof_name"=>$request->file("id_proof")->getClientOriginalName(),
                "contract"=>"/safe4/" . $customer_id."/".$request->file("contract")->getClientOriginalName(),
                "contract_name"=>$request->file("contract")->getClientOriginalName(),
                "residence"=>"/safe4/" . $customer_id."/".$request->file("residence")->getClientOriginalName(),
                "residence_name"=>$request->file("residence")->getClientOriginalName(),
                "selfie"=>"/safe4/" . $customer_id."/".$request->file("selfie")->getClientOriginalName(),
                "selfie_name"=>$request->file("selfie")->getClientOriginalName(),
            ];
            ExternalSystemReference::create([
                "external_system_id" => -1,
                "reference" => "temp_doc",
                "data" => json_encode($data),
                "customer_id" => $customer_id
            ]);
            $customer->status_id=Status::whereProcess("new_customer")->whereStatus("fica_no_safe4")->first()->id;
            $customer->save();
            $this->uploadTosafe4Server($customer,$user);
        }else{
            $customer->Status::whereProcess("new_customer")->whereStatus("fica_no_doc")->first()->id;
            $customer->save();
        }
    }catch(Exception $e){
        $customer->Status::whereProcess("new_customer")->whereStatus("fica_no_doc")->first()->id;
        $customer->save();
    }
    }

    public function uploadTosafe4Server($customer,$user)
    {
        $this->initSafe4();
        $customer_id = $customer->id;
        if (config('app.debug')) {
            $company_name = "test_" . $customer->name . "_" . $customer_id . "_" . $user->username;
        } else {
            $company_name = $customer->name . "_" . $customer_id . "_" . $user->username;
        }
        $d=ExternalSystemReference::whereCustomerId($customer_id)
                                    ->whereReference("temp_doc")
                                    ->whereExternalSystemId(-1)->first();
        if(!empty($d)){
            $providerID = "37865";
            $vaultID = "";
            $sessionKey = $this->getSessionKey();
            $vaultResponse = $this->createVaultCopyStructure($providerID, $company_name, $sessionKey);

            if (isset($vaultResponse['id'])) {
                $vaultID =  $vaultResponse['id'];
            }
            //dump($vaultID);
            $data=json_decode($d->data,true);
            $folderStructure = $this->getFolderStructure($providerID, $vaultID, $sessionKey);
            //logger($folderStructure);
            //print_r($folderStructure);

            $decodedFolders = json_decode($folderStructure);
            //dd($decodedFolders);
            $foldersOnly = $decodedFolders->{'folders'};
            $this->manipulateSubFolderStructure($foldersOnly);
            global $popFolderID;
            global $PersonPicFolderID;
            global $idFolderID;
            global $contractFolderID;
            
            if (isset($idFolderID) && isset($vaultID)) {
                //Store Folder ID in the DB
                $idurl = $this->uploadDocument($providerID, $vaultID, $sessionKey, storage_path($data["id_proof"]),$data["id_proof_name"], $idFolderID);
                if (isset($idurl)) {
                    unlink(storage_path($data["id_proof"]));
                }
            }
        
            if (isset($contractFolderID) && isset($vaultID)) {
                //Store Folder ID in the DB
                $contracturl = $this->uploadDocument($providerID, $vaultID, $sessionKey, storage_path($data["contract"]), $data["contract_name"], $idFolderID);
                if (isset($contracturl)) {
                    unlink(storage_path($data["contract"]));
                }
            }
            
            if (isset($popFolderID) && isset($vaultID)) {
                //Store Folder ID in the DB
                $popurl = $this->uploadDocument($providerID, $vaultID, $sessionKey, storage_path($data["residence"]), $data["residence_name"], $idFolderID);
                if (isset($popurl)) {
                    unlink(storage_path($data["residence"]));
                }
            }
        
            if (isset($PersonPicFolderID) && isset($vaultID)) {
                //Store Folder ID in the DB
                $personpicurl = $this->uploadDocument($providerID, $vaultID, $sessionKey, storage_path($data["selfie"]), $data["selfie_name"], $idFolderID);
                if (isset($personpicurl)) {
                    unlink(storage_path($data["selfie"]));
                }
            }


            // make json structure
            $data = '{"vault_id": "' . $vaultID . '", "folders": {
                "folder": [{
                "type": "id",
                "id": "' . $idFolderID . '",
                "url":"' . $idurl . '"
                },{
                "type": "merchant_contract",
                "id": "' . $contractFolderID . '",
                "url": "' . $contracturl . '"
                },{
                "type": "proof_of_residence",
                "id": "' . $popFolderID . '",
                "url": "' . $popurl . '"
                },{
                "type": "selfie",
                "id":"' . $PersonPicFolderID . '",
                "url":"' . $personpicurl . '"
                },{
                "type": "signature",
                "id": "",
                "url": ""
                },{
                "type": "signature",
                "id": "",
                "url": ""
                }
                ]}}';

            $e = ExternalSystem::whereDescription("Safe-4")->first();
            ExternalSystemReference::create([
                "external_system_id" => $e->id,
                "reference" => "Safe-4",
                "data" => $data,
                "customer_id" => $customer_id
            ]);
            $customer->status_id=Status::whereProcess("new_customer")->whereStatus("fica_approval")->first()->id;
            $customer->save();
        }
    }

    public function  manipulateSubFolderStructure($folderStructure)
    {

        array_map(function ($arrFolders) {
            global $SignatureID;
            global $popFolderID;
            global $PersonPicFolderID;
            global $idFolderID;
            global $contractFolderID;

            switch ($arrFolders->{'folder_name'}) {

                case 'Merchant Contract':
                    $contractFolderID = $arrFolders->{'id'};

                    break;
                case 'ID':
                    $idFolderID = $arrFolders->{'id'};


                    break;
                case 'Selfie':
                    $PersonPicFolderID = $arrFolders->{'id'};

                    break;
                case 'Proof of Residence':
                    $popFolderID = $arrFolders->{'id'};

                    break;
                case 'Signature':
                    $SignatureID = $arrFolders->{'id'};
                    break;
                default:
                    break;
            }




            if (count($arrFolders->{'folders'}) > 0) {

                $this->manipulateSubFolderStructure($arrFolders->{'folders'});
            }

            //return $localFolderID;

        }, $folderStructure);
    }
    public function getSessionKey()
    {


        $username = $this->safe4_username;
        $api_key =  $this->safe4_api_key;

        //Get IDs

        $arrCredentials = array(
            "username" => $username,
            "api_key" => $api_key,
            "api_version" => "1.0"
        );


        //Staging
        $url = $this->safe4_base_url . '/login';

        //$url = "http://crm.localhost/api/test";


        $headers = array();
        //$headers1 = array('Content-Type'=>'application/json');
        //Log::info($url);
        $result = $this->post($url, $headers, $arrCredentials);

        //return $result;
        if (isset($result->{'session_key'})) {
            return $result->{'session_key'};
        }

        return null;
    }

    public function killSessionKey($sessionKey)
    {

        $url = $this->safe4_base_url . "/logout";

        $headers = array(
            "SAFE4SESSIONKEY:$sessionKey",
            //'Content-Type'=>'application/json'
        );

        $this->get($url, $headers);
    }

    public function getSessionKeyWithParams($username, $api_key)
    {

        $arrCredentials = array(
            "username" => $username,
            "api_key" => $api_key,
            "api_version" => "1.0"
        );


        //Staging
        $url = $this->safe4_base_url . '/login';


        $headers = array();
        //$headers1 = array('Content-Type'=>'application/json');
        //Log::info($url);
        $result = $this->post($url, $headers, $arrCredentials);

        if (isset($result->{'session_key'})) {
            return $result->{'session_key'};
        }

        return null;
    }

    public function createVault($providerID, $company_name, $sessionKey = null)
    {

        if ($sessionKey == null) {
            $sessionKey = $this->getSessionKey();
        }

        //$providerID = config('app.safe4_provider_id');
        $url = $this->safe4_base_url . "/providers/$providerID/clients";

        $headers = array(
            "SAFE4SESSIONKEY" => $sessionKey,
            //'Content-Type'=>'application/json'
        );

        $body = array(
            'company_name' => $company_name
        );

        $response = $this->post($url, $headers, $body);

        if (isset($response->{'id'})) {

            echo json_encode($response);
            return array(
                'id' => $response->{'id'},
                'sessionKey' => $sessionKey,
                'root_folder_id' => null
            );
        } else {
            return null;
        }


        // }
        /* else{
            return array(
                'id'=>$doc->vault_id,
                'sessionKey'=>$sessionKey,
                'root_folder_id'=>$doc->root_folder_id
            );
        } */
    }

    public function createVaultCopyStructure($providerID, $company_name, $sessionKey, $vaultToCopy = null)
    {

        if ($vaultToCopy == null) {
            $vaultToCopy = $this->safe4_vault_to_copy;
        }

        //$providerID = config('app.safe4_provider_id');
        $url = $this->safe4_base_url . "/providers/$providerID/clients/$vaultToCopy/copy";
        //  echo "<br/>";
        //  echo "sessionkey ".$sessionKey;
        //  echo "<br/>";
        $headers = array(
            "SAFE4SESSIONKEY" => $sessionKey,
            //'Content-Type'=>'application/json'
        );

        $body = array(
            'company_name' => $company_name,
            'copyfolders' => 'true',
            'copypermissions' => 'false'
        );
        //   echo "body ".json_encode($body);
        //   echo "<br/>";

        $response = $this->post($url, $headers, $body);
        //  echo "response ".json_encode($response);
        activity()
            ->causedBy(Auth::user())
            ->withProperties(['request' => json_encode($body), 'response' => json_encode($response)])
            ->log('SAFE4_COPY_STRUCTURE');
        if (isset($response->{'id'})) {
            return array(
                'id' => $response->{'id'},
                'sessionKey' => $sessionKey,
                'root_folder_id' => null
            );
        }

        return null;
    }

    public function getFolderStructure($providerID, $vaultID, $sessionKey)
    {


        $endpoint = $this->safe4_base_url . "/providers/$providerID/clients/$vaultID/folders";


        $headers = array(
            "SAFE4SESSIONKEY" => $sessionKey,
            //'Content-Type'=>'application/json'
        );

        $response = $this->get($endpoint, $headers);

        return $response;
    }

    public function createRootFolder($providerID, $vaultID, $sessionKey, $folderName)
    {

        //$providerID = config('app.safe4_provider_id');
        $url = $this->safe4_base_url . "/providers/$providerID/clients/$vaultID/folders/0";



        $headers = array(
            "SAFE4SESSIONKEY" => $sessionKey,
            //'Content-Type'=>'application/json'
        );

        $body = array(
            'folder_name' => $folderName
        );
        $this->post($url, $headers, $body);

        $response = $this->post($url, $headers, $body);

        if (isset($response->{'id'})) {
            return $response->{'id'};
        } else {
            echo json_encode($response);
            //return json_encode($response);
        }

        return null;
    }

    public function createFolder($providerID, $vaultID, $sessionKey, $folderName, $rootFolderID)
    {

        //$providerID = config('app.safe4_provider_id');
        $url = $this->safe4_base_url . "/providers/$providerID/clients/$vaultID/folders/$rootFolderID";


        $headers = array(
            "SAFE4SESSIONKEY" => $sessionKey,
            //'Content-Type'=>'application/json'
        );

        $body = array(
            "folder_name" => $folderName
        );

        $response = $this->post($url, $headers, $body);

        if (isset($response->{'id'})) {
            return $response->{'id'};
        } else {
            return json_encode($response);
        }

        return null;
    }

    public function createSecurityGroup($providerID, $sessionKey, $groupName)
    {
        //$providerID = config('app.safe4_provider_id');
        $url = $this->safe4_base_url . "/providers/$providerID/groups";

        $headers = array(
            "SAFE4SESSIONKEY" => $sessionKey,
            //'Content-Type'=>'application/json'
        );

        $body = array(
            "group_type_name" => $groupName,
            "can_upload_file" => "false",
            "can_rename_file" => "false",
            "can_delete_file" => "false",
            "can_move_file" => "false",
            "can_add_folder" => "false",
            "can_rename_folder" => "false",
            "can_delete_folder" => "false",
            "can_move_folder" => "false"
        );

        $response = $this->post($url, $headers, $body);

        return $response;
    }

    public function applySecurityGroup($providerID, $vaultID, $sessionKey, $folderID, $arrSecurityGroup)
    {

        //$providerID = config('app.safe4_provider_id');
        $url = $this->safe4_base_url . "/providers/$providerID/clients/$vaultID/folders/$folderID/groups";
        //Log::info("Apply security group url: $url");
        //Log::info("Security group ID: $groupID");
        $headers = array(
            "SAFE4SESSIONKEY" => $sessionKey,
        );

        $adminGroup = config('app.trueid_admin_group');

        //Add admin group id to the list
        array_push($arrSecurityGroup, (int)$adminGroup);
        $body = array(
            "byName" => false,
            "groups" => $arrSecurityGroup,
            "applyToChildren" => false
        );

        $response = $this->put($url, $headers, $body);

        //Log::info(json_encode($response));
    }

    public function createUser($sessionKey, $providerID, $vaultID, $username, $password)
    {
        // $providerID = config('app.safe4_provider_id');
        $url = $this->safe4_base_url . "/providers/$providerID/clients/$vaultID/users";

        $headers = array(
            "SAFE4SESSIONKEY" => $sessionKey,
            //'Content-Type'=>'application/json'
        );

        $body = array(
            "username_1" => $username,
            "password_1" => $password
        );

        $response = $this->post($url, $headers, $body);


        return $response;
    }

    public function updateUserAccount($sessionKey, $providerID, $vaultID, $user_id, $securityGroupID, $uID)
    {
        //$providerID = config('app.safe4_provider_id');
        $url = $this->safe4_base_url . "/providers/$providerID/clients/$vaultID/users/$user_id";

        $url = str_replace("version", "1.0", $url);

        //Log::info("Url: $url");
        $headers = array(
            "SAFE4SESSIONKEY" => $sessionKey,
        );

        $body = array(
            "first_name" => $uID,
            "last_name" => "Not set",
            "job_title" => "",
            "email_address" => "$uID@example.com",
            "mobile_number" => "",
            "home_phone_number" => "",
            "work_phone_number" => "",
            "is_active" => true,
            "recIDs" => [(int)$securityGroupID]
        );

        //Log::info(json_encode($body));
        $response = $this->put($url, $headers, $body);
        //Log::info(json_encode($response));
    }

    public function addUserToVault($providerID, $sessionKey, $vaultID, $user_id)
    {

        //$providerID = config('app.safe4_provider_id');
        $url = $this->safe4_base_url . "/providers/$providerID/clients/$vaultID/users/$user_id/add";

        //$url = str_replace("version","1.0",$url);

        //Log::info("Url: $url");
        $headers = array(
            'SAFE4SESSIONKEY' => $sessionKey
        );

        $this->get($url, $headers);
    }

    public function uploadDocument($providerID, $vaultID, $sessionKey, $filePath, $fileName, $folderID)
    {


        $url = $this->safe4_base_url . "/providers/$providerID/clients/$vaultID/folders/$folderID/files";

        $client = new Client();
        $res = $client->request(
            'POST',
            $url,
            [
                'headers'  => ['SAFE4SESSIONKEY' => $sessionKey],
                'multipart' => [
                    [
                        'name'     => 'Filedata',
                        'contents' => fopen($filePath, 'r'),
                        'filename' => $fileName
                    ]
                ]

            ]

        );

        $status_code = $res->getStatusCode();

        //$header = $res->getHeaderLine('content-type');
        $body = $res->getBody();
        $decodedBody = json_decode($body);
        activity()
            ->causedBy(Auth::user())
            ->withProperties(['request' => $url, 'response' => $decodedBody])
            ->log('SAFE4_UPLOAD');
        $url = $decodedBody->{'url'};

        $url = str_ireplace("safe-4.com", "safe-4.com/api/version", $url);
        $url = str_ireplace("folders", "folders/", $url);

        // Log::info('Upload Body: '.$url);

        return $url;
    }

    public function uploadDocumentToVault($providerID, $vaultID, $sessionKey, $filePath, $fileName, $folderID)
    {

        if ($sessionKey == null) {
            $sessionKey = $this->getSessionKey();
        }
        //$providerID = config('app.safe4_provider_id');
        $url = $this->safe4_base_url . "/providers/$providerID/clients/$vaultID/folders/$folderID/files";

        $client = new Client();
        $res = $client->request(
            'POST',
            $url,
            [
                'headers'  => ['SAFE4SESSIONKEY' => $sessionKey],
                'multipart' => [
                    [
                        'name'     => 'Filedata',
                        'contents' => fopen($filePath, 'r'),
                        'filename' => $fileName
                    ]
                ]

            ]

        );

        $status_code = $res->getStatusCode();

        //$header = $res->getHeaderLine('content-type');
        $body = $res->getBody();
        $decodedBody = json_decode($body);
        $url = $decodedBody->{'url'};

        $url = str_ireplace("safe-4.com", "safe-4.com/api/version", $url);
        $url = str_ireplace("folders", "folders/", $url);

        //Log::info('Upload Body: '.$url);

        return $url;
    }


    public function downloadFile($endpoint, $sessionKey)
    {
        //Log::info("Attempt to fetch Vault document");
        //echo $endpoint;
        /*if($sessionKey == null){
            $sessionKey = $this->getSessionKey();
        }*/

        $headers = array("SAFE4SESSIONKEY" => $sessionKey);

        $response = $this->get($endpoint, $headers);

        if (isset($response)) {
            //Log::info("Done fetching document from vault");
            //Log::info($responseContent);
            //$body = $response->getBody();
            //echo 'in '.$body;
            //echo $response;
            return $response;
        } else {
            //echo 'out ';
            return null;
        }
    }
}
