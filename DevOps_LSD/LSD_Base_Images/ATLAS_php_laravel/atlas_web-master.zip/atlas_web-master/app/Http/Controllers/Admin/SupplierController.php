<?php

namespace App\Http\Controllers\Admin;

use App\Supplier;
use App\DB;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreSupplierRequest;
use App\Http\Requests\Admin\UpdateSupplierRequest;
Use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use App\Address;
use App\Contact;
use App\Status;
use App\Group;
use App\Http\Controllers\Traits\NavisionHelperTraits;
use Exception;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class SupplierController extends Controller {

    use NavisionHelperTraits;

    public function index() {
        if (!Gate::allows('view_suppliers')) {
            return abort(401);
        }

        $supplier = Supplier::all();

        return view('admin.supplier.index', compact('supplier'));
    }

    /**
     * Show the form for creating new product.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        if (!Gate::allows('add_supplier')) {
            return abort(401);
        }
        $addresstype = Status::whereProcess('address_type')->get();
        $identity = Status::whereProcess('identity_type')->get();
        $group = Group::all();

        return view('admin.supplier.create', compact('identity', 'group', 'addresstype'));
        }

        public function list(Request $request) {
        if (!Gate::allows('view_suppliers')) {
            return abort(401);
        }

        $data = Supplier::select("id", "name", "is_active", "created_at");

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }


        return datatables()->of($data)
                        ->make();
    }

    function addsupplier(Request $request) {
        if($this->isEnabled()){
            try{
                $address=null;
                if($request->filled('address')){
                    $address = Address::find($request->address[0]);
                }
                $this->nav_post("Vendor_Card",[
                    "No"=>Str::slug($request->name,""),
                    "Name"=>$request->name,
                    "Address"=>$address!=null?$address->address_line_1:"",
                    "Address_2"=>$address!=null?$address->address_line_2:"",
                    "Post_Code"=>$address!=null?$address->postal_code:"",
                    "City"=>$address!=null?$address->postal_code:"",
                ]);
            }catch(Exception $exception){
                Alert::error('Error.', "Supplier is already available in Navision.\n".$exception->getMessage());
                return redirect()->route('admin.supplier.index');
            }
        }
        $user_id = Auth::user()->user_type_id == 2 ? Auth::user()->id : -1;
        $request->request->add(['user_id' => $user_id]);
        $supplier = Supplier::create($request->except(['contact', 'address']));
        if ($request->filled('address')) {
            foreach ($request->address as $key => $id) {
                $address = Address::find($id);
                $address->customer_id = $supplier->id;
                $address->save();
            }
        }
        if ($request->filled('contact')) {
            foreach ($request->contact as $key => $id) {
                $contact = Contact::find($id);
                $contact->customer_id = $supplier->id;
                $contact->save();
            }
        }
        Alert::success('Success', "The supplier has been created.");
        return redirect()->route('admin.supplier.index');
    }

    public function show(Supplier $supplier) {
        if (!Gate::allows('view_suppliers')) {
            return abort(401);
        }

        return view('admin.supplier.show', compact('supplier'));
    }

    /* update suplier */

    public function edit(Supplier $supplier) {
        if (!Gate::allows('edit_supplier')) {
            return abort(401);
        }
        $addresstype = Status::whereProcess('address_type')->get();
        $identity = Status::whereProcess('identity_type')->get();
        $group = Group::all();

        return view('admin.supplier.edit', compact('supplier', 'identity', 'group', 'addresstype'));
    }

    public function update(UpdateSupplierRequest $request, Supplier $supplier) {

        $supplier->update($request->except(['contact', 'address']));
        if ($request->filled('address')) {
            foreach ($request->address as $key => $id) {
                $address = Address::find($id);
                $address->customer_id = $supplier->id;
                $address->save();
            }
        }
        if ($request->filled('contact')) {
            foreach ($request->contact as $key => $id) {
                $contact = Contact::find($id);
                $contact->customer_id = $supplier->id;
                $contact->save();
            }
        }
        Alert::success('Success', "The supplier has been updated.");
        return redirect()->route('admin.supplier.index');
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Supplier::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The supplier has been $msg successfully"
        ]);
    }

}
