<?php

namespace App\Http\Controllers\Api;

use App\Config;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\PurchaseOrderTrait;
use \App\Http\Controllers\Traits\RepOrderTrait;
use App\Http\Requests\Admin\StoreOgrRequest;
use Illuminate\Support\Facades\Auth;
use App\Notification;
use Response;
use App\Status;
use App\PurchaseOrder;
use RealRashid\SweetAlert\Facades\Alert;
use App\Notifications\PurchaseOrderApproved;
use App\Notifications\PurchaseOrderCreated;
use App\Notifications\RepOrderApproved;
use App\Notifications\RepOrderCreated;
use App\Stock;
use Exception;
use Illuminate\Support\Facades\DB;

class PurchaseOrderController extends Controller {

    use PurchaseOrderTrait;
    use \App\Http\Controllers\Traits\NotificationTraits;

    public function reject($id) {
        $order = PurchaseOrder::with("status")->where("id", $id)->get()->first();
        $soaa = Config::where("key", "purchase_order_apply_approval")->first();
        if ($order->status->id != $soaa->value) {
            Alert::error('Error!', 'You cannot reject an approved order');
        } else {
            $status = Status::where('process', 'purchase_order')->where('status', 'rejected')->get()->first();
            PurchaseOrder::where('id', $id)
                    ->update(['status_id' => $status->id]);
            Alert::success('Success', 'Order has been rejected.');
        }
        return back();
    }

    public function reject_rep($id) {
        $order = PurchaseOrder::with("status")->where("id", $id)->get()->first();
        $soaa = Config::where("key", "rep_order_apply_approval")->first();
        if ($order->status->id != $soaa->value) {
            Alert::error('Error!', 'You cannot reject an approved order');
        } else {
            $status = Status::where('process', 'rep_order')->where('status', 'rejected')->get()->first();
            PurchaseOrder::where('id', $id)
                    ->update(['status_id' => $status->id]);
            Alert::success('Success', 'Order has been rejected.');
        }
        return back();
    }

    public function update_status(Request $request) {
        PurchaseOrder::where('id', $request->input("id"))
                ->update(['status_id' => $request->input("status")]);

        $user = auth()->user();

        $order = PurchaseOrder::with("product", "warehouse")->where("id", $request->input("id"))->get()->first();

        $sl = array();
        $sl['user_id'] = Auth::user()->id;
        $sl['order_id'] = $request->input("id");
        $sl['qty'] = 0;
        $sl['status_id'] = $request->input("status");

        $sl['order_name'] = "PURCHASE";
        $sl['process_name'] = "update_status";

        \App\StockLedger::create($sl);

        Notification::create([
            'from_user' => $user->id,
            'to_user' => 1,
            'title' => $order->warehouse->description . ' has received your order',
            'message' => $order->product->description . " product received by " . $order->warehouse->description . ' warehouse',
            'type' => "Received",
            "url" => "admin/purchase/"
        ]);

        return response()->json([
                    "msg" => "Status has been updated successfully.",
                    "code" => 200
        ]);
    }


    
    public function scan_stock_rep(Request $request) {

        $input = str_replace(' ', '', $request->input("number"));
        $po = $request->input('order_id');
        $product_id = $request->input('product_id');

        $data = DB::table('grv')->where("is_transfer", 0)->where(function ($query) use ($input) {
                    $query->where("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input);
                })->get();

        $affected = count($data);

        if (empty($affected)) {
            return responder()->error(500, "Box is already scanned/Invalid.")->respond(500);
        }
        $user = auth()->user();
        $cnt = Stock::where("serial_no", $data[0]->serial_no)->where("warehouse_id", $user->warehouse_id)->where("product_id", $product_id)->count();

        if ($affected > 0 && !empty($cnt)) {
            DB::update("update grv set is_transfer = 1 where is_transfer = 0 AND (pallet = '$input' OR carton = '$input' OR box = '$input' OR brick = '$input')");

            \App\PurchaseOrder::where('id', $po)
                    ->update(['scanned_qty' => DB::raw('scanned_qty + ' . $affected)]);

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $request->input('pid');
            $sl['qty'] = $affected;
            $sl['order_name'] = "REP";
            $sl['process_name'] = "verify_order";

            \App\StockLedger::create($sl);
            $request->request->add([
                "qty" => $affected
            ]);
            return responder()->success($request->all())->respond(200);
        } else {
            return responder()->error(500, "Stock is not belong to this warehouse OR product mismatch")->respond(500);
        }
    }

}
