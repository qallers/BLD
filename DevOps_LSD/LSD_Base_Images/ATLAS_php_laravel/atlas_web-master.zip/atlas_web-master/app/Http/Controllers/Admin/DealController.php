<?php

namespace App\Http\Controllers\Admin;

use App\Config;
use App\Contract;
use App\Customer;
use App\CustomerSplit;
use App\Group;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ContractStoreRequest;
use App\Http\Requests\Admin\ProductDealStoreRequest;
use App\Http\Requests\Admin\UpdateProductDealRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\Admin\UpdateCustomerRequest;
use App\Http\Requests\Admin\StoreCustomerRequest;
use App\Network;
use App\Product;
use App\ProductDeal;
use App\Status;
use App\TierStage;
use App\User;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Log;

class DealController extends Controller {

    public function index() {

        // $deals = ProductDeal::with("product")->get() where is_active=1; 
        $deals = ProductDeal::where('is_active', 1)->get();
        return view('admin.deal.index', compact('deals'));
        }

        public function list(Request $request) {

        $data = ProductDeal::with("product", "group", "customer");

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }
        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }

        return datatables()->of($data)
                        ->make();
    }

    public function edit($ID) {
        $network = Network::all();
        $productdeal = ProductDeal::find($ID);
        $product = Product::all();
        $group = Group::all();
        $currentgroup = Group::find($productdeal->customer_group_id);
        $currentproduct = Product::find($productdeal->product_id);

        return view('admin.deal.edit', compact('network', 'productdeal', 'product', 'group', 'currentgroup', 'currentproduct'));
    }

    public function create() {

        $product = Product::all();
        $group = Group::all();

        return view('admin.deal.create', compact('product', 'group'));
    }

    public function update(UpdateProductDealRequest $request, $ID) {
        $productdeal = ProductDeal::find($ID);
        // dd($productdeal);
        // dd($request->all());
        // die;
        //    dd($productdeal);
        //    die;
        $productdeal->update($request->all());
        Alert::success('Success', "The Product Deal has been updated.");
        // return redirect()->back();
        return redirect()->route('admin.deal.index');
    }

    public function show($ID) {
       
        $productdeal = ProductDeal::find($ID);
        $product = Product::find($productdeal->product_id);
        $group = Group::find($productdeal->customer_group_id);

        return view('admin.deal.show', compact('productdeal', 'product', 'group'));
    }

    public function store(ProductDealStoreRequest $request) {
        ProductDeal::create($request->all());
        Alert::success('Success', "The Product Deal has been created.");
        return redirect()->route('admin.deal.index');
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        ProductDeal::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The product deal has been $msg successfully."
        ]);
    }

    public function destroy(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 0;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 1;
        }
        ProductDeal::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The product deal has been $msg successfully."
        ]);
    }

    public function massDestroy(Request $request) {
        if (!Gate::allows('edit_product_deal')) {
            return abort(401);
        }
        ProductDeal::whereIn('id', request('ids'))->update(['is_active' => 0]);
        Alert::success('Success', "The selected Product Deals have been made inactive.");
        return response()->noContent();
    }

    public function view_deals(Request $request)
    {
        $products=Product::whereisActive(1)->get();
        $customer=Customer::whereIsActive(1)->get();
        return view('order.deals.index',compact('products','customer'));
    }

}
