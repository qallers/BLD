<?php

namespace App\Http\Controllers\Traits;

use App\Box;

trait ParentChildTrait
{
    protected $ChildrenData=[];
    public function getChildBox($id){ 
        $childs= Box::whereParentId($id)->pluck("id");
        if($childs->count()>0){
            foreach($childs as $c){
                $this->getChildBox($c);
            }
            $this->ChildrenData[]=$id;
        }else{
            $this->ChildrenData[]=$id;
        }
        return $this->ChildrenData;
    }
}