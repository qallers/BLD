<?php

namespace App\Http\Controllers\Admin;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Flash;
use Response;
use App\Approvals;
use App\ApprovalStages;
use App\Config;
use App\StagesRoles;
use App\Status;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Spatie\Activitylog\Models\Activity;
use Spatie\Permission\Models\Role;
use RealRashid\SweetAlert\Facades\Alert;

class ApprovalController extends Controller
{
    /**
     * Display a listing of the Admin/audits.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var Admin/audits $admin/audits */

        $data = Approvals::with('stages','stages.approved_by',"stages.approved_by.roles")->get();
        $config = Config::select("value","key")
                    ->whereIn('key',['sales_order_approval','mobile_invoice_approval','return_stock_approval','rep_order_approval','purchase_order_approval','manufacture_stock_approval'])
                    ->get()->pluck('value','key');
        $roles = Role::all();
        $status = Status::all();
        $sales_order=Status::where("process","sales_order")->get();
        $purchase_order=Status::where("process","purchase_order")->get();
        $rep_order=Status::where("process","rep_order")->get();
        $manufacture_stock=Status::where("process","manufacture_stock")->get();
        $return_stock=Status::where("process","return_stock")->get();
        $mobile_invoice=Status::where("process","mobile_invoice")->get();

        $config_new = Config::select("value","key")->get()->pluck('value','key');
       

        return view('admin.approvals.index',compact('data','roles','config', 'sales_order','purchase_order','manufacture_stock','rep_order', 'status', 'config_new','return_stock','mobile_invoice'));
    }


    public function store(Request $request) {
        $request->merge(['name' =>$request->input('approval_name') ]);
        $approval = Approvals::create($request->only('name', 'process','status'));
        foreach ($request->stages as $key => $value) {
            $value["approval_id"]=$approval->id;
            $a=ApprovalStages::create($value);
            foreach (explode(",",$value['roles']) as $role) {
                StagesRoles::insert(["stage_id"=>$a->id,"role_id"=>$role]);
            }
        }
        Session::flash('message', 'Your stage has been created successfully.'); 
        return redirect()->route('admin.approvals.index');
    }


    public function edit($id) {
        $roles = Role::all();
        $approvals=Approvals::find($id);
        $approvals->load('stages','stages.approved_by',"stages.approved_by.roles");
        return view('admin.approvals.edit', compact('approvals','roles'));
    }

    public function update(Request $request,$id) {
        $data=$request->all();
        $data["name"]=$data["approval_name"];
        unset($data["approval_name"]);
         $approvals=Approvals::find($id);
         $approvals->update($data);
         if($request->filled("stages")){
         foreach ($request->stages as $key => $value) {
            $value["approval_id"]=$id;
            $r=$value["roles"];
            unset($value["roles"]);
            $a=ApprovalStages::create($value);
            foreach (explode(",",$r) as $role) {
                StagesRoles::insert(["stage_id"=>$a->id,"role_id"=>$role]);
            }
        }
    }
         
            return redirect()->route('admin.approvals.index');
     }

     public function updateStage(Request $request) {

            ApprovalStages::find($request->input("stage_id"))->update($request->only('name','priority'));
            if($request->filled("roles")){
                StagesRoles::where('stage_id',$request->input("stage_id"))->delete();
                foreach ($request->input("roles") as $role) {
                    StagesRoles::updateOrCreate(["stage_id"=>$request->input("stage_id")],["role_id"=>$role]);
                }
            }
            
            return response()->json([
                "msg"=>"Stage has been updated successfully",
                "code"=>200
            ], 200);
     }
 

    // public function show(Approvals $approval) {
        
    //    print_r($approval);
    // }


    public function destroy(Approvals $approvals) {
        
        $approvals->delete();

        return redirect()->route('admin.approvals.index');
    }

    public function destroyStage($id) {
        $r=ApprovalStages::destroy($id);
        $r=StagesRoles::where("stage_id",$id)->delete();
        return response()->json([
            "msg"=>"Stage has been deleted successfully",
            "code"=>200
        ], 200);
    }
   
}