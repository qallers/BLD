<?php

namespace App\Http\Controllers\Admin;

use App\Network;
use Session;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreNetworkRequest;
use App\Http\Requests\Admin\UpdateNetworkRequest;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Http\Request;

class NetworkController extends Controller {

    public function index() {
        if (!Gate::allows('view_network')) {
            return abort(401);
        }

        $network = Network::all();

        return view('admin.network.index', compact('network'));
        }

        public function list(Request $request) {


        $data = Network::select("id", "name", "is_active", "created_at");

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }

        return datatables()->of($data)
                        ->make();
    }

    /**
     * Show the form for creating new network.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        if (!Gate::allows('add_network')) {
            return abort(401);
        }
        return view('admin.network.create');
    }

    /**
     * Store a newly created product in storage.
     *
     * @param  \App\Http\Requests\StoreNetworkRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreNetworkRequest $request) {
        if (!Gate::allows('add_network')) {
            return abort(401);
        }
        Network::create($request->all());
        Alert::success('Success', "The network has been created.");
        return redirect()->route('admin.network.index');
    }

    public function show(Network $network) {
        if (!Gate::allows('view_network')) {
            return abort(401);
        }

        return view('admin.network.show', compact('network'));
    }

    /* update network */

    public function edit(Network $network) {
        if (!Gate::allows('edit_network')) {
            return abort(401);
        }
        //$network = Network::get()->first();
        return view('admin.network.edit', compact('network'));
    }

    public function update(UpdateNetworkRequest $request, Network $network) {

        if (!Gate::allows('edit_network')) {

            return abort(401);
        }

        Alert::success('Success', "The network has been updated.");
        $network->update($request->all());

        return redirect()->route('admin.network.index');
    }

    /**
     * Remove Network from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Network $network) {
        if (!Gate::allows('edit_network')) {
            return abort(401);
        }
        Network::whereIn('id', request('ids'))->update(['is_active' => 0]);
        Alert::success('Success', "The Network has been made inactive.");

        return redirect()->route('admin.network.index');
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Network::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The network has been $msg successfully"
        ]);
    }

    /**
     * Delete all selected networks at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request) {
        if (!Gate::allows('edit_network')) {
            return abort(401);
        }
        Network::whereIn('id', request('ids'))->update(['is_active' => 0]);
        Alert::success('Success', "The Network has been made inactive.");
        return response()->noContent();
    }
}
