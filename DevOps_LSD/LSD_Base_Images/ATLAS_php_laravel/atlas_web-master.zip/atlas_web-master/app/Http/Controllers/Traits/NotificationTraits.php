<?php

namespace App\Http\Controllers\Traits;

use App\Config;
use App\SalesOrder;
use App\StagesRoles;
use App\Notification;
use App\ApprovalStages;
use App\NotificationConfig;
use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Notification as FacadesNotification;

trait NotificationTraits
{
    /**
     * File upload trait used in controllers to upload files
     */
    public function get_my_notification()
    {
        return Notification::with("from", "to")->where('to_user', Auth::user()->id)->get();
    }

    public function getEmails($status)
    {
        return NotificationConfig::whereStatus($status)->first()->emails ?? '';
    }

    public function sendEmails($status, $notification)
    {
        $emails = $this->getEmails($status);
        if ($emails)
        {
            FacadesNotification::route('mail', explode(",", $emails))
                ->notify($notification);
        }
    }

    public function sendSMS($mobile, $msg)
    {
        $config = Config::whereIn("key", ["sms_uri", "sms_username", "sms_password"])->pluck("value", "key");
        $host = $config["sms_uri"];
        $endpoint = $host . "/gatewaywebservice/Service.asmx/LogIn";

        $curl = curl_init();
        $data = http_build_query([
            'UserName' => $config["sms_username"],
            'password' => $config["sms_password"],
        ]);
        
        curl_setopt_array($curl, array(
            CURLOPT_URL => $endpoint . '?' . $data,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_CIPHER_LIST => 'DEFAULT@SECLEVEL=1',
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "authorization: Basic CAA9D4CBDAED735FBA222CC42201F9C4",
                "cache-control: no-cache",
                "cookie: mac=00:1A:79:CB:7B:96",
                "postman-token: a3f4d173-891c-6c9e-6aac-7140352bceb0"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        activity()
            ->withProperties(['response' => json_encode($response)])
            ->log('SMS');

        curl_close($curl);
        $xml = simplexml_load_string($response);
        $json = json_encode($xml);
        $token = json_decode($json, TRUE);

        $curl = curl_init();

        $mobile = str_replace(" ", "", $mobile);
        $data = http_build_query([
            'session_token' => $token[0],
            'mobile' => $mobile,
            'message' => $msg
        ]);
        $endpoint = $host . "/gatewaywebservice/Service.asmx/SendSMSMessageSingleHttpGet";
        curl_setopt_array($curl, array(
            CURLOPT_URL => $endpoint . '?' . $data,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_CIPHER_LIST => 'DEFAULT@SECLEVEL=1',
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                "Cache-Control: no-cache",
                "Postman-Token: 9c63eea8-6933-4629-b85a-31f81404856a"
            ),
        ));

        $response = curl_exec($curl);

        activity()
            ->withProperties(['request' => json_encode($data), 'response' => json_encode($response)])
            ->log('SMS');

        $err = curl_error($curl);
        curl_close($curl);
        $xml = simplexml_load_string($response);
        $json = json_encode($xml);
        $token = json_decode($json, TRUE);
        $int = (int)$token[0];
        if ($int)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}