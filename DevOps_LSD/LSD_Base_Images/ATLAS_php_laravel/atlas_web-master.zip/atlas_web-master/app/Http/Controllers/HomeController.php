<?php

namespace App\Http\Controllers;

use App\BaseSummary;
use App\ExternalSystemReference;
use App\Http\Controllers\Traits\NotificationTraits;
use App\Reports\Warehouse\Warehousedashboard;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\View;

class HomeController extends Controller
{
    use NotificationTraits;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Session::flash('message', 'This is a message!');
        $dashboard = Auth::user()->roles->where("dashboard", "<>", null)->pluck("dashboard");
        if ($dashboard[0] == "normal") {
            return view('normal');
        } else if ($dashboard[0] == "warehouse") {
            $report = new Warehousedashboard();
            $report->run();
            return view("reporting.warehouse.dashboard", ["report" => $report]);
        }
    }

    public function list_notification()
    {
        return view('normal');
    }

    public function admin()
    {
        // Session::flash('message', 'This is a message!'); 
        return view('home_admin');
    }
}
