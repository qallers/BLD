<?php

namespace App\Http\Controllers;

use App\Config;
use App\Http\Requests;
use App\Fileconfig;
use App\Ogr;
use App\User;
use App\Warehouse;
use App\Customer;
use App\Product;
use App\Network;
use App\NotificationConfig;
use App\PassportClient;
use App\SalesOrderDetails;
use App\Status;
use App\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use SplFileObject;
use Session;
use Illuminate\Support\Facades\Crypt;

class AjaxController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    public function read_file() {

        $file = new SplFileObject($_FILES['file_upload']['tmp_name']);
        //$file->setFlags(\SplFileObject::READ_CSV);
// This seeks to the line that you want to start at
        $file->seek(1);
//        $handle = @fopen($_FILES['file_upload']['tmp_name'], "r");
//        if ($handle) {
//           
//            while (!feof($handle)) {
//                $buffer = fgets($handle);
//                echo $buffer; die;
//            }
//            fclose($handle);
//        }
        echo $file;
        die;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        
    }

    //check_customer_code

    public function check_customer_code(Request $request) {
        $cnt = Customer::where("cust_code", $request->input('code'))->count();
        if ($cnt > 0) {
            return 'true';
        } else {
            return 'false';
        }
    }

    public function getdirectoryfromnetwork(Request $request) {
        $id = $request->input("id");
        $data = Fileconfig::where("id", $id)->first();
        $path = $data->path;
        return view('admin.ogr.selected_network_file', compact('path'));
    }

    public function encrypt(Request $request) {
        $str = Crypt::encrypt($request->input('string'));
        return response()->json([
                    "res" => $str
        ]);
    }

    public function defaults_list() {
        $defaults = Config::all();
        return datatables()->of($defaults)
                        ->make();
    }

    public function productFromSupplier($id, Request $incoming) {
        $data = Product::select(['id', 'product_code as text', 'sale_price', 'product_code', 'description'])->where("supplier_id", $id)->where('product_code', 'like', '%' . $incoming->input('search') . '%')->get();
        return response()->json([
                    "results" => $data
        ]);
    }

    public function file_configs_by_network(Request $incoming) {
        $data = Fileconfig::where('network_id', $incoming->input('nid'))->get();
        return view('ajax.fileconfig', compact('data'));
    }

    public function file_configs_by_network_grv(Request $incoming) {
        $data = Fileconfig::with('filetype')->where('network_id', $incoming->input('nid'))->get();
        return view('ajax.fileconfig_grv', compact('data'));
    }

    public function file_history_by_month(Request $incoming) {
        $date = $incoming->input("month") . "-01";
        $data = Ogr::whereYear('process_month', date('Y', strtotime($date)))
                ->whereMonth('process_month', date('m', strtotime($date)))
                ->get();
        return view('ajax.fileimport_history_bymonth', compact('data'));
    }

    public function file_history_by_network(Request $incoming) {
        $date = $incoming->input("month") . "-01";
        $data = Ogr::whereYear('process_month', date('Y', strtotime($date)))
                ->whereMonth('process_month', date('m', strtotime($date)))
                ->where('network_id', $incoming->input('nid'))
                ->get();
        return view('ajax.fileimport_history_bynetwork', compact('data'));
    }

    public function users_by_id(Request $incoming) {
        $data = User::all();
        return view('ajax.users_by_id', compact('data'));
    }

    public function customers_by_id(Request $incoming) {
        if (Auth::user()->user_type_id == 2) {
            $data = Customer::select(['id', 'concat(name," ",cust_code) as text'])->where('name', 'like', '%' . $incoming->input('search') . '%')
                            ->whereIsActive(1)
                            ->whereRepUserId(Auth::user()->user_type_id)->get();
        } else {
            $data = Customer::select(DB::raw('id,CONCAT("[",cust_code,"] - ",name) AS text'))->where('name', 'like', '%' . $incoming->input('search') . '%')
                            ->whereIsActive(1)->get();
        }
        return response()->json([
                    "results" => $data
        ]);
    }

    public function notification_config_list() {
        $notifications = NotificationConfig::with("status_obj");
        return datatables()->of($notifications)
                        ->make();
    }

    public function warehouse_by_id(Request $incoming) {
        $data = \App\Warehouse::select(['id', 'description as text'])->where('description', 'like', '%' . $incoming->input('search') . '%')->get();
        return response()->json([
                    "results" => $data
        ]);
    }

    public function products_by_id(Request $incoming) {
        $data = Product::select(['id', 'product_code as text', 'sale_price', 'product_code', 'description'])->where('product_code', 'like', '%' . $incoming->input('search') . '%')->get();
        return response()->json([
                    "results" => $data
        ]);
    }

    public function purchase_order_by_id(Request $incoming) {
        //$data = \App\PurchaseOrder::select(['id', 'external_reference as text'])->where('external_reference', 'like', '%' . $incoming->input('search') . '%')->where('')->get();
        $data = DB::table('purchase_order')
                ->select(['purchase_order.id', 'external_reference as text'])
                ->join('status', 'purchase_order.status_id', '=', 'status.id')
                ->where('external_reference', 'like', '%' . $incoming->input('search') . '%')
                ->where('status.status', '=', 'approved')
                ->get();
        return response()->json([
                    "results" => $data
        ]);
    }

    public function getall(Request $request) {
        $id = $request->input('id');
        $purchaseOrder = \App\PurchaseOrder::with('product', 'supplier', 'status', 'user', 'warehouse')->find($id);
        return response()->json([
                    "status" => 200,
                    "res" => $purchaseOrder
        ]);
    }

    public function tier_by_ids() {

        $data = \App\Tier::all();
        return view('ajax.tier_by_id', compact('data'));
    }

    public function child_by_parent($id) {
        $data = DB::select("SELECT *,lv FROM (SELECT @pv:=(SELECT GROUP_CONCAT(id SEPARATOR ',') FROM customer WHERE parent_id IN (@pv)) AS lv,cust_code,name,id,created_at,updated_at,parent_id FROM customer JOIN (SELECT @pv:=$id)tmp WHERE parent_id IN (@pv)) a");
        return view('ajax.child_by_parent', compact('data'));
    }

    public function customer_child_by_parent(Request $request) {
        $data = Customer::whereparentId($request->parent_id)
                        ->whereIsActive(1)->get();
        return view('ajax.customer_by_id', compact('data'));
    }

    public function status_by_process(Request $request) {
        $status = Status::whereProcess($request->process)->get();
        return view('ajax.status_by_process', compact('status'));
    }

    public function emails_by_status(Request $request) {
        $emails = NotificationConfig::whereStatus($request->status)->first();
        if ($emails) {
            $emails = explode(",", $emails->emails);
        } else {
            $emails = [];
        }

        return view('ajax.emails_by_status', compact('emails'));
    }

    public function files_import_history(Request $incoming) {
        $ogr = Ogr::whereYear('process_month', date('Y'))
                ->where('file_config_id', $incoming->input('fid'))
                ->orderBy('process_month')
                ->get();

//        $date = $incoming->input("month") . "-01";
//        $file = Ogr::whereYear('process_month', date('Y', strtotime($date)))
//                ->whereMonth('process_month', date('m', strtotime($date)))
//                ->where('file_config_id', $incoming->input('fid'))
//                ->get();
        $file = \App\Ogr::where('file_name', $incoming->input('file_name'))->get();

        $check = (object) [];
        $check->count = $file->count();
        $check->msg = "";

        if ($check->count > 0) {
            $check->data = $file[0];
            $check->msg = "You already have this file imported into system.";
        }

        return view('ajax.fileimport_history', compact('ogr', 'check'));
    }

    public function config_apis() {
        $client = Config::where('key', 'app_client')->first();
        return view('admin.passport.index', compact('client'));
    }

    public function passport_client_change(Request $request) {
        $p = PassportClient::find($request->id);
        $p->password_client = $request->password_client;
        $p->save();
        return responder()->success()->respond();
    }

}
