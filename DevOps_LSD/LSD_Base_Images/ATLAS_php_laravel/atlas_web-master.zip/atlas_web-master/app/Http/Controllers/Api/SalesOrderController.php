<?php

namespace App\Http\Controllers\Api;

use Flash;
use App\Box;
use App\User;
use Response;
use stdClass;
use App\Stock;
use Exception;
use App\Config;
use App\Status;
use DataTables;
use App\Product;
use App\Contract;
use App\Customer;
use App\UserType;
use App\BulkOrder;
use App\SalesDeal;
use App\SplitDeal;
use App\TierStage;
use App\Warehouse;
use Carbon\Carbon;
use App\SalesOrder;
use App\BaseSummary;
use App\ProductDeal;
use App\StagesRoles;
use App\StockLedger;
use App\Notification;
use App\SalesInvoice;
use App\CustomerSplit;
use App\ApprovalStages;
use App\BulkOrderDetails;
use App\SalesOrderDetails;
use Illuminate\Support\Arr;
use App\Imports\OrderImport;
use Illuminate\Http\Request;
use Illuminate\Auth\Access\Gate;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Spatie\Activitylog\Models\Activity;
use App\Notifications\SalesOrderCreated;
use RealRashid\SweetAlert\Facades\Alert;
use App\Notifications\SalesOrderApproval;
use App\Notifications\SalesOrderApproved;
use App\Http\Controllers\Traits\PDFExportTrait;
use App\Http\Controllers\Traits\SalesOrderTrait;
use App\Http\Controllers\Traits\NotificationTraits;
use App\Http\Controllers\Traits\ParentChildTrait;
use Maatwebsite\Excel\Facades\Excel as FacadesExcel;

class SalesOrderController extends Controller
{

    use NotificationTraits;
    use SalesOrderTrait;
    use PDFExportTrait;
    use ParentChildTrait;

    /** 
     * @OA\Get(
     *      path="/api/v1/warehouse/list",
     *      operationId="getWarehouseList",
     *      tags={"Warehouse"},
     *      summary="Get Warehouse list",
     *      description="Returns warehouses",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function warehouses(Request $request)
    {
        $wa = Warehouse::whereUserId(Auth::user()->id)->get();
        if ($wa->count() == 0)
        {
            return responder()->error(500, "no warehouse found for this account.")->respond(500);
        }
        else
        {
            return responder()->success($wa)->respond(200);
        }
    }
    /** 
     * @OA\Get(
     *      path="/api/v1/order/payment_modes",
     *      operationId="getpaymentModes",
     *      tags={"Order"},
     *      summary="Get payment Modes",
     *      description="Returns Payment Modes",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function payment_modes()
    {
        $status = Status::whereProcess("payment_status")->get();
        if ($status->count() == 0)
        {
            return responder()->error(500, "no customer found for this account.")->respond(500);
        }
        else
        {
            return responder()->success($status)->respond(200);
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/order/delivery_modes",
     *      operationId="getdeliveryModes",
     *      tags={"Order"},
     *      summary="Get delivery Modes",
     *      description="Returns delivery Modes",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function delivery_modes()
    {
        $status = Status::whereProcess("delivery_mode")->get();
        if ($status->count() == 0)
        {
            return responder()->error(500, "no delivery modes found for this account.")->respond(500);
        }
        else
        {
            return responder()->success($status)->respond(200);
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/order/products",
     *      operationId="getProducts",
     *      tags={"Order"},
     *      summary="Get products",
     *      description="Returns products list",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function products()
    {
        $products = Product::all();
        if ($products->count() == 0)
        {
            return responder()->error(500, "no products found for this account.")->respond(500);
        }
        else
        {
            return responder()->success($products)->respond(200);
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/order/products/by_network",
     *      operationId="getProductsByNetwork",
     *      tags={"Order"},
     *      summary="Get products",
     *      description="Returns products list",
     * security={
     *  {"passport": {}},
     *   },
     *  @OA\Parameter(
     *      name="network_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function products_by_network(Request $request)
    {
        $products = Product::whereNetworkId($request->network_id);
        if ($products->count() == 0)
        {
            return responder()->error(500, "no products found for this network.")->respond(500);
        }
        else
        {
            return responder()->success($products)->respond(200);
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/order/deal",
     *      operationId="getProductDeals",
     *      tags={"Order"},
     *      summary="Get customer deal for particular network",
     *      description="Returns product deal",
     * security={
     *  {"passport": {}},
     *   },
     *  @OA\Parameter(
     *      name="product_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="customer_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function product_deal(Request $request)
    {
        $customer = Customer::find($request->customer_id);
        $product = Product::find($request->product_id);
        $network_id = $product->network->id;
        $contract = Contract::where('customer_id', $request->customer_id)
            ->where('network_id', $network_id)->first();

        if (!$contract)
        {
            return responder()->error(500, "The customer does not have any contracts with " . $product->network->name . " network.")->respond(500);
        }
        if (!$contract->is_tiered)
        {
            $deals = ProductDeal::where('product_id', $request->product_id)
                ->where('customer_group_id', $customer->group_id)
                ->whereRaw('(now() between start_date and end_date)')
                ->orWhere(function ($query) use ($customer, $request)
                {
                    $query->where('customer_id', $customer->id)
                        ->where('product_id', $request->product_id)
                        ->whereRaw('(now() between start_date and end_date)');
                })
                ->get();

            $splits = CustomerSplit::where('customer_id', $request->customer_id)
                ->where('network_id', $network_id)->get();
            $parent = null;
            if ($customer->parent_id != -1 || $customer->parent_id != NULL)
            {
                $parent = Contract::where('customer_id', $customer->parent_id)
                    ->where('network_id', $network_id)->first();
            }
            return responder()->success(compact('deals', 'splits', 'contract', 'parent'))->respond(200);
        }
        elseif ($contract->is_split)
        {
            $acb = BaseSummary::whereCustomerId($customer->id)
                ->whereNetworkId($network_id)
                ->sum("active_base");
            $deals = TierStage::where('customer_id', $request->customer_id)
                ->where('network_id', $network_id)
                ->where('from_cab', '<=', (int)$acb)
                ->where(function ($query) use ($acb)
                {
                    $query->where('to_cab', '>=', (int)$acb);
                    $query->orWhere('to_cab', -1);
                })
                ->first();
            $parent = null;
            if ($customer->parent_id != -1 || $customer->parent_id != NULL)
            {
                $parent = Contract::where('customer_id', $customer->parent_id)
                    ->where('network_id', $network_id)->first();
            }

            $split_deal = SplitDeal::where('customer_id', $request->customer_id)
                ->where('product_id', $request->product_id)
                ->whereRaw('(now() between start_date and end_date)')
                ->get();
            return responder()->success(compact('deals', 'contract', 'split_deal', 'parent'))->respond(200);
        }
        else
        {
            $splits = null;
            $acb = BaseSummary::whereCustomerId($customer->id)
                ->whereNetworkId($network_id)
                ->sum("active_base");
            $deals = TierStage::where('customer_id', $request->customer_id)
                ->where('network_id', $network_id)
                ->where('from_cab', '<=', (int)$acb)
                ->where(function ($query) use ($acb)
                {
                    $query->where('to_cab', '>=', (int)$acb);
                    $query->orWhere('to_cab', -1);
                })
                ->first();
            return responder()->success(compact('deals', 'splits', 'contract'))->respond(200);
        }
    }



    public function approve($id)
    {
        /** @var Admin/audits $admin/audits */
        if ($this->approveOrder($id))
        {
            $order = SalesOrder::find($id)->load("customer");
            $u = User::find($order->user_id);
            $u->notify(new SalesOrderApproved($order));

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $order->id;
            $sl['status_id'] = $order->status_id;
            $sl['qty'] = 0;

            $sl['order_name'] = "SALES";
            $sl['process_name'] = "approve_order";

            StockLedger::create($sl);

            Alert::success('Success', 'The order has been approved.');
        }
        else
        {
            Alert::success('Error', 'There is a problem with the approval of the order.');
        }
        return back();
    }



    public function list(Request $request)
    {
        /** @var Admin/audits $admin/audits */
        if (!empty($request->input('cid')))
        {
            $ids = [$request->input("cid")];
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->whereIn('customer_id', $ids);
        }
        else if (!empty($request->input('ps')))
        {
            $ids = [$request->input("ps")];
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->whereIn('customer_id', $ids);
        }
        else
        {
            $order = $this->getMyOrder()["orders"]->with('paymentStatus', 'customer', 'deliveryMode', 'user', 'status');
        }

        return datatables()->of($order)
            ->make();
    }

    /** 
     * @OA\Post(
     *      path="/api/v1/order/create/sales",
     *      operationId="createSalesOrder",
     *      tags={"Order"},
     *      summary="Create sales order for customer",
     *      description="Returns order information",
     * security={
     *  {"passport": {}},
     *   },
     *   @OA\RequestBody(
     *       required=true,
     *       description="Bulk products Body",
     *       @OA\JsonContent(type="array",
     *      		    @OA\Items(
     *                  @OA\Property(property="customer_id", type="string"),
     *                  @OA\Property(property="warehouse_id", type="string"),
     *                  @OA\Property(property="product_id", type="string"),
     *                  @OA\Property(property="qty", type="string"),
     *                  @OA\Property(property="sales_price", type="string"),
     *                  @OA\Property(property="product_deal", type="string"),
     *                  @OA\Property(property="split_deal_id", type="string"),
     *                  @OA\Property(property="payment_status_id", type="string"),
     *                  @OA\Property(property="delivery_method_id", type="string"),
     *         		),
     *       )
     *     ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function createorder(Request $request)
    {
        $input = $request->json()->all();
        $order = $input[0];
        $user = auth()->user();
        $order['user_id'] = $user->id;
        $order = SalesOrder::create(Arr::except($order, ['qty', 'product_id', 'product_deal', 'split_deal_id']));
        $sos = Config::where("key", "sales_order_status")->first();
        $order->status_id = $sos->value;
        $order->save();
        foreach ($input as $key => $p)
        {
            $or = (object) $p;
            $od = (object) $this->get_product_entry($or);

            $o["sales_order_id"] = $order->id;
            $o["qty"] = $or->qty;
            $o["sales_price"] = $or->sales_price;
            $o["product_id"] = $od->product->id;
            $o["cost"] = $or->qty * $or->sales_price;
            if (!empty($or->product_deal))
                $o["product_deal_id"] = $or->product_deal ?? '';
            else
                $o["product_deal_id"] = null;
            if (!empty($or->split_deal_id))
                $o["split_deal_id"] = $or->split_deal_id ?? '';
            else
                $o["split_deal_id"] = null;

            $deal = SalesOrderDetails::create($o);

            if ($od->contract->is_split)
            {
                foreach ($od->splits as $key => $split)
                {
                    $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                    $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                    $d["sales_order_detail_id"] = $deal->id;
                    $d["customer_id"] = $split->split_customer;
                    $d["is_tiered"] = $od->contract->is_tiered;
                    $d["is_split"] = $od->contract->is_split;
                    $d["split_customer"] = $order->customer_id == $split->split_customer ? 1 : 0;
                    $d["ogr"] = $split->ogr;
                    $d["act"] = $split->act;
                    $d["sim"] = $split->sim;
                    $d["ogr_tier"] = $split->ogr_tier;
                    $d["act_tier"] = $split->act_tier;
                    $d["sim_tier"] = $split->sim_tier;
                    $d["start_date"] = $start;
                    $d["end_date"] = new Carbon("2099-12-31");
                    SalesDeal::create($d);
                }
            }
            else
            {
                $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                $d["sales_order_detail_id"] = $deal->id;
                $d["customer_id"] = $or->customer_id;
                $d["is_tiered"] = $od->contract->is_tiered;
                $d["is_split"] = $od->contract->is_split;
                $d["split_customer"] = 0;
                $d["ogr"] = ($od->contract->is_tiered ? $od->tier->ogr : ($od->deal ? $od->deal->ogr : $od->contract->ogr));
                $d["act"] = ($od->contract->is_tiered ? $od->tier->act : ($od->deal ? $od->deal->act : $od->contract->act));
                $d["sim"] = ($od->contract->is_tiered ? $od->tier->sim : ($od->deal ? $od->deal->sim : $od->contract->sim));
                $d["start_date"] = $start;
                $d["end_date"] = new Carbon("2099-12-31");
                SalesDeal::create($d);
            }
        }
        $this->generatePDFSales($order);
        $order = $this->check_approval($order);
        $this->sendEmails($sos->value, new SalesOrderCreated($order));
        return responder()->success($order)->respond(200);
    }

    public function updateorder(Request $request)
    {
        $input = $request->json()->all();
        $user = auth()->user();
        $oid = $input[0]["sales_order_id"];
        $order = SalesOrder::find($oid);
        foreach ($input as $key => $p)
        {
            $or = (object) $p;
            if ($or->type == "edit" || $or->type == "add")
            {
                $od = (object) $this->get_product_entry($or);
                $deal = [];
                $o["sales_order_id"] = $oid;
                $o["qty"] = $or->qty;
                $o["sales_price"] =  $od->product->sale_price;
                $o["product_id"] = $od->product->id;
                $o["cost"] = $or->qty * $od->product->sale_price;
                if (!empty($or->product_deal))
                    $o["product_deal_id"] = $or->product_deal ?? '';
                else
                    $o["product_deal_id"] = null;
                if (!empty($or->split_deal_id))
                    $o["split_deal_id"] = $or->split_deal_id ?? '';
                else
                    $o["split_deal_id"] = null;

                if ($or->type == "edit")
                {
                    $deal = SalesOrderDetails::find($or->order_detail_id);
                    $deal->update($o);
                }
                else
                {
                    $deal = SalesOrderDetails::create($o);
                }
                SalesDeal::where("sales_order_detail_id", $deal->id)->delete();
                if ($od->contract->is_split)
                {
                    foreach ($od->splits as $key => $split)
                    {
                        $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                        $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                        $d["sales_order_detail_id"] = $deal->id;
                        $d["customer_id"] = $split->split_customer;
                        $d["is_tiered"] = $od->contract->is_tiered;
                        $d["is_split"] = $od->contract->is_split;
                        $d["split_customer"] = $order->customer_id == $split->split_customer ? 1 : 0;
                        $d["ogr"] = $split->ogr;
                        $d["act"] = $split->act;
                        $d["sim"] = $split->sim;
                        $d["ogr_tier"] = $split->ogr_tier;
                        $d["act_tier"] = $split->act_tier;
                        $d["sim_tier"] = $split->sim_tier;
                        $d["start_date"] = $start;
                        $d["end_date"] = new Carbon("2099-12-31");
                        SalesDeal::create($d);
                    }
                }
                else
                {
                    $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                    $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                    $d["sales_order_detail_id"] = $deal->id;
                    $d["customer_id"] = $or->customer_id;
                    $d["is_tiered"] = $od->contract->is_tiered;
                    $d["is_split"] = $od->contract->is_split;
                    $d["split_customer"] = 0;
                    $d["ogr"] = ($od->contract->is_tiered ? $od->tier->ogr : ($od->deal ? $od->deal->ogr : $od->contract->ogr));
                    $d["act"] = ($od->contract->is_tiered ? $od->tier->act : ($od->deal ? $od->deal->act : $od->contract->act));
                    $d["sim"] = ($od->contract->is_tiered ? $od->tier->sim : ($od->deal ? $od->deal->sim : $od->contract->sim));
                    $d["start_date"] = $start;
                    $d["end_date"] = new Carbon("2099-12-31");
                    SalesDeal::create($d);
                }
            }
            elseif ($or->type == "remove")
            {
                SalesOrderDetails::destroy($or->order_detail_id);
            }
        }
        return response()->json([
            "msg" => "The order has been updated successfully.",
            "id" => $oid
        ]);
    }

    /** 
     * @OA\Post(
     *      path="/api/v1/order/invoice",
     *      operationId="updateOrderInvoice",
     *      tags={"Order"},
     *      summary="Post order invoice for particular order",
     *      description="Returns Order",
     * security={
     *  {"passport": {}},
     *   },
     *  @OA\Parameter(
     *      name="sales_order_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="invoice_number",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="isPartial",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="boolean"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="ids[]",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="invoice[]",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function updateInvoice(Request $request)
    {
        if (SalesOrder::find($request->sales_order_id)->status_id == Status::whereProcess("sales_order")->whereStatus("approved")->first()->id)
        {

            if ($request->filled('isPartial'))
            {
                foreach ($request->input("ids") as $key => $value)
                {
                    SalesOrderDetails::where('id', $request->input("ids")[$key])
                        ->update(["invoice_number" => $request->input("invoice")[$key]]);
                }
            }
            else
            {
                $order = SalesOrder::find($request->input("sales_order_id"));
                if ($order->is_bulk)
                {
                    SalesOrderDetails::whereIn('sales_order_id', SalesOrder::whereParentId($order->id)->pluck("id"))
                        ->update(["invoice_number" => $request->input("invoice_number")]);
                }
                else
                {
                    SalesOrderDetails::where('sales_order_id', $request->input("sales_order_id"))
                        ->update(["invoice_number" => $request->input("invoice_number")]);
                }
            }
        }
        else
        {
            return responder()->error(500, "Order can not be invoiced before approval.")->respond(500);
        }
        return responder()->success("The order has been invoiced successfully.")->respond(200);
    }

    /**
     * Display the specified Admin/audits.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var Admin/audits $admin/audits */
        $status = $this->check_order($id);
        if ($status->isMine)
        {
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->find($id);
            if ($order->is_bulk)
            {
                $ids = SalesOrder::select(["id", "customer_id"])->with("customer:id,cust_code")->whereParentId($order->id)->get();
                $deal = [];
                $od = [];
                foreach ($ids as $order_child)
                {
                    $od[] = $o = SalesOrderDetails::with('product', 'deal')->where("sales_order_id", $order_child->id)->get();
                    foreach ($o as $key => $odetail)
                    {
                        $data = new stdClass();
                        $data->customer_id = $order_child->customer_id;
                        $data->customer_code = $order_child->customer->cust_code;
                        $data->product_id = $odetail->product_id;
                        $data->product_deal = $odetail->product_deal_id;
                        $data->split_deal_id = $odetail->split_deal_id;
                        $data->qty = $odetail->qty;
                        $data->sales_price = $odetail->sales_price;
                        $data->type = "none";
                        $data->order_detail_id = $odetail->id;
                        $data->sales_order_id = $odetail->sales_order_id;
                        $data->invoice_number = $odetail->invoice_number;
                        $deal[] = array_merge($this->get_product_entry($data), array("data" => $data, "type" => "edit", 'isReporting' => 0));
                    }
                }

                $isInvoiced = SalesOrderDetails::whereIn('sales_order_id', $ids->pluck("id"))->whereNull('invoice_number')->count();
            }
            else
            {
                $od = SalesOrderDetails::with('product', 'deal')->where("sales_order_id", $id)->get();
                $deal = [];
                foreach ($od as $key => $odetail)
                {
                    $data = new stdClass();
                    $data->customer_id = $order->customer_id;
                    $data->product_id = $odetail->product_id;
                    $data->product_deal = $odetail->product_deal_id;
                    $data->split_deal_id = $odetail->split_deal_id;
                    $data->qty = $odetail->qty;
                    $data->sales_price = $odetail->sales_price;
                    $data->type = "none";
                    $data->order_detail_id = $odetail->id;
                    $data->sales_order_id = $odetail->sales_order_id;
                    $data->invoice_number = $odetail->invoice_number;
                    $deal[] = array_merge($this->get_product_entry($data), array("data" => $data, "type" => "edit", 'isReporting' => 0));
                }
                $isInvoiced = SalesOrderDetails::where('sales_order_id', $id)->whereNull('invoice_number')->count();
            }

            return view('order.sales.show', compact('order', 'od', 'isInvoiced', 'status', 'deal'));
        }
        else
        {
            abort(401);
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/order/add_product",
     *      operationId="getProductEntry",
     *      tags={"Order"},
     *      summary="Get product entry for particular product line with deal information",
     *      description="Returns product split information",
     * security={
     *  {"passport": {}},
     *   },
     *  @OA\Parameter(
     *      name="product_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="customer_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="split_deal_id",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="product_deal",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="qty",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="payment_status_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="delivery_method_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="warehouse_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function add_product(Request $request)
    {
        $count = Stock::where('product_id', $request->product_id)
            ->whereWarehouseId($request->warehouse_id)
            ->whereNull('sales_order_detail_id')->count();
        $type = $request->type;
        $isReporting = 0;
        if ($count >= $request->qty)
        {
            $data = $request->all();
            $r = new stdClass();
            $r->customer_id = $request->customer_id;
            $r->product_id = $request->product_id;
            $r->product_deal = $request->product_deal;
            $r->split_deal_id = $request->split_deal_id;
            $r->qty = $request->qty;
            return responder()->success(array_merge($this->get_product_entry($r), $data, (array)$type))->respond(200);
        }
        else
        {
            if ($request->type == "edit")
            {
                $data = $request->all();
                $data["qty"] = $count;
                $r = new stdClass();
                $r->customer_id = $request->customer_id;
                $r->product_id = $request->product_id;
                $r->product_deal = $request->product_deal;
                $r->split_deal_id = $request->split_deal_id;
                $r->qty = $count;
                $title = "Error!";
                $msg = "There is only " . $count . " QTY availbale for this product.";
                return responder()->success(array_merge($this->get_product_entry($r), $data, (array)$type, (array)$count))->respond(200);
            }
            else
            {
                $title = "Error!";
                $msg = "There is no stock availbale for this product.";
                $type = "NO_STOCK";
                return responder()->error(500, $msg)->respond(500);
            }
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/order/splits",
     *      operationId="getProductSplits",
     *      tags={"Order"},
     *      summary="Get customer splits for particular network",
     *      description="Returns product split information",
     * security={
     *  {"passport": {}},
     *   },
     *  @OA\Parameter(
     *      name="product_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="customer_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="split_deal_id",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="product_deal_id",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="is_tiered",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function splits(Request $request)
    {
        $customer = Customer::find($request->customer_id);
        $product = Product::find($request->product_id);
        $network_id = $product->network->id;
        $product_deal_id = $request->product_deal_id;
        $contract = Contract::where('customer_id', $request->customer_id)
            ->where('network_id', $network_id)->first();
        if (!$contract->is_tiered && $contract->is_split)
        {

            $split_deal = SplitDeal::where('customer_id', $request->customer_id)
                ->where('product_deal_id', $product_deal_id)
                ->whereRaw('(now() between start_date and end_date)')
                ->get();
            return responder()->success(compact('split_deal', 'product_deal_id'))->respond(200);
        }
        else
        {
            return responder()->error(500, "The customer does not have any split billing contracts with this network.")->respond(500);
        }
    }

    public function split_deal(Request $request)
    {
        $product_deal_id = $request->product_deal_id;
        $product = Product::find($request->product_id);
        $network_id = $product->network->id;
        if (!$request->filled("split_deal_id") || strlen($request->split_deal_id) == 0)
        {
            $splits = CustomerSplit::where('customer_id', $request->customer_id)
                ->where('network_id', $network_id)
                ->whereNull('product_id')
                ->whereNull('product_deal_id')
                ->whereNull('split_deal_id')
                ->get();
        }
        else
        {
            $splits = CustomerSplit::where('split_deal_id', $request->split_deal_id)
                ->get();
        }
        if ($request->is_tiered)
        {
            return view('ajax/tier_split_select', compact('splits'));
        }
        else
        {
            return view('ajax/split_select', compact('splits', 'product_deal_id'));
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/order/change_splits",
     *      operationId="changeCustomerSplits",
     *      tags={"Order"},
     *      summary="Change split deal of customers ",
     *      description="Returns spllit informations",
     * security={
     *  {"passport": {}},
     *   },
     *  @OA\Parameter(
     *      name="product_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="customer_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="network_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="name",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="start_date",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="end_date",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="product_deal_id",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="array",
     *          @OA\Items(
     *              type="string",   
     *          )
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="split_id",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="array",
     *          @OA\Items(
     *              type="string",   
     *          )
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="ogr",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="array",
     *          @OA\Items(
     *              type="string",   
     *          )
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="act",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="array",
     *          @OA\Items(
     *              type="string",   
     *          )
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="sim",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="array",
     *          @OA\Items(
     *              type="string",   
     *          )
     *      )
     *   ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function change_split(Request $request)
    {

        $product = Product::find($request->product_id);
        $sp = CustomerSplit::where('split_deal_id', $request->split_deal)
            ->whereCustomerId($request->customer_id)
            ->whereNetworkId($product->network_id)
            ->get();
        $sp_id = SplitDeal::create([
            'customer_id' => $request->customer_id,
            'product_deal_id' => $request->product_deal_id[0],
            'name' => $request->name,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date
        ]);
        if ($sp->count() == 0)
        {
            foreach ($request->ogr as $key => $value)
            {
                $split = CustomerSplit::find($request->split_id[$key]);
                $new_split = $split->replicate();
                $new_split->product_deal_id = $request->product_deal_id[$key];
                $new_split->product_id = null;
                $new_split->split_deal_id = $sp_id->id;
                $new_split->ogr = $request->ogr[$key];
                $new_split->act = $request->act[$key];
                $new_split->sim = $request->sim[$key];
                $new_split->save();
            }
        }
        else
        {
            foreach ($sp as $key => $s)
            {
                $new_split = $s->replicate();
                $new_split->product_deal_id = $request->product_deal_id[$key];
                $new_split->split_deal_id = $sp_id->id;
                $new_split->ogr = $request->ogr[$key];
                $new_split->act = $request->act[$key];
                $new_split->sim = $request->sim[$key];
                $new_split->save();
            }
        }

        return response()->json([
            "code" => 200,
            "data" => $sp_id,
            "c" => $sp_id->name,
            "day" => $sp_id->end_date->diffinDays(),
        ], 200);
    }

    public function change_split_tier(Request $request)
    {
        $product = Product::find($request->product_id);
        $sp = CustomerSplit::where('split_deal_id', $request->split_deal)
            ->whereCustomerId($request->customer_id)
            ->whereNetworkId($product->network_id)
            ->get();
        $sp_id = SplitDeal::create([
            'customer_id' => $request->customer_id,
            'product_id' => $request->product_id,
            'name' => $request->name,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date
        ]);
        if ($sp->count() == 0)
        {
            foreach ($request->ogr as $key => $value)
            {
                $split = CustomerSplit::find($request->split_id[$key]);
                $new_split = $split->replicate();
                $new_split->product_deal_id = null;
                $new_split->split_deal_id = $sp_id->id;
                $new_split->product_id = $request->product_id;
                $new_split->ogr = $request->ogr[$key];
                $new_split->act = $request->act[$key];
                $new_split->sim = $request->sim[$key];
                $new_split->ogr_tier = $request->ogr_tier[$key];
                $new_split->act_tier = $request->act_tier[$key];
                $new_split->sim_tier = $request->sim_tier[$key];
                $new_split->save();
            }
        }
        else
        {
            foreach ($sp as $key => $s)
            {
                $new_split = $s->replicate();
                $new_split->split_deal_id = $sp_id->id;
                $new_split->ogr = $request->ogr[$key];
                $new_split->act = $request->act[$key];
                $new_split->sim = $request->sim[$key];
                $new_split->ogr_tier = $request->ogr_tier[$key];
                $new_split->act_tier = $request->act_tier[$key];
                $new_split->sim_tier = $request->sim_tier[$key];
                $new_split->save();
            }
        }
        return response()->json([
            "code" => 200,
            "data" => $sp_id,
            "c" => $sp_id->name,
            "day" => $sp_id->end_date->diffinDays(),
        ], 200);
    }

    /** 
     * @OA\Post(
     *      path="/api/v1/order/change_deal",
     *      operationId="changeCustomerDeal",
     *      tags={"Order"},
     *      summary="Change product deal of customers ",
     *      description="Returns deal informations",
     * security={
     *  {"passport": {}},
     *   },
     *  @OA\Parameter(
     *      name="product_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="customer_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="name",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="start_date",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="end_date",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="ogr",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *         
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="act",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string",
     *       
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="sim",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function change_deal(Request $request)
    {
        $product = ProductDeal::create($request->all());
        return responder()->success($product)->respond(200);
    }


    public function allocate_stock($data)
    {
        $input = str_replace(' ', '', $data["barcode"]);
        $qty = str_replace(' ', '', $data["qty"]);
        $po = $data["sales_order_id"];
        $soid = $data["soid"];
        $customer_id = $data["customer_id"];

        $boxdata = Box::where('barcode', $input)->get()->first();

        if (!empty($boxdata->id))
        {
            $getChild = $this->getChildBox($boxdata->id);

            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $box = $boxdata->id;
                $affected = Stock::where('box_id', $box)
                    ->update(['customer_id' => $customer_id, "sales_order_detail_id" => $soid]);
            }
            else
            {
                $affected = Stock::whereIn('box_id', $getChild)
                    ->update(['customer_id' => $customer_id, "sales_order_detail_id" => $soid]);
            }
        }
        else
        {

            $allSerial = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->get();

            $cnt = 0;

            foreach ($allSerial as $sr)
            {
                DB::update("UPDATE stock SET customer_id = $customer_id,sales_order_detail_id = $soid where serial_no = '$sr->serial_no'");
                $cnt++;
            }

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $po;
            $sl['qty'] = $cnt;
            $sl['order_name'] = "MOBILE_INVOICE";
            $sl['process_name'] = "allocate_order_app";

            StockLedger::create($sl);
        }
    }
}
