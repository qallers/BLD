<?php

namespace App\Http\Controllers\Admin;

use App\Address;
use App\AddressType;
use App\Contact;
use App\Country;
use App\Customer;
use App\ExternalSystem;
use App\ExternalSystemReference;
use App\User;
use App\UserType;
use Spatie\Permission\Models\Role;
use App\Warehouse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\NavisionHelperTraits;
use App\Http\Controllers\Traits\NotificationTraits;
use App\Http\Controllers\Traits\RicaTrait;
use App\Http\Controllers\Traits\Safe4Controller;
use App\Http\Requests\Admin\StoreUsersRequest;
use App\Http\Requests\Admin\UpdateUsersRequest;
use App\Notifications\NewUserCreated;
use App\Status;
use Exception;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Str;


class UsersController extends Controller
{

    use NavisionHelperTraits;
    use Safe4Controller;
    use RicaTrait;
    use NotificationTraits;



    /**
     * Display a listing of User.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!Gate::allows('view_user')) {
            return abort(401);
        }

        $users = User::all();

        return view('admin.users.index', compact('users'));
    }


    public function list(Request $request)
    {
        if (!Gate::allows('view_user')) {
            return abort(401);
        }

        $data = User::with(["roles:id,name"]);

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }
        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }

        return datatables()->of($data)
            ->make();
    }

    /**
     * Show the form for creating new User.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (!Gate::allows('add_user')) {
            return abort(401);
        }

        // $customer=Customer::find(2488);
        // $user=User::find(29);
        // $res=$this->sendRicaCredential($customer,$user,null);
        // dd($res);
        $roles = Role::get()->pluck('name', 'name');
        $userType = UserType::all();
        $identity = Status::whereProcess('identity_type')->get();
        $paymentmethod = Status::whereProcess('payment_method')->get();
        $country = Country::all();
        $addresstype = Status::whereProcess('address_type')->get();
        return view('admin.users.create', compact('roles', 'userType', 'identity', 'paymentmethod', 'country', 'addresstype'));
    }

    /**
     * Store a newly created User in storage.
     *
     * @param  \App\Http\Requests\StoreUsersRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreUsersRequest $request)
    {
        if (!Gate::allows('add_user')) {
            return abort(401);
        }
        if ($this->isEnabled()) {
            if ($request->user_type_id == 2) {
                try {
                    $this->nav_post("Sales_Persons", [
                        "Code" => $request->username,
                        "Name" => $request->first_name . " " . $request->last_name,
                    ]);
                } catch (Exception $exception) {
                    Alert::error('Error.', "User is already available in Navision.\n" . $exception->getMessage());
                    return redirect()->route('admin.users.index');
                }
            }
        }
        if ($request->user_type_id == 2 || $request->user_type_id == 4) {
            $request->request->add(['cust_code' => $request->username]);
            $validator = Validator::make($request->all(), [
                'cust_code' => 'required|unique:customer,cust_code'
            ], [
                'cust_code' => "This username has been already used as cust code."
            ]);
            if ($validator->fails()) {
                return redirect('admin/users/create')
                    ->withErrors($validator)
                    ->withInput();
            }
        }
        $passwrod = Str::random(8);
        $request->request->add(['password' => Hash::make($passwrod), "is_active" => 1]);
        $request->request->add(['email' => filter_var($request->input('email'), FILTER_SANITIZE_STRING)]);
        $user = User::create($request->all());

        if ($request->user_type_id != 1) {
            if ($request->user_type_id == 2 || $request->user_type_id == 4) {
                $status = Status::whereProcess("new_customer")->whereStatus("fica_no_doc")->first()->id;
            } else {
                $status = Status::whereProcess("new_customer")->whereStatus("no_fica")->first()->id;
            }
            $customer = [
                "cust_code" => $request->username,
                "name" => $request->name,
                "group_id" => 1,
                "identity_type_id" => $request->identity_type_id,
                "payment_method_id" => $request->payment_method_id,
                "identity_reference" => $request->identity_reference,
                "vat_registered" => 0,
                "user_id" => $user->id,
                "rep_user_id" => -1,
                "status_id" => $status,
            ];
            if ($request->filled("identity_reference_expiry_date")) {
                $customer["identity_reference_expiry_date"] = $request->identity_reference_expiry_date;
            }
            if ($request->filled("identity_reference_origin_country")) {
                $customer["identity_reference_origin_country"] = $request->identity_reference_origin_country;
            }
            $customer = Customer::create($customer);
            $request->request->add(['customer_id' => $customer->id]);
            $status = Status::whereProcess("address_entity_type")
                ->whereStatus("customer")->first();
            $request->request->add(['address_entity_id' => $status->id]);
            Address::create($request->except(['type']));
            $status = Status::whereProcess("address_entity_type")
                ->whereStatus("customer")->first();
            $request->request->add(['contact_entity_id' => $status->id]);
            Contact::create($request->except(['type']));
        }
        $roles = $request->input('roles') ? $request->input('roles') : [];
        $user->assignRole($roles);
        $user->notify(new NewUserCreated([
            'password' => $passwrod,
            'username' => $user->username
        ]));

        // create vault
        if ($request->user_type_id == 2 || $request->user_type_id == 4) {

            $this->uploadToSafe4($customer, $user, $request);
            // //Rica IT
            $res = $this->sendRicaCredential($customer, $user, $passwrod);
            if ($res) {
                $data = json_encode([
                    "rica_username" => $customer->cust_code,
                    "rica_password" => $passwrod
                ]);
                $e = ExternalSystem::whereDescription("RICA")->first();
                ExternalSystemReference::create([
                    "external_system_id" => $e->id,
                    "reference" => "RICA",
                    "data" => $data,
                    "customer_id" => $customer->id
                ]);
                $id = Status::whereProcess("new_customer")->whereStatus("fica_approved")->first()->id;
                Customer::find($customer->id)->update(['status_id' => $id, 'is_active' => 1]);
                $company = Config::get('company_name', 'Track n Trace');
                $msg = "Hi, $customer->name ,\nYour Username : $user->username\nYour Password : $passwrod\n\n$company Support.";
                $this->sendSMS($customer->contacts[0]->cell_no, $msg);
            }else{
                return redirect()->route('admin.users.index');
            }
        }

        Alert::success('Success', 'The user has been created.');
        return redirect()->route('admin.users.index');
    }


    /**
     * Show the form for editing User.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        if (!Gate::allows('edit_user')) {
            return abort(401);
        }
        $roles = Role::get()->pluck('name', 'name');
        $warehouse = Warehouse::all();
        $userType = UserType::all();
        $identity = Status::whereProcess('identity_type')->get();
        $paymentmethod = Status::whereProcess('payment_method')->get();
        $country = Country::all();
        $customer = Customer::whereUserId($user->id)
            ->whereIsActive(1)->first();

        $addresstype = Status::whereProcess('address_type')->get();
        return view('admin.users.edit', compact('addresstype', 'user', 'roles', 'warehouse', 'userType', 'identity', 'paymentmethod', 'country', 'customer'));
    }

    /**
     * Update User in storage.
     *
     * @param  \App\Http\Requests\UpdateUsersRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function change_status(Request $request)
    {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        User::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
            'status' => "200",
            'msg' => "The user has been $msg successfully"
        ]);
    }

    public function update(UpdateUsersRequest $request, User $user)
    {
        if (!Gate::allows('edit_user')) {
            return abort(401);
        }

        $user->update($request->all());

        if ($request->user_type_id != 1) {
            $customer = [
                "cust_code" => $request->username,
                "name" => $request->name,
                "group_id" => 1,
                "identity_type_id" => $request->identity_type_id,
                "payment_method_id" => $request->payment_method_id,
                "identity_reference" => $request->identity_reference,
                "vat_registered" => 0,
                "user_id" => $user->id,
                "rep_user_id" => -1,
            ];
            if ($request->filled("identity_reference_expiry_date")) {
                $customer["identity_reference_expiry_date"] = $request->identity_reference_expiry_date;
            }
            if ($request->filled("identity_reference_origin_country")) {
                $customer["identity_reference_origin_country"] = $request->identity_reference_origin_country;
            }
            $cus = Customer::whereUserId($user->id)->update($customer);
            $cus = Customer::whereUserId($user->id)->first();
            $request->request->add(['customer_id' => $cus->id]);
            $status = Status::whereProcess("address_entity_type")
                ->whereStatus("customer")->first();
            $request->request->add(['address_entity_id' => $status->id]);
            $status = Status::whereProcess("address_entity_type")
                ->whereStatus("customer")->first();
            $request->request->add(['contact_entity_id' => $status->id]);
            try {
                $cus->addresses[0]->update($request->except(['type']));
                $cus->contacts[0]->update($request->except(['type']));
            } catch (Exception $e) {
            }
            if ($request->user_type_id == 2 || $request->user_type_id == 4) {
                if ($cus->status->status == "fica_no_doc") {
                    $this->uploadToSafe4($cus, $user, $request);
                } else if ($cus->status->status == "fica_no_safe4") {
                    $this->uploadTosafe4Server($cus, $user);
                }
                if ($cus->status->status == "fica_approval" || $cus->status->status == "fica_no_doc") {
                    $passwrod = Str::random(8);
                    $res = $this->sendRicaCredential($cus, $user, $passwrod);
                    if ($res) {
                        $user->password = Hash::make($passwrod);
                        $user->save();
                        $data = json_encode([
                            "rica_username" => $cus->cust_code,
                            "rica_password" => $passwrod
                        ]);
                        $e = ExternalSystem::whereDescription("RICA")->first();
                        ExternalSystemReference::create([
                            "external_system_id" => $e->id,
                            "reference" => "RICA",
                            "data" => $data,
                            "customer_id" => $cus->id
                        ]);
                        $id = Status::whereProcess("new_customer")->whereStatus("fica_approved")->first()->id;
                        Customer::find($cus->id)->update(['status_id' => $id, 'is_active' => 1]);
                        $company = Config::get('company_name', 'Track n Trace');
                        $msg = "Hi, $cus->name ,\nYour Username : $user->username\nYour Password : $passwrod\n\n$company Support.";
                        $this->sendSMS($cus->contacts[0]->cell_no, $msg);
                    }else{
                       return redirect()->route('admin.users.index');
                    }
                }
            }
        }
        $roles = $request->input('roles') ? $request->input('roles') : [];
        $user->syncRoles($roles);
        Alert::success('Success', 'The user has been updated.');
        return redirect()->route('admin.users.index');
    }

    public function show(User $user)
    {
        if (!Gate::allows('view_user')) {
            return abort(401);
        }

        $user->load('roles');
        $usertype = UserType::all();

        return view('admin.users.show', compact('user', 'usertype'));
    }

    /**
     * Remove User from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        if (!Gate::allows('edit_user')) {
            return abort(401);
        }

        $user->update(['is_active' => 1]);


        return response()->json([
            'status' => "200",
            'msg' => "Stock dispatched"
        ]);
        //return redirect()->route('admin.users.index');
    }

    /**
     * Delete all selected User at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if (!Gate::allows('edit_user')) {
            return abort(401);
        }
        User::whereIn('id', request('ids'))->update(['is_active' => 1]);
        Session::flash('message', 'The User has been Inactivated Successfully');
        return response()->noContent();
    }
}
