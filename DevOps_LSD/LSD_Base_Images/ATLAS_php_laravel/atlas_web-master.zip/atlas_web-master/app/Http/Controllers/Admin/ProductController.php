<?php

namespace App\Http\Controllers\Admin;

use App\Product;
use App\Network;
use App\Supplier;
use App\Product_Type;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\NavisionHelperTraits;
use Illuminate\Support\Facades\Gate;
use Illuminate\Http\Request;
use App\Http\Requests\Admin\StoreProductRequest;
use App\Http\Requests\Admin\UpdateProductRequest;
use Exception;
use Illuminate\Support\Facades\Session;
use RealRashid\SweetAlert\Facades\Alert;

class ProductController extends Controller {

    use NavisionHelperTraits;

    public function index() {
        if (!Gate::allows('view_products')) {
            return abort(401);
        }

        $product = Product::all();
        return view('admin.product.index', compact('product'));
    }

    /**
     * Show the form for creating new product.
     *
     * @return \Illuminate\Http\Response
     */
   
    public function list(Request $request) {
        $data = Product::with("product_type");

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }
        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }
        return datatables()->of($data)
                        ->make();
    }

     public function create() {
        if (! Gate::allows('add_product')) {
            return abort(401);
        }
        $network = Network::all();
        $product_type = Product_Type::all();
        $supplier = Supplier::all();
        $item_cat=[];
            if($this->isEnabled()){
                $item_cat=$this->nav_get("Item_Categories");
            }
       
        return view('admin.product.create', compact('network', 'product_type', 'supplier','item_cat'));
    }

    /**
     * Store a newly created product in storage.
     *
     * @param  \App\Http\Requests\StoreProductRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreProductRequest $request) {
        if (!Gate::allows('add_product')) {
            return abort(401);
        }
        if($this->isEnabled()){
            try{
                $this->nav_post("Item_Card",[
                    "No"=>$request->product_code,
                    "Description"=>$request->description,
                    "Base_Unit_of_Measure"=>"EA",
                    "Item_Category_Code"=>$request->nav_item_category,
                    "Gen_Prod_Posting_Group"=>$request->nav_item_category,
                ]); 
            }catch(Exception $exception){
                Alert::error('Error.', "Product is already available in Navision.");
                return redirect()->route('admin.users.index');
            }
        }
        Product::create($request->all());
        Alert::success('Success', 'The product has been created.');

        return redirect()->route('admin.product.index');
    }

    public function show(Product $product) {
        if (!Gate::allows('view_products')) {
            return abort(401);
        }
        $product->load('network');


        return view('admin.product.show', compact('product'));
    }

    /* update product */

    public function edit(Product $product) {
        if (!Gate::allows('edit_product')) {
            return abort(401);
        }
        $network = Network::all();
        $product_type = Product_Type::all();
        $supplier = Supplier::all();
        $item_cat=[];
        if($this->isEnabled()){
            $item_cat=$this->nav_get("Item_Categories");
        }

        return view('admin.product.edit', compact('product', 'network', 'product_type', 'supplier','item_cat'));
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Product::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The product has been $msg successfully"
        ]);
    }

    public function update(UpdateProductRequest $request, Product $product) {

        if (!Gate::allows('edit_product')) {

            return abort(401);
        }

        if($this->isEnabled()){
            try{
                $this->nav_patch("Item_Card",$request->product_code,[
                    "No"=>$request->product_code,
                    "Description"=>$request->description,
                    "Base_Unit_of_Measure"=>"EA",
                    "Item_Category_Code"=>$request->nav_item_category,
                    "Gen_Prod_Posting_Group"=>$request->nav_item_category,
                ]); 
            }catch(Exception $exception){
                Alert::error('Error.', "Product is not updated in Navision.".$exception->getMessage());
                return redirect()->route('admin.product.index');
            }
        }
        $product->update($request->all());
        Alert::success('Success', 'The product has been updated.');
        return redirect()->route('admin.product.index');
    }

    public function massDestroy(Request $request) {
        if (!Gate::allows('edit_product')) {
            return abort(401);
        }
        Product::whereIn('id', request('ids'))->update(['is_active' => 1]);
        Session::flash('message', 'The product has been deactivated successfully');
        return response()->noContent();
    }
}
