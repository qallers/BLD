<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Flash;
use Response;
use App\Address;
use App\Contact;
use App\Status;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Spatie\Activitylog\Models\Activity;
use Spatie\Permission\Models\Role;

class ContactController extends Controller {

    public function store(Request $request) {

        if ($request->filled("id")) {
            $contact = Contact::find($request->id);
            $contact->update($request->except(['type']));
        } else {
            $status = Status::whereProcess("address_entity_type")
                            ->whereStatus($request->type)->first();
            $request->request->add(['contact_entity_id' => $status->id]);
            $contact = Contact::create($request->except(['type']));
        }
        return view('ajax.contact_line', compact('contact'));
    }

    public function destroy(Request $request) {
        $address = Contact::find($request->id);
        $address->delete();
        return response()->json([
                    "code" => 200,
                    "message" => "Success."
        ]);
    }

}
