<?php

namespace App\Http\Controllers;

use App\User;
use Exception;
use App\Tenant;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Notifications\NewClientAdded;
use Illuminate\Support\Facades\Config;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\Notification;

class ClientsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clients = Tenant::all();
        return view('admin.clients.index', compact('clients'));
    }

    public function list()
    {
        $clients = Tenant::with("domains");
        return datatables()->of($clients)
            ->make();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.clients.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $tenant = Tenant::create(['id' => $request->id, 'email' => $request->email]);
        $tenant->domains()->create(['domain' => $request->domains]);

        Alert::success("Client has been created successfully . You will receive mail when setup completes.");
        return redirect('admin/clients');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $tenant = tenancy()->find($id);
        $tenant->delete();
        return response()->json([
            'status' => 200,
            'title' => "Success!",
            'message' => "Client has been removed.\nDatabase purging is in progress..."
        ]);
    }

    public function resend_email(Request $request)
    {
        $tenant = Tenant::find($request->id);
        $tenant_fqdn = count(explode('.', $tenant->domains[0]->domain)) == 1 ? $tenant->domains[0]->domain . '.' . config('tenancy.central_domains')[0] : $tenant->domains[0]->domain;
        $password = Str::random(8);
        $user = [
            'email' => $tenant->email,
            'username' => $request->username,
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'user_type_id' => 1,
            'is_active' => 1,
            'password' => bcrypt($password),
            'domain' => $tenant_fqdn,
            'str_password' => $password
        ];

        $tenant->user = $user;

        try
        {
            $tenant->run(function ($tenant)
            {
                DB::table('users')->delete();
                $u = User::create($tenant->user);
                $u->assignRole('administrator');
            });
        }
        catch (Exception $ex)
        {
            return response()->json([
                'status' => 500,
                'title' => "Error",
                'message' => "Could not create user for tenant."
            ]);
        }

        Notification::route('mail', $tenant->email)
            ->notify(new NewClientAdded($user));

        return response()->json([
            'status' => 200,
            'title' => "Success!",
            'message' => "Notification has been sent to client."
        ]);
    }
}
