<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\TierStoreRequest;
use App\Tier;
use App\TierStage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use RealRashid\SweetAlert\Facades\Alert;

class TierController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function list_by_tier($id)
    {
        $data=TierStage::where('tier_id',$id)->get();
        return view('ajax.tierstages_by_id',compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TierStoreRequest $request)
    {
        Tier::create($request->all());
        Alert::success("Success","The tier has been created.");
        return redirect()->route('admin.contract.create');
    }

    public function create_stage(Request $request)
    {
        $data=$request->all();
        unset($data["customer_id"]);
        unset($data["network_id"]);
        data_fill($data,"tiers.*.customer_id",$request->input("customer_id"));
        data_fill($data,"tiers.*.network_id",$request->input("network_id"));
        TierStage::where('customer_id',$request->input("customer_id"))
                    ->where('network_id',$request->input("network_id"))
                    ->delete();
        TierStage::insert($data["tiers"]);
         return response()->json([
            "message"=>"The tier stages have been added successfully.",
            "code"=>200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
