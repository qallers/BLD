<?php

namespace App\Http\Controllers\Admin;

use App\ExternalSystemReference;
use Session;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreNetworkRequest;
use App\Http\Requests\Admin\UpdateNetworkRequest;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Http\Request;

class ExternalReferenceController extends Controller {

    public function index() {

        if (!Gate::allows('view_external_reference')) {
            return abort(401);
        }

        $network = ExternalSystemReference::all();

        return view('admin.external.index', compact('network'));
    }

    public function list_data(Request $request) {
        if (!Gate::allows('view_external_reference')) {
            return abort(401);
        }
        $data = ExternalSystemReference::with("customer", "external");

        return datatables()->of($data)
                        ->make();
    }

    /**
     * Show the form for creating new network.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        if (!Gate::allows('add_external_reference')) {
            return abort(401);
        }
        $external = \App\ExternalSystem::get();
        $customer = \App\Customer::get();
        //dd($customer);
        return view('admin.external.create', compact('external', 'customer'));
    }

    /**
     * Store a newly created product in storage.
     *
     * @param  \App\Http\Requests\StoreNetworkRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {

        $is_avail = ExternalSystemReference::where("customer_id", $request->input('customer_id'))->where("external_system_id", $request->input('external_system_id'))->first();
        if (!empty($is_avail)) {
            Alert::error('Error', "The reference has already added for selacted customer.");
            return redirect()->route('admin.external_reference.create');
        } else {
            ExternalSystemReference::create($request->all());
            Alert::success('Success', "The reference has been created.");
            return redirect()->route('admin.external_reference.index');
        }
    }

    public function show(ExternalSystemReference $e, $id) {
        if (!Gate::allows('view_external_reference')) {
            return abort(401);
        }

        $externalsystemreference = ExternalSystemReference::find($id);
        return view('admin.external.show', compact('externalsystemreference'));
    }

    /* update network */

    public function edit(ExternalSystemReference $e, $id) {

        $external = \App\ExternalSystem::get();
        $externalsystemreference = ExternalSystemReference::find($id);
        $customer = \App\Customer::get();
        return view('admin.external.edit', compact('externalsystemreference', 'external', 'customer'));
    }

    public function update(Request $request, $id) {

        $d = ExternalSystemReference::find($id);
        $is_avail = ExternalSystemReference::where("customer_id", $request->input('customer_id'))->where("external_system_id", $request->input('external_system_id'))->first();
        if (!empty($is_avail) && ($d->customer_id != $request->input('customer_id'))) {
            Alert::error('Error', "The reference has already added for selacted customer.");
        } else {
            $externalsystemreference = ExternalSystemReference::find($id);
            $externalsystemreference->update($request->all());
            Alert::success('Success', "The External Reference has been updated.");
        }
        return redirect()->route('admin.external_reference.index');
    }

    /**
     * Remove Network from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Network $network) {
        if (!Gate::allows('edit_network')) {
            return abort(401);
        }
        Network::whereIn('id', request('ids'))->update(['is_active' => 0]);
        Alert::success('Success', "The Network has been made inactive.");

        return redirect()->route('admin.network.index');
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Network::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The network has been $msg successfully"
        ]);
    }

    /**
     * Delete all selected networks at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request) {
        if (!Gate::allows('edit_network')) {
            return abort(401);
        }
        Network::whereIn('id', request('ids'))->update(['is_active' => 0]);
        Alert::success('Success', "The Network has been made inactive.");
        return response()->noContent();
    }

}
