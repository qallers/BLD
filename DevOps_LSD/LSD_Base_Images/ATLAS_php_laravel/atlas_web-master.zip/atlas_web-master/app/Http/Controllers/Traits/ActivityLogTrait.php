<?php

namespace App\Http\Controllers\Traits;

trait ActivityLogTrait
{
    /**
     * If the attribute is in the encryptable array
     * then decrypt it.
     *
     * @param  $key
     *
     * @return $value
     */
    public function getAttribute($key)
    {
        return $key;
    }

    /**
     * If the attribute is in the encryptable array
     * then encrypt it.
     *
     * @param $key
     * @param $value
     */
    public function setActivityLog($causedby, $performedon, $properties, $description)
    {
        if (!empty($causedby) && !empty($performedon))
        {
            activity()
                ->causedby($causedby)
                ->performedon($performedon)
                ->withProperties($properties)
                ->log($description);
        }
        else if (!empty($causedby))
        {
            activity()
                ->causedby($causedby)
                ->withProperties($properties)
                ->log($description);
        }
        else if (!empty($performedon))
        {
            activity()
                ->performedon($performedon)
                ->withProperties($properties)
                ->log($description);
        }
        else
        {
            activity()
                ->withProperties($properties)
                ->log($description);
        }
    }
}
