<?php

namespace App\Http\Controllers\Admin;

use App\Config;
use App\Network;
use App\Mecreditnote;
use App\Ogrpostprocess;
use Illuminate\Http\Request;
use App\Mesimswappostprocess;
use App\Meactivationpostprocess;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use App\Notifications\CreditnoteProcess;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Controllers\Traits\NotificationTraits;

class CreditNoteController extends Controller
{
    use NotificationTraits;

    public function index()
    {
        $creditnotedata = Mecreditnote::with('network')->get();

        return view('admin.creditnote.index', compact('creditnotedata'));
    }

    public function create()
    {
        $network = Network::all();

        return view('admin.creditnote.create', compact('network'));
    }

    public function download_file($id)
    {
        $Data = Mecreditnote::with('network')->where('id', $id)->get()->first();
        $tenant = tenant()->getTenantKey();
        return Storage::download('ogr/credit_note/' . 'TnT_' . $tenant . '_CreditNote_' . $Data->network->name . '_' . date('Y-m', strtotime($Data->process_month)) . '.csv');
    }

    public function store(Request $request)
    {
        $nid = $request->input('network_id');
        $month = $request->input('process_month') . "-01";

        $check = Mecreditnote::where("network_id", $nid)->where('process_month', $month)->count();
        if (!empty($check))
        {
            Alert::error('Duplicate', 'Credit note already generated for this network');
            return redirect()->route('admin.creditnote.index');
        }
        else
        {
            $data = array();
            $data['network_id'] = $nid;
            $data['process_month'] = $month;
            Mecreditnote::create($data);
        }

        $data = DB::select(
            "SELECT process_month
                ,`name`
                ,cust_code
                ,customer_name
                ,vat_registered
                ,address_line_1
                ,address_line_2
                ,city
                ,province
                ,postal_code
                ,username
                ,cell_no
                ,tel_no
                ,delivery_method
                ,code
                ,expense_code
                ,`description`
                ,qty
                ,excl_price
                ,incl_price
            FROM (
                SELECT t4.process_month
                    ,t2.name
                    ,t3.cust_code
                    ,t3.name AS 'customer_name'
                    ,t3.vat_registered
                    ,IFNULL(t7.address_line_1, '') AS 'address_line_1'
                    ,IFNULL(t7.address_line_2, '') AS 'address_line_2'
                    ,IFNULL(t7.city, '') AS 'city'
                    ,IFNULL(t7.province, '') AS 'province'
                    ,IFNULL(t7.postal_code, '') AS 'postal_code'
                    ,IFNULL(t8.username, '') AS 'username'
                    ,IFNULL(t9.cell_no, '') AS 'cell_no'
                    ,IFNULL(t9.tel_no, '') AS 'tel_no'
                    ,delivery_method.name AS 'delivery_method'
                    ,t10.code
                    ,t12.ogr_expense_code AS 'expense_code'
                    ,LEFT(t12.description, 50) AS 'description'
                    ,1 AS 'qty'
                    ,ROUND(SUM(t1.expense / (1 + t11.vat)), 4) AS 'excl_price'
                    ,ROUND(SUM(t1.expense), 4) AS 'incl_price'
                FROM me_ogr_post_process t1
                LEFT JOIN network t2 ON t1.network_id = t2.id
                LEFT JOIN customer t3 ON t1.customer_id = t3.id
                LEFT JOIN me_import_file t4 ON t1.file_id = t4.id
                LEFT JOIN sales_order_detail t5 ON t5.id = t1.sales_order_detail_id
                LEFT JOIN sales_order t6 ON t6.id = t5.sales_order_id
                LEFT JOIN (
                    SELECT MIN(id) AS 'id'
                        ,customer_id
                    FROM `address`
                    GROUP BY customer_id
                    ) t7a ON t7a.customer_id = t3.id
                LEFT JOIN `address` t7 ON t7.customer_id = t3.id
                    AND t7.id = t7a.id
                LEFT JOIN users t8 ON t8.id = t3.rep_user_id
                LEFT JOIN (
                    SELECT MIN(id) AS 'id'
                        ,customer_id
                    FROM contact
                    GROUP BY customer_id
                    ) t9a ON t9a.customer_id = t3.id
                LEFT JOIN contact t9 ON t9.customer_id = t3.id
                    AND t9.id = t9a.id
                LEFT JOIN `group` t10 ON t10.id = t3.group_id
                LEFT JOIN vat_config t11 ON t4.process_month BETWEEN t11.start_date
                        AND t11.end_date
                LEFT JOIN product t12 ON t12.id = t1.product_id
                LEFT JOIN (
                    SELECT id
                    ,`name`
                    FROM `status`
                    WHERE `process` = 'delivery_mode'
                ) delivery_method ON delivery_method.id = t6.delivery_method_id
                WHERE t4.process_month = :ogrMonth
                    AND t2.id = :ogrNetwork
                    AND t1.expense > 0
                GROUP BY t3.cust_code
                    ,t12.ogr_expense_code
                
                UNION
                
                SELECT t4.process_month
                    ,t2.name
                    ,t3.cust_code
                    ,t3.name AS 'customer_name'
                    ,t3.vat_registered
                    ,IFNULL(t7.address_line_1, '') AS 'address_line_1'
                    ,IFNULL(t7.address_line_2, '') AS 'address_line_2'
                    ,IFNULL(t7.city, '') AS 'city'
                    ,IFNULL(t7.province, '') AS 'province'
                    ,IFNULL(t7.postal_code, '') AS 'postal_code'
                    ,IFNULL(t8.username, '') AS 'username'
                    ,IFNULL(t9.cell_no, '') AS 'cell_no'
                    ,IFNULL(t9.tel_no, '') AS 'tel_no'
                    ,delivery_method.name AS 'delivery_method'
                    ,t10.code
                    ,t12.act_expense_code AS 'expense_code'
                    ,LEFT(t12.description, 50) AS 'description'
                    ,COUNT(t1.serial_no) AS 'qty'
                    ,ROUND(t1.expense / (1 + t11.vat), 4) AS 'excl_price'
                    ,ROUND(t1.expense, 4) AS 'incl_price'
                FROM me_act_post_process t1
                LEFT JOIN network t2 ON t1.network_id = t2.id
                LEFT JOIN customer t3 ON t1.customer_id = t3.id
                LEFT JOIN me_import_file t4 ON t1.file_id = t4.id
                LEFT JOIN sales_order_detail t5 ON t5.id = t1.sales_order_detail_id
                LEFT JOIN sales_order t6 ON t6.id = t5.sales_order_id
                LEFT JOIN (
                    SELECT MIN(id) AS 'id'
                        ,customer_id
                    FROM `address`
                    GROUP BY customer_id
                    ) t7a ON t7a.customer_id = t3.id
                LEFT JOIN `address` t7 ON t7.customer_id = t3.id
                    AND t7.id = t7a.id
                LEFT JOIN users t8 ON t8.id = t3.rep_user_id
                LEFT JOIN (
                    SELECT MIN(id) AS 'id'
                        ,customer_id
                    FROM contact
                    GROUP BY customer_id
                    ) t9a ON t9a.customer_id = t3.id
                LEFT JOIN contact t9 ON t9.customer_id = t3.id
                    AND t9.id = t9a.id
                LEFT JOIN `group` t10 ON t10.id = t3.group_id
                LEFT JOIN vat_config t11 ON t4.process_month BETWEEN t11.start_date
                        AND t11.end_date
                LEFT JOIN product t12 ON t12.id = t1.product_id
                LEFT JOIN (
                    SELECT id
                    ,`name`
                    FROM `status`
                    WHERE `process` = 'delivery_mode'
                ) delivery_method ON delivery_method.id = t6.delivery_method_id
                WHERE t4.process_month = :actMonth
                    AND t2.id = :actNetwork
                    AND t1.expense > 0
                GROUP BY t3.cust_code
                    ,t12.act_expense_code
                    ,t1.expense
                ) cndata
            GROUP BY cust_code
                ,expense_code
                ,qty
                ,excl_price
                ,incl_price
            ORDER BY cust_code
                ,expense_code
                ,qty
                ,excl_price
                ,incl_price",
            ["ogrMonth" => $month, "ogrNetwork" => $nid, "actMonth" => $month, "actNetwork" => $nid]
        );

        if (empty($data[0]))
        {
            Alert::error('No Data', 'Data is not available for selected month');
            $network = Network::all();
            return view('admin.creditnote.create', compact('network'));
        }

        $fileData = '';
        $prevCustCode = '';
        if (!empty($data))
        {
            $i = 1;
            foreach ($data as $k => $v)
            {
                if ($prevCustCode <> $v->cust_code)
                {
                    $prevCustCode = $v->cust_code;

                    $header = array();

                    $header[] = 'HEADER';
                    $header[] = 'CN000001';
                    $header[] = '';
                    $header[] = '';
                    $header[] = $v->cust_code;
                    $header[] = $this->get_fin_period($v->process_month);
                    $header[] = date('d/m/Y', strtotime($v->process_month . "+1 month"));
                    $header[] = 'TnT_' . $v->name . date('YM', strtotime($v->process_month)) . ' ' . $i;
                    $header[] = 'Y';
                    $header[] = '0';
                    $header[] = '';
                    $header[] = '';
                    $header[] = '';
                    $header[] = $v->address_line_1;
                    $header[] = $v->address_line_2;
                    $header[] = $v->city;
                    $header[] = $v->province;
                    $header[] = $v->postal_code;
                    $header[] = $v->username;
                    $header[] = '0';
                    $header[] = date('d/m/Y', strtotime($v->process_month . "+1 month"));
                    $header[] = $v->tel_no;
                    $header[] = $v->cell_no;
                    $header[] = $v->customer_name;
                    $header[] = '1';
                    $header[] = '';
                    $header[] = $v->delivery_method;
                    $header[] = '';
                    $header[] = '';

                    $fileData .= implode(',', $header) . PHP_RN;
                }
                $i++;

                $detail = array();

                $detail[] = 'DETAIL';
                $detail[] = '0';
                $detail[] = $v->qty;
                $detail[] = $v->excl_price;
                $detail[] = $v->vat_registered == 1 ? $v->incl_price : $v->excl_price;
                $detail[] = 'EA';
                $detail[] = $v->vat_registered == 1 ? '01' : '00';
                $detail[] = '3';
                $detail[] = '0';
                $detail[] = $v->expense_code;
                $detail[] = $v->description;
                $detail[] = '4';
                $detail[] = $v->code;
                $detail[] = '001';

                $fileData .= implode(',', $detail) . PHP_RN;
            }
        }

        $networkData = Network::where('id', $nid)->get()->first();

        $data = array();
        $data['network'] = $networkData->name;
        $data['month'] = $month;

        $sos = Config::where("key", "generate_credit_note")->first();
        if (!empty($sos->value))
        {
            $data = (object) $data;
            $this->sendEmails($sos->value, new CreditnoteProcess($data));
        }

        $tenant = tenant()->getTenantKey();
        Storage::disk('local')->put('ogr/credit_note/' . 'TnT_' . $tenant . '_CreditNote_' . $networkData->name . '_' . date('Y-m', strtotime($month)) . '.csv', $fileData);

        return Storage::download('ogr/credit_note/' . 'TnT_' . $tenant . '_CreditNote_' . $networkData->name . '_' . date('Y-m', strtotime($month)) . '.csv');
    }

    private function get_fin_period($date)
    {
        $month = date('M', strtotime($date));

        switch ($month)
        {
            case 'Jun':
                return '1';
                break;
            case 'Jul':
                return '2';
                break;
            case 'Aug':
                return '3';
                break;
            case 'Sep':
                return '4';
                break;
            case 'Oct':
                return '5';
                break;
            case 'Nov':
                return '6';
                break;
            case 'Dec':
                return '7';
                break;
            case 'Jan':
                return '8';
                break;
            case 'Feb':
                return '9';
                break;
            case 'Mar':
                return '10';
                break;
            case 'Apr':
                return '11';
                break;
            case 'May':
                return '12';
                break;
        }
    }
}
