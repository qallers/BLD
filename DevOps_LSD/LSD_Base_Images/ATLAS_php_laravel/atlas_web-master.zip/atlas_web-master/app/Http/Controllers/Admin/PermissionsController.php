<?php

namespace App\Http\Controllers\Admin;

use Spatie\Permission\Models\Permission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StorePermissionsRequest;
use App\Http\Requests\Admin\UpdatePermissionsRequest;
use Illuminate\Support\Facades\Session;
use RealRashid\SweetAlert\Facades\Alert;

class PermissionsController extends Controller {

    /**
     * Display a listing of Permission.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        if (!Gate::allows('view_user')) {
            return abort(401);
        }

        $permissions = Permission::all();

        return view('admin.permissions.index', compact('permissions'));
    }

    /**
     * Show the form for creating new Permission.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        if (!Gate::allows('add_user')) {
            return abort(401);
        }
        return view('admin.permissions.create');
    }

    /**
     * Store a newly created Permission in storage.
     *
     * @param  \App\Http\Requests\StorePermissionsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorePermissionsRequest $request) {
        if (!Gate::allows('add_user')) {
            return abort(401);
        }
        Permission::create($request->all());
        Alert::success('Success', 'The permission has been created.');

        return redirect()->route('admin.permissions.index');
    }

    /**
     * Show the form for editing Permission.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Permission $permission) {
        if (!Gate::allows('edit_user')) {
            return abort(401);
        }

        return view('admin.permissions.edit', compact('permission'));
    }

    /**
     * Update Permission in storage.
     *
     * @param  \App\Http\Requests\UpdatePermissionsRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatePermissionsRequest $request, Permission $permission) {
        if (!Gate::allows('edit_user')) {
            return abort(401);
        }

        $permission->update($request->all());
        Alert::success('Success', 'The permission has been updated.');

        return redirect()->route('admin.permissions.index');
    }

    /**
     * Remove Permission from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Permission $permission) {
        if (!Gate::allows('edit_user')) {
            return abort(401);
        }

        $permission->delete();

        return redirect()->route('admin.permissions.index');
    }

    public function show(Permission $permission) {
        if (!Gate::allows('view_user')) {
            return abort(401);
        }

        return view('admin.permissions.show', compact('permission'));
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'Activated';
        } else {
            $msg = 'Inactivated';
            $is_active = 0;
        }
        Permission::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The Permission has been $msg Successfully"
        ]);
    }

    /**
     * Delete all selected Permission at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request) {
        Permission::whereIn('id', request('ids'))->update(['is_active' => 1]);
        Session::flash('message', 'The Role has been Inactivated Successfully');
        return response()->noContent();
    }

}
