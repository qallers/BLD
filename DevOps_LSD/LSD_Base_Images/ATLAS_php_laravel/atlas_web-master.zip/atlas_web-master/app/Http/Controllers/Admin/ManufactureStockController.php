<?php

namespace App\Http\Controllers\Admin;

use App\Box;
use App\User;
use App\Stock;
use App\Config;
use App\Status;
use App\Product;
use App\StockLedger;
use App\ManufactureStock;
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Notification;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\StoreOgrRequest;
use App\Notifications\ManufactureStockCreated;
use App\Http\Controllers\Traits\PDFExportTrait;
use App\Notifications\ManufactureStockApproved;
use App\Notifications\ManufactureStockRejected;
use App\Http\Controllers\Traits\NotificationTraits;
use App\Http\Controllers\Traits\ManufactureStockTrait;
use App\Http\Controllers\Traits\ParentChildTrait;
use Illuminate\Support\Facades\Config as FacadesConfig;
use App\Http\Requests\Admin\UpdateManufactureStockRequest;
use App\Http\Requests\Admin\StoreManufactureProductRequest;

class ManufactureStockController extends Controller {

    use ManufactureStockTrait;
    use NotificationTraits;
    use PDFExportTrait;
    use ParentChildTrait;

    public function index() {
        $product = ManufactureStock::with('product', 'status')->get();
        return view('admin.manufacturestock.index', compact('product'));
    }

    /**
     * Show the form for creating new product.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        return view('admin.manufacturestock.create');
    }

    public function checkdup($code) {

        $dup = Product::where("product_code", $code)->count();
        $sos = Config::where("key", "manufacture_product_status")->first();
        if ($dup > 0) {
            return response()->json([
                        'status' => "400",
                        'msg' => "Product code already used",
                        'count' => 0
            ]);
        } else {

            $status = Status::where("process", 'manufacture_stock')->where("status", "approved")->first()->id;
            $dup = ManufactureStock::where("product_code", $code)->where("status_id", $sos->value)->count();

            if ($dup > 0) {
                return response()->json([
                            'status' => "400",
                            'msg' => "Product code already used",
                            'count' => 0
                ]);
            }
        }
        return response()->json([
                    'status' => "200",
                    'msg' => "true",
                    'count' => 0
        ]);
    }

    /**
     * Store a newly created product in storage.
     *
     * @param  \App\Http\Requests\StoreProductRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreManufactureProductRequest $request) {
        $user = auth()->user();
        $request->request->add(['user_id' => $user->id]);

        $code = $request->input('product_code');

        $dup = Product::where("product_code", $code)->count();
        $sos = Config::where("key", "manufacture_product_status")->first();
        if ($dup > 0) {
            Alert::error('Error', 'Product code already used');
            return redirect()->route('admin.manufacturestock.create');
        } else {

            $status = Status::where("process", 'manufacture_stock')->where("status", "approved")->first()->id;
            $dup = ManufactureStock::where("product_code", $code)->where("status_id", $sos->value)->count();

            if ($dup > 0) {
                Alert::error('Error', 'Product code already used');
                return redirect()->route('admin.manufacturestock.create');
            }
        }

        $order = ManufactureStock::create($request->all());

        $order->status_id = $sos->value;
        $this->generatePDFStock($order);
        $order = $this->check_approval($order);
        $this->sendEmails($sos->value, new ManufactureStockCreated($order));
        Alert::success('Success', 'The Manufacture Stock Order has been sent for approval.');
        return redirect()->route('admin.manufacturestock.index');
    }

    public function update_nav(Request $request) {
        ManufactureStock::where('id', $request->input("id"))
                ->update(['reference' => $request->input("nav_id")]);
        $order = ManufactureStock::find($request->id);
        $this->generatePDFStock($order);
        return response()->json([
                    "msg" => "External Reference has been updated successfully.",
                    "code" => 200
        ]);
    }

    public function approve($id) {
        /** @var Admin/audits $admin/audits */
        $res = $this->approveOrder($id);

        if (!empty($res)) {
            if ($res == 'done') {
                $order = ManufactureStock::with('product')->where("id", $id)->get()->first();
                $product = array();
                $product['manufacture_id'] = $id;
                $product['description'] = $order->description;
                $product['product_code'] = $order->product_code;
                $product['network_id'] = $order->product->network_id;
                $product['supplier_id'] = $order->product->supplier_id;
                $product['product_type_id'] = $order->product->product_type_id;
                $product['is_active'] = 1;
                $product['cost_price'] = $order->cost_price;
                $product['sale_price'] = $order->sale_price;

                Product::create($product);
            }
            $order = ManufactureStock::find($id)->load("user");
            $this->generatePDFStock($order);
            $u = User::find($order->user_id);
            $u->notify(new ManufactureStockApproved($order));

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $order->id;
            $sl['status_id'] = $order->status_id;
            $sl['qty'] = 0;

            $sl['order_name'] = "PURCHASE";
            $sl['process_name'] = "approve_order";

            StockLedger::create($sl);
            Alert::success('Success', 'The manufactured stock has been approved.');
        } else {
            Alert::error('Error', 'There is an issue approving your order. Please contact administrator.');
        }
        return back();
    }

    public function reject($id) {
        $order = ManufactureStock::with("status")->where("id", $id)->get()->first();
        $soaa = Config::where("key", "manufacture_stock_apply_approval")->first();
        if ($order->status->id != $soaa->value) {
            Alert::error('Error!', 'You cannot reject approved order');
        } else {
            $status = Status::where('process', 'manufacture_stock')->where('status', 'rejected')->get()->first();
            ManufactureStock::where('id', $id)
                    ->update(['status_id' => $status->id]);

            if (!empty($order->user_id)) {
                $u = User::find($order->user_id);
                $u->notify(new ManufactureStockRejected($order));
            }
            $this->generatePDFStock($order);
            Alert::success('Success', 'Order has been rejected.');
        }
        return back();
    }

    public function scan(StoreOgrRequest $request) {
        $input = str_replace(' ', '', $request->input("input"));
        $pid = $request->input('pid');
        $m = ManufactureStock::where('id', $pid)->first();
        $pfrom = $request->input('pfrom');
        $box_type = str_replace(' ', '', $request->input("box_type"));

        $prod = Product::where("manufacture_id", $pid)->first();
        if (empty($prod->id)) {
            return response()->json([
                        'status' => "400",
                        'msg' => "Order is in approval process",
                        'count' => 0
            ]);
        }

        if ($box_type == 'internal') {
            $boxdata = Box::where('barcode', $input)->first();

            if (empty($boxdata->id)) {
                return response()->json([
                            'status' => "400",
                            'msg' => "Box not found or you select wrong box type",
                            'count' => 0
                ]);
            }

            $getChild = $this->getChildBox($boxdata->id);
            if (count($getChild)==1 && $getChild[0]==$boxdata->id){
                $box = $boxdata->id;
                $cntQty = DB::table('stock')->where("box_id", $box)->count();
                $data = DB::table('stock')->where("box_id", $box)->get();
            } else {
                $cntQty = DB::table('stock')->whereIn("box_id", $getChild)->count();
                $data = DB::table('stock')->whereIn("box_id", $getChild)->get();
            }

            $cntAllocateQty = DB::table('stock')->where("product_id", $prod->id)->count();

            $qtyValidate = $m->qty - $cntAllocateQty;

            if ((int) $cntQty > (int) $qtyValidate) {
                return response()->json([
                            'status' => "400",
                            'msg' => "The allocated quantity is more than order quantity",
                            'count' => 0
                ]);
            }

            $cnt = 0;
            $serial = array();
            foreach ($data as $sr) {
                $affected = DB::update("UPDATE stock SET product_id = $prod->id where serial_no = '$sr->serial_no' and product_id = $pfrom and (sales_order_detail_id = 0 OR sales_order_detail_id IS NULL)");
                if (empty($affected)) {
                    $serial[] = $sr->serial_no;
                } else {
                    $cnt++;
                }
            }
            $order = $m;
            $this->generatePDFStock($order);
            if ($cnt <= 0) {
                return response()->json([
                            'status' => "400",
                            'msg' => "Starter Pack already sold or Parent product does not match",
                            'count' => $cnt,
                            'noFound' => implode(',', $serial)
                ]);
            }

            return response()->json([
                        'status' => "200",
                        'msg' => "Total $cnt starter pack assigned",
                        'count' => $cnt,
                        'noFound' => implode(',', $serial)
            ]);
        }
        if ($box_type == 'external') {

            $cntQty = DB::table('grv')->where("is_available", 0)->where(function ($query) use ($input) {
                        $query->where("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input);
                    })->count();

            if ($cntQty > 0) {
                return response()->json([
                            'status' => "400",
                            'msg' => "This box starter pack has been used for internal box OR allocated",
                            'count' => 0
                ]);
            }

            $data = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->get();

            if (empty($data[0])) {
                return response()->json([
                            'status' => "400",
                            'msg' => "Box or starter pack not found",
                            'count' => 0
                ]);
            }

            $cntQty = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->count();

            $cntAllocateQty = DB::table('stock')->where("product_id", $prod->id)->count();

            $qtyValidate = $m->qty - $cntAllocateQty;

            if ((int) $cntQty > (int) $qtyValidate) {
                return response()->json([
                            'status' => "400",
                            'msg' => "The allocated quantity is more than order quantity",
                            'count' => 0
                ]);
            }

            $cnt = 0;
            $serial = array();
            foreach ($data as $sr) {
                $affected = DB::update("UPDATE stock SET product_id = $prod->id where serial_no = '$sr->serial_no' and product_id = $pfrom and (sales_order_detail_id = 0 OR sales_order_detail_id IS NULL)");
                if (empty($affected)) {
                    $serial[] = $sr->serial_no;
                } else {
                    $cnt++;
                }
            }
            $order = $m;
            $this->generatePDFStock($order);
            if ($cnt <= 0) {
                return response()->json([
                            'status' => "400",
                            'msg' => "Starter Pack already sold",
                            'count' => $cnt,
                            'noFound' => implode(',', $serial)
                ]);
            }

            return response()->json([
                        'status' => "200",
                        'msg' => "Total $cnt starter pack assigned",
                        'count' => $cnt,
                        'noFound' => implode(',', $serial)
            ]);
        }
    }

    public function show($id) {
        $status = $this->check_order($id);
        $product = ManufactureStock::with('product')->find($id);
        $np = Product::where("manufacture_id", $id)->get()->first();
        if (!empty($np)) {
            $stock_count = Stock::where('product_id', $np->id)->count();
        } else {
            $stock_count = 0;
        }

        return view('admin.manufacturestock.show', compact('product', 'status', 'stock_count'));
    }

    /* update product */

    public function edit(ManufactureStock $manufacturestock) {
        return view('admin.manufacturestock.edit', compact('manufacturestock'));
    }

    public function update(UpdateManufacturestockRequest $request, Manufacturestock $manufacturestock) {

        $manufacturestock->update($request->all());
        $order = ManufactureStock::find($manufacturestock->id);
        $this->generatePDFStock($order);
        Alert::success('Success', 'The manufactured stock has been updated.');
        return redirect()->route('admin.manufacturestock.index');
    }

}
