<?php

namespace App\Http\Controllers\Traits;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\TransferException;


trait HttpController
{
    //Post
    function test(){
        //Log::info('Trait Logging');
        return 'Trait test';
    }
    public function post($url=null, $headers = array(), $body= array(),$ticketID=null, $attemptCount = 0){

        try{
            
            $httpClient = new Client();
            $request = $httpClient->request('POST',$url,[
                'headers'=>$headers,
                'form_params'=>$body
            ]);

            $responseContent = $request->getBody();
           // Log::info($responseContent);
		   
		   //echo $responseContent;
		  // echo '<br/>';

            return json_decode($responseContent);
        }
        catch(TransferException $e){
            //Log::error($e);
            //Log::info("Post to $url failed");

            $responseBody = $e->getResponse()->getBody(true);

            //Log::info($responseBody);
            
            
            return $responseBody;
        }
    }

    //Delete
    public function delete($url=null, $headers = array(), $body= array()){

        try{
            // Log::info("Url: $url");
            // Log::info(json_encode($body));
            // Log::info(json_encode($headers));
            $httpClient = new Client();
            $request = $httpClient->request("DELETE",$url,[
                'headers'=>$headers,
                'form_params'=>$body
            ]);

            $responseContent = $request->getBody();

            return $responseContent;
        }
        catch(TransferException $e){
            //Log::info("Post to $url failed");

            $responseBody = $e->getResponse()->getBody(true);

            //Log::info($responseBody);
        }
    }

    //Get
    public function get($url=null, $headers = array(),$attemptCount = 0){
        try{
            $httpClient = new Client();
            $request = $httpClient->request('GET',$url,['headers'=>$headers]);

            $responseContent = $request->getBody();

            return $responseContent;
        }
        catch(TransferException $e){
            
            //Log::error("Failed to make a get: $url, attempt count $attemptCount");
            

         

                $responseBody = $e->getResponse()->getBody(true);

                //Log::info($responseBody);
                return null;
            
            
        }
    }

    //Put
    public function put($url=null, $headers = array(), $body= array()){

        try{
            $httpClient = new Client();
            $request = $httpClient->request('PUT',$url,[
                'headers'=>$headers,
                'form_params'=>$body
            ]);

            $responseContent = $request->getBody();
            return $responseContent;
        }
        catch(TransferException $e){
            //Log::info("Post to $url failed");

            $responseBody = $e->getResponse()->getBody(true);

            //Log::info($responseBody);
        }
    }

    //Post Upload
    public function upload($url=null, $headers=array(),$filePath,$fileName=null){
        try{
            $httpClient = new Client();
            $request = $httpClient->request('POST',$url,[
                'headers'=>$headers,
                'multipart'=>[
                    'name'=>'Filedata',
                    'contents'=>fopen($filePath,'r'),
                    'filename'=>$fileName
                ]
            ]);

            $status_code = $res->getStatusCode();

            //Log::info("Upload status code: $status_code");

            $responseContent = $request->getBody();
            $decodedContent = json_decode($responseContent);
            $safe4Path = $decodedContent->{'url'};

            return $url;
        }
        catch(TransferException $e){
            //Log::info("Post to $url failed");

            $responseBody = $e->getResponse()->getBody(true);

            //Log::info($responseBody);
        }
    }
}
