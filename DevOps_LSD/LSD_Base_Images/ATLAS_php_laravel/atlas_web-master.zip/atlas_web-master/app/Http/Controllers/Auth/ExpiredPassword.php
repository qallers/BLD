<?php

namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PasswordExpiredRequest as AdminPasswordExpiredRequest;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;

class ExpiredPassword extends Controller
{

    public function expired()
    {
        //Alert::error("You must change your password before you move forward.😎");
        return view('auth.passwords.expired');
    }

    public function postExpired(AdminPasswordExpiredRequest $request)
    {
        
        // Checking current password
        if (!Hash::check($request->current_password, $request->user()->password)) {
            Alert::error("Current Password is not current");
            return redirect()->back();
        }

        $request->user()->update([
            'password' => bcrypt($request->password),
            'is_active'=>1,
            'password_changed_at' => Carbon::now()->toDateTimeString()
        ]);
        
        Alert::success("Password changed successfully.👌");
        return redirect("admin/home");
    }
}