<?php

namespace App\Http\Controllers\Admin;

use App\Config;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreDefaultsRequest;
use Illuminate\Support\Facades\Gate;
use App\Http\Requests\Admin\StoreStatusRequest;
use App\Http\Requests\Admin\UpdateDefaultsRequest;
use App\Http\Requests\Admin\UpdateStatusRequest;
use Flash;
use Response;
use App\Status;
use Spatie\Activitylog\Models\Activity;
use DataTables;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Session;
use RealRashid\SweetAlert\Facades\Alert;

class DefaultsController extends Controller {

    public function index() {
        if (!Gate::allows('view_defaults')) {
            return abort(401);
        }

        return view('admin.defaults.index');
        }


    /**
     * Display a listing of the Admin/audits.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function status_byname(Request $request) {
        /** @var Admin/audits $admin/audits */
        $data = Status::where('process', $request->input("process"))->get();

        return view("ajax.status_by_name", compact('data'));
    }

    /**
     * Show the form for creating new Status.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        if (!Gate::allows('add_defaults')) {
            return abort(401);
        }
        $process=Status::groupBy("process")->get();
        return view('admin.defaults.create',compact('process'));
    }

    public function store(StoreDefaultsRequest $request) {
        if (!Gate::allows('add_defaults')) {
            return abort(401);
        }
        Config::create($request->all());
        Alert::success('Success', "The default config has been created.");
        return redirect()->route('admin.defaults.index');
    }

    public function show(Config $config) {
        if (!Gate::allows('view_defaults')) {
            return abort(401);
        }
        dd($config);
        return view('admin.defaults.show', compact('config'));
    }

    /* update Status */

    public function edit($id) {
        if (!Gate::allows('edit_defaults')) {
            return abort(401);
        }
        $config=Config::find($id);
        return view('admin.defaults.edit',compact('config'));
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Status::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The status has been $msg successfully"
        ]);
    }

    public function update(UpdateDefaultsRequest $request, $id) {

        if (!Gate::allows('edit_defaults')) {

            return abort(401);
        }

        Config::find($id)->update($request->all());
        Alert::success('Success', "The default config has been updated.");
        return redirect()->route('admin.defaults.index');
    }

}
