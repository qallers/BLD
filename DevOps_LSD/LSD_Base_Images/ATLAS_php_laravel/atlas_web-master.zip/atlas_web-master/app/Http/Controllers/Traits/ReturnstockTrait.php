<?php

namespace App\Http\Controllers\Traits;

use App\Approvals;
use App\ApprovalStages;
use App\Config;
use App\StagesRoles;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use App\Notifications\ReturnStockApproval;
use App\User;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\Config as FacadesConfig;

trait ReturnstockTrait
{

    use PDFExportTrait;
    /**
     * File upload trait used in controllers to upload files
     */
    public function check_approval_return($order)
    {
        $cs = $order->status_id;
        $soaa = Config::where("key", "return_stock_apply_approval")->first();
        if ($cs == $soaa->value) {
            $soa = Config::where("key", "return_stock_approval")->first();
            $order->approval_id = $soa->value;
            $order->priority = 1;
            $order->save();


            $aid = ApprovalStages::where('approval_id', $soa->value)->where("priority", 1)->first();
            $users = Role::whereIn('id', $aid->approved_by->pluck('roles')->pluck("id"))->with('users')->get();
            foreach ($users as $key => $value) {
                foreach ($value->users()->pluck("id") as $k => $user) {
                    $u = User::find($user);
                    $u->notify(new ReturnStockApproval($order));
                }
            }
        }
        return $order;
    }

    public function check_order_return($order)
    {
        $o = $this->getMyOrder_return();

        $co = $o["orders"]->where("id", $order)->first();

        $obj = [];
        if (!empty($co->id)) {
            $obj["isMine"] = true;
            $c = $o["Approvals"]->where("approval_id", $co->approval_id)->get("priority")->first();

            if (empty($c)) {
                $obj["needsApproval"] = 0;
                $ap = Approvals::find($co->approval_id);

                if ($ap->status_id == $co->status_id) {
                    $obj["isApproved"] = 1;
                } else {
                    $obj["isApproved"] = 0;
                }
            } else {
                if ($co->priority > $c->priority) {
                    $obj["needsApproval"] = 0;
                    $obj["isApproved"] = 1;
                } else if ($co->priority == $c->priority) {
                    $obj["needsApproval"] = 1;
                    $obj["isApproved"] = 0;
                } else {
                    $obj["needsApproval"] = 0;
                    $obj["isApproved"] = 0;
                }
            }
        } else {
            $obj["isMine"] = false;
        }

        return (object) ($obj);
    }

    public function approveOrder_return($order)
    {

        $status = $this->check_order_return($order);

        if ($status->isMine && $status->needsApproval) {

            $order = \App\Returnstockmaster::find($order)->load('user');

            $res = $order->increment('priority');

            $aid = ApprovalStages::where('approval_id', $order->approval_id)->where("priority", $order->priority)->first();

            if ($aid) {
                $users = Role::whereIn('id', $aid->approved_by->pluck('roles')->pluck("id"))->with('users')->get();
                foreach ($users as $key => $value) {
                    foreach ($value->users()->pluck("id") as $k => $user) {
                        $u = User::find($user);
                        $u->notify(new ReturnStockApproval($order));
                    }
                }
            } else {
                $approvals = Approvals::find($order->approval_id);
                $order->status_id = $approvals->status_id;
                $order->save();
                $this->generatePDFReturn($order);
                return 'done';
            }
            return 'done';
        } else {
            return false;
        }
    }

    public function getMyOrder_return()
    {
        $aid = Config::where("key", "return_stock_approval")->first();
        $user = Auth::user();
        $stages = StagesRoles::whereIn("role_id", $user->roles->pluck("id"))->get();
        $approvals = ApprovalStages::whereIn("id", $stages->pluck("stage_id"))
            ->select(DB::raw("distinct approval_id,priority"));
        $order = \App\Returnstockmaster::where(function ($q) use ($approvals, $user) {
            $q->whereIn('approval_id', $approvals->get()->pluck("approval_id"))
                ->orWhere('user_id', $user->id);
        });

        return ["Approvals" => $approvals, "orders" => $order];
    }
}
