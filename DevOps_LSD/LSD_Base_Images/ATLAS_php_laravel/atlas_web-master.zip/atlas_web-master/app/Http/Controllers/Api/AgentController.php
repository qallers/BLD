<?php

namespace App\Http\Controllers\Api;

use App\User;
use App\Status;
use App\Customer;
use App\UserType;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use App\Notifications\NewUserCreated;
use Illuminate\Support\Facades\Validator;
use MarcinOrlowski\ResponseBuilder\ResponseBuilder;
use MarcinOrlowski\ResponseBuilder\ResponseBuilderBase;

class AgentController extends Controller {
  /**
     * @OA\Post(
     ** path="/api/v1/agent/register",
     *   tags={"Agent"},
     *   summary="register new agent by rep users",
     *   operationId="agentRegister",
     *   security={
     *      {"passport": {}},
     *   },
     *   @OA\Parameter(
     *      name="username",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="email",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="first_name",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="last_name",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="name",
     *      in="query",
     *      description="This is business name",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="identity_type_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="identity_reference",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="identity_reference_expiry_date",
     *      in="query",
     *      required=false,
     *      description="yyyy-mm-dd",
     *      @OA\Schema(
     *          type="string",
     *          format="date"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="identity_reference_origin_country",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="payment_method_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     * 
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     */
    public function register(Request $request) {
        $request->request->add(['cust_code' => $request->username]);
        $validator = Validator::make($request->all(),[
            'username' => 'required|unique:users',
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email|unique:users,email',
            'identity_type_id'=>'required',
            'payment_method_id' => 'required',
            'identity_reference'=>'required',
            'name'=>'required',
            'cust_code' => 'required|unique:customer,cust_code'
        ],[
            'cust_code.unique'=> "This username has been already used as cust code."
        ]);

        if ($validator->fails()) {
            return responder()->error(400,"vaidation_error")->data(['data'=>$validator->errors()])->respond(400);
        }
        $request->request->add(["user_type_id"=>4]);
        $passwrod = Str::random(8);
        $request->request->add(['password' => Hash::make($request->$passwrod)]);
        $request->request->add(['email' => filter_var($request->input('email'), FILTER_SANITIZE_STRING)]);

        $user = User::create($request->all());
        $customer=[
            "cust_code"=>$request->username,
            "name"=>$request->name,
            "group_id"=>1,
            "identity_type_id"=>$request->identity_type_id,
            "payment_method_id"=>$request->payment_method_id,
            "identity_reference"=>$request->identity_reference,
            "vat_registered"=>0,
            "user_id"=>$user->id,
            "is_active"=>0,
            "rep_user_id"=>Auth::user()->id,
            "status_id"=>Status::whereProcess("new_customer")->whereStatus("fica_approval")->first()->id,
        ];
        if($request->filled("identity_reference_expiry_date")){
            $customer["identity_reference_expiry_date"]=$request->identity_reference_expiry_date;
        }
        if($request->filled("identity_reference_origin_country")){
            $customer["identity_reference_origin_country"]=$request->identity_reference_origin_country;
        }
        $cus=Customer::create($customer);
        if(!$cus->id){
            responder()->error(500,"Agent Not created. Please contact admin.")->respond(500);
        }else{
            return responder()->success($cus)->respond(200);
        }
    }
}
