<?php

namespace App\Http\Controllers\Api;

use App\Box;
use App\User;
use Response;
use App\Stock;
use Exception;
use App\Config;
use App\Status;
use App\Product;
use App\Supplier;
use App\Warehouse;
use App\RepTransfer;
use App\StockLedger;
use App\Notification;
use App\RepTransferDetails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Notifications\RepOrderCreated;
use App\Notifications\RepOrderRejected;
use RealRashid\SweetAlert\Facades\Alert;
use \App\Http\Controllers\Traits\RepOrderTrait;
use App\Http\Controllers\Traits\PDFExportTrait;
use App\Http\Controllers\Traits\NotificationTraits;
use App\Http\Controllers\Traits\NavisionHelperTraits;
use App\Http\Controllers\Traits\ParentChildTrait;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Traits\ActivityLogTrait;

class ReptransferController extends Controller
{
    use RepOrderTrait;
    use NavisionHelperTraits;
    use NotificationTraits;
    use PDFExportTrait;
    use ParentChildTrait;
    use ActivityLogTrait;

    /**
     * Show the form for creating a new Admin/audits.
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $status_rep = Status::where('process', 'rep_order')->get();
        return view('admin.rep.index', compact('status_rep'));
    }

    public function index_approve(Request $request)
    {
        $status_rep = Status::where('process', 'rep_order')->get();
        return view('admin.rep.index_approve', compact('status_rep'));
    }

    public function edit(RepTransfer $purchase)
    {
        $product = Product::all();
        $supplier = Supplier::all();
        $warehouse = Warehouse::all();
        $costprice = Product::where('id', $purchase->product_id)->get();
        return view('admin.rep.edit', compact('purchase', 'product', 'supplier', 'warehouse', 'costprice'));
    }

    public function store(Request $request)
    {
        $user = auth()->user();

        $request->request->add(['user_id' => $user->id]);
        RepTransfer::create($request->input());
        return redirect()->route('admin.purchase.create');
    }

    public function reject($id)
    {
        $order = RepTransfer::with("status")->where("id", $id)->get()->first();
        $soaa = Config::where("key", "purchase_order_apply_approval")->first();
        if ($order->status->id != $soaa->value)
        {
            Alert::error('Error!', 'You cannot reject an approved order');
        }
        else
        {
            $status = Status::where('process', 'purchase_order')->where('status', 'rejected')->get()->first();
            RepTransfer::where('id', $id)
                ->update(['status_id' => $status->id]);
            if (!empty($order->user_id))
            {
                $u = User::find($order->user_id);
                $u->notify(new RepOrderRejected($order));
            }
            Alert::success('Success', 'Purchase Order has been rejected.');
        }
        return back();
    }

    public function update_status(Request $request)
    {
        RepTransfer::where('id', $request->input("id"))
            ->update(['status_id' => $request->input("status")]);

        $user = auth()->user();

        $order = RepTransfer::with("product", "warehouse")->where("id", $request->input("id"))->get()->first();

        $sl = array();
        $sl['user_id'] = Auth::user()->id;
        $sl['order_id'] = $request->input("id");
        $sl['qty'] = 0;
        $sl['status_id'] = $request->input("status");

        $sl['order_name'] = "REP";
        $sl['process_name'] = "update_status";

        StockLedger::create($sl);

        Notification::create([
            'from_user' => $user->id,
            'to_user' => 1,
            'title' => $order->warehouse->description . ' has received your order',
            'message' => $order->product->description . " product received by " . $order->warehouse->description . ' warehouse',
            'type' => "Received",
            "url" => "admin/purchase/"
        ]);

        return response()->json([
            "msg" => "Status has been updated successfully.",
            "code" => 200
        ]);
    }

    public function listdata(Request $request)
    {

        $order = RepTransfer::with('warehouse', 'status', 'user')->get();

        return datatables()->of($order)
            ->make();
    }

    public function listdata_approve(Request $request)
    {

        $order = $this->getMyOrder()["orders"]->with('warehouse', 'status', 'user')->get();

        return datatables()->of($order)
            ->make();
    }

    public function approve($id)
    {
        /** @var Admin/audits $admin/audits */
        if ($this->approveOrder($id))
        {
            $order = RepTransfer::find($id)->load("user");

            $u = \App\User::find($order->user_id);
            $u->notify(new \App\Notifications\RepOrderApproved($order));

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $order->id;
            $sl['status_id'] = $order->status_id;
            $sl['qty'] = 0;

            $sl['order_name'] = "REP";
            $sl['process_name'] = "approve_order";

            \App\StockLedger::create($sl);
            Alert::success('Success', 'Order has been approved.');
        }
        else
        {
            Alert::error('Error!', 'There is an issue approving your order. Please contact the administrator.');
        }
        return back();
    }

    public function update_nav(Request $request)
    {
        RepTransfer::where('id', $request->input("id"))
            ->update(['external_reference' => $request->input("nav_id")]);

        return response()->json([
            "msg" => "Purchase order has been updated successfully.",
            "code" => 200
        ]);
    }

    /**
     * @OA\Post(
     *      path="/api/v1/rep/create/transfer",
     *      operationId="createReptransfer",
     *      tags={"Rep"},
     *      summary="Create transfer order for rep",
     *      description="Returns order information",
     * security={
     *  {"passport": {}},
     *   },
     *   @OA\RequestBody(
     *       required=true,
     *       description="Bulk products Body",
     *       @OA\JsonContent(type="array",
     *      		    @OA\Items(
     *                  @OA\Property(property="product_id", type="string"),
     *                  @OA\Property(property="qty", type="string")
     *         		),
     *       )
     *     ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function createorder(Request $request)
    {
        $input = $request->json();
        $user = auth()->user();

        $order['user_id'] = $user->id;
        $order['warehouse_id'] =  $user->warehouse_id;
        $order = RepTransfer::create($order);
        $sos = Config::where("key", "rep_order_status")->first();
        $order->status_id = $sos->value;
        $order->save();

        foreach ($input as $key => $or)
        {
            $o["rep_transfer_id"] = $order->id;
            $o["qty"] = $or["qty"];
            $o["product_id"] = $or["product_id"];

            $orderData = RepTransferDetails::create($o);
        }
        $data = array("data" => $request, "Process" => "Create REP order");
        $description = "Success";
        $this->setActivityLog('', $orderData, $data, $description);

        $this->generatePDFRep($order);
        $order = $this->check_approval($order);
        $order->load(["reptransferdetail.product:id,description,product_code,network_id", "reptransferdetail.product.network"]);
        return responder()->success($order)->respond(200);
    }

    /**
     * @OA\Post(
     * * path="/api/v1/rep/transfer/scan",
     *   tags={"Rep"},
     *   summary="Scan stock to receive",
     *   operationId="scanStockRep",
     *   @OA\Parameter(
     *      name="product_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="number",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="order_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     * )
     */
    public function scan_stock_rep(Request $request)
    {
        $input = str_replace(' ', '', $request->input("number"));
        $po = $request->input('order_id');
        $OrderData = RepTransferDetails::with('reptransfer')->where("id", $po)->first();
        if ($OrderData->is_dispatch != 1)
        {
            return responder()->error(500, "You can't receive stock before it is dispatched.")->respond(500);
        }
        $pid = $request->input('product_id');

        $boxdata = Box::where('barcode', $input)->first();

        if (!empty($boxdata))
        {
            $getChild = $this->getChildBox($boxdata->id);
            $box = 0;

            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $box = $boxdata->id;
                $cntQty = DB::table('stock')->where("box_id", $box)->count();


                $affected = DB::update("UPDATE stock SET warehouse_id = " . $OrderData->reptransfer->warehouse_id . " where rep_transfer_detail_id = $po and box_id = '$box' ");


                $allSerial = Stock::where('box_id', $box)->where("rep_transfer_detail_id", $po)->get();
            }
            else
            {
                $cntQty = DB::table('stock')->whereIn("box_id", $getChild)->count();
                $affected = Stock::whereIn('box_id', $getChild)->where("rep_transfer_detail_id", $po)
                    ->update(["warehouse_id" => $OrderData->reptransfer->warehouse_id]);
                $allSerial = Stock::whereIn('box_id', $getChild)->where("rep_transfer_detail_id", $po)->get();
            }

            if ($affected <= 0)
            {
                if ($box == 0)
                    $box = $getChild;

                $w = Stock::where('box_id', $box)->first();

                if ($po != $w->rep_transfer_detail_id)
                {
                    $data = array("barcode" => $input, "data" => $request, "box_type" => "external", "Process" => "Mobile Invoice scan");
                    $description = "Box scanned to an incorrect transfer.";

                    $this->setActivityLog('', $boxdata, $data, $description);
                    return responder()->error(404, $description)->respond(404);
                }
            }

            if ($affected == 0)
            {
                if ($allSerial[0]->sales_order_detail_id != null)
                    $description = "Box Already been Sold.";
                else
                    $description = "Box already recieved.";

                $data = array("barcode" => $input, "data" => $request, "box_type" => "external", "Process" => "Mobile Invoice scan");
                $this->setActivityLog('', '', $data, $description);
                return responder()->error(404, $description)->respond(404);
            }
            else
            {
                $data = array("data" => $request, "stocks" => $allSerial, "scan_qty" => $affected, "box_type" => "internal", "Process" => "Rep transfer scanning");
                $description = "Success";
                $this->setActivityLog('', $OrderData, $data, $description);
            }

            $cntQty = Stock::where("rep_transfer_detail_id", $po)->where("warehouse_id", $OrderData->reptransfer->warehouse_id)->count();

            if ((int) $OrderData->qty == $cntQty)
            {
                RepTransferDetails::where('id', $po)
                    ->update(['is_verify' => 1]);

                $data = array("data" => $request, "box_type" => "internal", "Process" => "Rep transfer scanning");
                $description = "All quantity scanned and upddate is_verify 1 in rep transfer detail table";
                $this->setActivityLog('', $OrderData, $data, $description);
            }

            $qtyValidate = $OrderData->qty - $cntQty;

            try
            {
                $this->nav_patch_transfer($OrderData->reptransfer->external_reference, "10000", [
                    "Qty_to_Ship" => (string) $affected
                ]);
            }
            catch (Exception $e)
            {
            }
            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $po;
            $sl['qty'] = $affected;
            $sl['order_name'] = "REP";
            $sl['process_name'] = "verify_order";
            $sl['barcode'] = $input;

            StockLedger::create($sl);
            $r = RepTransferDetails::where('id', $po)->first();
            $r->product_qty = $affected;
            $r->scanned_qty = $cntQty;
            return responder()->success($r)->respond(200);
        }
        else
        {
            $cntQty = DB::table('grv')->where(function ($query) use ($input)
            {
                $query->where("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input);
            })->count();

            if ($cntQty == 0)
            {
                return responder()->error(500, "Box Not Found or Invalid.")->respond(500);
            }

            $OrderData = RepTransferDetails::with('reptransfer')->where("id", $po)->first();
            $cntStock = Stock::where("rep_transfer_detail_id", $po)->where("warehouse_id", $OrderData->reptransfer->warehouse_id)->count();

            $qtyValidate = $OrderData->qty - $cntStock;

            if ((int) $cntQty > (int) $qtyValidate)
            {
                return responder()->error(500, "Received quantity is more than order quantity or it is already your stock.")->respond(500);
            }
            if ($cntQty <= 0)
            {
                return responder()->error(500, "Stock is not available for this order")->respond(500);
            }

            $allSerial = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->get();

            $cnt = 0;
            foreach ($allSerial as $sr)
            {
                $affected = DB::update("UPDATE stock SET warehouse_id = " . $OrderData->reptransfer->warehouse_id . " where rep_transfer_detail_id = $po and serial_no = '$sr->serial_no'");
                if ($affected > 0)
                {
                    $cnt++;
                }
            }
            if (empty($cnt))
            {
                //return responder()->error(500, "Box is mismatch with allocated rep transfer request or already scanned.")->respond(500);

                $w = Stock::where('serial_no', $allSerial[0]->serial_no)->first();

                if ($po != $w->rep_transfer_detail_id)
                {
                    $data = array("barcode" => $input, "data" => $request, "box_type" => "external", "Process" => "Mobile Invoice scan");
                    $description = "Box scanned to an incorrect transfer.";

                    $this->setActivityLog('', '', $data, $description);
                    return responder()->error(404, $description)->respond(404);
                }
            }

            if ($cnt == 0)
            {
 
                $description = "Box already recieved.";

                $data = array("barcode" => $input, "data" => $request, "box_type" => "external", "Process" => "Mobile Invoice scan");
                $description = "Box already recieved.";

                $this->setActivityLog('', '', $data, $description);
                return responder()->error(404, $description)->respond(404);
            }
            else
            {
                $data = array("data" => $request, "serial_nos" => $allSerial, "scan_qty" => $affected, "box_type" => "external", "Process" => "Rep transfer scanning");
                $description = "Success";
                $this->setActivityLog('', $OrderData, $data, $description);
            }
            $cntQty = Stock::where("rep_transfer_detail_id", $po)->where("warehouse_id", $OrderData->reptransfer->warehouse_id)->count();

            if ((int) $OrderData->qty == ((int) $cntQty))
            {
                RepTransferDetails::where('id', $po)
                    ->update(['is_verify' => 1]);

                $data = array("data" => $request, "order_qty" => $OrderData->qty, "scanning_qty" => $cntQty, "box_type" => "internal", "Process" => "Rep transfer scanning");
                $description = "All quantity scanned and upddate is_verify 1 in rep transfer detail table";
                $this->setActivityLog('', $OrderData, $data, $description);
            }

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $po;
            $sl['qty'] = $cnt;
            $sl['order_name'] = "REP";
            $sl['process_name'] = "verify_order";
            $sl['barcode'] = $input;

            StockLedger::create($sl);
            $request->request->add([
                "qty" => $cnt
            ]);
            try
            {
                $this->nav_patch_transfer($OrderData->reptransfer->external_reference, "10000", [
                    "Qty_to_Ship" => (string) $cnt
                ]);
            }
            catch (Exception $e)
            {
            }
            $r = RepTransferDetails::where('id', $po)->first();
            $r->product_qty = $cnt;
            $r->scanned_qty = $cntQty;
            return responder()->success($r)->respond(200);
        }
    }
    /**
     * @OA\Post(
     * * path="/api/v1/rep/transfer/scan_revised",
     *   tags={"Rep"},
     *   summary="Scan stock to receive [New implementation]",
     * security={
     *  {"passport": {}},
     *   },
     *   operationId="scanStockRepRevised",
     *   @OA\Parameter(
     *      name="number",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     * )
     */
    public function scan_stock_rep_revised(Request $request)
    {
        $input = str_replace(' ', '', $request->input("number"));
        $validator = Validator::make($request->all(), [
            'number' => 'required'
        ]);
        if ($validator->fails())
        {
            return responder()->error(400, "vaidation_error")->data(['data' => $validator->errors()])->respond(400);
        }
        $boxdata = Box::where('barcode', $input)->first();
        if (!empty($boxdata))
        {
            $getChild = $this->getChildBox($boxdata->id);
            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $box = $boxdata->id;
                $stock = DB::table('stock')->where("box_id", $box)->first();
                $OrderData = RepTransferDetails::with('reptransfer')->where("id", $stock->rep_transfer_detail_id)->first();
                if (!$OrderData)
                {
                    return responder()->error(500, "No Transfer found for this box")->respond(500);
                }
                if ($OrderData->is_dispatch != 1)
                {
                    return responder()->error(500, "You can't receive stock before it is dispatched.")->respond(500);
                }
                $cntQty = DB::table('stock')->where("box_id", $box)->count();
                if ($OrderData->reptransfer->warehouse_id != Auth::user()->warehouse_id)
                {
                    return responder()->error(500, "Box doesn't belongs to you.")->respond(500);
                }

                // $affected = Stock::where('box_id', $box)->where("rep_transfer_detail_id", $OrderData->id)
                //     ->update(["warehouse_id" => $OrderData->reptransfer->warehouse_id]);

                $affected = DB::update("UPDATE stock SET warehouse_id = " . $OrderData->reptransfer->warehouse_id . " where rep_transfer_detail_id = $OrderData->id and box_id = '$box' ");

                $allSerial = Stock::where('box_id', $box)->where("rep_transfer_detail_id", $OrderData->id)->get();
            }
            else
            {
                $cntQty = DB::table('stock')->whereIn("box_id", $getChild)->count();
                $stock = DB::table('stock')->whereIn("box_id", $getChild)->first();
                $OrderData = RepTransferDetails::with('reptransfer')->where("id", $stock->rep_transfer_detail_id)->first();
                if (!$OrderData)
                {
                    return responder()->error(500, "No Transfer found for this box")->respond(500);
                }
                if ($OrderData->is_dispatch != 1)
                {
                    return responder()->error(500, "You can't receive stock before it is dispatched.")->respond(500);
                }
                if ($OrderData->reptransfer->warehouse_id != Auth::user()->warehouse_id)
                {
                    return responder()->error(500, "Box doesn't belongs to you.")->respond(500);
                }
                $affected = Stock::whereIn('box_id', $getChild)->where("rep_transfer_detail_id", $OrderData->id)
                    ->update(["warehouse_id" => $OrderData->reptransfer->warehouse_id]);

                $allSerial = Stock::whereIn('box_id', $getChild)->where("rep_transfer_detail_id", $OrderData->id)->get();
            }


            if ($allSerial[0]->rep_transfer_detail_id != $OrderData->id)
            {
                $description = "Box scanned to an incorrect transfer.";
                return responder()->error(500, $description)->respond(500);
            }

            if ($affected == 0)
            {
                if ($allSerial[0]->sales_order_detail_id != null)
                    $description = "Box Already been Sold.";
                else
                $description = "Box already recieved.";

               
                return responder()->error(404, $description)->respond(404);
            }
            else
            {
                $data = array("data" => $request, "stocks" => $allSerial, "scan_qty" => $affected, "box_type" => "internal", "Process" => "Rep transfer stock revised");
                $description = "Success";
                $this->setActivityLog('', $OrderData, $data, $description);
            }

            $cntQty = Stock::where("rep_transfer_detail_id", $OrderData->id)->where("warehouse_id", $OrderData->reptransfer->warehouse_id)->count();

            if ((int) $OrderData->qty == $cntQty)
            {
                RepTransferDetails::where('id', $OrderData->id)
                    ->update(['is_verify' => 1]);
            }

            $qtyValidate = $OrderData->qty - $cntQty;

            try
            {
                $this->nav_patch_transfer($OrderData->reptransfer->external_reference, "10000", [
                    "Qty_to_Ship" => (string) $affected
                ]);
            }
            catch (Exception $e)
            {
            }
            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $OrderData->id;
            $sl['qty'] = $affected;
            $sl['order_name'] = "REP";
            $sl['process_name'] = "verify_order";
            $sl['barcode'] = $input;

            StockLedger::create($sl);

            $r = RepTransferDetails::with('product')->where('id', $OrderData->id)->first();

            $response = [
                "status" => 200,
                "rep_transfer_id" => $r->rep_transfer_id,
                "product_code" => $r->product->product_code,
                "product_name" => $r->product->description,
                "transfer_qty" => $r->qty,
                "received_qty" => $cntQty,
                "pending_qty" => $qtyValidate,
            ];

            $data = array("data" => $request, "response" => $response, "Process" => "Rep transfer stock revised");
            $description = "Response to mobile";
            $this->setActivityLog('', $OrderData, $data, $description);

            return response()->json($response);
        }
        else
        {
            $allSerial = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->get();
            $cntQty = $allSerial->count();

            if ($cntQty == 0)
            {
                return responder()->error(500, "Box not found/Invalid.")->respond(500);
            }
            $stock = Stock::whereSerialNo($allSerial[0]->serial_no)->first();
            $OrderData = RepTransferDetails::with('reptransfer')->where("id", $stock->rep_transfer_detail_id)->first();
            if (empty($OrderData))
            {
                return responder()->error(500, "No Transfer found for this box")->respond(500);
            }

            $cntStock = Stock::where("rep_transfer_detail_id", $OrderData->id)->where("warehouse_id", $OrderData->reptransfer->warehouse_id)->count();
            if (!$OrderData)
            {
                return responder()->error(500, "The stock doesn't belongs to you.")->respond(500);
            }
            if ($OrderData->reptransfer->warehouse_id != Auth::user()->warehouse_id)
            {
                return responder()->error(500, "This stock doesn't belongs to you.")->respond(500);
            }

            $qtyValidate = $OrderData->qty - $cntStock;

            if ((int) $cntQty > (int) $qtyValidate)
            {
                return responder()->error(500, "Received quantity is more than order quantity or it is already your stock.")->respond(500);
            }
            if ($cntQty <= 0)
            {
                return responder()->error(500, "Stock is not available for this order")->respond(500);
            }

            $cnt = 0;
            foreach ($allSerial as $sr)
            {
                $affected = DB::update("UPDATE stock SET warehouse_id = " . $OrderData->reptransfer->warehouse_id . " where rep_transfer_detail_id = $OrderData->id and serial_no = '$sr->serial_no'");
                if ($affected > 0)
                {
                    $cnt++;
                }
            }

            if ($cnt == 0)
            {
                 
                   $description = "Box already recieved.";

                return responder()->error(500, $description)->respond(500);
            }
            else
            {
                $data = array("data" => $request, "stocks" => $allSerial, "scan_qty" => $cnt, "box_type" => "external", "Process" => "Rep transfer stock revised");
                $description = "Success";
                $this->setActivityLog('', $OrderData, $data, $description);
            }
            $cntQty = Stock::where("rep_transfer_detail_id", $OrderData->id)->where("warehouse_id", $OrderData->reptransfer->warehouse_id)->count();

            if ((int) $OrderData->qty == ((int) $cntQty))
            {
                RepTransferDetails::where('id', $OrderData->id)
                    ->update(['is_verify' => 1]);
            }

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $OrderData->id;
            $sl['qty'] = $cnt;
            $sl['order_name'] = "REP";
            $sl['process_name'] = "verify_order";
            $sl['barcode'] = $input;

            StockLedger::create($sl);
            $request->request->add([
                "qty" => $cnt
            ]);
            try
            {
                $this->nav_patch_transfer($OrderData->reptransfer->external_reference, "10000", [
                    "Qty_to_Ship" => (string) $cnt
                ]);
            }
            catch (Exception $e)
            {
            }
            $r = RepTransferDetails::with('product')->where('id', $OrderData->id)->first();
            $response = [
                "status" => 200,
                "rep_transfer_id" => $r->rep_transfer_id,
                "product_code" => $r->product->product_code,
                "product_name" => $r->product->description,
                "transfer_qty" => $r->qty,
                "received_qty" => $cntQty,
                "pending_qty" => $qtyValidate,
            ];

            $data = array("data" => $request, "response" => $response, "Process" => "Rep transfer stock revised");
            $description = "Response to mobile";
            $this->setActivityLog('', $OrderData, $data, $description);

            return response()->json($response);
        }
    }
}
