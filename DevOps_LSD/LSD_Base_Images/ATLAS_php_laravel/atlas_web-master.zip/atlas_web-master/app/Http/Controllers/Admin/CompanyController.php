<?php

namespace App\Http\Controllers\Admin;

use App\Company;
use Illuminate\Http\Request;
use App\Config;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use RealRashid\SweetAlert\Facades\Alert;

class CompanyController extends Controller {

    public function index() {
        if (!Gate::allows('view_comapny')) {
            return abort(401);
        }

        $company = Config::select("value", "key")->whereIn('key', ['company_email', 'company_address', 'company_avatar', 'company_name'])->get()->pluck('value', 'key');

        return view('admin.company.index', compact('company'));
    }
    
    public function update(Request $request) {
        foreach ($request->input() as $key => $value) {
            Config::updateOrCreate(['key'=>$key],['key'=> $key,'value' => $value]);
          
        }
        return response()->json ([
            'status' => '200',
            'msg' => 'The Company has been updated.'
           
        ]);
    }
}
