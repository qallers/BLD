<?php

namespace App\Http\Controllers\Traits;

use App\Http\Controllers\Traits\NavisionHelperTraits;
use App\Approvals;
use App\ApprovalStages;
use App\Config;
use App\PurchaseOrder;
use App\StagesRoles;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use App\Notifications\PurchaseOrderApproval;
use App\User;
use App\Warehouse;
use Exception;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\Config as FacadesConfig;

trait PurchaseOrderTrait
{
    use NavisionHelperTraits;
    use PDFExportTrait;
    /**
     * File upload trait used in controllers to upload files
     */
    public function check_approval($order)
    {
        $cs = $order->status_id;
        $soaa = Config::where("key", "purchase_order_apply_approval")->first();
        if ($cs == $soaa->value) {
            $soa = Config::where("key", "purchase_order_approval")->first();
            $order->approval_id = $soa->value;
            $order->priority = 1;
            $order->save();

            $aid = ApprovalStages::where('approval_id', $soa->value)->where("priority", 1)->first();
            $users = Role::whereIn('id', $aid->approved_by->pluck('roles')->pluck("id"))->with('users')->get();
            foreach ($users as $key => $value) {
                foreach ($value->users()->pluck("id") as $k => $user) {
                    $u = User::find($user);
                    $u->notify(new PurchaseOrderApproval($order));
                }
            }
        }
        return $order;
    }

    public function check_order($order)
    {
        $o = $this->getMyOrder();
        $co = $o["orders"]->where("id", $order)->first();
        $obj = [];
        if (!empty($co->id)) {
            $obj["isMine"] = true;
            $c = $o["Approvals"]->where("approval_id", $co->approval_id)->get("priority")->first();

            if (empty($c)) {
                $obj["needsApproval"] = 0;
                $ap = Approvals::find($co->approval_id);
                if ($ap->status_id == $co->status_id) {
                    $obj["isApproved"] = 1;
                } else {
                    $obj["isApproved"] = 0;
                }
            } else {
                if ($co->priority > $c->priority) {
                    $obj["needsApproval"] = 0;
                    $obj["isApproved"] = 1;
                } else if ($co->priority == $c->priority) {
                    $obj["needsApproval"] = 1;
                    $obj["isApproved"] = 0;
                } else {
                    $obj["needsApproval"] = 0;
                    $obj["isApproved"] = 0;
                }
            }
        } else {
            $obj["isMine"] = false;
        }

        return (object) ($obj);
    }

    public function approveOrder($order)
    {
        $status = $this->check_order($order);
        if ($status->isMine && $status->needsApproval) {
            $order = PurchaseOrder::find($order)->load('user');
            $res = $order->increment('priority');
            $aid = ApprovalStages::where('approval_id', $order->approval_id)->where("priority", $order->priority)->first();
            if ($aid) {
                $users = Role::whereIn('id', $aid->approved_by->pluck('roles')->pluck("id"))->with('users')->get();
                foreach ($users as $key => $value) {
                    foreach ($value->users()->pluck("id") as $k => $user) {
                        $u = User::find($user);
                        $u->notify(new PurchaseOrderApproval($order));
                    }
                }
            } else {
                $approvals = Approvals::find($order->approval_id);
                $order->status_id = $approvals->status_id;
                if ($order->is_rep) {
                    try {
                        $m = \App\Config::where("key", "main_warehouse")->first();
                        $warehouse = Warehouse::find($m->value);
                        $order_nav = $this->nav_post("Transfer_Order", [
                            "Transfer_from_Code" => $warehouse->warehouse_code,
                            "Transfer_to_Code" => $order->warehouse->warehouse_code,
                            "In_Transit_Code" => "IBT"
                        ]);
                        $this->nav_post("Transfer_Order('" . $order_nav[0]->No . "')/Transfer_OrderTransferLines", [
                            "Item_No" => (string)$order->product->product_code,
                            "Quantity" => (string)$order->qty
                        ]);
                        $order->external_reference = $order_nav[0]->No;
                    } catch (Exception $e) {
                    }
                } else {
                    try {
                    $order_nav = $this->nav_post("Purchase_Order", [
                        "Document_Type" => "Order",
                        "Buy_from_Vendor_No" => $order->supplier->vendor_code,
                        "Location_Code" => $order->warehouse->warehouse_code
                    ]);

                    $this->nav_post("Purchase_OrderPurchLines", [
                        "Document_Type" => "Order",
                        "Document_No" => $order_nav[0]->No,
                        "Type" => "Item",
                        "No" => $order->product->product_code,
                        "Quantity" => (string)$order->qty
                    ]);

                    $order->external_reference = $order_nav[0]->No;
                    } catch (Exception $e) {
                }
                }
                $order->save();
                $this->generatePDFPurchase($order);
            }

            return $res;
        } else {
            return false;
        }
    }

    public function getMyOrder()
    {
        $aid = Config::where("key", "purchase_order_approval")->first();
        $user = Auth::user();
        $stages = StagesRoles::whereIn("role_id", $user->roles->pluck("id"))->get();
        $approvals = ApprovalStages::whereIn("id", $stages->pluck("stage_id"))
            ->select(DB::raw("distinct approval_id,priority"));
        $order = PurchaseOrder::where(function ($q) use ($approvals, $user) {
            $q->whereIn('approval_id', $approvals->get()->pluck("approval_id"))
                ->orWhere('user_id', $user->id);
        });

        return ["Approvals" => $approvals, "orders" => $order];
    }
}
