<?php

namespace App\Http\Controllers\Api;

use Flash;
use App\Box;
use App\User;
use Response;
use stdClass;
use App\Stock;
use Exception;
use App\Config;
use App\Status;
use DataTables;
use App\Product;
use App\Contract;
use App\Customer;
use App\UserType;
use App\BulkOrder;
use App\SalesDeal;
use App\SplitDeal;
use App\TierStage;
use App\Warehouse;
use Carbon\Carbon;
use App\SalesOrder;
use App\BaseSummary;
use App\ProductDeal;
use App\StagesRoles;
use App\StockLedger;
use App\SalesInvoice;
use App\CustomerSplit;
use App\ApprovalStages;
use App\BulkOrderDetails;
use App\SalesOrderDetails;
use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Illuminate\Auth\Access\Gate;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Spatie\Activitylog\Models\Activity;
use App\Notifications\SalesOrderCreated;
use RealRashid\SweetAlert\Facades\Alert;
use App\Notifications\SalesOrderApproved;
use App\Http\Controllers\Traits\PDFExportTrait;
use App\Http\Controllers\Traits\MobileInvoiceTrait;
use App\Http\Controllers\Traits\NotificationTraits;
use App\Http\Controllers\Traits\ParentChildTrait;
use Maatwebsite\Excel\Facades\Excel as FacadesExcel;
use App\Http\Controllers\Traits\ActivityLogTrait;

class MobileInvoiceController extends Controller
{
    use NotificationTraits;
    use MobileInvoiceTrait;
    use PDFExportTrait;
    use ParentChildTrait;
    use ActivityLogTrait;

    /** 
     * @OA\Get(
     *      path="/api/v1/rep/mobile_invoice/scan",
     *      operationId="scanMobileInvoice",
     *      tags={"Rep"},
     *      summary="Change product deal of customers ",
     *      description="Returns deal informations",
     * security={
     *  {"passport": {}},
     *   },
     *  @OA\Parameter(
     *      name="barcode",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function mobile_invoice_scan(Request $request)
    {
        $input = str_replace(' ', '', $request->input("barcode"));

        $data = DB::table('grv')->where(function ($query) use ($input)
        {
            $query->where("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input);
        })->get();

        $affected = count($data);
        if ($affected == 0)
        {
            //find from internal BOx
            $boxdata = Box::where('barcode', $input)->first();
            if (empty($boxdata->id))
            {
                $data = array("barcode" => $input, "data" => $request, "box_type" => "internal", "Process" => "Mobile Invoice scan");
                $description = "Barcode scanned not found";
                $this->setActivityLog('', $boxdata, $data, $description);

                return responder()->error(404, "Barcode scanned not found")->respond(404);
            }
            $getChild = $this->getChildBox($boxdata->id);
            $box = 0;
            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $box = $boxdata->id;
                $affected = Stock::where('box_id', $box)->whereWarehouseId(Auth::user()->warehouse_id)
                    ->whereNull("sales_order_detail_id")->count();
                if ($affected != 0)
                {
                    $product = Stock::where('box_id', $box)->whereWarehouseId(Auth::user()->warehouse_id)
                        ->whereNull("sales_order_detail_id")->first()->product;
                }
            }
            else
            {
                $affected = Stock::whereIn('box_id', $getChild)->whereWarehouseId(Auth::user()->warehouse_id)
                    ->whereNull("sales_order_detail_id")->count();
                if ($affected != 0)
                {
                    $product = Stock::whereIn('box_id', $getChild)->whereWarehouseId(Auth::user()->warehouse_id)
                        ->whereNull("sales_order_detail_id")->first()->product;
                }
            }

            if ($affected == 0)
            {
                if ($box == 0)
                    $box = $getChild;

                $w = Stock::where('box_id', $box)->first();

                if (Auth::user()->warehouse_id != $w->warehouse_id)
                {
                    $data = array("barcode" => $input, "data" => $request, "box_type" => "external", "Process" => "Mobile Invoice scan");
                    $description = "Box doesn't belong to you";
                    $this->setActivityLog('', $boxdata, $data, $description);

                    return responder()->error(404, $description)->respond(404);
                }
                else
                {
                    $data = array("barcode" => $input, "data" => $request, "box_type" => "external", "Process" => "Mobile Invoice scan");
                    $description = "Box Already been Sold.";

                    $this->setActivityLog('', $boxdata, $data, $description);
                    return responder()->error(404, $description)->respond(404);
                }
            }
            else
            {
                $product->qty = $affected;
                $data = array("barcode" => $input, "data" => $request, "product" => $product, "affected" => $affected, "box_type" => "internal", "Process" => "Mobile Invoice scan");
                $description = "Success";
                $this->setActivityLog('', $boxdata, $data, $description);

                return responder()->success($product)->respond(200);
            }
        }
        else
        {
            $user = Auth::user();
            $cnt = Stock::where("serial_no", $data[0]->serial_no)
                ->where("warehouse_id", $user->warehouse_id)
                ->whereNull("sales_order_detail_id")->first();
            if (empty($cnt->serial_no))
            {

                $w = Stock::where('serial_no', $data[0]->serial_no)->first();

                if ($user->warehouse_id !=  $w->warehouse_id)
                {
                    $data = array("barcode" => $input, "data" => $request, "box_type" => "external", "Process" => "Mobile Invoice scan");
                    $description = "Box doesn't belong to you";
                    $this->setActivityLog('', '', $data, $description);

                    return responder()->error(404, $description)->respond(404);
                }
                else
                {
                    $data = array("barcode" => $input, "data" => $request, "box_type" => "external", "Process" => "Mobile Invoice scan");
                    $description = "Box Already been Sold.";
                    $this->setActivityLog('', '', $data, $description);

                    return responder()->error(404, $description)->respond(404);
                }
            }
            else
            {
                $product = Product::find($cnt->product_id);
                $product->qty = $affected;

                $data = array("barcode" => $input, "data" => $request, "product" => $product, "box_type" => "external", "Process" => "Mobile Invoice scan");
                $description = "Success";
                $this->setActivityLog('', $product, $data, $description);

                return responder()->success($product)->respond(200);
            }
        }
    }

    /** 
     * @OA\Post(
     *      path="/api/v1/rep/mobile_invoice/create",
     *      operationId="createMobileInvoiceOrder",
     *      tags={"Rep"},
     *      summary="Create sales mobile invoice for customer",
     *      description="Returns mobile invoice information",
     * security={
     *  {"passport": {}},
     *   },
     *   @OA\RequestBody(
     *       required=true,
     *       description="Bulk products Body",
     *       @OA\JsonContent(type="array",
     *      		    @OA\Items(
     *                  @OA\Property(property="customer_id", type="string"),
     *                  @OA\Property(property="warehouse_id", type="string"),
     *                  @OA\Property(property="product_id", type="string"),
     *                  @OA\Property(property="qty", type="string"),
     *                  @OA\Property(property="sales_price", type="string"),
     *                  @OA\Property(property="product_deal", type="string"),
     *                  @OA\Property(property="split_deal_id", type="string"),
     *                  @OA\Property(property="payment_status_id", type="string"),
     *                  @OA\Property(property="delivery_method_id", type="string"),
     *                  @OA\Property(property="barcode", type="string"),
     *         		),
     *       )
     *     ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function mobile_invoice_create(Request $request)
    {
        $input = $request->json()->all();
        $order = $input[0];
        $user = auth()->user();
        $order['user_id'] = $user->id;
        $order = SalesOrder::create(Arr::except($order, ['qty', 'product_id', 'product_deal', 'split_deal_id']));
        $sos = Config::where("key", "mobile_invoice_status")->first();
        $order->status_id = $sos->value;
        $msg = '';
        foreach ($input as $key => $p)
        {
            $or = (object) $p;
            $product = Product::find($or->product_id);

            $contract = Contract::where('customer_id', $or->customer_id)
                ->where('network_id', $product->network_id)->first();
            if (!$contract)
            {
                $customer = Customer::find($or->customer_id);
                $msg .= "$customer->name does not have a contract for " . $product->network->name . ", set up contract first and proceed.<br/>";
                continue;
            }
            $od = (object) $this->get_product_entry($or);

            $o["sales_order_id"] = $order->id;
            $o["qty"] = $or->qty;
            $o["sales_price"] = $or->sales_price;
            $o["product_id"] = $od->product->id;
            $o["cost"] = $or->qty * $or->sales_price;
            if (!empty($or->product_deal))
                $o["product_deal_id"] = $or->product_deal ?? '';
            else
                $o["product_deal_id"] = null;
            if (!empty($or->split_deal_id))
                $o["split_deal_id"] = $or->split_deal_id ?? '';
            else
                $o["split_deal_id"] = null;

            $deal = SalesOrderDetails::create($o);
            $o["soid"] = $deal->id;
            $o["barcode"] = $or->barcode;
            $o["customer_id"] = $or->customer_id;
            $this->allocate_stock($o);
            if ($od->contract->is_split)
            {

                foreach ($od->splits as $key => $split)
                {
                    $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                    $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                    $d["sales_order_detail_id"] = $deal->id;
                    $d["customer_id"] = $split->split_customer;
                    $d["is_tiered"] = $od->contract->is_tiered;
                    $d["is_split"] = $od->contract->is_split;
                    $d["split_customer"] = $order->customer_id == $split->split_customer ? 1 : 0;
                    $d["ogr"] = $split->ogr;
                    $d["act"] = $split->act;
                    $d["sim"] = $split->sim;
                    $d["ogr_tier"] = $split->ogr_tier;
                    $d["act_tier"] = $split->act_tier;
                    $d["sim_tier"] = $split->sim_tier;
                    $d["start_date"] = $start;
                    $d["end_date"] = new Carbon("2099-12-31");
                    SalesDeal::create($d);
                }
            }
            else
            {
                $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                $d["sales_order_detail_id"] = $deal->id;
                $d["customer_id"] = $or->customer_id;
                $d["is_tiered"] = $od->contract->is_tiered;
                $d["is_split"] = $od->contract->is_split;
                $d["split_customer"] = 0;
                $d["ogr"] = ($od->contract->is_tiered ? $od->tier->ogr : ($od->deal ? $od->deal->ogr : $od->contract->ogr));
                $d["act"] = ($od->contract->is_tiered ? $od->tier->act : ($od->deal ? $od->deal->act : $od->contract->act));
                $d["sim"] = ($od->contract->is_tiered ? $od->tier->sim : ($od->deal ? $od->deal->sim : $od->contract->sim));
                $d["start_date"] = $start;
                $d["end_date"] = new Carbon("2099-12-31");
                SalesDeal::create($d);
            }
        }
        $order->save();
        $this->generatePDFSales($order);
        $order = $this->check_approval($order);
        $this->sendEmails($sos->value, new SalesOrderCreated($order));

        try
        {
            $order_nav = $this->nav_post("Sales_Invoice", [
                "Document_Type" => "Invoice",
                "Sell_to_Customer_No" => $order->customer->cust_code,
                "Location_Code" => $order->warehouse->warehouse_code
            ]);
            foreach ($order->salesOrderDetail as $value)
            {
                $order_nav_line = $this->nav_post("Sales_InvoiceSalesLines", [
                    "Document_Type" => "Invoice",
                    "Document_No" => $order_nav[0]->No,
                    "Type" => "Item",
                    "No" => $value->product->product_code,
                    "Quantity" => (string) $value->qty
                ]);
            }
            $order->external_reference = $order_nav[0]->No;
            $order->save();
        }
        catch (Exception $e)
        {
        }
        $data_activity = array("data" => $request, "response" => $order, "msg" => $msg, "Process" => "Mobile Invoice create");
        if (!empty($msg))
        {
            $description = "Success:No Deal";
        }
        else
        {
            $description = "Success";
        }

        $this->setActivityLog('', $order, $data_activity, $description);
        return responder()->success($order)->respond(200);
    }

    public function allocate_stock($data)
    {
        $input = str_replace(' ', '', $data["barcode"]);
        $qty = str_replace(' ', '', $data["qty"]);
        $po = $data["sales_order_id"];
        $soid = $data["soid"];
        $customer_id = $data["customer_id"];

        $boxdata = Box::where('barcode', $input)->first();

        if (!empty($boxdata->id))
        {
            $getChild = $this->getChildBox($boxdata->id);
            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $box = $boxdata->id;
                $affected = Stock::where('box_id', $box)
                    ->update(['customer_id' => $customer_id, "sales_order_detail_id" => $soid]);

                $serials = Stock::where('box_id', $box)->get();
            }
            else
            {
                $affected = Stock::whereIn('box_id', $getChild)
                    ->update(['customer_id' => $customer_id, "sales_order_detail_id" => $soid]);

                $serials = Stock::whereIn('box_id', $getChild)->get();
            }

            $data_activity = array("data" => $data, "qty" => $qty, "stocks" => $serials, "allocate_qty" => $affected, "box_type" => "internal", "Process" => "Mobile Invoice allocate stock");
            $description = "Success";
            $this->setActivityLog('', $boxdata, $data_activity, $description);
        }
        else
        {

            $allSerial = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->get();

            $affected = 0;

            foreach ($allSerial as $sr)
            {
                $cnt = DB::update("UPDATE stock SET customer_id = $customer_id,sales_order_detail_id = $soid where serial_no = '$sr->serial_no'");
                $affected = $affected + $cnt;
            }

            $data_activity = array("data" => $data, "qty" => $qty, "stocks" => $allSerial, "allocate_qty" => $affected, "box_type" => "external", "Process" => "Mobile Invoice allocate stock");
            $description = "Success";
            $this->setActivityLog('', $boxdata, $data_activity, $description);

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $po;
            $sl['qty'] = $cnt;
            $sl['order_name'] = "MOBILE_INVOICE";
            $sl['process_name'] = "allocate_order_app";
            $sl['barcode'] = $input;

            StockLedger::create($sl);
        }
    }

    /** 
     * @OA\Post(
     *      path="/api/v1/rep/mobile_invoice/create_bulk",
     *      operationId="createMobileInvoiceOrderBulkAllocation",
     *      tags={"Rep"},
     *      summary="Create sales mobile invoice for customer bulk allocation",
     *      description="Create sales mobile invoice information",
     * security={
     *  {"passport": {}},
     *   },
     *   @OA\RequestBody(
     *       required=true,
     *       description="Bulk products Body",
     *       @OA\JsonContent(type="array",
     *      		    @OA\Items(
     *                  @OA\Property(property="customer_id", type="string"),
     *                  @OA\Property(property="warehouse_id", type="string"),
     *                  @OA\Property(property="product_id", type="string"),
     *                  @OA\Property(property="qty", type="string"),
     *                  @OA\Property(property="sales_price", type="string"),
     *                  @OA\Property(property="product_deal", type="string"),
     *                  @OA\Property(property="split_deal_id", type="string"),
     *                  @OA\Property(property="payment_status_id", type="string"),
     *                  @OA\Property(property="delivery_method_id", type="string"),
     *                  @OA\Property(property="barcode", type="array",
     *                      @OA\Items(
     *                          type="string"    
     *                      )
     *                  ),
     *         		),
     *       )
     *     ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function mobile_invoice_create_bulk(Request $request)
    {
        $input = $request->json()->all();
        $order = $input[0];
        $user = auth()->user();
        $order['user_id'] = $user->id;
        $order = SalesOrder::create(Arr::except($order, ['qty', 'product_id', 'product_deal', 'split_deal_id']));
        $sos = Config::where("key", "mobile_invoice_status")->first();
        $order->status_id = $sos->value;

        foreach ($input as $key => $p)
        {
            $or = (object) $p;
            $od = (object) $this->get_product_entry($or);

            $o["sales_order_id"] = $order->id;
            $o["qty"] = $or->qty;
            $o["sales_price"] = $or->sales_price;
            $o["product_id"] = $od->product->id;
            $o["cost"] = $or->qty * $or->sales_price;
            if (!empty($or->product_deal))
                $o["product_deal_id"] = $or->product_deal ?? '';
            else
                $o["product_deal_id"] = null;
            if (!empty($or->split_deal_id))
                $o["split_deal_id"] = $or->split_deal_id ?? '';
            else
                $o["split_deal_id"] = null;

            $deal = SalesOrderDetails::create($o);

            $qty = 0;
            $affected = 0;
            foreach ($or->barcode as $value)
            {
                $o["soid"] = $deal->id;
                $o["barcode"] = $value;
                $o["customer_id"] = $or->customer_id;


                $affected = $this->allocate($o);
                $qty = $qty + $affected;
            }

            $cost = $qty * $or->sales_price;

            SalesOrderDetails::where('id', $deal->id)
                ->update(['cost' => $cost, "qty" => $qty]);


            if ($od->contract->is_split)
            {

                foreach ($od->splits as $key => $split)
                {
                    $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                    $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                    $d["sales_order_detail_id"] = $deal->id;
                    $d["customer_id"] = $split->split_customer;
                    $d["is_tiered"] = $od->contract->is_tiered;
                    $d["is_split"] = $od->contract->is_split;
                    $d["split_customer"] = $order->customer_id == $split->split_customer ? 1 : 0;
                    $d["ogr"] = $split->ogr;
                    $d["act"] = $split->act;
                    $d["sim"] = $split->sim;
                    $d["ogr_tier"] = $split->ogr_tier;
                    $d["act_tier"] = $split->act_tier;
                    $d["sim_tier"] = $split->sim_tier;
                    $d["start_date"] = $start;
                    $d["end_date"] = new Carbon("2099-12-31");
                    SalesDeal::create($d);
                }
            }
            else
            {
                $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                $d["sales_order_detail_id"] = $deal->id;
                $d["customer_id"] = $or->customer_id;
                $d["is_tiered"] = $od->contract->is_tiered;
                $d["is_split"] = $od->contract->is_split;
                $d["split_customer"] = 0;
                $d["ogr"] = ($od->contract->is_tiered ? $od->tier->ogr : ($od->deal ? $od->deal->ogr : $od->contract->ogr));
                $d["act"] = ($od->contract->is_tiered ? $od->tier->act : ($od->deal ? $od->deal->act : $od->contract->act));
                $d["sim"] = ($od->contract->is_tiered ? $od->tier->sim : ($od->deal ? $od->deal->sim : $od->contract->sim));
                $d["start_date"] = $start;
                $d["end_date"] = new Carbon("2099-12-31");
                SalesDeal::create($d);
            }
        }
        $order->save();
        $this->generatePDFSales($order);
        $order = $this->check_approval($order);
        $this->sendEmails($sos->value, new SalesOrderCreated($order));

        try
        {
            $order_nav = $this->nav_post("Sales_Invoice", [
                "Document_Type" => "Invoice",
                "Sell_to_Customer_No" => $order->customer->cust_code,
                "Location_Code" => $order->warehouse->warehouse_code
            ]);
            foreach ($order->salesOrderDetail as $value)
            {
                $order_nav_line = $this->nav_post("Sales_InvoiceSalesLines", [
                    "Document_Type" => "Invoice",
                    "Document_No" => $order_nav[0]->No,
                    "Type" => "Item",
                    "No" => $value->product->product_code,
                    "Quantity" => (string) $value->qty
                ]);
            }
            $order->external_reference = $order_nav[0]->No;
            $order->save();
            $data_activity = array("data" => $request, "Process" => "Mobile Invoice create");
            $description = "Success";
            $this->setActivityLog('', $order, $data_activity, $description);
        }
        catch (Exception $e)
        {
            $data_activity = array("data" => $request, "Process" => "Mobile Invoice create");
            $description = "Fail :- " . $e->getMessage();
            $this->setActivityLog('', $order, $data_activity, $description);
        }
        return responder()->success($order)->respond(200);
    }


    /**
     * @OA\Post(
     *      path="/api/v1/rep/mobile_invoice/create_bulk_new",
     *      operationId="createMobileInvoiceOrderBulkAllocationNew",
     *      tags={"Rep"},
     *      summary="Create sales mobile invoice for customer bulk allocation",
     *      description="Create sales mobile invoice information new",
     * security={
     *  {"passport": {}},
     *   },
     *   @OA\RequestBody(
     *       required=true,
     *       description="Bulk products Body",
     *       @OA\JsonContent(type="array",
     *      		    @OA\Items(
     *                  @OA\Property(property="customer_id", type="string"),
     *                  @OA\Property(property="warehouse_id", type="string"),
     *                  @OA\Property(property="product_id", type="string"),
     *                  @OA\Property(property="qty", type="string"),
     *                  @OA\Property(property="sales_price", type="string"),
     *                  @OA\Property(property="product_deal", type="string"),
     *                  @OA\Property(property="split_deal_id", type="string"),
     *                  @OA\Property(property="payment_status_id", type="string"),
     *                  @OA\Property(property="delivery_method_id", type="string"),
     *                  @OA\Property(property="barcode", type="array",
     *                      @OA\Items(
     *                          type="string"    
     *                      )
     *                  ),
     *         		),
     *       )
     *     ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function mobile_invoice_create_bulk_new(Request $request)
    {
        $input = $request->json()->all();
        $order = $input[0];
        $user = auth()->user();
        $order['user_id'] = $user->id;
        $order = SalesOrder::create(Arr::except($order, ['qty', 'product_id', 'product_deal', 'split_deal_id']));
        $sos = Config::where("key", "mobile_invoice_status")->first();
        $order->status_id = $sos->value;


        foreach ($input as $key => $p)
        {
            $or = (object) $p;
            $od = (object) $this->get_product_entry($or);


            $o["sales_order_id"] = $order->id;
            $o["qty"] = $or->qty;
            $o["sales_price"] = $or->sales_price;
            $o["product_id"] = $od->product->id;
            $o["cost"] = $or->qty * $or->sales_price;
            if (!empty($or->product_deal))
                $o["product_deal_id"] = $or->product_deal ?? '';
            else
                $o["product_deal_id"] = null;
            if (!empty($or->split_deal_id))
                $o["split_deal_id"] = $or->split_deal_id ?? '';
            else
                $o["split_deal_id"] = null;

            $deal = SalesOrderDetails::create($o);

            $qty = 0;
            $affected = 0;

            foreach ($or->barcode as $value)
            {

                $o["soid"] = $deal->id;
                $o["barcode"] = $value;
                $o["customer_id"] = $or->customer_id;


                $affected = $this->allocate($o);
                $qty = $qty + $affected;
            }

            $cost = $qty * $or->sales_price;

            SalesOrderDetails::where('id', $deal->id)
                ->update(['cost' => $cost, "qty" => $qty]);


            if ($od->contract->is_split)
            {

                foreach ($od->splits as $key => $split)
                {
                    $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                    $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                    $d["sales_order_detail_id"] = $deal->id;
                    $d["customer_id"] = $split->split_customer;
                    $d["is_tiered"] = $od->contract->is_tiered;
                    $d["is_split"] = $od->contract->is_split;
                    $d["split_customer"] = $order->customer_id == $split->split_customer ? 1 : 0;
                    $d["ogr"] = $split->ogr;
                    $d["act"] = $split->act;
                    $d["sim"] = $split->sim;
                    $d["ogr_tier"] = $split->ogr_tier;
                    $d["act_tier"] = $split->act_tier;
                    $d["sim_tier"] = $split->sim_tier;
                    $d["start_date"] = $start;
                    $d["end_date"] = new Carbon("2099-12-31");
                    SalesDeal::create($d);
                }
            }
            else
            {
                $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                $d["sales_order_detail_id"] = $deal->id;
                $d["customer_id"] = $or->customer_id;
                $d["is_tiered"] = $od->contract->is_tiered;
                $d["is_split"] = $od->contract->is_split;
                $d["split_customer"] = 0;
                $d["ogr"] = ($od->contract->is_tiered ? $od->tier->ogr : ($od->deal ? $od->deal->ogr : $od->contract->ogr));
                $d["act"] = ($od->contract->is_tiered ? $od->tier->act : ($od->deal ? $od->deal->act : $od->contract->act));
                $d["sim"] = ($od->contract->is_tiered ? $od->tier->sim : ($od->deal ? $od->deal->sim : $od->contract->sim));
                $d["start_date"] = $start;
                $d["end_date"] = new Carbon("2099-12-31");
                SalesDeal::create($d);
            }
        }
        $order->save();
        $this->generatePDFSales($order);
        $order = $this->check_approval($order);
        $this->sendEmails($sos->value, new SalesOrderCreated($order));

        try
        {
            $order_nav = $this->nav_post("Sales_Invoice", [
                "Document_Type" => "Invoice",
                "Sell_to_Customer_No" => $order->customer->cust_code,
                "Location_Code" => $order->warehouse->warehouse_code
            ]);
            foreach ($order->salesOrderDetail as $value)
            {
                $order_nav_line = $this->nav_post("Sales_InvoiceSalesLines", [
                    "Document_Type" => "Invoice",
                    "Document_No" => $order_nav[0]->No,
                    "Type" => "Item",
                    "No" => $value->product->product_code,
                    "Quantity" => (string) $value->qty
                ]);
            }
            $order->external_reference = $order_nav[0]->No;
            $order->save();
            $data_activity = array("data" => $request, "Process" => "Mobile Invoice create");
            $description = "Success";
            $this->setActivityLog('', $order, $data_activity, $description);
        }
        catch (Exception $e)
        {
            $data_activity = array("data" => $request, "Process" => "Mobile Invoice create");
            $description = "Fail :- " . $e->getMessage();
            $this->setActivityLog('', $order, $data_activity, $description);
        }

        return responder()->success($order)->respond(200);
    }


    public function allocate($data)
    {
        $input = str_replace(' ', '', $data["barcode"]);
        $qty = str_replace(' ', '', $data["qty"]);
        $po = $data["sales_order_id"];
        $soid = $data["soid"];
        $customer_id = $data["customer_id"];

        $boxdata = Box::where('barcode', $input)->first();
        $affected = 0;
        if (!empty($boxdata->id))
        {
            $getChild = $this->getChildBox($boxdata->id);
            if (count($getChild) == 1 && $getChild[0] == $boxdata->id)
            {
                $box = $boxdata->id;
                $affected = Stock::where('box_id', $box)
                    ->whereNull('sales_order_detail_id')
                    ->update(['customer_id' => $customer_id, "sales_order_detail_id" => $soid]);

                $serials = Stock::where('box_id', $box)->get();
            }
            else
            {
                $affected = Stock::whereIn('box_id', $getChild)
                    ->whereNull('sales_order_detail_id')
                    ->update(['customer_id' => $customer_id, "sales_order_detail_id" => $soid]);


                $serials = Stock::whereIn('box_id', $getChild)->get();
            }

            $data_activity = array("data" => $data, "qty" => $qty, "stocks" => $serials, "allocate_qty" => $affected, "box_type" => "internal", "Process" => "Mobile Invoice allocate stock");
            $description = "Success";
            $this->setActivityLog('', $boxdata, $data_activity, $description);
        }
        else
        {

            $allSerial = DB::table('grv')->orWhere("pallet", $input)->orWhere("carton", $input)->orWhere("box", $input)->orWhere("brick", $input)->get();

            $affected = 0;

            foreach ($allSerial as $sr)
            {
                $cnt = DB::update("UPDATE stock SET customer_id = $customer_id,sales_order_detail_id = $soid where serial_no = '$sr->serial_no'  and  sales_order_detail_id is null ");
                $affected = $affected + $cnt;
            }

            $data_activity = array("data" => $data, "qty" => $qty, "stocks" => $allSerial, "allocate_qty" => $affected, "box_type" => "external", "Process" => "Mobile Invoice allocate stock");
            $description = "Success";
            $this->setActivityLog('', $boxdata, $data_activity, $description);

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $po;
            $sl['qty'] = $cnt;
            $sl['order_name'] = "MOBILE_INVOICE";
            $sl['process_name'] = "allocate_order_app";
            $sl['barcode'] = $input;

            StockLedger::create($sl);
        }
        return $affected;
    }
}
