<?php

namespace App\Http\Controllers\Admin;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Flash;
use Response;
use App\User;
use Spatie\Activitylog\Models\Activity;
use DataTables;
use Spatie\Permission\Models\Role;

class AuditsController extends Controller
{
    /**
     * Display a listing of the Admin/audits.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request)
    {
        /** @var Admin/audits $admin/audits */

        $users=User::all();
        $roles = Role::all();

        return view('admin.audits.index',compact('users','roles'));
    }

    public function list(Request $request)
    {
        /** @var Admin/audits $admin/audits */
        
        if(!empty($request->input('roles'))){
            $users=Role::where('id',$request->input('roles'))->with('users')->first();
            $ids=$users->pluck('id');
            $audits = Activity::with('causer', 'subject')
                        ->whereIn('causer_id',$ids);
        }else if(!empty($request->input('ids'))){
            $ids=[$request->input("ids")];
            $audits = Activity::with('causer', 'subject')
                        ->whereIn('causer_id',$ids);;
           
        }else{
            $audits = Activity::with('causer:id,email,username');
        }
        
                            
        return datatables()->of($audits)
                            ->make();
    }

    /**
     * Show the form for creating a new Admin/audits.
     *
     * @return Response
     */
    public function create()
    {
        return view('admin/audits.create');
    }

  
    /**
     * Display the specified Admin/audits.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var Admin/audits $admin/audits */
        $adminaudits = Activity::all($id);

        if (empty($admin/audits)) {
            Flash::error('Admin/audits not found');

            return redirect(route('admin/audits.index'));
        }

        return view('admin/audits.show')->with('admin/audits', $admin/audits);
    }

    /**
     * Show the form for editing the specified Admin/audits.
     *
     * @param int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        /** @var Admin/audits $admin/audits */
        $adminaudits = Activity::all($id);

        if (empty($admin/audits)) {
            Flash::error('Admin/audits not found');

            return redirect(route('admin/audits.index'));
        }

        return view('admin/audits.edit')->with('admin/audits', $admin/audits);
    }

    
    /**
     * Remove the specified Admin/audits from storage.
     *
     * @param int $id
     *
     * @throws \Exception
     *
     * @return Response
     */
   
}
