<?php

namespace App\Http\Controllers\Admin;

use App\Grv;
use App\User;
use Exception;
use App\Config;
use App\Network;
use App\Fileconfig;
use App\StockLedger;
use App\PurchaseOrder;
use Illuminate\Http\Request;
use App\Notifications\GrvProcess;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\StoreOgrRequest;
use App\Http\Controllers\Traits\NotificationTraits;
use \App\Http\Controllers\Traits\NavisionHelperTraits;
use App\Jobs\GrvJobprocess;

class GrvController extends Controller {

    use NotificationTraits;
    use NavisionHelperTraits;

    public function index() {
        $grv = Grv::with('purchaseOrder')->get();
        return view('admin.grv.index', compact('grv'));
    }

    public function list_ajax(Request $request) {
        $data = Grv::with('purchaseOrder');
        if ($request->filled("start_date") && $request->filled("end_date")) {
            $data->whereBetween('created_at', [$request->start_date. ' 00:00:00', $request->end_date. ' 23:59:59']);
        } else if ($request->filled("start_date") || $request->filled("end_date")) {
            if (!empty($request->filled("start_date"))) {
                $data->where('created_at','>=', $request->start_date.' 00:00:00');
            } else {
                $data->where('created_at','<=',$request->end_date.' 00:00:00');
            }
        }
        return datatables()->of($data)
                        ->make();
    }

    public function show(Grv $grv) {
        $grv->load('purchaseorder', 'fileconfig');
        $purchase = DB::select("select p.id,p.external_reference from grv_import_file g right join purchase_order p on p.id  = g.purchase_order_id where external_reference IS NOT NULL");

        return view('admin.grv.show', compact('grv', 'purchase'));
    }

    public function updatepo(Request $request) {
        Grv::where('id', $request->input("id"))
                ->update(['purchase_order_id' => $request->input("nav_id")]);

        $affected = \App\Grvdata::where('file_id', $request->input("id"))
                ->update(['purchase_order_id' => $request->input("nav_id")]);

        PurchaseOrder::where("id", $request->input("nav_id"))->update(['import_qty' => $affected]);

        return response()->json([
                    "msg" => "Purchase Order has been updated successfully.",
                    "code" => 200
        ]);
    }

    public function updateinvoice(Request $request) {
        Grv::where('id', $request->input("id"))
                ->update(['supplier_invoice_id' => $request->input("invoice_id")]);

        return response()->json([
                    "msg" => "Supplier invoice Number has been updated successfully.",
                    "code" => 200
        ]);
    }

    public function create() {
        $network = Network::all();
        $file_type = Fileconfig::all();
        $purchase = DB::select('select purchase_order.* from purchase_order join `status` on `status`.id = purchase_order.status_id where status.name = "pending"');

        return view('admin.grv.create', compact('network', 'file_type', 'purchase'));
    }

    public function store(StoreOgrRequest $request) {
        if (!empty($request->all()['reimp'])) { //this is for reimport file 
            $file_data = Grv::where('id', $request->all()['file_id'])->first();
            $file_name = $file_data->file_name;

            $file_type = Fileconfig::where('id', $file_data->file_config_id)->get()->first();
            $networkData = Network::where('id', $file_type->network_id)->get()->first();
            $col = '';
            $tab = '';
            $ignoreFirstLine = '';
        } else if (!empty($request->all()['is_delete'])) {
            $file_data = Grv::where('id', $request->all()['file_id'])->delete();
            DB::table('grv')->where("file_id", $request->all()['file_id'])->delete();
            return response()->json([
                        'status' => "200",
                        'msg' => "File data reverted"
            ]);
        } else {
            $file_validation = Grv::where(array('purchase_order_id' => $request->input('purchase_order_id'), 'supplier_invoice_id' => $request->all()['supplier_invoice_id']))->get()->first();
            if (!empty($file_validation->id)) {
                return response()->json([
                            'status' => "400",
                            'msg' => "You have already uploaded this file"
                ]);
            }
            if (empty($request->input('file_name'))) {
                return response()->json([
                            'status' => "400",
                            'msg' => "Please supply a file name."
                ]);
            }
            $file_name = $request->input('file_name');

            $poData = PurchaseOrder::with("product")->where("id", $request->input('purchase_order_id'))->get()->first();
            $network_name = $poData->product->network->name;
            $network_id = $poData->product->network_id;
            $file_type = Fileconfig::where('id', $request->all()['file_config_id'])->get()->first();
            $col = '';
            $tab = '';
            $ignoreFirstLine = '';
            $fId = 0;
            $filePath = '';
        }

        $tab = 'grv';
        $filePath = Storage::disk('local')->path($file_type->path . '/' . $file_name);

        if (empty($request->all()['reimp'])) {
            $data = Grv::create($request->all());
            $fId = $data->id;
        }
        $config = Config::where("key", 'file_import_background')->first();
        if (!empty($config->value)) {
            $request->merge(['file_name' => $file_name]);
            if (empty($request->all()['reimp'])) {
                dispatch(new GrvJobprocess($request->all(), $data, Auth::user()->id));
            } else {
                dispatch(new GrvJobprocess($request->all(), $file_data, Auth::user()->id));
            }
            return response()->json([
                        'status' => "200",
                        'id' => 0,
                        'msg' => "Stock file has been processed succesfully."
            ]);
        }
        if (!empty($request->all()['reimp'])) {
            $filePath = Storage::disk('local')->path($file_type->path . '/archived' . '/' . $file_name);
            $fId = $file_data->id;
            DB::table('grv')->where('file_id', $request->all()['file_id'])->delete();
        }

        if (file_exists($filePath)) { //check if file exist
            $request->merge(['file_name' => $file_name]);
            switch (str_replace(' ', '', strtoupper($network_name))) {
                case 'VODACOM': {
                        $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7) set file_id = ' . $fId . ',purchase_order_id = ' . $request->input('purchase_order_id') . ',serial_no=@col1,brick=@col2,file_date=@col6';
                    }
                    break;
                case 'CELLC': {
                        $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7) set file_id = ' . $fId . ',purchase_order_id = ' . $request->input('purchase_order_id') . ',pallet = SPLIT_STRING(@col2,"-",1),carton = concat(pallet,"-",SPLIT_STRING(@col2,"-",2)),box = concat(carton,"-",SPLIT_STRING(@col2,"-",3)),brick = concat(box,"-",SPLIT_STRING(@col2,"-",4)),serial_no=@col1,file_date=@col6';
                    }
                    break;
                case 'MTN': {
                        $col .= '(@col1,@col2,@col3,@col4,@col5) set file_id = ' . $fId . ',purchase_order_id = ' . $request->input('purchase_order_id') . ',serial_no=@col1,alt_serial_no=@col3,box=@col4,brick=REPLACE(@col5, "\r", "")';
                    }
                    break;
                case 'TELKOM': {
                        $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19) set file_id = ' . $fId . ',purchase_order_id = ' . $request->input('purchase_order_id') . ',serial_no=@col8,brick=REPLACE(@col9, "\r", ""),box=@col10';
                    }
                    break;
                default:
                    echo json_encode(array("msg" => "No network selected or network not found"));
                    die;
            }

            $filePath = str_replace("\\", "/", $filePath);
            $filePath = str_replace(':', ':/', $filePath);

            //query for load file into table
            $q = 'LOAD DATA LOCAL INFILE  \'' . $filePath . '\'
                INTO TABLE ' . $tab . '
                FIELDS TERMINATED by \'' . $file_type['ft'] . '\' LINES TERMINATED BY \'' . $file_type['lt'] . '\' IGNORE ' . $file_type->ignore_line . ' LINES ' . $col . '';

            $affected = DB::connection()->getPdo()->exec($q);

            if (empty($request->all()['reimp'])) {

                $q = 'update grv_import_file set status = 1,qty = ' . $affected . ' where id = ' . $data->id . '';
                $q = DB::connection()->getPdo()->exec($q);

                PurchaseOrder::where('id', $request->input('purchase_order_id'))
                        ->update(['import_qty' => DB::raw('import_qty + ' . $affected)]);

                $mismatchQty = 0;
                if ($affected != $poData->qty) {
                    $mismatchQty = 1;
                }
                Storage::move($file_type->path . '/' . $file_name, $file_type->path . '/archived' . '/' . $file_name);

                $sl = array();
                $sl['user_id'] = Auth::user()->id;
                $sl['order_id'] = $request->input('purchase_order_id');
                $sl['qty'] = $affected;

                $sl['order_name'] = "PURCHASE";
                $sl['process_name'] = "import_file";

                StockLedger::create($sl);
                $order = PurchaseOrder::where("id", $request->input('purchase_order_id'))->get()->first();
                $sos = Config::where("key", "grv_import_status")->first();
                if (!empty($sos->value)) {
                    $this->sendEmails($sos->value, new GrvProcess($order));
                    $u = User::find($order->user_id);
                    $u->notify(new GrvProcess($order));
                }
                return response()->json([
                            'status' => "200",
                            'msg' => "File has started uploading.",
                            "id" => $data->id,
                            "network_id" => $network_id,
                            "qtyMismatch" => $mismatchQty
                ]);
            } else {
                $sl = array();
                $sl['user_id'] = Auth::user()->id;
                $sl['order_id'] = $request->input('purchase_order_id');
                $sl['qty'] = $affected;

                $sl['order_name'] = "PURCHASE";
                $sl['process_name'] = "reimport_file";

                StockLedger::create($sl);

                try {
                    $order = PurchaseOrder::find($request->input('purchase_order_id'));
                    $this->nav_patch_order("Purchase_OrderPurchLines", $order->external_reference, "10000", [
                        "Qty_to_Receive" => $affected,
                        "Qty_to_Invoice" => "0"
                    ]);
                } catch (Exception $e) {
                    
                }

                return response()->json([
                            'status' => "200",
                            'msg' => "File has been proccessed.",
                            "id" => $file_data->id,
                            "network_id" => $file_data->network_id
                ]);
            }
        } else {
            return response()->json([
                        'status' => "404",
                        'msg' => "File is not found."
            ]);
        }
    }

}
