<?php

namespace App\Http\Controllers\Traits;

use App\Approvals;
use App\ApprovalStages;
use App\BaseSummary;
use App\Config;
use App\Contract;
use App\Customer;
use App\CustomerSplit;
use App\Notification;
use App\Notifications\SalesOrderApproval;
use App\Product;
use App\ProductDeal;
use App\SalesOrder;
use App\StagesRoles;
use App\Status;
use App\TierStage;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use App\Http\Controllers\Traits\NavisionHelperTraits;
use Exception;

trait MobileInvoiceTrait
{
use NavisionHelperTraits;
    /**
     * File upload trait used in controllers to upload files
     */
    public function check_approval($order, $skip_approval = false)
    {
        $cs = $order->status_id;
        $soaa = Config::where("key", "mobile_invoice_apply_approval")->first();
        if ($cs == $soaa->value) {
            
            $soa = Config::where("key", "mobile_invoice_approval")->first();
            $order->approval_id = $soa->value;
            $order->priority = 1;
            $order->save();

            if (!$skip_approval) {
                $aid = ApprovalStages::where('approval_id', $soa->value)->where("priority", 1)->first();
                $users = Role::whereIn('id', $aid->approved_by->pluck('roles')->pluck("id"))->with('users')->get();
                foreach ($users as $key => $value) {
                    foreach ($value->users()->pluck("id") as $k => $user) {
                        $u = User::find($user);
                        $u->notify(new SalesOrderApproval($order));
                    }
                }
            }
        }
        return $order;
    }
    public function check_order($order)
    {
        $o = $this->getMyOrder();
        $co = $o["orders"]->where("id", $order)->first();
        $obj = [];
        if (!empty($co->id)) {
            $obj["isMine"] = true;
            $c = $o["Approvals"]->where("approval_id", $co->approval_id)->get("priority")->first();

            if (empty($c)) {
                $obj["needsApproval"] = 0;
                $ap = Approvals::find($co->approval_id);
                if ($ap->status_id == $co->status_id) {
                    $obj["isApproved"] = 1;
                } else {
                    $obj["isApproved"] = 0;
                }
            } else {
                //   dd($co,$c);
                if ($co->priority > $c->priority) {
                    $obj["needsApproval"] = 0;
                    $obj["isApproved"] = 1;
                } else if ($co->priority == $c->priority) {
                    $obj["needsApproval"] = 1;
                    $obj["isApproved"] = 0;
                } else {
                    $obj["needsApproval"] = 0;
                    $obj["isApproved"] = $co->status_id == Status::whereProcess("sales_order")->whereStatus("approved")->first()->id;
                }
            }
        } else {
            $obj["isMine"] = false;
        }

        return (object)($obj);
    }

    public function approveOrder($order)
    {
        $status = $this->check_order($order);
        if ($status->isMine && $status->needsApproval) {
            $order = SalesOrder::find($order)->load('customer');
            $res = $order->increment('priority');
            if ($order->is_bulk) {
                SalesOrder::whereParentId($order->id)->increment("priority");
            }
            $aid = ApprovalStages::where('approval_id', $order->approval_id)->where("priority", $order->priority)->first();
            if ($aid) {
                $users = Role::whereIn('id', $aid->approved_by->pluck('roles')->pluck("id"))->with('users')->get();
                foreach ($users as $key => $value) {
                    foreach ($value->users()->pluck("id") as $k => $user) {
                        $u = User::find($user);
                        $u->notify(new SalesOrderApproval($order));
                    }
                }
            } else {
                $approvals = Approvals::find($order->approval_id);
                $order->status_id = $approvals->status_id;
                $order->save();
            }

            return $res;
        } else {
            return false;
        }
    }

    public function getMyOrder()
    {
        $user = Auth::user();
        if($user->user_type_id==2){
            $approvals=[];
            $order = SalesOrder::where('user_id', $user->id)->whereParentId(-1);
        }else{
            $stages = StagesRoles::whereIn("role_id", $user->roles->pluck("id"))->get();
            $approvals = ApprovalStages::whereIn("id", $stages->pluck("stage_id"))
                ->select(DB::raw("distinct approval_id,priority"));
            $order = SalesOrder::where(function ($q) use ($approvals, $user) {
                $q->whereIn('approval_id', $approvals->get()->pluck("approval_id"))
                    ->orWhere('user_id', $user->id);
            })->whereParentId(-1);
        }
        

        return ["Approvals" => $approvals, "orders" => $order];
    }

    public function get_product_entry($request)
    {

        $product = Product::find($request->product_id);
        $network_id = $product->network->id;
        $qty = $request->qty;
        $contract = Contract::where('customer_id', $request->customer_id)
            ->where('network_id', $network_id)->first();
        $customer = Customer::find($request->customer_id);
        $splits = null;
        $tier = null;
        $deal = null;
        if ($contract->is_split) {

            if (empty($request->split_deal_id)) {
                $splits = CustomerSplit::with("splitCustomer:id,name")->where('customer_id', $request->customer_id)
                    ->where('network_id', $network_id)
                    ->whereNull('product_id')
                    ->whereNull('product_deal_id')
                    ->whereNull('split_deal_id')
                    ->get();
            } else {
                $splits = CustomerSplit::where('split_deal_id', $request->split_deal_id)
                    ->get();
            }
        }
        if ($contract->is_tiered) {
            $acb = BaseSummary::whereCustomerId($customer->id)
                ->whereNetworkId($network_id)
                ->sum("active_base");
            $tier = TierStage::where('customer_id', $request->customer_id)
                ->where('network_id', $network_id)
                ->where('from_cab', '<=', (int)$acb)
                ->where(function ($query) use ($acb) {
                    $query->where('to_cab', '>=', (int)$acb);
                    $query->orWhere('to_cab', -1);
                })
                ->first();
        } else {
            if (!empty($request->product_deal)) {
                $deal = ProductDeal::find($request->product_deal);
            }
        }
        return compact('product', 'splits', 'tier', 'contract', 'qty', 'deal');
    }
}
