<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Flash;
use Response;
use App\Address;
use App\Status;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Spatie\Activitylog\Models\Activity;
use Spatie\Permission\Models\Role;

class AddressController extends Controller {

    /**
     * @OA\Post(
     ** path="/api/v1/address/add",
     *   tags={"Address"},
     *   summary="update address for customers",
     *   operationId="addAddress",
     *   security={
     *      {"passport": {}},
     *   },
     *   @OA\Parameter(
     *      name="customer_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="number"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="type",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="address_type_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="number"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="gps_coordinates",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string",
     *          format="lat,lng"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="address_line_1",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="address_line_2",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="city",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="province",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="postal_code",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     */
    public function store(Request $request) {
        $validator = Validator::make($request->all(),[
            'customer_id' => 'required',
            'type' => 'required',
            'address_type_id' => 'required',
            'gps_coordinates' => 'required',
            'address_line_1' => 'required',
            'postal_code' => 'required',
            
        ]);

        if ($validator->fails()) {
            return responder()->error(400,"vaidation_error")->data(['data'=>$validator->errors()])->respond(400);
        }
        if ($request->filled("id")) {
            $address = Address::find($request->id);
            $address->update($request->except(['type']));
        } else {
            $status = Status::whereProcess("address_entity_type")
                            ->whereStatus($request->type)->first();
            $request->request->add(['address_entity_id' => $status->id]);
            $address = Address::create($request->except(['type']));
        }

        if(!$address->id){
            responder()->error()->respond(500);
        }else{
            return responder()->success($address)->respond(200);
        }
    }

    /**
     * @OA\Put(
     ** path="/api/v1/address/update",
     *   tags={"Address"},
     *   summary="Update address for customers",
     *   operationId="updateAddress",
     *   security={
     *      {"passport": {}},
     *   },
     *   @OA\Parameter(
     *      name="id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="number"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="customer_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="number"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="type",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="address_type_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="number"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="gps_coordinates",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string",
     *          format="lat,lng"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="address_line_1",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="address_line_2",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="city",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="province",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="postal_code",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     */
    public function update(Request $request) {
        $validator = Validator::make($request->all(),[
            'customer_id' => 'required',
            'id' => 'required',
            'type' => 'required',
            'address_type_id' => 'required',
            'gps_coordinates' => 'required',
            'address_line_1' => 'required',
            'postal_code' => 'required',
            
        ]);

        if ($validator->fails()) {
            return responder()->error(400,"vaidation_error")->data(['data'=>$validator->errors()])->respond(400);
        }
        $address=Address::find($request->id);
        if($address===null){
            return responder()->error(404,"No contact found.")->respond(404);
        }
        if($request->type=="customer"){
            if($address->customer_id==Auth::user()->id){
                $address->update($request->except(['type']));
                return responder()->success()->respond(200);
            }else{
                return responder()->error(500,"You cannot update other users address.")->respond(500);
            }
        }else if($request->type=="warehouse"){
            if($address->customer_id==Auth::user()->warehouse_id){
                $address->update($request->except(['type']));
                return responder()->success()->respond(200);
            }else{
                return responder()->error(500,"You cannot update other users warehouse address.")->respond(500);
            }
        }else{
            $address->update($request->except(['type']));
            return responder()->success()->respond(200);
        }
        
    }
/**
     * @OA\Delete(
     ** path="/api/v1/address/delete",
     *   tags={"Address"},
     *   summary="remove address for customers,warehouse,supplier",
     *   operationId="deleteAddress",
     *   security={
     *      {"passport": {}},
     *   },
      *   @OA\Parameter(
     *      name="id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="number"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="type",
     *      in="query",
     *      description="Must be type of 'customer', 'warehouse', 'supplier'",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     */
    public function destroy(Request $request) {
        $validator = Validator::make($request->all(),[
            'id' => 'required',
            'type' => 'in:customer,warehouse,supplier'
        ]);

        if ($validator->fails()) {
            return responder()->error(400,"vaidation_error")->data(['data'=>$validator->errors()])->respond(400);
        }
        $address=Address::find($request->id);
        if($address===null){
            return responder()->error(404,"No contact found.")->respond(404);
        }
        if($request->type=="customer"){
            if($address->customer_id==Auth::user()->id){
                $address->delete();
                return responder()->success()->respond(200);
            }else{
                return responder()->error(500,"You cannot delete other users address.")->respond(500);
            }
        }else if($request->type=="warehouse"){
            if($address->customer_id==Auth::user()->warehouse_id){
                $address->delete();
                return responder()->success()->respond(200);
            }else{
                return responder()->error(500,"You cannot delete other users warehouse address.")->respond(500);
            }
        }else{
            $address->delete();
            return responder()->success()->respond(200);
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/address/types",
     *      operationId="getAddressTypes",
     *      tags={"Address"},
     *      summary="Get Adddress types",
     *      description="Returns address types",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
    *     )
    */
   public function types(Request $request)
   {
    return responder()->success(Status::whereProcess("address_type")->get())->respond();
   }

}
