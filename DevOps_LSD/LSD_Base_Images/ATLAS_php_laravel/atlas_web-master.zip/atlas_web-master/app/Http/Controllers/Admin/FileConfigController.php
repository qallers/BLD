<?php

namespace App\Http\Controllers\Admin;

use App\Fileconfig;
use App\Filetype;
use App\Network;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\Admin\UpdateConfigRequest;
use RealRashid\SweetAlert\Facades\Alert;
use Session;

class FileConfigController extends Controller {

    public function createFiletype() {

        return view('admin.filetype.createFiletype');
    }

    public function index() {

        //$fileconfig = Fileconfig::all();
        $filetype = Filetype::all();
        return view('admin.filetype.index', compact('filetype'));
        }

        public function list(Request $request) {

        $data = Fileconfig::with("network", "filetype");

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }


        return datatables()->of($data)
                        ->make();
    }

    public function list_filetype(Request $request) {
        $data = Filetype::select("id", "type", "slug", "is_active", "created_at");

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }

        return datatables()->of($data)
                        ->make();
    }

    public function edit(Fileconfig $fileconfig) {
        $network = Network::all();
        $filetype = Filetype::all();
        return view('admin.filetype.edit', compact('fileconfig', 'filetype', 'network'));
    }

    public function create() {
        $network = Network::all();
        $filetype = Filetype::all();
        return view('admin.filetype.create', compact('filetype', 'network'));
    }

    public function update(UpdateConfigRequest $request, FIleconfig $fileconfig) {

        $fileconfig->update($request->all());
        Storage::makeDirectory($request->input('path'));
        Alert::success('Success', 'The file configuration has been updated.');
        return redirect()->route('admin.fileconfig.index');
    }

    public function show(filetype $filetype) {

        return view('admin.filetype.show', compact('filetype'));
    }

    public function massDestroy(Request $request) {

        Fileconfig::whereIn('id', request('ids'))->delete();

        return response()->noContent();
    }

    public function store(UpdateConfigRequest $request) {
        Fileconfig::create($request->all());

        Storage::makeDirectory($request->input('path'));

        Alert::success('Success', 'The file configuration has been created.');
        return redirect()->route('admin.fileconfig.index');
    }

    public function storeFiletype(Request $request) {
        Filetype::create($request->all());
        Alert::success('Success', 'The file type has been created.');
        return redirect()->route('admin.fileconfig.index');
    }

    public function destroy(Fileconfig $fileconfig) {

        Alert::success('Success', 'The file configuration has been deleted.');
        $fileconfig->delete();
        return redirect()->route('admin.fileconfig.index');
    }

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Fileconfig::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The config has been $msg successfully"
        ]);
    }

}
