<?php

namespace App\Http\Controllers\Admin;

use App\Ogr;
use App\User;
use Exception;
use App\Config;
use App\Network;
use App\Customer;
use App\Fileconfig;
use Illuminate\Http\Request;
use App\Jobs\Monthendprocess;
use App\Notifications\Monthend;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\StoreOgrRequest;

class OgrController extends Controller
{
    use \App\Http\Controllers\Traits\NotificationTraits;

    public function index()
    {
        //$ogr = Ogr::with('network', 'fileconfig')->get();
        return view('admin.ogr.index');
    }

    public function list_ajax(Request $request)
    {
        $data = Ogr::with('network', 'fileconfig', 'fileconfig.filetype');


        if ($request->filled("process_month") && $request->filled("t_process_month"))
        {
            $data->whereBetween('process_month', [$request->process_month . '-01', $request->t_process_month . '-01']);
        }
        else if ($request->filled("process_month") || $request->filled("t_process_month"))
        {
            if (!empty($request->filled("process_month")))
            {
                $data->where('process_month', $request->process_month . '-01');
            }
            else
            {
                $data->where('process_month', $request->t_process_month . '-01');
            }
        }
        return datatables()->of($data)
            ->make();
    }

    public function create()
    {
        $config = Config::where("key", 'file_import_background')->get()->first();
        $network = Network::all();
        $file_type = Fileconfig::all();
        return view('admin.ogr.create', compact('network', 'file_type', 'config'));
    }

    public function show(Ogr $ogr)
    {
        $ogr->load('network', 'fileconfig');
        return view('admin.ogr.show', compact('ogr'));
    }

    public function getfile(Request $request)
    {
        $id = $request->input("customer_id");
        $nid = $request->input("network_id");
        $fid = $request->input("file_config_id");
        $pm = $request->input("process_month") . '-01';
        $fdata = Ogr::with('network', 'fileconfig')->where([
            ['network_id', '=', $nid],
            ['file_config_id', '=', $fid],
            ['process_month', '=', $pm]
        ])->get();

        return view('admin.ogr.ajax_generate_revenue', compact('fdata', 'id'));
    }

    public function customer_revenue()
    {
        $network = Network::all();
        $file_type = Fileconfig::all();
        return view('admin.ogr.generate_revenue', compact('file_type', 'network'));
    }

    public function revenue_file(Request $request)
    {
        $cust_id = $request->input('cust_id');
        $ogr = Ogr::with('network', 'fileconfig')->whereIn("id", $request->input('ids'))->get();
        $cust = Customer::find($cust_id);
        $nname = '';
        $ftype = '';
        $pmonth = '';
        $eData = \App\ExternalSystemReference::where("customer_id", $cust_id)->where("external_system_id", 5)->first();

        foreach ($ogr as $o => $v)
        {
            $nname = str_replace(' ', '', strtoupper($v->network->name));
            $ftype = strtoupper($v->fileconfig->filetype->slug);
            $pmonth = $v->process_month;
            $fname = $cust->cust_code . '_' . $nname . '_' . $ftype . '_' . date('Ym', strtotime($pmonth));

            try
            {
                switch ($nname)
                {
                    case 'MTN':
                        {
                            switch ($ftype)
                            {
                                case 'OGR':
                                    $data = DB::select(
                                        "SELECT mtn.primary_grp
                                        ,mtn.prov_first_conn
                                        ,mtn.city_first_conn
                                        ,mtn.customer_group
                                        ,t5.name AS 'customer_name'
                                        ,mtn.address1
                                        ,mtn.province
                                        ,mtn.region_name
                                        ,mtn.category_set_name
                                        ,mtn.description
                                        ,mtn.cat_segment2
                                        ,mtn.cat_segment3
                                        ,mtn.distribution_date
                                        ,mtn.msisdn
                                        ,mtn.serial_number
                                        ,mtn.trx_number
                                        ,mtn.box_serial_number
                                        ,mtn.brick_serial_number
                                        ,mtn.cps135_imei_number
                                        ,mtn.activation_date
                                        ,mtn.comm_mth
                                        ,mtn.comms_category
                                        ,t1.expense / (1 + t11.vat) AS 'comm_excl'
                                        ,t1.expense - (t1.expense / (1 + t11.vat)) AS 'vat'
                                        ,t1.expense AS 'comm_incl'
                                        ,mtn.base
                                        ,t6.ogr
                                        ,mtn.revenue_mth_0
                                        ,mtn.revenue_mth_1
                                        ,mtn.revenue_mth_2
                                        ,mtn.revenue_mth_3
                                        ,mtn.total_recharge_amt
                                        ,mtn.pre_loaded
                                        ,mtn.billdur
                                        ,mtn.callcost
                                        ,mtn.mmsamt
                                        ,mtn.gprsamt
                                    FROM me_ogr_post_process t1
                                    LEFT JOIN me_ogr_pre_process t2 ON t2.serial_no = t1.serial_no
                                        AND t1.file_id = t2.file_id
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_mtn_ogr_raw mtn ON mtn.file_id = t3.id
                                        AND mtn.network_id = t10.id
                                        AND mtn.serial_number = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["sdate" => $pmonth, "edate" => $pmonth, "fid" => $v->id, "cid" => $cust->id]
                                    );
                                    break;

                                case 'ACT':
                                    $data = DB::select(
                                        "SELECT mtn.primary_grp
                                        ,mtn.prov_first_conn
                                        ,mtn.city_first_conn
                                        ,t5.name AS 'customer_name'
                                        ,mtn.address1
                                        ,mtn.province
                                        ,mtn.region_name
                                        ,mtn.category_set_name
                                        ,mtn.cat_segment2
                                        ,mtn.cat_segment3
                                        ,mtn.distribution_date
                                        ,mtn.msisdn
                                        ,mtn.sim
                                        ,mtn.serial_number
                                        ,mtn.trx_number
                                        ,mtn.box_serial_number
                                        ,mtn.brick_serial_number
                                        ,mtn.activation_date
                                        ,mtn.dt_port_in
                                        ,mtn.rica_date
                                        ,mtn.comm_mth
                                        ,mtn.usage_spent_4mths
                                        ,mtn.usage_spent_7mths
                                        ,mtn.voice_amt_4mths
                                        ,mtn.gprsamt_4mths
                                        ,mtn.total_bundle_purchase_amt_4mths
                                        ,mtn.xtratime_sfee_repay_4mths
                                        ,mtn.comms_category
                                        ,t1.expense / (1 + t11.vat) AS 'comm_excl'
                                        ,t1.expense - (t1.expense / (1 + t11.vat)) AS 'vat'
                                        ,t1.expense AS 'comm_incl'
                                        ,mtn.agents_company_name
                                        ,mtn.officers_identity_number
                                        ,mtn.officers_company_name
                                        ,mtn.officers_name
                                        ,mtn.flag_spend
                                        ,mtn.gprs_inbundle_amt_4mths
                                        ,mtn.sms_inbundle_amt_4mths
                                        ,mtn.mms_inbundle_amt_4mths
                                        ,REPLACE(REPLACE(voice_inbundle_amt_4mths, '\r', ''), '\n', '') as voice_inbundle_amt_4mths
                                    FROM me_act_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_mtn_act_raw mtn ON mtn.file_id = t3.id
                                        AND mtn.network_id = t10.id
                                        AND mtn.serial_number = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["sdate" => $v->process_month, "edate" => $v->process_month, "fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'SWP':
                                    $data = DB::select(
                                        "SELECT mtn.primary_grp
                                        ,mtn.prov_first_conn
                                        ,mtn.city_first_conn
                                        ,t5.name AS 'customer_name'
                                        ,mtn.address1
                                        ,mtn.category_set_name
                                        ,mtn.description
                                        ,mtn.serial_number
                                        ,t1.expense / (1 + t11.vat) AS 'comm_excl'
                                        ,t1.expense - (t1.expense / (1 + t11.vat)) AS 'vat'
                                        ,t1.expense AS 'comm_incl'
                                        ,mtn.sim_flag
                                        ,mtn.sim_flag_month
                                        ,mtn.donor_kit_sim
                                        ,mtn.donor_msisdn
                                        ,mtn.donor_trans_date
                                        ,mtn.customer_category_code
                                        ,mtn.accumulated_usage
                                        ,mtn.category
                                        ,mtn.customer_number
                                        ,mtn.site_use_id
                                    FROM me_swp_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_mtn_simswap_raw mtn ON mtn.file_id = t3.id
                                        AND mtn.network_id = t10.id
                                        AND mtn.serial_number = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["sdate" => $v->process_month, "edate" => $v->process_month, "fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'CON':
                                    $data = DB::select(
                                        "SELECT mtn.primary_grp
                                        ,mtn.prov_first_conn
                                        ,mtn.city_first_conn
                                        ,t5.name AS 'customer_name'
                                        ,mtn.address1
                                        ,mtn.province
                                        ,mtn.region_name
                                        ,mtn.category_set_name
                                        ,mtn.description
                                        ,mtn.cat_segment2
                                        ,mtn.cat_segment3
                                        ,mtn.distribution_date
                                        ,mtn.msisdn
                                        ,mtn.serial_number
                                        ,mtn.trx_number
                                        ,mtn.box_serial_number
                                        ,mtn.brick_serial_number
                                        ,mtn.activation_date
                                        ,mtn.act_inc_prt
                                        ,mtn.port_in_flag
                                        ,mtn.usage_spent_4mths
                                        ,mtn.usage_spent_7mths
                                        ,mtn.list_price
                                        ,mtn.selling_price
                                        ,mtn.cps135_sim
                                        ,mtn.comms_category
                                        ,mtn.comm_excl
                                        ,mtn.vat
                                        ,mtn.comm_incl
                                        ,mtn.agents_company_name
                                        ,mtn.rica_date
                                        ,mtn.officers_identity_number
                                        ,mtn.officers_company_name
                                        ,mtn.officers_name
                                    FROM me_con_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN customer t5 ON t5.id = t1.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_mtn_con_raw mtn ON mtn.file_id = t3.id
                                        AND mtn.network_id = t10.id
                                        AND mtn.serial_number = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'DEL':
                                    $data = DB::select(
                                        "SELECT mtn.primary_grp
                                        ,mtn.prov_first_conn
                                        ,mtn.city_first_conn
                                        ,t5.name AS 'customer_name'
                                        ,mtn.address1
                                        ,mtn.province
                                        ,mtn.region_name
                                        ,mtn.category_set_name
                                        ,mtn.description
                                        ,mtn.cat_segment2
                                        ,mtn.cat_segment3
                                        ,mtn.distribution_date
                                        ,mtn.msisdn
                                        ,mtn.serial_number
                                        ,mtn.trx_number
                                        ,mtn.box_serial_number
                                        ,mtn.brick_serial_number
                                        ,mtn.cps135_imei_number
                                        ,mtn.activation_date
                                        ,mtn.comm_mth
                                        ,mtn.deactdte
                                    FROM me_del_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN customer t5 ON t5.id = t1.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_mtn_del_raw mtn ON mtn.file_id = t3.id
                                        AND mtn.network_id = t10.id
                                        AND mtn.serial_number = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'RETAIL':
                                    $data = DB::select(
                                        "SELECT mtn.report_month
                                        ,mtn.simFlag
                                        ,mtn.simFlagMonth
                                        ,mtn.simFlagQtr
                                        ,mtn.msisdn
                                        ,mtn.primary_grp
                                        ,t5.name AS 'customer_name'
                                        ,mtn.activation_date
                                        ,mtn.distribution_date
                                        ,mtn.deactivation_date
                                        ,mtn.category_set_name
                                        ,mtn.cat_segment2
                                        ,mtn.cat_segment3
                                        ,mtn.province
                                        ,mtn.region_name
                                        ,mtn.serial_number
                                        ,t5.id AS 'customer_number'
                                        ,mtn.description
                                        ,mtn.store
                                        ,mtn.customer_class_code
                                        ,mtn.demand_class_code
                                        ,t1.expense AS 'comm_incl'
                                        ,t1.expense / (1 + t11.vat) AS 'comm_excl'
                                        ,t1.expense - (t1.expense / (1 + t11.vat)) AS 'vat'
                                        ,mtn.sim
                                        ,mtn.branded_store_code
                                    FROM me_act_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_mtn_retail_raw mtn ON mtn.file_id = t3.id
                                        AND mtn.network_id = t10.id
                                        AND mtn.serial_number = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["sdate" => $v->process_month, "edate" => $v->process_month, "fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'RETSWP':
                                    $data = DB::select(
                                        "SELECT mtn.primary_grp
                                        ,mtn.sim_flag
                                        ,mtn.sim_flag_month
                                        ,mtn.donor_msisdn
                                        ,mtn.donor_kit_sim
                                        ,mtn.donor_sim_swap_date
                                        ,mtn.serial_number
                                        ,t5.name AS 'customer_name'
                                        ,mtn.address1
                                        ,mtn.customer_category_code
                                        ,mtn.category_set_name
                                        ,mtn.description
                                        ,mtn.usage
                                        ,t1.expense / (1 + t11.vat) AS 'comm_excl'
                                        ,t1.expense - (t1.expense / (1 + t11.vat)) AS 'vat'
                                        ,t1.expense AS 'comm_incl'
                                    FROM me_swp_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_mtn_simswap_raw mtn ON mtn.file_id = t3.id
                                        AND mtn.network_id = t10.id
                                        AND mtn.serial_number = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["sdate" => $v->process_month, "edate" => $v->process_month, "fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                default:
                                    break;
                            }
                            break;
                        }
                    case 'VODACOM':
                        {
                            switch ($ftype)
                            {
                                case 'OGR':
                                    $data = DB::select(
                                        "SELECT vod.serial_no
                                        ,SUM(vod.denom * vod.recharge_count) AS 'total_recharge_amount'
                                        ,vod.denom
                                        ,vod.recharge_count
                                        ,vod.msisdn
                                        ,t6.ogr
                                        ,t5.cust_code
                                    FROM me_ogr_post_process t1
                                    LEFT JOIN me_ogr_pre_process t2 ON t2.serial_no = t1.serial_no
                                        AND t2.file_id = t1.file_id
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_vodacom_ogr_raw vod ON vod.file_id = t3.id
                                        AND vod.network_id = t10.id
                                        AND vod.serial_no = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid
                                    GROUP BY vod.serial_no",
                                        ["sdate" => $v->process_month, "edate" => $v->process_month, "fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'ACT':
                                    $data = DB::select(
                                        "SELECT vod.serial_no
                                        ,vod.conn_month
                                        ,vod.msisdn
                                        ,t6.act AS 'comm_amount'
                                        ,t5.cust_code
                                    FROM me_act_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_vodacom_act_raw vod ON vod.file_id = t3.id
                                        AND vod.network_id = t10.id
                                        AND vod.serial_no = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["sdate" => $v->process_month, "edate" => $v->process_month, "fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'CON':
                                    $data = DB::select(
                                        "SELECT vod.serial_no
                                        ,vod.conn_month
                                        ,vod.msisdn
                                        ,vod.denom AS 'comm_amount'
                                        ,t5.cust_code
                                    FROM me_con_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN customer t5 ON t5.id = t1.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_vodacom_con_raw vod ON vod.file_id = t3.id
                                        AND vod.network_id = t10.id
                                        AND vod.serial_no = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'DEL':
                                    $data = DB::select(
                                        "SELECT vod.serial_no
                                        ,vod.del_month
                                        ,t5.cust_code
                                    FROM me_del_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN customer t5 ON t5.id = t1.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_vodacom_del_raw vod ON vod.file_id = t3.id
                                        AND vod.network_id = t10.id
                                        AND vod.serial_no = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                default:
                                    break;
                            }
                            break;
                        }
                    case 'CELLC':
                        {
                            switch ($ftype)
                            {
                                case 'OGR':
                                    $data = DB::select(
                                        "SELECT cel.serial_no
                                        ,SUM(cel.denom * cel.recharge_count) AS 'total_recharge_amount'
                                        ,cel.denom
                                        ,cel.recharge_count
                                        ,cel.msisdn
                                        ,t6.ogr
                                        ,t5.cust_code
                                    FROM me_ogr_post_process t1
                                    LEFT JOIN me_ogr_pre_process t2 ON t2.serial_no = t1.serial_no
                                        AND t2.file_id = t1.file_id
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_cellc_ogr_raw cel ON cel.file_id = t3.id
                                        AND cel.network_id = t10.id
                                        AND cel.serial_no = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid
                                    GROUP BY cel.serial_no",
                                        ["sdate" => $v->process_month, "edate" => $v->process_month, "fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'ACT':
                                    $data = DB::select(
                                        "SELECT cel.serial_no
                                        ,cel.conn_month
                                        ,cel.msisdn
                                        ,t6.act AS 'comm_amount'
                                        ,t5.cust_code
                                    FROM me_act_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_cellc_act_raw cel ON cel.file_id = t3.id
                                        AND cel.network_id = t10.id
                                        AND cel.serial_no = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["sdate" => $v->process_month, "edate" => $v->process_month, "fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'CON':
                                    $data = DB::select(
                                        "SELECT cel.serial_no
                                        ,cel.conn_month
                                        ,cel.msisdn
                                        ,cel.denom AS 'comm_amount'
                                        ,t5.cust_code
                                    FROM me_con_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN customer t5 ON t5.id = t1.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_cellc_con_raw cel ON cel.file_id = t3.id
                                        AND cel.network_id = t10.id
                                        AND cel.serial_no = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                            AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                default:
                                    break;
                            }
                            break;
                        }
                    case 'TELKOM':
                        {
                            switch ($ftype)
                            {
                                case 'OGR':
                                case 'DIROGR':
                                    $data = DB::select(
                                        "SELECT t5.cust_code
                                        ,t5.name
                                        ,tel.msisdn
                                        ,tel.sim_seq_num
                                        ,tel.imei
                                        ,tel.connection_date
                                        ,tel.billing_period
                                        ,tel.commission_code
                                        ,tel.subscriber_type
                                        ,tel.deal_id
                                        ,tel.commissionable_amount
                                        ,t1.expense AS 'commission_incl_vat'
                                        ,t1.expense / (1 + t11.vat) AS 'commission_excl_vat'
                                        ,t6.ogr
                                        ,tel.sub_dealer_code
                                        ,tel.comm_rocode
                                        ,t5.name
                                    FROM me_ogr_post_process t1
                                    LEFT JOIN me_ogr_pre_process t2 ON t2.serial_no = t1.serial_no
                                        AND t2.file_id = t1.file_id
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_telkom_ogr_raw tel ON tel.file_id = t3.id
                                        AND tel.network_id = t10.id
                                        AND tel.sim_seq_num = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                        AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid
                                    GROUP BY tel.sim_seq_num",
                                        ["sdate" => $v->process_month, "edate" => $v->process_month, "fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                case 'ACT':
                                case 'DIRACT':
                                    $data = DB::select(
                                        "SELECT t5.cust_code
                                        ,t5.name
                                        ,tel.msisdn
                                        ,tel.iccid
                                        ,tel.imei
                                        ,tel.tariff_plan
                                        ,tel.connection_date
                                        ,tel.billing_period
                                        ,tel.commission_code
                                        ,tel.subscriber_type
                                        ,t1.expense AS 'commission_incl_vat'
                                        ,t1.expense / (1 + t11.vat) AS 'commission_excl_vat'
                                        ,tel.deal_id
                                        ,tel.sub_dealer_code
                                        ,tel.comm_rocode
                                        ,t5.name
                                    FROM me_act_post_process t1
                                    LEFT JOIN me_import_file t3 ON t3.id = t1.file_id
                                    LEFT JOIN stock t4 ON t4.serial_no = t1.serial_no
                                    LEFT JOIN (
                                        SELECT sales_order_detail_id
                                            ,MAX(id) AS 'id'
                                            ,customer_id
                                        FROM sales_deal
                                        WHERE DATE_SUB(LAST_DAY(start_date), INTERVAL DAY(LAST_DAY(start_date)) - 1 DAY) <= :sdate
                                            AND :edate <= end_date
                                        GROUP BY sales_order_detail_id
                                            ,customer_id
                                        ORDER BY id DESC
                                        ) t6a ON t6a.sales_order_detail_id = t1.sales_order_detail_id
                                        AND t6a.customer_id = t1.customer_id
                                    LEFT JOIN product t7 ON t7.id = t4.product_id
                                    LEFT JOIN sales_order_detail t8 ON t8.id = t4.sales_order_detail_id
                                    LEFT JOIN sales_order t9 ON t9.id = t8.sales_order_id
                                    LEFT JOIN sales_deal t6 ON t6.id = t6a.id
                                    LEFT JOIN customer t5 ON t5.id = t6.customer_id
                                    LEFT JOIN network t10 ON t10.id = t4.network_id
                                    LEFT JOIN me_telkom_act_raw tel ON tel.file_id = t3.id
                                        AND tel.network_id = t10.id
                                        AND tel.iccid = t1.serial_no
                                    LEFT JOIN vat_config t11 ON t3.process_month BETWEEN DATE (t11.start_date)
                                        AND DATE (t11.end_date)
                                    WHERE t1.file_id = :fid
                                        AND t5.id = :cid",
                                        ["sdate" => $v->process_month, "edate" => $v->process_month, "fid" => $v->id, "cid" => $cust_id]
                                    );
                                    break;

                                default:
                                    break;
                            }
                            break;
                        }
                }
            }
            catch (QueryException $ex)
            {
                Alert::error('Error', 'There is an issue with database query, ' . substr($ex->getMessage(), 15, 150));
                return back();
            }

            $s = '';
            $i = 0;
            $value = '';
            $fname = $cust->cust_code . '_' . $nname . '_' . $ftype . '_' . date('Ym', strtotime($pmonth));

            $nid = $v->network_id;
            $store = '';
            $store_cal = '';
            if (empty($data))
            {
                Alert::error('Error', 'Selected file has no data for related customer.');
                return back();
            }
            try
            {
                foreach ($data as $k => $v)
                {

                    $d = (array) $v;

                    if (empty($i))
                    {
                        $s .= implode(',', array_keys($d));
                    }

                    $value .= implode(',', array_values($d)) . PHP_RN;
                    $i++;
                }

                $content = $s . PHP_RN;
                $content .= $value;
                //$fname = $cust->cust_code . '_' . $nname . '_' . $ftype . '_' . date('Ym', strtotime($pmonth));
                $fpath = 'ogr/exports/' . $cust->cust_code . '/';
                $t = Storage::disk('local')->path($fpath . $fname . '.csv');

                Storage::disk('local')->put($fpath . $fname . '.csv', $content);
                return Storage::download($fpath . $fname . '.csv');
            }
            catch (Exception $ex)
            {
                Alert::error('Error', 'There is an issue when generating file');
                return back();
            }
        }
    }

    /*
     * Function:- get_kits_not_in_invoice
     * Description:- change status of serial no which is not in invoice
     */

    public function get_invoice_not_in_stock(StoreOgrRequest $request)
    {
        $par = (int) $request->all()['file_id'];
        $fileData = Ogr::where('id', $par)->get()->first();
        $table_pre = '';
        $table_post = '';
        switch (strtoupper($fileData->fileconfig->filetype->slug))
        {
            case 'ACT':
            case 'RETAIL':
            case 'DIRACT':
                $table_post = 'me_act_post_process';
                break;
            case 'OGR':
            case 'DIROGR':
                $table_post = 'me_ogr_post_process';
                break;
            case 'SWP':
            case 'RETSWP':
                $table_post = 'me_swp_post_process';
                break;
            default:
                echo json_encode(array("msg" => "No network selected or network not found"));
                die;
        }
        $invoiceNotInStock = DB::select("SELECT * FROM `$table_post` t1 INNER JOIN stock t2 ON t1.serial_no = t2.serial_no WHERE t2.sales_order_detail_id IS NULL AND t1.file_id = $par");
        return view('ajax.get_invoice_not_in_stock', compact('invoiceNotInStock'));
    }

    public function get_deal_invalid(StoreOgrRequest $request)
    {
        $par = (int) $request->input('file_id');
        $fileData = Ogr::where('id', $par)->get()->first();
        $table_pre = '';
        $table_post = '';
        switch (strtoupper($fileData->fileconfig->filetype->slug))
        {
            case 'ACT':
            case 'RETAIL':
                $table_pre = 'me_act_pre_process';
                $table_post = 'me_act_post_process';
                break;
            case 'OGR':
                $table_pre = 'me_ogr_pre_process';
                $table_post = 'me_ogr_post_process';
                break;
            case 'SWP':
            case 'RETSWP':
                $table_pre = 'me_swp_pre_process';
                $table_post = 'me_swp_post_process';
                break;
            default:
                echo json_encode(array("msg" => "No network selected or network not found"));
                die;
        }
        $kitsNotInStock = DB::select('SELECT ' . $table_pre . '.serial_no FROM ' . $table_pre . ' where file_id = ' . $par);
        $serial = array();
        foreach ($kitsNotInStock as $s)
        {
            $r = DB::select('SELECT ' . $table_post . '.serial_no FROM ' . $table_post . ' where serial_no = "' . $s->serial_no . '"');
            if (empty($r[0]))
            {
                $serial[] = $s;
            }
        }
        return view('ajax.get_kits_not_valid_deal', compact('serial'));
    }

    /*
     * Function:- get_kits_not_in_stock
     * Description:- change status of serial no which is not in stock
     */

    public function get_kits_not_in_stock(StoreOgrRequest $request)
    {
        $par = (int) $request->all()['file_id'];
        $fileData = Ogr::where('id', $par)->get()->first();
        $table_pre = '';
        $table_post = '';
        switch (strtoupper($fileData->fileconfig->filetype->slug))
        {
            case 'ACT':
            case 'RETAIL':
            case 'DIRACT':
                $table_pre = 'me_act_pre_process';
                $table_post = 'me_act_post_process';
                break;
            case 'OGR':
            case 'DIROGR':
                $table_pre = 'me_ogr_pre_process';
                $table_post = 'me_ogr_post_process';
                break;
            case 'SWP':
            case 'RETSWP':
                $table_pre = 'me_swp_pre_process';
                $table_post = 'me_swp_post_process';
                break;
            default:
                echo json_encode(array("msg" => "No network selected or network not found"));
                die;
        }
        if (!empty($request->all()['count']))
        {
            $k = DB::select('UPDATE ' . $table_pre . ' SET `status`= 1 WHERE serial_no IN(SELECT serial_no FROM ' . $table_post . ' WHERE file_id = ' . $par . ');');
            return response()->json([
                'status' => "200",
                'id' => $par,
                'msg' => "kits not available in stock process completed",
                'count' => $k
            ]);
        }
        else
        {
            if ($table_pre == 'me_ogr_pre_process')
            {
                $kitsNotInStock = DB::select('SELECT ' . $table_pre . '.serial_no,total_recharge,revenue_percentage FROM ' . $table_pre . ' LEFT JOIN stock ON stock.serial_no = ' . $table_pre . '.serial_no WHERE stock.serial_no IS NULL and file_id = ' . $par . '');
            }
            else
            {
                $kitsNotInStock = DB::select('SELECT ' . $table_pre . '.serial_no FROM ' . $table_pre . ' LEFT JOIN stock ON stock.serial_no = ' . $table_pre . '.serial_no WHERE stock.serial_no IS NULL and file_id = ' . $par . '');
            }
            return view('ajax.get_kits_not_in_stock', compact('kitsNotInStock'));
        }
    }

    function reprocess_kits(StoreOgrRequest $request)
    {
        $par = (int) $request->all()['file_id'];
        $fileData = Ogr::where('id', $par)->get()->first();
        $table_pre = '';
        $table_post = '';
        switch (strtoupper($fileData->fileconfig->filetype->slug))
        {
            case 'ACT':
            case 'RETAIL':
            case 'DIRACT':
                $table_pre = 'me_act_pre_process';
                $table_post = 'me_act_post_process';
                break;
            case 'OGR':
            case 'DIROGR':
                $table_pre = 'me_ogr_pre_process';
                $table_post = 'me_ogr_post_process';
                break;
            case 'SWP':
            case 'RETSWP':
                $table_pre = 'me_swp_pre_process';
                $table_post = 'me_swp_post_process';
                break;
            default:
                echo json_encode(array("msg" => "No network selected or network not found"));
                die;
        }

        DB::select('INSERT into me_ogr_post_process SELECT 0,me_ogr_pre_process.file_id,sales_deal.customer_id,sales_deal.invoice_number,sales_deal.sales_order_detail_id,me_ogr_pre_process.network_id,stock.Product_id,me_ogr_pre_process.serial_no,me_ogr_pre_process.total_recharge as income,ROUND((me_ogr_pre_process.total_recharge*sales_deal.ogr)/100,2) AS expense FROM stock JOIN me_ogr_pre_process ON me_ogr_pre_process.serial_no = stock.serial_no JOIN sales_deal ON sales_deal.sales_order_detail_id=stock.invoice_id WHERE me_ogr_pre_process.file_id = ' . $par . ' and me_ogr_pre_process.status = 0');
        $k = DB::select('UPDATE me_ogr_pre_process SET `status`= 1 WHERE `status` = 0 and serial_no IN(SELECT serial_no FROM me_ogr_post_process WHERE file_id = ' . $par . ')');
        return response()->json([
            'status' => "200",
            'id' => $par,
            'msg' => "kits not available in stock process completed"
        ]);
    }

    function reprocess_invoices(StoreOgrRequest $request)
    {
        $par = (int) $request->all()['file_id'];
        $fileData = Ogr::where('id', $par)->get()->first();
        $table_pre = '';
        $table_post = '';
        switch (strtoupper($fileData->fileconfig->filetype->slug))
        {
            case 'ACT':
            case 'RETAIL':
            case 'DIRACT':
                $table_pre = 'me_act_pre_process';
                $table_post = 'me_act_post_process';
                break;
            case 'OGR':
            case 'DIROGR':
                $table_pre = 'me_ogr_pre_process';
                $table_post = 'me_ogr_post_process';
                break;
            case 'SWP':
            case 'RETSWP':
                $table_pre = 'me_swp_pre_process';
                $table_post = 'me_swp_post_process';
                break;
            default:
                echo json_encode(array("msg" => "No network selected or network not found"));
                die;
        }
        $invoiceNotInStock = DB::select("SELECT * FROM `me_ogr_post_process` WHERE invoice_number = '' AND file_id = $par");

        return response()->json([
            'status' => "200",
            'id' => $par,
            'msg' => "kits not available in stock process completed"
        ]);
    }

    /*
      Function:- store
      Process:- File import process with all calculation via ajax
     */

    public function store(StoreOgrRequest $request)
    {
        if (!empty($request->all()['store']))
        {
            if (!empty($request->all()['recal']))
            { //this is for reimport file 
                $fileData = Ogr::where('id', $request->all()['file_id'])->first();
                $file_name = $fileData->file_name;
                $rc = 0;

                $file_type = Fileconfig::where('id', $fileData->file_config_id)->first();
                $networkData = Network::where('id', $fileData->network_id)->first();

                $recal = 1;
                $config = Config::where("key", 'file_import_background')->first();
                if (!empty($config->value))
                {
                    $request->merge(['file_name' => $file_name]);

                    dispatch(new Monthendprocess($request->all(), $fileData));

                    return response()->json([
                        'status' => "200",
                        'id' => 0,
                        'msg' => "Month End file has been processed succesfully."
                    ]);
                }
            }
            else
            {
                $fileData = Ogr::where('id', $request->all()['file_id'])->get()->first();
                $networkData = Network::where('id', $fileData->network_id)->get()->first();
                $recal = 0;
            }

            switch (str_replace(' ', '', strtoupper($networkData->name)))
            {
                case 'VODACOM':
                    {
                        switch (strtoupper($fileData->fileconfig->filetype->slug))
                        {
                            case 'ACT':
                                $q = 'CALL MonthEndCONVodacom(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'CON':
                                $q = 'CALL MonthEndCONVodacom(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'DEL':
                                $q = 'CALL calculationPostProcessDel(' . $request->all()['file_id'] . ',' . $recal . ',"me_vodacom_del_raw")';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'OGR':
                                $q = 'CALL MonthEndOGRVodacom(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                case 'MTN':
                    {
                        switch (strtoupper($fileData->fileconfig->filetype->slug))
                        {
                            case 'ACT':
                                $q = 'CALL MonthEndACTMTN(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'RETAIL':
                                $q = 'CALL MonthEndRETAILMTN(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'CON':
                                $q = 'CALL MonthEndCONMTN(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'SWP':
                            case 'RETSWP':
                                $q = 'CALL MonthEndSWPMTN(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'DEL':
                                $q = 'CALL calculationPostProcessDel(' . $request->all()['file_id'] . ',' . $recal . ',"me_mtn_del_raw")';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'OGR':
                                $q = 'CALL MonthEndOGRMTN(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                case 'CELLC':
                    {
                        switch (strtoupper($fileData->fileconfig->filetype->slug))
                        {
                            case 'ACT':
                                $q = 'CALL MonthEndACTCELLC(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'CON':
                                $q = 'CALL MonthEndCONCELLC(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'OGR':
                                $q = 'CALL MonthEndOGRCELLC(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                case 'TELKOM':
                    {
                        switch (strtoupper($fileData->fileconfig->filetype->slug))
                        {
                            case 'ACT':
                            case 'DIRACT':
                                $q = 'CALL MonthEndACTTelkom(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            case 'OGR':
                            case 'DIROGR':
                                $q = 'CALL MonthEndOGRTelkom(' . $request->all()['file_id'] . ',' . $recal . ')';
                                $q = DB::connection()->getPdo()->exec($q);
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                default:
                    return response()->json([
                        'status' => "400",
                        'msg' => "No network selected or No File configuration found."
                    ]);
            }
            $sos = Config::where("key", "monthend_import_status")->first();
            if (!empty($sos->value))
            {
                $this->sendEmails($sos->value, new Monthend($fileData));
                $u = User::find($fileData->user_id);
                $u->notify(new Monthend($fileData));
            }
            return response()->json([
                'status' => "200",
                'id' => $request->all()['file_id'],
                'msg' => "Month End file has been processed succesfully."
            ]);
        }
        else
        {
            if (!empty($request->all()['reimp']))
            { //this is for reimport file 
                $file_data = Ogr::where('id', $request->all()['file_id'])->get()->first();
                $file_name = $file_data->file_name;
                $rc = 0;

                $file_type = Fileconfig::where('id', $file_data->file_config_id)->get()->first();
                $networkData = Network::where('id', $file_data->network_id)->get()->first();
                $col = '';
                $tab = '';
                $ignoreFirstLine = '';
            }
            else
            {
                $file_data = Ogr::where('file_name', $request->input('file_name'))->get()->first();
                if (!empty($file_data->file_name))
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "File is already uploaded"
                    ]);
                }
                if (empty($request->input('process_month')))
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "Please select valid process month."
                    ]);
                }
                if (empty($request->input('network_id')))
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "Please select network."
                    ]);
                }
                if (empty($request->input('file_name')))
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "Please give file name."
                    ]);
                }
                $file_name = $request->input('file_name');
                $rc = $request->all()['record_count'];

                unset($request->all()['record_count']);
                $request->offsetSet('process_month', $request->all()['process_month'] . "-01");

                $file_type = Fileconfig::where('id', $request->all()['file_config_id'])->get()->first();
                $networkData = Network::where('id', $request->all()['network_id'])->get()->first();
                $col = '';
                $tab = '';
                $ignoreFirstLine = '';
            }

            $t = Storage::disk('local')->path($file_type->path . '/' . $file_name);
            $a = Storage::disk('local')->path($file_type->path . '/archived' . '/' . $file_name);

            if (file_exists($t))
            { //check if file exist
                if (empty($request->all()['reimp']))
                {
                    $request->request->add(['user_id' => Auth::user()->id]);

                    $data = Ogr::create($request->all());
                }
                $config = Config::where("key", 'file_import_background')->get()->first();
                if (!empty($config->value))
                {
                    $request->merge(['file_name' => $file_name]);
                    if (empty($request->all()['reimp']))
                    {
                        dispatch(new Monthendprocess($request->all(), $data));
                    }
                    else
                    {
                        dispatch(new Monthendprocess($request->all(), $file_data));
                    }
                    return response()->json([
                        'status' => "200",
                        'id' => 0,
                        'msg' => "Month End file has been processed succesfully."
                    ]);
                }

                $fId = $data->id;
                $nId = $request->all()['network_id'];

                if (!empty($request->all()['reimp']))
                {
                    $fId = $file_data->id;
                    $nId = $file_data->network_id;
                }

                switch (str_replace(' ', '', strtoupper($networkData->name)))
                { //switch case for network
                    case 'VODACOM':
                        { // make column and table related to network and file type for load file query
                            switch (strtoupper($file_type->filetype->slug))
                            {
                                case 'ACT':
                                    $tab = 'me_vodacom_act_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6) set file_id = ' . $fId . ',network_id = ' . $nId . ',denom=@col4,serial_no=@col1,msisdn=@col3,conn_month=@col2,cust_code=@col5';
                                    break;
                                case 'CON':
                                    $tab = 'me_vodacom_con_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6) set file_id = ' . $fId . ',network_id = ' . $nId . ',denom=@col4,serial_no=@col1,msisdn=@col3,conn_month=@col2,cust_code=@col5';
                                    break;
                                case 'DEL':
                                    $tab = 'me_vodacom_del_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2) set file_id = ' . $fId . ',network_id = ' . $nId . ',serial_no=@col1,del_month=@col2';
                                    break;
                                case 'OGR':
                                    $tab = 'me_vodacom_ogr_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8) set file_id = ' . $fId . ',network_id = ' . $nId . ',denom=@col3,recharge_count=@col4,serial_no=@col2,msisdn=@col5,denom_duplicate=@col6,revenue_percentage=@col7,cust_code=@col8';
                                    break;
                                default:
                                    echo json_encode(array("msg" => "No network selected or network not found"));
                                    die;
                            }
                        }
                        break;
                    case 'MTN':
                        {
                            switch (strtoupper($file_type->filetype->slug))
                            {
                                case 'ACT':
                                    $tab = 'me_mtn_act_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21,@col22,@col23,@col24,@col25,@col26,@col27,@col28,@col29,@col30,@col31,@col32,@col33,@col34,@col35,@col36,@col37,@col38,@col39,@col40) set file_id = ' . $fId . ',network_id = ' . $nId . ',primary_grp=@col1,prov_first_conn=@col2,city_first_conn=@col3,customer_name=@col4,address1=@col5,province=@col6,region_name=@col7,category_set_name=@col8,cat_segment2=@col9,cat_segment3=@col10,distribution_date=@col11,msisdn=@col12,sim=@col13,serial_number=@col14,trx_number=@col15,box_serial_number=@col16,brick_serial_number=@col17,activation_date=@col18,dt_port_in=@col19,rica_date=@col20,comm_mth=@col21,usage_spent_4mths=@col22,usage_spent_7mths=@col23,voice_amt_4mths=@col24,gprsamt_4mths=@col25,total_bundle_purchase_amt_4mths=@col26,xtratime_sfee_repay_4mths=@col27,comms_category=@col28,comm_excl=@col29,vat=@col30,comm_incl=@col31,agents_company_name=@col32,officers_identity_number=@col33,officers_company_name=@col34,officers_name=@col35,flag_spend=@col36,gprs_inbundle_amt_4mths=@col37,sms_inbundle_amt_4mths=@col38,mms_inbundle_amt_4mths=@col39,voice_inbundle_amt_4mths=@col40';
                                    break;
                                case 'CON':
                                    $tab = 'me_mtn_con_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21,@col22,@col23,@col24,@col25,@col26,@col27,@col28,@col29,@col30,@col31,@col32,@col33,@col34) set file_id = ' . $fId . ',network_id = ' . $nId . ',primary_grp=@col1,prov_first_conn=@col2,city_first_conn=@col3,customer_name=@col4,address1=@col5,province=@col6,region_name=@col7,category_set_name=@col8,description=@col9,cat_segment2=@col10,cat_segment3=@col11,distribution_date=@col12,msisdn=@col13,serial_number=@col14,trx_number=@col15,box_serial_number=@col16,brick_serial_number=@col17,activation_date=@col18,act_inc_prt=@col19,port_in_flag=@col20,usage_spent_4mths=@col21,usage_spent_7mths=@col22,list_price=@col23,selling_price=@col24,cps135_sim=@col25,comms_category=@col26,comm_excl=@col27,vat=@col28,comm_incl=@col29,agents_company_name=@col30,rica_date=@col31,officers_identity_number=@col32,officers_company_name=@col33,officers_name=@col34';
                                    break;
                                case 'SWP':
                                    $tab = 'me_mtn_simswap_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21) set file_id = ' . $fId . ',network_id = ' . $nId . ',primary_grp=@col1,prov_first_conn=@col2,city_first_conn=@col3,customer_name=@col4,address1=@col5,category_set_name=@col6,description=@col7,serial_number=@col8,comm_excl=@col9,vat=@col10,comm_incl=@col11,sim_flag=@col12,sim_flag_month=@col13,donor_kit_sim=@col14,donor_msisdn=@col15,donor_trans_date=@col16,customer_category_code=@col17,accumulated_usage=@col18,category=@col19,customer_number=@col20,site_use_id=@col21';
                                    break;
                                case 'RETSWP':
                                    $tab = 'me_mtn_simswap_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16) set file_id = ' . $fId . ',network_id = ' . $nId . ',primary_grp=@col1,sim_flag=@col2,sim_flag_month=@col3,donor_msisdn=@col4,donor_kit_sim=@col5,donor_trans_date=@col6,serial_number=@col7,customer_name=@col8,address1=@col9,customer_category_code=@col10,category_set_name=@col11,description=@col12,accumulated_usage=@col13,comm_excl=@col14,vat=@col15,comm_incl=@col16';
                                    break;
                                case 'DEL':
                                    $tab = 'me_mtn_del_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21) set file_id = ' . $fId . ',network_id = ' . $nId . ',primary_grp=@col1,prov_first_conn=@col2,city_first_conn=@col3,customer_name=@col4,address1=@col5,province=@col6,region_name=@col7,category_set_name=@col8,description=@col9,cat_segment2=@col10,cat_segment3=@col11,distribution_date=@col12,msisdn=@col13,serial_number=@col14,trx_number=@col15,box_serial_number=@col16,brick_serial_number=@col17,cps135_imei_number=@col18,activation_date=@col19,comm_mth=@col20,deactdte=@col21';
                                    break;
                                case 'OGR':
                                    $tab = 'me_mtn_ogr_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21,@col22,@col23,@col24,@col25,@col26,@col27,@col28,@col29,@col30,@col31,@col32,@col33,@col34,@col35,@col36,@col37,@col38,@col39,@col40,@col41) set file_id = ' . $fId . ',network_id = ' . $nId . ',primary_grp=@col1,prov_first_conn=@col2,city_first_conn=@col3,customer_group=@col4,customer_name=@col5,address1=@col6,province=@col7,region_name=@col8,category_set_name=@col9,description=@col10,cat_segment2=@col11,cat_segment3=@col12,distribution_date=@col13,msisdn=@col14,serial_number=@col15,trx_number=@col16,box_serial_number=@col17,brick_serial_number=@col18,cps135_imei_number=@col19,activation_date=@col20,comm_mth=@col21,comms_category=@col22,comm_excl=@col23,vat=@col24,comm_incl=@col25,base=@col26,percentage=(@col27*100),revenue_mth_0=@col28,revenue_mth_1=@col29,revenue_mth_2=@col30,revenue_mth_3=@col31,total_recharge_amt=@col32,pre_loaded=@col33,flag_spend=@col34,total_bundle_purchase_amt=@col35,xtratime_sfee_repay=@col36,billdur=@col37,callcost=@col38,smscost=@col39,mmsamt=@col40,gprsamt=@col41';
                                    break;
                                case 'RETAIL':
                                    $tab = 'me_mtn_retail_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21,@col22,@col23,@col24,@col25,@col26) set file_id = ' . $fId . ',network_id = ' . $nId . ',report_month=@col1,simFlag=@col2,simFlagMonth=@col3,simFlagQtr=@col4,msisdn=@col5,primary_grp=@col6,customer_name=@col7,activation_date=@col8,distribution_date=@col9,deactivation_date=@col10,category_set_name=@col11,cat_segment2=@col12,cat_segment3=@col13,province=@col14,region_name=@col15,serial_number=@col16,customer_number=@col17,description=@col18,store=@col19,customer_class_code=@col20,demand_class_code=@col21,comm_incl=@col22,comm_excl=@col23,vat=@col24,sim=@col25,branded_store_code=@col26';
                                    break;
                                default:
                                    echo json_encode(array("msg" => "No network selected or network not found"));
                                    die;
                            }
                        }
                        break;
                    case 'CELLC':
                        {
                            switch (strtoupper($file_type->filetype->slug))
                            {
                                case 'ACT':
                                    $tab = 'me_cellc_act_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5) set file_id = ' . $fId . ',network_id = ' . $nId . ',denom=@col4,serial_no=@col1,msisdn=@col3,conn_month=@col2,cust_code=@col5';
                                    break;
                                case 'CON':
                                    $tab = 'me_cellc_con_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5) set file_id = ' . $fId . ',network_id = ' . $nId . ',denom=@col4,serial_no=@col1,msisdn=@col3,conn_month=@col2,cust_code=@col5';
                                    break;
                                case 'OGR':
                                    $tab = 'me_cellc_ogr_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8) set file_id = ' . $fId . ',network_id = ' . $nId . ',denom=@col3,recharge_count=@col4,serial_no=@col2,msisdn=@col5,denom_duplicate=@col6,revenue_percentage=@col7,cust_code=@col8';
                                    break;
                                default:
                                    echo json_encode(array("msg" => "No network selected or network not found"));
                                    die;
                            }
                        }
                        break;
                    case 'TELKOM':
                        {
                            switch (strtoupper($file_type->filetype->slug))
                            {
                                case 'ACT':
                                case 'DIRACT':
                                    $tab = 'me_telkom_act_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16) set file_id = ' . $fId . ',network_id = ' . $nId . ',dealer_code=@col1,dealer_name=@col2,msisdn=@col3,iccid=@col4,imei=@col5,tariff_plan=@col6,connection_date=@col7,billing_period=@col8,commission_code=@col9,subscriber_type=@col10,commission_amount=@col11,commission_amount_excl_vat=@col12,deal_id=@col13,sub_dealer_code=@col14,comm_rocode=@col15,retail_outlet_name=@col16';
                                    break;
                                case 'OGR':
                                    $tab = 'me_telkom_ogr_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17) set file_id = ' . $fId . ',network_id = ' . $nId . ',dealer_code=@col1,dealer_name=@col2,msisdn=@col3,sim_seq_num=@col4,imei=@col5,connection_date=@col6,billing_period=@col7,commission_code=@col8,subscriber_type=@col9,deal_id=@col10,commissionable_amount=REPLACE(@col11, \' \', \'\'),commission_amount=@col12,commission_amount_excl_vat=@col13,commissionable_percent=@col14,sub_dealer_code=@col15,comm_rocode=@col16,retail_outlet_name=@col17';
                                    break;
                                case 'DIROGR':
                                    $tab = 'me_telkom_ogr_raw';
                                    if (!empty($request->all()['reimp']))
                                    {
                                        DB::table($tab)->where('file_id', $request->all()['file_id'])->delete();
                                    }
                                    $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16) set file_id = ' . $fId . ',network_id = ' . $nId . ',dealer_code=@col1,dealer_name=@col2,msisdn=@col3,sim_seq_num=@col4,imei=@col5,connection_date=@col6,billing_period=@col7,commission_code=@col8,subscriber_type=@col9,deal_id=@col10,commissionable_amount=REPLACE(@col11, \' \', \'\'),commission_amount=@col12,commission_amount_excl_vat=@col13,sub_dealer_code=@col14,comm_rocode=@col15,retail_outlet_name=@col16';
                                    break;
                                default:
                                    echo json_encode(array("msg" => "No network selected or network not found"));
                                    die;
                            }
                        }
                        break;
                    default:
                        echo json_encode(array("msg" => "No network selected or network not found"));
                        die;
                }

                $t = str_replace("\\", "/", $t);
                $t = str_replace(':', ':/', $t);

                $a = str_replace("\\", "/", $a);

                $a = str_replace(':', ':/', $a);

                //query for load file into table
                if (!empty($request->all()['reimp']))
                {
                    DB::select('update me_import_file set status = 0 where id = ' . $file_data->id . '');
                }
                $q = 'LOAD DATA LOCAL INFILE  \'' . $t . '\'
                INTO TABLE ' . $tab . '
                FIELDS TERMINATED by \'' . $file_type['ft'] . '\' LINES TERMINATED BY \'' . $file_type['lt'] . '\' IGNORE ' . $file_type->ignore_line . ' LINES ' . $col . '';
                $q = DB::connection()->getPdo()->exec($q);
                if ($q <= 0)
                {
                    return response()->json([
                        'status' => "400",
                        'msg' => "Somthing wrong, check the file format."
                    ]);
                }

                if ($rc != null)
                {
                    $count = DB::table($tab)
                        ->where('file_id', $data->id)
                        ->count();
                    if ($count == $rc)
                    {
                        $q = 'update me_import_file set status = 1 where id = ' . $data->id . '';
                        $q = DB::connection()->getPdo()->exec($q);

                        Storage::move($file_type->path . '/' . $file_name, $file_type->path . '/archived' . '/' . $file_name);
                        return response()->json([
                            'status' => "200",
                            'msg' => "File has been imported and records have been validated.",
                            "id" => $data->id,
                            "network_id" => $request->all()['network_id']
                        ]);
                    }
                    else
                    {
                        Ogr::destroy($data->id);
                        DB::table($tab)
                            ->where('file_id', $data->id)
                            ->delete();
                        return response()->json([
                            'status' => "400",
                            'msg' => "File has been imported but there is " . $count . " records found."
                        ]);
                    }
                }
                if (empty($request->all()['reimp']))
                {
                    $q = 'update me_import_file set status = 1 where id = ' . $data->id . '';
                    $q = DB::connection()->getPdo()->exec($q);
                    Storage::move($file_type->path . '/' . $file_name, $file_type->path . '/archived' . '/' . $file_name);

                    return response()->json([
                        'status' => "200",
                        'msg' => "File has been started uploading.",
                        "id" => $data->id,
                        "network_id" => $request->all()['network_id']
                    ]);
                }
                else
                {
                    DB::select('update me_import_file set status = 1 where id = ' . $file_data->id . '');
                    Storage::move($file_type->path . '\\' . $file_name, $file_type->path . '/archived' . '/' . $file_name);

                    return response()->json([
                        'status' => "200",
                        'msg' => "File has been proccessed.",
                        "id" => $file_data->id,
                        "network_id" => $file_data->network_id
                    ]);
                }
            }
            else
            {
                // send fail response back to ajax request 
                return response()->json([
                    'status' => "404",
                    'msg' => "File is not found."
                ]);
            }
        }
    }
}
