<?php

namespace App\Http\Controllers\Api;

use App\Customer;
use App\Identity;
use App\Address;
use App\Contact;
use App\Group;
use App\Region;
use App\AddressType;
use App\Contract;
use App\CustomerHasAddress;
use App\CustomerHasContact;
use App\Country;
use App\CustomerSplit;
use App\ExternalSystemReference;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Requests\Admin\UpdateCustomerRequest;
use App\Http\Requests\Admin\StoreCustomerRequest;
use App\Status;
use App\User;
use App\TierStage;
use App\Network;
use Illuminate\Support\Facades\Auth;
use Session;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use RealRashid\SweetAlert\Facades\Alert;

class CustomerController extends Controller
{

    //Edit Function
    public function edit(Customer $customer)
    {

        if (!Gate::allows('edit_customers')) {
            return abort(401);
        }

        $addresstype = Status::whereProcess('address_type')->get();
        $identity = Status::whereProcess('identity_type')->get();
        $paymentmethod = Status::whereProcess('payment_method')->get();
        $group = Group::all();
        $users = User::all();
        $country = Country::all();
        $repuser = User::where('user_type_id', 2)->get();
        $customers = Customer::where('parent_id', -1)->get();
        $parentcustomer = Customer::find($customer->parent_id);

        return view('admin.customer.edit', compact('customer', 'identity', 'group', 'addresstype', 'users', 'repuser', 'customers', 'parentcustomer', 'country', 'paymentmethod'));
    }


    public function update_parent(Request $request)
    {
        //dd($request->all());
        $customer = Customer::find($request->input("id"));
        $customer->parent_id = $request->input("parent_id");
        $customer->save();
        return back();
    }

    //Update Customer
    public function update(UpdateCustomerRequest $request, Customer $customer)
    {

        // $user_id = Auth::user()->user_type_id == 2 ? Auth::user()->id : -1;
        // $request->request->add(['user_id' => $user_id]);
        $customer->update($request->except(['contact', 'address']));
        if ($request->filled('address')) {
            foreach ($request->address as $key => $id) {
                $address = Address::find($id);
                $address->customer_id = $customer->id;
                $address->save();
            }
        }
        if ($request->filled('contact')) {
            foreach ($request->contact as $key => $id) {
                $contact = Contact::find($id);
                $contact->customer_id = $customer->id;
                $contact->save();
            }
        }
        Alert::success('Success', "The customer has been updated.");
        return redirect()->route('admin.customer.index');
    }


    /**
     * @OA\Post(
     ** path="/api/v1/customer/register",
     *   tags={"Customers"},
     *   summary="register new customer",
     *   operationId="register",
     * security={
     *  {"passport": {}},
     *   },
     *   @OA\Parameter(
     *      name="cust_code",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="rep_user_id",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="parent_id",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="group_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="identity_type_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="identity_reference",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="name",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="payment_method_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     * 
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     **/

    public function register(Request $request)
    {

        if (!Gate::allows('add_customers')) {
            return  responder()->error(403, "You don't have permission.")->respond(403);
        }
        $validator = Validator::make($request->all(), [
            'cust_code' => 'required|unique:customer',
            'name' => 'required',
            'group_id' => 'required',
            'identity_type_id' => 'required',
            'payment_method_id' => 'required',
            'identity_reference' => 'required',
        ]);

        if ($validator->fails()) {
            return responder()->error(400, "vaidation_error")->data(['data' => $validator->errors()])->respond(400);
        }
        $request->request->add(["is_active"=>0]);
        $cus = Customer::create($request->all());
        if (!$cus->id) {
            responder()->error()->respond(500);
        } else {
            return responder()->success($cus)->respond(200);
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/customer/groups",
     *      operationId="getCustomerGroups",
     *      tags={"Customers"},
     *      summary="Get customers groups",
     *      description="Returns customers groups",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function groups()
    {
        return responder()->success(Group::all())->respond();
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/customer/identity_types",
     *      operationId="getIdentityTypes",
     *      tags={"Customers"},
     *      summary="Get customers IdentityTypes",
     *      description="Returns customers IdentityTypes",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function identity_types()
    {
        return responder()->success(Status::whereProcess("identity_type"))->respond();
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/customer/payment_methods",
     *      operationId="getPaymentMethods",
     *      tags={"Customers"},
     *      summary="Get customers preferred Payment Methods",
     *      description="Returns customers preferred Payment Methods",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function payment_methods()
    {
        return responder()->success(Status::whereProcess("payment_method"))->respond();
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/customer/external_system_reference",
     *      operationId="getExternalSystemReference",
     *      tags={"Customers"},
     *      summary="Get customers ExternalSystemReference",
     *      description="Returns customers ExternalSystemReference",
     * security={
     *  {"passport": {}},
     *   },
     *   @OA\Parameter(
     *      name="external_system_id",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function list_external_system_reference(Request $request)
    {
        $customer = Customer::whereUserId(Auth::user()->id)->first();
        if (empty($customer)) {
            return responder()->error(500,"We dnd't found any customer profile for this user.")->respond(500);
        }
        if($request->filled("external_system_id")){
            return responder()->success(ExternalSystemReference::whereCustomerId($customer->id)->whereExternalSystemId($request->external_system_id))->respond();
        }else{
            return responder()->success(ExternalSystemReference::whereCustomerId($customer->id))->respond();
        }
    }

    /**
     * @OA\Post(
     ** path="/api/v1/customer/external_system_reference",
     *   tags={"Customers"},
     *   summary="register new external_system_reference",
     *   operationId="registerExternalSystemReference",
     * security={
     *  {"passport": {}},
     *   },
     *   @OA\Parameter(
     *      name="external_system_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="customer_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="reference",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="data",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     **/

    public function external_system_reference(Request $request)
    {
        $customer = Customer::whereUserId(Auth::user()->id)->first();
        if (empty($customer->id)) {
            return responder()->error("We dnd't found any customer profile for this user.")->respond(500);
        } else {
            $request->request->add(['customer_id', $customer->id]);
        }
        $validator = Validator::make($request->all(), [
            'external_system_id' => 'required',
            'reference' => 'required',
        ]);
        if ($validator->fails()) {
            return responder()->error(400, "vaidation_error")->data(['data' => $validator->errors()])->respond(400);
        }

        $cus = ExternalSystemReference::create($request->only(['external_system_id', 'customer_id', 'reference', 'data']));
        if (!$cus->id) {
            responder()->error()->respond(500);
        } else {
            return responder()->success($cus)->respond(200);
        }
    }

    /**
     * @OA\Put(
     ** path="/api/v1/customer/external_system_reference",
     *   tags={"Customers"},
     *   summary="update existing external_system_reference",
     *   operationId="updateExternalSystemReference",
     * security={
     *  {"passport": {}},
     *   },
     *   @OA\Parameter(
     *      name="id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="reference",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="data",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     **/

    public function external_system_reference_update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id' => 'required',
            'reference' => 'required',
            'data'=>'required'
        ]);
        if ($validator->fails()) {
            return responder()->error(400, "vaidation_error")->data(['data' => $validator->errors()])->respond(400);
        }
        $user=Auth::user();
        $customer=Customer::whereUserId($user->id)->first();
        if(!$customer){
            return responder()->error(400, "vaidation_error")->data(['data' => ["No customer account found for this user."]])->respond(400);
        }else{
            $e = ExternalSystemReference::find($request->id);
            if($e->customer_id!=$customer->id){
                return responder()->error(400, "vaidation_error")->data(['data' => ["You can't update this external system reference."]])->respond(400);
            }
            $cus=$e->update($request->all());
            if (!$cus) {
                return responder()->error()->respond(500);
            } else {
                return responder()->success(ExternalSystemReference::find($request->id))->respond(200);
            }
        }
    }
    function identity_type_ref_validation($idNumber)
    {
        $correct = 1;
        if (strlen($idNumber) !== 13 || !is_numeric($idNumber)) {
            //echo 'ID number does not appear to be authentic - input not a valid number';
            $correct = 0;
            // die();
        }

        $year = substr($idNumber, 0, 2);
        $currentYear = date('Y') % 100;
        $prefix = '19';
        if ($year < $currentYear) {
            $prefix = '20';
        }
        $id_year = $prefix . $year;

        $id_month = substr($idNumber, 2, 2);
        $id_date = substr($idNumber, 4, 2);

        $fullDate = $id_year . '-' . $id_month . '-' . $id_date;

        global $dateOfBirth;


        $dateOfBirth = $fullDate;
        if (!$id_year == substr($idNumber, 0, 2) && $id_month == substr($idNumber, 2, 2) && $id_date == substr($idNumber, 4, 2)) {
            ///  echo 'ID number does not appear to be authentic - date part not valid';
            $correct = 0;
        }
        $genderCode = substr($idNumber, 6, 4);
        $gender = (int) $genderCode < 5000 ? 'Female' : 'Male';

        global $genders;

        $genders = $gender;

        $citzenship = (int) substr($idNumber, 10, 1) === 0 ? 'citizen' : 'resident'; //0 for South African citizen, 1 for a permanent resident

        $total = 0;
        $count = 0;
        for ($i = 0; $i < strlen($idNumber); ++$i) {
            $multiplier = $count % 2 + 1;
            ++$count;
            $temp = $multiplier * (int) $idNumber[$i];
            $temp = floor($temp / 10) + ($temp % 10);
            $total += $temp;
        }
        $total = ($total * 9) % 10;

        if ($total % 10 != 0) {
            return false;
        }
        return true;
    }

    public function change_status(Request $request)
    {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Customer::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
            'status' => "200",
            'msg' => "The customer has been $msg successfully"
        ]);
    }
}
