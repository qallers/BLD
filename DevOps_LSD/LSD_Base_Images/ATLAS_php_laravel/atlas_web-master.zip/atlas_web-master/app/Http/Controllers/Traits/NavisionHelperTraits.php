<?php

namespace App\Http\Controllers\Traits;

use App\Config;
use Exception;
use SaintSystems\OData\ODataClient;

trait NavisionHelperTraits
{
    public function isEnabled()
    {
        return $this->getConfig()->nav_enabled;
    }
    public function getConfig()
    {   
        return (object)Config::whereIn('key', ['nav_odata_url','nav_username','nav_password','nav_enabled'])->get()->pluck('value','key')->toArray();  
    }

    public function nav_get($resource)
    {
        if($this->isEnabled()){
            $config=$this->getConfig();
            $odataClient = new ODataClient($config->nav_odata_url, function($request) {
                $request->headers['Accept'] = 'application/json';
              });
            $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));
            return $odataClient->from($resource)->get();
        }else{
            return false;
        }
    }
    public function nav_get_select($resource,$select)
    {
        if($this->isEnabled()){
            $config=$this->getConfig();
            $odataClient = new ODataClient($config->nav_odata_url, function($request) {
                $request->headers['Accept'] = 'application/json';
              });
            $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));
            return $odataClient->from($resource)->select($select)->get();
        }else{
            return false;
        }
    }
    public function nav_get_find($resource,$find)
    {
        if($this->isEnabled()){
            $config=$this->getConfig();
            $odataClient = new ODataClient($config->nav_odata_url, function($request) {
                $request->headers['Accept'] = 'application/json';
              });
            $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));
            return $odataClient->from($resource)->find($find);
        }else{
            return false;
        }
    }
    public function nav_get_order_lines($resource,$find,$node)
    {
        if($this->isEnabled()){
            $config=$this->getConfig();
            $odataClient = new ODataClient($config->nav_odata_url, function($request) {
                $request->headers['Accept'] = 'application/json';
              });
            $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));
            return $odataClient->from($resource."(Document_Type='Order',No='".$find."')/".$node)->get();
        }else{
            return false;
        }
    }

    public function nav_get_order_line($resource,$find,$line)
    {
        if($this->isEnabled()){
            $config=$this->getConfig();
            $odataClient = new ODataClient($config->nav_odata_url, function($request) {
                $request->headers['Accept'] = 'application/json';
              });
            $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));
            return $odataClient->from($resource."(Document_Type='Order',Document_No='".$find."',Line_No=".(int)$line.")")->get()[0];
        }else{
            return false;
        }
    }

    public function nav_post($resource,$data)
    {
        if($this->isEnabled()){
            $config=$this->getConfig();
            $odataClient = new ODataClient($config->nav_odata_url, function($request) {
                $request->headers['Accept'] = 'application/json';
              });
            $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));
           
            return $odataClient->post($resource,$data);
            
        }else{
            return false;
        }
    }

    public function nav_patch($resource,$node,$data)
    {
        if($this->isEnabled()){
            $config=$this->getConfig();
            $tag=$this->nav_get_find($resource,$node);
            $eTag = 'W/"\'' . $tag->ETag . '\'"';
            $odataClient = new ODataClient($config->nav_odata_url, function($request) use ($eTag){
                $request->headers['Accept'] = 'application/json';
                $request->headers['If-Match'] = $eTag;
              });
            $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));
        
            return $odataClient->patch($resource."('$node')",$data);
            
        }else{
            return false;
        }
    }

    
    public function nav_patch_order($resource,$id,$line,$data)
    {
        if($this->isEnabled()){
            $config=$this->getConfig();
            $tag=$this->nav_get_order_line($resource,$id,$line);
            $eTag = 'W/"\'' . $tag->ETag . '\'"';
            $odataClient = new ODataClient($config->nav_odata_url, function($request) use ($eTag){
                $request->headers['Accept'] = 'application/json';
                $request->headers['If-Match'] = $eTag;
              });
            $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));
        
            return $odataClient->patch($resource."(Document_Type='Order',Document_No='".$id."',Line_No=".(int)$line.")",$data);
            
        }else{
            return false;
        }
    }

    public function nav_patch_transfer($id,$line,$data)
    {
        if($this->isEnabled()){
            $config=$this->getConfig();
            $tag=$this->nav_get_transfer_line($id,$line);
            $eTag = 'W/"\'' . $tag->ETag . '\'"';
            $odataClient = new ODataClient($config->nav_odata_url, function($request) use ($eTag){
                $request->headers['Accept'] = 'application/json';
                $request->headers['If-Match'] = $eTag;
              });
            $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));
        
            return $odataClient->patch("/Transfer_OrderTransferLines(Document_No='".$id."',Line_No=".(int)$line.")",$data);
            
        }else{
            return false;
        }
    }

    public function nav_get_transfer_line($find,$line)
    {
        if($this->isEnabled()){
            $config=$this->getConfig();
            $odataClient = new ODataClient($config->nav_odata_url, function($request) {
                $request->headers['Accept'] = 'application/json';
              });
            $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));
            return $odataClient->from("/Transfer_OrderTransferLines(Document_No='".$find."',Line_No=".(int)$line.")")->get()[0];
        }else{
            return false;
        }
    }
}