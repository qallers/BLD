<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Flash;
use Response;
use App\User;
use App\Status;
use App\SalesOrder;
use Spatie\Activitylog\Models\Activity;
use DataTables;
use Spatie\Permission\Models\Role;

class OrderController extends Controller {

    /**
     * Display a listing of the Admin/audits.
     *
     * @param Request $request
     *
     * @return Response
     */
    public function index(Request $request) {
        /** @var Admin/audits $admin/audits */
        $users = User::all();
        $roles = Role::all();

        return view('admin.audits.index', compact('users', 'roles'));
    }

    public function purchase_order(Request $request) {
        /** @var Admin/audits $admin/audits */
        $users = User::all();
        $roles = Role::all();


        return view('order.purchase.index', compact('users', 'roles'));
    }
    public function purchase_order_approve(Request $request) {
        /** @var Admin/audits $admin/audits */
        $users = User::all();
        $roles = Role::all();


        return view('admin.purchase.approve', compact('users', 'roles'));
    }

    public function sales_order_approve(Request $request) {
        /** @var Admin/audits $admin/audits */
        $path = explode('/', $_SERVER['PHP_SELF']);
        $path = end($path);
        $is_dis = false;
        if ($path == 'dispatch') {
            $is_dis = true;
        }

        $payment = Status::where('process', 'payment_status')->get();
        $delivery = Status::where('process', 'delivery_mode')->get();


        return view('order.sales.approve', compact('payment', 'delivery', 'is_dis'));
    }
    public function sales_order(Request $request) {
        /** @var Admin/audits $admin/audits */
        $path = explode('/', $_SERVER['PHP_SELF']);
        $path = end($path);
        $is_dis = false;
        if ($path == 'dispatch') {
            $is_dis = true;
        }

        $payment = Status::where('process', 'payment_status')->get();
        $delivery = Status::where('process', 'delivery_mode')->get();


        return view('order.sales.index', compact('payment', 'delivery', 'is_dis'));
    }

    public function list(Request $request) {
        /** @var Admin/audits $admin/audits */
        if (!empty($request->input('roles'))) {
            $users = Role::where('id', $request->input('roles'))->with('users')->first();
            $ids = $users->pluck('id');
            $audits = Activity::with('causer', 'subject')
                    ->whereIn('causer_id', $ids);
        } else if (!empty($request->input('ids'))) {
            $ids = [$request->input("ids")];
            $audits = Activity::with('causer', 'subject')
                    ->whereIn('causer_id', $ids);
            ;
        } else {
            $audits = Activity::with('causer', 'subject');
        }


        return datatables()->of($audits)
                        ->make();
    }

    /**
     * Show the form for creating a new Admin/audits.
     *
     * @return Response
     */
    public function create() {
        return view('admin/audits.create');
    }

    /**
     * Display the specified Admin/audits.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id) {
        /** @var Admin/audits $admin/audits */
        $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->find($id);
        return view('order/sales.show', compact('order'));
    }


}
