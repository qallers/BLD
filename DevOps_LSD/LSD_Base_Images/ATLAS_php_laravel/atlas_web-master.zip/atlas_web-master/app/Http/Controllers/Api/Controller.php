<?php

class Controller
{
    /**
     * @OA\Info(
     *      version="1.0.0",
     *      title="Track n Trace OpenAPI Documentation",
     *      description="Track n Trace Swagger API documentation",
     *      @OA\Contact(
     *          email="tntsupport@t3tsa.co.za"
     *      ),
     *      @OA\License(
     *          name="Apache 2.0",
     *          url="http://www.apache.org/licenses/LICENSE-2.0.html"
     *      )
     * )
     *
     * @OA\Server(
     *      url=L5_SWAGGER_CONST_HOST,
     *      description="API Server"
     * )

     *
     * @OA\Tag(
     *     name="Track n Trace",
     *     description="API Endpoints of Track n Trace"
     * )
     */
}