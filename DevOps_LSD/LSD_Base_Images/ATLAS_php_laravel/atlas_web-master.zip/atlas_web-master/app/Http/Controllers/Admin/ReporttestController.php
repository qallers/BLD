<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Reports\MyReport;

class ReporttestController extends Controller {

    public function __contruct() {
        $this->middleware("guest");
    }

    public function index() {
        $report = new MyReport;
        $report->run();
        return view("report", ["report" => $report]);
    }

}
