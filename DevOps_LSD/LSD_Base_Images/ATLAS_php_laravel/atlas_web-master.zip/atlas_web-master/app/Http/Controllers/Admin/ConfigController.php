<?php

namespace App\Http\Controllers\Admin;
use App\Config;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\Admin\UpdateCustomerRequest;
use App\Http\Requests\Admin\StoreCustomerRequest;
use App\Status;

class ConfigController extends Controller
{
    public function index() {
        
        $config = Config::select("value","key")->get()->pluck('value','key');
        $sales_order=Status::where("process","sales_order")->get();
        return view('admin.config.index',compact('config','sales_order'));
    }

    public function upload(Request $request) {
        $old=Config::where('key','company_avatar')->firstOrFail();
    
        if(File::exists(storage_path('avatar/').$old->value)){
            File::delete(storage_path('avatar/').$old->value);
        }

        $fileName = Auth::user()->id.'_'.time().'.'.$request->file('company_avatar')->extension();  
        Config::where('key', '=', 'company_avatar')->update(['value' => $fileName]);
        $request->file('company_avatar')->move(storage_path('avatar'), $fileName);
        $path=url('avatar/'.$fileName);
        

        return response()->json([
            'initialPreview'=>array(
                '<img src='.$path.' class="file-preview-image kv-preview-data">'
            )
        ]);
    }

    public function update(Request $request) {
        foreach ($request->input() as $key => $value) {
            Config::updateOrCreate(['key'=>$key],['key'=> $key,'value' => $value]);
        }
        
        return response()->json([
            'status' => '200',
            'msg' => 'The configuration has been updated successfully.'
        ]);
    }
}