<?php

namespace App\Http\Controllers\Api;

use App\User;
use Exception;
use App\Config;
use App\Address;
use App\Country;
use App\Warehouse;
use App\SalesOrder;
use App\PurchaseOrder;
use App\ExternalSystem;
use Illuminate\Http\Request;
use App\ExternalSystemReference;
use Illuminate\Support\Facades\DB;
use SaintSystems\OData\ODataClient;
use App\Http\Controllers\Controller;
use PhpParser\Node\Expr\Cast\String_;
use SaintSystems\OData\GuzzleHttpProvider;
use App\Http\Controllers\Traits\NavisionHelperTraits;

class SystemController extends Controller
{
  use NavisionHelperTraits;
  /** 
   * @OA\Get(
   *      path="/api/v1/system/countries",
   *      operationId="getContries",
   *      tags={"System"},
   *      summary="Get Available Countries",
   *      description="Returns All Countries",
   *      @OA\Response(
   *          response=200,
   *          description="Successful operation",
   *       @OA\MediaType(
   *           mediaType="application/json",
   *          )
   *       ),
   *      @OA\Response(
   *          response=401,
   *          description="Unauthenticated",
   *      ),
   *      @OA\Response(
   *          response=403,
   *          description="Forbidden"
   *      ),
   *     )
   */
  public function countries()
  {
    $countries = Country::all();
    if ($countries->count() == 0)
    {
      return responder()->error(500, "no countries found for this account.")->respond(500);
    }
    else
    {
      return responder()->success($countries)->respond(200);
    }
  }

  /** 
   * @OA\Get(
   *      path="/api/v1/system/external_systems",
   *      operationId="getExternalSystems",
   *      tags={"System"},
   *      summary="Get Available External Systems",
   *      description="Returns All External Systems",
   *      @OA\Response(
   *          response=200,
   *          description="Successful operation",
   *       @OA\MediaType(
   *           mediaType="application/json",
   *          )
   *       ),
   *      @OA\Response(
   *          response=401,
   *          description="Unauthenticated",
   *      ),
   *      @OA\Response(
   *          response=403,
   *          description="Forbidden"
   *      ),
   *     )
   */
  public function external_systems()
  {
    $es = ExternalSystem::all();
    if ($es->count() == 0)
    {
      return responder()->error(500, "no external system found for this account.")->respond(500);
    }
    else
    {
      return responder()->success($es)->respond(200);
    }
  }

  public function nav(Request $request)
  {

    //  try {
    //    $resource="Item_Card";
    //    $node="voda_atlas";
    //    $config=$this->getConfig();
    //   $data=$this->nav_get_find($resource,$node);
    //   $eTag = 'W/"\'' . $data->ETag . '\'"';
    //   $odataClient = new ODataClient($config->nav_odata_url, function($request) use ($eTag){
    //       $request->headers['Accept'] = 'application/json';
    //       $request->headers['If-Match'] = $eTag;
    //     });
    //   $odataClient->getHttpProvider()->setExtraOptions(array('auth' => [$config->nav_username, $config->nav_password, 'ntlm']));

    //   // $res= $odataClient->patch($resource."('$node')",[
    //   //   "Description"=>"Updated DEscription new"
    //   // ]);
    //   // dump($res);
    //   dump($this->nav_get_find($resource,$node));

    //  } catch (\Throwable $th) {
    //   dump($th);
    //  }
    //dump($this->nav_get("Transfer_OrderTransferLines")->toArray());

    //   Retuen::fing(1)


    //   // $order = PurchaseOrder::find(2);
    // // $m = Config::where("key", "main_warehouse")->first();
    // // $warehouse = Warehouse::find($m->value);
    // // $order_nav = $this->nav_post("Transfer_Order", [
    // //   "Transfer_from_Code" => $warehouse->warehouse_code,
    // //   "Transfer_to_Code" => $order->warehouse->warehouse_code,
    // //   "In_Transit_Code"=>"IBT"
    // // ]);
    // // dump($order_nav);
    //  $order=$this->nav_post("Sales_Cr_MemoSalesLines", [
    //   "Sell_to_Customer_No" => $cust
    // ]);

    // //$order_nav[0]->No

    //  dd($this->nav_get("Sales_Cr_Memo")->toArray());
    // try {

    //   $order = SalesOrder::find(1);
    //   $order_nav = $this->nav_post("Sales_Order_Card", [
    //     "Document_Type" => "Order",
    //     "Sell_to_Customer_No" => $order->customer->cust_code,
    //     "Location_Code" => $order->warehouse->warehouse_code
    //   ]);
    //   //dd($order_nav);
    //   foreach ($order->salesOrderDetail as $value) {
    //     $order_nav_line = $this->nav_post("Sales_Order_CardSalesLines", [
    //       "Document_Type" => "Order",
    //       "Document_No" => $order_nav[0]->No,
    //       "Type" => "Item",
    //       "No" => $value->product->product_code,
    //       "Quantity" => (string)$value->qty
    //     ]);
    //   }
    // } catch (Exception $e) {
    // }

    // dd($this->nav_get_order_line("Transfer_Order","TFO00220000","10000")->toArray());
    // dump($this->nav_get("  ")->toArray());
    // dump($this->nav_get("Transfer_Order")->toArray());
    //     dd($this->nav_get_select("Item_Card","No")->toArray());
    //     $order=SalesOrder::find(1);
    //     $order_nav=$this->nav_post("Purchase_Order",[
    //       "Document_Type"=>"Order",
    //        "Sell_to_Customer_No"=>$order->customer->cust_code,
    //        "Location_Code"=>$order->warehouse->warehouse_code
    //   ]);
    // dump($order_nav);
    //   foreach ($order->salesOrderDetail as $value) {
    //       $order_nav_line=$this->nav_post("Sales_Order_CardSalesLines",[
    //         "Document_Type"=>"Order",
    //         "Document_No"=>$order_nav[0]->No,
    //         "Type"=>"Item",
    //         "No"=>$value->product->product_code,
    //         "Quantity"=>(String)$value->qty
    //         //"Sell_to_Customer_No"=>"WIC001-1636",
    //         // "Sell_to_Customer_Name"=>$order->customer->name,
    //         // "Salesperson_Code"=>$order->user->username,
    //         // "Location_Code"=>$order->warehouser_id,
    //         //"Bill_to_Customer_No"=>$order->customer_id,
    //     ]);
    //   }
    //   $order=SalesOrder::find(1);
    //   if($order->user->user_type_id==2){
    //     $order_nav=$this->nav_post("Sales_Invoice",[
    //       "Document_Type"=>"Invoice",
    //        "Sell_to_Customer_No"=>$order->customer->cust_code,
    //        "Location_Code"=>$order->warehouse->warehouse_code
    //   ]);
    //   dump($order_nav);
    //   foreach ($order->salesOrderDetail as $value) {
    //       $order_nav_line=$this->nav_post("Sales_InvoiceSalesLines",[
    //         "Document_Type"=>"Invoice",
    //         "Document_No"=>$order_nav[0]->No,
    //         "Type"=>"Item",
    //         "No"=>$value->product->product_code,
    //         "Quantity"=>(String)$value->qty
    //     ]);
    //   }
    // }

    //dump($this->nav_get("Sales_Invoice('".$order_nav[0]->No."')/Sales_InvoiceSalesLines"));
    // dump($this->nav_get_transfer_line("TFO00220000","10000"));
    //dump($this->nav_post("Assembly_Order",[
    //  "Code"=>"A123",
    //  "Name"=>"Test"
    //]));
    //dump($this->nav_get_transfer_line("TFO00220000","10000"));
    // $order_nav=$this->nav_post("Purchase_Order",[
    //   "Document_Type"=>"Order",
    //    "Buy_from_Vendor_No"=>$order->supplier->vendor_code,
    //    "Location_Code"=>$order->warehouse->warehouse_code
    // ]);


    // dump($this->nav_get_order_line("Purchase_OrderPurchLines","PO00220271","10000"));
    // dump($this->nav_patch_order("Purchase_OrderPurchLines","PO00220271","10000",[
    //     "Quantity"=>"600"
    // ]));
    // dump($this->nav_get_order_line("Purchase_OrderPurchLines","PO00220271","10000"));
    // $order_nav_line=$this->nav_post("Purchase_OrderPurchLines",[
    //     "Document_Type"=>"Order",
    //     "Document_No"=>$order_nav[0]->No,
    //     "Type"=>"Item",
    //     "No"=>$order->product->product_code,
    //     "Quantity"=>(String)$order->qty
    // ]);

    // $order->external_reference=$order_nav[0]->No;
    // $order->save();
    //dd($this->nav_get("Purchase_Order(Document_Type='Order',Line_No='1000')/Purchase_OrderPurchLines")->toArray());
    //        dd($order_nav,$order_nav_line);
    //dd($this->nav_get("Sales_Invoice('INXX220032')/Microsoft.NAV.Post"));
    //dd($this->nav_get_find("Sales_Order_Card","IO00220303"));
    //  dump($this->nav_patch_order("Purchase_OrderPurchLines","PO00220271","10000",[
    //       "Quantity"=>"524",
    //       "Qty_to_Receive"=>"524",
    //       "Qty_to_Invoice"=>"0",
    //       "Direct_Unit_Cost"=>"4.0"
    //    ]));
    // dump($this->nav_get_order_line("Purchase_OrderPurchLines","PO00220271","10000"));
    //dd($this->nav_get_order_line("Purchase_OrderPurchLines","PO00220271","10000"));
    // dd($collection->Code);
    //dd($collection->toArray());


  }

  //encrypt external system
  public function ees()
  {
    ini_set('max_execution_time', 3000);
    $ricaId = ExternalSystem::whereDescription('RICA')->first();
    $getData = ExternalSystemReference::whereExternalSystemId($ricaId->id)->get();

    foreach ($getData as $v)
    {
      $obj = json_decode($v->data);

      $obj->rica_password = encrypt($obj->rica_password);
      $v->data = json_encode($obj);
      $v->save();
    }
  }

  //hash user passwords
  public function hup()
  {
    ini_set('max_execution_time', 3000);
    $users = User::whereNotNull('kms_password')->get();

    foreach ($users as $v)
    {
      $v->password = bcrypt($v->kms_password);
      $v->save();
    }
  }
}
