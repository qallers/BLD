<?php

namespace App\Http\Controllers\Api;

use App\Customer;
use App\Http\Controllers\Controller;
use App\Notifications\NewUserCreated;
use App\PurchaseOrder;
use App\RepTransferDetails;
use App\Stock;
use App\User;
use App\UserType;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use MarcinOrlowski\ResponseBuilder\ResponseBuilder;
use MarcinOrlowski\ResponseBuilder\ResponseBuilderBase;

class UserController extends Controller
{
    /**
     * @OA\Post(
     ** path="/api/v1/user/register",
     *   tags={"User"},
     *   summary="register new user",
     *   operationId="userRegister",
     * security={
     *  {"passport": {}},
     *   },
     *   @OA\Parameter(
     *      name="user_type_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="first_name",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="last_name",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="username",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="email",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     * 
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     */
    public function store(Request $request)
    {
        if (!Gate::allows('add_user')) {
            return abort(401);
        }
        $validator = Validator::make($request->all(), [
            'username' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email|unique:users,email',
            'user_type_id' => 'required',
        ]);

        if ($validator->fails()) {
            return responder()->error(400, "vaidation_error")->data(['data' => $validator->errors()])->respond(400);
        }

        $passwrod = Str::random(8);
        $request->request->add(['password' => Hash::make($passwrod), "is_active" => 1]);
        $request->request->add(['email' => filter_var($request->input('email'), FILTER_SANITIZE_STRING)]);

        $user = User::create($request->all());
        $user->notify(new NewUserCreated([
            'password' => $passwrod,
            'username' => $user->username
        ]));
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/user/profile",
     *      operationId="getProfile",
     *      tags={"User"},
     *      summary="Get user profile",
     *      description="Returns user proile",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function profile(Request $request)
    {
        return responder()->success(Auth::user()->load('customer','customer.addresses','customer.contacts'))->respond();
    }


    /** 
     * @OA\Get(
     *      path="/api/v1/user/types",
     *      operationId="getTypes",
     *      tags={"User"},
     *      summary="Get user types",
     *      description="Returns user types",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function types(Request $request)
    {
        return responder()->success(UserType::all())->respond();
    }
    /** 
     * @OA\Get(
     *      path="/api/v1/user/customers",
     *      operationId="getUserCustomers",
     *      tags={"User"},
     *      summary="Get user's customers",
     *      description="Returns user's customers'",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function customers(Request $request)
    {
        $customers = Customer::whereRepUserId(Auth::user()->id)
                                ->whereIsActive(1)->get();
        if ($customers->count() == 0) {
            return responder()->error(500, "no customer found for this account.")->respond(500);
        } else {
            return responder()->success($customers)->respond(200);
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/rep/mystock",
     *      operationId="getRepStock",
     *      tags={"Rep"},
     *      summary="Get Rep's Stock",
     *      description="Returns Rep's Stocks'",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */
    public function mystock(Request $request)
    {
        if (Auth::user()->user_type_id == 4) {
            $customer = Customer::whereUserId(Auth::user()->id)->first();
            $stocks = Stock::with("product:id,description,product_code", "network:id,name")->whereCustomerId($customer->id)
                ->select(["stock.product_id", "stock.box_id", "stock.network_id", DB::raw('COUNT(product_id) as available_stock')])
                ->groupBy("product_id")
                ->get();
        } else {
            $stocks = Stock::with("product:id,description,product_code", "network:id,name")->whereWarehouseId(Auth::user()->warehouse_id)
                ->select(["stock.product_id", "stock.box_id", "stock.network_id", DB::raw('COUNT(product_id) as available_stock')])
                ->whereNull("sales_order_detail_id")
                ->groupBy("product_id")
                ->get();
        }
        if ($stocks->count() == 0) {
            return responder()->error(500, "No stock found for this account.")->respond(500);
        } else {
            return responder()->success($stocks)->respond(200);
        }
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/rep/transfer/list",
     *      operationId="listReptransfer",
     *      tags={"Rep"},
     *      summary="List transfer order for rep",
     *      description="Returns order information",
     * security={
     *  {"passport": {}},
     *   },
     *      @OA\Response(
     *          response=200,
     *          description="Successful operation",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=401,
     *          description="Unauthenticated",
     *      ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      ),
     *     )
     */

    public function listdata_rep(Request $request)
    {
        return responder()->success(RepTransferDetails::with('product:id,product_code,description,network_id', 'product.network')
            ->join("rep_transfer", "rep_transfer.id", "=", "rep_transfer_detail.rep_transfer_id")
            ->select("rep_transfer_detail.*")
            ->where("rep_transfer_detail.is_verify","=",0)
            ->where("rep_transfer_detail.is_allocate","=",1)
            ->where("rep_transfer_detail.is_dispatch","=",1)
            ->where("rep_transfer.warehouse_id", "=", Auth::user()->warehouse_id))->respond(200);
    }
}
