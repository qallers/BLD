<?php

namespace App\Http\Controllers\Admin;

use App\Fileconfig;
use App\Filetype;
use App\Network;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Requests\Admin\UpdateFiletypeRequest;
use App\Http\Requests\Admin\StorefiletypeRequest;
use RealRashid\SweetAlert\Facades\Alert;
use Session;

class FileTypeController extends Controller {

    public function index() {

        $fileconfig = Fileconfig::all();

        return view('admin.filetype.index', compact('fileconfig'));
    }

    public function edit(Filetype $filetype) {
        return view('admin.filetype.editFiletype', compact('filetype'));
    }

    public function create() {
        return view('admin.filetype.createFiletype');
    }

    public function update(UpdateFiletypeRequest $request, Filetype $filetype) {

        $filetype->update($request->all());
        Alert::success('Success', 'The file type has been updated.');
        return redirect()->route('admin.fileconfig.index');
    }

    public function show(filetype $filetype) {
      

        return view('admin.filetype.show', compact('filetype'));
    }

    public function massDestroy(Request $request) {

        User::whereIn('id', request('ids'))->delete();

        return response()->noContent();
    }

    public function store(UpdateFiletypeRequest $request) {
        Filetype::create($request->all());
        Alert::success('Success', 'The file type has been created.');
        return redirect()->route('admin.fileconfig.index');
    }

    public function destroy(Filetype $filetype) {


        $filetype->delete();

        return redirect()->route('admin.fileconfig.index');
    }

}
