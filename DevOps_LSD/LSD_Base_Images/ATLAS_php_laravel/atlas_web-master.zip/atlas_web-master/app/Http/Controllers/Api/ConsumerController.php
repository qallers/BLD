<?php

namespace App\Http\Controllers\Api;

use App\Customer;
use App\Http\Controllers\Controller;
use App\Notifications\NewUserCreated;
use App\User;
use App\UserType;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use MarcinOrlowski\ResponseBuilder\ResponseBuilder;
use MarcinOrlowski\ResponseBuilder\ResponseBuilderBase;

class ConsumerController extends Controller {
  /**
     * @OA\Post(
     ** path="/api/v1/consumer/register",
     *   tags={"Consumers"},
     *   summary="register new consumer",
     *   operationId="consumerRegister",
     *   @OA\Parameter(
     *      name="username",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="password",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="email",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="first_name",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="last_name",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="name",
     *      in="query",
     *      description="This is business name",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="identity_type_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="identity_reference",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="identity_reference_expiry_date",
     *      in="query",
     *      required=false,
     *      description="yyyy-mm-dd",
     *      @OA\Schema(
     *          type="string",
     *          format="date"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="identity_reference_origin_country",
     *      in="query",
     *      required=false,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="payment_method_id",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     * 
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     */
    public function register(Request $request) {
        $request->request->add(['cust_code' => $request->username]);
        $validator = Validator::make($request->all(),[
            'username' => 'required|unique:users',
            'password' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email|unique:users,email',
            'identity_type_id'=>'required',
            'payment_method_id' => 'required',
            'identity_reference'=>'required',
            'name'=>'required',
            'cust_code' => 'required|unique:customer,cust_code'
        ],[
            'cust_code'=> "This username has been already used as cust code."
        ]);

        if ($validator->fails()) {
            return responder()->error(400,"vaidation_error")->data(['data'=>$validator->errors()])->respond(400);
        }
        $request->request->add(["user_type_id"=>3]);
        $request->request->add(['password' => Hash::make($request->password)]);
        $request->request->add(['email' => filter_var($request->input('email'), FILTER_SANITIZE_STRING)]);

        $user = User::create($request->all());
        $customer=[
            "cust_code"=>$request->username,
            "name"=>$request->name,
            "group_id"=>1,
            "identity_type_id"=>$request->identity_type_id,
            "payment_method_id"=>$request->payment_method_id,
            "identity_reference"=>$request->identity_reference,
            "vat_registered"=>0,
            "is_active"=>0,
            "user_id"=>$user->id,
            "rep_user_id"=>-1,
        ];
        if($request->filled("identity_reference_expiry_date")){
            $customer["identity_reference_expiry_date"]=$request->identity_reference_expiry_date;
        }
        if($request->filled("identity_reference_origin_country")){
            $customer["identity_reference_origin_country"]=$request->identity_reference_origin_country;
        }
        $cus=Customer::create($customer);
        $user->notify(new NewUserCreated([
            'password' => $request->password,
            'username' => $user->username
        ]));
        if(!$cus->id){
            responder()->error(500,"Consumer not created. Please contact admin.")->respond(500);
        }else{
            return responder()->success($cus)->respond(200);
        }
    }
    

}
