<?php

namespace App\Http\Controllers\Admin;
use App\Group;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreGroupRequest;
use App\Http\Requests\Admin\UpdateGroupRequest;
use RealRashid\SweetAlert\Facades\Alert;

use DB;

class GroupController extends Controller {

    public function index() {
        if (!Gate::allows('view_group')) {
            return abort(401);
        }

        $group = Group::all();

        return view('admin.group.index', compact('group'));
    }


  /**
     * Show the form for creating new group.
     *
     * @return \Illuminate\Http\Response
     */
    public function list(Request $request) {

        $data = Group::select('id','code','description', 'is_active', 'created_at', 'updated_at');

        if (!empty($request->is_active)) {
            $data->whereIsActive($request->is_active);
        } else {
            $data->whereIsActive(0);
        }
        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }
        return datatables()->of($data)
                        ->make();
    }

    public function create()
    {
        if (! Gate::allows('add_group')) {
            return abort(401);
        }
        $group = Group::all();
        return view('admin.group.create', compact('group'));
    }

     /**
     * Store a newly created product in storage.
     *
     * @param  \App\Http\Requests\StoregroupRequest  $request
     * @return \Illuminate\Http\Response
     */

    public function change_status(Request $request) {
        $id = $request->input('id');
        $type = $request->input('type');
        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }
        Group::where('id', $id)->update(['is_active' => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The Group has been $msg successfully."
        ]);
    }

    public function store(StoreGroupRequest $request)
    {
        if (! Gate::allows('add_group')) {
            return abort(401);
        }
        group::create($request->all());
        Alert::success('Success', "The Group has been created.");
        return redirect()->route('admin.group.index');
    }
 
    public function show(Group $group) {
        if (!Gate::allows('view_group')) {
            return abort(401);
        }

       
        $allGroups = Group::where('id','!=',$group->id)->first();
        return view('admin.group.show', compact('group','allGroups'));
    }

 /* update group */
    public function edit(Group $group) {
        if (!Gate::allows('edit_group')) {
            return abort(401);
        }
 
        $allGroups = Group::where('id','!=',$group->id)->get();

        return view('admin.group.edit', compact('group','allGroups'));
  
    }

    public function update(UpdateGroupRequest $request, group $group) {

        if (!Gate::allows('edit_group')) {

            return abort(401);
        }


        $group->update($request->all());
        Alert::success('Success', "The Group has been updated.");
        return redirect()->route('admin.group.index');
    }
}
