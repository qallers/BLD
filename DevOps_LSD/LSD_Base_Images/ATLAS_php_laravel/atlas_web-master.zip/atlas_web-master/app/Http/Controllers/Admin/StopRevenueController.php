<?php

namespace App\Http\Controllers\Admin;

use App\Network;
use App\Customer;
use App\StopRevenue;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Session;
use RealRashid\SweetAlert\Facades\Alert;
use App\Http\Requests\Admin\StoreStopRevenueRequest;
use App\Http\Requests\Admin\UpdateStopRevenueRequest;

class StopRevenueController extends Controller {

    public function index() {
        if (!Gate::allows('view_stop_revenue')) {
            return abort(401);
        }

        return view('admin.stop_revenue.index');
        }

        public function list(Request $request) {

        $data = StopRevenue::with("customer");


        if ($request->filled("start_date")) {
            $data->whereBetween('created_at', [$request->start_date, $request->end_date]);
        }
        return datatables()->of($data)
                        ->make();
    }

    public function create() {

        $customer = \App\Customer::whereIsActive(1)->get();

        return view('admin.stop_revenue.create', compact('customer'));
    }
    
    public function store(StoreStopRevenueRequest $request) {

        $stop_revenue = !empty($request->input('stop_revenue')) ? 1 : 0;
        $stop_rebate = !empty($request->input('stop_rebate')) ? 1 : 0;
        $stop_simswap = !empty($request->input('stop_simswap')) ? 1 : 0;
        $data = array_merge($request->all(), ['stop_revenue' => $stop_revenue]);
        $data = array_merge($data, ['stop_rebate' => $stop_rebate]);
        $data = array_merge($data, ['stop_simswap' => $stop_simswap]);

        $isavailable = StopRevenue::with('customer')->where("customer_id", $request->input('customer_id'))->where(function ($query) use ($data) {
                    $query->whereBetween('from_date', [$data['from_date'], $data['to_date']])->orWhereBetween('to_date', [$data['from_date'], $data['to_date']]);
                })->first();
        if (!empty($isavailable->customer_id)) {
            Alert::error('Error', "The stop revenue has already been created for this time periods");
            return redirect()->route('admin.stop_revenue.create');
        }

        StopRevenue::create($data);
        Alert::success('Success', "Stop revenue has been created.");
        return redirect()->route('admin.stop_revenue.index');
    }

    public function change_status(Request $request) {

        $id = $request->input('id');
        $type = $request->input('type');
        $option = $request->input('option');

        if ($type == 'active') {
            $is_active = 1;
            $msg = 'activated';
        } else {
            $msg = 'deactivated';
            $is_active = 0;
        }

        StopRevenue::where('customer_id', $id)->update([$option => $is_active]);
        return response()->json([
                    'status' => "200",
                    'msg' => "The " . str_replace('_', ' ', $option) . " has been $msg"
        ]);
    }

    public function show($id) {
        $stoprevenue = StopRevenue::with('customer')->where('customer_id', $id)->get()->first();
        return view('admin.stop_revenue.show', compact('stoprevenue'));
    }

    public function edit($id) {
        $stoprevenue = StopRevenue::where('customer_id', $id)->get()->first();
        $customer = Customer::whereIsActive(1)->get();
        return view('admin.stop_revenue.edit', compact('stoprevenue', 'customer'));
    }

    public function update(UpdateStopRevenueRequest $request) {
        $data = array();
        $data['from_date'] = $request->input('from_date');
        $data['to_date'] = $request->input('to_date');
        $stop_revenue = !empty($request->input('stop_revenue')) ? 1 : 0;
        $stop_rebate = !empty($request->input('stop_rebate')) ? 1 : 0;
        $stop_simswap = !empty($request->input('stop_simswap')) ? 1 : 0;
        $data = array_merge($data, ['stop_revenue' => $stop_revenue]);
        $data = array_merge($data, ['stop_rebate' => $stop_rebate]);
        $data = array_merge($data, ['stop_simswap' => $stop_simswap]);


        StopRevenue::where('customer_id', $request->input('id'))
                ->update($data);

        Alert::success('Success', "Stop revenue has been updated.");
        return redirect()->route('admin.stop_revenue.index');
    }

    public function massDestroy(Request $request) {
        if (!Gate::allows('set_network_status')) {
            return abort(401);
        }
        Network::whereIn('id', request('ids'))->delete();

        return response()->noContent();
    }
}
