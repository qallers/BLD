<?php

namespace App\Http\Controllers\Admin;

use Flash;
use App\User;
use Response;
use stdClass;
use App\Stock;
use Exception;
use App\Config;
use App\Status;
use DataTables;
use App\Product;
use App\Contract;
use App\Customer;
use App\UserType;
use App\BulkOrder;
use App\SalesDeal;
use App\SplitDeal;
use App\TierStage;
use App\Warehouse;
use Carbon\Carbon;
use App\SalesOrder;
use App\BaseSummary;
use App\ProductDeal;
use App\StagesRoles;
use App\StockLedger;
use App\Notification;
use App\SalesInvoice;
use App\CustomerSplit;
use App\ApprovalStages;
use App\BulkOrderDetails;
use App\SalesOrderDetails;
use Illuminate\Support\Arr;
use App\Imports\OrderImport;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Spatie\Activitylog\Models\Activity;
use App\Notifications\SalesOrderCreated;
use RealRashid\SweetAlert\Facades\Alert;
use App\Notifications\SalesOrderApproval;
use App\Notifications\SalesOrderApproved;
use App\Notifications\SalesOrderRejected;
use App\Http\Controllers\Traits\PDFExportTrait;
use App\Http\Controllers\Traits\SalesOrderTrait;
use App\Notifications\ChangeOrderDealNotification;
use App\Http\Controllers\Traits\NotificationTraits;
use App\Notifications\SalesOrderDeleted;
use Maatwebsite\Excel\Facades\Excel as FacadesExcel;
use Illuminate\Support\Facades\Config as FacadesConfig;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Validator;

class SalesOrderController extends Controller
{
    
    use NotificationTraits;
    use SalesOrderTrait;

    public function reject($id)
    {
        $order = SalesOrder::with("status")->where("id", $id)->get()->first();
        $soaa = Config::where("key", "sales_order_apply_approval")->first();
        if ($order->status->id != $soaa->value)
        {
            Alert::error('Error!', 'You cannot reject an approved order');
        }
        else
        {
            $status = Status::where('process', 'sales_order')->where('status', 'rejected')->get()->first();
            SalesOrder::where('id', $id)
                ->update(['status_id' => $status->id]);
            $this->generatePDFSales($order);
            if (!empty($order->user_id))
            {
                $u = User::find($order->user_id);
                $u->notify(new SalesOrderRejected($order));
            }
            Alert::success('Success', 'Order has been rejected.');
        }
        return back();
    }

    public function remove(Request $request)
    {
        if (Gate::allows('delete_sales_order')) {
            $order = SalesOrder::with("status")->where("id", $request->id)->get()->first();
            if ($order->status->status == "approval") {
                return response()->json([
                    "status" => 500,
                    "message" => "You can not delete an order which is in approval. Try Rejecting order."
                ]);
            } else {
                $status = Status::where('process', 'order')->where('status', 'deleted')->get()->first();
                if ($order->is_bulk && $order->parent_id == -1) {
                    $allocated = Status::where('process', 'sales_order')->where('status', 'allocated')->get()->first();
                    SalesOrder::whereParentId($request->id)
                        ->where("status_id", "<>", $allocated->id)
                        ->update(['status_id' => $status->id]);
                }
                SalesOrder::where('id', $request->id)
                    ->update(['status_id' => $status->id]);
                $this->generatePDFSales($order);
                if (!empty($order->user_id)) {
                    $u = User::find($order->user_id);
                    $u->notify(new SalesOrderDeleted($order));
                }
                return response()->json([
                    "status" => 200,
                    "message" => "Order has been deleted."
                ]);
            }
        }
        return response()->json([
            "status" => 403,
            "message" => "You are not authorized to do this action."
        ]);
    }

    public function approve_all(Request $request)
    {
        $count = 0;
        foreach (explode(",", $request->id) as $key => $value)
        {
            if ($this->approveOrder($value))
            {
                $order = SalesOrder::find($value)->load("customer");

                $u = User::find($order->user_id);
                $u->notify(new SalesOrderApproved($order));

                $sl = array();
                $sl['user_id'] = Auth::user()->id;
                $sl['order_id'] = $order->id;
                $sl['status_id'] = $order->status_id;
                $sl['qty'] = 0;
                $sl['order_name'] = "SALES";
                $sl['process_name'] = "approve_order";
                StockLedger::create($sl);
                $count++;
            }
        }
        return response()->json([
            "message" => "Total $count orders approved successfully."
        ]);
    }

    public function export_mobile_invoice(Request $request)
    {
       
        $start_date=date('Y-m-d', strtotime($request->input("start_date")));
        $end_date  =date('Y-m-d', strtotime($request->input("end_date"))); 

        $data = DB::select(
            "SELECT t3.cust_code AS 'cust_code'
                ,t1.created_at AS 'created_at'
                ,t1.id AS 'order_id'
                ,t3.vat_registered AS 'vat_registered'
                ,delivery_method.name AS 'delivery_method'
                ,IFNULL(t5.address_line_1, '') AS 'address_line_1'
                ,IFNULL(t5.address_line_2, '') AS 'address_line_2'
                ,IFNULL(t5.city, '') AS 'city'
                ,IFNULL(t5.province, '') AS 'province'
                ,IFNULL(t5.postal_code, '') AS 'postal_code'
                ,IFNULL(t6.tel_no, '') AS 'tel_no'
                ,IFNULL(t6.cell_no, '') AS 'cell_no'
                ,IFNULL(t6.name, '') AS 'name'
                ,t4.username AS 'rep_code'
                ,t2.qty AS 'qty'
                ,ROUND(t2.sales_price/(1+t10.vat), 4) AS 'excl_price'
                ,t2.sales_price AS 'incl_price'
                ,t7.product_code AS 'product_code'
                ,LEFT(t7.description, 19) AS 'product_desc'
                ,t8.code AS 'group_code'
                ,t9.warehouse_code AS 'warehouse_code'
                ,t3.name AS 'customer'
                ,t4.username AS 'sales_rep'
                ,t2.invoice_number AS 'invoice_no'
                ,t1.created_at AS 'invoice_date'
                ,t7.product_code AS 'product'
                ,t2.sales_price AS 'sales_price'
                ,t9.warehouse_code AS 'warehouse_code'
                FROM sales_order t1
                LEFT JOIN sales_order_detail t2 ON t2.sales_order_id = t1.id
                LEFT JOIN customer t3 ON t3.id = t1.customer_id
                LEFT JOIN users t4 ON t4.id = t3.rep_user_id
                LEFT JOIN (
                    SELECT MIN(id) AS 'id'
                        ,customer_id
                    FROM `address`
                    GROUP BY customer_id
                    ) addr ON addr.customer_id = t3.id
                LEFT JOIN `address` t5 ON t5.customer_id = t3.id
                    AND t5.id = addr.id
                LEFT JOIN (
                    SELECT MIN(id) AS 'id'
                        ,customer_id
                    FROM contact
                    GROUP BY customer_id
                    ) cont ON cont.customer_id = t3.id
                LEFT JOIN contact t6 ON t6.customer_id = t3.id
                    AND t6.id = cont.id
                LEFT JOIN product t7 ON t7.id = t2.product_id
                LEFT JOIN `group` t8 ON t8.id = t3.group_id
                LEFT JOIN warehouse t9 ON t9.id = t4.warehouse_id
                LEFT JOIN vat_config t10 ON t1.created_at BETWEEN t10.start_date AND t10.end_date
                LEFT JOIN (
                    SELECT id
                    ,`name`
                    FROM `status`
                    WHERE `process` = 'delivery_mode'
                ) delivery_method ON delivery_method.id = t1.delivery_method_id
                WHERE t1.approval_id = (
                    SELECT id
                        FROM approvals
                        WHERE `process` = 'mobile_invoice'
                        LIMIT 1)
                AND    t1.created_at >= '$start_date  00:00:00' AND  t1.created_at<= '$end_date 23:59:59' 
                GROUP BY t1.id
                ,t2.id
            ORDER BY t1.id ,t2.id"
        );

        $fileData = '';
        $order_id="";

        foreach ($data as $v) {

            if( $order_id <> $v->order_id )
            {
           
                $order_id=$v->order_id;

                $header = array();
                $header[] = 'HEADER';
                $header[] = 'IN000001';
                $header[] = '';
                $header[] = '';
                $header[] = !empty($v->cust_code) ? $v->cust_code : '';
                $header[] = !empty($v->process_month) ? $this->get_fin_period($v->process_month) : '';
                $header[] = !empty($v->created_at) ? date('d/m/Y', strtotime($v->created_at)) : '';
                $header[] = !empty($v->order_id) ? $v->order_id : '';
                $header[] = 'Y';
                $header[] = '0';
                $header[] = '';
                $header[] = '';
                $header[] = '';
                $header[] = !empty($v->address_line_1) ? $v->address_line_1 : '';
                $header[] = !empty($v->address_line_2) ? $v->address_line_2 : '';
                $header[] = !empty($v->city) ? $v->city : '';
                $header[] = !empty($v->province) ? $v->province : '';
                $header[] = !empty($v->postal_code) ? $v->postal_code : '';
                $header[] = !empty($v->rep_code) ? $v->rep_code : '';
                $header[] = '0';
                $header[] = !empty($v->created_at) ? date('d/m/Y', strtotime($v->created_at)) : '';
                $header[] = !empty($v->tel_no) ? $v->tel_no : '';
                $header[] = !empty($v->cell_no) ? $v->cell_no : '';
                $header[] = !empty($v->name) ? $v->name : '';
                $header[] = '1';
                $header[] = '';
                $header[] = !empty($v->delivery_method) ? $v->delivery_method : '';
                $header[] = '';
                $header[] = '';

                $fileData .= implode(',', $header) . PHP_RN;
           }

            $detail = array();
            $detail[] = 'DETAIL';
            $detail[] = '0';
            $detail[] = !empty($v->qty) ? $v->qty : 0;
            $detail[] = !empty($v->excl_price) ? $v->excl_price : 0;
            $detail[] = !empty($v->incl_price) ? $v->incl_price : 0;
            $detail[] = 'EA';
            $detail[] = '01';
            $detail[] = '3';
            $detail[] = '0';
            $detail[] = !empty($v->product_code) ? $v->product_code : '';
            $detail[] = !empty($v->product_desc) ? $v->product_desc : '';
            $detail[] = '4';
            $detail[] = !empty($v->group_code) ? $v->group_code : '';
            $detail[] = !empty($v->warehouse_code) ? $v->warehouse_code : '';

            $fileData .= implode(',', $detail) . PHP_RN;
        }

        $fileName = 'salesrepinvoice_' . date('YmdHis') . '.csv';

        Storage::disk('local')->put('mobile_invoice/' . $fileName, $fileData);
        return Storage::download('mobile_invoice/' . $fileName);
    }

    public function mobile_invoice()
    {
        $customers = Customer::all();

        return view('order.sales.mobile_invoice', compact('customers'));
    }

    public function list_data_mobile(Request $request)
    {

        $start_date = date('Y-m-d', strtotime($request->input("start_date")));
        $end_date  = date('Y-m-d', strtotime($request->input("end_date")));



        if (empty($request->input("end_date"))) {
            $end_date=date("Y-m-d");
           }

      if (empty($request->input("start_date"))) {
              $start_date=date("Y-m-d", strtotime("-1 months", strtotime(date("Y-m-d"))));
         }
 
        $query = "SELECT
        t3.cust_code AS 'cust_code'
        ,t1.created_at AS 'created_at'
        ,t1.id AS 'order_id'
        ,t3.vat_registered AS 'vat_registered'
        ,delivery_method.name AS 'delivery_method'
        ,IFNULL(t5.address_line_1, '') AS 'address_line_1'
        ,IFNULL(t5.address_line_2, '') AS 'address_line_2'
        ,IFNULL(t5.city, '') AS 'city'
        ,IFNULL(t5.province, '') AS 'province'
        ,IFNULL(t5.postal_code, '') AS 'postal_code'
        ,IFNULL(t6.tel_no, '') AS 'tel_no'
        ,IFNULL(t6.cell_no, '') AS 'cell_no'
        ,IFNULL(t6.name, '') AS 'name'
        ,t4.username AS 'rep_code'
        ,t2.qty AS 'qty'
        ,COUNT(t13.serial_no) AS 'allocated_qty'
        ,ROUND(t2.sales_price/(1+t10.vat), 4) AS 'excl_price'
        ,t2.sales_price AS 'incl_price'
        ,t7.product_code AS 'product_code'
        ,LEFT(t7.description, 19) AS 'product_desc'
        ,t8.code AS 'group_code'
        ,t9.warehouse_code AS 'warehouse_code'
        ,t3.name AS 'customer'
        ,t4.username AS 'sales_rep'
        ,t2.invoice_number AS 'invoice_no'
        ,t1.created_at AS 'invoice_date'
        ,t7.product_code AS 'product'
        ,t11.act AS 'ori_act'
        ,
        CASE
          WHEN t11.id <> t12.id
          THEN t12.act
          ELSE NULL
        END AS 'cur_act'
        ,t11.ogr AS 'ori_ogr'
        ,
        CASE
          WHEN t11.id <> t12.id
          THEN t12.ogr
          ELSE NULL
        END AS 'cur_ogr'
      FROM
        sales_order t1
        LEFT JOIN sales_order_detail t2
          ON t2.sales_order_id = t1.id
        LEFT JOIN customer t3
          ON t3.id = t1.customer_id
        LEFT JOIN users t4
          ON t4.id = t3.rep_user_id
        LEFT JOIN
          (SELECT
            MIN(id) AS 'id'
                ,customer_id
          FROM
            `address`
          GROUP BY customer_id) addr
          ON addr.customer_id = t3.id
        LEFT JOIN `address` t5
          ON t5.customer_id = t3.id
            AND t5.id = addr.id
        LEFT JOIN
          (SELECT
            MIN(id) AS 'id'
                ,customer_id
          FROM
            contact
          GROUP BY customer_id) cont
          ON cont.customer_id = t3.id
        LEFT JOIN contact t6
          ON t6.customer_id = t3.id
            AND t6.id = cont.id
        LEFT JOIN product t7
          ON t7.id = t2.product_id
        LEFT JOIN `group` t8
          ON t8.id = t3.group_id
        LEFT JOIN warehouse t9
          ON t9.id = t4.warehouse_id
        LEFT JOIN vat_config t10
          ON t1.created_at BETWEEN t10.start_date
          AND t10.end_date
        LEFT JOIN
          (SELECT
            MIN(id) AS 'id'
                ,sales_order_detail_id
                ,customer_id
          FROM
            sales_deal
                GROUP BY sales_order_detail_id
            , customer_id) original_deal
          ON original_deal.sales_order_detail_id = t2.id
        LEFT JOIN sales_deal t11
          ON t11.id = original_deal.id
        LEFT JOIN
          (SELECT
            MAX(id) AS 'id'
                ,sales_order_detail_id
                ,customer_id
          FROM
            sales_deal
                GROUP BY sales_order_detail_id
            , customer_id) updated_deal
          ON updated_deal.sales_order_detail_id = t2.id
        LEFT JOIN sales_deal t12
          ON t12.id = updated_deal.id
        LEFT JOIN
          (SELECT
            id
            ,`name`
          FROM
            `status`
          WHERE `process` = 'delivery_mode') delivery_method
          ON delivery_method.id = t1.delivery_method_id
        LEFT JOIN stock t13
          ON t13.sales_order_detail_id = t2.id
      WHERE t1.approval_id =
        (SELECT
          id
        FROM
          approvals
        WHERE `process` = 'mobile_invoice'
        AND t1.created_at >= '$start_date  00:00:00' AND  t1.created_at<= '$end_date 23:59:59'
        LIMIT 1) GROUP BY t1.id, t2.id ORDER BY t11.act <> t12.act DESC ,t11.ogr <> t12.ogr DESC";
  
        $data = DB::select($query);

        return datatables()->of($data)
            ->make();
    }
    public function approve($id)
    {
        /** @var Admin/audits $admin/audits */
        if ($this->approveOrder($id))
        {
            $order = SalesOrder::find($id)->load("customer");
            $this->generatePDFSales($order);

            $u = User::find($order->user_id);
            $u->notify(new SalesOrderApproved($order));

            $sl = array();
            $sl['user_id'] = Auth::user()->id;
            $sl['order_id'] = $order->id;
            $sl['status_id'] = $order->status_id;
            $sl['qty'] = 0;

            $sl['order_name'] = "SALES";
            $sl['process_name'] = "approve_order";

            StockLedger::create($sl);

            Alert::success('Success', 'The order has been approved.');
        }
        else
        {
            Alert::success('Error', 'There is a problem with the approval of the order.');
        }
        return back();
    }

    public function edit($id)
    {
        $payment = Status::where('process', 'payment_status')->get();
        $delivery = Status::where('process', 'delivery_mode')->get();
        $order = SalesOrder::find($id);
        if($order->is_bulk && $order->parent_id==-1){
            Alert::error("You cannot edit an parent order. Please edit individual order.");
            return redirect("order/sales/".$order->id);
        }
        if ($order->status->status == 'approved' || $order->status->status == 'dispatched' || $order->status->status == 'allocated' || $order->status->status == 'invoiced' || $order->status->status == 'rejected') {
            Alert::error("You cannot edit an order after it has been approved or rejected");
            return redirect("order/sales/");
        }
        $order_details = SalesOrderDetails::where('sales_order_id', $id)->get();
        $deal = [];
        foreach ($order_details as $key => $od)
        {
            $data = new stdClass();
            $data->customer_id = $order->customer_id;
            $data->product_id = $od->product_id;
            $data->product_deal = $od->product_deal_id;
            $data->split_deal_id = $od->split_deal_id;
            $data->qty = $od->qty;
            $data->sales_price = $od->sales_price;
            $data->type = "none";
            $data->order_detail_id = $od->id;
            $data->sales_order_id = $od->sales_order_id;
            $deal[] = array_merge($this->get_product_entry($data), array("data" => $data, "type" => "edit", 'isReporting' => 0));
        }
        if (Auth::user()->user_type_id == 2)
        {
            $customer = Customer::whereRepUserId(Auth::user()->user_type_id)
                ->whereIsActive(1)->get();
        }
        else
        {
            $customer = Customer::whereIsActive(1)->get();
        }
        $product = Product::all();
        $warehouse = Warehouse::all();
        return view('order.sales.edit', compact('customer', 'warehouse', 'product', 'payment', 'delivery', 'order', 'order_details', 'deal'));
    }

    public function list(Request $request)
    {
        if (!empty($request->input('cid')))
        {
            $ids = [$request->input("cid")];
            $order = $this->getMyOrderAll()["orders"]->with('paymentStatus', 'customer', 'status', 'deliveryMode', 'user', 'approvals')->whereIn('customer_id', $ids)->whereParentId(-1);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
        }
    }
        else if (!empty($request->input('ps')))
        {
            $ids = [$request->input("ps")];
            $order = $this->getMyOrderAll()["orders"]->with('paymentStatus', 'customer', 'status', 'deliveryMode', 'user', 'approvals')->whereIn('customer_id', $ids)->whereParentId(-1);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
        }
    }
        else
        {
            $order = $this->getMyOrderAll()["orders"]->with('paymentStatus', 'customer', 'deliveryMode', 'user', 'status', 'approvals');
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        }

        return datatables()->of($order)
            ->make();
    }



    public function list_approve(Request $request)
    {
        if (!empty($request->input('cid')))
        {
            $ids = [$request->input("cid")];
            $order = $this->getMyOrder()["orders"]->with('paymentStatus', 'status', 'customer', 'deliveryMode', 'user', 'approvals')->whereIn('customer_id', $ids);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        }
        else if (!empty($request->input('ps')))
        {
            $ids = [$request->input("ps")];
            $order = $this->getMyOrder()["orders"]->with('paymentStatus', 'status', 'customer', 'deliveryMode', 'user', 'approvals')->whereIn('customer_id', $ids);
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        }
        else
        {
            $order = $this->getMyOrder()["orders"]->with('paymentStatus', 'status', 'customer', 'deliveryMode', 'user', 'approvals');
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        }

        return datatables()->of($order)
            ->make();
    }
    public function list_without_bulk(Request $request)
    {
        if (!empty($request->input('cid')))
        {
            $ids = [$request->input("cid")];
            $order =  $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user', 'status', 'approvals')->whereIn('customer_id', $ids)
                ->where(function ($q)
                {
                    $q->whereIsBulk(0)->orWhere(function ($q)
                    {
                        $q->whereIsBulk(1)->Where("parent_id", "<>", -1);
                    });
                });
            if (!Gate::allows("view_deleted_orders")) {
                $order = $order->whereHas('status', function ($q) {
                    $q->where("status", "<>", "deleted");
                });
            }
        }
        else
        {
            if ($request->search["value"])
            {
                $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user', 'status', 'approvals')
                    ->where(function ($q)
                    {
                        $q->whereIsBulk(0)->orWhere(function ($q)
                        {
                            $q->whereIsBulk(1)->Where("parent_id", "<>", -1);
                        });
                    });
                if (!Gate::allows("view_deleted_orders")) {
                    $order = $order->whereHas('status', function ($q) {
                        $q->where("status", "<>", "deleted");
                    });
                }
            }
            else
            {
                $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user', 'status', 'approvals')
                    ->where(function ($q)
                    {
                        $q->whereIsBulk(0)->orWhere(function ($q)
                        {
                            $q->whereIsBulk(1)->Where("parent_id", "<>", -1);
                        });
                    });
                if (!Gate::allows("view_deleted_orders")) {
                    $order = $order->whereHas('status', function ($q) {
                        $q->where("status", "<>", "deleted");
                    });
                }
            }
        }

        return datatables()->of($order)
            ->make();
    }

    /**
     * Show the form for creating a new Admin/audits.
     *
     * @return Response
     */
    public function createorder(Request $request)
    {
        $input = $request->json()->all();
        $order = $input[0];
        $user = auth()->user();
        $order['user_id'] = $user->id;
        $order = SalesOrder::create(Arr::except($order, ['qty', 'product_id', 'product_deal', 'split_deal_id', 'sales_price']));
        $sos = Config::where("key", "sales_order_status")->first();
        $order->status_id = $sos->value;
        $order->save();
        foreach ($input as $key => $p)
        {
            $or = (object) $p;
            $od = (object) $this->get_product_entry($or);

            $o["sales_order_id"] = $order->id;
            $o["qty"] = $or->qty;
            $o["sales_price"] = $or->sales_price;
            $o["product_id"] = $od->product->id;
            $o["cost"] = $od->product->cost_price;
            if (!empty($or->product_deal))
                $o["product_deal_id"] = $or->product_deal ?? '';
            else
                $o["product_deal_id"] = null;
            if (!empty($or->split_deal_id))
                $o["split_deal_id"] = $or->split_deal_id ?? '';
            else
                $o["split_deal_id"] = null;

            $deal = SalesOrderDetails::create($o);

            if ($od->contract->is_split)
            {
                foreach ($od->splits as $key => $split)
                {
                    $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                    $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                    $d["sales_order_detail_id"] = $deal->id;
                    $d["customer_id"] = $split->split_customer;
                    $d["is_tiered"] = $od->contract->is_tiered;
                    $d["is_split"] = $od->contract->is_split;
                    $d["split_customer"] = $order->customer_id == $split->split_customer ? 1 : 0;
                    $d["ogr"] = $split->ogr;
                    $d["act"] = $split->act;
                    $d["sim"] = $split->sim;
                    $d["ogr_tier"] = $split->ogr_tier;
                    $d["act_tier"] = $split->act_tier;
                    $d["sim_tier"] = $split->sim_tier;
                    $d["start_date"] = $start;
                    $d["end_date"] = new Carbon("2099-12-31");
                    SalesDeal::create($d);
                }
            }
            else
            {
                $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                $d["sales_order_detail_id"] = $deal->id;
                $d["customer_id"] = $or->customer_id;
                $d["is_tiered"] = $od->contract->is_tiered;
                $d["is_split"] = $od->contract->is_split;
                $d["split_customer"] = 0;
                $d["ogr"] = ($od->contract->is_tiered ? $od->tier->ogr : ($od->deal ? $od->deal->ogr : $od->contract->ogr));
                $d["act"] = ($od->contract->is_tiered ? $od->tier->act : ($od->deal ? $od->deal->act : $od->contract->act));
                $d["sim"] = ($od->contract->is_tiered ? $od->tier->sim : ($od->deal ? $od->deal->sim : $od->contract->sim));
                $d["start_date"] = $start;
                $d["end_date"] = new Carbon("2099-12-31");
                SalesDeal::create($d);
            }
        }
        $this->generatePDFSales($order);
        $order = $this->check_approval($order);
        $this->sendEmails($sos->value, new SalesOrderCreated($order));
        return response()->json([
            "msg" => "The order has been created successfully.",
            "id" => $order->id
        ]);
    }

    /**
     * Show the form for editing the specified Admin/audits.
     *
     * @param int $id
     *
     * @return Response
     */
    public function create()
    {
        $payment = Status::where('process', 'payment_status')->get();
        $delivery = Status::where('process', 'delivery_mode')->get();
        if (Auth::user()->user_type_id == 2)
        {
            $customer = Customer::whereRepUserId(Auth::user()->user_type_id)
                ->whereIsActive(1)->get();
        }
        else
        {
            $customer = Customer::whereIsActive(1)->get();
        }
        $warehouse = Warehouse::whereId(Config::where("key", "main_warehouse")->first()->value)->get();
        return view('order.sales.create', compact('warehouse', 'customer', 'payment', 'delivery'));
    }

    public function create_bulk()
    {
        $payment = Status::where('process', 'payment_status')->get();
        $delivery = Status::where('process', 'delivery_mode')->get();
        $id = Auth::user()->user_type_id == 2 ? Auth::user()->id : -1;
        $customer = Customer::whereparentId(-1)
            ->whereIsActive(1)->get();
        $warehouse = Warehouse::all();
        $data = BulkOrderDetails::with("customer:id,name", "product:id,description,product_code,sale_price")->whereUserId(Auth::user()->id)->get();
        return view('order.sales.create_bulk', compact('warehouse', 'customer', 'payment', 'delivery', 'data'));
    }

    public function updateorder(Request $request)
    {
        $input = $request->data;
        $input= json_decode($input,true);

        $payment_status=  $request->input('payment_status');
        $delivery_mode=  $request->input('delivery_mode');

        //$input = $request->json()->all();
        $user = auth()->user();
        $oid = $input[0]["sales_order_id"];
        $order = SalesOrder::find($oid);
        foreach ($input as $key => $p) {
            $or = (object) $p;
            if ($or->type == "edit" || $or->type == "add") {
                $od = (object) $this->get_product_entry($or);
                $deal = [];
                $o["sales_order_id"] = $oid;
                $o["qty"] = $or->qty;
                $o["sales_price"] = $or->sales_price;
                $o["product_id"] = $od->product->id;
                $o["cost"] = $or->qty * $or->sales_price;
                if (!empty($or->product_deal))
                    $o["product_deal_id"] = $or->product_deal ?? '';
                else
                    $o["product_deal_id"] = null;
                if (!empty($or->split_deal_id))
                    $o["split_deal_id"] = $or->split_deal_id ?? '';
                else
                    $o["split_deal_id"] = null;

                if ($or->type == "edit") {
                    $deal = SalesOrderDetails::find($or->order_detail_id);
                    $deal->update($o);
                } else {
                    $deal = SalesOrderDetails::create($o);
                }
                SalesDeal::where("sales_order_detail_id", $deal->id)->delete();
                if ($od->contract->is_split) {
                    foreach ($od->splits as $key => $split) {
                        $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                        $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                        $d["sales_order_detail_id"] = $deal->id;
                        $d["customer_id"] = $split->split_customer;
                        $d["is_tiered"] = $od->contract->is_tiered;
                        $d["is_split"] = $od->contract->is_split;
                        $d["split_customer"] = $order->customer_id == $split->split_customer ? 1 : 0;
                        $d["ogr"] = $split->ogr;
                        $d["act"] = $split->act;
                        $d["sim"] = $split->sim;
                        $d["ogr_tier"] = $split->ogr_tier;
                        $d["act_tier"] = $split->act_tier;
                        $d["sim_tier"] = $split->sim_tier;
                        $d["start_date"] = $start;
                        $d["end_date"] = new Carbon("2099-12-31");
                        SalesDeal::create($d);
                    }
                } else {
                    $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                    $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                    $d["sales_order_detail_id"] = $deal->id;
                    $d["customer_id"] = $or->customer_id;
                    $d["is_tiered"] = $od->contract->is_tiered;
                    $d["is_split"] = $od->contract->is_split;
                    $d["split_customer"] = 0;
                    $d["ogr"] = ($od->contract->is_tiered ? $od->tier->ogr : ($od->deal ? $od->deal->ogr : $od->contract->ogr));
                    $d["act"] = ($od->contract->is_tiered ? $od->tier->act : ($od->deal ? $od->deal->act : $od->contract->act));
                    $d["sim"] = ($od->contract->is_tiered ? $od->tier->sim : ($od->deal ? $od->deal->sim : $od->contract->sim));
                    $d["start_date"] = $start;
                    $d["end_date"] = new Carbon("2099-12-31");
                    SalesDeal::create($d);
                }
            } elseif ($or->type == "remove") {
                SalesOrderDetails::destroy($or->order_detail_id);
            }
            }

            /* change payment and delivery */
            if(isset($request->payment_status) || isset($request->delivery_mode) ){
                    
                if($payment_status != $order->warehouse_id )
            {
                    DB::table('sales_order')
                    ->where('id',$oid)
                    ->update(['payment_status_id' => $payment_status]);
                }

                if($delivery_mode != $order->delivery_method_id )
                {
                    DB::table('sales_order')
                    ->where('id',$oid)
                    ->update(["delivery_method_id"=>$delivery_mode]);
            }
        }

        $this->generatePDFSales($order);
        $this->sendEmails($order->status_id, new SalesOrderCreated($order));
        return response()->json([
            "msg" => "The order has been updated successfully.",
            "id" => $oid
        ]);
    }

    public function updateInvoice(Request $request)
    {
        if (SalesOrder::find($request->sales_order_id)->status_id == Status::whereProcess("sales_order")->whereStatus("approved")->first()->id) {
            if ($request->filled('isPartial')) {
                foreach ($request->input("ids") as $key => $value) {
                    SalesOrderDetails::where('id', $request->input("ids")[$key])
                        ->update(["invoice_number" => $request->input("invoice")[$key]]);
                }
            }
            else
            {
                $order = SalesOrder::find($request->input("sales_order_id"));
                if ($order->is_bulk) {
                    $status = Status::where('process', 'order')->where('status', 'deleted')->first();
                    SalesOrderDetails::whereIn('sales_order_id', SalesOrder::whereParentId($order->id)
                                                                    ->where("status_id","<>",$status->id)
                                                                    ->pluck("id"))
                        ->update(["invoice_number" => $request->input("invoice_number")]);
                }
                else
                {
                    SalesOrderDetails::where('sales_order_id', $request->input("sales_order_id"))
                        ->update(["invoice_number" => $request->input("invoice_number")]);
                }
            }
        }
        else if (SalesOrder::find($request->sales_order_id)->status_id == Status::whereProcess("mobile_invoice")->whereStatus("approved")->first()->id)
        {
            SalesOrderDetails::where('sales_order_id', $request->input("sales_order_id"))
                ->update(["invoice_number" => $request->input("invoice_number")]);
        }
        else
        {
            return response()->json([
                "msg" => "Order cannot be invoiced before approval.",
                "code" => 500
            ]);
        }
        Alert::success('Success', 'The order has been invoiced.');
        return response()->json([
            "msg" => "The order has been invoiced successfully.",
            "code" => 200
        ]);
    }

    /**
     * Display the specified Admin/audits.
     *
     * @param int $id
     *
     * @return Response
     */
    public function show($id)
    {
        /** @var Admin/audits $admin/audits */
        // $status = $this->check_order_all($id);
        // if ($status->isMine) {
        //return view("pdf.sales");

        $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user', 'status')->find($id);
        $isAllocated = 0;
        if ($order->is_bulk) {
            $ids = SalesOrder::select(["id"])->whereParentId($order->id)->get();
            $deal = [];
            $d=[];
            $od = [];
            foreach ($ids as $order_child) {
                $od[] = $o = SalesOrderDetails::with('product', 'dispatch','order.customer:id,cust_code')->where("sales_order_id", $order_child->id)->get();
                foreach ($o as $key => $odetail) {
                    $d[] = $this->valid_deal($odetail->id);
                    //dump($this->valid_deal($odetail->id));
                    // $data = new stdClass();
                    // $data->customer_id = $order_child->customer_id;
                    // $data->customer_code = $order_child->customer->cust_code;
                    // $data->product_id = $odetail->product_id;
                    // $data->product_deal = $odetail->product_deal_id;
                    // $data->tenant_status = !empty($odetail->dispatch->status->name) ? $odetail->dispatch->status->name : 'Pending';
                    // $data->split_deal_id = $odetail->split_deal_id;
                    // $data->qty = $odetail->qty;
                    // $data->sales_price = $odetail->sales_price;
                    // $data->type = "none";
                    // $data->is_dispatch = $odetail->is_dispatch;
                    // $data->is_allocate = $odetail->is_allocate;
                    // $data->order_detail_id = $odetail->id;
                    // $data->sales_order_id = $odetail->sales_order_id;
                    // $data->invoice_number = $odetail->invoice_number;
                    // $deal[] = array_merge($this->get_product_entry($data), array("data" => $data, "type" => "edit", 'isReporting' => 0));
                }
                $deal[]=$d;
                $d=[];
            }
            $st = Status::where('process', 'order')->where('status', 'deleted')->first();
            $ids = SalesOrder::select(["id"])->whereParentId($order->id)->where("status_id","<>",$st->id)->pluck("id");
            $isInvoiced = SalesOrderDetails::whereIn('sales_order_id', $ids)->whereNull('invoice_number')->count();
        } else {
            $od = SalesOrderDetails::with('product', 'dispatch')->where("sales_order_id", $id)->get();
            $deal = [];
            foreach ($od as $key => $odetail) {
                $deal[]=$this->valid_deal($odetail->id);
                // $data = new stdClass();
                // $data->customer_id = $order->customer_id;
                // $data->product_id = $odetail->product_id;
                // $data->product_deal = $odetail->product_deal_id;
                // $data->split_deal_id = $odetail->split_deal_id;
                // $data->tenant_status = !empty($odetail->dispatch->status->name) ? $odetail->dispatch->status->name : 'Pending';
                // $data->qty = $odetail->qty;
                // $data->sales_price = $odetail->sales_price;
                // $data->type = "none";
                // $data->is_dispatch = $odetail->is_dispatch;
                // $data->is_allocate = $odetail->is_allocate;
                // $data->order_detail_id = $odetail->id;
                // $data->sales_order_id = $odetail->sales_order_id;
                // $data->invoice_number = $odetail->invoice_number;
                // $deal[] = array_merge($this->get_product_entry($data), array("data" => $data, "type" => "edit", 'isReporting' => 0));
            }
            $isInvoiced = SalesOrderDetails::where('sales_order_id', $id)->whereNull('invoice_number')->count();
            $isAllocated = Stock::whereIn('sales_order_detail_id', $od->pluck("id"))->count();
        }
        //dd($deal,$od,$order);
        return view('order.sales.show', compact('order', 'od', 'isInvoiced', 'deal', 'isAllocated'));
    }

    public function valid_deal($id)
    {
        return SalesDeal::with("customer")->select(DB::raw("sales_deal.*,count(stock.sales_order_detail_id) as isAllocated"))
            ->leftjoin("stock", "sales_deal.sales_order_detail_id", "=", "stock.sales_order_detail_id")
            ->whereIn(
                "sales_deal.id",
                SalesDeal::select(DB::raw("MAX(id)"))
                    ->whereRaw("DATE_SUB(LAST_DAY(sales_deal.start_date),INTERVAL DAY(LAST_DAY(sales_deal.start_date)) - 1 DAY) <= CURRENT_TIMESTAMP AND CURRENT_TIMESTAMP <= sales_deal.end_date and `sales_deal`.`sales_order_detail_id` = $id")
                    ->groupBy("sales_deal.sales_order_detail_id")
                    ->groupBy("sales_deal.customer_id")
                                        ->get()
        )->get();
    }

    public function show_approve($id)
    {
        /** @var Admin/audits $admin/audits */
        $status = $this->check_order($id);
        if ($status->isMine) {
            $order = SalesOrder::with('paymentStatus', 'customer', 'deliveryMode', 'user')->find($id);
            $isAllocated = 0;
            if ($order->is_bulk) {
                $ids = SalesOrder::select(["id"])->whereParentId($order->id)->get();
                $deal = [];
                $d=[];
                $od = [];
                foreach ($ids as $order_child) {
                    $od[] = $o = SalesOrderDetails::with('product','order.customer:id,cust_code')->where("sales_order_id", $order_child->id)->get();
                    foreach ($o as $key => $odetail) {
                        $d[] = $this->valid_deal($odetail->id);
                        // $data = new stdClass();
                        // $data->customer_id = $order_child->customer_id;
                        // $data->customer_code = $order_child->customer->cust_code;
                        // $data->product_id = $odetail->product_id;
                        // $data->product_deal = $odetail->product_deal_id;
                        // $data->split_deal_id = $odetail->split_deal_id;
                        // $data->qty = $odetail->qty;
                        // $data->sales_price = $odetail->sales_price;
                        // $data->type = "none";
                        // $data->is_dispatch = $odetail->is_dispatch;
                        // $data->is_allocate = $odetail->is_allocate;
                        // $data->order_detail_id = $odetail->id;
                        // $data->sales_order_id = $odetail->sales_order_id;
                        // $data->invoice_number = $odetail->invoice_number;
                        // $deal[] = array_merge($this->get_product_entry($data), array("data" => $data, "type" => "edit", 'isReporting' => 0));
                    }
                    $deal[]=$d;
                    $d=[];
                }
                $st = Status::where('process', 'order')->where('status', 'deleted')->first();
                $ids = SalesOrder::select(["id"])->whereParentId($order->id)->where("status_id","<>",$st->id)->pluck("id");
                $isInvoiced = SalesOrderDetails::whereIn('sales_order_id', $ids)->whereNull('invoice_number')->count();
            } else {
                $od = SalesOrderDetails::with('product')->where("sales_order_id", $id)->get();
                $deal = [];
                foreach ($od as $key => $odetail) {
                    $deal[]=$this->valid_deal($odetail->id);
                    // $data = new stdClass();
                    // $data->customer_id = $order->customer_id;
                    // $data->product_id = $odetail->product_id;
                    // $data->product_deal = $odetail->product_deal_id;
                    // $data->split_deal_id = $odetail->split_deal_id;
                    // $data->qty = $odetail->qty;
                    // $data->sales_price = $odetail->sales_price;
                    // $data->type = "none";
                    // $data->is_dispatch = $odetail->is_dispatch;
                    // $data->is_allocate = $odetail->is_allocate;
                    // $data->order_detail_id = $odetail->id;
                    // $data->sales_order_id = $odetail->sales_order_id;
                    // $data->invoice_number = $odetail->invoice_number;
                    // $deal[] = array_merge($this->get_product_entry($data), array("data" => $data, "type" => "edit", 'isReporting' => 0));
                }
                $isInvoiced = SalesOrderDetails::where('sales_order_id', $id)->whereNull('invoice_number')->count();
                $isAllocated = Stock::whereIn('sales_order_detail_id', $od->pluck("id"))->count();
            }
            $performance = DB::select(
                "SELECT network
                    ,SUM(CASE WHEN revenue_type = 'Ongoing Revenue' THEN income ELSE 0 END) AS 'ogr_income'
                    ,SUM(CASE WHEN revenue_type = 'Activation' THEN income ELSE 0 END) AS 'act_income'
                    ,SUM(CASE WHEN revenue_type = 'Activation' THEN kit_count ELSE 0 END) AS 'act_kit_count'
                    ,SUM(CASE WHEN revenue_type = 'Connection' THEN kit_count ELSE 0 END) AS 'con_kit_count'
                    ,SUM(CASE WHEN revenue_type = 'Kits Allocated' THEN kit_count ELSE 0 END) AS 'kits_allocated_count'
                    FROM (
                    (SELECT t4.process_month
                        ,'Ongoing Revenue' AS 'revenue_type'
                        ,t2.name AS 'network'
                        ,t4.file_name
                        ,t3.cust_code
                        ,SUM(income) AS 'income'
                        ,SUM(expense) AS 'expense'
                        ,0 AS 'kit_count'
                        FROM me_ogr_post_process t1
                        LEFT JOIN network t2 ON t1.network_id = t2.id
                        LEFT JOIN customer t3 ON t1.customer_id = t3.id
                        LEFT JOIN me_import_file t4 ON t1.file_id = t4.id
                        LEFT JOIN sales_order_detail t5 ON t5.id = t1.sales_order_detail_id
                        LEFT JOIN sales_order t6 ON t6.id = t5.sales_order_id
                        WHERE t3.cust_code = '" . $order->customer->cust_code . "'
                        GROUP BY t2.name
                        )
                        UNION
                        (
                        SELECT t4.process_month
                        ,'Activation' AS 'revenue_type'
                        ,t2.name AS 'network'
                        ,t4.file_name
                        ,t3.cust_code
                        ,SUM(income) AS 'income'
                        ,SUM(expense) AS 'expense'
                        ,COUNT(t1.serial_no) AS 'kit_count'
                        FROM me_act_post_process t1
                        LEFT JOIN network t2 ON t1.network_id = t2.id
                        LEFT JOIN customer t3 ON t1.customer_id = t3.id
                        LEFT JOIN me_import_file t4 ON t1.file_id = t4.id
                        LEFT JOIN sales_order_detail t5 ON t5.id = t1.sales_order_detail_id
                        LEFT JOIN sales_order t6 ON t6.id = t5.sales_order_id
                        WHERE t3.cust_code = '" . $order->customer->cust_code . "'
                        AND t1.income > 0
                        GROUP BY t2.name
                        )
                        UNION
                        (
                        SELECT t4.process_month
                        ,'Connection' AS 'revenue_type'
                        ,t2.name AS 'network'
                        ,t4.file_name
                        ,t3.cust_code
                        ,0 AS 'Income'
                        ,0 AS 'Expense'
                        ,COUNT(t1.serial_no) AS 'kit_count'
                        FROM me_con_post_process t1
                        LEFT JOIN network t2 ON t1.network_id = t2.id
                        LEFT JOIN customer t3 ON t1.customer_id = t3.id
                        LEFT JOIN me_import_file t4 ON t1.file_id = t4.id
                        LEFT JOIN sales_order_detail t5 ON t5.id = t1.sales_order_detail_id
                        LEFT JOIN sales_order t6 ON t6.id = t5.sales_order_id
                        WHERE t3.cust_code = '" . $order->customer->cust_code . "'
                        GROUP BY t2.name
                        )
                        UNION
                        (
                        SELECT ''
                        ,'Kits Allocated' AS 'revenue_type'
                        ,t2.name AS 'network'
                        ,''
                        ,t3.cust_code
                        ,0 AS 'Income'
                        ,0 AS 'Expense'
                        ,COUNT(t1.serial_no) AS 'kit_count'
                        FROM stock t1
                        LEFT JOIN network t2 ON t1.network_id = t2.id
                        LEFT JOIN customer t3 ON t1.customer_id = t3.id
                        WHERE t3.cust_code = '" . $order->customer->cust_code . "'
                        GROUP BY t2.name
                    )
                ) performance
                GROUP BY network"
            );
            return view('order.sales.show_approve', compact('order', 'od', 'isInvoiced', 'status', 'deal', 'performance', 'isAllocated'));
        } else {
            abort(401);
        }
    }

    public function add_product(Request $request)
    {
        if($request->has("order_detail_id")){
            $count = Stock::where('product_id', $request->product_id)
            ->whereWarehouseId($request->warehouse_id)
            ->whereNull('sales_order_detail_id')
            ->orWhere("sales_order_detail_id",$request->order_detail_id)->count();
        }else{
        $count = Stock::where('product_id', $request->product_id)
            ->whereWarehouseId($request->warehouse_id)
            ->whereNull('sales_order_detail_id')->count();
        }
        $type = $request->type;
        $isReporting = 0;
        if ($count >= $request->qty)
        {
            $data = $request->all();
            $r = new stdClass();
            $r->customer_id = $request->customer_id;
            $r->product_id = $request->product_id;
            $r->product_deal = $request->product_deal;
            $r->split_deal_id = $request->split_deal_id;
            $r->qty = $request->qty;
            $r->sales_price = $request->sales_price;
            return view('ajax.salesorder_product_row', $this->get_product_entry($r), compact('data', 'type', 'isReporting'));
        }
        else
        {
            if ($request->type == "edit")
            {
                $data = $request->all();
                $data["qty"] = $count;
                $r = new stdClass();
                $r->customer_id = $request->customer_id;
                $r->product_id = $request->product_id;
                $r->product_deal = $request->product_deal;
                $r->split_deal_id = $request->split_deal_id;
                $r->qty = $count;
                $r->sales_price = $request->sales_price;
                $title = "Error!";
                $msg = "There is only " . $count . " QTY available for this product.";
                return view('ajax.salesorder_product_row', $this->get_product_entry($r), compact('data', 'title', 'msg', 'type', 'isReporting'));
            }
            else
            {
                $title = "Error!";
                $msg = "There is no stock available for this product.";
                $type = "NO_STOCK";
                return view('ajax.alert_error', compact('title', 'msg', 'type'));
            }
        }
    }

    public function product_deal(Request $request)
    {
        $customer = Customer::find($request->customer_id);
        $product = Product::find($request->product_id);
        $network_id = $product->network->id;
        $contract = Contract::where('customer_id', $request->customer_id)
            ->where('network_id', $network_id)->first();

        if (!$contract)
        {
            $title = "Error!";
            $msg = "The customer does not have any contracts with this network.";
            $type = "NO_CONTRACT";
            return view("ajax.alert_error", compact('title', 'msg', 'type'));
        }
        if (!$contract->is_tiered)
        {
            $deals = ProductDeal::where('product_id', $request->product_id)
                ->where('customer_group_id', $customer->group_id)
                ->whereRaw('(now() between start_date and end_date)')
                ->orWhere(function ($query) use ($customer, $request)
                {
                    $query->where('customer_id', $customer->id)
                        ->where('product_id', $request->product_id)
                        ->whereRaw('(now() between start_date and end_date)');
                })
                ->get();

            $splits = CustomerSplit::where('customer_id', $request->customer_id)
                ->where('network_id', $network_id)->get();
            $parent = null;
            if ($customer->parent_id != -1 || $customer->parent_id != NULL)
            {
                $parent = Contract::where('customer_id', $customer->parent_id)
                    ->where('network_id', $network_id)->first();
            }
            return view('ajax.product_deal_select', compact('deals', 'splits', 'contract', 'parent'));
        }
        elseif ($contract->is_split)
        {
            $acb = BaseSummary::whereCustomerId($customer->id)
                ->whereNetworkId($network_id)
                ->sum("active_base");
            $deals = TierStage::where('customer_id', $request->customer_id)
                ->where('network_id', $network_id)
                ->where('from_cab', '<=', (int) $acb)
                ->where(function ($query) use ($acb)
                {
                    $query->where('to_cab', '>=', (int) $acb);
                    $query->orWhere('to_cab', -1);
                })
                ->first();
            $parent = null;
            if ($customer->parent_id != -1 || $customer->parent_id != NULL)
            {
                $parent = Contract::where('customer_id', $customer->parent_id)
                    ->where('network_id', $network_id)->first();
            }

            $split_deal = SplitDeal::where('customer_id', $request->customer_id)
                ->where('product_id', $request->product_id)
                ->whereRaw('(now() between start_date and end_date)')
                ->get();

            return view('ajax.product_deal_select', compact('deals', 'contract', 'split_deal', 'parent'));
        }
        else
        {
            $splits = null;
            $acb = BaseSummary::whereCustomerId($customer->id)
                ->whereNetworkId($network_id)
                ->sum("active_base");
            $deals = TierStage::where('customer_id', $request->customer_id)
                ->where('network_id', $network_id)
                ->where('from_cab', '<=', (int) $acb)
                ->where(function ($query) use ($acb)
                {
                    $query->where('to_cab', '>=', (int) $acb);
                    $query->orWhere('to_cab', -1);
                })
                ->first();

            return view('ajax.product_deal_select', compact('deals', 'splits', 'contract'));
        }
    }

    public function splits(Request $request)
    {
        $customer = Customer::find($request->customer_id);
        $product = Product::find($request->product_id);
        $network_id = $product->network->id;
        $product_deal_id = $request->product_deal_id;
        $contract = Contract::where('customer_id', $request->customer_id)
            ->where('network_id', $network_id)->first();
        if (!$contract->is_tiered && $contract->is_split)
        {
            $split_deal = SplitDeal::where('customer_id', $request->customer_id)
                ->where('product_deal_id', $product_deal_id)
                ->whereRaw('(now() between start_date and end_date)')
                ->get();
            return view('ajax.product_split_select', compact('split_deal', 'product_deal_id'));
        }
        else
        {
            return "The customer does not have any split billing contracts with this network.";
        }
    }

    public function split_deal(Request $request)
    {
        $product_deal_id = $request->product_deal_id;
        $product = Product::find($request->product_id);
        $network_id = $product->network->id;

        if (!$request->filled("split_deal_id") || strlen($request->split_deal_id) == 0)
        {
            $splits = CustomerSplit::where('customer_id', $request->customer_id)
                ->where('network_id', $network_id)
                ->whereNull('product_id')
                ->whereNull('product_deal_id')
                ->whereNull('split_deal_id')
                ->get();
        }
        else
        {
            $splits = CustomerSplit::where('split_deal_id', $request->split_deal_id)
                ->get();
        }
        if ($request->is_tiered)
        {
            return view('ajax/tier_split_select', compact('splits'));
        }
        else
        {
            return view('ajax/split_select', compact('splits', 'product_deal_id'));
        }
    }

    public function change_split(Request $request)
    {
        $product = Product::find($request->product_id);
        $sp = CustomerSplit::where('split_deal_id', $request->split_deal)
            ->whereCustomerId($request->customer_id)
            ->whereNetworkId($product->network_id)
            ->get();
        $sp_id = SplitDeal::create([
            'customer_id' => $request->customer_id,
            'product_deal_id' => $request->product_deal_id[0],
            'name' => $request->name,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date
        ]);
        if ($sp->count() == 0)
        {
            foreach ($request->ogr as $key => $value)
            {
                $split = CustomerSplit::find($request->split_id[$key]);
                $new_split = $split->replicate();
                $new_split->product_deal_id = $request->product_deal_id[$key];
                $new_split->product_id = null;
                $new_split->split_deal_id = $sp_id->id;
                $new_split->ogr = $request->ogr[$key];
                $new_split->act = $request->act[$key];
                $new_split->sim = $request->sim[$key];
                $new_split->save();
            }
        }
        else
        {
            foreach ($sp as $key => $s)
            {
                $new_split = $s->replicate();
                $new_split->product_deal_id = $request->product_deal_id[$key];
                $new_split->split_deal_id = $sp_id->id;
                $new_split->ogr = $request->ogr[$key];
                $new_split->act = $request->act[$key];
                $new_split->sim = $request->sim[$key];
                $new_split->save();
            }
        }

        return response()->json([
            "code" => 200,
            "data" => $sp_id,
            "c" => $sp_id->name,
            "day" => $sp_id->end_date->diffinDays(),
        ], 200);
    }

    public function change_split_tier(Request $request)
    {
        $product = Product::find($request->product_id);
        $sp = CustomerSplit::where('split_deal_id', $request->split_deal)
            ->whereCustomerId($request->customer_id)
            ->whereNetworkId($product->network_id)
            ->get();
        $sp_id = SplitDeal::create([
            'customer_id' => $request->customer_id,
            'product_id' => $request->product_id,
            'name' => $request->name,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date
        ]);
        if ($sp->count() == 0)
        {
            foreach ($request->ogr as $key => $value)
            {
                $split = CustomerSplit::find($request->split_id[$key]);
                $new_split = $split->replicate();
                $new_split->product_deal_id = null;
                $new_split->split_deal_id = $sp_id->id;
                $new_split->product_id = $request->product_id;
                $new_split->ogr = $request->ogr[$key];
                $new_split->act = $request->act[$key];
                $new_split->sim = $request->sim[$key];
                $new_split->ogr_tier = $request->ogr_tier[$key];
                $new_split->act_tier = $request->act_tier[$key];
                $new_split->sim_tier = $request->sim_tier[$key];
                $new_split->save();
            }
        }
        else
        {
            foreach ($sp as $key => $s)
            {
                $new_split = $s->replicate();
                $new_split->split_deal_id = $sp_id->id;
                $new_split->ogr = $request->ogr[$key];
                $new_split->act = $request->act[$key];
                $new_split->sim = $request->sim[$key];
                $new_split->ogr_tier = $request->ogr_tier[$key];
                $new_split->act_tier = $request->act_tier[$key];
                $new_split->sim_tier = $request->sim_tier[$key];
                $new_split->save();
            }
        }
        return response()->json([
            "code" => 200,
            "data" => $sp_id,
            "c" => $sp_id->name,
            "day" => $sp_id->end_date->diffinDays(),
        ], 200);
    }

    public function change_deal(Request $request)
    {
        $product = ProductDeal::create($request->all());
        return response()->json([
            "data" => $product,
            "c" => $product->customer->name,
            "day" => $product->end_date->diffinDays(),
            "code" => 200
        ], 200);
    }

    public function createbulkorder(Request $request)
    {
        $order = json_decode($request->order);
        $a = [];
        $user = Auth::user();
        BulkOrderDetails::whereUserId($user->id)->delete();
        foreach ($order as $key => $value)
        {
            BulkOrderDetails::insert([
                'customer_id' => $value->customer_id,
                'parent_id' => $request->customer_id,
                'order_id' => $value->odid,
                'product_id' => $value->id,
                'user_id' => $user->id,
                'qty' => $value->qty,
                'payment_status_id' => $request->payment_status_id,
                'delivery_method_id' => $request->delivery_mode,
                'warehouse_id' => $request->warehouse_id,
                'bill_to_headoffice' => $request->filled("bill_to_headoffice"),
                'deliver_to_headoffice' => $request->filled("deliver_to_headoffice"),
                'price' => $value->sale_price,
            ]);
        }

        return response()->json([
            "data" => $a,
            "status" => 200,
            "msg" => "Bulk order generated."
        ], 200);
    }

    public function bulkorder_import(Request $request)
    {
        $user = Auth::user();
        if(!$request->hasFile("order")){
            Alert::error("Please select valid file to upload.");
            return redirect("order/sales/create_bulk");
        }
        try {
            $array = FacadesExcel::toArray(new OrderImport, $request->file('order'));
            $validator = Validator::make($array[0][0], [
                "head_office" => 'required',
                "customer_code"=>'required',
                "product_code"=>'required',
                "sales_price"=>'required',
                "qty"=>'required',
                "warehouse_id"=>'required',
                "payment_status"=>'required',
                "delivey_mode"=>'required',
                "bill_to_headoffice"=>'required',
                "deliver_to_headoffice"=>'required',
            ]);
            
            if($validator->fails())
            {
                Alert::html("Your file doesn't have following required data.",implode(",<br/>",$validator->errors()->all()),"error");
                return redirect("order/sales/create_bulk");
            }
        } catch (\Throwable $th) {
            Alert::error("Your file is not valid.");
            return redirect("order/sales/create_bulk");
        }
        
        $payment = Status::whereProcess("payment_status")->whereStatus($array[0][0]["payment_status"])->first();
        $delivery = Status::whereProcess("delivery_mode")->whereStatus($array[0][0]["delivey_mode"])->first();
        $bill_to_headoffice = $array[0][0]["bill_to_headoffice"] == "YES" ? 1 : 0;
        $deliver_to_headoffice = $array[0][0]["deliver_to_headoffice"] == "YES" ? 1 : 0;
        $msg="";
        $type="success";
        $parent = Customer::whereCustCode($array[0][0]['head_office'])->first();
        if(!$payment){
            $type="error";
            $msg.=$array[0][0]["payment_status"]." Payment status not exists in system.<br/>";
            Alert::html("Bulk Upload Result.",$msg, $type);
            return redirect("order/sales/create_bulk");
        }
        if(!$delivery){
            $type="error";
            $msg.=$array[0][0]["delivey_mode"]." Delivery status not exists in system.<br/>";
            Alert::html("Bulk Upload Result.",$msg, $type);
            return redirect("order/sales/create_bulk");
        }
        if(!$parent){
            $type="error";
            $msg.=$array[0][0]['head_office']." Head Office is not exists in system.<br/>";
            Alert::html("Bulk Upload Result.",$msg, $type);
            return redirect("order/sales/create_bulk");
        }
        BulkOrderDetails::whereuserId($user->id)->delete();

        foreach ($array[0] as $key => $row)
        {
            if (!empty($row['customer_code']))
            {
                $product = Product::whereProductCode($row['product_code'])->first();
                $customer = Customer::whereCustCode($row['customer_code'])->first();
                if(!$customer){
                    $type="error";
                    $msg.=$row['customer_code']." is not exists in system.<br/>";
                    continue;
                }else{    
                    if($customer->is_active!=1){
                        $type="error";
                        $msg.=$row['customer_code']." is not active.<br/>";
                        continue;
                    }
                    $contract = Contract::where('customer_id', $customer->id)
                                        ->where('network_id', $product->network_id)->first();
                    if (!$contract)
                    {
                        $type="error";
                        $msg .= $row['customer_code']." does not have any contract with ".$product->network->name." <br/>";
                        continue;
                    }
                }
                $data = [
                    'customer_id' => $customer->id,
                    'parent_id' => $parent->id,
                    'order_id' => 123456,
                    'product_id' => $product->id,
                    'user_id' => $user->id,
                    'qty' => $row['qty'],
                    'payment_status_id' => $payment->id,
                    'delivery_method_id' => $delivery->id,
                    'warehouse_id' => $row['warehouse_id'],
                    'bill_to_headoffice' => $bill_to_headoffice,
                    'deliver_to_headoffice' => $deliver_to_headoffice,
                    'price' => $row['sales_price'],
                ];
                BulkOrderDetails::create($data);
            }
        }
        Alert::html("Bulk Upload Result.",($type=='success')?"Bulk upload has been done successfully.":$msg, $type);
        return redirect("order/sales/create_bulk");
    }

    public function createbulkorder_step2(Request $request)
    {
        $product = Product::all();
        $data = BulkOrderDetails::with("customer:id,name")->whereUserId(Auth::user()->id)->groupBy("customer_id")->get();
        return view('order.sales.create_bulk_step2', compact('data', 'product'));
    }

    public function createbulkorder_step2_edit(Request $request)
    {
        $deal = [];
        $order_details = BulkOrderDetails::whereCustomerId($request->customer_id)->whereUserId($request->user_id)->get();

        foreach ($order_details as $key => $od)
        {
            $data = new stdClass();
            $data->customer_id = $od->customer_id;
            $data->product_id = $od->product_id;
            $data->product_deal = $od->product_deal;
            $data->split_deal_id = $od->split_deal_id;
            $data->qty = $od->qty;
            $data->sales_price = $od->price;
            $data->type = "none";
            $data->order_detail_id = $od->id;

            $product = Product::find($od->product_id);
            $network_id = $product->network->id;
            $contract = Contract::where('customer_id', $od->customer_id)
                ->where('network_id', $network_id)->first();
            if (!$contract)
            {
                $title = "Oops!";
                $msg = "The customer does not have any contract with this network.";
                $type = "NO_CONTRACT";
                return view("ajax.alert_error", compact('title', 'msg', 'type'));
            }

            $deal[] = array_merge($this->get_product_entry($data), array("data" => $data, "type" => "edit", 'isReporting' => 0));
        }
        return view('ajax.sales_bulk_edit_product', compact('deal'));
    }

    public function createbulkorder_step2_edit_product(Request $request)
    {
        $order = BulkOrderDetails::whereUserId(Auth::user()->id)
            ->whereCustomerId($request->customer_id)
            ->whereProductId($request->product_id)->first();
        $order->update($request->except(["customer_id", "order_detail_id"]));
        $count = Stock::where('product_id', $request->product_id)
            ->whereWarehouseId($order->warehouse_id)
            ->whereNull('sales_order_detail_id')->count();
        $type = $request->type;
        $isReporting = 0;
        if ($count >= $request->qty)
        {
            $data = $request->all();
            $r = new stdClass();
            $r->customer_id = $request->customer_id;
            $r->product_id = $request->product_id;
            $r->product_deal = $request->product_deal;
            $r->split_deal_id = $request->split_deal_id;
            $r->qty = $request->qty;
            $r->sales_price = $request->price;
            return view('ajax.salesorder_product_row', $this->get_product_entry($r), compact('data', 'type', 'isReporting'));
        }
        else
        {
            if ($request->type == "edit")
            {
                $data = $request->all();
                $data["qty"] = $count;
                $r = new stdClass();
                $r->customer_id = $request->customer_id;
                $r->product_id = $request->product_id;
                $r->product_deal = $request->product_deal;
                $r->split_deal_id = $request->split_deal_id;
                $r->qty = $count;
                $r->sales_price = $request->price;
                $title = "Error!";
                $msg = "There is only " . $count . " QTY available for this product.";
                return view('ajax.salesorder_product_row', $this->get_product_entry($r), compact('data', 'title', 'msg', 'type', 'isReporting'));
            }
            else
            {
                $title = "Error!";
                $msg = "There is no stock available for this product.";
                $type = "NO_STOCK";
                return view('ajax.alert_error', compact('title', 'msg', 'stock'));
            }
        }
    }

    public function createorder_bulk(Request $request)
    {
        $user = auth()->user();

        $od = BulkOrderDetails::whereUserId($user->id)->groupBy("customer_id")->get()->toArray();
        $msg = "";
        foreach ($od as $key => $order)
        {
            $product = Product::find($order["product_id"]);
            $contract = Contract::where('customer_id', $order["customer_id"])
                ->where('network_id', $product->network_id)->first();
            if (!$contract)
            {
                $customer = Customer::find($order["customer_id"]);
                $msg .= "$customer->name does not have a contract for " . $product->network->name . ", set up contract first and proceed.<br/>";
            }
        }
        if ($msg != "")
        {
            return response()->json([
                "msg" => $msg,
                "code" => 400
            ]);
        }
        $parentOrder = Arr::except((array) $od[0], ['qty', 'product_id', 'product_deal', 'split_deal_id', 'order_id', 'price', 'created_at', 'updated_at', 'id']);
        $parentOrder["customer_id"] = $parentOrder["parent_id"];
        $parentOrder["parent_id"] = -1;
        $parentOrder["is_bulk"] = 1;
        $parentOd = SalesOrder::create($parentOrder);
        $sos = Config::where("key", "sales_order_status")->first();
        $parentOd->status_id = $sos->value;
        $this->check_approval($parentOd);
        foreach ($od as $key => $odetail)
        {
            $order = SalesOrder::create(Arr::except((array) $odetail, ['qty', 'product_id', 'product_deal', 'split_deal_id', 'order_id', 'price', 'created_at', 'updated_at', 'id']));
            $order->is_bulk = 1;
            $order->parent_id = $parentOd->id;
            $sos = Config::where("key", "sales_order_status")->first();
            $order->status_id = $sos->value;
            $order = $this->check_approval($order, true);
            $input = BulkOrderDetails::whereCustomerId($odetail["customer_id"])->whereUserId($user->id)->get();
            foreach ($input as $key => $p)
            {
                $or = (object) $p;
                $od = (object) $this->get_product_entry($or);

                $o["sales_order_id"] = $order->id;
                $o["qty"] = $or->qty;
                $o["sales_price"] = $or->price;
                $o["product_id"] = $od->product->id;
                $o["cost"] =  $or->qty * $or->price;
                if (!empty($or->product_deal))
                    $o["product_deal_id"] = $or->product_deal ?? '';
                else
                    $o["product_deal_id"] = null;
                if (!empty($or->split_deal_id))
                    $o["split_deal_id"] = $or->split_deal_id ?? '';
                else
                    $o["split_deal_id"] = null;

                $deal = SalesOrderDetails::create($o);
                if ($od->contract->is_split)
                {
                    foreach ($od->splits as $key => $split)
                    {
                        $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                        $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                        $d["sales_order_detail_id"] = $deal->id;
                        $d["customer_id"] = $split->split_customer;
                        $d["is_tiered"] = $od->contract->is_tiered;
                        $d["is_split"] = $od->contract->is_split;
                        $d["split_customer"] = $order->customer_id == $split->split_customer ? 1 : 0;
                        $d["ogr"] = $split->ogr;
                        $d["act"] = $split->act;
                        $d["sim"] = $split->sim;
                        $d["ogr_tier"] = $split->ogr_tier;
                        $d["act_tier"] = $split->act_tier;
                        $d["sim_tier"] = $split->sim_tier;
                        $d["start_date"] = $start;
                        $d["end_date"] = new Carbon("2099-12-31");
                        SalesDeal::create($d);
                    }
                }
                else
                {
                    $start = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->start_date : now());
                    $end = $od->contract->is_tiered ? now() : ($od->deal ? $od->deal->end_date : now());
                    $d["sales_order_detail_id"] = $deal->id;
                    $d["customer_id"] = $or->customer_id;
                    $d["is_tiered"] = $od->contract->is_tiered;
                    $d["is_split"] = $od->contract->is_split;
                    $d["split_customer"] = 0;
                    $d["ogr"] = ($od->contract->is_tiered ? $od->tier->ogr : ($od->deal ? $od->deal->ogr : $od->contract->ogr));
                    $d["act"] = ($od->contract->is_tiered ? $od->tier->act : ($od->deal ? $od->deal->act : $od->contract->act));
                    $d["sim"] = ($od->contract->is_tiered ? $od->tier->sim : ($od->deal ? $od->deal->sim : $od->contract->sim));
                    $d["start_date"] = $start;
                    $d["end_date"] = new Carbon("2099-12-31");
                    SalesDeal::create($d);
                }
            }
        }

        BulkOrder::whereuserId($user->id)->delete();
        BulkOrderDetails::whereuserId($user->id)->delete();
        return response()->json([
            "msg" => "The order has been created successfully.",
            "code" => 200
        ]);
    }

    public function change_order_deal(Request $request)
    {
        if ($request->customer != -1)
        {
            $orders = SalesOrder::whereCustomerId($request->customer)->pluck("id");
            $ods = SalesOrderDetails::whereIn("sales_order_id", $orders)
                ->whereProductId($request->product)->pluck("id");

            foreach ($ods as $deal)
            {
                $deals = SalesDeal::where("sales_order_detail_id", $deal)->first();
                $so = SalesOrderDetails::select(["sales_order_id"])->whereId($deal)->first();
                $order = SalesOrder::select(["customer_id"])->whereId($so->sales_order_id)->first();
                if ($request->is_split)
                {
                    foreach (json_decode($request->splits) as $key => $split)
                    {
                        $start = $request->start_date;
                        $end = $request->end_date;
                        $d["sales_order_detail_id"] = $deal;
                        $d["customer_id"] = $split->split_customer;
                        $d["is_tiered"] = $deals->is_tiered;
                        $d["is_split"] = $deals->is_split;
                        $d["split_customer"] = $order->customer_id == $split->split_customer ? 1 : 0;
                        $d["ogr"] = $split->ogr;
                        $d["act"] = $split->act;
                        $d["sim"] = $split->sim;
                        $d["ogr_tier"] = $split->ogr_tier;
                        $d["act_tier"] = $split->act_tier;
                        $d["sim_tier"] = $split->sim_tier;
                        $d["start_date"] = $start;
                        $d["end_date"] = $end;
                        SalesDeal::create($d);
                    }
                }
                else
                {
                    $start = $request->start_date;
                    $end = $request->end_date;
                    $d["sales_order_detail_id"] = $deal;
                    $d["customer_id"] = $order->customer_id;
                    $d["is_tiered"] = $deals->is_tiered;
                    $d["is_split"] = $deals->is_split;
                    $d["split_customer"] = 0;
                    $d["ogr"] = $request->ogr;
                    $d["act"] = $request->act;
                    $d["sim"] = $request->sim;
                    $d["start_date"] = $start;
                    $d["end_date"] = $end;
                    SalesDeal::create($d);
                }
                $this->sendEmails(Status::whereProcess("change_deal_order")->whereStatus("send_mail")->first()->id, new ChangeOrderDealNotification($order));
            }
        }
        else if ($request->order != -1)
        {
            $od = SalesOrderDetails::whereSalesOrderId($request->order)->whereProductId($request->product)->first();
            $deals = SalesDeal::where("sales_order_detail_id", $od->id)->first();
            $order = SalesOrder::find($request->order);
            if ($request->is_split)
            {
                foreach (json_decode($request->splits) as $key => $split)
                {
                    $start = $request->start_date;
                    $end = $request->end_date;
                    $d["sales_order_detail_id"] = $od->id;
                    $d["customer_id"] = $split->split_customer;
                    $d["is_tiered"] = $deals->is_tiered;
                    $d["is_split"] = $deals->is_split;
                    $d["split_customer"] = $order->customer_id == $split->split_customer ? 1 : 0;
                    $d["ogr"] = $split->ogr;
                    $d["act"] = $split->act;
                    $d["sim"] = $split->sim;
                    $d["ogr_tier"] = $split->ogr_tier;
                    $d["act_tier"] = $split->act_tier;
                    $d["sim_tier"] = $split->sim_tier;
                    $d["start_date"] = $start;
                    $d["end_date"] = $end;
                    SalesDeal::create($d);
                }
            }
            else
            {
                $start = $request->start_date;
                $end = $request->end_date;
                $d["sales_order_detail_id"] = $od->id;
                $d["customer_id"] = $order->customer_id;
                $d["is_tiered"] = $deals->is_tiered;
                $d["is_split"] = $deals->is_split;
                $d["split_customer"] = 0;
                $d["ogr"] = $request->ogr;
                $d["act"] = $request->act;
                $d["sim"] = $request->sim;
                $d["start_date"] = $start;
                $d["end_date"] = $end;
                SalesDeal::create($d);
            }
            $this->sendEmails(Status::whereProcess("change_deal_order")->whereStatus("send_mail")->first()->id, new ChangeOrderDealNotification($order));
        }
        return response()->json([
            "msg" => "Customer deals has been changed successfully.",
        ]);
    }

    public function change_order_deal_get(Request $request)
    {
        if ($request->id == -1)
        {
            $product = Product::find($request->product_id);
            $network_id = $product->network->id;
            $contract = Contract::where('customer_id', $request->customer_id)
                ->where('network_id', $network_id)->first();
            return view('ajax.contract_details_input_hidden', compact('contract'));
        }
        $order = SalesOrder::find($request->id);
        $order_details = SalesOrderDetails::where('sales_order_id', $request->id)
            ->whereProductId($request->product_id)->get();
        $deal = [];
        foreach ($order_details as $key => $od)
        {
            $data = new stdClass();
            $data->customer_id = $order->customer_id;
            $data->product_id = $od->product_id;
            $data->product_deal = $od->product_deal_id;
            $data->split_deal_id = $od->split_deal_id;
            $data->is_dispatch = $od->is_dispatch;
            $data->sales_price = $od->sales_price;
            $data->qty = $od->qty;
            $data->type = "none";
            $data->order_detail_id = $od->id;
            $data->sales_order_id = $od->sales_order_id;
            $deal[] = array_merge($this->get_product_entry($data), array("data" => $data, "type" => "edit", 'isReporting' => 1));
        }
        return view('ajax.salesdeal_row', compact('deal', 'order'));
    }

    private function get_fin_period($date)
    {
        $month = date('M', strtotime($date));

        switch ($month)
        {
            case 'Jun':
                return '1';
                break;
            case 'Jul':
                return '2';
                break;
            case 'Aug':
                return '3';
                break;
            case 'Sep':
                return '4';
                break;
            case 'Oct':
                return '5';
                break;
            case 'Nov':
                return '6';
                break;
            case 'Dec':
                return '7';
                break;
            case 'Jan':
                return '8';
                break;
            case 'Feb':
                return '9';
                break;
            case 'Mar':
                return '10';
                break;
            case 'Apr':
                return '11';
                break;
            case 'May':
                return '12';
                break;
        }
    }
}
