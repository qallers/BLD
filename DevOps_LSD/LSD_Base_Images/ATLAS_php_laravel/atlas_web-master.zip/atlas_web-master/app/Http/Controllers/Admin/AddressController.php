<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Flash;
use Response;
use App\Address;
use App\Status;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Spatie\Activitylog\Models\Activity;
use Spatie\Permission\Models\Role;

class AddressController extends Controller {

    public function store(Request $request) {
        if ($request->filled("id")) {
            $address = Address::find($request->id);
            $address->update($request->except(['type']));
        } else {
            $status = Status::whereProcess("address_entity_type")
                            ->whereStatus($request->type)->first();
            $request->request->add(['address_entity_id' => $status->id]);
            $address = Address::create($request->except(['type']));
        }

        return view('ajax.address_line', compact('address'));
    }

    public function destroy(Request $request) {
        $address = Address::find($request->id);
        $address->delete();
        return response()->json([
                    "code" => 200,
                    "message" => "Success."
        ]);
    }

}
