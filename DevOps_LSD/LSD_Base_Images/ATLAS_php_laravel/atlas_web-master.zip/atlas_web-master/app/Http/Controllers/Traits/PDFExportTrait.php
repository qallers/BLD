<?php

namespace App\Http\Controllers\Traits;

use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Support\Facades\Config as FacadesConfig;
use Illuminate\Support\Facades\File;

trait PDFExportTrait {

    public function generatePDFPurchase($order) {
        if (!File::isDirectory(storage_path('/purchase/'))) {
            File::makeDirectory(storage_path('/purchase/'),0777,true);
        }
        $logo = base64_encode(file_get_contents((storage_path("/avatar/" . FacadesConfig::get('company_avatar', 'default.png')))));
        $order->load('product', 'supplier', 'status', 'user', 'warehouse');
        $pdf = PDF::loadView('pdf.purchase', compact('order', 'logo'));
        $pdf->save(storage_path('/purchase/order_' . $order->id . '.pdf'));
    }

    public function generatePDFRep($order) {
        if (!File::isDirectory(storage_path('/rep/'))) {
            File::makeDirectory(storage_path('/rep/',0777,true));
        }
        $logo = base64_encode(file_get_contents((storage_path("/avatar/" . FacadesConfig::get('company_avatar', 'default.png')))));
        $order->load('warehouse', 'status', 'user','reptransferdetail','reptransferdetail.product');
        $pdf = PDF::loadView('pdf.rep_transfer', compact('order', 'logo'));
        $pdf->save(storage_path('/rep/rep_transfer_' . $order->id . '.pdf'));
    }

    public function generatePDFReturn($order) {
        if (!File::isDirectory(storage_path('/stock/'))) {
            File::makeDirectory(storage_path('/stock/',0777,true));
        }
        $logo = base64_encode(file_get_contents((storage_path("/avatar/" . FacadesConfig::get('company_avatar', 'default.png')))));
        $order->load('status','customer','user');
        $pdf = PDF::loadView('pdf.return_stock', compact('order', 'logo'));
        $pdf->save(storage_path('/stock/return_stock_' . $order->id . '.pdf'));
    }

    public function generatePDFSales($order) {
        if (!File::isDirectory(storage_path('/sales/'))) {
            File::makeDirectory(storage_path('/sales/',0777,true));
        }
        $order->load("salesOrderDetail","paymentStatus","deliveryMode","status","user","customer","warehouse");
        $logo = base64_encode(file_get_contents((storage_path("/avatar/" . FacadesConfig::get('company_avatar', 'default.png')))));
        $pdf = PDF::loadView('pdf.sales', compact('order', 'logo'));
        $pdf->save(storage_path('/sales/order_' . $order->id . '.pdf'));
    }

    public function generatePDFStock($order) {
        if (!File::isDirectory(storage_path('/stock/'))) {
            File::makeDirectory(storage_path('/stock/',0777,true));
        }
        $order->load('user','product','status');
        $logo = base64_encode(file_get_contents((storage_path("/avatar/" . FacadesConfig::get('company_avatar', 'default.png')))));
        $pdf = PDF::loadView('pdf.manufacturer_stock', compact('order', 'logo'));
        $pdf->save(storage_path('/stock/manufacture_stock_' . $order->id . '.pdf'));
    }

}
