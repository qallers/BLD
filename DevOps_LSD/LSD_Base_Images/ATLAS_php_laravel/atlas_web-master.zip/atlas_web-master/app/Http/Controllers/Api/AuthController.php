<?php

namespace App\Http\Controllers\Api;

use App\Otps;
use App\User;
use Exception;
use Throwable;
use App\Config;
use App\Status;
use App\Customer;
use App\PassportClient;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Route;
use GuzzleHttp\Client as GuzzleClient;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Http\Controllers\Traits\NotificationTraits;

class AuthController extends Controller
{

    use NotificationTraits;
    /**
     * @OA\Post(
     ** path="/api/v1/login",
     *   tags={"Login"},
     *   summary="Login",
     *   operationId="login",
     *
     *   @OA\Parameter(
     *      name="username",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="password",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     **/

    public function login(\Illuminate\Http\Request $request)
    {
        $client = PassportClient::find(Config::where("key", "app_client")->first()->value)->first();
        $request->request->add([
            'grant_type' => 'password',
            'client_id' => $client->id,
            'client_secret' => $client->secret,
            'username' => $request->username,
            'password' => $request->password,
            'scope' => '*',

        ]);


        $http = new \GuzzleHttp\Client;

        $response = $http->post(url('/oauth/token'), [
            'form_params' => $request->all(),
            'debug' => false
        ]);
        return json_decode((string) $response->getBody(), true);
    }
    /**
     * @OA\Post(
     ** path="/api/v1/login/alternative",
     *   tags={"Login"},
     *   summary="Login",
     *   operationId="loginAlternative",
     *
     *   @OA\Parameter(
     *      name="username",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *   @OA\Parameter(
     *      name="password",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *          type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     **/

    public function login_alternative(\Illuminate\Http\Request $request)
    {
        $client = PassportClient::find(Config::where("key", "app_client")->first()->value)->first();
        $request->request->add([
            'grant_type' => 'password',
            'client_id' => $client->id,
            'client_secret' => $client->secret,
            'username' => $request->username,
            'password' => $request->password,
            'scope' => '*',

        ]);


        $tokenRequest = $request->create(
            url('/oauth/token'),
            'post'
        );

        $instance = Route::dispatch($tokenRequest);
        return json_decode((string) $instance->getContent(), true);
    }

    /**
     * @OA\Post(
     ** path="/api/v1/reset_password",
     *   tags={"Login"},
     *   summary="Reset Password",
     *   operationId="resetPassword",
     *
     *   @OA\Parameter(
     *      name="email",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     **/

    public function reset_password(\Illuminate\Http\Request $request)
    {
        $credentials = $request->validate(['email' => 'required|email']);
        Password::sendResetLink($credentials);
        return responder()->success()->respond(200);
    }

    /**
     * @OA\Post(
     ** path="/api/v1/reset_password/sms",
     *   tags={"Login"},
     *   summary="Reset Password",
     *   operationId="resetPasswordSMS",
     *
     *   @OA\Parameter(
     *      name="cust_code",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     **/

    public function reset_password_sms(\Illuminate\Http\Request $request)
    {
        $min = str_pad(1, 6, 0);
        $max = str_pad(9, 6, 9);
        $otp = random_int($min, $max);
        $customer = Customer::whereCustCode($request->cust_code)->first();
        if (!empty($customer->id))
        {
            if (!$customer->contacts[0]->cell_no)
            {
                return responder()->error(500,"No mobile number registered.")->respond(500);
            }
            $user = User::find($customer->user_id);
            $mobile = $customer->contacts[0]->cell_no;
        }
        else
        {
            return responder()->error(500,"Customer not found")->respond(500);
            //$user = User::whereUsername($request->cust_code);
            //$mobile = $user->contacts[0]->cell_no;
        }

        if (empty($user->id))
        {
            return responder()->error(500,"No User associated with this account.")->respond(500);
        }
        $user->password = bcrypt($otp);
        $user->save();
        $t = $this->sendSMS($mobile, "Your new password is : " . $otp . "\n\nDo not share it with anyone.");
        return responder()->success()->respond(200);
    }

    /**
     * @OA\Post(
     ** path="/api/v1/reset_password/verify",
     *   tags={"Login"},
     *   summary="Reset Password",
     *   operationId="resetPasswordVerify",
     *
     *   @OA\Parameter(
     *      name="mobile",
     *      in="query",
     *      required=true,
     *      @OA\Schema(
     *           type="string"
     *      )
     *   ),
     *   @OA\Response(
     *      response=200,
     *       description="Success",
     *      @OA\MediaType(
     *           mediaType="application/json",
     *      )
     *   ),
     *   @OA\Response(
     *      response=401,
     *       description="Unauthenticated"
     *   ),
     *   @OA\Response(
     *      response=400,
     *      description="Bad Request"
     *   ),
     *   @OA\Response(
     *      response=404,
     *      description="not found"
     *   ),
     *      @OA\Response(
     *          response=403,
     *          description="Forbidden"
     *      )
     *)
     **/

    public function reset_password_verify(\Illuminate\Http\Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile' => 'required',
            'otp' => 'required',
            'password' => 'required',
            'username' => 'required'
        ]);

        if ($validator->fails())
        {
            return responder()->error(400, "vaidation_error")->data(['data' => $validator->errors()])->respond(400);
        }
        $otp = Otps::whereMobile($request->mobile)
            ->whereOtp($request->otp)->count();
        if ($otp > 0)
        {
            $user = User::whereUsername($request->username)->first();
            if ($user->id)
            {
                $user->password = bcrypt($request->password);
                $user->save();
                return responder()->success("Your password has been updated.")->respond(200);
            }
            else
            {
                return responder()->error("No user has been found.")->respond(500);
            }
        }
        else
        {
            return responder()->error("Otp doesn't match")->respond(500);
        }
    }

    /**
     *  @OA\Post(
     *      path="/api/v1/forgotPassword",
     *      operationId="forgotPassword",
     *      tags={"Login"},
     *      summary="Multi-Channel Forgot Password Service",
     *      description="Multi-Channel Forgot Password Service",
     *      @OA\Parameter(
     *          name="username",
     *          in="query",
     *          required=true,
     *          @OA\Schema(
     *              type="string"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="password_reset_channel_id",
     *          in="query",
     *          required=true,
     *          @OA\Schema(
     *              type="string"
     *          )
     *      ), 
     *      @OA\Response(
     *          response=200,
     *          description="OK",
     *          )
     *      ),
     *      @OA\Response(
     *          response=500,
     *          description="Unexpected Error",
     *      ),
     *  )
     **/
    public function forgot_password(Request $request)
    {
        try
        {
            $validator = Validator::make($request->all(), [
                'username' => 'required',
                'password_reset_channel_id' => 'required'
            ]);

            if ($validator->fails())
            {
                return responder()->error()->respond(500);
            }

            $mailId = Status::whereProcess('password_reset_channel')->where('status', 'mail_channel')->get()->first()->id;
            $smsId = Status::whereProcess('password_reset_channel')->where('status', 'sms_channel')->get()->first()->id;

            if ($request->password_reset_channel_id == $mailId)
            {
                $email = User::whereUsername($request->username)->first()->email;
                $credentials = array("email" => $email);
                Password::sendResetLink($credentials);
                return responder()->success()->respond(200);
            }
            else if ($request->password_reset_channel_id == $smsId)
            {
                $min = str_pad(1, 6, 0);
                $max = str_pad(9, 6, 9);
                $otp = random_int($min, $max);
                $customer = Customer::whereCustCode($request->username)->first();
                if (!empty($customer->id))
                {
                    if (!$customer->contacts[0]->cell_no)
                    {
                        return responder()->success()->respond(200);
                    }
                    $user = User::find($customer->user_id);
                    $mobile = $customer->contacts[0]->cell_no;
                }
                else
                {
                    $user = User::whereUsername($request->username);
                    $mobile = $user->contacts[0]->cell_no;
                }

                if (empty($user->id))
                {
                    return responder()->success()->respond(200);
                }
                $user->password = bcrypt($otp);
                $user->save();
                $t = $this->sendSMS($mobile, "Your new password is : " . $otp . "\n\nDo not share it with anyone.");
                return responder()->success()->respond(200);
            }
        }
        catch (Throwable $e)
        {
            // Don't care.
        }
        catch (Exception $e)
        {
            // Still don't care.
        }

        return responder()->error()->respond(500);
    }

    /** 
     * @OA\Get(
     *      path="/api/v1/commsChannels",
     *      operationId="getCommsChannels",
     *      tags={"Login"},
     *      summary="Get available Forgot Password communication channels",
     *      description="Returns available channels for Forgot Password Service communication",
     * 
     *      @OA\Response(
     *          response=200,
     *          description="OK",
     *       @OA\MediaType(
     *           mediaType="application/json",
     *          )
     *       ),
     *      @OA\Response(
     *          response=500,
     *          description="Unexpected Error",
     *      ),
     *     )
     */
    public function channels(Request $request)
    {
        return responder()->success(Status::whereProcess('password_reset_channel')->get())->respond();
    }
}
