<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreUsersRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'username' => 'required|unique:users',
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email|unique:users,email',
            'roles' => 'required',
            'user_type_id' => 'required',
            'name' => 'required_if:user_type_id,2|required_if:user_type_id,4',
            'cell_no' => 'required_if:user_type_id,2|required_if:user_type_id,4',
            'identity_type_id' => 'required_if:user_type_id,2|required_if:user_type_id,4',
            'payment_method_id' => 'required_if:user_type_id,2|required_if:user_type_id,4',
            'address_line_1' => 'required_if:user_type_id,2|required_if:user_type_id,4',
            'postal_code' => 'required_if:user_type_id,2|required_if:user_type_id,4',
        ];
    }
    public function messages()
    {
        return [
            'name.required_if'   => "Contact name is required when user type is Reps or Agent.",
            'cell_no.required_if'   => "Cell no is required when user type is Reps or Agent.",
            'identity_type_id.required_if'   => "Identity type is required when user type is Reps or Agent.",
            'payment_method_id.required_if'   => "Payment method is required when user type is Reps or Agent.",
            'address_line_1.required_if'   => "Address line 1 is required when user type is Reps or Agent.",
            'postal_code.required_if'   => "Postal code is required when user type is Reps or Agent.",
        ];
    }
}
