<?php
namespace App;

use Laravel\Passport\Token;

class PassportAccessToken extends Token{
   
    protected $connection;
    public function getConnectionName()
    {
        return $this->connection;
    }
}