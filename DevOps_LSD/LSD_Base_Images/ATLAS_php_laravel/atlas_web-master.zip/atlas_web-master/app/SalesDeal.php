<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;
/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class SalesDeal extends Authenticatable {
    use LogsActivity;

    public $table = "sales_deal";

    use Notifiable;

    protected $fillable = ['id','sales_order_detail_id','ogr_tier','act_tier','sim_tier','is_tiered','is_split','split_customer','start_date','end_date','act','ogr','sim','invoice_number','customer_id','created_at','updated_at'];
    protected static $logAttributes = ['id','sales_order_detail_id','ogr_tier','act_tier','sim_tier','is_tiered','is_split','split_customer','start_date','end_date','act','ogr','sim','invoice_number','customer_id','created_at','updated_at'];
   
    
    public function SalesOrderDetails()
    {
        return $this->belongsTo('App\SalesOrderDetails','sales_order_detail_id');
    }

    public function customer()
    {
        return $this->belongsTo('App\Customer', 'customer_id');
    }
}
