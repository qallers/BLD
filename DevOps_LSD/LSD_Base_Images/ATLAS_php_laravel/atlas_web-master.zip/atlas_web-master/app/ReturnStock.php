<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class ReturnStock extends Model {

    use LogsActivity;

    public $table = "return_stock";
    protected $fillable = ['sales_order_detail_id', 'return_stock_master_id', 'serial_no', 'return_type', 'user_id', 'created_at', 'updated_at'];
    protected static $logAttributes = ['sales_order_detail_id', 'return_stock_master_id', 'serial_no', 'return_type', 'user_id', 'created_at', 'updated_at'];

    public function salesOrderDetail() {
        return $this->belongsTo('App\SalesOrderDetails', 'sales_order_detail_id');
    }

    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }

    public function returnstockmaster() {
        return $this->belongsTo('App\Returnstockmaster', 'return_stock_master_id');
    }

}
