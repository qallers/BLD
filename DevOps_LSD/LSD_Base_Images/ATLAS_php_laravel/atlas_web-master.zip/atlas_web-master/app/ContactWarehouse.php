<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\WarehouseHasContact;
use App\ContactWarehouse;
use Spatie\Activitylog\Traits\LogsActivity;

class ContactWarehouse extends Model{
    use LogsActivity;
    
    public $table= 'contact';

    //use Notifiable;

    protected $fillable = ['warehouse_id','contact_id', 'name', 'mail_address', 'tel_no', 'fax_no', 'cell_no'];
    protected static $logAttributes =  ['warehouse_id','contact_id', 'name', 'mail_address', 'tel_no', 'fax_no', 'cell_no'];
     public function warehousehascontact()
    {
        return $this->belongsToMany('App\WarehouseHasContact');
    }

    public function warehouse(){
       
        return $this->belongsToMany('App\Warehouse')->using('App\WarehouserHasContact');
    }

    public function deleteContactWithLink($contactid){
     wahouseHasContact::where('contact_id', $contactid)->delete();
    }   
 }