<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
/**
 * @property int $id
 * @property string $code
 * @property string $description
 * @property string $created_at
 * @property string $updated_at
 * @property Customer[] $customers
 */
class Group extends Model
{
    use LogsActivity;
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'group';

    /**
     * @var array
     */
    protected $fillable = ['code', 'description', 'is_active', 'created_at', 'updated_at'];
    protected static $logAttributes = ['code', 'description', 'is_active', 'created_at', 'updated_at'];
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function customers()
    {
        return $this->hasMany('App\Customer');
    }
}
