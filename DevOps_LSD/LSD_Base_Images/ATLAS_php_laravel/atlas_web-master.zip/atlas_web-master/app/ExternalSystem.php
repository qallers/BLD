<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class ExternalSystem extends Model
{
    use LogsActivity;
    public $table = "external_system";

    protected $fillable = ['description'];
    protected static $logAttributes = ['description'];
}
