<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Spatie\Activitylog\Traits\LogsActivity;

class VatConfig extends Model {

    use LogsActivity;

    public $table = "vat_config";
    protected $fillable = ['id', 'vat', 'start_date','end_date'];
    protected static $logAttributes = ['id', 'vat', 'start_date','end_date'];

}

?>
 