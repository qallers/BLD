<?php

namespace App\Jobs;

use App\Ogr;
use App\User;
use App\Config;
use App\Network;
use App\Fileconfig;
use Illuminate\Bus\Queueable;
use App\Notifications\Monthend;
use Illuminate\Support\Facades\DB;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Storage;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Http\Requests\Admin\StoreOgrRequest;
use App\Http\Controllers\Traits\NotificationTraits;

class Monthendprocess implements ShouldQueue
{

    use Dispatchable,
        InteractsWithQueue,
        Queueable,
        SerializesModels;
    use NotificationTraits;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    private $request;
    private $data;

    public function __construct($request, $data)
    {
        $this->request = $request;
        $this->data = $data;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $col = '';
        $tab = '';
        $ignoreFirstLine = '';
        $file_type = Fileconfig::where('id', $this->data['file_config_id'])->get()->first();
        $networkData = Network::where('id', $this->data['network_id'])->get()->first();
        $file_name = $this->request['file_name'];
        $rc = '';
        $t = Storage::disk('local')->path($file_type->path . '/' . $file_name);
        $a = Storage::disk('local')->path($file_type->path . '/archived' . '/' . $file_name);
        if (empty($this->request['recal']))
        {
            switch (str_replace(' ', '', strtoupper($networkData->name)))
            { //switch case for network
                case 'VODACOM':
                    { // make column and table related to network and file type for load file query
                        switch (strtoupper($file_type->filetype->slug))
                        {
                            case 'ACT':
                                $tab = 'me_vodacom_act_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',denom=@col4,serial_no=@col1,msisdn=@col3,conn_month=@col2,cust_code=@col5';
                                break;
                            case 'CON':
                                $tab = 'me_vodacom_con_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',denom=@col4,serial_no=@col1,msisdn=@col3,conn_month=@col2,cust_code=@col5';
                                break;
                            case 'DEL':
                                $tab = 'me_vodacom_del_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',serial_no=@col1,del_month=@col2';
                                break;
                            case 'OGR':
                                $tab = 'me_vodacom_ogr_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',denom=@col3,recharge_count=@col4,serial_no=@col2,msisdn=@col5,denom_duplicate=@col6,revenue_percentage=@col7,cust_code=@col8';
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                case 'MTN':
                    {
                        switch (strtoupper($file_type->filetype->slug))
                        {
                            case 'ACT':
                                $tab = 'me_mtn_act_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21,@col22,@col23,@col24,@col25,@col26,@col27,@col28,@col29,@col30,@col31,@col32,@col33,@col34,@col35,@col36,@col37,@col38,@col39,@col40) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',primary_grp=@col1,prov_first_conn=@col2,city_first_conn=@col3,customer_name=@col4,address1=@col5,province=@col6,region_name=@col7,category_set_name=@col8,cat_segment2=@col9,cat_segment3=@col10,distribution_date=@col11,msisdn=@col12,sim=@col13,serial_number=@col14,trx_number=@col15,box_serial_number=@col16,brick_serial_number=@col17,activation_date=@col18,dt_port_in=@col19,rica_date=@col20,comm_mth=@col21,usage_spent_4mths=@col22,usage_spent_7mths=@col23,voice_amt_4mths=@col24,gprsamt_4mths=@col25,total_bundle_purchase_amt_4mths=@col26,xtratime_sfee_repay_4mths=@col27,comms_category=@col28,comm_excl=@col29,vat=@col30,comm_incl=@col31,agents_company_name=@col32,officers_identity_number=@col33,officers_company_name=@col34,officers_name=@col35,flag_spend=@col36,gprs_inbundle_amt_4mths=@col37,sms_inbundle_amt_4mths=@col38,mms_inbundle_amt_4mths=@col39,voice_inbundle_amt_4mths=@col40';
                                break;
                            case 'CON':
                                $tab = 'me_mtn_con_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21,@col22,@col23,@col24,@col25,@col26,@col27,@col28,@col29,@col30,@col31,@col32,@col33,@col34) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',primary_grp=@col1,prov_first_conn=@col2,city_first_conn=@col3,customer_name=@col4,address1=@col5,province=@col6,region_name=@col7,category_set_name=@col8,description=@col9,cat_segment2=@col10,cat_segment3=@col11,distribution_date=@col12,msisdn=@col13,serial_number=@col14,trx_number=@col15,box_serial_number=@col16,brick_serial_number=@col17,activation_date=@col18,act_inc_prt=@col19,port_in_flag=@col20,usage_spent_4mths=@col21,usage_spent_7mths=@col22,list_price=@col23,selling_price=@col24,cps135_sim=@col25,comms_category=@col26,comm_excl=@col27,vat=@col28,comm_incl=@col29,agents_company_name=@col30,rica_date=@col31,officers_identity_number=@col32,officers_company_name=@col33,officers_name=@col34';
                                break;
                            case 'SWP':
                                $tab = 'me_mtn_simswap_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',primary_grp=@col1,prov_first_conn=@col2,city_first_conn=@col3,customer_name=@col4,address1=@col5,category_set_name=@col6,description=@col7,serial_number=@col8,comm_excl=@col9,vat=@col10,comm_incl=@col11,sim_flag=@col12,sim_flag_month=@col13,donor_kit_sim=@col14,donor_msisdn=@col15,donor_trans_date=@col16,customer_category_code=@col17,accumulated_usage=@col18,category=@col19,customer_number=@col20,site_use_id=@col21';
                                break;
                            case 'RETSWP':
                                $tab = 'me_mtn_simswap_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',primary_grp=@col1,sim_flag=@col2,sim_flag_month=@col3,donor_msisdn=@col4,donor_kit_sim=@col5,donor_trans_date=@col6,serial_number=@col7,customer_name=@col8,address1=@col9,customer_category_code=@col10,category_set_name=@col11,description=@col12,accumulated_usage=@col13,comm_excl=@col14,vat=@col15,comm_incl=@col16';
                                break;
                            case 'DEL':
                                $tab = 'me_mtn_del_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',primary_grp=@col1,prov_first_conn=@col2,city_first_conn=@col3,customer_name=@col4,address1=@col5,province=@col6,region_name=@col7,category_set_name=@col8,description=@col9,cat_segment2=@col10,cat_segment3=@col11,distribution_date=@col12,msisdn=@col13,serial_number=@col14,trx_number=@col15,box_serial_number=@col16,brick_serial_number=@col17,cps135_imei_number=@col18,activation_date=@col19,comm_mth=@col20,deactdte=@col21';
                                break;
                            case 'OGR':
                                $tab = 'me_mtn_ogr_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21,@col22,@col23,@col24,@col25,@col26,@col27,@col28,@col29,@col30,@col31,@col32,@col33,@col34,@col35,@col36,@col37,@col38,@col39,@col40,@col41) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',primary_grp=@col1,prov_first_conn=@col2,city_first_conn=@col3,customer_group=@col4,customer_name=@col5,address1=@col6,province=@col7,region_name=@col8,category_set_name=@col9,description=@col10,cat_segment2=@col11,cat_segment3=@col12,distribution_date=@col13,msisdn=@col14,serial_number=@col15,trx_number=@col16,box_serial_number=@col17,brick_serial_number=@col18,cps135_imei_number=@col19,activation_date=@col20,comm_mth=@col21,comms_category=@col22,comm_excl=@col23,vat=@col24,comm_incl=@col25,base=@col26,percentage=(@col27*100),revenue_mth_0=@col28,revenue_mth_1=@col29,revenue_mth_2=@col30,revenue_mth_3=@col31,total_recharge_amt=@col32,pre_loaded=@col33,flag_spend=@col34,total_bundle_purchase_amt=@col35,xtratime_sfee_repay=@col36,billdur=@col37,callcost=@col38,smscost=@col39,mmsamt=@col40,gprsamt=@col41';
                                break;
                            case 'RETAIL':
                                $tab = 'me_mtn_retail_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21,@col22,@col23,@col24,@col25,@col26) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',report_month=@col1,simFlag=@col2,simFlagMonth=@col3,simFlagQtr=@col4,msisdn=@col5,primary_grp=@col6,customer_name=@col7,activation_date=@col8,distribution_date=@col9,deactivation_date=@col10,category_set_name=@col11,cat_segment2=@col12,cat_segment3=@col13,province=@col14,region_name=@col15,serial_number=@col16,customer_number=@col17,description=@col18,store=@col19,customer_class_code=@col20,demand_class_code=@col21,comm_incl=@col22,comm_excl=@col23,vat=@col24,sim=@col25,branded_store_code=@col26';
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                case 'CELLC':
                    {
                        switch (strtoupper($file_type->filetype->slug))
                        {
                            case 'ACT':
                                $tab = 'me_cellc_act_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',denom=@col4,serial_no=@col1,msisdn=@col3,conn_month=@col2,cust_code=@col5';
                                break;
                            case 'CON':
                                $tab = 'me_cellc_con_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',denom=@col4,serial_no=@col1,msisdn=@col3,conn_month=@col2,cust_code=@col5';
                                break;
                            case 'OGR':
                                $tab = 'me_cellc_ogr_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',denom=@col3,recharge_count=@col4,serial_no=@col2,msisdn=@col5,denom_duplicate=@col6,revenue_percentage=@col7,cust_code=@col8';
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                case 'TELKOM':
                    {
                        switch (strtoupper($file_type->filetype->slug))
                        {
                            case 'ACT':
                            case 'DIRACT':
                                $tab = 'me_telkom_act_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',dealer_code=@col1,dealer_name=@col2,msisdn=@col3,iccid=@col4,imei=@col5,tariff_plan=@col6,connection_date=@col7,billing_period=@col8,commission_code=@col9,subscriber_type=@col10,commission_amount=@col11,commission_amount_excl_vat=@col12,deal_id=@col13,sub_dealer_code=@col14,comm_rocode=@col15,retail_outlet_name=@col16';
                                break;
                            case 'OGR':
                                $tab = 'me_telkom_ogr_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',dealer_code=@col1,dealer_name=@col2,msisdn=@col3,sim_seq_num=@col4,imei=@col5,connection_date=@col6,billing_period=@col7,commission_code=@col8,subscriber_type=@col9,deal_id=@col10,commissionable_amount=REPLACE(@col11, \' \', \'\'),commission_amount=@col12,commission_amount_excl_vat=@col13,commissionable_percent=@col14,sub_dealer_code=@col15,comm_rocode=@col16,retail_outlet_name=@col17';
                                break;
                            case 'DIROGR':
                                $tab = 'me_telkom_ogr_raw';
                                if (!empty($this->request['reimp']))
                                {
                                    DB::table($tab)->where('file_id', $this->request['file_id'])->delete();
                                }
                                $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16) set file_id = ' . $this->data->id . ',network_id = ' . $this->data->network_id . ',dealer_code=@col1,dealer_name=@col2,msisdn=@col3,sim_seq_num=@col4,imei=@col5,connection_date=@col6,billing_period=@col7,commission_code=@col8,subscriber_type=@col9,deal_id=@col10,commissionable_amount=REPLACE(@col11, \' \', \'\'),commission_amount=@col12,commission_amount_excl_vat=@col13,sub_dealer_code=@col14,comm_rocode=@col15,retail_outlet_name=@col16';
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                default:
                    echo json_encode(array("msg" => "No network selected or network not found"));
                    die;
            }

            $t = str_replace("\\", "/", $t);
            $t = str_replace(':', ':/', $t);

            $a = str_replace("\\", "/", $a);

            $a = str_replace(':', ':/', $a);

            //query for load file into table

            $q = 'LOAD DATA LOCAL INFILE  \'' . $t . '\'
                INTO TABLE ' . $tab . '
                FIELDS TERMINATED by \'' . $file_type['ft'] . '\' LINES TERMINATED BY \'' . $file_type['lt'] . '\' IGNORE ' . $file_type->ignore_line . ' LINES ' . $col . '';
            $q = DB::connection()->getPdo()->exec($q);
            if ($q <= 0)
            {
                return response()->json([
                    'status' => "400",
                    'msg' => "Somthing wrong, check the file format."
                ]);
            }

            if ($rc != null)
            {
                $count = DB::table($tab)
                    ->where('file_id', $this->data->id)
                    ->count();
                if ($count == $rc)
                {
                    DB::select('update me_import_file set status = 1 where id = ' . $this->data->id . '');
                    Storage::move($file_type->path . '/' . $file_name, $file_type->path . '/archived' . '/' . $file_name);
                    return response()->json([
                        'status' => "200",
                        'msg' => "File has been imported and records have been validated.",
                        "id" => $this->data->id,
                        "network_id" => $this->data->network_id
                    ]);
                }
                else
                {
                    Ogr::destroy($this->data->id);
                    DB::table($tab)
                        ->where('file_id', $this->data->id)
                        ->delete();
                    return response()->json([
                        'status' => "400",
                        'msg' => "File has been imported but there is " . $count . " records found."
                    ]);
                }
            }
            
            $q = 'update me_import_file set status = 1 where id = ' . $this->data->id . '';
            $q = DB::connection()->getPdo()->exec($q);
            Storage::move($file_type->path . '/' . $file_name, $file_type->path . '/archived' . '/' . $file_name);
        }

        if (empty($this->request['reimp']))
        {
            $fileData = Ogr::where('id', $this->data->id)->get()->first();
            $file_name = $fileData->file_name;
            $rc = 0;

            $file_type = Fileconfig::where('id', $fileData->file_config_id)->get()->first();
            $networkData = Network::where('id', $fileData->network_id)->get()->first();

            $recal = 1;

            switch (str_replace(' ', '', strtoupper($networkData->name)))
            {
                case 'VODACOM':
                    {
                        switch (strtoupper($fileData->fileconfig->filetype->slug))
                        {
                            case 'ACT':
                                DB::select('CALL MonthEndACTVodacom(' . $this->data->id . ',' . $recal . ')'); //call store procedure for file calculation
                                break;
                            case 'CON':
                                DB::select('CALL MonthEndCONVodacom(' . $this->data->id . ',' . $recal . ')');
                                break;
                            case 'DEL':
                                DB::select('CALL calculationPostProcessDel(' . $this->data->id . ',' . $recal . ',"me_vodacom_del_raw")');
                                break;
                            case 'OGR':
                                DB::select('CALL MonthEndOGRVodacom(' . $this->data->id . ',' . $recal . ')');
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                case 'MTN':
                    {
                        switch (strtoupper($fileData->fileconfig->filetype->slug))
                        {
                            case 'ACT':
                                DB::select('CALL MonthEndACTMTN(' . $this->data->id . ',' . $recal . ')');
                                break;
                            case 'RETAIL':
                                DB::select('CALL MonthEndRETAILMTN(' . $this->data->id . ',' . $recal . ')');
                                break;
                            case 'CON':
                                DB::select('CALL MonthEndCONMTN(' . $this->data->id . ',' . $recal . ')');
                                break;
                            case 'SWP':
                            case 'RETSWP':
                                DB::select('CALL MonthEndSWPMTN(' . $this->data->id . ',' . $recal . ')');
                                break;
                            case 'DEL':
                                DB::select('CALL calculationPostProcessDel(' . $this->data->id . ',' . $recal . ',"me_mtn_del_raw")');
                                break;
                            case 'OGR':
                                DB::select('CALL MonthEndOGRMTN(' . $this->data->id . ',' . $recal . ')');
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                case 'CELLC':
                    {
                        switch (strtoupper($fileData->fileconfig->filetype->slug))
                        {
                            case 'ACT':
                                DB::select('CALL MonthEndACTCELLC(' . $this->data->id . ',' . $recal . ')');
                                break;
                            case 'CON':
                                DB::select('CALL MonthEndCONCELLC(' . $this->data->id . ',' . $recal . ')');
                                break;
                            case 'OGR':
                                DB::select('CALL MonthEndOGRCELLC(' . $this->data->id . ',' . $recal . ')');
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                case 'TELKOM':
                    {
                        switch (strtoupper($fileData->fileconfig->filetype->slug))
                        {
                            case 'ACT':
                            case 'DIRACT':
                                DB::select('CALL MonthEndACTTelkom(' . $this->data->id . ',' . $recal . ')');
                                break;
                            case 'OGR':
                            case 'DIROGR':
                                DB::select('CALL MonthEndOGRTelkom(' . $this->data->id . ',' . $recal . ')');
                                break;
                            default:
                                echo json_encode(array("msg" => "No network selected or network not found"));
                                die;
                        }
                    }
                    break;
                default:
                    return response()->json([
                        'status' => "400",
                        'msg' => "No network selected or No File configuration found."
                    ]);
            }

            $sos = Config::where("key", "monthend_import_status")->first();
            if (!empty($sos->value))
            {
                $this->sendEmails($sos->value, new Monthend($fileData));
                $u = User::find($fileData->user_id);
                $u->notify(new Monthend($fileData));
            }

            return response()->json([
                'status' => "200",
                'msg' => "File has started uploading.",
                "id" => $this->data->id,
                "network_id" => $this->data->network_id
            ]);

            return response()->json([
                'status' => "200",
                'id' => $this->data->id,
                'msg' => "Month End file has been processed succesfully."
            ]);
        }
    }
}
