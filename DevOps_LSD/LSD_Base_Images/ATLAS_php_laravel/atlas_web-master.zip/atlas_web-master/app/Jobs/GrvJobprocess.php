<?php

namespace App\Jobs;

use App\Ogr;
use App\User;
use App\Config;
use App\Network;
use App\Fileconfig;
use Illuminate\Bus\Queueable;
use App\Notifications\Monthend;
use Illuminate\Support\Facades\DB;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Storage;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Http\Requests\Admin\StoreOgrRequest;
use App\Http\Controllers\Traits\NotificationTraits;
use App\Notifications\GrvProcess;
use App\PurchaseOrder;
use Illuminate\Support\Facades\Auth;
use App\StockLedger;

class GrvJobprocess implements ShouldQueue {

    use Dispatchable,
        InteractsWithQueue,
        Queueable,
        SerializesModels;
    use \App\Http\Controllers\Traits\NavisionHelperTraits;
    use NotificationTraits;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    private $request;
    private $data;
    private $id;

    public function __construct($request, $data, $id) {
        $this->request = $request;
        $this->data = $data;
        $this->id = $id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle() {
        $col = '';
        $tab = '';
        $ignoreFirstLine = '';
        $file_type = Fileconfig::where('id', $this->data['file_config_id'])->first();
        $poData = PurchaseOrder::with("product")->where("id", $this->data['purchase_order_id'])->first();
        $network_name = $poData->product->network->name;
        $file_name = $this->request['file_name'];
        $rc = '';
        $t = Storage::disk('local')->path($file_type->path . '/' . $file_name);
        $a = Storage::disk('local')->path($file_type->path . '/archived' . '/' . $file_name);
        $tab = 'grv';
        $fId = $this->data->id;
        $filePath = Storage::disk('local')->path($file_type->path . '/' . $file_name);
        if (!empty($this->request['reimp'])) {
            $filePath = Storage::disk('local')->path($file_type->path . '/archived' . '/' . $file_name);
            $fId = $this->data->id;
            DB::table('grv')->where('file_id', $this->data['file_id'])->delete();
        }

        if (file_exists($filePath)) { //check if file exist
            //$this->request->merge(['file_name' => $file_name]);
            switch (str_replace(' ', '', strtoupper($network_name))) {
                case 'VODACOM': {
                        $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7) set file_id = ' . $fId . ',purchase_order_id = ' . $this->data['purchase_order_id'] . ',serial_no=@col1,brick=@col2,file_date=@col6';
                    }
                    break;
                case 'CELLC': {
                        $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7) set file_id = ' . $fId . ',purchase_order_id = ' . $this->data['purchase_order_id'] . ',pallet = SPLIT_STRING(@col2,"-",1),carton = concat(pallet,"-",SPLIT_STRING(@col2,"-",2)),box = concat(carton,"-",SPLIT_STRING(@col2,"-",3)),brick = concat(box,"-",SPLIT_STRING(@col2,"-",4)),serial_no=@col1,file_date=@col6';
                    }
                    break;
                case 'MTN': {
                        $col .= '(@col1,@col2,@col3,@col4,@col5) set file_id = ' . $fId . ',purchase_order_id = ' . $this->data['purchase_order_id'] . ',serial_no=@col1,alt_serial_no=@col3,box=@col4,brick=REPLACE(@col5, "\r", "")';
                    }
                    break;
                case 'TELKOM': {
                        $col .= '(@col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19) set file_id = ' . $fId . ',purchase_order_id = ' . $this->data['purchase_order_id'] . ',serial_no=@col8,brick=REPLACE(@col9, "\r", ""),box=@col10';
                    }
                    break;
                default:
                    echo json_encode(array("msg" => "No network selected or network not found"));
                    die;
            }

            $filePath = str_replace("\\", "/", $filePath);
            $filePath = str_replace(':', ':/', $filePath);

            //query for load file into table
            $q = 'LOAD DATA LOCAL INFILE  \'' . $filePath . '\'
                INTO TABLE ' . $tab . '
                FIELDS TERMINATED by \'' . $file_type['ft'] . '\' LINES TERMINATED BY \'' . $file_type['lt'] . '\' IGNORE ' . $file_type->ignore_line . ' LINES ' . $col . '';

            $affected = DB::connection()->getPdo()->exec($q);

            if (empty($this->request['reimp'])) {

                $q = 'update grv_import_file set status = 1,qty = ' . $affected . ' where id = ' . $this->data->id . '';
                $q = DB::connection()->getPdo()->exec($q);

                $mismatchQty = 0;
                PurchaseOrder::where('id', $this->request['purchase_order_id'])
                        ->update(['import_qty' => DB::raw('import_qty + ' . $affected)]);

                if ($affected != $poData->qty) {
                    $mismatchQty = 1;
                }
                Storage::move($file_type->path . '/' . $file_name, $file_type->path . '/archived' . '/' . $file_name);

                $sl = array();
                $sl['user_id'] = $this->id;
                $sl['order_id'] = $this->request['purchase_order_id'];
                $sl['qty'] = $affected;

                $sl['order_name'] = "PURCHASE";
                $sl['process_name'] = "import_file";

                StockLedger::create($sl);
                $order = PurchaseOrder::where("id", $this->data['purchase_order_id'])->first();
                $sos = Config::where("key", "grv_import_status")->first();
                $username = User::where("id", $this->id)->first()->username;
                if (!empty($sos->value)) {
                    $this->sendEmails($sos->value, new GrvProcess($order, $username));
                    $u = User::find($order->user_id);
                    $u->notify(new GrvProcess($order, $username));
                }
                return response()->json([
                            'status' => "200",
                            'msg' => "File has started uploading.",
                            "id" => $this->data['id'],
                            "network_id" => $poData->product->network->id,
                            "qtyMismatch" => $mismatchQty
                ]);
            } else {
                $sl = array();
                $sl['user_id'] = $this->id;
                $sl['order_id'] = $this->data['purchase_order_id'];
                $sl['qty'] = $affected;

                $sl['order_name'] = "PURCHASE";
                $sl['process_name'] = "reimport_file";

                StockLedger::create($sl);

                try {
                    $order = PurchaseOrder::find($this->data['purchase_order_id']);
                    $this->nav_patch_order("Purchase_OrderPurchLines", $order->external_reference, "10000", [
                        "Qty_to_Receive" => $affected,
                        "Qty_to_Invoice" => "0"
                    ]);
                } catch (Exception $e) {
                    
                }

                return response()->json([
                            'status' => "200",
                            'msg' => "File has been proccessed.",
                            "id" => $this->data->id,
                            "network_id" => $this->data->network_id
                ]);
            }
        } else {
            return response()->json([
                        'status' => "404",
                        'msg' => "File is not found."
            ]);
        }
    }

}
