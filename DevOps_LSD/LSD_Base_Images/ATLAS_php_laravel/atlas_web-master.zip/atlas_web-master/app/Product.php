<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class Product extends Authenticatable {

    public $table = "product";
    use LogsActivity;
    use Notifiable;

    protected $fillable = ['id', 'manufacture_id', 'description', 'product_code', 'network_id', 'product_type_id', 'supplier_id',
        'sale_price', 'cost_price', 'act_expense_code', 'ogr_expense_code', 'sim_expense_code'];
        protected static $logAttributes = ['id', 'manufacture_id', 'description', 'product_code', 'network_id', 'product_type_id', 'supplier_id',
        'sale_price', 'cost_price', 'act_expense_code', 'ogr_expense_code', 'sim_expense_code'];

    public function getFormattedPrice($a) {
        return number_format($this->attributes[$a], 2);
    }

    //////////////get network
    public function network() {
        return $this->belongsTo('App\Network', 'network_id');
    }

    public function purchaseOrder() {
        return $this->hasMany('App\PurchaseOrder', 'product_id');
    }

    ////get 
    public function supplier() {
        return $this->belongsTo('App\Supplier');
    }

    public function order() {
        return $this->hasMany('App\SalesOrderDetails', 'id');
    }

    ////get 
    public function product_type() {
        return $this->belongsTo('App\Product_Type');
    }

    public function manufacturestock() {
        return $this->belongsTo('App\ManufactureStock', 'manufacture_id');
    }

}
