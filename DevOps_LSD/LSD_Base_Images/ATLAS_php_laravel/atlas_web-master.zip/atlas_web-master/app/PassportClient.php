<?php
namespace App;
use Laravel\Passport\Client;
use Laravel\Passport\Passport;

class PassportClient extends Client{
   
    protected $connection;
    public function getConnectionName()
    {
        return $this->connection;
    }
}