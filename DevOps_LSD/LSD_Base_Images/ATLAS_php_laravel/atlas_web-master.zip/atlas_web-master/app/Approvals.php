<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Approvals extends Model
{
    use LogsActivity;
    public $table = "approvals";

    protected $fillable = ['id','name', 'process','status_id','created_at','updated_at'];
    protected static $logAttributes = ['id','name', 'process','status_id','created_at','updated_at'];

    public function stages(){
        return $this->hasMany('App\ApprovalStages','approval_id');
    }
    
}