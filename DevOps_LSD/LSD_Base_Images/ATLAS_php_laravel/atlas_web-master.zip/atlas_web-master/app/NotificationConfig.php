<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Hash;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class NotificationConfig extends Model {

    use Notifiable;
    protected $table="notification_config";

    protected $fillable = ['title','status','emails','created_at','updated_at'];
    protected static $logAttributes = ['title','status','emails','created_at','updated_at'];

    public function status_obj()
    {
        return $this->belongsTo('App\Status','status');
    }
}
