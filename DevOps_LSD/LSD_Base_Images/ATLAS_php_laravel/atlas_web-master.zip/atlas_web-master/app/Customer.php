<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Spatie\Activitylog\Traits\LogsActivity;

class Customer extends Model {

    use LogsActivity;
    public $table = "customer";
    protected $fillable = ['id', 'cust_code', 'user_id','rep_user_id', 'parent_id', 'name', 'group_id', 'identity_type_id', 'identity_reference', 'identity_reference_expiry_date', 'identity_reference_origin_country', 'vat_registered', 'vat_reg_no', 'is_active', 'status_id', 'payment_method_id'];
    protected $dates=['identity_type_expiry_date'];
    protected static $logAttributes = ['id', 'cust_code', 'user_id','rep_user_id', 'parent_id', 'name', 'group_id', 'identity_type_id', 'identity_reference', 'identity_reference_expiry_date', 'identity_reference_origin_country', 'vat_registered', 'vat_reg_no', 'is_active', 'status_id', 'payment_method_id'];
    
    public function group() {
        return $this->belongsTo('App\Group');
    }
    public function status() {
        return $this->belongsTo('App\Status')->whereProcess("new_customer");
    }
    public function customerhasaddress() {
        return $this->belongsToMany('App\CustomerHasAddress');
    }

    public function addresses() {
        return $this->hasMany('App\Address', 'customer_id')->whereAddressEntityId(Status::whereProcess("address_entity_type")->whereStatus("customer")->first()->id);
    }

    public function contacts() {
        return $this->hasMany('App\Contact', 'customer_id')->whereContactEntityId(Status::whereProcess("address_entity_type")->whereStatus("customer")->first()->id);
    }

    public function identity_type() {
        return $this->belongsTo('App\Status', 'identity_type_id')->whereProcess("identity_type");
    }

    public function payment_method() {
        return $this->belongsTo('App\Status', 'payment_method_id')->whereProcess("payment_method");
    }

     
}
