<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class Supplier extends Authenticatable {
    use LogsActivity;
    use Notifiable;

    public $table = "supplier";

    protected $fillable = ['id', 'name', 'telephone', 'email', 'account_number', 'status'];
    protected static $logAttributes =  ['id', 'name', 'telephone', 'email', 'account_number', 'status'];

    public function product() {
        return $this->hasMany('App\Product');
    }

    public function purchaseOrder() {
        return $this->hasMany('App\PurchaseOrder');
    }

    public function addresses() {
        return $this->hasMany('App\Address', 'customer_id')->whereAddressEntityId(Status::whereProcess("address_entity_type")->whereStatus("supplier")->first()->id);
    }

    public function contacts() {
        return $this->hasMany('App\Contact', 'customer_id')->whereContactEntityId(Status::whereProcess("address_entity_type")->whereStatus("supplier")->first()->id);;
    }

}
