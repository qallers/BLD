<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Grvdata extends Model {

    use LogsActivity;

    public $table = "grv";
    protected $fillable = ['id', 'file_id', 'purchase_order_id', 'serial_no', 'imsi_no', 'pallet', 'carton', 'box', 'brick', 'file_date', 'status', 'is_available', 'is_transfer'];
    protected static $logAttributes = ['id', 'file_id', 'purchase_order_id', 'serial_no', 'imsi_no', 'pallet', 'carton', 'box', 'brick', 'file_date', 'status', 'is_available', 'is_transfer'];

    public function purchaseOrder() {
        return $this->belongsTo('App\PurchaseOrder', 'purchase_order_id');
    }

    public function grv() {
        return $this->belongsTo('App\Grv', 'file_id');
    }

}
