<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class Otps extends Authenticatable {
    use LogsActivity;    
    public $table = "otps";


    protected $fillable = ['id', 'mobile', 'otp','process'];
    protected static $logAttributes = ['id', 'mobile', 'otp','process'];
    

}
