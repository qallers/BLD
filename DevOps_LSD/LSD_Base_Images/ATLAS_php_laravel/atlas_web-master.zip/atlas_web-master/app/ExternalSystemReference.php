<?php

namespace App;

use App\Http\Controllers\Traits\EncryptionTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;
use Spatie\Activitylog\Traits\LogsActivity;

class ExternalSystemReference extends Model {

    use LogsActivity;
    use EncryptionTrait;

    public $table = "external_system_reference";
    protected $fillable = ['id', 'external_system_id', 'reference', 'data', 'customer_id'];
    protected $encryptable = ['data'];
    protected $passwordField = "rica_password";
    protected static $logAttributes = ['id', 'external_system_id', 'reference', 'data', 'customer_id'];

    public function external() {
        return $this->belongsTo('App\ExternalSystem', 'external_system_id');
    }

    public function customer() {
        return $this->belongsTo('App\Customer', 'customer_id');
    }

}
