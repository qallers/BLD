<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class Fileconfig extends Model {

    use LogsActivity;

    public $table = "file_config";
    protected $fillable = ['id', 'name', 'path', 'network_id', 'file_type_id', 'ft', 'lt', 'ignore_line', 'percentage'];
    protected static $logAttributes = ['id', 'name', 'path', 'network_id', 'file_type_id', 'ft', 'lt', 'ignore_line', 'percentage'];

    public function ogr() {
        return $this->hasMany('App\Ogr', 'id');
    }

    public function filetype() {
        return $this->belongsTo('App\Filetype', 'file_type_id');
    }

    public function network() {
        return $this->belongsTo('App\Network');
    }

}
