<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property int $id
 * @property int $tier_id
 * @property int $from_cab
 * @property int $to_cab
 * @property float $ogr
 * @property float $act
 * @property float $sim
 * @property string $created_at
 * @property string $updated_at
 */
class TierStage extends Model
{
    use LogsActivity;
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'tier_stage';

    /**
     * @var array
     */
    protected $fillable = ['id', 'customer_id', 'network_id', 'from_cab', 'to_cab', 'ogr', 'act', 'sim', 'created_at', 'updated_at'];
    protected static $logAttributes =  ['id', 'customer_id', 'network_id', 'from_cab', 'to_cab', 'ogr', 'act', 'sim', 'created_at', 'updated_at'];
}
