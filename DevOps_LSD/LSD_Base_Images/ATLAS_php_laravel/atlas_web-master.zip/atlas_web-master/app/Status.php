<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class Status extends Model {
    use LogsActivity;

    public $table = "status";
    protected $fillable = ['id', 'name', 'process','status'];
    protected static $logAttributes = ['id', 'name', 'process','status'];
    
    public function SalesOrder() {
        return $this->hasMany('App\SalesOrder', 'id');
    }

    public function purchaseOrder() {
        return $this->hasMany('App\PurchaseOrder', 'id');
    }

}
