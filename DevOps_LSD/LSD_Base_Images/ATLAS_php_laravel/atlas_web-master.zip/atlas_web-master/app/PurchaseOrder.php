<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class PurchaseOrder extends Authenticatable {
    use LogsActivity;
    
    public $table = "purchase_order";

    use Notifiable;

    protected $fillable = ['id', 'supplier_id', 'warehouse_id', 'product_id','approval_id','priority', 'qty', 'supplier_invoice_number', 'external_reference', 'purchase_order_date', 'status_id', 'user_id'];
    protected static $logAttributes = ['id', 'supplier_id', 'warehouse_id', 'product_id','approval_id','priority', 'qty', 'supplier_invoice_number', 'external_reference', 'purchase_order_date', 'status_id', 'user_id'];

    public function status() {
        return $this->belongsTo('App\Status', 'status_id');
    }

    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }

    public function grv() {
        return $this->hasMany('App\Grv');
    }

    public function product() {
        return $this->belongsTo('App\Product', 'product_id');
    }

    public function supplier() {
        return $this->belongsTo('App\Supplier', 'supplier_id');
    }

    public function warehouse() {
        return $this->belongsTo('App\Warehouse', 'warehouse_id');
    }

}
