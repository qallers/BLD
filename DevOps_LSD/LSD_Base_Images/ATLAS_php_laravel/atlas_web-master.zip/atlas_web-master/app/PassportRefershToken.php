<?php
namespace App;

use Laravel\Passport\RefreshToken;

class PassportRefershToken extends RefreshToken{

    protected $connection;
    public function getConnectionName()
    {
        return $this->connection;
    }
}