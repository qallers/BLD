<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class Filetype extends Model {
    use LogsActivity;

    public $table = "file_type";
    protected $fillable = ['id', 'type','slug'];
    protected static $logAttributes = ['id','type','slug'];
    

    public function fileconfig() {
        return $this->hasMany('App\Fileconfig','id');
    }

    

}
