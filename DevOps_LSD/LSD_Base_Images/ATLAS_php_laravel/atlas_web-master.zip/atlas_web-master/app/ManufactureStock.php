<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class ManufactureStock extends Authenticatable {
    use LogsActivity;
    use Notifiable;

    public $table = "manufacture_stock";
    
    protected $fillable = ['id', 'product_id', 'description', 'product_code', 'qty', 'sale_price', 'cost_price', 'approval_id', 'priority', 'user_id'];
    protected static $logAttributes =  ['id', 'product_id', 'description', 'product_code', 'qty', 'sale_price', 'cost_price', 'approval_id', 'priority', 'user_id'];

    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }

    public function product() {
        return $this->belongsTo('App\Product', 'product_id');
    }

    public function status() {
        return $this->belongsTo('App\Status', 'status_id');
    }

}
