<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class StockLedger extends Model {
    use LogsActivity;
    
    public $table = "stock_ledger";
    protected $primaryKey = 'id';
    protected $fillable = ['id', 'order_name', 'process_name', 'order_id', 'qty', 'status_id', 'user_id', 'customer_id','barcode'];
    protected static $logAttributes = ['id', 'order_name', 'process_name', 'order_id', 'qty', 'status_id', 'user_id', 'customer_id','barcode'];


    public function purchaseOrder() {
        return $this->belongsTo('App\PurchaseOrder', 'order_id');
    }

    public function saleOrder() {
        return $this->belongsTo('App\SalesOrder', 'order_id');
    }

    public function status() {
        return $this->belongsTo('App\Status', 'status_id');
    }

    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }

}
