<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Ogr extends Model {

    use LogsActivity;

    public $table = "me_import_file";
    protected $fillable = ['id', 'user_id', 'file_name', 'process_month', 'network_id', 'file_config_id'];
    protected static $logAttributes = ['id', 'user_id', 'file_name', 'process_month', 'network_id', 'file_config_id'];

    public function network() {
        return $this->belongsTo('App\Network', 'network_id');
    }

    public function fileconfig() {
        return $this->belongsTo('App\Fileconfig', 'file_config_id');
    }

}
