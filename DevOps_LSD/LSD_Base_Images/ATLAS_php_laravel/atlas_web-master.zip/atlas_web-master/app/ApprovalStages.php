<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Models\Role;
use Spatie\Activitylog\Traits\LogsActivity;

class ApprovalStages extends Model
{
    use LogsActivity;
    public $table = "approval_stages";

    protected $fillable = ['id','approval_id', 'name','priority','status','created_at','updated_at'];
    protected static $logAttributes = ['id','approval_id', 'name','priority','status','created_at','updated_at'];

    public function approved_by()
    {
        return $this->hasMany("App\StagesRoles","stage_id");
    }
}