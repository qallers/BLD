<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property int $id
 * @property int $product_id
 * @property int $customer_group_id
 * @property float $ogr
 * @property float $sim
 * @property float $act
 * @property string $start_date
 * @property string $end_date
 * @property string $created_at
 * @property string $updated_at
 */
class ProductDeal extends Model
{
    use LogsActivity;
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'product_deal';

    /**
     * @var array
     */
    protected $fillable = ['product_id','name','customer_id', 'customer_group_id', 'ogr', 'sim', 'act', 'start_date', 'end_date', 'created_at', 'updated_at'];
    protected static $logAttributes = ['product_id','name','customer_id', 'customer_group_id', 'ogr', 'sim', 'act', 'start_date', 'end_date', 'created_at', 'updated_at'];
    
    protected $dates=['start_date','end_date'];


    public function product()
    {
        return $this->belongsTo('App\Product', 'product_id');
    }

    public function group()
    {
        return $this->belongsTo('App\Group', 'customer_group_id');
    }
    public function customer()
    {
        return $this->belongsTo('App\Customer', 'customer_id');
    }
}
