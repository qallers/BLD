<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Grv extends Model {

    use LogsActivity;

    public $table = "grv_import_file";
    protected $fillable = ['id', 'purchase_order_id', 'file_config_id', 'supplier_invoice_id', 'file_name', 'qty'];
    protected static $logAttributes = ['id', 'purchase_order_id', 'file_config_id', 'supplier_invoice_id', 'file_name', 'qty'];

    public function purchaseOrder() {
        return $this->belongsTo('App\PurchaseOrder', 'purchase_order_id');
    }
    
    public function fileconfig() {
        return $this->belongsTo('App\Fileconfig', 'file_config_id');
    }

}
