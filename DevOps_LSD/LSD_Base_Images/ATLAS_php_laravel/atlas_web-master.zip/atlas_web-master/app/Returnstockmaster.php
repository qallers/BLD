<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Returnstockmaster extends Model {
    use LogsActivity;
    
    public $table = "return_stock_master";

    use Notifiable;

    protected $fillable = ['id', 'customer_id', 'user_id', 'box_ids', 'box_type', 'status_id', 'priority', 'approval_id', 'created_at', 'updated_at'];
    protected static $logAttributes = ['id', 'customer_id', 'user_id', 'box_ids', 'box_type', 'status_id', 'priority', 'approval_id', 'created_at', 'updated_at'];

    public function status() {
        return $this->belongsTo('App\Status', 'status_id');
    }

    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }

    public function customer() {
        return $this->belongsTo('App\Customer', 'customer_id');
    }

}
