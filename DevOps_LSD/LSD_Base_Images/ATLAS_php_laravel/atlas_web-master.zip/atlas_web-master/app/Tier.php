<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
/**
 * @property int $id
 * @property string $name
 * @property string $created_at
 * @property string $updated_at
 */
class Tier extends Model
{
    use LogsActivity;
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'tier';

    /**
     * @var array
     */
    protected $fillable = ['id', 'name', 'created_at', 'updated_at'];
    protected static $logAttributes =  ['id', 'name', 'created_at', 'updated_at'];
}
