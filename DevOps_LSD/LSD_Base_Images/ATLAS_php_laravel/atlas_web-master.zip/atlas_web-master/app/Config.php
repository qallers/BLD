<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Config extends Model
{
    use LogsActivity;
    public $table = "config";

    protected $fillable = ['key', 'value','description'];
    protected static $logAttributes = ['key', 'value','description'];

}
