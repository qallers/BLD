<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Stock extends Model {
    use LogsActivity;
    
    public $table = "stock";
    protected $primaryKey = 'serial_no';
    protected $fillable = ['serial_no', 'network_id', 'product_id', 'box_id', 'customer_id', 'sales_order_detail_id', 'warehouse_id'];
    protected $casts = ['serial_no' => 'string'];
    protected static $logAttributes = ['serial_no', 'network_id', 'product_id', 'box_id', 'customer_id', 'sales_order_detail_id', 'warehouse_id'];

    public function network() {
        return $this->belongsTo('App\Network', 'network_id');
    }

    public function product() {
        return $this->belongsTo('App\Product', 'product_id');
    }

    public function grvData() {
        return $this->belongsTo('App\Grvdata','serial_no','serial_no');
    }

    public function customer() {
        return $this->belongsTo('App\Customer', 'customer_id');
    }

    public function salesOrderDetail() {
        return $this->belongsTo('App\SalesOrderDetails', 'sales_order_detail_id');
    }

    public function warehouse() {
        return $this->belongsTo('App\Warehouse', 'warehouse_id');
    }

    public function box() {
        return $this->belongsTo('App\Box', 'box_id');
    }   
}
