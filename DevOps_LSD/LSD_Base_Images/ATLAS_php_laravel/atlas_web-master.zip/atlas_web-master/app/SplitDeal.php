<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class SplitDeal extends Authenticatable {
    use LogsActivity;
    
    public $table = "split_deal";

    protected $dates=['start_date','end_date'];

    protected $fillable = ['id', 'customer_id', 'product_id','product_deal_id','name','start_date','end_date'];
    protected static $logAttributes = ['id', 'customer_id', 'product_id','product_deal_id','name','start_date','end_date'];

    public function customer() {
        return $this->belongsTo('App\Customer', 'customer_id');
    }

    public function product()
    {
        return $this->belongsTo('App\Product','product_id');
    }

}
