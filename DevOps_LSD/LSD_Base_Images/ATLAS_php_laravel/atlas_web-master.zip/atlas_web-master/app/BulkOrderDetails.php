<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class BulkOrderDetails  extends Model{
    use LogsActivity;
    
    public $table = "bulk_order_details";
  
    protected $fillable = ['id', 'customer_id','parent_id','user_id','qty','payment_status_id','delivery_method_id','warehouse_id','bill_to_headoffice','deliver_to_headoffice','price', 'product_id', 'product_deal', 'split_deal_id', 'order_id'];
    protected static $logAttributes = ['id', 'customer_id','parent_id','user_id','qty','payment_status_id','delivery_method_id','warehouse_id','bill_to_headoffice','deliver_to_headoffice','price', 'product_id', 'product_deal', 'split_deal_id', 'order_id'];

    public function customer()
    {
        return $this->belongsTo('App\Customer', 'customer_id', 'id');
    }
    public function product()
    {
        return $this->belongsTo('App\Product', 'product_id', 'id');
    }

}
