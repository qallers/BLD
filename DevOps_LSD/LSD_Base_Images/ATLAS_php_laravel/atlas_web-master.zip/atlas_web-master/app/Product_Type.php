<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class Product_Type extends Authenticatable {
    use LogsActivity;
    
    public $table = "product_type";

    use Notifiable;

    protected $fillable = ['id','name', 'is_active', 'created_at', 'updated_at'];
    protected static $logAttributes = ['id','name', 'is_active', 'created_at', 'updated_at'];

    public function product()
    {
        return $this->hasMany('App\Product');
    }
    

}
