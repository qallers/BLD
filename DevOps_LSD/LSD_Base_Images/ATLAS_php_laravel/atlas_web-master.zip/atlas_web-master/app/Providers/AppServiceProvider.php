<?php

namespace App\Providers;

use App\PassportAccessToken;
use App\Tenant;
use Exception;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Laravel\Passport\Passport;
use App\PassportClient;
use App\PassportRefershToken;
use koolreport\laravel\LaravelDataSource;
use Stancl\Tenancy\Events\TenancyBootstrapped;
use Stancl\Tenancy\Middleware\InitializeTenancyByDomain;
use Stancl\Tenancy\Middleware\InitializeTenancyByDomainOrSubdomain;
use Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains;
use Illuminate\Support\Facades\Blade;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        
       
        Schema::defaultStringLength(191);
        Event::listen(TenancyBootstrapped::class, function (TenancyBootstrapped $event) {
            \Spatie\Permission\PermissionRegistrar::$cacheKey = 'spatie.permission.cache.tenant.' . $event->tenancy->tenant->id;
            $db=Config::get('database');
            
            try{
                $mail = \App\Config::whereIn("key",["smtp_host","company_name","company_avatar","company_email","company_address","smtp_port","smtp_username","smtp_password","smtp_from","smtp_fromname"])
                ->select("value","key")->get()->pluck('value','key');
                Config::set('company_name', $mail['company_name']);
                Config::set('company_avatar', $mail['company_avatar']);
                Config::set('company_email', $mail['company_email']);
                Config::set('company_address', $mail['company_address']);
                if ($mail) //checking if table is not empty
                {
                    $config = array(
                        'driver'     => "smtp",
                        'host'       => empty($mail["smtp_host"])?"":$mail["smtp_host"],
                        'port'       => empty($mail["smtp_port"])?"":$mail["smtp_port"],
                        'from'       => array('address' => $mail["smtp_from"], 'name' => $mail["smtp_fromname"]),
                        'username'   => empty($mail["smtp_username"])?"":$mail["smtp_username"],
                        'password'   =>   empty($mail["smtp_password"])?"":$mail["smtp_password"]
                    );
                    Config::set('mail', $config);
                }
                $app = App::getInstance();
                $app->register('Illuminate\Mail\MailServiceProvider',true);
                $app->register('Laravel\Passport\PassportServiceProvider',true);
               
            }catch(Exception $e){
                //dd($e);
            }
            
        });
        Blade::directive('money', function ($amount) {
            return "<?php echo number_format (((float)$amount), 2); ?>";
        });

    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
        Passport::ignoreMigrations();
        Passport::useClientModel(PassportClient::class);
        Passport::useTokenModel(PassportAccessToken::class);
        Passport::useRefreshTokenModel(PassportRefershToken::class);
        Passport::routes(function ($router) {
            $router->forAuthorization();
            $router->forAccessTokens();
            $router->forTransientTokens();
            $router->forClients();
            $router->forPersonalAccessTokens();
            Passport::loadKeysFrom(storage_path(""));
            
        }, ['middleware' => InitializeTenancyByDomainOrSubdomain::class]);

    }
}
