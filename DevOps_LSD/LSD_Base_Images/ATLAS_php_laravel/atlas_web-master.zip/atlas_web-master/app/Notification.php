<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Hash;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class Notification extends Model {

    use LogsActivity;
    use Notifiable;
    protected $table="notification";

    protected $fillable = ['from_user','to_user','title','message', 'is_read', 'url', 'type','created_at','updated_at'];
    protected static $logAttributes = ['from_user','to_user','title','message', 'is_read', 'url', 'type','created_at','updated_at'];

    public function user()
    {
        return $this->belongsTo('App\User','from_user');
    }
    public function to()
    {
        return $this->hasMany('App\User', 'to_user');
    }
}
