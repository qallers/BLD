<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * 
 */
class Mecreditnote extends Authenticatable {
    use LogsActivity;
    
    public $table = 'me_credit_note';

    use Notifiable;

    protected $fillable = ['id', 'network_id', 'process_month'];
    protected static $logAttributes = ['id', 'network_id', 'process_month'];
    
    public function network() {
        return $this->belongsTo('App\Network', 'network_id');
    }

}
