<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Spatie\Activitylog\Traits\LogsActivity;

class Warehouse extends Model {
    use LogsActivity;
    
    public $table = "warehouse";
    protected $fillable = ['id', 'warehouse_type_id', 'description', 'warehouse_code', 'created_at', 'updated_at'];
    protected static $logAttributes =  ['id', 'warehouse_type_id', 'description', 'warehouse_code', 'created_at', 'updated_at'];

    public function warehousehasaddress() {
        return $this->belongsToMany('App\WarehouseHasAddress');
    }

    public function user() {
        return $this->belongsTo('App\User','id','warehouse_id');
    }

    public function addresses() {
        return $this->hasMany('App\Address', 'customer_id')->whereAddressEntityId(Status::whereProcess("address_entity_type")->whereStatus("warehouse")->first()->id);
    }

    public function contacts() {
        return $this->hasMany('App\Contact', 'customer_id')->whereContactEntityId(Status::whereProcess("address_entity_type")->whereStatus("warehouse")->first()->id);
    }
}
