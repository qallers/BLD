<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;
/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class BulkOrder extends Authenticatable {
    use LogsActivity;
    use Notifiable;

    public $table = "bulk_order";
   
    protected $fillable = ['id', 'customer_id', 'warehouse_id', 'user_id', 'payment_status_id', 'delivery_method_id','product_id','qty','price'];
    protected static $logAttributes = ['id', 'customer_id', 'warehouse_id', 'user_id', 'payment_status_id', 'delivery_method_id','product_id','qty','price'];

   

   



}
