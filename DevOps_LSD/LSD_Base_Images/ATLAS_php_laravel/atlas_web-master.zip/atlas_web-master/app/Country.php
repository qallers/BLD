<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class Country extends Model {
    use LogsActivity;

    public $table = "country";
    protected $fillable = ['id', 'NAME', 'abv', 'abv3', 'alt', 'CODE', 'slug'];
    protected static $logAttributes =['id', 'NAME', 'abv', 'abv3', 'alt', 'CODE', 'slug'];
  
    
 

    

}
