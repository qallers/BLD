<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class BaseSummary extends Model {
    use LogsActivity;
    use Notifiable;

    public $table = "base_summary";
    protected $fillable = [	"customer_id",	"rep_month",	"network_id",	"product_id",	"sales_qty","rev_income",	"rev_expense"	,"conn_qty",	"comm_qty",	"swp_qty",	"del_qty",	"opening_balance",	"closing_balance",	"percentage_vabs",	"active_base",	"comm_income",	"comm_expense",	"swp_income",	"swp_expense",	"sales_income",	"cost_of_sales",	"total_recharge"];
    protected static $logAttributes = [	"customer_id",	"rep_month",	"network_id",	"product_id",	"sales_qty","rev_income",	"rev_expense"	,"conn_qty",	"comm_qty",	"swp_qty",	"del_qty",	"opening_balance",	"closing_balance",	"percentage_vabs",	"active_base",	"comm_income",	"comm_expense",	"swp_income",	"swp_expense",	"sales_income",	"cost_of_sales",	"total_recharge"];

   

   
    
}
