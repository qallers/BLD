<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Company extends Model
{
    use LogsActivity;
    public $table = "company";
   
    protected $fillable = ['name', 'value'];
    protected static $logAttributes =['name', 'value'];
}
