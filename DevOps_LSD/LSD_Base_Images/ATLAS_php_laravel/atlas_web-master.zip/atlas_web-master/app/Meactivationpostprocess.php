<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Meactivationpostprocess extends Model {

    use LogsActivity;

    public $table = "me_act_post_process";
    protected $fillable = ['id', 'file_id', 'customer_id', 'network_id', 'invoice_number', 'sales_order_detail_id', 'product_id', 'serial_no', 'income', 'expense'];
    protected static $logAttributes =  ['id', 'file_id', 'customer_id', 'network_id', 'invoice_number', 'sales_order_detail_id', 'product_id', 'serial_no', 'income', 'expense'];

    public function network() {
        return $this->belongsTo('App\Network', 'network_id');
    }

    public function ogr() {
        return $this->belongsTo('App\Ogr', 'file_id');
    }

    public function customer() {
        return $this->belongsTo('App\Customer', 'customer_id');
    }

    public function Salesorderdetail() {
        return $this->belongsTo('App\SalesOrderDetails', 'sales_order_detail_id');
    }

    public function product() {
        return $this->belongsTo('App\Product', 'product_id');
    }

}
