<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Auth;

class Monthend extends Notification {

    use Queueable;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    protected $order;

    public function __construct($order) {
        $this->order = $order;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable) {
        if (config('app.debug')) {
            return ['database'];
        } else {
            return ['mail', 'database'];
        }
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable) {
        return (new MailMessage)
                        ->line('Your File(' . $this->order->file_name . ') has been imported.')
                        ->action('View File', url('/admin/ogr/' . $this->order->id))
                        ->line('Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable) {
        return [
            'title' => "New MonthEnd File imported.",
            "message" => 'Your File(' . $this->order->file_name . ') has been imported.',
            "id" => $this->order->id,
            "link" => url('/admin/ogr/' . $this->order->id),
            "type" => "monthend_file_imported"
        ];
    }

}
