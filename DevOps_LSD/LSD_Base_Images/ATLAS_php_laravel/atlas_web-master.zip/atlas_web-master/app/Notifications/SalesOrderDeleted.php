<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Auth;

class SalesOrderDeleted extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    protected $order;
    public function __construct($order)
    {
        $this->order=$order;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        if(config('app.debug')){
            return ['database'];   
        }else{
            return ['mail','database'];
        }
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->greeting("Hello! ")
                    ->line("Sales Order for ".$this->order->customer->name." marked as deleted by ".Auth::user()->username)
                    ->action('View Order', url('/order/sales/'.$this->order->id))
                    ->line('Thank you for using our application!')
                    ->attach(storage_path("sales/order_".$this->order->id.".pdf"), [
                        'as' => "sales_order_".$this->order->id.".pdf",
                        'mime' => 'text/pdf',
                    ]);;
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'title'=>"Deleted order #".$this->order->id."",
            "message"=>"Sales Order for ".$this->order->customer->name." marked as deleted by ".Auth::user()->username,
            "id"=>$this->order->id,
            "link"=>url('/order/sales/'.$this->order->id),
            "type"=>"sales_order_deleted"
        ];
    }
}
