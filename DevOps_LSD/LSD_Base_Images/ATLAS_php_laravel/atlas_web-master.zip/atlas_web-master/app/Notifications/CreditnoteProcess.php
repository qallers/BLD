<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Auth;

class CreditnoteProcess extends Notification {

    use Queueable;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    protected $order;

    public function __construct($order) {
        $this->order = $order;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable) {
        if (config('app.debug')) {
            return ['database'];
        } else {
            return ['mail', 'database'];
        }
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable) {
        return (new MailMessage)
                        ->line('Credit Note File for ' . $this->order->network . ' has been generated. You can downlaod from here')
                        ->action('View File', url('/admin/creditnote/'))
                        ->line('Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable) {
        return [
            'title' => "New Credit Note File generated.",
            "message" => Auth::user()->username . " generated file for you.",
            "link" => url('/admin/creditnote/'),
            "type" => "creditnote"
        ];
    }

}
