<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;
/**
 * Class User
 *
 * 
 */
class Network extends Authenticatable {
    use LogsActivity;
    use Notifiable;

    public $table = 'network';

    protected $fillable = ['id', 'name'];
    protected static $logAttributes =['id', 'name'];

    public function product() {
        return $this->hasMany('App\Product', 'product_id');
    }

    public function stock() {
        return $this->hasMany('App\Stock', 'network_id');
    }

}
