<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;


class CustomerHasContact extends Model {
    use LogsActivity;

    public $table = "customer_has_contact";

    protected $fillable = ['customer_id','contact_id'];
    protected static $logAttributes =['customer_id','contact_id'];

public function customer()
{
    return $this->hasMany('App\Customer');
}
}