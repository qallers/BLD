<?php

namespace App\Reports;

class CustomerAjax extends Dbsetting
{

    use \koolreport\laravel\Friendship;
    use \koolreport\inputs\Bindable;
    use \koolreport\inputs\POSTBinding;

    protected function defaultParamValues()
    {
        return array(
            "group" => array(),
            "customer" => array(),
        );
    }

    protected function bindParamsToInputs()
    {
        return array(
            "group",
            "customer"
        );
    }

    function settings()
    {
        return array(
            "dataSources" => array(
                "tenantDB" => $this->db(),
            ),
        );
    }

    function setup()
    {
        $this->src("tenantDB")->query("
            SELECT id,code from `group`
        ")->pipe($this->dataStore("group"));

        if (!empty($this->params["group"]))
        {
            $this->src("tenantDB")->query(
                "SELECT id
                    ,CONCAT('(', cust_code, ') - ', `name`) AS `name` 
                    FROM customer
                    WHERE group_id IN (:group)
                    ORDER BY CONCAT('(', cust_code, ') - ', `name`)"
            )->params(array(
                ":group" => $this->params["group"],
            ))->pipe($this->dataStore("customer"));
        }
    }
}
