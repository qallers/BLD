<?php

namespace App\Reports;

class ProductAjax extends Dbsetting
{
    use \koolreport\laravel\Friendship;
    use \koolreport\inputs\Bindable;
    use \koolreport\inputs\POSTBinding;

    protected function defaultParamValues()
    {
        return array(
            "network" => array(),
        );
    }

    protected function bindParamsToInputs()
    {
        return array(
            "network"
        );
    }

    function settings()
    {
        return array(
            "dataSources" => array(
                "tenantDB" => $this->db(),
            ),
        );
    }

    function setup()
    {
        $this->src("tenantDB")->query(
            "SELECT id
                ,`name`
                FROM `network`
                ORDER BY `name`"
        )->pipe($this->dataStore("network"));

        if (!empty($this->params["network"]))
        {
            $this->src("tenantDB")->query(
                "SELECT id
                    ,product_code
                    FROM product
                    WHERE network_id IN (:network)
                    ORDER BY product_code"
            )->params(array(
                ":network" => $this->params["network"],
            ))->pipe($this->dataStore("product"));
        }
    }
}
