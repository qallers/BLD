<?php

use \koolreport\inputs\Select2;
?>

<div class="col-md-12 form-group">
    <strong>Select Network</strong>
    <?php
    Select2::create(array(
        "name" => "network",
        "multiple" => true,
        "dataStore" => $this->dataStore("network"),
        "defaultOption" => array("--" => null),
        "dataBind" => array(
            "text" => "name",
            "value" => "id",
        ),
        "clientEvents" => array(
            "change" => "function(){
                 subReport.update('productAjax',{
                    network:$('#network').val(),
                    _token: '" . csrf_token() . "'
                });
            }",
        ),
        "attributes" => array(
            "class" => "form-control",
            "size" => 5
        )
    ));
    ?>
</div>  
<?php
if ($this->params["network"]) {
    ?>
    <div class="col-md-12 form-group">
        <strong>Select Product</strong>
        <?php
        Select2::create(array(
            "name" => "product",
            "multiple" => true,
            "dataStore" => $this->dataStore("product"),
            "dataBind" => array(
                "text" => "product_code",
                "value" => "id",
            ),
            "attributes" => array(
                "class" => "form-control",
                "size" => 5
            )
        ));
        ?>
    </div>   
<?php }
?>
