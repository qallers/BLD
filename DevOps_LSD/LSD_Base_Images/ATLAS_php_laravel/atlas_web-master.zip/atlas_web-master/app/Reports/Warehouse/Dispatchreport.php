<?php

namespace App\Reports\Warehouse;

use \koolreport\processes\ColumnMeta;
use \koolreport\pivot\processes\Pivot;
use App\Reports\CustomerAjax;
use App\Reports\ProductAjax;
use App\Reports\Dbsetting;

class Dispatchreport extends Dbsetting 
{
    use \koolreport\laravel\Friendship;
    use \koolreport\inputs\Bindable;
    use \koolreport\inputs\POSTBinding;
    use \koolreport\export\Exportable;
    use \koolreport\excel\ExcelExportable;
    use \koolreport\core\SubReport;

    function settings()
    { 
            return array(
                "dataSources" => array(
                    "tenantDB" => $this->db(),
                ),
          );
    }

    protected function defaultParamValues()
    {

        return array(
            "customer" => array(),
            "product" => array(),
            "start_date" => date('Y-m-d'),
            "end_date" => date('Y-m-d')
        );
    }

    protected function bindParamsToInputs()
    {
        return array(
            "customer",
            "product",
            "start_date",
            "end_date"
        );
    }

    function setup()
    {
    
            $this->src('tenantDB')->query(
            "SELECT t1.id 'Order Number',t5.cust_code 'Customer Code', t5.name 'Customer Name',
             t4.name 'Network',t3.product_code 'Product Code',t2.qty 'QTY',t2.invoice_number 'Invoice',t6.name ' Status',DATE_FORMAT(t1.created_at,'%Y-%m-%d') 'Dispatch Date' 
             FROM sales_order t1
             LEFT JOIN sales_order_detail t2 ON t1.id = t2.sales_order_id
             LEFT JOIN product t3 ON t2.product_id = t3.id
             LEFT JOIN network t4 ON t3.network_id = t4.id
             LEFT JOIN customer t5 ON t5.id = t1.customer_id
             LEFT JOIN status t6 ON t6.id = t1.status_id
             WHERE t2.is_dispatch='1' AND "
              . (($this->params["customer"] != array()) ? "t5.id IN (:customer) AND " : "")
              . (($this->params["product"] != array()) ? "t2.product_id IN (:product) AND " : "")
              . "date(t1.created_at) BETWEEN :start_date AND :end_date order by t1.id desc"
              

        ) ->params(array(
                    ":customer" => $this->params["customer"],
                    ":product" => $this->params["product"],
                    ":end_date" => $this->params["end_date"],
                    ":start_date" => $this->params["start_date"]
                ))
                ->pipe($this->dataStore("sales"));

              $this->src("tenantDB")->query("
                SELECT id, name from customer
              ")
                ->pipe($this->dataStore("customer"));
                $this->src("tenantDB")->query("
                  SELECT id, product_code from product
                ")
                ->pipe($this->dataStore("product"));
    }
}
