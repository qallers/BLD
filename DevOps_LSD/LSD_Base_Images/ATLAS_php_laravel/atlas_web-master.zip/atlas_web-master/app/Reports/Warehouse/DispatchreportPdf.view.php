<?php

use \koolreport\widgets\koolphp\Table;
 use \koolreport\pivot\widgets\PivotTable;
?>
<div class="report-content">
    <div class="text-center">
        <h1>Dispatch Report </h1>
    </div>
    <div class="page-header" style="text-align:right"><i>Dispatch Report</i></div>
         <div class="page-header" style="text-align:left"><i> <?php echo date("Y-m-d H:i:s"); ?></i></div>
         
        <hr/>

        <?php 
                            Table::create(array(
								"dataStore"=>$this->dataStore("sales"),
								"showHeader"=>true,
								"cssClass"=>array(
									"table"=>"table table-bordered"
								), "columns" => array(
                                        "Order Number" => array(
                                            "label" => "Order Number",
                                            "type" => "string"
                                        ),
                                        "Customer Code" => array(
                                            "label" => "Customer Code",
                                            "type" => "string"
                                        ),
                                        "Customer Name" => array(
                                            "label" => "Customer Name",
                                            "type" => "string"
                                        ),
                                        "Network" => array(
                                            "label" => "Network",
                                            "type" => "string"
                                        ),
                                        "Product Code" => array(
                                            "label" => "Product Code",
                                            "type" => "string"
                                        ),
                                        "QTY" => array(
                                            "label" => "QTY",
                                            "type" => "number",
                                             
                                        ),
                                        "Invoice" => array(
                                            "label" => "Invoice",
                                            "type" => "string",
                                            
                                        ),
                                        "Status" => array(
                                            "label" => "Status",
                                            "type" => "string"
                                        ),
                                        "Dispatch Date" => array(
                                            "label" => "Dispatch Date",
                                            "type" => "string"
                                        ),
                                )
							));
					 
                    ?>
                </div>
				    </body>
</html>