<?php

namespace App\Reports\Warehouse;

use \koolreport\processes\ColumnMeta;
use \koolreport\pivot\processes\Pivot;
use App\Reports\ProductAjax;
use App\Reports\WarehouseAjax;
use Illuminate\Support\Facades\DB;

class Warehousedashboard extends \App\Reports\Dbsetting
{
    use \koolreport\export\Exportable;
    use \koolreport\excel\ExcelExportable;
    use \koolreport\core\SubReport;
    use \koolreport\laravel\Friendship;
    use \koolreport\inputs\Bindable;
    use \koolreport\inputs\POSTBinding;

    function settings()
    {
        return array(
            "subReports" => array(
                "warehouseAjax" => WarehouseAjax::class,
                "productAjax" => ProductAjax::class
            ),
            "dataSources" => array(
                "tenantDB" => $this->db(),
            ),
        );
    }

    protected function defaultParamValues()
    {
        return array(
            "warehouse" => array(),
            "network" => array(),
            "product" => array(),
        );
    }

    protected function bindParamsToInputs()
    {
        return array(
            "warehouse",
            "network",
            "product"
        );
    }

    function setup()
    {
        $query_params = array();
        if ($this->params["warehouse"] != array())
        {
            $query_params[":warehouse"] = $this->params["warehouse"];
        }
        if ($this->params["network"] != array())
        {
            $query_params[":network"] = $this->params["network"];
        }
        if ($this->params["product"] != array())
        {
            $query_params[":product"] = $this->params["product"];
        }
        $this->src('tenantDB')->query(
            "SELECT CONCAT(t4.warehouse_code, ' - ', t4.description) AS 'Warehouse'
            ,t3.name AS 'Network'
            ,t2.product_code AS 'Product Code'
            ,COUNT(t1.serial_no) AS 'Count'
            FROM stock t1
            LEFT JOIN product t2 ON t2.id = t1.product_id
            LEFT JOIN network t3 ON t3.id = t2.network_id
            LEFT JOIN warehouse t4 ON t4.id = t1.warehouse_id
            WHERE customer_id IS NULL
            AND sales_order_detail_id IS NULL
            " . (($this->params["warehouse"] != array()) ? "AND t1.warehouse_id IN (:warehouse)" : "") . "
            " . (($this->params["network"] != array()) ? "AND t1.network_id IN (:network)" : "") . "
            " . (($this->params["product"] != array()) ? "AND t1.product_id IN (:product)" : "") . "
            GROUP BY CONCAT(t4.warehouse_code, ' - ', t4.description)
            ,t3.name
            ,t2.product_code
            ORDER BY t4.id
            ,t3.name
            ,t2.product_code"
        )->params($query_params)
            ->pipe(new Pivot(array(
                "dimensions" => array(
                    "row" => "Warehouse,Network,Product Code"
                ),
                "aggregates" => array(
                    "sum" => "Count",
                )
            )))->pipe($this->dataStore('sales'));
    }
}
