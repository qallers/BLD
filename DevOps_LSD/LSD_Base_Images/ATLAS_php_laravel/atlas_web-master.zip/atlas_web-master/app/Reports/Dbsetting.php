<?php

namespace App\Reports;

class Dbsetting extends \koolreport\KoolReport {

    public function db() {
        return array(
            "connectionString" => "mysql:host=" . env("DB_HOST") . ";dbname=" . tenant()->getAttribute("tenancy_db_name"),
            "username" => env("DB_USERNAME"),
            "password" => env("DB_PASSWORD"),
            "charset" => "utf8"
        );
    }

}
