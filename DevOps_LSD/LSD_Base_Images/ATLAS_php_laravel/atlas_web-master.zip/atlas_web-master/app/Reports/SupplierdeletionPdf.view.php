<?php

use \koolreport\pivot\widgets\PivotTable;
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Supplier Deletion</title>
    </head>
    <style>
        .box-container {
            width: 29cm;
        }
        .pivot-data-cell {
            text-align: right;
        }
    </style>
    <body>
        <div>

            <h1>Supplier Deletion</h1>
            <div>
                <?php
                $dataStore = $this->dataStore('sales');
                PivotTable::create(array(
                    "dataStore" => $dataStore,
                    "measures" => array(
                        "income - sum",
                    ),
                    'rowSort' => array(
                        'income - sum' => 'desc',
                    ),
                    'columnSort' => array(
                        'month' => function($a, $b) {
                            return (int) $a < (int) $b;
                        },
                    ),
                    'width' => '100%',
                    'headerMap' => array(
                        'income - sum' => 'Sales',
                        'serial_no - count' => 'Number of Sales',
                    ),
                ));
                ?>
            </div>

        </div>
    </body>
</html>
