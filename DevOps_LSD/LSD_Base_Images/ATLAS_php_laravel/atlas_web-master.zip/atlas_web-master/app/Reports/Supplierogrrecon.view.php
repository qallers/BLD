<?php

use \koolreport\pivot\widgets\PivotTable;
use \koolreport\inputs\DateTimePicker;
?>
<style>
    .calendar.left .daterangepicker_input,
    .calendar.right .daterangepicker_input {
        display: none;
    }
</style>
<div class="report-content">

    <form method="POST">
        <?php echo csrf_field() ?>
        <div class="text-center">
            <h3>Supplier OGR Recon</h3>
            <br/>
            <div class="form-group">
                <button formaction="/reporting/supplier_ogr_recon_export_pdf/" class="btn btn-primary">Download PDF</button>
                <button formaction="/reporting/supplier_ogr_recon_export_excel/" class="btn btn-primary">Download Excel</button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                From Date:
                <?php
                DateTimePicker::create(array(
                    "name" => "month",
                    "maxDate" => "@endDatePicker",
                    "format" => "YYYY-MM",
                    "themeBase" => "bs4",
                ));
                ?>
            </div>
            <div class="col-md-3">
                <?php $this->subReport("customerAjax"); ?>
            </div>
            <div class="col-md-3">
                <?php $this->subReport("productAjax"); ?>
            </div>

            <div class="form-group" style="margin-top:30px;">
                <button class="btn btn-lg btn-primary">Submit form</button>
            </div>
        </div>

    </form>
</div>

<?php
if (!empty($this->dataStore('sales')->data())) {
    PivotTable::create(array(
        "dataStore" => $this->dataStore('sales'),
        'rowCollapseLevels' => array(0),
        'columnCollapseLevels' => array(0),
        'hideSubtotalRow' => true,
        'hideSubtotalColumn' => true,
        'showDataHeaders' => true,
        'columnSort' => array(
            'month' => function ($a, $b) {
                return false;
            },
        ),
    ));
}
?>

