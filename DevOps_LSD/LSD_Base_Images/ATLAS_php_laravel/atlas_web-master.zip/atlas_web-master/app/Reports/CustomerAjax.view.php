<?php

use \koolreport\inputs\Select2;
?>

<div class="col-md-12 form-group">
    <strong>Select Customer Group</strong>
    <?php
    Select2::create(array(
        "name" => "group",
        "multiple" => true,
        "dataStore" => $this->dataStore("group"),
        "defaultOption" => array("--" => null),
        "dataBind" => array(
            "text" => "code",
            "value" => "id",
        ),
        "clientEvents" => array(
            "change" => "function(){
                 subReport.update('customerAjax',{
                    group:$('#group').val(),
                    _token: '" . csrf_token() . "'
                });
            }",
        ),
        "attributes" => array(
            "class" => "form-control",
            "size" => 5
        )
    ));
    ?>
</div>  
<?php
if ($this->params["group"]) {
    ?>
    <div class="col-md-12 form-group">
        <strong>Select Customer</strong>
        <?php
        Select2::create(array(
            "name" => "customer",
            "multiple" => true,
            "dataStore" => $this->dataStore("customer"),
            "dataBind" => array(
                "text" => "name",
                "value" => "id",
            ),
            "attributes" => array(
                "class" => "form-control",
                "size" => 5
            )
        ));
        ?>
    </div>   
<?php }
?>
