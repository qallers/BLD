<?php

use \koolreport\inputs\Select2;
?>

<div class="col-md-12 form-group">
    <strong>Select Warehouse</strong>
    <?php
    Select2::create(array(
        "name" => "warehouse",
        "multiple" => true,
        "dataStore" => $this->dataStore("warehouse"),
        "defaultOption" => array("--" => null),
        "dataBind" => array(
            "text" => "warehouse",
            "value" => "id",
        ),
        "clientEvents" => array(
            "change" => "function(){
                 subReport.update('warehouseAjax',{
                    warehouse:$('#warehouse').val(),
                    _token: '" . csrf_token() . "'
                });
            }",
        ),
        "attributes" => array(
            "class" => "form-control",
            "size" => 5
        )
    ));
    ?>
</div>

