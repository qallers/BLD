<?php

namespace App\Reports;

class WarehouseAjax extends Dbsetting
{
    use \koolreport\laravel\Friendship;
    use \koolreport\inputs\Bindable;
    use \koolreport\inputs\POSTBinding;

    protected function defaultParamValues()
    {
        return array(
            "warehouse" => array()
        );
    }

    protected function bindParamsToInputs()
    {
        return array(
            "warehouse"
        );
    }

    function settings()
    {
        return array(
            "dataSources" => array(
                "tenantDB" => $this->db(),
            ),
        );
    }

    function setup()
    {
        $this->src("tenantDB")->query(
            "SELECT id
                ,CONCAT(t1.warehouse_code, ' - ', t1.description) AS 'warehouse'
                FROM warehouse t1
                ORDER BY CONCAT(t1.warehouse_code, ' - ', t1.description)"
        )->pipe($this->dataStore("warehouse"));
    }
}
