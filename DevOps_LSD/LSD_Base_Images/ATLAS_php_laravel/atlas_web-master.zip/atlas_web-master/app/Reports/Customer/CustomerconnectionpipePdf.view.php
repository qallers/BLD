<?php

use \koolreport\widgets\koolphp\Table;
?>
<div class="report-content">
    <div class="text-center">
        <h1>Sales Deal</h1>
    </div>

    <html>
        <body style="margin:0.5in 1in 0.5in 1in">
            <link rel="stylesheet" href="koolreport/assets/bs3/bootstrap.min.css" />
            <link rel="stylesheet" href="koolreport/assets/bs3/bootstrap-theme.min.css" />   
            <div class="page-header" style="text-align:right"><i>Sales Deal</i></div>

            <hr/>
            <?php
            Table::create(array(
                "dataStore" => $this->dataStore("sales"),
                "cssClass" => array(
                    "table" => "table table-bordered"
                )
            ));
            ?>
</div>
</body>
</html>
