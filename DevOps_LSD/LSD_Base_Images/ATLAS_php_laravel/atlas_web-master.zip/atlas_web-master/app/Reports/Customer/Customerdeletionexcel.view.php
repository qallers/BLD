<?php

use \koolreport\excel\PivotTable;

?>
<div sheet-name="Customer Deletion">

    <div>
        <?php
        PivotTable::create(array(
            "dataSource" => $this->dataStore('sales'),
            'rowCollapseLevels' => array(0),
            'columnCollapseLevels' => array(0),
            'hideSubtotalRow' => true,
            'hideSubtotalColumn' => true,
            'showDataHeaders' => true,
        ));
        ?>
    </div>
</div>