<?php

use \koolreport\widgets\koolphp\Table;
?>
<div class="report-content">
    <div class="text-center">
        <h1>Sales Deal</h1>
    </div>

   
            <?php
            Table::create(array(
                "dataStore" => $this->dataStore("sales"),
                "cssClass" => array(
                    "table" => "table table-bordered"
                ),
//                "columns" => array(
//                    "Order ID" => array(
//                        "label" => "Order ID",
//                        "type" => "string"
//                    ),
//                    "Order Date" => array(
//                        "label" => "Order Date",
//                    ),
//                    "Customer Name" => array(
//                        "label" => "Customer Name",
//                    ),
//                    "Product Name" => array(
//                        "label" => "Product Name",
//                    ),
//                    "Activation" => array(
//                        "label" => "Activation",
//                        "type" => "number",
//                        "prefix" => "R "
//                    ),
//                    "OGR" => array(
//                        "label" => "OGR",
//                        "type" => "number",
//                        "suffix" => "%"
//                    ),
//                    "Quantity" => array(
//                        "label" => "Quantity",
//                    ),
//                )
            ));
            ?>
      
</div>

