<?php

use \koolreport\pivot\widgets\PivotTable;
?>
<!DOCTYPE html>
<html>

<head>
    <title>Customer Deletion</title>
</head>
<style>
    .box-container {
        width: 29cm;
    }

    .pivot-data-cell {
        text-align: right;
    }
</style>

<body>
    <div>

        <h1>Customer Deletion</h1>
        <div>
            <?php
           PivotTable::create(array(
            "dataSource" => $this->dataStore('sales'),
            'rowCollapseLevels' => array(0),
            'columnCollapseLevels' => array(0),
            'hideSubtotalRow' => true,
            'hideSubtotalColumn' => true,
            'showDataHeaders' => true,
        ));
            ?>
        </div>

    </div>
</body>

</html>