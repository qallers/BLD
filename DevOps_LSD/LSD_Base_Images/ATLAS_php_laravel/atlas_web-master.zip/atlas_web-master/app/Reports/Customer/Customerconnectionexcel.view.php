<?php

//use \koolreport\excel\Table;
use \koolreport\excel\PivotTable;

//use \koolreport\excel\BarChart;
//use \koolreport\excel\LineChart;
?>
<div sheet-name="<?php echo "Customer Activation"; ?>">

    <div>
        <?php
        PivotTable::create(array(
            "dataSource" => 'sales',
            'rowCollapseLevels' => array(0),
            'columnCollapseLevels' => array(0),
            'hideSubtotalRow' => true,
            'hideSubtotalColumn' => true,
            'showDataHeaders' => true,
        ));
        ?>
    </div>
</div>