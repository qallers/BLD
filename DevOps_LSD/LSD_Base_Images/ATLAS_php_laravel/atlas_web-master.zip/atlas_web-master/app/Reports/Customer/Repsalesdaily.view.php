<?php

use \koolreport\widgets\koolphp\Table;
use \koolreport\inputs\DateTimePicker;
use \koolreport\inputs\Select2;
?>

<div class="report-content">
    <form method="POST">
        <?php echo csrf_field() ?>
        <div class="text-center">
            <h3>Rep Sales Deal Report</h3>
            <br/>

            <div class="form-group">
                <button formaction="/reporting/rep_sales_daily_export_pdf/" class="btn btn-primary">Download PDF</button>
                <button formaction="/reporting/rep_sales_daily_export_excel/" class="btn btn-primary">Download Excel</button>
            </div>

        </div>
        <div class="row">
            <div class="col-md-3 form-group">
                <strong>Select Users</strong>
                <?php
                Select2::create(array(
                    "name" => "user",
                    "multiple" => true,
                    "dataStore" => $this->dataStore("users"),
                    "dataBind" => array(
                        "text" => "username",
                        "value" => "id",
                    ),
                    "attributes" => array(
                        "class" => "form-control",
                        "size" => 5
                    )
                ));
                ?>
            </div>   
            <div class="col-md-3 form-group">
                <strong>Select Customer</strong>
                <?php
                Select2::create(array(
                    "name" => "customer",
                    "multiple" => true,
                    "dataStore" => $this->dataStore("customer"),
                    "dataBind" => array(
                        "text" => "name",
                        "value" => "id",
                    ),
                    "attributes" => array(
                        "class" => "form-control",
                        "size" => 5
                    )
                ));
                ?>
            </div>   
            <div class="col-md-3 form-group">
                <strong>Select Product</strong>
                <?php
                Select2::create(array(
                    "name" => "product",
                    "multiple" => true,
                    "dataStore" => $this->dataStore("products"),
                    "dataBind" => array(
                        "text" => "description",
                        "value" => "id",
                    ),
                    "attributes" => array(
                        "class" => "form-control",
                        "size" => 5
                    )
                ));
                ?>
            </div>   
            <div class="col-md-3">
                Start Date:
                <?php
                DateTimePicker::create(array(
                    "name" => "start_date",
                    "maxDate" => "@endDatePicker",
                    "format" => "YYYY-MM-DD",
                    "themeBase" => "bs4",
                ));
                ?>
            </div>
            <div class="col-md-3">
                End Date:
                <?php
                DateTimePicker::create(array(
                    "name" => "end_date",
                    "maxDate" => "@endDatePicker",
                    "format" => "YYYY-MM-DD",
                    "themeBase" => "bs4",
                ));
                ?>
            </div>

            <div class="form-group" style="margin-top:20px;">
                <button class="btn btn-primary">Submit form</button>
            </div>
        </div>

    </form>
</div>

<?php
Table::create(array(
    "dataStore" => $this->dataStore("sales"),
    "cssClass" => array(
        "table" => "table table-bordered"
    ),
    "paging" => array(
        "pageSize" => 10,
        "pageIndex" => 0,
    )
));
?>

