<?php

namespace App\Reports\Customer;

use App\Reports\Dbsetting;

class Repsalesdaily extends Dbsetting {

    use \koolreport\export\Exportable;
    use \koolreport\excel\ExcelExportable;
    use \koolreport\laravel\Friendship;
    use \koolreport\inputs\Bindable;
    use \koolreport\inputs\POSTBinding;

    function settings() {
        return array(
            "dataSources" => array(
                "tenantDB" => $this->db(),
            ),
        );
    }

    protected function defaultParamValues() {

        return array(
            "customer" => array(),
            "product" => array(),
            "user" => array(),
            "start_date" => date('Y-m-d'),
            "end_date" => date('Y-m-d')
        );
    }

    protected function bindParamsToInputs() {
        return array(
            "customer",
            "product",
            "user",
            "start_date",
            "end_date"
        );
    }

    function setup() {

        $node = $this->src('tenantDB')->query("SELECT sales_order_id as `Order ID`, DATE_FORMAT(o.created_at,'%d %b %Y') as `Order Date`,concat('( ', c.cust_code,' ) - ',c.name) as `Customer Name`,u.username,g.code as `Department`,p.description as `Product Name`,sd.act as `Activation`,sd.ogr as `OGR`,s.sales_price as `Sale Price`,s.qty as `Quantity`,s.invoice_number,s.qty FROM sales_order_detail s "
                        . "JOIN sales_order o ON s.sales_order_id = o.id "
                        . "LEFT JOIN customer c ON c.id = o.customer_id "
                        . "LEFT JOIN `group` g ON g.id = c.group_id "
                        . "LEFT JOIN product p ON p.id = s.product_id "
                        . "LEFT JOIN users u ON u.id = c.rep_user_id "
                        . "LEFT JOIN user_type ut ON u.user_type_id = ut.id "
                        . "LEFT JOIN (SELECT sales_order_detail_id ,MAX(id) AS 'id' ,customer_id,act,ogr FROM sales_deal WHERE DATE_SUB(LAST_DAY(start_date),INTERVAL DAY(LAST_DAY(start_date))-1 DAY) <= now() AND now() <= end_date GROUP BY sales_order_detail_id, customer_id) as sd ON sd.sales_order_detail_id = s.id "
                        . "WHERE s.is_dispatch = 1 AND ut.slug = 'REP_USER' AND "
                        . (($this->params["customer"] != array()) ? "o.customer_id IN (:customer) AND " : "")
                        . (($this->params["product"] != array()) ? "s.product_id IN (:product) AND " : "")
                        . (($this->params["user"] != array()) ? "u.id IN (:user) AND " : "")
                        . "date(o.created_at) BETWEEN :start_date AND :end_date"
                )
                ->params(array(
                    ":customer" => $this->params["customer"],
                    ":product" => $this->params["product"],
                    ":user" => $this->params["user"],
                    ":end_date" => $this->params["end_date"],
                    ":start_date" => $this->params["start_date"]
                ))
                ->pipe($this->dataStore("sales"));

        $this->src("tenantDB")->query("
                SELECT u.id,u.username from users u join user_type ut ON u.user_type_id = ut.id where ut.slug = 'REP_USER'
            ")
                ->pipe($this->dataStore("users"));

        $this->src("tenantDB")->query("
                SELECT id, name from customer
            ")
                ->pipe($this->dataStore("customer"));
        $this->src("tenantDB")->query("
                SELECT id, description from product
            ")
                ->pipe($this->dataStore("products"));
    }

}
