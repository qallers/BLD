<?php

namespace App\Reports\Customer;

use App\Reports\Dbsetting;

class Returnstock extends Dbsetting {

    use \koolreport\export\Exportable;
    use \koolreport\excel\ExcelExportable;
    use \koolreport\laravel\Friendship;
    use \koolreport\inputs\Bindable;
    use \koolreport\inputs\POSTBinding;

    function settings() {
        return array(
            "dataSources" => array(
                "tenantDB" => $this->db(),
            ),
        );
    }

    protected function defaultParamValues() {

        return array(
            "customer" => array(),
            "start_date" => date('Y-m-d'),
            "end_date" => date('Y-m-d')
        );
    }

    protected function bindParamsToInputs() {
        return array(
            "customer",
            "product",
            "start_date",
            "end_date"
        );
    }

    function setup() {

//        echo "SELECT p.product_code as Products,n.name as Network,sd.qty as QTY,c.name as Customer,sd.invoice_number as Invoice,st.name as Status FROM return_stock r "
//        . "LEFT JOIN sales_order_detail sd ON r.sales_order_detail_id = sd.id "
//        . "LEFT JOIN product p ON sd.product_id = p.id "
//        . "LEFT JOIN sales_order s ON sd.sales_order_id = s.id "
//        . "LEFT JOIN customer c ON c.id = s.customer_id "
//        . "LEFT JOIN return_stock_master rm ON rm.id = r.return_stock_master_id "
//        . "LEFT JOIN `status` st ON st.id = rm.status_id "
//        . "JOIN network n ON p.network_id = n.id";
//        die;


        $node = $this->src('tenantDB')->query("SELECT p.product_code as Products,n.name as Network,count(r.id) as QTY,c.name as Customer,sd.invoice_number as Invoice,IF(r.return_stock_master_id = 0,'APPROVED',st.name) as Status FROM return_stock r "
                        . "LEFT JOIN sales_order_detail sd ON r.sales_order_detail_id = sd.id "
                        . "LEFT JOIN product p ON sd.product_id = p.id "
                        . "LEFT JOIN sales_order s ON sd.sales_order_id = s.id "
                        . "LEFT JOIN customer c ON c.id = s.customer_id "
                        . "LEFT JOIN return_stock_master rm ON rm.id = r.return_stock_master_id "
                        . "LEFT JOIN `status` st ON st.id = rm.status_id "
                        . "LEFT JOIN network n ON p.network_id = n.id where "
                        . (($this->params["customer"] != array()) ? "s.customer_id IN (:customer) AND " : "")
                        . "date(r.created_at) BETWEEN :start_date AND :end_date group by r.sales_order_detail_id"
                )
                ->params(array(
                    ":customer" => $this->params["customer"],
                    ":end_date" => $this->params["end_date"],
                    ":start_date" => $this->params["start_date"]
                ))
                ->pipe($this->dataStore("sales"));

        $this->src("tenantDB")->query("
                SELECT id, name from customer
            ")
                ->pipe($this->dataStore("customer"));
    }

}
