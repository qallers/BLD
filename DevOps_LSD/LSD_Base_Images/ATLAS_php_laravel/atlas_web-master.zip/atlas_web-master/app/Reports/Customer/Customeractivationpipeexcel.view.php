<?php

//use \koolreport\excel\Table;
use \koolreport\excel\PivotTable;

//use \koolreport\excel\BarChart;
//use \koolreport\excel\LineChart;
?>
<div sheet-name="<?php echo "Customer Activation Pipe"; ?>">

    <div>
        <?php
        PivotTable::create(array(
            "dataSource" => 'sales',
            'headerMap' => function($v, $f) {
                if ($v === 'expense - sum')
                    $v = 'Total Expense';
                if ($v === 'income - sum')
                    $v = 'Total Income';
                if ($v === 'serial_no - count')
                    $v = 'Total Count';
                if ($f === 'year')
                    $v = 'Year ' . $v;
                return $v;
            },
            'rowCollapseLevels' => array(0),
            'columnCollapseLevels' => array(0),
            'hideSubtotalRow' => true,
            'hideSubtotalColumn' => true,
            'showDataHeaders' => true,
        ));
        ?>
    </div>
</div>