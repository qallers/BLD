<?php

namespace App\Reports\Customer;

use App\Customer;
use \koolreport\processes\ColumnMeta;
use \koolreport\pivot\processes\Pivot;
use App\Reports\Dbsetting;
use App\Reports\ProductAjax;
use Illuminate\Support\Facades\Auth;

class Customeractivationpipe extends Dbsetting
{

    use \koolreport\export\Exportable;
    use \koolreport\excel\ExcelExportable;
    use \koolreport\laravel\Friendship;
    use \koolreport\inputs\Bindable;
    use \koolreport\inputs\POSTBinding;
    use \koolreport\core\SubReport;

    function settings()
    {
        return array(
            "useLocalTempFolder"=>true,
            "subReports" => array(
                "productAjax" => ProductAjax::class
            ),
            "dataSources" => array(
                "tenantDB" => $this->db(),
            ),
        );
    }

    protected function defaultParamValues()
    {

        if (Auth::user()->user_type_id == 5) {
            $id = Customer::whereUserId(Auth::user()->id)->first()->id;
            return array(
                "month" => date('Y-m'),
                "customer" => array($id),
                "network" => array(),
                "product" => array(),
            );
        } else {
            return array(
                "month" => date('Y-m'),
                "customer" => array(),
                "network" => array(),
                "product" => array(),
            );
        }
    }

    protected function bindParamsToInputs()
    {
        return array(
            "month",
            "customer",
            "network",
            "product"
        );
    }

    function setup()
    {
        $toMonth = date('Y-m-d', strtotime($this->params["month"]));
        $fromMonth = date('Y-m-d', strtotime($this->params["month"]));

        $query_params = array();

        if ($this->params["customer"] != array()) {
            $query_params[":customer"] = $this->params["customer"];
        }
        if ($this->params["network"] != array()) {
            $query_params[":network"] = $this->params["network"];
        }
        if ($this->params["product"] != array()) {
            $query_params[":product"] = $this->params["product"];
        }

        $this->src('tenantDB')->query(
            "SELECT t4.process_month AS 'month'
                ,CONCAT(t8.code, ' - ', t8.description) AS 'group'
                ,CONCAT('(', t7.cust_code, ') - ', t7.name) AS 'parent'
                ,CONCAT('(', t3.cust_code, ') - ', t3.name) AS 'name'
                ,CASE WHEN t3.vat_registered = 1 THEN ROUND(t1.expense, 4)
                    ELSE ROUND(t1.expense / (1 + t9.vat), 4)
                    END AS income
                ,t1.serial_no
                FROM me_act_post_process t1
                LEFT JOIN network t2 ON t1.network_id = t2.id
                LEFT JOIN customer t3 ON t1.customer_id = t3.id
                LEFT JOIN me_import_file t4 ON t1.file_id = t4.id
                LEFT JOIN sales_order_detail t5 ON t5.id = t1.sales_order_detail_id
                LEFT JOIN sales_order t6 ON t6.id = t5.sales_order_id
                LEFT JOIN customer t7 ON t7.id = t3.parent_id
                LEFT JOIN `group` t8 ON t8.id = t3.group_id
                LEFT JOIN vat_config t9 ON t1.created_at BETWEEN t9.start_date AND t9.end_date
                WHERE t4.process_month BETWEEN '$fromMonth' AND '$toMonth'
                " . (($this->params["customer"] != array()) ? "AND t1.customer_id IN (:customer)" : "") . "
                " . (($this->params["network"] != array()) ? "AND t1.network_id IN (:network)" : "") . "
                " . (($this->params["product"] != array()) ? "AND t1.product_id IN (:product)" : "")
        )->params($query_params)
            ->pipe(new ColumnMeta(array(
                "income" => array(
                    'type' => 'number',
                    "decimals" => 2,
                    "prefix" => "R",
                ),
                "serial_no" => array(
                    'type' => 'number',
                ),
            )))
            ->pipe(new Pivot(array(
                "dimensions" => array(
                    "column" => "month",
                    "row" => "group,parent,name"
                ),
                "aggregates" => array(
                    "sum" => "income,expense",
                    "count" => "serial_no",
                )
            )))->pipe($this->dataStore('sales'));

        if (Auth::user()->user_type_id != 5) {
            $this->src("tenantDB")->query(
                "SELECT id
                        ,`name`
                        FROM customer"
            )->pipe($this->dataStore("customer"));
        }
    }
}
