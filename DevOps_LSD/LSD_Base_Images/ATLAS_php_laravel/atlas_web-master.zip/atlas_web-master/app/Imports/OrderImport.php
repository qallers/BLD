<?php

namespace App\Imports;

use App\BulkOrderDetails;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class OrderImport implements ToModel,WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new BulkOrderDetails([
                    'customer_id'=>$row['customer_id'],
                    'parent_id'=>$row['product_code'],
                    'order_id'=>$row['product_code'],
                    'product_id'=>$row['product_code'],
                    'user_id'=>$row['product_code'],
                    'qty'=>$row['qty'],
                    'payment_status_id'=>$row['payment_status'],
                    'delivery_method_id'=>$row['delivey_mode'],
                    'warehouse_id'=>$row['warehouse_id'],
                    'bill_to_headoffice'=>$row['product_code'],
                    'deliver_to_headoffice'=>$row['product_code'],
                    'price'=>$row['product_code'],
        ]);
    }
}
