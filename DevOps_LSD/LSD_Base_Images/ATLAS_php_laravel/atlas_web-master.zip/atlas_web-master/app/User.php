<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Support\Facades\Hash;
use Spatie\Activitylog\Traits\LogsActivity;
use Laravel\Passport\HasApiTokens;
/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class User extends Authenticatable {

    use Notifiable;
    use HasRoles;
    use LogsActivity;
    use HasApiTokens;

    protected $fillable = ['first_name', 'last_name', 'username', 'email', 'password', 'remember_token', 'is_active','user_type_id', 'warehouse_id','password_changed_at'];
    protected static $logAttributes = ['id', 'email', 'username'];

    public function findForPassport($username)
    {
        return $this->where('username', $username)->first();
    }
    
    /**
     * Hash password
     * @param $input
     */
    public function setPasswordAttribute($input) {
        if ($input)
            $this->attributes['password'] = app('hash')->needsRehash($input) ? Hash::make($input) : $input;
    }

    public function purchaseOrder() {
        return $this->hasMany('App/PurchaseOrder');
    }

    public function role() {
        return $this->belongsToMany(Role::class, 'role_user');
    }

    public function SalesOrder() {
        return $this->hasMany('App\SalesOrder');
    }
    public function customer() {
        return $this->hasOne('App\Customer');
    }
    public function contacts() {
        return $this->hasMany('App\Contact','id','customer_id')->where("entity_type_id",24);
    }

    //////////////get usertype
    public function usertype() {
        return $this->belongsTo('App\UserType', 'user_type_id');
    }

    public function warehouse() {
        return $this->belongsTo('App\Warehouse', 'warehouse_id');
    }

}
