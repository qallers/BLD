<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\DB;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class SalesOrderDetails extends Authenticatable {

    use LogsActivity;
    use Notifiable;

    public $table = "sales_order_detail";
    protected $fillable = ['id', 'sales_order_id', 'split_deal_id', 'qty', 'cost', 'sales_price', 'product_id', 'product_deal_id', 'invoice_number'];
    protected static $logAttributes = ['id', 'sales_order_id', 'split_deal_id', 'qty', 'cost', 'sales_price', 'product_id', 'product_deal_id', 'invoice_number'];

    public function order() {
        return $this->belongsTo('App\SalesOrder', 'sales_order_id');
    }

    public function product() {
        return $this->belongsTo('App\Product', 'product_id');
    }

    public function deal() {
        return $this->hasOne('App\SalesDeal', "sales_order_detail_id");
    }

    public function deals() {
        return $this->hasMany('App\SalesDeal', "sales_order_detail_id");
    }

    public function stock() {
        return $this->hasMany('App\Stock', 'sales_order_detail_id');
    }

    public function dispatch() {
        return $this->belongsTo('App\Dispatch', 'id', 'invoice_id');
    }

//    public function returnStock() {
//        return $this->hasMany('App\ReturnStock', "sales_order_detail_id");
//    }
}
