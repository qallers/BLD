<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\WarehouseHasAddress;
use App\AddressWarehouse;
use Spatie\Activitylog\Traits\LogsActivity;

class AddressWarehouse extends Model{
    use LogsActivity;
    public $table= 'address';

    //use Notifiable;

    protected $fillable = ['warehouse_id','address_id','address_type_id', 'address_line_1', 'address_line_2', 'region_id', 'postal_code', 'gps_coordinates'];
    protected static $logAttributes = ['warehouse_id','address_id','address_type_id', 'address_line_1', 'address_line_2', 'region_id', 'postal_code', 'gps_coordinates'];
   
    public function warehousehasaddress()
    {
        return $this->belongsToMany('App\WarehouseHasAddress');
    }

    public function warehouse(){
       
        return $this->belongsToMany('App\Warehouse')->using('App\WarehouseHasAddress');
    }
 

    protected $geometry = ['gps_coordinates'];

    /**
     * Select geometrical attributes as text from database.
     *
     * @var bool
     */
    protected $geometryAsText = true;
 

   
  
}
