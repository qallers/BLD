<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Spatie\Activitylog\Traits\LogsActivity;

class UserType extends Model {

    use LogsActivity;

    public $table = "user_type";
    protected $fillable = ['id', 'description', 'slug'];
    protected static $logAttributes = ['id', 'description', 'slug'];

    public function users() {
        //return $this->hasMany('App\User');
        return $this->hasMany('App\User', 'user_id');
    }

}

?>
 