<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Dispatch extends Model {

    use LogsActivity;

    public $table = "dispatch";
    protected $fillable = ['id', 'invoice_id', 'qty', 'warehouse_id', 'status_id', 'created_at', 'updated_at'];
    protected static $logAttributes =['id', 'invoice_id', 'qty', 'warehouse_id', 'status_id', 'created_at', 'updated_at'];
    
    public function salesorderdetail() {
        return $this->belongsTo('App\SalesOrderDetails', 'invoice_id');
    }

    public function status() {
        return $this->belongsTo('App\Status', 'status_id');
    }

}
