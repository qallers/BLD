<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;
/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class SalesOrder extends Model {
    use LogsActivity;
    use Notifiable;
    
    public $table = "sales_order";

    protected $fillable = ['id','is_bulk', 'customer_id', 'warehouse_id', 'user_id', 'status_id', 'payment_status_id', 'delivery_method_id','bill_to_headoffice','deliver_to_headoffice','parent_id', 'created_at', 'updated_at'];
    protected static $logAttributes =  ['id','is_bulk', 'customer_id', 'warehouse_id', 'user_id', 'status_id', 'payment_status_id', 'delivery_method_id','bill_to_headoffice','deliver_to_headoffice','parent_id', 'created_at', 'updated_at'];

    public function paymentStatus() {
        return $this->belongsTo('App\Status', 'payment_status_id');
    }

    public function deliveryMode() {
        return $this->belongsTo('App\Status', 'delivery_method_id');
    }

    public function status() {
        return $this->belongsTo('App\Status', 'status_id');
    }

    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }

    public function customer() {
        return $this->belongsTo('App\Customer', 'customer_id');
    }

    public function warehouse() {
        return $this->belongsTo('App\Warehouse', 'warehouse_id');
    }

    public function salesOrderDetail() {
        return $this->hasMany('App\SalesOrderDetails', 'sales_order_id');
    }

    public function approvals() {
        return $this->belongsTo('App\Approvals', 'approval_id');
    }
}
