<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\CustomerHasContact;
use Spatie\Activitylog\Traits\LogsActivity;

class Contact extends Model {
    use LogsActivity;
    
    public $table = 'contact';
    //use Notifiable;
   
    protected $fillable = ['customer_id', 'contact_id', 'contact_entity_id', 'name', 'mail_address', 'tel_no', 'fax_no', 'cell_no'];
    protected static $logAttributes =  ['customer_id', 'contact_id', 'contact_entity_id', 'name', 'mail_address', 'tel_no', 'fax_no', 'cell_no'];
    
    public function customerhascontact() {
        return $this->belongsToMany('App\CustomerHasContact');
    }

    public function customer() {

        return $this->belongsToMany('App\Customer')->using('App\CustomerHasContact');
    }

    public function deleteContactWithLink($contactid) {

        CustomerHasContact::where('contact_id', $contactid)->delete();
    }

}
