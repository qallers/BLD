<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class CustomerHasAddress extends Model {
    use LogsActivity;
    
    public $table = "customer_has_address";

    protected $fillable = ['customer_id','address_id'];
    protected static $logAttributes =['customer_id','address_id'];

public function customer()
{
    return $this->hasMany('App\Customer');
}
}