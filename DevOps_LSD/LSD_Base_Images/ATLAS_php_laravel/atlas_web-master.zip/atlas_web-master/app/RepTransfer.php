<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class RepTransfer extends Authenticatable {

    use LogsActivity;

    public $table = "rep_transfer";

    use Notifiable;

    protected $fillable = ['id', 'warehouse_id', 'approval_id', 'priority', 'external_reference', 'order_date', 'status_id', 'user_id'];

    public function status() {
        return $this->belongsTo('App\Status', 'status_id');
    }

    public function user() {
        return $this->belongsTo('App\User', 'user_id');
    }

    public function warehouse() {
        return $this->belongsTo('App\Warehouse', 'warehouse_id');
    }

    public function reptransferdetail() {
        return $this->hasMany('App\RepTransferDetails', 'rep_transfer_id');
    }

}
