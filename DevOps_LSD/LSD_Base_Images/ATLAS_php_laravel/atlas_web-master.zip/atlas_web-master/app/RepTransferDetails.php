<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class RepTransferDetails extends Authenticatable {

    use LogsActivity;

    public $table = "rep_transfer_detail";

    use Notifiable;

    protected $fillable = ['id', 'rep_transfer_id', 'product_id', 'qty', 'is_dispatch', 'is_allocate', 'is_verify'];

    public function product() {
        return $this->belongsTo('App\Product', 'product_id');
    }

    public function reptransfer() {
        return $this->belongsTo('App\RepTransfer', 'rep_transfer_id');
    }

    public function stock() {
        return $this->hasMany('App\Stock', 'rep_transfer_detail_id');
    }

}
