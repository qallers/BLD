<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property int $id
 * @property boolean $is_tired
 * @property int $tier_id
 * @property float $ogr
 * @property float $act
 * @property float $sim
 * @property int $network_id
 * @property boolean $is_split
 * @property string $created_at
 * @property string $updated_at
 */
class Contract extends Model
{
    use LogsActivity;
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'contract';

    /**
     * @var array
     */
    protected $fillable = ['name','customer_id','is_tiered', 'tier_id', 'ogr', 'act', 'sim', 'network_id', 'is_split', 'created_at', 'updated_at'];
    protected static $logAttributes = ['name','customer_id','is_tiered', 'tier_id', 'ogr', 'act', 'sim', 'network_id', 'is_split', 'created_at', 'updated_at'];

    public function network()
    {
        return $this->belongsTo('App\Network', 'network_id');
    }
}
