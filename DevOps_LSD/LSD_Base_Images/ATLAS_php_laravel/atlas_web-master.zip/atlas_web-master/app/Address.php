<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\CustomerHasAddress;
use Spatie\Activitylog\Traits\LogsActivity;

class Address extends Model{
    use LogsActivity;
    public $table= 'address';


    protected $fillable = ['customer_id','address_type_id','address_entity_id','city','province', 'address_line_1', 'address_line_2', 'postal_code', 'gps_coordinates'];
    protected static $logAttributes = ['customer_id','address_type_id','address_entity_id','city','province', 'address_line_1', 'address_line_2', 'postal_code', 'gps_coordinates'];
   
    public function address_type()
    {
        return $this->belongsTo('App\Status','address_type_id')->whereProcess("address_type");
    }

    public function customer(){
        return $this->belongsTo('App\Customer','customer_id');
    }
    

   public function deleteAddressWithLink($addressid){
    
    CustomerHasAddress::where('address_id', $addressid)->delete();

   }   



     
 
  
}
