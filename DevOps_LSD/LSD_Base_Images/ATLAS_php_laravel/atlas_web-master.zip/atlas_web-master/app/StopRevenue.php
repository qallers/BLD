<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class StopRevenue extends Model {
    use LogsActivity;
    
    public $table = "stop_revenue";
    protected $primaryKey = 'customer_id';
    protected $fillable = ['customer_id', 'from_date', 'to_date', 'stop_revenue', 'stop_rebate', 'stop_simswap'];
    protected static $logAttributes = ['customer_id', 'from_date', 'to_date', 'stop_revenue', 'stop_rebate', 'stop_simswap'];

    public function customer() {
        return $this->belongsTo('App\Customer', 'customer_id');
    }

}
