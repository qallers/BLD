<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
/**
 * @property int $id
 * @property int $customer_id
 * @property int $customer_split
 * @property float $ogr
 * @property float $act
 * @property boolean $is_eligible_tier
 * @property float $ogr_tier
 * @property float $act_tier
 * @property float $sim_tier
 * @property string $created_at
 * @property string $updated_at
 */
class CustomerSplit extends Model
{
    use LogsActivity;
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'customer_split';

    /**
     * @var array
     */
    protected $fillable = ['id', 'customer_id','network_id', 'split_customer','product_deal_id', 'ogr', 'act','sim', 'is_eligible_tier', 'ogr_tier', 'act_tier', 'sim_tier', 'created_at', 'updated_at'];
    protected static $logAttributes =['id', 'customer_id','network_id', 'split_customer','product_deal_id', 'ogr', 'act','sim', 'is_eligible_tier', 'ogr_tier', 'act_tier', 'sim_tier', 'created_at', 'updated_at'];

    public function splitCustomer()
    {
        return $this->belongsTo('App\Customer', 'split_customer');
    }

    public function getOgrTierAttribute($value) {
        return round($value,2);
    }
    public function getActTierAttribute($value) {
        return round($value,2);
    }
    public function getSimTierAttribute($value) {
        return round($value,2);
    }
}
