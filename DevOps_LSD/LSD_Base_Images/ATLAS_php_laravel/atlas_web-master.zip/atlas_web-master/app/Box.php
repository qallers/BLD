<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * Class User
 *
 * @package App
 * @property string $name
 * @property string $email
 * @property string $password
 * @property string $remember_token
 */
class Box extends Authenticatable {
    use LogsActivity;
    use Notifiable;
    public $table = "box";
   
    protected $fillable = ['id', 'barcode', 'parent_id','product_id'];
    protected static $logAttributes =['id', 'barcode', 'parent_id','product_id'];

    

}
