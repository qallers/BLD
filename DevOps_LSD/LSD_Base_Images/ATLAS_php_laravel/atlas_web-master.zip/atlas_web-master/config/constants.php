<?php

// please run composer dump-autoload to include this constant
if (!defined('PHP_RN')) define ('PHP_RN', "\r\n");

