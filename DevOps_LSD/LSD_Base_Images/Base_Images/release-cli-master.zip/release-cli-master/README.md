# LSDautomate: Base Images

## Release CLI Builder

* Base image is official GitLab release cli `registry.gitlab.com/gitlab-org/release-cli:latest`
* PEM certificates found within files/pki will be added to global trust store

```
NPM_CAFILE     - NPM registry CA certificate
NPM_REGISTRY   - NPM registry URL
NPM_AUTH       - NPM registry auth string
```

## Build image
```-> %  docker build -t lsdautomate-release-cli-builder:1.0.0 . --build-arg=NPM_REGISTRY=https://registry.url```

## Run image
```
-> % docker run -it lsd-automate-release-cli-builder:1.0.0-dev
```

### Version
See VERSION

### Author(s)
LSD Solutioneering

###### LSD Information Technology
###### automate@lsdopen.io
2021
