#!/usr/bin/env sh
##
##  trustcerts.sh
##  Configures os and java trust with custom ceritifcates
## 
##  LSDautomate
##  <automate@lsdopen.io>
##

if [ "$(id -u)" != "0" ]; then
  echo "$0 must be executed as root user to update CA"
  exit 1
fi

if [ -z "$1" ]; then
  echo "$0 expects path to PEM certificates"
  exit 1
fi

CERT_DIR="$1"

for cert in $(ls "$CERT_DIR"); do

  echo "found $CERT_DIR/$cert, adding to os and jks"

  if [ -f "$JAVA_HOME/lib/security/cacerts" ]; then
    keytool -keystore "$JAVA_HOME/lib/security/cacerts" -storepass changeit -noprompt -trustcacerts -importcert -alias "$cert" -file "$CERT_DIR/$cert"  
  else
    echo "No global JKS detected, skipping keytool"
  fi

  if [ -f /etc/debian_version ]; then 

    echo "debian image detected - adding $CERT_DIR/$cert"
    mkdir -p /usr/local/share/ca-certificates/custom/
    cp "$CERT_DIR/$cert" /usr/local/share/ca-certificates/custom/
    update-ca-certificates

  fi

  if [ -f /etc/alpine-release ]; then 

    echo "alpine image detected - adding $CERT_DIR/$cert"
    cp "$CERT_DIR/$cert" "/usr/local/share/ca-certificates/$cert"
    update-ca-certificates

  fi

done

echo "$0 complete"
exit 0
