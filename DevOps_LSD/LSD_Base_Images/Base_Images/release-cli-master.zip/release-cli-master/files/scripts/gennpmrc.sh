#!/usr/bin/env sh
##
##  gennpmrc.sh
##  Generates npmrc
## 
##  LSDautomate
##  <automate@lsdopen.io>
##

if [ "$(id -u)" != "0" ]; then
  echo "$0 must be executed as root user to set global npmrc"
  exit 1
fi

if [ -n "$NPM_REGISTRY" ] && [ -n "$NPM_AUTH" ]; then

    mkdir -p /usr/etc

    if [ -n "$NPM_CAFILE" ]; then

        cat <<EOF >> /usr/etc/npmrc
cafile=$NPM_CAFILE
registry=$NPM_REGISTRY
_auth=$NPM_AUTH
EOF

    else

        echo "Omitting cafile due to missing NPM_CAFILE environment variable"
            cat <<EOF >> /usr/etc/npmrc
registry=$NPM_REGISTRY
_auth=$NPM_AUTH
EOF
    fi

else

    echo "Environment variables NPM_REGISTRY and NPM_AUTH are undefined, skipping gennpmrc.sh"
    exit 0

fi




