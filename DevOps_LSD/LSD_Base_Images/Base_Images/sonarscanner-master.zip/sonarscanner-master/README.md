# LSD Automate

## SonarScanner CLI Builder


* Base image is official sonarscanner upstream (see Dockerfile)
* PEM certificates found within files/pki will be added to global trust store and jks
* The following runtime variables are added to global SonarScanner properties file (found under files/sonarscanner/sonar-scanner.properties):

```
- SONAR_HOST_URL:   SonarQube URL
- SONAR_API_TOKEN:  Token for SonarQube authentication
```

## Build image
```-> %  docker build -t lsd-automate-sonarscanner-builder:${VERSION}-${BRANCH} .```

## Run image
```
-> % docker run lsd-automate-sonarscanner-builder:${VERSION}-${BRANCH} 
```
## Documentation

Official SonarScanner documentation is available at: https://docs.sonarqube.org/latest/analysis/scan/sonarscanner

### Version
See VERSION

### Author(s)
LSD Solutioneering

###### LSD Information Technology
###### automate@lsdopen.io
2021

