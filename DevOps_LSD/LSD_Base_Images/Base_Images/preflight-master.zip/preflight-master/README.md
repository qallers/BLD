# LSDautomate: Base Images
  
## Preflight Builder

Preflight Builder Image

* Base image is official ubuntu:latest (see Dockerfile)
* PEM certificates found within files/pki will be added to global trust store and jks
* The preflight builder defines specific build parameters based on GitLab CI variables:

1. A VERSION file is expected in the workspace directory (the git repository root directory)
2. A PIPELINE_VERSION (string) variable is defined and set to true or false to activate auto-incremented versioning
3. Note, if HTTP|S_PROXY env vars are passed at build time the aptproxy.sh script will configure 
   the proxy settings in the container for apt accordingly
4. The following GitLab CI variables are currently taken into account (see files/scripts/preflight.sh for more detail):

```
- CI_COMMIT_TAG
- CI_COMMIT_BRANCH
- CI_PIPELINE_ID
- CI_COMMIT_TITLE
```

A detailed explanation of GitLab CI predefined variables can be found at: https://docs.gitlab.com/ee/ci/variables/predefined_variables.html

### preflight.sh variables and operation:

* **PIPELINE_VERSION**:    When "true" will set patch version to CI_PIPELINE_IID. 
                           When building off a tag, the tag is the preferred version.
                           (Defined as BUILD_VERSION environment variable). When false
                           the major.minor.patch specified in VERSION is used.

* **BUILD_VERSION**:       Represents the current major.minor specified in VERSION file
                           with the patch version set to GitLab CI variable CI_PIPELINE_IID
                           when PIPELINE_VERSION is true.
                           When building off a tag the CI_PIPELINE_IID is ommited and the tag
                           is used as the sole BUILD_VERSION.
                           When building from a branch, BUILD_VERSION is set with major.minor 
                           from the VERSION file and patch set to CI_PIPELINE_IID.  

* **BUILD_PROFILE**:   Defines which build profile should use at compilation.
                       When building from branch master the prod profile is used,
                       for all other branches the dev profile is used.
                       When building from a tag with "release" in its commit msg the prod
                       profile is used, for all other tags the dev profile is used.

* **BUILD_ENV**:        Specifies the environment to be used for deployments into Kubernetes
                        when using the kube-deployer deployment workflow.

* **BRANCH_TAG**:       When  BRANCH_IMAGE_TAG is "true" and building from a branch, the BRANCH_TAG
                        environment variable will be set to IMAGE:BUILD_VERSION-BUILD_BRANCH in-line
                        with builder.sh in the builder image.

## Build image
```-> %  docker build -t lsdautomate-preflight-builder:${VERSION}-${BRANCH} .```

## Run image
```
-> % docker run -it lsdautomate-preflight-builder:1.0.0-dev
```

### Version
See VERSION

### Author(s)
LSD Solutioneering

###### LSD Information Technology
###### automate@lsdopen.io
2020
