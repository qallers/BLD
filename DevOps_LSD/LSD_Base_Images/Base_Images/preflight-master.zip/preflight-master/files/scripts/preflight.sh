#!/usr/bin/env bash
## 
##  preflight.sh
##  Preflight for GitLab CI
## 
##  LSDautomate
##  <automate@lsdopen.io>
##

# Preflight variables:
# 
# PIPELINE_VERSION: When "true" will set patch version to CI_PIPELINE_IID. 
#                   When building off a tag, the tag is the preferred version.
#                   (Defined as BUILD_VERSION environment variable). When false
#                   the major.minor.patch specified in VERSION is used.
#
# BUILD_VERSION:    Represents the current major.minor specified in VERSION file
#                   with the patch version set to GitLab CI variable CI_PIPELINE_IID
#                   when PIPELINE_VERSION is true.
#                   When building off a tag the CI_PIPELINE_IID is ommited and the tag
#                   is used as the sole BUILD_VERSION.
#                   When building from a branch, BUILD_VERSION is set with major.minor 
#                   from the VERSION file and patch set to CI_PIPELINE_IID.  
# 
# BUILD_PROFILE:    Defines which build profile should use at compilation.
#                   When building from branch master the prod profile is used,
#                   for all other branches the dev profile is used.
#                   When building from a tag with "release" in its commit msg the prod
#                   profile is used, for all other tags the dev profile is used.
# 
# BUILD_ENV:        Specifies the environment to be used for deployments into Kubernetes
#                   when using the kube-deployer deployment workflow.
#
# BRANCH_TAG:       When  BRANCH_IMAGE_TAG is "true" and building from a branch, the BRANCH_TAG
#                   environment variable will be set to IMAGE:BUILD_VERSION-BUILD_BRANCH in-line
#                   with builder.sh in the builder image.

# Disable case sensitivity when string matching
shopt -s nocaseglob

# Building off branch:
if [ -n "$CI_COMMIT_BRANCH" ]; then

    # For version tracking and attribution with PIPELINE_IIDs
    if [ "$PIPELINE_VERSION" = "true" ]; then

        # BUILD_VERSION=VERSION.$CI_PIPELINE_IID
        VERSION=$(cat "$CI_PROJECT_DIR"/VERSION)
        BUILD_VERSION=${VERSION%.*}.$CI_PIPELINE_IID

    else

        # PIPELINE_VERSION is false, fallback to VERSION file
        BUILD_VERSION=$(cat VERSION | xargs)

    fi

    # Set BUILD_VERSION within build.env 
    echo "BUILD_VERSION=$BUILD_VERSION" >> build.env

    # Set BRANCH_TAG when BRANCH_IMAGE_TAG is true
    if [ "$BRANCH_IMAGE_TAG" = "true" ]; then

        # Scrub branch name of special characters
        BUILD_BRANCH=${CI_COMMIT_REF_SLUG//[^[:alnum:]]/-}

        case "$CI_COMMIT_REF_SLUG" in                                                     
            master  ) echo "BRANCH_TAG=$BUILD_VERSION"               >> build.env   ;;  
            *       ) echo "BRANCH_TAG=$BUILD_VERSION-$BUILD_BRANCH" >> build.env   ;;  
        esac  

    fi  

    # Set BUILD_PROFILE from branch name
    case "$CI_COMMIT_BRANCH" in                                                     
        master  ) echo "BUILD_PROFILE=prod"       >> build.env
                  echo "BUILD_ENV=staging"        >> build.env
                  echo "NPM_BUILD_ENV=production" >> build.env
                ;;
        qa      ) echo "BUILD_PROFILE=prod"       >> build.env
                  echo "BUILD_ENV=staging"        >> build.env
                  echo "NPM_BUILD_ENV=production" >> build.env
                ;;  
        develop ) echo "BUILD_PROFILE=dev"         >> build.env
                  echo "BUILD_ENV=dev"             >> build.env
                  echo "NPM_BUILD_ENV=development" >> build.env
                ;;  
        *       ) echo "BUILD_PROFILE=dev"         >> build.env
                  echo "BUILD_ENV=dev"             >> build.env
                  echo "NPM_BUILD_ENV=development" >> build.env
                ;;
    esac

fi

# Building off tag:
if [ -n "$CI_COMMIT_TAG" ]; then
   
    # Tag overrides all other versioning
    # set BUILD_VERSION to CI_COMMIT_TAG
    echo "BUILD_VERSION=$CI_COMMIT_TAG" >> build.env

    # Set BUILD_PROFILE from commit message
    # "release" string signals a prod build
    case "$CI_COMMIT_TITLE" in                                                     
        *"release"* ) echo "BUILD_PROFILE=prod"       >> build.env
                      echo "BUILD_ENV=prod"           >> build.env
                      echo "NPM_BUILD_ENV=production" >> build.env
                    ;;  
        *           ) echo "BUILD_PROFILE=dev"         >> build.env
                      echo "BUILD_ENV=dev"             >> build.env
                      echo "NPM_BUILD_ENV=development" >> build.env
                    ;;
    esac

fi

