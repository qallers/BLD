# LSD Automate: Maven Builder

Maven Builder Image

* Base image is official maven upstream (see Dockerfile)
* PEM certificates found within files/pki will be added to global trust store and jks
* The following runtime variables are added to global maven settings.xml (required for Nexus), and assumes you have a Maven group with all the necessary proxy, hosted and snapshot repositories added:

```
- NEXUS_REPO_ID  :     To be referenced within pom files, i.e. my-maven-group
- NEXUS_REPO_USER:     Nexus repository username with sufficient rights to access repositories and release artifacts  
- NEXUS_REPO_PASS:     Nexus repository password
- NEXUS_REPO_URL :     Fully qualified URL to Nexus group repository, i.e. https://nexus.fqdn/repository/my-maven-group/
```

## Build image
```-> %  docker build -t lsd-automate-maven-builder:${VERSION}-${BRANCH} .```

## Run image
```
-> % docker run -e NEXUS_REPO_USER=nxrm \
                -e NEXUS_REPO_PASS=nxrmpass \
                -e NEXUS_REPO_URL=https://nxrm.url \
                -it lsd-automate-maven-builder:1.0.0-dev
```

### Version
See VERSION

### Author(s)
LSD Solutioneering

###### LSD Information Technology
###### automate@lsdopen.io
2020
