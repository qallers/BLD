#!/usr/bin/env sh
##
##  aptproxy.sh
##  Set proxy for APT if defined as env var
## 
##  LSDautomate
##  <automate@lsdopen.io>
##

if [ "$(id -u)" != "0" ]; then
  echo "$0 must be executed as root user to set apt proxy"
  exit 1
fi

if [ ! -f /etc/debian_version ]; then 

  echo "$0 must be run on a debian base image"
  exit 1

fi

if [ ! -z $HTTP_PROXY ]; then
   echo "$0 detected env HTTP_PROXY ($HTTP_PROXY)"
   mkdir -p /etc/apt/apt.conf.d
   echo "Acquire::http::Proxy \"$HTTP_PROXY\";" >> /etc/apt/apt.conf.d/proxy.conf
fi

if [ ! -z $HTTPS_PROXY ]; then
   echo "$0 detected env HTTPS_PROXY ($HTTPS_PROXY)"
   mkdir -p /etc/apt/apt.conf.d
   echo "Acquire::https::Proxy \"$HTTPS_PROXY\";" >> /etc/apt/apt.conf.d/proxy.conf
fi
