# LSDautomate: Base Images

## AWX Deployer Image

### Shared with LSD Automate: awx-cli
* Base image is official python:latest (see Dockerfile)
* PEM certificates found within files/pki will be added to global trust store and jks
* Installs the latest version of awx-cli
* Environment variables to be set for awx-cli config - see files/awx-cli/tower_cli.cfg

```
host = ${env.AWX_HOST}
username = ${env.USERNAME}
password = ${env.AWX_PASSWORD}
certificate = ${env.AWX_CERTIFICATE}
```

See the awx-cli/tower-cli documentation: https://tower-cli.readthedocs.io/en/latest/

## Build image
```-> %  docker build -t lsdautomate-awx-deployer:${VERSION}-${BRANCH} .```

## Run image
```
-> % docker run -it lsd-automate-awx-deployer:1.0.0-dev
```

### Version
See VERSION

### Author(s)
LSD Solutioneering

###### LSD Information Technology
###### automate@lsdopen.io
2021
