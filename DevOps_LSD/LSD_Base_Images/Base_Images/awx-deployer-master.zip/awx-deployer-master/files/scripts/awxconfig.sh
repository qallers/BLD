#!/usr/bin/env bash
##
##  awxconfig.sh
##  Configure ~/.tower_cli.cfg based on preset environment variables
##
##  LSD Automate
##  <automate@lsdopen.io>
##

preflight() {

    REQUIRED_VARS=(
                "AWX_HOST"
                "AWX_USERNAME"
                "AWX_PASSWORD"
                "AWX_CERTIFICATE"
    )

    for REQUIRED_VAR in "${REQUIRED_VARS[@]}"; do
        if [[ -z ${!REQUIRED_VAR+x} ]]; then
            echo "$0 error: $REQUIRED_VAR is not defined" >&2
            usage
            exit 1
        fi
    done

    mkdir -p /etc/tower
    chmod 755 /etc/tower
}

awx_config() {

cat << EOF >> /etc/tower/tower_cli.cfg
[general]
host = $AWX_HOST
username = $AWX_USERNAME
password = $AWX_PASSWORD
certificate = $AWX_CERTIFICATE
EOF

}

preflight
awx_config