# LSDautomate: Base Images

## Image Builder

* Base image is official gcr.io/kaniko-project/executor:latest (see Dockerfile)
* A multistage build is used to extract the Kaniko executor to Alpine (as busybox does not have a similarly rich runtime)
* Configures tagging parameters for Kaniko based image builds, referenced below (as described within: **files/scripts/builder.sh**):

### builder.sh variables and operation:

* **BRANCH_IMAGE_TAG**:     When "true" images will be tagged as IMAGE:BUILD_VERSION-BUILD_BRANCH
                            If the BUILD_BRANCH (CI_COMMIT_REF_SLUG scrubbed of special characters)
                            is master then no branch name will be added to the image tag, i.e. the 
                            image will be tagged as IMAGE:BUILD_VERSION

* **BUILD_BRANCH**:         Is the GitLab CI variable CI_COMMIT_REF_SLUG with special  
                            characters replaced with dashes (specifically to address feature/branch
                            named branches).

* **BUILD_VERSION**:        If defined (i.e. when preflight is used), BUILD_VERSION will
                            be used when tagging the image.

* **BUILD_IMAGE**:          Represents the full image path which will be pushed, i.e.
                            CI_REGISTRY/project/path/image:BUILD_TAG
 
* **BUILD_TAG**:            If the GitLab CI environment variable CI_BUILD_TAG is defined 
                            then the tag will be preferred over any other versioning
                            options when setting the image tag (i.e. it overrides all others).
                            If BUILD_VERSION is not defined (i.e. no preflight is used) then
                            the builder script will attempt to use the first string in the first
                            line of a VERSION file, if one is present within the checked out 
                            repository.
                            BUILD_TAG will take the form of the following:
                            1) If building from a tag then BUILD_TAG is set to CI_BUILD_TAG, else:
                            2) If BUILD_VERSION is defined, BUILD_TAG is set to BUILD_VERSION, else
                            3) If CI_PROJECT_DIR/VERSION file exists, BUILD_TAG is set to this.
                            Additional: If BRANCH_IMAGE_TAG is "true" and branch is not master,
                            BUILD_TAG is set to BUILD_TAG-BUILD_BRANCH

* **IMAGE_SKIP_TLS**:       Will append "--skip-tls-verify" to the Kaniko build argument when set to "true"
  
* **Operation**:            Any additional Kaniko executor parameters can be passed to this script
                            at runtime, i.e. builder.sh --build-arg=KEY=$$VALUE

* Configures default Kaniko configuration (/kaniko/.docker/config.json) to enable certificate trust and registry authentication (as described within: **files/scripts/kaniko.sh**):

### kaniko.sh required environment variables and operation (sourced from GitLab CI)
 
* **CI_REGISTRY**:                 Image registry FQDN (Environment variable within GitLab)
 
* **CI_REGISTRY_SVC_USER**:        Registry username
 
* **CI_REGISTRY_SVC_PASSWORD**:    Registry password

* **Operation**:            ./kaniko.sh /path/to/registry/certificates

### kaniko.sh optional environment variables:
 
* **HTTP_PROXY**:      Will be set as httpProxy within /kaniko/.docker/config.json

* **HTTPS_PROXY**:     Will be set as httpsProxy within /kaniko/.docker/config.json
 
* **NO_PROXY**:        Will be set as noProxy within /kaniko/.docker/config.json

## Build image
```-> %  docker build -t lsdautomate-image-builder:${VERSION}-${BRANCH} .```

## Run image
```
-> % docker run -it lsdautomate-image-builder:1.0.0-develop
```

### Version
See VERSION

### Author(s)
automate@lsdopen.io

###### LSD Information Technology
###### automate@lsdopen.io
2021
