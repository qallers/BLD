#!/busybox/env sh
##
##  kaniko.sh 
##  Sets the default configuration values for Kaniko, specifically
##  registry authentication, proxy and certificate trust
## 
##  LSDautomate
##  <automate@lsdopen.io>
##

# Test cert directory has been passed as a runtime argument
if [ -z "$1" ]; then
  echo "$0 error: expects path to PEM certificates"
  exit 1
fi

CERT_DIR="$1"

# Confirm image registry environment variables are set
if [ -z "$CI_REGISTRY" ] || [ -z "$CI_REGISTRY_SVC_USER" ] || [ -z "$CI_REGISTRY_SVC_PASSWORD" ]; then
  echo "$0 error: environment variables CI_REGISTRY, CI_REGISTRY_SVC_USER and CI_REGISTRY_SVC_PASSWORD to be set"
  exit 1
fi

# Configure Kaniko registry credentials (Kaniko expects a dockercfg file under /kaniko/.docker/config.json)
# Set docker proxy if env vars HTTP(S)_PROXY & NO_PROXY are defined
mkdir -p /kaniko/.docker
if [ -n "$HTTP_PROXY" ] && [ -n "$HTTPS_PROXY" ] && [ -n "$NO_PROXY" ]; then

cat > /kaniko/.docker/config.json <<EOF
{
	"auths": {
		"$CI_REGISTRY": {
			"username": "$CI_REGISTRY_SVC_USER",
			"password": "$CI_REGISTRY_SVC_PASSWORD"
		}
	},
	"proxies": {
		"default": {
			"httpProxy": "$HTTP_PROXY",
			"httpsProxy": "$HTTPS_PROXY",
			"noProxy": "$NO_PROXY"
		}
	}
}
EOF

else

cat > /kaniko/.docker/config.json <<EOF
{
	"auths": {
		"$CI_REGISTRY": {
			"username": "$CI_REGISTRY_SVC_USER",
			"password": "$CI_REGISTRY_SVC_PASSWORD"
		}
	}
}
EOF

fi

# Configure custom CAs for Kaniko trust
mkdir -p /kaniko/ssl/certs
cp "$CERT_DIR"/additional-ca-cert-bundle.crt /kaniko/ssl/certs/additional-ca-cert-bundle.crt
