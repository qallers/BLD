#!/busybox/env sh
##
##  builder.sh
##  Builder sets up tagging parameters for Kaniko image builds (https://github.com/GoogleContainerTools/kaniko)
## 
##  LSDautomate
##  <automate@lsdopen.io>
##

# Builder variables and operation:
# 
# BRANCH_IMAGE_TAG: When "true" images will be tagged as IMAGE:BUILD_VERSION-BUILD_BRANCH
#                   If the BUILD_BRANCH (CI_COMMIT_REF_SLUG scrubbed of special characters)
#                   is master then no branch name will be added to the image tag, i.e. the 
#                   image will be tagged as IMAGE:BUILD_VERSION
#
# BUILD_BRANCH:     Is the GitLab CI variable CI_COMMIT_REF_SLUG with special  
#                   characters replaced with dashes (specifically to address feature/branch
#                   named branches).
#
# BUILD_VERSION:    If defined (i.e. when preflight is used), BUILD_VERSION will
#                   be used when tagging the image.
#
# BUILD_IMAGE:      Represents the full image path which will be pushed, i.e.
#                   CI_REGISTRY/project/path/image:BUILD_TAG
# 
# BUILD_TAG:        If the GitLab CI environment variable CI_BUILD_TAG is defined 
#                   then the tag will be preferred over any other versioning
#                   options when setting the image tag (i.e. it overrides all others).
# 
#                   If BUILD_VERSION is not defined (i.e. no preflight is used) then
#                   the builder script will attempt to use the first string in the first
#                   line of a VERSION file, if one is present within the checked out 
#                   repository.
#                   BUILD_TAG will take the form of the following:
#                   1) If building from a tag then BUILD_TAG is set to CI_BUILD_TAG, else:
#                   2) If BUILD_VERSION is defined, BUILD_TAG is set to BUILD_VERSION, else
#                   3) If CI_PROJECT_DIR/VERSION file exists, BUILD_TAG is set to this.
#                   
#                   Additional: If BRANCH_IMAGE_TAG is "true" and branch is not master,
#                               BUILD_TAG is set to BUILD_TAG-BUILD_BRANCH
#
# Operation:        Any additional Kaniko executor parameters can be passed to this script
#                   at runtime, i.e. builder.sh --build-arg=KEY=$$VALUE
#

# Optional variables:
#
# IMAGE_SKIP_TLS:  Will append "--skip-tls-verify" to the Kaniko build argument when set to "true"
#

# Use CI_BUILD_TAG for image tag if defined
if [ -n "$CI_BUILD_TAG" ]; then
  BUILD_TAG="$CI_BUILD_TAG"
  echo "Found CI_BUILD_TAG, setting $BUILD_TAG as BUILD_TAG"

# BUILD_VERSION is defined (preflight) use with image tag
elif [ -n "$BUILD_VERSION" ]; then
  BUILD_TAG="$BUILD_VERSION"
  echo "Found BUILD_VERSION, setting $BUILD_TAG as BUILD_TAG"

# No BUILD_VERSION defined, default to VERSION file if it exists
elif [ -f "$CI_PROJECT_DIR/VERSION" ]; then
  BUILD_TAG=$(cat "$CI_PROJECT_DIR"/VERSION | xargs)
  echo "Found VERSION file, setting $BUILD_TAG as BUILD_TAG"

fi

# BRANCH_IMAGE_TAG is true, append branch to BUILD_TAG for non-master branches
if [ "$BRANCH_IMAGE_TAG" = "true" ]; then

  BUILD_BRANCH=${CI_COMMIT_REF_SLUG//[^[:alnum:]]/-}

  case "$CI_COMMIT_REF_SLUG" in                                                     
    master  ) echo "Building from master branch, using tag: $BUILD_TAG" ;;  
    *       ) BUILD_TAG=$BUILD_TAG-$BUILD_BRANCH                        ;;  
  esac  

fi

# Debug Image Path 
echo "Pushing to: $CI_REGISTRY_IMAGE:$BUILD_TAG"

# Build and push image
case "$IMAGE_SKIP_TLS" in
  true  ) /kaniko/executor --context $CI_PROJECT_DIR --dockerfile $CI_PROJECT_DIR/Dockerfile --destination $CI_REGISTRY_IMAGE:$BUILD_TAG --skip-tls-verify $@  ;;
  *     ) /kaniko/executor --context $CI_PROJECT_DIR --dockerfile $CI_PROJECT_DIR/Dockerfile --destination $CI_REGISTRY_IMAGE:$BUILD_TAG $@                    ;;
esac