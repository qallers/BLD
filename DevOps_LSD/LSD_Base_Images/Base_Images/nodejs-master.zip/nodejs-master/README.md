# LSDautomate: Base Images

## NodeJS Builder

* Base image is official nodejs upstream (current-buster-slim)
* PEM certificates found within files/pki will be added to global trust store
* gennpmrc.sh will generate generate a global npmrc (/usr/etc/npmrc or $PREFIX/etc/npmrc) when the following build-args are set:

```
NPM_CAFILE      - NPM registry CA certificate
NPM_REGISTRY    - NPM registry URL
NPM_TOKEN       - NPM registry auth token
```

## Build image
```-> %  docker build -t lsdautomate-nodejs-builder:1.0.0 . --build-arg=NPM_REGISTRY=https://registry.url```

## Run image
```
-> % docker run -it lsd-automate-nodejs-builder:1.0.0-dev
```

### Version
See VERSION

### Author(s)
LSD Solutioneering

###### LSD Information Technology
###### automate@lsdopen.io
2021
