#!/usr/bin/env sh
##
##  gennpmrc.sh
##  Generates npmrc
## 
##  LSDautomate
##  <automate@lsdopen.io>
##

if [ -n "$NPM_REGISTRY" ] && [ -n "$NPM_TOKEN" ]; then

    NPM_AUTH_URL="${NPM_REGISTRY#/*\:/}"

    if [ -n "$NPM_CAFILE" ]; then

        cat <<EOF >> $HOME/.npmrc
cafile=$NPM_CAFILE
registry=$NPM_REGISTRY
always-auth=true
$NPM_AUTH_URL:_authToken=$NPM_TOKEN
EOF

    else

        echo "Omitting cafile due to missing NPM_CAFILE environment variable"
            cat <<EOF >> $HOME/.npmrc
registry=$NPM_REGISTRY
always-auth=true
$NPM_AUTH_URL:_authToken=$NPM_TOKEN
EOF
    fi

else

    echo "Environment variables NPM_REGISTRY and NPM_TOKEN are undefined, skipping gennpmrc.sh"
    exit 0

fi




