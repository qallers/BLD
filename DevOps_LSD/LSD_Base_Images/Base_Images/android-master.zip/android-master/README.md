# LSD Automate: Android Builder

Android Builder Image

* Base image is official maven upstream (see Dockerfile)
* PEM certificates found within files/pki will be added to global trust store and jks

## Build image
```-> %  docker build -t lsd-automate-android-builder:${VERSION}-${BRANCH} .```

## Run image
```
-> % docker run -it lsd-automate-android-builder:1.0.0
```

### Version
See VERSION

### Author(s)
LSD Solutioneering

###### LSD Information Technology
###### automate@lsdopen.io
2020
