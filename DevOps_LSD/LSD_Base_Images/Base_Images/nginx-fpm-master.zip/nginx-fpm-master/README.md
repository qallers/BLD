# LSDautomate: Base Images

## Nginx PHP-FPM Builder

* Base image is official php upstream (using fpm-buster)
* PEM certificates found within files/pki will be added to global trust store and jks
* NodeJS version is set via the build argument NODE_VERSION 
* Upstream composer is installed
* Nginx installed and pre-configred to reverse proxy fpm (*see files/config/nginx.conf*)
* Supervisord installed and pre-configured to start nginx and php-fpm (nginx listens on port 8080)

## Build image
```-> % docker build -t lsdautomate-nginx-fpm-builder:1.0.0 . --build-arg=NODE_VERSION=12```

## Run image
```
-> % docker run -it lsdautomate-nginx-fpm-builder:1.0.0-dev
```

### Version
See VERSION

### Author(s)
LSD Solutioneering

###### LSD Information Technology
###### automate@lsdopen.io
2021
