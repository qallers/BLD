# Contributing

When contributing to this repository, please first discuss the change you wish to make via issue,
email, or any other method with the owners of this repository before making a change.

## Merge Request Process

1. Ensure any install or build dependencies are removed before the end of the layer when doing a
   build.
2. Update the README.md with details of changes to the interface, this includes new environment
   variables, exposed ports, useful file locations and container parameters.
3. Increase the relevant version numbers in the VERSION file within this repository to the new version that this
   Merge Request would represent. It is at the contributors discretion as to what additions constitute a major version increment.
   (SemVer provides a good foundation for increments https://semver.org/). 
4. Mantainers may approve the Merge request based should all automated build, test and quality requirements be upheld