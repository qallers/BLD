package za.co.blts.bltandroidgui3;

import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidParameterException;

import android_serialport_api.SerialPort;


class CashDrawerUtil {
    private static final String TAG = CashDrawerUtil.class.getSimpleName();

    private static SerialPort mSerialPort = null;

    private static void getSerialPort() throws SecurityException, IOException, InvalidParameterException {
        if (mSerialPort == null) {
            mSerialPort = new SerialPort(new File("/dev/ttyS1"), 115200, 0, true);
        }
    }

    private static void closeSerialPort() {
        if (mSerialPort != null) {
            mSerialPort.close();
            mSerialPort = null;
        }
    }


    public static void openCash() {

        try {
            getSerialPort();
            OutputStream mOutputStream = mSerialPort.getOutputStream();

            byte[] printText = new byte[6];

            printText[1] = 0x1B;
            printText[2] = 0x70;
            printText[3] = 0x00;
            printText[4] = (byte) 0x80;
            printText[5] = (byte) 0x80;
            mOutputStream.write(printText);
            closeSerialPort();
            //This is for testing purposes
            //Do Not Remove
            Log.v(TAG, "TEST : CASH DRAWER OPEN");
        } catch (Exception ex) {
            Log.v(TAG, "openCash throwing " + ex);
        }
    }

}