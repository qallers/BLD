package za.co.blts.bltandroidgui3.confirmations.printPreview;

import java.lang.ref.WeakReference;
import java.util.List;

import za.co.blts.bltandroidgui3.ActivityMain;
import za.co.blts.reactnative.FragmentCrossBorder;

public class BluDroidJsonSlipPreviewIPayDialog extends BluDroidJsonSlipPreviewDialog {
    private final String TAG = this.getClass().getSimpleName();
    private WeakReference<FragmentCrossBorder> fragmentReference;

    public BluDroidJsonSlipPreviewIPayDialog(final FragmentCrossBorder fragment, List<JsonPrintJob> printJobs) {
        super(fragment.getBaseActivity(), printJobs);
        fragmentReference = new WeakReference<>(fragment);
        setTitle("Voucher Preview");
        setup();
    }

    public void finishTransaction() {
        FragmentCrossBorder fragment = fragmentReference.get();
        if (fragment != null) {
            fragment.completePrint();
        }
    }
}
