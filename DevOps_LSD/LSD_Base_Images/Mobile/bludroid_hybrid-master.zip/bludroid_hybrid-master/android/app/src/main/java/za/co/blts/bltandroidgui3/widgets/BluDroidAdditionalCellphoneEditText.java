package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.text.Editable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/6/2017.
 */

public class BluDroidAdditionalCellphoneEditText extends BluDroidIntegerEditText {
    private final String TAG = this.getClass().getSimpleName();
    private int prevL = 0;

    public BluDroidAdditionalCellphoneEditText(BaseActivity context) {
        super(context);
        setUpCell();

    }

    public BluDroidAdditionalCellphoneEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpCell();
    }

    private void setUpCell() {

        maxLength = 12;
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(maxLength);
        setFilters(inputFilters);
        setOnFocusChangeListener(this);

    }


    @Override
    public boolean validate() {
        Log.d(TAG, "validate");
        String cellphoneRegex = "^0[0-9].*$";
        String cellphoneString = getText().toString().trim();

        if (cellphoneString.equalsIgnoreCase("")) {
            removeErrorMessage();
            return true;
        } else {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                if (tryParseInt(cellphoneString)) {

                    cellphoneString = cellphoneString.replace(" ", "");

                    if (cellphoneString.length() == 10 && cellphoneString.matches(cellphoneRegex)) {
                        removeErrorMessage();
                        return true;
                    } else {
                        setErrorMessage(baseScreen.getResources().getString(R.string.cellNumberInvalid));
                        return false;
                    }
                } else {
                    setErrorMessage(baseScreen.getResources().getString(R.string.cellNumberNotEntered));
                    return false;
                }
            }
        }
        return false;
    }

    boolean tryParseInt(String value) {
        try {
            value = value.replace(" ", "");
            Integer.parseInt(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        prevL = getText().toString().length();
    }

    @Override
    public void afterTextChanged(Editable editable) {
        int length = editable.length();
        String data = getText().toString();

        if ((prevL < length) && (length == 3 || length == 7)) {
            String addSpace = data + " ";
            setText(addSpace);
            setSelection(length + 1);
        }

        /*
         * when a user changes the cell number and remove a space in the cell number the edit text then adds the second space
         * */
        int spaces = data.length() - data.replace(" ", "").length();
        if (length > 10 && spaces == 1) {
            data = data.replace(" ", "");
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < data.length(); i++) {
                if (i == 3) {
                    result.append(" ");
                }
                if (i == 6) {
                    result.append(" ");
                }
                result.append(data.charAt(i));
            }
            setText(result.toString());
        }
    }
}
