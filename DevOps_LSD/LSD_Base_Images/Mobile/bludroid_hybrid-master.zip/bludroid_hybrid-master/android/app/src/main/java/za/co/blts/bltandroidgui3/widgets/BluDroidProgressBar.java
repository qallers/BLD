package za.co.blts.bltandroidgui3.widgets;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.util.Log;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ProgressBar;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 2/20/2017.
 */

public class BluDroidProgressBar extends Dialog implements BluDroidSetupable {

    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference;

    private BluDroidTextView messageTextView;

    public void setContext(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    public void setup() {
        try {
            Log.d(TAG, "setup");
            if (baseActivityWeakReference != null) {
                BaseActivity baseActivity = baseActivityWeakReference.get();
                BluDroidRelativeLayout layout = this.findViewById(R.id.layout);
                layout.setContext(baseActivity);

                layout.setBackgroundColor(Color.TRANSPARENT);
                getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                messageTextView = this.findViewById(R.id.message);
                messageTextView.setContext(baseActivity);
                messageTextView.setTextColor(baseActivity.getResources().getColor(R.color.progressBarTextColor));
                messageTextView.setTextSize(20);

                ProgressBar progressBar = findViewById(R.id.progressBar);

                progressBar.getIndeterminateDrawable().setColorFilter(baseActivity.getResources().getColor(R.color.progressBarLoadingColor),
                        android.graphics.PorterDuff.Mode.SRC_IN);
                setCancelable(false);
            }
        } catch (Exception exception) {
            Log.d(TAG, "problem setting up confirmation " + exception);
        }
    }

    public BluDroidProgressBar(BaseActivity context) {
        super(context);
        //
        // this request Feature must execute before the layout is expanded
        //
        this.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        this.baseActivityWeakReference = new WeakReference<>(context);
        this.setContentView(R.layout.progress_dialog);
        setup();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            this.getWindow().setLayout(300, ViewGroup.LayoutParams.MATCH_PARENT);
        } else {
            this.getWindow().setLayout(300, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        Log.d(TAG, "showing");

        this.show();
    }

    public void setMessage(String message) {
        // messageTextView = (BluDroidTextView) this.findViewById(R.id.message);
        BaseActivity.logger.info(": setting a new message to progressBar " + message);
        messageTextView.setText(message);
    }

    public void updateMessage(String message) {
        BaseActivity.logger.info(": updating a new progressBar with message " + message);
        messageTextView.setText(message);
    }

    public void setMessage(int messageResourceId) {
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                setMessage(baseActivity.getResources().getString(messageResourceId));
            }
        }
    }


}
