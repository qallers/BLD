package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by Warren2.0 on 10/04/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00140_DataPinless_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_Vodacom_100MB() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "VODACOM MENU selected");

            gotoPinlessBundles();
            Log.d(TAG, "PINLESS TOP UP data vouchers selected");

            solo.clickOnText("100MB");
            Log.d(TAG, "100MB PINLESS TOP UP data voucher selected");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with no cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberNotEntered))) {
                Log.d(TAG, "Cellphone number not entered error message displayed");
            } else {
                fail("Cellphone number not entered error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "1121231234");
            Log.d(TAG, "Invalid cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "1121231234");
            Log.d(TAG, "Invalid cellphone number confirmed");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with invalid cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberInvalid))) {
                Log.d(TAG, "Cellphone number invalid error message displayed");
            } else {
                fail("Cellphone number invalid error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "0601231234");
            Log.d(TAG, "Not Matching Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0601231235");
            Log.d(TAG, "Not Matching Cellphone number confirmed");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with mismatching cellphone numbers");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumbersDontMatch))) {
                Log.d(TAG, "Cellphone numbers don't match error message displayed");
            } else {
                fail("Cellphone numbers don't match error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "0601231235");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0601231235");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T100_Mtn_300MB() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }
            //scroll for telkom using cellc
            selectProviderMTN();
            Log.d(TAG, "MTN MENU selected");

            gotoPinlessBundles();
            Log.d(TAG, "MTN TOP UP data vouchers selected");

            solo.clickOnText("300MB");
            Log.d(TAG, "100MB PINLESS TOP UP data voucher selected");

            checks.enterText(R.id.cellNumber, "0601231235");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0601231235");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T300_CellC_100MB() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }
            //scroll for telkom using cellc
            selectProviderCellC();
            Log.d(TAG, "CellC MENU selected");

            gotoPinlessBundles();
            Log.d(TAG, "CellC TOP UP data vouchers selected");

            solo.clickOnText("100MB");
            Log.d(TAG, "100MB PINLESS TOP UP data voucher selected");

            checks.enterText(R.id.cellNumber, "0601231235");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0601231235");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T700_Any_100MB() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }
            //scroll for All Providers using Cellc,Telkom, Neoel and Virgin Mobile
            selectProviderCellC();
            selectProviderTelkom();
            selectProviderNeotel();
            selectProviderVirginMobile();
            selectProviderAllProviders();
            Log.d(TAG, "All MENU selected");

            gotoPinlessBundles();
            Log.d(TAG, "All TOP UP data vouchers selected");

            solo.clickOnText("100MB");
            Log.d(TAG, "100MB PINLESS TOP UP data voucher selected");

            checks.enterText(R.id.cellNumber, "0601231235");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0601231235");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
