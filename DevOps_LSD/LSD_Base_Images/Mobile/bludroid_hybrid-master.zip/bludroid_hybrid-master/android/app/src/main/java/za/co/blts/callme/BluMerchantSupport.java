package za.co.blts.callme;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;

public class BluMerchantSupport extends BaseActivity implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {

    private BluDroidButton nextBtn;
    private List<CallMeCategory> categoryList;
    private List<CheckBox> checkboxList;
    private TextView callMeDescTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant_support);

        String callMeData = getCachedCallMeData();
        nextBtn = findViewById(R.id.nextButton);
        nextBtn.setEnabled(false);
        nextBtn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        nextBtn.setOnClickListener(this);
        BluDroidButton cancelBtn = findViewById(R.id.cancelButton);
        cancelBtn.setOnClickListener(this);

        try {
            JSONObject number = new JSONObject(callMeData);
            Log.d("CallMe", "valid callmedata: " + callMeData);
            JSONArray menuArray = number.getJSONArray("menu");
            categoryList = new ArrayList<>();
            checkboxList = new ArrayList<>();

            for (int i = 0; i < menuArray.length(); ++i) {
                JSONObject menu = menuArray.getJSONObject(i);
                String id = menu.getString("id");
                String desc = menu.getString("desc");
                categoryList.add(new CallMeCategory(id, desc));
            }

            for (CallMeCategory cat : categoryList) {
                Log.d("CallMe", cat.toString());
            }

            if (categoryList.isEmpty()) {
                Toast.makeText(this, "Categories cannot be empty", Toast.LENGTH_SHORT).show();
            } else {
                populateScreen();
            }

        } catch (Exception e) {
            logger.error("CallMe: invalid callmedata: " + callMeData);
            e.printStackTrace();
            Toast.makeText(this, "Invalid data", Toast.LENGTH_SHORT).show();
            gotoLandingScreen();
        }
    }

    private void populateScreen() {
        ImageView callme = findViewById(R.id.callme);
        Drawable image = getResources().getDrawable(R.drawable.callme);
        callme.setImageDrawable(image);
        Drawable roundDrawable = getResources().getDrawable(R.drawable.button_bg_shadow_rounded);
        roundDrawable.setColorFilter(getSkinResources().getButtonColor(), PorterDuff.Mode.MULTIPLY);
        callme.setBackground(roundDrawable);

        callMeDescTextView = findViewById(R.id.callMeDescTextView);
        callMeDescTextView.setText("");
        callMeDescTextView.setVisibility(View.GONE);

        ViewGroup insertPoint = findViewById(R.id.callMeLayout);

        for (int i = 0; i < categoryList.size(); i++) {
            LayoutInflater categoryInflater = getLayoutInflater();
            View callMeCategory1 = categoryInflater.inflate(R.layout.callmecategory, insertPoint, false);
            CheckBox checkBoxCallMe = callMeCategory1.findViewById(R.id.checkboxCallMe);
            TextView callMeTextView = callMeCategory1.findViewById(R.id.callMeText);
            String display = categoryList.get(i).getId();
            callMeTextView.setText(display);

            checkBoxCallMe.setId(i + 1);

            // insert into main view
            insertPoint.addView(callMeCategory1, i, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            checkboxList.add(checkBoxCallMe);
            checkBoxCallMe.setOnCheckedChangeListener(this);
        }
        for (int i = 0; i < checkboxList.size(); i++) {
            Log.d("CallMe", "inserted checkbox id " + checkboxList.get(i).getId());
        }
        insertPoint.invalidate();
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean checked) {
        Log.d("CallMe", "checkbox " + compoundButton.getText() + " check changed to " + checked);
        Log.d("CallMe", "checkbox id " + compoundButton.getId());
        if (checked) {
            for (int i = 0; i < checkboxList.size(); i++) {
                if (checkboxList.get(i).getId() != compoundButton.getId()) {
                    checkboxList.get(i).setChecked(false);
                } else {
                    callMeDescTextView.setText(categoryList.get(i).getDesc());
                }
            }
        }

        nextBtn.setEnabled(false);
        nextBtn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        for (int i = 0; i < checkboxList.size(); i++) {
            if (checkboxList.get(i).isChecked()) {
                nextBtn.setEnabled(true);
                nextBtn.setBackgroundColor(getSkinResources().getButtonColor());
                break;
            }
        }
        callMeDescTextView.setVisibility(nextBtn.isEnabled() ? View.VISIBLE : View.GONE);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.nextButton:
                for (int i = 0; i < checkboxList.size(); i++) {
                    if (checkboxList.get(i).isChecked()) {
                        String checkId = categoryList.get(i).getId();
                        gotoMerchantSupportConfirmScreen(checkId);
                        break;
                    }
                }
                break;
            case R.id.cancelButton:
                gotoLandingScreen();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        gotoLandingScreen();
    }
}

