package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;

/**
 * Created by BoitshokoM on 3/4/2018.
 */

@RunWith(AndroidJUnit4.class)
public class DEV_00901_ForcedReprint_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void testForcedReprint() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            solo.clickOnText("R2");
            Log.d(TAG, "R2 airtime voucher selected");


            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            confirmPrintVoucher();
            Log.d(TAG, "Attempting to get vouchers");

            solo.sleep(2000);

            checks.setWifi(false);
            Log.d(TAG, "Turned off WiFi");

            solo.sleep(2000);

            checks.setWifi(true);
            Log.d(TAG, "Turned on WiFi");

            solo.sleep(3000);

            solo.clickOnButton("Auto Login");
            Log.d(TAG, "Clicked 'Auto Login'");

            solo.sleep(2000);

            solo.waitForDialogToOpen();
            Log.d(TAG, "Dialog opened");

            solo.clickOnText("OK");
            Log.d(TAG, "Reprinting vouchers that did not print...");

            solo.sleep(5000);

            solo.waitForLogMessage("TenderResponseMessage");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
