package za.co.blts.bltandroidgui3;

import android.util.Log;

import com.google.gson.Gson;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

@SuppressWarnings("unused,FieldCanBeLocal")
class AwsHeartbeat {
    private String devId, date, db, ave, median, min, max;

    AwsHeartbeat(String deviceId, String sigStrength, String average, String median, String min, String max) {
        this.devId = deviceId;
        this.db = sigStrength;
        this.ave = average;
        this.min = min;
        this.max = max;
        this.median = median;
    }

    String toJson() {
        date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());

        Log.d("sigStr2", "Signal Strength " + db);
        return new Gson().toJson(this);
    }

}

