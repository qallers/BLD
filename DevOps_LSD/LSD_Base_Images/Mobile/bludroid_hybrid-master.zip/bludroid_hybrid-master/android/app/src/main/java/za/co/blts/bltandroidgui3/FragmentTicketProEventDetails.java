package za.co.blts.bltandroidgui3;


import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseEventDetailsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseSeatCategoryMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidHeading;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTicketProEventDetails extends TicketProRecycler implements NeedsAEONResults, View.OnClickListener {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidHeading txtEventName;
    private TextView txtVenue, txtDate, txtTime;
    private ListView listView;

    private BluDroidTicketProSeatListAdapter ticketProPriceListAdapter;

    public FragmentTicketProEventDetails() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment

        View rootView = inflater.inflate(R.layout.fragment_ticket_pro_event_details, container, false);
        // recycler = (BluRecyclerView) rootView.findViewById(R.id.recycler_view);
        txtEventName = rootView.findViewById(R.id.eventName);
        txtVenue = rootView.findViewById(R.id.venue);
        txtDate = rootView.findViewById(R.id.date);
        txtTime = rootView.findViewById(R.id.time);
        BluDroidButton btnNext = rootView.findViewById(R.id.next);
        BluDroidButton btnBack = rootView.findViewById(R.id.back);

        if (Build.MODEL.startsWith("CITAQ")) {
            TextView txtStadium = rootView.findViewById(R.id.txtStadium);
            txtStadium.setText(getString(R.string.view_stadium_layout));
        }

        btnNext.setOnClickListener(this);
        btnBack.setOnClickListener(this);

        listView = rootView.findViewById(R.id.pricingList);

        ImageView viewVenueLayout = rootView.findViewById(R.id.layoutIcon);

        viewVenueLayout.setOnClickListener(this);

        return rootView;
    }

    @Override
    public void onDestroy() {
        if (listView != null) listView.setAdapter(null);
        super.onDestroy();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

//    getTicketProAllEventDetails(getBaseActivity().ticketProAllProEvent);
        authenticateWithTicketPro();

//        getBaseActivity().toolbar.setNavigationDrawable();
//        getBaseActivity().toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                getBaseActivity().gotoMenuFragment();
//            }
//        });
    }

    @Override
    public void results(Object object) {

        try {
            Log.d(TAG, "results object " + object);
            Log.d(TAG, "(Details) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }

        if (object instanceof TicketProAuthenticationResponseMessage) {
            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProAuthenticationResponseMessage = (TicketProAuthenticationResponseMessage) object;

            if (getBaseActivity().ticketProAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

                if (getBaseActivity().ticketProResponseCreateCartMessage != null) {
                    getBaseActivity().ticketProResponseCreateCartMessage.setSessionId(getBaseActivity().ticketProAuthenticationResponseMessage.getSessionId());
                }

                getTicketProAllEventDetails(getBaseActivity().ticketProAllProEvent);

            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProAuthenticationResponseMessage, true);
            }
        } else if (object instanceof TicketProResponseEventDetailsMessage) {


            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProResponseEventDetailsMessage = (TicketProResponseEventDetailsMessage) object;

            if (getBaseActivity().ticketProResponseEventDetailsMessage.getEvent().getEventCode().equals("0")) {
                if (getBaseActivity().ticketProResponseEventDetailsMessage.getData().getSoldOut().equals("true")) {
                    getBaseActivity().createAlertDialog("TICKETPRO", "EVENT SOLD OUT");
                } else {

                    txtEventName.setText(getBaseActivity().ticketProResponseEventDetailsMessage.getData().getName());

                    txtVenue.setText(getBaseActivity().ticketProResponseEventDetailsMessage.getData().getVenueName());

                    if (getBaseActivity().ticketProResponseEventDetailsMessage.getData().getStartDate().length() > 0) {

                        txtDate.setText(getBaseActivity().ticketProResponseEventDetailsMessage.getData().getStartDate().substring(0, 10));

                        txtTime.setText(getBaseActivity().ticketProResponseEventDetailsMessage.getData().getStartTime().substring(10));
                    }


                    final ArrayList<TicketProSeatCategory> pricingSpinnerData = new ArrayList<>();
                    for (int i = 0; i < getBaseActivity().ticketProResponseEventDetailsMessage.getData().getSeatCategories().size(); i++) {

                        TicketProResponseSeatCategoryMessage seatCategoryMessage = getBaseActivity().ticketProResponseEventDetailsMessage.getData().getSeatCategories().get(i);

                        TicketProSeatCategory seatCategory = new TicketProSeatCategory(seatCategoryMessage.getSeatCategoryId(),
                                seatCategoryMessage.getSeatLabel(),
                                seatCategoryMessage.getPricing(),
                                seatCategoryMessage.getPriceCategories(),
                                seatCategoryMessage.getSeatsSoldOut(),
                                R.drawable.ic_checkbox_off,
                                false);
                        pricingSpinnerData.add(seatCategory);
                    }

                    ticketProPriceListAdapter = new BluDroidTicketProSeatListAdapter(getBaseActivity(), R.layout.putco_trip_row_item, pricingSpinnerData);
                    listView.setAdapter(ticketProPriceListAdapter);

                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            TicketProSeatCategory seatCategory = pricingSpinnerData.get(position);

                            if (seatCategory.getSoldOut().equalsIgnoreCase("false")) {


                                for (TicketProSeatCategory seat : pricingSpinnerData) {


                                    seat.setSelected(false);
                                    seat.setIconSelected(R.drawable.ic_checkbox_off);
                                }

                                if (!seatCategory.isSelected()) {

                                    seatCategory.setSelected(true);
                                    seatCategory.setIconSelected(R.drawable.ic_checkbox_on);

                                    getBaseActivity().ticketProSeatCategory = seatCategory;

                                } else {
                                    seatCategory.setSelected(false);
                                    seatCategory.setIconSelected(R.drawable.ic_checkbox_off);
                                }
                                ticketProPriceListAdapter.notifyDataSetChanged();
                                ticketProPriceListAdapter.notifyDataSetInvalidated();

                            } else {
                                getBaseActivity().createAlertDialog("Seats sold out", "Sorry. Your desired seats have been sold out, please choose alternate seats");
                            }

                        }
                    });
                }
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProResponseEventDetailsMessage, true);
            }
        }

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.next:
                if (getBaseActivity().ticketProSeatCategory != null) {
                    getBaseActivity().gotoFragment(new FragmentTicketProPriceCategory(), "FragmentTicketProPriceCategory");
                } else {
                    getBaseActivity().createAlertDialog("TicketPro", "Please select a seat category before you can continue.");
                }

                BaseActivity.logger.info("NEXT");
                break;
            case R.id.back:
                onBackPressed();
                break;
            case R.id.layoutIcon:
                getBaseActivity().createVenueLayoutDialog();
                BaseActivity.logger.info("View stadium layout");
            default:
                break;
        }
    }

    @Override
    public boolean onBackPressed() {
        BaseActivity.logger.info(" BACK");
        if (getBaseActivity().ticketProCategoryId.isEmpty()) {
            getBaseActivity().gotoFragment(new FragmentTicketProCategories(), "FragmentTicketProCategories");
        } else {
            getBaseActivity().gotoFragment(new FragmentTicketProEvents(), "FragmentTicketProEvents");
        }
        return true;
    }
}
