package za.co.blts.bltandroidgui3;


import java.io.Serializable;

import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestPassengerMessage;

class CarmaRequestPassengerMessageSerializable implements Serializable {
    private String title;
    private String initials;
    private String lastName;
    private String idNumber;
    private String cellNum;
    private String email;
    private String passengerType;
    private String discount;
    private String infant;

    public CarmaRequestPassengerMessageSerializable(CarmaRequestPassengerMessage carmaRequestPassengerMessage) {
        this.title = carmaRequestPassengerMessage.getTitle();
        this.initials = carmaRequestPassengerMessage.getInitials();
        this.lastName = carmaRequestPassengerMessage.getLastName();
        this.idNumber = carmaRequestPassengerMessage.getIdNumber();
        this.cellNum = carmaRequestPassengerMessage.getCellNum();
        this.email = carmaRequestPassengerMessage.getEmail();
        this.passengerType = carmaRequestPassengerMessage.getPassengerType();
        this.discount = carmaRequestPassengerMessage.getDiscount();
        this.infant = carmaRequestPassengerMessage.getInfant();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInitials() {
        return initials;
    }

    public void setInitials(String initials) {
        this.initials = initials;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getCellNum() {
        return cellNum;
    }

    public void setCellNum(String cellNum) {
        this.cellNum = cellNum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassengerType() {
        return passengerType;
    }

    public void setPassengerType(String passengerType) {
        this.passengerType = passengerType;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getInfant() {
        return infant;
    }

    public void setInfant(String infant) {
        this.infant = infant;
    }
}
