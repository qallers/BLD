package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

/**
 * Created by NkosanaM on 3/22/2017.
 */

class TransactTabRecycler extends BaseFragment {

    TabLayout tabs = null;
    ViewPager viewPager = null;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        String[] tabTitles = getResources().getStringArray(R.array.TransactOptions);

        if (getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            tabs.setTabGravity(TabLayout.GRAVITY_CENTER);
        } else {
            tabs.setTabGravity(TabLayout.GRAVITY_FILL);
        }

        if (tabs != null) {
            setupTabs(tabs, tabTitles);
        }
        TransactPagerAdapter adapter = new TransactPagerAdapter
                (getActivity().getSupportFragmentManager(), tabs.getTabCount());
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabs));
    }

    private void setupTabs(TabLayout tabs, String[] tabTitles) {

        for (String tabTitle : tabTitles) {
            tabs.addTab(tabs.newTab().setText(tabTitle));
        }

        tabs.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                switch (tab.getPosition()) {
                    case 0:
                        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentTransactAccounts", null);
                        break;
                    case 1:
                        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentTransactTrafficFines", null);
                        break;
                }

                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
}

class TransactPagerAdapter extends FragmentStatePagerAdapter {
    private int mNumOfTabs;

    TransactPagerAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                return new FragmentTransactAccounts();
            case 1:
                return new FragmentTransactTrafficFines();
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
