package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.content.res.ColorStateList;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

import androidx.appcompat.widget.SwitchCompat;
import androidx.core.graphics.drawable.DrawableCompat;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;

//
// view and button stuff
//
//
// touchy stuff
//
//
// color filtering
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidSwitch extends SwitchCompat implements OnTouchListener {
    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference = null;

    private void setUp() {
        setOnTouchListener(this);
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                //
                // see http://stackoverflow.com/questions/26788251/android-tint-using-drawablecompat/30928051
                //
                ColorStateList thumbColorStateList = new ColorStateList(
                        new int[][]{
                                new int[]{android.R.attr.state_checked},
                                new int[]{-android.R.attr.state_checked},
                        },
                        new int[]{
                                baseScreen.getSkinResources().getButtonColor(),
                                baseScreen.getSkinResources().getBackgroundColor()
                        }
                );
                ColorStateList trackColorStateList = new ColorStateList(
                        new int[][]{
                                new int[]{android.R.attr.state_checked},
                                new int[]{-android.R.attr.state_checked},
                        },
                        new int[]{
                                baseScreen.getSkinResources().getLightColor(),
                                baseScreen.getSkinResources().getLightColor()
                        }
                );
                DrawableCompat.setTintList(getThumbDrawable(), thumbColorStateList);
                DrawableCompat.setTintList(getTrackDrawable(), trackColorStateList);

                setFocusableInTouchMode(true);
            }
        }
    }

    public BluDroidSwitch(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setUp();
    }

    //
// http://stackoverflow.com/questions/10254748/how-to-extend-an-android-button-and-use-an-xml-layout-file
//
    public BluDroidSwitch(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (context instanceof BaseActivity) {
            try {
                this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
                setUp();
            } catch (Exception exception) {
                Log.d(TAG, "BluDroidSwitch exception " + exception);
            }
        }
    }


    public boolean onTouch(View view, MotionEvent event) {
        try {
            if (baseActivityWeakReference != null) {
                BaseActivity baseScreen = baseActivityWeakReference.get();
                if (baseScreen != null) {
                    BaseActivity.logger.info(": onTouch(): ");
                    baseScreen.resetTimer();
                }
            }
            requestFocus();
        } catch (Exception exception) {
            Log.v(TAG, "onTouch exception " + exception);
        }
        return false;
    }


}

