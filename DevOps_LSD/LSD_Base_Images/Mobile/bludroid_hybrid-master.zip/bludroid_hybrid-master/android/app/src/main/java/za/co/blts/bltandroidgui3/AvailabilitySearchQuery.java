package za.co.blts.bltandroidgui3;

import java.io.Serializable;

/**
 * Created by MasiS on 2018/02/26.
 */

public class AvailabilitySearchQuery implements Serializable {

    private String carrierCode;
    private String carrierName;
    private String departurePoint;
    private String destinationPoint;
    private String departurePointName;
    private String destinationPointName;
    private String departureDate = "";
    private String returnDate = "";
    private String travelClass;
    private int numberOfPassengers = 0;
    private int numberOfPassengersChild = 0;
    private int numberOfPassengersInfants = 0;
    private int numberOfConvertedInfantsToChildPassengers = 0;
    private int numberOfInfantsOnlap = 0;
    private int totalNumberOfSeatsToReserve = 0;
    private double totalAmountDue = 0.0;
    private boolean isReturnTrip = false;

    public AvailabilitySearchQuery() {
    }


    public String getCarrierCode() {
        return carrierCode;
    }

    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    public String getDeparturePoint() {
        return departurePoint;
    }

    public void setDeparturePoint(String departurePoint) {
        this.departurePoint = departurePoint;
    }

    public String getDestinationPoint() {
        return destinationPoint;
    }

    public void setDestinationPoint(String destinationPoint) {
        this.destinationPoint = destinationPoint;
    }

    public String getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(String departureDate) {
        this.departureDate = departureDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public int getNumberOfPassengers() {
        return numberOfPassengers;
    }

    public void setNumberOfPassengers(int numberOfPassengers) {
        this.numberOfPassengers = numberOfPassengers;
    }

    public int getNumberOfPassengersChild() {
        return numberOfPassengersChild;
    }

    public void setNumberOfPassengersChild(int numberOfPassengersChild) {
        this.numberOfPassengersChild = numberOfPassengersChild;
    }

    public int getNumberOfPassengersInfants() {
        return numberOfPassengersInfants;
    }

    public void setNumberOfPassengersInfants(int numberOfPassengersInfants) {
        this.numberOfPassengersInfants = numberOfPassengersInfants;
    }

    public double getTotalAmountDue() {
        return totalAmountDue;
    }

    public void setTotalAmountDue(double totalAmountDue) {
        this.totalAmountDue = totalAmountDue;
    }

    public boolean isReturnTrip() {
        return isReturnTrip;
    }

    public void setReturnTrip(boolean returnTrip) {
        isReturnTrip = returnTrip;
    }

    public int getTotalNumberOfSeatsToReserve() {
        return totalNumberOfSeatsToReserve;
    }

    public void setTotalNumberOfSeatsToReserve(int totalNumberOfSeatsToReserve) {
        this.totalNumberOfSeatsToReserve = totalNumberOfSeatsToReserve;
    }

    public String getTravelClass() {
        return travelClass;
    }

    public void setTravelClass(String travelClass) {
        this.travelClass = travelClass;
    }

    public int getNumberOfConvertedInfantsToChildPassengers() {
        return numberOfConvertedInfantsToChildPassengers;
    }

    public void setNumberOfConvertedInfantsToChildPassengers(int numberOfConvertedInfantsToChildPassengers) {
        this.numberOfConvertedInfantsToChildPassengers = numberOfConvertedInfantsToChildPassengers;
    }

    public String getDeparturePointName() {
        return departurePointName;
    }

    public void setDeparturePointName(String departurePointName) {
        this.departurePointName = departurePointName;
    }

    public String getDestinationPointName() {
        return destinationPointName;
    }

    public void setDestinationPointName(String destinationPointName) {
        this.destinationPointName = destinationPointName;
    }


    public int getNumberOfInfantsOnlap() {
        return numberOfInfantsOnlap;
    }

    public void setNumberOfInfantsOnlap(int numberOfInfantsOnlap) {
        this.numberOfInfantsOnlap = numberOfInfantsOnlap;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    @SuppressWarnings("NullableProblems")
    @Override
    public String toString() {
        return "AvailabilitySearchQuery{" +
                "carrierCode='" + carrierCode + '\'' +
                ", carrierName='" + carrierName + '\'' +
                ", departurePoint='" + departurePoint + '\'' +
                ", destinationPoint='" + destinationPoint + '\'' +
                ", departurePointName='" + departurePointName + '\'' +
                ", destinationPointName='" + destinationPointName + '\'' +
                ", departureDate='" + departureDate + '\'' +
                ", returnDate='" + returnDate + '\'' +
                ", travelClass='" + travelClass + '\'' +
                ", numberOfPassengers=" + numberOfPassengers +
                ", numberOfPassengersChild=" + numberOfPassengersChild +
                ", numberOfPassengersInfants=" + numberOfPassengersInfants +
                ", numberOfConvertedInfantsToChildPassengers=" + numberOfConvertedInfantsToChildPassengers +
                ", totalNumberOfSeatsToReserve=" + totalNumberOfSeatsToReserve +
                ", totalAmountDue=" + totalAmountDue +
                ", isReturnTrip=" + isReturnTrip +
                '}';
    }
}
