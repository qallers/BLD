package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidDeviceIdEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidSwitch;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PAPER_CUTTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PREVIOUS_SKIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINTER_WIDTH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_SALES_RECEIPT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SECURE_USB_PRINTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VOUCHER_SECONDS;

/**
 * Created by warrenm on 2016/11/24.
 * <p>
 * Modified by LB
 */

public class ActivitySetup extends BaseActivity {

    private final String TAG = this.getClass().getSimpleName();

    private BluDroidLinearLayout layout;
    private String selection = "blu";

    private BluDroidRadioButton zeroSecondsRadioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        cancelTimer();

        setContentView(R.layout.activity_setup);
        initFields();

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        layout = findViewById(R.id.layout);

        BluDroidSwitch paperCutterSwitch = findViewById(R.id.paperCutterSwitch);
        zeroSecondsRadioButton = findViewById(R.id.zeroRadio);

        paperCutterSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    zeroSecondsRadioButton.setChecked(true);
                }
            }
        });

        RadioGroup rg = findViewById(R.id.themeOptions);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.bltRadio) {
                    selection = "blu";
                } else if (i == R.id.tspcRadio) {
                    selection = "tspc";
                } else if (i == R.id.gcrsRadio) {
                    selection = "gcrs";
                }
            }
        });

        Button save = findViewById(R.id.save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logger.info("ActivitySetup" + ((BluDroidButton) view).getText());
                if (layout.validate()) {

                    BluDroidDeviceIdEditText deviceIdText;
                    deviceIdText = findViewById(R.id.deviceIdSetting);
                    String deviceId = deviceIdText.getText().toString().trim();

                    updatePreference(PREF_DEVICE_ID, deviceId);
                    switch (selection) {
                        case "blu":
                            updatePreference(PREF_SKIN, getResources().getString(R.string.skinBLT));
                            updatePreference(PREF_PREVIOUS_SKIN, getResources().getString(R.string.skinBLT));
                            break;

                        case "tspc":
                            updatePreference(PREF_SKIN, getResources().getString(R.string.skinTSPC));
                            updatePreference(PREF_PREVIOUS_SKIN, getResources().getString(R.string.skinTSPC));
                            break;

                        case "gcrs":
                            updatePreference(PREF_SKIN, getResources().getString(R.string.skinGCRS));
                            updatePreference(PREF_PREVIOUS_SKIN, getResources().getString(R.string.skinGCRS));
                            break;
                    }

                    compareUpdate(PREF_PAPER_CUTTER, R.id.paperCutterSwitch);
                    compareUpdate(PREF_SECURE_USB_PRINTER, R.id.secureUsbPrinterSwitch);
                    compareUpdate(PREF_PRINT_SALES_RECEIPT, R.id.salesReceiptSwitch);
                    compareUpdate(PREF_PRINTER_WIDTH, R.id.printerWidthOptions);
                    compareUpdate(PREF_VOUCHER_SECONDS, R.id.voucherSecondsRadios);

                    createAlertDialog("Skin", getResources().getString(R.string.skinMessage));

                    alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
//                            changeIcon();
                            resetTimer();
                            dialog.dismiss();
                            finish();
                        }
                    });
                }
            }
        });
    }

    private void initFields() {

        setupSwitch(R.id.paperCutterSwitch, PREF_PAPER_CUTTER);
        setupSwitch(R.id.secureUsbPrinterSwitch, PREF_SECURE_USB_PRINTER);
        setupSwitch(R.id.salesReceiptSwitch, PREF_PRINT_SALES_RECEIPT);

        setupRadioGroup(R.id.printerWidthOptions, PREF_PRINTER_WIDTH);

        setupRadioGroup(R.id.voucherSecondsRadios, PREF_VOUCHER_SECONDS);

        if (isGcrs()) {
            findViewById(R.id.bltRadio).setVisibility(View.GONE);
            findViewById(R.id.tspcRadio).setVisibility(View.GONE);
            ((RadioButton) findViewById(R.id.gcrsRadio)).setChecked(true);
            selection = "gcrs";
        } else if (isRelease()) {
            findViewById(R.id.gcrsRadio).setVisibility(View.GONE);
        }


    }
}
