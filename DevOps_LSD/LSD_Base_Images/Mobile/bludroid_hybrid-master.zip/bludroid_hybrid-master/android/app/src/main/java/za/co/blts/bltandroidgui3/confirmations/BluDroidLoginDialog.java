package za.co.blts.bltandroidgui3.confirmations;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;

import za.co.blts.bltandroidgui3.ActivityLanding;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidPinEditText;

/**
 * Created by NkosanaM on 7/26/2018.
 */

public class BluDroidLoginDialog extends Dialog implements View.OnClickListener {
    private final String TAG = this.getClass().getSimpleName();
    private ActivityLanding activity;
    private BluDroidPinEditText password;

    public BluDroidLoginDialog(ActivityLanding activity) {
        super(activity);
        this.activity = activity;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.login_dialog);

        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        BluDroidLinearLayout layout = findViewById(R.id.layout);
        layout.setContext(activity);
        layout.setup();


        Button cancel = findViewById(R.id.btnCancel);
        password = findViewById(R.id.loginPassword);

        password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                password.post(new Runnable() {
                    @Override
                    public void run() {
                        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
                        inputMethodManager.showSoftInput(password, InputMethodManager.SHOW_IMPLICIT);
                    }
                });
            }
        });
        password.requestFocus();


        cancel.setOnClickListener(this);
        //to validate if enter is entered
        password.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP) {

                    if (keyCode == KeyEvent.KEYCODE_ENTER) {
                        if (password.validate()) {
//                            activity.doAreaCheck(password.getText().toString());
                            activity.login(password.getText().toString());
                        }
                    }
                }
                return false;
            }
        });
// to check is the pin entered is 6 digits
        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String pw = password.getText().toString();

                if (pw.length() == 6) {
                    if (password.validate()) {
//                        activity.doAreaCheck(password.getText().toString());
                        activity.login(password.getText().toString());
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnCancel) {
            dismiss();
        }
    }

    public void displayError(String msg) {
        clearPassword();
        password.setErrorMessage(msg);
    }

    public void clearPassword() {
        password.setText("");
    }
}