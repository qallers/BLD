package za.co.blts.bltandroidgui3;

import android.app.Activity;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.hardware.usb.UsbRequest;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USB_PRINT_TIMEOUT;

class USBPrintTimer extends CountDownTimer {

    private final String TAG = this.getClass().getSimpleName();

    private USBPrintAsync usbPrintAsyncTask;

    USBPrintTimer(USBPrintAsync task, long millisInFuture, long countDownInterval) {
        super(millisInFuture, countDownInterval);
        Log.v(TAG, "new USBPrintTimer task:" + task + " millisInFuture:" + millisInFuture + " countDownInterval:" + countDownInterval);
        usbPrintAsyncTask = task;
        BaseActivity.timers.put(this.hashCode(), this);
    }

    public void onFinish() {
        try {
            Log.v(TAG, "USBPrintTimer finished, this should not happen, print an error");
            Log.v(TAG, "status of task is " + usbPrintAsyncTask.getStatus().toString());
            Log.v(TAG, "trying to cancel");
            boolean b = usbPrintAsyncTask.cancel(true);
            Log.v(TAG, "cancel returns " + b);
            Log.v(TAG, "status of task now is " + usbPrintAsyncTask.getStatus().toString());
            BaseActivity baseActivity = usbPrintAsyncTask.baseActivityWeakReference.get();
            if (baseActivity != null) {
                baseActivity.results("USB Print OK With Condition No Response, 98");
                BaseActivity.logger.debug("printed ok  With Condition No Response - codes: 98");
            }

        } catch (Exception exception) {
            Log.v(TAG, "problems with cancelling usbPrintAsyncTask " + exception);
        }
    }

    public void onTick(long millisUntilFinished) {
        Log.v(TAG, "ticking for AEON task " + usbPrintAsyncTask + " " + millisUntilFinished + " left to go");
    }

}

class USBPrintAsync extends AsyncTask<Object, Void, String> {
    private final String TAG = this.getClass().getSimpleName();

    WeakReference<BaseActivity> baseActivityWeakReference = null;

    private USBPrintTimer usbPrintTimer = null;

    public void setActivity(Activity activity) {
        Log.v(TAG, "USBPrintAsync setActivity");
        String msg = "Printing Tickets";
        ProgressDialog dialog = new ProgressDialog(activity);
        dialog.setIndeterminate(true);
        SpannableString spannableString = new SpannableString(msg);
        spannableString.setSpan(new AbsoluteSizeSpan(msg.length()), 0, msg.length(), 0);
        dialog.setMessage(spannableString);
        baseActivityWeakReference = new WeakReference<>((BaseActivity) activity);
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        Log.v(TAG, "onPreExecute");
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            try {
                int timeout = Integer.parseInt(baseActivity.getPreference(PREF_USB_PRINT_TIMEOUT));
                timeout *= 1000;
                usbPrintTimer = new USBPrintTimer(this, timeout, 1000);
                usbPrintTimer.start();
                Log.v(TAG, "USBPrintTimer started for " + baseActivity.getClass().getSimpleName());
            } catch (Exception exception) {
                Log.e(TAG, "timer exception " + exception);
            }
        }
    }

    @Override
    protected void onPostExecute(String sResult) {
        Log.v(TAG, "onPostExecute sResult:" + sResult);
        BaseActivity baseActivity = baseActivityWeakReference.get();
        String resultsMessage;
        if (sResult != null && sResult.length() >= 2 && (sResult.substring(0, 2).equals("50") || sResult.substring(0, 2).equals("60"))) {
            resultsMessage = "USB Print OK," + sResult;
            if (baseActivity != null) {
                BaseActivity.logger.debug("printed ok - codes: " + sResult);
                Log.d(TAG, "printed ok - codes: " + sResult);
            }
        } else if (sResult != null && sResult.equals("-2")) {
            resultsMessage = "USB Print OK With Condition Printer detached," + sResult;
            if (baseActivity != null) {
                BaseActivity.logger.debug("printed ok  With Condition Printer detached - codes: " + sResult);
                Log.d(TAG, "printed ok - codes: " + sResult);
            }
        } else if (sResult != null && sResult.equals("20")) {
            resultsMessage = "USB Print OK With Condition Printer paused," + sResult;
            if (baseActivity != null) {
                BaseActivity.logger.debug("printed ok  With Condition Printer detached - codes: " + sResult);
                Log.d(TAG, "printed ok - codes: " + sResult);
            }
        } else if (sResult != null && sResult.equals("98")) {
            resultsMessage = "USB Print OK With Condition No Response," + sResult;
            if (baseActivity != null) {
                BaseActivity.logger.debug("printed ok  With Condition No Response - codes: " + sResult);
                Log.d(TAG, "printed ok - codes: " + sResult);
            }
        } else {
            resultsMessage = "USB Print FAILED," + sResult;
            if (baseActivity != null) {
                BaseActivity.logger.debug("printing failed with codes: " + sResult);
                Log.d(TAG, "printing failed with codes: " + sResult);
                // No, if we allow the ticket to be printed again we are only creating the same situation as
                // before where they can "reprint" thousands of tickets the whole time
                BaseActivity.logger.error("The entire ticket did not print");
                USBCommsException exception = new USBCommsException(resultsMessage);
                ((NeedsUSBResults) baseActivity).results(exception);
            }
        }
        if (baseActivity != null) {
            ((NeedsUSBResults) baseActivity).results(resultsMessage);
        }
        if (!isCancelled()) {
            Log.d(TAG, "USB should be fine, cancelling timer");
            usbPrintTimer.cancel();
        }
        //
        // do not remove this log message
        // it iis used for testing purposes
        //
        Log.d(TAG, "TEST : USB TICKET PRINTED");
    }

    /*
        Object[0] = byte[] - printjob byte array
        Object[1] = UsbRequest OUT request
        Object[2] = UsbDeviceConnection connection
        Object[3] = USBPrint instance
    */
    @Override
    protected String doInBackground(Object... params) {
        byte[] bytes = (byte[]) params[0];
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            Log.v(TAG, "Need to print " + bytes.length + " bytes");
            BaseActivity.logger.debug("Need to print " + bytes.length + " bytes");
        }
        UsbRequest outRequest = (UsbRequest) params[1];
        UsbDeviceConnection connection = (UsbDeviceConnection) params[2];
        ByteBuffer buff = ByteBuffer.wrap(bytes);
        BluDroidUSBPrint usbPrinter = (BluDroidUSBPrint) params[3];
        // We send the print job to the printer first
        int totalBytes = 0;
        try {
            do {
                // Queue should use the remaining in buff each time but doesn't - seems like a bug,
                // maybe better after API 26, thus the workaround for now with the copyOfRange
                outRequest.queue(buff, buff.remaining());

                if (connection.requestWait() == outRequest) {
                    totalBytes += buff.position();
                    Log.d(TAG, "USB Print wrote: " + buff.position() + " bytes, total so far: " + totalBytes);
                    if (baseActivity != null) {
                        BaseActivity.logger.debug("true-USB Print wrote: " + buff.position() + " bytes, total so far: " + totalBytes);
                    }
                    byte[] remainingBytes = Arrays.copyOfRange(bytes, totalBytes, bytes.length);
                    buff = ByteBuffer.wrap(remainingBytes);
                } else {
                    Log.d(TAG, "USB Print wrote: " + buff.position() + " bytes, total so far: " + totalBytes);
                    if (baseActivity != null) {
                        BaseActivity.logger.error("false-USB Print wrote: " + buff.position() + " bytes, total so far: " + totalBytes);
                    }
                    return "-1";
                }

            } while (buff.hasRemaining() && !isCancelled());

        } catch (Exception exception) {
            Log.e(TAG, "USBPrintAsync throwing " + exception);
            if (baseActivity != null) {
                BaseActivity.logger.error("USBPrintAsync throwing " + exception);
            }
        }
		/*
			 After the print job has been sent - we need to check the status of the printer
			 We are expecting the following:
			 	The printer should have a status of "00" before we started printing, after we sent the print job
			 	we can expect any error but we would like to see a "50" - busy printing or "60" - data in process.
			 	After the status "50/60" we would like to see a "00" from which we can deduce a successful print.
			 	If we have an error like "01" - out of paper it still does not mean an unsuccessful print but it does
			 	mean a possible issue.
			 We build up a string that represents the status codes received from the printer, we only record a change
			 in status codes, ie, the printer starts with a "00", if we receive a "50/60" and then receive a "00" the
			 string will be: "5000" = "50" + "00"
		*/
        boolean printerStatus50 = false;
        int tryCount = 0;
        StringBuilder printerResultsStringBuilder = new StringBuilder();
        byte[] printerStatusResponse;
        try {
            do {
                printerStatusResponse = usbPrinter.getUSBPrinterStatus(true);
                Log.d(TAG, "true-USB Printer Status50or60 printed: " + printerStatus50);
                Log.d(TAG, "printerStatusResponse: " + (printerStatusResponse == null ? null : new String(printerStatusResponse)));

                if (printerStatusResponse == null) {
                    printerResultsStringBuilder = new StringBuilder();
                    printerResultsStringBuilder.append("-2");
                    break;

                } else if ((printerStatusResponse[0] == 0x35 && printerStatusResponse[1] == 0x30)) {//50
                    if (!printerStatus50) {
                        printerStatus50 = true;
                    } else {
                        printerResultsStringBuilder = new StringBuilder();
                        printerResultsStringBuilder.append("50");
                        break;
                    }

                } else if ((printerStatusResponse[0] == 0x36 && printerStatusResponse[1] == 0x30)) {//60
                    //  ignore status 60 - printer busy

                } else if ((printerStatusResponse[0] == 0x32 && printerStatusResponse[1] == 0x30)) {//20
                    printerResultsStringBuilder = new StringBuilder();
                    printerResultsStringBuilder.append("20");
                    break;

                } else if (printerStatusResponse[0] == 0x30 && printerStatusResponse[1] == 0x30) {//00
                    if (printerStatus50) {
                        printerResultsStringBuilder = new StringBuilder();
                        printerResultsStringBuilder.append("50");
                        break;
                    }

                } else {//any other codes
                    printerResultsStringBuilder = new StringBuilder();
                    buildPrinterResultString(printerResultsStringBuilder, printerStatusResponse);
                    break;
                }

                tryCount += 1;
                Log.d(TAG, "true-USB Printer Status checking - tryCounter: " + tryCount + " resultsCode " + printerResultsStringBuilder.toString());
                BaseActivity.logger.debug("true-USB Printer Status checking - tryCounter: " + tryCount + " resultsCode " + printerResultsStringBuilder.toString());
                try {
                    Thread.sleep(1000);
                } catch (Exception exception) {
                    //ignore interrupted
                }
            }
            while (tryCount < 10);    // The tryCount counter is so that we do not go into an endless loop

            if (printerResultsStringBuilder.length() < 2) {
                // We now have not received the required sequence of codes for a print and have an invalid code
                printerResultsStringBuilder.append("98");
            }

            BaseActivity.logger.debug("true-USB Printer Status Final printed: " + printerStatus50 + " resultsCode: " + printerResultsStringBuilder.toString());
            Log.d(TAG, "true-USB Printer Status Final printed: " + printerStatus50 + " resultsCode " + printerResultsStringBuilder.toString());

        } catch (Exception exception) {
            exception.printStackTrace();
            if (baseActivity != null) {
                BaseActivity.logger.error("EXCEPTION: USBPrintAsync - " + exception);
            }
            Log.e(TAG, "EXCEPTION: USBPrintAsync - " + exception);
            Log.d(TAG, "almost end of catch");
            printerResultsStringBuilder.append("99");
            Log.d(TAG, "end of catch");
        }
        if (baseActivity != null) {
            if (totalBytes == bytes.length) {
                BaseActivity.logger.debug("all printed");
            } else {
                BaseActivity.logger.error("not all tickets printed.  Needed to print " + bytes.length + " but only printed " + totalBytes);
            }
        }
        return printerResultsStringBuilder.toString();
    }

    private void buildPrinterResultString(StringBuilder strBuilder, byte[] printerResult) {
        strBuilder.append(Character.toChars(printerResult[0]));
        strBuilder.append(Character.toChars(printerResult[1]));
    }
}

public class BluDroidUSBPrint extends BluDroidUSBPrinter implements NeedsUSBResults {
    private final String TAG = this.getClass().getSimpleName();

    private PendingIntent permissionIntent = null;

    private static final String ACTION_USB_PERMISSION = "za.co.blt.bludroid.USB_PERMISSION";

    // pool of requests for the OUT endpoint
    private final LinkedList<UsbRequest> mOutRequestPool = new LinkedList<>();
    // pool of requests for the IN endpoint
    private final LinkedList<UsbRequest> mInRequestPool = new LinkedList<>();
    // map of error string codes for the printer - specific to Inani GoDex printer!!
    private final HashMap<String, String> hmPrinterErrorStrings = new HashMap<String, String>() {{
        put("00", "Ready                    ");
        put("01", "Paper out                ");
        put("02", "Paper jam or missing gap ");
        put("03", "Ribbon out               ");
        put("04", "Print head is up         ");
        put("05", "Rewinder full            ");
        put("06", "Memory is full           ");
        put("07", "Filename can not be found");
        put("08", "Filename duplicate       ");
        put("09", "Syntax error             ");
        put("10", "Cutter JAM               ");
        put("11", "CF Card not found        ");
        put("20", "Pause                    ");
        put("21", "In Setting Mode          ");
        put("22", "In Keyboard Mode         ");
        put("50", "Printer is printing      ");
        put("60", "Data in process          ");
//    put("99", "USB Printer status error ");    // This is a custom error @see getUSBPrinterStatus()
        put("99", "USB Printer error        ");    // This is a custom error @see getUSBPrinterStatus()
    }};

    private WeakReference<BaseActivity> baseActivityWeakReference;

    private byte[] bytes = null;

    private static UsbDevice securePrinter = null;
    private static UsbEndpoint outputEndpoint = null;
    private static UsbEndpoint inputEndpoint = null;
    private static UsbDeviceConnection connection = null;

    private UsbManager usbManager = null;

    private BroadcastReceiver usbReceiver = null;

    public BluDroidUSBPrint(BaseActivity activity, byte[] bytes) {
        super();
        try {
            this.bytes = bytes;
            usbManager = (UsbManager) activity.getSystemService(Context.USB_SERVICE);
            this.baseActivityWeakReference = new WeakReference<>(activity);
            Log.d(TAG, "creating broadcast receiver");

            usbReceiver = new BroadcastReceiver() {
                public void onReceive(Context context, Intent intent) {
                    String action = intent.getAction();
                    if (ACTION_USB_PERMISSION.equals(action)) {
                        synchronized (this) {
                            UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

                            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                                if (device != null) {
                                    findUSB();
                                    Log.d(TAG, "got permission");
                                } else {
                                    Log.d(TAG, "device is null");
                                }
                            } else {
                                Log.d(TAG, "permission not granted");
                            }
                        }
                    }
                }
            };

            permissionIntent = PendingIntent.getBroadcast(activity, 0, new Intent(ACTION_USB_PERMISSION), 0);
            IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
            activity.registerReceiver(usbReceiver, filter);

            Log.d(TAG, "baseActivity registerd");

            Log.d(TAG, "Checking USB connectivity");
            if (BaseActivity.logger != null) {
                BaseActivity.logger.debug("Checking USB connectivity");
            }
            checkUSBConnectivity();
            Log.d(TAG, "USBPrint constructor finishing normally");
            if (BaseActivity.logger != null) {
                Log.d(TAG, "USBPrint constructor finishing normally");
            }
        } catch (Exception exception) {
            Log.e(TAG, "USBPrint throwing " + exception);
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            exception.printStackTrace(pw);
            Log.d(TAG, sw.toString());
            if (BaseActivity.logger != null) {
                BaseActivity.logger.error("USBPrint throwing " + exception);
            }
        }
    }

    public void unregisterReceiver() {
        Log.d(TAG, "unregisterReceiver");
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            baseActivity.unregisterReceiver(usbReceiver);
        }
    }

    public boolean hasPermission() {
        try {
            if (securePrinter == null) {
                Log.d(TAG, "no secure printer");
                return false;
            } else {
                Log.d(TAG, "has usb permission? " + usbManager.hasPermission(securePrinter));
                return usbManager.hasPermission(securePrinter);
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems with USB permissions " + exception);
            BaseActivity.logger.error("problems with USB permissions " + exception);
            return false;
        }
    }

    private void getEndPoints() {
        try {
            Log.d(TAG, "device has " + securePrinter.getInterfaceCount() + " interface/s\n");
            for (int i = 0; i < securePrinter.getInterfaceCount(); i++) {
                UsbInterface usbInterface = securePrinter.getInterface(i);
                for (int j = 0; j < usbInterface.getEndpointCount(); j++) {
                    UsbEndpoint endpoint = usbInterface.getEndpoint(j);
                    if (endpoint.getDirection() == UsbConstants.USB_DIR_OUT) {
                        Log.d(TAG, "OUTPUT");
                        outputEndpoint = endpoint;
                        Log.d(TAG, "outputEndPoint set to " + outputEndpoint);
                    }
                    if (endpoint.getDirection() == UsbConstants.USB_DIR_IN) {
                        Log.d(TAG, "INPUT");
                        inputEndpoint = endpoint;
                        Log.d(TAG, "inputEndpoint set to " + inputEndpoint);
                    }

                    Log.d(TAG, "type " + endpoint.getType() + "\n");
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "problems getting outputEndpoint " + exception);
            BaseActivity.logger.error("problems getting outputEndpoint " + exception);
        }
    }

    private UsbRequest getInRequest() {
        if (connection == null) {
            Log.d(TAG, "No USB connection when trying to get In UsbRequest");
            BaseActivity.logger.warn("No USB connection when trying to get In UsbRequest");
            return null;
        }
        if (mInRequestPool.isEmpty()) {
            UsbRequest request = new UsbRequest();
            request.initialize(connection, inputEndpoint);
            return request;
        } else {
            return mInRequestPool.removeFirst();
        }
    }

    private UsbRequest getOutRequest() {
        if (connection == null) {
            Log.d(TAG, "No USB connection when trying to get Out UsbRequest");
            BaseActivity.logger.warn("No USB connection when trying to get Out UsbRequest");
            return null;
        }
        if (mOutRequestPool.isEmpty()) {
            UsbRequest request = new UsbRequest();
            if (request.initialize(connection, outputEndpoint)) {
                Log.d(TAG, "Out request successful: " + request);
            } else {
                Log.d(TAG, "Out request failed ");
                BaseActivity.logger.warn("Out request failed ");
            }
            return request;
        } else {
            return mOutRequestPool.removeFirst();
        }
    }

    private void createConnection() {
        try {
            connection = usbManager.openDevice(securePrinter);

            Log.d(TAG, "connection is " + connection + "\n");
            boolean result = connection.claimInterface(securePrinter.getInterface(0), true);
            Log.d(TAG, "claimed interface result is " + result + "\n");
        } catch (Exception exception) {
            Log.e(TAG, "problem creating connection " + exception);
            BaseActivity.logger.error("problem creating connection " + exception);
        }
    }

    private void getSecurePrinter() {
        try {
            HashMap<String, UsbDevice> usbDevices = usbManager.getDeviceList();
            for (UsbDevice device : usbDevices.values()) {
                Log.d(TAG, "\n\nDEV " + device.toString() + "\n");
                Log.d(TAG, "DEVICE ID= " + device.getDeviceId() + "\n");
                Log.d(TAG, "DEVICE NAME= " + device.getDeviceName() + "\n");
                Log.d(TAG, "PRODUCT ID= " + device.getProductId() + "\n");
                Log.d(TAG, "VENDOR ID= " + device.getVendorId() + "\n");
                //
                // this should be Godex
                //
                if ((device.getVendorId() == 6495) && (device.getProductId() == 1)) {
                    securePrinter = device;
                    Log.d(TAG, "setting secure printer");
                    break;
                }
                //
                // this is an epson for testing only
                //
                if ((device.getVendorId() == 1208) && (device.getProductId() == 514)) {
                    securePrinter = device;
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "problem getting Secure Printer " + exception);
            BaseActivity.logger.error("problem getting Secure Printer " + exception);
        }
    }

    /*
        Sends a status request to the printer and checks for a valid response indicating the printer
        is ready
        This applies to the Inani DT2 EZPL Printer at the moment - probably needs to make this more
        generic so that it can do other printers as well, just saying
        ~S,STATUS - return format: "aa,nnnnn<CR><LF>" = 10 bytes
     */
    public boolean checkUSBReadyStatus() {
        try {
            byte[] printerStatus = getUSBPrinterStatus(false);
            Log.d(TAG, "checkUSBReadyStatus: " + (printerStatus == null ? null : new String(printerStatus)));
            // We just check for a "00" response in the first 2 characters,
            // 48 or 0x30 = "0", ie 00,00000 = OK
            return printerStatus != null && ((printerStatus[0] == 48) && (printerStatus[1] == 48));
        } catch (Exception exception) {
            Log.e(TAG, "Unable to checkUSBReadyStatus: " + exception);
            exception.printStackTrace();
        }
        return false;
    }

    /*
        We will get the printer to move the paper forward and then back to check for any out of paper errors
        We also make sure the printer settings is correct for the label we are printing on - we have seen that the
        printer auto sensing capabilities is not very accurate... So we set it explicitly for now -
        In the future with different label lengths this will need to be adjusted accordingly
     */
    public boolean checkUSBPrinterPaperAvailable() {
        try {
            String readyMsg;

            readyMsg = "^S2\n" +              //Speed setting, S3 = 76.2mm/s
                    "^H12\n" +             //Print darkness, 00-19
                    "^R0\n" +              //Row column adjustment, 0-399
                    "^W54\n" +             //Label width, 54mm
                    "^Q203,5,0\n" +        //Label length, 203mm, 5mm black line, tear is after black line
                    "^O0\n" +              //Disable label dispenser and applicator
                    "^AD\n" +              //Printing mode = direct thermal
                    "^D0\n" +              //Disable cutting
                    "^E13\n" +             //Stop position setting, feed paper to specific stop position, 13mm
                    "^XSET,SENSING,0\n" +  //Use reflect sensor to detect paper out on a continuous label
                    "~S,FEED\n" +          //Feed the paper
                    "^B203\n"            //Backward length = 203mm
            ;
            Log.d(TAG, "Checking for out of paper on printer - top of form command");
            callUSBPrinterCommand(readyMsg, 0);

            // We need to wait for the top of form printer command to finish before we try for a status, this is not
            // really the best way of waiting for this to happen...
            Thread.sleep(6000); //increased from 4500 due to slowing the paper check speed

            byte[] status = getUSBPrinterStatus(true);
            Log.d(TAG, "checkUSBPrinterPaperAvailable: " + (status == null ? "null" : new String(status)));

            if (status != null && status.length > 1) {
                return status[0] == 0x30 && status[1] == 0x30;
            }
            return false;
        } catch (Exception exception) {
            BaseActivity.logger.error("checkUSBPrinterPaperAvailable exception: " + exception);
            Log.e(TAG, "checkUSBPrinterPaperAvailable exception: " + exception);
            return false;
        }
    }

    /*
        Returns the Error string for the printer based on the code received:
        USB Printer result codes which needs to be standardised if we want to use them in this function correctly
     */
    public String getUSBPrinterErrorString() {
        byte[] printerResponse = getUSBPrinterStatus(true);
        String printerErrorString = new String(printerResponse);
        // Check if the error is in our hashmap
        if (hmPrinterErrorStrings.containsKey(printerErrorString.substring(0, 2))) {
            return hmPrinterErrorStrings.get(printerErrorString.substring(0, 2));
        } else {
            return "Unknown Error";
        }
    }

    /*
        Gets the USB status information, we can probably make an abstract class for usb printers,
        of which you subclass the different printers and their specific commands, but someone needs
        to stick their hands in the air...  (waiting...)
        This applies to the Inani DT2 EZPL Printer at the moment - probably needs to make this more
        generic so that it can do other printers as well, just saying
        ~S,STATUS - return format: "aa,nnnnn<CR><LF>" = 10 bytes
     */
    byte[] getUSBPrinterStatus(Boolean quietMode) {
        Log.d(TAG, "trying to getUSBPrinterStatus");
        try {
            String readyMsg;
            if (quietMode) {
                readyMsg = "~S,STATUS\n";
            } else {
                readyMsg = "^XSET,IMMEDIATE,1\n~S,STATUS\n";
            }
            return callUSBPrinterCommand(readyMsg, 10);
        } catch (Exception exception) {
            BaseActivity.logger.error("can't get printer status " + exception);
            Log.e(TAG, "can't get printer status " + exception);
        }
        return new byte[]{57, 57};    // 57 = "9"
    }

    /*
        Call the USB Printer with the specified `command`, returns a byte[] with the response
        for the command.  You need to specify the size of the response that will be received for
        the command that will be executed
     */
    private byte[] callUSBPrinterCommand(String command, Integer cmdResponseSize) {
        UsbRequest outRequest = null;
        UsbRequest inRequest = null;
        try {
            ByteBuffer requestMsg = ByteBuffer.wrap(command.getBytes());
            ByteBuffer responseMsg = ByteBuffer.allocate(cmdResponseSize);
            byte[] response = null;
            if (checkUSBConnectivity()) {
                outRequest = getOutRequest();
                inRequest = getInRequest();
                if (outRequest.queue(requestMsg, requestMsg.remaining())) {
                    if (connection.requestWait() == outRequest) {
                        Log.d(TAG, "USB STATUS CHECK - wrote: " + requestMsg.position());
                        if (cmdResponseSize > 0) {            // Check if this command needs a response message
                            if (inRequest.queue(responseMsg, responseMsg.limit())) {
                                if (connection.requestWait() == inRequest) {
                                    Log.d(TAG, "USB STATUS CHECK - received: " + responseMsg.position() + " = " + new String(responseMsg.array()));
                                    if (responseMsg.position() > 0) {
                                        response = responseMsg.array();
                                    }
                                }
                            } else {
                                Log.d(TAG, "USB STATUS CHECK (IN) request queue failed !!");
                                connection.close();
                                connection = null;        // Reset the connection status just in case
                                securePrinter = null;
                            }
                        }
                    }
                } else {
                    Log.d(TAG, "USB STATUS CHECK (OUT) request queue failed !!");
                    connection.close();
                    connection = null;        // Reset the connection status just in case
                    securePrinter = null;
                }
            }
            return response;
        } catch (Exception exception) {
            Log.e(TAG, "callUSBPrinterCommand exception: " + exception);
            if (BaseActivity.logger != null) {
                BaseActivity.logger.error("callUSBPrinterCommand exception:" + exception);
            }
            return null;
        } finally {
            if (outRequest != null) {
                outRequest.close();
            }
            if (inRequest != null) {
                inRequest.close();
            }
        }
    }

    private boolean checkUSBConnectivity() {
        try {
            if (securePrinter == null) {
                getSecurePrinter();
            }
            if (securePrinter != null && usbManager.hasPermission(securePrinter)) {
                if (outputEndpoint == null) {
                    getEndPoints();
                }
                if (outputEndpoint != null) {
                    if (connection == null) {
                        createConnection();
                    }
                } else {
                    Log.d(TAG, "no output endpoint :-(\n");
                    return false;
                }
            } else {
                if (securePrinter == null) {
                    Log.d(TAG, "securePrinter is null after connection attempt");
                    return false;
                } else {
                    Log.d(TAG, "requesting permission");
                    usbManager.requestPermission(securePrinter, permissionIntent);
                    Log.d(TAG, "requested permission");
                    return false;
                }
            }
        } catch (Exception exception) {
            Log.e(TAG, "checkUSBConnectivity EXCEPTION " + exception + "\n");
            if (BaseActivity.logger != null)
                BaseActivity.logger.error("checkUSBConnectivity EXCEPTION " + exception + "\n");
            return false;
        }
        return true;
    }

    private void findUSB() {

        HashMap<String, UsbDevice> usbDevices = usbManager.getDeviceList();
        if (usbDevices == null) {
            Log.d(TAG, "usbDevices is null\n");
        } else {
            Log.d(TAG, "usbDevices is not null\n");
            Log.d(TAG, "there are " + usbDevices.size() + " usbDevices\n");
            Log.d(TAG, "securePrinter is " + securePrinter);
            if (securePrinter == null) {
                getSecurePrinter();
            }
            if (securePrinter != null) {
                Log.d(TAG, "has permission " + usbManager.hasPermission(securePrinter) + "\n");
                if (usbManager.hasPermission(securePrinter)) {
                    try {
                        if (outputEndpoint == null) {
                            getEndPoints();
                        }
                        if (outputEndpoint != null) {
                            if (connection == null) {
                                createConnection();
                            }
                            if (connection != null && bytes != null) {
                                USBPrintAsync printUSBTaskAsync = new USBPrintAsync();
                                printUSBTaskAsync.setActivity(baseActivityWeakReference.get());
                                printUSBTaskAsync.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, bytes,
                                        getOutRequest(), connection, this);
                                Log.d(TAG, "starting printUSBAsyncTask with AsyncTask.THREAD_POOL_EXECUTOR");
                            }
                        } else
                            Log.d(TAG, "no output endpoint :-(\n");
                    } catch (Exception exception) {
                        Log.d(TAG, "EXCEPTION " + exception + "\n");
                        if (BaseActivity.logger != null)
                            BaseActivity.logger.error("findUSB EXCEPTION " + exception + "\n");
                    }
                } else {
                    Log.d(TAG, "requesting permission");
                    usbManager.requestPermission(securePrinter, permissionIntent);
                    Log.d(TAG, "requested permission");
                }
            } else {
                Log.d(TAG, "No SecurePrinter Object in findUSB?");
            }
        }

    }

    private byte[] lineTerminationCheck(byte[] in) {
        Log.d(TAG, ">>>>>>>>>>>>>>>>>lineTerminationCheck<<<<<<<<<<<<<<<<<<");

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (int i = 0; i < in.length; i++) {
            if (in[i] == 0x0a && in[i - 1] != 0x0d) {
                out.write(0x0d);
            }
            out.write(in[i]);
            if (i == in.length - 1 && in[i] != 0x0a) {
                out.write(0x0d);
                out.write(0x0a);
            }
        }

        byte[] outB = out.toByteArray();
        Log.d(TAG, ">>>>>>>>>>>>>>>>>in:" + in.length + " out:" + outB.length + "<<<<<<<<<<<<<<<<<<");
        return outB;
    }

    public void print(byte[] bytes) {
        byte[] print = lineTerminationCheck(bytes);
        Log.d(TAG, "received " + print.length + " length");
        if (BaseActivity.logger != null) {
            BaseActivity.logger.debug("USBPrint received " + print.length + " length");
        }
        this.bytes = print;
        findUSB();
    }

    public void results(Object object) {
        Log.d(TAG, "results: " + object);
        if (BaseActivity.logger != null) {
            BaseActivity.logger.debug("USBPrint results receive " + object);
        }
    }

    public void error(Object object) {
        Log.e(TAG, "error: " + object);
        if (BaseActivity.logger != null) {
            BaseActivity.logger.error("USBPrint error receive " + object);
        }
    }

}
