package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Filter;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Map;

import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 4/5/2017.
 */

class FavouritesListAdapter extends ArrayAdapter<Map<String, String>> implements CompoundButton.OnCheckedChangeListener {

    private final String TAG = this.getClass().getSimpleName();
    private ArrayList<Map<String, String>> dataSet;
    private WeakReference<BaseActivity> baseActivityWeakReference;
    private int layoutResourceId;

    private Filter filter;

    public FavouritesListAdapter(BaseActivity context, int layoutResourceId, ArrayList<Map<String, String>> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.layoutResourceId = layoutResourceId;
        this.dataSet = dataSet;
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Map<String, String> product = getItem(position);

        if (convertView == null) {

            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(layoutResourceId, parent, false);
        }

        CheckBox checkBox = convertView.findViewById(R.id.cbOption);

        if (product.get("textDesc").isEmpty()) {
            checkBox.setText(product.get("textValue"));
        } else {
            checkBox.setText(product.get("textDesc"));
        }

        checkBox.setOnCheckedChangeListener(this);
        checkBox.setTag(position);
        //checkBox.setId(Integer.parseInt(permission.getId()));

        BluDroidTextView textDesc = convertView.findViewById(R.id.textDesc);
        textDesc.setText(product.get("textDesc"));

        BluDroidTextView textValue = convertView.findViewById(R.id.textValue);
        textValue.setText(product.get("textValue"));

        BluDroidTextView stockId = convertView.findViewById(R.id.stockId);
        stockId.setText(product.get("stockId"));

        BluDroidTextView voucherType = convertView.findViewById(R.id.voucherType);
        voucherType.setText(product.get("voucherType"));

        BluDroidTextView tag = convertView.findViewById(R.id.tag);
        tag.setText(product.get("tag"));

        // Return the completed view to render on screen
        return convertView;
    }


    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            int position = (Integer) buttonView.getTag();
            Map<String, String> options = getItem(position);

            if (isChecked) {
                Log.v(TAG, "options: " + options);
                baseActivity.configFavouritesList.add(options);
            } else {
                baseActivity.configFavouritesList.remove(options);
            }
        }
    }

    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new FavouritesListAdapter.AppFilter<>(dataSet);
        }
        return filter;
    }

    private class AppFilter<T> extends Filter {

        private ArrayList<T> sourceObjects;

        AppFilter(ArrayList<T> objects) {
            sourceObjects = new ArrayList<>();
            synchronized (this) {
                sourceObjects.addAll(objects);
            }
        }

        @Override
        protected FilterResults performFiltering(CharSequence chars) {
            String filterSeq = chars.toString().toLowerCase();
            FilterResults result = new FilterResults();
            if (filterSeq.length() > 0) {
                ArrayList<T> filter = new ArrayList<>();

                for (T object : sourceObjects) {
                    // the filtering itself:
                    @SuppressWarnings("unchecked")
                    Map<String, String> fav = (Map<String, String>) object;
                    if (fav.get("textDesc").toLowerCase().contains(filterSeq)) {
                        filter.add(object);
                    }
                }
                result.count = filter.size();
                result.values = filter;
            } else {
                // add all objects
                synchronized (this) {
                    result.values = sourceObjects;
                    result.count = sourceObjects.size();
                }
            }
            return result;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            // NOTE: this function is *always* called from the UI thread.
            ArrayList<T> filtered = (ArrayList<T>) results.values;
            notifyDataSetChanged();
            clear();
            for (int i = 0, l = filtered.size(); i < l; i++) {
                add((Map<String, String>) filtered.get(i));
            }
            notifyDataSetInvalidated();
        }
    }
}
