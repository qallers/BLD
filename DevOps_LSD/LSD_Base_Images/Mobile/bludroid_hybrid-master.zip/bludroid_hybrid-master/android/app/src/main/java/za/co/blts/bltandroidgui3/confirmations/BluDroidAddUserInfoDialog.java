package za.co.blts.bltandroidgui3.confirmations;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioGroup;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.users.request.UsersRequestPermissionMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BluDroidPermissionsListAdapter;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

/**
 * Created by NkosanaM on 3/23/2017.
 */

public class BluDroidAddUserInfoDialog extends BluDroidConfirmationDialog implements BluDroidSetupable {

    private BluDroidRadioButton radio;
    private RadioGroup radioGroup;

    private Animation animShow, animHide;

    private ListView listView;

    public void setup() {
        super.setup();

        baseActivity.permissions = new ArrayList<>();

        initAnimation();

        hidePermissions();

        setAffirmativeButtonLabel(R.string.add);
        hideView(R.id.neutralButton);
        setNegativeButtonLabel(R.string.cancel);
        setHeading("Add User");

        radioGroup = findViewById(R.id.userlevelRadios);
        listView = findViewById(R.id.listView);

        populatePermissionTypesList();


        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                BluDroidRadioButton radioButton = findViewById(checkedId);
                if (radioButton.isChecked() && radioButton.getText().toString().equalsIgnoreCase("cashier plus")) {
                    showPermissions();
                } else {
                    hidePermissions();
                }
            }
        });
    }

    @Override
    protected void onStop() {
        if (listView != null) listView.setAdapter(null);
        super.onStop();
    }

    public BluDroidAddUserInfoDialog(BaseActivity context) {
        super(context, R.layout.dialog_user_info);
        setup();
        String TAG = this.getClass().getSimpleName();
        Log.d(TAG, "user details");
        BaseActivity.logger.info(": dismiss()");
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    protected void setName(String name) {
        BluDroidEditText NameEditText = findViewById(R.id.nameSetting);
        if (NameEditText != null) {
            NameEditText.setText(name);
        }
    }

    public String getName() {
        BluDroidEditText NameEditText = findViewById(R.id.nameSetting);
        if (NameEditText != null) {
            return NameEditText.getText().toString();
        } else {
            return "";
        }
    }

    public void setNameError(String message) {
        BluDroidEditText NameEditText = findViewById(R.id.nameSetting);
        if (NameEditText != null) {
            NameEditText.setErrorMessage(message);
        }
    }

    protected void setPin(String pin) {
        BluDroidEditText pinEditText = findViewById(R.id.pinSetting);
        if (pinEditText != null) {
            pinEditText.setText(pin);
        }
    }

    public String getPin() {
        BluDroidEditText pinEditText = findViewById(R.id.pinSetting);
        if (pinEditText != null) {
            return pinEditText.getText().toString();
        } else {
            return "";
        }
    }

    public void setPinError(String message) {
        BluDroidEditText pinEditText = findViewById(R.id.pinSetting);
        if (pinEditText != null) {
            pinEditText.setErrorMessage(message);
        }
    }

    public String getConfirmPin() {
        BluDroidEditText pinEditText = findViewById(R.id.confirmPinSetting);
        if (pinEditText != null) {
            return pinEditText.getText().toString();
        } else {
            return "";
        }
    }

    public void setConfirmPinError(String message) {
        BluDroidEditText pinEditText = findViewById(R.id.confirmPinSetting);
        if (pinEditText != null) {
            pinEditText.setErrorMessage(message);
        }
    }

    protected void setLevel(String level) {

        switch (level) {
            case "0":
                radio = findViewById(R.id.cashierRadio);
                radio.setChecked(true);
                break;
            case "1":
                radio = findViewById(R.id.supervisorRadio);
                radio.setChecked(true);
                break;
            case "2":
                radio = findViewById(R.id.cashierPlusRadio);
                radio.setChecked(true);
                break;
        }
    }


    public String getLevel() {

        String level = "";
        if (radioGroup != null) {
            int radioButtonID = radioGroup.getCheckedRadioButtonId();

            if (radioButtonID != -1) {
                radio = findViewById(radioButtonID);
                if (radio.getText().toString().equalsIgnoreCase("cashier")) {
                    level = "0";
                } else if (radio.getText().toString().equalsIgnoreCase("supervisor")) {
                    level = "1";
                } else if (radio.getText().toString().equalsIgnoreCase("cashier plus")) {
                    level = "2";
                }
            }
        }

        return level;
    }

    protected void setUserID(String id) {
        BluDroidTextView idTextView = findViewById(R.id.userId);
        if (idTextView != null) {
            idTextView.setText(id);
        }
    }

    public String getUserID() {
        BluDroidTextView idTextView = findViewById(R.id.userId);
        if (idTextView != null) {
            return idTextView.getText().toString();
        } else {
            return "";
        }
    }

    private void populatePermissionTypesList() {
        ArrayList<UsersRequestPermissionMessage> permissionTypesDataSet = new ArrayList<>();

        if (baseActivity.usersResponseListPermissionTypesMessage != null) {
            for (int i = 0; i < baseActivity.usersResponseListPermissionTypesMessage.getData().getPermissions().size(); i++) {

                UsersRequestPermissionMessage permission = new UsersRequestPermissionMessage();
                permission.setId(baseActivity.usersResponseListPermissionTypesMessage.getData().getPermissions().get(i).getId());
                permission.setText(baseActivity.usersResponseListPermissionTypesMessage.getData().getPermissions().get(i).getName());

                permissionTypesDataSet.add(permission);
            }

            BluDroidPermissionsListAdapter permissionsListAdapter = new BluDroidPermissionsListAdapter(baseActivity, R.layout.permissions_row_item, permissionTypesDataSet);
            listView.setAdapter(permissionsListAdapter);
        }
    }

    private void initAnimation() {
        animShow = AnimationUtils.loadAnimation(baseActivity, R.anim.view_show);
        animHide = AnimationUtils.loadAnimation(baseActivity, R.anim.view_hide);
    }

    private void showPermissions() {
        View view = this.findViewById(R.id.userPermissionsLayout);
        view.startAnimation(animShow);
        view.setVisibility(VISIBLE);
    }

    private void hidePermissions() {
        View view = this.findViewById(R.id.userPermissionsLayout);
        view.startAnimation(animHide);
        view.setVisibility(GONE);
    }

}
