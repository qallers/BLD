package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TableRow;

import androidx.annotation.Nullable;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidNumericEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by WarrenM1 on 2017/07/11.
 */

public class FragmentIthubaQPick extends BaseFragment implements View.OnFocusChangeListener {

    private final String TAG = this.getClass().getSimpleName();

    private String name;
    private BluDroidNumericEditText numBoards = null;
    private BluDroidNumericEditText numDraws = null;

    //Checkbox
    private CheckBox playPlusBox = null;

    //Checkbox2
    private CheckBox playPlus2Box = null;


    public FragmentIthubaQPick() {
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentVouchersMenu(), "FragmentVouchersMenu").commit();

                }
                return true;
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_ithuba_quickpick, container, false);
        Bundle bundle = getArguments();
        name = bundle.getString("name");
        getBaseActivity().resetTimer();

        ImageView pageLogo = rootView.findViewById(R.id.ithuba_lotto_img);

        BluDroidTextView qpNumBoardsTxt = rootView.findViewById(R.id.qpNumBoards);
        qpNumBoardsTxt.setTextSize(getBaseActivity().getSkinResources().getTextSize());
        BluDroidTextView qpNumDrawsTxt = rootView.findViewById(R.id.qpNumDraws);
        qpNumDrawsTxt.setTextSize(getBaseActivity().getSkinResources().getTextSize());

        playPlusBox = rootView.findViewById(R.id.qpPlayPlusBox);
        playPlus2Box = rootView.findViewById(R.id.qpPlayPlus2Box);

        if (name.contains("lotto")) {
            pageLogo.setImageDrawable(getResources().getDrawable(R.drawable.ic_lotto_quickpick));
            playPlusBox.setText(getResources().getString(R.string.playLottoPlus));
            playPlus2Box.setText(getResources().getString(R.string.playLottoPlus2));
            playPlus2Box.setTextColor(getResources().getColor(R.color.check_box_text_disabled));
        } else if (name.contains("powerball")) {
            pageLogo.setImageDrawable(getResources().getDrawable(R.drawable.ic_powerball_quickpick));
            playPlusBox.setText(getResources().getString(R.string.playPowerballPlus));
            playPlus2Box.setVisibility(View.GONE);
        }

        TableRow.LayoutParams editTextParams = new TableRow.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        editTextParams.setMargins(0, 0, 2, 0);

        numBoards = rootView.findViewById(R.id.qpNumBoardsBox);
        numBoards.setText("1");
        numBoards.setTextSize(getBaseActivity().getSkinResources().getTextSize());
        numBoards.setRawInputType(InputType.TYPE_CLASS_NUMBER);
        numBoards.setFilters(new InputFilter[]{new InputFilterMinMax("1", "20")});
        numBoards.setLayoutParams(editTextParams);
        numBoards.setOnFocusChangeListener(this);

        numDraws = rootView.findViewById(R.id.qpNumDrawsBox);
        numDraws.setText("1");
        numDraws.setTextSize(getBaseActivity().getSkinResources().getTextSize());
        numDraws.setRawInputType(InputType.TYPE_CLASS_NUMBER);
        numDraws.setFilters(new InputFilter[]{new InputFilterMinMax("1", "10")});
        numDraws.setLayoutParams(editTextParams);
        numDraws.setOnFocusChangeListener(this);

        playPlusBox = rootView.findViewById(R.id.qpPlayPlusBox);
        playPlusBox.setTextSize(getBaseActivity().getSkinResources().getTextSize());
        playPlusBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getBaseActivity().resetTimer();
                if (isChecked) {
                    // The toggle is enabled
                    playPlus2Box.setEnabled(true);
                    playPlus2Box.setTextColor(getSkinResources().getBackgroundTextColor());
                } else {
                    // The toggle is disabled
                    playPlus2Box.setChecked(false);
                    playPlus2Box.setEnabled(false);
                    playPlus2Box.setTextColor(getResources().getColor(R.color.check_box_text_disabled));
                }
            }
        });


        playPlus2Box.setEnabled(false);
        playPlus2Box.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getBaseActivity().resetTimer();
            }
        });

        BluDroidButton playBtn = rootView.findViewById(R.id.qpPlay);
        playBtn.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        playBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BaseActivity.logger.info(((BluDroidButton) view).getText());
                if (String.valueOf(numBoards.getText()).isEmpty()) {
                    numBoards = rootView.findViewById(R.id.qpNumBoardsBox);
                    numBoards.setText("1");
                }

                if (String.valueOf(numDraws.getText()).isEmpty()) {
                    numDraws = rootView.findViewById(R.id.qpNumDrawsBox);
                    numDraws.setText("1");
                }
                //getBaseActivity().resetTimer();
                getBaseActivity().ithubaAuth(name, numBoards.getText().toString(), numDraws.getText().toString(),
                        String.valueOf(playPlusBox.isChecked()), String.valueOf(playPlus2Box.isChecked()));
            }
        });

        BluDroidButton cancelBtn = rootView.findViewById(R.id.qpCancel);
        playBtn.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BaseActivity.logger.info(((BluDroidButton) view).getText());
                getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentIthubaMenu(), "FragmentIthubaMenu").commit();
            }
        });

        return rootView;
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus) {
            switch (v.getId()) {
                case R.id.qpNumBoardsBox:
                    numBoards.setText("");
                    break;
                case R.id.qpNumDrawsBox:
                    numDraws.setText("");
                    break;
            }
        } else {
            switch (v.getId()) {
                case R.id.qpNumBoardsBox:
                    if (numBoards.getText().toString().isEmpty()) {
                        numBoards.setText("1");
                    }
                    break;
                case R.id.qpNumDrawsBox:
                    if (numDraws.getText().toString().isEmpty()) {
                        numDraws.setText("1");
                    }
                    break;
            }
        }
    }

    @Override
    public boolean onBackPressed() {
//        FragmentManager fm = getBaseActivity().getSupportFragmentManager();
//        FragmentTransaction ft = fm.beginTransaction();
//
//        FragmentIthubaMenu fragment = new FragmentIthubaMenu();
//        ft.replace(R.id.content_frame, fragment);
//        ft.commit();

        getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentIthubaMenu(), "FragmentIthubaMenu").commit();

        return true;
    }
}
