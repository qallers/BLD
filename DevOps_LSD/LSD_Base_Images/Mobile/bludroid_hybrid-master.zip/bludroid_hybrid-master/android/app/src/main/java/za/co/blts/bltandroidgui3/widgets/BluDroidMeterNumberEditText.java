package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/27/2017.
 */

public class BluDroidMeterNumberEditText extends BluDroidEditText {

    private final String TAG = this.getClass().getSimpleName();

    public BluDroidMeterNumberEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUp();
    }

    private void setUp() {

        setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent event) {
                Log.v(TAG, "actionId " + actionId + " event " + event);
                if (actionId == 0) {
                    setImeActionLabel(getResources().getString(R.string.next), EditorInfo.IME_ACTION_GO);
                    setInputType(InputType.TYPE_CLASS_TEXT);
                    return true;
                }
                if (actionId == 2) {
                    BaseActivity baseScreen = baseActivityWeakReference.get();
                    if (baseScreen != null) {
                        baseScreen.hideKeyboard();
                    }
                }
                return true;
            }
        });
    }

    public BluDroidMeterNumberEditText(BaseActivity context) {
        super(context);
        setUp();
        //setRawInputType(Configuration.KEYBOARD_UNDEFINED);
    }

    @Override
    public boolean validate() {
        //BaseActivity.logger.info(": validate()");
        Log.d(TAG, "validate MeterNumber");

        String text = getText().toString().trim();
        boolean isvalidated;

        if (!text.trim().isEmpty()) {
            isvalidated = true;
            removeErrorMessage();
        } else {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                setErrorMessage(baseScreen.getResources().getString(R.string.meterNumberEmpty));
            }
            isvalidated = false;
        }


        return isvalidated;
    }
}

