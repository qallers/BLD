package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by Warren 2.0 on 26/05/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00190_Electricity_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_FBE() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeElectricity();

            if (solo.waitForFragmentByTag("FragmentElectricity")) {
                Log.d(TAG, "Select Electricity Fragment");
            } else {
                fail("Select Electricity Fragment");
            }

            solo.clickOnText("Free Basic Electricity");
            Log.d(TAG, "FBE selected");

            confirmElectrictyVoucher();

            Log.d(TAG, "Electricity confirmed with no meter number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.meterNumberEmpty))) {
                Log.d(TAG, "Meter number not entered error messages displayed");
            } else {
                fail("Meter number not entered error messages NOT displayed");
            }

            enterMeterNumber("01050020001");

            confirmElectrictyVoucher();
            Log.d(TAG, "Electricity confirmed with valid meter number");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm Electricity Voucher Displayed");
            } else {
                fail("Confirm Electricity Voucher NOT Displayed");
            }

            buyElectricityVoucher();
            Log.d(TAG, "FBE Token Purchased");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_BelaBela() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeElectricity();

            if (solo.waitForFragmentByTag("FragmentElectricity")) {
                Log.d(TAG, "Select Electricity Fragment");
            } else {
                fail("Select Electricity Fragment");
            }

            solo.clickOnText("BelaBela");
            Log.d(TAG, "Bela Bela selected");

            cancelElectricityVoucher();
            Log.d(TAG, "Electricity purchase cancelled");

            solo.sleep(500);

            solo.clickOnText("BelaBela");
            Log.d(TAG, "Bela Bela selected");

            confirmElectrictyVoucher();
            Log.d(TAG, "Electricity confirmed with no meter number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.meterNumberEmpty))) {
                Log.d(TAG, "Meter number not entered error messages displayed");
            } else {
                fail("Meter number not entered error messages NOT displayed");
            }

            enterMeterNumber("01050020001");
            Log.d(TAG, "Meter number entered");

            confirmFBEElectrictyVoucher();
            Log.d(TAG, "FBE confirmed with valid meter number");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm Electricity Voucher Displayed");
            } else {
                fail("Confirm Electricity Voucher NOT Displayed");
            }

            buyElectricityVoucher();
            Log.d(TAG, "FBE Token Purchased");

            selectVoucherTypeElectricity();

            solo.clickOnText("BelaBela");
            Log.d(TAG, "Bela Bela selected");

            enterMeterNumber("01050020001");
            Log.d(TAG, "Meter number entered");

            enterAmount("80");
            Log.d(TAG, "Amount entered");

            confirmElectrictyVoucher();
            Log.d(TAG, "Electricity confirmed with valid meter number and amount");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm Electricity Voucher Displayed");
            } else {
                fail("Confirm Electricity Voucher NOT Displayed");
            }

            buyElectricityVoucher();
            Log.d(TAG, "Munic Electricity Token Purchased");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T020_Eskom() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeElectricity();

            if (solo.waitForFragmentByTag("FragmentElectricity")) {
                Log.d(TAG, "Select Electricity Fragment");
            } else {
                fail("Select Electricity Fragment");
            }

            solo.clickOnText("Eskom");
            Log.d(TAG, "Eskom electricity selected");

            confirmElectrictyVoucher();
            Log.d(TAG, "Eskom Electricity confirmed with no meter number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.meterNumberEmpty))) {
                Log.d(TAG, "Meter number not entered error messages displayed");
            } else {
                fail("Meter number not entered error messages NOT displayed");
            }

            enterMeterNumber("01050020001");
            Log.d(TAG, "Meter number entered");

            confirmFBEElectrictyVoucher();
            Log.d(TAG, "FBE confirmed with valid meter number");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm Electricity Voucher Displayed");
            } else {
                fail("Confirm Electricity Voucher NOT Displayed");
            }

            buyElectricityVoucher();
            Log.d(TAG, "FBE Token Purchased");

            selectVoucherTypeElectricity();

            solo.clickOnText("Eskom");
            Log.d(TAG, "Eskom selected");

            enterMeterNumber("01050020001");
            Log.d(TAG, "Meter number entered");

            enterAmount("80");
            Log.d(TAG, "Amount entered");

            confirmElectrictyVoucher();
            Log.d(TAG, "Electricity confirmed with valid meter number and amount");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm Electricity Voucher Displayed");
            } else {
                fail("Confirm Electricity Voucher NOT Displayed");
            }

            buyElectricityVoucher();
            Log.d(TAG, "ESKOM Electricity Token Purchased");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T021_EskomRedeemToken() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeElectricity();

            if (solo.waitForFragmentByTag("FragmentElectricity")) {
                Log.d(TAG, "Select Electricity Fragment");
            } else {
                fail("Select Electricity Fragment");
            }

            solo.clickOnText("Eskom");
            Log.d(TAG, "Eskom electricity selected");

            solo.clickOnText("Other");
            Log.d(TAG, "Clicked on 'OTHER' tab");

            solo.clickOnText("Redeem Token");
            Log.d(TAG, "Clicked on 'Redeem Token' option");

            solo.clickOnButton("Encode Token");
            Log.d(TAG, "'Encode Token' button clicked");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.tokenNumberLength))) {
                Log.d(TAG, "'Token number must be between 16 and 20 digits' error messages displayed");
            } else {
                fail("'Token number must be between 16 and 20 digits' error messages NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked on 'Cancel' button");

            solo.clickOnText("Redeem Token");
            Log.d(TAG, "Clicked on 'Redeem Token' option");

            solo.enterText(0, "1234567890");
            Log.d(TAG, "Entered less than 16 digits");

            solo.clickOnButton("Encode Token");
            Log.d(TAG, "'Encode Token' button clicked");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.tokenNumberLength))) {
                Log.d(TAG, "'Token number must be between 16 and 20 digits' error messages displayed");
            } else {
                fail("'Token number must be between 16 and 20 digits' error messages NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked on 'Cancel' button");

            solo.clickOnText("Redeem Token");
            Log.d(TAG, "Clicked on 'Redeem Token' option");

            solo.enterText(0, "1234567890123456");
            Log.d(TAG, "Entered less than 16 digits");

            solo.clickOnButton("Encode Token");
            Log.d(TAG, "'Encode Token' button clicked");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "'Mag Reader' dialog appeared");
            } else {
                fail("Mag Reader' dialog did not appear");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
