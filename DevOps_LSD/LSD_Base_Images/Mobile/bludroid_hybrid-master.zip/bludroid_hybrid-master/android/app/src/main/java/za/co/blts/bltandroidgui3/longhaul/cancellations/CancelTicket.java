package za.co.blts.bltandroidgui3.longhaul.cancellations;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class CancelTicket implements Comparable {
    private String transactionDate;
    private String carrier;
    private String carrierName;
    private String transRef;
    private int qty;
    private String departure;
    private String destination;
    private String travelTime;

    public CancelTicket() {
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getTransRef() {
        return transRef;
    }

    public void setTransRef(String transRef) {
        this.transRef = transRef;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getTravelTime() {
        return travelTime;
    }

    public void setTravelTime(String travelTime) {
        this.travelTime = travelTime;
    }

    @Override
    public String toString() {
        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").serializeNulls().create();
        return gson.toJson(this);
    }

    @Override
    public int compareTo(Object o) {
        if (o != null) {
            return transactionDate.compareTo(((CancelTicket) o).getTransactionDate()) * -1;
        }
        return 0;
    }

}
