package za.co.blts.bltandroidgui3.confirmations;

import android.view.View;
import android.view.View.OnClickListener;

import za.co.blts.bltandroidgui3.AEONErrors;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;

//
// view and button stuff
//

public class BluDroidPrintErrorConfirmationDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, OnClickListener {
    private final String TAG = this.getClass().getSimpleName();
    public void setup() {
        super.setup();
        hideView(R.id.affirmativeButton);
        hideView(R.id.negativeButton);
        setNeutralButtonLabel(R.string.ok);
        BluDroidButton button = findViewById(R.id.neutralButton);
        if (button != null)
            button.setOnClickListener(this);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BaseActivity.loginRequestMessage = null;
                BaseActivity.loginResponseMessage = null;
                baseActivity.logout();
                baseActivity.firebaseSessionEnd("print_error");
                BaseActivity.lockBackButton = false;
            }
        });

        BaseActivity.isLotto = false;
        BaseActivity.lockBackButton = true;
        baseActivity.cleanUp();
    }

    public BluDroidPrintErrorConfirmationDialog(BaseActivity context) {
        super(context, R.layout.confirmation_network_error);
        setup();
        BaseActivity.logger.info(": construction with BaseActivity");
    }

    public void setErrorType(int errorType) {
        //
        // remove some fields if necessary
        //
        if (errorType == AEONErrors.NO_USER_ACTION_REQUIRED) {
            View view = findViewById(R.id.errorTryAgain);
            if (view != null)
                view.setVisibility(View.GONE);
            view = findViewById(R.id.errorOr);
            if (view != null)
                view.setVisibility(View.GONE);
            view = findViewById(R.id.errorRestart);
            if (view != null)
                view.setVisibility(View.GONE);
            view = findViewById(R.id.errorTheApp);
            if (view != null)
                view.setVisibility(View.GONE);
        }

    }

    public void onClick(View view) {
        BaseActivity.logger.info(((BluDroidButton) view).getText());
        BaseActivity.logger.info(": onClick()");

        if (BaseActivity.loginResponseMessage != null) {
            BaseActivity.userPin = BaseActivity.loginResponseMessage.getData().getUserPin();
        }
        BaseActivity.loginRequestMessage = null;
        BaseActivity.loginResponseMessage = null;
        baseActivity.logout();
        baseActivity.firebaseSessionEnd("print_error");
        BaseActivity.lockBackButton = false;
        baseActivity.cleanUp();

    }

}

