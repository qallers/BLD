package za.co.blts.bltandroidgui3;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;

import java.net.Socket;
import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.login.response.LoginResponseGroupMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseTransactionTypeMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseAllowedProductsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePrintEZPLMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePrintMessage;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.cardviews.CardviewVoucherMenu;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;

/**
 * Created by warrenm on 2016/10/03.
 */

public class FragmentTickets extends VoucherRecycler implements NeedsAEONResults {

    private final String TAG = this.getClass().getSimpleName();
    private BluDroidButton ticket_collection;

    private ArrayList<CardviewDataObject> list;

    private boolean isCollectionAllowed = false;

    public FragmentTickets() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(za.co.blts.bltandroidgui3.R.layout.fragment_tickets, container, false);
        recycler = rootView.findViewById(R.id.bluRecycler);

        ticket_collection = rootView.findViewById(R.id.ticket_collection);

        ticket_collection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getBaseActivity().createBluDroidCustomDialog(FragmentTickets.this);
            }
        });

        if (Build.MODEL.startsWith("CITAQ")) {
            grid = new GridLayoutManager(getActivity(), 4);
        }

        list = new ArrayList<>();

        for (int i = 0; i < BaseActivity.loginResponseMessage.getData().getTransactionTypes().size(); i++) {
            LoginResponseGroupMessage group = BaseActivity.loginResponseMessage.getData().getTransactionTypes().get(i);

            for (int j = 0; j < group.getTransactionTypes().size(); j++) {
                LoginResponseTransactionTypeMessage transactionType = group.getTransactionTypes().get(j);

                String transactionName = transactionType.getDisplayName().toLowerCase();

                if (transactionName.equalsIgnoreCase("tkp_ticket")) {
                    authenticateWithTicketPro();
                    break;
                }
            }
        }

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        String title = getActivity().getResources().getString(za.co.blts.bltandroidgui3.R.string.tickets);
        getActivity().setTitle(title);
        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();
        getBaseActivity().isTicketProReprint = false;
        getBaseActivity().navigatedFromFavourites = false;
    }

    private void populateScreen() {
        boolean eventsAllowed = false;
        boolean putcoAllowed = false;
        boolean nfcBus = BaseActivity.loginResponseMessage.getData().canDo("SmartTapEldo");

        for (int i = 0; i < getBaseActivity().ticketProResponseAllowedProductsMessage.getData().getVasProducts().size(); i++) {
            Log.d(TAG, "vas products " + getBaseActivity().ticketProResponseAllowedProductsMessage.getData().getVasProducts().get(i).getText());

            if (getBaseActivity().ticketProResponseAllowedProductsMessage.getData().getVasProducts().get(i).getText().contains("Events")) {
                eventsAllowed = true;
            }
            if (getBaseActivity().ticketProResponseAllowedProductsMessage.getData().getVasProducts().get(i).getText().contains("Putco")) {
                putcoAllowed = true;
            }
            if (getBaseActivity().ticketProResponseAllowedProductsMessage.getData().getVasProducts().get(i).getText().contains("Collection")) {
                isCollectionAllowed = true;
            }
        }


        if (eventsAllowed) {
            Log.d(TAG, "Events allowed");
            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.events, R.color.tickets, "Events", "Events"));
        }

        if (putcoAllowed) {
            Log.d(TAG, "Putco allowed");
            if (Build.MODEL.startsWith("CITAQ") || getBaseActivity().isDebug()) {
                list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.putco, R.color.white, "Putco", "Putco"));
            } else {
                Log.e(TAG, "Putco only allowed on V11, secure usb printer not available");

            }
        }

        if (getBaseActivity().canDoLongHaulBus()) {
            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.longhaulbus_menu_card, R.color.white, "Bus", "Bus"));
        }

        if (Build.MODEL.startsWith("P1") && nfcBus) {
            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.nfcbus_menu_card, R.color.white, "NFC Bus", "NFC Bus"));
        }

        ticket_collection.setVisibility(isCollectionAllowed ? View.VISIBLE : View.GONE);
        setupTicketMenuRecycler(list);
    }

    private void populateCarma() {

        if (getBaseActivity().canDoLongHaulBus()) {
            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.longhaulbus_menu_card, R.color.white, "Bus", "Bus"));
        }

        setupTicketMenuRecycler(list);
    }


    public void results(Object object) {
        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(Tickets) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }
        if (object instanceof Socket) {
            BaseActivity.socket = (Socket) object;
        } else if (object instanceof TicketProAuthenticationResponseMessage) {
            getBaseActivity().ticketProAuthenticationResponseMessage = (TicketProAuthenticationResponseMessage) object;
            if (getBaseActivity().ticketProAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                if (collectRefNumber.isEmpty()) {
                    getTicketProPermissions();
                } else {
                    doTicketProCollection(collectRefNumber);
                }

            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProAuthenticationResponseMessage, true);
            }
        } else if (object instanceof TicketProResponseAllowedProductsMessage) {
            getBaseActivity().closeAeonSocket(21);
            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProResponseAllowedProductsMessage = (TicketProResponseAllowedProductsMessage) object;
            Log.d(TAG, "got ticket pro allowed products");

            populateScreen();
            //
            // do not remove this log message
            // it iis used for testing purposes
            //
            Log.d(TAG, "TEST : RECEIVED PUTCO PERMISSIONS");
        } else if (object instanceof TicketProResponsePrintMessage) {

            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProResponsePrintMessage = (TicketProResponsePrintMessage) object;
            if (getBaseActivity().ticketProResponsePrintMessage.getEvent().getEventCode().equals("0")) {
                getBaseActivity().printEventTickets();
//                if (getBaseActivity().ticketProResponsePrintMessage.getData().getTickets().size() > 0) {
//
//                    getBaseActivity().cleanUp();
//                    getBaseActivity().createProgress(R.string.gettingTicketProFormattedTickets);
//                    HTTPGetAsyncTask getAsyncTask = new HTTPGetAsyncTask(getBaseActivity());
//                    getAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, getBaseActivity(), getBaseActivity().ticketProResponsePrintMessage.getData().getTickets().get(0).getLogoGif().getText());
//
//                }
            } else {

                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProResponsePrintMessage, true);
            }
        } else if (object instanceof TicketProResponsePrintEZPLMessage) {


            getBaseActivity().dismissProgress();
            TicketProResponsePrintEZPLMessage ticketProResponsePrintEZPLMessage = (TicketProResponsePrintEZPLMessage) object;
            if (ticketProResponsePrintEZPLMessage.getEvent().getEventCode().equals("0")) {

                getBaseActivity().cleanUp();
                getBaseActivity().createProgress(R.string.gettingTicketProFormattedTickets);

                HTTPGetAsyncTask getAsyncTask = new HTTPGetAsyncTask(getBaseActivity());
                getAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, getBaseActivity(), ticketProResponsePrintEZPLMessage.getData().getTickets());

            } else {

                getBaseActivity().createSystemErrorConfirmation(ticketProResponsePrintEZPLMessage, true);
            }
        } else {
            getBaseActivity().dismissProgress();
            Log.d(TAG, "unknown return type");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "onCreate");
        //set cart mesasge to null so a new cart must be created
        getBaseActivity().ticketProResponseCreateCartMessage = null;
        //set reserved seats message to null so cart button not displayed on toolbar until new seats are reserved
        getBaseActivity().ticketProResponseReservedSeatsMessage = null;
    }


    public boolean onBackPressed() {

        getBaseActivity().gotoMainScreen();

        return true;
    }

}