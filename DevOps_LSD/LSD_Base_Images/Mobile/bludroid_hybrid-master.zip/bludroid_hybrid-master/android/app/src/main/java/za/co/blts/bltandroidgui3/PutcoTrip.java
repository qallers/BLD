package za.co.blts.bltandroidgui3;

/**
 * Created by NkosanaM on 4/21/2017.
 */

public class PutcoTrip {

    private String travelClass;
    private String fare;
    private int iconSelected;
    private boolean isSelected;
    private String routeId;
    private String route;
    private String nipType;

    public PutcoTrip(String travelClass, String fare, int iconSelected, boolean isSelected, String routeId, String route, String nipType) {
        this.travelClass = travelClass;
        this.fare = fare;
        this.iconSelected = iconSelected;
        this.isSelected = isSelected;
        this.routeId = routeId;
        this.route = route;
        this.nipType = nipType;

    }

    public String getFare() {
        return fare;
    }

    public void setFare(String fare) {
        this.fare = fare;
    }

    public String getTravelClass() {
        return travelClass;
    }

    public void setTravelClass(String travelClass) {
        this.travelClass = travelClass;
    }

    public int getIconSelected() {
        return iconSelected;
    }

    public void setIconSelected(int iconSelected) {
        this.iconSelected = iconSelected;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }


    public String getRouteId() {
        return routeId;
    }

    public void setRouteId(String routeId) {
        this.routeId = routeId;
    }

    public String getRoute() {
        return route;
    }

    public void setRoute(String route) {
        this.route = route;
    }

    public String getNipType() {
        return nipType;
    }

    public void setNipType(String nipType) {
        this.nipType = nipType;
    }
}
