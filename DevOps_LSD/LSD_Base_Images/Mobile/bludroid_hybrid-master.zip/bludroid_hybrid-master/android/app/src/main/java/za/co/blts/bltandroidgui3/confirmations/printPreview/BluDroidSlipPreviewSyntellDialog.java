package za.co.blts.bltandroidgui3.confirmations.printPreview;

import java.lang.ref.WeakReference;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;

public class BluDroidSlipPreviewSyntellDialog extends BluDroidSlipPreviewDialog {
    private final String TAG = this.getClass().getSimpleName();
    private WeakReference<BaseActivity> activityReference;

    public BluDroidSlipPreviewSyntellDialog(final BaseActivity activity, List<PrintJob> printJobs) {
        super(activity, printJobs);
        activityReference = new WeakReference<>(activity);
        setTitle("Syntell Preview");
        setup();
    }

    public void finishTransaction() {
        BaseActivity activity = activityReference.get();
        if (activity != null) {
            activity.completeSyntell();
        }
    }
}
