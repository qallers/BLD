package za.co.blts.bltandroidgui3.confirmations;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.Date;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//import android.view.View;

/**
 * Created by NkosanaM on 4/20/2017.
 */

public class BluDroidTimePickerDialog extends BluDroidAlertDialog {

    private Builder dialogBuilder = null;
    private Date mDate;
    private int hour, min;
    private Calendar calendar;
    private String timeString;

    public BluDroidTimePickerDialog(BaseActivity context) {
        super(context);
        setUp(context);
    }

    public void setUp(BaseActivity context) {
        dialogBuilder = new Builder(context);
        LayoutInflater inflater = context.getLayoutInflater();

        mDate = new Date();

        calendar = Calendar.getInstance();
        calendar.setTime(mDate);
        hour = 0;
        min = 0;

        timeString = formatTime(hour, min);

        @SuppressLint("InflateParams") View dialogView = inflater.inflate(R.layout.dialog_time_picker, null);
        dialogBuilder.setView(dialogView);

        TimePicker timePicker = dialogView.findViewById(R.id.timePicker);
        timePicker.setIs24HourView(true);
        timePicker.setCurrentHour(0);
        timePicker.setCurrentMinute(0);

//        timePicker.init(year, month, day, new DatePicker.OnDateChangedListener() {
//            public void onDateChanged(DatePicker view, int year, int month, int day) {
//                BluDroidTimePickerDialog.this.year = year;
//                BluDroidTimePickerDialog.this.month = month;
//                BluDroidTimePickerDialog.this.day = day;
//
//                timeString = formatTime(day, month, year);
//                // fromDate.setText(date);
//
//                updateDateTime();
//            }
//        });

        timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                hour = hourOfDay;
                min = minute;
                timeString = formatTime(hourOfDay, minute);
                updateDateTime();
            }
        });

        dialogBuilder.setTitle("Time");


    }

    private String formatTime(int temp_hour, int temp_min) {
        String hourTmp, minTmp;
        if (temp_hour < 10) {
            hourTmp = "0" + temp_hour;
        } else {
            hourTmp = "" + temp_hour;
        }

        if (temp_min < 10) {
            minTmp = "0" + temp_min;
        } else {
            minTmp = "" + temp_min;
        }

        return hourTmp + ":" + minTmp;
    }

    public void createDialog() {
        AlertDialog dialog = dialogBuilder.create();
        dialog.show();
    }


    @Override
    public void setNegativeOption(String option, OnClickListener listener) {
        dialogBuilder.setNegativeButton(option, listener);
    }

    @Override
    public void setPositiveOption(String option, OnClickListener listener) {
        dialogBuilder.setPositiveButton(option, listener);
    }

    @Override
    public void setNeutralOption(String option, OnClickListener listener) {
        dialogBuilder.setNeutralButton(option, listener);
    }


    private void updateDateTime() {
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, min);
        calendar.set(Calendar.SECOND, 0);

        mDate = calendar.getTime();
    }

    public String getTimeString() {

        //return year + "-" + month + "-" + day + "  " + hour + ":" + min;
        return timeString;
    }

    public String getMillies() {

        return String.valueOf(calendar.getTimeInMillis());
    }
}
