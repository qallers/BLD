package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.graphics.PorterDuff;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by MasiS on 3/8/2017.
 */

public class BluDroidMandatoryAutoCompleteTextView extends androidx.appcompat.widget.AppCompatAutoCompleteTextView implements View.OnTouchListener, BluDroidValidatable, TextWatcher, BluDroidSetupable, View.OnFocusChangeListener {

    private int errorFieldResourceId = -1;

    private final String TAG = this.getClass().getSimpleName();

    private int maxLength = -1;

    //
    // onTextChanged often gets called twice
    // I don't understand why but this boolean
    // is a temporary fix
    //
    private boolean alreadyCalledFlow = false;

    private WeakReference<BaseActivity> baseActivityWeakReference = null;

    private void setTextSize(int size) {
        super.setTextSize(size);
    }

    public void setTextColor(int color) {
        super.setTextColor(color);
    }


    public void setup() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                setTextSize(baseScreen.getSkinResources().getTextSize());
                setTextColor(baseScreen.getSkinResources().getBackgroundTextColor());
                getBackground().setColorFilter(baseScreen.getSkinResources().getButtonColor(), PorterDuff.Mode.SRC_IN);
                setOnTouchListener(this);
                Log.d(TAG, "setOnTouchListener");
                addTextChangedListener(this);
                Log.d(TAG, "setOnFocusChangeListener");
                setOnFocusChangeListener(this);
                Log.d(TAG, "setup complete");
            }
        }
    }

    public BluDroidMandatoryAutoCompleteTextView(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setup();


    }

    public BluDroidMandatoryAutoCompleteTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        boolean needTextSize = true;
        boolean needTextColor = true;

        for (int i = 0; i < attrs.getAttributeCount(); i++) {
            if (attrs.getAttributeName(i).equals("textSize")) {
                needTextSize = false;
            }
            if (attrs.getAttributeName(i).equals("textColor")) {
                needTextColor = false;
            }
            if (attrs.getAttributeName(i).equals("errorField")) {
                errorFieldResourceId = attrs.getAttributeResourceValue(i, -1);
            }
            if (attrs.getAttributeName(i).equals("maxLength")) {
                maxLength = attrs.getAttributeIntValue(i, -1);
            }

        }

        if (context instanceof BaseActivity) {
            try {
                this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
                setup();
                if (needTextColor) {
                    setTextColor(((BaseActivity) context).getSkinResources().getBackgroundTextColor());
                }
                getBackground().setColorFilter(((BaseActivity) context).getSkinResources().getButtonColor(), PorterDuff.Mode.SRC_IN);
                if (needTextSize) {
                    setTextSize(((BaseActivity) context).getSkinResources().getTextSize());
                }
            } catch (Exception exception) {
                Log.d(TAG, "BluDroidEditText exception " + exception);
            }
        }
    }

    public boolean onTouch(View v, MotionEvent event) {
        Log.d(TAG, "onTouch [" + getText().toString().trim() + "]");

        if (errorFieldResourceId != -1) {
            TextView textView = getErrorTextView();
            if (textView != null) {
                textView.setText("");
                removeErrorMessage();
            }
        }
        return false;
    }

    public void setContext(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    public void afterTextChanged(Editable s) {
    }

    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    public void onTextChanged(CharSequence s, int start, int before, int count) {

        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                baseScreen.resetTimer();
                if (alreadyCalledFlow) {
                    baseScreen.cancelTimer();
                }

                int ccnt = getText().toString().trim().length();
                if (ccnt > 0) {
                    removeErrorMessage();
                }
                if ((baseScreen instanceof BluDroidFlowable) &&
                        (maxLength != -1)) {
                    int cnt = getText().toString().trim().length();
                    Log.d(TAG, "count is " + cnt);


                    if (cnt < maxLength)
                        alreadyCalledFlow = false;

                    if (cnt == maxLength && !alreadyCalledFlow) {
                        Log.d(TAG, "calling flow");
                        alreadyCalledFlow = true;
                        ((BluDroidFlowable) baseScreen).flow(this);
                    }
                }
            }
        }
    }


    public boolean validate() {
        //BaseActivity.logger.info(": validate()");
        String text = getText().toString().trim();
        boolean isvalidated = false;

        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                if (text.isEmpty()) {
                    setErrorMessage(baseScreen.getResources().getString(R.string.required));
                    isvalidated = false;
                } else {
                    removeErrorMessage();
                    isvalidated = true;
                }
            }
        }
        return isvalidated;
    }

    public void onFocusChange(View view, boolean hasFocus) {
        Log.d(TAG, "onFocusChange hasFocus is " + hasFocus);
        if (!hasFocus) {
            this.validate();
        }
    }

    private BluDroidErrorTextView getErrorTextView() {
        ViewParent parent = getParent();
        if (parent instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) parent;
            for (int i = 0; i < group.getChildCount(); i++) {
                View child = group.getChildAt(i);
                if (child.getId() == errorFieldResourceId) {
                    return (BluDroidErrorTextView) child;
                }
            }
        }
        return null;
    }

    private void setErrorMessage(String message) {
        try {
            if (errorFieldResourceId != -1) {
                BluDroidErrorTextView textView = getErrorTextView();

                if (textView != null) {
                    textView.setText(message);
                    if (baseActivityWeakReference != null) {
                        BaseActivity baseScreen = baseActivityWeakReference.get();
                        if (baseScreen != null) {
                            this.getBackground().setColorFilter(baseScreen.getSkinResources().getErrorColor(), PorterDuff.Mode.SRC_IN);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }


    public void setErrorMessage(int messageResourceId) {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                setErrorMessage(baseScreen.getResources().getString(messageResourceId));
            }
        }
    }


    private void removeErrorMessage() {
        try {
            if (errorFieldResourceId != -1) {
                //TextView textView = (TextView) baseScreen.findViewById(errorFieldResourceId);
                BluDroidErrorTextView textView = getErrorTextView();
                if (textView != null) {
                    textView.setText("");
                    if (baseActivityWeakReference != null) {
                        BaseActivity baseScreen = baseActivityWeakReference.get();
                        if (baseScreen != null) {
                            this.getBackground().setColorFilter(baseScreen.getSkinResources().getButtonColor(), PorterDuff.Mode.SRC_IN);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

}
