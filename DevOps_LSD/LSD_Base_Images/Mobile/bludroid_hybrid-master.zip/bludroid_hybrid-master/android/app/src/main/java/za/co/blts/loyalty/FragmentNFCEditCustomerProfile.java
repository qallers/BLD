package za.co.blts.loyalty;

import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import sunmi.paylib.SunmiPayKernel;
import za.co.blt.consumer.loyalty.api.service.model.request.ConsumerProfileRequest;
import za.co.blt.consumer.loyalty.api.service.model.response.Error;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.BluDroidVolley;
import za.co.blts.bltandroidgui3.MainApplication;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidIdNumberEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMandatoryEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidScrollView;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentNFCEditCustomerProfile extends BaseFragment implements BluDroidNFCCardAsyncResponse {

    private final String TAG = this.getClass().getSimpleName();
    private BluDroidButton nfc_update;
    private ConsumerProfileRequest consumerProfileRequest = new ConsumerProfileRequest();
    private BluDroidVolley bluDroidVolley;
    private Bundle fromFragment = new Bundle();
    private BluDroidAlertDialog alert = null;
    private BluDroidMandatoryEditText nfc_card_code, nfc_name, nfc_surname;
    private BluDroidCellphoneEditText nfc_cell_number;
    private BluDroidIdNumberEditText nfc_id_number;

    //----------------------------------------------------------------------------------------------
    public FragmentNFCEditCustomerProfile() {
        // Required empty public constructor
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_nfc_edit_profile, container, false);
        getBaseActivity().hideKeyboard();
        fromFragment = getArguments();

        nfc_card_code = rootView.findViewById(R.id.nfc_card_code);
        nfc_name = rootView.findViewById(R.id.nfc_name);
        nfc_surname = rootView.findViewById(R.id.nfc_surname);
        nfc_cell_number = rootView.findViewById(R.id.nfc_cell_number);
        nfc_id_number = rootView.findViewById(R.id.nfc_id_number);

        getBaseActivity().toolbar.removeNavigationIcon();

        BluDroidButton nfc_cancel = rootView.findViewById(R.id.cancel_nfc);
        nfc_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        });

        final BluDroidScrollView layout = rootView.findViewById(R.id.layout);

        nfc_update = rootView.findViewById(R.id.nfc_update);
        nfc_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (layout.validate()) {

                    if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCEditConsumerProfile")) {
                        sendCustomerProfile();

                    } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateCardScreen")) {
                        alert = getBaseActivity().confirmDeactivateCardDialog("Replace card", "Are you sure you want to replace the Card?");

                        alert.setPositiveOption(getString(R.string.nfc_confirm_replace_card), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                sendCustomerProfile();
                            }
                        });

                        alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                alert.dismiss();
                            }
                        });

                        alert.show();
                        // create a confirmation dialog
                    } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateProfileScreen")) {

                        alert = getBaseActivity().confirmDeactivateCardDialog("Deactivate Profile", "Are you sure you want to Deactivate the Profile?");

                        alert.setPositiveOption(getString(R.string.nfc_confirm_deactivate_profile), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                doDeactivateProfileReguest();
                            }
                        });

                        alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                alert.dismiss();
                            }
                        });

                        alert.show();
                        // create a confirmation dialog
                    }
                }
            }
        });

        // REPLALCE THIS WITH DATABINDING TECHNIQUE WHEN FULLY IMPLEMENTED

        BluDroidTextView nfc_card_code_text = rootView.findViewById(R.id.nfc_card_code_text);

        // we need to enable of disable certain fields based on what we are planning to edit and send to the server
        // lets do that here
        if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCEditConsumerProfile")) {
            // disable and enable fields
            nfc_card_code_text.setText(R.string.card_code);
        } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateCardScreen")) {
            // disable and enable fields
            nfc_card_code_text.setText(R.string.new_card_code);
        }

        setCustomerProfileToViews();
        if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateProfileScreen")) {
            disableInputFields();
            changeButtonLabels();
        } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateCardScreen")) {
            disableInputFields();
            nfc_update.setText(getString(R.string.nfc_lost_card));
        }


        return rootView;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCEditConsumerProfile")) {
            setTitle(getString(R.string.nfc_edit));
        } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateCardScreen")) {
            setTitle(getString(R.string.replace_card));
        } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateProfileScreen")) {
            setTitle(getString(R.string.nfc_deactivate_profile));
        }

        bluDroidVolley = BluDroidVolley.getInstance(getBaseActivity());
    }

    //----------------------------------------------------------------------------------------------
    private void setTitle(String title) {
        getActivity().setTitle(title);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean onBackPressed() {
        closeFragment();
        return true;
    }

    //----------------------------------------------------------------------------------------------
    private void disableInputFields() {
        nfc_card_code.setEnabled(false);
        nfc_name.setEnabled(false);
        nfc_surname.setEnabled(false);
        nfc_cell_number.setEnabled(false);
        nfc_id_number.setEnabled(false);
    }

    //----------------------------------------------------------------------------------------------
    private void changeButtonLabels() {
        nfc_update.setText(getString(R.string.nfc_confirm_deactivate_profile));
    }

    //----------------------------------------------------------------------------------------------
    private void setCustomerProfileToViews() {
        if (BaseActivity.consumerProfile != null) {
            // they come from the server
            nfc_name.setText(BaseActivity.consumerProfile.getName());
            nfc_surname.setText(BaseActivity.consumerProfile.getSurname());
            nfc_id_number.setText(BaseActivity.consumerProfile.getIdentityNumber());
            nfc_cell_number.setText(BaseActivity.consumerProfile.getMobile());

            if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCEditConsumerProfile") || fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateProfileScreen")) {
                nfc_card_code.setText(BaseActivity.consumerProfile.getLoyaltyCard());
            }


            // these are already set
            //consumerProfileRequest.setDeviceId(getBaseActivity().getPreference(PREF_DEVICE_ID));
            //consumerProfileRequest.setDeviceUserId(getBaseActivity().getPreference(BaseActivity.loginResponseMessage.getData().getUserId()));
        }
    }

    //----------------------------------------------------------------------------------------------
    private void sendCustomerProfile() {
        // validate fields using the parent's layout validate()
        //if(layout.validate()) {
        consumerProfileRequest.setName(nfc_name.getText().toString());
        consumerProfileRequest.setSurname(nfc_surname.getText().toString());
        consumerProfileRequest.setIdentityNumber(nfc_id_number.getText().toString());
        consumerProfileRequest.setMobile(nfc_cell_number.getText().toString());
        consumerProfileRequest.setLoyaltyCard(nfc_card_code.getText().toString());
        // we can use values stored in shared prefs, the response object does not have these properties
        consumerProfileRequest.setDeviceId(getBaseActivity().getPreference(PREF_DEVICE_ID));
        consumerProfileRequest.setDeviceUserId(getBaseActivity().getPreference(BaseActivity.loginResponseMessage.getData().getUserId()));
        // if valid
        try {
            doRequest(new JSONObject(new Gson().toJson(consumerProfileRequest)));
        } catch (JSONException e) {
            BaseActivity.logger.error(" " + e);
            e.printStackTrace();
        }
        //}
    }

    //----------------------------------------------------------------------------------------------
    // since we are not requesting for json, we will then request for a string
    // take a look at how we embed our json object as a string body data.
    // we need to explicitly tell the request the content type since its set to text by default
    private void doRequest(final JSONObject o) {
        StringRequest registerConsumer = new StringRequest(Request.Method.PUT,
                BaseActivity.loyaltyServerBaseUrl + BaseActivity.consumerProfile.getProfileId(),
                createReqSuccessListener(),
                createReqErrorListener()) {
            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }

            @Override
            public byte[] getBody() {
                return o.toString() == null ? null : o.toString().getBytes(StandardCharsets.UTF_8);
            }
        };

        if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCEditConsumerProfile")) {
            getBaseActivity().createProgress(R.string.nfc_update);
        } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateCardScreen")) {
            getBaseActivity().createProgress(R.string.replace_card);
        }

        bluDroidVolley.addRequestApiGateway(registerConsumer); // make sure that this is not null
    }

    //----------------------------------------------------------------------------------------------
    private void doDeactivateProfileReguest() {

        String url = BaseActivity.loyaltyServerBaseUrl + BaseActivity.consumerProfile.getProfileId()
                + "?deviceid=" + getBaseActivity().getPreference(PREF_DEVICE_ID)
                + "&deviceuserid=" + BaseActivity.loginResponseMessage.getData().getUserId();

        Log.d(TAG, "delete url: " + url);


        StringRequest deactivateProfile = new StringRequest(Request.Method.DELETE,
                url,
                createReqSuccessListener(),
                createReqErrorListener()) {
            @Override
            public Map<String, String> getParams() {
                Map<String, String> mParams = new HashMap<>();
                mParams.put("deviceid", getBaseActivity().getPreference(PREF_DEVICE_ID));
                mParams.put("deviceuserid", BaseActivity.loginResponseMessage.getData().getUserId());
                return mParams;
            }
        };
        getBaseActivity().createProgress(R.string.deactivating_profile);
        bluDroidVolley.addRequestApiGateway(deactivateProfile); // make sure that this is not null
    }

    //----------------------------------------------------------------------------------------------
    private Response.Listener<String> createReqSuccessListener() {
        return new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                getBaseActivity().dismissProgress();
                String messageTitle = "";
                String successMessage = "";
                if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCEditConsumerProfile")) {
                    messageTitle = "Successful";
                    successMessage = "Editing Successful";
                } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateCardScreen")) {
                    messageTitle = "Successful";
                    successMessage = "Card has been replaced successfully";
                } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateProfileScreen")) {
                    messageTitle = "Successful";
                    successMessage = "Account has been deactivated successfully";
                }
                BaseActivity.logger.info(" " + successMessage + " - " + BaseActivity.consumerProfile);
                handleResponseMessage(true, messageTitle, successMessage);
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    private Response.ErrorListener createReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.e("error: " + error);
                String message;
                if (getBaseActivity() != null) {
                    getBaseActivity().dismissProgress();
                    VolleyLog.e("error.getMessage(): " + error.getMessage());
                    VolleyLog.e("error.networkResponse: " + error.networkResponse);
                    String errorMessage;
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            errorMessage = new String(error.networkResponse.data, StandardCharsets.UTF_8); // for UTF-8 encoding
                            VolleyLog.e("errorMessage: " + errorMessage);
                            Error error1 = new Gson().fromJson(errorMessage, Error.class);
                            message = error1.getMessage();
                        } catch (Exception e) {
                            BaseActivity.logger.error(" " + e);
                            e.printStackTrace();
                            message = "An unknown error occurred";
                        }
                    } else {
                        message = "Could not connect";
                    }

                    BaseActivity.logger.error(" " + message);
                    handleResponseMessage(false, "Failed", message); // propagate the server error message
                }
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    private void handleResponseMessage(final boolean responseIsSuccessful, String title, String message) {
        String messageTitle;
        if (responseIsSuccessful) {
            messageTitle = title;
        } else {
            messageTitle = "Failed";
        }

        alert = getBaseActivity().createAlertDialog(messageTitle, message);

        String stringOption = "";

        if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateCardScreen")) {
            stringOption = getString(R.string.nfc_confirm_replace_card);
        } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateProfileScreen")) {
            stringOption = getString(R.string.nfc_confirm_deactivate_profile);
        }
        alert.setPositiveOption(stringOption, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (responseIsSuccessful)
                    getBaseActivity().clearNFCActiveConsumer(true);
                else
                    alert.dismiss(); // retry
            }
        });
    }
    //----------------------------------------------------------------------------------------------
    /*
    * You can use the internal IP and port:
    http://10.22.7.12:9012/customer/loyalty/v1/...

    Or the external IP and port:
    http://196.37.22.179:9012/customer/loyalty/v1/...
*/


    private void closeFragment() {
        getBaseActivity().clearNFCActiveConsumer(true);
    }

    @Override
    public void onError(String msg) {
        BaseActivity.logger.error(" " + msg);
    }

    @Override
    public void onReady() {

    }

    @Override
    public void onCardNumberRead(String cardNumber) {
        nfc_card_code.setText(cardNumber);

    }

    @Override
    public void onPause() {
        super.onPause();
        stopNFCListener();
        if (mSunmiPayKernel != null) {
            mSunmiPayKernel.destroyPaySDK();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (Build.MODEL.startsWith("P1")) {
            mSunmiPayKernel = SunmiPayKernel.getInstance();
            mSunmiPayKernel.connectPayService(getContext(), mConnCallback);
        } else {
            startNFCListener(FragmentNFCEditCustomerProfile.this);
        }
    }

    private SunmiPayKernel.ConnCallback mConnCallback = new SunmiPayKernel.ConnCallback() {
        @Override
        public void onServiceConnected() {
            try {
                //Toast.makeText(ActivityMain.this, "onServiceConnected()", Toast.LENGTH_SHORT).show();
                MainApplication.mReadCardOpt = mSunmiPayKernel.mReadCardOpt;
                startNFCListener(FragmentNFCEditCustomerProfile.this);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected() {
        }
    };
}
