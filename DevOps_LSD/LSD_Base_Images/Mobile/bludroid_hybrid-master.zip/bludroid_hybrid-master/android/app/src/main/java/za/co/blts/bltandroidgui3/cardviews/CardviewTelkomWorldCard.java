package za.co.blts.bltandroidgui3.cardviews;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewTelkomWorldCard extends CardviewDataObject {

    public CardviewTelkomWorldCard(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.telkom,
                baseActivity.getResources().getColor(R.color.telkom),
                stockId, voucherType, tag, voucherTypeDesc);

        super.setHasAirtimePlus(hasAirtimePlus);
    }

    //
// NB this supplier code is for TelkomMobile only
//
    public String getSupplierCode() {
        return "4";
    }

    public String getBundlesName() {
        return "TelkomMobileBundles";
    }

    public String getTopupName() {
        return "Telkommobile";
    }
}

