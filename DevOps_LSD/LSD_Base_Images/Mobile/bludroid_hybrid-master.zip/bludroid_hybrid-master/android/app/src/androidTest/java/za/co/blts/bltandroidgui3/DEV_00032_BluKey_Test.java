package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 2/8/2017.
 */
@RunWith(AndroidJUnit4.class)
public class DEV_00032_BluKey_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }


    @Test
    public void testBluKey() {

        try {
            checks.bluKey();
            Log.d(TAG, "Clicked on 'BluKey View'");

            solo.goBack();
            Log.d(TAG, "Click back to exit");


            solo.waitForDialogToOpen();
            Log.d(TAG, "search for exit on dialog box");
            //solo.waitForDialogToOpen();
            solo.clickOnText("Cancel");
            Log.d(TAG, "Cancel is clicked");

            solo.goBack();
            solo.waitForDialogToOpen();
            Log.d(TAG, "search for exit BluKey on dialog box");
            solo.clickOnText("Exit");

            Log.d(TAG, "Exiting BluKey window");

        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }


}
