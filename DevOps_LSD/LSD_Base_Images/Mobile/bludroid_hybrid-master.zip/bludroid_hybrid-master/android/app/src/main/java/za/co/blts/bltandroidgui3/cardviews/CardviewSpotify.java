package za.co.blts.bltandroidgui3.cardviews;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewSpotify extends CardviewDataObject {

    public CardviewSpotify(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.spotify,
                baseActivity.getResources().getColor(R.color.spotify),
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(false);
    }

    public String getSupplierCode() {
        return "-1";
    }
}

