package za.co.blts.bltandroidgui3.widgets;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidDeviceIdEditText extends BluDroidIntegerEditText {
    private final String TAG = this.getClass().getSimpleName();
    private String editTextCategory;

    private void setUpDeviceId() {
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(9);
        setFilters(inputFilters);
    }

    public BluDroidDeviceIdEditText(BaseActivity context) {
        super(context);
        setUpDeviceId();

    }

    public BluDroidDeviceIdEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpDeviceId();

        @SuppressLint("CustomViewStyleable") TypedArray attributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidEditText);

        try {
            editTextCategory = attributesArray.getString(R.styleable.BluDroidEditText_EditTextCategory);
        } catch (Exception e) {
            e.printStackTrace();
        }
        attributesArray.recycle();
    }

    public boolean validate() {
        Log.d(TAG, "validate");
        //BaseActivity.logger.info(": validate()");
        if (!(getText().toString().length() > 0)) {
            setErrorMessage(R.string.deviceIdError);
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                if (editTextCategory != null) {

                    if (editTextCategory.equalsIgnoreCase("deviceSettings")) {
                        baseScreen.deviceSettingsHaserrors = true;

                    } else if (editTextCategory.equalsIgnoreCase("ricaSettings")) {
                        baseScreen.ricaSettingsHaserrors = true;
                    } else if (editTextCategory.equalsIgnoreCase("repositorySettings")) {
                        baseScreen.repositorySettingsHaserrors = true;
                    }
                }
            }
            return false;
        } else {
            removeErrorMessage();
            return true;
        }
    }

}

