package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseItemMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by MasiS on 4/5/2018.
 */

class BluDroidTicketsReprintsAdapter extends ArrayAdapter<CarmaResponseTicketMessageSerializable> {
    private WeakReference<BaseActivity> baseActivityWeakReference;

    //----------------------------------------------------------------------------------------------
    public BluDroidTicketsReprintsAdapter(BaseActivity context, int layoutResourceId, ArrayList<CarmaResponseTicketMessageSerializable> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            final CarmaResponseTicketMessageSerializable carmaResponseTicketMessage = getItem(position);
            final ViewHolder viewHolder;

            if (convertView == null) {
                // inflate the layout
                convertView = baseActivity.getLayoutInflater().inflate(R.layout.reprint_bus_ticket_layout_item, parent, false);
                // well set up the ViewHolder
                viewHolder = new ViewHolder();
                viewHolder.bus_icon_image_view = convertView.findViewById(R.id.bus_icon_image_view);
                viewHolder.ticket_price = convertView.findViewById(R.id.ticket_price);
                viewHolder.ticket_number = convertView.findViewById(R.id.ticket_number);
                viewHolder.reference_number = convertView.findViewById(R.id.reference_number);
                viewHolder.issue_date = convertView.findViewById(R.id.issue_date);
                viewHolder.bus_class_type = convertView.findViewById(R.id.class_type);
                viewHolder.selectTicketToReprint = convertView.findViewById(R.id.selectTicketToReprint);
                viewHolder.carrier_name = convertView.findViewById(R.id.carrier_name);

                // store the holder with the view.
                convertView.setTag(viewHolder);
            } else {
                // we've just avoided calling findViewById() on resource everytime
                // just use the viewHolder
                viewHolder = (ViewHolder) convertView.getTag();
            }

            if (carmaResponseTicketMessage != null) { // the object at current position

                String carrierCode = "";

                for (CarmaResponseItemMessage carrier : baseActivity.carmaResponseCarrierListMessage.getData().getItems()) {
                    if (carmaResponseTicketMessage.getCarrier().equalsIgnoreCase(carrier.getName())) {
                        carrierCode = carrier.getCode();
                    }
                }

                Log.d("carrierNameB", "getView: carrierName " + carmaResponseTicketMessage.getCarrierDescription());

                viewHolder.carrier_name.setText(carmaResponseTicketMessage.getCarrierDescription());

                viewHolder.imageURL = baseActivity.carmaResponseCarrierListMessage.getData().getMediaUrl() + "/" + carrierCode + ".png";
                viewHolder.bus_icon_image_view.setTag(viewHolder.imageURL);
                if (viewHolder.bus_icon_image_view != null) {
                    Picasso picasso = Picasso.get();
                    picasso.setIndicatorsEnabled(baseActivity.isDebug());
                    picasso
                            .load(viewHolder.imageURL)
                            .placeholder(R.drawable.longhaul)
                            .error(R.drawable.longhaul)
                            .into(viewHolder.bus_icon_image_view);
                }


                String disp = "R" + new BluDroidUtils().formatMoney(carmaResponseTicketMessage.getAmount());
                viewHolder.ticket_price.setText(disp);

                viewHolder.ticket_number.setText(carmaResponseTicketMessage.getTicketNumber());
                viewHolder.reference_number.setText(carmaResponseTicketMessage.getReference());
                viewHolder.issue_date.setText(carmaResponseTicketMessage.getTicketTimeStamp());
                viewHolder.bus_class_type.setText(carmaResponseTicketMessage.getTravelClass());
            }

            viewHolder.selectTicketToReprint.setOnClickListener(new View.OnClickListener() {
                @SuppressLint("ResourceAsColor") // what does this do? like I still don't get it
                @Override
                public void onClick(View v) {
                    BaseActivity.logger.info(((BluDroidTextView) v).getText());
                    baseActivity.reprintTicket(carmaResponseTicketMessage);
                    baseActivity.gotoMainScreen();
                }
            });
        }
        // Return the completed view to render on screen
        return convertView;
    }

    //----------------------------------------------------------------------------------------------
    static class ViewHolder {
        ImageView bus_icon_image_view;
        TextView ticket_price;
        BluDroidTextView ticket_number;
        BluDroidTextView reference_number;
        TextView issue_date;
        TextView bus_class_type;
        TextView carrier_name;
        BluDroidTextView selectTicketToReprint;
        String imageURL;
    }

    //----------------------------------------------------------------------------------------------
}
