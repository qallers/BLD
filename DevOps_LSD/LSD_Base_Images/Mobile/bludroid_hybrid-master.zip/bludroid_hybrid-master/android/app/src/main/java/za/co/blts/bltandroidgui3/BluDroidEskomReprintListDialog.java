package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ListView;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponseMeterMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponseTokenMessage;
import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidHeading;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.magcard.BluDroidMagCardAsyncReponse;
import za.co.blts.magcard.MagCardData;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

/**
 * Created by NkosanaM on 3/23/2017.
 */

public class BluDroidEskomReprintListDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, TextWatcher, BluDroidMagCardAsyncReponse {


    private ListView listView;

    private Animation animShow, animHide;

    private BluDroidEskomReprintListAdapter reprintListAdapter;

    private ArrayList<EskomReprint> reprintList;

    private BluDroidHeading noTransactions;

    public void setup() {
        super.setup();

        if (baseActivity.openMagEncoder()) {
            baseActivity.magCard.setDelegate(this);
        }

        reprintList = new ArrayList<>();
        initAnimation();

        setHeading("Eskom  Reprint List");


        listView = findViewById(R.id.reprintList);
        listView.setTextFilterEnabled(true);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        noTransactions = findViewById(R.id.noTransactions);
        BluDroidHeading meterNumber = findViewById(R.id.meterNumber);

        meterNumber.setText(baseActivity.meterNum);

        hideList();
        generateReprintList();

    }

    @Override
    protected void onStop() {
        if (listView != null) listView.setAdapter(null);
        super.onStop();
    }

    public BluDroidEskomReprintListDialog(BaseActivity context) {
        super(context, R.layout.dialog_eskom_reprint_list);
        setup();
        Log.d(TAG, "user details");
    }

    private void generateReprintList() {

        for (int i = 0; i < baseActivity.eskomDirectReprintResponseMessage.getData().getVouchers().size(); i++) {
            String type = "Voucher";
            String date = baseActivity.eskomDirectReprintResponseMessage.getData().getVouchers().get(i).getDate();
            String printMagCard = baseActivity.eskomDirectReprintResponseMessage.getData().getVouchers().get(i).getPrintMagCard();
            ElectricityVoucherResponseMeterMessage meter = baseActivity.eskomDirectReprintResponseMessage.getData().getVouchers().get(i).getMeter();
            ArrayList<ElectricityVoucherResponseTokenMessage> tokens = baseActivity.eskomDirectReprintResponseMessage.getData().getVouchers().get(i).getTokens();

            double amountDouble = 0.0;
            for (int j = 0; j < baseActivity.eskomDirectReprintResponseMessage.getData().getVouchers().get(i).getTokens().size(); j++) {

                amountDouble += Double.parseDouble(baseActivity.eskomDirectReprintResponseMessage.getData().getVouchers().get(i).getTokens().get(j).getAmount());
            }

            ArrayList<CommonResponseLineMessage> printLines = baseActivity.eskomDirectReprintResponseMessage.getData().getVouchers().get(i).getPrintLines();

            EskomReprint reprint = new EskomReprint(type, date, Double.toString(amountDouble), printLines, printMagCard, meter, tokens);
            reprintList.add(reprint);
        }
        reprintListAdapter = new BluDroidEskomReprintListAdapter(baseActivity, R.layout.reprint_row_item, reprintList);
        listView.setAdapter(reprintListAdapter);
        showList();

        if (reprintList.size() > 0) {
            noTransactions.setVisibility(View.GONE);
        } else {
            showNoTransactions();
        }


    }

    private void initAnimation() {
        animShow = AnimationUtils.loadAnimation(baseActivity, R.anim.view_show);
        animHide = AnimationUtils.loadAnimation(baseActivity, R.anim.view_hide);
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        reprintListAdapter.getFilter().filter(s);
    }


    @Override
    public void afterTextChanged(Editable s) {

    }

    private void showList() {
        View view = this.findViewById(R.id.reprintList);
        view.startAnimation(animShow);
        view.setVisibility(VISIBLE);
    }

    private void showNoTransactions() {
        noTransactions.startAnimation(animShow);
        noTransactions.setVisibility(VISIBLE);
    }

    private void hideList() {

        View view = this.findViewById(R.id.reprintList);
        view.startAnimation(animHide);
        view.setVisibility(GONE);
    }

    @Override
    public void processFinish(String output) {
        if (baseActivity.alert != null) {
            baseActivity.alert.dismiss();
        }

        if (baseActivity.magCardAction.equalsIgnoreCase("write")) {


            if (output.toLowerCase().contains("success")) {

                baseActivity.createMagCardAlertDialog("Mag Encoder", output);

                baseActivity.alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        baseActivity.magCardDataList.remove(0);

                        if (baseActivity.magCardDataList.size() > 0) {
                            baseActivity.cardNumber++;
                            baseActivity.isElectricityResponseFirstTime = false;
                            baseActivity.results(baseActivity.electricityVoucherResponseMessage);
                        }
//                        else{
//                            baseActivity.printElectricityVoucher();
//                        }

                        dialog.dismiss();
                    }
                });
                baseActivity.alert.show();
            } else {
                baseActivity.createMagCardAlertDialog("Mag Encoder", output + ", Would You like to retry?");
                baseActivity.alert.setPositiveOption("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        baseActivity.magCard.resetMsr();

                        MagCardData cardData = baseActivity.magCardDataList.get(0);
                        baseActivity.magCard.setTrack2(cardData.getTrack2());
                        baseActivity.magCard.setTrack3(cardData.getTrack3());

                        baseActivity.magCard.sendWriteCommand();
                        baseActivity.magCardAction = "write";
                        baseActivity.createNotifyAlertDialog("Mag Card", "Please swipe card to write " + baseActivity.cardNumber + "/" + baseActivity.tokensSize);
                    }
                });

                baseActivity.alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                baseActivity.alert.show();
            }
        }
    }
}
