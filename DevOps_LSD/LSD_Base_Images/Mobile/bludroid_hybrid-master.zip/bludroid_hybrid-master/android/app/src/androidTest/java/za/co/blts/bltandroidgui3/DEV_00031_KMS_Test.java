package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 2/8/2017.
 */
@RunWith(AndroidJUnit4.class)
public class DEV_00031_KMS_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }


    @Test
    public void testKMS() {

        try {
            checks.gotoKMS();
            Log.d(TAG, "Clicked on 'Download KMS'");

            solo.waitForDialogToOpen();

            solo.clickOnText("LATER");
            Log.d(TAG, "Downloading KMS...");
            //kms link not accessible on dev, so cannot do this test

//      checks.gotoKMS();
//      Log.d(TAG, "Clicked on 'Download KMS'");
//
//      solo.waitForDialogToOpen();
//
//      solo.clickOnText("NOW");


        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }


}
