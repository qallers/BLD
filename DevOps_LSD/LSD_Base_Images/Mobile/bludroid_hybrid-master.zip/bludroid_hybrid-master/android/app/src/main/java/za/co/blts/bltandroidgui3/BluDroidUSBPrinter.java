package za.co.blts.bltandroidgui3;

/**
 * Created by NkosanaM on 9/11/2017.
 */

abstract class BluDroidUSBPrinter {

    BluDroidUSBPrinter() {
    }

    public abstract void unregisterReceiver();

    public abstract boolean hasPermission();

    public abstract void print(byte[] bytes);
}
