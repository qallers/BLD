package za.co.blts.bltandroidgui3.cardviews;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewPlaystation extends CardviewDataObject {

    public CardviewPlaystation(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.playstation,
                baseActivity.getResources().getColor(R.color.white),
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(false);
    }

    public String getSupplierCode() {
        return "-1";
    }
}

