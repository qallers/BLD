package za.co.blts.loyalty;

import android.os.RemoteException;

/**
 * Created by MasiS on 8/14/2018.
 */

public interface NFCCardInterface {
    void setDelegate(BluDroidNFCCardAsyncResponse delegate);

    void openReader();

    void closeReader();

    void startListener();

    void stopListener() throws RemoteException;

    String getCardNumber();
}
