package za.co.blts.bltandroidgui3.cardviews;

import android.app.Activity;

import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/16/2017.
 */

public class CardViewBillPayment extends CardviewDataObject {

    public CardViewBillPayment(Activity baseActivity, String cardDesc, String cardValue, int logo, String stockId, String voucherType, String tag, String voucherTypeDesc, String provider) {
        super(cardDesc, cardValue,
                logo,
                baseActivity.getResources().getColor(R.color.white),
                stockId, voucherType, tag, voucherTypeDesc, provider);
    }

    public CardViewBillPayment(String cardDesc, String cardValue, int logo, int color, String stockId, String voucherType, String tag, String voucherTypeDesc, String provider) {
        super(cardDesc, cardValue,
                logo,
                color,
                stockId, voucherType, tag, voucherTypeDesc, provider);
    }
}