package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.util.AttributeSet;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by warrenm on 2016/07/06.
 */
public class BluRecyclerView extends RecyclerView {

    public BluRecyclerView(Context context) {
        super(context);
    }

    public BluRecyclerView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public BluRecyclerView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

}
