package za.co.blts.bltandroidgui3;

/**
 * Created by MasiS on 2018/03/05.
 */

class CarmaPassengerAdult extends CarmaPassenger {
    private String cellNumber = "";
    public boolean infantOnLap = false;

    public CarmaPassengerAdult() {
    }

    public String getCellNumber() {
        return cellNumber;
    }

    public void setCellNumber(String cellNumber) {
        this.cellNumber = cellNumber;
    }

    public boolean isInfantOnLap() {
        return infantOnLap;
    }

    public void setInfantOnLap(boolean infantOnLap) {
        this.infantOnLap = infantOnLap;
    }

    @Override
    public String toString() {
        return "CarmaPassengerAdult{" +
                "cellNumber='" + cellNumber + '\'' +
                ", infantOnLap=" + infantOnLap +
                ", title='" + title + '\'' +
                ", initials='" + initials + '\'' +
                ", lastName='" + lastName + '\'' +
                ", idNumber='" + idNumber + '\'' +
                ", passport=" + passport +
                ", price='" + price + '\'' +
                '}';
    }
}
