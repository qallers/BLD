package za.co.blts.loyalty;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.AsyncTask;
import android.util.Log;

import com.acs.smartcard.Reader;

import java.nio.ByteBuffer;
import java.util.Locale;

/**
 * Created by Michael on 9/19/2018.
 */

public class ExternalNFCCard implements NFCCardInterface {
    private static final String TAG = ExternalNFCCard.class.getName();

    private static BluDroidNFCCardAsyncResponse delegate = null;

    private Context mContext;
    private String cardNumber;

    private UsbManager usbManager;
    private static Reader reader;
    private String deviceName;

    private static final String ACTION_USB_PERMISSION = "za.co.bludroidnfccard.USB_PERMISSION";

    @SuppressWarnings("unused")
    private class PowerParams {
        public int slotNum;
        public int action;
    }

    @SuppressWarnings("unused")
    private static class PowerResult {
        byte[] atr;
        Exception e;
    }


    @SuppressWarnings("unused")
    private class SetProtocolParams {
        public int slotNum;
        public int preferredProtocols;
    }

    @SuppressWarnings("unused")
    private static class SetProtocolResult {
        int activeProtocol;
        Exception e;
    }

    @SuppressWarnings("unused")
    private static class TransmitParams {
        int slotNum;
        int controlCode;
        String commandString;
    }

    @SuppressWarnings({"unused"})
    private static class TransmitProgress {
        int controlCode;
        byte[] command;
        int commandLength;
        byte[] response;
        int responseLength;
        Exception e;
    }

    public ExternalNFCCard(Context c) {
        mContext = c;
        // get service
        usbManager = (UsbManager) c.getSystemService(Context.USB_SERVICE);

        // Initialize reader
        reader = new Reader(usbManager);
    }

    private static byte[] toByteArray(String hexString) {
        int hexStringLength = hexString.length();
        byte[] byteArray;
        int count = 0;
        char c;
        int i;
        // Count number of hex characters
        for (i = 0; i < hexStringLength; i++) {
            c = hexString.charAt(i);
            if (c >= '0' && c <= '9' || c >= 'A' && c <= 'F' || c >= 'a'
                    && c <= 'f') {
                count++;
            }
        }

        byteArray = new byte[(count + 1) / 2];
        boolean first = true;
        int len = 0;
        int value;
        for (i = 0; i < hexStringLength; i++) {
            c = hexString.charAt(i);
            if (c >= '0' && c <= '9') {
                value = c - '0';
            } else if (c >= 'A' && c <= 'F') {
                value = c - 'A' + 10;
            } else if (c >= 'a' && c <= 'f') {
                value = c - 'a' + 10;
            } else {
                value = -1;
            }

            if (value >= 0) {
                if (first) {
                    byteArray[len] = (byte) (value << 4);
                } else {
                    byteArray[len] |= value;
                    len++;
                }
                first = !first;
            }
        }
        return byteArray;
    }

    private static String toHexString(byte[] buffer) {
        String bufferString = "";
        for (byte b : buffer) {
            String hexChar = Integer.toHexString(b & 0xFF);
            if (hexChar.length() == 1) {
                hexChar = "0" + hexChar;
            }
            bufferString += hexChar.toUpperCase() + " ";
        }
        return bufferString;
    }

    @Override
    public void setDelegate(BluDroidNFCCardAsyncResponse delegate) {
        ExternalNFCCard.delegate = delegate;
    }

    @Override
    public void startListener() {
        cardNumber = null;
        reader.setOnStateChangeListener(new Reader.OnStateChangeListener() {

            @Override
            public void onStateChange(int slotNum, int prevState, int currState) {
                if (currState == Reader.CARD_PRESENT) {
                    Log.d(TAG, "card presented");
                    resetCard();
                }
            }
        });
    }

    @Override
    public void stopListener() {
        cardNumber = null;
        reader.setOnStateChangeListener(null);
    }

    @Override
    public void openReader() {
        // Register receiver for USB permission
        PendingIntent permissionIntent = PendingIntent.getBroadcast(mContext, 0, new Intent(ACTION_USB_PERMISSION), 0);
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_USB_PERMISSION);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        mContext.registerReceiver(mReceiver, filter);

        for (UsbDevice device : usbManager.getDeviceList().values()) {
            if (reader.isSupported(device)) {
                deviceName = device.getDeviceName();
                break;
            }
        }

        if (deviceName == null) {
            Log.i(TAG, "Error - no nfc device connected");
        }


        try {
            deviceName = null;
            for (UsbDevice device : usbManager.getDeviceList().values()) {
                if (reader.isSupported(device)) {
                    deviceName = device.getDeviceName();
                    break;
                }
            }
            boolean requested = false;
            if (deviceName != null) {
                // For each device
                for (UsbDevice device : usbManager.getDeviceList().values()) {
                    // If device name is found
                    if (deviceName.equals(device.getDeviceName())) {
                        // Request permission
                        Log.d(TAG, "Requesting USB permission");
                        usbManager.requestPermission(device, permissionIntent);
                        requested = true;
                        break;
                    }
                }
            }

            if (!requested) {
                Log.i(TAG, "Could not find device to open");
                delegate.onError("Could not open NFC Reader");
            }

        } catch (Exception ex) {
            Log.d(TAG, "openReader: " + ex.getMessage());
        }

    }

    @Override
    public void closeReader() {
// Close reader
        try {
            Log.d(TAG, "Closing reader...");
            stopListener();
            mContext.unregisterReceiver(mReceiver);
            new CloseTask().execute();
        } catch (Exception ex) {
            Log.d(TAG, "closeReader: " + ex.getMessage());
        }
    }

    @Override
    public String getCardNumber() {
        return cardNumber;
    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                Log.d(TAG, "USB permission receiver");
                synchronized (this) {
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (device != null) {
                            // Open reader
                            Log.d(TAG, "Opening reader: " + device.getDeviceName() + "...");
                            new OpenTask().execute(device);
                        }
                    } else {
                        Log.d(TAG, "Permission denied for device " + device.getDeviceName());
                        delegate.onError("USB permission denied");
                    }
                }

            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {

                synchronized (this) {
                    // Update reader list
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (device != null && device.equals(reader.getDevice())) {
                        // Close reader
                        Log.d(TAG, "Closing reader...");
                        new CloseTask().execute();
                    }
                }
            }
        }
    };

    private static class OpenTask extends AsyncTask<UsbDevice, Void, Exception> {

        @Override
        protected Exception doInBackground(UsbDevice... params) {
            Exception result = null;
            try {
                reader.open(params[0]);
            } catch (Exception e) {
                result = e;
            }
            return result;
        }

        @Override
        protected void onPostExecute(Exception result) {
            if (result != null) {
                Log.d(TAG, result.toString());
                delegate.onError(result.getLocalizedMessage());
            } else {
                Log.d(TAG, "Reader name: " + reader.getReaderName());
                int numSlots = reader.getNumSlots();
                Log.d(TAG, "Number of slots: " + numSlots);
                delegate.onReady();
            }
        }
    }

    private static class CloseTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            reader.close();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
        }
    }

    private static class PowerTask extends AsyncTask<PowerParams, Void, PowerResult> {

        @Override
        protected PowerResult doInBackground(PowerParams... params) {
            PowerResult result = new PowerResult();
            try {
                result.atr = reader.power(0, Reader.CARD_WARM_RESET);
            } catch (Exception e) {
                result.e = e;
            }
            return result;
        }

        @Override
        protected void onPostExecute(PowerResult result) {
            if (result.e != null) {
                Log.e(TAG, result.e.toString());
                delegate.onError(result.e.getLocalizedMessage());
            } else {
                // Show ATR
                if (result.atr != null) {
                    Log.d(TAG, "ATR:" + toHexString(result.atr));
                    setProtocol();
                } else {
                    Log.d(TAG, "ATR: None");
                }
            }
        }
    }

    private static class SetProtocolTask extends AsyncTask<SetProtocolParams, Void, SetProtocolResult> {

        @Override
        protected SetProtocolResult doInBackground(SetProtocolParams... params) {
            SetProtocolResult result = new SetProtocolResult();
            try {
                result.activeProtocol = reader.setProtocol(0, Reader.PROTOCOL_T0 | Reader.PROTOCOL_T1);
            } catch (Exception e) {
                result.e = e;
            }
            return result;
        }

        @Override
        protected void onPostExecute(SetProtocolResult result) {
            if (result.e != null) {
                Log.e(TAG, result.e.toString());
                delegate.onError(result.e.getLocalizedMessage());
            } else {
                String activeProtocolString = "Active Protocol: ";
                switch (result.activeProtocol) {
                    case Reader.PROTOCOL_T0:
                        activeProtocolString += "T=0";
                        break;
                    case Reader.PROTOCOL_T1:
                        activeProtocolString += "T=1";
                        break;
                    default:
                        activeProtocolString += "Unknown";
                        break;
                }
                // Show active protocol
                Log.d(TAG, activeProtocolString);
                readCardNumber();
            }
        }
    }

    private static class TransmitTask extends AsyncTask<TransmitParams, TransmitProgress, Void> {

        @Override
        protected Void doInBackground(TransmitParams... params) {
            TransmitProgress progress;
            byte[] command;
            byte[] response;
            int responseLength;
            int foundIndex;
            int startIndex = 0;

            do {
                // Find carriage return
                foundIndex = params[0].commandString.indexOf('\n', startIndex);
                if (foundIndex >= 0) {
                    command = toByteArray(params[0].commandString.substring(startIndex, foundIndex));
                } else {
                    command = toByteArray(params[0].commandString.substring(startIndex));
                }

                // Set next start index
                startIndex = foundIndex + 1;
                response = new byte[300];
                progress = new TransmitProgress();
                progress.controlCode = params[0].controlCode;
                try {

                    if (params[0].controlCode < 0) {
                        // Transmit APDU
                        responseLength = reader.transmit(params[0].slotNum, command, command.length, response, response.length);

                    } else {
                        // Transmit control command
                        responseLength = reader.control(params[0].slotNum, params[0].controlCode, command, command.length, response, response.length);
                    }
                    progress.command = command;
                    progress.commandLength = command.length;
                    progress.response = response;
                    progress.responseLength = responseLength;
                    progress.e = null;
                } catch (Exception e) {
                    progress.command = null;
                    progress.commandLength = 0;
                    progress.response = null;
                    progress.responseLength = 0;
                    progress.e = e;
                }
                publishProgress(progress);
            } while (foundIndex >= 0);
            return null;
        }

        @Override
        protected void onProgressUpdate(final TransmitProgress... progress) {
            if (progress[0].e != null) {
                Log.i(TAG, progress[0].e.toString());
                delegate.onError(progress[0].e.getLocalizedMessage());
            } else {
                Log.d(TAG, "Command: " + toHexString(progress[0].command));
                Log.d(TAG, "Response: " + toHexString(progress[0].response));

                byte[] cardUid = new byte[8];  //long is 8 bytes in length
                System.arraycopy(progress[0].response, 0, cardUid, 4, 4);  //copy unsigned int (4 bytes) into lower half of long
                ByteBuffer wrapped = ByteBuffer.wrap(cardUid); // big-endian by default
                //format the card uid as a 10 digit string
                String cardString = String.format(Locale.US, "%010d", wrapped.getLong());

                Log.i(TAG, "UID: " + cardString);
                delegate.onCardNumberRead(cardString);

                // startListener();
            }
        }
    }

    private void resetCard() {
        Log.d(TAG, "Slot 0: Warm Reset...");
        new PowerTask().execute();
    }

    private static void setProtocol() {
        // Set protocol
        Log.d(TAG, "Slot 0: Setting protocol to T0/T1...");
        new SetProtocolTask().execute();
    }

    private static void readCardNumber() {
        Log.d(TAG, "Slot 0: Get Card UID...");
        // Get slot number
        int slotNum = 0;

        // Set parameters
        TransmitParams params = new TransmitParams();
        params.slotNum = slotNum;
        params.controlCode = -1;
        params.commandString = "FFCA000000";
        // Transmit APDU
        Log.d(TAG, "Slot " + slotNum + ": Transmitting APDU...");
        new TransmitTask().execute(params);
    }


}