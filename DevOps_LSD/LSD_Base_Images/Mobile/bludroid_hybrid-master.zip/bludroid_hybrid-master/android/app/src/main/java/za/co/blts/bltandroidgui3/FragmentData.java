package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by warrenm on 2016/10/03.
 */

public class FragmentData extends TabbedRecycler {

    private final String TAG = this.getClass().getSimpleName();

    //private int[] pinlessTitles = {R.string.printVoucher, R.string.pinlessBundles};

    public FragmentData() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_data, container, false);
        tabs = rootView.findViewById(R.id.tabLayout);
        pinlessPrintTabLayout = rootView.findViewById(R.id.pinlessprintLayout);
        recycler = rootView.findViewById(R.id.bluRecycler);

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        String title = getActivity().getResources().getString(R.string.data);
        getActivity().setTitle(title);
        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();

        if (BaseActivity.voucherListResponseMessage != null) {
            populateScreen();
        }

    }

    public void populateScreen() {
        setupTabs(this, tabs);

        String type = "Data";
        setupRecycler(type);
        adapter.setFilter(tabs.getTabAt(0).getText().toString());
        tabs.getTabAt(0).select();

    }

    @Override
    public boolean onBackPressed() {

        getBaseActivity().gotoMainScreen();

        return true;
    }
}