package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import java.util.ArrayList;

import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 4/5/2017.
 */

class BluDroidRicaSerialListAdapter extends ArrayAdapter<String> {
    private final String TAG = this.getClass().getSimpleName();
    private ArrayList<String> dataSet;
    private int layoutResourceId;

    public BluDroidRicaSerialListAdapter(BaseActivity context, int layoutResourceId, ArrayList<String> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.layoutResourceId = layoutResourceId;
        this.dataSet = dataSet;
        //  private BluDroidUser user;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {


        String sim = getItem(position);

        String[] simParts = sim.split(",");

        String provider = simParts[0];
        String serial = simParts[1];

        if (convertView == null) {

            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(layoutResourceId, parent, false);
        }

        BluDroidTextView textView = convertView.findViewById(R.id.txtSerial);
        BluDroidTextView textProvider = convertView.findViewById(R.id.txtProvider);
        ImageView removeSerial = convertView.findViewById(R.id.removeSerial);

        if (textView != null) {

            textView.setText(serial);
            textProvider.setText(provider);

            String tag = String.valueOf(position).trim();
            textView.setTag(Integer.parseInt(tag));

        }

        removeSerial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Remove Rica serial");
                dataSet.remove(position);
                notifyDataSetChanged();
            }
        });

        // Return the completed view to render on screen
        return convertView;
    }

}
