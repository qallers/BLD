package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.os.Build;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;
import java.security.cert.X509Certificate;
import java.util.zip.GZIPInputStream;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DOWNLOAD_DECLINE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_INSTALL_DECLINE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_UPDATE_DATE;

//
// required for accepting unsigned certificates
//


class HTTPUtils {

    private final String TAG = this.getClass().getSimpleName();
    private HttpURLConnection httpURLConnection = null;

    private boolean isDebug;

    public HTTPUtils(boolean isDebug) {
        this.isDebug = isDebug;
        Log.v(TAG, "isDebug is " + isDebug);
    }

    private void setUpSSLForSelfSignedCertificates(HttpURLConnection connection) {
        try {
            TrustManager[] trustSelfSigned = new TrustManager[]{
                    new X509TrustManager() {
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }

                        @Override
                        public void checkClientTrusted(X509Certificate[] certs,
                                                       String authType) {
                            for (int i = 0; i < certs.length; i++) {
                                Log.v(TAG, "1-i=" + i);
                                Log.v(TAG, "1-Cert Hash Code : " + certs[i].hashCode());
                                Log.v(TAG, "1-name " + certs[i].getSubjectX500Principal().getName());
                                Log.v(TAG, "1-issuer " + certs[i].getIssuerX500Principal().getName());
                            }

                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] certs,
                                                       String authType) {
                            Log.v(TAG, "we have " + certs.length + " certs");
                            for (int i = 0; i < certs.length; i++) {
                                Log.v(TAG, "2-i=" + i);
                                Log.v(TAG, "2-Cert Hash Code : " + certs[i].hashCode());
                                Log.v(TAG, "2-name " + certs[i].getSubjectX500Principal().getName());
                                Log.v(TAG, "2-issuer " + certs[i].getIssuerX500Principal().getName());
                            }
                        }
                    }


            };
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustSelfSigned, new java.security.SecureRandom());
            if (connection instanceof HttpsURLConnection) {
                try {
                    HttpsURLConnection httpsURLConnection = (HttpsURLConnection) connection;

                    httpsURLConnection.setHostnameVerifier(new HostnameVerifier() {
                                                               @SuppressLint("BadHostnameVerifier")
                                                               @Override
                                                               public boolean verify(String hostname, SSLSession session) {
                                                                   Log.v(TAG, "2-Approving certificate for " + hostname);
                                                                   return true;
                                                               }
                                                           }
                    );

                    httpsURLConnection.setSSLSocketFactory(sc.getSocketFactory());
                } catch (Exception exception) {
                    Log.d(TAG, "problems setting SSLSocketFactory " + exception);
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "SSL exceptoin " + exception);
        }
    }


    private byte[] readPayload(HttpURLConnection httpURLConnection) throws Exception {

        httpURLConnection.setConnectTimeout(5000);
//      Advertise that we can now accept gzipped payloads - does not matter if this can't be set
        try {
            httpURLConnection.setRequestProperty("Accept-Encoding", "gzip");
        } catch (Exception ignored) {
        }
        Log.v(TAG, "response code: " + httpURLConnection.getResponseCode());
        Log.v(TAG, "content type: " + httpURLConnection.getContentType());
        Log.v(TAG, "contentLength: " + httpURLConnection.getContentLength());
        Log.v(TAG, "contentLength via header: " + httpURLConnection.getHeaderField("content-length"));
        Log.v(TAG, "content encoding: " + httpURLConnection.getContentEncoding());
        Log.v(TAG, "Location via header: " + httpURLConnection.getHeaderField("Location"));
        try {
            if (httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                InputStream is;
                if ("gzip".equals(httpURLConnection.getContentEncoding())) {
                    // If we have a gzip'ed payload we need to decompress it
                    is = new BufferedInputStream(new GZIPInputStream(httpURLConnection.getInputStream()));
                } else {
                    is = new BufferedInputStream(httpURLConnection.getInputStream());
                }
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buffer = new byte[102400];   // 100KB
                int count;
                while ((count = is.read(buffer)) > 0) {
                    bos.write(buffer, 0, count);
                    Log.d(TAG, "HTTP GET byte count: " + count + " total: " + bos.size() + " encoding: " + httpURLConnection.getContentEncoding());
                }
                BaseActivity.logger.info("HTTP GET complete. total: " + bos.size() + " encoding: " + httpURLConnection.getContentEncoding());
                bos.close();
                return bos.toByteArray();
            }
            //
            // added by LB
            //
            else {
                BaseActivity.logger.error("did not receive HTTP OK");
//                throw new Exception("did not receive HTTP OK");
                return new byte[0];
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        }
    }

    byte[] getData(String urlString, BaseActivity baseActivity) throws Exception { // UnknownHostException {
        if (!urlString.startsWith("http")) {
            urlString = "http://" + urlString;
        }
        try {
            URL url = new URL(urlString);
            URLConnection urlConnection = url.openConnection();

            String userAgent = "devId=" + baseActivity.getPreference(PREF_DEVICE_ID)
                    + ";version=" + baseActivity.getVersionName()
//                    + ";version=" + baseActivity.getString(R.string.version)
                    + ";android=" + Build.VERSION.SDK_INT
                    + ";model=" + Build.MODEL
                    + ";theme=" + baseActivity.getPreference(PREF_SKIN)
                    + ";decl=" + baseActivity.getDeclineCount(PREF_DOWNLOAD_DECLINE) + "/" + baseActivity.getDeclineCount(PREF_INSTALL_DECLINE)
                    + ";updt=" + baseActivity.getPreference(PREF_UPDATE_DATE);
            urlConnection.setRequestProperty("User-Agent", userAgent);

            Log.v(TAG, "urlConnection is " + urlConnection);
            Log.v("DECLINE", "userAgent is " + userAgent);

            //
            // if it is an HttpURL Connection
            //
            if (urlConnection instanceof HttpURLConnection) {
                //HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;
                httpURLConnection = (HttpURLConnection) urlConnection;
                Log.d(TAG, "host is " + httpURLConnection.getURL().getHost());
                Log.d(TAG, "protocol is " + httpURLConnection.getURL().getProtocol());
                if (isDebug || (httpURLConnection.getURL().getHost().equals("10.22.7.23") &&
                        httpURLConnection.getURL().getProtocol().equals("https"))) {
                    Log.d(TAG, "setting up for ssl for self signed certificates");
                    setUpSSLForSelfSignedCertificates(httpURLConnection);
                }
                Log.v(TAG, "reading payload");
                byte[] data = readPayload(httpURLConnection);
                Log.v(TAG, "read payload");
                return data;
            }
            //
            // or just a urlConnection
            //
            else {
                return null;
            }

        } catch (UnknownHostException uhe) {
            Log.e(TAG, "3-Networking Exception " + uhe);
            throw uhe;
        } catch (Exception t) {
            Log.e(TAG, "getData throwing " + t);
            throw t;
        }

    }

    private String putData(String urlString, byte[] payload, int connectTimeout, int readTimeout) throws UnknownHostException {
        Log.v(TAG, "putData urlString is " + urlString);

        if (payload == null)
            Log.v(TAG, "payload is null");
        else
            Log.v(TAG, "payload is " + payload.length + " bytes");
        if (!urlString.matches("^https?.*")) {
            urlString = "http://" + urlString;
        }
        try {
            URL url;
            OutputStream outputStream;
            URLConnection urlConnection;

            url = new URL(urlString);

            urlConnection = url.openConnection();

            if (urlConnection instanceof HttpURLConnection) {
                //HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;
                httpURLConnection = (HttpURLConnection) urlConnection;
                httpURLConnection.setRequestMethod("PUT");
                httpURLConnection.setConnectTimeout(connectTimeout);
                httpURLConnection.setReadTimeout(readTimeout);
                //
                // this was added by thomas request
                //
                httpURLConnection.setRequestProperty("Content-Type", "application/json");
                outputStream = new BufferedOutputStream(urlConnection.getOutputStream());
                outputStream.write(payload);
                outputStream.flush();
                byte[] data = readPayload(httpURLConnection);
                String st = new String(data);
                Log.v(TAG, "data: " + st);
                //String st = readPayload(httpURLConnection);
                return Integer.toString(((HttpURLConnection) urlConnection).getResponseCode());
            } else {
                return "putpage only support HTTPURLConnections";
            }
        } catch (UnknownHostException uhe) {
            Log.e(TAG, "5-Networking Exception " + uhe);
            throw uhe;
        } catch (Exception t) {
            Log.e(TAG, "problem getting webaddress " + t);
            return "putPage throwing " + t;
        }
    }

    public String putData(String urlString, byte[] payload) throws UnknownHostException {
        return putData(urlString, payload, 3000, 3000);
    }

    public void disconnect() {
        Log.v(TAG, "trying to break http connection " + httpURLConnection);
        if (httpURLConnection != null) {
            httpURLConnection.disconnect();
        }
    }

}
