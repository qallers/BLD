package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;

/**
 * Created by BoitshokoM on 1/5/2018.
 */

@RunWith(AndroidJUnit4.class)
public class DEV_00902_BSSID_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        checks.setWifi(true); //if test fails, ensure wifi back on for next test
        tearDown();
    }

    @Test
    public void testLocationServices() {
        try {

            checks.setWifi(true);
            Log.d(TAG, "1 Turned on wifi");


            checks.login("011234");
            Log.d(TAG, "Logging in");


            if (solo.waitForLogMessage("bssid=f0:5c:19:93:0e:c3")) {
                //solo.wait(30000);
                Log.d(TAG, "2 Got log");
            } else
                fail("No log");


            if (solo.waitForLogMessage("bssid")) {
                //solo.wait(30000);
                Log.d(TAG, "3 Got log");
            } else
                fail("No log");

//      solo.clearLog();
//      solo.sleep(500);
            checks.setWifi(false);
            Log.d(TAG, "4 Turned off wifi");
//      //is this clearLog and wait breaking the test purpose?
//      solo.clearLog();
            solo.sleep(3000);


//      if(solo.waitForLogMessage("bssid=f0:5c:19:93:0e:c3")) {
//        //solo.wait(30000);
//        fail( "Got log");
//      }
//      else
//        Log.d(TAG,"5 No log");

            checks.setWifi(true);
            Log.d(TAG, "6 Turned on wifi");


            if (solo.waitForLogMessage("BSSID")) {
                //solo.wait(30000);
                Log.d(TAG, "7 Got log");
            } else
                fail("No log");


        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }

    }


}


