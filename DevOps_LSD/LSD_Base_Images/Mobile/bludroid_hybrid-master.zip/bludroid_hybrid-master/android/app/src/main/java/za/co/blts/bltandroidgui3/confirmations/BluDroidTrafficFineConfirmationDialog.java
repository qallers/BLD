package za.co.blts.bltandroidgui3.confirmations;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidMoneyEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 3/23/2017.
 */

public class BluDroidTrafficFineConfirmationDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, View.OnClickListener {
    private final String TAG = this.getClass().getSimpleName();
    private String supplierCode;

    private BluDroidRelativeLayout layout;

    public void setup() {
        super.setup();
        // setIcon(baseActivity.getResources().getDrawable(R.drawable.eskom_confirm));
        hideView(R.id.neutralButton);
        setAffirmativeButtonLabel(R.string.print);
        setNegativeButtonLabel(R.string.cancel);
        setHeading(R.string.confirm_purchase);
        setClickListeners();
        layout = findViewById(R.id.layout);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }


    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }

    private void setClickListeners() {
        BluDroidButton cashButton = findViewById(R.id.cashButton);
        BluDroidButton debitButton = findViewById(R.id.debitCardButton);
        BluDroidButton creditButton = findViewById(R.id.creditCardButton);

        cashButton.setOnClickListener(this);
        debitButton.setOnClickListener(this);
        creditButton.setOnClickListener(this);
    }

    public String getSupplierCode() {
        return supplierCode;
    }


    public BluDroidTrafficFineConfirmationDialog(BaseActivity context) {
        super(context, R.layout.confirmation_traffic_fine);
        setup();
        String TAG = this.getClass().getSimpleName();
        Log.d(TAG, "Purchase confirmation with activity");
        BaseActivity.logger.info(": construction with BaseActivity");
    }

    public void setNoticeNumber(String noticeNumber) {
        BluDroidTextView noticeNumberTextView = findViewById(R.id.noticeNumber);
        if (noticeNumberTextView != null) {
            noticeNumberTextView.setText(noticeNumber);
        }
    }

    public void setVehicleRegNumber(String vehicleReg) {
        BluDroidTextView vehicleRegTextView = findViewById(R.id.vehicleReg);
        if (vehicleRegTextView != null) {
            vehicleRegTextView.setText(vehicleReg);
        }
    }

    public void setOnwerId(String onwerId) {
        BluDroidTextView onwerIdTextView = findViewById(R.id.ownerId);
        if (onwerIdTextView != null) {
            onwerIdTextView.setText(onwerId);
        }
    }

    public void setlocation(String location) {
        BluDroidTextView locationTextView = findViewById(R.id.location);
        if (locationTextView != null) {
            locationTextView.setText(location);
        }
    }

    public void setDate(String date) {
        BluDroidTextView dateTextView = findViewById(R.id.date);
        if (dateTextView != null) {
            dateTextView.setText(date);
        }
    }

    public void setAmountDue(String amountDue) {
        BluDroidTextView amountTextView = findViewById(R.id.amountDue);
        if (amountTextView != null) {
            amountTextView.setText(amountDue);
        }
    }

    public void setConvienceFee(String convienceFee) {
        BluDroidTextView amountTextView = findViewById(R.id.convenience);
        if (amountTextView != null) {
            amountTextView.setText(convienceFee);
        }
    }

    public void setTotalPayable(String payable) {
        BluDroidTextView amountTextView = findViewById(R.id.total);
        if (amountTextView != null) {
            amountTextView.setText(payable);
        }
    }

    public void setpartPayment(String partPayment) {
        BluDroidTextView amountTextView = findViewById(R.id.partPayment);
        if (amountTextView != null) {
            amountTextView.setText(partPayment);
        }
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.blubillLogo);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    private String getAmount() {
        BluDroidTextView amountTextView = findViewById(R.id.amountDue);

        String amount = "";
        if (amountTextView != null) {
            amount = amountTextView.getText().toString();
        }

        return amount;
    }

    public void setAmount(String amount) {
        BluDroidMoneyEditText amountEditText = findViewById(R.id.amountDue);
        if (amountEditText != null) {
            amountEditText.setText(amount);
            amountEditText.setEnabled(false);
        }
    }


    @Override
    public void onClick(View view) {
        BaseActivity.logger.info(((BluDroidButton) view).getText());

        if (layout.validate()) {


            double amount = Double.parseDouble(getAmount());

            //this is the amount to be displayed as payable on the confirm payment dialog
            final Double total = amount + baseActivity.bpConvienceFee;

            if (view.getId() == R.id.cashButton) {

                baseActivity.createBillPaymentsAlertDialog("Confirm Traffic Fine Payment", "Amount Due R" + baseActivity.df2.format(total));

                baseActivity.alert.setPositiveOption("Continue", new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        if (baseActivity.possibleTitle.toLowerCase().contains("pay@")) {

                            baseActivity.payPayAtAccount(getAmount(), "cash");
                        } else if (baseActivity.possibleTitle.toLowerCase().contains("syntell")) {

                            baseActivity.paySyntellAccount(getAmount(), "cash");
                        }
                        //this is the amount used for tender
                        baseActivity.amount = total.toString();
                    }
                });
                baseActivity.alert.show();


            } else if (view.getId() == R.id.debitCardButton) {

                baseActivity.createBillPaymentsAlertDialog("Confirm Traffic Fine Payment", "Amount Due R" + baseActivity.df2.format(total));

                baseActivity.alert.setPositiveOption("Continue", new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        if (baseActivity.possibleTitle.toLowerCase().contains("pay@")) {

                            baseActivity.payPayAtAccount(getAmount(), "debitCard");
                        } else if (baseActivity.possibleTitle.toLowerCase().contains("syntell")) {

                            baseActivity.paySyntellAccount(getAmount(), "debitCard");
                        }
                        //this is the amount used for tender
                        baseActivity.amount = total.toString();
                    }
                });
                baseActivity.alert.show();


            } else if (view.getId() == R.id.creditCardButton) {

                baseActivity.createBillPaymentsAlertDialog("Confirm Traffic Fine Payment", "Amount Due R" + baseActivity.df2.format(total));

                baseActivity.alert.setPositiveOption("Continue", new OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        if (baseActivity.possibleTitle.toLowerCase().contains("pay@")) {

                            baseActivity.payPayAtAccount(getAmount(), "creditCard");
                        } else if (baseActivity.possibleTitle.toLowerCase().contains("syntell")) {

                            baseActivity.paySyntellAccount(getAmount(), "creditCard");
                        }
                        //this is the amount used for tender
                        baseActivity.amount = total.toString();
                    }
                });
                baseActivity.alert.show();

            }

            dismiss();
        }
    }

}
