package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.KeyEvent;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by warrenm
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00230_BillPayment_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_Menu() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            checks.selectBillPaymentType("Traffic Fines");

            Log.d(TAG, "Select traffic fines tab");

            checks.selectBillPaymentType("Accounts");

            Log.d(TAG, "Select accounts tab");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_Sapo() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            checks.selectBillPaymentType("Accounts");

            Log.d(TAG, "Select accounts tab");

            checks.enterText(R.id.search, "Albert");

            solo.clickOnText("Albert Luthli Municipality");

            Log.d(TAG, "Albert Luthuli municipality selected");

            checks.enterText(R.id.accountNumber, "01234567");

            Log.d(TAG, "Account number entered");

            checks.enterText(R.id.amount, "25");

            Log.d(TAG, "Amount entered");

            checks.clickButton(R.id.cashButton);

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm cash payment dialog");
            } else {
                fail("Can't open confirm payment dialog");
            }

            solo.clickOnText("Cancel");

            Log.d(TAG, "Cancel cash payment");

            solo.waitForDialogToClose();

            checks.clickButton(R.id.creditCardButton);

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm credit card payment dialog");
            } else {
                fail("Can't open confirm payment dialog");
            }

            solo.clickOnText("Cancel");

            Log.d(TAG, "Cancel credit card payment");

            solo.waitForDialogToClose();

            checks.clickButton(R.id.debitCardButton);

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm debit card payment dialog");
            } else {
                fail("Can't open confirm payment dialog");
            }

            solo.clearLog();
            solo.clickOnButton(1);

            Log.d(TAG, "Pay account");

            if (solo.searchText("Provider Application offline")) {
                fail("SAPO is offline");
            }

            solo.waitForLogMessage("TenderResponseMessage");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T020_Syntell() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            checks.selectBillPaymentType("Accounts");
            Log.d(TAG, "Select accounts tab");

            checks.enterText(R.id.search, "Cape Town");
            Log.d(TAG, "Search City of Cape Town");

            if (solo.searchText("City of Cape Town")) {
                Log.d(TAG, "City of Cape Town card found");
            } else {
                fail("City of Cape Town card not found");
            }

            solo.clickOnText("City of Cape Town");
            Log.d(TAG, "City of Cape Town selected");

            checks.enterText(R.id.accountNumber, "206129962");
            Log.d(TAG, "Account number entered.");

            checks.clickButton(R.id.showDetailsButton);
            Log.d(TAG, "Show details button clicked");

            solo.waitForDialogToOpen();

            if (solo.searchText("Provider error")) {
                fail("AEON provider error");
            } else {
                checks.enterText(R.id.amount, "20");
                Log.d(TAG, "Amount entered.");

                solo.clearLog();
                solo.clickOnButton(0);
                Log.d(TAG, "Cash payment selected");

                solo.waitForLogMessage("TenderResponseMessage");
                Log.d(TAG, "Payment Confirmed");
            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T030_PayAt() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            checks.selectBillPaymentType("Accounts");

            Log.d(TAG, "Select accounts tab");

            checks.enterText(R.id.search, "Multichoice");

            solo.clickOnText("Multichoice/DSTV");

            Log.d(TAG, "Select Multichoice/DSTV");

            checks.enterText(R.id.accountNumber, "12280246");

            Log.d(TAG, "Account number entered");

            checks.clickButton(R.id.showDetailsButton);
            Log.d(TAG, "Show details button clicked");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Customer Details Dialog open");
            } else {
                fail("Can't open Customer Details Dialog");
            }

            checks.enterText(R.id.amount, "25");
            Log.d(TAG, "Amount entered");

            solo.scrollToBottom();

            checks.clickButton(R.id.cashButton);
            Log.d(TAG, "Cash Payment confirmed");

            solo.clearLog();
            solo.clickOnText("Continue");
            Log.d(TAG, "Clicked 'CONTINUE'");

            solo.waitForDialogToClose();

//      if (solo.waitForText("Paying account")) {
//        Log.d(TAG, "Voucher purchase confirmation dismissed");
//      } else {
//        fail("Voucher purchase confirmation NOT dismissed");
//      }

            solo.sendKey(KeyEvent.KEYCODE_BACK);
            Log.d(TAG, "back button disabled");

            solo.waitForLogMessage("TenderResponseMessage");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T040_BluBill() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            checks.selectBillPaymentType("Accounts");

            Log.d(TAG, "Select accounts tab");

            searchText("DST", "DSTV");
//      solo.goBack();
//
//      scrollToText("DSTV");
//
//      Log.d(TAG, "Select DSTV");

            //test  for account
            enterAccountNumber("98921670");

            Log.d(TAG, "Account number entered");

            checks.clickButton(R.id.showDetailsButton);
            Log.d(TAG, "Show details button clicked");

            if (solo.waitForText("Verifying account")) {
                Log.d(TAG, "Verifying account");
                if (solo.waitForDialogToClose(60000)) {
                    Log.d(TAG, "dialog closed");
                }
            }

            Log.d(TAG, "search for error");
            if (solo.searchText("Error")) {
                fail("Aeon returned an error");
            } else if (solo.searchText("Timeout")) {
                fail("Aeon timed out");
            }

            solo.scrollToBottom();

            checks.enterText(R.id.amount, "25");
            Log.d(TAG, "Amount entered");


            checks.clickButton(R.id.cashButton);
            Log.d(TAG, "Cash Payment confirmed");

            solo.clearLog();
            solo.clickOnText("Continue");
            Log.d(TAG, "Clicked 'CONTINUE'");

            if (solo.waitForText("Paying account")) {
                Log.d(TAG, "Voucher purchase confirmation dismissed");
            } else {
                fail("Voucher purchase confirmation NOT dismissed");
            }

            solo.sendKey(KeyEvent.KEYCODE_BACK);
            Log.d(TAG, "back button disabled");

            solo.waitForLogMessage("TenderResponseMessage");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T050_TrafficFinePayAT() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            checks.selectBillPaymentType("Traffic Fines");
            Log.d(TAG, "Traffic Fines tab");

            checks.enterText(R.id.search_fine, "TMT");

            solo.clickOnText("TMT Traffic Fines");

            Log.d(TAG, "Select TMT Traffic Fines");

            checks.enterText(R.id.accountNumber, "6999971048200059");

            Log.d(TAG, "Notice number entered");

            checks.clickButton(R.id.showDetailsButton);
            Log.d(TAG, "Show details button clicked");


            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Customer Details Dialog open");
            } else {
                fail("Can't open Customer Details Dialog");
            }

            if (solo.searchText("Not a valid Notice Number")) {
                //a fine can only be paid once, thereafter we receive this error message
                Log.d(TAG, "Not a valid Notice Number");
            } else {
                solo.scrollToBottom();
                solo.clearLog();
                checks.clickButton(R.id.cashButton);
                Log.d(TAG, "Cash Payment confirmed");
                solo.waitForLogMessage("TenderResponseMessage");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T060_MerchantTransfer() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            checks.selectBillPaymentType("Accounts");

            Log.d(TAG, "Select accounts tab");

            checks.enterText(R.id.search, "Merchant To Merchant");

            solo.clickOnText("Merchant To Merchant Transfer");

            Log.d(TAG, "Select Merchant To Merchant Transfer");

            checks.enterText(R.id.accountNumber, "eee122643");

            Log.d(TAG, "Account number entered");

            checks.enterText(R.id.amount, "200");
            Log.d(TAG, "Amount entered");

            checks.clickButton(R.id.showDetailsButton);
            Log.d(TAG, "Show details button clicked");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Customer Details Dialog open");
            } else {
                fail("Can't open Customer Details Dialog");
            }

            solo.scrollToBottom();

            solo.clearLog();
            checks.clickButton(R.id.cashButton);
            Log.d(TAG, "Cash Payment confirmed");

            if (solo.waitForText("Confirming Transfer")) {
                Log.d(TAG, "Voucher purchase confirmation dismissed");
            } else {
                fail("Voucher purchase confirmation NOT dismissed");
            }

//      solo.sendKey(KeyEvent.KEYCODE_BACK);
//      Log.d(TAG, "back button disabled");

            solo.waitForLogMessage("TenderResponseMessage");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T070_BluBill_Mukuru() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            billPaymentAccounts();
            Log.d(TAG, "Select accounts tab");

            //Selecting Mukuru using the search option
            searchText("Muk", "Mukuru");
            Log.d(TAG, "Selected 'Mukuru' using the search option");

            //Test for an invalid account number
            enterAccountNumber("1234567890");
            Log.d(TAG, "Account number entered");

            showDetailsButton();
            Log.d(TAG, "Show details button clicked");

            if (solo.waitForText("Verifying account")) {
                Log.d(TAG, "Verifying account");
                if (solo.waitForDialogToClose(60000)) {
                    Log.d(TAG, "dialog closed");
                }
            }

            if (solo.searchText("FAILED: ORDER_ID_INVALID")) {
                Log.d(TAG, "Invalid account number entered");
                solo.clickOnButton("OK");
            } else {
                fail("Unexpected response from AEON");
            }

            //Test for an valid account number
            enterAccountNumber("7306206");
            Log.d(TAG, "Account number entered");

            showDetailsButton();
            Log.d(TAG, "Show details button clicked");

            if (solo.waitForDialogToOpen() && !solo.searchText("FAILED: ORDER_ALREADY_PAID")) {
                Log.d(TAG, "Customer Details Dialog open");
            } else {
                fail("Account already paid");
            }

            checks.enterText(R.id.amount, "20");
            Log.d(TAG, "lower amount entered");

            solo.scrollToBottom();

            checks.clickButton(R.id.cashButton);
            Log.d(TAG, "Cash Payment confirmed");

            solo.waitForDialogToOpen();
            Log.d(TAG, "Payment confirmation appeared dialogue box appeared");

            solo.clickOnText("Continue");
            Log.d(TAG, "Clicked on continue");

            solo.waitForDialogToOpen();
            Log.d(TAG, "'Full amount must be' dialogue box appeared");

            solo.clickOnText("OK");
            Log.d(TAG, "'OK' button clicked");

            paymentConfirmation("7306206");

            checks.enterText(R.id.amount, "500");
            Log.d(TAG, "Higher amount entered");

            solo.scrollToBottom();

            checks.clickButton(R.id.cashButton);
            Log.d(TAG, "Cash Payment confirmed");

            solo.waitForDialogToOpen();
            Log.d(TAG, "Payment confirmation appeared dialogue box appeared");

            solo.clickOnText("Continue");
            Log.d(TAG, "Clicked on continue");

            solo.waitForDialogToOpen();
            Log.d(TAG, "'Full amount must be' dialogue box appeared");

            solo.clickOnText("OK");
            Log.d(TAG, "'OK' button clicked");

            paymentConfirmation("7306206");

            checks.enterText(R.id.amount, "431");
            Log.d(TAG, "Exact amount owed entered");

            solo.scrollToBottom();

            checks.clickButton(R.id.creditCardButton);
            Log.d(TAG, "Credit Card button clicked");

            solo.waitForDialogToOpen();
            Log.d(TAG, "Payment confirmation appeared dialogue box appeared");

            solo.clickOnText("Cancel");
            Log.d(TAG, "Clicked cancel");

            checks.clickButton(R.id.debitCardButton);
            Log.d(TAG, "Debit Card button clicked");

            solo.waitForDialogToOpen();
            Log.d(TAG, "Payment confirmation appeared dialogue box appeared");

            solo.clickOnText("Cancel");
            Log.d(TAG, "Clicked cancel");

            checks.clickButton(R.id.cashButton);
            Log.d(TAG, "Cash Payment confirmed");

            solo.waitForDialogToOpen();
            Log.d(TAG, "Payment confirmation appeared dialogue box appeared");

            solo.clickOnText("Continue");
            Log.d(TAG, "Clicked on continue");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    private void paymentConfirmation(String accountNumber) {

        enterAccountNumber(accountNumber);
        Log.d(TAG, "Account number entered");

        showDetailsButton();
        Log.d(TAG, "Show details button clicked");

        if (solo.waitForDialogToOpen()) {
            Log.d(TAG, "Customer Details Dialog open");
        } else {
            fail("Can't open Customer Details Dialog");
        }
    }
}
