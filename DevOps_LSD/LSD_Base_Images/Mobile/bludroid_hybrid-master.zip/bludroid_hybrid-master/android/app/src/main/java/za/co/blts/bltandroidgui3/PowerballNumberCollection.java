package za.co.blts.bltandroidgui3;

/**
 * Created by warrenm on 2016/03/24.
 */
public class PowerballNumberCollection extends LottoNumberCollection {

    private int powerball;

    public int getPowerball() {
        return powerball;
    }

    public void setPowerball(int powerBall) {
        this.powerball = powerBall;
    }

    @Override
    public boolean isComplete() {
        return getNumbers().size() == 5 && powerball > 0;
    }

    @Override
    public String toString() {
        return super.toString() + "," + powerball;
    }
}
