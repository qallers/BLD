package za.co.blts.bltandroidgui3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.List;

class CarmaFilterListAdapter extends ArrayAdapter<String> {


    private WeakReference<BaseActivity> baseActivityWeakReference;

    public CarmaFilterListAdapter(BaseActivity context, int resource, List<String> dataset) {
        super(context, resource, dataset);
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listView = convertView;
        if (listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(R.layout.spinner_item_carrier, parent, false);
        }

        String filterName = getItem(position);

        TextView textCarrierName = listView.findViewById(R.id.text);
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            textCarrierName.setTextColor(baseActivity.getSkinResources().getButtonTextColor());
        }
        textCarrierName.setText(filterName);
        return listView;
    }


    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        View listView = convertView;
        if (listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_spinner_dropdown_item, parent, false);
        }

        String carrierItem = getItem(position);

        TextView textCarrierName = listView.findViewById(android.R.id.text1);

        textCarrierName.setText(carrierItem);
        return listView;
    }
}
