package za.co.blts.callme;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONObject;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

public class BluMerchantSupportResponse extends BaseActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant_response);

        Intent intent = getIntent();
        String callMeData = intent.getStringExtra("msg");

        ImageView callme = findViewById(R.id.callme);
        Drawable image = getResources().getDrawable(R.drawable.callme);
        callme.setImageDrawable(image);
        Drawable roundDrawable = getResources().getDrawable(R.drawable.button_bg_shadow_rounded);
        roundDrawable.setColorFilter(getSkinResources().getButtonColor(), PorterDuff.Mode.MULTIPLY);
        callme.setBackground(roundDrawable);

        BluDroidTextView callMeResponseMsg = findViewById(R.id.callMeMsg);

        findViewById(R.id.helpMeOkBtn).setOnClickListener(this);

        try {
            JSONObject obj = new JSONObject(callMeData);
            Log.d("CallMe", "valid callmedata1: " + callMeData);
            String msgToDisplay = obj.getString("message");

            if (msgToDisplay == null || msgToDisplay.isEmpty()) {
                logger.error("CallMe: invalid callmedata1: " + callMeData);
                Toast.makeText(this, "Invalid response", Toast.LENGTH_SHORT).show();
                gotoLandingScreen();
            } else {
                callMeResponseMsg.setText(msgToDisplay);
            }
        } catch (Exception e) {
            logger.error("CallMe: invalid callmedata1: " + callMeData);
            e.printStackTrace();
            Toast.makeText(this, "Invalid response", Toast.LENGTH_SHORT).show();
            gotoLandingScreen();
        }
    }

    public void onClick(View view) {
        gotoLandingScreen();
    }

    @Override
    public void onBackPressed() {
        gotoLandingScreen();
    }
}
