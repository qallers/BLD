package za.co.blts.bltandroidgui3;

/**
 * Created by NkosanaM on 9/12/2017.
 */

interface BluDroidScanListener {

    void setBarcode(String barcode);
}
