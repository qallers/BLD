package za.co.blts.bltandroidgui3.cardviews;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewVirgin extends CardviewDataObject {

    private WeakReference<BaseActivity> baseActivityWeakReference;

    public CardviewVirgin(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.virgin,
                baseActivity.getResources().getColor(R.color.white),
                stockId, voucherType, tag);
        super.setHasAirtimePlus(hasAirtimePlus);

        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    public CardviewVirgin(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.virgin,
                baseActivity.getResources().getColor(R.color.white),
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(hasAirtimePlus);

        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    public String getSupplierCode() {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            return baseActivity.virginMobileSupplierCode;
        }
        return null;
    }

    public String getTopupName() {
        return "VirginMobile";
    }

}

