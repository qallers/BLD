package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseProductMessage;
import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponseSupplierMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseManufacturerMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseProductMessage;
import za.co.blts.bltandroidgui3.cardviews.CardViewEasyHealth;
import za.co.blts.bltandroidgui3.cardviews.CardViewOTT;
import za.co.blts.bltandroidgui3.cardviews.CardviewAdvinne;
import za.co.blts.bltandroidgui3.cardviews.CardviewAfricaPin;
import za.co.blts.bltandroidgui3.cardviews.CardviewAxxess;
import za.co.blts.bltandroidgui3.cardviews.CardviewBetFlash;
import za.co.blts.bltandroidgui3.cardviews.CardviewBluVoucher;
import za.co.blts.bltandroidgui3.cardviews.CardviewCallAll;
import za.co.blts.bltandroidgui3.cardviews.CardviewCellC;
import za.co.blts.bltandroidgui3.cardviews.CardviewConnect;
import za.co.blts.bltandroidgui3.cardviews.CardviewDabba;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.cardviews.CardviewDeezer;
import za.co.blts.bltandroidgui3.cardviews.CardviewDefaultAirtime;
import za.co.blts.bltandroidgui3.cardviews.CardviewDefaultData;
import za.co.blts.bltandroidgui3.cardviews.CardviewFNBConnect;
import za.co.blts.bltandroidgui3.cardviews.CardviewGooglePlay;
import za.co.blts.bltandroidgui3.cardviews.CardviewHollywoodBets;
import za.co.blts.bltandroidgui3.cardviews.CardviewLottoStar;
import za.co.blts.bltandroidgui3.cardviews.CardviewLucky365;
import za.co.blts.bltandroidgui3.cardviews.CardviewLycaMobile;
import za.co.blts.bltandroidgui3.cardviews.CardviewMTN;
import za.co.blts.bltandroidgui3.cardviews.CardviewMyAir;
import za.co.blts.bltandroidgui3.cardviews.CardviewNeotel;
import za.co.blts.bltandroidgui3.cardviews.CardviewNetflix;
import za.co.blts.bltandroidgui3.cardviews.CardviewPlanetGames;
import za.co.blts.bltandroidgui3.cardviews.CardviewPlaystation;
import za.co.blts.bltandroidgui3.cardviews.CardviewRingas;
import za.co.blts.bltandroidgui3.cardviews.CardviewShowmax;
import za.co.blts.bltandroidgui3.cardviews.CardviewSpotify;
import za.co.blts.bltandroidgui3.cardviews.CardviewStarSat;
import za.co.blts.bltandroidgui3.cardviews.CardviewSteam;
import za.co.blts.bltandroidgui3.cardviews.CardviewSupabets;
import za.co.blts.bltandroidgui3.cardviews.CardviewTelkom;
import za.co.blts.bltandroidgui3.cardviews.CardviewTelkomWorldCard;
import za.co.blts.bltandroidgui3.cardviews.CardviewTheUnlimited;
import za.co.blts.bltandroidgui3.cardviews.CardviewUber;
import za.co.blts.bltandroidgui3.cardviews.CardviewUberEats;
import za.co.blts.bltandroidgui3.cardviews.CardviewUnipin;
import za.co.blts.bltandroidgui3.cardviews.CardviewVirgin;
import za.co.blts.bltandroidgui3.cardviews.CardviewVodacom;
import za.co.blts.bltandroidgui3.cardviews.CardviewVoucherMenu;
import za.co.blts.bltandroidgui3.confirmations.BluDroidChatForChangeConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDialogable;
import za.co.blts.bltandroidgui3.confirmations.BluDroidFreeBasicElectricityDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessBundleConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessTopupAnyAmountConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessTopupConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidUniversalElectricityDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidVoucherPurchaseConfirmationDialog;

/**
 * Created by warrenm on 2017/02/15.
 */

public class VoucherRecycler extends BaseFragment implements BluDroidDialogable {

    private final String TAG = this.getClass().getSimpleName();

    VoucherUtility vu = null;
    private BluRecyclerMenuAdapter menuAdapter;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        vu = new VoucherUtility(getBaseActivity());
        ElectricityUtility eu = new ElectricityUtility();
        getBaseActivity().isAirtimePlusAllowed = vu.isAirtimePlusAllowed();
        getBaseActivity().airtimePlusValue = vu.getAirtimePlusValue();
    }

    void setupRecycler(String type) {
        configureRecycler(createCards(retrieveVoucherMap(type), type));
    }

    //Method added to create Voucher Other Menu
    void setupMenuRecycler(String type) {
        configureMenuRecycler(createMenuCards(retrieveVoucherMap(type)));

    }

    void setupTicketMenuRecycler(ArrayList<CardviewDataObject> list) {
        configureTicketMenuRecycler(list);

    }

    Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> retrieveVoucherMap(String type) {
        Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> mappedResponse = null;

        if (BaseActivity.voucherListResponseMessage != null) {
            mappedResponse = vu.getVouchers(type);
        }

        //Remove all all airtime and data if the type is equal to airtime / data
        if (type.equalsIgnoreCase("Airtime") || type.equalsIgnoreCase("Data") || type.equalsIgnoreCase("MVNO") || retrieveC4cSuppliers().size() == 0) {
            removeMVMOFromAllAirtime(mappedResponse);
        }
        return mappedResponse;
    }

    boolean checkAirtimePlus(String manufacturer) {
        if (BaseActivity.voucherListResponseMessage != null) {
            for (VoucherListResponseManufacturerMessage manu : BaseActivity.voucherListResponseMessage.getData().getManufacturers()) {
                if (manu.getName().contains(manufacturer)) {
                    Log.d("kuijkenplus", "manufacturer: " + manufacturer + " airtimeplus:" + manu.getAirtimePlus());
                    return manu.getAirtimePlus().equals("1");
                }
            }
        }
        Log.e("kuijkenplus", "manufacturer: " + manufacturer + " not found");
        return false;
    }

    private void removeMVMOFromAllAirtime(Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> mappedResponse) {
        VoucherListResponseManufacturerMessage manufacturerMessage = null;
        if (mappedResponse != null)
            for (VoucherListResponseManufacturerMessage voucherListResponseManufacturerMessage : mappedResponse.keySet()) {
                if (voucherListResponseManufacturerMessage.getName().equalsIgnoreCase("MVNO")) {
                    manufacturerMessage = voucherListResponseManufacturerMessage;
                }
            }
        if (manufacturerMessage != null) {
            mappedResponse.remove(manufacturerMessage);
        }
    }

    private List<Chat4ChangeResponseSupplierMessage> retrieveC4cSuppliers() {
        List<Chat4ChangeResponseSupplierMessage> suppliers = new ArrayList<>();

        BaseActivity base = getBaseActivity();
        if (base.getCachedMVNOData() != null) {
            suppliers = vu.getC4cSuppliers();
        }
        return suppliers;
    }

    Map<Provider, ArrayList<BundlesResponseProductMessage>> retrieveBundleMap() {
        Map<Provider, ArrayList<BundlesResponseProductMessage>> mappedResponse = null;

        if (BaseActivity.bundlesResponseGetProductListMessages != null) {
            mappedResponse = vu.getBundles();
        }

        return mappedResponse;
    }

    ArrayList<CardviewDataObject> createCards(Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> map, String type) {
        ArrayList<CardviewDataObject> list = new ArrayList<>();

        String currency = getResources().getString(R.string.currency);
        String voucher = getResources().getString(R.string.voucher);
        String topup = getResources().getString(R.string.topUp);

        if (map != null) {
            Log.d("Keys", "Card map: " + map);
            for (VoucherListResponseManufacturerMessage mapKey : map.keySet()) {
                ArrayList<VoucherListResponseProductMessage> products = map.get(mapKey);
                Log.d("Keys", "Card keys: " + products);
                for (VoucherListResponseProductMessage product : products) { // see if this based on supplier list? dump one though
                    String key = mapKey.getName();

                    boolean hasAirtimePlus = mapKey.getAirtimePlus().equals("1");

                    if (key.equals("Vodacom")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewVodacom(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewVodacom(getBaseActivity(), getCleanDesc(product.getName(), key), product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("MTN")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewMTN(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewMTN(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Cell C")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewCellC(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewCellC(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Telkom Mobile")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewTelkom(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewTelkom(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Telkom")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewTelkomWorldCard(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewTelkomWorldCard(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Neotel")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewNeotel(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewNeotel(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Virgin Mobile")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewVirgin(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewVirgin(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("UniPin")) {
                        list.add(new CardviewUnipin(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                    } else if (key.equals("Axxess")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewAxxess(getBaseActivity(), currency + product.getValue().replace(".00", ""), getCleanDesc(product.getName(), key), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewAxxess(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("xHollywood Bets")) {

                        if (type.equals("Data")) {
                            list.add(new CardviewHollywoodBets(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewHollywoodBets(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Deezer")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewDeezer(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewDeezer(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Google Play")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewGooglePlay(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewGooglePlay(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Netflix")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewNetflix(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewNetflix(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Planet Games")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewPlanetGames(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewPlanetGames(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Playstation")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewPlaystation(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewPlaystation(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Showmax")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewShowmax(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewShowmax(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Spotify")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewSpotify(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewSpotify(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Steam")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewSteam(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewSteam(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Uber")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewUber(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewUber(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("Uber Eats")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewUberEats(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewUberEats(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    }
                    else if (key.equals("Top TV")) {

                        if (type.equals("Data")) {
                            list.add(new CardviewStarSat(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            Log.d("Product", product.getCategoryDesc());
                            Log.d("Product", product.getName());
                            Log.d("Product", product.getText());
                            Log.d("Product", product.getValue());
                            Log.d("Product", product.toString());

                            list.add(new CardviewStarSat(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("xDabba")) {
                        if (!type.equals("Data")) {
                            list.add(new CardviewDabba(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equalsIgnoreCase("xSupabets")) {
                        if (!type.equals("Data")) {
                            list.add(new CardviewSupabets(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equals("xLottoStar")) {
                        if (!type.equals("Data")) {
                            list.add(new CardviewLottoStar(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equalsIgnoreCase("ott")) {
                        if (!type.equals("Data")) {
                            list.add(new CardViewOTT(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equalsIgnoreCase("Discovery Prepaid Health")) {
                        if (!type.equals("Data")) {
                            list.add(new CardViewEasyHealth(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        } else {
                            list.add(new CardViewEasyHealth(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    }  else if (key.equalsIgnoreCase("AfricaPin")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewAfricaPin(getBaseActivity(), currency + product.getValue().replace(".00", ""), getCleanDesc(product.getName(), key), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewAfricaPin(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    } else if (key.equalsIgnoreCase("xBetFlash")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewBetFlash(getBaseActivity(), currency + product.getValue().replace(".00", ""), getCleanDesc(product.getName(), key), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewBetFlash(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    }

                    //lucky 365 needs to be a top up
                    //all wallet topups need to be added here as topu or it will not work
                    //check topup vs voucher variable for the voucher type
                    else if (key.equalsIgnoreCase("lucky365")) {
                        if (type.equals("Data")) {
                            list.add(new CardviewLucky365(getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), topup, key, "Wallet Top Up", hasAirtimePlus));
                        } else {
                            list.add(new CardviewLucky365(getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), topup, key, "Wallet Top Up", hasAirtimePlus));
                        }
//                    } else if (key.equalsIgnoreCase("connect")) {
//                        if (type.equalsIgnoreCase("VoucherOther")) {
//                            list.add(new CardviewConnect(getCleanDesc(product.getName(), key),
//                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), topup, key, "Wallet Top Up", hasAirtimePlus));
//                        } else {
//                            list.add(new CardviewConnect(getCleanDesc(product.getName(), key),
//                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), topup, key, "Wallet Top Up", hasAirtimePlus));
//                        }
                    } else {
                        if (type.equals("Data")) {
                            list.add(new CardviewDefaultData(getBaseActivity(), currency + product.getValue().replace(".00", ""), getCleanDesc(product.getName(), key), product.getText(), voucher, key, type, hasAirtimePlus));
                        } else {
                            list.add(new CardviewDefaultAirtime(getBaseActivity(), getCleanDesc(product.getName(), key),
                                    product.getValue().contains("Any") ? product.getValue() : currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    }

//                    //check for favourites list entries
//
//                    getBaseActivity().favouritesStockIDs.add(product.getText());
                }


            }
        }

        return list;
    }

    void setupRecyclerForChat4Change() {
        configureMenuRecycler(createC4cMenuCards(retrieveC4cSuppliers()));
    }

    void setUpMVONRecycler() {
        ArrayList<CardviewDataObject> list = new ArrayList<>();

        String voucher = getResources().getString(R.string.voucher);
        String topup = getResources().getString(R.string.topup);
        String c4c = getResources().getString(R.string.c4c);

        boolean hasAirtimePlus = false;

        String[] amounts = {"R10", "R20", "R30", "R50", "R100", "R200", "Any Amount"};

        if (getBaseActivity().getCachedMVNOData() != null) {

            for (Chat4ChangeResponseSupplierMessage supplierMessage : getBaseActivity().getCachedMVNOData().getData().getSuppliers()) {
                Log.d("Keys", "MVNO supplier name: " + supplierMessage.getName());
                String supplierMessageName = supplierMessage.getName();

                if (!supplierMessageName.equalsIgnoreCase("All")) {
                    for (String amount : amounts) {
                        if (supplierMessageName.equalsIgnoreCase("Advinne")) {
                            list.add(new CardviewAdvinne(getBaseActivity(), supplierMessageName, amount, c4c, voucher, supplierMessageName, true, supplierMessage.getCode(), hasAirtimePlus));
                        } else if (supplierMessageName.equalsIgnoreCase("TheUnlimited")) {
                            list.add(new CardviewTheUnlimited(getBaseActivity(), supplierMessageName, amount, c4c, voucher, supplierMessageName, true, supplierMessage.getCode(), hasAirtimePlus));
                        } else if (supplierMessageName.equalsIgnoreCase("MyAir")) {
                            list.add(new CardviewMyAir(getBaseActivity(), supplierMessageName, amount, c4c, voucher, supplierMessageName, true, supplierMessage.getCode(), hasAirtimePlus));
                        } else if (supplierMessageName.equalsIgnoreCase("FNBConnect")) {
                            list.add(new CardviewFNBConnect(getBaseActivity(), supplierMessageName, amount, c4c, voucher, supplierMessageName, true, supplierMessage.getCode(), hasAirtimePlus));
                        } else if (supplierMessageName.equalsIgnoreCase("LycaMobile")) {
                            list.add(new CardviewLycaMobile(getBaseActivity(), supplierMessageName, amount, c4c, voucher, supplierMessageName, true, supplierMessage.getCode(), hasAirtimePlus));
                        } else if (supplierMessageName.equalsIgnoreCase("Ringas")) {
                            list.add(new CardviewRingas(getBaseActivity(), supplierMessageName, amount, c4c, voucher, supplierMessageName, true, supplierMessage.getCode(), hasAirtimePlus));
                        } else if (supplierMessageName.equalsIgnoreCase("CallAll")) {
                            list.add(new CardviewCallAll(getBaseActivity(), supplierMessageName, amount, c4c, voucher, supplierMessageName, true, supplierMessage.getCode(), hasAirtimePlus));
                        } else if (supplierMessageName.equalsIgnoreCase("BluVoucher")) {
                            list.add(new CardviewBluVoucher(getBaseActivity(), supplierMessageName, amount, c4c, voucher, supplierMessageName, true, supplierMessage.getCode(), hasAirtimePlus));
                        } else if (supplierMessageName.equalsIgnoreCase("Vodacom")) {
                            list.add(new CardviewVodacom(getBaseActivity(), supplierMessageName, amount, "", voucher, supplierMessageName, supplierMessageName, false, false));
                        } else if (supplierMessageName.equalsIgnoreCase("MTN")) {
                            list.add(new CardviewMTN(getBaseActivity(), supplierMessageName, amount, "", voucher, supplierMessageName, supplierMessageName, false, true));
                        } else if (supplierMessageName.equalsIgnoreCase("CellC")) {
                            list.add(new CardviewCellC(getBaseActivity(), supplierMessageName, amount, "", voucher, supplierMessageName, supplierMessageName, false, true));
                        } else if (supplierMessageName.equalsIgnoreCase("TelkomMobile")) {
                            list.add(new CardviewTelkom(getBaseActivity(), supplierMessageName, amount, "", voucher, supplierMessageName, supplierMessageName, false, true));
                        } else if (supplierMessageName.equalsIgnoreCase("Connect")) {
                            list.add(new CardviewConnect(supplierMessageName, amount, "", topup, supplierMessageName, true, supplierMessage.getCode(), hasAirtimePlus));
                        } else {
                            list.add(new CardviewDefaultAirtime(getBaseActivity(), supplierMessageName, amount, c4c, voucher, supplierMessageName, true, supplierMessage.getCode(), hasAirtimePlus));
                        }
                    }
                }
            }
        }

        configureRecycler(list);
    }

    ArrayList<CardviewDataObject> createPinlessTopupCards() {
        ArrayList<CardviewDataObject> list = new ArrayList<>();
        LinkedList<Provider> networkProviders = null;
        if (vu != null) {
            networkProviders = vu.getProviders();
        }

        String currency = getResources().getString(R.string.currency);
        String topup = getResources().getString(R.string.topup);

        if (networkProviders.size() > 0) {
            for (Provider p : networkProviders) {
                String providerName = p.getProviderName();

                boolean hasAirtimePlus;

                hasAirtimePlus = p.getHasAirtimePlus();
                String[] amounts = {"R10", "R20", "R30", "R50", "R100", "R200", "Any Amount"};

                //any amount should be based on the C4C permission
                if (!providerName.equalsIgnoreCase("All")) {
                    for (String amount : amounts) {
                        if (providerName.equalsIgnoreCase("Vodacom") && p.isHasTopup()) {
                            list.add(new CardviewVodacom(getBaseActivity(), "", amount, "", topup, providerName, hasAirtimePlus));
                        } else if (providerName.equalsIgnoreCase("MTN") && p.isHasTopup()) {
                            list.add(new CardviewMTN(getBaseActivity(), "", amount, "", topup, providerName, hasAirtimePlus));
                        } else if (providerName.equalsIgnoreCase("Cell C") && p.isHasTopup()) {
                            list.add(new CardviewCellC(getBaseActivity(), "", amount, "", topup, providerName, hasAirtimePlus));
                        } else if (providerName.equalsIgnoreCase("Telkom Mobile") && p.isHasTopup()) {
                            list.add(new CardviewTelkom(getBaseActivity(), "", amount, "", topup, providerName, hasAirtimePlus));
                        } else if (providerName.equalsIgnoreCase("Neotel") && p.isHasTopup()) {
                            list.add(new CardviewNeotel(getBaseActivity(), "", amount, "", topup, providerName, hasAirtimePlus));
                        } else if (providerName.equalsIgnoreCase("Virgin Mobile") && p.isHasTopup()) {
                            list.add(new CardviewVirgin(getBaseActivity(), "", amount, "", topup, providerName, hasAirtimePlus));
                        } else if (p.isHasTopup()) {
                            list.add(new CardviewDefaultAirtime(getBaseActivity(), "", amount, "", topup, providerName, hasAirtimePlus));
                        }
                    }
                }
            }
        }
        return list;
    }

    ArrayList<CardviewDataObject> createBundledPinlessTopupCards(Map<Provider, ArrayList<BundlesResponseProductMessage>> map) {
        ArrayList<CardviewDataObject> list = new ArrayList<>();

        String currency = getResources().getString(R.string.currency);
        String bundle = getResources().getString(R.string.bundle);

        if (map != null) {
            for (Provider mapKey : map.keySet()) {
                ArrayList<BundlesResponseProductMessage> products = map.get(mapKey);

                String key = mapKey.getProviderName();

                for (BundlesResponseProductMessage product : products) {

                    //StockId used as productCode too...
                    if (key.startsWith("Vodacom")) {
                        list.add(new CardviewVodacom(getBaseActivity(), getCleanDesc(product.getDescription(), key), currency + product.getAmount().replaceAll("\\.0*$", ""), product.getProductCode(), bundle, key, mapKey.getHasAirtimePlus()));
                    } else if (key.startsWith("MTN")) {
                        list.add(new CardviewMTN(getBaseActivity(), getCleanDesc(product.getDescription(), key), currency + product.getAmount().replaceAll("\\.0*$", ""), product.getProductCode(), bundle, key, mapKey.getHasAirtimePlus()));
                    } else if (key.startsWith("Cell")) {
                        list.add(new CardviewCellC(getBaseActivity(), getCleanDesc(product.getDescription(), key), currency + product.getAmount().replaceAll("\\.0*$", ""), product.getProductCode(), bundle, key, mapKey.getHasAirtimePlus()));
                    } else if (key.startsWith("Telkom Mobile")) {
                        list.add(new CardviewTelkom(getBaseActivity(), getCleanDesc(product.getDescription(), key.replace(" ", "")), currency + product.getAmount().replaceAll("\\.0*$", ""), product.getProductCode(), bundle, key.replace(" ", ""), mapKey.getHasAirtimePlus()));
                    } else if (key.startsWith("Virgin Mobile")) {
                        list.add(new CardviewVirgin(getBaseActivity(), getCleanDesc(product.getDescription(), key), currency + product.getAmount().replaceAll("\\.0*$", ""), product.getProductCode(), bundle, key, mapKey.getHasAirtimePlus()));
                    } else {
                        list.add(new CardviewDefaultData(getBaseActivity(), currency + product.getAmount().replaceAll("\\.0*$", ""), getCleanDesc(product.getDescription(), key), product.getProductCode(), bundle, key, mapKey.getHasAirtimePlus()));
                    }
                }
            }
        }
        return list;
    }

    String getCleanDesc(String description, String network) {
        //THIS IS ULGY - NOT WRITTEN BY WARREN :P
        //Specifics ESTA wanted :(
        String cleanDescription = "";
        if (network.startsWith("x")) {
            network = network.replace("x", "");
        }

        String[] parts = description.split(" |\\(|\\)|\\,");
        for (String part : parts) {
            if (!part.equalsIgnoreCase(network) &&
                    !part.equalsIgnoreCase("Airtime") &&
                    !part.equalsIgnoreCase("Data") &&
                    !part.equalsIgnoreCase("Cell") &&
                    !part.equalsIgnoreCase("C") &&
                    !part.equalsIgnoreCase("TelkomMobile") &&
                    !part.equalsIgnoreCase("8ta") &&
                    !part.equalsIgnoreCase("TOP") &&
                    !part.equalsIgnoreCase("TV") &&
                    !part.equalsIgnoreCase("Hollywood") &&
                    !part.equalsIgnoreCase("Bets")) {
                cleanDescription += part + " ";
            }
        }


        return cleanDescription.trim();
    }

    private ArrayList<CardviewDataObject> createC4cMenuCards(List<Chat4ChangeResponseSupplierMessage> suppliers) {
        ArrayList<CardviewDataObject> list = new ArrayList<>();

        if (suppliers != null) {
            for (Chat4ChangeResponseSupplierMessage supplierMessage : suppliers) {

                String key = supplierMessage.getName();
                if (key.startsWith("x")) {
                    key = key.replace("x", "");
                }

                if (key.equals("Advinne")) {
                    list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.advinne, R.color.white, key, key));
                } else if (key.equals("TheUnlimited")) {
                    list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.theunlimited, R.color.white, key, key));
                } else if (key.equals("MyAir")) {
                    list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.myair, R.color.white, key, key));
                } else if (key.equals("FNBConnect")) {
                    list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.fnbconnect, R.color.fnbconnect, key, key));
                } else if (key.contains("Lyca")) {
                    list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.lycamobile, R.color.white, key, key));
                } else if (key.contains("Ringas")) {
                    list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ringas, R.color.white, key, key));
                } else if (key.equals("CallAll")) {
                    list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.callall, R.color.white, key, key));
                } else if (key.contains("BluVoucher")) {
                    //do not display BluVoucher menu card under MVNOs, as it is moved into Vouchers
                } else if (key.equalsIgnoreCase("Connect")) {
                    list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.connect_menu_card, R.color.white, key, key));
                } else {
                    list.add(new CardviewVoucherMenu(getBaseActivity(), key, key));
                }

            }
        }


//    if (BaseActivity.loginResponseMessage != null) {
//      for (LoginResponseGroupMessage group : BaseActivity.loginResponseMessage.getData().getTransactionTypes()) {
//        if (group.getName().equalsIgnoreCase("xml interface")) {
//          for (LoginResponseTransactionTypeMessage trxType : group.getTransactionTypes()) {
//            if (trxType.getType().equalsIgnoreCase("topup") && trxType.getDisplayName().equalsIgnoreCase("connect")) {
//              Log.d("kuijkenfav", "************adding connect menu");
//              list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.connect_menu_card, R.color.white, trxType.getDisplayName(), trxType.getDisplayName()));
//            }
//          }
//        }
//      }
//
//    }

        return list;
    }

    //Method added to create Voucher Other Menu
    private ArrayList<CardviewDataObject> createMenuCards(Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> map) {
        ArrayList<CardviewDataObject> list = new ArrayList<>();

        if (map != null) {
            for (VoucherListResponseManufacturerMessage mapKey : map.keySet()) {

                String key = mapKey.getName();
                if (key.startsWith("x")) {
                    key = key.replace("x", "");
                }
                switch (key) {
                    case "Axxess":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.axxess, R.color.white, key, key));
                        break;
                    case "Hollywood Bets":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.hollywoodbets, R.color.hollywoodbets, key, key));
                        break;
                    case "Deezer":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.deezer, R.color.deezer, key, key));
                        break;
                    case "Google Play":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.google_play, R.color.white, key, key));
                        break;
                    case "Netflix":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.netflix, R.color.white, key, key));
                        break;
                    case "Planet Games":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.planet_games, R.color.white, key, key));
                        break;
                    case "Showmax":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.showmax, R.color.white, key, key));
                        break;
                    case "Playstation":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.playstation, R.color.white, key, key));
                        break;
                    case "Spotify":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.spotify, R.color.spotify, key, key));
                        break;
                    case "Steam":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.steam, R.color.white, key, key));
                        break;
                    case "Uber":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.uber, R.color.white, key, key));
                        break;
                    case "Uber Eats":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ubereats, R.color.uber_eats, key, key));
                        break;
                    case "Top TV":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.starsat, R.color.white, key, key));
                        break;
                    case "Dabba":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.dabba, R.color.white, key, key));
                        break;
                    case "Supabets":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.supabets, R.color.white, key, key));
                        break;
                    case "LottoStar":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.lottostar, R.color.white, key, key));
                        break;
                    case "BetFlash":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.betflash, R.color.white, key, key));
                        break;
                    case "AfricaPIN":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.africapin, R.color.white, key, key));
                        break;
                    case "MVNO":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.mvno_menu_card, R.color.mvno, key, key));
                        break;
                    case "OTT":
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ott, R.color.white, key, key));
                        break;
                    case "Discovery Prepaid Health":
                        list.add(new CardViewEasyHealth(getBaseActivity(), R.drawable.discovery, R.color.white, key, key));
                        break;
                    default:
                        list.add(new CardviewVoucherMenu(getBaseActivity(), key, key));
                        break;
                }
            }
        }

        if (BaseActivity.loginResponseMessage.getData().canDoIthuba()) {
            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ithuba, R.color.ithuba, getResources().getString(R.string.ithuba), getResources().getString(R.string.ithuba)));
        }
        return list;
    }

    //Method added to create Voucher Other Menu
    private void configureMenuRecycler(ArrayList<CardviewDataObject> list) {
        recycler.setHasFixedSize(true);
        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getBaseActivity(), R.dimen.item_offset);
        recycler.addItemDecoration(itemDecoration);
        recycler.setLayoutManager(grid);
        menuAdapter = new BluRecyclerMenuAdapter(this, list);
        recycler.setAdapter(menuAdapter);
    }

    private void configureTicketMenuRecycler(ArrayList<CardviewDataObject> list) {

        recycler.setHasFixedSize(true);
        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getBaseActivity(), R.dimen.item_offset);
        recycler.addItemDecoration(itemDecoration);
        recycler.setLayoutManager(grid);
        menuAdapter = new BluRecyclerMenuAdapter(this, list);
        recycler.setAdapter(menuAdapter);

    }

    //
    // these three methods are the possible buttons
    // on purchase confirmations
    //
    public void affirmativeButton(View view) {
        Log.d(TAG, "affirmativeButton " + getBaseActivity().confirmation.getClass().getSimpleName());
        Log.d(TAG, "stockId is " + adapter.getStockId());
        Log.d(TAG, "confirmation is " + getBaseActivity().confirmation.getClass().getSimpleName());
        int quantity;
        if (getBaseActivity().confirmation instanceof BluDroidVoucherPurchaseConfirmationDialog) {
            BluDroidVoucherPurchaseConfirmationDialog dialog =
                    (BluDroidVoucherPurchaseConfirmationDialog) getBaseActivity().confirmation;
            quantity = dialog.getQuantity();
            getBaseActivity().dismissConfirmation();
            Log.d(TAG, "quantity is " + quantity);
            if (!((BluDroidVoucherPurchaseConfirmationDialog) getBaseActivity().confirmation).isMVNO()) {
                getMainActivity().getVoucher(adapter.getStockId(), quantity, dialog.getSupplierCode(), dialog.getAmount());
            } else {
                BaseActivity.gettingVouchers = true;
                getMainActivity().authenticateForChatForChange(dialog.getSupplierCode(), dialog.getAmount());
            }
        } else if (getBaseActivity().confirmation instanceof BluDroidChatForChangeConfirmationDialog) {

            BluDroidChatForChangeConfirmationDialog dialog =
                    (BluDroidChatForChangeConfirmationDialog) getBaseActivity().confirmation;
            String supplierCode = dialog.getSupplierCode();
            String amount = dialog.getAmount();

            Log.d(TAG, "supplierCode is " + supplierCode);
            Log.d(TAG, "supplierCode is " + dialog.getSupplierCode() + " Amount " + dialog.getAmount());

            if (dialog.validate()) {
                getBaseActivity().multipleVouchersAuthenticationResponseMessage = null;
                getBaseActivity().dismissConfirmation();
                String possibleStockId = getPossibleStockId(supplierCode, amount);
                BaseActivity.gettingVouchers = true;
                if (possibleStockId == null) {
                    getMainActivity().authenticateForChatForChange(dialog.getSupplierCode(), amount);
                } else {
                    getMainActivity().getVoucher(possibleStockId, 1, supplierCode, amount);
                }
            }
        }
        //
        // order of next two items is important because of inheritance
        //
        else if (getBaseActivity().confirmation instanceof BluDroidPinlessBundleConfirmationDialog) {
            Log.d(TAG, "bundles");
            BluDroidPinlessBundleConfirmationDialog dialog =
                    (BluDroidPinlessBundleConfirmationDialog) getBaseActivity().confirmation;
            String cellNumber = dialog.getCellNumber();

            if (dialog.validate()) {
                Log.d(TAG, "validated");
                String provider = dialog.getTopupName();

                Log.d(TAG, "provider is [" + provider + "]");
                //
                // there has to be a better way to do this
                //
                String bundleProvider = provider.replaceAll(" ", "").replaceAll("TelkomMobile", "TelkomMobile") + "Bundles";
                Log.d(TAG, "bundleProvider is [" + bundleProvider + "]");
                Log.d(TAG, "adapter.getStockId is [" + adapter.getStockId() + "]");
                //
                // stockId holds the product code
                //
                getBaseActivity().dismissConfirmation();
                getMainActivity().getBundle(bundleProvider, adapter.getStockId(), cellNumber);
            } else {
                Log.d(TAG, "validation failed");
            }
        } else if (getBaseActivity().confirmation instanceof BluDroidPinlessTopupConfirmationDialog) {
            Log.d(TAG, "pinless topup");

            BluDroidPinlessTopupConfirmationDialog dialog = (BluDroidPinlessTopupConfirmationDialog) getBaseActivity().confirmation;
            String topupName = dialog.getTopupName();
            String amount = dialog.getAmount();
            String cellNumber = dialog.getCellNumber();

            Log.d(TAG, "topupName is " + topupName);

            if (dialog.validate()) {

                if (vu.containsCaseInsensitive(topupName, BaseActivity.walletTopupProviders)) {
                    getBaseActivity().gettingWalletTopup = true;
                }
                Log.d(TAG, "need to validate for pinless topup");
                Log.d(TAG, "topupName is " + topupName);
                Log.d(TAG, "amount is " + amount);
                getBaseActivity().dismissConfirmation();

                getMainActivity().authenticateForPinlessTopup(topupName, cellNumber, amount);
            }
        } else if (getBaseActivity().confirmation instanceof BluDroidPinlessTopupAnyAmountConfirmationDialog) {

            Log.d(TAG, "pinless topup any amount");

            BluDroidPinlessTopupAnyAmountConfirmationDialog dialog = (BluDroidPinlessTopupAnyAmountConfirmationDialog) getBaseActivity().confirmation;

            String topupName = dialog.getTopupName();
            String amount = dialog.getAmount();
            String cellNumber = dialog.getCellNumber();

            Log.d(TAG, "topupName is " + topupName);

            if (dialog.validate()) {

                if (vu.containsCaseInsensitive(topupName, BaseActivity.walletTopupProviders)) {
                    getBaseActivity().gettingWalletTopup = true;
                }
                Log.d(TAG, "need to validate for pinless topup any amount");
                Log.d(TAG, "topupName is " + topupName);
                Log.d(TAG, "amount is " + amount);
                getBaseActivity().dismissConfirmation();
                getMainActivity().authenticateForPinlessTopup(topupName, cellNumber, amount);

            }

        } else if (getBaseActivity().confirmation instanceof BluDroidUniversalElectricityDialog) {

            Log.d(TAG, "universal electricity");

            BluDroidUniversalElectricityDialog dialog = (BluDroidUniversalElectricityDialog) getBaseActivity().confirmation;

            String municName = dialog.getMunicName();
            String meterNumber = dialog.getMeterNumber();
            String amount = dialog.getAmount();
            String purchaseType = "Token";


            Log.d(TAG, "municName is " + municName);

            if (dialog.validate()) {

                Log.d(TAG, "need to validate for universal electricity");
                Log.d(TAG, "municName is " + municName);
                Log.d(TAG, "meterNumber is " + meterNumber);
                Log.d(TAG, "amount is " + amount);
                getBaseActivity().dismissConfirmation();
                getMainActivity().authenticateForUniversalElectricity(municName, meterNumber, amount, purchaseType);
            }


        } else if (getBaseActivity().confirmation instanceof BluDroidFreeBasicElectricityDialog) {

            Log.d(TAG, "universal electricity");

            BluDroidFreeBasicElectricityDialog dialog = (BluDroidFreeBasicElectricityDialog) getBaseActivity().confirmation;

            String meterNumber = dialog.getMeterNumber();

            String purchaseType = "FBE";

            if (dialog.validate()) {

                Log.d(TAG, "need to validate for free basic electricity");

                Log.d(TAG, "meterNumber is " + meterNumber);
                getBaseActivity().dismissConfirmation();
                getMainActivity().authenticateForUniversalElectricity("Electricity", meterNumber, "0.00", purchaseType);
            }
        }

        BaseActivity.logger.info("VoucherPurchase Confirmed");
    }

    public void negativeButton(View view) {
        Log.d(TAG, "negativeButton");
        BaseActivity.logger.info("VoucherPurchase Cancelled");
        getBaseActivity().dismissConfirmation();
        getBaseActivity().airtimePlusPlayed = "0";
        BaseActivity.gettingMvnoVoucher = false;

    }

    public void neutralButton(View view) {
        Log.d(TAG, "neutralButton");

        if (getBaseActivity().confirmation instanceof BluDroidUniversalElectricityDialog) {

            Log.d(TAG, "universal electricity");

            BluDroidUniversalElectricityDialog dialog = (BluDroidUniversalElectricityDialog) getBaseActivity().confirmation;

            dialog.setAmount("0.00");
            String municName = dialog.getMunicName();
            String meterNumber = dialog.getMeterNumber();
            String amount = dialog.getAmount();
            String purchaseType = "FBE";

            Log.d(TAG, "municName is " + municName);
            if (dialog.validate()) {

                Log.d(TAG, "need to validate for universal electricity");
                Log.d(TAG, "municName is " + municName);
                Log.d(TAG, "meterNumber is " + meterNumber);
                Log.d(TAG, "amount is " + amount);
                getBaseActivity().dismissConfirmation();
                getMainActivity().authenticateForUniversalElectricity(municName, meterNumber, amount, purchaseType);
            }
        }
    }

    //
    // return true for chat4change
    // return false if it must go voucher
    //
    private String getPossibleStockId(String supplierCode, String amount) {
        String serviceProviderName = "";
        switch (supplierCode) {
            case "1":
                serviceProviderName = "Vodacom";
                break;
            case "2":
                serviceProviderName = "MTN";
                break;
            case "3":
                serviceProviderName = "Cell C";
                break;
            case "4":
                serviceProviderName = "Telkom Mobile";
                break;
            case "5":
                serviceProviderName = "Virgin Mobile";
                break;
        }
        for (int i = 0; i < BaseActivity.voucherListResponseMessage.getData().getManufacturers().size(); i++) {

            if (BaseActivity.voucherListResponseMessage.getData().getManufacturers().get(i).getName().equals(serviceProviderName)) {
                Log.d(TAG, "got " + serviceProviderName);
                Log.d(TAG, "amount [" + amount + "]");
                for (int j = 0; j < BaseActivity.voucherListResponseMessage.getData().getManufacturers().get(i).getProducts().size(); j++) {
                    if (BaseActivity.voucherListResponseMessage.getData().getManufacturers().get(i).getProducts().get(j).getCategoryDesc().equals("Airtime")) {

                        if (BaseActivity.voucherListResponseMessage.getData().getManufacturers().get(i).getProducts().get(j).getValue().equals(amount)) {
                            String stockId = BaseActivity.voucherListResponseMessage.getData().getManufacturers().get(i).getProducts().get(j).getText();
                            Log.d(TAG, "got stockId " + stockId);
                            return stockId;
                        }
                    }
                }
            }

        }
        return null;
    }


}
