package za.co.blts.bltandroidgui3;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_CAN_BOXRICA;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_USE_SSL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

/**
 * Created by NkosanaM on 3/14/2017.
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00280_Rica_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
        changePreference(PREF_RICA_CAN_BOXRICA, PREF_FALSE);
        changePreference(PREF_RICA_USE_SSL, PREF_FALSE);
    }

    @After
    public void after() {
        changePreference(PREF_RICA_CAN_BOXRICA, PREF_FALSE);
        changePreference(PREF_RICA_USE_SSL, PREF_FALSE);
        tearDown();
    }

    @Test
    public void T001_Query() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            selectVoucherTypeRica();
            Log.d(TAG, "Select FragmentRica");

            checkRicaLogin();

            checks.enterText(R.id.cellNumber, "0731234567");
            Log.d(TAG, "cellphone number entered");

            checks.clickButton("Query");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "rica query successful");
            } else {
                fail("rica query NOT successful");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_Register() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            selectVoucherTypeRica();
            Log.d(TAG, "Select FragmentRica");

            checkRicaLogin();

            checks.selectRicaTab("New Registration");

            if (solo.waitForText("Consumer Information")) {
                Log.d(TAG, "Consumer Information");
            }

            checks.enterText(R.id.consumerName, "test");
            Log.d(TAG, "Consumer name entered");

            checks.enterText(R.id.consumerLastName, "test");
            Log.d(TAG, "Consumer last name entered");

            BluDroidLinearLayout bottomPortionLayout = (BluDroidLinearLayout) solo.getView(R.id.bottomPortionLayout);
            bottomPortionLayout.scrollBy(0, 250);
            Log.d(TAG, "scroll down");

            checks.enterText(R.id.idNumber, "9301285773084");
            Log.d(TAG, "Consumer id number entered");

            clickNext();
            Log.d(TAG, "Next button clicked");

            if (solo.waitForText("Address Information")) {
                Log.d(TAG, "Address Information");
            } else {
                fail("Address Information not visible");
            }

            checks.enterText(R.id.addressLine1, "test1");
            Log.d(TAG, "address line 1 entered");

            checks.enterText(R.id.addressLine2, "test1");
            Log.d(TAG, "address line 2 entered");

            checks.enterText(R.id.suburb, "test1");
            Log.d(TAG, "suburb entered");

            bottomPortionLayout = (BluDroidLinearLayout) solo.getView(R.id.bottomPortionLayout);
            bottomPortionLayout.scrollBy(0, 250);
            Log.d(TAG, "scroll down");

            checks.enterText(R.id.city, "test1");
            Log.d(TAG, "city entered");

            checks.enterText(R.id.postalCode, "0002");
            Log.d(TAG, "postal code entered");

            clickNext();
            Log.d(TAG, "Next button clicked");

            if (solo.waitForText("Sim Registration")) {
                Log.d(TAG, "Sim Registration");
            } else {
                fail("Sim Registration not visible");
            }

            solo.clickOnText("Vodacom");
            solo.clickOnText("Cell C");
            Log.d(TAG, "Cell C selected");

            checks.enterText(R.id.simSerial, "123456");
            Log.d(TAG, "Serial number entered");

            checks.clickButton("Add");
            Log.d(TAG, "Serial number added");

            checks.clickButton("Submit");
            Log.d(TAG, "Submit button clicked");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "rica Register successful");
            } else {
                fail("rica Register NOT successful");
            }
            solo.clickOnText("OK");

            checks.enterText(R.id.simSerial, "1234567");
            Log.d(TAG, "Serial number entered");

            checks.clickButton("Add");
            Log.d(TAG, "Serial number added");

            checks.enterText(R.id.simSerial, "12345678");
            Log.d(TAG, "Serial number entered");

            checks.clickButton("Add");
            Log.d(TAG, "Serial number added");

            checks.clickButton("Submit");
            Log.d(TAG, "Submit button clicked");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "rica Multiple Register successful");
            } else {
                fail("rica Multiple Register NOT successful");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    //solo.getCurrentViews() shows that there are 5 fragments currently open, as there are 5 copies of the leftmenu/toolbar/etc returned
// for some reason robotium is not getting the correct fragment on top, so we need to use the statically defined edittexts/layouts/etc to enter text
// and scroll the page
    @Test
    public void T020_ChangeOwner() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            selectVoucherTypeRica();
            Log.d(TAG, "Select FragmentRica");

            checkRicaLogin();

            checks.selectRicaTab("Change Owner");
            Log.d(TAG, "Select Change Owner");

            if (solo.searchText("Old Consumer Information")) {
                Log.d(TAG, "Old Consumer Information");
            } else {
                fail("Old Consumer Information not found");
            }

            checks.enterText(R.id.oldIdNumber, "9301285773084");
            Log.d(TAG, "Old Consumer id number entered");

            clickNext();
            Log.d(TAG, "Next button clicked");

            if (solo.searchText("New Consumer Information")) {
                Log.d(TAG, "New Consumer Information");
            } else {
                fail("New Consumer Information not found");
            }

            checks.enterText(R.id.changeNewConsumerName, "test");
            Log.d(TAG, "Consumer name entered");

            checks.enterText(R.id.changeNewConsumerLastName, "test");
            Log.d(TAG, "Consumer last name entered");

            BluDroidLinearLayout bottomPortionLayout = (BluDroidLinearLayout) solo.getView(R.id.changeNewBottomPortionLayout);
            bottomPortionLayout.scrollBy(0, 250);
            Log.d(TAG, "scroll down");

            checks.enterText(R.id.changeNewIdNumber, "9301285773084");
            Log.d(TAG, "Consumer id number entered");

            clickNext();
            Log.d(TAG, "Next button clicked");

            if (solo.waitForText("Address Information")) {
                Log.d(TAG, "Address Information");
            } else {
                fail("Address not found");
            }

            checks.enterText(R.id.changeAddressLine1, "test1");
            Log.d(TAG, "address line 1 entered");

            checks.enterText(R.id.changeAddressLine2, "test1");
            Log.d(TAG, "address line 2 entered");

            checks.enterText(R.id.changeSuburb, "test1");
            Log.d(TAG, "suburb entered");

            bottomPortionLayout = (BluDroidLinearLayout) solo.getView(R.id.changeAddressBottomPortionLayout);
            bottomPortionLayout.scrollBy(0, 400);
            Log.d(TAG, "scroll down");

            checks.enterText(R.id.changeCity, "test1");
            Log.d(TAG, "city entered");

            checks.enterText(R.id.changePostalCode, "0002");
            Log.d(TAG, "postal code entered");

            clickNext();
            Log.d(TAG, "Next button clicked");

            View providerSpinner = solo.getView(R.id.providerSpinner);
            solo.clickOnView(providerSpinner);

            solo.clickOnText("Cell C");
            Log.d(TAG, "Cell C selected");

            checks.enterText(R.id.simSerial, "123456");
            Log.d(TAG, "Serial number entered");

            checks.clickButton("Add");
            Log.d(TAG, "Serial number added");

            checks.clickButton("Submit");
            Log.d(TAG, "Submit button clicked");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "rica change owner successful");
            } else {
                fail("rica change owner NOT successful");
            }
            solo.clickOnText("OK");
            Log.d(TAG, "dialog dismissed");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    // solo.getCurrentViews() shows that there are 5 fragments currently open, as there are 5 copies of the leftmenu/toolbar/etc returned
// for some reason robotium is not getting the correct fragment on top, so we need to use the statically defined edittexts/layouts/etc to enter text
// and scroll the page
    @Test
    public void T030_BoxRegister() {
        try {
            changePreference(PREF_RICA_CAN_BOXRICA, PREF_TRUE);
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            selectVoucherTypeRica();
            Log.d(TAG, "Select FragmentRica");

            checkRicaLogin();

            checks.selectRicaTab("Change Owner");
            checks.selectRicaTab("Box Rica");

            if (solo.waitForText("Consumer Information")) {
                Log.d(TAG, "Consumer Information");
            }

            checks.enterText(R.id.consumerName, "test");
            Log.d(TAG, "Consumer name entered");

            checks.enterText(R.id.consumerLastName, "test");
            Log.d(TAG, "Consumer last name entered");

            BluDroidLinearLayout bottomPortionLayout = (BluDroidLinearLayout) solo.getView(R.id.boxConsumerBottomPortionLayout);
            bottomPortionLayout.scrollBy(0, 400);
            Log.d(TAG, "scroll down");

            checks.enterText(R.id.boxidNumber, "9301285773084");
            Log.d(TAG, "Consumer id number entered");

            clickNext();
            Log.d(TAG, "Next button clicked");

            if (solo.waitForText("Address Information")) {
                Log.d(TAG, "Address Information");
            }

            checks.enterText(R.id.addressLine1, "test1");
            Log.d(TAG, "address line 1 entered");

            checks.enterText(R.id.addressLine2, "test1");
            Log.d(TAG, "address line 2 entered");

            checks.enterText(R.id.suburb, "test1");
            Log.d(TAG, "suburb entered");

            bottomPortionLayout = (BluDroidLinearLayout) solo.getView(R.id.addressBottomPortionLayout);
            bottomPortionLayout.scrollBy(0, 400);

            Log.d(TAG, "scroll down");

            checks.enterText(R.id.city, "test1");
            Log.d(TAG, "city entered");

            checks.enterText(R.id.postalCode, "0002");
            Log.d(TAG, "postal code entered");

            clickNext();
            Log.d(TAG, "Next button clicked");

            solo.pressSpinnerItem(0, 2);
            solo.clickOnText("Cell C");
            Log.d(TAG, "Cell C selected");

            checks.enterText(R.id.simSerial, "123456");
            Log.d(TAG, "Serial number entered");

            checks.clickButton("Add");
            Log.d(TAG, "Serial number added");

            checks.clickButton("Submit");
            Log.d(TAG, "Submit button clicked");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "rica Register successful");
            } else {
                fail("rica Register NOT successful");
            }

            solo.clickOnText("OK");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T040_IdValidation() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            selectVoucherTypeRica();
            Log.d(TAG, "Select FragmentRica");

            checkRicaLogin();

            checks.selectRicaTab("New Registration");

            if (solo.waitForText("Consumer Information")) {
                Log.d(TAG, "Consumer Information");
            } else {
                fail("Could not find Consumer Information");
            }

            checks.enterText(R.id.consumerName, "test");
            Log.d(TAG, "Consumer name entered");

            checks.enterText(R.id.consumerLastName, "test");
            Log.d(TAG, "Consumer last name entered");

            BluDroidLinearLayout bottomPortionLayout = (BluDroidLinearLayout) solo.getView(R.id.bottomPortionLayout);
            bottomPortionLayout.scrollBy(0, 250);
            Log.d(TAG, "scroll down");

            checks.enterText(R.id.idNumber, "8913030290081");

            clickNext();

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.idNumberInvalid))) {
                Log.d(TAG, "Invalid Id Number No 13th Month");
            } else {
                fail("Invalid Id Number No 13th Month");
            }

            checks.enterText(R.id.idNumber, "");
            checks.enterText(R.id.idNumber, "8909320290081");

            clickNext();
            if (solo.searchText(getBaseActivity().getResources().getString(R.string.idNumberInvalid))) {
                Log.d(TAG, "Invalid Id Number No 32days");
            } else {
                fail("Invalid Id Number No 32days");
            }

            checks.enterText(R.id.idNumber, "");
            checks.enterText(R.id.idNumber, "8913030290");

            clickNext();
            if (solo.searchText(getBaseActivity().getResources().getString(R.string.idNumberInvalid))) {
                Log.d(TAG, "Less than 13 digits");
            } else {
                fail("Less than 13 digits");
            }

            checks.enterText(R.id.idNumber, "89130302jh@2");
            checks.enterText(R.id.idNumber, "89130302jh");

            clickNext();
            if (solo.searchText(getBaseActivity().getResources().getString(R.string.idNumberInvalid))) {
                Log.d(TAG, "Symbols included");
            } else {
                fail("Symbols included");
            }

            checks.enterText(R.id.idNumber, "9203020743084");
            Log.d(TAG, "Valid Id Number");
            checks.enterText(R.id.idNumber, "9203020743084");

            clickNext();

            if (solo.waitForText("Address Information")) {
                Log.d(TAG, "ID validation test passed");
            } else {
                fail("ID validation test failed");
            }


        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    private void clickNext() {
//        View nextBtn = solo.getView(R.id.next);
//        solo.clickOnView(nextBtn);

//        solo.clickOnButton("Next");

//        solo.clickOnButton(1);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getBaseActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        solo.clickOnScreen(width - 20, height - 20);
    }

}
