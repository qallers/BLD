package za.co.blts.bltandroidgui3;


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.net.Socket;
import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePrintEZPLMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePrintMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseTicketMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidMandatoryEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTicketProReprint extends TicketProRecycler implements NeedsAEONResults, View.OnClickListener {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidMandatoryEditText referenceNumberEditText;
    private BluDroidRelativeLayout layout;

    public FragmentTicketProReprint() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // Inflate the layout for this fragment

        View rootView = inflater.inflate(R.layout.fragment_ticket_pro_reprint, container, false);

        layout = rootView.findViewById(R.id.layout);
        referenceNumberEditText = rootView.findViewById(R.id.referenceNumber);
        BluDroidButton btnCancel = rootView.findViewById(R.id.cancel);
        BluDroidButton btnReprint = rootView.findViewById(R.id.reprint);
        btnCancel.setOnClickListener(this);
        btnReprint.setOnClickListener(this);

        getBaseActivity().isTicketProReprint = true;
        return rootView;
    }

    @Override
    public void onClick(View v) {
        BaseActivity.logger.info(((BluDroidButton) v).getText());
        switch (v.getId()) {
            case R.id.cancel:
                getBaseActivity().gotoFragment(new FragmentTicketProCategories(), "FragmentTicketProCategories");
                break;
            case R.id.reprint:
                if (layout.validate()) {
//          String refNumber = referenceNumberEditText.getText().toString();
//          doTicketProReprint(refNumber);
                    authenticateWithTicketPro();
                }
                break;

            default:
                break;
        }
    }

    @Override
    public void results(Object object) {

        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(Reprint) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }

        if (object instanceof TicketProAuthenticationResponseMessage) {
            getBaseActivity().ticketProAuthenticationResponseMessage = (TicketProAuthenticationResponseMessage) object;

            if (getBaseActivity().ticketProAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                String refNumber = referenceNumberEditText.getText().toString();
                doTicketProReprint(refNumber);
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProAuthenticationResponseMessage, true);
            }

        } else if (object instanceof TicketProResponsePrintMessage) {
            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProResponsePrintMessage = (TicketProResponsePrintMessage) object;
            if (getBaseActivity().ticketProResponsePrintMessage.getEvent().getEventCode().equals("0")) {
                getBaseActivity().printEventTickets();
//                if (getBaseActivity().ticketProResponsePrintMessage.getData().getTickets().size() > 0) {
//
//                    getBaseActivity().createProgress(R.string.gettingTicketProFormattedTickets);
//                    HTTPGetAsyncTask getAsyncTask = new HTTPGetAsyncTask(getBaseActivity());
//                    getAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, getBaseActivity(), getBaseActivity().ticketProResponsePrintMessage.getData().getTickets().get(0).getLogoGif().getText());
//                }
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProResponsePrintMessage, true);
            }

        } else if (object instanceof TicketProResponsePrintEZPLMessage) {
            getBaseActivity().dismissProgress();
            TicketProResponsePrintEZPLMessage ticketProResponsePrintEZPLMessage = (TicketProResponsePrintEZPLMessage) object;
            if (ticketProResponsePrintEZPLMessage.getEvent().getEventCode().equals("0")) {
                getBaseActivity().createProgress(R.string.gettingTicketProFormattedTickets);
                HTTPGetAsyncTask getAsyncTask = new HTTPGetAsyncTask(getBaseActivity());
                getAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, getBaseActivity(), ticketProResponsePrintEZPLMessage.getData().getTickets());
            } else {
                getBaseActivity().createSystemErrorConfirmation(ticketProResponsePrintEZPLMessage, true);
            }

        } else if (object instanceof byte[]) {
            getBaseActivity().dismissProgress();
            if (getBaseActivity().securePrint) {

                getBaseActivity().ticket = (byte[]) object;
                if (getBaseActivity().checkUSBPrinter()) {
                    getBaseActivity().securePrint();
                }

            } else {
                getBaseActivity().logo = (byte[]) object;

                Bitmap logoBitmap = BitmapFactory.decodeByteArray(getBaseActivity().logo, 0, getBaseActivity().logo.length);

                for (int i = 0; i < getBaseActivity().ticketProResponsePrintMessage.getData().getTickets().size(); i++) {

                    try {
                        ArrayList<CommonResponseLineMessage> output = new ArrayList<>();
                        TicketProResponseTicketMessage ticket = getBaseActivity().ticketProResponsePrintMessage.getData().getTickets().get(i);
                        output.add(getBaseActivity().printLine("H", "TicketPro"));
                        output.add(getBaseActivity().printLine("H", ticket.getName().getText()));
                        if (!ticket.getParentEventName().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getParentEventName().getText()));

                        if (!ticket.getEventName().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getEventName().getText()));
                        if (!ticket.getVenueName().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getVenueName().getText()));
                        if (!ticket.getMediumDate().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getMediumDate().getText()));
                        if (!ticket.getPriceCatLabel().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getPriceCatLabel().getText()));
                        if (!ticket.getEventDateDay().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getEventDateDay().getText()));
                        if (!ticket.getEventDateMonth().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getEventDateMonth().getText()));
                        if (!ticket.getEventDateYear().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getEventDateYear().getText()));
                        if (!ticket.getStartTime().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getStartTime().getText()));
                        //
                        // NB:  Zack says we do NOT add anything to the ticket
                        //
                        if (!ticket.getStand().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getStand().getText()));
                        if (!ticket.getGate().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getGate().getText()));
                        if (!ticket.getEntrance().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getEntrance().getText()));
                        if (!ticket.getBlock().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getBlock().getText()));
                        if (!ticket.getRow().getText().trim().isEmpty())
                            output.add(getBaseActivity().printLine("H", ticket.getRow().getText()));
                        for (int j = 0; j < ticket.getSeats().size(); j++) {
                            if (!ticket.getSeats().get(j).getText().trim().isEmpty())
                                output.add(getBaseActivity().printLine("H", ticket.getSeats().get(j).getText()));
                        }
                        //
                        // do not add duplicates
                        // as per Brian Robinson
                        //

                        for (int j = 0; j < ticket.getTicketIds().size(); j++) {

                            if (j == 0 || (j > 0 && !ticket.getTicketIds().get(j).getText().equals(
                                    ticket.getTicketIds().get(j - 1).getText()))) {
                                output.add(getBaseActivity().printLine("H", ticket.getTicketIds().get(j).getText()));

                            }
                        }
                        output.add(getBaseActivity().printLine("H", ticket.getTransactionNo().getText()));
                        output.add(getBaseActivity().printLine("H", ticket.getTimeStamp().getText()));
                        output.add(getBaseActivity().printLine("H", getResources().getString(R.string.ticketproTCReference)));
                        output.add(getBaseActivity().printLine("H", getResources().getString(R.string.ticketproWebsite)));
                        output.add(getBaseActivity().printLine("H", getResources().getString(R.string.ticketproRefundablePolicy)));
                        //
                        // as per Brian Robinson
                        //
                        output.add(getBaseActivity().printLine("H", convertHex(ticket.getBarcode1().getText())));

                        output.add(getBaseActivity().printLine("O", null));

                        int width = BaseActivity.printWidth * 10;
                        int height = getBaseActivity().BARCODE_HEIGHT_128;
                        if (ticket.getBarcode1().getEncoding().equals("pdf417")) {
                            width = getBaseActivity().BARCODE_WIDTH_PDF417;
                            height = getBaseActivity().BARCODE_HEIGHT_PDF417;
                        }

                        Bitmap bitmap = getBaseActivity().generateBarcode(ticket.getBarcode1().getEncoding(),
                                convertHex(ticket.getBarcode1().getText()),
                                width, height);
                        try {
//                            BaseActivity.smartPrinter.print(logoBitmap, output, bitmap);
                            getBaseActivity().printWithDynamic(logoBitmap, output, bitmap);
                        } catch (Exception exception) {
                            Log.v("TicketPro", "problems printing barcode " + exception);
                        }

                    } catch (Exception exception) {
                        Log.v("TicketPro", "problems encoding barcodes " + exception);
                    }

                }
            }


            getBaseActivity().gotoMainScreen();


        }

        if (object != null && !(object instanceof Socket)) {
            getBaseActivity().firebaseBundle = new Bundle();
            getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            getBaseActivity().mFirebaseAnalytics.logEvent("aeon_connection", getBaseActivity().firebaseBundle);
        }
    }

    @Override
    public boolean onBackPressed() {

        getBaseActivity().gotoFragment(new FragmentTicketProCategories(), "FragmentTicketProCategories");

        return true;
    }
}
