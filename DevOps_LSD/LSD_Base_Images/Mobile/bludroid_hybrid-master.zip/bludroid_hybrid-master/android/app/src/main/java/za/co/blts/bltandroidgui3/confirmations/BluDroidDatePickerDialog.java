package za.co.blts.bltandroidgui3.confirmations;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.DatePicker;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//import android.view.View;

/**
 * Created by NkosanaM on 4/20/2017.
 */

public class BluDroidDatePickerDialog extends BluDroidAlertDialog {


    private Builder dialogBuilder = null;
    private Date mDate;
    private int year, month, day;
    private Calendar calendar;
    private String dateString;
    private DatePicker datePicker;


    public BluDroidDatePickerDialog(BaseActivity context) {
        super(context);
        setUp(context);

    }

    public void setMinDate(long minDate){
        datePicker.setMinDate(minDate);
    }

    public void setMaxDate(long maxDate){
        datePicker.setMaxDate(maxDate);
    }

    public void setUp(BaseActivity context) {

        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialogBuilder = new Builder(context);
        LayoutInflater inflater = context.getLayoutInflater();


        mDate = new Date();

        calendar = Calendar.getInstance();
        calendar.setTime(mDate);
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);

        dateString = formatDate(day, month, year);

        @SuppressLint("InflateParams") View dialogView = inflater.inflate(R.layout.dialog_date_picker, null);
        dialogBuilder.setView(dialogView);

        datePicker = dialogView.findViewById(R.id.dateDayPicker);


        datePicker.init(year, month, day, new DatePicker.OnDateChangedListener() {
            public void onDateChanged(DatePicker view, int year, int month, int day) {
                BluDroidDatePickerDialog.this.year = year;
                BluDroidDatePickerDialog.this.month = month;
                BluDroidDatePickerDialog.this.day = day;

                dateString = formatDate(day, month, year);


                updateDate();
            }


        });


        dialogBuilder.setTitle("Date");


    }

    private String formatDate(int temp_day, int temp_month, int temp_year) {
        String dayTmp;
        if (temp_day < 10) {
            dayTmp = "" + 0 + temp_day;
        } else {
            dayTmp = "" + temp_day;
        }

        String monthTmp;
        if (temp_month < 9) {
            monthTmp = "" + 0 + (temp_month + 1);
        } else {
            monthTmp = "" + (temp_month + 1);
        }
        return dayTmp + "/" + monthTmp + "/" + temp_year;
    }

    public void createDialog() {
        AlertDialog dialog = dialogBuilder.create();
        dialog.show();
    }


    @Override
    public void setNegativeOption(String option, OnClickListener listener) {
        dialogBuilder.setNegativeButton(option, listener);
    }

    @Override
    public void setPositiveOption(String option, OnClickListener listener) {
        dialogBuilder.setPositiveButton(option, listener);
    }

    @Override
    public void setNeutralOption(String option, OnClickListener listener) {
        dialogBuilder.setNeutralButton(option, listener);
    }


    private void updateDate() {
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);

        try {
            calendar.setTime(df.parse(dateString));


            mDate = new GregorianCalendar(year, month, day, 0, 0).getTime();
            // getArguments().putSerializable(EXTRA_DATE, mDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public String getDate() {

        return dateString;
    }

    public String getMillies() {

        return String.valueOf(calendar.getTimeInMillis());
    }

    //----------------------------------------------------------------------------------------------
}
