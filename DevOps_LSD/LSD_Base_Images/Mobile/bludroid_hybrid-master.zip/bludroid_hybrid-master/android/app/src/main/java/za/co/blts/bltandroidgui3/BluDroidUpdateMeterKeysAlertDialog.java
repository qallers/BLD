package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;

import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;

/**
 * Created by NkosanaM on 3/29/2017.
 */

public class BluDroidUpdateMeterKeysAlertDialog extends BluDroidAlertDialog {


    private Builder dialogBuilder = null;

    public BluDroidUpdateMeterKeysAlertDialog(BaseActivity context, String type) {
        super(context);

        if (type.equalsIgnoreCase("new")) {
            setUp(context);
        } else if (type.equalsIgnoreCase("newandold")) {

            setUpNewAndOld(context);
        }
    }

    private void setUp(BaseActivity context) {
        dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = context.getLayoutInflater();
        @SuppressLint("InflateParams") final View dialogView = inflater.inflate(R.layout.alert_dialog_update_meter_keys, null);
        dialogBuilder.setView(dialogView);

        dialogBuilder.setTitle("Update Meter Keys");


    }

    protected void setUp(BaseFragment context) {
        dialogBuilder = new AlertDialog.Builder(context.getActivity());
        LayoutInflater inflater = context.getBaseActivity().getLayoutInflater();
        @SuppressLint("InflateParams") final View dialogView = inflater.inflate(R.layout.alert_dialog_update_meter_keys, null);
        dialogBuilder.setView(dialogView);

        dialogBuilder.setTitle("Update Meter Keys");

    }

    private void setUpNewAndOld(BaseActivity context) {
        dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = context.getLayoutInflater();
        @SuppressLint("InflateParams") final View dialogView = inflater.inflate(R.layout.alert_dialog_update_meter_keys_new_and_old, null);
        dialogBuilder.setView(dialogView);

        dialogBuilder.setTitle("Update Meter Keys");


    }

    public void createDialog() {

        AlertDialog dialog = dialogBuilder.create();

        dialog.show();


    }


    @Override
    public void setNegativeOption(String option, DialogInterface.OnClickListener listener) {
        dialogBuilder.setNegativeButton(option, listener);
    }

    @Override
    public void setPositiveOption(String option, DialogInterface.OnClickListener listener) {
        dialogBuilder.setPositiveButton(option, listener);
    }

    @Override
    public void setNeutralOption(String option, DialogInterface.OnClickListener listener) {
        dialogBuilder.setNeutralButton(option, listener);
    }


}
