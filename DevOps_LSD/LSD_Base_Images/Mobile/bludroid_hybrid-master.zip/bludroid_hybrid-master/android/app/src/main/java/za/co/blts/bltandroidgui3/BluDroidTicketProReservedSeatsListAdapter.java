package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseSeatMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 4/5/2017.
 */

class BluDroidTicketProReservedSeatsListAdapter extends ArrayAdapter<TicketProResponseSeatMessage> {
    private final String TAG = this.getClass().getSimpleName();

    private ArrayList<TicketProResponseSeatMessage> dataSet;

    private WeakReference<BaseActivity> baseActivityWeakReference;


    private LayoutInflater inflater;

    public BluDroidTicketProReservedSeatsListAdapter(BaseActivity context, int layoutResourceId, ArrayList<TicketProResponseSeatMessage> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.dataSet = dataSet;
        this.baseActivityWeakReference = new WeakReference<>(context);

        inflater = LayoutInflater.from(context);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            final TicketProResponseSeatMessage reservedSeat = getItem(position);

            final BluDroidTicketProReservedSeatsListAdapter.ViewHolder holder;
            if (convertView == null) {

                holder = new BluDroidTicketProReservedSeatsListAdapter.ViewHolder();

                convertView = inflater.inflate(R.layout.ticketpro_reserved_seat_row_item, parent, false);
                holder.txtHeading = convertView.findViewById(R.id.eventName);
                holder.txtVenue = convertView.findViewById(R.id.venue);
                holder.txtDatetime = convertView.findViewById(R.id.datetime);
                holder.txtSeatlabel = convertView.findViewById(R.id.seatLabel);
                holder.txtprice = convertView.findViewById(R.id.fare);
                holder.txtseatCategory = convertView.findViewById(R.id.seatCategory);
                holder.imgLogo = convertView.findViewById(R.id.logo);
                holder.imgSelected = convertView.findViewById(R.id.selectSeat);
                convertView.setTag(holder);

            } else {
                holder = (BluDroidTicketProReservedSeatsListAdapter.ViewHolder) convertView.getTag();
            }


            holder.imgSelected.setImageDrawable(baseActivity.getResources().getDrawable(android.R.drawable.ic_menu_delete));
            holder.imgSelected.setColorFilter(baseActivity.getResources().getColor(android.R.color.holo_red_dark),
                    android.graphics.PorterDuff.Mode.MULTIPLY);


            holder.imgSelected.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(TAG, "Remove From Cart");
                    baseActivity.removeTicketProItem(reservedSeat.getInventoryId());
                    dataSet.remove(reservedSeat);
                    baseActivity.ticketProResponseReservedSeatsMessage.getData().getSeats().remove(reservedSeat);
                    baseActivity.ticketProTotal -= Double.parseDouble(reservedSeat.getPrice());
                    String disp = "R" + baseActivity.df2.format(baseActivity.ticketProTotal);
                    FragmentTicketProViewCart.txtAmountDue.setText(disp);
                    FragmentTicketProViewCart.txtNumTickets.setText(String.valueOf(dataSet.size()));
                    notifyDataSetChanged();
                }
            });

            String heading = reservedSeat.getEventName();
            String venue = reservedSeat.getVenue();
            String datetime = reservedSeat.getStartDate();
            String seatLabel = reservedSeat.getSectionName();
            String price = reservedSeat.getPrice();
            String category = reservedSeat.getSeatCatName();

            holder.txtHeading.setText(heading);
            holder.txtVenue.setText(venue);
            holder.txtDatetime.setText(datetime);
            holder.txtSeatlabel.setText(seatLabel);
            holder.txtseatCategory.setText(category);
            holder.txtprice.setText(price);

            holder.imgLogo.setTag(baseActivity.ticketProResponseEventDetailsMessage.getData().getSmallImage());

            if (holder.imgLogo != null) {
                Picasso picasso = Picasso.get();
                picasso.setIndicatorsEnabled(baseActivity.isDebug());
                picasso
                        .load(baseActivity.ticketProResponseEventDetailsMessage.getData().getSmallImage())
                        .placeholder(R.drawable.ticketpro_loading)
                        .error(R.drawable.ticketpro_loading)
                        .into(holder.imgLogo);
            }
        }
        return convertView;
    }

    static class ViewHolder {
        BluDroidTextView txtHeading;
        BluDroidTextView txtVenue;
        BluDroidTextView txtDatetime;
        BluDroidTextView txtSeatlabel;
        BluDroidTextView txtprice;
        BluDroidTextView txtseatCategory;
        ImageView imgLogo;
        ImageView imgSelected;
    }


}

