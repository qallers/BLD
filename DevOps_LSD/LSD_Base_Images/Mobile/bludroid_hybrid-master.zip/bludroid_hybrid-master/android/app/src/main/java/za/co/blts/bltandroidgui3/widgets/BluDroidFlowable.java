package za.co.blts.bltandroidgui3.widgets;

import android.view.View;

public interface BluDroidFlowable {

    void flow(View view);

}

