package za.co.blts.bltandroidgui3.confirmations;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

/**
 * Created by NkosanaM on 3/22/2017.
 */

public class BluDroidAlertDialog extends AlertDialog {
    public BluDroidAlertDialog(Context context) {
        super(context);
        setCancelable(false);
    }

    public void setNegativeOption(String option, DialogInterface.OnClickListener listener) {
        setButton(BUTTON_NEGATIVE, option, listener);
    }

    public void setPositiveOption(String option, DialogInterface.OnClickListener listener) {
        setButton(BUTTON_POSITIVE, option, listener);
    }

    public void setNeutralOption(String option, DialogInterface.OnClickListener listener) {
        setButton(BUTTON_NEUTRAL, option, listener);
    }


}
