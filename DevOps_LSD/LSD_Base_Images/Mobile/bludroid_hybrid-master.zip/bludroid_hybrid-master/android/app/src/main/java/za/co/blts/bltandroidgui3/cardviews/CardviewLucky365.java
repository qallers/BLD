package za.co.blts.bltandroidgui3.cardviews;

import za.co.blts.bltandroidgui3.R;

public class CardviewLucky365 extends CardviewDataObject {

    public CardviewLucky365(String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.lucky365,
                R.color.lucky365,
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(hasAirtimePlus);
    }

    public String getBundlesName() {
        return this.getTag() + "Bundles";
    }

    public String getTopupName() {
        return this.getTag();
    }
}

