package za.co.blts.bltandroidgui3;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidMeterNumberEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.magcard.BluDroidMagCardAsyncReponse;

import static android.view.View.GONE;

/**
 * Created by NkosanaM on 3/29/2017.
 */

public class BluDroidUpdateEskomMeterKeysDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, BluDroidMagCardAsyncReponse {

    public void setup() {
        super.setup();
        setAffirmativeButtonLabel(R.string.update);
        hideView(R.id.neutralButton);
        setNegativeButtonLabel(R.string.cancel);
        setHeading("Update Meter Keys");

        BluDroidButton swipeCard = findViewById(R.id.swipeCard);

        if (baseActivity.openMagEncoder()) {

            baseActivity.magCard.setDelegate(this);
            swipeCard.setVisibility(View.VISIBLE);

            swipeCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    BaseActivity.logger.info(((BluDroidButton) v).getText());
                    baseActivity.magCard.openUsbSerial();
                    baseActivity.createMagEncoderAlertDialog("Mag Card", "Please swipe card to read");
                    baseActivity.magCard.sendReadCommand();
                    baseActivity.magCardAction = "read";
                }
            });
        } else {
            swipeCard.setVisibility(GONE);
        }

        setupSpinner();

        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private void setupSpinner() {
        final Spinner meterNumberSpinner = findViewById(R.id.meterNumberSpinner);
        final BluDroidLinearLayout buttonLayout = findViewById(R.id.buttonLay);
        final BluDroidMeterNumberEditText meterNumber = findViewById(R.id.meterNumber);

        final List<String> meterNumbers = new ArrayList<>();

        if (checkCustomerProfileAccountNumbers(meterNumbers)) {
            meterNumbers.add(0, "Other");
            meterNumberSpinner.setVisibility(View.VISIBLE);
            buttonLayout.setVisibility(View.GONE);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(baseActivity, android.R.layout.simple_spinner_item, meterNumbers);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            meterNumberSpinner.setAdapter(dataAdapter);
            //although meterNumber is hidden, update this with the selected spinner value, so the dialog.validate() will pass
            meterNumber.setText(meterNumbers.get(1));
            meterNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i == 0) {
                        onNothingSelected(null);
                    } else {
                        meterNumber.setText(meterNumbers.get(i));
                        buttonLayout.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    meterNumber.setText("");
                    buttonLayout.setVisibility(View.VISIBLE);
                }
            });
            meterNumberSpinner.setSelection(1);

        } else {
            meterNumberSpinner.setVisibility(View.GONE);
            buttonLayout.setVisibility(View.VISIBLE);
        }

    }

    private boolean checkCustomerProfileAccountNumbers(List<String> accountNumbers) {
        if (BaseActivity.consumerProfile != null && baseActivity.customerProfileElectricityAccountNumbers != null) {
            String[] accounts = baseActivity.customerProfileElectricityAccountNumbers.get("EskomDirect");
            if (accounts != null && accounts.length > 0) {
                accountNumbers.addAll(Arrays.asList(accounts));
                return true;
            }
        }
        return false;
    }

    public BluDroidUpdateEskomMeterKeysDialog(BaseActivity context) {
        super(context, R.layout.dialog_update_eskom_meter_keys);
        setup();
        String TAG = this.getClass().getSimpleName();
        Log.d(TAG, "update meter keys");
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public String getMeterNumber() {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            return meterEditText.getText().toString();
        } else {
            return "";
        }
    }

    private void setMeterNumber(String meterNumber) {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setText(meterNumber);
        }
    }


    public void setMeterNumberErrorMessage(String errorMessage) {
        BluDroidEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setErrorMessage(errorMessage);
        }
    }

    public String getTt() {
        BluDroidEditText editText = findViewById(R.id.tt);
        if (editText != null) {
            if (editText.getText().toString().isEmpty()) {
                return "0";
            } else {
                return editText.getText().toString();
            }
        } else {
            return "0";
        }
    }

    public String getTi() {
        BluDroidEditText editText = findViewById(R.id.ti);
        if (editText != null) {
            if (editText.getText().toString().isEmpty()) {
                return "0";
            } else {
                return editText.getText().toString();
            }
        } else {
            return "0";
        }
    }

    public String getSgc() {
        BluDroidEditText editText = findViewById(R.id.sgc);
        if (editText != null) {
            if (editText.getText().toString().isEmpty()) {
                return "0";
            } else {
                return editText.getText().toString();
            }
        } else {
            return "0";
        }

    }

    public String getKrn() {
        BluDroidEditText editText = findViewById(R.id.krn);
        if (editText != null) {
            return editText.getText().toString();
        } else {
            return "0";
        }
    }

    public String getAlg() {
        BluDroidEditText editText = findViewById(R.id.aig);
        if (editText != null) {
            if (editText.getText().toString().isEmpty()) {
                return "0";
            } else {
                return editText.getText().toString();
            }
        } else {
            return "0";
        }
    }

    @Override
    public void processFinish(String output) {
        if (baseActivity.alert != null) {
            baseActivity.alert.dismiss();
        }

        if (output.toLowerCase().contains("success")) {
            setMeterNumber(baseActivity.magCard.getTracks().get(1));
        } else {
            baseActivity.createAlertDialog("Mag Encoder", output);
        }
    }

}
