package za.co.blts.bltandroidgui3.confirmations;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMeterNumberEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.magcard.BluDroidMagCardAsyncReponse;

import static android.view.View.GONE;

/**
 * Created by NkosanaM on 3/23/2017.
 */

public class BluDroidFreeBasicElectricityDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, BluDroidMagCardAsyncReponse {
    private final String TAG = this.getClass().getSimpleName();
    public void setup() {
        super.setup();
        hideView(R.id.neutralButton);
        setAffirmativeButtonLabel(R.string.confirm);
        setNegativeButtonLabel(R.string.cancel);
        setHeading("Free Basic Electricity");

        BluDroidButton swipeCard = findViewById(R.id.swipeCard);

        if (baseActivity.openMagEncoder()) {

            baseActivity.magCard.setDelegate(this);

            swipeCard.setVisibility(View.VISIBLE);

            swipeCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    BaseActivity.logger.info(((BluDroidButton) v).getText());
                    baseActivity.magCard.openUsbSerial();
                    baseActivity.createMagEncoderAlertDialog("Mag Card", "Please swipe card to read");
                    baseActivity.magCard.sendReadCommand();
                    baseActivity.magCardAction = "read";
                }
            });
        } else {
            swipeCard.setVisibility(GONE);
        }


        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }

    public BluDroidFreeBasicElectricityDialog(BaseFragment context) {
        super(context, R.layout.dialog_free_basic_electricity);
        setup();
        String TAG = this.getClass().getSimpleName();
        Log.d(TAG, "Purchase confirmation with activity");
        BaseActivity.logger.info(": construction with BaseFragment");
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public String getMeterNumber() {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            return meterEditText.getText().toString();
        } else {
            return "";
        }
    }

    private void setMeterNumber(String meterNumber) {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setText(meterNumber);
        }
    }


    public void setMeterNumberErrorMessage(String errorMessage) {
        BluDroidEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setErrorMessage(errorMessage);
        }
    }

    @Override
    public void processFinish(String output) {
        BaseActivity.logger.info(": processFinish with output: " + output);
        if (baseActivity.alert != null) {
            baseActivity.alert.dismiss();
        }

        if (output.toLowerCase().contains("success")) {
            setMeterNumber(baseActivity.magCard.getTracks().get(1));
        } else {
            baseActivity.createAlertDialog("Mag Encoder", output);
        }
    }
}
