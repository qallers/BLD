package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.ArrayList;

import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.widgets.BluDroidHeading;

/**
 * Created by warrenm on 2016/10/03.
 */

public class FragmentConfirmConfigFavourites extends FavouritesRecycler {

    private final String TAG = this.getClass().getSimpleName();

    private BluDroidHeading noFavourites;

    public FragmentConfirmConfigFavourites() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_confirm_configure_favourites, container, false);
        recycler = rootView.findViewById(R.id.bluRecycler);
        Button saveConfig = rootView.findViewById(R.id.saveConfigFav);
        Button restoreConfig = rootView.findViewById(R.id.restoreConfigFav);

        saveConfig.setBackgroundResource(R.drawable.blu_btn_background);

        ImageButton navUp = rootView.findViewById(R.id.nav_up);
        navUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recycler.smoothScrollBy(0, -100);
            }
        });
        navUp.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                recycler.smoothScrollToPosition(0);
                return false;
            }
        });

        ImageButton navDown = rootView.findViewById(R.id.nav_down);
        navDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recycler.smoothScrollBy(0, 100);
            }
        });
        navUp.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                recycler.smoothScrollToPosition(listOfCardItems.size());
                return false;
            }
        });

        saveConfig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((Button) v).getText());
                ArrayList<String> favourites = new ArrayList<>();
                for (CardviewDataObject object : listOfCardItems) {

                    if (!object.getCardDesc().equals("Add")) {
                        String textDesc = object.getCardDesc();
                        String textValue = object.getCardValue();
                        String stockId = object.getStockId();
                        String voucherType = object.getVoucherType();
                        String tag = object.getTag();
                        String voucherTypeDesc = object.getVoucherTypeDesc();
                        String provider = object.getProvider();

                        String strData;

                        if (textValue == null || stockId == null || tag == null || voucherTypeDesc == null) {
                            strData = ((textDesc.isEmpty()) ? "N/A" : textDesc)
                                    + ";" + "N/A"
                                    + ";" + "N/A"
                                    + ";" + "Menu"
                                    + ";" + "N/A"
                                    + ";" + "N/A"
                                    + ";" + "N/A";
                        } else if (object.isMVNO()) {
                            provider = object.getSupplierCode();
                            strData = ((textDesc.isEmpty()) ? "N/A" : textDesc)
                                    + ";" + ((textValue.isEmpty()) ? "N/A" : textValue)
                                    + ";" + ((stockId.isEmpty()) ? "N/A" : stockId)
                                    + ";" + ((voucherType.isEmpty()) ? "N/A" : voucherType)
                                    + ";" + ((textDesc.isEmpty()) ? "N/A" : textDesc)
                                    + ";" + ((voucherTypeDesc.isEmpty()) ? "N/A" : voucherTypeDesc)
                                    + ";" + ((provider == null) ? "N/A" : provider); // I need to change this to just object.getSupplierCode()
                        } else {
                            strData = ((textDesc.isEmpty()) ? "N/A" : textDesc)
                                    + ";" + ((textValue.isEmpty()) ? "N/A" : textValue)
                                    + ";" + ((stockId.isEmpty()) ? "N/A" : stockId)
                                    + ";" + ((voucherType.isEmpty()) ? "N/A" : voucherType)
                                    + ";" + ((tag.isEmpty()) ? "N/A" : tag)
                                    + ";" + ((voucherTypeDesc.isEmpty()) ? "N/A" : voucherTypeDesc)
                                    + ";" + ((provider == null) ? "N/A" : provider);
                        }

                        favourites.add(strData);

                        Log.v(TAG, strData);
                    }
                }
                getBaseActivity().updateFavouritesListOrder(favourites);
                getBaseActivity().createNotification("Favourites list updated.");
                getBaseActivity().gotoMainScreen();
            }
        });

        restoreConfig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((Button) v).getText());
                getBaseActivity().restoreDefaultFavouritesList();
                getBaseActivity().createDefaultFavouritesList();
                getBaseActivity().createNotification("Favourites list restored.");
                getBaseActivity().gotoMainScreen();
            }
        });
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        String title = getActivity().getResources().getString(R.string.sort_favourites);
        getActivity().setTitle(title);

        noFavourites = getActivity().findViewById(R.id.noFavourites);

        populateScreen();
    }

    private void populateScreen() {
        canDrag = true;
        setupRecycler();

        if (favouritesSize > 0) {
            noFavourites.setVisibility(View.GONE);
        } else {
            noFavourites.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onBackPressed() {
        getBaseActivity().gotoMainScreen();
        return true;
    }
}