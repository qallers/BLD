package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.ScrollView;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidScrollView extends ScrollView implements BluDroidValidatable, BluDroidSetupable {
    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference = null;

    public BluDroidScrollView(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    public BluDroidScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (context instanceof BaseActivity) {
            this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
        }
    }

    public boolean validate() {
        //BaseActivity.logger.info(": validate()");
        Log.d(TAG, "validate");
        boolean returnValue = true;
        for (int i = 0; i < getChildCount(); i++) {
            View view = getChildAt(i);
            if (view instanceof BluDroidValidatable) {
                returnValue = ((BluDroidValidatable) view).validate() && returnValue;
            }
        }
        return returnValue;
    }


    public void setup() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                this.setBackground(new ColorDrawable(baseScreen.getSkinResources().getBackgroundColor()));
                for (int i = 0; i < getChildCount(); i++) {
                    View view = getChildAt(i);
                    if (view instanceof BluDroidSetupable) {
                        BluDroidSetupable setupable = (BluDroidSetupable) view;
                        setupable.setContext(baseScreen);
                        setupable.setup();
                    }
                }
            }
        }
    }

    public void setContext(BaseActivity context) {
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

}

