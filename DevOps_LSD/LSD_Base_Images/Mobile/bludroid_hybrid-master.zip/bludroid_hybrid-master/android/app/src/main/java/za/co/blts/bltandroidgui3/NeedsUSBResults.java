package za.co.blts.bltandroidgui3;

//
// needs results from USB
//
@SuppressWarnings("unused")
interface NeedsUSBResults {

    void results(Object object);

    void error(Object object);

}
