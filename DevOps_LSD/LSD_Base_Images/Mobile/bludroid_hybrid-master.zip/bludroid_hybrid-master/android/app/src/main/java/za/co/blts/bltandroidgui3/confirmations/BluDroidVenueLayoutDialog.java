package za.co.blts.bltandroidgui3.confirmations;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidHeading;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;

/**
 * Created by NkosanaM on 3/23/2017.
 */

public class BluDroidVenueLayoutDialog extends BluDroidConfirmationDialog implements BluDroidSetupable {

    public void setup() {
        super.setup();
        setHeading(baseActivity.ticketProResponseEventDetailsMessage.getData().getVenueName());
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        hideKeyboard();


    }

    public BluDroidVenueLayoutDialog(BaseActivity context) {
        super(context, R.layout.dialog_venue_layout);
        setup();

        ImageView layoutImageView = findViewById(R.id.venueLayoutImage);
        layoutImageView.setTag(baseActivity.ticketProResponseEventDetailsMessage.getData().getStadiumBackground());
        BluDroidHeading noLayout = findViewById(R.id.noLayout);

        if (layoutImageView != null) {

            if (baseActivity.ticketProResponseEventDetailsMessage != null && !baseActivity.ticketProResponseEventDetailsMessage.getData().getStadiumBackground().isEmpty()) {

                Picasso picasso = Picasso.get();
                picasso.setIndicatorsEnabled(baseActivity.isDebug());
                picasso
                        .load(baseActivity.ticketProResponseEventDetailsMessage.getData().getStadiumBackground())
                        .placeholder(R.drawable.ticketpro_loading)
                        .error(R.drawable.ticketpro_loading)
                        .into(layoutImageView);

            } else {
                noLayout.setVisibility(View.VISIBLE);
            }

        }

        hideKeyboard();
        Log.d(TAG, "Purchase confirmation with activity");
    }

    private void hideKeyboard() {
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

}
