package za.co.blts.bltandroidgui3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by WarrenM1 on 2017/06/20.
 */

class CalculateChangeListAdapter extends BaseAdapter /*implements View.OnClickListener*/ {


    private ArrayList<CalculateChangeDataModel> dataSet;
    private WeakReference<BaseActivity> baseActivityWeakReference;
    private LayoutInflater inflater;


    public CalculateChangeListAdapter(ArrayList<CalculateChangeDataModel> dataSet, BaseActivity context) {
        this.baseActivityWeakReference = new WeakReference<>(context);
        this.dataSet = dataSet;
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return dataSet.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        if (convertView == null) {
            vi = inflater.inflate(R.layout.item_calculator, parent, false);
        }
        BluDroidTextView txtProvider = vi.findViewById(R.id.txtProvider);
        BluDroidTextView txtVoucherType = vi.findViewById(R.id.txtVoucherType);
        BluDroidTextView txtAmount = vi.findViewById(R.id.txtAmount);
        BluDroidTextView txtCanCalculate = vi.findViewById(R.id.txtCanCalculate);
        ImageView iconSelected = vi.findViewById(R.id.selectProduct);

        //voucherInfo.setTag(position);

        CalculateChangeDataModel dataModel = dataSet.get(position);

        txtProvider.setText(dataModel.getProvider());
        txtVoucherType.setText(dataModel.getVoucherType());
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            String disp = baseActivity.getResources().getString(R.string.amount) + " "
                    + baseActivity.getResources().getString(R.string.currency) + " "
                    + baseActivity.df2.format(dataModel.getAmount());
            txtAmount.setText(disp);
        }
        txtCanCalculate.setText(String.valueOf(dataModel.canCalculate()));
        iconSelected.setImageResource(dataModel.getIconSelected());

        if (dataModel.getVoucherType().isEmpty()) {
            txtVoucherType.setVisibility(View.GONE);
        }
        // Return the completed view to render on screen
        return vi;
    }

}
