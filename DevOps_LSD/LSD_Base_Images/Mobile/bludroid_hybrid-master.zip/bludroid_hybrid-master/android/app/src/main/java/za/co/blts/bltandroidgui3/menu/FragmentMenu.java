package za.co.blts.bltandroidgui3.menu;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.FragmentAirtime;
import za.co.blts.bltandroidgui3.FragmentData;
import za.co.blts.bltandroidgui3.FragmentElectricity;
import za.co.blts.bltandroidgui3.FragmentFavourites;
import za.co.blts.bltandroidgui3.FragmentRicaLogin;
import za.co.blts.bltandroidgui3.FragmentSearch;
import za.co.blts.bltandroidgui3.FragmentTickets;
import za.co.blts.bltandroidgui3.FragmentTransact;
import za.co.blts.bltandroidgui3.FragmentVouchersMenu;
import za.co.blts.bltandroidgui3.ItemOffsetDecoration;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluRecyclerView;
import za.co.blts.reactnative.FragmentCrossBorder;

public class FragmentMenu extends BaseFragment implements BluMenuRecyclerAdapter.ItemClickListener {
    private final String TAG = this.getClass().getSimpleName();

    private BluMenuRecyclerAdapter adapter;
    private BluRecyclerView recyclerView;
    private List<MenuPageButton> buttons;

    public FragmentMenu() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getBaseActivity().toolbar.setTitle("Menu");
        getBaseActivity().toolbar.setNavigationBackIcon();
        getBaseActivity().toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoFavourites();
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_menu, container, false);

        GridLayoutManager grid;
        if (getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            grid = new GridLayoutManager(getContext(), 4);
        } else {
            grid = new GridLayoutManager(getContext(), 3);
        }

        RecyclerView.LayoutManager manager = grid;
        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getContext(), R.dimen.item_offset);
        recyclerView = rootView.findViewById(R.id.buttonRecycler);
        recyclerView.addItemDecoration(itemDecoration);
        recyclerView.setLayoutManager(manager);

        setButtons();

        adapter = new BluMenuRecyclerAdapter(((BaseActivity) getContext()), buttons);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);


        return rootView;
    }

    private void setButtons() {
        buttons = new ArrayList<>();

        for (String key : BaseActivity.menuMap.keySet()) {
            int menuIcon = getResources().getIdentifier(key.toLowerCase().replaceAll(" ", ""), "drawable", getContext().getPackageName());
            if (menuIcon > 0) {
                Log.i(TAG, "add to menu: " + key);
                buttons.add(new MenuPageButton(key, menuIcon));
            } else {
                Log.w(TAG, "icon not found for: " + key);
            }
        }
    }

    @Override
    public void onItemClick(int position) {
        getBaseActivity().resetTimer();
        getBaseActivity().navigatedFromFavourites = false;
        getBaseActivity().navigatedFromSearch = false;
        switch (adapter.getItem(position).getLabel()) {
            case "Favourites":
                gotoFavourites();
                break;

            case "Airtime":
                gotoAirtime();
                break;

            case "Data":
                gotoData();
                break;

            case "Electricity":
                gotoElectricity();
                break;

            case "Transact":
                gotoTransact();
                break;

            case "Vouchers":
                gotoVouchers();
                break;

            case "Tickets":
                gotoTickets();
                break;

            case "Rica":
                gotoRica();
                break;

            case "Search":
                gotoSearch();
                break;

            case "Cross Border":
                gotoCrossBorder();
                break;

        }
    }

    private void gotoFavourites() {
        getBaseActivity().navigatedFromFavourites = true;
        ((BaseActivity) getContext()).isBillPaymentScreen = false;
        Fragment fragment = new FragmentFavourites();
        ((BaseActivity) getContext()).baseFm.beginTransaction().replace(R.id.content_frame, fragment, fragment.getClass().getSimpleName()).commit();
    }

    private void gotoAirtime() {
        ((BaseActivity) getContext()).isBillPaymentScreen = false;
        Fragment fragment = new FragmentAirtime();
        ((BaseActivity) getContext()).baseFm.beginTransaction().replace(R.id.content_frame, fragment, fragment.getClass().getSimpleName()).commit();
    }

    private void gotoData() {
        ((BaseActivity) getContext()).isBillPaymentScreen = false;
        Fragment fragment = new FragmentData();
        ((BaseActivity) getContext()).baseFm.beginTransaction().replace(R.id.content_frame, fragment, fragment.getClass().getSimpleName()).commit();
    }

    private void gotoElectricity() {
        ((BaseActivity) getContext()).isBillPaymentScreen = false;
        Fragment fragment = new FragmentElectricity();
        ((BaseActivity) getContext()).baseFm.beginTransaction().replace(R.id.content_frame, fragment, fragment.getClass().getSimpleName()).commit();
    }

    private void gotoTransact() {
        ((BaseActivity) getContext()).isBillPaymentScreen = true;
        Fragment fragment = new FragmentTransact();
        ((BaseActivity) getContext()).baseFm.beginTransaction().replace(R.id.content_frame, fragment, fragment.getClass().getSimpleName()).commit();
    }

    private void gotoVouchers() {
        ((BaseActivity) getContext()).isBillPaymentScreen = false;
        Fragment fragment = new FragmentVouchersMenu();
        ((BaseActivity) getContext()).baseFm.beginTransaction().replace(R.id.content_frame, fragment, fragment.getClass().getSimpleName()).commit();
    }

    private void gotoTickets() {
        ((BaseActivity) getContext()).isTesting = false;
        ((BaseActivity) getContext()).isBillPaymentScreen = false;
        Fragment fragment = new FragmentTickets();
        ((BaseActivity) getContext()).baseFm.beginTransaction().replace(R.id.content_frame, fragment, fragment.getClass().getSimpleName()).commit();
    }

    private void gotoRica() {
        ((BaseActivity) getContext()).isBillPaymentScreen = false;
        Fragment fragment = new FragmentRicaLogin();
        ((BaseActivity) getContext()).baseFm.beginTransaction().replace(R.id.content_frame, fragment, fragment.getClass().getSimpleName()).commit();
    }

    private void gotoSearch() {
        getBaseActivity().navigatedFromSearch = true;
        ((BaseActivity) getContext()).isBillPaymentScreen = false;
        Fragment fragment = new FragmentSearch();
        ((BaseActivity) getContext()).baseFm.beginTransaction().replace(R.id.content_frame, fragment, fragment.getClass().getSimpleName()).commit();
    }

    private void gotoCrossBorder() {
        ((BaseActivity) getContext()).isBillPaymentScreen = false;
        Fragment fragment = new FragmentCrossBorder();
        ((BaseActivity) getContext()).baseFm.beginTransaction().replace(R.id.content_frame, fragment, fragment.getClass().getSimpleName()).commit();
    }

    @Override
    public boolean onBackPressed() {
        gotoFavourites();
        return true;
    }
}