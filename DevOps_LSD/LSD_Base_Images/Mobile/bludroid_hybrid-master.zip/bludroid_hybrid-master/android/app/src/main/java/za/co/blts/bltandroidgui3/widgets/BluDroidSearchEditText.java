package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputType;
import android.util.AttributeSet;
import android.view.Gravity;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 2/17/2017.
 */

public class BluDroidSearchEditText extends BluDroidEditText {

    private void setUpSearch() {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            Drawable searchicon = getResources().getDrawable(R.drawable.search_black);
            searchicon.setColorFilter(baseScreen.getSkinResources().getButtonColor(), PorterDuff.Mode.SRC_IN);
            setCompoundDrawablesWithIntrinsicBounds(null, null, searchicon, null);
            setGravity(Gravity.LEFT);
            setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        }
    }

    public BluDroidSearchEditText(BaseActivity context) {
        super(context);
        setUpSearch();
    }

    public BluDroidSearchEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpSearch();
    }
}
