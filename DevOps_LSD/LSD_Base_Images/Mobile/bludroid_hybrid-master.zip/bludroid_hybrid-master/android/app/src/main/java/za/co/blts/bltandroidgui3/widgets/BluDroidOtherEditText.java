package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/8/2017.
 */

public class BluDroidOtherEditText extends BluDroidEditText {

    private final String TAG = this.getClass().getSimpleName();
    private String fieldName;
    private int minCharacterCount;
    private int maxCharacterCount;


    public BluDroidOtherEditText(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray attributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidOtherEditText);

        try {
            fieldName = attributesArray.getString(R.styleable.BluDroidOtherEditText_otherFieldName);
            minCharacterCount = attributesArray.getInt(R.styleable.BluDroidOtherEditText_minLength, Integer.MAX_VALUE);
            maxCharacterCount = attributesArray.getInt(R.styleable.BluDroidOtherEditText_maxLength, Integer.MAX_VALUE);
        } catch (Exception e) {
            e.printStackTrace();
        }
        attributesArray.recycle();
    }

    public BluDroidOtherEditText(BaseActivity context) {
        super(context);
    }

    @Override
    public boolean validate() {
        //BaseActivity.logger.info(": validate()");
        Log.d(TAG, "validate Other");


        String text = getText().toString().trim();
        boolean isvalidated = false;
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {

            if (fieldName.equals("Vat reg no.")) {
                if (text.length() == 0 || (text.length() == maxCharacterCount)) {
                    isvalidated = true;
                } else {
                    baseScreen.storeSettingsHaserrors = true;
                    setErrorMessage(String.format(baseScreen.getResources().getString(R.string.vatRegNoError), maxCharacterCount));

                }

            } else if (fieldName.contains("Rica")) {
                if (text.length() > maxCharacterCount || text.length() < minCharacterCount) {
                    isvalidated = false;
                    setErrorMessage(baseScreen.getResources().getString(R.string.invalid_length));
                } else {
                    isvalidated = true;
                    removeErrorMessage();
                }

            } else if (fieldName.equalsIgnoreCase("passport")) {
                if (getVisibility() == VISIBLE) {
                    if (text.length() > maxCharacterCount || text.length() < minCharacterCount) {
                        isvalidated = false;
                        setErrorMessage(baseScreen.getResources().getString(R.string.invalid_passport_length));
                    } else {
                        isvalidated = true;
                        removeErrorMessage();
                    }
                } else {
                    isvalidated = true;
                }

            } else {
                if (text.length() == 0 || (text.length() >= minCharacterCount && text.length() <= maxCharacterCount)) {
                    isvalidated = true;
                } else {
                    if (fieldName.equalsIgnoreCase("store name") || fieldName.equalsIgnoreCase("Address")) {
                        baseScreen.storeSettingsHaserrors = true;
                    }
                    isvalidated = false;
                    setErrorMessage(String.format(baseScreen.getResources().getString(R.string.OtherInputError), fieldName, minCharacterCount, maxCharacterCount));
                }
            }
        }
        return isvalidated;
    }
}
