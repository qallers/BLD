package za.co.blts.bltandroidgui3.cardviews;

import android.app.Activity;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewCellC extends CardviewDataObject {

    public CardviewCellC(Activity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.cellc,
                baseActivity.getResources().getColor(R.color.cellc),
                stockId, voucherType, tag);
        super.setHasAirtimePlus(hasAirtimePlus);

    }

    public CardviewCellC(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.cellc,
                baseActivity.getResources().getColor(R.color.cellc),
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(hasAirtimePlus);

    }

    public CardviewCellC(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus, boolean isMvno) {
        super(cardDesc, cardValue,
                R.drawable.cellc,
                baseActivity.getResources().getColor(R.color.cellc),
                stockId, voucherType, tag, voucherTypeDesc);

        super.setHasAirtimePlus(hasAirtimePlus);
        super.setMVNO(isMvno);

    }

    public String getSupplierCode() {
        return "3";
    }

    public String getBundlesName() {
        return "CellCBundles";
    }

    public String getTopupName() {
        return "CellC";
    }

}

