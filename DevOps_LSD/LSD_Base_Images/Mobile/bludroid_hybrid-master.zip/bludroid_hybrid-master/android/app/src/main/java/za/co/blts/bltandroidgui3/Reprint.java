package za.co.blts.bltandroidgui3;

/**
 * Created by NkosanaM on 4/21/2017.
 */

class Reprint {

    private String voucherType;
    private String date;
    private String amount;
    private String id;
    private String ref;

    Reprint() {

    }

    public Reprint(String voucherType, String date, String amount, String id, String ref) {
        this.voucherType = voucherType;
        this.date = date;
        this.amount = amount;
        this.id = id;
        this.ref = ref;
    }

    Reprint(String voucherType, String date, String amount) {
        this.voucherType = voucherType;
        this.date = date;
        this.amount = amount;
    }

    public String getVoucherType() {
        return voucherType;
    }

    public void setVoucherType(String voucherType) {
        this.voucherType = voucherType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
