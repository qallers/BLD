package za.co.blts.bltandroidgui3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by MasiS on 4/3/2018.
 */

class BluDroidPlacesAdapter extends ArrayAdapter<String> {
    private Context context;
    //int resource;
    private ArrayList<String> items;
    private Filter nameFilter;

    public BluDroidPlacesAdapter(Context context, int textViewResourceId, ArrayList<String> items) {
        super(context, textViewResourceId, items);
        this.context = context;
        this.items = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.places_row, parent, false);
        }
        String place = items.get(position);
        if (place != null) {
            TextView lblName = view.findViewById(R.id.lbl_name);
            if (lblName != null)
                lblName.setText(place);
        }
        return view;
    }

    @Override
    public Filter getFilter() {

        if (nameFilter == null)
            nameFilter = new BluDroidPlacesAdapter.CityListFilter<>(items);

        return nameFilter;
    }

    /**
     * Custom Filter implementation for custom suggestions we provide.
     */


    class CityListFilter<T> extends Filter {

        private ArrayList<T> sourceObjects;

        CityListFilter(ArrayList<T> objects) {
            sourceObjects = new ArrayList<>();
            synchronized (this) {
                sourceObjects.addAll(objects);
            }
        }


        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            FilterResults filterResults = new FilterResults();
            ArrayList<T> filter = new ArrayList<>();

            if (constraint != null) {

                for (T place : sourceObjects) {
                    if (place.toString().toLowerCase().contains(constraint.toString().toLowerCase())) {
                        filter.add(place);
                    }
                }

                filterResults.values = filter;
                filterResults.count = filter.size();
                return filterResults;
            } else {
                synchronized (this) {
                    filterResults.values = sourceObjects;
                    filterResults.count = sourceObjects.size();
                }
            }

            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            @SuppressWarnings("unchecked")
            List<String> filterList = (ArrayList<String>) results.values;
            if (results.count > 0) {
                clear();

                for (String place : filterList) {
                    add(place);
                }
                notifyDataSetChanged();
            }
        }

        @Override
        public CharSequence convertResultToString(Object resultValue) {
            return ((String) resultValue);
        }
    }

}

