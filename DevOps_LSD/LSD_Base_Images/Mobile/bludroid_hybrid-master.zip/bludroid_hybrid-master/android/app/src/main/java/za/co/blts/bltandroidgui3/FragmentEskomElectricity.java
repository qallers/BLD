package za.co.blts.bltandroidgui3;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class FragmentEskomElectricity extends EskomTabRecycler {
    private final String TAG = this.getClass().getSimpleName();


    public FragmentEskomElectricity() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_eskom_electricity, container, false);
        getActivity().setTitle("Eskom");
        tabs = rootView.findViewById(R.id.tabLayout);

        viewPager = rootView.findViewById(R.id.viewpager);
        getBaseActivity().hideKeyboard();

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public boolean onBackPressed() {
        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentElectricity(), "FragmentElectricity").commit();
        }
        return true;
    }


}


