package za.co.blts.bltandroidgui3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 4/5/2017.
 */

class BluDroidPutcoTripsListAdapter extends ArrayAdapter<PutcoTrip> implements View.OnClickListener {


    private WeakReference<BaseActivity> baseActivityWeakReference;
    private int layoutResourceId;

    public BluDroidPutcoTripsListAdapter(BaseActivity context, int layoutResourceId, ArrayList<PutcoTrip> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.layoutResourceId = layoutResourceId;
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    @Override
    public void onClick(View v) {
        BaseActivity.logger.info(((BluDroidButton) v).getText());

        //selectedPosition= Integer.parseInt(v.getTag().toString());


    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        PutcoTrip trip = getItem(position);


        if (convertView == null) {

            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(layoutResourceId, parent, false);
        }


        ImageView selected = convertView.findViewById(R.id.selectTrip);


        String travelClass = trip.getTravelClass();
        String fare = trip.getFare();
        int iconSelected = trip.getIconSelected();


        BluDroidTextView txtClass = convertView.findViewById(R.id.travelClass);
        BluDroidTextView txtFare = convertView.findViewById(R.id.fare);


        String NEED_WORD = "Day";
        if (travelClass.equals("1")) {
            travelClass = travelClass.concat(" " + NEED_WORD);
        } else {
            travelClass = travelClass.concat(" " + NEED_WORD + "s");
        }

        txtClass.setText(travelClass);
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            String disp = baseActivity.getResources().getString(R.string.amount) + " : " + baseActivity.getResources().getString(R.string.currency) + "" + fare;
            txtFare.setText(disp);
        }
        selected.setImageResource(iconSelected);


        return convertView;
    }

}

