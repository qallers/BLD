package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidLinearLayout extends LinearLayout implements BluDroidValidatable, BluDroidSetupable {
    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference = null;

    public void setContext(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    public void setup() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                this.setBackground(new ColorDrawable(baseActivity.getSkinResources().getBackgroundColor()));
                for (int i = 0; i < getChildCount(); i++) {
                    View view = getChildAt(i);
                    if (view instanceof BluDroidSetupable) {
                        BluDroidSetupable setupable = (BluDroidSetupable) view;
                        setupable.setContext(baseActivity);
                        setupable.setup();
                    }
                }
            }
        }
    }

    public BluDroidLinearLayout(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setup();
    }

    public BluDroidLinearLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (context instanceof BaseActivity) {
            try {
                this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
                setup();
            } catch (Exception ignored) {
            }
        }
    }

    public boolean validate() {
        Log.d(TAG, "validate");
        //BaseActivity.logger.info(": validate()");
        boolean returnValue = true;
        for (int i = 0; i < getChildCount(); i++) {
            View view = getChildAt(i);
            if (view instanceof BluDroidValidatable) {
                returnValue = ((BluDroidValidatable) view).validate() && returnValue;
            }

        }
        return returnValue;
    }

}

