package za.co.blts.bltandroidgui3.widgets;

import za.co.blts.bltandroidgui3.BaseActivity;

public interface BluDroidSetupable {

    void setup();

    void setContext(BaseActivity baseActivity);

}

