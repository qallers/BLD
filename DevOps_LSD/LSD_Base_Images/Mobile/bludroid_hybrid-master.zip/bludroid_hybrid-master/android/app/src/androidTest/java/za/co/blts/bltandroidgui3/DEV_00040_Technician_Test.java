package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AEON_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AWS_HEARTBEAT_MINUTES;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BLUKEY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASH_DRAWER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_EPUB_MANUAL_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_EPUB_READER_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FDROID_REPO_DIR;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FDROID_REPO_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HEARTBEAT_ENABLE_TECH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HEARTBEAT_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOG_DAYS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MANUAL_OVERRIDE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PAPER_CUTTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINTER_WIDTH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_SALES_RECEIPT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_CAN_BOXRICA;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SCANNING_APP;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRANSACTION_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VOUCHER_SECONDS;

/**
 * Created by NkosanaM on 2/8/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00040_Technician_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
        restoreAllDefaultSettings();
    }

    @After
    public void after() {
        restoreAllDefaultSettings();
        tearDown();
    }


    @Test
    public void T001_Login() {
        try {
            //test valid login
            if (!checks.validTechnicianLogin()) {
                fail("Valid Technician Login");
            } else {
                Log.d(TAG, "Valid Technician Login Test Passed Successfully..!");
            }

            checks.save();
            checks.confirmTechnician();

            //test invalid login
            getBaseActivity().cancelTimer();
            solo.waitForActivity("ActivityLanding");

            if (!checks.invalidTechnicianLogin()) {
                fail("Invalid Technician login");
            } else {
                Log.d(TAG, "Invalid Technician Login Test Passed Successfully..!");
            }
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T020_DeviceSettings() {

        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login");
            } else {
                fail("Login");
            }


            checks.toggleTechSetup("devicesettings");
            Log.d(TAG, "Device Setting Section open");

            if (checks.isViewEnabled(R.id.hostSetting)) {
                fail("AEON Host EditText enabled");
            } else {
                Log.d(TAG, "AEON Host EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.portSetting)) {
                fail("AEON Port EditText enabled");
            } else {
                Log.d(TAG, "AEON Port EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.sslSwitch)) {
                fail("AEON SSL switch enabled");
            } else {
                Log.d(TAG, "AEON SSL switch not enabled");
            }

            checks.toggleManualOverrideSwitch();
            Log.d(TAG, "Manual override switch enabled");

            if (checks.isViewEnabled(R.id.hostSetting)) {
                Log.d(TAG, "AEON Host EditText enabled");
            } else {
                fail("AEON Host EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.portSetting)) {
                Log.d(TAG, "AEON Port EditText enabled");
            } else {
                fail("AEON Port EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.sslSwitch)) {
                Log.d(TAG, "AEON SSL switch not enabled");
            } else {
                fail("AEON SSL switch enabled");
            }


            checks.enterText(R.id.hostSetting, "10.22.7.11");
            Log.d(TAG, "Host Setting Changed");

            checks.enterText(R.id.portSetting, "9012");
            Log.d(TAG, "Post Setting Changed");


            checks.enterDeviceID("29511");
            Log.d(TAG, "Device ID Changed");

            checks.save();

            checks.confirmTechnician();
            Log.d(TAG, "Confirm Technician Pin");

            solo.sleep(500);//wait for preferences to be committed

            if (checks.checkPreference(PREF_MANUAL_OVERRIDE).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_MANUAL_OVERRIDE updated to " + PREF_TRUE);
            } else {
                fail("PREF_MANUAL_OVERRIDE not updated");
            }

            if (checks.checkPreference(PREF_HOST).equals("10.22.7.11")) {
                Log.d(TAG, "HOST_PREF updated");
            } else {
                fail("HOST_PREF not updated");
            }

            if (checks.checkPreference(PREF_PORT).equals("9012")) {
                Log.d(TAG, "PREF_PORT updated");
            } else {
                fail("PREF_PORT not updated");
            }

            if (checks.checkPreference(PREF_DEVICE_ID).equals("29511")) {
                Log.d(TAG, "PREF_DEVICE_ID updated");
            } else {
                fail("PREF_DEVICE_ID not updated");
            }

            Log.d(TAG, "Device Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T030_CashDrawerSettings() {

        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login");
            } else {
                fail("Login");
            }

            checks.toggleTechSetup("cashdrawersetting");
            Log.d(TAG, "Cash Drawer settings section open");

            //Cash Drawer on and off
            checks.toggleSwitch("cashdrawer");
            Log.d(TAG, "toggled the Cash Drawer");

            checks.save();

            checks.confirmTechnician();
            Log.d(TAG, "Confirm Technician Pin");

            solo.sleep(500); //wait for preferences to have been committed

            if (checks.checkPreference(PREF_CASH_DRAWER).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_USE_CASHDRAWER updated");
            } else {
                fail("PREF_USE_CASHDRAWER not updated");
            }

            Log.d(TAG, "Cash Drawer Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T040_ErrorLoggingSettings() {

        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login");
            } else {
                fail("Login");
            }

            checks.toggleTechSetup("errorLogging");
            Log.d(TAG, "Error Logging settings section open");

            checks.enterText(R.id.logPeriodSetting, "6");
            Log.d(TAG, "file log days changed");

            checks.clickButton("Export Log Files");
            solo.waitForDialogToClose();
            solo.clickOnText("OK");
            Log.d(TAG, "Zip logs folder exported");

            checks.save();

            checks.confirmTechnician();
            Log.d(TAG, "Confirm Technician Pin");

            solo.sleep(500);

            if (getBaseActivity().logsDir.listFiles() != null) {
                Log.d(TAG, "Zip logs folder in the logs directory");
            } else {
                fail("Zip logs folder not exported");
            }

            if (checks.checkPreference(PREF_LOG_DAYS).equals("6")) {
                Log.d(TAG, "PREF_LOG_DAYS updated");
            } else {
                fail("PREF_LOG_DAYS not updated");
            }

            Log.d(TAG, "Error Logging Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T050_ScanningSettings() {

        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login");
            } else {
                fail("Login");
            }

            checks.toggleTechSetup("scanning");
            Log.d(TAG, "Scanning settings section open");

            solo.clickOnText("com.codecorp.cortex_scan");
            Log.d(TAG, "clicked on Scanner Options");

            solo.clickOnText("com.google.zxing.client.android");
            Log.d(TAG, "scanner option selected");

            checks.save();

            checks.confirmTechnician();
            Log.d(TAG, "Confirm Technician Pin");

            solo.sleep(500);

            if (checks.checkPreference(PREF_SCANNING_APP).equals("com.google.zxing.client.android")) {
                Log.d(TAG, "PREF_SCANNING_APP updated");
            } else {
                fail("PREF_SCANNING_APP  not updated");
            }

            Log.d(TAG, "Error Logging Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }


    @Test
    public void T060_TrainingAppSettings() {

        try {

            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login as Technician");
            } else {
                fail("Login");
            }

            checks.toggleTechSetup("trainingApp");
            Log.d(TAG, "Training App section open");

            checks.enterText(R.id.ePubHostSetting, "http://196.38.158.102/touchscreen/bd3/LithiumEPUBReader.apk");
            Log.d(TAG, "Reader Host changed");


            checks.enterText(R.id.epubManualSetting, "http://196.38.158.102/touchscreen/bd3/Training.epub");
            Log.d(TAG, "Manual Directory changed");

            checks.save();

            checks.confirmTechnician();
            Log.d(TAG, "Confirm Technician Pin");

            solo.sleep(500);

            if (checks.checkPreference(PREF_EPUB_READER_URL).equals("http://196.38.158.102/touchscreen/bd3/LithiumEPUBReader.apk")) {
                Log.d(TAG, "PREF_EPUB_READER HOST updated");
            } else {
                fail("PREF_EPUB_READER not updated");
            }


            if (checks.checkPreference(PREF_EPUB_MANUAL_URL).equals("http://196.38.158.102/touchscreen/bd3/Training.epub")) {
                Log.d(TAG, "PREF_EPUB_MANUAL_URL updated");
            } else {
                fail("PREF_EPUB_MANUAL_URL not updated");
            }

            Log.d(TAG, "Error Logging Settings Test Passed successfully");

        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T070_PrinterSettings() {
        try {

            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login as a technician");
            } else {
                fail("Could not login");
            }

            checks.toggleTechSetup("printersettings");
            Log.d(TAG, "Printer settings section open");

            //paper cutter on and off
            checks.toggleSwitch("papercutter");

            //checks.toggleSwitch("papercutter");
            Log.d(TAG, "toggled the paper cutter");

            //sales receipt off and on
            checks.toggleSwitch("salesreceipt");

            //checks.toggleSwitch("salesreceipt");
            Log.d(TAG, "toggled the sales receipt");

            checks.changePrinterWidth(testProperties.getProperty("printerWidth"));
            Log.d(TAG, "changed the printer width");


            checks.selectSecondsRadioButton("0");
            checks.selectSecondsRadioButton("5");
            checks.selectSecondsRadioButton("7");
            checks.selectSecondsRadioButton("10");

            Log.d(TAG, "Seconds between vouchers selected");

            checks.save();

            checks.confirmTechnician();
            Log.d(TAG, "Save and Confirm Technician Pin");

            solo.sleep(500);

            //check if the paer cutter was updated
            if (checks.checkPreference(PREF_PAPER_CUTTER).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_PAPER_CUTTER updated");
            } else {
                fail("PREF_PAPER_CUTTER not updated");
            }

            //check if the print sales receipt pref was updated
            if (checks.checkPreference(PREF_PRINT_SALES_RECEIPT).equals("false")) {
                Log.d(TAG, "PREF_PRINT_SALES_RECEIPT updated");
            } else {
                fail("PREF_PRINT_SALES_RECEIPT not updated");
            }

            //check if the printer width was updated
            if (checks.checkPreference(PREF_PRINTER_WIDTH).equals(testProperties.getProperty("printerWidth"))) {
                Log.d(TAG, "PREF_PRINTER_WIDTH updated");
            } else {
                fail("PREF_PRINTER_WIDTH not updated");
            }

            //check if the voucher seconds was updated
            if (checks.checkPreference(PREF_VOUCHER_SECONDS).equals("10")) {
                Log.d(TAG, "PREF_VOUCHER_SECONDS updated");
            } else {
                fail("PREF_VOUCHER_SECONDS not updated");
            }

            Log.d(TAG, "Printer Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T080_TimeoutSettings() {

        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login as a technician");
            } else {
                fail("Could not login");
            }

            checks.toggleTechSetup("timeoutsettings");
            Log.d(TAG, "Timeout settings section open");

            checks.enterText(R.id.aeonTimeoutSetting, "299");
            Log.d(TAG, "AEON TIMEOUT SETTING CHANGED");

            checks.enterText(R.id.transactionTimeoutSetting, "45");
            Log.d(TAG, "Transaction TIMEOUT SETTING CHANGED");

            checks.save();

            checks.confirmTechnician();
            Log.d(TAG, "Save and confirm technician PIN");

            solo.sleep(500);

            //check if the printer width was updated
            if (checks.checkPreference(PREF_AEON_TIMEOUT).equals("299")) {
                Log.d(TAG, "PREF_AEON_TIMEOUT updated");
            } else {
                fail("PREF_AEON_TIMEOUT not updated");
            }

            //check if the voucher seconds was updated
            if (checks.checkPreference(PREF_TRANSACTION_TIMEOUT).equals("45")) {
                Log.d(TAG, "PREF_TRANSACTION_TIMEOUT updated");
            } else {
                fail("PREF_TRANSACTION_TIMEOUT not updated");
            }

            Log.d(TAG, "Timeout Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T090_RicaSettings() {
        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login");
            } else {
                fail("Login");
            }

            checks.toggleTechSetup("ricasettings");
            Log.d(TAG, "RICA Setting Section open");

            if (checks.isViewEnabled(R.id.ricaHostSetting)) {
                fail("RICA Host EditText enabled");
            } else {
                Log.d(TAG, "RICA Host EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.ricaPortSetting)) {
                fail("RICA Port EditText enabled");
            } else {
                Log.d(TAG, "RICA Port EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.ricaDeviceIdSetting)) {
                fail("RICA Device ID EditText enabled");
            } else {
                Log.d(TAG, "RICA Device ID EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.ricaDeviceSerialSetting)) {
                fail("RICA Device Serial EditText enabled");
            } else {
                Log.d(TAG, "RICA Device Serial EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.ricaSSLSwitch)) {
                fail("AEON SSL switch enabled");
            } else {
                Log.d(TAG, "RICA SSL switch not enabled");
            }

            checks.toggleManualOverrideSwitch();
            Log.d(TAG, "Manual override switch enabled");

            if (checks.isViewEnabled(R.id.hostSetting)) {
                Log.d(TAG, "RICA Host EditText enabled");
            } else {
                fail("RICA Host EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.portSetting)) {
                Log.d(TAG, "RICA Port EditText enabled");
            } else {
                fail("RICA Port EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.ricaDeviceIdSetting)) {
                Log.d(TAG, "RICA Device ID EditText enabled");
            } else {
                fail("RICA Device ID EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.ricaDeviceSerialSetting)) {
                Log.d(TAG, "RICA Device Serial EditText enabled");
            } else {
                fail("RICA Device Serial EditText not enabled");
            }

            if (checks.isViewEnabled(R.id.sslSwitch)) {
                Log.d(TAG, "RICA SSL switch not enabled");
            } else {
                fail("RICA SSL switch enabled");
            }

            checks.enterText(R.id.ricaHostSetting, "10.22.7.11");
            Log.d(TAG, "Rica Host Setting Changed");

            checks.enterText(R.id.ricaPortSetting, "9012");
            Log.d(TAG, "RICA Post Setting Changed");

            checks.enterText(R.id.ricaDeviceIdSetting, "12345");
            Log.d(TAG, "RICA Device id Setting Changed");

            checks.enterText(R.id.ricaDeviceSerialSetting, "679");
            Log.d(TAG, "RICA device serial Setting Changed");

            checks.toggleSwitch("ricassl");
            Log.d(TAG, "RICA SSL Switch toggled");

            checks.toggleSwitch("boxrica");
            Log.d(TAG, "Box rica Switch toggled");

            checks.save();

            checks.confirmTechnician();
            Log.d(TAG, "Confirm Technician Pin");

            solo.sleep(500);

            if (checks.checkPreference(PREF_MANUAL_OVERRIDE).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_MANUAL_OVERRIDE updated to " + PREF_TRUE);
            } else {
                fail("PREF_MANUAL_OVERRIDE not updated");
            }

            if (checks.checkPreference(PREF_RICA_HOST).equals("10.22.7.11")) {
                Log.d(TAG, "PREF_RICA_HOST updated");
            } else {
                fail("PREF_RICA_HOST not updated");
            }

            if (checks.checkPreference(PREF_RICA_PORT).equals("9012")) {
                Log.d(TAG, "PREF_RICA_PORT updated");
            } else {
                fail("PREF_RICA_PORT not updated");
            }

            if (checks.checkPreference(PREF_RICA_DEVICE_ID).equals("12345")) {
                Log.d(TAG, "PREF_RICA_DEVICE_ID updated");
            } else {
                fail("PREF_RICA_DEVICE_ID not updated");
            }

            if (checks.checkPreference(PREF_RICA_DEVICE_SER).equals("679")) {
                Log.d(TAG, "PREF_RICA_DEVICE_SER updated");
            } else {
                fail("PREF_RICA_DEVICE_SER not updated");
            }


            if (checks.checkPreference(PREF_RICA_CAN_BOXRICA).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_RICA_CAN_BOXRICA updated");
            } else {
                fail("PREF_RICA_CAN_BOXRICA not updated");
            }

            Log.d(TAG, "RICA Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }


    @Test
    public void T100_RepositorySettings() {
        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login");
            } else {
                fail("Login");
            }

            checks.toggleTechSetup("repositorysettings");
            Log.d(TAG, "Repository Setting Section open");

            if (checks.isViewEnabled(R.id.fdroidHostSetting)) {
                fail("Repo Host EditText enabled");
            } else {
                Log.d(TAG, "Repo Host EditText not enabled");
            }

            checks.toggleManualOverrideSwitch();
            Log.d(TAG, "Manual override switch enabled");

            if (checks.isViewEnabled(R.id.fdroidHostSetting)) {
                Log.d(TAG, "Repo Host EditText enabled");
            } else {
                fail("Repo Host EditText not enabled");
            }

            checks.enterText(R.id.fdroidHostSetting, "https://10.22.7.24:80");
            Log.d(TAG, "Repository Host Setting Changed");


            //enter directory without trailing /
            checks.enterText(R.id.fdroidRepoSetting, "/fdroid/repotest");
            Log.d(TAG, "Repository Directory Setting Changed");

            checks.save();

            checks.confirmTechnician();

            solo.sleep(500);

            Log.d(TAG, "Confirm Technician Pin");

            if (checks.checkPreference(PREF_MANUAL_OVERRIDE).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_MANUAL_OVERRIDE updated to " + PREF_TRUE);
            } else {
                fail("PREF_MANUAL_OVERRIDE not updated");
            }

            if (checks.checkPreference(PREF_FDROID_REPO_URL).equals("https://10.22.7.24:80")) {
                Log.d(TAG, "PREF_FDROID_REPO_URL updated");
            } else {
                fail("PREF_FDROID_REPO_URL not updated");
            }


            //app should automatically have added the trailing /
            if (checks.checkPreference(PREF_FDROID_REPO_DIR).equals("/fdroid/repotest/")) {
                Log.d(TAG, "PREF_FDROID_REPO_DIR updated");
            } else {
                fail("PREF_FDROID_REPO_DIR not updated");
            }

            Log.d(TAG, "Repository Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T110_LoyaltySettings() {
        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login");
            } else {
                fail("Login");
            }

            //solo.scrollToBottom();
            checks.toggleTechSetup("loyalty");
            Log.d(TAG, "Loyalty Setting Section open");

            if (checks.isViewEnabled(R.id.loyaltyHostSetting)) {
                fail("API Gateway Host EditText enabled");
            } else {
                Log.d(TAG, "API Gateway Host EditText not enabled");
            }

            checks.toggleManualOverrideSwitch();
            Log.d(TAG, "Manual override switch enabled");

            if (checks.isViewEnabled(R.id.loyaltyHostSetting)) {
                Log.d(TAG, "API Gateway Host EditText enabled");
            } else {
                fail("API Gateway Host EditText not enabled");
            }

            checks.enterText(R.id.loyaltyHostSetting, "https://10.22.7.12:9013");
            Log.d(TAG, "Loyalty Host Setting Changed");

            checks.save();

            checks.confirmTechnician();

            solo.sleep(500);

            Log.d(TAG, "Confirm Technician Pin");

            if (checks.checkPreference(PREF_MANUAL_OVERRIDE).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_MANUAL_OVERRIDE updated to " + PREF_TRUE);
            } else {
                fail("PREF_MANUAL_OVERRIDE not updated");
            }

            if (checks.checkPreference(PREF_LOYALTY_URL).equals("https://10.22.7.12:9013")) {
                Log.d(TAG, "PREF_LOYALTY_URL updated");
            } else {
                fail("PREF_LOYALTY_URL not updated");
            }

            Log.d(TAG, "Loyalty Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T112_BluKeySettings() {
        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login");
            } else {
                fail("Login");
            }

            //solo.scrollToBottom();
            checks.toggleTechSetup("blukey");
            Log.d(TAG, "BluKey Setting Section open");

            if (checks.isViewEnabled(R.id.merchantHostSetting)) {
                fail("BluKey Host EditText enabled");
            } else {
                Log.d(TAG, "BluKey Host EditText not enabled");
            }

            solo.scrollToTop();
            checks.toggleManualOverrideSwitch();
            Log.d(TAG, "Manual override switch enabled");

            solo.scrollToBottom();

            if (checks.isViewEnabled(R.id.merchantHostSetting)) {
                Log.d(TAG, "BluKey Host EditText enabled");
            } else {
                fail("BluKey Host EditText not enabled");
            }

            checks.enterText(R.id.merchantHostSetting, "https://blutrader.qa.bltelecoms.com");
            Log.d(TAG, "BluKey Host Setting Changed");

            checks.save();

            checks.confirmTechnician();

            solo.sleep(500);

            Log.d(TAG, "Confirm Technician Pin");

            if (checks.checkPreference(PREF_MANUAL_OVERRIDE).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_MANUAL_OVERRIDE updated to " + PREF_TRUE);
            } else {
                fail("PREF_MANUAL_OVERRIDE not updated");
            }

            if (checks.checkPreference(PREF_BLUKEY_URL).equals("https://blutrader.qa.bltelecoms.com")) {
                Log.d(TAG, "PREF_BLUKEY_URL updated");
            } else {
                fail("PREF_BLUKEY_URL not updated");
            }

            Log.d(TAG, "BluKey Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T111_HeartbeatSettings() {
        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login");
            } else {
                fail("Login");
            }

            //solo.scrollToBottom();
            checks.toggleTechSetup("heartbeat");
            Log.d(TAG, "Heartbeat Setting Section open");

            if (checks.isViewEnabled(R.id.heartbeatURLSetting)) {
                fail("Heartbeat URL EditText enabled");
            } else {
                Log.d(TAG, "Heartbeat URL EditText not enabled");
            }

            solo.scrollToTop();

            checks.toggleManualOverrideSwitch();
            Log.d(TAG, "Manual override switch enabled");

            if (checks.isViewEnabled(R.id.heartbeatURLSetting)) {
                Log.d(TAG, "Heartbeat URL EditText enabled");
            } else {
                fail("Heartbeat URL EditText not enabled");
            }

            solo.scrollToBottom();

            checks.toggleSwitch("heartbeatenable");
            Log.d(TAG, "Heartbeat Enable Switch toggled");

            checks.selectHeartbeatIntervalRadioButton("3");
            checks.selectHeartbeatIntervalRadioButton("5");
            checks.selectHeartbeatIntervalRadioButton("7");
            Log.d(TAG, "Minutes intervals selected");

            checks.enterText(R.id.heartbeatURLSetting
                    , "https://sqs.eu-west-1.amazonaws.net/834031529481/device_heartbeat_dev-queue?Action=SendMessage&amp;MessageBody=");
            Log.d(TAG, "BluKey Host Setting Changed");



            checks.save();

            checks.confirmTechnician();

            solo.sleep(500);

            Log.d(TAG, "Confirm Technician Pin");

            if (checks.checkPreference(PREF_MANUAL_OVERRIDE).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_MANUAL_OVERRIDE updated to " + PREF_TRUE);
            } else {
                fail("PREF_MANUAL_OVERRIDE not updated");
            }

            if (checks.checkPreference(PREF_HEARTBEAT_ENABLE_TECH).equals(PREF_FALSE)) {
                Log.d(TAG, "PREF_HEARTBEAT_ENABLE_TECH updated");
            } else {
                fail("PREF_HEARTBEAT_ENABLE_TECH not updated");
            }

            if (checks.checkPreference(PREF_HEARTBEAT_URL)
                    .equals("https://sqs.eu-west-1.amazonaws.net/834031529481/device_heartbeat_dev-queue?Action=SendMessage&amp;MessageBody=")) {
                Log.d(TAG, "PREF_HEARTBEAT_URL updated");
            } else {
                fail("PREF_HEARTBEAT_URL not updated");
            }

            if (checks.checkPreference(PREF_AWS_HEARTBEAT_MINUTES).equals("7")) {
                Log.d(TAG, "PREF_AWS_HEARTBEAT_MINUTES updated");
            } else {
                fail("PREF_AWS_HEARTBEAT_MINUTES not updated");
            }

            Log.d(TAG, "Heartbeat Settings Test Passed successfully");
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }

    @Test
    public void T130_LeaveWithoutSaving() {
        try {
            if (checks.validTechnicianLogin()) {
                Log.d(TAG, "Login as a technician");
            } else {
                fail("Could not login as a technician");
            }

            //click the close button
            checks.clickOnToobarNavigationButton();

            if (solo.waitForActivity(ActivityLanding.class)) {
                Log.d(TAG, "Return to Login screen");
            } else {
                fail("Leave Did not return to Login screen");
            }

        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }
}


