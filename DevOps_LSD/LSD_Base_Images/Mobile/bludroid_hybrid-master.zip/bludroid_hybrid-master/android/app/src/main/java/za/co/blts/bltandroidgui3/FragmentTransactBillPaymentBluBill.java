package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by WarrenM1 on 2017/07/21.
 */

public class FragmentTransactBillPaymentBluBill extends BaseFragment implements NeedsAEONResults, View.OnFocusChangeListener {

    private final String TAG = this.getClass().getSimpleName();


    private View rootView;

    public FragmentTransactBillPaymentBluBill() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle bundle = getArguments();
        getBaseActivity().providerId = bundle.getString("providerId");
        getBaseActivity().productId = bundle.getString("productId");
        getBaseActivity().productName = bundle.getString("productName");
        getBaseActivity().logoId = bundle.getString("logoId");
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_bill_payment_blubill, container, false);

        ImageView logo = rootView.findViewById(R.id.blubillLogo);

        if (getBaseActivity().logoId != null) {
            if (getBaseActivity().logoId.equals("30")) {
                logo.setImageResource(R.drawable.billpayment_easypay);
            } else if (getBaseActivity().logoId.equals("31")) {
                logo.setImageResource(R.drawable.billpayment_unipay);
            }
        }

        BluDroidTextView productNameTextView = rootView.findViewById(R.id.productName);
        productNameTextView.setText(getBaseActivity().productName);

        final BluDroidEditText accountNumber = rootView.findViewById(R.id.accountNumber);

        accountNumber.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent event) {
                Log.v(TAG, "actionId " + actionId + " event " + event);
                if (actionId == 0) {
                    accountNumber.setImeActionLabel(getResources().getString(R.string.next), EditorInfo.IME_ACTION_GO);
                    accountNumber.setInputType(InputType.TYPE_CLASS_TEXT);
                }

                return true;
            }
        });


        final BluDroidButton showDetails = rootView.findViewById(R.id.showDetailsButton);

        showDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BaseActivity.logger.info(((BluDroidButton) view).getText());
                if (accountNumber.getText().toString().trim().isEmpty()) {

                    accountNumber.setErrorMessage(getResources().getString(R.string.account_number_required));
                    accountNumber.getErrorTextView().setText(getResources().getString(R.string.account_number_required));

                } else {
                    accountNumber.removeErrorMessage();
                    accountNumber.getErrorTextView().setText("");

                    String account = accountNumber.getText().toString().trim();
                    new Handler().postDelayed(new Runnable() {

                        @Override
                        public void run() {
                            showDetails.setEnabled(true);

                        }
                    }, 5000);
                    getBaseActivity().authenticateForBluBillPayments(account);
                }
            }
        });

        setupSpinner();

        return rootView;
    }

    private void setupSpinner() {
        final Spinner accountNumberSpinner = rootView.findViewById(R.id.accountNumberSpinner);
        final BluDroidLinearLayout numberLayout = rootView.findViewById(R.id.numberLayout);
        final BluDroidEditText accountNumber = rootView.findViewById(R.id.accountNumber);

        final List<String> accountNumbers = new ArrayList<>();
        boolean hasAccountNumbers = checkCustomerProfileAccountNumbers(accountNumbers);

        if (hasAccountNumbers) {
            Log.d(TAG, "has account numbers");
            accountNumbers.add(0, "Other");
            accountNumberSpinner.setVisibility(View.VISIBLE);
            numberLayout.setVisibility(View.INVISIBLE);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getBaseActivity(), android.R.layout.simple_spinner_item, accountNumbers);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            accountNumberSpinner.setAdapter(dataAdapter);
            //although meterNumber is hidden, update this with the selected spinner value, so the dialog.validate() will pass
            accountNumber.setText(accountNumbers.get(1));
            accountNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i == 0) {
                        onNothingSelected(null);
                    } else {
                        accountNumber.setText(accountNumbers.get(i));
                        numberLayout.setVisibility(View.GONE);
                        getBaseActivity().hideKeyboard();
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    accountNumber.setText("");
                    numberLayout.setVisibility(View.VISIBLE);
                    accountNumber.requestFocus();
                    getBaseActivity().showKeyboard();
                }
            });
            accountNumberSpinner.setSelection(1);

        } else {
            Log.d(TAG, "no account numbers");
            accountNumberSpinner.setVisibility(View.GONE);
            numberLayout.setVisibility(View.VISIBLE);
            accountNumber.requestFocus();
            getBaseActivity().showKeyboard();
        }

    }

    private boolean checkCustomerProfileAccountNumbers(List<String> accountNumbers) {
        Log.d(TAG, "search for account numbers for " + getBaseActivity().productName);
        if (BaseActivity.consumerProfile != null && getBaseActivity().customerProfileBillPaymentsAccountNumbers != null) {
            String[] accounts = getBaseActivity().customerProfileBillPaymentsAccountNumbers.get(getBaseActivity().productName);
            if (accounts != null && accounts.length > 0) {
                accountNumbers.addAll(Arrays.asList(accounts));
                return true;
            }
        }
        return false;
    }

    @Override
    public void onFocusChange(View view, boolean b) {

    }

    @Override
    public boolean onBackPressed() {
        BaseActivity.logger.info(": onBackPressed()");
        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else if (getBaseActivity().navigatedFromSearch) {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentSearch(), "FragmentSearch").commit();
        } else {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentTransact(), "FragmentTransact").commit();
        }
        return true;
    }

}
