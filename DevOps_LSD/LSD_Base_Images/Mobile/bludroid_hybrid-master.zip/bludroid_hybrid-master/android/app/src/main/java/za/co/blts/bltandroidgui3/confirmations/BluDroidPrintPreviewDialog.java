package za.co.blts.bltandroidgui3.confirmations;

import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;

/**
 * Created by MasiS on 3/23/2018.
 */

public class BluDroidPrintPreviewDialog extends BluDroidConfirmationDialog implements BluDroidSetupable {
    private TextView print_lines;
    private final String TAG = this.getClass().getSimpleName();
    private ArrayList lines;
    private WeakReference<BaseActivity> baseActivityWeakReference;

    BluDroidPrintPreviewDialog(final BaseActivity context, ArrayList lines) {
        super(context, R.layout.dialog_print_preview);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setup();
        setHeading("Print Preview");
        this.lines = lines;

        print_lines = findViewById(R.id.print_lines);
        convertPrintLinesToString();

        BluDroidButton cancel_print_button = findViewById(R.id.cancel_print_button);
        cancel_print_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { // dismiss without doing a thing
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                dismiss();
            }
        });

        BluDroidButton do_print_button = findViewById(R.id.do_print_button);
        do_print_button.setOnClickListener(new View.OnClickListener() { // this is where the juice is
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                doPrintLines();
                dismiss();
            }
        });
    }

    //----------------------------------------------------------------------------------------------
    private void convertPrintLinesToString() {
        try {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                @SuppressWarnings("unchecked")
                ArrayList<String> tmp = lines;
                if (lines.size() > 0) {
                    if (lines.get(0) instanceof CommonResponseLineMessage) {
                        tmp = new ArrayList<>();
                        for (int i = 0; i < lines.size(); i++) {
                            CommonResponseLineMessage line = (CommonResponseLineMessage) lines.get(i);
                            StringBuilder st = new StringBuilder();

                            switch (line.getF()) {
                                case "H":
                                case "E":
                                    line.setText(baseActivity.center(line.getText()));
                                    break;
                                case "P":
                                case "Q":
                                    line.setText("");
                                    break;
                            }
                            if (line.getText() != null && !line.getText().equals("0") && !line.getF().equals("P") && !line.getF().equals("Q")) {
                                st.append(line.getText());
                                tmp.add(st.toString());
                            }
                            if (line.getF().equals("N")) {
                                tmp.add(BaseActivity.HORIZONTAL_LINE);
                            }
                        }
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    for (String theLine : tmp) {
                        stringBuilder.append(theLine).append("\n");
                    }
                    setPrintLinesToView(stringBuilder.toString());
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems printing " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    private void setPrintLinesToView(String lines) {
        print_lines.setText(lines);
    }

    //----------------------------------------------------------------------------------------------
    private void doPrintLines() {
        baseActivity.print(lines);
    }
    //----------------------------------------------------------------------------------------------
}
