package za.co.blts.bltandroidgui3;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blts.bltandroidgui3.dynamic.DynamicPrintUtil;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PAPER_CUTTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINTER_WIDTH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VOUCHER_SECONDS;
import static za.co.blts.bltandroidgui3.PrintUtil.setBold;

public class CitaqSmartPrinter implements SmartPrinter {
    private final String TAG = this.getClass().getSimpleName();
    private WeakReference<BaseActivity> baseActivityWeakReference;
    private String ENDTEXT = null;
    public boolean paperCutter = false;

    public CitaqSmartPrinter() {
    }

    public void initialise(BaseActivity baseScreen) {
        Log.d(TAG, ": initialise() with BaseActivity");
        try {
            this.baseActivityWeakReference = new WeakReference<>(baseScreen);
            paperCutter = baseScreen.getPreference(PREF_PAPER_CUTTER).equals(PREF_TRUE);
            if (!paperCutter) {
                int printWidth = Integer.parseInt(baseScreen.getPreference(PREF_PRINTER_WIDTH));
                Log.d(TAG, "printWidth = " + printWidth);
                StringBuilder sb = new StringBuilder();
                sb.append("\n\n");
                for (int i = 0; i < printWidth; i++) {
                    sb.append("=");
                }
                sb.append("\n");
                ENDTEXT = sb.toString();
            }
            PrintLines.setCitaqSmartPrinter(this);
        } catch (Exception exception) {
            Log.d(TAG, "problem initializing citaqs " + exception);
        }
    }

    public void terminate() {
    }

    @Override
    public void print(ArrayList<CommonResponseLineMessage> lines, boolean feed) {
        try {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                String barcodeNumber;
                Bitmap barcode;
                int barcodeWidth = BaseActivity.printWidth * 12;
                baseScreen.choosePrintLogo();
                PrintLines.printSmartStrings(baseScreen.bluLogo, new ArrayList<String>(), null, "");
                ArrayList<String> lineList;
                if (lines.size() > 0) {
                    for (CommonResponseLineMessage line : lines) {
                        switch (line.getF()) {
                            // center
                            case "H":
                                lineList = new ArrayList<>();
                                line.setText(baseScreen.center(line.getText()));
                                lineList.add(line.getText());
                                PrintLines.printSmartStrings(null, lineList, null, "");
                                break;

                            // left align (should be default)
                            case "O":
                                lineList = new ArrayList<>();
                                if (line.getText() != null) {
                                    lineList.add(line.getText());
                                }
                                PrintLines.printSmartStrings(null, lineList, null, "");
                                break;

                            //print horizontal line
                            case "N":
                                lineList = new ArrayList<>();
                                if (line.getText() != null && !line.getText().isEmpty()) {
                                    line.setText(baseScreen.center(line.getText()));
                                    lineList.add(line.getText());
                                }
                                lineList.add(BaseActivity.HORIZONTAL_LINE);
                                PrintLines.printSmartStrings(null, lineList, null, "");
                                break;

                            // need to generate EAN 13 barcode
                            case "P":
                                lineList = new ArrayList<>();
                                barcodeNumber = line.getText();
                                barcode = baseScreen.generateBarcode("ean13", line.getText(), barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13);
                                PrintLines.printSmartStrings(null, lineList, barcode, baseScreen.center(barcodeNumber));
                                break;

                            // need to generate Code 39 barcode
                            case "Q":
                                lineList = new ArrayList<>();
                                barcodeNumber = line.getText();
                                barcode = baseScreen.generateBarcode("code39", line.getText(), barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13);
                                PrintLines.printSmartStrings(null, lineList, barcode, baseScreen.center(barcodeNumber));
                                break;

                            // need to generate ITF barcode for Lotto
                            case "U":
                                lineList = new ArrayList<>();
                                BaseActivity.isLotto = true;
                                String specialChar = ";";
                                String barcodeText = line.getText();
                                String printableBarcode = barcodeText.substring(0, barcodeText.indexOf(specialChar));
                                barcode = baseScreen.generateBarcode("itf", printableBarcode, barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13);
                                PrintLines.printSmartStrings(null, lineList, barcode, baseScreen.center(printableBarcode));
                                break;

                            case "X":
                                lineList = new ArrayList<>();
                                barcodeNumber = line.getText();
                                barcode = baseScreen.generateBarcode("code128", line.getText(), barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13);
                                PrintLines.printSmartStrings(null, lineList, barcode, baseScreen.center(barcodeNumber));
                                break;

                            //normal
                            case "A":
                            case "G":
                            case "K":
                            case "M":
                                lineList = new ArrayList<>();
                                lineList.add(line.getText());
                                PrintLines.printSmartStrings(null, lineList, null, "");
                                break;

                            //bold
                            case "B":
                            case "C":
                            case "D":
                                PrintUtil.printBytes(setBold(true));
                                lineList = new ArrayList<>();
                                lineList.add(line.getText());
                                PrintLines.printSmartStrings(null, lineList, null, "");
                                PrintUtil.printBytes(setBold(false));
                                break;

                            // center bold
                            case "E":
                                boolean pin = new BluDroidUtils().isPinFormat(line.getText());
                                if (pin) {
                                    line.setText(line.getText().replaceAll("\\s{2,}", " "));
                                }
                                ArrayList<String> wrappedLines = BluDroidUtils.wordWrap(line.getText(), pin ? 16 : 32);
                                for (String s : wrappedLines) {
                                    PrintLines.printText(s, ALIGN_CENTER, pin ? FONT_LARGE : FONT_NORMAL, true);
                                }
                                break;

                            case "F":
                            case "L":
                                break;

                            default:
                        }
                    }
                    if (feed) {
                        lineList = new ArrayList<>();
                        lineList.add(".\n");
                        lineList.add(".\n");
                        PrintLines.printSmartStrings(null, lineList, null, "");
                    }
                }
                int millis = Integer.parseInt(baseScreen.getPreference(PREF_VOUCHER_SECONDS)) * 1000;
                Thread.sleep(millis);
                BaseActivity.logger.info(": done printing");
            }
        } catch (Exception ex) {
            BaseActivity.logger.error("Printing Error: " + ex);
            Log.d(TAG, "exception " + ex);
        }
    }

    @Override
    public void print(List<String> lines) {
        Log.d(TAG, ": print()");
        PrintLines.printStrings(null, lines, null, "");
        BaseActivity.logger.info(": done printing");
    }

    @Override
    public void print(Bitmap logo, List<String> lines, Bitmap barcode, String barcodeNumber) {
        try {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                Log.d(TAG, "printing");
                PrintLines.printStrings(logo, lines, barcode, "");
                Log.d(TAG, "printed");
                if (!paperCutter && ENDTEXT != null) {
                    ArrayList<String> list = new ArrayList<>();
                    list.add(ENDTEXT);
                    list.add("");
                    list.add("");
                    PrintLines.printStrings(null, list, null, "");
                }
                int millis = Integer.parseInt(baseScreen.getPreference(PREF_VOUCHER_SECONDS)) * 1000;
                Thread.sleep(millis);
                BaseActivity.logger.info(": done printing");
            }
        } catch (Exception exception) {
            BaseActivity.logger.error("Printing Error: " + exception);
            Log.d(TAG, "exception " + exception);
        }
    }

    @Override
    public void print(Bitmap logo, List<CommonResponseLineMessage> lines, Bitmap barcode, boolean feed) {
        try {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                if (logo != null) {
                    PrintLines.printSmartStrings(logo, new ArrayList<String>(), null, "");
                }
                ArrayList<String> lineList;
                if (lines.size() > 0) {
                    for (CommonResponseLineMessage line : lines) {
                        switch (line.getF()) {
                            // center
                            case "H":
                                lineList = new ArrayList<>();
                                line.setText(baseScreen.center(line.getText()));
                                lineList.add(line.getText());
                                PrintLines.printSmartStrings(null, lineList, null, "");
                                break;

                            // left align (should be default)
                            case "O":
                                lineList = new ArrayList<>();
                                if (line.getText() != null) {
//								lineList.add(line.getText() + "\n");
                                    lineList.add(line.getText());
                                }
                                PrintLines.printSmartStrings(null, lineList, null, "");
                                break;

                            //print horizontal line
                            case "N":
                                lineList = new ArrayList<>();
                                if (line.getText() != null && !line.getText().isEmpty()) {
                                    line.setText(baseScreen.center(line.getText()));
                                    lineList.add(line.getText());
                                }
                                lineList.add(BaseActivity.HORIZONTAL_LINE);
                                PrintLines.printSmartStrings(null, lineList, null, "");
                                break;

                            case "A":
                                lineList = new ArrayList<>();
                                lineList.add(line.getText());
                                PrintLines.printSmartStrings(null, lineList, null, "");
                                break;

                            // center bold
                            case "E":
                                boolean pin = new BluDroidUtils().isPinFormat(line.getText());
                                if (pin) {
                                    line.setText(line.getText().replaceAll("\\s{2,}", " "));
                                }
                                ArrayList<String> wrappedLines = BluDroidUtils.wordWrap(line.getText(), pin ? 16 : 32);
                                for (String s : wrappedLines) {
                                    PrintLines.printText(s, ALIGN_CENTER, pin ? FONT_LARGE : FONT_NORMAL, true);
                                }
                                break;

                            case "L":
                                break;

                            default:
                        }
                    }
                    if (barcode != null) {
                        PrintLines.printSmartStrings(null, new ArrayList<String>(), barcode, "");
                    }
                    if (feed) {
                        lineList = new ArrayList<>();
                        lineList.add("\n");
                        lineList.add("\n");
                        PrintLines.printSmartStrings(null, lineList, null, "");
                    }
                }
                int millis = Integer.parseInt(baseScreen.getPreference(PREF_VOUCHER_SECONDS)) * 1000;
                Thread.sleep(millis);
                BaseActivity.logger.info(": done printing");
            }
        } catch (Exception ex) {
            BaseActivity.logger.error("Printing Error: " + ex);
            Log.d(TAG, "exception " + ex);
        }
    }

    public Bitmap convertBitMatrixToBitMap(BitMatrix bitMatrix) {
        try {
            Log.d(TAG, ": convertBitMatrixToBitMap()");
            Bitmap bitmap = Bitmap.createBitmap(bitMatrix.getWidth(), bitMatrix.getHeight(), Bitmap.Config.ARGB_8888);
            for (int k = 0; k < bitMatrix.getWidth(); k++) {
                for (int j = 0; j < bitMatrix.getHeight(); j++) {
                    try {
                        bitmap.setPixel(k, j, bitMatrix.get(k, j) ? Color.BLACK : Color.WHITE);
                    } catch (Exception exception) {
                        Log.v(TAG, "problems " + exception);
                    }
                }
            }
            Log.d(TAG, ": done convert bit matrix to bitmap");
            return bitmap;
        } catch (Exception exception) {
            BaseActivity.logger.error("problem generating bitmap " + exception);
        }
        return null;
    }

    public int getBitmapMaxWidth() {
        return 1000;
    }

    public void print(JSONArray printJob) {
        try {
            for (int i = 0; i < printJob.length(); i++) {
                JSONObject obj = printJob.getJSONObject(i);
                switch (obj.getString("type").toLowerCase()) {
                    case "text":
                        printText(obj);
                        break;
                    case "line":
                        printLine();
                        break;
                    case "barcode":
                        printBarcode(obj);
                        break;
                    case "image":
                        printImage(obj);
                        break;
                }
            }
            PrintLines.printText("\n\n\n", ALIGN_LEFT, FONT_NORMAL, false);
        } catch (Exception e) {
            e.printStackTrace();
            BaseActivity.logger.error("print exception" + e);
        }
    }

    private void printText(JSONObject obj) throws Exception {
        boolean bold;
        int align, size;
        try {
            bold = obj.getString("style").equals("bold");
        } catch (Exception ignore) {
            bold = false;
        }
        try {
            switch (obj.getString("align").toLowerCase()) {
                case "center":
                    align = ALIGN_CENTER;
                    break;
                case "right":
                    align = ALIGN_RIGHT;
                    break;
                default:
                    align = ALIGN_LEFT;
                    break;
            }
        } catch (Exception ignore) {
            align = ALIGN_LEFT;
        }
        try {
            if ("large".equals(obj.getString("size").toLowerCase())) {
                size = FONT_LARGE;
            } else {
                size = FONT_NORMAL;
            }
        } catch (Exception ignore) {
            size = FONT_NORMAL;
        }
        PrintLines.printText(obj.getString("value"), align, size, bold);
    }

    private void printLine() throws Exception {
        char[] array = new char[32];
        Arrays.fill(array, '=');
        PrintLines.printText(new String(array), ALIGN_CENTER, FONT_NORMAL, false);
    }

    private void printBarcode(JSONObject obj) throws Exception {
        BarcodeFormat barcodeFormat;
        int height = 100;
        int width = 384;
        String format = obj.getString("format").toLowerCase();
        switch (format) {
            case "ean13":
                barcodeFormat = BarcodeFormat.EAN_13;
                break;
            case "code39":
                barcodeFormat = BarcodeFormat.CODE_39;
                break;
            case "itf":
                barcodeFormat = BarcodeFormat.ITF;
                break;
            case "code128":
                barcodeFormat = BarcodeFormat.CODE_128;
                break;
            case "pdf417":
                barcodeFormat = BarcodeFormat.PDF_417;
                height = 152;
                width = 320;
                break;
            default:
                return;
        }
        String barcode = obj.getString("value");
        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
        BitMatrix bitMatrix = multiFormatWriter.encode(barcode, barcodeFormat, width, height, null);
        Bitmap bitmap = convertBitMatrixToBitMap(bitMatrix);
        PrintUtil.printPicture(bitmap);
        PrintLines.printText(barcode, ALIGN_CENTER, FONT_NORMAL, false);
    }

    private void printImage(JSONObject obj) throws Exception {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
//            Bitmap logo = new PrintImageUtil(baseActivity).getLogo(obj.getString("id"), obj.getString("url"));
            Bitmap logo = new DynamicPrintUtil(baseActivity).getLogoForPrint(obj.getString("id"));
            if (logo != null) {
                PrintUtil.printPicture(logo);
//                PrintLines.printText("\n", ALIGN_LEFT, FONT_NORMAL, false);
            }
        }
    }

    public void printJsonDefaultLogo(JSONArray printJob, boolean feed) {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            try {
                baseScreen.choosePrintLogo();
                PrintLines.printSmartStrings(baseScreen.bluLogo, new ArrayList<String>(), null, "");
                for (int i = 0; i < printJob.length(); i++) {
                    JSONObject obj = printJob.getJSONObject(i);
                    switch (obj.getString("type").toLowerCase()) {
                        case "text":
                            printText(obj);
                            break;
                        case "line":
                            printLine();
                            break;
                        case "barcode":
                            printBarcode(obj);
                            break;
                        case "image":
                            printImage(obj);
                            break;
                    }
                }
                if (feed) {
                    PrintLines.printText("\n\n\n", ALIGN_LEFT, FONT_NORMAL, false);
                }
            } catch (Exception e) {
                e.printStackTrace();
                BaseActivity.logger.error("print exception" + e);
            }
        }
    }
}