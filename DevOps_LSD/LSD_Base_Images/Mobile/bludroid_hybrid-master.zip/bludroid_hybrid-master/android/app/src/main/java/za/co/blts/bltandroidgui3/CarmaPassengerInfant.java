package za.co.blts.bltandroidgui3;

import java.util.Date;

/**
 * Created by MasiS on 2018/03/05.
 */

class CarmaPassengerInfant extends CarmaPassenger {
    private Date dob;
    private boolean onLap;

    public CarmaPassengerInfant() {
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public boolean isOnLap() {
        return onLap;
    }

    public void setOnLap(boolean onLap) {
        this.onLap = onLap;
    }

    @Override
    public String toString() {
        return "CarmaPassengerInfant{" +
                "dob=" + dob +
                ", onLap=" + onLap +
                ", title='" + title + '\'' +
                ", initials='" + initials + '\'' +
                ", lastName='" + lastName + '\'' +
                ", idNumber='" + idNumber + '\'' +
                ", passport=" + passport +
                ", price='" + price + '\'' +
                '}';
    }
}
