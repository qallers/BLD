package za.co.blts.bltandroidgui3;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

import za.co.blt.interfaces.external.factories.TicketProRequestFactory;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPriceCategoryMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestReservedSeatsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseCreateCartMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePriceCategoryMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseReservedSeatsMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidHeading;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTicketProPriceCategory extends TicketProRecycler implements NeedsAEONResults, View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();
    private ListView listView;

    private ArrayList<TicketProPriceCategory> priceCategories;

    public FragmentTicketProPriceCategory() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_ticket_pro_price_category, container, false);
        BluDroidHeading txtEventName = rootView.findViewById(R.id.eventName);
        TextView txtVenue = rootView.findViewById(R.id.venue);
        TextView txtDate = rootView.findViewById(R.id.date);
        TextView txtTime = rootView.findViewById(R.id.time);
        BluDroidButton btnNext = rootView.findViewById(R.id.next);
        BluDroidButton btnBack = rootView.findViewById(R.id.back);


        btnNext.setOnClickListener(this);
        btnBack.setOnClickListener(this);

        listView = rootView.findViewById(R.id.priceList);


        txtEventName.setText(getBaseActivity().ticketProResponseEventDetailsMessage.getData().getName());

        txtVenue.setText(getBaseActivity().ticketProResponseEventDetailsMessage.getData().getVenueName());

        txtDate.setText(getBaseActivity().ticketProResponseEventDetailsMessage.getData().getStartDate().substring(0, 10));

        txtTime.setText(getBaseActivity().ticketProResponseEventDetailsMessage.getData().getStartTime().substring(10));


        priceCategories = new ArrayList<>();
        for (int i = 0; i < getBaseActivity().ticketProSeatCategory.getPriceCategories().size(); i++) {
            TicketProResponsePriceCategoryMessage priceCategoryMessage = getBaseActivity().ticketProSeatCategory.getPriceCategories().get(i);
            TicketProPriceCategory priceCategory = new TicketProPriceCategory(priceCategoryMessage.getPriceCategoryId(), priceCategoryMessage.getPriceLabel(), priceCategoryMessage.getPrice(), 0);

            priceCategories.add(priceCategory);
        }

        BluDroidTicketProTicketPriceListAdapter ticketProTicketPriceListAdapter = new BluDroidTicketProTicketPriceListAdapter(getBaseActivity(), R.layout.ticketpro_price_row_item, priceCategories);
        listView.setAdapter(ticketProTicketPriceListAdapter);

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

//        getBaseActivity().toolbar.setNavigationDrawable();
//        getBaseActivity().toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                getBaseActivity().gotoMenuFragment();
//            }
//        });
    }

    @Override
    public void onDestroy() {
        if (listView != null) listView.setAdapter(null);
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        BaseActivity.logger.info(((BluDroidButton) v).getText());
        switch (v.getId()) {
            case R.id.next:
                boolean atLeastOne = false;
                for (TicketProPriceCategory priceCategory : priceCategories) {
                    if (priceCategory.getQuantity() > 0) {
                        atLeastOne = true;
                    }
                }
                if (atLeastOne) {
//          addToCart();
                    checkCreateCart();
                } else {
                    getBaseActivity().createAlertDialog("TicketPro", "Please indicate the number of tickets you would like to reserve");
                }

                break;
            case R.id.back:
                getBaseActivity().ticketProSeatCategory = null;
                getBaseActivity().gotoFragment(new FragmentTicketProEventDetails(), "FragmentTicketProEventDetails");
                break;

//            case R.id.cart:
//                Log.i(TAG, "goto cart");
//                getBaseActivity().gotoFragment(new FragmentTicketProViewCart(),"FragmentTicketProViewCart");
//                break;

            default:
                break;
        }
    }

    private void checkCreateCart() {
        if (getBaseActivity().ticketProResponseCreateCartMessage == null) {
            createTicketProCart();
        } else {
            addToCart();
        }
    }


    private void addToCart() {
        try {
            getBaseActivity().createProgress(R.string.addingTicketProItemToCart);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestReservedSeatsMessage ticketProRequestReservedSeatsMessage =
                    factory.createReservedSeats(getBaseActivity().ticketProResponseCreateCartMessage,
                            getBaseActivity().ticketProResponseEventDetailsMessage.getData().getEventId(),
                            getBaseActivity().ticketProSeatCategory.getCategoryId(),
                            "true");

            TicketProRequestPriceCategoryMessage ticketProRequestPriceCategoryMessage;

            for (TicketProPriceCategory priceCategory : priceCategories) {

                if (priceCategory.getQuantity() > 0) {
                    ticketProRequestPriceCategoryMessage = factory.createPriceCategory(priceCategory.getId(), String.valueOf(priceCategory.getQuantity()));
                    ticketProRequestReservedSeatsMessage.getEvent().getPriceCategories().
                            add(ticketProRequestPriceCategoryMessage);
                }

            }
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProRequestReservedSeatsMessage);
        } catch (Exception exception) {
            Log.v(TAG, "addToCart excepton " + exception);
        }
    }


    @Override
    public void results(Object object) {

        try {
            Log.d(TAG, "results object " + object);
            Log.d(TAG, "(PriceCategory) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }

        if (object instanceof TicketProResponseReservedSeatsMessage) {
            getBaseActivity().dismissProgress();
            //read response into temp object, so if there is an error, our saved baseactivity.ticketProResponseReservedSeatsMessage used for cart is not overwritten
            TicketProResponseReservedSeatsMessage ticketProResponseReservedSeatsMessage = (TicketProResponseReservedSeatsMessage) object;

            if (ticketProResponseReservedSeatsMessage.getEvent().getEventCode().equals("0")) {
                //only if no error, update the baseactivity.ticketProResponseReservedSeatsMessage
                getBaseActivity().ticketProResponseReservedSeatsMessage = ticketProResponseReservedSeatsMessage;
                getBaseActivity().gotoFragment(new FragmentTicketProViewCart(), "FragmentTicketProViewCart");
            } else {
                getBaseActivity().returnToFavouritesScreen = true;
                getBaseActivity().createSystemErrorConfirmation(ticketProResponseReservedSeatsMessage, true);
            }
        } else if (object instanceof TicketProResponseCreateCartMessage) {
            getBaseActivity().ticketProResponseCreateCartMessage = (TicketProResponseCreateCartMessage) object;
            getBaseActivity().dismissProgress();
            Log.i(TAG, "after createcartmessage: " + (getBaseActivity().ticketProResponseCreateCartMessage == null ? "null" : getBaseActivity().ticketProResponseCreateCartMessage.toString()));
            //
            // do not remove this log message
            // it iis used for testing purposes
            //
            Log.d(TAG, "TEST : RECEIVED TICKETPRO CART MESSAGE");
            addToCart();
        }

    }

    @Override
    public boolean onBackPressed() {

        getBaseActivity().gotoFragment(new FragmentTicketProEventDetails(), "FragmentTicketProEventDetails");

        return true;
    }
}
