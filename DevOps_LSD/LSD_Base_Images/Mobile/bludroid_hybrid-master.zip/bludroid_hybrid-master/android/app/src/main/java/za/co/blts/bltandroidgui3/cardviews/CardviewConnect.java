package za.co.blts.bltandroidgui3.cardviews;

import za.co.blts.bltandroidgui3.R;

public class CardviewConnect extends CardviewDataObject {

    public CardviewConnect(String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.connect,
                R.color.white,
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(hasAirtimePlus);
    }

    public CardviewConnect(String cardDesc, String cardValue, String voucherType, String tag, String voucherTypeDesc, boolean isMVNO, String code, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.connect,
                R.color.white,
                voucherType, tag, voucherTypeDesc, "", isMVNO, code);
        super.setHasAirtimePlus(hasAirtimePlus);
    }

    public String getBundlesName() {
        return this.getTag() + "Bundles";
    }

    public String getTopupName() {
        return this.getTag();
    }
}

