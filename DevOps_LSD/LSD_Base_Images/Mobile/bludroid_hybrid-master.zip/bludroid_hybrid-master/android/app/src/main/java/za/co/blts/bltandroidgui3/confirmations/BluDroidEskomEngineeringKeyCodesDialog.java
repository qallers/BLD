package za.co.blts.bltandroidgui3.confirmations;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.ImageView;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMeterNumberEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;

/**
 * Created by NkosanaM on 3/29/2017.
 */

public class BluDroidEskomEngineeringKeyCodesDialog extends BluDroidConfirmationDialog implements BluDroidSetupable {
    private final String TAG = this.getClass().getSimpleName();
    public void setup() {
        super.setup();
        setAffirmativeButtonLabel(R.string.update);
        hideView(R.id.neutralButton);
        setNegativeButtonLabel(R.string.cancel);
        setHeading("Engineering Key Codes");
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    public BluDroidEskomEngineeringKeyCodesDialog(BaseActivity context) {
        super(context, R.layout.dialog_eskom_engineering_key_codes);
        setup();
        String TAG = this.getClass().getSimpleName();
        Log.d(TAG, "update meter keys");
        BaseActivity.logger.info(": construction with BaseActivity");
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public String getMeterNumber() {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            return meterEditText.getText().toString();
        } else {
            return "";
        }
    }

    public void setMeterNumber(String meterNumber) {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setText(meterNumber);
        }
    }


    public void setMeterNumberErrorMessage(String errorMessage) {
        BluDroidEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setErrorMessage(errorMessage);
        }
    }

}
