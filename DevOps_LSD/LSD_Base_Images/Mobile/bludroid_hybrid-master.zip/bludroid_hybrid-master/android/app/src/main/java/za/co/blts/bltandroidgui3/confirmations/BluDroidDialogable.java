package za.co.blts.bltandroidgui3.confirmations;

import android.view.View;

@SuppressWarnings("unused")
public interface BluDroidDialogable {

    void affirmativeButton(View view);

    void negativeButton(View view);

    void neutralButton(View view);

}

