package za.co.blts.bltandroidgui3.cardviews;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewFNBConnect extends CardviewDataObject {


    public CardviewFNBConnect(BaseActivity baseActivity, String cardDesc, String cardValue, String voucherType, String tag, String voucherTypeDesc, boolean isMVNO, String code, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.fnbconnect,
                baseActivity.getResources().getColor(R.color.fnbconnect)
                , voucherType, tag, voucherTypeDesc, "", isMVNO, code);
        super.setHasAirtimePlus(hasAirtimePlus);
    }

}

