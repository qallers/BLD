package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.util.AttributeSet;

import com.google.android.material.tabs.TabLayout;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;

//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidTabLayout extends TabLayout implements BluDroidSetupable {

    private WeakReference<BaseActivity> baseActivityWeakReference = null;

    public BluDroidTabLayout(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setup();

    }

    public BluDroidTabLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (context instanceof BaseActivity) {
            this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
            setup();
        }
    }

    public void setup() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                setBackgroundColor(baseActivity.getSkinResources().getButtonColor());
                setTabTextColors(baseActivity.getSkinResources().getButtonTextColor(), baseActivity.getSkinResources().getAccentColor());

                setSelectedTabIndicatorColor(baseActivity.getSkinResources().getAccentColor());
            }
        }
    }

    public void setContext(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    public String getSelectedTab() {
        return getTabAt(getSelectedTabPosition()).getText().toString().trim();
    }
}

