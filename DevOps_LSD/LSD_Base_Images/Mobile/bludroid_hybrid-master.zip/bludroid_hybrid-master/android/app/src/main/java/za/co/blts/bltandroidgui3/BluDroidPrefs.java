package za.co.blts.bltandroidgui3;

public class BluDroidPrefs {
    //
    // preference string names so we don't misspell them
    //

    public static final String PREF_TRUE = "true";
    public static final String PREF_FALSE = "false";

    public static final String PREF_UNKNOWN = "";

    public static final String PREF_MANUAL_OVERRIDE = "manualOverride";

    public static final String PREF_AWS_HEARTBEAT_MINUTES = "heartbeatMinutes";
    public static final String PREF_HEARTBEAT_ENABLE_TECH = "heartbeatEnableTech";
    public static final String PREF_HEARTBEAT_URL = "heartbeatURL";

    public static final String PREF_MENDIX_URL = "mendixUrl";

    public static final String PREF_HOST = "host";
    public static final String PREF_PORT = "port";
    public static final String PREF_USE_SSL = "useSSL";

    public static final String PREF_BLUKEY_URL = "merchantURL";

    public static final String PREF_LOYALTY_ENABLE_TECH = "loyaltyEnableTech";
    public static final String PREF_LOYALTY_ENABLE_USER = "loyaltyEnableUser";
    public static final String PREF_LOYALTY_URL = "loyaltyURL";

    public static final String PREF_DEVICE_ID = "deviceId";
    public static final String PREF_SECURE_USB_PRINTER = "secureUSBPrinter";
    public static final String PREF_CASH_DRAWER = "cashDrawer";
    public static final String PREF_MAG_READER = "magReader";
    public static final String PREF_TECH_PIN = "techPin";
    public static final String PREF_DEVICE_SER = "deviceSer";
    public static final String PREF_AEON_TIMEOUT = "aeonTimeout";
    public static final String PREF_SCREEN_TIMEOUT = "screenTimeout";
    public static final String PREF_TRANSACTION_TIMEOUT = "transactionTimeout";
    public static final String PREF_CASHIER_END_SHIFT = "cashierEndShift";
    public static final String PREF_PRINT_PREVIEWS = "printPreview";
    public static final String PREF_PRINT_PREVIEW_RECEIPTS = "printPreviewReceipts";
    public static final String PREF_PRINT_MERCHANT_VOUCHER = "printMerchantVoucher";
    public static final String PREF_PRINT_MERCHANT_VOUCHER_TICKETS = "printMerchantVoucherTickets";
    public static final String PREF_PRINT_SALES_RECEIPT = "printSalesReceipt";
    public static final String PREF_PRINT_BARCODE_RECEIPT = "printBarcodeReceipt";
    public static final String PREF_STORE_NAME = "storeName";
    public static final String PREF_STORE_ADDRESS = "storeAddress";
    public static final String PREF_VAT_REG_NO = "VATRegNo";
    public static final String PREF_RICA_HOST = "ricaHost";
    public static final String PREF_RICA_PORT = "ricaPort";
    public static final String PREF_RICA_USER_PIN = "ricaUserPin";
    public static final String PREF_RICA_DEVICE_ID = "ricaDeviceId";
    public static final String PREF_RICA_DEVICE_SER = "ricaDeviceSer";
    public static final String PREF_RICA_USERNAME = "ricaUsername";
    public static final String PREF_RICA_PASSWORD = "ricaPassword";
    public static final String PREF_RICA_USE_SSL = "ricaUseSSL";
    public static final String PREF_RICA_CAN_BOXRICA = "canBoxRica";

    public static final String PREF_PRINTER_WIDTH = "printerWidth";
    public static final String PREF_PAPER_CUTTER = "paperCutter";

    public static final String PREF_FDROID_REPO_URL = "fdroidRepoURL";
    public static final String PREF_FDROID_REPO_DIR = "fdroidRepoDir";

    public static final String PREF_SCANNING_APP = "scanningApp";

    public static final String PREF_EPUB_READER_URL = "ePubReaderURL";
    public static final String PREF_EPUB_MANUAL_URL = "ePubManualURL";

    public static final String PREF_PUTCO_PAPER_CHECK_SLEEP_TIME = "putcoPaperCheckSleepTime";
    public static final String PREF_PUTCO_URL = "putcoUrl";
    public static final String PREF_USB_PRINT_TIMEOUT = "usbPrintTimeout";

    public static final String PREF_VOUCHER_SECONDS = "voucherSeconds";
    public static final String PREF_SKIN = "skin";
    public static final String PREF_PREVIOUS_SKIN = "previousSkin";

    public static final String PREF_CREATE_ICON = "create_icon";
    public static final String PREF_CREATE_LANDING_ICON = "create_landing_icon";

    public static final String PREF_BP_LIMIT = "bpLimit";

    public static final String PREF_DEF_ACCOUNT = "defAccount";
    public static final String PREF_DEF_ACCOUNT_INDEX = "defAccountIndex";
    public static final String PREF_DISPLAY_BALANCE1 = "showBalance";
    public static final String PREF_LOW_BALANCE_AMOUNT = "lowBalanceAMount";
    public static final String PREF_ACCOUNT_BALANCE = "accountBalance";
    public static final String PREF_BALANCE = "balance";
    public static final String PREF_BALANCEAMT = "balanceAmt";
    public static final String PREF_PROFIT = "profit";
    public static final String PREF_PROFIT_DISPLAY_ENABLED = "profitDisplayEnabled";
    public static final String PREF_BALANCE_DISPLAY_ENABLED = "balanceDisplayEnabled";

    public static final int MAX_ACCOUNT_DISPLAY = 2;

    //NB !!! this was cha nge to calculator on the GUI
    public static final String PREF_USE_BASKET = "useBasket";

    public static final String PREF_MAX_CACHE_AGE = "maxCacheAge";

    //Error Loging
    public static final String PREF_GRAY_LOG_URL = "grayLogURL";
    public static final String PREF_GRAY_LOG_LEVEL = "grayLogLevel";

    public static final String PREF_LOG_LEVEL = "logLevel";
    public static final String PREF_LOG_DAYS = "logDays";

    public static final String PREF_DISK_IMAGE_CACHE_CLEARED_DATE = "diskImageCachedCleared";

    public static final String PREF_FAVOURITES_VERSION = "favourites_version";

    public static final String PREF_IOT_FLAG_ENABLE = "iot_flag_enable";

    public static final String PREF_DOWNLOAD_DECLINE = "download_decline";
    public static final String PREF_INSTALL_DECLINE = "install_decline";
    public static final String PREF_UPDATE_DATE = "update_date";
    public static final String PREF_CURRENT_VERSION = "current_version";
    public static final String PREF_RESET_DECLINE_COUNT = "reset_decline";

    public static final String PREF_ACCOUNT_DETAILS = "account_details";

    public static final String PREF_DYNAMIC_PRINT_COUNTS = "dynamicPrintCounts";
    public static final String PREF_DYNAMIC_PRINT_INDEX = "dynamicPrintIndex";

    public static final String PREF_LAST_LOGIN = "last_login";

    public static final String PREF_PRINT_APP_VERSION = "print_app_version";

    public static final String PREF_LOCATION_CHECK = "location_check";
    public static final String PREF_SAVED_LOCATION = "saved_location";

}
