package za.co.blts.bltandroidgui3;

import android.os.AsyncTask;
import android.util.Log;

import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;

/**
 * Created by NkosanaM on 1/22/2018.
 */

class UsbResultHttpPutAsyncTask extends AsyncTask<Object, Void, HashMap<String, String>> {

    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference;


    public UsbResultHttpPutAsyncTask(BaseActivity baseScreen) {
        this.baseActivityWeakReference = new WeakReference<>(baseScreen);
    }

    //objects[0] = (Activity) baseActivity
    //objects[1] = String url
    //objects[2] = (HashMap<String,String>) trxID,responseCode
    //objects[3] = (byte[]) payload					* Optional
    @Override
    protected HashMap<String, String> doInBackground(Object... objects) {
        HashMap<String, String> newTrxIdMap = new HashMap<>();
        try {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                Log.v(TAG, "doInBackground got " + objects.length + " parameters");
                baseActivity = (BaseActivity) objects[0];
                String url = (String) objects[1];
                @SuppressWarnings("unchecked")
                HashMap<String, String> trxIdMap = (HashMap<String, String>) objects[2];
                byte[] payload = new byte[0];
                // Any payload parameters ?
                if (objects.length > 3) {
                    payload = (byte[]) objects[3];
                }
                for (Map.Entry<String, String> entry : trxIdMap.entrySet()) {
                    Date startTime = new Date();
                    Log.d(TAG, "starting http at : " + startTime.getTime());
                    HTTPUtils httpUtils = new HTTPUtils(baseActivity.isDebug());
                    try {
                        BaseActivity.logger.info(" sending usb print result " + entry.getKey() + ":" + entry.getValue() + " to " + url);

                        String results = httpUtils.putData(buildUrlParameters(url, entry), payload);
                        // We add the entry back into our list in order to retry in the future
                        if (!results.matches("200")) {
                            newTrxIdMap.put(entry.getKey(), entry.getValue());
                            Thread.sleep(1000);   // If we have an error we need to make sure we don't tight loop
                        }
                    } catch (Exception ex) {
                        Log.d(TAG, "Exception in doInBackground (putData): " + ex + " for entry: " + entry);
                    }
                    Date endTime = new Date();
                    Log.d(TAG, "gotback http at : " + endTime.getTime() + " " + (endTime.getTime() - startTime.getTime()));
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "Exception in doInBackground: " + exception);
        }
        return newTrxIdMap;
    }

    @Override
    protected void onPostExecute(HashMap<String, String> resultsMap) {
        Log.d(TAG, "onPostExecute - resultsMap: " + resultsMap);
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            ((NeedsUSBResults) baseActivity).results(resultsMap);
        }
    }

    /**
     * @param url       ie http://domain.com
     * @param urlParams Map of url parameters
     * @return new url with constructed with parameters in the form: url?trxID=key&code=value
     */
    private String buildUrlParameters(String url, Map.Entry<String, String> urlParams) throws UnsupportedEncodingException {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        StringBuilder urlWithParams = new StringBuilder();
        if (baseActivity != null) {
            urlWithParams.append(url).append("?");
            urlWithParams.append(URLEncoder.encode("trxID", "UTF-8"));
            urlWithParams.append("=");
            urlWithParams.append(URLEncoder.encode(urlParams.getKey(), "UTF-8"));
            urlWithParams.append("&");
            urlWithParams.append(URLEncoder.encode("code", "UTF-8"));
            urlWithParams.append("=");
            urlWithParams.append(URLEncoder.encode(urlParams.getValue(), "UTF-8"));
            urlWithParams.append("&");
            urlWithParams.append(URLEncoder.encode("swVer", "UTF-8"));
            urlWithParams.append("=");
            urlWithParams.append(URLEncoder.encode(baseActivity.getVersionName(), "UTF-8"));
//            urlWithParams.append(URLEncoder.encode(baseActivity.getResources().getString(R.string.version), "UTF-8"));
            urlWithParams.append("&");
            urlWithParams.append(URLEncoder.encode("deviceID", "UTF-8"));
            urlWithParams.append("=");
            urlWithParams.append(URLEncoder.encode(baseActivity.getPreference(PREF_DEVICE_ID), "UTF-8"));
        }
        return urlWithParams.toString();
    }
}
