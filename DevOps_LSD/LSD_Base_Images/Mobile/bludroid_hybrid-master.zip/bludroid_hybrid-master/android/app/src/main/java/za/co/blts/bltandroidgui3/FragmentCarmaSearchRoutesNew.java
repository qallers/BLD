package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.math.BigDecimal;
import java.net.Socket;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import za.co.blt.interfaces.external.factories.CarmaRequestFactory;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestCarrierListMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestCityListMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestClassListMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestPassengerTypeListMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestTitleListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseAvailabilityMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseCarrierListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseCityListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseClassListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseDestinationsListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseItemMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponsePassengerTypeListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseReserveSeatsMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseTitleListMessage;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDatePickerDialog;
import za.co.blts.bltandroidgui3.longhaul.cancellations.TicketCacheHandler;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidMandatoryAutoCompleteTextView;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidScrollView;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static java.lang.String.valueOf;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;

/**
 * Created by NkosanaM.
 */

public class FragmentCarmaSearchRoutesNew extends BaseFragment implements NeedsAEONResults, AdapterView.OnItemSelectedListener {

    private final String TAG = this.getClass().getSimpleName();

    private String filteredCriteria = "";
    private BluDroidRelativeLayout return_date_layout;
    private BluDroidRelativeLayout search_routes_relativelayout_id;


    private BluDroidDatePickerDialog departure_date_dialog;
    private BluDroidDatePickerDialog return_date_dialog;

    private BluDroidRadioButton return_trip;
    private BluDroidButton search_trip_btn;
    private BluDroidTextView departure_date;
    private BluDroidTextView return_date;

    private BluDroidScrollView searchScrollView;
    private BluDroidTextView departureLabel, destinationLabel;

    // departure
    private BluDroidMandatoryAutoCompleteTextView departureSpinner;

    // destination
    private BluDroidMandatoryAutoCompleteTextView destinationSpinner;

    // travel class
    private BluDroidSpinner travel_class_spinner;
    private int travelClassesPos = 0;

    private BluDroidTextView seat_number_value;
    private ImageView add_seat_number;
    private ImageView minus_seat_number;

    private Date now = new Date();

    //----------------------------------------------------------------------------------------------
    public FragmentCarmaSearchRoutesNew() {
    }

    //----------------------------------------------------------------------------------------------
    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_bus_service, container, false);

        final BaseActivity baseActivity = getBaseActivity();
        BluDroidRadioButton one_way_trip = rootView.findViewById(R.id.one_way_trip);
        search_routes_relativelayout_id = rootView.findViewById(R.id.search_routes_relativelayout_id);
        return_trip = rootView.findViewById(R.id.return_trip);
        final ImageButton departure_date_calender = rootView.findViewById(R.id.departure_date_calender);
        ImageButton return_date_calender = rootView.findViewById(R.id.return_date_calender);
        return_date_layout = rootView.findViewById(R.id.return_date_layout);
        search_trip_btn = rootView.findViewById(R.id.search_trip_btn);
        BluDroidButton back_search_trip_btn = rootView.findViewById(R.id.back_search_trip_btn);
        departure_date = rootView.findViewById(R.id.departure_date);
        return_date = rootView.findViewById(R.id.return_date);
        departureSpinner = rootView.findViewById(R.id.departs_from_input);
        destinationSpinner = rootView.findViewById(R.id.destination_to_input);
        travel_class_spinner = rootView.findViewById(R.id.travel_class_spinner);

        searchScrollView = rootView.findViewById(R.id.searchScrollView);
        departureLabel = rootView.findViewById(R.id.departureLabel);
        destinationLabel = rootView.findViewById(R.id.destinationLabel);

        departureSpinner.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                getBaseActivity().availabilitySearchQuery.setDeparturePointName(((TextView) view.findViewById(R.id.lbl_name)).getText().toString());

                for (CarmaResponseItemMessage carmaResponseItemMessage : getBaseActivity().carmaResponseCityListMessage.getData().getItems()) {
                    if (carmaResponseItemMessage.getName().equalsIgnoreCase(getBaseActivity().availabilitySearchQuery.getDeparturePointName())) {
                        getBaseActivity().availabilitySearchQuery.setDeparturePoint(carmaResponseItemMessage.getCode());
                        break;
                    }
                }
            }
        });

        destinationSpinner.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                getBaseActivity().availabilitySearchQuery.setDestinationPointName(((TextView) view.findViewById(R.id.lbl_name)).getText().toString());

                for (CarmaResponseItemMessage carmaResponseItemMessage : getBaseActivity().carmaResponseCityListMessage.getData().getItems()) {
                    if (carmaResponseItemMessage.getName().equalsIgnoreCase(getBaseActivity().availabilitySearchQuery.getDestinationPointName())) {
                        getBaseActivity().availabilitySearchQuery.setDestinationPoint(carmaResponseItemMessage.getCode());
                        break;
                    }
                }

            }
        });

        departureSpinner.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                searchScrollView.post(new Runnable() {
                    @Override
                    public void run() {
                        searchScrollView.smoothScrollTo(0, departureLabel.getTop());
                        departureSpinner.requestFocus();
                    }
                });
                return false;
            }
        });

        destinationSpinner.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                searchScrollView.post(new Runnable() {
                    @Override
                    public void run() {
                        searchScrollView.smoothScrollTo(0, destinationLabel.getTop());
                        destinationSpinner.requestFocus();
                    }
                });
                return false;
            }
        });

        one_way_trip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidRadioButton) v).getText());
                if (((BluDroidRadioButton) v).isChecked()) {
                    // INVISIBLE/GONE layout return date
                    return_date.setText("");
                    getBaseActivity().availabilitySearchQuery.setReturnDate(""); // set it to nothing
                    return_date_layout.setVisibility(View.GONE); // INVISIBLE to be able to reference subviews
                    getBaseActivity().availabilitySearchQuery.setReturnTrip(false);
                    // reset the return trip data
                    getBaseActivity().bluDroidRoutesAndTimesReturn = null;
                    getBaseActivity().returnRoutes.clear();
                }
            }
        });

        return_trip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidRadioButton) v).getText());
                if (((BluDroidRadioButton) v).isChecked()) {
                    // VISIBLE layout return date
                    return_date_layout.setVisibility(View.VISIBLE);
                    getBaseActivity().availabilitySearchQuery.setReturnTrip(true);
                }
            }
        });



        // attach event
        departure_date_calender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info("departure calendar");
                departure_date_dialog = getBaseActivity().createDatePickerDialog(getBaseActivity());

                if (Build.MODEL.startsWith("CITAQ"))
                    departure_date_dialog.setMinDate(Calendar.getInstance().getTimeInMillis() -
                        ((24 * 60 * 60 * 1000)));
                else
                    departure_date_dialog.setMinDate(Calendar.getInstance().getTimeInMillis());

                departure_date_dialog.setPositiveOption("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        getBaseActivity().availabilitySearchQuery.setDepartureDate(departure_date_dialog.getDate());
                        departure_date.setText(departure_date_dialog.getDate()); // set date to text view
                    }
                });
                departure_date_dialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        departure_date_dialog.dismiss();
                    }
                });


                departure_date_dialog.createDialog();
            }
        });

        // attach event
        return_date_calender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info("return calendar");
                return_date_dialog = baseActivity.createDatePickerDialog(baseActivity);
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

                try {
                    Date date = sdf.parse(departure_date.getText().toString());
                    return_date_dialog.setMinDate(date.getTime());
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                return_date_dialog.setPositiveOption("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getBaseActivity().availabilitySearchQuery.setReturnDate(return_date_dialog.getDate());
                        return_date.setText(return_date_dialog.getDate()); // set date to text view
                    }
                });

                return_date_dialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        return_date_dialog.dismiss();
                    }
                });

                return_date_dialog.createDialog();
            }
        });

        // hide return date if the user opted for not return, this is by default
        return_date_layout.setVisibility(View.GONE);

        // adult
        add_seat_number = rootView.findViewById(R.id.add_adult_number);
        minus_seat_number = rootView.findViewById(R.id.minus_adult_number);
        seat_number_value = rootView.findViewById(R.id.adult_number_value);


        // child number of passengers
        add_seat_number.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, " Add seats");
                // color buttons
                if (computeSeats() < 10) {
                    if (getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() < 10) {
                        int adults = getBaseActivity().availabilitySearchQuery.getNumberOfPassengers();
                        adults++;
                        getBaseActivity().availabilitySearchQuery.setNumberOfPassengers(adults);
                        seat_number_value.setText(valueOf(getBaseActivity().availabilitySearchQuery.getNumberOfPassengers()));
                        computeSeats();
                        add_seat_number.setColorFilter(baseActivity.getResources().getColor(R.color.accentColorDEF), android.graphics.PorterDuff.Mode.SRC_IN);
                        if (getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() > 0)
                            minus_seat_number.setColorFilter(baseActivity.getResources().getColor(R.color.accentColorDEF), android.graphics.PorterDuff.Mode.SRC_IN);
                        if (getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() == 10)
                            add_seat_number.setColorFilter(baseActivity.getResources().getColor(R.color.lightGrey), android.graphics.PorterDuff.Mode.SRC_IN);
                    }
                }
            }
        });

        minus_seat_number.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, " minus seats");
                if (getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() > 0) { // decrease if less greater than zero
                    int adults = getBaseActivity().availabilitySearchQuery.getNumberOfPassengers();
                    adults--;
                    getBaseActivity().availabilitySearchQuery.setNumberOfPassengers(adults);
                    seat_number_value.setText(valueOf(getBaseActivity().availabilitySearchQuery.getNumberOfPassengers()));
                    computeSeats();
                    minus_seat_number.setColorFilter(baseActivity.getResources().getColor(R.color.accentColorDEF), android.graphics.PorterDuff.Mode.SRC_IN);
                    if (getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() < 10)
                        add_seat_number.setColorFilter(baseActivity.getResources().getColor(R.color.accentColorDEF), android.graphics.PorterDuff.Mode.SRC_IN);
                    if (getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() == 0)
                        minus_seat_number.setColorFilter(baseActivity.getResources().getColor(R.color.lightGrey), android.graphics.PorterDuff.Mode.SRC_IN);
                }
            }
        });

        search_trip_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                getBaseActivity().fragmentCarmaPassengerDetailsWizard = null;
                if (validateSearchQuery()) {
                    getBaseActivity().carmaResponseAvailabilityExtendedMessage = null;
                    getBaseActivity().fragmentCarmaSearchResults = new FragmentCarmaSearchResults();
                    getBaseActivity().gotoFragment(getBaseActivity().fragmentCarmaSearchResults, "FragmentCarmaSearchResults");
                }
            }
        });

        back_search_trip_btn.setOnClickListener(new View.OnClickListener() { // back not cancel
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();


        return rootView;
    }

    //----------------------------------------------------------------------------------------------
    private int computeSeats() { // this method is juicy

        // reset fragments and all except for the availabilitySearchQuery :)
        getBaseActivity().initLongHaulVariables();
        int total_seats = 0;
        // do the computation

        // reset
        if (getBaseActivity().availabilitySearchQuery.getNumberOfPassengersInfants() == getBaseActivity().availabilitySearchQuery.getNumberOfPassengers())
            getBaseActivity().availabilitySearchQuery.setNumberOfConvertedInfantsToChildPassengers(0);

        total_seats = total_seats + (getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() + getBaseActivity().availabilitySearchQuery.getNumberOfPassengersChild());
        if (getBaseActivity().availabilitySearchQuery.getNumberOfPassengersInfants() - getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() > 0) { // difference
            getBaseActivity().availabilitySearchQuery.setNumberOfConvertedInfantsToChildPassengers(getBaseActivity().availabilitySearchQuery.getNumberOfPassengersInfants() - getBaseActivity().availabilitySearchQuery.getNumberOfPassengers());
            total_seats = total_seats + getBaseActivity().availabilitySearchQuery.getNumberOfConvertedInfantsToChildPassengers();
        }

        getBaseActivity().availabilitySearchQuery.setNumberOfInfantsOnlap(getBaseActivity().availabilitySearchQuery.getNumberOfPassengersInfants() - getBaseActivity().availabilitySearchQuery.getNumberOfConvertedInfantsToChildPassengers());

        getBaseActivity().availabilitySearchQuery.setTotalNumberOfSeatsToReserve(total_seats);
        return total_seats;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        try {
            filteredCriteria = getArguments().getString("filteredCriteria");
            getBaseActivity().carrierCode = getArguments().getString("carrierCode");
            setTitle(filteredCriteria);
            if (getBaseActivity().availabilitySearchQuery == null) {
                getBaseActivity().availabilitySearchQuery = new AvailabilitySearchQuery();
                getBaseActivity().availabilitySearchQuery.setReturnTrip(false);
                getBaseActivity().availabilitySearchQuery.setCarrierCode(getArguments().getString("carrierCode"));
                getActivity().setTitle(filteredCriteria);
            }
            TicketCacheHandler ticketCacheHandler = new TicketCacheHandler(getBaseActivity().ticketCancelCacheDir);
            ticketCacheHandler.removeExpiredCaches();

            prepareCarma();
        } catch (Exception e) {
            e.printStackTrace();
            BaseActivity.logger.error("onActivityCreated exception" + e);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        configureViews();
    }

    //----------------------------------------------------------------------------------------------
    private void configureViews() {

        if (getBaseActivity().availabilitySearchQuery != null) {
            // adult
            minus_seat_number.setColorFilter(getContext().getResources().getColor(R.color.accentColorDEF), android.graphics.PorterDuff.Mode.SRC_IN);
            if (getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() < 10)
                add_seat_number.setColorFilter(getContext().getResources().getColor(R.color.accentColorDEF), android.graphics.PorterDuff.Mode.SRC_IN);
            if (getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() == 0)
                minus_seat_number.setColorFilter(getContext().getResources().getColor(R.color.lightGrey), android.graphics.PorterDuff.Mode.SRC_IN);

            // departure
            configureDepartureSpinner();
            departureSpinner.setText(getBaseActivity().availabilitySearchQuery.getDeparturePointName());
            // destination
            configureDestinationSpinner();
            destinationSpinner.setText(getBaseActivity().availabilitySearchQuery.getDestinationPointName());
            // travel class
            configureTravelClassSpinner();
            travel_class_spinner.setSelection(travelClassesPos);
            //the date
            departure_date.setText(String.valueOf(getBaseActivity().availabilitySearchQuery.getDepartureDate()));
            if (getBaseActivity().availabilitySearchQuery.isReturnTrip()) {
                // isReturn
                return_trip.setChecked(true);
                return_date_layout.setVisibility(View.VISIBLE);
                return_date.setText(String.valueOf(getBaseActivity().availabilitySearchQuery.getReturnDate()));
            }

            // passenger things
            seat_number_value.setText(String.valueOf(getBaseActivity().availabilitySearchQuery.getNumberOfPassengers()));
        }
    }

    //----------------------------------------------------------------------------------------------
    private void setTitle(String title) {
        String filteredCriteria1 = title;
        if (filteredCriteria.equalsIgnoreCase("City to city")) {
            filteredCriteria1 = "citytocity";
        }
        getActivity().setTitle(title);
        getBaseActivity().carrierCode = filteredCriteria1;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean onBackPressed() {
        getBaseActivity().availabilitySearchQuery = null;
        getBaseActivity().fragmentCarmaSearchResults = null;
        getBaseActivity().departureRoutes.clear();
        getBaseActivity().returnRoutes.clear();

        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else {
            getBaseActivity().gotoFragment(new FragmentTickets(), "FragmentTickets");
        }
        return true;
    }

    // Carma implementation
    //----------------------------------------------------------------------------------------------
    private void prepareCarma() {
        try {
            getBaseActivity().availabilitySearchQuery.setCarrierName(getBaseActivity().carrierCode);
            getBaseActivity().createProgress(R.string.authenticating);
            CarmaRequestFactory factory = new CarmaRequestFactory();

            getBaseActivity().carmaAuthenticationRequestMessage =
                    factory.create(
                            BaseActivity.loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER));

            if (BaseActivity.completeConsumerProfile != null) {
                getBaseActivity().carmaAuthenticationRequestMessage.getEvent().setLoyaltyProfileId(BaseActivity.completeConsumerProfile.getConsumer().getProfileId());
            }
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, getBaseActivity().carmaAuthenticationRequestMessage);
        } catch (Exception exception) {
            //Log.v(TAG, "prepareCarma throws " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    private void requestTitles() {
        try {
            getBaseActivity().createProgress(R.string.gettingTitles);
            CarmaRequestFactory factory = new CarmaRequestFactory();
            CarmaRequestTitleListMessage request = factory.createTitleList(getBaseActivity().carmaAuthenticationResponseMessage);
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, request);
        } catch (Exception exception) {
            //Log.v(TAG, "requestTitles throws " + exception);
            //Log.v(TAG, "prepareCarma throws " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    private void requestClasses() {
        try {
            getBaseActivity().createProgress(R.string.gettingTravelClasses);
            CarmaRequestFactory factory = new CarmaRequestFactory();
            CarmaRequestClassListMessage request = factory.createClassList(getBaseActivity().carmaAuthenticationResponseMessage);

            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, request);

        } catch (Exception exception) {
            //Log.v(TAG, "requestClasses throws " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    private void requestPassengerTypes() {
        try {
            getBaseActivity().createProgress(R.string.gettingPassengerTypes);
            CarmaRequestFactory factory = new CarmaRequestFactory();
            CarmaRequestPassengerTypeListMessage request = factory.createPassengerTypeList(getBaseActivity().carmaAuthenticationResponseMessage);

            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, request);

        } catch (Exception exception) {
            //Log.v(TAG, "requestPassengerTypes throws " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    private void requestDepartures() {
        try {
            getBaseActivity().createProgress(R.string.gettingDepartures);
            CarmaRequestFactory factory = new CarmaRequestFactory();
            CarmaRequestCityListMessage request = factory.createCityList(getBaseActivity().carmaAuthenticationResponseMessage);

            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, request);

        } catch (Exception exception) {
            //Log.v(TAG, "requestDepartures throws " + exception);
        }
    }

    private void getCarrierlist() {
        try {
            getBaseActivity().createProgress(R.string.gettingCarriers);
            CarmaRequestFactory factory = new CarmaRequestFactory();
            CarmaRequestCarrierListMessage request = factory.createCarrierList(getBaseActivity().carmaAuthenticationResponseMessage);

            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, request);

        } catch (Exception exception) {
            //Log.v(TAG, "requestDepartures throws " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    //used for departure and destination
    private void configureDepartureSpinner() {
        if (getBaseActivity().carmaResponseCityListMessage != null) {
            ArrayList<String> departures = new ArrayList<>();
            for (int i = 0; i < getMainActivity().carmaResponseCityListMessage.getData().getItems().size(); i++) {
                departures.add(getMainActivity().carmaResponseCityListMessage.getData().getItems().get(i).getName());
            }
            departureSpinner.setAdapter(new BluDroidPlacesAdapter(getBaseActivity(), R.layout.support_simple_spinner_dropdown_item, departures));
            departureSpinner.setFocusable(true); //  http://stackoverflow.com/questions/6443212/spinner-does-not-get-focus
            departureSpinner.setOnItemSelectedListener(this); // because this implements the methods

            destinationSpinner.setAdapter(new BluDroidPlacesAdapter(getBaseActivity(), R.layout.support_simple_spinner_dropdown_item, departures));
            destinationSpinner.setFocusable(true); //  http://stackoverflow.com/questions/6443212/spinner-does-not-get-focus
            destinationSpinner.setOnItemSelectedListener(this); // because this implements the methods
        }
    }

    //----------------------------------------------------------------------------------------------
    private void configureDestinationSpinner() {

        if (getMainActivity().carmaResponseCityListMessage != null) {
            ArrayList<String> destinations = new ArrayList<>();
            for (int i = 0; i < getMainActivity().carmaResponseCityListMessage.getData().getItems().size(); i++) {
                destinations.add(getMainActivity().carmaResponseCityListMessage.getData().getItems().get(i).getName());
            }
            destinationSpinner.setAdapter(new BluDroidPlacesAdapter(getBaseActivity(), R.layout.support_simple_spinner_dropdown_item, destinations));
            destinationSpinner.setFocusable(true); //  http://stackoverflow.com/questions/6443212/spinner-does-not-get-focus
            destinationSpinner.setOnItemSelectedListener(this); // because this implements the methods
        }
    }

    //----------------------------------------------------------------------------------------------
    private void configureTravelClassSpinner() {
        if (getMainActivity().carmaResponseClassListMessage != null) {
            List<String> travelClasses = new ArrayList<>();
            for (int i = 0; i < getMainActivity().carmaResponseClassListMessage.getData().getItems().size(); i++) {
                travelClasses.add(getMainActivity().carmaResponseClassListMessage.getData().getItems().get(i).getName());
            }

            // create an adapter and set dataset
            travel_class_spinner.setAdapter(new ArrayAdapter<>(getBaseActivity(), R.layout.support_simple_spinner_dropdown_item, travelClasses));
            travel_class_spinner.setOnItemSelectedListener(this);
        }
    }

    //----------------------------------------------------------------------------------------------
    public void results(Object obj) {
        try {
            Log.d("MPKresults", "(CarmaSearch) class " + obj.getClass().getSimpleName());
        } catch (Exception ignore) {
        }

        getBaseActivity().dismissProgress();

        if (obj instanceof CarmaAuthenticationResponseMessage) {
            getBaseActivity().carmaAuthenticationResponseMessage = (CarmaAuthenticationResponseMessage) obj;
            if (getBaseActivity().carmaAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

                if (getBaseActivity().authenticatingForTitles) {
                    getBaseActivity().carmaResponseTitleListMessage = getBaseActivity().getCachedCarmaTitlesList();
                    if ((getBaseActivity().carmaResponseTitleListMessage == null) || ((now.getTime() - getBaseActivity().dateLastCarmaCache().getTime()) > getBaseActivity().CACHE_12_HOURS)) {
                        getBaseActivity().removeCarmaCache();
                        requestTitles();
                    } else {
                        results(getBaseActivity().carmaResponseTitleListMessage);
                    }

                }
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaAuthenticationResponseMessage, true);
                search_trip_btn.setEnabled(false);
                search_trip_btn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            }

        } else if (obj instanceof CarmaResponseTitleListMessage) {
            //Log.d(TAG, "got back title list");
            getBaseActivity().carmaResponseTitleListMessage = (CarmaResponseTitleListMessage) obj;

            if (getBaseActivity().carmaResponseTitleListMessage.getEvent().getEventCode().equals("0")) {
                getBaseActivity().cacheCarmaTitlesListData();
                getBaseActivity().carmaResponseClassListMessage = getBaseActivity().getCachedCarmaTravelClasses();

                if ((getBaseActivity().carmaResponseClassListMessage == null) || ((now.getTime() - getBaseActivity().dateLastCarmaCache().getTime()) > getBaseActivity().CACHE_12_HOURS)) {
                    requestClasses();
                } else {
                    results(getBaseActivity().carmaResponseClassListMessage);
                }
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaResponseTitleListMessage, true);
                search_trip_btn.setEnabled(false);
                search_trip_btn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            }

        } else if (obj instanceof CarmaResponseClassListMessage) {
            //Log.d(TAG, "got back travel class list");
            getBaseActivity().carmaResponseClassListMessage = (CarmaResponseClassListMessage) obj;
            if (getBaseActivity().carmaResponseClassListMessage.getEvent().getEventCode().equals("0")) {

                getBaseActivity().cacheCarmaTravelClassesData();
                configureTravelClassSpinner();
                getBaseActivity().carmaResponsePassengerTypeListMessage = getBaseActivity().getCachedCarmaPassengerTypes();

                if ((getBaseActivity().carmaResponsePassengerTypeListMessage == null) || ((now.getTime() - getBaseActivity().dateLastCarmaCache().getTime()) > getBaseActivity().CACHE_12_HOURS)) {
                    requestPassengerTypes();
                } else {
                    results(getBaseActivity().carmaResponsePassengerTypeListMessage);
                }
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaResponseClassListMessage, true);
                search_trip_btn.setEnabled(false);
                search_trip_btn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            }

        } else if (obj instanceof CarmaResponsePassengerTypeListMessage) {
            //Log.d(TAG, "got back travel PassengerType list");
            getBaseActivity().carmaResponsePassengerTypeListMessage = (CarmaResponsePassengerTypeListMessage) obj;
            if (getBaseActivity().carmaResponsePassengerTypeListMessage.getEvent().getEventCode().equals("0")) {

                getBaseActivity().cacheCarmaPassengerTypesData();
                getBaseActivity().carmaResponseCityListMessage = getBaseActivity().getCachedCarmaCityList();

                if ((getBaseActivity().carmaResponseCityListMessage == null) || ((now.getTime() - getBaseActivity().dateLastCarmaCache().getTime()) > getBaseActivity().CACHE_12_HOURS)) {
                    requestDepartures();
                } else {
                    results(getBaseActivity().carmaResponseCityListMessage);
                }
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaResponsePassengerTypeListMessage, true);
            }

        } else if (obj instanceof CarmaResponseCityListMessage) {
            //Log.d(TAG, "got back departures list");
            getBaseActivity().carmaResponseCityListMessage = (CarmaResponseCityListMessage) obj;
            if (getBaseActivity().carmaResponseCityListMessage.getEvent().getEventCode().equals("0")) {

                if (!getMainActivity().carmaResponseCityListMessage.getData().getItems().isEmpty()) {

                    getBaseActivity().cacheCarmaCityListData();

                    configureDepartureSpinner();
                    getBaseActivity().carmaResponseCarrierListMessage = getBaseActivity().getCachedCarmaCarrierList();

                    if ((getBaseActivity().carmaResponseCarrierListMessage == null) || ((now.getTime() - getBaseActivity().dateLastCarmaCache().getTime()) > getBaseActivity().CACHE_12_HOURS)) {
                        getCarrierlist();
                    } else {
                        results(getBaseActivity().carmaResponseCarrierListMessage);
                    }
                } else {
                    getBaseActivity().createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, getContext().getResources().getString(R.string.empty_city_list), true);
                    search_trip_btn.setEnabled(false);
                    search_trip_btn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                }
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaResponseCityListMessage, true);
                search_trip_btn.setEnabled(false);
                search_trip_btn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            }
        } else if (obj instanceof CarmaResponseCarrierListMessage) {
            //Log.d(TAG, "got back departures list");
            getBaseActivity().carmaResponseCarrierListMessage = (CarmaResponseCarrierListMessage) obj;
            getBaseActivity().closeAeonSocket(27);
            if (getBaseActivity().carmaResponseCarrierListMessage.getEvent().getEventCode().equals("0")) {
                getBaseActivity().cacheCarmaCarrierListData();

            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaResponseCarrierListMessage, true);
                search_trip_btn.setEnabled(false);
                search_trip_btn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            }

        } else if (obj instanceof CarmaResponseDestinationsListMessage) {
            //Log.d(TAG, "got back Destinations list");
            getBaseActivity().carmaResponseDestinationsMessage = (CarmaResponseDestinationsListMessage) obj;
            if (getBaseActivity().carmaResponseDestinationsMessage.getEvent().getEventCode().equals("0")) {
                configureDestinationSpinner();
                destinationSpinner.requestFocus();
                InputMethodManager imm = (InputMethodManager) getBaseActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaResponseDestinationsMessage, true);
                search_trip_btn.setEnabled(false);
                search_trip_btn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            }

        } else if (obj instanceof CarmaResponseAvailabilityMessage) {
            //Log.d(TAG, "got back Availability ");
            getBaseActivity().carmaResponseAvailabilityMessage = (CarmaResponseAvailabilityMessage) obj;
            if (!getBaseActivity().carmaResponseAvailabilityMessage.getEvent().getEventCode().equals("0")) {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaResponseAvailabilityMessage, true);
                search_trip_btn.setEnabled(false);
                search_trip_btn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            }

        } else if (obj instanceof CarmaResponseReserveSeatsMessage) {
            //Log.d(TAG, "got back reserve seats");
            getBaseActivity().carmaResponseReserveSeatsMessage = (CarmaResponseReserveSeatsMessage) obj;
            if (getBaseActivity().carmaResponseReserveSeatsMessage.getEvent().getEventCode().equals("0")) {
                getBaseActivity().createProgress(R.string.completingBooking);
                BigDecimal total = BigDecimal.ZERO;
                for (int i = 0; i < getBaseActivity().carmaResponseReserveSeatsMessage.getData().getTickets().size(); i++) {
                    BigDecimal amount = new BigDecimal(
                            getBaseActivity().carmaResponseReserveSeatsMessage.getData().getTickets().get(i).getAmount());
                    total = total.add(amount);
                }

                // whats happening here
                CarmaRequestFactory factory = new CarmaRequestFactory();
                getBaseActivity().carmaRequestCompleteBookingMessage = factory.createCompleteBooking(
                        getBaseActivity().carmaResponseReserveSeatsMessage,
                        getBaseActivity().paymentType,
                        total.toString());
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaResponseReserveSeatsMessage, true);
                search_trip_btn.setEnabled(false);
                search_trip_btn.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            }
        } else {
            //Log.d(TAG, "calling results on BaseScreen");
            super.results(obj);
        }

        if (obj != null && !(obj instanceof Socket) && getBaseActivity().connectedToAEON) {
            getBaseActivity().connectedToAEON = false;
            getBaseActivity().firebaseBundle = new Bundle();
            getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, obj.getClass().getSimpleName());
            getBaseActivity().mFirebaseAnalytics.logEvent("aeon_connection", getBaseActivity().firebaseBundle);
        }
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { // does not work anymore
        if (parent.getId() == travel_class_spinner.getId()) {
            getBaseActivity().availabilitySearchQuery.setTravelClass(getBaseActivity().carmaResponseClassListMessage.getData().getItems().get(position).getCode());
            travelClassesPos = position;
        }
    }
    //----------------------------------------------------------------------------------------------

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    //----------------------------------------------------------------------------------------------
    private boolean validateSearchQuery() {
        boolean isValid;
        try {
            isValid = search_routes_relativelayout_id.validate();

            if (getBaseActivity().availabilitySearchQuery.getDeparturePoint().equalsIgnoreCase(getBaseActivity().availabilitySearchQuery.getDestinationPoint())) {
                getBaseActivity().createAlertDialog("Error Departure Destination", "The departure and the destination can not be the same");
                return false;
            }
            if (getBaseActivity().availabilitySearchQuery.getDepartureDate().trim().length() == 0) {
                getBaseActivity().createAlertDialog("Departure Date", "Select Departure Date");
                return false;
            }
            if (getBaseActivity().availabilitySearchQuery.isReturnTrip() && getBaseActivity().availabilitySearchQuery.getReturnDate().trim().length() == 0) {
                getBaseActivity().createAlertDialog("Return Date", "Select Return Date");
                return false;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
            Date dateDeparture = sdf.parse(getBaseActivity().availabilitySearchQuery.getDepartureDate().trim(), new ParsePosition(0));

            if (getBaseActivity().availabilitySearchQuery.isReturnTrip()) {

                Date dateReturn = sdf.parse(getBaseActivity().availabilitySearchQuery.getReturnDate().trim(), new ParsePosition(0));
                if (dateReturn.getTime() <= dateDeparture.getTime()) {
                    getBaseActivity().createAlertDialog("Invalid dates", "The return date must be after the departure date");
                    return false;
                }
            }

            Calendar now = Calendar.getInstance();
            now.set(Calendar.HOUR_OF_DAY, 0);
            now.set(Calendar.MINUTE, 0);
            now.set(Calendar.SECOND, 0);
            now.set(Calendar.MILLISECOND, 0);

            if (dateDeparture.before(now.getTime())) {
                getBaseActivity().createAlertDialog("Error", "Date cannot be in the past");
                return false;
            }

            if ((getBaseActivity().availabilitySearchQuery.getNumberOfPassengers() + getBaseActivity().availabilitySearchQuery.getNumberOfPassengersChild()) == 0) {
                getBaseActivity().createAlertDialog("Number Of Seats", "Please add at least one seat.");
                return false;
            }

        } catch (Exception exception) {
            // Log.v(TAG, "validate exception " + exception);
            isValid = false;
        }
        return isValid;
    }
    //----------------------------------------------------------------------------------------------
}