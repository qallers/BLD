package za.co.blts.bltandroidgui3;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SCANNING_APP;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentRicaChangeSimRegistration extends BaseFragment implements View.OnClickListener, BluDroidScanListener {

    private final String TAG = this.getClass().getSimpleName();

    private BluDroidEditText simSerialNumber;

    private BluDroidSpinner providerSpinner;
    public  String selectedProvider;
    private ListView listView;

    private BluDroidTextView simSerialsLabel;

    private BluDroidRicaSerialListAdapter ricaSerialListAdapter;
    public  BluDroidRelativeLayout layout;
    public ArrayList<String> ricaSerialNumberList;

    public FragmentRicaChangeSimRegistration() {
        // Required empty public constructor
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        ricaSerialNumberList = new ArrayList<>();
        layout = getView().findViewById(R.id.layout);
        listView = getView().findViewById(R.id.simSerials);

        simSerialsLabel = getView().findViewById(R.id.serialsLabel);
        simSerialsLabel.setVisibility(View.GONE);

        BluDroidButton addButton = getView().findViewById(R.id.add);
        BluDroidButton scanButton = getView().findViewById(R.id.scan);
        addButton.setOnClickListener(this);
        scanButton.setOnClickListener(this);

        simSerialNumber = getView().findViewById(R.id.simSerial);

        providerSpinner = getView().findViewById(R.id.providerSpinner);

        String[] providers = getResources().getStringArray(R.array.ricaNetworkProviders);
        ArrayAdapter<String> provincesAdapter = new ArrayAdapter<>(getBaseActivity(), R.layout.spinner_item, providers);
        providerSpinner.setAdapter(provincesAdapter);

        providerSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedProvider = parent.getSelectedItem().toString();
                if (selectedProvider.equalsIgnoreCase("mtn")) {
                    simSerialNumber.setHint("Kit Number");
                } else {
                    simSerialNumber.setHint("Serial Number");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ricaSerialNumberList = new ArrayList<>();
        ricaSerialListAdapter = new BluDroidRicaSerialListAdapter(getBaseActivity(), R.layout.item_rica_serial, ricaSerialNumberList);
        listView.setAdapter(ricaSerialListAdapter);

    }

    @Override
    public void onDestroy() {
        if (listView != null) listView.setAdapter(null);
        super.onDestroy();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), TAG, null);
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_rica_sim_registration, container, false);
    }

    @Override
    public void onClick(View view) {
        BaseActivity.logger.info(((BluDroidButton) view).getText());
        switch (view.getId()) {
            case R.id.add:
                if (simSerialNumber.getText().toString().trim().isEmpty()) {
                    getBaseActivity().createAlertDialog("Serial Number required", getResources().getString(R.string.serial_required));
                } else {
                    if (ricaSerialNumberList.size() == 1) {
                        getBaseActivity().createAlertDialog("Only 1 serial number", getResources().getString(R.string.one_serial_required));
                    } else {
                        String provider = providerSpinner.getSelectedItem().toString();
                        String serialNumber = simSerialNumber.getText().toString();
                        String sim = provider + "," + serialNumber;

                        if (ricaSerialNumberList.contains(sim)) {
                            getBaseActivity().createAlertDialog("Serial Number", getResources().getString(R.string.serial_exists));
                        } else {
                            simSerialsLabel.setVisibility(View.VISIBLE);
                            ricaSerialNumberList.add(sim);
                            ricaSerialListAdapter.notifyDataSetChanged();

                            simSerialNumber.setText("");
                            getBaseActivity().createNotification("Serial number added");
                        }
                    }

                }
                break;

            case R.id.scan:
                scanBarcode();
                break;

            default:
                break;
        }
    }

    private void scanBarcode() {
        Log.d(TAG, "scanClick");
        try {
            if (getPreference(PREF_SCANNING_APP).equals("com.google.zxing.client.android")) {

                Log.d(TAG, "trying to start com.google.zxing.client.android.SCAN");

                if (getBaseActivity().isPackageInstalled("com.google.zxing.client.android", getBaseActivity().getPackageManager())) {
                    Intent intent = new Intent("com.google.zxing.client.android.SCAN");
                    startActivityForResult(intent, 0);
                } else {
                    getBaseActivity().createAlertDialog("Scanning App", "Preferred scanning app not found");
                }
            } else {
                BluDroidScanReciever.setListener(this);
                Log.d(TAG, "trying to start " + getPreference(PREF_SCANNING_APP));
                if (getBaseActivity().isPackageInstalled((getPreference(PREF_SCANNING_APP)), getBaseActivity().getPackageManager())) {
                    Intent intent = getBaseActivity().getPackageManager().getLaunchIntentForPackage(getPreference(PREF_SCANNING_APP));
                    startActivityForResult(intent, 0);
                } else {
                    getBaseActivity().createAlertDialog("Scanning App", "Preferred scanning app not found");
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems starting scanning application " + exception);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        try {
            Log.d(TAG, "onActivityResult ");
            Log.d(TAG, "requestCode " + requestCode);
            Log.d(TAG, "resultCode " + resultCode);
            Log.d(TAG, "intent is " + intent);
            if (intent != null) {

                String contents = intent.getStringExtra("SCAN_RESULT");

                if (contents.trim().isEmpty()) {
                    getBaseActivity().createAlertDialog("Serial Number required", getResources().getString(R.string.serial_required));
                } else {
                    if (ricaSerialNumberList.size() == 1) {
                        getBaseActivity().createAlertDialog("Only 1 serial number", getResources().getString(R.string.one_serial_required));

                    } else {
                        String provider = providerSpinner.getSelectedItem().toString();
                        String sim = provider + "," + contents;

                        if (ricaSerialNumberList.contains(sim)) {
                            getBaseActivity().createAlertDialog("Serial Number", getResources().getString(R.string.serial_exists));
                        } else {
                            simSerialsLabel.setVisibility(View.VISIBLE);

                            ricaSerialNumberList.add(sim);
                            ricaSerialListAdapter.notifyDataSetChanged();
                            getBaseActivity().createNotification("Serial number added");
                        }
                    }

                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "problem getting scan result " + exception);
        }
    }

    @Override
    public void setBarcode(String barcode) {
        if (barcode.trim().isEmpty()) {
            getBaseActivity().createAlertDialog("Serial Number required", getResources().getString(R.string.serial_required));
        } else {
            if (ricaSerialNumberList.size() == 1) {
                getBaseActivity().createAlertDialog("Only 1 serial number", getResources().getString(R.string.one_serial_required));

            } else {
                String provider = providerSpinner.getSelectedItem().toString();
                String sim = provider + "," + barcode;

                if (ricaSerialNumberList.contains(sim)) {
                    getBaseActivity().createAlertDialog("Serial Number", getResources().getString(R.string.serial_exists));
                } else {

                    simSerialsLabel.setVisibility(View.VISIBLE);

                    ricaSerialNumberList.add(sim);
                    ricaSerialListAdapter.notifyDataSetChanged();
                    getBaseActivity().createNotification("Serial number added");
                }
            }

        }
    }

    public void clearAll() {
        if (simSerialNumber != null) {
            simSerialNumber.setText("");
            ricaSerialNumberList.clear();
            ricaSerialListAdapter.notifyDataSetChanged();
        }
    }
}
