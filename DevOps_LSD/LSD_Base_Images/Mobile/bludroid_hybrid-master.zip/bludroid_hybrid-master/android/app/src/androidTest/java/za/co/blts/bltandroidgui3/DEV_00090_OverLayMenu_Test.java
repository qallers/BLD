package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASH_DRAWER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

/**
 * Created by NkosanaM on 3/14/2017.
 */

@RunWith(AndroidJUnit4.class)
public class DEV_00090_OverLayMenu_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void OverLayMenu_Test() {
        try {

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.clickOnActionMenu();

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.about))) {
                Log.d(TAG, "About menu is on screen");
            } else {
                fail("about menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.users))) {
                Log.d(TAG, "Users menu is on screen");
            } else {
                fail("Users menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.reports))) {
                Log.d(TAG, "Reports menu is on screen");
            } else {
                fail("Reports menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.end_shift))) {
                Log.d(TAG, "End SHift menu is on screen");
            } else {
                fail("End SHift menu is not on screen");
            }

            if (checks.checkPreference(PREF_CASH_DRAWER).equals(PREF_TRUE)) {
                if (solo.searchText(getBaseActivity().getResources().getString(R.string.open_cash_drawer))) {
                    Log.d(TAG, "Open Cash Drawer menu is on screen");
                } else {
                    fail("Open Cash Drawer menu is not on screen");
                }
            } else {
                Log.d(TAG, "User does not have permission to open cash drawer");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.device_settings))) {
                Log.d(TAG, "Device Settings menu is on screen");
            } else {
                fail("Device Settings  menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.sort_favourites))) {
                Log.d(TAG, "Sort favourites menu is on screen");
            } else {
                fail("Sort favourites menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.signOut))) {
                Log.d(TAG, "Sign Out menu is on screen");
            } else {
                fail("Sign Out  menu is not on screen");
            }

            if (BaseActivity.loginResponseMessage.getData().canDoEmergencyTopup()) {
                if (solo.searchText(getBaseActivity().getResources().getString(R.string.emergency_topUp))) {
                    Log.d(TAG, "Emergency To up menu is on screen");
                } else {
                    fail("Emergency To up menu is not on screen");
                }
            }

            solo.clickOnText("Sign-Out");
            Log.d(TAG, "logout");

            solo.sleep(1000);

            if (checks.cashierLogin(this)) {
                Log.d(TAG, "login as cashier");
            } else {
                fail("login as cashier");
            }

            checks.clickOnActionMenu();

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.about))) {
                Log.d(TAG, "About menu is on screen");
            } else {
                fail("about menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.signOut))) {
                Log.d(TAG, "Sign Out menu is on screen");
            } else {
                fail("Sign Out  menu is not on screen");
            }

            solo.clickOnText("Sign-Out");
            Log.d(TAG, "logout");

            solo.sleep(1000);

            if (checks.cashierPlusLogin(this)) {
                Log.d(TAG, "login as cashier plus");
            } else {
                fail("login as cashier plus");
            }

            checks.clickOnActionMenu();

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.about))) {
                Log.d(TAG, "About menu is on screen");
            } else {
                fail("about menu is not on screen");
            }
            if (solo.searchText(getBaseActivity().getResources().getString(R.string.reports))) {
                Log.d(TAG, "Reports menu is on screen");
            } else {
                fail("Reports menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.end_shift))) {
                Log.d(TAG, "End SHift menu is on screen");
            } else {
                fail("End SHift menu is not on screen");
            }

            if (checks.checkPreference(PREF_CASH_DRAWER).equals(PREF_TRUE)) {
                if (solo.searchText(getBaseActivity().getResources().getString(R.string.open_cash_drawer))) {
                    Log.d(TAG, "Open Cash Drawer menu is on screen");
                } else {
                    fail("Open Cash Drawert menu is not on screen");
                }
            } else {
                Log.d(TAG, "User does not have permission to open cash drawer");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.signOut))) {
                Log.d(TAG, "Sign Out menu is on screen");
            } else {
                fail("Sign Out  menu is not on screen");
            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
