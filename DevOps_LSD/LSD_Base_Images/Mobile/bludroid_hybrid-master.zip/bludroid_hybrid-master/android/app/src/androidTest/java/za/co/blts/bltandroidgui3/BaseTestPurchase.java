package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.KeyEvent;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Arrays;
import java.util.Calendar;

import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMandatoryEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 3/8/2017.
 */

class BaseTestPurchase extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    BaseTestPurchase() {
        super();
    }

    //Voucher type
    void selectVoucherTypeAirtime() {
        checks.selectMenuItem(getBaseActivity().getString(R.string.airtime));
    }

    void selectVoucherTypeData() {
        checks.selectMenuItem(getBaseActivity().getString(R.string.data));
    }

    void selectVoucherTypeOtherVouchers() {
        checks.selectMenuItem(getBaseActivity().getString(R.string.vouchers));
    }

    void selectVoucherTypeElectricity() {
        checks.selectMenuItem(getBaseActivity().getString(R.string.electricity));
    }

    void selectVoucherTypeRica() {
        checks.selectMenuItem(getBaseActivity().getString(R.string.rica));
    }

    void checkRicaLogin() {
        if (!solo.searchText("Query")) {
            solo.enterText(0, "abcde");
            solo.enterText(1, "sa3026");
            solo.clickOnButton("Sign in");
            Log.d(TAG, "Logging into Rica");
        }
    }

    //
    //Pinless
    //

    void gotoPinless() {
        solo.clickOnText(getBaseActivity().getResources().getString(R.string.pinlessTopUp));
    }

    void gotoPinlessBundles() {
        solo.clickOnText(getBaseActivity().getResources().getString(R.string.pinlessBundles));
    }


    //
    //Providers
    //

    void selectProviderVoda() {
        checks.selectProvider(providers[0]);
    }

    void selectProviderMTN() {
        checks.selectProvider(providers[1]);
    }

    void selectProviderCellC() {
        checks.selectProvider(providers[2]);
    }

    void selectProviderTelkom() {
        checks.selectProvider(providers[3]);
    }

    void selectProviderNeotel() {
        checks.selectProvider(providers[4]);
    }

    void selectProviderVirginMobile() {
        checks.selectProvider(providers[5]);
    }

    void selectProviderAllProviders() {
        checks.selectProvider(providers[6]);
    }

    void selectProviderAfricaPin() {
        solo.clickInRecyclerView(9);
    }

    void selectProviderAxxess() {
        solo.clickInRecyclerView(8);
    }

    void selectProviderBela() {
        solo.clickInRecyclerView(7);
    }

    void selectProviderLucky365() {
        solo.clickInRecyclerView(6);
    }

    void selectProviderTelkomWorldCard() {
        solo.clickInRecyclerView(4);
    }

    void selectProviderStarSat() {
        solo.clickInRecyclerView(3);
    }

    void selectProviderBetFlash() {
        solo.clickInRecyclerView(2);
    }

    void selectProviderLottery() {
        solo.clickInRecyclerView(10);
    }

    void selectProviderDabba() {
        solo.clickInRecyclerView(1);
    }

    void selectProviderHollywoodBet() {
        solo.clickInRecyclerView(0);
    }

    void selectC4C() {
        solo.clickInRecyclerView(5);
    }

    //MVNO menu
    void selectMVNOAdvinne() {
        solo.clickInRecyclerView(0);
    }

    void selectMVNOTheUnlimited() {
        solo.clickInRecyclerView(1);
    }

    void selectMVNOMyAir() {
        solo.clickInRecyclerView(2);
    }

    void selectMVNOFNBConnect() {
        solo.clickInRecyclerView(3);
    }

    void selectMVNOLycaMobile() {
        solo.clickInRecyclerView(4);
    }

    void selectMVNOCallAll() {
        solo.clickInRecyclerView(5);
    }

    void selectMVNOBluVoucher() {
        solo.clickInRecyclerView(7);
    }

    // Under lottery methods

    void selectLottoNumbers() {
        solo.clickInRecyclerView(0);
    }

    void selectPowerballNumbers() {
        solo.clickInRecyclerView(1);
    }

    void selectLottoQuickpick() {
        solo.clickInRecyclerView(2);
    }

    void selectPowerballQuickpick() {
        solo.clickInRecyclerView(3);
    }

    void confirmNumbers() {
        solo.clickOnButton("Select Numbers");
    }

    void confirmBoardA() {
        solo.clickOnButton("Board A");
    }

    void confirmBoardB() {
        solo.clickOnButton("Board B");
    }

    void confirmAccept() {
        solo.clickOnButton("Accept");
    }

    void confirmPlay() {
        solo.clickOnButton("Play");
    }

    void selectPowerballNumbers(int size) {
        int[] numbers = new int[size];
        //Generates Random Numbers in the range 1 -50
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = (int) (Math.random() * 50 + 1);

            for (int j = 0; j < i; j++) {
                if (numbers[i] == numbers[j]) {
                    i--; //if numbers[i] is a duplicate of numbers[j], then run the outer loop on i again
                    break;
                }
            }
        }

        for (int number : numbers) {
            solo.clickOnText(Integer.toString(number));
        }

        String selectedNumbers = Arrays.toString(numbers);
        Log.d(TAG, "Selected number(s) are " + selectedNumbers);
    }

    void selectPowerball() {
        int powerBall = (int) (Math.random() * 20 + 1);
        String strPowerball = Integer.toString(powerBall);

        solo.clickOnText("-");
        solo.clickOnText(strPowerball);
        Log.d(TAG, "The PowerBall is " + powerBall);
    }


    //
    //Confirmations
    //

    void confirmPrintVoucher() {
        solo.clickOnButton("Print");

        if (solo.waitForText("Getting voucher") || solo.waitForDialogToClose()) {
            Log.d(TAG, "Voucher purchase confirmation dismissed");
        } else {
            fail("Voucher purchase confirmation NOT dismissed");
        }
    }


    boolean checkStock() {
        solo.clearLog();
        confirmPrintVoucher();

        solo.sendKey(KeyEvent.KEYCODE_BACK);
        Log.d(TAG, "back button disabled");

        if (solo.waitForDialogToOpen() && solo.searchText("No Stock available")) {
            Log.d(TAG, "No stock available");

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            return false;
        } else {
            Log.d(TAG, "Voucher confirmed");
            solo.waitForLogMessage("TenderResponseMessage");
            return true;
        }
    }

    void confirmTopUpVoucher(boolean waitForTender) {
        solo.clearLog();
        solo.clickOnButton("TopUp");
        Log.d(TAG, " Voucher confirmed");

        if (waitForTender) {
            solo.waitForLogMessage("TenderResponseMessage");
        }
    }

    void billPaymentAccounts() {
        checks.selectBillPaymentType("Accounts");
    }

    void searchText(String searchText, String textToSelect) {

        checks.enterText(R.id.search, searchText);
        solo.clickOnText(textToSelect);
    }

    void scrollToText(String textToSelect) {
        while (!solo.searchText(textToSelect)) {
            solo.scrollDownRecyclerView(0);
        }
        solo.clickOnText(textToSelect);
    }

    void enterAccountNumber(String accountNumber) {
        checks.enterText(R.id.accountNumber, accountNumber);
    }

    void showDetailsButton() {
        checks.clickButton(R.id.showDetailsButton);
    }

    void selectVoucherTypeTickets() {
        checks.selectMenuItem(getBaseActivity().getString(R.string.tickets));
    }

    void gotoBusType(int index) {
        solo.clickInRecyclerView(index);
    }

    void getBusTickets() {
        solo.clickInRecyclerView(2);
    }

    void indicateWayOfTravel(String travelType) {
        BluDroidRadioButton radioButton = null;
        if (travelType.equalsIgnoreCase("OneWay")) {
            radioButton = (BluDroidRadioButton) solo.getView(R.id.one_way_trip);
        } else if (travelType.equalsIgnoreCase("Return")) {
            radioButton = (BluDroidRadioButton) solo.getView(R.id.return_trip);
        }
        solo.clickOnView(radioButton);
    }

    void selectDepart(String search, String departure) {
        solo.typeText(0, search);
        solo.waitForText(departure);
        solo.clickOnText(departure);
    }

    void destination(String search, String destination) {
        solo.typeText(1, search);
        solo.waitForText(destination);
        solo.clickOnText(destination);
    }

    void paymentType(String payment) {
        BluDroidRadioButton radioButton = null;

        if (payment.equalsIgnoreCase("cash")) {
            radioButton = (BluDroidRadioButton) solo.getView(R.id.cash_payment);
        } else if (payment.equalsIgnoreCase("debit card")) {
            radioButton = (BluDroidRadioButton) solo.getView(R.id.debit_order_payment);
        } else if (payment.equalsIgnoreCase("credit card")) {
            radioButton = (BluDroidRadioButton) solo.getView(R.id.credit_card_payment);
        }
        solo.clickOnView(radioButton);
    }

    void Book() {
        solo.clickOnView(solo.getView(R.id.book_bus_ticket));
        solo.waitForText(solo.getCurrentActivity().getResources().getString(R.string.completingBooking));
//    solo.waitForDialogToClose();
        solo.waitForLogMessage("TenderResponseMessage");
    }

    void searchBusTicket() {
        solo.clickOnView(solo.getView(R.id.search_trip_btn));
        Log.d(TAG, "Search");

        solo.waitForText("Getting Availability");
        solo.waitForDialogToClose();
    }

    void Title(int index) {
        solo.clickOnView(solo.getView(R.id.title_spinner));
        solo.clickInList(index);
    }

    void passengerTypeSpinner(int index) {
        solo.clickOnView(solo.getView(R.id.passenger_type_spinner));
        solo.clickInList(index);
    }

    //Adult details
    void initial(String initials) {
        BluDroidEditText initialsEditText = (BluDroidEditText) solo.getView(R.id.passenger_adult_initials);
        solo.enterText(initialsEditText, initials);
    }

    void Surname(String surname) {
        BluDroidEditText nameEditText = (BluDroidEditText) solo.getView(R.id.passenger_adult_last_name);
        solo.enterText(nameEditText, surname);
    }


    void Cellphone(String cell) {
        BluDroidEditText cellEditText = (BluDroidEditText) solo.getView(R.id.passenger_cell_phone_number);
        solo.enterText(cellEditText, cell);
    }

    void ID(String id) {
        BluDroidEditText nameEditText = (BluDroidEditText) solo.getView(R.id.passenger_id_number);
        solo.enterText(nameEditText, id);
    }

    //indicate documentation for passenger information
    void indicateDocumentation(String DocType) {
        BluDroidRadioButton radioButton = null;

        if (DocType.equalsIgnoreCase("ID")) {
            radioButton = (BluDroidRadioButton) solo.getView(R.id.radio_button_id_selected);
        } else if (DocType.equalsIgnoreCase("Passsport")) {
            radioButton = (BluDroidRadioButton) solo.getView(R.id.radio_button_passport_selected);
        }
        solo.clickOnView(radioButton);
    }

    void departDate() {
        DatePicker datePicker = (DatePicker) solo.getView(R.id.dateDayPicker);
        Calendar depart = Calendar.getInstance();
        depart.add(Calendar.DAY_OF_MONTH, 7);
        solo.setDatePicker(datePicker, depart.get(Calendar.YEAR), depart.get(Calendar.MONTH), depart.get(Calendar.DAY_OF_MONTH));
    }

    void departDateYesterday() {
        DatePicker datePicker = (DatePicker) solo.getView(R.id.dateDayPicker);
        Calendar depart = Calendar.getInstance();
        depart.add(Calendar.DATE, -1);
        solo.setDatePicker(datePicker, depart.get(Calendar.YEAR), depart.get(Calendar.MONTH), depart.get(Calendar.DAY_OF_MONTH));
    }

    void departDateToday() {
        DatePicker datePicker = (DatePicker) solo.getView(R.id.dateDayPicker);
        Calendar depart = Calendar.getInstance();
        depart.add(Calendar.DATE, 0);
        solo.setDatePicker(datePicker, depart.get(Calendar.YEAR), depart.get(Calendar.MONTH), depart.get(Calendar.DAY_OF_MONTH));
    }

    void returnDate() {
        DatePicker datePicker = (DatePicker) solo.getView(R.id.dateDayPicker);
        Calendar depart = Calendar.getInstance();
        depart.add(Calendar.DAY_OF_MONTH, 14);
        solo.setDatePicker(datePicker, depart.get(Calendar.YEAR), depart.get(Calendar.MONTH), depart.get(Calendar.DAY_OF_MONTH));
    }

    void infantChildDob(Calendar cal) {
        DatePicker datePicker = (DatePicker) solo.getView(R.id.dateDayPicker);
        solo.setDatePicker(datePicker, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE));
    }

    void PrintTicket() {
        solo.clearLog();
        solo.waitForDialogToOpen();
        solo.clickOnButton("Print");
        solo.waitForLogMessage("TenderResponseMessage");
    }


    void DepartCalendar() {
        solo.clickOnView(solo.getView(R.id.departure_date_calender));
    }

    void ReturnCalendar() {
        solo.clickOnView(solo.getView(R.id.return_date_calender));
    }

    void infantChildCalendar() {
        solo.clickOnView(solo.getView(R.id.btnDatePicker));
    }


    void gotoPutco() {
        solo.clickInRecyclerView(1);
    }

    //
    /*Bustype routes*/

    void selectDeparture(int index) {
        solo.pressSpinnerItem(0, index);
    }

    void selectDestination(int index) {
        solo.pressSpinnerItem(1, index);
    }


    /* Bustype routes */
    void enterRouteCode(String routeCode) {
        BluDroidMandatoryEditText routeeditText = (BluDroidMandatoryEditText) solo.getView(R.id.routeCode);
        solo.enterText(routeeditText, routeCode);
    }

    void gotoEvents() {
        solo.clickInRecyclerView(0);
    }

    //
    //Event categories
    //
    void chooseCategory(String category) {
        solo.clickOnText(category);
    }

    void enterName(String name) {
        BluDroidEditText nameEditText = (BluDroidEditText) solo.getView(R.id.name);
        solo.enterText(nameEditText, name);
    }

    void enterCell(String cell) {
        BluDroidEditText cellEditText = (BluDroidEditText) solo.getView(R.id.cellPhone);
        solo.enterText(cellEditText, cell);
    }

    void indicatepaymentType(String paymentType) {

        BluDroidRadioButton radioButton = null;

        if (paymentType.equalsIgnoreCase("cash")) {
            radioButton = (BluDroidRadioButton) solo.getView(R.id.cashRadio);
        } else if (paymentType.equalsIgnoreCase("debit card")) {
            radioButton = (BluDroidRadioButton) solo.getView(R.id.debitRadio);
        } else if (paymentType.equalsIgnoreCase("credit card")) {
            radioButton = (BluDroidRadioButton) solo.getView(R.id.creditRadio);
        }
        solo.clickOnView(radioButton);
    }
    //
    //Confirmations
    //

    void confirmPurchaseTicket() {
        solo.clearLog();
        solo.clickOnButton("Pay");
        solo.waitForLogMessage("TenderResponseMessage");
    }

    void enterMeterNumber(String meterNum) {
        EditText meterNumEditText = (EditText) solo.getView(R.id.meterNumber);
        solo.clearEditText(meterNumEditText);
        solo.enterText(meterNumEditText, meterNum);
    }

    void enterAmount(String amount) {
        EditText edt_amount = (EditText) solo.getView(R.id.amount);
        solo.clearEditText(edt_amount);
        solo.enterText(edt_amount, amount);
    }

    //
    //Confirmations
    //

    void confirmElectrictyVoucher() {
        solo.clickOnText("Confirm");
    }

    void confirmFBEElectrictyVoucher() {
        solo.clickOnText("FBE");
    }

    void cancelElectricityVoucher() {
        solo.clickOnText("Cancel");
    }

    void buyElectricityVoucher() {
        solo.clearLog();
        solo.clickOnButton("Print");

        if (solo.waitForDialogToClose()) {
            Log.d(TAG, "Voucher purchase confirmation dismissed");
        } else {
            fail("Voucher purchase confirmation NOT dismissed");
        }

        if (solo.searchText("Connection Error")) {
            fail("AEON - Connection Error");
        }

        solo.waitForLogMessage("TenderResponseMessage");
    }

}
