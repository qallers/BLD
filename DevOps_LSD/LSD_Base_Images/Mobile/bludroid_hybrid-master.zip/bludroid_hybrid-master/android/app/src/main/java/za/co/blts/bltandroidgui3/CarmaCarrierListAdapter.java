package za.co.blts.bltandroidgui3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseItemMessage;

class CarmaCarrierListAdapter extends ArrayAdapter<CarmaResponseItemMessage> {


    private WeakReference<BaseActivity> baseActivityWeakReference;

    public CarmaCarrierListAdapter(BaseActivity context, int resource, ArrayList<CarmaResponseItemMessage> dataset) {
        super(context, resource, dataset);
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listView = convertView;
        if (listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(R.layout.spinner_item_carrier, parent, false);
        }

        CarmaResponseItemMessage carrierItem = getItem(position);

        TextView textCarrierName = listView.findViewById(R.id.text);
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            textCarrierName.setTextColor(baseActivity.getSkinResources().getButtonTextColor());
        }
        if (carrierItem != null) {
            textCarrierName.setText(carrierItem.getDescription());
        }
        return listView;
    }


    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        View listView = convertView;
        if (listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_spinner_dropdown_item, parent, false);
        }

        CarmaResponseItemMessage carrierItem = getItem(position);

        TextView textCarrierName = listView.findViewById(android.R.id.text1);

        if (carrierItem != null)
            textCarrierName.setText(carrierItem.getDescription());
        return listView;
    }
}
