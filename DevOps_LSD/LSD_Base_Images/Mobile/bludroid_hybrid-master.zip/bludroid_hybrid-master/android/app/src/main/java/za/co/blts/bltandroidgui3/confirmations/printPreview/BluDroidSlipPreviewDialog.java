package za.co.blts.bltandroidgui3.confirmations.printPreview;

import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;

/**
 * Created by MasiS on 3/23/2018.
 */

public abstract class BluDroidSlipPreviewDialog extends BluDroidConfirmationDialog implements BluDroidSetupable {
    private final String TAG = this.getClass().getSimpleName();

    private TextView print_lines;
    private List<PrintJob> printJobs;
    private WeakReference<BaseActivity> baseActivityWeakReference;
    private int index = 0;
    private BluDroidButton do_print_button;
    private String title = "Print Preview";

    public BluDroidSlipPreviewDialog(final BaseActivity context, final List<PrintJob> printJobs) {
        super(context, R.layout.dialog_print_preview);
        this.baseActivityWeakReference = new WeakReference<>(context);
        hideNavigation();
        setup();
        this.printJobs = printJobs;

        updateHeading();

        setCancelable(false);

        print_lines = findViewById(R.id.print_lines);
        convertPrintLinesToString(index);

        BluDroidButton cancel_print_button = findViewById(R.id.cancel_print_button);
        cancel_print_button.setVisibility(View.GONE);

        do_print_button = findViewById(R.id.do_print_button);
        do_print_button.setText(index < printJobs.size() - 1 ? "Next" : "Print");
        do_print_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (index < printJobs.size() - 1) {
                    convertPrintLinesToString(++index);
                    do_print_button.setText(index < printJobs.size() - 1 ? "Next" : "Print");
                    updateHeading();
                } else {
                    dismiss();
                    doPrintLines();
                    finishTransaction();
                }
            }
        });
    }

    public abstract void finishTransaction();

    public void setTitle(String title) {
        this.title = title;
        updateHeading();
    }

    public void updateHeading() {
        String heading = title;
        if (printJobs.size() > 1) {
            heading += " (" + (index + 1) + "/" + printJobs.size() + ")";
        }
        setHeading(heading);
    }

    //----------------------------------------------------------------------------------------------
    private void convertPrintLinesToString(int index) {
        try {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                ArrayList<String> tmp = new ArrayList<>();
                if (printJobs.get(index).getLines().size() > 0) {
                    for (int i = 0; i < printJobs.get(index).getLines().size(); i++) {
                        CommonResponseLineMessage line = printJobs.get(index).getLines().get(i);
                        StringBuilder st = new StringBuilder();

                        String text = line.getText();

                        switch (line.getF()) {
                            case "H":
                            case "E":
                                text = baseActivity.center(line.getText());
                                break;

                            case "P":
                            case "Q":
                                text = "";
                                break;
                        }
                        if (text != null && !text.equals("0") && !line.getF().equals("P") && !line.getF().equals("Q")) {
                            st.append(text);
                            tmp.add(st.toString());
                        }
                        if (line.getF().equals("N")) {
                            tmp.add(BaseActivity.HORIZONTAL_LINE);
                        }
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    for (String theLine : tmp) {
                        stringBuilder.append(theLine).append("\n");
                    }
                    setPrintLinesToView(stringBuilder.toString());
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems printing " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    private void setPrintLinesToView(String lines) {
        /*if (Build.SERIAL.contains("xgd")){
            Log.e("PrintPreview", "Build version: " + Build.SERIAL);
            print_lines.setTextSize(12);
        }*/
        print_lines.setText(lines);
    }

    //----------------------------------------------------------------------------------------------
    private void doPrintLines() {
        baseActivity.createProgress(R.string.printing);
        for (int i = 0; i < printJobs.size(); i++) {
            if (printJobs.get(i).isDynamicPrint()) {
                baseActivity.printWithDynamic(printJobs.get(i).getLines(), printJobs.get(i).isBarcodes());
            } else {
                baseActivity.print(printJobs.get(i).getLines());
            }
        }
    }
    //----------------------------------------------------------------------------------------------
}
