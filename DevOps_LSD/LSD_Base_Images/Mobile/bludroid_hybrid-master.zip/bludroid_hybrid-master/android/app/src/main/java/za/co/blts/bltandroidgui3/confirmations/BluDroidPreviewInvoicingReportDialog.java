package za.co.blts.bltandroidgui3.confirmations;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blts.bltandroidgui3.BaseActivity;

/**
 * Created by BoitshokoM on 6/08/2018.
 */

public class BluDroidPreviewInvoicingReportDialog extends BluDroidPrintPreviewDialog {
    private final String TAG = this.getClass().getSimpleName();
    //----------------------------------------------------------------------------------------------
    public BluDroidPreviewInvoicingReportDialog(final BaseActivity context, ArrayList<CommonResponseLineMessage> lines) {
        super(context, lines);
        setup();
        setHeading("Invoicing Report");
    }
    //----------------------------------------------------------------------------------------------
}
