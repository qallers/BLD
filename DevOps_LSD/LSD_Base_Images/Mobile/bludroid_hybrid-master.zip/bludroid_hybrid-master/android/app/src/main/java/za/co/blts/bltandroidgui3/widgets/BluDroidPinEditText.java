package za.co.blts.bltandroidgui3.widgets;


import android.content.Context;
import android.text.InputFilter;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//
// view and button stuff
//


public class BluDroidPinEditText extends BluDroidIntegerEditText {


    private void setUpPin() {
        addPinTransformer();
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(6);
        setFilters(inputFilters);
        maxLength = 6;
    }


    private void addPinTransformer() {
        setTransformationMethod((new PasswordTransformationMethod()));
    }

    public BluDroidPinEditText(BaseActivity context) {
        super(context);
        setUpPin();
    }


    public BluDroidPinEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpPin();
    }


    public boolean validate() {
        String pin = getText().toString().trim();
        int length = pin.length();
        if (length != 6) {
            setErrorMessage(R.string.pinError);
            setText("");
            return false;
        } else {
            removeErrorMessage();
            return true;
        }
    }

}

