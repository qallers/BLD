package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SECURE_USB_PRINTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

/**
 * Created by warrenm
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00200_Putco_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
        changePreference(PREF_SECURE_USB_PRINTER, PREF_TRUE);
    }

    @After
    public void after() {
        changePreference(PREF_SECURE_USB_PRINTER, PREF_FALSE);
        tearDown();
    }

    @Test
    public void T001_Route_T016() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            gotoPutco();
            Log.d(TAG, "Goto Putco");

            if (solo.waitForText("Secure USB Printer")) {
                solo.clickOnText("OK");
                Log.d(TAG, "Ok is clicked for USB printer");
            } else {
                enterRouteCode("T016");
                Log.d(TAG, "route code entered");

                BluDroidButton btngetRoute = (BluDroidButton) solo.getView(R.id.getRoute);
                solo.clickOnView(btngetRoute);
                Log.d(TAG, "Get Route Button Clicked");

                solo.waitForDialogToClose();
                Log.d(TAG, "Routes found");

                selectDeparture(8);
                Log.d(TAG, "Departure selected");

                solo.waitForDialogToClose();

                selectDestination(0);
                Log.d(TAG, "Destination selected");

                solo.clickOnView(btngetRoute);
                Log.d(TAG, "Get Route Button Clicked");

                solo.waitForDialogToClose();
                Log.d(TAG, "Routes found");

                solo.clickOnButton("Next");
                Log.d(TAG, "Click next");

                solo.clickInList(1, 1);
                Log.d(TAG, "select first ticketType");

                solo.clickOnButton("Next");
                Log.d(TAG, "Click next");

                enterCell("0731231234");
                Log.d(TAG, "Cell Entered");

                indicatepaymentType("debit card");
                Log.d(TAG, "Payment type indicated");

                confirmPurchaseTicket();
                Log.d(TAG, "Confirm Purchase Ticket clicked");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_AutoCancel() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            gotoPutco();
            Log.d(TAG, "Goto Putco");
            if (solo.waitForText("Secure USB Printer")) {
                solo.clickOnText("OK");
                Log.d(TAG, "Ok is clicked for USB printer");
            } else {
                solo.waitForDialogToClose();

                enterRouteCode("T016");
                Log.d(TAG, "route code entered");

                BluDroidButton btngetRoute = (BluDroidButton) solo.getView(R.id.getRoute);
                solo.clickOnView(btngetRoute);
                Log.d(TAG, "Get Route Button Clicked");

                solo.waitForDialogToClose();
                Log.d(TAG, "Routes found");

                selectDeparture(8);
                Log.d(TAG, "Departure selected");

                solo.waitForDialogToClose();

                selectDestination(0);
                Log.d(TAG, "Destination selected");

                solo.clickOnView(btngetRoute);
                Log.d(TAG, "Get Route Button Clicked");

                solo.waitForDialogToClose();
                Log.d(TAG, "Routes found");

                solo.clickOnButton("Next");
                Log.d(TAG, "Click next");

                solo.clickInList(1, 1);
                Log.d(TAG, "select first ticketType");

                solo.clickOnButton("Next");
                Log.d(TAG, "Click next");

                enterCell("0731231234");
                Log.d(TAG, "Cell Entered");

                indicatepaymentType("debit card");
                Log.d(TAG, "Payment type indicated");

                confirmPurchaseTicket();
                Log.d(TAG, "Confirm Purchase Ticket clicked");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T020_AutoCancelRetry() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            gotoPutco();
            Log.d(TAG, "Goto Putco");
            if (solo.waitForText("Secure USB Printer")) {
                solo.clickOnText("OK");
                Log.d(TAG, "Ok is clicked for USB printer");
            } else {
                solo.waitForDialogToClose();

                enterRouteCode("T016");
                Log.d(TAG, "route code entered");

                BluDroidButton btngetRoute = (BluDroidButton) solo.getView(R.id.getRoute);
                solo.clickOnView(btngetRoute);
                Log.d(TAG, "Get Route Button Clicked");

                solo.waitForDialogToClose();
                Log.d(TAG, "Routes found");

                selectDeparture(8);
                Log.d(TAG, "Departure selected");

                solo.waitForDialogToClose();

                selectDestination(0);
                Log.d(TAG, "Destination selected");

                solo.clickOnView(btngetRoute);
                Log.d(TAG, "Get Route Button Clicked");

                solo.waitForDialogToClose();
                Log.d(TAG, "Routes found");

                solo.clickOnButton("Next");
                Log.d(TAG, "Click next");

                solo.clickInList(1, 0);
                Log.d(TAG, "select first ticketType");

                solo.clickOnButton("Next");
                Log.d(TAG, "Click next");

                enterCell("0731231234");
                Log.d(TAG, "Cell Entered");

                indicatepaymentType("debit card");
                Log.d(TAG, "Payment type indicated");

                solo.clickOnButton("Pay");
                Log.d(TAG, "Confirm Purchase Ticket clicked");

                solo.sleep(2000);

                checks.setWifi(false);
                Log.d(TAG, "WIFI disabled");

                solo.sleep(2000);
                checks.setWifi(true);
                solo.sleep(5000);
                solo.clickOnButton("Auto Login");
                Log.d(TAG, "Clicked 'Auto Login'");

//            if (solo.waitForLogMessage("TEST got DoCompleteTrx",30000)){
//
//                checks.setWifi(false);
//                Log.d(TAG, "WIFI disabled");
//
//
//                solo.sleep(2000);
//                checks.setWifi(true);
//                solo.sleep(5000);
//                solo.clickOnButton("Auto Login");
//                Log.d(TAG, "Clicked 'Auto Login'");
//            }


                // printTestReport("Putco ticket should follow");

                solo.waitForDialogToClose();
            }

        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }

    }
}
