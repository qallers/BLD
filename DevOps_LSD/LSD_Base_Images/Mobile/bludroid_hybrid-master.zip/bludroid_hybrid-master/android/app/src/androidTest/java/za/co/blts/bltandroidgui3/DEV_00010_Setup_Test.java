package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;
import androidx.test.rule.GrantPermissionRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINTER_WIDTH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;

/**
 * Created by NkosanaM on 1/9/2017.
 */

@RunWith(AndroidJUnit4.class)
public class DEV_00010_Setup_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> activityActivityTestRule = new ActivityTestRule<>(ActivityLanding.class);

    @Rule public GrantPermissionRule storageRule = GrantPermissionRule.grant(android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
    @Rule public GrantPermissionRule phoneRule = GrantPermissionRule.grant(android.Manifest.permission.READ_PHONE_STATE);
    @Rule public GrantPermissionRule locationRule = GrantPermissionRule.grant(android.Manifest.permission.ACCESS_FINE_LOCATION);

    @Before
    public void before() throws Exception {
        setUp(activityActivityTestRule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void testSetUp() {
        try {
            checks.enterDeviceID(testProperties.getProperty("deviceId"));

            checks.selectTheme("tspc");
            checks.selectTheme("blt");

            //paper cutter on and off again
            checks.toggleSwitch("papercutter");
            checks.toggleSwitch("papercutter");

            //usb printer on and off again
            checks.toggleSwitch("usbprinter");
            checks.toggleSwitch("usbprinter");

            //sales receipt off and on again
            checks.toggleSwitch("salesreceipt");
            checks.toggleSwitch("salesreceipt");

            //change printer width
            checks.changePrinterWidth("42");
            checks.changePrinterWidth("32");
            checks.changePrinterWidth(testProperties.getProperty("printerWidth"));

            //save to preferences
            checks.save();

//            solo.waitForActivity(ActivityLanding.class, 2000);
            solo.clickOnButton("OK");
            Log.d(TAG, "Clicked on OK");
            solo.sleep(1000);

            Log.d(TAG, getBaseActivity().getPreference(PREF_DEVICE_ID));

            //check if the device id was updated
            if (!checks.checkPreference(PREF_DEVICE_ID).equals(testProperties.getProperty("deviceId"))) {
                fail("PREF_DEVICE_ID not updated");
            } else {
                Log.d(TAG, "PREF_DEVICE_ID updated");
            }

            //check if the theme was updated
            if (!checks.checkPreference(PREF_SKIN).equals(getBaseActivity().getResources().getString(R.string.blt))) {
                fail("PREF_THEME not updated");
            } else {
                Log.d(TAG, "PREF_THEME updated");
            }

            //check if the printer width was updated
            if (!checks.checkPreference(PREF_PRINTER_WIDTH).equals(testProperties.getProperty("printerWidth"))) {
                fail("PREF_PRINTER_WIDTH not updated");
            } else {
                Log.d(TAG, "PREF_PRINTER_WIDTH updated");
            }

            Log.d(TAG, "Passed Successfully..!");

        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }
}
