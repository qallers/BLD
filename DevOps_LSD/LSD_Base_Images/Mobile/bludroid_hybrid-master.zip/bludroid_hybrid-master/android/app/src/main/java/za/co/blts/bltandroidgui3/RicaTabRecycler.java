package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_CAN_BOXRICA;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

/**
 * Created by NkosanaM on 7/12/2017.
 */

class RicaTabRecycler extends BaseFragment {

    TabLayout tabs = null;
    ViewPager viewPager = null;

    private FragmentRicaRegister ricaRegister;
    private FragmentRicaChangeOwner ricaChangeOwner;
    private FragmentRicaBoxRegister ricaBoxRegister;

    RicaPagerAdapter adapter;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String[] tabTitles = getResources().getStringArray(R.array.ricaTabs);


        if (tabs != null) {
            setupTabs(tabs, tabTitles);
            tabs.setTabMode(TabLayout.MODE_SCROLLABLE);
        }


        FragmentRicaQuery ricaQuery = new FragmentRicaQuery();
        ricaRegister = new FragmentRicaRegister();
        ricaChangeOwner = new FragmentRicaChangeOwner();
        ricaBoxRegister = new FragmentRicaBoxRegister();

        adapter = new RicaPagerAdapter(getChildFragmentManager(), tabs.getTabCount());

        adapter.addFragment(ricaQuery);
        adapter.addFragment(ricaRegister);
        adapter.addFragment(ricaChangeOwner);

        adapter.addFragment(ricaBoxRegister);

        viewPager.setAdapter(adapter);


        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabs));

    }

    private void setupTabs(TabLayout tabs, String[] tabTitles) {

        for (String tabTitle : tabTitles) {
            tabs.addTab(tabs.newTab().setText(tabTitle));
        }
        if (getBaseActivity().getPreference(PREF_RICA_CAN_BOXRICA).equals(PREF_TRUE)) {
            tabs.addTab(tabs.newTab().setText("Box Rica"));
        }

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                switch (tab.getPosition()) {
                    case 0:
                        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentRicaQuery", null);
                        break;
                    case 1:
                        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentRicaRegister", null);
                        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentRicaConsumerInfo", null);
                        break;
                    case 2:
                        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentRicaChangeOwner", null);
                        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentRicaChangeConsumerInfo", null);
                        break;
                }

                viewPager.setCurrentItem(tab.getPosition());

                if (ricaRegister != null && ricaRegister.isAdded()) {
                    FragmentRicaRegister f = (FragmentRicaRegister) adapter.getItem(1);
                    if (f._mViewPager != null) {
                        f._mViewPager.setCurrentItem(0);
                    }
                }

                if (ricaChangeOwner != null && ricaChangeOwner.isAdded()) {
                    FragmentRicaChangeOwner f = (FragmentRicaChangeOwner)adapter.getItem(2);
                    if ( f._mViewPager != null) {
                        f._mViewPager.setCurrentItem(0);
                    }
                }

                if (ricaBoxRegister != null && ricaBoxRegister.isAdded()) {
                    FragmentRicaBoxRegister f = (FragmentRicaBoxRegister)adapter.getItem(3);
                    if ( f._mViewPager != null) {
                        f._mViewPager.setCurrentItem(0);
                    }
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {


            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());

            }
        });
    }
}

class RicaPagerAdapter extends FragmentPagerAdapter {
    private int mNumOfTabs;

    private final List<Fragment> mFragments = new ArrayList<>();

    public RicaPagerAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }

    public void addFragment(Fragment fragment) {
        mFragments.add(fragment);
        notifyDataSetChanged();
    }

    @Override
    public Fragment getItem(int position) {

        return mFragments.get(position);

    }


    @Override
    public int getCount() {
        return mNumOfTabs;
    }
}
