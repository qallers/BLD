package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidIntegerEditText extends BluDroidEditText {
    private final String TAG = this.getClass().getSimpleName();

    private void setUpInteger() {
        setInputType(InputType.TYPE_CLASS_NUMBER);
        setKeyListener(DigitsKeyListener.getInstance("0123456789"));
    }

    BluDroidIntegerEditText(BaseActivity context) {
        super(context);
        setUpInteger();
    }

    public BluDroidIntegerEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpInteger();
    }

    public BluDroidIntegerEditText(Context context, AttributeSet attrs, BaseActivity baseActivity) {
        super(context, attrs);
        setUpInteger();
    }

    public boolean validate() {
        Log.d(TAG, "validate");
        BaseActivity.logger.info(": validate()");
        String numString = getText().toString().trim();

        if (!tryParseInt(numString)) {
            setErrorMessage("Only numbers are allowed");
            return false;
        } else {
            removeErrorMessage();
            return true;
        }
    }

    boolean tryParseInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }


}

