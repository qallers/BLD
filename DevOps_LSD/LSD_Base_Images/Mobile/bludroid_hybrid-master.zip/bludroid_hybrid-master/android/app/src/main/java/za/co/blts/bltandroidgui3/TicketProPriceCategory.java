package za.co.blts.bltandroidgui3;

/**
 * Created by NkosanaM on 2/5/2018.
 */

class TicketProPriceCategory {

    private String id;
    private String label;
    private String price;
    private int quantity;

    public TicketProPriceCategory(String id, String label, String price, int quantity) {
        this.id = id;
        this.label = label;
        this.price = price;
        this.quantity = quantity;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
