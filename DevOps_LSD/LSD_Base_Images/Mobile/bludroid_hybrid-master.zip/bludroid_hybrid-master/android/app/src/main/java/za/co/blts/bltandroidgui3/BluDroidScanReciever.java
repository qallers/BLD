package za.co.blts.bltandroidgui3;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by NkosanaM on 9/12/2017.
 */

public class BluDroidScanReciever extends BroadcastReceiver {

    private final String TAG = this.getClass().getSimpleName();
    private static BluDroidScanListener listener = null;

    public static void setListener(BluDroidScanListener activityListening) {
        listener = activityListening;
    }

    @Override
    public void onReceive(Context arg, Intent intent) {
        Log.d(TAG, "onReceive intent is " + intent);

        Log.d(TAG, "symbology is " + intent.getStringExtra("symbology"));
        Log.d(TAG, "barcode is " + intent.getStringExtra("barcode"));
        if (listener != null) {
            listener.setBarcode(intent.getStringExtra("barcode"));
        }
    }
}
