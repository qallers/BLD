package za.co.blts.bltandroidgui3.confirmations;

import android.view.View;
import android.view.View.OnClickListener;

import za.co.blts.bltandroidgui3.AEONErrors;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

//
// view and button stuff
//

public class BluDroidNetworkErrorConfirmationDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, OnClickListener {
    private final String TAG = this.getClass().getSimpleName();
    public void setup() {
        super.setup();
        hideView(R.id.affirmativeButton);
        hideView(R.id.negativeButton);

        BluDroidButton button = findViewById(R.id.neutralButton);

        BluDroidTextView warning = findViewById(R.id.warning);
        warning.setTextColor(baseActivity.getResources().getColor(R.color.errorColorBLT));

        BluDroidTextView retriesLeft = findViewById(R.id.errorOr);
        retriesLeft.setText(getContext().getResources().getString(R.string.retries_left, BaseActivity.autoLoginRetryCap));

        if (BaseActivity.autoLoginRetryCap > 0) {
            setNeutralButtonLabel("Auto Login");
        } else {
            retriesLeft.setVisibility(View.GONE);
            setNeutralButtonLabel(baseActivity.getString(R.string.ok));
        }


        if (button != null)
            button.setOnClickListener(this);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BaseActivity.loginRequestMessage = null;
                BaseActivity.loginResponseMessage = null;
                BaseActivity.isForcedLogout = true;
                baseActivity.logout();
                baseActivity.firebaseSessionEnd("network_error");
                BaseActivity.lockBackButton = false;
            }
        });

        BaseActivity.isLotto = false;
        BaseActivity.lockBackButton = true;
        baseActivity.cleanUp();
    }

    public BluDroidNetworkErrorConfirmationDialog(BaseActivity context) {
        super(context, R.layout.confirmation_network_error);
        setup();
        BaseActivity.logger.info(": construction with BaseActivity");
    }

    public void setErrorType(int errorType) {
        //
        // remove some fields if necessary
        //
        if (errorType == AEONErrors.NO_USER_ACTION_REQUIRED) {
            View view = findViewById(R.id.errorTryAgain);
            if (view != null) {
                view.setVisibility(View.GONE);
            }
            view = findViewById(R.id.errorRestart);
            if (view != null) {
                view.setVisibility(View.GONE);
            }
            view = findViewById(R.id.errorTheApp);
            if (view != null) {
                view.setVisibility(View.GONE);
            }
        }

    }

    public void onClick(View view) {
        //BaseActivity.logger.info(": onClick()");
        BaseActivity.logger.info(((BluDroidButton) view).getText());
        if (BaseActivity.loginResponseMessage != null) {
            BaseActivity.userPin = BaseActivity.loginResponseMessage.getData().getUserPin();
        }
        BaseActivity.loginRequestMessage = null;
        BaseActivity.loginResponseMessage = null;
        BaseActivity.isForcedLogout = true;
        baseActivity.removeLoginCache();
        baseActivity.logout();
        baseActivity.firebaseSessionEnd("network_error");
        BaseActivity.lockBackButton = false;
        baseActivity.cleanUp();


    }

    @Override
    public void onBackPressed() {
        BaseActivity.lockBackButton = false;
    }
}

