package za.co.blts.bltandroidgui3;

/**
 * Created by WarrenM1 on 2017/06/20.
 */

class CalculateChangeDataModel {
    private String provider;
    private String voucherType;
    private double amount;
    private boolean canCalculate;
    private int iconSelected;

    public CalculateChangeDataModel(String provider, String voucherType, double amount, boolean canCalculate, int iconSelected) {
        this.provider = provider;
        this.voucherType = voucherType;
        this.amount = amount;
        this.canCalculate = canCalculate;
        this.iconSelected = iconSelected;
    }


    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public String getVoucherType() {
        return voucherType;
    }

    public void setVoucherType(String voucherType) {
        this.voucherType = voucherType;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public boolean canCalculate() {
        return canCalculate;
    }

    public void setCanCalculate(boolean canCalculate) {
        this.canCalculate = canCalculate;
    }

    public int getIconSelected() {
        return iconSelected;
    }

    public void setIconSelected(int iconSelected) {
        this.iconSelected = iconSelected;
    }
}
