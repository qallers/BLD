package za.co.blts.bltandroidgui3;

import android.content.Context;
import android.util.AttributeSet;

import com.google.android.material.tabs.TabLayout;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;

//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidPinlessPrintTabLayout extends TabLayout implements BluDroidSetupable {

    private WeakReference<BaseActivity> baseActivityWeakReference;

    public BluDroidPinlessPrintTabLayout(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setup();
    }

    public BluDroidPinlessPrintTabLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (context instanceof BaseActivity) {
            this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
            setup();
        }
    }

    public void setup() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                setTabTextColors(baseActivity.getSkinResources().getButtonColor(), baseActivity.getSkinResources().getButtonColor());
                setSelectedTabIndicatorColor(baseActivity.getSkinResources().getButtonColor());
            }
        }
    }

    public void setContext(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

}

