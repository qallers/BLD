package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by Warren2.0 on 10/04/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00130_DataVoucher_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_Vodacom_50MB() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeData();

            solo.clickOnText("50MB");
            Log.d(TAG, "50MB data voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T100_Mtn_50MB() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN  MENU selected");

            solo.clickOnText("50MB");
            Log.d(TAG, "Bundle 50MB Weekly data voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T300_CellC_3GB() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "CELL C  MENU selected");

            solo.clickOnText("3GB");
            Log.d(TAG, "3GB data voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T500_Telkom_100MB() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }
            //scroll for telkom using cellc
            selectProviderCellC();

            selectProviderTelkom();
            Log.d(TAG, "TELKOM MENU selected");

            gotoPinlessBundles();
            Log.d(TAG, "TELKOM TOP UP data vouchers selected");

            solo.clickOnText("100MB");
            Log.d(TAG, "100MB PINLESS TOP UP data voucher selected");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with no cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberNotEntered))) {
                Log.d(TAG, "Cellphone number not entered error message displayed");
            } else {
                fail("Cellphone number not entered error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "1121231234");
            Log.d(TAG, "Invalid cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "1121231234");
            Log.d(TAG, "Invalid cellphone number confirmed");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with invalid cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberInvalid))) {
                Log.d(TAG, "Cellphone number invalid error message displayed");
            } else {
                fail("Cellphone number invalid error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "0601231234");
            Log.d(TAG, "Not Matching Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0601231235");
            Log.d(TAG, "Not Matching Cellphone number confirmed");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with mismatching cellphone numbers");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumbersDontMatch))) {
                Log.d(TAG, "Cellphone numbers don't match error message displayed");
            } else {
                fail("Cellphone numbers don't match error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "0601231235");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0601231235");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T600_Neotel_Wifi() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }

            selectProviderMTN();
            selectProviderCellC();
            selectProviderTelkom();
            selectProviderNeotel();
            Log.d(TAG, "NEOTEL  MENU selected");

            solo.clickOnText("WiFi");
            Log.d(TAG, "WiFi voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T700_All_3GB() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN  MENU selected");

            selectProviderCellC();
            Log.d(TAG, "CELL C  MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "TELKOM  MENU selected");

            selectProviderNeotel();
            Log.d(TAG, "NEOTEL  MENU selected");

            selectProviderVirginMobile();
            Log.d(TAG, "Virgin Mobile  MENU selected");

            selectProviderAllProviders();
            Log.d(TAG, "All Service Providers MENU selected");

            scrollToText("3GB");
            Log.d(TAG, "3GB voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
