package za.co.blts.bltandroidgui3;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProductMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProviderMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseProductMessage;
import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponseSupplierMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseManufacturerMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseProductMessage;
import za.co.blts.bltandroidgui3.cardviews.CardViewBillPayment;
import za.co.blts.bltandroidgui3.cardviews.CardViewElectricity;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.cardviews.CardviewUnipin;
import za.co.blts.bltandroidgui3.cardviews.CardviewVoucherMenu;
import za.co.blts.bltandroidgui3.confirmations.BluDroidChatForChangeConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDialogable;
import za.co.blts.bltandroidgui3.confirmations.BluDroidElectricityPurchaseConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidEskomTrialPurchaseDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidFreeBasicElectricityDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessBundleConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessTopupAnyAmountConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessTopupConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidUniversalElectricityDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidVoucherPurchaseConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidSearchEditText;
import za.co.blts.magcard.MagCardData;

public class FragmentSearch extends BaseFragment implements NeedsAEONResults, BluDroidDialogable {

    private final String TAG = this.getClass().getSimpleName();
    private BluDroidSearchEditText txtSearch;

    private final ArrayList<CardviewDataObject> masterList = new ArrayList<>();
    private final ArrayList<CardviewDataObject> displayList = new ArrayList<>();
    private boolean productsLoading = false;

    public FragmentSearch() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        getBaseActivity().crashLog("Activity", getBaseActivity().getClass().getSimpleName());
        getBaseActivity().crashLog("Fragment", this.getClass().getSimpleName());
        getBaseActivity().crashLog("Progress", null);
        getBaseActivity().crashLog("Dialog", null);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView");
        View rootView = inflater.inflate(R.layout.fragment_search, container, false);
        recycler = rootView.findViewById(R.id.bluRecycler);
        txtSearch = rootView.findViewById(R.id.search);

        return rootView;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        Log.d(TAG, "onActivityCreated");
        super.onActivityCreated(savedInstanceState);
        getBaseActivity().hideKeyboard();
        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();

        int spanCount = 2;
        if (getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            spanCount = 3;
        }

        GridLayoutManager grid = new GridLayoutManager(getActivity(), spanCount) {
            @Override
            public void onLayoutCompleted(final RecyclerView.State state) {
                super.onLayoutCompleted(state);
                Log.v(TAG, "onLayoutCompleted: firstDraw=" + productsLoading);
                if (productsLoading) {
                    productsLoading = false;
                    getBaseActivity().runOnUiThread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    getBaseActivity().dismissProgress();
                                }
                            });
                }
            }
        };

        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getActivity(), R.dimen.item_offset);
        recycler.addItemDecoration(itemDecoration);

        recycler.setLayoutManager(grid);

        adapter = new BluRecyclerAdapter(this, masterList);
        recycler.setAdapter(adapter);

        txtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
                String search = txtSearch.getText().toString().toLowerCase();
                Log.d(TAG, "afterTextChanged: " + search);
                if (search.isEmpty()) {
                    adapter.clearFilter();
                } else {
                    recycler.setAdapter(null);
                    adapter.setFilterSearch(search);
                    recycler.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
//                filterList(search);
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume");
        String title = "Search";
        if (getActivity() != null) getActivity().setTitle(title);

        configureRecycler();
    }

    @Override
    public boolean onBackPressed() {
        getBaseActivity().gotoMainScreen();
        return true;
    }

    private void configureRecycler() {
        getBaseActivity().createProgress(R.string.loadingProducts);
        //building products can take a few seconds due to number of products
        //must be done in a separate thread so that the progress dialog gets displayed
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                buildProducts();
                productsLoading = true;
                //only ui thread allowed to change UI, so notify data changed on ui thread again
                getBaseActivity().runOnUiThread(
                        new Runnable() {
                            @Override
                            public void run() {
                                adapter.notifyDataSetChanged();
                            }
                        });
            }
        });
    }

    private void buildProducts() {
        long start = System.currentTimeMillis();
        masterList.clear();

        List<CardviewDataObject> cached = getBaseActivity().getCachedSearchData1();
        if (cached != null) {
            masterList.addAll(cached);
            Log.d(TAG, "got search cache: items=" + masterList.size());
        }

        if (masterList.isEmpty()) {
            Log.w(TAG, "rebuilding search cache");
            addAirtime();
            addData();
            addBillPayments();
            addElectricity();
            addVouchers();
            addChatForChange();
            Collections.sort(masterList, CardviewDataObject.tagComparator);
            getBaseActivity().cacheSearchData1(masterList);
        }

        Log.v(TAG, "Items in MasterList: " + masterList.size());
        Log.v(TAG, "Time to build: " + (System.currentTimeMillis() - start));
    }

    private void addBillPayments() {
        ArrayList<SortableProduct> products = new ArrayList<>();

        if (BaseActivity.billPaymentsResponseProductListMessage != null && BaseActivity.billPaymentsResponseProductListMessage.getData().getProviders().size() > 0) {

            for (int i = 0; i < BaseActivity.billPaymentsResponseProductListMessage.getData().getProviders().size(); i++) {
                BillPaymentsResponseProviderMessage provider = BaseActivity.billPaymentsResponseProductListMessage.getData().getProviders().get(i);
                for (int j = 0; j < provider.getProducts().size(); j++) {
                    BillPaymentsResponseProductMessage product = provider.getProducts().get(j);
                    SortableProduct newProduct = new SortableProduct(product, provider);
                    products.add(newProduct);
                }
            }

            for (int i = 0; i < products.size(); i++) {
                SortableProduct product = products.get(i);
                BillPaymentsResponseProviderMessage provider = product.getProvider();

                if (provider != null) {
                    // ignore bus tickets right now
                    if (provider.getName().equals("Pay@ Bus Tickets")) {
                        continue;
                    }
                    // ignore insurance premiums right now
                    if (provider.getName().equals("Pay@ insurance Payment")) {
                        continue;
                    }

                    if (provider.getName().equals("SAPO Account Payment")) {
                        addBillPaymentToProductList(product.getName(), provider.getName(), product.getLogoId());
                    } else if (provider.getName().equals("Pay@ Account Payment")) {
                        addBillPaymentToProductList(product.getName(), provider.getName(), product.getLogoId());
                    } else if (provider.getName().equals("Blu Bill Payment")) {
                        addBillPaymentToProductList(product.getName(), provider.getName(), product.getLogoId());
                    } else if (provider.getName().equals("Syntell Account Payment")) {
                        addBillPaymentToProductList(product.getName(), provider.getName(), product.getLogoId());

                    } else if (provider.getName().equals("Pay@ Fine Payment")) {
                        addBillPaymentToProductList(product.getName(), provider.getName(), product.getLogoId());
                    } else if (provider.getName().equals("Syntell Traffic Fines")) {
                        addBillPaymentToProductList(product.getName(), provider.getName(), product.getLogoId());
                    }

                }
            }
        }

        //Merchant to Merchant Transfer
        if (BaseActivity.loginResponseMessage.getData().canDoMerchantTransfer()) {
            addBillPaymentToProductList("Merchant To Merchant Transfer", "MerchantTransfer", "");
        }
    }

    private void addBillPaymentToProductList(String product, String provider, String logoId) {
        int resId;

        String voucherTypeDesc;
        if (provider.contains("Traffic Fine") || provider.contains("Fine Payment")) {
            voucherTypeDesc = "Traffic Fine";
        } else {
            voucherTypeDesc = "Bill Payment";
        }

        if (logoId != null && logoId.equals("30")) {
            resId = R.drawable.billpayment_easypay;
        } else if (logoId != null && logoId.equals("31")) {
            resId = R.drawable.billpayment_unipay;

        } else if (product.toLowerCase().contains("telkom")) {
            resId = getBaseActivity().getDrawableResource("telkomdark");
        } else {
            String shortname = getBaseActivity().getShortName(product);
            resId = getBaseActivity().getDrawableResource(shortname);
        }
        if (resId == 0) {
            resId = getBaseActivity().getDrawableResource("default_transact");
        }
        masterList.add(new CardViewBillPayment(getBaseActivity(), product, "", resId, "", "bill_payment", "Bill", voucherTypeDesc, provider));
    }

    private void addElectricity() {
        createElectricityCards(retrieveMunics(), retrieveUniPin());
    }

    private Map<String, String> retrieveMunics() {
        Map<String, String> munics = null;
        if (BaseActivity.loginResponseMessage != null) {
            munics = new ElectricityUtility().getElectricity();
        }
        return munics;
    }

    private Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> retrieveUniPin() {
        Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> uniPin = null;
        if (BaseActivity.loginResponseMessage != null) {
            uniPin = new ElectricityUtility().getVouchers("Electricity");
        }
        return uniPin;
    }

    private void createElectricityCards(Map<String, String> munics, Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> uniPinVouchers) {
        String currency = getResources().getString(R.string.currency);
        String voucher = getResources().getString(R.string.voucher);

        String voucherTypeDesc = "Electricity";
        if (munics != null) {
            for (String municRealName : munics.keySet()) {
                String municName = munics.get(municRealName);
                if (municName != null && getActivity() != null) {
                    if (municName.equalsIgnoreCase("electricity") || municName.equalsIgnoreCase("eskom")) {
                        if (municName.equalsIgnoreCase("eskom")) {
                            masterList.add(new CardViewElectricity(getActivity(), municName, "", R.drawable.eskom, "", "munics", municRealName, voucherTypeDesc));
                        } else {
                            masterList.add(new CardViewElectricity(getActivity(), municName, "", "", "munics", municRealName, voucherTypeDesc));
                        }
                    }
                }
            }
            if (munics.size() > 0 && getActivity() != null) {
                masterList.add(new CardViewElectricity(getActivity(), "Free Basic Electricity", "", "", "munics", "FBE", voucherTypeDesc));
            }
        }

        if (munics != null) {
            for (String municRealName : munics.keySet()) {
                String municName = munics.get(municRealName);
                if (municName != null && getActivity() != null) {
                    if (!(municName.equalsIgnoreCase("electricity") || municName.equalsIgnoreCase("eskom"))) {

                        String shortname = getBaseActivity().getShortName(municName);
                        int resId = getBaseActivity().getDrawableResource(shortname);

                        if (resId != 0) {
                            masterList.add(new CardViewElectricity(getActivity(), municName, "", resId, "", "munics", municRealName, voucherTypeDesc));
                        } else {
                            masterList.add(new CardViewElectricity(getActivity(), municName, "", "", "munics", municRealName, voucherTypeDesc));
                        }
                    }
                }
            }
        }

        if (uniPinVouchers != null) {
            for (VoucherListResponseManufacturerMessage mapKey : uniPinVouchers.keySet()) {
                boolean hasAirtimePlus = mapKey.getAirtimePlus().equals("1");
                ArrayList<VoucherListResponseProductMessage> products = uniPinVouchers.get(mapKey);
                String key = mapKey.getName();
                if (products != null) {
                    for (VoucherListResponseProductMessage product : products) {
                        if (key.equals("UniPin")) {
                            masterList.add(new CardviewUnipin(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                        }
                    }
                }
            }
        }
    }

    private String getCleanDesc(String description, String network) {
        String cleanDescription = "";
        if (network.startsWith("x")) {
            network = network.replace("x", "");
        }

        String[] parts = description.split(" |\\(|\\)|\\,");
        for (String part : parts) {
            if (!part.equalsIgnoreCase(network) &&
                    !part.equalsIgnoreCase("Airtime") &&
                    !part.equalsIgnoreCase("Data") &&
                    !part.equalsIgnoreCase("Cell") &&
                    !part.equalsIgnoreCase("C") &&
                    !part.equalsIgnoreCase("TelkomMobile") &&
                    !part.equalsIgnoreCase("8ta") &&
                    !part.equalsIgnoreCase("TOP") &&
                    !part.equalsIgnoreCase("TV") &&
                    !part.equalsIgnoreCase("Hollywood") &&
                    !part.equalsIgnoreCase("Bets")) {
                cleanDescription += part + " ";
            }
        }
        return cleanDescription.trim();
    }

    @Override
    public void affirmativeButton(View view) {
        Log.d(TAG, "affirmativeButton " + getBaseActivity().confirmation.getClass().getSimpleName());

        getBaseActivity().isElectricityResponseFirstTime = true;

        if (getBaseActivity().confirmation instanceof BluDroidConfirmPassengerDialog) {
            getBaseActivity().dismissConfirmation();
            getBaseActivity().fragmentCarmaConfirmPurchaseTicket = new FragmentCarmaConfirmPurchaseTicketNew();
            getBaseActivity().gotoFragment(getBaseActivity().fragmentCarmaConfirmPurchaseTicket, "FragmentCarmaConfirmPurchaseTicketNew");

        } else if (getBaseActivity().confirmation instanceof BluDroidElectricityPurchaseConfirmationDialog) {
            BaseActivity.logger.info("Electricity Purchase Confirmed");
            BluDroidElectricityPurchaseConfirmationDialog dialog = (BluDroidElectricityPurchaseConfirmationDialog) getBaseActivity().confirmation;

            // Displaying of the outstanding balance no longer required as it is already displayed on the confirmation
            // of purchase screen.
            // check if we have an outstanding amount
            /* if (!dialog.getOutstanding().isEmpty() || dialog.getOutstanding().equalsIgnoreCase("0.00")) {
                getBaseActivity().dismissConfirmation();
                double outstanding = Double.parseDouble(dialog.getOutstanding().replace("R", ""));
                double amount = Double.parseDouble(dialog.getAmount().replace("R", ""));

                 if (outstanding >= amount) {
                    getBaseActivity().alert = getBaseActivity().createElectricityAlertDialog("Outstanding Amount", "Your outstanding balance of <font color='#FF0000'><b> R" + getBaseActivity().df2.format(outstanding) + "</b></font>"
                            + " will need to be settled before you can purchase a new voucher. Do you wish to continue?");
                    getBaseActivity().alert.setPositiveOption("Continue", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ((ActivityMain) getBaseActivity()).purchaseElectricity();
                        }
                    });
                    getBaseActivity().alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    getBaseActivity().alert.show();

                }
                    else if (outstanding < amount) {
                    getBaseActivity().alert = getBaseActivity().createElectricityAlertDialog("Outstanding Amount", "Your outstanding balance of <font color='#FF0000'><b> R"
                            + getBaseActivity().df2.format(outstanding) + "</b></font>" + " will need to be settled before you can purchase a new voucher. The value of your token will be <font color='#FF0000'><b>R"
                            + getBaseActivity().df2.format(amount - outstanding) + "</b></font>. Do you wish to continue?");
                    getBaseActivity().alert.setPositiveOption("Continue", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ((ActivityMain) getBaseActivity()).purchaseElectricity();
                        }
                    });
                    getBaseActivity().alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    getBaseActivity().alert.show();
                }

            }
            else {
                getBaseActivity().dismissConfirmation();
                ((ActivityMain) getBaseActivity()).purchaseElectricity();
            } */

            // if-statement above no longer required as part of the CR-2630 change request
            // which stated that CIGICELL - Remove "Outstanding Amount" Dialog from BluDroid App Meter Confirmation Flow
            getBaseActivity().dismissConfirmation();
            ((ActivityMain) getBaseActivity()).purchaseElectricity();

        } else if (getBaseActivity().confirmation instanceof BluDroidEskomTrialPurchaseDialog) {
            BluDroidEskomTrialPurchaseDialog dialog = (BluDroidEskomTrialPurchaseDialog) getBaseActivity().confirmation;
            if (dialog.validate()) {
                BaseActivity.logger.info("Eskom Electricity Purchase Confirmed");
                String municName = "EskomDirect";
                String meterNumber = dialog.getMeterNumber();
                String amount = dialog.getAmount();
                String purchaseType = "Trial";
                getBaseActivity().dismissConfirmation();
                ((ActivityMain) getBaseActivity()).authenticateForUniversalElectricity(municName, meterNumber, amount, purchaseType);
            }

        } else if (getBaseActivity().confirmation instanceof BluDroidUpdateEskomMeterKeysDialog) {
            BluDroidUpdateEskomMeterKeysDialog dialog = (BluDroidUpdateEskomMeterKeysDialog) getBaseActivity().confirmation;
            if (dialog.validate()) {
                String municName = "EskomDirect";
                String meterNumber = dialog.getMeterNumber();
                String amount = "0.00";
                String purchaseType = "Update";
                String tt = dialog.getTt();
                String ti = dialog.getTi();
                String sgc = dialog.getSgc();
                String krn = dialog.getKrn();
                String alg = dialog.getAlg();
                getBaseActivity().dismissConfirmation();
                ((ActivityMain) getBaseActivity()).authenticateForUpdateMeterKeys(municName, meterNumber, amount, purchaseType, tt, alg, sgc, krn, ti);
            }

        } else if (getBaseActivity().confirmation instanceof BluDroidEskomTokenByOtherDialog) {
            BluDroidEskomTokenByOtherDialog dialog = (BluDroidEskomTokenByOtherDialog) getBaseActivity().confirmation;
            if (dialog.validate()) {
                String municName = "EskomDirect";
                String meterNumber = dialog.getMeterNumber();
                String amount = dialog.getAmount();
                String purchaseType = "Token";
                String tt = dialog.getTt();
                String ti = dialog.getTi();
                String sgc = dialog.getSgc();
                String krn = dialog.getKrn();
                String alg = dialog.getAlg();
                getBaseActivity().dismissConfirmation();
                ((ActivityMain) getBaseActivity()).authenticateForEskomTokenByOther(municName, meterNumber, amount, purchaseType, sgc, tt, ti, krn, alg);
            }

        } else if (getBaseActivity().confirmation instanceof BluDroidEskomRedeemTokenDialog) {
            BluDroidEskomRedeemTokenDialog dialog = (BluDroidEskomRedeemTokenDialog) getBaseActivity().confirmation;
            if (dialog.validate()) {
                BaseActivity.logger.info(((Button) view).getText());
                if (getBaseActivity().openMagEncoder()) {
                    getBaseActivity().tokensSize = 1;
                    getBaseActivity().magCard.setDelegate((ActivityMain) getBaseActivity());
                    getBaseActivity().magCardDataList = new ArrayList<>();
                    MagCardData magCardData = new MagCardData();
                    magCardData.setTrack3(dialog.getTokenNumber());
                    getBaseActivity().magCardDataList.add(magCardData);
                    getBaseActivity().magCard.setTrack3(getBaseActivity().magCardDataList.get(0).getTrack3());
                    getBaseActivity().magCard.openUsbSerial();
                    getBaseActivity().magCard.sendWriteCommand();
                    getBaseActivity().magCardAction = "write";
                    getBaseActivity().alert = getBaseActivity().createMagEncoderAlertDialog("Mag Card", "Please swipe card to write " + getBaseActivity().cardNumber + "/" + getBaseActivity().tokensSize);
                } else {
                    getBaseActivity().createNotifyAlertDialog("Mag Encoder", "Mag Encoder not detected");
                }
            }

        } else if (getBaseActivity().confirmation instanceof BluDroidVoucherPurchaseConfirmationDialog) {
            BluDroidVoucherPurchaseConfirmationDialog dialog = (BluDroidVoucherPurchaseConfirmationDialog) getBaseActivity().confirmation;
            int quantity = dialog.getQuantity();
            getBaseActivity().dismissConfirmation();
            Log.d(TAG, "quantity is " + quantity);
            if (!((BluDroidVoucherPurchaseConfirmationDialog) getBaseActivity().confirmation).isMVNO()) {
                getMainActivity().getVoucher(adapter.getStockId(), quantity, dialog.getSupplierCode(), dialog.getAmount());
            } else {
                BaseActivity.gettingVouchers = true;
                getMainActivity().authenticateForChatForChange(dialog.getSupplierCode(), dialog.getAmount());
            }

        } else if (getBaseActivity().confirmation instanceof BluDroidChatForChangeConfirmationDialog) {
            BluDroidChatForChangeConfirmationDialog dialog = (BluDroidChatForChangeConfirmationDialog) getBaseActivity().confirmation;
            String supplierCode = dialog.getSupplierCode();
            String amount = dialog.getAmount();
            Log.d(TAG, "supplierCode is " + supplierCode);
            Log.d(TAG, "supplierCode is " + dialog.getSupplierCode() + " Amount " + dialog.getAmount());

            if (dialog.validate()) {
                getBaseActivity().multipleVouchersAuthenticationResponseMessage = null;
                getBaseActivity().dismissConfirmation();
                String possibleStockId = getPossibleStockId(supplierCode, amount);
                BaseActivity.gettingVouchers = true;
                if (possibleStockId == null) {
                    getMainActivity().authenticateForChatForChange(dialog.getSupplierCode(), amount);
                } else {
                    getMainActivity().getVoucher(possibleStockId, 1, supplierCode, amount);
                }
            }
        }

        // order of next two items is important because of inheritance
        else if (getBaseActivity().confirmation instanceof BluDroidPinlessBundleConfirmationDialog) {
            Log.d(TAG, "bundles");
            BluDroidPinlessBundleConfirmationDialog dialog = (BluDroidPinlessBundleConfirmationDialog) getBaseActivity().confirmation;
            String cellNumber = dialog.getCellNumber();

            if (dialog.validate()) {
                Log.d(TAG, "validated");
                String provider = dialog.getTopupName();
                Log.d(TAG, "provider is [" + provider + "]");
                String bundleProvider = provider.replaceAll(" ", "").replaceAll("TelkomMobile", "TelkomMobile") + "Bundles";
                Log.d(TAG, "bundleProvider is [" + bundleProvider + "]");
                Log.d(TAG, "adapter.getStockId is [" + adapter.getStockId() + "]");
                // stockId holds the product code
                getBaseActivity().dismissConfirmation();
                getMainActivity().getBundle(bundleProvider, adapter.getStockId(), cellNumber);
            } else {
                Log.d(TAG, "validation failed");
            }

        } else if (getBaseActivity().confirmation instanceof BluDroidPinlessTopupConfirmationDialog) {
            Log.d(TAG, "pinless topup");
            BluDroidPinlessTopupConfirmationDialog dialog = (BluDroidPinlessTopupConfirmationDialog) getBaseActivity().confirmation;
            String topupName = dialog.getTopupName();
            String amount = dialog.getAmount();
            String cellNumber = dialog.getCellNumber();
            Log.d(TAG, "topupName is " + topupName);
            if (dialog.validate()) {
                if (new VoucherUtility(getBaseActivity()).containsCaseInsensitive(topupName, BaseActivity.walletTopupProviders)) {
                    getBaseActivity().gettingWalletTopup = true;
                }
                Log.d(TAG, "need to validate for pinless topup");
                Log.d(TAG, "topupName is " + topupName);
                Log.d(TAG, "amount is " + amount);
                getBaseActivity().dismissConfirmation();
                getMainActivity().authenticateForPinlessTopup(topupName, cellNumber, amount);
            }
        } else if (getBaseActivity().confirmation instanceof BluDroidPinlessTopupAnyAmountConfirmationDialog) {
            Log.d(TAG, "pinless topup any amount");
            BluDroidPinlessTopupAnyAmountConfirmationDialog dialog = (BluDroidPinlessTopupAnyAmountConfirmationDialog) getBaseActivity().confirmation;
            String topupName = dialog.getTopupName();
            String amount = dialog.getAmount();
            String cellNumber = dialog.getCellNumber();
            Log.d(TAG, "topupName is " + topupName);
            if (dialog.validate()) {
                if (new VoucherUtility(getBaseActivity()).containsCaseInsensitive(topupName, BaseActivity.walletTopupProviders)) {
                    getBaseActivity().gettingWalletTopup = true;
                }
                Log.d(TAG, "need to validate for pinless topup any amount");
                Log.d(TAG, "topupName is " + topupName);
                Log.d(TAG, "amount is " + amount);
                getBaseActivity().dismissConfirmation();
                getMainActivity().authenticateForPinlessTopup(topupName, cellNumber, amount);
            }

        } else if (getBaseActivity().confirmation instanceof BluDroidUniversalElectricityDialog) {
            Log.d(TAG, "universal electricity");
            BluDroidUniversalElectricityDialog dialog = (BluDroidUniversalElectricityDialog) getBaseActivity().confirmation;
            String municName = dialog.getMunicName();
            String meterNumber = dialog.getMeterNumber();
            String amount = dialog.getAmount();
            String purchaseType = "Token";
            Log.d(TAG, "municName is " + municName);
            if (dialog.validate()) {
                Log.d(TAG, "need to validate for universal electricity");
                Log.d(TAG, "municName is " + municName);
                Log.d(TAG, "meterNumber is " + meterNumber);
                Log.d(TAG, "amount is " + amount);
                getBaseActivity().dismissConfirmation();
                getMainActivity().authenticateForUniversalElectricity(municName, meterNumber, amount, purchaseType);
            }

        } else if (getBaseActivity().confirmation instanceof BluDroidFreeBasicElectricityDialog) {
            Log.d(TAG, "universal electricity");
            BluDroidFreeBasicElectricityDialog dialog = (BluDroidFreeBasicElectricityDialog) getBaseActivity().confirmation;
            String meterNumber = dialog.getMeterNumber();
            String purchaseType = "FBE";
            if (dialog.validate()) {
                Log.d(TAG, "need to validate for free basic electricity");
                Log.d(TAG, "meterNumber is " + meterNumber);
                getBaseActivity().dismissConfirmation();
                getMainActivity().authenticateForUniversalElectricity("Electricity", meterNumber, "0.00", purchaseType);
            }
        }
    }

    @Override
    public void negativeButton(View view) {
        Log.d("negativeButton", "cancel pressed on " + getBaseActivity().confirmation.getClass().getSimpleName());
        getBaseActivity().dismissConfirmation();
        getBaseActivity().isEncodingMagToken = false;
        if (getBaseActivity().confirmation instanceof BluDroidElectricityPurchaseConfirmationDialog) {
            getBaseActivity().closeAeonSocket(34);
        }
    }

    @Override
    public void neutralButton(View view) {
        Log.d("neutralButton", "ok pressed on " + getBaseActivity().confirmation.getClass().getSimpleName());
    }

    //
    // return true for chat4change
    // return false if it must go voucher
    //
    private String getPossibleStockId(String supplierCode, String amount) {
        String serviceProviderName = "";
        switch (supplierCode) {
            case "1":
                serviceProviderName = "Vodacom";
                break;
            case "2":
                serviceProviderName = "MTN";
                break;
            case "3":
                serviceProviderName = "Cell C";
                break;
            case "4":
                serviceProviderName = "Telkom Mobile";
                break;
            case "5":
                serviceProviderName = "Virgin Mobile";
                break;
        }
        for (int i = 0; i < BaseActivity.voucherListResponseMessage.getData().getManufacturers().size(); i++) {

            if (BaseActivity.voucherListResponseMessage.getData().getManufacturers().get(i).getName().equals(serviceProviderName)) {
                Log.d(TAG, "got " + serviceProviderName);
                Log.d(TAG, "amount [" + amount + "]");
                for (int j = 0; j < BaseActivity.voucherListResponseMessage.getData().getManufacturers().get(i).getProducts().size(); j++) {
                    if (BaseActivity.voucherListResponseMessage.getData().getManufacturers().get(i).getProducts().get(j).getCategoryDesc().equals("Airtime")) {

                        if (BaseActivity.voucherListResponseMessage.getData().getManufacturers().get(i).getProducts().get(j).getValue().equals(amount)) {
                            String stockId = BaseActivity.voucherListResponseMessage.getData().getManufacturers().get(i).getProducts().get(j).getText();
                            Log.d(TAG, "got stockId " + stockId);
                            return stockId;
                        }
                    }
                }
            }

        }
        return null;
    }

    private void addVouchers() {
        createMenuCards(retrieveVoucherMap("VoucherOther"));
    }

    private void createMenuCards(Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> map) {
        if (map != null) {
            for (VoucherListResponseManufacturerMessage mapKey : map.keySet()) {

                String key = mapKey.getName();
                if (key.startsWith("x")) {
                    key = key.replace("x", "");
                }

                Log.d(TAG, "voucher menu card: " + key);

                switch (key) {
                    case "Axxess":
                        masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.axxess, R.color.white, key, key));
                        break;
                    case "Hollywood Bets":
                        masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.hollywoodbets, R.color.hollywoodbets, key, key));
                        break;
                    case "Top TV":
                        masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.starsat, R.color.white, key, key));
                        break;
                    case "Dabba":
                        masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.dabba, R.color.white, key, key));
                        break;
                    case "Supabets":
                        masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.supabets, R.color.white, key, key));
                        break;
                    case "LottoStar":
                        masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.lottostar, R.color.white, key, key));
                        break;
                    case "BetFlash":
                        masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.betflash, R.color.white, key, key));
                        break;
                    case "AfricaPIN":
                        masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.africapin, R.color.white, key, key));
                        break;
                    case "Telkom":
                        masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.telkom, R.color.white, key, key));
                        break;
                    case "MVNO":
//                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.mvno_menu_card, R.color.mvno, key, key));
                        break;
                    default:
                        masterList.add(new CardviewVoucherMenu(getBaseActivity(), key, key));
                        break;
                }
            }
        }

        if (BaseActivity.loginResponseMessage.getData().canDoIthuba()) {
            masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ithuba, R.color.ithuba, getResources().getString(R.string.ithuba), getResources().getString(R.string.ithuba)));
        }
    }

    private Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> retrieveVoucherMap(String type) {
        Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> mappedResponse = null;

        if (BaseActivity.voucherListResponseMessage != null) {
            mappedResponse = new VoucherUtility(getBaseActivity()).getVouchers(type);
        }

        //Remove all all airtime and data if the type is equal to airtime / data
        if (type.equalsIgnoreCase("Airtime") || type.equalsIgnoreCase("Data") || type.equalsIgnoreCase("MVNO") || retrieveC4cSuppliers().size() == 0) {
            removeMVMOFromAllAirtime(mappedResponse);
        }
        return mappedResponse;
    }

    private List<Chat4ChangeResponseSupplierMessage> retrieveC4cSuppliers() {
        List<Chat4ChangeResponseSupplierMessage> suppliers = new ArrayList<>();

        BaseActivity base = getBaseActivity();
        if (base.getCachedMVNOData() != null) {
            suppliers = new VoucherUtility(getBaseActivity()).getC4cSuppliers();
        }
        return suppliers;
    }

    private void removeMVMOFromAllAirtime(Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> mappedResponse) {
        VoucherListResponseManufacturerMessage manufacturerMessage = null;
        if (mappedResponse != null)
            for (VoucherListResponseManufacturerMessage voucherListResponseManufacturerMessage : mappedResponse.keySet()) {
                if (voucherListResponseManufacturerMessage.getName().equalsIgnoreCase("MVNO")) {
                    manufacturerMessage = voucherListResponseManufacturerMessage;
                }
            }
        if (manufacturerMessage != null) {
            mappedResponse.remove(manufacturerMessage);
        }
    }

    private void addChatForChange() {
        createC4cMenuCards(retrieveC4cSuppliers());
    }

    private ArrayList<CardviewDataObject> createC4cMenuCards(List<Chat4ChangeResponseSupplierMessage> suppliers) {
        if (suppliers != null) {
            for (Chat4ChangeResponseSupplierMessage supplierMessage : suppliers) {

                String key = supplierMessage.getName();
                if (key.startsWith("x")) {
                    key = key.replace("x", "");
                }

                if (key.equals("Advinne")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.advinne, R.color.white, key, key));
                } else if (key.equals("TheUnlimited")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.theunlimited, R.color.white, key, key));
                } else if (key.equals("MyAir")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.myair, R.color.white, key, key));
                } else if (key.equals("FNBConnect")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.fnbconnect, R.color.fnbconnect, key, key));
                } else if (key.contains("Lyca")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.lycamobile, R.color.white, key, key));
                } else if (key.contains("Ringas")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ringas, R.color.white, key, key));
                } else if (key.equals("CallAll")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.callall, R.color.white, key, key));
                } else if (key.contains("BluVoucher")) {
                    //do not display BluVoucher menu card under MVNOs, as it is moved into Vouchers
                } else if (key.equalsIgnoreCase("Connect")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.connect_menu_card, R.color.white, key, key));
                } else {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), key, key));
                }

            }
        }
        return masterList;
    }

    private void addAirtime() {
        createCards(retrieveVoucherMap("Airtime"), "Airtime");
        createPinlessTopupCards();
    }

    private void createCards(Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> map, String type) {
        if (map != null) {
            for (VoucherListResponseManufacturerMessage mapKey : map.keySet()) {

                if (mapKey.getName().equals("Vodacom")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.vodacom, R.color.vodacom, type, mapKey.getName(), mapKey.getName()));
                } else if (mapKey.getName().equals("MTN")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.mtn, R.color.mtn, type, mapKey.getName(), mapKey.getName()));
                } else if (mapKey.getName().equals("Cell C")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.cellc, R.color.cellc, type, mapKey.getName(), mapKey.getName()));
                } else if (mapKey.getName().equals("Telkom Mobile")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.telkommobile, R.color.telkom, type, mapKey.getName(), mapKey.getName()));
                } else if (mapKey.getName().equals("Neotel")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.neotel, R.color.neotel_border, type, mapKey.getName(), mapKey.getName()));
                } else if (mapKey.getName().equals("Virgin Mobile")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.virgin, R.color.virgin, type, mapKey.getName(), mapKey.getName()));
                }
            }
        }
    }

    private void createPinlessTopupCards() {
        LinkedList<Provider> networkProviders = new VoucherUtility(getBaseActivity()).getProviders();

        if (networkProviders.size() > 0) {
            for (Provider p : networkProviders) {
                String providerName = p.getProviderName();

                if (providerName.equals("Vodacom")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.vodacom, R.color.vodacom, "Pinless Topup", providerName, providerName));
                } else if (providerName.equals("MTN")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.mtn, R.color.mtn, "Pinless Topup", providerName, providerName));
                } else if (providerName.equals("Cell C")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.cellc, R.color.cellc, "Pinless Topup", providerName, providerName));
                } else if (providerName.equals("Telkom Mobile")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.telkommobile, R.color.telkom, "Pinless Topup", providerName, providerName));
                } else if (providerName.equals("Neotel")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.neotel, R.color.neotel_border, "Pinless Topup", providerName, providerName));
                } else if (providerName.equals("Virgin Mobile")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.virgin, R.color.virgin, "Pinless Topup", providerName, providerName));
                }
            }
        }
    }

    private void addData() {
        createCards(retrieveVoucherMap("Data"), "Data");
        createBundledPinlessTopupCards(retrieveBundleMap());
    }

    private void createBundledPinlessTopupCards(Map<Provider, ArrayList<BundlesResponseProductMessage>> map) {
        if (map != null) {
            for (Provider mapKey : map.keySet()) {

                if (mapKey.getProviderName().equals("Vodacom")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.vodacom, R.color.vodacom, "Pinless Bundle", mapKey.getProviderName(), mapKey.getProviderName()));
                } else if (mapKey.getProviderName().equals("MTN")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.mtn, R.color.mtn, "Pinless Bundle", mapKey.getProviderName(), mapKey.getProviderName()));
                } else if (mapKey.getProviderName().equals("Cell C")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.cellc, R.color.cellc, "Pinless Bundle", mapKey.getProviderName(), mapKey.getProviderName()));
                } else if (mapKey.getProviderName().equals("Telkom Mobile")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.telkommobile, R.color.telkom, "Pinless Bundle", mapKey.getProviderName(), mapKey.getProviderName()));
                } else if (mapKey.getProviderName().equals("Neotel")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.neotel, R.color.neotel_border, "Pinless Bundle", mapKey.getProviderName(), mapKey.getProviderName()));
                } else if (mapKey.getProviderName().equals("Virgin Mobile")) {
                    masterList.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.virgin, R.color.virgin, "Pinless Bundle", mapKey.getProviderName(), mapKey.getProviderName()));
                }
            }
        }
    }

    private Map<Provider, ArrayList<BundlesResponseProductMessage>> retrieveBundleMap() {
        Map<Provider, ArrayList<BundlesResponseProductMessage>> mappedResponse = null;
        if (BaseActivity.bundlesResponseGetProductListMessages != null) {
            mappedResponse = new VoucherUtility(getBaseActivity()).getBundles();
        }
        return mappedResponse;
    }

}