package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatSpinner;
import androidx.core.view.ViewCompat;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidSpinner extends AppCompatSpinner implements OnTouchListener, AdapterView.OnItemSelectedListener {
    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference = null;


    private void setTextColor() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();

            if (baseScreen != null) {
                ColorStateList colorStateList = new ColorStateList(
                        new int[][]{
                                new int[]{android.R.attr.state_checked},
                                new int[]{-android.R.attr.state_checked},
                        },
                        new int[]{
                                baseScreen.getSkinResources().getButtonColor(),
                                baseScreen.getSkinResources().getBackgroundTextColor()
                        }
                );

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    setBackgroundTintList(colorStateList);
                } else {
                    ViewCompat.setBackgroundTintList(this, colorStateList);
                }

                TextView tv = this.findViewById((android.R.id.title));
                tv.setTextColor(baseScreen.getSkinResources().getButtonColor());
            }
        }
    }

    private void setup() {
        setTextColor();
        //setOnItemClickListener(this);
        setOnTouchListener(this);

        setFocusableInTouchMode(true);
    }

    public BluDroidSpinner(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setup();
    }

    //
// http://stackoverflow.com/questions/10254748/how-to-extend-an-android-button-and-use-an-xml-layout-file
//
    public BluDroidSpinner(Context context, AttributeSet attrs) {
        super(context, attrs);
        boolean needTextColor = true;
        for (int i = 0; i < attrs.getAttributeCount(); i++) {
            if (attrs.getAttributeName(i).equals("textColor")) {
                needTextColor = false;
            }
        }
        //setOnItemClickListener(this);
        if (context instanceof BaseActivity) {
            try {
                this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
                setup();
                if (needTextColor) {
                    setTextColor();
                }
            } catch (Exception exception) {
                Log.d(TAG, "BluDroidRadioButton exception " + exception);
            }
        }
    }

    public boolean onTouch(View v, MotionEvent event) {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                baseScreen.resetTimer();
            }
        }
        requestFocus();
        return false;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Log.d(TAG, "onItemSelected");
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                BaseActivity.logger.info(": onItemSelected(): " + parent.getItemAtPosition(position));
                baseScreen.resetTimer();
            }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}

