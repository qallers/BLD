package za.co.blts.bltandroidgui3.confirmations.printPreview;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;

public class PrintJob {
    private ArrayList<CommonResponseLineMessage> lines;
    private boolean dynamicPrint;
    private boolean barcodes;

    public PrintJob(ArrayList<CommonResponseLineMessage> lines, boolean dynamicPrint, boolean barcodes) {
        this.lines = lines;
        this.dynamicPrint = dynamicPrint;
        this.barcodes = barcodes;
    }

    public ArrayList<CommonResponseLineMessage> getLines() {
        return lines;
    }

    public void setLines(ArrayList<CommonResponseLineMessage> lines) {
        this.lines = lines;
    }

    public boolean isDynamicPrint() {
        return dynamicPrint;
    }

    public void setDynamicPrint(boolean dynamicPrint) {
        this.dynamicPrint = dynamicPrint;
    }

    public boolean isBarcodes() {
        return barcodes;
    }

    public void setBarcodes(boolean barcodes) {
        this.barcodes = barcodes;
    }
}
