package za.co.blts.bltandroidgui3.widgets;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

public class BluDroidTextWatcher implements TextWatcher {

    private ScreenFlow screenFlow;
    private EditText editText;
    private int waitingFor;

    public BluDroidTextWatcher(ScreenFlow screenFlow, EditText editText, int waitingFor) {
        super();
        this.screenFlow = screenFlow;
        this.editText = editText;
        this.waitingFor = waitingFor;
    }

    public void afterTextChanged(Editable s) {
    }

    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (editText.getText().toString().length() >= waitingFor) {
            screenFlow.gotMaxChars(editText);
        }
    }

}
