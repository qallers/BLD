package za.co.blts.bltandroidgui3;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.Log;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.nexgo.oaf.apiv3.device.printer.AlignEnum;
import com.nexgo.oaf.apiv3.device.printer.DotMatrixFontEnum;
import com.nexgo.oaf.apiv3.device.printer.FontEntity;
import com.nexgo.oaf.apiv3.device.printer.OnPrintListener;
import com.nexgo.oaf.apiv3.device.printer.Printer;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blts.bltandroidgui3.dynamic.DynamicPrintUtil;

import static com.nexgo.oaf.apiv3.APIProxy.getDeviceEngine;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PAPER_CUTTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

public class NexgoN3SmartPrinter implements SmartPrinter {

    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference;

    private boolean paperCutter = false;
    private Printer printer;

    private int printLength;

    public NexgoN3SmartPrinter() {
    }

    //----------------------------------------------------------------------------------------------
    public void initialise(BaseActivity baseScreen) {
        try {
            this.baseActivityWeakReference = new WeakReference<>(baseScreen);
            Log.d(TAG, ": initialise() with BaseActivity");
            paperCutter = baseScreen.getPreference(PREF_PAPER_CUTTER).equals(PREF_TRUE);
            Log.d(TAG, "paperCutter " + paperCutter);
            if (baseScreen.deviceEngine == null)
                baseScreen.deviceEngine = getDeviceEngine();
            printer = baseScreen.deviceEngine.getPrinter();
            printer.initPrinter();
            printLength = 0;
        } catch (Exception exception) {
            Log.e(TAG, "problem initializing Nexgo N3 " + exception);
            BaseActivity.logger.error("problem initializing Nexgo N3" + exception);

        }
    }

    public void terminate() {
    }

    @Override
    public void print(ArrayList<CommonResponseLineMessage> lines, boolean feed) {
        Log.d("KUIJKEN", "here");
        printLength += lines.size();
        try {
            final BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                Log.d(TAG, ": print()");
//                printer.initPrinter();
                printer.setTypeface(Typeface.MONOSPACE);
                printer.setLetterSpacing(5);
                String barcodeNumber;
                int barcodeWidth = BaseActivity.printWidth * 12;

                baseScreen.choosePrintLogo();

                printer.appendImage(baseScreen.bluLogo, AlignEnum.CENTER);

                FontEntity stdFont = new FontEntity(DotMatrixFontEnum.ASC_SONG_12X24);
                FontEntity boldFont = new FontEntity(DotMatrixFontEnum.ASC_SONG_BOLD_12X24);

                if (lines.size() > 0) {
                    for (CommonResponseLineMessage line : lines) {

                        switch (line.getF()) {
                            // center
                            case "H":
                                if (line.getText() != null) {
                                    line.setText(baseScreen.center(line.getText()));
                                    printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.LEFT);
                                }
                                break;

                            // left align (should be default)
                            case "O":
                                if (line.getText() != null)
                                    printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.LEFT);

                                break;

                            //print horizontal line
                            case "N":
                                if (line.getText() != null && !line.getText().isEmpty()) {
                                    printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.LEFT);
                                }
                                printer.appendPrnStr(BaseActivity.HORIZONTAL_LINE, stdFont, AlignEnum.LEFT);
                                break;

                            // need to generate EAN 13 barcode
                            case "P":
                                barcodeNumber = line.getText();
                                printer.appendImage(baseScreen.generateBarcode("ean13", barcodeNumber, barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13), AlignEnum.CENTER);
                                printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.CENTER);
                                break;

                            // need to generate Code 39 barcode
                            case "Q":
                                barcodeNumber = line.getText();
                                printer.appendImage(baseScreen.generateBarcode("code39", barcodeNumber, barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13), AlignEnum.CENTER);
                                printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.CENTER);
                                break;

                            // need to generate ITF barcode for Lotto
                            case "U":
                                BaseActivity.isLotto = true;
                                String specialChar = ";";
                                String barcodeText = line.getText();
                                String printableBarcode = barcodeText.substring(0, barcodeText.indexOf(specialChar));
                                printer.appendImage(baseScreen.generateBarcode("itf", printableBarcode, barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13), AlignEnum.CENTER);
                                printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.CENTER);
                                break;

                            // need to generate code128 barcode
                            case "X":
                                barcodeNumber = line.getText();
                                printer.appendImage(baseScreen.generateBarcode("code128", barcodeNumber, barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13), AlignEnum.CENTER);
                                printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.CENTER);
                                break;

                            //normal
                            case "A":
                            case "G":
                            case "K":
                            case "M":
                                if (line.getText() != null) {
                                    printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.LEFT);
                                }
                                break;

                            //center bold
                            case "E":
                                if (line.getText() != null) {
                                    boolean pin = new BluDroidUtils().isPinFormat(line.getText());
                                    if (pin) {
                                        line.setText(line.getText().replaceAll("\\s{2,}", " "));
                                    }
                                    ArrayList<String> wrappedLines = BluDroidUtils.wordWrap(line.getText(), pin ? 16 : 32);
                                    for (String s : wrappedLines) {
                                        printText(s, AlignEnum.CENTER, pin ? large : normal, true);
                                    }
                                }
                                break;

                            //bold
                            case "B":
                            case "C":
                            case "D":
                                if (line.getText() != null) {
                                    line.setText(baseScreen.center(line.getText()));
                                    printer.appendPrnStr(line.getText().replaceAll("\n", ""), boldFont, AlignEnum.LEFT);
                                }
                                break;

                            case "F":
                            case "L":
                            default:
                                break;
                        }

                    }
                }
                if (feed) {
                    executePrint(true);
                }
            }
        } catch (NumberFormatException exception) {
            BaseActivity.logger.error("NumberFormatException " + exception);
        } catch (Exception exception) {
            BaseActivity.logger.error("exception " + exception);
        }

    }

    @Override
    public void print(List<String> lines) {
        Log.d(TAG, ": print()");
        print(null, lines, null, "");
        BaseActivity.logger.info(": done printing");
    }

    @Override
    public void print(Bitmap logo, List<String> lines, Bitmap barcode, String barcodeNumber) {
        printLength += lines.size();
        try {
            Log.d(TAG, ": print()");
//            printer.initPrinter();
            printer.setTypeface(Typeface.MONOSPACE);
            printer.setLetterSpacing(5);
            if (logo != null) {
                printer.appendImage(logo, AlignEnum.CENTER);
            }
            int FONT_SIZE_NORMAL = 18;
            for (int i = 0; i < lines.size(); i++) {
                printer.appendPrnStr(lines.get(i).replaceAll("\n", ""), FONT_SIZE_NORMAL, AlignEnum.LEFT, false);
            }
            if (barcode != null) {
                printer.appendImage(barcode, AlignEnum.CENTER);
            }
            if (barcodeNumber != null && barcodeNumber.length() > 0) {
                printer.appendPrnStr(barcodeNumber, FONT_SIZE_NORMAL, AlignEnum.CENTER, false);
            }
            executePrint(true);
        } catch (NumberFormatException exception) {
            Log.d(TAG, "NumberFormatException " + exception);
        } catch (Exception exception) {
            Log.d(TAG, "exception " + exception);
        }
    }

    @Override
    public void print(Bitmap logo, List<CommonResponseLineMessage> lines, Bitmap barcode, boolean feed) {
        printLength += lines.size();
        try {
            final BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {

                Log.d(TAG, ": print()");
//                printer.initPrinter();
                printer.setTypeface(Typeface.MONOSPACE);
                printer.setLetterSpacing(5);
                printer.appendImage(logo, AlignEnum.CENTER);

                FontEntity boldFont = new FontEntity(DotMatrixFontEnum.ASC_SONG_BOLD_12X24);
                FontEntity stdFont = new FontEntity(DotMatrixFontEnum.ASC_MYuen_12X24);

                if (lines.size() > 0) {
                    for (CommonResponseLineMessage line : lines) {

                        switch (line.getF()) {
                            // center
                            case "H":
                                if (line.getText() != null) {
                                    line.setText(baseScreen.center(line.getText()));
                                    printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.LEFT);
                                }
                                break;

                            case "A":
                                // left align (should be default)
                            case "O":
                                if (line.getText() != null) {
                                    printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.LEFT);
                                }
                                break;

                            //print horizontal line
                            case "N":
                                if (line.getText() != null && !line.getText().isEmpty()) {
                                    printer.appendPrnStr(line.getText().replaceAll("\n", ""), stdFont, AlignEnum.LEFT);
                                }
                                printer.appendPrnStr(BaseActivity.HORIZONTAL_LINE, stdFont, AlignEnum.LEFT);
                                break;

                            // center bold
                            case "E":
                                if (line.getText() != null) {
                                    boolean pin = new BluDroidUtils().isPinFormat(line.getText());
                                    if (pin) {
                                        line.setText(line.getText().replaceAll("\\s{2,}", " "));
                                    }
                                    ArrayList<String> wrappedLines = BluDroidUtils.wordWrap(line.getText(), pin ? 16 : 32);
                                    for (String s : wrappedLines) {
                                        printText(s, AlignEnum.CENTER, pin ? large : normal, true);
                                    }
                                }
                                break;

                            case "L":
                            default:
                                break;
                        }

                    }
                }

                printer.appendImage(barcode, AlignEnum.CENTER);
                printer.appendPrnStr("\n", stdFont, AlignEnum.CENTER);

                if (feed) {
                    executePrint(true);
                }
            }
        } catch (NumberFormatException exception) {
            Log.d(TAG, "NumberFormatException " + exception);
        } catch (Exception exception) {
            Log.d(TAG, "exception " + exception);
        }

    }

    public Bitmap convertBitMatrixToBitMap(BitMatrix bitMatrix) {
        try {
            Log.d(TAG, ": convertBitMatrixToBitMap()");
            Bitmap bitmap = Bitmap.createBitmap(bitMatrix.getWidth(), bitMatrix.getHeight(), Bitmap.Config.ARGB_8888);

            for (int k = 0; k < bitMatrix.getWidth(); k++) {
                for (int j = 0; j < bitMatrix.getHeight(); j++) {
                    try {
                        bitmap.setPixel(k, j, bitMatrix.get(k, j) ? Color.BLACK : Color.WHITE);
                    } catch (Exception exception) {
                        Log.v(TAG, "problems " + exception);
                    }
                }
            }
            Log.d(TAG, ": done convert bit matrix to bitmap()");
            return bitmap;

        } catch (Exception exception) {
            BaseActivity.logger.error("problem generating bitmap " + exception);
        }
        return null;
    }

    //----------------------------------------------------------------------------------------------
    public int getBitmapMaxWidth() {
        return 1000;
    }
    //----------------------------------------------------------------------------------------------

    public void print(JSONArray printJob) {
        try {
//            printer.initPrinter();
            printer.setTypeface(Typeface.MONOSPACE);
            printer.setLetterSpacing(5);

            for (int i = 0; i < printJob.length(); i++) {
                JSONObject obj = printJob.getJSONObject(i);
                switch (obj.getString("type").toLowerCase()) {
                    case "text":
                        printText(obj);
                        break;
                    case "line":
                        printLine();
                        break;
                    case "barcode":
                        printBarcode(obj);
                        break;
                    case "image":
                        printImage(obj);
                        break;
                }
            }
            printLength += printJob.length();
            executePrint(true);
        } catch (Exception e) {
            e.printStackTrace();
            BaseActivity.logger.error("print exception" + e);
        }
    }

    private void printText(JSONObject obj) throws Exception {
        boolean bold;
        AlignEnum align;
        FontEntity[] size;

        try {
            bold = obj.getString("style").equals("bold");
        } catch (Exception ignore) {
            bold = false;
        }

        try {
            switch (obj.getString("align").toLowerCase()) {
                case "center":
                    align = AlignEnum.CENTER;
                    break;
                case "right":
                    align = AlignEnum.RIGHT;
                    break;
                default:
                    align = AlignEnum.LEFT;
                    break;
            }
        } catch (Exception ignore) {
            align = AlignEnum.LEFT;
        }

        try {
            if ("large".equals(obj.getString("size").toLowerCase())) {
                size = large;
            } else {
                size = normal;
            }
        } catch (Exception ignore) {
            size = normal;
        }
        printText(obj.getString("value"), align, size, bold);
    }

    private FontEntity[] normal = new FontEntity[]{new FontEntity(DotMatrixFontEnum.ASC_SONG_12X24), new FontEntity(DotMatrixFontEnum.ASC_SONG_BOLD_12X24)};//32char/line
    private FontEntity[] large = new FontEntity[]{new FontEntity(DotMatrixFontEnum.ASC_SONG_24X48), new FontEntity(DotMatrixFontEnum.ASC_SONG_BOLD_24X48)};//16char/line

    private void printText(String text, AlignEnum align, FontEntity[] size, boolean bold) throws Exception {
        int fontIdx = bold ? 1 : 0;
        printer.appendPrnStr(text, size[fontIdx], align);
    }

    private void printLine() throws Exception {
        char[] array = new char[32];
        Arrays.fill(array, '=');
        printText(new String(array), AlignEnum.LEFT, normal, false);
    }

    private void printBarcode(JSONObject obj) throws Exception {
        BarcodeFormat barcodeFormat;
        int height = 100;
        String format = obj.getString("format").toLowerCase();
        switch (format) {
            case "ean13":
                barcodeFormat = BarcodeFormat.EAN_13;
                break;
            case "code39":
                barcodeFormat = BarcodeFormat.CODE_39;
                break;
            case "itf":
                barcodeFormat = BarcodeFormat.ITF;
                break;
            case "code128":
                barcodeFormat = BarcodeFormat.CODE_128;
                break;
            case "pdf417":
                barcodeFormat = BarcodeFormat.PDF_417;
                height = 200;
                break;
            default:
                return;
        }
        String barcode = obj.getString("value");
        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
//            BitMatrix bitMatrix = multiFormatWriter.encode(barcode, barcodeFormat, 384, height, null);
        BitMatrix bitMatrix = multiFormatWriter.encode(barcode, barcodeFormat, 411, height, null);

        Bitmap bitmap = convertBitMatrixToBitMap(bitMatrix);
        printer.appendImage(bitmap, AlignEnum.CENTER);
        //            printText("\n", ALIGN_LEFT, FONT_NORMAL, false);
        printText(barcode, AlignEnum.CENTER, normal, false);
    }

    private void printImage(JSONObject obj) throws Exception {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
//            Bitmap logo = new PrintImageUtil(baseActivity).getLogo(obj.getString("id"), obj.getString("url"));
            Bitmap logo = new DynamicPrintUtil(baseActivity).getLogoForPrint(obj.getString("id"));

            if (logo != null) {
                AlignEnum align;
                try {
                    switch (obj.getString("align").toLowerCase()) {
                        case "center":
                            align = AlignEnum.CENTER;
                            break;
                        case "right":
                            align = AlignEnum.RIGHT;
                            break;
                        default:
                            align = AlignEnum.LEFT;
                            break;
                    }
                } catch (Exception ignore) {
                    align = AlignEnum.LEFT;
                }

                printer.appendImage(logo, align);
//                printText("\n", AlignEnum.LEFT, normal, false);
            }
        }
    }

    private void executePrint(boolean delay) {
//        boolean feedPaper = true;
        final BaseActivity baseScreen = baseActivityWeakReference.get();
//        if (baseScreen != null && baseScreen.getPreference(PREF_PAPER_CUTTER).equals(PREF_TRUE)) {
//            feedPaper = false;
//            printer.cutPaper();
//        }

        printer.startPrint(true, new OnPrintListener() {
            @Override
            public void onPrintResult(final int retCode) {
                if (retCode == 0) {
                    BaseActivity.isVoucherPrinted = true;
                    Log.d(TAG, "print finished" + retCode);
                } else {
                    BaseActivity.isVoucherPrinted = false;
                    Log.e(TAG, "print failed" + retCode);
                    if (baseScreen != null) {
                        baseScreen.createPrintErrorConfirmation();
                    }
                }
            }
        });
        if (delay) {
            try {
                int millis;
                if (printLength > 60) {
                    millis = 15000;
                } else if (printLength > 32) {
                    millis = 10000;
                } else {
                    millis = 5000;
                }
                Thread.sleep(millis);
                Log.d(TAG, "printed");
            } catch (Exception ignore) {
            }
        } else {
            //todo - this is a risk, as the delay is needed to ensure the onPrintResult has time to fire
            //however, with the react native integration, the delay causes the screen to go black while
            //the thread sleeps, which is unacceptable
            BaseActivity.isVoucherPrinted = true;
        }
        BaseActivity.logger.info(": done printing");
        printLength = 0;
    }


    public void printJsonDefaultLogo(JSONArray printJob, boolean feed) {
        final BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            try {
                Log.d(TAG, ": print()");
                printer.setTypeface(Typeface.MONOSPACE);
                printer.setLetterSpacing(5);

                baseScreen.choosePrintLogo();
                printer.appendImage(baseScreen.bluLogo, AlignEnum.CENTER);

                for (int i = 0; i < printJob.length(); i++) {
                    JSONObject obj = printJob.getJSONObject(i);
                    switch (obj.getString("type").toLowerCase()) {
                        case "text":
                            printText(obj);
                            break;
                        case "line":
                            printLine();
                            break;
                        case "barcode":
                            printBarcode(obj);
                            break;
                        case "image":
                            printImage(obj);
                            break;
                    }
                }
                printLength += printJob.length();

                if (feed) {
                    executePrint(false);
                }
            } catch (Exception e) {
                e.printStackTrace();
                BaseActivity.logger.error("print exception" + e);
            }
        }
    }

}
