package za.co.blts.bltandroidgui3.cardviews;

import java.io.Serializable;
import java.util.Comparator;

/**
 * Created by warrenm on 2016/06/28.
 */
public class CardviewDataObject implements Serializable {

    private int iconId;
    private int cardColor;
    private String cardDesc;
    private String cardValue;
    private String tag;
    private String stockId;
    private String voucherType;
    private String defaultCard = "";
    private String voucherTypeDesc;
    private String provider;
    private boolean hasAirtimePlus;
    private boolean isMVNO;
    private String supplierCode;

    public CardviewDataObject(String cardDesc, String cardValue, int iconId, int cardColor, String stockId, String voucherType, String tag) {
        this.iconId = iconId;
        this.cardDesc = cardDesc;
        this.cardValue = cardValue;
        this.cardColor = cardColor;
        this.stockId = stockId;
        this.voucherType = voucherType;
        this.tag = tag;
    }

    CardviewDataObject(String cardDesc, String cardValue, int iconId, int cardColor, String stockId, String voucherType, String tag, String voucherTypeDesc) {
        this.iconId = iconId;
        this.cardDesc = cardDesc;
        this.cardValue = cardValue;
        this.cardColor = cardColor;
        this.stockId = stockId;
        this.voucherType = voucherType;
        this.tag = tag;
        this.voucherTypeDesc = voucherTypeDesc;
    }

    CardviewDataObject(String cardDesc, String cardValue, int iconId, int cardColor, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean isMVNO, String supplierCode) {
        this.iconId = iconId;
        this.cardDesc = cardDesc;
        this.cardValue = cardValue;
        this.cardColor = cardColor;
        this.stockId = stockId;
        this.voucherType = voucherType;
        this.tag = tag;
        this.voucherTypeDesc = voucherTypeDesc;
        this.isMVNO = isMVNO;
        this.supplierCode = supplierCode;
    }

    CardviewDataObject(String cardDesc, String cardValue, int iconId, int cardColor, String stockId, String voucherType, String tag, String voucherTypeDesc, String provider) {
        this.iconId = iconId;
        this.cardDesc = cardDesc;
        this.cardValue = cardValue;
        this.cardColor = cardColor;
        this.stockId = stockId;
        this.voucherType = voucherType;
        this.tag = tag;
        this.voucherTypeDesc = voucherTypeDesc;
        this.provider = provider;
    }

    CardviewDataObject(String cardDesc, int cardColor, String tag) {
        this.cardDesc = cardDesc;
        this.cardColor = cardColor;
        this.tag = tag;
    }

    CardviewDataObject(String cardDesc, int iconId, int cardColor, String tag) {
        this.cardDesc = cardDesc;
        this.iconId = iconId;
        this.cardColor = cardColor;
        this.tag = tag;
    }

    CardviewDataObject(String cardDesc, int iconId, int cardColor, String tag, String voucherTypeDesc) {
        this.cardDesc = cardDesc;
        this.iconId = iconId;
        this.cardColor = cardColor;
        this.tag = tag;
        this.voucherTypeDesc = voucherTypeDesc;
    }

    public int getIconId() {
        return iconId;
    }

    public int getCardColor() {
        //Log.d(TAG, "getCardColor returning " + cardColor);
        return cardColor;
    }

    public String getCardDesc() {
        return cardDesc;
    }

    public String getCardValue() {
        return cardValue;
    }

    public String getTag() {
        return tag;
    }

    public String getStockId() {
        return stockId;
    }

    public String getSupplierCode() {
        return supplierCode;
    }

    public String getBundlesName() {
        return "";
    }

    public String getTopupName() {
        return "";
    }

    public String getVoucherType() {
        return voucherType;
    }

    public String getVoucherTypeDesc() {
        return voucherTypeDesc;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public boolean getHasAirtimePlus() {
        return hasAirtimePlus;
    }

    void setHasAirtimePlus(boolean hasAirtimePlus) {
        this.hasAirtimePlus = hasAirtimePlus;
    }

    public String getDefaultCard() {
        return defaultCard;
    }

    void setDefaultCard(String defaultCard) {
        this.defaultCard = defaultCard;
    }

    public boolean isMVNO() {
        return isMVNO;
    }

    void setMVNO(boolean MVNO) {
        isMVNO = MVNO;
    }

    void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }

    public boolean isHasAirtimePlus() {
        return hasAirtimePlus;
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + "{" +
                "hasAirtimePlus=" + hasAirtimePlus +
                ", iconId=" + iconId +
                ", cardColor=" + cardColor +
                ", cardDesc='" + cardDesc + '\'' +
                ", cardValue='" + cardValue + '\'' +
                ", tag='" + tag + '\'' +
                ", stockId='" + stockId + '\'' +
                ", voucherType='" + voucherType + '\'' +
                ", defaultCard='" + defaultCard + '\'' +
                ", voucherTypeDesc='" + voucherTypeDesc + '\'' +
                ", provider='" + provider + '\'' +
                ", isMVNO=" + isMVNO +
                ", supplierCode='" + supplierCode + '\'' +
                '}';
    }

    public int compareTo(CardviewDataObject card) {
        return this.getCardDesc().toLowerCase().compareTo(card.getCardDesc().toLowerCase());
    }

    public int compareTagTo(CardviewDataObject card) {
        return this.getTag().toLowerCase().compareTo(card.getTag().toLowerCase());
    }

    public static Comparator<CardviewDataObject> cardDescComparator = new Comparator<CardviewDataObject>() {
        public int compare(CardviewDataObject card1, CardviewDataObject card2) {
            return card1.compareTo(card2);
        }
    };

    public static Comparator<CardviewDataObject> tagComparator = new Comparator<CardviewDataObject>() {
        public int compare(CardviewDataObject card1, CardviewDataObject card2) {
            return card1.compareTagTo(card2);
        }
    };

}
