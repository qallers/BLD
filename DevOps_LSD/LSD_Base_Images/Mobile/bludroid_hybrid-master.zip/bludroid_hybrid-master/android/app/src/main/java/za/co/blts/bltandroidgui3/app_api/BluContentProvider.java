package za.co.blts.bltandroidgui3.app_api;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_UNKNOWN;

public class BluContentProvider extends ContentProvider {
    private final String TAG = this.getClass().getSimpleName();

    static final String PROVIDER_NAME = "za.co.blts.bltandroidgui3.app_api.BluContentProvider";
    static final int DEVICE = 1;
    static final UriMatcher uriMatcher;

    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(PROVIDER_NAME, "device", DEVICE);
    }

    @Override
    public boolean onCreate() {
        return false;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] strings, @Nullable String s, @Nullable String[] strings1, @Nullable String s1) {
        switch (uriMatcher.match(uri)) {
            case DEVICE:
                Log.d(TAG, "DEVICE");
                return getDeviceDetails();
        }
        return null;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }

    private Cursor getDeviceDetails() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getContext());
        String deviceId = prefs.getString(PREF_DEVICE_ID, PREF_UNKNOWN);
        String serial = prefs.getString(PREF_DEVICE_SER, PREF_UNKNOWN);
        MatrixCursor mc = new MatrixCursor(new String[]{"DeviceId", "Serial"});
        mc.addRow(new String[]{deviceId, serial});
        return mc;
    }
}
