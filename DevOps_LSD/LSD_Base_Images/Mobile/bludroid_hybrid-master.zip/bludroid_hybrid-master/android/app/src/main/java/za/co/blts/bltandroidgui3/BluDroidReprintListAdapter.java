package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 4/5/2017.
 */

class BluDroidReprintListAdapter extends ArrayAdapter<Reprint> implements View.OnClickListener {


    private Filter filter;
    private ArrayList<Reprint> dataSet;

    private WeakReference<BaseActivity> baseActivityWeakReference;
    private int layoutResourceId;

    public BluDroidReprintListAdapter(BaseActivity context, int layoutResourceId, ArrayList<Reprint> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.layoutResourceId = layoutResourceId;
        this.dataSet = dataSet;
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    @Override
    public void onClick(View v) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            BaseActivity.logger.info(((BluDroidButton) v).getText());
            try {
                List<String> tags = (List<String>) v.getTag();
                String id = tags.get(0);
                BaseActivity.supplierName = tags.get(1);
                Log.d("print logo", "supplierName > " + tags.get(1));
                baseActivity.reprint(id);
            } catch (Exception ignore){
                //Unchecked cast or IndexOutOfBounds should never happen
            }
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Reprint reprint = getItem(position);

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(layoutResourceId, parent, false);
        }

        BluDroidButton btnPrint = convertView.findViewById(R.id.print);
        btnPrint.setOnClickListener(this);

        String voucherName = reprint.getRef();
        String date = reprint.getDate();
        String amount = reprint.getAmount();

        List<String> tags = new ArrayList<>();
        tags.add(reprint.getId());
        tags.add(reprint.getRef().replaceAll(" ", ""));
        btnPrint.setTag(tags);

        BluDroidTextView txtType = convertView.findViewById(R.id.voucherType);
        BluDroidTextView txtDate = convertView.findViewById(R.id.date);
        BluDroidTextView txtAmount = convertView.findViewById(R.id.amount);
        BluDroidTextView txtTransId = convertView.findViewById(R.id.transId);

        txtType.setText(voucherName);
        txtDate.setText(date);
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            String disp = baseActivity.getResources().getString(R.string.amount) + ":" + baseActivity.getResources().getString(R.string.currency) + "" + baseActivity.df2.format(Double.parseDouble(amount));
            txtAmount.setText(disp);
        }
        txtTransId.setText("");

        return convertView;
    }


    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new BluDroidReprintListAdapter.AppFilter<>(dataSet);
        }
        return filter;
    }

    private class AppFilter<T> extends Filter {

        private ArrayList<T> sourceObjects;

        AppFilter(ArrayList<T> objects) {
            sourceObjects = new ArrayList<>();
            synchronized (this) {
                sourceObjects.addAll(objects);
            }
        }

        @Override
        protected FilterResults performFiltering(CharSequence chars) {
            String filterSeq = chars.toString().toLowerCase();
            FilterResults result = new FilterResults();
            if (filterSeq.length() > 0) {
                ArrayList<T> filter = new ArrayList<>();

                for (T object : sourceObjects) {
                    // the filtering itself:
                    Reprint reprint = (Reprint) object;
                    if (reprint.getRef().toLowerCase().contains(filterSeq)) {
                        filter.add(object);
                    }
                }
                result.count = filter.size();
                result.values = filter;
            } else {
                // add all objects
                synchronized (this) {
                    result.values = sourceObjects;
                    result.count = sourceObjects.size();
                }
            }
            return result;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {
            // NOTE: this function is *always* called from the UI thread.
            ArrayList<T> filtered = (ArrayList<T>) results.values;
            notifyDataSetChanged();
            clear();
            for (int i = 0, l = filtered.size(); i < l; i++) {
                add((Reprint) filtered.get(i));
            }
            notifyDataSetInvalidated();
        }
    }
}

