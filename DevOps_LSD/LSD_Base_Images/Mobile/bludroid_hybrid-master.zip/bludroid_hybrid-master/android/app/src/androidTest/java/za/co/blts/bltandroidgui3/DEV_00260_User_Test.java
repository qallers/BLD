package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.widget.TextView;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASHIER_END_SHIFT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

/**
 * Created by Warren 2.0 on 24/05/2017.
 */
//These tests need to be reconsidered, since AEON will only allow 100 users to be created for a device.
//Users cannot be deleted (only flagged as deleted) since they might be linked to past transactions
//not sure if "deleted" users count toward the 100 limit or not?


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00260_User_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    private static String cashierPin;
    private static String cashierPlusPin;
    private static String cashierName;
    private static String cashierPlusName;

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_AddCashier() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoUsersScreen();
            Log.d(TAG, "Goto Users Screen");

            checks.clickButton(R.id.add);
            Log.d(TAG, "Add user button clicked");

            solo.waitForDialogToOpen();

            cashierName = "Cashier" + System.currentTimeMillis();
            checks.enterText(R.id.nameSetting, cashierName);
            Log.d(TAG, "User name entered.");

            checks.enterText(R.id.pinSetting, "2468");
            Log.d(TAG, "User pin entered.");

            checks.enterText(R.id.confirmPinSetting, "2468");
            Log.d(TAG, "Confirm user pin entered.");

            solo.clickOnRadioButton(0);
            Log.d(TAG, "Cashier radio button selected.");

            checks.clickButton(R.id.affirmativeButton);
            Log.d(TAG, "Add user button clicked");

            if (solo.waitForDialogToOpen()) {
                TextView dlgMsg = (TextView) solo.getView(android.R.id.message);
                String msg = dlgMsg.getText().toString();
                cashierPin = msg.substring(msg.indexOf("new pin is") + 11);
                Log.d(TAG, "new pin = " + cashierPin);

                solo.clickOnText("OK");
                Log.d(TAG, "Cashier added, clicked 'OK'");
            } else {
                fail("Could not add as a cashier");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_AddSupervisor() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoUsersScreen();
            Log.d(TAG, "Goto Users Screen");

            checks.clickButton(R.id.add);
            Log.d(TAG, "Add user button clicked");

            solo.waitForDialogToOpen();

            String supervisorName = "Super" + System.currentTimeMillis();
            checks.enterText(R.id.nameSetting, supervisorName);
            Log.d(TAG, "User name entered.");

            checks.enterText(R.id.pinSetting, "1234");
            Log.d(TAG, "User pin entered.");

            checks.enterText(R.id.confirmPinSetting, "1234");
            Log.d(TAG, "Confirm user pin entered.");

            solo.clickOnRadioButton(2);
            Log.d(TAG, "Supervisor radio button selected.");

            checks.clickButton(R.id.affirmativeButton);
            Log.d(TAG, "Add user button clicked");

            if (solo.waitForDialogToOpen()) {
                TextView dlgMsg = (TextView) solo.getView(android.R.id.message);
                String msg = dlgMsg.getText().toString();
                String supervisorPin = msg.substring(msg.indexOf("new pin is") + 11);
                Log.d(TAG, "new pin = " + supervisorPin);

                solo.clickOnText("OK");
                Log.d(TAG, "Supervisor added, clicked 'OK'");
            } else {
                fail("Could not add as a Supervisor");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T020_AddCashierPlus() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoUsersScreen();
            Log.d(TAG, "Goto Users Screen");

            checks.clickButton(R.id.add);
            Log.d(TAG, "Add user button clicked");

            solo.waitForDialogToOpen();

            cashierPlusName = "Plus" + System.currentTimeMillis();
            checks.enterText(R.id.nameSetting, cashierPlusName);
            Log.d(TAG, "User name entered.");

            checks.enterText(R.id.pinSetting, "4443");
            Log.d(TAG, "User pin entered.");

            checks.enterText(R.id.confirmPinSetting, "4443");
            Log.d(TAG, "Confirm user pin entered.");

            solo.clickOnRadioButton(1);
            Log.d(TAG, "Cashier Plus radio button selected.");

            solo.scrollToBottom();

            solo.clickOnCheckBox(1);
            Log.d(TAG, "Transaction List selected");

            solo.clickOnCheckBox(2);
            Log.d(TAG, "End Shift selected");

            solo.clickOnCheckBox(3);
            Log.d(TAG, "Account Status selected");

            solo.clickOnCheckBox(8);
            Log.d(TAG, "Emergency Top Up Status selected");

            checks.clickButton(R.id.affirmativeButton);
            Log.d(TAG, "Add user button clicked");

            if (solo.waitForDialogToOpen()) {
                TextView dlgMsg = (TextView) solo.getView(android.R.id.message);
                String msg = dlgMsg.getText().toString();
                cashierPlusPin = msg.substring(msg.indexOf("new pin is") + 11);
                Log.d(TAG, "new pin = " + cashierPlusPin);

                solo.clickOnText("OK");
                Log.d(TAG, "Cashierplus added, clicked 'OK'");
            } else {
                fail("Could not add as a Cashierplues");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T030_EditCashier() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoUsersScreen();
            Log.d(TAG, "Goto Users Screen");

            solo.clickOnText("Cashier / " + cashierName);
            Log.d(TAG, "Cashier user selected");

            solo.waitForDialogToOpen();

            solo.clickOnRadioButton(1);
            Log.d(TAG, "Cashier Plus radio button selected.");

            solo.scrollDown();
            solo.clickOnCheckBox(0);
            solo.clickOnCheckBox(1);
            solo.clickOnCheckBox(2);
            Log.d(TAG, "Cashier Plus permissions selected.");

            checks.clickButton(R.id.affirmativeButton);
            Log.d(TAG, "Update user button clicked");

            if (solo.waitForDialogToOpen()) {
                solo.clickOnText("OK");
                Log.d(TAG, "Cashierplus updated, clicked 'OK'");
            } else {
                fail("Could not update a Cashierplus");
            }

            checks.clickOnToobarNavigationButton();
            checks.logout();
            Log.d(TAG, "Logout successful");

            if (checks.validLogin(cashierPin)) {
                Log.d(TAG, "Login as the newly edited cashier plus");
            } else {
                fail("Could not login as the newly edited cashier plus");
            }

            checks.clickOnActionMenu();

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.about))) {
                Log.d(TAG, "About menu is on screen");
            } else {
                fail("about menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.reports))) {
                Log.d(TAG, "Reports menu is on screen");
            } else {
                fail("Reports menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.end_shift))) {
                Log.d(TAG, "End SHift menu is on screen");
            } else {
                fail("End SHift menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.signOut))) {
                Log.d(TAG, "Sign Out menu is on screen");
            } else {
                fail("Sign Out  menu is not on screen");
            }

            solo.clickOnText(getBaseActivity().getResources().getString(R.string.reports));

            if (solo.searchText("Reprint")) {
                Log.d(TAG, "Reprint report menu is on screen");
            } else {
                fail("Reprint report  menu is not on screen");
            }

            if (solo.searchText("Transaction List")) {
                Log.d(TAG, "Transaction List report menu is on screen");
            } else {
                fail("Transaction List report menu is not on screen");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T040_EditCashierPin() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoUsersScreen();
            Log.d(TAG, "Goto Users Screen");

            if (solo.searchText(cashierName)) {
                Log.d(TAG, "Cashier found");
                solo.clickOnText(cashierName);
                Log.d(TAG, "Cashier user selected");
            } else {
                fail("Could not find cashier");
            }

            checks.enterText(R.id.pinSetting, "4444");
            Log.d(TAG, "User pin entered.");

            checks.enterText(R.id.confirmPinSetting, "4444");
            Log.d(TAG, "Confirm user pin entered.");

            checks.clickButton(R.id.affirmativeButton);
            Log.d(TAG, "Updated user button clicked");

            if (solo.waitForDialogToOpen()) {
                cashierPin = cashierPin.substring(0, 2) + "4444";
                solo.clickOnText("OK");
                Log.d(TAG, "Cashier pin updated, clicked 'OK'");
            } else {
                fail("Could not update a cashier pin");
            }

            checks.clickOnToobarNavigationButton();
            checks.logout();
            Log.d(TAG, "Logout successful");

            if (checks.validLogin(cashierPin)) {
                Log.d(TAG, "Login using new cashier pin");
            } else {
                fail("Could not login using new cashier pin");
            }

            checks.clickOnActionMenu();

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.about))) {
                Log.d(TAG, "About option menu exists");
            } else {
                fail("About option menu does not exist");
            }

            if (checks.checkPreference(PREF_CASHIER_END_SHIFT).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_CASHIER_END_SHIFT is true");

                if (solo.searchText(getBaseActivity().getResources().getString(R.string.end_shift))) {
                    Log.d(TAG, "End Shift option menu exists");
                } else {
                    fail("End Shift option menu does not exist");
                }

            } else {
                Log.d(TAG, "End Shift preference is false");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.signOut))) {
                Log.d(TAG, "Logout option menu exists");
            } else {
                fail("Logout option menu does not exists");
            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T050_EditCashierPlusPermissions() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoUsersScreen();
            Log.d(TAG, "Goto Users Screen");

            solo.clickOnText(cashierPlusName);
            Log.d(TAG, "CashierPlus user selected");

            solo.waitForDialogToOpen();

            solo.scrollToBottom();
            solo.clickOnCheckBox(1);
            Log.d(TAG, "Disabled Transaction List");
            solo.clickOnCheckBox(2);
            Log.d(TAG, "Disabled End Shift");
            Log.d(TAG, "Cashier Plus permissions changed.");

            checks.clickButton(R.id.affirmativeButton);
            Log.d(TAG, "Update user button clicked");

            if (solo.waitForDialogToOpen()) {
                solo.clickOnText("OK");
                Log.d(TAG, "Cashierplus permissions updated, clicked 'OK'");
            } else {
                fail("Could not update cashierplus permissions");
            }

            checks.clickOnToobarNavigationButton();
            checks.logout();
            Log.d(TAG, "Logout successful");

            if (checks.validLogin(cashierPlusPin)) {
                Log.d(TAG, "Login as a cashier plus");
            } else {
                fail("Could not login as a cashier plus");
            }

            checks.clickOnActionMenu();

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.reports))) {
                Log.d(TAG, "Reports menu is on screen");
            } else {
                fail("Reports menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.end_shift))) {
                fail("End Shift menu is on screen");
            } else {
                Log.d(TAG, "End Shift menu is not on screen");
            }

            solo.clickOnText(getBaseActivity().getResources().getString(R.string.reports));

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.reports_account_status))) {
                Log.d(TAG, "Account Status report menu is on screen");
            } else {
                fail("Account Status report menu is not on screen");
            }

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.reports_transaction_list))) {
                fail("Transaction List report menu is on screen");
            } else {
                Log.d(TAG, "Transaction List report menu is not on screen");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T060_EditCashierName() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoUsersScreen();
            Log.d(TAG, "Goto Users Screen");

            if (solo.searchText(cashierName)) {
                Log.d(TAG, "Cashier found");
                solo.clickOnText(cashierName);
                Log.d(TAG, "Cashier user selected");
            } else {
                fail("Could not find cashier");
            }

            cashierName = cashierName.replace("Cashier", "Update");
            checks.enterText(R.id.nameSetting, cashierName);
            Log.d(TAG, "Cashier user name updated.");

            checks.clickButton(R.id.affirmativeButton);
            Log.d(TAG, "Updated user button clicked");

            if (solo.waitForDialogToOpen()) {
                solo.clickOnText("OK");
                Log.d(TAG, "Cashier name updated, clicked 'OK'");
            } else {
                fail("Could not update cashier name");
            }

            checks.clickOnToobarNavigationButton();
            checks.logout();
            Log.d(TAG, "Logout successful");

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoUsersScreen();
            Log.d(TAG, "Goto Users Screen");

            if (solo.searchText(cashierName)) {
                Log.d(TAG, "Updated cashier found");
                solo.clickOnText(cashierName);
                Log.d(TAG, "Updated cashier selected");
            } else {
                fail("Could not find updated cashier");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T070_PrintUsers() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoUsersScreen();
            Log.d(TAG, "Goto Users Screen");

            solo.clickOnButton("Print Users");
            Log.d(TAG, "Printed users' list");

            solo.sleep(2000);

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

}
