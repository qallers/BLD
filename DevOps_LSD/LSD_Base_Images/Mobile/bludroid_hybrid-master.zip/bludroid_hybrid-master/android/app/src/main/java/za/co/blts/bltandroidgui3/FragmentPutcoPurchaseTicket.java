package za.co.blts.bltandroidgui3;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;


/**
 * A simple {@link Fragment} subclass.
 */


public class FragmentPutcoPurchaseTicket extends BaseFragment implements CompoundButton.OnCheckedChangeListener {
    private final String TAG = this.getClass().getSimpleName();

    public BluDroidEditText cellNumber;
    public BluDroidRelativeLayout layout;

    public FragmentPutcoPurchaseTicket() {
        // Required empty public constructor
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume");

        layout = getView().findViewById(R.id.layout);
        RelativeLayout routeDetailsLayout = getView().findViewById(R.id.routeDetails);
        routeDetailsLayout.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());
        cellNumber = getView().findViewById(R.id.cellPhone);

        TextView txtRouteCode = getView().findViewById(R.id.routeCode);
        txtRouteCode.setText(getBaseActivity().routeCode);
        TextView txtFrom = getView().findViewById(R.id.from);
        txtFrom.setText(getBaseActivity().departureName);
        TextView txtTo = getView().findViewById(R.id.to);
        txtTo.setText(getBaseActivity().destinationName);

        BluDroidTextView txtNumTrips = getView().findViewById(R.id.numtrips);
        txtNumTrips.setText(getBaseActivity().putcoTrip.getTravelClass());

        TextView txtNipType = getView().findViewById(R.id.type);
        if (getBaseActivity().putcoTrip.getNipType().equals("1")) {
            txtNipType.setText(getResources().getString(R.string.single_nip));
        } else {
            txtNipType.setText(getResources().getString(R.string.double_nip));
        }
        TextView txtPrice = getView().findViewById(R.id.price);
        String disp = getBaseActivity().getResources().getString(R.string.currency) + getBaseActivity().putcoTrip.getFare();
        txtPrice.setText(disp);

        BluDroidRadioButton radioCash = getView().findViewById(R.id.cashRadio);
        BluDroidRadioButton radioCredit = getView().findViewById(R.id.creditRadio);
        BluDroidRadioButton radioDebit = getView().findViewById(R.id.debitRadio);

        radioCash.setOnCheckedChangeListener(this);
        radioCredit.setOnCheckedChangeListener(this);
        radioDebit.setOnCheckedChangeListener(this);

        getBaseActivity().resetTimer();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d(TAG, "onViewCreated");
        //default selected radio Button is cash
        getBaseActivity().paymentType = "cash";
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_putco_purchase_ticket, container, false);
    }


    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            Log.i(TAG, "tender selected: " + buttonView.getText());
            if (buttonView.getId() == R.id.cashRadio) {
                getBaseActivity().paymentType = "cash";
            } else if (buttonView.getId() == R.id.creditRadio) {
                getBaseActivity().paymentType = "creditCard";
            } else if (buttonView.getId() == R.id.debitRadio) {
                getBaseActivity().paymentType = "debitCard";
            }
        }
    }
}
