package za.co.blts.bltandroidgui3;


import android.util.Log;
import android.view.View;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import java.util.Calendar;

import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SECURE_USB_PRINTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00210_Carma_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
        changePreference(PREF_SECURE_USB_PRINTER, PREF_TRUE);
    }

    @After
    public void after() {
        changePreference(PREF_SECURE_USB_PRINTER, PREF_FALSE);
        tearDown();
    }

    @Test
    public void T001_OneWayTrip() {
        try {
            //Return trip with parent and infant
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Search Routes");

            //click on Translux
            //gotoBusType(0);
            //Log.d(TAG, "Go to Translux");

            //solo.waitForDialogToClose();

            //OneWay Trip
            indicateWayOfTravel("OneWay");
            Log.d(TAG, "OneWay trip selected");

            selectDepart("CAPE", "CAPE TOWN");
            Log.d(TAG, "departure from Cape town");

            destination("DUR", "DURBAN");
            Log.d(TAG, "Destination Durban");

            //departure date picker
            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDate();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set departure date");

            solo.scrollDown();

            solo.clickOnView(solo.getView(R.id.add_adult_number));
            Log.d(TAG, "Adult added");

            searchBusTicket();

            //Departure ticket
            solo.clickOnView(solo.getView(R.id.parent_layout_id));
            Log.d(TAG, "Click on ticket");

            solo.clickOnView(solo.getView(R.id.next_search_results));
            Log.d(TAG, "Next");

            solo.sleep(500);

            //Parent details
            Title(4);
            Log.d(TAG, "Title entered");

            initial("RJ");
            Log.d(TAG, "Initials entered");

            Surname("Motsamai");
            Log.d(TAG, "Surname");

            Cellphone("0735780512");
            Log.d(TAG, "Cellphone entered");

            indicateDocumentation("ID");
            Log.d(TAG, "ID selected");

            View BottomF = solo.getView(R.id.fragment_passenger_details_id);
            BottomF.scrollBy(0, 360);

            ID("8903030290081");
            Log.d(TAG, "ID number entered");

            /*solo.clickOnCheckBox(0);
            Log.d(TAG, "Adding infant");*/

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            //Infant Details
           /* Title(0);
            Log.d(TAG, "Title entered");

            InfantInitial("GC");
            Log.d(TAG, "Initials entered");

            InfantSurname("Gaolebalwe");
            Log.d(TAG, "Last name entered");

            infantCalendar();
            Log.d(TAG, "Click on Infant Calendar");
            //select a specific date
            infantDob();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set infant date of birth");*/


            solo.clickOnButton("Confirm");
            Log.d(TAG, "Confirm");

            paymentType("credit card");
            Log.d(TAG, "paying using a credit card");

            Book();
            Log.d(TAG, "Booking a ticket");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    @Test
    public void T010_ReturnTrip() {
        try {
            //Return trip with parent and infant
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Search Routes");

            //click on Translux
            //gotoBusType(0);
            //Log.d(TAG, "Go to Translux");

            solo.waitForDialogToClose();


            //Return Trip
            indicateWayOfTravel("Return");
            Log.d(TAG, "Return trip");

            selectDepart("CAPE", "CAPE TOWN");
            Log.d(TAG, "departure from Cape town");

            destination("DUR", "DURBAN");
            Log.d(TAG, "Destination Durban");


            //departure date picker
            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDate();

            solo.clickOnText("Ok");
            Log.d(TAG, "Set departure date");

            ReturnCalendar();
            Log.d(TAG, "Click on Return Calendar");
            //select a specific date
            returnDate();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set return date");

            solo.scrollDown();

            solo.clickOnView(solo.getView(R.id.add_adult_number));
            Log.d(TAG, "Passenger added");

            searchBusTicket();

            //Departure ticket
            solo.clickOnView(solo.getView(R.id.parent_layout_id));
            Log.d(TAG, "Click on ticket");

            solo.clickOnView(solo.getView(R.id.next_search_results));
            Log.d(TAG, "Next");

            //Return ticket
            solo.clickOnView(solo.getView(R.id.parent_layout_id));
            Log.d(TAG, "Click on ticket");

            solo.clickOnView(solo.getView(R.id.next_search_results));
            Log.d(TAG, "Next");

            solo.sleep(500);

            //Customer details
            Title(4);
            Log.d(TAG, "Title entered");

            initial("RJ");
            Log.d(TAG, "Initials entered");

            Surname("Motsamai");
            Log.d(TAG, "Surname");

            Cellphone("0735780512");
            Log.d(TAG, "Cellphone entered");

            indicateDocumentation("ID");
            Log.d(TAG, "ID selected");

            View BottomF = solo.getView(R.id.fragment_passenger_details_id);
            BottomF.scrollBy(0, 360);

            ID("8903030290081");
            Log.d(TAG, "ID number entered");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Confirm");

            solo.waitForDialogToClose(30000);

            paymentType("credit card");
            Log.d(TAG, "paying using a credit card");

            Book();
            Log.d(TAG, "Booking a ticket");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    @Test
    public void T020_ChildAdded() {
        try {
            //Return trip with parent and infant
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            solo.waitForDialogToClose();


            //OneWay Trip
            indicateWayOfTravel("OneWay");
            Log.d(TAG, "OneWay trip selected");

            selectDepart("CAPE", "CAPE TOWN");
            Log.d(TAG, "departure from Cape town");

            destination("DUR", "DURBAN");
            Log.d(TAG, "Destination Durban");

            //departure date picker
            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDate();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set departure date");

            solo.scrollDown();

            solo.clickOnView(solo.getView(R.id.add_adult_number));
            solo.clickOnView(solo.getView(R.id.add_adult_number));
            Log.d(TAG, "2 Passengers added");

            searchBusTicket();

            //Departure ticket
            solo.clickOnView(solo.getView(R.id.parent_layout_id));
            Log.d(TAG, "Click on ticket");

            solo.clickOnView(solo.getView(R.id.next_search_results));
            Log.d(TAG, "Next");

            solo.sleep(500);

            //Parent details
            Title(4);
            Log.d(TAG, "Title entered");

            initial("RJ");
            Log.d(TAG, "Initials entered");

            Surname("Motsamai");
            Log.d(TAG, "Surname entered");

            Cellphone("0735780512");
            Log.d(TAG, "Cellphone number entered");

            indicateDocumentation("ID");
            Log.d(TAG, "ID selected");

            View BottomF = solo.getView(R.id.fragment_passenger_details_id);
            BottomF.scrollTo(0, 360);

            ID("8903030290081");
            Log.d(TAG, "ID number entered");


            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            Log.d(TAG, "moved to next passenger");

            //Child's Details
            passengerTypeSpinner(2);
            Log.d(TAG, "Child passenger type selected ");

            BottomF.scrollTo(0, 0);

            Title(0);
            Log.d(TAG, "Title entered");

            initial("GC");
            Log.d(TAG, "Initials entered");

            Surname("Motsamai");
            Log.d(TAG, "Last name entered");

            infantChildCalendar();
            Log.d(TAG, "Clicked on calender ");
            Calendar dob = Calendar.getInstance();
            dob.add(Calendar.YEAR, -10);

            infantChildDob(dob);
            solo.clickOnText("Ok");
            Log.d(TAG, "Set date of birth");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Confirm");

//            solo.clickOnButton("Next");
//            Log.d(TAG, "Next");
            solo.waitForDialogToClose(30000);

            paymentType("credit card");
            Log.d(TAG, "paying using a credit card");

            Book();
            Log.d(TAG, "Booking a ticket");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T030_InfantAdded() {
        try {
            //Return trip with parent and infant
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            solo.waitForDialogToClose();


            //OneWay Trip
            indicateWayOfTravel("OneWay");
            Log.d(TAG, "OneWay trip selected");

            selectDepart("CAPE", "CAPE TOWN");
            Log.d(TAG, "departure from Cape town");

            destination("DUR", "DURBAN");
            Log.d(TAG, "Destination Durban");

            //departure date picker
            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDate();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set departure date");

            solo.scrollDown();

            solo.clickOnView(solo.getView(R.id.add_adult_number));
            solo.clickOnView(solo.getView(R.id.add_adult_number));
            Log.d(TAG, "2 Passengers added");

            searchBusTicket();

            //Departure ticket
            solo.clickOnView(solo.getView(R.id.parent_layout_id));
            Log.d(TAG, "Click on ticket");

            solo.clickOnView(solo.getView(R.id.next_search_results));
            Log.d(TAG, "Next");

            solo.sleep(500);

            //Parent details
            Title(4);
            Log.d(TAG, "Title entered");

            initial("RJ");
            Log.d(TAG, "Initials entered");

            Surname("Motsamai");
            Log.d(TAG, "Surname entered");

            Cellphone("0735780512");
            Log.d(TAG, "Cellphone number entered");

            indicateDocumentation("ID");
            Log.d(TAG, "ID selected");

            View BottomF = solo.getView(R.id.fragment_passenger_details_id);
            BottomF.scrollTo(0, 360);

            ID("8903030290081");
            Log.d(TAG, "ID number entered");


            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            Log.d(TAG, "moved to next passenger");

            //Child's Details
            passengerTypeSpinner(3);
            Log.d(TAG, "Infant passenger type selected ");

            BottomF.scrollTo(0, 0);

            Title(0);
            Log.d(TAG, "Title entered");

            initial("GC");
            Log.d(TAG, "Initials entered");

            Surname("Motsamai");
            Log.d(TAG, "Last name entered");

            infantChildCalendar();
            Log.d(TAG, "Clicked on calender ");
            Calendar dob = Calendar.getInstance();
            dob.add(Calendar.DAY_OF_YEAR, -5);

            infantChildDob(dob);
            solo.clickOnText("Ok");
            Log.d(TAG, "Set date of birth");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Confirm");

            solo.waitForDialogToClose(30000);

            paymentType("credit card");
            Log.d(TAG, "paying using a credit card");

            Book();
            Log.d(TAG, "Booking a ticket");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T030_InfantOnLapAdded() {
        try {
            //Return trip with parent and infant
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            solo.waitForDialogToClose();


            //OneWay Trip
            indicateWayOfTravel("OneWay");
            Log.d(TAG, "OneWay trip selected");

            selectDepart("CAPE", "CAPE TOWN");
            Log.d(TAG, "departure from Cape town");

            destination("DUR", "DURBAN");
            Log.d(TAG, "Destination Durban");

            //departure date picker
            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDate();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set departure date");

            solo.scrollDown();

            solo.clickOnView(solo.getView(R.id.add_adult_number));
            Log.d(TAG, "1 Passenger added");

            searchBusTicket();

            //Departure ticket
            solo.clickOnView(solo.getView(R.id.parent_layout_id));
            Log.d(TAG, "Click on ticket");

            solo.clickOnView(solo.getView(R.id.next_search_results));
            Log.d(TAG, "Next");

            solo.sleep(500);

            //Parent details
            Title(4);
            Log.d(TAG, "Title entered");

            initial("RJ");
            Log.d(TAG, "Initials entered");

            Surname("Motsamai");
            Log.d(TAG, "Surname entered");

            Cellphone("0735780512");
            Log.d(TAG, "Cellphone number entered");

            indicateDocumentation("ID");
            Log.d(TAG, "ID selected");

            View BottomF = solo.getView(R.id.fragment_passenger_details_id);
            BottomF.scrollTo(0, 360);

            ID("8903030290081");
            Log.d(TAG, "ID number entered");

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Infant On Lap checked");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            Log.d(TAG, "moved to next passenger");

            BottomF.scrollTo(0, 0);

            Title(0);
            Log.d(TAG, "Title entered");

            initial("GC");
            Log.d(TAG, "Initials entered");

            Surname("Motsamai");
            Log.d(TAG, "Last name entered");

            infantChildCalendar();
            Log.d(TAG, "Clicked on calender ");
            Calendar dob = Calendar.getInstance();
            dob.add(Calendar.DAY_OF_YEAR, -5);

            infantChildDob(dob);
            solo.clickOnText("Ok");
            Log.d(TAG, "Set date of birth");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Confirm");

            solo.waitForDialogToClose(30000);

            paymentType("credit card");
            Log.d(TAG, "paying using a credit card");

            Book();
            Log.d(TAG, "Booking a ticket");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T040_Reprint() {
        try {
            //Parent trip
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            checks.busReprints();
            Log.d(TAG, "Clicked on 'REPRINTS'");

            solo.sleep(500);

            if (solo.searchText("Reprint")) {
                solo.clickOnText("Reprint");
                Log.d(TAG, "Clicked on 'Reprint'");
            } else {
                Log.d(TAG, "No reprints found");
            }
//            if (solo.searchText("No Tickets Found")) {
//                Log.d(TAG, "No reprints found");
//            } else {
//                solo.clickOnText("Reprint");
//                Log.d(TAG, "Clicked on 'Reprint'");
//            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    @Test
    public void T100_TotalSeats() {
        try {
            //Return trip with parent and infant
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            solo.waitForDialogToClose();

            solo.scrollDown();

            for (int i = 0; i < 11; i++) {
                solo.clickOnView(solo.getView(R.id.add_adult_number));
            }
            Log.d(TAG, "Clicked on add seat 11 times");

            BluDroidTextView seats = (BluDroidTextView) solo.getView(R.id.adult_number_value);
            String numSeats = seats.getText().toString();

            if (!numSeats.equals("10")) {
                fail("Cannot book more than 10 seats");
            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    @Test
    public void T110_ChildValidation() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            solo.waitForDialogToClose();

            //OneWay Trip
            indicateWayOfTravel("OneWay");
            Log.d(TAG, "OneWay trip selected");

            selectDepart("CAPE", "CAPE TOWN");
            Log.d(TAG, "departure from Cape town");

            destination("DUR", "DURBAN");
            Log.d(TAG, "Destination Durban");


            //departure date picker
            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDate();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set departure date");

            View Scroll = solo.getView(R.id.searchScrollView);
            Scroll.scrollTo(0, 360);

            solo.clickOnView(solo.getView(R.id.add_adult_number));
            Log.d(TAG, "1 passenger added");

            searchBusTicket();

            //Departure ticket
            solo.clickOnView(solo.getView(R.id.parent_layout_id));
            Log.d(TAG, "Click on ticket");

            solo.clickOnView(solo.getView(R.id.next_search_results));
            Log.d(TAG, "Next");

            passengerTypeSpinner(2);
            Log.d(TAG, "Child passenger type selected ");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText("Required"))
                Log.d(TAG, "Date of birth required");
            else
                fail("Age is valid");

            initial("AB");
            Surname("Smith");

            infantChildCalendar();
            Log.d(TAG, "Clicked on calender ");
            Calendar dob = Calendar.getInstance();
            dob.add(Calendar.DATE, -1);
            infantChildDob(dob);

            solo.clickOnText("Ok");
            Log.d(TAG, "Set date of birth");
            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText("Must be between"))
                Log.d(TAG, "Date of birth must be between");
            else
                fail("Age is valid");

            infantChildCalendar();
            Log.d(TAG, "Clicked on calender ");
            dob.add(Calendar.YEAR, -10);
            infantChildDob(dob);

            solo.clickOnText("Ok");
            Log.d(TAG, "Set date of birth");
            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText("At least one adult"))
                Log.d(TAG, "At least one adult");
            else
                fail("Child not allowed to travel without adult");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    @Test
    public void T110_InfantValidation() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            solo.waitForDialogToClose();

            //OneWay Trip
            indicateWayOfTravel("OneWay");
            Log.d(TAG, "OneWay trip selected");

            selectDepart("CAPE", "CAPE TOWN");
            Log.d(TAG, "departure from Cape town");

            destination("DUR", "DURBAN");
            Log.d(TAG, "Destination Durban");


            //departure date picker
            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDate();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set departure date");

            View Scroll = solo.getView(R.id.searchScrollView);
            Scroll.scrollTo(0, 360);

            solo.clickOnView(solo.getView(R.id.add_adult_number));
            Log.d(TAG, "1 passenger added");

            searchBusTicket();

            //Departure ticket
            solo.clickOnView(solo.getView(R.id.parent_layout_id));
            Log.d(TAG, "Click on ticket");

            solo.clickOnView(solo.getView(R.id.next_search_results));
            Log.d(TAG, "Next");

            passengerTypeSpinner(3);
            Log.d(TAG, "Infant passenger type selected ");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText("Required"))
                Log.d(TAG, "Date of birth required");
            else
                fail("Age is valid");

            initial("AB");
            Surname("Smith");

            infantChildCalendar();
            Log.d(TAG, "Clicked on calender ");
            Calendar dob = Calendar.getInstance();
            dob.add(Calendar.DATE, 1);
            infantChildDob(dob);

            solo.clickOnText("Ok");
            Log.d(TAG, "Set date of birth");
            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText("months or younger"))
                Log.d(TAG, "Date of birth must x months or younger");
            else
                fail("Age is valid");

            infantChildCalendar();
            Log.d(TAG, "Clicked on calender ");
            dob.add(Calendar.DATE, -10);
            infantChildDob(dob);

            solo.clickOnText("Ok");
            Log.d(TAG, "Set date of birth");
            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText("At least one adult"))
                Log.d(TAG, "At least one adult");
            else
                fail("Child not allowed to travel without adult");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T130_CellphoneNumberValidation() {
        try {
            //Return trip with parent and infant
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            solo.waitForDialogToClose();

            //OneWay Trip
            indicateWayOfTravel("OneWay");
            Log.d(TAG, "OneWay trip selected");

            selectDepart("CAPE", "CAPE TOWN");
            Log.d(TAG, "departure from Cape town");

            destination("DUR", "DURBAN");
            Log.d(TAG, "Destination Durban");


            //departure date picker
            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDate();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set departure date");

            solo.scrollDown();

            solo.clickOnView(solo.getView(R.id.add_adult_number));
            Log.d(TAG, "Adult added");

            searchBusTicket();

            //Departure ticket
            solo.clickOnView(solo.getView(R.id.parent_layout_id));
            Log.d(TAG, "Click on ticket");

            solo.clickOnView(solo.getView(R.id.next_search_results));
            Log.d(TAG, "Next");

            Cellphone("");
            Log.d(TAG, "No Cellphone number is entered");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberNotEntered)))
                Log.d(TAG, "'Cellphone number is required' text appeared. ");
            else
                fail("No cellphone number went through.");

            Cellphone("");

            Cellphone("1735780512");
            Log.d(TAG, "Cellphone number with no 0 at the beginning is entered");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberInvalid)))
                Log.d(TAG, "'Please enter a valid south african cellphone number' " +
                        "text appeared. Cellphone number with no 0 at the beginning not allowed.");
            else
                fail("Cellphone number with no 0 at the beginning went through.");

            Cellphone("");
            Log.d(TAG, "Cellphone number field cleared");
            Cellphone("073578051");
            Log.d(TAG, "Less than 10 cellphone number digits entered");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText("Cellphone Number"))
                Log.d(TAG, "'Please enter a valid south african cellphone number' " +
                        "text appeared. Cellphone number with less than 10 digits not allowed.");
            else
                fail("Cellphone number with less than than 10 digits went through.");

//      Cellphone("");
//      Log.d(TAG, "Cellphone number field cleared");
//
//      Cellphone("07357801235");
//      Log.d(TAG, "More than 10 cellphone number digits entered");
//
//      solo.clickOnButton("Next");
//      Log.d(TAG, "Next");
//
//      if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberInvalid)))
//        Log.d(TAG, "'Please enter a valid south african cellphone number' " +
//            "text appeared. Cellphone number with more than 10 digits not allowed.");
//      else
//        fail("Cellphone number with more than than 10 digits went through.");

            Cellphone("");
            Log.d(TAG, "Cellphone number field cleared");

            Cellphone("073578#@d");
            Log.d(TAG, "Cellphone number with invalid characters entered");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberNotEntered)))
                Log.d(TAG, "'Please enter a valid south african cellphone number' " +
                        "text appeared. Cellphone number with invalid characters not allowed.");
            else
                fail("Cellphone number with invalid characters went through.");

            Cellphone("");
            Log.d(TAG, "Cellphone number field cleared");

            Cellphone("0035785678");
            Log.d(TAG, "Cellphone number starting with 00 entered");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberInvalidZeros)))
                Log.d(TAG, "'Cellphone number cannot start with 00' " +
                        "text appeared. Cellphone number starting with 00 not allowed.");
            else
                fail("Cellphone number starting with 00 went through.");

            Cellphone("");
            Log.d(TAG, "Cellphone number field cleared");

            //Customer details
            Title(4);
            Log.d(TAG, "Title entered");

            initial("RJ");
            Log.d(TAG, "Initials entered");

            Surname("Motsamai");
            Log.d(TAG, "Surname");

            Cellphone("0735785478");
            Log.d(TAG, "A valid cellphone number entered");

            indicateDocumentation("ID");
            Log.d(TAG, "ID selected");

            View BottomF = solo.getView(R.id.fragment_passenger_details_id);
            BottomF.scrollBy(0, 360);

            ID("8903030290081");
            Log.d(TAG, "ID number entered");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            if (solo.searchText("Confirm Passengers"))
                Log.d(TAG, "passenger details accepted");
            else
                fail("passenger details not accepted");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    @Test
    public void T140_DepartureDate() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto Tickets Menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            solo.waitForDialogToClose();

            //OneWay Trip
            indicateWayOfTravel("OneWay");
            Log.d(TAG, "OneWay trip selected");

            selectDepart("CAPE", "CAPE TOWN");
            Log.d(TAG, "Departure from Cape Town");

            destination("DUR", "DURBAN");
            Log.d(TAG, "Destination Durban");


            //departure date picker
            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDateYesterday();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set Departure Date");

            solo.scrollDown();

            solo.clickOnView(solo.getView(R.id.add_adult_number));
            Log.d(TAG, "Adult added");

            searchBusTicket();

            if (solo.searchText("Date cannot be in the past")) {
                Log.d(TAG, "'Error: Date cannot be in the past' dialog opened");
                solo.clickOnText("OK");
            } else
                fail("Able to select date in the past");

            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDateToday();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set Departure Date");

            searchBusTicket();

            if (solo.searchText("Date cannot be in the past"))
                fail("Unable to select today's date as departure");
            else
                Log.d(TAG, "'Error: Date cannot be in the past' dialog did not open");


        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    @Test
    public void T170_CashierReprint() {
        try {
            if (checks.cashierLogin(this)) {
                Log.d(TAG, "Login as a Cashier");
            } else {
                fail("Could not login as a Cashier");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            checks.busReprints();
            Log.d(TAG, "Clicked on 'REPRINTS'");

            if (getBaseActivity().fragmentBusTicketsReprints != null)
                fail("Cashier not allowed to do reprints");
            else
                Log.d(TAG, "Cashier allowed to do reprints");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

}
