package za.co.blts.bltandroidgui3.confirmations;


import android.util.Log;
import android.view.WindowManager;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;

//
// view and button stuff
//

public class BluDroidTechPinConfirmationDialog extends BluDroidConfirmationDialog implements BluDroidSetupable {

    public void setup() {
        super.setup();
        hideView(R.id.neutralButton);
        setAffirmativeButtonLabel(R.string.confirm);
        setNegativeButtonLabel(R.string.cancel);
        setHeading(R.string.confirm);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }

    public BluDroidTechPinConfirmationDialog(BaseActivity context) {
        super(context, R.layout.confirmation_tech_pin);
        setup();
        String TAG = this.getClass().getSimpleName();
        Log.d(TAG, "Purchase confirmation with activity");
        BaseActivity.logger.info(": construction with BaseActivity");
    }


}

