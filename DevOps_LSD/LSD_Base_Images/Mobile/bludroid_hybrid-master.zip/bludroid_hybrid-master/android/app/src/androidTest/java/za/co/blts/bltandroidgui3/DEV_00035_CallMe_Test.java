package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00035_CallMe_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() throws Exception {
        tearDown();
    }

    @Test
    public void T10_EnableCallMe() {
        String refreshText = solo.getCurrentActivity().getResources().getString(R.string.refresh);
        solo.clickOnView(solo.getView(R.id.fab));
        solo.clickOnMenuItem(refreshText);

        changePreference(PREF_DEVICE_ID, "54453");
        solo.clickInRecyclerView(0);
        checks.login(testProperties.getProperty("supervisorPin"));

        if (solo.searchText("Device not active")) {
            Log.d(TAG, "Dismiss device not active error dialog");
            solo.goBack();
        }
        if (solo.searchText("Sign-In")) {
            Log.d(TAG, "Dismiss login dialog");
            solo.goBack();
        }
        changePreference(PREF_DEVICE_ID, testProperties.getProperty("deviceId"));

        if (!solo.searchText("Call Me")) {
            fail("Call Me button not displayed");
        }
    }

    @Test
    public void T20_CallMe() {
        try {
            if (!solo.searchText("Call Me")) {
                fail("Call Me button not visible");
            }

            checks.callMe();
            Log.d(TAG, "Clicked on call Me button'");

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Click device");
            solo.clickOnCheckBox(1);
            Log.d(TAG, "Click account");
            solo.clickOnCheckBox(2);
            Log.d(TAG, "Click deposit");

            solo.clickOnText("Cancel");
            Log.d(TAG, "Clicked on cancel button");

            checks.callMe();
            Log.d(TAG, "Clicked on call Me button'");

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Click device");
            solo.clickOnCheckBox(1);
            Log.d(TAG, "Click account");
            solo.clickOnCheckBox(2);
            Log.d(TAG, "Click deposit");
            solo.clickOnText("Next");
            Log.d(TAG, "go to Confirm cell number layout");

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Valid Cellphone number entered");
            checks.enterText(R.id.confirmCellNumber1, "0721231234");
            Log.d(TAG, " Valid Cellphone number confirmed");

            solo.clickOnText("Cancel");
            Log.d(TAG, "go to landing page");

            checks.callMe();
            Log.d(TAG, "Clicked on call Me button'");

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Click device");
            solo.clickOnCheckBox(1);
            Log.d(TAG, "Click account");
            solo.clickOnCheckBox(2);
            Log.d(TAG, "Click deposit");
            solo.clickOnText("Next");
            Log.d(TAG, "go to Confirm cell number layout");

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Valid Cellphone number entered");
            solo.sleep(1000);
            checks.enterText(R.id.confirmCellNumber1, "0721231234");
            Log.d(TAG, "Valid Cellphone number confirmed");

            solo.clickOnText("Next");
            Log.d(TAG, "send email...");

            solo.sleep(1000);

            solo.clickOnText("OK");
            Log.d(TAG, "go to landing page");

        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }


    @Test
    public void T30_DisableCallMe() {
        String refreshText = solo.getCurrentActivity().getResources().getString(R.string.refresh);
        solo.clickOnView(solo.getView(R.id.fab));
        solo.clickOnMenuItem(refreshText);

        if (solo.searchText("Call Me")) {
            fail("Call Me button displayed after cache refresh");
        }
        changePreference(PREF_DEVICE_ID, "29788");

        checks.superVisorLogin(this);
        checks.logout();

        if (solo.searchText("Call Me")) {
            fail("Call Me button displayed for device Id " + testProperties.getProperty("deviceId"));
        }
    }
}
