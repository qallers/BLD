package za.co.blts.loyalty;

import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

import sunmi.paylib.SunmiPayKernel;
import za.co.blt.consumer.loyalty.api.service.model.request.ConsumerProfileRequest;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfileIdentifier;
import za.co.blt.consumer.loyalty.api.service.model.response.Error;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.BluDroidVolley;
import za.co.blts.bltandroidgui3.FragmentFavourites;
import za.co.blts.bltandroidgui3.MainApplication;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidIdNumberEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMandatoryEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidScrollView;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentNFCCustomerRegistration extends BaseFragment implements BluDroidNFCCardAsyncResponse {

    private ConsumerProfileRequest consumerProfileRequest = new ConsumerProfileRequest();
    private BluDroidVolley bluDroidVolley;
    private BluDroidAlertDialog alert = null;
    private BluDroidMandatoryEditText nfc_card_code;
    private BluDroidMandatoryEditText nfc_name, nfc_surname;
    private BluDroidCellphoneEditText nfc_cell_number;
    private BluDroidIdNumberEditText nfc_id_number;

    //----------------------------------------------------------------------------------------------
    public FragmentNFCCustomerRegistration() {
        // Required empty public constructor
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_nfc_registration, container, false);
        getBaseActivity().hideKeyboard();

        nfc_card_code = rootView.findViewById(R.id.nfc_card_code);
        nfc_name = rootView.findViewById(R.id.nfc_name);
        nfc_surname = rootView.findViewById(R.id.nfc_surname);
        nfc_cell_number = rootView.findViewById(R.id.nfc_cell_number);
        nfc_id_number = rootView.findViewById(R.id.nfc_id_number);

        final BluDroidScrollView scroll = rootView.findViewById(R.id.layout);

        BluDroidButton nfc_register = rootView.findViewById(R.id.nfc_register);
        nfc_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (scroll.validate()) {

                    consumerProfileRequest.setName(nfc_name.getText().toString());
                    consumerProfileRequest.setSurname(nfc_surname.getText().toString());
                    consumerProfileRequest.setIdentityNumber(nfc_id_number.getText().toString());
                    consumerProfileRequest.setMobile(nfc_cell_number.getText().toString());
                    consumerProfileRequest.setLoyaltyCard(nfc_card_code.getText().toString());
                    consumerProfileRequest.setDeviceId(getBaseActivity().getPreference(PREF_DEVICE_ID));
                    consumerProfileRequest.setDeviceUserId(getBaseActivity().getPreference(BaseActivity.loginResponseMessage.getData().getUserId()));
                    // if valid
                    try {
                        doRequest(new JSONObject(new Gson().toJson(consumerProfileRequest)));
                    } catch (JSONException e) {
                        BaseActivity.logger.error(" " + e);
                        e.printStackTrace();
                    }
                }
            }
        });
        BluDroidButton cancel_nfc = rootView.findViewById(R.id.cancel_nfc);
        cancel_nfc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getBaseActivity().resetTimer();
                getBaseActivity().clearNFCActiveConsumer(true);
            }
        });


        return rootView;
    }


    //----------------------------------------------------------------------------------------------
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setTitle(getString(R.string.nfc_registration));
        bluDroidVolley = BluDroidVolley.getInstance(getBaseActivity());
    }

    @Override
    public void onDestroy() {
        if (bluDroidVolley != null) bluDroidVolley.cancelAll();
        super.onDestroy();
    }

    //----------------------------------------------------------------------------------------------
    private void setTitle(String title) {
        getActivity().setTitle(title);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean onBackPressed() {
        getBaseActivity().gotoFragment(new FragmentFavourites(), "FragmentFavourites");
        return true;
    }

    //----------------------------------------------------------------------------------------------
    private void doRequest(JSONObject o) {
        getBaseActivity().createProgress("Register Customer");
        JsonObjectRequest registerConsumer = new JsonObjectRequest(Request.Method.POST, BaseActivity.loyaltyServerBaseUrl, o, // URL
                createReqSuccessListener(),
                createReqErrorListener());
        registerConsumer.setTag(this);
        getBaseActivity().createProgress(R.string.nfc_customer_registration);
        bluDroidVolley.addRequestApiGateway(registerConsumer); // make sure that this is not null
    }

    //----------------------------------------------------------------------------------------------
    private Response.Listener<JSONObject> createReqSuccessListener() {
        return new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                getBaseActivity().dismissProgress();
                ConsumerProfileIdentifier consumerProfileIdentifier = new Gson().fromJson(response.toString(), ConsumerProfileIdentifier.class);
                if (consumerProfileIdentifier != null && Integer.valueOf(consumerProfileIdentifier.getProfileId()) > 0) {
                    BaseActivity.logger.info(" Registration successful - " + BaseActivity.consumerProfile);
                    handleResponseMessage(true, "Registration Successful");
                } else { // failed
                    BaseActivity.logger.error(" Something went wrong. Please try again - " + BaseActivity.consumerProfile);
                    handleResponseMessage(false, "Something went wrong. Please try again");
                }
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    private Response.ErrorListener createReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.e("error: " + error);
                String message;
                if (getBaseActivity() != null) {
                    getBaseActivity().dismissProgress();
                    VolleyLog.e("error.getMessage(): " + error.getMessage());
                    VolleyLog.e("error.networkResponse: " + error.networkResponse);
                    String errorMessage;
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            errorMessage = new String(error.networkResponse.data, StandardCharsets.UTF_8); // for UTF-8 encoding
                            VolleyLog.e("errorMessage: " + errorMessage);
                            Error error1 = new Gson().fromJson(errorMessage, Error.class);
                            message = error1.getMessage();
                        } catch (Exception e) {
                            BaseActivity.logger.error(" " + e);
                            e.printStackTrace();
                            message = "An unknown error occurred";
                        }
                    } else {
                        message = "Could not connect";
                    }

                    BaseActivity.logger.error(" " + message);
                    handleResponseMessage(false, message); // propagate the server error message
                }
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    private void handleResponseMessage(final boolean responseIsSuccessful, String message) {
        String messageTitle;
        if (responseIsSuccessful) {
            messageTitle = "Successful";
        } else {
            messageTitle = "Failed";
        }

        alert = getBaseActivity().createAlertDialog(messageTitle, message);
        alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (responseIsSuccessful)
                    getBaseActivity().clearNFCActiveConsumer(true);
                else
                    alert.dismiss(); // retry
            }
        });
    }

    @Override
    public void onError(String msg) {
        BaseActivity.logger.error(" " + msg);
    }

    @Override
    public void onReady() {

    }

    @Override
    public void onCardNumberRead(String cardNumber) {
        nfc_card_code.setText(cardNumber);
    }

    @Override
    public void onPause() {
        super.onPause();
        stopNFCListener();
        if (mSunmiPayKernel != null) {
            mSunmiPayKernel.destroyPaySDK();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (Build.MODEL.startsWith("P1")) {
            mSunmiPayKernel = SunmiPayKernel.getInstance();
            mSunmiPayKernel.connectPayService(getContext(), mConnCallback);
        } else {
            startNFCListener(FragmentNFCCustomerRegistration.this);
        }
    }

    private SunmiPayKernel.ConnCallback mConnCallback = new SunmiPayKernel.ConnCallback() {
        @Override
        public void onServiceConnected() {
            try {
                //Toast.makeText(ActivityMain.this, "onServiceConnected()", Toast.LENGTH_SHORT).show();
                MainApplication.mReadCardOpt = mSunmiPayKernel.mReadCardOpt;
                startNFCListener(FragmentNFCCustomerRegistration.this);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected() {
        }
    };
    //----------------------------------------------------------------------------------------------
    /*
    * You can use the internal IP and port:
    http://10.22.7.12:9012/customer/loyalty/v1/...

    Or the external IP and port:
    http://196.37.22.179:9012/customer/loyalty/v1/...
*/
}
