package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 3/14/2017.
 */

@RunWith(AndroidJUnit4.class)
public class DEV_00160_EndShift_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void EndShift_Test() {
        try {


            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }


            checks.endShift();
            Log.d(TAG, "End shift menu option selected");

            checks.clickOnDialogOption("Cancel");
            Log.d(TAG, "Cancel dialog option clicked");


            checks.endShift();
            Log.d(TAG, "End shift menu option selected");

            checks.clickOnDialogOption("End Shift");
            Log.d(TAG, "End Shift dialog option clicked");

            solo.clearLog();

            solo.waitForLogMessage("TEST : VOUCHER PRINTED");
            Log.d(TAG, "End Shift report printed");
            //checks.clickOnActionMenu();


        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
