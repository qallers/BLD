package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.lang.ref.WeakReference;
import java.util.List;

/**
 * Created by MasiS on 4/5/2017.
 */

class BluDroidCarmaRoutesAdapter extends ArrayAdapter<BluDroidRoutesAndTimes> {
    private final String TAG = this.getClass().getSimpleName();

    private boolean isConfirmTickets;

    private WeakReference<BaseActivity> baseActivityWeakReference;

    //----------------------------------------------------------------------------------------------
    public BluDroidCarmaRoutesAdapter(BaseActivity context, int layoutResourceId, List<BluDroidRoutesAndTimes> dataSet, boolean isConfirmTickets) {
        super(context, layoutResourceId, dataSet);
        this.baseActivityWeakReference = new WeakReference<>(context);
        this.isConfirmTickets = isConfirmTickets;
    }

    //----------------------------------------------------------------------------------------------
    @SuppressLint("ResourceAsColor")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final BluDroidRoutesAndTimes bluDroidRoutesAndTimes = getItem(position);
        final ViewHolder viewHolder;

        final BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {

            if (convertView == null) {
                // inflate the layout
                convertView = baseActivity.getLayoutInflater().inflate(R.layout.bus_trip_info_layout_item, parent, false);
                // well set up the ViewHolder
                viewHolder = new ViewHolder();
                viewHolder.bus_icon_image_view = convertView.findViewById(R.id.bus_icon_image_view);
                viewHolder.carrierName = convertView.findViewById(R.id.carrierName);
                viewHolder.depart_bus_info_time = convertView.findViewById(R.id.depart_bus_info_time);
                viewHolder.arrive_bus_info_time = convertView.findViewById(R.id.arrive_bus_info_time);
                viewHolder.adult_price = convertView.findViewById(R.id.adult_price);
                viewHolder.child_price = convertView.findViewById(R.id.child_price);
                viewHolder.infant_price = convertView.findViewById(R.id.infant_price);
                viewHolder.depart_bus_place = convertView.findViewById(R.id.depart_bus_place);
                viewHolder.arrive_bus_place = convertView.findViewById(R.id.arrive_bus_place);
                viewHolder.bus_class_type = convertView.findViewById(R.id.class_type);
                viewHolder.selectRoute = convertView.findViewById(R.id.selectRoute);

                if (isConfirmTickets) {
                    viewHolder.selectRoute.setVisibility(View.INVISIBLE);
                }

                // store the holder with the view.
                convertView.setTag(viewHolder);
            } else {
                // we've just avoided calling findViewById() on resource everytime
                // just use the viewHolder
                viewHolder = (ViewHolder) convertView.getTag();
            }


            if (bluDroidRoutesAndTimes != null) { // the object at current position

                viewHolder.imageURL = bluDroidRoutesAndTimes.getMediaUrl() + "/";

                if (BaseActivity.isSearchResultsScreen)
                    viewHolder.imageURL += bluDroidRoutesAndTimes.getCarrier() + ".png";
                else
                    viewHolder.imageURL += baseActivity.availabilitySearchQuery.getCarrierCode() + ".png";

                Log.d(TAG, "getView: imageURL = " + viewHolder.imageURL);

                viewHolder.bus_icon_image_view.setTag(viewHolder.imageURL);
                if (viewHolder.bus_icon_image_view != null) {
                    Picasso picasso = Picasso.get();
                    picasso.setIndicatorsEnabled(baseActivity.isDebug());
                    picasso
                            .load(viewHolder.imageURL)
                            .placeholder(R.drawable.longhaul)
                            .error(R.drawable.longhaul)
                            .into(viewHolder.bus_icon_image_view);
                }

                viewHolder.carrierName.setText(bluDroidRoutesAndTimes.getCarrierName().toUpperCase());

                viewHolder.depart_bus_info_time.setText(baseActivity.formatDate(bluDroidRoutesAndTimes.getBoardTime()));

                viewHolder.arrive_bus_info_time.setText(baseActivity.formatDate(bluDroidRoutesAndTimes.getArriveTime()));

                if (isConfirmTickets) {
                    viewHolder.adult_price.setText(baseActivity.getResources().getString(R.string.format_seats, bluDroidRoutesAndTimes.getPositionInList()));
                    viewHolder.child_price.setText(baseActivity.getResources().getString(R.string.format_price, bluDroidRoutesAndTimes.getAdultPrice()));
                    viewHolder.child_price.setVisibility(View.VISIBLE);
                } else {
                    String price = new BluDroidUtils().formatMoney(bluDroidRoutesAndTimes.getAdultPrice());
                    viewHolder.adult_price.setText(baseActivity.getResources().getString(R.string.format_seat_price, price));
                    viewHolder.child_price.setVisibility(View.GONE);
                }

                viewHolder.infant_price.setVisibility(View.GONE);


                viewHolder.depart_bus_place.setText(baseActivity.getResources().getString(R.string.format_depart, bluDroidRoutesAndTimes.getBoardLocation()));
                viewHolder.arrive_bus_place.setText(baseActivity.getResources().getString(R.string.format_arrive, bluDroidRoutesAndTimes.getDestLocation()));
                viewHolder.bus_class_type.setText(String.format("%s%s", bluDroidRoutesAndTimes.getTravelClass().substring(0, 1),
                        bluDroidRoutesAndTimes.getTravelClass().substring(1).toLowerCase()));
                int iconSelected = bluDroidRoutesAndTimes.getIconSelected();
                if (bluDroidRoutesAndTimes.isSelected()) {
                    viewHolder.selectRoute.setImageResource(iconSelected);
                } else
                    viewHolder.selectRoute.setImageResource(R.drawable.ic_checkbox_off);
            }

            if (!isConfirmTickets) {
                convertView.setOnClickListener(new View.OnClickListener() {
                    @SuppressLint("ResourceAsColor") // what does this do? like I still don't get it
                    @Override
                    public void onClick(View v) {
                        Log.d(TAG, "onClick");

                        baseActivity.availabilitySearchQuery.setCarrierCode(bluDroidRoutesAndTimes.getCarrier());

                        baseActivity.fragmentCarmaSearchResults.toggleRouteSelect(position);
                    }
                });
            }
        }

        // Return the completed view to render on screen
        return convertView;
    }


    //----------------------------------------------------------------------------------------------
    static class ViewHolder {
        ImageView bus_icon_image_view;
        TextView depart_bus_info_time;
        TextView carrierName;
        TextView arrive_bus_info_time;
        TextView adult_price;
        TextView child_price;
        TextView infant_price;
        TextView bus_class_type;
        TextView depart_bus_place;
        TextView arrive_bus_place;
        ImageView selectRoute;
        String imageURL;
    }

}
