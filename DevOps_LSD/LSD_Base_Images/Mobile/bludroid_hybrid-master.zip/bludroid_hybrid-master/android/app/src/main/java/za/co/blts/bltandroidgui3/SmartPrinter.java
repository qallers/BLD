package za.co.blts.bltandroidgui3;

import android.graphics.Bitmap;

import com.google.zxing.common.BitMatrix;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;

//
// Interface for printer access
//
// this is the interface for our newer smart printers
// where the printers will interpret the formatting
// chargs sent down from AEON
//
public interface SmartPrinter {

    int ALIGN_LEFT = 0;
    int ALIGN_CENTER = 1;
    int ALIGN_RIGHT = 2;

    int FONT_NORMAL = 24;
    int FONT_LARGE = 46;

    int MODE_MONO = 1;

    void initialise(BaseActivity baseScreen);

    void terminate();

    void print(ArrayList<CommonResponseLineMessage> lines, boolean feed);

    void print(List<String> lines);

    void print(Bitmap logo, List<String> lines, Bitmap barcode, String barcodeNumber);

    void print(Bitmap logo, List<CommonResponseLineMessage> lines, Bitmap barcode, boolean feed);

    int getBitmapMaxWidth();

    Bitmap convertBitMatrixToBitMap(BitMatrix bitMatrix);

    void print(JSONArray printJob);

    void printJsonDefaultLogo(JSONArray printJob, boolean feed);

}
