package za.co.blts.bltandroidgui3;

import android.view.ViewGroup;
import android.view.WindowManager;

import java.util.List;

import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 3/29/2017.
 */

public class BluDroidConfirmPassengerDialog extends BluDroidConfirmationDialog implements BluDroidSetupable {

    public void setup() {
        super.setup();
        setAffirmativeButtonLabel(R.string.confirm);
        hideView(R.id.neutralButton);
        setNegativeButtonLabel(R.string.cancel);
        setHeading("Confirm Passengers");

        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    public BluDroidConfirmPassengerDialog(BaseActivity context) {
        super(context, R.layout.dialog_confirm_passenger);
        setup();
    }

    public void setPassengers(List<CarmaPassenger> passengerDetails) {
        BluDroidTextView passengers = findViewById(R.id.passengers);
        if (passengers != null) {
            String str = "";
            for (int i = 0; i < passengerDetails.size(); i++) {
                CarmaPassenger p = passengerDetails.get(i);
                str += (i + 1) + ". " + p.getInitials() + " " + p.getLastName();
                if (p instanceof CarmaPassengerInfant) {
                    str += " (Infant " + (((CarmaPassengerInfant) p).isOnLap() ? "on Lap" : "") + ")";
                } else if (p instanceof CarmaPassengerChild) {
                    str += " (Child)";
                } else if (p instanceof CarmaPassengerAdult) {
                    str += " (Adult)";
                }
                str += "\n";
            }
            passengers.setText(str);
        }
    }

}
