package za.co.blts.bltandroidgui3.cardviews;

import android.app.Activity;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewDefaultAirtime extends CardviewDataObject {

    public CardviewDefaultAirtime(Activity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.default_airtime,
                ((BaseActivity) baseActivity).getSkinResources().getButtonColor(),
                stockId, voucherType, tag);
        super.setHasAirtimePlus(hasAirtimePlus);
        setDefaultCard("default_airtime");
    }

    public CardviewDefaultAirtime(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.default_airtime,
                baseActivity.getSkinResources().getButtonColor(),
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(hasAirtimePlus);
        setDefaultCard("default_airtime");
    }

    public CardviewDefaultAirtime(BaseActivity baseActivity, String cardDesc, String cardValue, String voucherType, String tag, String voucherTypeDesc, boolean isMVNO, String code, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.default_airtime,
                baseActivity.getSkinResources().getButtonColor()
                , voucherType, tag, voucherTypeDesc, "", isMVNO, code);//, , supplierCode);
        super.setHasAirtimePlus(hasAirtimePlus);
        setDefaultCard("default_airtime");
    }

    public String getBundlesName() {
        return this.getTag() + "Bundles";
    }

    public String getTopupName() {
        return this.getTag();
    }

}

