package za.co.blts.bltandroidgui3;

import java.util.Date;

/**
 * Created by MasiS on 2018/03/05.
 */

class CarmaPassengerChild extends CarmaPassenger {
    private Date dob;

    public CarmaPassengerChild() {
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    @Override
    public String toString() {
        return "CarmaPassengerChild{" +
                "dob=" + dob +
                ", title='" + title + '\'' +
                ", initials='" + initials + '\'' +
                ", lastName='" + lastName + '\'' +
                ", idNumber='" + idNumber + '\'' +
                ", passport=" + passport +
                ", price='" + price + '\'' +
                '}';
    }
}
