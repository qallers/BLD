package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;
import za.co.blts.magcard.MagCardData;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_BARCODE_RECEIPT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_UNKNOWN;

/**
 * Created by NkosanaM on 11/16/2017.
 */

class BluDroidEskomReprintListAdapter extends ArrayAdapter<EskomReprint> implements View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();
    private Filter filter;
    private ArrayList<EskomReprint> dataSet;

    private WeakReference<BaseActivity> baseActivityWeakReference;
    private int layoutResourceId;
    private EskomReprint reprint;


    public BluDroidEskomReprintListAdapter(BaseActivity context, int layoutResourceId, ArrayList<EskomReprint> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.layoutResourceId = layoutResourceId;
        this.dataSet = dataSet;
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    @Override
    public void onClick(View v) {
        final BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            BaseActivity.logger.info("ActivitySetup" + ((BluDroidButton) v).getText());

            int position = Integer.parseInt(v.getTag().toString());
            reprint = getItem(position);

            //Get print barcode from shared preferences
            boolean printBarcode = PreferenceManager.getDefaultSharedPreferences(getContext()).getString(PREF_PRINT_BARCODE_RECEIPT, PREF_UNKNOWN).equals(PREF_TRUE);
            baseActivity.printWithDynamic(reprint.getPrintLines(), printBarcode);

            // if (baseActivity.isDebug()){

            if (reprint.getPrintMagCard().equalsIgnoreCase("true")) {

                if (Build.MODEL.startsWith("CITAQ") || Build.MODEL.startsWith("TPS")) {


                    if (!baseActivity.magCard.isConnected()) {
                        Log.d(TAG, "New instance of adapter");

                        if (!baseActivity.magCard.enumerate()) {

                            baseActivity.createAlertDialog("Mag Card", "No devices found, please check if mag encoder is connected");
                            //Toast.makeText(this, "no more devices found", Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            Log.d(TAG, "enumerate succeeded!");
                        }
                    }//if isConnected

                    Toast.makeText(getContext(), "attached", Toast.LENGTH_SHORT).show();
                    baseActivity.magCard.openUsbSerial();


                    baseActivity.magCardDataList = baseActivity.getMagCardReprintTokens(reprint);

                    baseActivity.tokensSize = baseActivity.magCardDataList.size();

                    if (baseActivity.magCardDataList.size() > 0) {

                        baseActivity.alert = baseActivity.createMagCardAlertDialog("MAG Encoder", "Please have " + baseActivity.tokensSize + " paper card(s) ready");

                        baseActivity.alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {


                                MagCardData cardData = baseActivity.magCardDataList.get(0);
                                baseActivity.magCard.setTrack2(cardData.getTrack2());
                                baseActivity.magCard.setTrack3(cardData.getTrack3());
                                baseActivity.magCard.sendWriteCommand();
                                baseActivity.magCardAction = "write";
                                baseActivity.createNotifyAlertDialog("MAG Card", "Please swipe card to write " + baseActivity.cardNumber + "/" + baseActivity.tokensSize);


                            }
                        });

                        baseActivity.alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                        baseActivity.alert.show();
                    }

                } else {
                    baseActivity.createAlertDialog("Mag Encoder", "This Device does not support Mag Encoding, Please contact support");
                }
            }
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        reprint = getItem(position);

        if (convertView == null) {

            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(layoutResourceId, parent, false);
        }


        BluDroidButton btnPrint = convertView.findViewById(R.id.print);
        btnPrint.setOnClickListener(this);
        btnPrint.setTag(position);


        String voucherName = reprint.getRef();
        String date = reprint.getDate();
        String amount = reprint.getAmount();
        String type = reprint.getVoucherType();


        BluDroidTextView txtType = convertView.findViewById(R.id.voucherType);
        BluDroidTextView txtDate = convertView.findViewById(R.id.date);
        BluDroidTextView txtAmount = convertView.findViewById(R.id.amount);
        BluDroidTextView txtTransId = convertView.findViewById(R.id.transId);

        txtType.setText(type);
        txtDate.setText(date);
        txtAmount.setText(getContext().getResources().getString(R.string.eskom_reprint_amount, amount));
        txtTransId.setText(voucherName);

        return convertView;
    }


    @Override
    public Filter getFilter() {
        if (filter == null)
            filter = new BluDroidEskomReprintListAdapter.AppFilter<>(dataSet);
        return filter;
    }

    private class AppFilter<T> extends Filter {

        private ArrayList<T> sourceObjects;

        AppFilter(ArrayList<T> objects) {
            sourceObjects = new ArrayList<>();
            synchronized (this) {
                sourceObjects.addAll(objects);
            }
        }

        @Override
        protected FilterResults performFiltering(CharSequence chars) {
            String filterSeq = chars.toString().toLowerCase();
            FilterResults result = new FilterResults();
            if (filterSeq != null && filterSeq.length() > 0) {
                ArrayList<T> filter = new ArrayList<>();

                for (T object : sourceObjects) {
                    // the filtering itself:
                    Reprint reprint = (Reprint) object;
                    if (reprint.getVoucherType().toLowerCase().contains(filterSeq))
                        filter.add(object);
                }
                result.count = filter.size();
                result.values = filter;
            } else {
                // add all objects
                synchronized (this) {
                    result.values = sourceObjects;
                    result.count = sourceObjects.size();
                }
            }
            return result;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {
            // NOTE: this function is *always* called from the UI thread.
            ArrayList<T> filtered = (ArrayList<T>) results.values;
            notifyDataSetChanged();
            clear();
            for (int i = 0, l = filtered.size(); i < l; i++)
                add((EskomReprint) filtered.get(i));
            notifyDataSetInvalidated();
        }
    }
}

