package za.co.blts.bltandroidgui3;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import za.co.blts.bltandroidgui3.confirmations.BluDroidTestScannerDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;

import static android.view.View.GONE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PAPER_CUTTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SCANNING_APP;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

public class ActivityTestPeripherals extends BaseActivity implements View.OnClickListener, BluDroidScanListener {

    private final String TAG = this.getClass().getSimpleName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_peripherals);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        if (Build.MODEL.contains("CITAQ")) {
            if (Build.MODEL.contains("CITAQ POS")) {
                updatePreference(PREF_PAPER_CUTTER, PREF_FALSE);
            } else {
                updatePreference(PREF_PAPER_CUTTER, PREF_TRUE);
            }
        } else {
            updatePreference(PREF_PAPER_CUTTER, PREF_FALSE);
        }


        toolbar = findViewById(R.id.toolbar);
        String title = "Test Peripherals";
        toolbar.setTitle(title);
        toolbar.setNavigationCloseIcon();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                gotoLandingScreen();
            }
        });

        BluDroidButton testPrinter = findViewById(R.id.testPrinter);
        BluDroidButton testDynamicPrint = findViewById(R.id.testDynamicPrint);
        BluDroidButton testUsbPrinter = findViewById(R.id.testSecureUSBPrinter);
        BluDroidButton testMagEncoder = findViewById(R.id.testMagEncoder);
        BluDroidButton testNFCReader = findViewById(R.id.testNFCReader);
        BluDroidButton testBuiltInScanner = findViewById(R.id.testBuiltInScanner);
        BluDroidButton testExternalScanner = findViewById(R.id.testExternalScanner);
        BluDroidButton testExternalNfcReader = findViewById(R.id.testExternalNfcReader);
        BluDroidButton testZipLog = findViewById(R.id.testZipLog);

        if (!isDebug()) {
            testExternalNfcReader.setVisibility(GONE);
        }

        testPrinter.setOnClickListener(this);
        testDynamicPrint.setOnClickListener(this);
        testUsbPrinter.setOnClickListener(this);
        testMagEncoder.setOnClickListener(this);
        testNFCReader.setOnClickListener(this);
        testBuiltInScanner.setOnClickListener(this);
        testExternalScanner.setOnClickListener(this);
        testExternalNfcReader.setOnClickListener(this);
        testZipLog.setOnClickListener(this);

        if (Build.MODEL.startsWith("CITAQ")) {
            testExternalNfcReader.setVisibility(View.VISIBLE);
            testExternalNfcReader.setEnabled(true);
            testNFCReader.setEnabled(false);
            testNFCReader.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            testBuiltInScanner.setEnabled(false);
            testBuiltInScanner.setBackgroundColor(getResources().getColor(R.color.lightGrey));

        } else {
            testExternalNfcReader.setVisibility(GONE);
            testExternalNfcReader.setEnabled(false);
            testBuiltInScanner.setEnabled(true);
            testBuiltInScanner.setBackgroundColor(getSkinResources().getButtonColor());
        }

        if (Build.MODEL.startsWith("V1") || (Build.MODEL.startsWith("N3"))) {
            testExternalScanner.setEnabled(false);
            testExternalScanner.setBackgroundColor(getResources().getColor(R.color.lightGrey));

            testUsbPrinter.setEnabled(false);
            testUsbPrinter.setBackgroundColor(getResources().getColor(R.color.lightGrey));

            if (Build.MODEL.startsWith("V1")) {
                testMagEncoder.setEnabled(false);
                testMagEncoder.setBackgroundColor(getResources().getColor(R.color.lightGrey));

                testNFCReader.setEnabled(false);
                testNFCReader.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            }
        } else {
            testExternalScanner.setEnabled(true);
            testExternalScanner.setBackgroundColor(getSkinResources().getButtonColor());

            testUsbPrinter.setEnabled(true);
            testUsbPrinter.setBackgroundColor(getSkinResources().getButtonColor());

            testMagEncoder.setEnabled(true);
            testMagEncoder.setBackgroundColor(getSkinResources().getButtonColor());

        }

        if ((Build.MODEL.startsWith("N3"))) {
            testNFCReader.setVisibility(View.VISIBLE);

            if (isDebug()) {
                testUsbPrinter.setEnabled(true);
                testUsbPrinter.setBackgroundColor(getSkinResources().getButtonColor());
            }
        }

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.testPrinter:
                testPrinter();
                break;

            case R.id.testDynamicPrint:
                testDynamicPrint();
                break;

            case R.id.testSecureUSBPrinter:
                if (checkUSBPrinter()) {
                    testSecureUSBPrinter();
                }
                break;

            case R.id.testMagEncoder:
                gotoTestMagEncoderScreen();
                break;

            case R.id.testNFCReader:
                gotoTestNFCReaderScreen();
                break;

            case R.id.testBuiltInScanner:
                printTestBarcode();
                scanBarcode();
                break;

            case R.id.testExternalScanner:
                printTestBarcode();
                createTestScannerDialog(this);
                break;

            case R.id.testExternalNfcReader:
                gotoTestExternalNFCReaderScreen();
                break;

            case R.id.testZipLog:
                zipLogFiles();
                break;

            default:
                break;
        }

    }


    private void zipLogFiles() {
        createDirsIfNecessary();
    }

    private void scanBarcode() {
        Log.d("TEst Scanner", "scanClick");
        try {
            //EditText editText = (EditText) findViewById(R.id.referenceNumber);
            // editText.setText("");
            if (getPreference(PREF_SCANNING_APP).equals("com.google.zxing.client.android")) {

                Log.d("TEst Scanner", "trying to start com.google.zxing.client.android.SCAN");

                if (isPackageInstalled("com.google.zxing.client.android", getPackageManager())) {
                    Intent intent = new Intent("com.google.zxing.client.android.SCAN");
                    startActivityForResult(intent, 0);
                } else {
                    createAlertDialog("Scanning App", "Preferred scanning app not found");
                }
            } else {

                //Log.d(TAG, "trying to start com.gamma.scan/example.qrcode.MainActivity");
                //Intent intent = new Intent("com.gamma.scan/example.qrcode.MainActivity");
                //startActivityForResult(intent, 0);
                //
                // this starts the entire application
                //
                BluDroidScanReciever.setListener(this);
                Log.d(TAG, "trying to start " + getPreference(PREF_SCANNING_APP));

                if (isPackageInstalled((getPreference(PREF_SCANNING_APP)), getPackageManager())) {
                    Intent intent = getPackageManager().getLaunchIntentForPackage(getPreference(PREF_SCANNING_APP));
                    startActivityForResult(intent, 0);
                } else {
                    createAlertDialog("Scanning App", "Preferred scanning app not found");
                }

                //Log.d(TAG, "trying to start com.gamma.scan.SCAN");
                //Intent intent = new Intent("com.gamma.scan.SCAN");
                //startActivityForResult(intent, 0);
            }
        } catch (Exception exception) {
            Log.d("TEst Scanner", "problems starting scanner app " + exception);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        try {
            Log.d(TAG, "onActivityResult ");
            Log.d(TAG, "requestCode " + requestCode);
            Log.d(TAG, "resultCode " + resultCode);
            Log.d(TAG, "intent is " + intent);
            if (intent != null) {

                String contents = intent.getStringExtra("SCAN_RESULT");

                if (contents.trim().isEmpty()) {
                    createAlertDialog("Serial Number required", getResources().getString(R.string.serial_required));
                } else {
                    createTestScannerDialog(this);
                    if (confirmation instanceof BluDroidTestScannerDialog) {

                        BluDroidTestScannerDialog dialog = (BluDroidTestScannerDialog) confirmation;
                        dialog.setBarcode(contents);
                    }

                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "problem getting scan result " + exception);
        }
    }


    @Override
    public void setBarcode(String barcode) {
        if (barcode.trim().isEmpty()) {
            createAlertDialog("Serial Number required", getResources().getString(R.string.serial_required));
        } else {
            createTestScannerDialog(this);

            if (confirmation instanceof BluDroidTestScannerDialog) {

                BluDroidTestScannerDialog dialog = (BluDroidTestScannerDialog) confirmation;
                dialog.setBarcode(barcode);
            }

        }
    }

    @Override
    public void onBackPressed() {
        gotoLandingScreen();
    }
}

