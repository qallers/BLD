package za.co.blts.bltandroidgui3.cardviews;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewStarSat extends CardviewDataObject {

    public CardviewStarSat(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.starsat,
                baseActivity.getResources().getColor(R.color.white),
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(hasAirtimePlus);
    }

    public String getSupplierCode() {
        return "-1";
    }

}

