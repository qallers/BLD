package za.co.blts.bltandroidgui3.confirmations.printPreview;

import java.lang.ref.WeakReference;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;

public class BluDroidSlipPreviewMerchantTransfersDialog extends BluDroidSlipPreviewDialog {
    private final String TAG = this.getClass().getSimpleName();
    private WeakReference<BaseActivity> activityReference;

    public BluDroidSlipPreviewMerchantTransfersDialog(final BaseActivity activity, List<PrintJob> printJobs) {
        super(activity, printJobs);
        activityReference = new WeakReference<>(activity);
        setTitle("Merchant Transfer Preview");
        setup();
    }

    public void finishTransaction() {
        BaseActivity activity = activityReference.get();
        if (activity != null) {
            activity.completeMerchantTransfers();
        }
    }
}
