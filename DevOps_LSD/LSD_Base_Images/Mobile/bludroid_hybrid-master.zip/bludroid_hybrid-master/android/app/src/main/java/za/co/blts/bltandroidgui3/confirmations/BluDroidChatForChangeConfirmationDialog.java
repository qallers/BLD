package za.co.blts.bltandroidgui3.confirmations;

import android.graphics.drawable.Drawable;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ImageView;

import java.util.Locale;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidMoneyEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

//
// view and button stuff
//

public class BluDroidChatForChangeConfirmationDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, OnClickListener {
    protected final String TAG = this.getClass().getSimpleName();
    private String supplierCode;


    public void setup() {
        super.setup();
        supplierCode = "";
        hideView(R.id.neutralButton);
        setAffirmativeButtonLabel(R.string.print);
        setNegativeButtonLabel(R.string.cancel);
        setHeading(R.string.confirm_purchase);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }

    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }

    public String getSupplierCode() {
        return supplierCode;
    }

    public BluDroidChatForChangeConfirmationDialog(BaseActivity context) {
        super(context, R.layout.confirmation_chat_for_change);
        setup();
        BaseActivity.logger.info(": construction with BaseActivity");
    }

    public BluDroidChatForChangeConfirmationDialog(BaseFragment context) {
        super(context, R.layout.confirmation_chat_for_change);
        setup();
        BaseActivity.logger.info(": construction with BaseFragment");
    }


    public void setMinMaxValues(float min, float max) {
        BluDroidTextView amountLabel = findViewById(R.id.amountLabel);
        if (amountLabel != null) {
            String label = String.format(Locale.US, "Enter an amount between R%.2f and R%.2f", min, max);
            amountLabel.setText(label);
        }
        BluDroidMoneyEditText amountTextView = findViewById(R.id.amount);
        if (amountTextView != null) {
            amountTextView.setMinValue(min);
            amountTextView.setMaxValue(max);
        }
    }

    public void setAmount(String amount) {
        BluDroidMoneyEditText amountTextView = findViewById(R.id.amount);
        if (amountTextView != null) {
            final Double doubleAmount = Double.valueOf(amount);
            amountTextView.setText(baseActivity.df2.format(doubleAmount));
        }
    }

    public String getAmount() {
        BluDroidMoneyEditText amount = findViewById(R.id.amount);
        if (amount != null) {
            //return amount.getText().toString();
            return amount.getAmount();
        } else
            return "0.00";
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public ImageView getIcon() {
        return findViewById(R.id.icon);
    }

    public void disableTextBox() {
        BluDroidMoneyEditText amount = findViewById(R.id.amount);
        amount.setKeyListener(null);
    }

}

