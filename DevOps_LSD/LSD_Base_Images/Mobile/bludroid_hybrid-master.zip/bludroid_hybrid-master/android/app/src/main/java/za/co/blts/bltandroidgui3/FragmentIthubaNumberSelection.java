package za.co.blts.bltandroidgui3;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCheckBoxButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidScrollView;

/**
 * Created by WarrenM1 on 2017/07/12.
 */

public class FragmentIthubaNumberSelection extends FragmentIthubaBase {

    private final String TAG = this.getClass().getSimpleName();

    //Name from previous Intent, usually contains looto ot powerball
    private String name = "";

    //Numbers required depending on game(lotto-6 or powerball-5)
    private int numbersRequired = 0;
    //lotto 49-7 powerball 45-7 & 20-5
    private int boardNumbersInTotal = 0;
    private int boardNumberPerRow = 0;
    private boolean isPowerball = false;

    //boards
    private int numOfBoards = 0;
    private int numOfDraws = 0;

    //Play plus
    private BluDroidCheckBoxButton psPlayPlusBox;
    private String yesNoCheckBox = "No";

    //Play plus
    private BluDroidCheckBoxButton psPlayPlus2Box;
    private String yesNoCheckBox2 = "No";

    //used for naming the boards from A-Z instead of 0-X
    private char board;

    //Popup Window for number selection
    private PopupWindow popupWindow = null;

    private TextView boardMessage = null;
    private boolean passesChecks;
    private Map<String, LottoNumberCollection> boardNumbers = new TreeMap<>();

    private View rootView = null;

    public FragmentIthubaNumberSelection() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_ithuba_number_select, container, false);

        Bundle bundle = getArguments();
        getBaseActivity().resetTimer();
        getBaseActivity().hideKeyboard();
        this.name = bundle.getString("name");
        this.numOfBoards = Integer.valueOf(bundle.getString("numBoardsText"));
        this.numOfDraws = Integer.valueOf(bundle.getString("numDrawsText"));

        psPlayPlusBox = rootView.findViewById(R.id.psPlayPlusBox);
        psPlayPlus2Box = rootView.findViewById(R.id.psPlayPlus2Box);

        makeBoards();
        stylePlus2CheckBox();
        playPlus();
        playPlus2();
        play();

        return rootView;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    private void stylePlus2CheckBox() {
        psPlayPlus2Box.setEnabled(false);
        psPlayPlus2Box.setTextColor(getResources().getColor(R.color.check_box_text_disabled));
        psPlayPlus2Box.setTextSize(getSkinResources().getTextSize());
    }

    private void makeBoards() {

        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowmanager = (WindowManager) getBaseActivity().getSystemService(Context.WINDOW_SERVICE);
        windowmanager.getDefaultDisplay().getMetrics(displayMetrics);

        //Find Tablelayout defined in xml
        TableLayout boardMainTable = rootView.findViewById(R.id.boardMainTable);
        boardMainTable.setPadding(0, 10, 0, 10);

        TableRow logoRow = new TableRow(getBaseActivity());
        TableLayout.LayoutParams logoRowParams = new TableLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        logoRow.setLayoutParams(logoRowParams);
        logoRow.setGravity(Gravity.LEFT);

        ImageView pageLogo = new ImageView(getBaseActivity());

        if (name.contains("lotto")) {
            numbersRequired = 6;
            pageLogo.setImageDrawable(getResources().getDrawable(R.drawable.ic_lotto));
            isPowerball = false;
        } else if (name.contains("powerball")) {
            //if number require is 5, the powerball must also be selected. boolean?
            numbersRequired = 5;
            pageLogo.setImageDrawable(getResources().getDrawable(R.drawable.ic_powerball));
            isPowerball = true;
        }

        logoRow.addView(pageLogo);
        boardMainTable.addView(logoRow);

        for (board = 'A'; board < 'A' + numOfBoards; board++) {

            //Creating space between boards
            TextView space = new TextView(getBaseActivity());
            space.setText("   ");
            space.setGravity(Gravity.CENTER_HORIZONTAL);
            boardMainTable.addView(space);

            TableRow boardMainRow = new TableRow(getBaseActivity());
            TableLayout.LayoutParams rowParams = new TableLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            boardMainRow.setLayoutParams(rowParams);
            boardMainRow.setPadding(10, 0, 10, 0);

            //width based on screen
            int desiredWidth = displayMetrics.widthPixels;

            //Check if this boolean is really required
            boolean twoColumn = false;
            createBoard(numbersRequired, boardMainRow, twoColumn);

            if (pxInDIP(desiredWidth) > pxInDIP(800) && isTablet(getBaseActivity()) && (board % 2 != 0) && (board - 64) < numOfBoards) {

                //Had to use "View" here as LayoutParams cause a strange issue and causes the layout to disappear. Using LayoutParams allows you to setMargins.
                View v = new View(getBaseActivity());
                v.setMinimumWidth(20);
                boardMainRow.addView(v);

                twoColumn = true;
                createBoard(numbersRequired, boardMainRow, twoColumn);
            } else if (pxInDIP(desiredWidth) > pxInDIP(800) && isTablet(getBaseActivity()) && (board % 2 != 0) && ((board - 64) == numOfBoards) && ((board - 64) != 1)) {

                View v = new View(getBaseActivity());
                v.setMinimumWidth(20);
                boardMainRow.addView(v);

                LinearLayout boardLayout = new LinearLayout(getBaseActivity());
                boardLayout.setOrientation(LinearLayout.HORIZONTAL);
                boardLayout.setPadding(10, 10, 10, 10);
                boardLayout.setVisibility(View.INVISIBLE);
                TableRow.LayoutParams boardParams = new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
                boardLayout.setLayoutParams(boardParams);
                boardMainRow.addView(boardLayout);
            }

            //Adding board layout to Table
            boardMainTable.addView(boardMainRow);
        }
    }

    private void createBoard(final int numbersRequired, TableRow boardRow, boolean twoColumn) {
        final List<TextView> listTxts = new ArrayList<>();
        final TextView powerballTxt = new TextView(getBaseActivity());

        LinearLayout boardLayout = new LinearLayout(getBaseActivity());
        boardLayout.setOrientation(LinearLayout.HORIZONTAL);
        boardLayout.setBackgroundResource(R.drawable.board_background);
        boardLayout.setPadding(0, 0, 0, 10);

        TableRow.LayoutParams boardParams = new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        boardLayout.setLayoutParams(boardParams);

        /* Create a Button to be the row-content. */
        final BluDroidButton numberSelectBtn = new BluDroidButton(getBaseActivity());
        if (twoColumn) {
            numberSelectBtn.setText(getContext().getResources().getString(R.string.board, (int)(++board)));
        } else {
            numberSelectBtn.setText(getContext().getResources().getString(R.string.board, (int)board));
        }

//        numberSelectBtn.setBackgroundColor(getResources().getColor(R.color.white));
        // numberSelectBtn.setBackgroundResource(R.drawable.board_btn_bg);
        numberSelectBtn.setTextColor(getResources().getColor(R.color.white));
        numberSelectBtn.setTextSize(getSkinResources().getTextSize() - 4);
        numberSelectBtn.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        numberSelectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                getBaseActivity().resetTimer();
                //Params -> this board : list of textviews below : numbers required for board : Total Board Numbers Required : board Numbers Per Row : sort numbers(boolean)
                if (isPowerball) {
                    boardNumbersInTotal = 50;

                } else {
                    boardNumbersInTotal = 52;
                }
                boardNumberPerRow = 6;
                onClickBoard(numberSelectBtn, listTxts, powerballTxt, numbersRequired, boardNumbersInTotal, boardNumberPerRow, true);
            }
        });
        boardLayout.addView(numberSelectBtn);

        int i;
        for (i = 0; i < numbersRequired; i++) {
            TextView txt = new TextView(getBaseActivity());
            txt.setText("-");
            txt.setTextColor(getResources().getColor(R.color.darkBlue));
            txt.setTypeface(null, Typeface.BOLD);
            txt.setId(board + i);
            txt.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            txt.setGravity(Gravity.CENTER | Gravity.CENTER_VERTICAL);
            boardLayout.addView(txt);
            listTxts.add(txt);
        }

        if (isPowerball) {
            powerballTxt.setText("-");
            powerballTxt.setTextColor(getResources().getColor(R.color.darkBlue));
            powerballTxt.setBackgroundResource(R.drawable.disabled_powerball_background);
            powerballTxt.setTypeface(null, Typeface.BOLD);
            powerballTxt.setId(board + ++i);
            powerballTxt.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            powerballTxt.setGravity(Gravity.CENTER | Gravity.CENTER_VERTICAL);
            powerballTxt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    BaseActivity.logger.info(((TextView) v).getText());
                    getBaseActivity().resetTimer();
                    //Params -> this board : list of textviews below : numbers required for board : Total Board Numbers Required : board Numbers Per Row : sort numbers(boolean)
                    boardNumbersInTotal = 20;
                    boardNumberPerRow = 5;
                    onClickBoard(numberSelectBtn, listTxts, powerballTxt, 1, boardNumbersInTotal, boardNumberPerRow, true);
                }
            });
            powerballTxt.setEnabled(false);
            boardLayout.addView(powerballTxt);
        } else {
            powerballTxt.setBackgroundResource(R.drawable.disabled_powerball_background);
        }
        boardRow.addView(boardLayout);
    }

    private void onClickBoard(final BluDroidButton btn, final List<TextView> listTxts, final TextView powerball, final int numbersRequired, int boardNumbersInTotal, int boardNumberPerRow, final boolean sortRequired) {
        final int totalBoardNumbers = boardNumbersInTotal;
        int buttonNumber = 1;

        //Create scroller
        BluDroidScrollView scroll = new BluDroidScrollView(getBaseActivity());
        scroll.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scroll.setVerticalScrollBarEnabled(true);

        //Create main layout
        LinearLayout numberSelectorLayout = new LinearLayout(getBaseActivity());
        numberSelectorLayout.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        numberSelectorLayout.setBackgroundResource(R.drawable.board_background);
        numberSelectorLayout.setPadding(10, 10, 10, 10);
        numberSelectorLayout.setOrientation(LinearLayout.VERTICAL);

        //Create popup window
        popupWindow = new PopupWindow(scroll);
        popupWindow.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
        popupWindow.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        popupWindow.showAtLocation(scroll, Gravity.CENTER, 0, 0);
        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.BLACK));

        WindowManager wm = (WindowManager) getBaseActivity().getSystemService(Context.WINDOW_SERVICE);

        if (!Build.MODEL.contains("P1")) {
            try {
                WindowManager.LayoutParams p = (WindowManager.LayoutParams) scroll.getLayoutParams();
                p.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
                p.dimAmount = 0.5f;
                wm.updateViewLayout(scroll, p);
            } catch (Exception ignore) {
            }
        }


        //Create TableLayouts
        TableLayout numberTable = new TableLayout(getBaseActivity());
        TableLayout operationTable = new TableLayout(getBaseActivity());

        /* Create a new row to be added. */
        TableRow headerRow = new TableRow(getBaseActivity());
        headerRow.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(getBaseActivity());
        title.setText(btn.getText());
        title.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        title.setPadding(5, 0, 0, 0);
        title.setTextColor(getSkinResources().getBackgroundTextColor());
        title.setTypeface(null, Typeface.BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        title.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        headerRow.addView(title);
        numberTable.addView(headerRow, new TableLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        int sp = 15 / 2;

        final List<String> listSelected = new ArrayList<>();

        while (boardNumbersInTotal > 0) {
            if (buttonNumber <= this.boardNumbersInTotal) {
                TableRow numberRow = new TableRow(getBaseActivity());
                TableRow.LayoutParams rowParams = new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                numberRow.setLayoutParams(rowParams);

                for (int i = 0; i < boardNumberPerRow; i++) {

                    String btnText = String.valueOf(buttonNumber++);

                    final ToggleButton toggleNum = new ToggleButton(getBaseActivity());
                    toggleNum.setText(btnText);
                    toggleNum.setTextOn(btnText);
                    toggleNum.setTextOff(btnText);
                    TableRow.LayoutParams toggleNumParams = new TableRow.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
                    toggleNumParams.setMargins(sp, sp, sp, sp);
                    toggleNum.setLayoutParams(toggleNumParams);
                    //toggleNum.setBackgroundResource(R.drawable.ithuba_dark_half_empty_button);
                    toggleNum.setBackgroundResource(R.drawable.select_number_background_default);
                    toggleNum.setTextColor(getSkinResources().getBackgroundTextColor());
                    toggleNum.setTypeface(null, Typeface.BOLD);
                    toggleNum.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            getBaseActivity().resetTimer();
                            String messageNotAllow = getResources().getString(R.string.numbers_allowed, numbersRequired);
                            int listSize = listSelected.size();
                            if (isChecked) {
                                if (numbersRequired < listSize || numbersRequired == listSize) {
                                    boardMessage.setText(messageNotAllow);
                                    toggleNum.setChecked(false);
                                } else {
                                    //toggleNum.setBackgroundResource(R.drawable.ithuba_light_half_empty_button);
                                    toggleNum.setBackgroundResource(R.drawable.select_number_background);
                                    toggleNum.setTextColor(getSkinResources().getBackgroundTextColor());
                                    listSelected.add(String.valueOf(toggleNum.getText()));
                                    boardMessage.setText(getResources().getString(R.string.numbers_selected, listSize+1, numbersRequired));
                                }
                            } else {
                                if (listSelected.contains(String.valueOf(toggleNum.getText()))) {
                                    //toggleNum.setBackgroundResource(R.drawable.ithuba_dark_half_empty_button);
                                    toggleNum.setBackgroundResource(R.drawable.select_number_background_default);
                                    toggleNum.setTextColor(getSkinResources().getBackgroundTextColor());
                                    listSelected.remove(String.valueOf(toggleNum.getText()));
                                }
                                listSize = listSelected.size();
                                if (numbersRequired < listSize || numbersRequired == listSize) {
                                    boardMessage.setText(messageNotAllow);
                                } else {
                                    boardMessage.setText(getResources().getString(R.string.numbers_selected, listSize, numbersRequired));
                                }
                            }
                        }
                    });
                    if (listTxts != null) {
                        if (totalBoardNumbers == 20) {
                            if (powerball.getText().equals(toggleNum.getText())) {
                                toggleNum.setBackgroundResource(R.drawable.select_number_background);
                                //toggleNum.setBackgroundResource(R.drawable.ithuba_light_half_empty_button);
                                toggleNum.setTextColor(getSkinResources().getBackgroundTextColor());
                                toggleNum.setChecked(true);
                            }
                        } else {
                            for (TextView txt : listTxts) {
                                if (txt.getText().equals(toggleNum.getText())) {
                                    toggleNum.setBackgroundResource(R.drawable.select_number_background);
                                    //toggleNum.setBackgroundResource(R.drawable.ithuba_light_half_empty_button);
                                    toggleNum.setTextColor(getSkinResources().getBackgroundTextColor());
                                    toggleNum.setChecked(true);
                                }
                            }
                        }
                    }
                    numberRow.addView(toggleNum);
                    boardNumbersInTotal--;
                    int intOfToggle = Integer.parseInt(String.valueOf(toggleNum.getText()).trim());

                    if (intOfToggle > this.boardNumbersInTotal) {
                        toggleNum.setEnabled(false);
                        toggleNum.setBackgroundResource(0);
                        toggleNum.setText(" ");
                        toggleNum.setVisibility(View.INVISIBLE);
                    }
                }
                numberTable.addView(numberRow, new TableLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }
        }


        numberSelectorLayout.addView(numberTable);

        TableRow messageRow = new TableRow(getBaseActivity());
        TableRow.LayoutParams messageParams = new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        messageRow.setLayoutParams(messageParams);
        messageRow.setGravity(Gravity.CENTER);

        //Footer row
        TableRow footerRow = new TableRow(getBaseActivity());
        TableRow.LayoutParams footerParams = new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        footerRow.setLayoutParams(footerParams);
        footerRow.setGravity(Gravity.CENTER);

        TableRow.LayoutParams operationBtnParams = new TableRow.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT);
        operationBtnParams.setMargins(sp, sp, sp, sp);

        boardMessage = new TextView(getBaseActivity());
        boardMessage.setText("");
        boardMessage.setGravity(Gravity.CENTER | Gravity.CENTER_VERTICAL);
        boardMessage.setTextColor(getSkinResources().getBackgroundTextColor());
//        boardMessage.setTypeface(null, Typeface.BOLD);
        boardMessage.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        boardMessage.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        messageRow.addView(boardMessage);

        operationTable.addView(messageRow, new TableLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT));

        BluDroidButton acceptBtn = new BluDroidButton(getBaseActivity());
        acceptBtn.setText(getResources().getString(R.string.accept));
        acceptBtn.setGravity(Gravity.CENTER | Gravity.CENTER_VERTICAL);
        acceptBtn.setLayoutParams(operationBtnParams);
        acceptBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                getBaseActivity().resetTimer();
                List<Integer> finalList;
                if (!listSelected.isEmpty()) {
                    if (listSelected.size() < numbersRequired) {
                        String disp = getResources().getString(R.string.please_select_numbers, numbersRequired);
                        boardMessage.setText(disp);
                        getBaseActivity().createAlertDialog("Info", disp);
                    } else {
                        if (sortRequired) {
                            finalList = sorted(listSelected);
                        } else {
                            finalList = convertList(listSelected);
                        }
                        if (isPowerball) {
//                           /* For PowerBall, we can only select ONE number, so our list will only have ONE number, at index 0 */
                            if (totalBoardNumbers != 20) {
//                                //Powerball Numbers
                                PowerballNumberCollection powerballNumbers = new PowerballNumberCollection();
                                powerballNumbers.getNumbers().addAll(finalList);
                                captureUserSelection(String.valueOf(btn.getText()), powerballNumbers);

                                powerball.setEnabled(true);
                                powerball.setBackgroundResource(R.drawable.powerball_background);
                            } else {
                                //Actual Powerball
                                PowerballNumberCollection powerballOnly = new PowerballNumberCollection();
                                int ball = finalList.get(0);
                                powerballOnly.setPowerball(ball);
                                captureUserSelection(String.valueOf(btn.getText()), powerballOnly);
                            }
                        } else {
                            LottoNumberCollection lottoNumbers = new LottoNumberCollection();
                            lottoNumbers.getNumbers().addAll(finalList);
                            captureUserSelection(String.valueOf(btn.getText()), lottoNumbers);
                        }


                        if (!finalList.isEmpty()) {
                            if (isPowerball) {
                                if (finalList.size() == 5) {
                                    for (int k = 0; k < numbersRequired; k++) {
                                        listTxts.get(k).setText(String.valueOf(finalList.get(k)));
                                    }
                                } else if (finalList.size() == 6) {
                                    for (int k = 0; k < (numbersRequired + 1); k++) {
                                        if (k == 5) {
                                            powerball.setText(String.valueOf(finalList.get(k)));
                                        } else {
                                            listTxts.get(k).setText(String.valueOf(finalList.get(k)));
                                        }
                                    }
                                } else if (finalList.size() == 1) {
                                    powerball.setText(String.valueOf(finalList.get(0)));
                                } else {
                                    boardMessage.setText(getResources().getString(R.string.error_numbers_selected));
                                }
                            } else {
                                for (int k = 0; k < numbersRequired; k++) {
                                    listTxts.get(k).setText(String.valueOf(finalList.get(k)));
                                }
                            }
                        } else {
                            boardMessage.setText(getResources().getString(R.string.error_numbers_selected));
                            getBaseActivity().createAlertDialog(getResources().getString(R.string.error), getResources().getString(R.string.error_numbers_selected));
                        }
                        popupWindow.dismiss();
                    }
                }
            }
        });

        BluDroidButton cancelBtn = new BluDroidButton(getBaseActivity());
        cancelBtn.setText(getResources().getString(R.string.cancel));
        cancelBtn.setGravity(Gravity.CENTER | Gravity.CENTER_VERTICAL);
        cancelBtn.setLayoutParams(operationBtnParams);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                Log.e("MKError", "baseactivity: " + getBaseActivity());
                getBaseActivity().resetTimer();
                popupWindow.dismiss();
            }
        });

        footerRow.addView(cancelBtn, 0);
        footerRow.addView(acceptBtn, 1);

        operationTable.addView(footerRow, new TableLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        numberSelectorLayout.addView(operationTable);

        scroll.addView(numberSelectorLayout);
    }

    private List<Integer> sorted(List<String> listToSort) {
        List<Integer> listAsInt = new ArrayList<>();
        try {
            for (String s : listToSort) {
                int num = Integer.parseInt(s.trim());
                listAsInt.add(num);
            }
            Collections.sort(listAsInt);
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
            BaseActivity.logger.error("sorted exception" + nfe);
        }
        return listAsInt;
    }

    private List<Integer> convertList(List<String> listToConvert) {
        List<Integer> listAsInt = new ArrayList<>();
        try {
            for (String s : listToConvert) {
                int num = Integer.parseInt(s.trim());
                listAsInt.add(num);
            }
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
            BaseActivity.logger.error("convertList exception" + nfe);
        }
        return listAsInt;
    }

    private void captureUserSelection(String boardName, LottoNumberCollection newNumbers) {
        if (boardNumbers.containsKey(boardName)) {
            LottoNumberCollection previousNumbers = boardNumbers.get(boardName);

            // If numbers were captured, overwrite it.
            if (!newNumbers.getNumbers().isEmpty()) {
                previousNumbers.setNumbers(newNumbers.getNumbers());
            }

            if (newNumbers instanceof PowerballNumberCollection) {
                int newPowerBall = ((PowerballNumberCollection) newNumbers).getPowerball();

                if (newPowerBall > 0) {
                    ((PowerballNumberCollection) previousNumbers).setPowerball(newPowerBall);
                }
            }
        } else {
            boardNumbers.put(boardName, newNumbers);
        }
    }

    private void playPlus() {

        psPlayPlusBox.setTextSize(getSkinResources().getTextSize());
        if (name.contains("lotto")) {
            psPlayPlusBox.setText(getResources().getString(R.string.playLottoPlus));
        } else if (name.contains("powerball")) {
            psPlayPlusBox.setText(getResources().getString(R.string.playPowerballPlus));
        }

        psPlayPlusBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getBaseActivity().resetTimer();
                if (isChecked) {
                    // The toggle is enabled
                    yesNoCheckBox = "Yes";
                    psPlayPlus2Box.setEnabled(true);
                    psPlayPlus2Box.setTextColor(getSkinResources().getBackgroundTextColor());
                } else {
                    // The toggle is disabled
                    yesNoCheckBox = "No";
                    psPlayPlus2Box.setChecked(false);
                    psPlayPlus2Box.setEnabled(false);
                    psPlayPlus2Box.setTextColor(getResources().getColor(R.color.check_box_text_disabled));
                }
            }
        });

    }

    private void playPlus2() {

        if (name.contains("lotto")) {
            psPlayPlus2Box.setText(getResources().getString(R.string.playLottoPlus2));
        } else if (name.contains("powerball")) {
            psPlayPlus2Box.setVisibility(View.GONE);
            psPlayPlus2Box.setVisibility(View.GONE);
        }

        psPlayPlus2Box.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getBaseActivity().resetTimer();
                if (isChecked) {
                    // The toggle is enabled
                    yesNoCheckBox2 = "Yes";
                } else {
                    // The toggle is disabled
                    yesNoCheckBox2 = "No";
                }
            }
        });

    }

    private void play() {

        final BluDroidButton playBtn = rootView.findViewById(R.id.qpPlay);
        playBtn.setText(getResources().getString(R.string.play));

        playBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BaseActivity.logger.info(((BluDroidButton) view).getText());
                // Check that all boards are complete first
                getBaseActivity().resetTimer();
                passesChecks = false;
                boardChecks();
                if (boardChecks() && passesChecks) {
                    //ithubaAuth();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            playBtn.setEnabled(true);

                        }
                    }, 5000);
                    getBaseActivity().ithubaAuth(name, numOfBoards + "", numOfDraws + "",
                            String.valueOf(psPlayPlusBox.isChecked()), String.valueOf(psPlayPlus2Box.isChecked()), yesNoCheckBox, yesNoCheckBox2, passesChecks, boardNumbers);
                }
            }
        });

        BluDroidButton cancelBtn = rootView.findViewById(R.id.qpCancel);
        cancelBtn.setText(getResources().getString(R.string.cancel));
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BaseActivity.logger.info(((BluDroidButton) view).getText());
//                FragmentManager fm = getBaseActivity().getSupportFragmentManager();
//                FragmentTransaction ft = fm.beginTransaction();
//
                FragmentIthubaPSelect fragment = new FragmentIthubaPSelect();
                Bundle bundle = new Bundle();
                bundle.putString("thisScreen", this.getClass().getName());
                bundle.putString("name", name);

                fragment.setArguments(bundle);
//                ft.replace(R.id.content_frame, fragment);
//                ft.commit();

                getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, fragment, "FragmentIthubaPSelect").commit();
            }
        });

    }

    private boolean boardChecks() {
        if (boardNumbers.isEmpty()) {
            this.passesChecks = false;
            Toast.makeText(getBaseActivity(), "All Boards are empty!!!", Toast.LENGTH_SHORT).show();
        } else {
            if (numOfBoards != boardNumbers.size()) {
                int emptyBoards = numOfBoards - boardNumbers.size();
                if (emptyBoards == 1) {
                    Toast.makeText(getBaseActivity(), emptyBoards + " Board is still empty!!!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getBaseActivity(), emptyBoards + " Boards are still empty!!!", Toast.LENGTH_SHORT).show();
                }
                this.passesChecks = false;
            } else {
                for (String key : boardNumbers.keySet()) {
                    if (!boardNumbers.get(key).isComplete()) {
                        this.passesChecks = false;
                        if (isPowerball && boardNumbers.get(key).getNumbers().size() == 5) {
                            Toast.makeText(getBaseActivity(), key + "'s Powerball is missing", Toast.LENGTH_SHORT).show();
                            break;
                        } else {
                            Toast.makeText(getBaseActivity(), key + " contains an error", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    } else {
                        this.passesChecks = true;
                    }
                }
            }
        }
        return passesChecks;
    }

    @Override
    public boolean onBackPressed() {

//        FragmentIthubaPSelect fragment = new FragmentIthubaPSelect();
//        Bundle bundle = new Bundle();
//        bundle.putString("thisScreen", this.getClass().getName());
//        bundle.putString("name", name);
//
//        fragment.setArguments(bundle);
//        getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, fragment, "FragmentIthubaPSelect").commit();

        return true;
    }
}
