package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.magcard.BluDroidMagCardAsyncReponse;
import za.co.blts.magcard.MagCardData;


public class FragmentEskomOther extends BaseFragment implements BluDroidMagCardAsyncReponse {

    private final String TAG = this.getClass().getSimpleName();

    private String[] eskomOtherOptions = null;

    public FragmentEskomOther() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getBaseActivity().hideKeyboard();


        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_eskom_other, container, false);


    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        configureRecycler();

    }

    private void configureRecycler() {
        recycler = getActivity().findViewById(R.id.eskomOtherRecycler);
        recycler.setHasFixedSize(true);

        eskomOtherOptions = getResources().getStringArray(R.array.eskomOtherOptions);

        List<CardviewDataObject> list = allListItems();


        GridLayoutManager grid;

        if (getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            grid = new GridLayoutManager(getActivity(), 2);
        } else {
            grid = new GridLayoutManager(getActivity(), 1);
        }

        RecyclerView.LayoutManager manager = grid;

        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getActivity(), R.dimen.item_offset);
        recycler.addItemDecoration(itemDecoration);

        recycler.setLayoutManager(manager);

        adapter = new BluRecyclerAdapter(getBaseActivity(), list);

        recycler.setAdapter(adapter);

    }

    private List<CardviewDataObject> allListItems() {

        List<CardviewDataObject> allItems = new ArrayList<>();

        for (String eskomOtherOption : eskomOtherOptions) {
            Log.d(TAG, eskomOtherOption);
            allItems.add(new CardviewDataObject(eskomOtherOption, "", 0, getBaseActivity().getSkinResources().getButtonColor(), "", "eskomother", "eskomother"));

        }

        //index 3 is redeem token, only for Citaq and P1-4G
        if (Build.MODEL.startsWith("CITAQ") || Build.MODEL.startsWith("P1_4G")) {
            //and only if external encoder is connected
            if (!getBaseActivity().openMagEncoder()) {
                Log.d(TAG, "remove redeem token");
                allItems.remove(3);
            }
        } else {
            Log.d(TAG, "remove redeem token");
            allItems.remove(3);
        }

        return allItems;
    }


    @Override
    public void processFinish(String output) {
        if (getBaseActivity().alert != null) {
            getBaseActivity().alert.dismiss();
        }

        if (!getBaseActivity().magCardAction.equalsIgnoreCase("read")) {

            if (output.toLowerCase().contains("success")) {

                getBaseActivity().createMagCardAlertDialog("Mag Encoder", output);

                getBaseActivity().alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        getBaseActivity().magCardDataList.remove(0);

                        if (getBaseActivity().magCardDataList.size() > 0) {
                            getBaseActivity().cardNumber++;
                            getBaseActivity().isElectricityResponseFirstTime = false;
                            getMainActivity().results(getBaseActivity().electricityVoucherResponseMessage);
                        } else {
                            if (BaseActivity.isVoucherPrinted) {
                                getMainActivity().printElectricityVoucher();
                            } else {
                                getBaseActivity().cleanUp();
                                getBaseActivity().createPrintErrorConfirmation();
                            }
                        }

                        dialog.dismiss();
                    }
                });
                getBaseActivity().alert.show();
            } else {
                getBaseActivity().createMagCardAlertDialog("Mag Encoder", output + ", Would You like to retry?");
                getBaseActivity().alert.setPositiveOption("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        getBaseActivity().magCard.resetMsr();

                        MagCardData cardData = getBaseActivity().magCardDataList.get(0);
                        getBaseActivity().magCard.setTrack2(cardData.getTrack2());
                        getBaseActivity().magCard.setTrack3(cardData.getTrack3());

                        getBaseActivity().magCard.sendWriteCommand();
                        getBaseActivity().magCardAction = "write";
                        getBaseActivity().createNotifyAlertDialog("Mag Card", "Please swipe card to write " + getBaseActivity().cardNumber + "/" + getBaseActivity().tokensSize);
                    }
                });

                getBaseActivity().alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                getBaseActivity().alert.show();
            }
        }
    }
}
