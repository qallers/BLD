package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseAllEventsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseCategoriesMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseParentAllEventMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTicketProCategories extends TicketProRecycler implements NeedsAEONResults, TextWatcher {

    private final String TAG = this.getClass().getSimpleName();

    private ListView listView;
    private TextView txtEventCacheDate;

    private BluDroidTicketProAllEventsListAdapter ticketProAllEventsListAdapter;
    private ArrayList<TicketProResponseParentAllEventMessage> allEventstList;
    public boolean toBeCached = false;

    public FragmentTicketProCategories() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
//        authenticateForTicketProEvents();

        View rootView = inflater.inflate(R.layout.fragment_ticket_pro_categories, container, false);
        recycler = rootView.findViewById(R.id.bluRecycler);
        listView = rootView.findViewById(R.id.allEventsList);
        txtEventCacheDate = rootView.findViewById(R.id.txtEventCacheDate);
        txtEventCacheDate.setText("");

        EditText filterEditText = rootView.findViewById(R.id.search);
        filterEditText.addTextChangedListener(this);

        BluDroidButton btnReprint = rootView.findViewById(R.id.reprint);

        if (getBaseActivity().userLevel.equals("1")) {

            btnReprint.setEnabled(true);
            btnReprint.setBackgroundColor(getSkinResources().getButtonColor());

            btnReprint.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    BaseActivity.logger.info(((BluDroidButton) v).getText());
                    getBaseActivity().gotoFragment(new FragmentTicketProReprint(), "FragmentTicketProReprint");
                }
            });
        } else {
            btnReprint.setEnabled(false);
            btnReprint.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        }

//        getBaseActivity().toolbar.setNavigationDrawable();
//        getBaseActivity().toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                getBaseActivity().gotoMenuFragment();
//            }
//        });

        TicketProResponseCategoriesMessage categories = getBaseActivity().getCachedTicketproCategoriesData();

        if (getBaseActivity().ticketProAuthenticationResponseMessage == null || categories == null) {
            authenticateWithTicketPro();
        } else {
            getTicketProCategories();
        }

        return rootView;

    }

    @Override
    public void onDestroy() {
        if (listView != null) listView.setAdapter(null);
        super.onDestroy();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "onCreate");

        if (getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            grid = new GridLayoutManager(getActivity(), 3);
        } else {
            grid = new GridLayoutManager(getActivity(), 2);
        }

        String title = getActivity().getResources().getString(R.string.tickets);
        getActivity().setTitle(title);

        getBaseActivity().ticketProCategoryId = "";


    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    private void populateScreen() {
        setupRecycler();
    }

    private void populateAllEvents() {
        txtEventCacheDate.setText(new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(getBaseActivity().dateLastTicketproAllEventsCache()));
        //setupEventsRecycler();

        allEventstList = new ArrayList<>();
        if (getBaseActivity().ticketProResponseAllEventsMessage != null) {
            for (int i = 0; i < getBaseActivity().ticketProResponseAllEventsMessage.getData().getEvents().size(); i++) {
                String name = getBaseActivity().ticketProResponseAllEventsMessage.getData().getEvents().get(i).getName();

                //
                // sometimes Ticketpro sends back empty names in the categories
                // we have to ignore them
                //
                if (name.trim().isEmpty()) {
                    continue;
                }

                allEventstList.add(getBaseActivity().ticketProResponseAllEventsMessage.getData().getEvents().get(i));

            }
        }

        ticketProAllEventsListAdapter = new BluDroidTicketProAllEventsListAdapter(getBaseActivity(), R.layout.event_row_item, allEventstList);
        listView.setAdapter(ticketProAllEventsListAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                getBaseActivity().ticketProAllProEvent = allEventstList.get(position);

                //sold out check removed, since we working with cached data. Event might have had tickets returned, so request event details
                //FragmentTicketProEventDetails will fetch live data and display an error if the event is sold out

                getBaseActivity().gotoFragment(new FragmentTicketProEventDetails(), "FragmentTicketProEventDetails");
            }
        });

    }

    public void results(Object object) {

        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(Categories) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }
        if (object instanceof Socket) {
            BaseActivity.socket = (Socket) object;
        }

        //auth response handler added again, since we could arrive at this fragment directly from favourites, so bypass the auth in FragmentTickets
        if (object instanceof TicketProAuthenticationResponseMessage) {
            Log.d(TAG, "ticketpro authentication response");
            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProAuthenticationResponseMessage = (TicketProAuthenticationResponseMessage) object;

            if (getBaseActivity().ticketProAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

                getTicketProCategories();

            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProAuthenticationResponseMessage, true);
            }
        } else if (object instanceof TicketProResponseCategoriesMessage) {
            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProResponseCategoriesMessage = (TicketProResponseCategoriesMessage) object;

            if (getBaseActivity().ticketProResponseCategoriesMessage.getEvent().getEventCode().equals("0")) {
                if (toBeCached) {
                    getBaseActivity().cacheTicketproCategoriesData();
                }
                populateScreen();
                getAllTicketProEvents();
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProResponseCategoriesMessage, true);
            }
        } else if (object instanceof TicketProResponseAllEventsMessage) {
            getBaseActivity().dismissProgress();
            if (getBaseActivity().ticketProResponseCreateCartMessage == null) {
                getBaseActivity().closeAeonSocket(20);
            }
            // configureActionBar(getResources().getString(R.string.ticketpro) + ": " + categoryName.replaceAll("\n", " "));
            getBaseActivity().ticketProResponseAllEventsMessage = (TicketProResponseAllEventsMessage) object;
            // Do the caching here
            if (toBeCached) {
                getBaseActivity().cacheTicketproAllEventsData();
            }
            populateAllEvents();
            Log.i(TAG, "before createcartmessage: " + (getBaseActivity().ticketProResponseCreateCartMessage == null ? "null" : getBaseActivity().ticketProResponseCreateCartMessage.toString()));
            //
            // do not remove this log message
            // it iis used for testing purposes
            //
            Log.d(TAG, "TEST : RECEIVED TICKETPRO All EVENTS LIST");
        } else {
            getBaseActivity().dismissProgress();
            Log.d(TAG, "unknown return type");
        }
    }

    @Override
    public boolean onBackPressed() {
        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else {
            getBaseActivity().gotoFragment(new FragmentTickets(), "FragmentTickets");
        }
        return true;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (ticketProAllEventsListAdapter != null)
            ticketProAllEventsListAdapter.getFilter().filter(s);
        if (count > 0) {
            listView.setVisibility(View.VISIBLE);
            recycler.setVisibility(View.GONE);
        } else {
            listView.setVisibility(View.GONE);
            recycler.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}
