package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.text.InputFilter;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/27/2017.
 */

public class BluDroidTokenNumberEditText extends BluDroidEditText {

    private final String TAG = this.getClass().getSimpleName();

    public BluDroidTokenNumberEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        //setRawInputType(Configuration.KEYBOARD_UNDEFINED);
        setUp();
    }

    private void setUp() {


        maxLength = 20;
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(maxLength);
        setFilters(inputFilters);
        setOnFocusChangeListener(this);
        addTextChangedListener(this);


        setOnEditorActionListener(new OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent event) {
                Log.v(TAG, "actionId " + actionId + " event " + event);
                if (actionId == 0) {
                    setImeActionLabel(getResources().getString(R.string.next), EditorInfo.IME_ACTION_GO);
                    setInputType(InputType.TYPE_CLASS_TEXT);
                    return true;
                }
                if (actionId == 2) {
                    BaseActivity baseScreen = baseActivityWeakReference.get();
                    if (baseScreen != null) {
                        baseScreen.hideKeyboard();
                    }
                }
                return true;
            }
        });
    }

    public BluDroidTokenNumberEditText(BaseActivity context) {
        super(context);
        setUp();
        //setRawInputType(Configuration.KEYBOARD_UNDEFINED);
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        super.beforeTextChanged(s, start, count, after);
        if (count < 16 || count == 20) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                setErrorMessage(baseScreen.getResources().getString(R.string.tokenNumberLength));
            }
        } else {
            removeErrorMessage();
        }
    }

    @Override
    public boolean validate() {
        //BaseActivity.logger.info(": validate()");
        Log.d(TAG, "validate TokenNumber");

        String text = getText().toString().trim();
        boolean isvalidated;


        if (text.length() >= 16 && text.length() <= 20) {
            isvalidated = true;
            removeErrorMessage();
        } else {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                setErrorMessage(baseScreen.getResources().getString(R.string.tokenNumberLength));
            }
            isvalidated = false;
        }


        return isvalidated;
    }


}

