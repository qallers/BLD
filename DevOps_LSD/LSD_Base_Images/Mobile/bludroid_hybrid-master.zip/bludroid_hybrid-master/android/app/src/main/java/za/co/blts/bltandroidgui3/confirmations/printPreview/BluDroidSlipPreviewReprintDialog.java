package za.co.blts.bltandroidgui3.confirmations.printPreview;

import java.lang.ref.WeakReference;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;

public class BluDroidSlipPreviewReprintDialog extends BluDroidSlipPreviewDialog {
    private final String TAG = this.getClass().getSimpleName();
    private WeakReference<BaseActivity> baseActivityWeakReference;

    public BluDroidSlipPreviewReprintDialog(final BaseActivity activity, List<PrintJob> printJobs) {
        super(activity, printJobs);
        baseActivityWeakReference = new WeakReference<>(activity);
        setTitle("Reprint Preview");
        setup();
    }

    public void finishTransaction() {
        BaseActivity activity = baseActivityWeakReference.get();
        if (activity != null) {
            activity.dismissProgress();
        }
    }
}
