package za.co.blts.bltandroidgui3.dynamic;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import za.co.blts.bltandroidgui3.ActivityLanding;

public class DynamicBannerUtil {
    private static final String TAG = DynamicBannerUtil.class.getSimpleName();
    private File bannerDir;
    private WeakReference<ActivityLanding> activityLandingWeakReference;

    public DynamicBannerUtil(ActivityLanding context) {
        activityLandingWeakReference = new WeakReference<>(context);
        bannerDir = context.bannerDir;
    }

    public void updateBannerImages() {
        final ActivityLanding activityLanding = activityLandingWeakReference.get();
        if (activityLanding != null) {

            String bannerStr = activityLanding.getCachedBannerData();
            Log.d("DynamicBanner", "banner cache: " + bannerStr);

            String[] files = bannerDir.list();
            List<String> bannerFiles = new ArrayList<>();
            for (String s : files) {
                if (!s.endsWith(".txt")) {
                    bannerFiles.add(s);
                }
            }

            for (String s : bannerFiles) {
                Log.d("DynamicBanner", "banner file: " + s);
            }

            try {
                JSONObject cache = new JSONObject(bannerStr);
                JSONArray arr = cache.getJSONArray("banners");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject obj = arr.getJSONObject(i);
                    String id = obj.getString("id");
                    String url = obj.getString("url");
                    String fileName = getImage(id, url);
                    bannerFiles.remove(fileName);
                }
            } catch (JSONException je) {
                je.printStackTrace();
            }

            for (String s : bannerFiles) {
                Log.d("DynamicBanner", "deleting banner file: " + s);
                File file = new File(bannerDir, s);
                file.delete();
            }

        }
    }

    private String getImage(String id, String url) {
        Bitmap logo;

        try {
            final File logoFile = new File(bannerDir, id + ".png");

            if (!logoFile.exists()) {
                Log.d(TAG, "new banner, creating " + id + ".png");
                GetLogoAsync getLogoAsync = new GetLogoAsync();
                getLogoAsync.execute(url);
                logo = getLogoAsync.get();
                Log.d(TAG, "downloaded width=" + logo.getWidth() + " height=" + logo.getHeight());
                logo = Bitmap.createScaledBitmap(logo, 673, 309, false);
                // save the downloaded image
                FileOutputStream fos = new FileOutputStream(logoFile.getPath());
                logo.compress(Bitmap.CompressFormat.PNG, 100, fos);
                Log.d(TAG, "saved image, width=" + logo.getWidth() + " height=" + logo.getHeight());
                fos.flush();
                fos.close();
            } else {
                Log.d(TAG, "existing banner " + id + ".png");
            }
            return id + ".png";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private static Bitmap getLogoFromUrl(String urlStr) {
        try {
            Log.d(TAG, "downloading logo: " + urlStr);
            URL url = new URL(urlStr);
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            connection.setSSLSocketFactory(new TLSSocketFactory());
            connection.setDoInput(true);
            connection.setConnectTimeout(3000);
            connection.setReadTimeout(5000);
            connection.connect();
            InputStream input = connection.getInputStream();
            return BitmapFactory.decodeStream(input);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static class GetLogoAsync extends AsyncTask<String, Void, Bitmap> {
        private Bitmap results;

        @Override
        protected Bitmap doInBackground(String... params) {
            return getLogoFromUrl(params[0]);
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            //  return the bitmap by doInBackground and store in result
            results = bitmap;
        }
    }
}
