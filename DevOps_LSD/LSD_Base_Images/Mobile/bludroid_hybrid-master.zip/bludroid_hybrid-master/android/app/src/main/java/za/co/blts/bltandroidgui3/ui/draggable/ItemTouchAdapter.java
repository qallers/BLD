package za.co.blts.bltandroidgui3.ui.draggable;

/**
 * Created by warrenm on 2016/12/02.
 */

interface ItemTouchAdapter {
//    void onItemDismiss(int position);

    void onItemMove(int fromPosition, int toPosition);
}
