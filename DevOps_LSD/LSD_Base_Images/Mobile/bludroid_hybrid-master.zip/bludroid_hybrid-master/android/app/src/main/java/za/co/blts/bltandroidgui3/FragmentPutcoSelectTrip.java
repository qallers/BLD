package za.co.blts.bltandroidgui3;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


/**
 * A simple {@link Fragment} subclass.
 */


public class FragmentPutcoSelectTrip extends BaseFragment {
    private final String TAG = this.getClass().getSimpleName();

    public FragmentPutcoSelectTrip() {
        // Required empty public constructor

    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume");

        RelativeLayout routeDetailsLayout = getView().findViewById(R.id.routeDetails);
        routeDetailsLayout.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());
        TextView txtRouteCode = getView().findViewById(R.id.routeCode);
        TextView txtFrom = getView().findViewById(R.id.from);
        TextView txtTo = getView().findViewById(R.id.to);

        txtRouteCode.setText(getBaseActivity().routeCode);
        txtFrom.setText(getBaseActivity().departureName);
        txtTo.setText(getBaseActivity().destinationName);

        ListView listView = getView().findViewById(R.id.tripsList);

        final BluDroidPutcoTripsListAdapter putcoTripsListAdapter = new BluDroidPutcoTripsListAdapter(getBaseActivity(), R.layout.putco_trip_row_item, getBaseActivity().putcoTrips);
        listView.setAdapter(putcoTripsListAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                getBaseActivity().putcoTrip = getBaseActivity().putcoTrips.get(position);


                for (PutcoTrip trip : getBaseActivity().putcoTrips) {

                    trip.setSelected(false);
                    trip.setIconSelected(R.drawable.ic_checkbox_off);
                }

                if (!getBaseActivity().putcoTrip.isSelected()) {

                    getBaseActivity().putcoTrip.setSelected(true);
                    getBaseActivity().putcoTrip.setIconSelected(R.drawable.ic_checkbox_on);
                    getBaseActivity().routeIndex = position;

                } else {
                    getBaseActivity().putcoTrip.setSelected(false);
                    getBaseActivity().putcoTrip.setIconSelected(R.drawable.ic_checkbox_off);
                }
                putcoTripsListAdapter.notifyDataSetChanged();
                putcoTripsListAdapter.notifyDataSetInvalidated();

            }
        });

        getBaseActivity().resetTimer();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d(TAG, "onViewCreated");


    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_putco_select_trip, container, false);
    }


}
