package za.co.blts.bltandroidgui3;

import android.os.AsyncTask;
import android.util.Log;

import java.lang.ref.WeakReference;
import java.net.Socket;
import java.util.Date;

import za.co.blt.interfaces.external.exceptions.AEONCommsException;
import za.co.blt.interfaces.external.messages.airtimetopup.request.AirtimeTopupRequestMessage;
import za.co.blt.interfaces.external.messages.airtimetopup.request.AirtimeTopupRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.airtimetopup.request.AirtimeTopupRequestPurchaseMessage;
import za.co.blt.interfaces.external.messages.airtimetopup.request.WalletTopupRequestPurchaseMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsBluBillAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsPayAtAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestBluBillConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestBluBillGetInfoMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestPayAtAccountPaymentMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestPayAtConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestProductListMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestSapoAccountPaymentMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestSapoConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestSyntellAccountPaymentMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestSyntellConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsSapoAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsSyntellAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.bundles.request.BundlesAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.bundles.request.BundlesRequestDoBundleTopupMessage;
import za.co.blt.interfaces.external.messages.bundles.request.BundlesRequestGetProductListMessage;
import za.co.blt.interfaces.external.messages.bundles.request.BundlesRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestAvailabilityExtendedMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestAvailabilityMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestBookingCancellationMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestCarrierListMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestCityListMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestClassListMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestCompleteBookingMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestDestinationsListMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestPassengerTypeListMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestReserveSeatsMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestTitleListMessage;
import za.co.blt.interfaces.external.messages.chat4change.request.Chat4ChangeAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.chat4change.request.Chat4ChangeRequestListSuppliersMessage;
import za.co.blt.interfaces.external.messages.chat4change.request.Chat4ChangeRequestMessage;
import za.co.blt.interfaces.external.messages.chat4change.request.Chat4ChangeRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.confirmmeter.request.ConfirmMeterRequestMessage;
import za.co.blt.interfaces.external.messages.confirmmeter.response.ConfirmMeterResponseMessage;
import za.co.blt.interfaces.external.messages.electricity.request.ElectricityAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.request.ElectricityVoucherRequestMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.request.ElectricityVoucherRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.request.ElectricityVoucherRequestSoldMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.request.EmergencyLoanAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.request.EmergencyLoanRequestListAccountsMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.request.EmergencyLoanRequestLoanApplicationMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.request.EmergencyLoanRequestLoanConfirmationMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.request.EmergencyLoanRequestPrintEmergencyTopupMessage;
import za.co.blt.interfaces.external.messages.eskomdirectreprint.request.EskomDirectReprintAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.eskomdirectreprint.request.EskomDirectReprintRequestMessage;
import za.co.blt.interfaces.external.messages.international_airtime.request.InterAirAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.international_airtime.request.InterAirRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.ithuba.request.IthubaAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.ithuba.request.IthubaRequestItbConfirmMessage;
import za.co.blt.interfaces.external.messages.ithuba.request.IthubaRequestItbLotteryMessage;
import za.co.blt.interfaces.external.messages.ithuba.request.IthubaRequestItbPowerballMessage;
import za.co.blt.interfaces.external.messages.ithuba.request.IthubaRequestItbPrintedMessage;
import za.co.blt.interfaces.external.messages.login.request.LoginRequestMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.request.MerchantTransferAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.request.MerchantTransferRequestConfirmMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.request.MerchantTransferRequestGetInfoMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.request.MerchantTransferRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.moneytransfer.request.MoneyTransferAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.moneytransfer.request.MoneyTransferRequestCashInMessage;
import za.co.blt.interfaces.external.messages.moneytransfer.request.MoneyTransferRequestCashOutMessage;
import za.co.blt.interfaces.external.messages.moneytransfer.request.MoneyTransferRequestPreAuthMessage;
import za.co.blt.interfaces.external.messages.moneytransfer.request.MoneyTransferRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.multiplevouchers.request.MultipleVouchersAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.multiplevouchers.request.MultipleVouchersRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusCancelTicketRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusCheckoutRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusConfirmCancelTicketRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusConfirmCheckoutRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusFindTicketRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusGetCustomerRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusListCarriersRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusListStopsRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusLookupDestinationsRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusLookupFaresRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusUpdateCustomerRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusValidateSvcRequestMessage;
import za.co.blt.interfaces.external.messages.profitdisplay.request.ProfitDisplayRequestMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsAccountInfoAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestAccountListMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestBatchMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestEndShiftMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestInvoiceListMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestPrintInvoiceMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestPrintShiftMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestProfitMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestShiftListMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestShiftProfitMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestStatementMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestTransListMessage;
import za.co.blt.interfaces.external.messages.reprint.request.ReprintAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.reprint.request.ReprintRequestListByDateMessage;
import za.co.blt.interfaces.external.messages.reprint.request.ReprintRequestReprintMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestBoxNumberSIMSMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestChangeOwnerMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestCheckUserMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestMultipleRegisterMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestQueryMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestRegisterMessage;
import za.co.blt.interfaces.external.messages.soldunprinted.request.SoldUnprintedRequestMessage;
import za.co.blt.interfaces.external.messages.tender.request.TenderAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.tender.request.TenderRequestMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestAllEventsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestAllLocationsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestAllowedProductsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestBookRouteMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestCategoriesMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestCheckOutMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestClearCartMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestCreateCartMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestEventDetailsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestEventsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPaymentMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPossibleDestinationsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPrintMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoAutoCancelMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoCheckOutMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoCreateCartMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoDoCompleteTrxMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoPaymentMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoPrintMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestReservedSeatsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestRouteMessage;
import za.co.blt.interfaces.external.messages.unprinted.request.UnprintedAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.unprinted.request.UnprintedRequestMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersRequestAddUserMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersRequestListMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersRequestListPermissionTypesMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersRequestUpdateUserMessage;
import za.co.blt.interfaces.external.messages.voucher.request.VoucherAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.voucher.request.VoucherRequestMessage;
import za.co.blt.interfaces.external.messages.voucher.request.VoucherRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.voucherlist.request.VoucherListRequestMessage;
import za.co.blt.interfaces.external.services.AEONService;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AEON_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_USE_SSL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRANSACTION_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_SSL;


class AEONAsyncTask extends AsyncTask<Object, Object, Object> {

    private final String TAG = this.getClass().getSimpleName();

    WeakReference<BaseActivity> baseActivityWeakReference;
    private WeakReference<BaseFragment> baseFragmentWeakReference;


    private Socket socket;

    private AEONService service;

    private static Date lastContact = null;

    //
    // minutes
    //
    private static long AEONTimeout = -1;

    private boolean updatedSocket;

    private AEONTimer aeonTimer = null;

    private Status taskStatus;

    public AEONAsyncTask(BaseActivity baseScreen) {
        taskStatus = Status.PENDING;
        this.baseActivityWeakReference = new WeakReference<>(baseScreen);
        Log.d(TAG, "new AEONAsyncTask: " + this.hashCode());
    }

    public AEONAsyncTask(BaseFragment baseFragment) {
        taskStatus = Status.PENDING;
        this.baseFragmentWeakReference = new WeakReference<>(baseFragment);
        this.baseActivityWeakReference = new WeakReference<>((BaseActivity) baseFragment.getActivity());
        Log.d(TAG, "new AEONAsyncTask: " + this.hashCode());
    }

    @Override
    protected void onPreExecute() {
        taskStatus = Status.PENDING;
        super.onPreExecute();
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {

            try {
                int timeout = Integer.parseInt(baseScreen.getPreference(PREF_TRANSACTION_TIMEOUT));
                timeout *= 1000;
                aeonTimer = new AEONTimer(this, timeout, 60000);
                aeonTimer.start();
                Log.d(TAG, "AEONtimer started for " + baseScreen + " with timeout " + timeout);
            } catch (Exception exception) {
                Log.d(TAG, "timer exception " + exception);
            }
        }
    }

    private void getAEONService() {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {


            Log.d(TAG, "useSSL is " + baseScreen.getPreference(PREF_USE_SSL));
            if (baseScreen.getPreference(PREF_USE_SSL).equals(PREF_TRUE)) {
                service = new AEONService(true);
            } else {

                try {
                    Log.d(TAG, "no gray logger stuff");
                    if (BaseActivity.logger == null)
                        service = new AEONService(false);
                    else
                        service = new AEONService(BaseActivity.logger, false);
                    Log.d(TAG, "service is " + service);
                } catch (Exception exception) {
                    Log.d(TAG, "problem creating service " + exception);
                }
            }
        }
    }

    //
// if there is only one parameter, it logs into aeon
// otherwise there must be three parameters representing
//      basescreen, socket, object to send
//
    @Override
    protected Object doInBackground(Object... params) {
        taskStatus = Status.RUNNING;
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {

            try {
                Log.d(TAG, "doInBackground with " + params.length + " params");
                Log.d(TAG, "params[0] is " + params[0]);
                if (params[0] instanceof BaseFragment) {
                    baseScreen = ((BaseFragment) params[0]).getBaseActivity();
                } else {
                    baseScreen = (BaseActivity) params[0];
                }

                updatedSocket = false;
                Log.d(TAG, "socket = " + socket);
                if (socket != null)
                    Log.d(TAG, "socket closed? " + socket.isClosed());

                // need to reconnect
                if (socket == null || socket.isClosed()) {
                    Log.d(TAG, "updated socket set to true");
                    updatedSocket = true;
                }
                //Log.d(TAG, "last contact " + lastContact);
                if (AEONTimeout == -1) {
                    try {
                        String timeout = baseScreen.getPreference(PREF_AEON_TIMEOUT);
                        AEONTimeout = Integer.valueOf(timeout);
                        Log.d(TAG, "AEONTimeout is set to " + AEONTimeout);
                    } catch (Exception exception) {
                        Log.v(TAG, "number format " + exception);
                        AEONTimeout = 5 * 60;
                    }
                }
                if (lastContact == null) {
                    lastContact = new Date();
                } else {
                    Date now = new Date();
                    Log.d(TAG, "last contact " + lastContact + " now " + now);
                    long elapsedMillis = now.getTime() - lastContact.getTime();
                    long elapsedSeconds = elapsedMillis / 1000;
                    Log.d(TAG, "elapsed Millis " + elapsedMillis);
                    Log.d(TAG, "elapsed Seconds " + elapsedSeconds);
                }
                try {
                    // this is a proccess request
                    if (params.length > 1) {
                        Object object = params[1];
                        if (object instanceof LoginRequestMessage) {
                            openSocket();
                            LoginRequestMessage request = (LoginRequestMessage) object;
                            return service.login(socket, request);
                        }
                        if (object instanceof RicaAuthenticationRequestMessage) {
                            Log.d("AeonAsyncTask", "1-RicaAuthenticationRequestMessage: " + object);
                            openSocketRica();
                            RicaAuthenticationRequestMessage request = (RicaAuthenticationRequestMessage) object;
                            return service.prepareRica(socket, request);
                        }
                        if (object instanceof Socket) {
                            if (params.length == 2) {
                                //LB Socket socket = (Socket) object;
                                socket = (Socket) object;
                                getAEONService(); //service = new AEONService();
                                service.closeSocket(socket);
                                Log.d(TAG, "socket closed returning null-OK");
                                return socket;
                            } else {
                                socket = (Socket) object;
                                getAEONService(); //service = new AEONService();

                                Object request = params[2];

                                if (request instanceof ProfitDisplayRequestMessage) {
                                    Log.d(TAG, "profitdisplay");
                                    openSocket();
                                    return service.getProfitDisplay(socket, (ProfitDisplayRequestMessage) request);

                                } else if (request instanceof MultipleVouchersAuthenticationRequestMessage) {
                                    Log.d(TAG, "mutliplevouchers");
                                    openSocket();
                                    return service.getMultipleVouchers(socket, (MultipleVouchersAuthenticationRequestMessage) request);

                                } else if (request instanceof MultipleVouchersRequestPrintedMessage) {
                                    Log.d(TAG, "mutliplevouchersPrinted");
                                    openSocket();
                                    return service.printMultipleVouchers(socket, (MultipleVouchersRequestPrintedMessage) request);

                                } else if (request instanceof AirtimeTopupRequestMessage) {
                                    Log.d(TAG, "airtimeTopupRequestMessage");
                                    openSocket();
                                    return service.prepareAirtimeTopup(socket, (AirtimeTopupRequestMessage) request);

                                } else if (request instanceof AirtimeTopupRequestPurchaseMessage) {
                                    Log.d(TAG, "airtimeTopupRequestPurchaseMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.purchaseAirtimeTopup(socket, (AirtimeTopupRequestPurchaseMessage) request);

                                } else if (request instanceof WalletTopupRequestPurchaseMessage) {
                                    Log.d(TAG, "WalletTopupRequestPurchaseMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.purchaseWalletTopup(socket, (WalletTopupRequestPurchaseMessage) request);

                                } else if (request instanceof AirtimeTopupRequestPrintedMessage) {
                                    Log.d(TAG, "airtimeTopupRequestPrintedMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.printedAirtimeTopup(socket, (AirtimeTopupRequestPrintedMessage) request);

                                } else if (request instanceof Chat4ChangeAuthenticationRequestMessage) {
                                    Log.d(TAG, "Chat4ChangeAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareChat4Change(socket, (Chat4ChangeAuthenticationRequestMessage) request);

                                } else if (request instanceof Chat4ChangeRequestListSuppliersMessage) {
                                    Log.d(TAG, "Chat4ChangeRequestListSuppliersMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.listChat4ChangeSuppliers(socket, (Chat4ChangeRequestListSuppliersMessage) request);

                                } else if (request instanceof VoucherAuthenticationRequestMessage) {
                                    Log.d(TAG, "VoucherAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareVoucherList(socket, (VoucherAuthenticationRequestMessage) request);

                                } else if (request instanceof Chat4ChangeRequestMessage) {
                                    Log.d(TAG, "Chat4ChanageRequestMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.purchaseChat4Change(socket, (Chat4ChangeRequestMessage) request);

                                } else if (request instanceof Chat4ChangeRequestPrintedMessage) {
                                    Log.d(TAG, "Chat4ChanageRequestPrintedMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.printChat4Change(socket, (Chat4ChangeRequestPrintedMessage) request);

                                } else if (request instanceof VoucherListRequestMessage) {
                                    Log.d(TAG, "VoucherListRequestMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.voucherList(socket, (VoucherListRequestMessage) request);

                                } else if (request instanceof VoucherRequestMessage) {
                                    Log.d(TAG, "VoucherRequestMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.purchaseVoucher(socket, (VoucherRequestMessage) request);

                                } else if (request instanceof VoucherRequestPrintedMessage) {
                                    Log.d(TAG, "VoucherRequestPrintedMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.printVoucher(socket, (VoucherRequestPrintedMessage) request);

                                } else if (request instanceof ConfirmMeterRequestMessage) {
                                    Log.d(TAG, "ConfirmMeterRequestMessage");
                                    return service.confirmMeter(socket, (ConfirmMeterRequestMessage) request);

                                } else if (request instanceof ElectricityAuthenticationRequestMessage) {
                                    Log.d(TAG, "ElectricityAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareElectricity(socket, (ElectricityAuthenticationRequestMessage) request);

                                } else if (request instanceof ElectricityVoucherRequestMessage) {
                                    Log.d(TAG, "ElectricityVoucherRequestMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.buyMeteredElectricity(socket, (ElectricityVoucherRequestMessage) request);

                                } else if (request instanceof ElectricityVoucherRequestPrintedMessage) {
                                    Log.d(TAG, "ElectricityVoucherRequestPrintedMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.printedElectricity(socket, (ElectricityVoucherRequestPrintedMessage) request);

                                } else if (request instanceof ElectricityVoucherRequestSoldMessage) {
                                    Log.d(TAG, "ElectricityVoucherRequestSoldMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.soldElectricity(socket, (ElectricityVoucherRequestSoldMessage) request);

                                } else if (request instanceof TicketProAuthenticationRequestMessage) {
                                    Log.d(TAG, "TicketProAuthenticationRequestMessage");
                                    openSocket();
                                    //getAEONService(); //service = new AEONService();
                                    return service.prepareTicketPro(socket, (TicketProAuthenticationRequestMessage) request);

                                } else if (request instanceof TicketProRequestAllowedProductsMessage) {
                                    Log.d(TAG, "TicketProRequestAllowedProductsMessage");
                                    return service.allowedProducts(socket, (TicketProRequestAllowedProductsMessage) request);

                                } else if (request instanceof TicketProRequestAllLocationsMessage) {
                                    Log.d(TAG, "TicketProRequestAllLocationsMessage");
                                    return service.allLocations(socket, (TicketProRequestAllLocationsMessage) request);

                                } else if (request instanceof TicketProRequestPossibleDestinationsMessage) {
                                    Log.d(TAG, "TicketProRequestPossibleDestinationsMessage");
                                    return service.possibleDestinations(socket, (TicketProRequestPossibleDestinationsMessage) request);

                                } else if (request instanceof TicketProRequestRouteMessage) {
                                    Log.d(TAG, "TicketProRequestRouteMessage");
                                    return service.route(socket, (TicketProRequestRouteMessage) request);

                                } else if (request instanceof TicketProRequestBookRouteMessage) {
                                    Log.d(TAG, "TicketProRequestBookRouteMessage");
                                    return service.bookRoute(socket, (TicketProRequestBookRouteMessage) request);

                                } else if (request instanceof TicketProRequestPutcoCheckOutMessage) {
                                    Log.d(TAG, "TicketProRequestPutcoCheckOutMessage");
                                    return service.putcoCheckOut(socket, (TicketProRequestPutcoCheckOutMessage) request);

                                } else if (request instanceof TicketProRequestPutcoPaymentMessage) {
                                    Log.d(TAG, "TicketProRequestPutcoPaymentMessage");
                                    return service.putcoPayment(socket, (TicketProRequestPutcoPaymentMessage) request);

                                } else if (request instanceof TicketProRequestPutcoPrintMessage) {
                                    Log.d(TAG, "TicketProRequestPutcoPrintMessage");
                                    return service.putcoPrint(socket, (TicketProRequestPutcoPrintMessage) request);

                                } else if (request instanceof TicketProRequestPutcoDoCompleteTrxMessage) {
                                    Log.d(TAG, "TicketProRequestPutcoDoCompleteTrxPutcoMessage");
                                    return service.putcoDoCompleteTrx(socket, (TicketProRequestPutcoDoCompleteTrxMessage) request);

                                } else if (request instanceof TicketProRequestPutcoCreateCartMessage) {
                                    Log.d(TAG, "TicketProRequestPutcoCreateCartMessage");
                                    return service.putcoCreateCart(socket, (TicketProRequestPutcoCreateCartMessage) request);

                                } else if (request instanceof TicketProRequestPutcoAutoCancelMessage) {
                                    Log.d(TAG, "TicketProRequestPutcoAutoCancelMessage");
                                    openSocket();
                                    return service.putcoAutoCancel(socket, (TicketProRequestPutcoAutoCancelMessage) request);

                                } else if (request instanceof TicketProRequestCreateCartMessage) {
                                    Log.d(TAG, "TicketProRequestCreateCartMessage");
                                    return service.createTicketProCart(socket, (TicketProRequestCreateCartMessage) request);

                                } else if (request instanceof TicketProRequestCategoriesMessage) {
                                    Log.d(TAG, "TicketProRequestCategoriesMessage");
                                    return service.getCategories(socket, (TicketProRequestCategoriesMessage) request);

                                } else if (request instanceof TicketProRequestEventsMessage) {
                                    Log.d(TAG, "TicketProRequestEventsMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getEvents(socket, (TicketProRequestEventsMessage) request);

                                } else if (request instanceof TicketProRequestAllEventsMessage) {
                                    Log.d(TAG, "TicketProRequestAllEventsMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getAllEvents(socket, (TicketProRequestAllEventsMessage) request);

                                } else if (request instanceof TicketProRequestEventDetailsMessage) {
                                    Log.d(TAG, "TicketProRequestEventDetailsMessage");
                                    return service.getEventDetails(socket, (TicketProRequestEventDetailsMessage) request);

                                } else if (request instanceof TicketProRequestReservedSeatsMessage) {
                                    Log.d(TAG, "TicketProRequestReservedSeatsMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.reserveSeats(socket, (TicketProRequestReservedSeatsMessage) request);

                                } else if (request instanceof TicketProRequestClearCartMessage) {
                                    Log.d(TAG, "TicketProRequestClearCartMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.clearCart(socket, (TicketProRequestClearCartMessage) request);

                                } else if (request instanceof TicketProRequestCheckOutMessage) {
                                    Log.d(TAG, "TicketProRequestCheckOutMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.checkOut(socket, (TicketProRequestCheckOutMessage) request);

                                } else if (request instanceof TicketProRequestPaymentMessage) {
                                    Log.d(TAG, "TicketProRequestPaymentMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.checkOut(socket, (TicketProRequestPaymentMessage) request);

                                }
                                //
                                // if the ticketpro request is for an xml print, return TicketProResponsePrintMessage
                                // if the ticketpro request is for an ezpl print, return TicketProResponsePrintEZPLMessage
                                else if (request instanceof TicketProRequestPrintMessage) {
                                    Log.d(TAG, "TicketProRequestPrintMessage");
                                    TicketProRequestPrintMessage ticketProRequest = (TicketProRequestPrintMessage) request;
                                    if (ticketProRequest.getEvent().getFormat().equals("xml")) {
                                        return service.print(socket, (TicketProRequestPrintMessage) request);
                                    } else if (ticketProRequest.getEvent().getFormat().equals("ezpl")) {
                                        return service.printEZPL(socket, (TicketProRequestPrintMessage) request);
                                    }

                                } else if (request instanceof TenderRequestMessage) {
                                    Log.d(TAG, "TicketProRequestPrintMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.tender(socket, (TenderRequestMessage) request);

                                } else if (request instanceof TenderAuthenticationRequestMessage) {
                                    Log.d(TAG, "TicketProRequestPrintMessage");
                                    openSocket();
                                    return service.prepareTender(socket, (TenderAuthenticationRequestMessage) request);

                                } else if (request instanceof BillPaymentsAuthenticationRequestMessage) {
                                    Log.d(TAG, "BillPaymentsAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareBillPayments(socket, (BillPaymentsAuthenticationRequestMessage) request);

                                } else if (request instanceof BillPaymentsRequestProductListMessage) {
                                    Log.d(TAG, "BillPaymentsRequestProductListMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getBillPaymentsProductList(socket, (BillPaymentsRequestProductListMessage) request);

                                } else if (request instanceof BillPaymentsSapoAuthenticationRequestMessage) {
                                    Log.d(TAG, "BillPaymentsSapoAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareSapoAccountPayment(socket, (BillPaymentsSapoAuthenticationRequestMessage) request);

                                } else if (request instanceof BillPaymentsRequestSapoAccountPaymentMessage) {
                                    Log.d(TAG, "BillPaymentsRequestSapoAccountPaymentMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getBillPaymentsSapoAccountPayment(socket, (BillPaymentsRequestSapoAccountPaymentMessage) request);

                                } else if (request instanceof BillPaymentsRequestSapoConfirmMessage) {
                                    Log.d(TAG, "BillPaymentsRequestSapoConfirmMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.confirmBillPaymentsSapoAccountPayment(socket, (BillPaymentsRequestSapoConfirmMessage) request);

                                } else if (request instanceof BillPaymentsPayAtAuthenticationRequestMessage) {
                                    Log.d(TAG, "BillPaymentsPayAtAuthenticationRequestMessage");
                                    openSocket();
                                    return service.preparePayAtAccountPayment(socket, (BillPaymentsPayAtAuthenticationRequestMessage) request);

                                } else if (request instanceof BillPaymentsRequestPayAtAccountPaymentMessage) {
                                    Log.d(TAG, "BillPaymentsRequestPayAtAccountPaymentMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getBillPaymentsPayAtAccountPayment(socket, (BillPaymentsRequestPayAtAccountPaymentMessage) request);

                                } else if (request instanceof BillPaymentsRequestPayAtConfirmMessage) {
                                    Log.d(TAG, "BillPaymentsRequestPayAtConfirmMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.confirmBillPaymentsPayAtAccountPayment(socket, (BillPaymentsRequestPayAtConfirmMessage) request);

                                } else if (request instanceof BillPaymentsBluBillAuthenticationRequestMessage) {
                                    Log.d(TAG, "BillPaymentsBluBillAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareBluBillAccountPayment(socket, (BillPaymentsBluBillAuthenticationRequestMessage) request);

                                } else if (request instanceof BillPaymentsRequestBluBillGetInfoMessage) {
                                    Log.d(TAG, "BillPaymentsRequestBluBillGetInfoMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getBluBillInfo(socket, (BillPaymentsRequestBluBillGetInfoMessage) request);

                                } else if (request instanceof BillPaymentsRequestBluBillConfirmMessage) {
                                    Log.d(TAG, "BillPaymentsRequestBluBillConfirmMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getBluBillConfirm(socket, (BillPaymentsRequestBluBillConfirmMessage) request);

                                } else if (request instanceof UsersAuthenticationRequestMessage) {
                                    Log.d(TAG, "UsersAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareUsers(socket, (UsersAuthenticationRequestMessage) request);

                                } else if (request instanceof UsersRequestListMessage) {
                                    Log.d(TAG, "UsersRequestListMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getUsers(socket, (UsersRequestListMessage) request);

                                } else if (request instanceof UsersRequestListPermissionTypesMessage) {
                                    Log.d(TAG, "UsersRequestListPermissionTypesMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getPermissions(socket, (UsersRequestListPermissionTypesMessage) request);

                                } else if (request instanceof UsersRequestAddUserMessage) {
                                    Log.d(TAG, "UsersRequestAddUserMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.addUser(socket, (UsersRequestAddUserMessage) request);

                                } else if (request instanceof UsersRequestUpdateUserMessage) {
                                    Log.d(TAG, "UsersRequestUpdateUserMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.updateUser(socket, (UsersRequestUpdateUserMessage) request);

                                } else if (request instanceof ReportsAuthenticationRequestMessage) {
                                    Log.d(TAG, "ReportsAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareReports(socket, (ReportsAuthenticationRequestMessage) request);

                                } else if (request instanceof ReportsRequestBatchMessage) {
                                    Log.d(TAG, "ReportsRequestBatchMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getBatchReport(socket, (ReportsRequestBatchMessage) request);

                                } else if (request instanceof ReportsRequestShiftListMessage) {
                                    Log.d(TAG, "ReportsRequestShiftListMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getShiftList(socket, (ReportsRequestShiftListMessage) request);

                                } else if (request instanceof ReportsRequestPrintShiftMessage) {
                                    Log.d(TAG, "ReportsRequestPrintShiftMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getShiftReport(socket, (ReportsRequestPrintShiftMessage) request);

                                } else if (request instanceof ReportsRequestTransListMessage) {
                                    Log.d(TAG, "ReportsRequestTransListMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getTransReport(socket, (ReportsRequestTransListMessage) request);

                                } else if (request instanceof ReportsRequestAccountListMessage) {
                                    Log.d(TAG, "ReportsRequestAccountListMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getAccountList(socket, (ReportsRequestAccountListMessage) request);

                                } else if (request instanceof ReportsAccountInfoAuthenticationRequestMessage) {
                                    Log.d(TAG, "ReportsAccountInfoAuthenticationRequestMessage");
                                    openSocket();
                                    return service.getAccountInfo(socket, (ReportsAccountInfoAuthenticationRequestMessage) request);

                                } else if (request instanceof ReportsRequestEndShiftMessage) {
                                    Log.d(TAG, "ReportsRequestEndShiftMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.endShift(socket, (ReportsRequestEndShiftMessage) request);

                                } else if (request instanceof ReportsRequestProfitMessage) {
                                    Log.d(TAG, "ReportsRequestProfitMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getProfit(socket, (ReportsRequestProfitMessage) request);

                                } else if (request instanceof ReportsRequestShiftProfitMessage) {
                                    Log.d(TAG, "ReportsRequestShiftProfitMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getShiftProfit(socket, (ReportsRequestShiftProfitMessage) request);

                                } else if (request instanceof ReportsRequestStatementMessage) {
                                    Log.d(TAG, "ReportsRequestStatementMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getStatement(socket, (ReportsRequestStatementMessage) request);

                                } else if (request instanceof ReportsRequestInvoiceListMessage) {
                                    Log.d(TAG, "ReportsRequestInvoiceListMessage");
                                    //getAEONService();
                                    //service = new AEONService();
                                    return service.getInvoiceList(socket, (ReportsRequestInvoiceListMessage) request);

                                } else if (request instanceof ReportsRequestPrintInvoiceMessage) {
                                    Log.d(TAG, "ReportsRequestPrintInvoiceMessage");
//                openSocket();
                                    return service.getPrintInvoice(socket, (ReportsRequestPrintInvoiceMessage) request);

                                } else if (request instanceof BundlesAuthenticationRequestMessage) {
                                    Log.d(TAG, "BundlesAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareBundles(socket, (BundlesAuthenticationRequestMessage) request);

                                } else if (request instanceof BundlesRequestGetProductListMessage) {
                                    Log.d(TAG, "BundlesRequestGetProductListMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getBundleProductList(socket, (BundlesRequestGetProductListMessage) request);

                                } else if (request instanceof BundlesRequestDoBundleTopupMessage) {
                                    Log.d(TAG, "BundlesRequestDoBundleTopupMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.doBundleTopup(socket, (BundlesRequestDoBundleTopupMessage) request);

                                } else if (request instanceof BundlesRequestPrintedMessage) {
                                    Log.d(TAG, "BundlesRequestPrintedMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.printedBundle(socket, (BundlesRequestPrintedMessage) request);

                                } else if (request instanceof RicaAuthenticationRequestMessage) {
                                    Log.d("AeonAsyncTask", "RicaAuthenticationRequestMessage: " + request);
                                    openSocketRica();
                                    return service.prepareRica(socket, (RicaAuthenticationRequestMessage) request);

                                } else if (request instanceof RicaRequestCheckUserMessage) {
                                    Log.d(TAG, "RicaRequestCheckUserMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.checkUser(socket, (RicaRequestCheckUserMessage) request);

                                } else if (request instanceof RicaRequestQueryMessage) {
                                    Log.d(TAG, "RicaRequestQueryMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.query(socket, (RicaRequestQueryMessage) request);
                                }

                                //
                                // order of next two are important.  MultipleRegister must
                                // be tested before Register
                                //
                                else if (request instanceof RicaRequestMultipleRegisterMessage) {
                                    Log.d(TAG, "RicaRequestMultipleRegisterMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.registerMultiple(socket, (RicaRequestMultipleRegisterMessage) request);

                                } else if (request instanceof RicaRequestChangeOwnerMessage) {
                                    Log.d(TAG, "RicaRequestChangeOwnerMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.changeOwner(socket, (RicaRequestChangeOwnerMessage) request);

                                } else if (request instanceof RicaRequestRegisterMessage) {
                                    Log.d(TAG, "RicaRequestRegisterMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.register(socket, (RicaRequestRegisterMessage) request);

                                } else if (request instanceof RicaRequestBoxNumberSIMSMessage) {
                                    Log.d(TAG, "RicaRequestBoxNumberSIMSMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.boxNumberMessage(socket, (RicaRequestBoxNumberSIMSMessage) request);

                                } else if (request instanceof BillPaymentsSyntellAuthenticationRequestMessage) {
                                    Log.d(TAG, "BillPaymentsSyntellAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareSyntellAccountPayment(socket, (BillPaymentsSyntellAuthenticationRequestMessage) request);

                                } else if (request instanceof BillPaymentsRequestSyntellAccountPaymentMessage) {
                                    Log.d(TAG, "BillPaymentsRequestSyntellAccountPaymentMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.getBillPaymentsSyntellAccountPayment(socket, (BillPaymentsRequestSyntellAccountPaymentMessage) request);

                                } else if (request instanceof BillPaymentsRequestSyntellConfirmMessage) {
                                    Log.d(TAG, "BillPaymentsRequestSyntellConfirmMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.confirmSyntellAccountPayment(socket, (BillPaymentsRequestSyntellConfirmMessage) request);

                                } else if (request instanceof BillPaymentsRequestPrintedMessage) {
                                    Log.d(TAG, "BillPaymentsRequestPrintedMessage");
                                    //getAEONService(); //service = new AEONService();
                                    return service.confirmPrinted(socket, (BillPaymentsRequestPrintedMessage) request);

                                } else if (request instanceof MoneyTransferAuthenticationRequestMessage) {
                                    Log.d(TAG, "MoneyTransferAuthenticationRequestMessage");
                                    openSocket();
                                    Log.d(TAG, "request " + request);
                                    return service.prepareMoneyTransfer(socket, (MoneyTransferAuthenticationRequestMessage) request);

                                } else if (request instanceof MoneyTransferRequestPreAuthMessage) {
                                    Log.d(TAG, "MoneyTransferRequestPreAuthMessage");
                                    //getAEONService();
                                    return service.moneyTransferPreAuth(socket, (MoneyTransferRequestPreAuthMessage) request);

                                } else if (request instanceof MoneyTransferRequestCashInMessage) {
                                    Log.d(TAG, "MoneyTransferRequestCashInMessage");
                                    //getAEONService();
                                    return service.moneyTransferCashIn(socket, (MoneyTransferRequestCashInMessage) request);

                                } else if (request instanceof MoneyTransferRequestPrintedMessage) {
                                    Log.d(TAG, "MoneyTransferRequestPrintedMessage");
                                    //getAEONService();
                                    return service.moneyTransferPrinted(socket, (MoneyTransferRequestPrintedMessage) request);

                                } else if (request instanceof MoneyTransferRequestCashOutMessage) {
                                    Log.d(TAG, "MoneyTransferRequestCashOutMessage");
                                    //getAEONService();
                                    return service.moneyTransferCashOut(socket, (MoneyTransferRequestCashOutMessage) request);

                                } else if (request instanceof UnprintedAuthenticationRequestMessage) {
                                    Log.d(TAG, "UnprintedAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareUnprinted(socket, (UnprintedAuthenticationRequestMessage) request);

                                } else if (request instanceof UnprintedRequestMessage) {
                                    Log.d(TAG, "UnprintedRequestMessage");
                                    //getAEONService();
                                    return service.unprinted(socket, (UnprintedRequestMessage) request);

                                } else if (request instanceof SoldUnprintedRequestMessage) {
                                    Log.d(TAG, "SoldUnprintedRequestMessage");
                                    //getAEONService();
                                    return service.soldUnprinted(socket, (SoldUnprintedRequestMessage) request);

                                } else if (request instanceof IthubaAuthenticationRequestMessage) {
                                    Log.d(TAG, "IthubaAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareIthuba(socket, (IthubaAuthenticationRequestMessage) request);

                                } else if (request instanceof IthubaRequestItbConfirmMessage) {
                                    Log.d(TAG, "IthubaRequestItbConfirmMessage");
                                    //getAEONService();
                                    return service.ithubaConfirm(socket, (IthubaRequestItbConfirmMessage) request);

                                } else if (request instanceof IthubaRequestItbLotteryMessage) {
                                    Log.d(TAG, "IthubaRequestItbLotteryMessage");
                                    //getAEONService();
                                    return service.ithubaLottery(socket, (IthubaRequestItbLotteryMessage) request);

                                } else if (request instanceof IthubaRequestItbPowerballMessage) {
                                    Log.d(TAG, "IthubaRequestItbPowerballMessage");
                                    //getAEONService();
                                    return service.ithubaPowerball(socket, (IthubaRequestItbPowerballMessage) request);

                                } else if (request instanceof IthubaRequestItbPrintedMessage) {
                                    Log.d(TAG, "IthubaRequestItbPrintedMessage");
                                    //getAEONService();
                                    return service.ithubaPrinted(socket, (IthubaRequestItbPrintedMessage) request);

                                } else if (request instanceof ReprintAuthenticationRequestMessage) {
                                    Log.d(TAG, "ReprintAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareReprint(socket, (ReprintAuthenticationRequestMessage) request);

                                } else if (request instanceof ReprintRequestListByDateMessage) {
                                    Log.d(TAG, "ReprintRequestListByDateMessage");
                                    //getAEONService();
                                    return service.reprintListByDate(socket, (ReprintRequestListByDateMessage) request);

                                } else if (request instanceof ReprintRequestReprintMessage) {
                                    Log.d(TAG, "ReprintRequestReprintMessage");
                                    return service.reprint(socket, (ReprintRequestReprintMessage) request);

                                } else if (request instanceof EmergencyLoanAuthenticationRequestMessage) {
                                    Log.d(TAG, "EmergencyLoanAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareEmergencyLoan(socket, (EmergencyLoanAuthenticationRequestMessage) request);

                                } else if (request instanceof EmergencyLoanRequestListAccountsMessage) {
                                    Log.d(TAG, "EmergencyLoanResponseListAccountsMessage");
                                    //getAEONService();
                                    return service.listAccounts(socket, (EmergencyLoanRequestListAccountsMessage) request);

                                } else if (request instanceof EmergencyLoanRequestLoanApplicationMessage) {
                                    Log.d(TAG, "EmergencyLoanResponseLoanApplicationMessage");
                                    //getAEONService();
                                    return service.loanApplication(socket, (EmergencyLoanRequestLoanApplicationMessage) request);

                                } else if (request instanceof EmergencyLoanRequestLoanConfirmationMessage) {
                                    Log.d(TAG, "EmergencyLoanResponseLoanConfirmationMessage");
                                    //getAEONService();
                                    return service.loanConfirmation(socket, (EmergencyLoanRequestLoanConfirmationMessage) request);

                                } else if (request instanceof EmergencyLoanRequestPrintEmergencyTopupMessage) {
                                    Log.d(TAG, "EmergencyLoanResponsePrintEmergencyTopupMessage");
                                    //getAEONService();
                                    return service.printReport(socket, (EmergencyLoanRequestPrintEmergencyTopupMessage) request);

                                } else if (request instanceof EskomDirectReprintAuthenticationRequestMessage) {
                                    Log.d(TAG, "EskomDirectReprintAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareEskomDirectReprint(socket, (EskomDirectReprintAuthenticationRequestMessage) request);

                                } else if (request instanceof EskomDirectReprintRequestMessage) {
                                    Log.d(TAG, "EskomDirectReprintRequestMessage");
                                    //getAEONService();
                                    return service.eskomDirectReprint(socket, (EskomDirectReprintRequestMessage) request);

                                } else if (request instanceof MerchantTransferAuthenticationRequestMessage) {
                                    Log.d(TAG, "MerchantTransferAuthenticationRequestMessage");
                                    openSocket();
                                    return service.prepareMerchantTransfer(socket, (MerchantTransferAuthenticationRequestMessage) request);

                                } else if (request instanceof MerchantTransferRequestGetInfoMessage) {
                                    Log.d(TAG, "MerchantTransferRequestGetInfoMessage");
                                    return service.getMerchantInfo(socket, (MerchantTransferRequestGetInfoMessage) request);

                                } else if (request instanceof MerchantTransferRequestConfirmMessage) {
                                    Log.d(TAG, "MerchantTransferRequestConfirmMessage");
                                    return service.confirmMerchantTransfer(socket, (MerchantTransferRequestConfirmMessage) request);

                                } else if (request instanceof MerchantTransferRequestPrintedMessage) {
                                    Log.d(TAG, "MerchantTransferRequestPrintedMessage");
                                    return service.printMerchantTransfer(socket, (MerchantTransferRequestPrintedMessage) request);
                                }
                                //
                                // carma stuff
                                //
                                else if (request instanceof CarmaAuthenticationRequestMessage) {
                                    Log.d(TAG, "CarmaAuthenticationResquestMessage");
                                    openSocket();
                                    return service.prepareCarma(socket, (CarmaAuthenticationRequestMessage) request);

                                } else if (request instanceof CarmaRequestBookingCancellationMessage) {
                                    Log.d(TAG, "CarmaRequestBookingCancellationMessage");
                                    return service.carmaCancelBooking(socket, (CarmaRequestBookingCancellationMessage) request);

                                } else if (request instanceof CarmaRequestTitleListMessage) {
                                    Log.d(TAG, "CarmaRequestTitleListMessage");
                                    return service.carmaTitleList(socket, (CarmaRequestTitleListMessage) request);

                                } else if (request instanceof CarmaRequestClassListMessage) {
                                    Log.d(TAG, "CarmaRequestClassListMessage");
                                    return service.carmaClassList(socket, (CarmaRequestClassListMessage) request);

                                } else if (request instanceof CarmaRequestPassengerTypeListMessage) {
                                    Log.d(TAG, "CarmaRequestPassengerTypeListMessage");
                                    return service.carmaPassengerTypeList(socket, (CarmaRequestPassengerTypeListMessage) request);

                                } else if (request instanceof CarmaRequestCityListMessage) {
                                    Log.d(TAG, "CarmaRequestCityListMessage");
                                    return service.carmaCityList(socket, (CarmaRequestCityListMessage) request);

                                } else if (request instanceof CarmaRequestCarrierListMessage) {
                                    Log.d(TAG, "CarmaRequestCityListMessage");
                                    return service.carmaCarrierList(socket, (CarmaRequestCarrierListMessage) request);

                                } else if (request instanceof CarmaRequestDestinationsListMessage) {
                                    Log.d(TAG, "CarmaRequestDestinationsListMessage");
                                    return service.carmaDestinationsList(socket, (CarmaRequestDestinationsListMessage) request);

                                } else if (request instanceof CarmaRequestAvailabilityMessage) {
                                    Log.d(TAG, "CarmaRequestAvailabilityMessage");
                                    return service.carmaAvailability(socket, (CarmaRequestAvailabilityMessage) request);

                                } else if (request instanceof CarmaRequestAvailabilityExtendedMessage) {
                                    Log.d(TAG, "CarmaRequestAvailabilityExtendedMessage");
                                    return service.carmaExtededAvailability(socket, (CarmaRequestAvailabilityExtendedMessage) request);

                                } else if (request instanceof CarmaRequestReserveSeatsMessage) {
                                    Log.d(TAG, "CarmaRequestReserveSeatsMessage");
                                    return service.carmaReserveSeats(socket, (CarmaRequestReserveSeatsMessage) request);

                                } else if (request instanceof CarmaRequestCompleteBookingMessage) {
                                    Log.d(TAG, "CarmaRequestCompleteBookingMessage");
                                    return service.carmaCompleteBooking(socket, (CarmaRequestCompleteBookingMessage) request);


                                    //NFC BUS
                                } else if (request instanceof NfcBusAuthenticationRequestMessage) {
                                    Log.d(TAG, "NfcBusAuthenticationRequestMessage");
                                    openSocket();
                                    return service.nfcBusAuth(socket, (NfcBusAuthenticationRequestMessage) request);
                                } else if (request instanceof NfcBusListCarriersRequestMessage) {
                                    Log.d(TAG, "NfcBusListCarriersRequestMessage");
                                    return service.nfcBusListCarriers(socket, (NfcBusListCarriersRequestMessage) request);
                                } else if (request instanceof NfcBusListStopsRequestMessage) {
                                    Log.d(TAG, "NfcBusListStopsRequestMessage");
                                    return service.nfcBusListStops(socket, (NfcBusListStopsRequestMessage) request);
                                } else if (request instanceof NfcBusLookupDestinationsRequestMessage) {
                                    Log.d(TAG, "NfcBusLookupDestinationsRequestMessage");
                                    return service.nfcBusLookupDestinations(socket, (NfcBusLookupDestinationsRequestMessage) request);
                                } else if (request instanceof NfcBusLookupFaresRequestMessage) {
                                    Log.d(TAG, "NfcBusLookupFaresRequestMessage");
                                    return service.nfcBusLookupFares(socket, (NfcBusLookupFaresRequestMessage) request);
                                } else if (request instanceof NfcBusUpdateCustomerRequestMessage) {
                                    Log.d(TAG, "NfcBusUpdateCustomerRequestMessage");
                                    return service.nfcBusUpdateCustomer(socket, (NfcBusUpdateCustomerRequestMessage) request);
                                } else if (request instanceof NfcBusGetCustomerRequestMessage) {
                                    Log.d(TAG, "NfcBusGetCustomerRequestMessage");
                                    return service.nfcBusGetCustomer(socket, (NfcBusGetCustomerRequestMessage) request);
                                } else if (request instanceof NfcBusValidateSvcRequestMessage) {
                                    Log.d(TAG, "NfcBusValidateSvcRequestMessage");
                                    return service.nfcBusValidateSvc(socket, (NfcBusValidateSvcRequestMessage) request);
                                } else if (request instanceof NfcBusCancelTicketRequestMessage) {
                                    Log.d(TAG, "NfcBusCancelTicketRequestMessage");
                                    return service.nfcBusCancelTicket(socket, (NfcBusCancelTicketRequestMessage) request);
                                } else if (request instanceof NfcBusCheckoutRequestMessage) {
                                    Log.d(TAG, "NfcBusCheckoutRequestMessage");
                                    return service.nfcBusCheckout(socket, (NfcBusCheckoutRequestMessage) request);
                                } else if (request instanceof NfcBusConfirmCancelTicketRequestMessage) {
                                    Log.d(TAG, "NfcBusConfirmCancelTicketRequestMessage");
                                    return service.nfcBusConfirmCancelTicket(socket, (NfcBusConfirmCancelTicketRequestMessage) request);
                                } else if (request instanceof NfcBusConfirmCheckoutRequestMessage) {
                                    Log.d(TAG, "NfcBusConfirmCheckoutRequestMessage");
                                    return service.nfcBusConfirmCheckout(socket, (NfcBusConfirmCheckoutRequestMessage) request);
                                } else if (request instanceof NfcBusFindTicketRequestMessage) {
                                    Log.d(TAG, "NfcBusFindTicketRequestMessage");
                                    return service.nfcBusFindTicket(socket, (NfcBusFindTicketRequestMessage) request);

                                //International Airtime
                                } else if (request instanceof InterAirAuthenticationRequestMessage) {
                                    Log.d(TAG, "InterAirAuthenticationRequestMessage");
                                    openSocket();
                                    return service.interAirAuth(socket, (InterAirAuthenticationRequestMessage) request);
                                } else if (request instanceof InterAirRequestPrintedMessage) {
                                    Log.d(TAG, "InterAirRequestPrintedMessage");
                                    return service.interAirSetPrinted(socket, (InterAirRequestPrintedMessage) request);
                                }


                            }
                        }
                        Log.d(TAG, "returning null-1");
                        return null;
                    }
                    Log.d(TAG, "returning null-2");
                    return null;

                } catch (AEONCommsException exception) {
                    Log.d(TAG, "got an AEONCommsException " + exception);
                    return exception;

                } catch (Exception exception) {
                    Log.d(TAG, "exception " + exception);
                }
                Log.d(TAG, "returning null-3");
                return null;

            } catch (Exception exception) {
                Log.d(TAG, "doInBackground exception " + exception);
                return null;
            }
        }
        return null;
    }

    private void openSocket() throws AEONCommsException {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            baseScreen.closeAeonSocket(22);
            String host = baseScreen.getPreference(PREF_HOST);
            String port = baseScreen.getPreference(PREF_PORT);

            service = new AEONService(BaseActivity.logger, baseScreen.getPreference(PREF_USE_SSL).equals(PREF_TRUE));
            socket = service.openSocket(host, port);
            Log.d("AeonAsyncTask", "opened socket: " + socket.hashCode() + " (" + host + ":" + port + ")");
            BaseActivity.socket = socket;
            updatedSocket = true;
        }
    }

    private void openSocketRica() throws AEONCommsException {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            baseScreen.closeAeonSocket(31);
            String host = baseScreen.getPreference(PREF_RICA_HOST);
            String port = baseScreen.getPreference(PREF_RICA_PORT);
            service = new AEONService(BaseActivity.logger, baseScreen.getPreference(PREF_RICA_USE_SSL).equals(PREF_TRUE));

            socket = service.openSocket(host, port);
            Log.d("AeonAsyncTask", "opened socket: " + socket.hashCode() + " (" + host + ":" + port + ")");
            BaseActivity.socket = socket;
            updatedSocket = true;
        }
    }

    protected void onPostExecute(Object result) {
        taskStatus = Status.FINISHED;


        if (!isCancelled()) {

            if (result == null) {

                Log.d(TAG, "null");
                if (service != null)
                    service.closeSocket(socket);
                return;
            }
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                aeonTimer.cancel();
                Log.d(TAG, "AEON TIMER Cancelled");
                if (result instanceof LoginResponseMessage) {
                    LoginResponseMessage response = (LoginResponseMessage) result;
                    // send back the socket
                    if (response.getEvent().getEventCode().equals("0")) {
                        ((NeedsAEONResults) baseScreen).results(socket);
                    } else {
                        Log.d(TAG, "closing socket");
                        // if it is NOT successful, close the socket
                        service.closeSocket(socket);
                    }
                }
                // ConfirmMeterResponse also sends back the socket
                if (result instanceof ConfirmMeterResponseMessage) {
                    ConfirmMeterResponseMessage response = (ConfirmMeterResponseMessage) result;
                    if (response.getEvent().getEventCode().equals("0")) {
                        ((NeedsAEONResults) baseScreen).results(socket);
                    }
                }

                BaseFragment baseFragment = null;
                if (baseFragmentWeakReference != null) {
                    baseFragment = baseFragmentWeakReference.get();
                }

                if (updatedSocket) {
                    ((NeedsAEONResults) baseScreen).results(socket);
                    if (baseFragment != null) {
                        ((NeedsAEONResults) baseFragment).results(socket);
                    }
                }
                // send back the data
                ((NeedsAEONResults) baseScreen).results(result);
                if (baseFragment != null) {
                    ((NeedsAEONResults) baseFragment).results(result);
                }
            }
        } else {
            Log.d(TAG, "is cancelled");
        }

    }

    protected void onCancelled(Object result) {
        Log.d("AeonAsyncTask", "****asyncTask CANCELLED");
        taskStatus = Status.FINISHED;
        Log.d(TAG, "onCancelled " + result);
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            if (!isCancelled()) {
                ((NeedsAEONResults) baseScreen).error(null);
            }
        }
    }


    public void closeSocket(int caller) {
        //added a caller integer, so its simpler to debug where a socket is getting closed.  be sure to always call with an incremented int
        Log.d("AeonAsyncTask", "****asyncTask CLOSE SOCKET " + caller);
        taskStatus = Status.FINISHED;
        if (socket != null && !socket.isClosed()) {
            Log.d("AeonAsyncTask", "closing socket: " + socket.hashCode());
            service.closeSocket(socket);
        } else {
            Log.e("AeonAsyncTask", "cannot close socket: " + socket);
            if (socket != null)
                Log.e(TAG, "socket closed: " + socket.isClosed());
        }
    }

    public Status getTaskStatus() {
        return taskStatus;
    }
}
