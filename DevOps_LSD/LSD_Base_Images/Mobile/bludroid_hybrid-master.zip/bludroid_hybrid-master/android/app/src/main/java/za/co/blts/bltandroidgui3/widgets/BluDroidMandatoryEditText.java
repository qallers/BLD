package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/8/2017.
 */

public class BluDroidMandatoryEditText extends BluDroidEditText {

    private final String TAG = this.getClass().getSimpleName();

    public BluDroidMandatoryEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public BluDroidMandatoryEditText(BaseActivity context) {
        super(context);
    }

    @Override
    public boolean validate() {
        Log.d(TAG, "validate Mandatory");

        String text = getText().toString().trim();
        boolean isValidated = false;

        if (text.isEmpty()) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                setErrorMessage(baseScreen.getResources().getString(R.string.required));
            }
        } else {
            removeErrorMessage();
            isValidated = true;
        }

        return isValidated;
    }
}
