package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/6/2017.
 */

public class BluDroidIdNumberEditText extends BluDroidIntegerEditText {
    private final String TAG = this.getClass().getSimpleName();

    public BluDroidIdNumberEditText(BaseActivity context) {
        super(context);
        setUpId();

    }

    public BluDroidIdNumberEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpId();
    }

    private void setUpId() {

        maxLength = 13;
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(maxLength);
        setFilters(inputFilters);
        setOnFocusChangeListener(this);

    }

    @SuppressWarnings("Annotator")
    @Override
    public boolean validate() {
        //BaseActivity.logger.info(": validate()");
        Log.d(TAG, "validate");
        String idRegex = "(((\\d{2}((0[13578]|1[02])(0[1-9]|[12]\\d|3[01])|(0[13456789]|1[012])(0[1-9]|[12]\\d|30)|02(0[1-9]|1\\d|2[0-8])))|([02468][048]|[13579][26])0229))(( |-)(\\d{4})( |-)(\\d{3})|(\\d{7}))";
        String idString = getText().toString().trim();

        if (this.getVisibility() == VISIBLE) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                if (idString.isEmpty()) {
                    setErrorMessage(baseScreen.getResources().getString(R.string.required));
                    return false;
                } else if (idString.length() == 13 && idString.matches(idRegex)) {
                    removeErrorMessage();
                    return true;
                } else {
                    setErrorMessage(baseScreen.getResources().getString(R.string.idNumberInvalid));
                    return false;
                }
            }
        }
        return true;

    }

}
