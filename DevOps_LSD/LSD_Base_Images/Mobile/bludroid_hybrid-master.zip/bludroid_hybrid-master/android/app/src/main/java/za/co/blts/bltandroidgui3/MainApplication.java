package za.co.blts.bltandroidgui3;

import android.app.Application;
import android.content.Context;

import androidx.multidex.MultiDex;

import com.sunmi.pay.hardware.aidl.readcard.ReadCardOpt;

public class MainApplication extends Application {
    private static MainApplication myApplication;
    public static ReadCardOpt mReadCardOpt;

    //----------------------------------------------------------------------------------------------
    public static MainApplication getInstance() {
        return myApplication;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onCreate() {
        super.onCreate();
        myApplication = this;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(base);
    }

}