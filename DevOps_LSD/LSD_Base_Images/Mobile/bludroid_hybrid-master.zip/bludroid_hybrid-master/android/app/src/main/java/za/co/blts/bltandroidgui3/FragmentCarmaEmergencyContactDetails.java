package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;

/**
 * Created by MasiS on 2018/03/03.
 */

public class FragmentCarmaEmergencyContactDetails extends BaseFragment {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidEditText emergency_contact_name;
    private BluDroidCellphoneEditText emergency_cell_phone_number;


    public FragmentCarmaEmergencyContactDetails() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_carma_emergency_contact, container, false);

        BluDroidButton next = rootView.findViewById(R.id.next_emergency_contact);
        BluDroidButton cancel = rootView.findViewById(R.id.cancel_emergency_contact);
        BluDroidButton back = rootView.findViewById(R.id.back_emergency_contact);

        emergency_contact_name = rootView.findViewById(R.id.emergency_contact_name);
        emergency_cell_phone_number = rootView.findViewById(R.id.emergency_cell_phone_number);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                next_navigate();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { // back to
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                getBaseActivity().bluDroidRoutesAndTimes = null;
                getBaseActivity().fragmentCarmaPassengerDetailsWizard = null;
                getBaseActivity().fragmentCarmaConfirmPurchaseTicket = null;
                getBaseActivity().availabilitySearchQuery = null;
                getBaseActivity().fragmentCarmaSearchResults = null;
                getBaseActivity().carmaResponseAvailabilityExtendedMessage = null;
                getBaseActivity().passengerDetails.clear();
                getBaseActivity().gotoFragment(new FragmentTickets(), "FragmentTickets");
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back_navigate();
            }
        });

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        Log.d(TAG, "onActivityCreated");

        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
    }

    private void next_navigate() {
        clearValidationErrors();
        if (validateEmergency()) {
            Log.v(TAG, "GOTO NEXT");
            Log.v(TAG, "EMERGENCY name:" + getBaseActivity().emergencyName + " number:" + getBaseActivity().emergencyNumber);
            getBaseActivity().fragmentCarmaConfirmPurchaseTicket = new FragmentCarmaConfirmPurchaseTicketNew();
            getBaseActivity().gotoFragment(getBaseActivity().fragmentCarmaConfirmPurchaseTicket, "FragmentCarmaConfirmPurchaseTicketNew");
        }
    }

    private void clearValidationErrors() {
        emergency_contact_name.removeErrorMessage();
        emergency_cell_phone_number.removeErrorMessage();
    }

    //----------------------------------------------------------------------------------------------
    private void back_navigate() {
        clearValidationErrors();
        if (getBaseActivity().fragmentCarmaSearchResults == null) {
            getBaseActivity().fragmentCarmaSearchResults = new FragmentCarmaSearchResults();
        }

        getBaseActivity().fragmentCarmaSearchResults.state = "Departure";

        getBaseActivity().fragmentCarmaPassengerDetailsWizard = null;
        getBaseActivity().passengerDetails.clear();
        getBaseActivity().gotoFragment(getBaseActivity().fragmentCarmaSearchResults, "FragmentCarmaSearchResults");
    }

    private boolean validateEmergency() {
        Log.d(TAG, "validate emergency");
        boolean ret = true;

        if (!emergency_contact_name.validate()) {
            Log.e(TAG, "error on name");
            ret = false;
        } else {
            getBaseActivity().emergencyName = emergency_contact_name.getText().toString();
        }
        if (!emergency_cell_phone_number.validate()) {
            Log.e(TAG, "error on cell number");
            ret = false;
        } else {
            getBaseActivity().emergencyNumber = emergency_cell_phone_number.getText().toString();
        }

        Log.d(TAG, "validate success = " + ret);
        return ret;
    }

    @Override
    public boolean onBackPressed() {
        back_navigate();
        return true;
    }

}