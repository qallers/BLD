package za.co.blts.bltandroidgui3.blt_draggable;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by warrenm on 2016/12/02.
 */

public interface OnStartDragListener {
    void onStartDrag(RecyclerView.ViewHolder viewHolder);
}
