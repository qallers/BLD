package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.annotation.Nullable;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by WarrenM1 on 2017/08/03.
 */

public class FragmentTransactTrafficFinesPayAt extends BaseFragment {

    private final String TAG = this.getClass().getSimpleName();

    public FragmentTransactTrafficFinesPayAt() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle bundle = getArguments();
        getBaseActivity().providerId = bundle.getString("providerId");
        getBaseActivity().productId = bundle.getString("productId");
        getBaseActivity().productName = bundle.getString("productName");

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_bill_payment_payat, container, false);


        BluDroidTextView productNameTextView = rootView.findViewById(R.id.productName);
        productNameTextView.setText(getBaseActivity().productName);

        BluDroidTextView accountNumberLabel = rootView.findViewById(R.id.accountNumberLabel);
        accountNumberLabel.setText(getString(R.string.noticeNumber));

        final BluDroidEditText accountNumber = rootView.findViewById(R.id.accountNumber);
        accountNumber.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent event) {

                if (actionId == 0) {
                    accountNumber.setImeActionLabel(getResources().getString(R.string.next), EditorInfo.IME_ACTION_GO);
                    accountNumber.setInputType(InputType.TYPE_CLASS_TEXT);
                }

                return true;
            }
        });


        final BluDroidButton showDetails = rootView.findViewById(R.id.showDetailsButton);

        showDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BaseActivity.logger.info(((BluDroidButton) view).getText());
                if (accountNumber.getText().toString().trim().isEmpty()) {

                    accountNumber.setErrorMessage(getResources().getString(R.string.account_number_required));
                    accountNumber.getErrorTextView().setText(getResources().getString(R.string.account_number_required));

                } else {
                    accountNumber.removeErrorMessage();
                    accountNumber.getErrorTextView().setText("");

                    String noticeNumber = accountNumber.getText().toString().trim();
                    new Handler().postDelayed(new Runnable() {

                        @Override
                        public void run() {
                            showDetails.setEnabled(true);

                        }
                    }, 5000);
                    getBaseActivity().authenticateForPayAtTraficFinePayments(noticeNumber);
                }
            }
        });

        accountNumber.requestFocus();
        getBaseActivity().showKeyboard();

        return rootView;
    }

    @Override
    public boolean onBackPressed() {
        BaseActivity.logger.info(": onBackPressed()");
        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else if (getBaseActivity().navigatedFromSearch) {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentSearch(), "FragmentSearch").commit();
        } else {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentTransact(), "FragmentTransact").commit();
        }
        return true;
    }


}
