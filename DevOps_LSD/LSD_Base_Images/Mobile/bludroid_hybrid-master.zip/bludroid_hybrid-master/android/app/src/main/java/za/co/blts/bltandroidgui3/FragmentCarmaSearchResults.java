package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import za.co.blt.interfaces.external.factories.CarmaRequestFactory;
import za.co.blt.interfaces.external.messages.carma.response.CarmaAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseAvailabilityExtendedMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseExtendedRouteMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseItemMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static java.lang.String.valueOf;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;

/**
 * Created by MasiS on 2018/02/13.
 */

public class FragmentCarmaSearchResults extends BaseFragment implements NeedsAEONResults {
    private final String TAG = this.getClass().getSimpleName();
    //----------------------------------------------------------------------------------------------

    private ListView availability_search_results;
    private BluDroidCarmaRoutesAdapter bluDroidCarmaRoutesAdapter;
    String state = "Departure";
    private BluDroidTextView routes_title;
    private TextView no_results_message;
    private BluDroidSpinner filterCarrierSpinner, orderBySpinner;
    private BluDroidLinearLayout filterLayoutCarrier;

    private Comparator<BluDroidRoutesAndTimes> comparatorPrice, comparatorDate;

    private final List<BluDroidRoutesAndTimes> routes = new ArrayList<>();

    public FragmentCarmaSearchResults() {
        //sort by depart date, if equal sort by price
        comparatorDate = new Comparator<BluDroidRoutesAndTimes>() {
            @Override
            public int compare(BluDroidRoutesAndTimes o1, BluDroidRoutesAndTimes o2) {
                int comp = o1.getDepartTime().compareTo(o2.getDepartTime());
                return comp == 0 ? o1.getAdultPrice().compareTo(o2.getAdultPrice()) : comp;
            }
        };

        //sort by price, if equal sort by depart date
        comparatorPrice = new Comparator<BluDroidRoutesAndTimes>() {
            @Override
            public int compare(BluDroidRoutesAndTimes o1, BluDroidRoutesAndTimes o2) {
                int comp = o1.getAdultPrice().compareTo(o2.getAdultPrice());
                return comp == 0 ? o1.getDepartTime().compareTo(o2.getDepartTime()) : comp;
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView state=" + state);

        View rootView = inflater.inflate(R.layout.fragment_carma_search_results, container, false);
        routes_title = rootView.findViewById(R.id.routes_title);

        filterLayoutCarrier = rootView.findViewById(R.id.filter_layout_carrier);
//        filterLayout.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());
//
//        RelativeLayout spinnerLayout = rootView.findViewById(R.id.spinner_layout);
//        spinnerLayout.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());

        // cancel
        rootView.findViewById(R.id.cancel_search_results).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getBaseActivity().bluDroidRoutesAndTimes = null; // we want to get new routes each time
                getBaseActivity().availabilitySearchQuery = null;
                getBaseActivity().fragmentCarmaSearchResults = null;
                getBaseActivity().fragmentCarmaPassengerDetailsWizard = null;
                getBaseActivity().fragmentCarmaConfirmPurchaseTicket = null;
                getBaseActivity().carmaResponseAvailabilityExtendedMessage = null;
                if (getBaseActivity().navigatedFromFavourites) {
                    getBaseActivity().gotoMainScreen();
                } else {
                    getBaseActivity().gotoFragment(new FragmentTickets(), "FragmentTickets");
                }
            }
        });
        // back to departure trips or to search criteria
        rootView.findViewById(R.id.back_search_results).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        no_results_message = rootView.findViewById(R.id.no_results_message);

        BluDroidButton next_search_results = rootView.findViewById(R.id.next_search_results);
        next_search_results.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if we must select return trip
                if (getBaseActivity().availabilitySearchQuery.isReturnTrip() && !state.equals("Return")) {
                    if (isRouteSelected(false)) {
                        updateState(true);
                    } else {
                        getBaseActivity().createAlertDialog("Select route", "Please select a route.");
                    }

                    //else must capture passenger details
                } else {
                    if (isRouteSelected(state.equalsIgnoreCase("Return"))) {
                        Log.d(TAG, "leaving search results");
                        Log.d(TAG, "out depart = " + getBaseActivity().bluDroidRoutesAndTimes);
                        Log.d(TAG, "out return = " + getBaseActivity().bluDroidRoutesAndTimesReturn);

                        getBaseActivity().passengerDetails.clear();
                        Log.d(TAG, "number of seats: " + getBaseActivity().availabilitySearchQuery.getTotalNumberOfSeatsToReserve());
                        for (int i = 0; i < getBaseActivity().availabilitySearchQuery.getTotalNumberOfSeatsToReserve(); i++) {
                            getBaseActivity().passengerDetails.add(new CarmaPassenger());
                        }

                        getBaseActivity().fragmentCarmaPassengerDetailsWizard = new FragmentCarmaPassengerDetailsWizard();
                        getBaseActivity().gotoFragment(getBaseActivity().fragmentCarmaPassengerDetailsWizard, "FragmentCarmaPassengerDetailsWizard");
                    } else {
                        getBaseActivity().createAlertDialog("Select route", "Please select a route.");
                    }
                }


            }
        });

        availability_search_results = rootView.findViewById(R.id.availability_search_results);
        filterCarrierSpinner = rootView.findViewById(R.id.filter_carrier);
        orderBySpinner = rootView.findViewById(R.id.filter_orderby);

        bluDroidCarmaRoutesAdapter = new BluDroidCarmaRoutesAdapter(getBaseActivity(), R.layout.bus_trip_info_layout_item, routes, false);
        availability_search_results.setAdapter(bluDroidCarmaRoutesAdapter);

        configureCarriersSpinner();
        configureFilterSpinner();

        return rootView;
    }

    @Override
    public void onDestroy() {
        if (availability_search_results != null) availability_search_results.setAdapter(null);
        super.onDestroy();
    }

    private boolean isRouteSelected(boolean isReturn) {
        if (isReturn) {
            getBaseActivity().bluDroidRoutesAndTimesReturn = null;
        } else {
            getBaseActivity().bluDroidRoutesAndTimes = null;
        }
        for (BluDroidRoutesAndTimes r : routes) {
            if (r.isSelected()) {
                if (isReturn) {
                    getBaseActivity().bluDroidRoutesAndTimesReturn = r;
                } else {
                    getBaseActivity().bluDroidRoutesAndTimes = r;
                }
                return true;
            }
        }
        return false;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        Log.d(TAG, "onActivityCreated");
        super.onActivityCreated(savedInstanceState);

        getBaseActivity().bluDroidRoutesAndTimesReturn = null;
        getBaseActivity().bluDroidRoutesAndTimes = null;
        getBaseActivity().carmaRequestReserveSeatsMessage = null;
        BaseActivity.isSearchResultsScreen = true;
        if (getBaseActivity().carmaResponseAvailabilityExtendedMessage == null) // we dont care about the return trips
//      requestExtendedRequestAvailability();
            authForCarma();
        else
            updateState(false);

        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
    }

    private void authForCarma() {
        try {
            getBaseActivity().availabilitySearchQuery.setCarrierName(getBaseActivity().carrierCode);
            getBaseActivity().createProgress(R.string.authenticating);
            CarmaRequestFactory factory = new CarmaRequestFactory();

            getBaseActivity().carmaAuthenticationRequestMessage =
                    factory.create(
                            BaseActivity.loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER));

            if (BaseActivity.completeConsumerProfile != null) {
                getBaseActivity().carmaAuthenticationRequestMessage.getEvent().setLoyaltyProfileId(BaseActivity.completeConsumerProfile.getConsumer().getProfileId());
            }
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, getBaseActivity().carmaAuthenticationRequestMessage);
        } catch (Exception exception) {
            //Log.v(TAG, "prepareCarma throws " + exception);
        }
    }

    private void setTitle(String title) {
        routes_title.setText(title);
    }

    private void configureFilterSpinner() {
        List<String> filterTypes = Arrays.asList(getResources().getStringArray(R.array.orderbyarray));

        CarmaFilterListAdapter carmaFilterListAdapter = new CarmaFilterListAdapter(getBaseActivity(), R.layout.spinner_item_carrier, filterTypes);
        orderBySpinner.setAdapter(carmaFilterListAdapter);
        orderBySpinner.setSelection(0, true);
        View v = orderBySpinner.getSelectedView();
        ((TextView) v).setTextColor(getBaseActivity().getSkinResources().getButtonColor());

        orderBySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //sort the list by time, earliest first, implementing the Comparable<T> interface
                Log.v("BusFilter", "filter selected: " + position);
                switch (position) {
                    case 0:
                        Collections.sort(getBaseActivity().departureRoutes, comparatorDate);
                        Collections.sort(getBaseActivity().returnRoutes, comparatorDate);
                        updateState(state.equalsIgnoreCase("Return"));
                        break;

                    case 1:
                        Collections.sort(getBaseActivity().departureRoutes, comparatorPrice);
                        Collections.sort(getBaseActivity().returnRoutes, comparatorPrice);
                        updateState(state.equalsIgnoreCase("Return"));
                        break;
                }
                ((TextView) view).setTextColor(getBaseActivity().getSkinResources().getButtonColor());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void configureCarriersSpinner() {

        ArrayList<CarmaResponseItemMessage> carrierNames = new ArrayList<>();

        //1 way trips
        if (getBaseActivity().carmaResponseAvailabilityExtendedMessage != null) {
            for (CarmaResponseExtendedRouteMessage extendedRouteMessage : getBaseActivity().carmaResponseAvailabilityExtendedMessage.getData().getRoutes()) {
                for (CarmaResponseItemMessage carrier : getBaseActivity().carmaResponseCarrierListMessage.getData().getItems()) {
                    if (extendedRouteMessage.getCarrier().equalsIgnoreCase(carrier.getCode()) && !carrierNames.contains(carrier)) {
                        carrierNames.add(carrier);
                    }
                }
            }
        }

        Collections.sort(carrierNames, new Comparator<CarmaResponseItemMessage>() {
            @Override
            public int compare(CarmaResponseItemMessage one, CarmaResponseItemMessage two) {
                return one.getDescription().compareTo(two.getDescription());
            }
        });

        CarmaResponseItemMessage all = new CarmaResponseItemMessage();
        all.setCarrierId("0");
        all.setCode("0");
        all.setDescription("All Carriers");
        carrierNames.add(0, all);

        CarmaCarrierListAdapter carmaCarrierListAdapter = new CarmaCarrierListAdapter(getBaseActivity(), R.layout.spinner_item_carrier, carrierNames);
        filterCarrierSpinner.setAdapter(carmaCarrierListAdapter);
        filterCarrierSpinner.setSelection(0, true);
        View v = filterCarrierSpinner.getSelectedView();
        ((TextView) v).setTextColor(getBaseActivity().getSkinResources().getButtonColor());

        filterCarrierSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(final AdapterView<?> parent, View view, int position, long id) {
                Log.d(TAG, "carrierSpinner onSelected pos=" + position);
                updateState(state.equalsIgnoreCase("Return"));
                ((TextView) view).setTextColor(getBaseActivity().getSkinResources().getButtonColor());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void requestExtendedRequestAvailability() {
        try {
            getBaseActivity().createProgress(R.string.gettingAvailability);
            CarmaRequestFactory factory = new CarmaRequestFactory();
            getBaseActivity().carmaRequestAvailabilityExtendedMessage = factory.createExtendedAvailability(
                    getBaseActivity().carmaAuthenticationResponseMessage,
                    "Carma",
                    getBaseActivity().availabilitySearchQuery.getDeparturePoint(),
                    getBaseActivity().availabilitySearchQuery.getDestinationPoint(),
                    "",
                    valueOf(getBaseActivity().availabilitySearchQuery.getNumberOfPassengers()), valueOf(getBaseActivity().availabilitySearchQuery.getNumberOfPassengersChild()),
                    valueOf(getBaseActivity().availabilitySearchQuery.getNumberOfPassengersChild()),
                    getBaseActivity().availabilitySearchQuery.isReturnTrip() ? "1" : "0",
                    getBaseActivity().availabilitySearchQuery.getDepartureDate(),
                    getBaseActivity().availabilitySearchQuery.isReturnTrip() ?
                            getBaseActivity().availabilitySearchQuery.getReturnDate() : "");

            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, getBaseActivity().carmaRequestAvailabilityExtendedMessage);
        } catch (Exception exception) {
            exception.printStackTrace();
            BaseActivity.logger.error("requestExtendedRequestAvailability exception" + exception);
        }
    }

    private void updateState(boolean isReturn) {
        Log.d(TAG, "updateState: " + isReturn);
        state = isReturn ? "Return" : "Departure";
        setTitle(state);

        updateRoutesByFilter(isReturn);

        for (BluDroidRoutesAndTimes r : routes) {
            r.setSelected(false);
            r.setIconSelected(R.drawable.ic_checkbox_off);
            Log.d(TAG, "displaying route: " + r);
        }

        if (isReturn) {
            getBaseActivity().bluDroidRoutesAndTimesReturn = null;
        } else {
            getBaseActivity().bluDroidRoutesAndTimes = null;
        }

        bluDroidCarmaRoutesAdapter.notifyDataSetChanged();
        //scroll to top of listview, posted since it may not be repopulated yet
        availability_search_results.getHandler().post(new Runnable() {
            @Override
            public void run() {
                availability_search_results.setSelectionAfterHeaderView();
            }
        });

        filterLayoutCarrier.setVisibility(isReturn ? View.INVISIBLE : View.VISIBLE);
        availability_search_results.setVisibility(routes.isEmpty() ? View.GONE : View.VISIBLE);
        no_results_message.setVisibility(routes.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void updateRoutesByFilter(boolean isReturn) {
        routes.clear();
        if (isReturn) {
            for (BluDroidRoutesAndTimes r : getBaseActivity().returnRoutes) {
                if (r.getCarrierName().equalsIgnoreCase(getBaseActivity().bluDroidRoutesAndTimes.getCarrierName())) {
                    routes.add(r);
                }
            }

        } else {
            String selectedCarrier = ((CarmaResponseItemMessage) filterCarrierSpinner.getSelectedItem()).getDescription();
            if (selectedCarrier.equalsIgnoreCase("All Carriers")) {
                routes.addAll(getBaseActivity().departureRoutes);
            } else {
                for (BluDroidRoutesAndTimes r : getBaseActivity().departureRoutes) {
                    if (r.getCarrierName().equalsIgnoreCase(selectedCarrier)) {
                        routes.add(r);
                    }
                }
            }
        }
    }

    //----------------------------------------------------------------------------------------------
    void toggleRouteSelect(final int pos) {
        Log.d(TAG, "toggleRouteSelect pos=" + pos);
        for (int i = 0; i < routes.size(); i++) {
            BluDroidRoutesAndTimes r = routes.get(i);
            if (pos != i) {
                r.setSelected(false);
                r.setIconSelected(R.drawable.ic_checkbox_off);
            } else {
                r.setSelected(!r.isSelected());
                r.setIconSelected(r.isSelected() ? R.drawable.ic_checkbox_on : R.drawable.ic_checkbox_off);
            }
        }
        bluDroidCarmaRoutesAdapter.notifyDataSetChanged();
        availability_search_results.smoothScrollToPosition(pos);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean onBackPressed() {
        if (state.equalsIgnoreCase("Return")) {
            updateState(false);
        } else {
            getBaseActivity().bluDroidRoutesAndTimes = null;
            getBaseActivity().bluDroidRoutesAndTimesReturn = null;
            getBaseActivity().fragmentCarmaSearchResults = null;
            getBaseActivity().fragmentCarmaPassengerDetailsWizard = null;
            getBaseActivity().fragmentCarmaConfirmPurchaseTicket = null;
            getBaseActivity().departureRoutes.clear();
            getBaseActivity().returnRoutes.clear();
            BaseActivity.isSearchResultsScreen = false;
            getMainActivity().gotoFragment(new FragmentCarmaSearchRoutesNew(), "FragmentCarmaSearchRoutesNew");
        }
        return true;
    }

    //----------------------------------------------------------------------------------------------
    @SuppressLint("ResourceAsColor")
    public void results(Object obj) {
        // assert response object

        if (obj instanceof CarmaAuthenticationResponseMessage) {
            getBaseActivity().carmaAuthenticationResponseMessage = (CarmaAuthenticationResponseMessage) obj;
            if (getBaseActivity().carmaAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                requestExtendedRequestAvailability();
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaAuthenticationResponseMessage, true);
            }

        } else if (obj instanceof CarmaResponseAvailabilityExtendedMessage) {
            getBaseActivity().closeAeonSocket(28);
            // cast obj to class type
            getBaseActivity().carmaResponseAvailabilityExtendedMessage = (CarmaResponseAvailabilityExtendedMessage) obj;
            // bind the data to UI views (list_view)
            // parse trips
            getBaseActivity().departureRoutes.clear();

            configureCarriersSpinner();

            int posInList = 0;
            for (CarmaResponseExtendedRouteMessage responseRouteMessage : getBaseActivity().carmaResponseAvailabilityExtendedMessage.getData().getRoutes()) {
                Log.d(TAG, "departRoute: " + responseRouteMessage.toString());

                String carrierName = "";
                for (CarmaResponseItemMessage carrierResponseItem : getBaseActivity().carmaResponseCarrierListMessage.getData().getItems()) {
                    if (responseRouteMessage.getCarrier().equals(carrierResponseItem.getCode())) {
                        carrierName = carrierResponseItem.getDescription();
                    }
                }

                String priceChild = ((responseRouteMessage.getPriceChild().isEmpty()) ? responseRouteMessage.getPriceAdult() : responseRouteMessage.getPriceChild());
                String priceInfant = ((responseRouteMessage.getPriceInfant().isEmpty()) ? responseRouteMessage.getPriceAdult() : responseRouteMessage.getPriceInfant());
                String mediaUrl = getBaseActivity().carmaResponseCarrierListMessage.getData().getMediaUrl();
                getBaseActivity().departureRoutes.add(
                        new BluDroidRoutesAndTimes(
                                responseRouteMessage.getTravelClassDescription(),
                                responseRouteMessage.getRouteCode(),
                                ((responseRouteMessage.getPriceAdult().isEmpty()) ? "0.0" : responseRouteMessage.getPriceAdult()),
                                priceChild,
                                priceInfant,
                                responseRouteMessage.getArriveTime(),
                                //boardDate,
                                responseRouteMessage.getBoardTime(),
                                responseRouteMessage.getCarrier(),
                                carrierName,
                                responseRouteMessage.getBoardLocationDescription(),
                                responseRouteMessage.getAvailable(),
                                responseRouteMessage.getDestLocationDescription(),
                                responseRouteMessage.getBoardTime(),
                                posInList, mediaUrl));
                posInList++;
            }

            getBaseActivity().returnRoutes.clear();
            int posInListReturn = 0;
            for (CarmaResponseExtendedRouteMessage responseRouteMessage : getBaseActivity().carmaResponseAvailabilityExtendedMessage.getData().getReturnRoutes()) {
                Log.d(TAG, "returnRoute: " + responseRouteMessage.toString());
                String carrierName = "";
                for (CarmaResponseItemMessage carrierResponseItem : getBaseActivity().carmaResponseCarrierListMessage.getData().getItems()) {
                    if (responseRouteMessage.getCarrier().equals(carrierResponseItem.getCode())) {
                        carrierName = carrierResponseItem.getDescription();
                    }
                }
                String priceChild = ((responseRouteMessage.getPriceChild().isEmpty()) ? responseRouteMessage.getPriceAdult() : responseRouteMessage.getPriceChild());
                String priceInfant = ((responseRouteMessage.getPriceInfant().isEmpty()) ? responseRouteMessage.getPriceAdult() : responseRouteMessage.getPriceInfant());
                String mediaUrl = getBaseActivity().carmaResponseCarrierListMessage.getData().getMediaUrl();

                //  for (CarmaResponseExtendedRouteMessage.TravelClass travelClass :responseRouteMessage.getTravelClasses()) {
                getBaseActivity().returnRoutes.add(
                        new BluDroidRoutesAndTimes(
                                responseRouteMessage.getTravelClassDescription(),
                                responseRouteMessage.getRouteCode(),
                                (responseRouteMessage.getPriceAdult() == null || responseRouteMessage.getPriceAdult().isEmpty() ? "0.0" : responseRouteMessage.getPriceAdult()),
                                priceChild,
                                priceInfant,
                                responseRouteMessage.getArriveTime(),
                                //boardDate,
                                responseRouteMessage.getBoardTime(),
                                responseRouteMessage.getCarrier(),
                                carrierName,
                                responseRouteMessage.getBoardLocationDescription(),
                                responseRouteMessage.getAvailable(),
                                responseRouteMessage.getDestLocationDescription(),
                                responseRouteMessage.getBoardTime(),
                                posInListReturn, mediaUrl));
                posInListReturn++;
                //   }
            }
            Collections.sort(getBaseActivity().departureRoutes, comparatorDate);
            Collections.sort(getBaseActivity().returnRoutes, comparatorDate);

        }
    }
    //----------------------------------------------------------------------------------------------
}