package za.co.blts.bltandroidgui3.confirmations;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.ImageView;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 3/23/2017.
 */

public class BluDroidElectricityPurchaseConfirmationDialog extends BluDroidConfirmationDialog implements BluDroidSetupable {

    private final String TAG = this.getClass().getSimpleName();

    private String supplierCode;

    public void setup() {
        super.setup();
        hideView(R.id.neutralButton);
        setAffirmativeButtonLabel(R.string.print);
        setNegativeButtonLabel(R.string.cancel);
        setHeading(R.string.confirm_purchase);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }


    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }

    public String getSupplierCode() {
        return supplierCode;
    }


    public BluDroidElectricityPurchaseConfirmationDialog(BaseActivity context) {
        super(context, R.layout.confirmation_purchase_electricity);
        setup();
        String TAG = this.getClass().getSimpleName();
        Log.d(TAG, "Purchase confirmation with activity");
        BaseActivity.logger.info(": construction with BaseActivity");
    }

    public void setMeterNumber(String meterNumber) {
        BluDroidTextView amountTextView = findViewById(R.id.meterNumber);
        if (amountTextView != null) {
            if (meterNumber != null)
                amountTextView.setText(meterNumber);
        }
    }

    public void setAccountHolder(String accountHolder) {
        BluDroidTextView amountTextView = findViewById(R.id.accountHolder);
        if (amountTextView != null) {
            if (accountHolder != null)
                amountTextView.setText(accountHolder);
        }
    }

    public void setAddress(String address) {
        BluDroidTextView amountTextView = findViewById(R.id.address);
        if (amountTextView != null) {
            if (address != null)
                amountTextView.setText(address);
        }
    }

    public void setAmount(String amount) {
        BluDroidTextView amountTextView = findViewById(R.id.amount);
        if (amountTextView != null) {
            if (amount != null)
                amountTextView.setText(amount);
        }
    }

    public void setOutstanding(String outstanding) {


        BluDroidTextView minTextView = findViewById(R.id.outstandingAmount);
        minTextView.setTextColor(baseActivity.getSkinResources().getErrorColor());

        BluDroidTextView minLabel = findViewById(R.id.outstandingAmountLabel);
        minLabel.setTextColor(baseActivity.getSkinResources().getErrorColor());

        minTextView.setText(outstanding);
    }

    public String getOutstanding() {
        BluDroidTextView minTextView = findViewById(R.id.outstandingAmount);
        String outstanding = "0";
        if (minTextView != null) {
            outstanding = minTextView.getText().toString();
        }
        return outstanding;
    }

    public String getAmount() {
        BluDroidTextView minTextView = findViewById(R.id.amount);
        String amount = "0";
        if (minTextView != null) {
            amount = minTextView.getText().toString();
        }
        return amount;
    }


    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

}
