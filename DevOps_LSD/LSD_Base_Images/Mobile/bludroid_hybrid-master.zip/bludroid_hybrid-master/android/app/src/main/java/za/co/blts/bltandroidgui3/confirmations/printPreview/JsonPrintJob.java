package za.co.blts.bltandroidgui3.confirmations.printPreview;

import org.json.JSONArray;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;

public class JsonPrintJob {
    private JSONArray lines;
    private boolean dynamicPrint;
    private boolean barcodes;

    public JsonPrintJob(JSONArray lines, boolean dynamicPrint, boolean barcodes) {
        this.lines = lines;
        this.dynamicPrint = dynamicPrint;
        this.barcodes = barcodes;
    }

    public JSONArray getLines() {
        return lines;
    }

    public void setLines(JSONArray lines) {
        this.lines = lines;
    }

    public boolean isDynamicPrint() {
        return dynamicPrint;
    }

    public void setDynamicPrint(boolean dynamicPrint) {
        this.dynamicPrint = dynamicPrint;
    }

    public boolean isBarcodes() {
        return barcodes;
    }

    public void setBarcodes(boolean barcodes) {
        this.barcodes = barcodes;
    }
}
