package za.co.blts.bltandroidgui3.cardviews;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewPlanetGames extends CardviewDataObject {

    public CardviewPlanetGames(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.planet_games,
                baseActivity.getResources().getColor(R.color.white),
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(false);
    }

    public String getSupplierCode() {
        return "-1";
    }
}

