package za.co.blts.bltandroidgui3.confirmations.printPreview;

import java.lang.ref.WeakReference;
import java.util.List;

import za.co.blts.bltandroidgui3.ActivityMain;

public class BluDroidSlipPreviewTopupDialog extends BluDroidSlipPreviewDialog {
    private final String TAG = this.getClass().getSimpleName();
    private WeakReference<ActivityMain> activityReference;

    public BluDroidSlipPreviewTopupDialog(final ActivityMain activity, List<PrintJob> printJobs) {
        super(activity, printJobs);
        activityReference = new WeakReference<>(activity);
        setTitle("Topup Preview");
        setup();
    }

    public void finishTransaction() {
        ActivityMain activity = activityReference.get();
        if (activity != null) {
            activity.completeTopupPrint();
        }
    }
}
