package za.co.blts.bltandroidgui3.widgets;

import android.widget.EditText;

public interface ScreenFlow {

    void gotMaxChars(EditText editText);

}
