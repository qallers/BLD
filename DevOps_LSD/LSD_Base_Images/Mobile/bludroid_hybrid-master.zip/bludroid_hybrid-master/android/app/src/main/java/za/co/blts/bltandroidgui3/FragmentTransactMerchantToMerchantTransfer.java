package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;

public class FragmentTransactMerchantToMerchantTransfer extends BaseFragment {


    private BluDroidRelativeLayout layout;

    private final String TAG = this.getClass().getSimpleName();

    public FragmentTransactMerchantToMerchantTransfer() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_transact_merchant_to_merchant_transfer, container, false);
        layout = rootView.findViewById(R.id.layout);


        final BluDroidEditText amountEditText = rootView.findViewById(R.id.amount);

        final BluDroidEditText accountNumber = rootView.findViewById(R.id.accountNumber);
        accountNumber.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent event) {
                Log.v(TAG, "actionId " + actionId + " event " + event);
                if (actionId == 0) {
                    accountNumber.setImeActionLabel(getResources().getString(R.string.next), EditorInfo.IME_ACTION_GO);
                    accountNumber.setInputType(InputType.TYPE_CLASS_TEXT);
                }

                return true;
            }
        });

        BluDroidButton showDetails = rootView.findViewById(R.id.showDetailsButton);

        showDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BaseActivity.logger.info(((BluDroidButton) view).getText());
                if (accountNumber.getText().toString().trim().isEmpty() && !layout.validate()) {

                    accountNumber.setErrorMessage(getResources().getString(R.string.account_number_required));
                    accountNumber.getErrorTextView().setText(getResources().getString(R.string.account_number_required));

                } else if (accountNumber.getText().toString().trim().isEmpty() && layout.validate()) {

                    accountNumber.setErrorMessage(getResources().getString(R.string.account_number_required));
                    accountNumber.getErrorTextView().setText(getResources().getString(R.string.account_number_required));

                } else if (!accountNumber.getText().toString().trim().isEmpty() && !layout.validate()) {

                } else {
                    accountNumber.removeErrorMessage();
                    accountNumber.getErrorTextView().setText("");

                    String account = accountNumber.getText().toString().trim();
                    String amount = amountEditText.getText().toString().trim();

                    getBaseActivity().authenticateForMerchantTransfers(account, amount);
                }
            }
        });

        return rootView;
    }

    @Override
    public boolean onBackPressed() {
        BaseActivity.logger.info(": onBackPressed()");
        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else if (getBaseActivity().navigatedFromSearch) {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentSearch(), "FragmentSearch").commit();
        } else {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentTransact(), "FragmentTransact").commit();
        }
        return true;
    }

}
