package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.viewpager.widget.ViewPager;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;

import static androidx.fragment.app.FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT;


public class FragmentPutco extends BaseFragment implements View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();

    public ViewPager _mViewPager;
    public PutcoPagerAdapter _adapter;
    private ImageView _btn1, _btn2, _btn3;
    private BluDroidButton buttonNext, buttonBack;

    public FragmentPutco() {

    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Log.d(TAG, "onViewCreated");
        String title = getActivity().getResources().getString(R.string.tickets);
        getActivity().setTitle(title);
        setUpView();
        setTab();
//        onCircleButtonClick();


        getBaseActivity().toolbar.setNavigationBackIcon();
        getBaseActivity().toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getBaseActivity().clearNFCActiveConsumer(true);
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_putco, container, false);

    }


//    private void onCircleButtonClick() {
//        _btn1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                _btn1.setImageResource(R.drawable.selected_item);
//                _mViewPager.setCurrentItem(0);
//
//            }
//        });
//        _btn2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                _btn2.setImageResource(R.drawable.selected_item);
//                _mViewPager.setCurrentItem(1);
//            }
//        });
//        _btn3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                _btn3.setImageResource(R.drawable.selected_item);
//                _mViewPager.setCurrentItem(2);
//            }
//        });
//    }

    private void setUpView() {
        _mViewPager = getView().findViewById(R.id.imageviewPager);
        _adapter = new PutcoPagerAdapter(getChildFragmentManager(), BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        _mViewPager.setAdapter(_adapter);
        _mViewPager.setCurrentItem(0);

        initButton();
    }

    private void setTab() {

        _mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int position) {
            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
            }

            @Override
            public void onPageSelected(int position) {
                _btn1.setImageResource(R.drawable.nonselected_item);
                _btn2.setImageResource(R.drawable.nonselected_item);
                _btn3.setImageResource(R.drawable.nonselected_item);
                btnAction(position);
            }
        });
    }

    private void btnAction(int action) {
        switch (action) {
            case 0:
                _btn1.setImageResource(R.drawable.selected_item);
                buttonBack.setEnabled(true);
                buttonBack.setBackgroundColor(getSkinResources().getButtonColor());
                break;
            case 1:
                _btn2.setImageResource(R.drawable.selected_item);
                buttonBack.setEnabled(true);
                buttonNext.setEnabled(true);
                buttonNext.setText(getString(R.string.next));
                buttonNext.setBackgroundColor(getSkinResources().getButtonColor());
                buttonBack.setBackgroundColor(getSkinResources().getButtonColor());
                break;
            case 2:
                _btn3.setImageResource(R.drawable.selected_item);
                buttonNext.setText(getString(R.string.pay));
                break;
        }
    }

    private void initButton() {
        buttonNext = getView().findViewById(R.id.next);
        buttonBack = getView().findViewById(R.id.back);

        buttonBack.setOnClickListener(this);
        buttonNext.setOnClickListener(this);

        buttonBack.setEnabled(true);
        buttonBack.setBackgroundColor(getSkinResources().getButtonColor());

        _btn1 = getView().findViewById(R.id.btn1);
        _btn1.setImageResource(R.drawable.selected_item);

        _btn2 = getView().findViewById(R.id.btn2);
        _btn3 = getView().findViewById(R.id.btn3);

        _btn2.setImageResource(R.drawable.nonselected_item);
        _btn3.setImageResource(R.drawable.nonselected_item);
    }

    @Override
    public void onClick(View view) {
        BaseActivity.logger.info(((BluDroidButton) view).getText());

        switch (view.getId()) {
            case R.id.next:
                Log.i(TAG, "Next button clicked on fragment: " + this);
                Log.d(TAG, "page number " + _mViewPager.getCurrentItem());

                //search route info
                if (_mViewPager.getCurrentItem() == 0) {
                    FragmentPutcoSearchRoute fragmentPutcoSearchRoute = (FragmentPutcoSearchRoute) _adapter.getItemIndex(0);
                    if (fragmentPutcoSearchRoute.layout.validate()) {
                        getBaseActivity().routeCode = fragmentPutcoSearchRoute.route.getText().toString();
                        _mViewPager.setCurrentItem(1);
                    }

                }
                ///Trip info
                else if (_mViewPager.getCurrentItem() == 1) {


                    if (getBaseActivity().putcoTrip != null) {

                        if (getBaseActivity().putcoTrip.getTravelClass().equals("1")) {

                            getBaseActivity().putcoTrip.setTravelClass(getBaseActivity().putcoTrip.getTravelClass().concat(" Day"));
                        } else {
                            getBaseActivity().putcoTrip.setTravelClass(getBaseActivity().putcoTrip.getTravelClass().concat(" Days"));
                        }

                        if (!getBaseActivity().checkUSBPrinter()) {
                            if (BaseActivity.logger != null)
                                BaseActivity.logger.warn("USB Printer is not ready");
                            return;
                        }
                        getBaseActivity().createPutcoCart();

                    } else {

                        getBaseActivity().createAlertDialog("Putco Trip", "Please select a Putco trip before you can continue.");
                    }

                }
                ///purchase ticket
                else if (_mViewPager.getCurrentItem() == 2) {
                    FragmentPutcoPurchaseTicket fragmentPutcoPurchaseTicket = (FragmentPutcoPurchaseTicket) _adapter.getItemIndex(2);
                    if (fragmentPutcoPurchaseTicket.layout.validate()) {
                        completeTransaction();
                    }
                }


                break;
            case R.id.back:

                if (_mViewPager.getCurrentItem() == 0) {
                    leavePutco();
                } else if (_mViewPager.getCurrentItem() == 1) {

                    getBaseActivity().routeCode = "";
                    _mViewPager.setCurrentItem(0);

                } else if (_mViewPager.getCurrentItem() == 2) {

                    getBaseActivity().results(getBaseActivity().ticketProResponseRouteMessage);
                    getBaseActivity().putcoTrip = null;
                    _mViewPager.setCurrentItem(1);
                }
                break;
            default:

                break;
        }

    }

    private void completeTransaction() {
        Log.d(TAG, "creating a progress dialog");
        getBaseActivity().createProgress(R.string.checkingPrinter);

        FragmentPutcoPurchaseTicket fragmentPutcoPurchaseTicket = (FragmentPutcoPurchaseTicket) _adapter.getItemIndex(2);
        getBaseActivity().startPutcoCompleteTrx(fragmentPutcoPurchaseTicket.cellNumber.getText().toString().replace(" ", ""), getBaseActivity().routeIndex, 1);
    }


    @Override
    public boolean onBackPressed() {
        if (_mViewPager.getCurrentItem() == 0) {
            leavePutco();

        } else if (_mViewPager.getCurrentItem() == 1) {

            getBaseActivity().routeCode = "";
            _mViewPager.setCurrentItem(0);

        } else if (_mViewPager.getCurrentItem() == 2) {

            getBaseActivity().results(getBaseActivity().ticketProResponseRouteMessage);
            getBaseActivity().putcoTrip = null;
            _mViewPager.setCurrentItem(1);
        }
        return true;
    }

    private void leavePutco() {
        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else {
            getBaseActivity().doPuctoStuff = false;
            Log.d(TAG, "going to FragmentTickets");
            getBaseActivity().gotoFragment(new FragmentTickets(), "FragmentTickets");
        }
    }

}

