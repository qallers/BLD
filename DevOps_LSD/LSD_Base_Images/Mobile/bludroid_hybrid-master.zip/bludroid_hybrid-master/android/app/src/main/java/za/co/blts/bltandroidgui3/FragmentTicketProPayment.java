package za.co.blts.bltandroidgui3;


import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseCheckOutMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePaymentMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePrintEZPLMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePrintMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static za.co.blts.bltandroidgui3.AEONErrors.NO_USER_ACTION_REQUIRED;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTicketProPayment extends TicketProRecycler implements View.OnClickListener, CompoundButton.OnCheckedChangeListener, NeedsAEONResults {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidRelativeLayout layout;

    private BluDroidEditText txtName;
    private BluDroidCellphoneEditText txtCell;

    public FragmentTicketProPayment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_ticket_pro_payment, container, false);
        layout = rootView.findViewById(R.id.layout);
        //    BluDroidHeading txtEventName;
        //    TextView txtVenue,txtDate,txtTime;
        //    ListView listView;
        BluDroidButton btnNext = rootView.findViewById(R.id.next);
        BluDroidButton btnBack = rootView.findViewById(R.id.back);
        BluDroidTextView txtNumTickets = rootView.findViewById(R.id.numTickets);
        BluDroidTextView txtAmountDue = rootView.findViewById(R.id.amountDue);
        txtName = rootView.findViewById(R.id.name);
        txtCell = rootView.findViewById(R.id.cellPhone);

        BluDroidRadioButton radioCash = rootView.findViewById(R.id.cashRadio);
        BluDroidRadioButton radioCredit = rootView.findViewById(R.id.creditRadio);
        BluDroidRadioButton radioDebit = rootView.findViewById(R.id.debitRadio);

        radioCash.setOnCheckedChangeListener(this);
        radioCredit.setOnCheckedChangeListener(this);
        radioDebit.setOnCheckedChangeListener(this);

        btnNext.setOnClickListener(this);
        btnBack.setOnClickListener(this);

        String disp = "R" + getBaseActivity().df2.format(getBaseActivity().ticketProTotal);
        txtAmountDue.setText(disp);
        txtNumTickets.setText(String.valueOf(getBaseActivity().ticketProResponseReservedSeatsMessage.getData().getSeats().size()));

        getBaseActivity().paymentType = "cash";

        return rootView;

    }


    @Override
    public void onClick(View v) {
        BaseActivity.logger.info(((BluDroidButton) v).getText());
        switch (v.getId()) {
            case R.id.next:
                if (layout.validate()) {
                    String name = txtName.getText().toString();
                    String cell = txtCell.getText().toString();

                    if (getBaseActivity().securePrint) {
                        if (getBaseActivity().checkUSBPrinter()) {

                            doTicketProcheckOut(name, cell.replace(" ", ""));
                        }
                    } else {

                        doTicketProcheckOut(name, cell.replace(" ", ""));
                    }

                }

                //getBaseActivity().gotoFragment(new FragmentTicketProPayment(),"FragmentTicketProPayment");
                break;
            case R.id.back:

                getBaseActivity().gotoFragment(new FragmentTicketProViewCart(), "FragmentTicketProViewCart");
                break;

            default:
                break;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        if (isChecked) {
            if (buttonView.getId() == R.id.cashRadio) {
                getBaseActivity().paymentType = "cash";
            } else if (buttonView.getId() == R.id.creditRadio) {
                getBaseActivity().paymentType = "creditCard";
            } else if (buttonView.getId() == R.id.debitRadio) {
                getBaseActivity().paymentType = "debitCard";
            }
        }
    }

    @Override
    public void results(Object object) {

        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(Payment) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }
        if (object instanceof TicketProResponseCheckOutMessage) {


            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProResponseCheckOutMessage = (TicketProResponseCheckOutMessage) object;

            if (getBaseActivity().ticketProResponseCheckOutMessage.getEvent().getEventCode().equals("0")) {
                payTicketProTicket(getBaseActivity().paymentType);
            } else {
                getBaseActivity().returnToFavouritesScreen = true;
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProResponseCheckOutMessage, true);
            }
        } else if (object instanceof TicketProResponsePaymentMessage) {
            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProResponsePaymentMessage = (TicketProResponsePaymentMessage) object;
            if (getBaseActivity().ticketProResponsePaymentMessage.getEvent().getEventCode().equals("0")) {
                if (false) {
                    //this causes a ticket to be checked out, but not printed
                    //the ticket ref number will be displayed as an error dialog
                    //can can then be used to test ticket collection
                    getBaseActivity().returnToFavouritesScreen = true;
                    getBaseActivity().createSystemErrorConfirmation(NO_USER_ACTION_REQUIRED, getBaseActivity().ticketProResponsePaymentMessage.getData().getReference(), true);
                } else {
                    getTicketProTickets();

                    int total = 0;
                    for (int i = 0; i < getBaseActivity().ticketProResponseReservedSeatsMessage.getData().getSeats().size(); i++) {
                        total += Double.parseDouble(getBaseActivity().ticketProResponseReservedSeatsMessage.getData().getSeats().get(i).getPrice());
                    }

                    getBaseActivity().saveDetailsUntilPaid(getBaseActivity().ticketProResponsePaymentMessage.getData().getTransRef(),
                            "Ticket Pro",
                            getBaseActivity().ticketProResponsePaymentMessage.getData().getReference(),
                            String.valueOf(total));
                }
            } else {
                getBaseActivity().returnToFavouritesScreen = true;
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProResponsePaymentMessage, true);
            }
        } else if (object instanceof TicketProResponsePrintMessage) {
//            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProResponsePrintMessage = (TicketProResponsePrintMessage) object;
            if (getBaseActivity().ticketProResponsePrintMessage.getEvent().getEventCode().equals("0")) {
                getBaseActivity().printEventTickets();
            } else {
                getBaseActivity().returnToFavouritesScreen = true;
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProResponsePrintMessage, true);
            }
        } else if (object instanceof TicketProResponsePrintEZPLMessage) {
//            getBaseActivity().dismissProgress();
            getBaseActivity().ticketProResponsePrintEZPLMessage = (TicketProResponsePrintEZPLMessage) object;
            if (getBaseActivity().ticketProResponsePrintEZPLMessage.getEvent().getEventCode().equals("0")) {

                getBaseActivity().cleanUp();
                getBaseActivity().createProgress(R.string.gettingTicketProFormattedTickets);

                HTTPGetAsyncTask getAsyncTask = new HTTPGetAsyncTask(getBaseActivity());
                getAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, getBaseActivity(), getBaseActivity().ticketProResponsePrintEZPLMessage.getData().getTickets());

            } else {
                getBaseActivity().returnToFavouritesScreen = true;
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().ticketProResponsePrintEZPLMessage, true);
            }
        }

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

//        getBaseActivity().toolbar.setNavigationDrawable();
//        getBaseActivity().toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                getBaseActivity().gotoMenuFragment();
//            }
//        });
    }

    @Override
    public boolean onBackPressed() {

        getBaseActivity().gotoFragment(new FragmentTicketProViewCart(), "FragmentTicketProViewCart");

        return true;
    }
}
