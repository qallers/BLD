package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.rica.request.RicaRequestMultipleSIMSMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestRegistrationMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;


public class FragmentRicaChangeOwner extends BaseFragment implements View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();

    public  ViewPager _mViewPager;
    private ImageView _btn1, _btn2, _btn3, _btn4;
    private BluDroidButton buttonNext, buttonBack;

    private RicaChangeOwnerPagerAdapter _adapter;


    public FragmentRicaChangeOwner() {
        // Required empty public constructor
        Log.d(TAG, "constructor");
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onViewCreated");
        super.onViewCreated(view, savedInstanceState);
        setUpView();
        setTab();
        onCircleButtonClick();
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        Log.d(TAG, "onActivityCreated");
        super.onActivityCreated(savedInstanceState);
        _mViewPager.setCurrentItem(0);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(TAG, "onCreateView");
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_rica_change_owner, container, false);
    }

    private void onCircleButtonClick() {
        Log.d(TAG, "onCircleButtonClick");
        _btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _btn1.setImageResource(R.drawable.selected_item);
                _mViewPager.setCurrentItem(0);
            }
        });
        _btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _btn2.setImageResource(R.drawable.selected_item);
                _mViewPager.setCurrentItem(1);
            }
        });
        _btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _btn3.setImageResource(R.drawable.selected_item);
                _mViewPager.setCurrentItem(2);
            }
        });
    }

    private void setUpView() {
        Log.d(TAG, "setUpView");
        _mViewPager = getView().findViewById(R.id.viewPager);
        _adapter = new RicaChangeOwnerPagerAdapter(getChildFragmentManager());
        _mViewPager.setAdapter(_adapter);
        _mViewPager.setCurrentItem(0);
        initButton();
    }

    private void setTab() {

        _mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int position) {
            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
            }

            @Override
            public void onPageSelected(int position) {
                _btn1.setImageResource(R.drawable.nonselected_item);
                _btn2.setImageResource(R.drawable.nonselected_item);
                _btn3.setImageResource(R.drawable.nonselected_item);
                _btn4.setImageResource(R.drawable.nonselected_item);
                btnAction(position);
            }
        });
    }

    private void btnAction(int action) {
        Log.d(TAG, "btnAction: " + action);
        switch (action) {
            case 0:
                _btn1.setImageResource(R.drawable.selected_item);
                buttonBack.setEnabled(false);
                buttonBack.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentRicaConsumerInfo", null);
                break;

            case 1:
                _btn2.setImageResource(R.drawable.selected_item);
                buttonBack.setEnabled(true);
                buttonNext.setEnabled(true);
                buttonNext.setBackgroundColor(getSkinResources().getButtonColor());
                buttonBack.setBackgroundColor(getSkinResources().getButtonColor());
                getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentRicaChangeNewConsumerInfo", null);
                break;

            case 2:
                _btn3.setImageResource(R.drawable.selected_item);
                buttonNext.setText(getString(R.string.next));
                getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentRicaChangeAddressInfo", null);
                break;

            case 3:
                _btn4.setImageResource(R.drawable.selected_item);
                buttonNext.setText(getString(R.string.submit));
                getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), "FragmentRicaChangeSimRegistration", null);
                break;
        }
    }

    private void initButton() {
        Log.d(TAG, "initButton");
        buttonNext = getView().findViewById(R.id.next);
        buttonBack = getView().findViewById(R.id.back);

        buttonBack.setOnClickListener(this);
        buttonNext.setOnClickListener(this);

        buttonBack.setEnabled(false);
        buttonBack.setBackgroundColor(getResources().getColor(R.color.lightGrey));

        _btn1 = getView().findViewById(R.id.btn1);
        _btn1.setImageResource(R.drawable.selected_item);

        _btn2 = getView().findViewById(R.id.btn2);
        _btn3 = getView().findViewById(R.id.btn3);
        _btn4 = getView().findViewById(R.id.btn4);
        _btn4.setVisibility(View.VISIBLE);

        _btn2.setImageResource(R.drawable.nonselected_item);
        _btn3.setImageResource(R.drawable.nonselected_item);
        _btn4.setImageResource(R.drawable.nonselected_item);
    }

    @Override
    public void onClick(View view) {
        BaseActivity.logger.info(((BluDroidButton) view).getText());
        switch (view.getId()) {
            case R.id.next:
                Fragment f = _adapter.getItemIndex(_mViewPager.getCurrentItem());
                Log.d(TAG, "onClick next: " + f.getClass().getSimpleName());
                //Consumer info
                if (_mViewPager.getCurrentItem() == 0) {

                    if (((FragmentRicaChangeConsumerInfo)f).userInfoLayout.validate()) {

                        getBaseActivity().ricaRegistrationMessage = new RicaRequestRegistrationMessage();
                        String countryCode = ((FragmentRicaChangeConsumerInfo)f).selectedNationality.substring(0, 2);
                        getBaseActivity().ricaRegistrationMessage.setExisting("true");
                        getBaseActivity().ricaRegistrationMessage.getCurrentOwner().setCountryCode(countryCode);

                        if (((FragmentRicaChangeConsumerInfo)f).idType.equals("idNumber")) {
                            getBaseActivity().ricaRegistrationMessage.getCurrentOwner().setIDType("N");
                            getBaseActivity().ricaRegistrationMessage.getCurrentOwner().setIDNumber(((FragmentRicaChangeConsumerInfo)f).consumerId.getText().toString());

                        } else {
                            getBaseActivity().ricaRegistrationMessage.getCurrentOwner().setIDType("P");
                            getBaseActivity().ricaRegistrationMessage.getCurrentOwner().setIDNumber(((FragmentRicaChangeConsumerInfo)f).passportNumber.getText().toString());
                        }
                        _mViewPager.setCurrentItem(1);
                    }
                }
                ///Address info
                else if (_mViewPager.getCurrentItem() == 1) {

                    if (((FragmentRicaChangeNewConsumerInfo)f).userInfoLayout.validate()) {

                        String countryCode = ((FragmentRicaChangeNewConsumerInfo)f).selectedNationality.substring(0, 2);

                        getBaseActivity().ricaRegistrationMessage.setFirstName(((FragmentRicaChangeNewConsumerInfo)f).consumerName.getText().toString());
                        getBaseActivity().ricaRegistrationMessage.setLastName(((FragmentRicaChangeNewConsumerInfo)f).consumerLastName.getText().toString());

                        if (((FragmentRicaChangeNewConsumerInfo)f).idType.equals("idNumber")) {
                            getBaseActivity().ricaRegistrationMessage.getIdInfo().setIDType("N");
                            getBaseActivity().ricaRegistrationMessage.getIdInfo().setIDNumber(((FragmentRicaChangeNewConsumerInfo)f).consumerId.getText().toString());

                        } else {
                            getBaseActivity().ricaRegistrationMessage.getIdInfo().setIDType("P");
                            getBaseActivity().ricaRegistrationMessage.getIdInfo().setIDNumber(((FragmentRicaChangeNewConsumerInfo)f).passportNumber.getText().toString());
                        }

                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setCountryCode(countryCode);

                        _mViewPager.setCurrentItem(2);
                    }
                }
                ///Sim info
                else if (_mViewPager.getCurrentItem() == 2) {

                    if (((FragmentRicaChangeAddressInfo)f).layout.validate()) {

                        String countryCode = ((FragmentRicaChangeAddressInfo)f).selectedCountry.substring(0, 2);

                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setAddressLine1(((FragmentRicaChangeAddressInfo)f).addressLine1.getText().toString());
                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setAddressLine2(((FragmentRicaChangeAddressInfo)f).addressLine2.getText().toString());
                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setPostalCode(((FragmentRicaChangeAddressInfo)f).postalCode.getText().toString());

                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setCountryCode(countryCode);
                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setSuburb(((FragmentRicaChangeAddressInfo)f).suburb.getText().toString());
                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setCityTown(((FragmentRicaChangeAddressInfo)f).city.getText().toString());

                        if (countryCode.equals("ZA")) {
                            getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setRegion(((FragmentRicaChangeAddressInfo)f).selectedProvince);
                        } else {
                            getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setRegion("");
                        }

                        _mViewPager.setCurrentItem(3);
                    }

                } else if (_mViewPager.getCurrentItem() == 3) {

                    if (((FragmentRicaChangeSimRegistration)f).layout.validate()) {

                        //remove the previously set ref numbers
                        getBaseActivity().ricaRegistrationMessage.setReferenceNumber("");
                        getBaseActivity().ricaRegistrationMessage.setReferenceNumbers(new ArrayList<RicaRequestMultipleSIMSMessage>());

                        String network = ((FragmentRicaChangeSimRegistration)f).selectedProvider;

                        switch (network) {
                            case "Vodacom":
                                getBaseActivity().ricaRegistrationMessage.setMsisdnNetwork("Vodacom");
                                getBaseActivity().ricaRegistrationMessage.setReferenceType("SIM");
                                Log.d(TAG, "vodacom showing");
                                break;

                            case "Cell C":
                                getBaseActivity().ricaRegistrationMessage.setMsisdnNetwork("CellC");
                                getBaseActivity().ricaRegistrationMessage.setReferenceType("SIM");
                                Log.d(TAG, "cellc showing");
                                break;

                            case "MTN":
                                getBaseActivity().ricaRegistrationMessage.setMsisdnNetwork("MTN");
                                getBaseActivity().ricaRegistrationMessage.setReferenceType("STARTER_PACK_REF");
                                Log.d(TAG, "mtn showing");
                                break;

                            case "Telkom Mobile":
                                getBaseActivity().ricaRegistrationMessage.setMsisdnNetwork("Telkom");
                                getBaseActivity().ricaRegistrationMessage.setReferenceType("SIM");
                                Log.d(TAG, "telkommobile showing");
                                break;

                            case "Virgin Mobile":
                                getBaseActivity().ricaRegistrationMessage.setMsisdnNetwork("VirginMobile");
                                getBaseActivity().ricaRegistrationMessage.setReferenceType("SIM");
                                Log.d(TAG, "virgin showing");
                                break;

                            default:
                                Log.d(TAG, "problem with network spinner");
                                break;
                        }

                        if (((FragmentRicaChangeSimRegistration)f).ricaSerialNumberList.size() != 0) {

                            if (((FragmentRicaChangeSimRegistration)f).ricaSerialNumberList.size() == 1) {
                                String sim = ((FragmentRicaChangeSimRegistration)f).ricaSerialNumberList.get(0);
                                String[] simParts = sim.split(",");
                                String serial = simParts[1];
                                getBaseActivity().ricaMultiRegistration = false;
                                getBaseActivity().ricaRegistrationMessage.setReferenceNumber(serial);
                                getBaseActivity().authenticateRicaChangeOwner();

                            } else {
                                getBaseActivity().ricaMultiRegistration = true;
                                RicaRequestMultipleSIMSMessage sim;

                                for (int i = 0; i < ((FragmentRicaChangeSimRegistration)f).ricaSerialNumberList.size(); i++) {
                                    String simMultiple = ((FragmentRicaChangeSimRegistration)f).ricaSerialNumberList.get(i);
                                    String[] simParts = simMultiple.split(",");
                                    String serial = simParts[1];
                                    sim = new RicaRequestMultipleSIMSMessage();
                                    sim.setReferenceNumber(serial);
                                    getBaseActivity().ricaRegistrationMessage.getReferenceNumbers().add(sim);
                                }
                                getBaseActivity().authenticateRicaChangeOwner();
                            }

                        } else {
                            getBaseActivity().createAlertDialog("RICA", "Please add a sim serial");
                        }
                    }

                }
                break;

            case R.id.back:
                if (_mViewPager.getCurrentItem() == 1) {
                    _mViewPager.setCurrentItem(0);
                } else if (_mViewPager.getCurrentItem() == 2) {
                    _mViewPager.setCurrentItem(1);
                } else if (_mViewPager.getCurrentItem() == 3) {
                    _mViewPager.setCurrentItem(2);
                }
                break;

            default:
                break;
        }
    }

}

