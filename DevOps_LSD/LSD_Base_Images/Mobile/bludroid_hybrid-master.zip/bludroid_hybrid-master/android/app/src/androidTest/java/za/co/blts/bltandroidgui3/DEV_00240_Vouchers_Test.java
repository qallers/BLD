package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 3/3/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00240_Vouchers_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_Menu() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }
            selectProviderAfricaPin();
            Log.d(TAG, "Goto Africa Pin");

            solo.goBack();
            selectProviderAxxess();
            Log.d(TAG, "Goto Axxess");

            solo.goBack();

            selectProviderBela();
            Log.d(TAG, "Goto Bela");

            solo.goBack();

            selectProviderTelkomWorldCard();
            Log.d(TAG, "Goto Telkom world card");

            solo.goBack();

            selectProviderStarSat();
            Log.d(TAG, "Goto StartSat");

            solo.goBack();

            selectProviderBetFlash();
            Log.d(TAG, "Goto Bet Flash");

            solo.goBack();

            selectProviderDabba();
            Log.d(TAG, "Goto dabba");

            solo.goBack();
            selectProviderLucky365();
            Log.d(TAG, "Goto Lucky365");

            solo.goBack();

            selectProviderHollywoodBet();
            Log.d(TAG, "Goto Hollywood Bets");

            solo.goBack();

            selectProviderLottery();
            Log.d(TAG, "Goto Lottery");

            solo.goBack();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_AfricaPin() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderAfricaPin();
            Log.d(TAG, "AfricaPIN MENU selected");

            solo.clickOnText("R250");
            Log.d(TAG, "R250 AfricaPIN voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T020_Axxess() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderAxxess();
            Log.d(TAG, "AXXESS MENU selected");

            solo.clickOnText("R140");
            Log.d(TAG, "R140 AXXESS voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T030_Bela() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderBela();
            Log.d(TAG, "Bela International Calling Card MENU selected");

            solo.clickOnText("R50");
            Log.d(TAG, "R50 Bela International Calling Card voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T040_TelkomWorldCard() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderTelkomWorldCard();
            Log.d(TAG, "Telkom World Card MENU selected");

            solo.clickOnText("R50");
            Log.d(TAG, "R50 Telkom World Card voucher selected");

            checkStock();

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T050_StarSat() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderStarSat();
            Log.d(TAG, "Star Sat MENU selected");

            solo.clickOnText("R178");
            Log.d(TAG, "R178 Star Sat voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T060_BetFlash() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderBetFlash();
            Log.d(TAG, "Bet Flash MENU selected");

            solo.clickOnText("R30");
            Log.d(TAG, "R30 Bet Flash voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T070_Dabba() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderDabba();
            Log.d(TAG, "Dabba MENU selected");

            solo.clickOnText("R50");
            Log.d(TAG, "R50 airtime voucher selected");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");
            solo.clickOnButton("-");
            Log.d(TAG, " Voucher quantity decreased");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T080_HollywoodBets() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderHollywoodBet();
            Log.d(TAG, "Hollywood Bets MENU selected");

            solo.clickOnText("R50");
            Log.d(TAG, "R50 Hollywood Bets voucher selected");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");
            solo.clickOnButton("-");
            Log.d(TAG, " Voucher quantity decreased");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T090_Lottery() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderLottery();
            Log.d(TAG, "Lotto MENU selected");

            selectLottoNumbers();
            Log.d(TAG, "Choose Lotto Numbers");
            solo.goBack();

            if (!solo.waitForDialogToOpen(1000))
                Log.d(TAG, "Exit dialog did not appear");
            else
                fail("Exit dialog appeared");

            selectPowerballNumbers();
            Log.d(TAG, "Choose Powerball Numbers");
            solo.goBack();

            if (!solo.waitForDialogToOpen(1000))
                Log.d(TAG, "Exit dialog did not appear");
            else
                fail("Exit dialog appeared");

            selectLottoQuickpick();
            Log.d(TAG, "Select Lotto Quickpick");
            solo.goBack();

            if (!solo.waitForDialogToOpen(1000))
                Log.d(TAG, "Exit dialog did not appear");
            else
                fail("Exit dialog appeared");

            selectPowerballQuickpick();
            Log.d(TAG, "Select PowerBall Quickpick");
            solo.goBack();

            if (!solo.waitForDialogToOpen(1000))
                Log.d(TAG, "Exit dialog did not appear");
            else
                fail("Exit dialog appeared");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T100_LotteryNumbers() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderLottery();
            Log.d(TAG, "National Lottery MENU selected");

            selectLottoNumbers();
            Log.d(TAG, "Choose Lotto Numbers");

            checks.enterText(R.id.qpNumBoardsBox, "2");
            Log.d(TAG, "Number of boards number entered");

            checks.enterText(R.id.qpNumDrawsBox, "2");
            Log.d(TAG, "Number of Draws number entered");

            confirmNumbers();
            Log.d(TAG, "Select Numbers");

            confirmBoardA();
            Log.d(TAG, "Select Board A");

            solo.clickOnText("7");
            solo.clickOnText("8");
            solo.clickOnText("17");
            solo.clickOnText("20");
            solo.clickOnText("32");

            solo.scrollDown();

            confirmAccept();
            Log.d(TAG, "Select Accept");

            if (solo.waitForDialogToOpen() && solo.searchText("Info")) {

                Log.d(TAG, "Please enter 6 numbers ");
                solo.clickOnButton("OK");
            }

            solo.clickOnText("47");

            Log.d(TAG, "Lotto Numbers selected for Bpard A");

            solo.scrollDown();

            confirmAccept();
            Log.d(TAG, "Select Accept");

            confirmPlay();
            Log.d(TAG, "Select play");

            confirmBoardB();
            Log.d(TAG, "Select Board B");

            solo.clickOnText("1");
            solo.clickOnText("18");
            solo.clickOnText("26");
            solo.clickOnText("20");
            solo.clickOnText("32");
            solo.clickOnText("47");
            Log.d(TAG, "Lotto Numbers selected for Board B");

            solo.scrollDown();

            confirmAccept();
            Log.d(TAG, "Select Accept");

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Lotto Plus 1");
            solo.clickOnCheckBox(1);
            Log.d(TAG, "Lotto Plus 2");

            //uncheck Lotto Plus 1 and Lotto Plus 2

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Uncheck Lotto Plus 1 and Lotto Plus 2");
            solo.sleep(100);


            // check them again
            solo.clickOnCheckBox(0);
            Log.d(TAG, "Lotto Plus 1");
            solo.clickOnCheckBox(1);
            Log.d(TAG, "Lotto Plus 2");

            confirmPlay();
            Log.d(TAG, "Select play");

            solo.waitForDialogToOpen();
            solo.clickOnButton("OK");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T110_PowerBallNumbers() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderLottery();
            Log.d(TAG, "National Lottery MENU selected");

            selectPowerballNumbers();
            Log.d(TAG, "Choose Powerball Numbers");

            checks.enterText(R.id.qpNumBoardsBox, "2");
            Log.d(TAG, "Number of boards number entered");

            checks.enterText(R.id.qpNumDrawsBox, "2");
            Log.d(TAG, "Number of Draws number entered");

            confirmNumbers();
            Log.d(TAG, "Select Numbers");

            confirmBoardA();
            Log.d(TAG, "Select Board A");

            selectPowerballNumbers(4);

            confirmAccept();
            Log.d(TAG, "Select Accept");

            if (solo.waitForDialogToOpen() && solo.searchText("Info")) {

                Log.d(TAG, "'Please enter 6 numbers' dialog box appeared");

                solo.clickOnText("OK");
                Log.d(TAG, "Clicked 'Ok'");
            }

            selectPowerballNumbers(1);

            confirmAccept();
            Log.d(TAG, "Select Accept");

            confirmBoardB();
            Log.d(TAG, "Select Board B");

            selectPowerballNumbers(4);

            confirmAccept();
            Log.d(TAG, "Select Accept");

            if (solo.waitForDialogToOpen() && solo.searchText("Info")) {
                Log.d(TAG, "'Please enter 6 numbers' dialog box appeared");
                solo.clickOnText("OK");
                Log.d(TAG, "Clicked 'Ok'");
            }

            selectPowerballNumbers(1);

            confirmAccept();
            Log.d(TAG, "Select Accept");

            solo.clickOnCheckBox(0);
            Log.d(TAG, " PowerBall Plus ");

            //uncheck Power Ball plus

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Uncheck Power Ball plus");

            //check Power Ball plus again
            solo.clickOnCheckBox(0);
            Log.d(TAG, "Power Ball plus Plus 1");

            confirmPlay();
            Log.d(TAG, "Select play");

            selectPowerball();

            confirmAccept();
            Log.d(TAG, "Select Accept");

            confirmPlay();
            Log.d(TAG, "Select play");

            selectPowerball();

            confirmAccept();
            Log.d(TAG, "Select Accept");

            confirmPlay();
            Log.d(TAG, "Select play");

            solo.clickOnText("OK");
            Log.d(TAG, "Clicked 'OK'");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T120_LotteryQuickPick() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderLottery();
            Log.d(TAG, "National Lottery MENU selected");

            selectLottoQuickpick();
            Log.d(TAG, "Select Lotto Quickpick");

            checks.enterText(R.id.qpNumBoardsBox, "2");
            Log.d(TAG, "Entered number of Boards");

            checks.enterText(R.id.qpNumDrawsBox, "2");
            Log.d(TAG, "Entered number of Draws");

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Lotto Plus 1");
            solo.clickOnCheckBox(1);
            Log.d(TAG, "Lotto Plus 2");

            //uncheck Lotto Plus 1 and Lotto Plus 2

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Uncheck Lotto Plus 1 and Lotto Plus 2");
            solo.sleep(100);

            // check them again
            solo.clickOnCheckBox(0);
            Log.d(TAG, "Lotto Plus 1");
            solo.clickOnCheckBox(1);
            Log.d(TAG, "Lotto Plus 2");

            confirmPlay();
            Log.d(TAG, "Select play");

            solo.clickOnText("OK");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T130_PowerBallQuickPick() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderLottery();
            Log.d(TAG, "National Lottery MENU selected");

            selectPowerballQuickpick();
            Log.d(TAG, "Select Power Ball Quickpick");

            checks.enterText(R.id.qpNumBoardsBox, "2");
            Log.d(TAG, "Entered number of Boards");

            checks.enterText(R.id.qpNumDrawsBox, "2");
            Log.d(TAG, "Entered number of Draws");

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Power Ball plus Plus 1");

            //uncheck Power Ball plus

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Uncheck Power Ball plus");

            //check Power Ball plus again
            solo.clickOnCheckBox(0);
            Log.d(TAG, "Power Ball plus Plus 1");

            confirmPlay();
            Log.d(TAG, "Select play");

            solo.clickOnText("OK");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T140_Lucky365() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderLucky365();
            Log.d(TAG, "Lucky365 MENU selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 Lucky365 voucher selected");
            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with no cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberNotEntered))) {
                Log.d(TAG, "Cellphone number not entered error message displayed");
            } else {
                fail("Cellphone number not entered error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "1121231234");
            Log.d(TAG, "Invalid cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "1121231234");
            Log.d(TAG, "Invalid cellphone number confirmed");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with invalid cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberInvalid))) {
                Log.d(TAG, "Cellphone number invalid error message displayed");
            } else {
                fail("Cellphone number invalid error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Not Matching Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231235");
            Log.d(TAG, "Not Matching Cellphone number confirmed");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with mismatching cellphone numbers");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumbersDontMatch))) {
                Log.d(TAG, "Cellphone numbers don't match error message displayed");
            } else {
                fail("Cellphone numbers don't match error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231234");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");


        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    @Test
    public void T150_BluVoucher() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

      /*selectC4C();
      Log.d(TAG, "C4C MENU selected");*/

            selectMVNOBluVoucher();
            Log.d(TAG, "BluVoucher MENU selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 BluVoucher voucher selected");

            checkStock();
            Log.d(TAG, "Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


}
