package za.co.blts.bltandroidgui3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blts.bltandroidgui3.confirmations.BluDroidUpdateUserInfoDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 4/5/2017.
 */

class BluDroidUserListAdapter extends ArrayAdapter<BluDroidUser> implements View.OnClickListener {

    private WeakReference<BaseActivity> baseActivityWeakReference;
    private int layoutResourceId;
    private int selectedPosition;

    public BluDroidUserListAdapter(BaseActivity context, int layoutResourceId, ArrayList<BluDroidUser> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.layoutResourceId = layoutResourceId;
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    protected BluDroidUser getUser() {
        return getItem(selectedPosition);
    }

    @Override
    public void onClick(View v) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            int position = (Integer) v.getTag();
            selectedPosition = position;
            baseActivity.user = getItem(position);

            baseActivity.createUpdateUserinfoDialog();

            if (baseActivity.confirmation instanceof BluDroidUpdateUserInfoDialog) {
                BluDroidUpdateUserInfoDialog dialog = (BluDroidUpdateUserInfoDialog) baseActivity.confirmation;

                dialog.setName(baseActivity.user.getName());
                dialog.setLevel(baseActivity.user.getUserLevel());
                dialog.setUserID(baseActivity.user.getId());
                dialog.setPermissions(baseActivity.user.getPermissions());
            }
        }


    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        BluDroidUser user = getItem(position);

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(layoutResourceId, parent, false);
        }

        BluDroidRelativeLayout userInfo = convertView.findViewById(R.id.userInfo);

        //hide currently logged in user
        String loggedInUserId = BaseActivity.loginResponseMessage.getData().getUserId();

        final BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            if (loggedInUserId.equals(user.getId())) {
                userInfo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        baseActivity.createNotification("This User cannot be updated currently");
                    }
                });
                userInfo.setBackgroundColor(baseActivity.getResources().getColor(R.color.lightGrey));
            } else {
                userInfo.setOnClickListener(this);
                userInfo.setBackgroundColor(baseActivity.getSkinResources().getBackgroundColor());
            }
        }

        userInfo.setTag(position);

        String level = user.getUserLevel();
        String name = user.getName();
        // baseActivity.userPermissions = user.getPermissions();

        String userType = "";

        switch (level) {
            case "0":
                userType = "Cashier";
                break;
            case "1":
                userType = "Supervisor";
                break;
            case "2":
                userType = "CashierPlus";
                break;
        }

        String header = userType + " / " + name;

        BluDroidTextView txtName = convertView.findViewById(R.id.userText);
        txtName.setText(header);

        // Return the completed view to render on screen
        return convertView;
    }
}
