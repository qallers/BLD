package za.co.blts.bltandroidgui3.widgets;

public interface BluDroidValidatable {

    boolean validate();

}

