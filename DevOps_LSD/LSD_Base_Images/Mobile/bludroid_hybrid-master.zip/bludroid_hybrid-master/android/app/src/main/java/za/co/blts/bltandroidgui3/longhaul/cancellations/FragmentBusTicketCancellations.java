package za.co.blts.bltandroidgui3.longhaul.cancellations;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.squareup.picasso.Picasso;

import za.co.blt.interfaces.external.factories.CarmaRequestFactory;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestBookingCancellationMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseBookingCancellationMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseItemMessage;
import za.co.blts.bltandroidgui3.AEONErrors;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.FragmentCarmaSearchRoutesNew;
import za.co.blts.bltandroidgui3.NeedsAEONResults;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidErrorTextView;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;

public class FragmentBusTicketCancellations extends BaseFragment implements NeedsAEONResults {

    private final String TAG = this.getClass().getSimpleName();

    private LinearLayout mainLayout, successLayout;

    private BluDroidTextView tvDeparture, tvDestination, tvTransactionDte, tvNumTickets, tvCarrier, tvDepartDate, tvRefundAmt;
    private BluDroidErrorTextView errorReason;
    private BluDroidSpinner spCancelReason;

    private ImageView ivBusLogo, ivBusLogo2;

    private TicketCacheHandler ticketCacheHandler;
    private CancelTicket ticket;
    private String transRef, cancellationReason;

    private CarmaResponseBookingCancellationMessage carmaResponseBookingCancellationMessage;

    public FragmentBusTicketCancellations() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_ticket_cancellations, container, false);
        mainLayout = rootView.findViewById(R.id.layout_cancel_ticket);
        mainLayout.setVisibility(View.GONE);
        successLayout = rootView.findViewById(R.id.layout_cancel_success);
        successLayout.setVisibility(View.GONE);

        tvCarrier = rootView.findViewById(R.id.tvCarrier);
        tvDeparture = rootView.findViewById(R.id.tvDeparture);
        tvDestination = rootView.findViewById(R.id.tvDestination);
        tvTransactionDte = rootView.findViewById(R.id.tvTransactionDte);
        tvNumTickets = rootView.findViewById(R.id.tvNumTickets);
        errorReason = rootView.findViewById(R.id.errorReason);
        tvDepartDate = rootView.findViewById(R.id.tvDepartDate);
        tvRefundAmt = rootView.findViewById(R.id.tvRefundAmt);

        ivBusLogo = rootView.findViewById(R.id.ivBusLogo);
        ivBusLogo2 = rootView.findViewById(R.id.ivBusLogo2);

        spCancelReason = rootView.findViewById(R.id.cancellation_reason_spinner);
        spCancelReason.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                errorReason.setText("");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                errorReason.setText("");
            }
        });

        ticketCacheHandler = new TicketCacheHandler(getBaseActivity().ticketCancelCacheDir);
        ticket = null;

        rootView.findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (areAllFieldsAnswered()) {
                    processCancellationRequest();
                } else {
                    Log.e(TAG, "Some fields have missing input.");
                }
            }
        });
        rootView.findViewById(R.id.btnBack1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        rootView.findViewById(R.id.btnBack2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        rootView.findViewById(R.id.btnReprint).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                printMerchantSlip();
            }
        });

        requestTicketReference();

        return rootView;
    }

    private void requestTicketReference() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
        final View view = LayoutInflater.from(getContext()).inflate(R.layout.layout_insert_bus_ticket_reference_number, null);
        final BluDroidEditText etRefNo = (BluDroidEditText) view.findViewById(R.id.etTicketRefNo);

        alertDialog.setView(view);
        alertDialog.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ticket = ticketCacheHandler.getTicketByRef(etRefNo.getText().toString());
                if (ticket != null) {
                    transRef = etRefNo.getText().toString();
                    mainLayout.setVisibility(View.VISIBLE);
                    successLayout.setVisibility(View.GONE);

                    tvTransactionDte.setText(ticket.getTransactionDate());
                    tvDeparture.setText(ticket.getDeparture());
                    tvDestination.setText(ticket.getDestination());
                    tvNumTickets.setText(String.valueOf(ticket.getQty()));
                    tvCarrier.setText(ticket.getCarrierName().toUpperCase());
                    tvDepartDate.setText(ticket.getTravelTime());

                    String imageURL = getBaseActivity().carmaResponseCarrierListMessage.getData().getMediaUrl() + ticket.getCarrier() + ".png";
                    Log.i(TAG, "getView: imageURL = " + imageURL);

                    if (ivBusLogo != null) {
                        ivBusLogo.setTag(imageURL);
                        Picasso picasso = Picasso.get();
                        picasso.setIndicatorsEnabled(getBaseActivity().isDebug());
                        picasso
                                .load(imageURL)
                                .placeholder(R.drawable.longhaul)
                                .error(R.drawable.longhaul)
                                .into(ivBusLogo);
                    }
                } else {
                    mainLayout.setVisibility(View.GONE);
                    popUpErrorNoTicket();
                }

            }
        });
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                onBackPressed();
            }
        });

        alertDialog.setCancelable(false);
        alertDialog.create().show();
    }

    private void popUpErrorNoTicket() {
        getBaseActivity().alert = new BluDroidAlertDialog(getBaseActivity());
        getBaseActivity().alert.setTitle("Cancel Error");
        getBaseActivity().alert.setMessage("Ticket not found.  Please contact Support to cancel the ticket.");
        getBaseActivity().alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                getBaseActivity().alert.dismiss();
                onBackPressed();
            }
        });
        getBaseActivity().alert.show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public boolean onBackPressed() {
        getBaseActivity().gotoFragment(new FragmentCarmaSearchRoutesNew(), "FragmentCarmaSearchRoutesNew");
        return true;
    }

    private String lookupCarrierTrxType(String carrierName) {
        if (getBaseActivity().carmaResponseCarrierListMessage != null) {
            for (CarmaResponseItemMessage item : getBaseActivity().carmaResponseCarrierListMessage.getData().getItems()) {
                if (item.getDescription().equals(carrierName)) {
                    return item.getTransType();
                }
            }
        }
        return null;
    }

    private void processCancellationRequest() {
        try {
            String transType = lookupCarrierTrxType(ticket.getCarrierName());
            if (transType == null) {
                getBaseActivity().createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, "Carrier name not recognized", true);
                return;
            }

            getBaseActivity().createProgress(R.string.authenticating);
            CarmaRequestFactory factory = new CarmaRequestFactory();

            getBaseActivity().carmaAuthenticationRequestMessage =
                    factory.create(
                            BaseActivity.loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER),
                            transType);

            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, getBaseActivity().carmaAuthenticationRequestMessage);
        } catch (Exception exception) {
            //Log.v(TAG, "prepareCarma throws " + exception);
        }
    }

    private void requestBookingCancellation() {
        try {
            getBaseActivity().createProgress(R.string.authenticating);
            CarmaRequestFactory factory = new CarmaRequestFactory();

            CarmaRequestBookingCancellationMessage carmaRequestBookingCancellationMessage =
                    factory.createBookingCancellation(getBaseActivity().carmaAuthenticationResponseMessage, transRef, cancellationReason);

            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, carmaRequestBookingCancellationMessage);
        } catch (Exception exception) {
            //Log.v(TAG, "prepareCarma throws " + exception);
        }
    }

    private boolean areAllFieldsAnswered() {
        int reasonIdx = spCancelReason.getSelectedItemPosition();

        if (reasonIdx == 0) {
            errorReason.setText("Required");
            return false;
        } else {
            cancellationReason = spCancelReason.getSelectedItem().toString();
        }

        return true;
    }

    private CarmaResponseBookingCancellationMessage dummySuccessfulResponse() {
        CarmaResponseBookingCancellationMessage response = new CarmaResponseBookingCancellationMessage();
        response.setSessionId("111-222-333-444");
        response.setEventType("BookingCancellation");
        response.getEvent().setEventCode("0");
        response.getData().setAeonTransactionReference(transRef);
        response.getData().setMessage("Success");
        response.getData().setReversedAmount("290");
        response.getData().setTraceNo("9876543210");
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("E", "Merchant Copy"));
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("A", "Device ID   :              29718"));
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("A", "Shift No    :                  1"));
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("A", "Sequence No.:                114"));
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("A", "Trans Type "));
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("A", ":BUSTICKETSCANCELLATION"));
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("A", "Product    :  IM A00000019747134"));
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("A", "Reversed Amount      :    310.00"));
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("A", "Cashier     :         Supervisor"));
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("A", "Trx Ref     :         1000048098"));
        response.getData().getMerchantPrintLines().add(getBaseActivity().printLine("A", "Date        :2020-10-08 11:45:25"));
        return response;
    }


    public void results(Object obj) {
        if (obj instanceof CarmaAuthenticationResponseMessage) {
            getBaseActivity().carmaAuthenticationResponseMessage = (CarmaAuthenticationResponseMessage) obj;
            if (getBaseActivity().carmaAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                requestBookingCancellation();
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaAuthenticationResponseMessage, true);
            }
        } else if (obj instanceof CarmaResponseBookingCancellationMessage) {
            getBaseActivity().dismissProgress();
            carmaResponseBookingCancellationMessage = (CarmaResponseBookingCancellationMessage) obj;

            if (carmaResponseBookingCancellationMessage.getEvent().getEventCode().equals("0")) {
                Log.v(TAG, "booking cancelled");
                //not checking for user preference here, as slip should always be printed
                printMerchantSlip();

                mainLayout.setVisibility(View.GONE);
                successLayout.setVisibility(View.VISIBLE);

                tvRefundAmt.setText(carmaResponseBookingCancellationMessage.getData().getReversedAmount());
                String imageURL = getBaseActivity().carmaResponseCarrierListMessage.getData().getMediaUrl() + ticket.getCarrier() + ".png";
                if (ivBusLogo2 != null) {
                    ivBusLogo2.setTag(imageURL);
                    Picasso picasso = Picasso.get();
                    picasso.setIndicatorsEnabled(getBaseActivity().isDebug());
                    picasso.load(imageURL)
                            .placeholder(R.drawable.longhaul)
                            .error(R.drawable.longhaul)
                            .into(ivBusLogo2);
                }

                ticketCacheHandler.deleteTicketByRef(transRef);

            } else {
                getBaseActivity().createSystemErrorConfirmation(carmaResponseBookingCancellationMessage, true);
            }
        }
    }

    private void printMerchantSlip() {
        getBaseActivity().print(carmaResponseBookingCancellationMessage.getData().getMerchantPrintLines());
    }
}
