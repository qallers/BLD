package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseCategoryMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseGetProductListMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseProductMessage;
import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponseListSuppliersMessage;
import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponseSupplierMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseDataMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseGroupMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseTransactionTypeMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseManufacturerMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseProductMessage;

/**
 * Created by warrenm on 2017/02/07.
 */

class VoucherUtility extends BaseFragment {

    private final String TAG = this.getClass().getSimpleName();
    private Context context;
    private LinkedList<Provider> providers = null;

    private static VoucherListResponseMessage voucherListResponseMessage = null;

    private boolean isAirtimePlusAllowed;
    private String airtimePlusValue;

    private boolean walletTopUpEnabled = false;


    public VoucherUtility() {
        initProviders();
    }

    @SuppressLint("ValidFragment")
    public VoucherUtility(Context context) {
        this.context = context;
        initProviders();
    }

    public String getAirtimePlusValue() {
        return airtimePlusValue;
    }

    public boolean isAirtimePlusAllowed() {
        return isAirtimePlusAllowed;
    }

    private void initProviders() {
        providers = getNetworkList();
    }


    private LinkedList<Provider> getNetworkList() {
        LinkedList<Provider> networks = new LinkedList<>();
        Provider vodacom = new Provider("Vodacom");
        Provider mtn = new Provider("MTN");
        Provider cellc = new Provider("Cell C");
        Provider telkomMobile = new Provider("Telkom Mobile");
        Provider neotel = new Provider("Neotel");
        Provider virgin = new Provider("Virgin Mobile");
        Provider lucky365 = new Provider("Lucky365");
        Provider connect = new Provider("connect");

        networks.add(vodacom);
        networks.add(mtn);
        networks.add(cellc);
        networks.add(telkomMobile);
        networks.add(neotel);
        networks.add(virgin);
        networks.add(lucky365);
        networks.add(connect);


        LoginResponseMessage loginResponseMessage = BaseActivity.loginResponseMessage;

        if (loginResponseMessage != null) {
            LoginResponseDataMessage data = loginResponseMessage.getData();
            for (int i = 0; i < data.getTransactionTypes().size(); i++) {
                LoginResponseGroupMessage group = data.getTransactionTypes().get(i);
                for (int j = 0; j < group.getTransactionTypes().size(); j++) {
                    LoginResponseTransactionTypeMessage transactionType = group.getTransactionTypes().get(j);
                    String transactionName = transactionType.getDisplayName().toLowerCase();
                    String type = transactionType.getType().toLowerCase();
                    switch (type) {
                        case "vouchers":
                            if (transactionName.startsWith("voucher")) {
                                voucherListResponseMessage = BaseActivity.voucherListResponseMessage;
                                if (voucherListResponseMessage != null) {
                                    ArrayList<VoucherListResponseManufacturerMessage> manufacturerMessages = voucherListResponseMessage.getData().getManufacturers();
                                    for (VoucherListResponseManufacturerMessage msg : manufacturerMessages) {
                                        String manufacturerName = msg.getName().toLowerCase();
                                        if (manufacturerName.startsWith("vodacom")) {
                                            vodacom.setHasVouchers(true);
                                        }
                                        if (manufacturerName.startsWith("mtn")) {
                                            mtn.setHasVouchers(true);
                                        }
                                        if (manufacturerName.startsWith("cell")) {
                                            cellc.setHasVouchers(true);
                                        }
                                        if (manufacturerName.startsWith("telkom mobile") || transactionName.startsWith("telkommobile")) {
                                            telkomMobile.setHasVouchers(true);
                                        }
                                        if (manufacturerName.startsWith("neotel")) {
                                            neotel.setHasVouchers(true);
                                        }
                                        if (manufacturerName.startsWith("virgin")) {
                                            virgin.setHasVouchers(true);
                                        }

                                        if (!msg.getAirtimePlus().equalsIgnoreCase("")) {
                                            if (manufacturerName.startsWith("vodacom")) {
                                                vodacom.setHasAirtimePlus(true);
                                            }
                                            if (manufacturerName.startsWith("mtn")) {
                                                mtn.setHasAirtimePlus(true);
                                            }
                                            if (manufacturerName.startsWith("cell")) {
                                                cellc.setHasAirtimePlus(true);
                                            }
                                            if (manufacturerName.startsWith("telkom mobile") || transactionName.startsWith("telkommobile")) {
                                                telkomMobile.setHasAirtimePlus(true);
                                            }
                                            if (manufacturerName.startsWith("neotel")) {
                                                neotel.setHasAirtimePlus(true);
                                            }
                                            if (manufacturerName.startsWith("virgin")) {
                                                virgin.setHasAirtimePlus(true);
                                            }

                                            if (manufacturerName.toLowerCase().startsWith("unipin")) {
                                                cellc.setHasAirtimePlus(true);
                                            }
                                            if (manufacturerName.startsWith("telkom mobile") || transactionName.startsWith("telkommobile")) {
                                                telkomMobile.setHasAirtimePlus(true);
                                            }
                                            if (manufacturerName.startsWith("neotel")) {
                                                neotel.setHasAirtimePlus(true);
                                            }
                                            if (manufacturerName.startsWith("virgin")) {
                                                virgin.setHasAirtimePlus(true);
                                            }

                                        }
                                    }
                                }

                            }

                            if (transactionName.equalsIgnoreCase("RechargePlus")) {
                                isAirtimePlusAllowed = true;
                                airtimePlusValue = transactionType.getValue();
                            }
                            break;
                        case "topup":
                            if (transactionName.startsWith("vodacom")) {
                                vodacom.setHasTopup(true);
                            }
                            if (transactionName.startsWith("mtn")) {
                                mtn.setHasTopup(true);
                            }
                            if (transactionName.startsWith("cell")) {
                                cellc.setHasTopup(true);
                            }
                            if (transactionName.startsWith("telkommobile") || transactionName.startsWith("telkom mobile")) {
                                telkomMobile.setHasTopup(true);
                            }
                            if (transactionName.startsWith("neotel")) {
                                neotel.setHasTopup(true);
                            }
                            if (transactionName.startsWith("virgin")) {
                                virgin.setHasTopup(true);
                            }
                            break;
                        case "bundles":
                            if (transactionName.startsWith("vodacom")) {
                                vodacom.setHasBundles(true);
                            }
                            if (transactionName.startsWith("mtn")) {
                                mtn.setHasBundles(true);
                            }
                            if (transactionName.startsWith("cell")) {
                                cellc.setHasBundles(true);
                            }
                            if (transactionName.startsWith("telkommobile") || transactionName.startsWith("telkom mobile")) {
                                telkomMobile.setHasBundles(true);
                            }
                            if (transactionName.startsWith("neotel")) {
                                neotel.setHasBundles(true);
                            }
                            if (transactionName.startsWith("virgin")) {
                                virgin.setHasBundles(true);
                            }
                            if (containsCaseInsensitive(transactionName, BaseActivity.walletTopupProviders)) {
                                walletTopUpEnabled = true;
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
        } else {
            networks.clear();
        }

        Provider all = new Provider("All");
        all.setHasVouchers(true);
        all.setHasTopup(true);
        all.setHasBundles(true);
        networks.add(all);
        return removeProvidersWithNoVouchers(networks);
    }

    private LinkedList<Provider> getOtherVouchersMenuList() {
        LinkedList<Provider> networks = getProviders();
        LinkedList<Provider> otherVouchersMenuList = new LinkedList<>();

        if (networks.size() > 0) {
            voucherListResponseMessage = BaseActivity.voucherListResponseMessage;
            if (voucherListResponseMessage != null) {
                ArrayList<VoucherListResponseManufacturerMessage> manufacturerMessages = voucherListResponseMessage.getData().getManufacturers();
                for (VoucherListResponseManufacturerMessage msg : manufacturerMessages) {
                    String manufacturerName = msg.getName();
                    Log.i("manufacturerName", manufacturerName);
                    if ( //Networks providers
                            !manufacturerName.startsWith("Vodacom") &&
                                    !manufacturerName.startsWith("MTN") &&
                                    !manufacturerName.startsWith("Cell") &&
                                    !manufacturerName.startsWith("Telkom Mobile") &&
                                    !manufacturerName.startsWith("Neotel") &&
                                    !manufacturerName.startsWith("Virgin") &&
                                    //Electricity providers
                                    !manufacturerName.startsWith("Power") &&
                                    !manufacturerName.startsWith("UniPin")) {
                        Provider p = new Provider(manufacturerName);
                        if (!msg.getAirtimePlus().isEmpty()) {
                            p.setHasAirtimePlus(true);
                        }
                        otherVouchersMenuList.add(p);

                    }

                    if (walletTopUpEnabled) {
                        for (String providerName : BaseActivity.walletTopupProviders) {
                            Provider p = new Provider(providerName);
                            otherVouchersMenuList.add(p);
                        }
                    }
                }
            }
        }

        if (context != null) {
            Chat4ChangeResponseListSuppliersMessage mvnoList = ((BaseActivity) context).getCachedMVNOData();
            if (mvnoList != null) {
                for (Chat4ChangeResponseSupplierMessage c4cSupplier : mvnoList.getData().getSuppliers()) {
                    if (c4cSupplier.getName().equalsIgnoreCase("bluvoucher")) {
                        Provider p = new Provider(c4cSupplier.getName());
                        p.setHasAirtimePlus(false);
                        otherVouchersMenuList.add(p);
                    }
                }
            }
        }

        //todo: Remove hardcoded provider once backend is ready
//        Provider deezer = new Provider("Deezer");
//        otherVouchersMenuList.add(deezer);
//        Provider googlePlay = new Provider("Google Play");
//        otherVouchersMenuList.add(googlePlay);
//        Provider netflix = new Provider("Netflix");
//        otherVouchersMenuList.add(netflix);
//        Provider planetGames = new Provider("Planet Games");
//        otherVouchersMenuList.add(planetGames);
//        Provider playstation = new Provider("Playstation");
//        otherVouchersMenuList.add(playstation);
//        Provider showmax = new Provider("Showmax");
//        otherVouchersMenuList.add(showmax);
//        Provider spotify = new Provider("Spotify");
//        otherVouchersMenuList.add(spotify);
//        Provider steam = new Provider("Steam");
//        otherVouchersMenuList.add(steam);
//        Provider uber = new Provider("Uber");
//        otherVouchersMenuList.add(uber);
//        Provider uberEats = new Provider("Uber Eats");
//        otherVouchersMenuList.add(uberEats);

        for (Provider p : otherVouchersMenuList) {
            Log.d(TAG, "Other Provider: " + p.getProviderName());
        }


        return otherVouchersMenuList;
    }

    private LinkedList<Provider> removeProvidersWithNoVouchers(LinkedList<Provider> list) {
        LinkedList<Provider> providerList = new LinkedList<>();
        for (Provider p : list) {
            if (p.isHasVouchers() || p.isHasTopup() || p.isHasBundles()) {
                providerList.add(p);
            }
        }
        return providerList;
    }

    public List<Chat4ChangeResponseSupplierMessage> getC4cSuppliers() {

        ArrayList<Chat4ChangeResponseSupplierMessage> suppliers = new ArrayList<>();

        if (((BaseActivity) context).getCachedMVNOData() != null) {

            for (Chat4ChangeResponseSupplierMessage chat4ChangeResponseSupplierMessage : ((BaseActivity) context).getCachedMVNOData().getData().getSuppliers()) {
                if (!chat4ChangeResponseSupplierMessage.getName().toLowerCase().contains("mtn") &&
                        !chat4ChangeResponseSupplierMessage.getName().toLowerCase().contains("vodacom") &&
                        !chat4ChangeResponseSupplierMessage.getName().toLowerCase().contains("telkom") &&
                        !chat4ChangeResponseSupplierMessage.getName().toLowerCase().contains("cellc") &&
                        !chat4ChangeResponseSupplierMessage.getName().toLowerCase().contains("neotel") &&
                        !chat4ChangeResponseSupplierMessage.getName().toLowerCase().contains("virgin")) {

                    suppliers.add(chat4ChangeResponseSupplierMessage);
                }
            }
        }

        return suppliers;
    }

    public Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> getVouchers(String type) {
        LinkedList<Provider> otherVoucherProviders = getOtherVouchersMenuList();

        Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> map = new TreeMap<>();
        voucherListResponseMessage = BaseActivity.voucherListResponseMessage;

        if (voucherListResponseMessage != null) {
            ArrayList<VoucherListResponseManufacturerMessage> manufacturerMessages = voucherListResponseMessage.getData().getManufacturers();
            for (VoucherListResponseManufacturerMessage msg : manufacturerMessages) {
                String manufacturerName = msg.getName();
                if (providers.size() > 0 && (type.equalsIgnoreCase("airtime") || type.equalsIgnoreCase("data"))) {
                    for (Provider p : providers) {
                        if (manufacturerName.equalsIgnoreCase(p.getProviderName())) {
                            ArrayList<VoucherListResponseProductMessage> products = msg.getProducts();
                            if (type.equalsIgnoreCase("airtime")) {
                                ArrayList<VoucherListResponseProductMessage> filteredProducts = extractByCatergoryId(products, 1);

                                //Chat for chat functionality must be removed if the device does not have the transaction type
                                if (canDoChatForChange) {

                                    if (((BaseActivity) context).getCachedMVNOData() != null)
                                        for (Chat4ChangeResponseSupplierMessage chat4ChangeResponseSupplierMessage : ((BaseActivity) context).getCachedMVNOData().getData().getSuppliers()) {
                                            if (manufacturerName.replace(" ", "").toLowerCase().contains(chat4ChangeResponseSupplierMessage.getName().replace(" ", "").toLowerCase())) {
                                                filteredProducts.add(addAnyAmountVoucher());
                                            }
                                            //cater for virgin mobile's supplier code
                                            if (chat4ChangeResponseSupplierMessage.getName().toLowerCase().replace(" ", "").contains("virginmobile")) {
                                                ((BaseActivity) context).virginMobileSupplierCode = chat4ChangeResponseSupplierMessage.getCode();
                                            }
                                        }
                                }
                                map.put(msg, filteredProducts);
                            } else if (type.equalsIgnoreCase("data")) {
                                map.put(msg, extractByCatergoryId(products, 2));
                            }
                        }
                    }
                } else if (otherVoucherProviders.size() > 0 && type.equalsIgnoreCase("VoucherOther")) {
                    for (Provider p : otherVoucherProviders) {

                        //todo: Remove hardcoded product once backend is ready
//                        if (p.getProviderName().equals("Deezer") ||
//                                p.getProviderName().equals("Google Play") ||
//                                p.getProviderName().equals("Netflix") ||
//                                p.getProviderName().equals("Planet Games") ||
//                                p.getProviderName().equals("Playstation") ||
//                                p.getProviderName().equals("Showmax") ||
//                                p.getProviderName().equals("Spotify") ||
//                                p.getProviderName().equals("Steam") ||
//                                p.getProviderName().equals("Uber") ||
//                                p.getProviderName().equals("Uber Eats")) {
//                            ArrayList<VoucherListResponseProductMessage> products = new ArrayList<>();
//                            VoucherListResponseProductMessage product = new VoucherListResponseProductMessage();
//                            product.setName("R10");
//                            product.setValue("10.00");
//                            product.setCategoryId("123");
//                            product.setCategoryDesc("Other");
//                            product.setCategoryId("146");
//                            products.add(product);
//                            VoucherListResponseManufacturerMessage message = new VoucherListResponseManufacturerMessage();
//                            message.setAirtimePlus("0");
//                            message.setName(p.getProviderName());
//                            message.setProducts(products);
//                            map.put(message, products);
//                        }

                        if (manufacturerName.equals(p.getProviderName())) {
                            ArrayList<VoucherListResponseProductMessage> products = msg.getProducts();

                            if (products.size() > 0) {
                                map.put(msg, products);
                            }
                        } else if (containsCaseInsensitive(p.getProviderName(), BaseActivity.walletTopupProviders) ||
                                (p.getProviderName().equalsIgnoreCase("bluvoucher"))) {

                            VoucherListResponseManufacturerMessage voucherListResponseManufacturerMessage = new VoucherListResponseManufacturerMessage();
                            voucherListResponseManufacturerMessage.setName(p.getProviderName());

                            ArrayList<VoucherListResponseProductMessage> voucherListResponseProductMessages = new ArrayList<>();

                            String[] amounts = {"10", "20", "30", "50", "100", "200", "Any Amount"};
                            for (String amount : amounts) {
                                VoucherListResponseProductMessage voucherListResponseProductMessage = new VoucherListResponseProductMessage();
                                voucherListResponseProductMessage.setName(p.getProviderName());
                                voucherListResponseProductMessage.setValue(amount);
                                voucherListResponseProductMessage.setText(amount);
                                voucherListResponseProductMessages.add(voucherListResponseProductMessage);
                            }
                            voucherListResponseManufacturerMessage.setProducts(voucherListResponseProductMessages);
                            map.put(voucherListResponseManufacturerMessage, voucherListResponseManufacturerMessage.getProducts());
                        }
                    }
//                } else if (manufacturerName.equals("UniPin")) {
//                    ArrayList<VoucherListResponseProductMessage> products = msg.getProducts();
//                    if (type.equals("Electricity") && (products.size() > 0)) {
//                        map.put(msg, products);
//                    }
                } else if (type.equals("Electricity")) {
                    ArrayList<VoucherListResponseProductMessage> products = msg.getProducts();
                    if (manufacturerName.equals("UniPin") && products.size() > 0) {
                        map.put(msg, products);
                    }
                } else {
                    for (Provider p : otherVoucherProviders) {
                        if (manufacturerName.equals(p.getProviderName())) {
                            ArrayList<VoucherListResponseProductMessage> products = msg.getProducts();
                            if (products.size() > 0) {
                                map.put(msg, products);
                            }
                        }
                    }
                }
            }
        }

        if (context != null) {
            if (((BaseActivity) context).getCachedMVNOData() != null && ((BaseActivity) context).getCachedMVNOData().getData().getSuppliers().size() > 0) {
                VoucherListResponseManufacturerMessage voucherListResponseManufacturerMessage = new VoucherListResponseManufacturerMessage();
                //This section is used to display the the NVNO Button under the Vouchers section
                Log.v("vouvher list1", voucherListResponseManufacturerMessage.getName());
                voucherListResponseManufacturerMessage.setName("MVNO");
                //voucherListResponseManufacturerMessage.setName("BLU");
                Log.v("vouvher list2", voucherListResponseManufacturerMessage.getName());
                //voucherListResponseManufacturerMessage.setName("blu");

                ArrayList<VoucherListResponseProductMessage> voucherListResponseProductMessages = new ArrayList<>();

                //Section used to cycle through GetCachedMVNOData to populate view
                for (Chat4ChangeResponseSupplierMessage msg : ((BaseActivity) context).getCachedMVNOData().getData().getSuppliers()) {

                    VoucherListResponseProductMessage voucherListResponseProductMessage = new VoucherListResponseProductMessage();
                    voucherListResponseProductMessage.setName(msg.getName());
                    voucherListResponseProductMessages.add(voucherListResponseProductMessage);

                }

                voucherListResponseManufacturerMessage.setProducts(voucherListResponseProductMessages);
                map.put(voucherListResponseManufacturerMessage, voucherListResponseManufacturerMessage.getProducts());

            }
        }

//        VoucherListResponseManufacturerMessage voucherListResponseManufacturerMessage = new VoucherListResponseManufacturerMessage();
//        voucherListResponseManufacturerMessage.setName("BluVoucher");
//
//        ArrayList<VoucherListResponseProductMessage> voucherListResponseProductMessages = new ArrayList<>();
//
//        String[] amounts = {"10", "20", "30", "50", "100", "200", "Any Amount"};
//        for (String amount : amounts) {
//            VoucherListResponseProductMessage voucherListResponseProductMessage = new VoucherListResponseProductMessage();
//            voucherListResponseProductMessage.setName("BluVoucher");
//            voucherListResponseProductMessage.setValue(amount);
//            voucherListResponseProductMessage.setText(amount);
//            voucherListResponseProductMessages.add(voucherListResponseProductMessage);
//        }
//        voucherListResponseManufacturerMessage.setProducts(voucherListResponseProductMessages);
//        map.put(voucherListResponseManufacturerMessage, voucherListResponseManufacturerMessage.getProducts());

        Log.v("vouvher list2", map.toString());
        return map;
    }

    public Map<String, ArrayList<VoucherListResponseProductMessage>> getAllVouchers() {
        LinkedList<Provider> otherVoucherProviders = getOtherVouchersMenuList();
        providers = getNetworkList();

        Map<String, ArrayList<VoucherListResponseProductMessage>> map = new TreeMap<>();
        voucherListResponseMessage = BaseActivity.voucherListResponseMessage;

        if (voucherListResponseMessage != null) {
            ArrayList<VoucherListResponseManufacturerMessage> manufacturerMessages = voucherListResponseMessage.getData().getManufacturers();
            for (VoucherListResponseManufacturerMessage msg : manufacturerMessages) {
                String manufacturerName = msg.getName();

                for (Provider p : providers) {
                    if (manufacturerName.equalsIgnoreCase(p.getProviderName())) {
                        ArrayList<VoucherListResponseProductMessage> products = msg.getProducts();

                        map.put(manufacturerName, products);
                    }
                }

                for (Provider p : otherVoucherProviders) {
                    if (manufacturerName.equals(p.getProviderName())) {
                        ArrayList<VoucherListResponseProductMessage> products = msg.getProducts();
                        if (products.size() > 0) {
                            map.put(manufacturerName, products);
                        }
                    }
                }
                ArrayList<VoucherListResponseProductMessage> products = msg.getProducts();
                if (manufacturerName.equals("UniPin")) {
                    map.put(manufacturerName, products);
                }
            }
        }

        return map;
    }

    private ArrayList<VoucherListResponseProductMessage> extractByCatergoryId(ArrayList<VoucherListResponseProductMessage> list, int id) {
        ArrayList<VoucherListResponseProductMessage> output = new ArrayList<>();
        for (VoucherListResponseProductMessage resp : list) {
            if (Integer.parseInt(resp.getCategoryId()) == id) {
                output.add(resp);
            }
        }
        return output;
    }

    private VoucherListResponseProductMessage addAnyAmountVoucher() {
        VoucherListResponseProductMessage anyAirtimeProduct = new VoucherListResponseProductMessage();
        anyAirtimeProduct.setCategoryId("1");
        anyAirtimeProduct.setCategoryDesc("Airtime");
        anyAirtimeProduct.setName("");
        anyAirtimeProduct.setValue(context.getResources().getString(R.string.anyAmount));
        anyAirtimeProduct.setText("C4C");

        return anyAirtimeProduct;
    }

    Map<Provider, ArrayList<BundlesResponseProductMessage>> getBundles() {
        Map<Provider, ArrayList<BundlesResponseProductMessage>> map = new TreeMap<>();
        try {
            Map<String, BundlesResponseGetProductListMessage> bundlesResponseGetProductListMessage = BaseActivity.bundlesResponseGetProductListMessages;
            if (bundlesResponseGetProductListMessage != null) {
                for (String network : bundlesResponseGetProductListMessage.keySet()) {
                    for (Provider p : providers) {
                        if (p.isHasBundles()) {
                            //Split is for Cell C - We only want Cell
                            String[] parts = p.getProviderName().split(" ");
                            String providerName = parts[0];
                            if (network.startsWith(providerName) && !providerName.equals("All")) {
                                ArrayList<BundlesResponseProductMessage> products = new ArrayList<>();
                                for (BundlesResponseCategoryMessage list : bundlesResponseGetProductListMessage.get(network).getData().getCategories()) {
                                    products.addAll(list.getProducts());
                                }
                                map.put(p, products);
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            Log.d(TAG, ex.toString());
        }
        return map;
    }


    boolean containsCaseInsensitive(String s, List<String> l) {
        for (String string : l) {
            if (string.equalsIgnoreCase(s)) {
                return true;
            }
        }
        return false;
    }

    public LinkedList<Provider> getProviders() {
        return providers;
    }

    public void setProviders(LinkedList<Provider> providers) {
        this.providers = providers;
    }
}
