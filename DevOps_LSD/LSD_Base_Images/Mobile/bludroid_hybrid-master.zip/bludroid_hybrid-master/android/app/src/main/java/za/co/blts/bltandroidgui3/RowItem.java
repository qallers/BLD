package za.co.blts.bltandroidgui3;

/**
 * Created by warrenm on 2016/10/03.
 */

class RowItem {

    private int imageId;
    private String title;

    //main menu
    public RowItem(String title, int imageId) {
        this.imageId = imageId;
        this.title = title;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}
