package za.co.blts.bltandroidgui3;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

import za.co.blt.interfaces.external.messages.login.response.LoginResponseGroupMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseTransactionTypeMessage;

/**
 * Created by warrenm on 2017/02/07.
 */

class ElectricityUtility extends VoucherUtility {

    public ElectricityUtility() {

    }

    public Map<String, String> getElectricity() {

        ArrayList<LoginResponseGroupMessage> groups = BaseActivity.loginResponseMessage.getData().getTransactionTypes();
        Map<String, String> munics = new TreeMap<>();

        for (int i = 0; i < groups.size(); i++) {
            LoginResponseGroupMessage group = groups.get(i);

            if (group.getName().equals("XML Interface")) {
                for (int j = 0; j < group.getTransactionTypes().size(); j++) {
                    LoginResponseTransactionTypeMessage transactionType =
                            group.getTransactionTypes().get(j);
                    if (transactionType.getType().equals("Electricity")) {
                        munics.put(transactionType.getText(), transactionType.getDisplayName());
                    }
                }
            }
        }
        return munics;
    }
}
