package za.co.blts.bltandroidgui3;

import java.io.Serializable;

/**
 * Created by MasiS on 19/02/2018.
 */

public class BluDroidRoutesAndTimes implements Serializable, Comparable<BluDroidRoutesAndTimes> {
    private String travelClass;
    private String routeCode;
    private String adultPrice;
    private String childPrice;
    private String infantPrice;
    private String arriveTime;
    private String departTime;
    private String carrier;
    private String carrierName;
    private String boardLocation;
    private String available;
    private String destLocation;
    private String boardTime;
    private boolean isSelected = false;
    private int iconSelected;
    private int positionInList;
    private String mediaUrl;

    public BluDroidRoutesAndTimes() {
    }

    public BluDroidRoutesAndTimes(String travelClass, String routeCode, String adultPrice, String childPrice, String infantPrice, String arriveTime, String boardTime, String carrier, String carrierName, String boardLocation, String available, String destLocation, String departTime, int positionInList, String mediaUrl) {
        this.travelClass = travelClass;
        this.routeCode = routeCode;
        this.adultPrice = new BluDroidUtils().formatMoney(adultPrice);
        this.childPrice = new BluDroidUtils().formatMoney(childPrice);
        this.infantPrice = new BluDroidUtils().formatMoney(infantPrice);
        this.arriveTime = arriveTime;
        this.boardTime = boardTime;
        this.carrier = carrier;
        this.carrierName = carrierName;
        this.boardLocation = boardLocation;
        this.available = available;
        this.destLocation = destLocation;
        this.departTime = departTime;
        this.positionInList = positionInList;
        this.mediaUrl = mediaUrl;
    }

    public String getTravelClass() {
        return travelClass;
    }

    public void setTravelClass(String travelClass) {
        this.travelClass = travelClass;
    }

    public String getRouteCode() {
        return routeCode;
    }

    public void setRouteCode(String routeCode) {
        this.routeCode = routeCode;
    }


    public String getArriveTime() {
        return arriveTime;
    }

    public void setArriveTime(String arriveTime) {
        this.arriveTime = arriveTime;
    }

    public String getDepartTime() {
        return departTime;
    }

    public void setDepartTime(String departTime) {
        this.departTime = departTime;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getBoardLocation() {
        return boardLocation;
    }

    public void setBoardLocation(String boardLocation) {
        this.boardLocation = boardLocation;
    }

    public String getAvailable() {
        return available;
    }

    public void setAvailable(String available) {
        this.available = available;
    }

    public String getDestLocation() {
        return destLocation;
    }

    public void setDestLocation(String destLocation) {
        this.destLocation = destLocation;
    }

    public String getBoardTime() {
        return boardTime;
    }

    public void setBoardTime(String boardTime) {
        this.boardTime = boardTime;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public void setIconSelected(int iconSelected) {
        this.iconSelected = iconSelected;
    }

    public int getIconSelected() {
        return iconSelected;
    }

    public int getPositionInList() {
        return positionInList;
    }

    public void setPositionInList(int positionInList) {
        this.positionInList = positionInList;
    }

    public String getAdultPrice() {
        return adultPrice;
    }

    public void setAdultPrice(String adultPrice) {
        this.adultPrice = adultPrice;
    }

    public String getChildPrice() {
        return childPrice;
    }

    public void setChildPrice(String childPrice) {
        this.childPrice = childPrice;
    }

    public String getInfantPrice() {
        return infantPrice;
    }

    public void setInfantPrice(String infantPrice) {
        this.infantPrice = infantPrice;
    }

    public String getMediaUrl() {
        return mediaUrl;
    }

    public void setMediaUrl(String mediaUrl) {
        this.mediaUrl = mediaUrl;
    }

    @Override
    public String toString() {
        return "BluDroidRoutesAndTimes{" +
                "travelClass='" + travelClass + '\'' +
                ", routeCode='" + routeCode + '\'' +
                ", adultPrice='" + adultPrice + '\'' +
                ", childPrice='" + childPrice + '\'' +
                ", infantPrice='" + infantPrice + '\'' +
                ", arriveTime='" + arriveTime + '\'' +
                ", departTime='" + departTime + '\'' +
                ", carrier='" + carrier + '\'' +
                ", boardLocation='" + boardLocation + '\'' +
                ", available='" + available + '\'' +
                ", destLocation='" + destLocation + '\'' +
                ", boardTime='" + boardTime + '\'' +
                ", isSelected=" + isSelected +
                ", iconSelected=" + iconSelected +
                ", positionInList=" + positionInList +
                ", mediaUrl=" + mediaUrl +
                '}';
    }

    @Override
    public int compareTo(BluDroidRoutesAndTimes o) {

        return getDepartTime().compareTo(o.getDepartTime());
        /*if (getAdultPrice() == null || o.getAdultPrice() == null) {
            return 0;
        }
        return getAdultPrice().compareTo(o.getAdultPrice());*/

        //  int compare = getCarrierName().compareTo(o.getCarrierName()); //sort by carrier first
        // if (compare == 0){
        //  int  compare = getDepartTime().compareTo(o.getDepartTime());
        //if same carrier, sort by depart time
        // }
        //   return compare;
    }
}
