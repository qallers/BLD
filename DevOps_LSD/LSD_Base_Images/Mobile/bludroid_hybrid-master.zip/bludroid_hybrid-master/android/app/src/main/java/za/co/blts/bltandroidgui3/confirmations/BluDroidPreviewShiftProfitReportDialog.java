package za.co.blts.bltandroidgui3.confirmations;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blts.bltandroidgui3.BaseActivity;

/**
 * Created by MasiS on 3/23/2018.
 */

public class BluDroidPreviewShiftProfitReportDialog extends BluDroidPrintPreviewDialog {
    private final String TAG = this.getClass().getSimpleName();
    //----------------------------------------------------------------------------------------------
    public BluDroidPreviewShiftProfitReportDialog(final BaseActivity context, ArrayList<CommonResponseLineMessage> lines) {
        super(context, lines);
        setup();
        setHeading("Shift Report");
    }

    //----------------------------------------------------------------------------------------------
}


