package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.rica.request.RicaRequestMultipleSIMSMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestRegistrationMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;


public class FragmentRicaBoxRegister extends BaseFragment implements View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();

    public ViewPager _mViewPager;
    private ImageView _btn1, _btn2, _btn3;
    private BluDroidButton buttonNext, buttonBack;

    RicaBoxRegisterInfopagerAdapter _adapter;

    public FragmentRicaBoxRegister() {
        // Required empty public constructor
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setUpView();
        setTab();
        onCircleButtonClick();

        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), TAG, null);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_rica_box_register, container, false);
    }

    private void onCircleButtonClick() {
        _btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _btn1.setImageResource(R.drawable.selected_item);
                _mViewPager.setCurrentItem(0);
            }
        });
        _btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _btn2.setImageResource(R.drawable.selected_item);
                _mViewPager.setCurrentItem(1);
            }
        });
        _btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _btn3.setImageResource(R.drawable.selected_item);
                _mViewPager.setCurrentItem(2);
            }
        });
    }

    private void setUpView() {
        _mViewPager = getView().findViewById(R.id.imageviewPager);
        _adapter = new RicaBoxRegisterInfopagerAdapter(getChildFragmentManager());
        _mViewPager.setAdapter(_adapter);
        _mViewPager.setCurrentItem(0);
        initButton();
    }

    private void setTab() {

        _mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int position) {
            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
            }

            @Override
            public void onPageSelected(int position) {
                _btn1.setImageResource(R.drawable.nonselected_item);
                _btn2.setImageResource(R.drawable.nonselected_item);
                _btn3.setImageResource(R.drawable.nonselected_item);
                btnAction(position);
            }
        });
    }

    private void btnAction(int action) {
        switch (action) {
            case 0:
                _btn1.setImageResource(R.drawable.selected_item);
                buttonBack.setEnabled(false);
                buttonBack.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                break;

            case 1:
                _btn2.setImageResource(R.drawable.selected_item);
                buttonBack.setEnabled(true);
                buttonNext.setEnabled(true);
                buttonNext.setText(getString(R.string.next));
                buttonNext.setBackgroundColor(getSkinResources().getButtonColor());
                buttonBack.setBackgroundColor(getSkinResources().getButtonColor());
                break;

            case 2:
                _btn3.setImageResource(R.drawable.selected_item);
                buttonNext.setText(getString(R.string.submit));
                break;
        }
    }

    private void initButton() {
        buttonNext = getView().findViewById(R.id.next);
        buttonBack = getView().findViewById(R.id.back);

        buttonBack.setOnClickListener(this);
        buttonNext.setOnClickListener(this);

        buttonBack.setEnabled(false);
        buttonBack.setBackgroundColor(getResources().getColor(R.color.lightGrey));

        _btn1 = getView().findViewById(R.id.btn1);
        _btn1.setImageResource(R.drawable.selected_item);

        _btn2 = getView().findViewById(R.id.btn2);
        _btn3 = getView().findViewById(R.id.btn3);

        _btn2.setImageResource(R.drawable.nonselected_item);
        _btn3.setImageResource(R.drawable.nonselected_item);
    }

    @Override
    public void onClick(View view) {
        BaseActivity.logger.info(((BluDroidButton) view).getText());
        switch (view.getId()) {
            case R.id.next:
                Fragment f = _adapter.getItemIndex(_mViewPager.getCurrentItem());
                //Consumer info
                if (_mViewPager.getCurrentItem() == 0) {

                    if (((FragmentBoxRicaConsumerInfo) f).userInfoLayout.validate()) {

                        getBaseActivity().ricaRegistrationMessage = new RicaRequestRegistrationMessage();

                        String countryCode = ((FragmentBoxRicaConsumerInfo) f).nationality.substring(0, 2);

                        getBaseActivity().ricaRegistrationMessage.setExisting("false");
                        getBaseActivity().ricaRegistrationMessage.setFirstName(((FragmentBoxRicaConsumerInfo) f).consumerName.getText().toString());
                        getBaseActivity().ricaRegistrationMessage.setLastName(((FragmentBoxRicaConsumerInfo) f).consumerLastName.getText().toString());

                        getBaseActivity().ricaRegistrationMessage.getIdInfo().setCountryCode(countryCode);

                        if (((FragmentBoxRicaConsumerInfo) f).idType.equals("idNumber")) {
                            getBaseActivity().ricaRegistrationMessage.getIdInfo().setIDType("N");
                            getBaseActivity().ricaRegistrationMessage.getIdInfo().setIDNumber(((FragmentBoxRicaConsumerInfo) f).consumerId.getText().toString());

                        } else {
                            getBaseActivity().ricaRegistrationMessage.getIdInfo().setIDType("P");
                            getBaseActivity().ricaRegistrationMessage.getIdInfo().setIDNumber(((FragmentBoxRicaConsumerInfo) f).passportNumber.getText().toString());
                        }

                        _mViewPager.setCurrentItem(1);
                    }

                }
                ///Address info
                else if (_mViewPager.getCurrentItem() == 1) {

                    if (((FragmentRicaAddressInfo) f).layout.validate()) {

                        String countryCode = ((FragmentRicaAddressInfo) f).selectedCounty.substring(0, 2);

                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setAddressLine1(((FragmentRicaAddressInfo) f).addressLine1.getText().toString());
                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setAddressLine2(((FragmentRicaAddressInfo) f).addressLine2.getText().toString());
                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setPostalCode(((FragmentRicaAddressInfo) f).postalCode.getText().toString());

                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setCountryCode(countryCode);
                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setSuburb(((FragmentRicaAddressInfo) f).suburb.getText().toString());
                        getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setCityTown(((FragmentRicaAddressInfo) f).city.getText().toString());

                        if (countryCode.equals("ZA")) {
                            getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setRegion(((FragmentRicaAddressInfo) f).selectedProvince);
                        } else {
                            getBaseActivity().ricaRegistrationMessage.getAddressIndividual().setRegion("");
                        }

                        _mViewPager.setCurrentItem(2);
                    }
                }
                ///Sim info
                else if (_mViewPager.getCurrentItem() == 2) {

                    if (((FragmentRicaBoxSimRegistration) f).layout.validate()) {

                        //remove the previously set reference numbers

                        getBaseActivity().ricaRegistrationMessage.setReferenceNumber("");
                        getBaseActivity().ricaRegistrationMessage.setReferenceNumbers(new ArrayList<RicaRequestMultipleSIMSMessage>());

                        String network = ((FragmentRicaBoxSimRegistration) f).selectedProvider;

                        switch (network) {
                            case "Vodacom":
                                getBaseActivity().ricaRegistrationMessage.setMsisdnNetwork("Vodacom");
                                getBaseActivity().ricaRegistrationMessage.setReferenceType("SIM");
                                Log.d(TAG, "vodacom showing");
                                break;
                            case "Cell C":
                                getBaseActivity().ricaRegistrationMessage.setMsisdnNetwork("CellC");
                                getBaseActivity().ricaRegistrationMessage.setReferenceType("SIM");
                                Log.d(TAG, "cellc showing");
                                break;
                            case "MTN":
                                getBaseActivity().ricaRegistrationMessage.setMsisdnNetwork("MTN");
                                getBaseActivity().ricaRegistrationMessage.setReferenceType("STARTER_PACK_REF");
                                Log.d(TAG, "mtn showing");
                                break;
                            case "Telkom Mobile":
                                getBaseActivity().ricaRegistrationMessage.setMsisdnNetwork("TelkomMobile");
                                getBaseActivity().ricaRegistrationMessage.setReferenceType("SIM");
                                Log.d(TAG, "telkommobile showing");
                                break;
                            case "Virgin Mobile":
                                getBaseActivity().ricaRegistrationMessage.setMsisdnNetwork("VirginMobile");
                                getBaseActivity().ricaRegistrationMessage.setReferenceType("SIM");
                                Log.d(TAG, "virgin showing");
                                break;
                            default:
                                Log.d(TAG, "problem with network spinner");
                                break;
                        }

                        if (((FragmentRicaBoxSimRegistration) f).ricaSerialNumberList.size() != 0) {

                            if (((FragmentRicaBoxSimRegistration) f).ricaSerialNumberList.size() == 1) {

                                String sim = ((FragmentRicaBoxSimRegistration) f).ricaSerialNumberList.get(0);
                                String[] simParts = sim.split(",");
                                String serial = simParts[1];

                                getBaseActivity().ricaMultiRegistration = false;
                                getBaseActivity().authenticateBoxRica(serial);
                            }

                        } else {
                            getBaseActivity().createAlertDialog("RICA", "Please add a sim serial");
                        }
                    }
                }
                break;

            case R.id.back:
                if (_mViewPager.getCurrentItem() == 1) {
                    _mViewPager.setCurrentItem(0);
                } else if (_mViewPager.getCurrentItem() == 2) {
                    _mViewPager.setCurrentItem(1);
                }
                break;

            default:
                break;
        }

    }


}

