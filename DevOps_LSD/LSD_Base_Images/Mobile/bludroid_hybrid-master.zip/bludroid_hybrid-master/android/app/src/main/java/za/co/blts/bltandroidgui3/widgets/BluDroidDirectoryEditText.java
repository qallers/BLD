package za.co.blts.bltandroidgui3.widgets;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidDirectoryEditText extends BluDroidEditText {
    private final String TAG = this.getClass().getSimpleName();

    private String editTextCategory;

    public BluDroidDirectoryEditText(BaseActivity context) {
        super(context);
    }

    public BluDroidDirectoryEditText(Context context, AttributeSet attrs) {
        super(context, attrs);

        @SuppressLint("CustomViewStyleable") TypedArray attributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidEditText);

        try {
            editTextCategory = attributesArray.getString(R.styleable.BluDroidEditText_EditTextCategory);
        } catch (Exception e) {
            e.printStackTrace();
        }
        attributesArray.recycle();
    }

    public boolean validate() {
        Log.d(TAG, "validate");
        BaseActivity.logger.info(": validate()");
        String validDirectoryRegex = "^/[a-zA-Z][a-zA-Z0-9./_-]*$";

        String directory = getText().toString().trim();
        Log.d(TAG, "directory is " + directory);
        boolean matchesDirectory = directory.matches(validDirectoryRegex);
        Log.d(TAG, "matchesDirectory " + matchesDirectory);
        if (matchesDirectory) {
            removeErrorMessage();
            return true;
        } else {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            setErrorMessage(R.string.directoryError);
            if (baseScreen != null) {

                if (editTextCategory.equalsIgnoreCase("repositorySettings")) {
                    baseScreen.repositorySettingsHaserrors = true;
                } else if (editTextCategory.equalsIgnoreCase("ePubSettings")) {
                    baseScreen.ePubSettingsHaserrors = true;
                }
            }
            //setText("");
            return false;
        }
    }

}

