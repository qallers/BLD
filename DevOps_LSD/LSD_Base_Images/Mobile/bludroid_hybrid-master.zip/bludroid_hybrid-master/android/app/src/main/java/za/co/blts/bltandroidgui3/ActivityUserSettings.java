package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseAccountMessage;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDialogable;
import za.co.blts.bltandroidgui3.widgets.BluDroidErrorTextView;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidMoneyEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidSwitch;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.MAX_ACCOUNT_DISPLAY;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_ACCOUNT_DETAILS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BALANCE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BALANCEAMT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BALANCE_DISPLAY_ENABLED;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BP_LIMIT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASHIER_END_SHIFT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASH_DRAWER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_ENABLE_TECH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_ENABLE_USER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_APP_VERSION;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_BARCODE_RECEIPT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER_TICKETS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_PREVIEWS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_PREVIEW_RECEIPTS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_SALES_RECEIPT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PROFIT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PROFIT_DISPLAY_ENABLED;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SCREEN_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_STORE_ADDRESS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_STORE_NAME;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_BASKET;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VAT_REG_NO;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VOUCHER_SECONDS;

//this class was renamed to device settings on options menu
public class ActivityUserSettings extends BaseActivity implements BluDroidDialogable {

    private final String TAG = this.getClass().getSimpleName();

    private BluDroidRelativeLayout layout;

    private int confirmationType = 0;
    private BluDroidAlertDialog alert = null;

    //receipt Settings
    private boolean isReceiptsToggled = false;
    private ImageView receiptsToggleImg = null;

    //device Settings
    private boolean isDeviceToggled = false;
    private ImageView deviceToggleImg = null;

    //store Settings
    private boolean isStoreToggled = false;
    private ImageView storeToggleImg = null;

    //store Settings
    private boolean isAccountBalanceToggled = false;
    private ImageView accountBalanceToggleImg = null;

    //loyalty Settings
    private boolean isLoyaltyToggled = false;
    private ImageView loyaltyToggleImg = null;

    private ArrayList<String> accountNumbers;
    private boolean balanceDisplayEnabled, profitDisplayEnabled;

    private RadioGroup rgTimeoutSetting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_settings);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        layout = findViewById(R.id.layout);

        toolbar = findViewById(R.id.toolbar);

//        profitDisplayEnabled = mFirebaseRemoteConfig.getString("enable_profit_display").equals("true");
        balanceDisplayEnabled = getPreference(PREF_BALANCE_DISPLAY_ENABLED).equals("true");
        profitDisplayEnabled = getPreference(PREF_PROFIT_DISPLAY_ENABLED).equals("true");

        Log.d("ProfDisp", "balance:" + balanceDisplayEnabled + " profit:" + profitDisplayEnabled);

        if(isDebug() || isQa()){
            ((BluDroidLinearLayout)findViewById(R.id.lnrPreviewReceipt)).setVisibility(VISIBLE);
        }else
            ((BluDroidLinearLayout)findViewById(R.id.lnrPreviewReceipt)).setVisibility(GONE);

        rgTimeoutSetting = findViewById(R.id.rgTimeout);
        initialiseRGTimeout();
        rgTimeoutSetting.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int timeoutValue;
                switch (checkedId) {
                    case R.id.rbTimeout3:
                        timeoutValue = 60 * 3;
                        updatePreference(PREF_SCREEN_TIMEOUT, "" + timeoutValue);
                        break;

                    case R.id.rbTimeout5:
                        timeoutValue = 60 * 5;
                        updatePreference(PREF_SCREEN_TIMEOUT, "" + timeoutValue);
                        break;

                    case R.id.rbTimeout10:
                        timeoutValue = 60 * 10;
                        updatePreference(PREF_SCREEN_TIMEOUT, "" + timeoutValue);
                        break;

                    case R.id.rbTimeout30:
                        timeoutValue = 60 * 30;
                        updatePreference(PREF_SCREEN_TIMEOUT, "" + timeoutValue);
                        break;

                    case R.id.rbTimeoutHour:
                        timeoutValue = 60 * 60;
                        updatePreference(PREF_SCREEN_TIMEOUT, "" + timeoutValue);
                        break;
                }
            }
        });

        String title = "Device Settings";
        toolbar.setTitle(title);
        toolbar.setNavigationBackIcon();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmationType = 1;
                resetTimer();

                if (hasChanges(R.id.storeNameSetting, PREF_STORE_NAME)
                        || hasChanges(R.id.addressSetting, PREF_STORE_ADDRESS)
                        || hasChanges(R.id.vatRegNoSetting, PREF_VAT_REG_NO)
                        || hasChanges(R.id.merchantVouchersSwitch, PREF_PRINT_MERCHANT_VOUCHER)
                        || hasChanges(R.id.merchantTicketsSwitch, PREF_PRINT_MERCHANT_VOUCHER_TICKETS)
                        || hasChanges(R.id.cashierEndShiftSwitch, PREF_CASHIER_END_SHIFT)
                        || hasChanges(R.id.useBasketSwitch, PREF_USE_BASKET)
                        || hasChanges(R.id.salesReceiptSwitch, PREF_PRINT_SALES_RECEIPT)
                        || hasChanges(R.id.reportPreviewSwitch, PREF_PRINT_PREVIEWS)
                        || hasChanges(R.id.cashDrawSwitch, PREF_CASH_DRAWER)
                        || hasChanges(R.id.bpLimitSetting, PREF_BP_LIMIT)

                        || hasChanges(R.id.loyaltySwitch, PREF_LOYALTY_ENABLE_USER)

                        || hasBalanceChanges()
                        || hasProfitChanges()
                ) {
                    alert = createLeaveNoSaveConfirmation();

                    setAlertNeutralButton();
                    setAlertNegativeButton();
                    setAlertPositiveButton();
                    alert.show();
                } else {
                    gotoMainScreen();
                }
            }
        });

        initFields();
        hideLoyaltyIfTechDisabled();
        hideLoyaltyIfGcrs();
        hideReceiptsSettings();
        hideDeviceSettings();
        hideStoreSettings();
        hideAccountBalanceSettings();
        hideLoyaltySettings();
        hideToggleErrors();

        Button userSave = findViewById(R.id.save);
        userSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "SAAAAAAVVVVVVEEEE");

                hideToggleErrors();

                if (layout.validate()) {
                    Log.d(TAG, "=============>2");
                    saveSettings();
                } else {
                    showToggleErrors();
                }
            }
        });


        //Toggling arrows
        receiptsToggleImg = findViewById(R.id.receiptsToggle);
        deviceToggleImg = findViewById(R.id.deviceToggle);
        storeToggleImg = findViewById(R.id.storeToggle);
        loyaltyToggleImg = findViewById(R.id.loyaltyToggle);

        accountBalanceToggleImg = findViewById(R.id.accountBalanceToggle);

        LinearLayout receiptsToggle = findViewById(R.id.receiptsGroupToggle);
        receiptsToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isReceiptsToggled) {
                    hideReceiptsSettings();
                    receiptsToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showReceiptsSettings();
                    receiptsToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isReceiptsToggled = !isReceiptsToggled;
            }
        });


        LinearLayout deviceToggle = findViewById(R.id.deviceSettingsGroupToggle);
        deviceToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isDeviceToggled) {
                    hideDeviceSettings();
                    deviceToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showDeviceSettings();
                    deviceToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isDeviceToggled = !isDeviceToggled;
            }
        });

        LinearLayout storeToggle = findViewById(R.id.storeSettingsGroupToggle);
        storeToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isStoreToggled) {
                    hideStoreSettings();
                    storeToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showStoreSettings();
                    storeToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isStoreToggled = !isStoreToggled;
            }
        });


        LinearLayout accountBalanceToggle = findViewById(R.id.accountBalanceGroupToggle);

        accountBalanceToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetTimer();

                if (isAccountBalanceToggled) {
                    hideAccountBalanceSettings();
                    accountBalanceToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showAccountBalanceSettings();
                    accountBalanceToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isAccountBalanceToggled = !isAccountBalanceToggled;
            }
        });

        LinearLayout loyaltyToggle = findViewById(R.id.loyaltyGroupToggle);
        loyaltyToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isLoyaltyToggled) {
                    hideLoyaltySettings();
                    loyaltyToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showLoyaltySettings();
                    loyaltyToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isLoyaltyToggled = !isLoyaltyToggled;
            }
        });

        accountNumbers = new ArrayList<>();

        if (balanceDisplayEnabled || profitDisplayEnabled) {
            accountBalanceToggle.setVisibility(VISIBLE);
            populateAccounts();
        } else {
            accountBalanceToggle.setVisibility(GONE);
        }
    }

    private void initialiseRGTimeout() {
        String timeoutValue = getPreference(PREF_SCREEN_TIMEOUT);

        switch (timeoutValue) {
            default:
            case "180":
                rgTimeoutSetting.check(R.id.rbTimeout3);
                break;

            case "300":
                rgTimeoutSetting.check(R.id.rbTimeout5);
                break;

            case "600":
                rgTimeoutSetting.check(R.id.rbTimeout10);
                break;

            case "1800":
                rgTimeoutSetting.check(R.id.rbTimeout30);
                break;

            case "3600":
                rgTimeoutSetting.check(R.id.rbTimeoutHour);
                break;
        }
    }

    private boolean hasBalanceChanges() {
        for (String acc : accountNumbers) {
            String superBalancePref = getBalancePref("Supervisor", acc);
            String superBalance = getBalanceSelection("Supervisor", acc);
            if (!superBalancePref.equals(superBalance)) {
                return true;
            }

            String plusBalancePref = getBalancePref("CashierPlus", acc);
            String plusBalance = getBalanceSelection("CashierPlus", acc);
            if (!plusBalancePref.equals(plusBalance)) {
                return true;
            }

            String cashBalancePref = getBalancePref("Cashier", acc);
            String cashBalance = getBalanceSelection("Cashier", acc);
            if (!cashBalancePref.equals(cashBalance)) {
                return true;
            }

            String warnAmountPref = getBalanceAmountPref(acc);
            String warnAmount = getBalanceAmountEntered(acc);
            if (!warnAmountPref.equals(warnAmount)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasProfitChanges() {
        for (String acc : accountNumbers) {
            String superProfitPref = getProfitPref("Supervisor", acc);
            String superProfit = getProfitSelection("Supervisor", acc);
            if (!superProfitPref.equals(superProfit)) {
                return true;
            }

            String plusProfitPref = getProfitPref("CashierPlus", acc);
            String plusProfit = getProfitSelection("CashierPlus", acc);
            if (!plusProfitPref.equals(plusProfit)) {
                return true;
            }

            String cashProfitPref = getProfitPref("Cashier", acc);
            String cashProfit = getProfitSelection("Cashier", acc);
            if (!cashProfitPref.equals(cashProfit)) {
                return true;
            }
        }
        return false;
    }

    private void saveSettings() {
        for (String acc : accountNumbers) {
            Log.i("ProfDisp", "=======" + acc + "=======");

            String superBalancePref = getBalancePref("Supervisor", acc);
            String superBalance = getBalanceSelection("Supervisor", acc);
            Log.i("ProfDisp", "Balance - Supervisor : pref:" + superBalancePref + " selected:" + superBalance);
            updatePreference(PREF_BALANCE + "Supervisor" + acc, superBalance);

            String plusBalancePref = getBalancePref("CashierPlus", acc);
            String plusBalance = getBalanceSelection("CashierPlus", acc);
            Log.i("ProfDisp", "Balance - CashierPlus : pref:" + plusBalancePref + " selected:" + plusBalance);
            updatePreference(PREF_BALANCE + "CashierPlus" + acc, plusBalance);

            String cashBalancePref = getBalancePref("Cashier", acc);
            String cashBalance = getBalanceSelection("Cashier", acc);
            Log.i("ProfDisp", "Balance - Cashier : pref:" + cashBalancePref + " selected:" + cashBalance);
            updatePreference(PREF_BALANCE + "Cashier" + acc, cashBalance);

            String superProfitPref = getProfitPref("Supervisor", acc);
            String superProfit = getProfitSelection("Supervisor", acc);
            Log.i("ProfDisp", "Profit - Supervisor : pref:" + superProfitPref + " selected:" + superProfit);
            updatePreference(PREF_PROFIT + "Supervisor" + acc, superProfit);

            String plusProfitPref = getProfitPref("CashierPlus", acc);
            String plusProfit = getProfitSelection("CashierPlus", acc);
            Log.i("ProfDisp", "Profit - CashierPlus : pref:" + plusProfitPref + " selected:" + plusProfit);
            updatePreference(PREF_PROFIT + "CashierPlus" + acc, plusProfit);

            String cashProfitPref = getProfitPref("Cashier", acc);
            String cashProfit = getProfitSelection("Cashier", acc);
            Log.i("ProfDisp", "Profit - Cashier : pref:" + cashProfitPref + " selected:" + cashProfit);
            updatePreference(PREF_PROFIT + "Cashier" + acc, cashProfit);

            String warnAmountPref = getBalanceAmountPref(acc);
            String warnAmount = getBalanceAmountEntered(acc);
            Log.i("ProfDisp", "Low Balance : pref:" + warnAmountPref + " entered:" + warnAmount);
            updatePreference(PREF_BALANCEAMT + acc, warnAmount);
        }

        compareUpdate(PREF_PRINT_MERCHANT_VOUCHER, R.id.merchantVouchersSwitch);
        compareUpdate(PREF_PRINT_MERCHANT_VOUCHER_TICKETS, R.id.merchantTicketsSwitch);
        compareUpdate(PREF_CASHIER_END_SHIFT, R.id.cashierEndShiftSwitch);
        compareUpdate(PREF_USE_BASKET, R.id.useBasketSwitch);
        compareUpdate(PREF_PRINT_SALES_RECEIPT, R.id.salesReceiptSwitch);
        compareUpdate(PREF_PRINT_PREVIEWS, R.id.reportPreviewSwitch);
        compareUpdate(PREF_CASH_DRAWER, R.id.cashDrawSwitch);
        compareUpdate(PREF_PRINT_PREVIEW_RECEIPTS, R.id.receiptPreviewSwitch);
        //Set status for new print barcode status
        compareUpdate(PREF_PRINT_BARCODE_RECEIPT, R.id.printBarcodeSwitch);

        compareUpdate(PREF_PRINT_APP_VERSION, R.id.printVersionNoSwitch);
        Log.e("PrintAppVersion", "Checked status: " + ((BluDroidSwitch)findViewById(R.id.printVersionNoSwitch)).isChecked());

        compareUpdate(PREF_STORE_NAME, R.id.storeNameSetting);
        compareUpdate(PREF_STORE_ADDRESS, R.id.addressSetting);
        compareUpdate(PREF_VAT_REG_NO, R.id.vatRegNoSetting);

        compareUpdate(PREF_BP_LIMIT, R.id.bpLimitSetting);

        compareUpdate(PREF_LOYALTY_ENABLE_USER, R.id.loyaltySwitch);

        String salesReceipt = getPreference(PREF_PRINT_SALES_RECEIPT);
        String merchantReceipt = getPreference(PREF_PRINT_MERCHANT_VOUCHER);

        if (salesReceipt.equalsIgnoreCase("true") || merchantReceipt.equalsIgnoreCase("true")) {
            updatePreference(PREF_VOUCHER_SECONDS, "5");
        } else {
            updatePreference(PREF_VOUCHER_SECONDS, "0");
        }

        gotoMainScreen();
        createNotification(String.format(getResources().getString(R.string.changesSaved), "User"));
    }


    private void initFields() {
        setupSwitch(R.id.printVersionNoSwitch, PREF_PRINT_APP_VERSION);
        setupSwitch(R.id.merchantVouchersSwitch, PREF_PRINT_MERCHANT_VOUCHER);
        setupSwitch(R.id.merchantTicketsSwitch, PREF_PRINT_MERCHANT_VOUCHER_TICKETS);
        setupSwitch(R.id.merchantVouchersSwitch, PREF_PRINT_MERCHANT_VOUCHER);
        setupSwitch(R.id.printBarcodeSwitch, PREF_PRINT_BARCODE_RECEIPT);
        setupSwitch(R.id.cashierEndShiftSwitch, PREF_CASHIER_END_SHIFT);
        setupSwitch(R.id.useBasketSwitch, PREF_USE_BASKET);
        setupSwitch(R.id.salesReceiptSwitch, PREF_PRINT_SALES_RECEIPT);
        setupSwitch(R.id.reportPreviewSwitch, PREF_PRINT_PREVIEWS);
        setupSwitch(R.id.receiptPreviewSwitch, PREF_PRINT_PREVIEW_RECEIPTS);
        setupSwitch(R.id.cashDrawSwitch, PREF_CASH_DRAWER);

//        setupSpinner(R.id.displayBalanceSpinner, PREF_DISPLAY_BALANCE1, displayBalanceOptions);

        //setupEditText(R.id.screenTimeOutSetting, PREF_SCREEN_TIMEOUT);
        setupEditText(R.id.storeNameSetting, PREF_STORE_NAME);
        setupEditText(R.id.addressSetting, PREF_STORE_ADDRESS);
        setupEditText(R.id.vatRegNoSetting, PREF_VAT_REG_NO);
        setupEditText(R.id.bpLimitSetting, PREF_BP_LIMIT);

        setupSwitch(R.id.loyaltySwitch, PREF_LOYALTY_ENABLE_USER);

//        setupEditText(R.id.lowBalanceAmountSetting, PREF_LOW_BALANCE_AMOUNT);

        //Error images
        setUpImageView(R.id.deviceUserError, getResources().getDrawable(R.drawable.warning));
        setUpImageView(R.id.receiptsError, getResources().getDrawable(R.drawable.warning));
        setUpImageView(R.id.storeError, getResources().getDrawable(R.drawable.warning));

        setUpImageView(R.id.accountBalanceError, getResources().getDrawable(R.drawable.warning));

    }

    private void hideLoyaltyIfTechDisabled() {
        if (!getPreference(PREF_LOYALTY_ENABLE_TECH).equals(PREF_TRUE)) {
            hideShow(R.id.loyaltyGroupToggle, GONE);
        }
    }

    private void hideLoyaltyIfGcrs() {
        if (isGcrs() || isGcrsSkin()) {
            hideShow(R.id.loyaltyGroupToggle, GONE);
        }
    }

    private void hideReceiptsSettings() {
        hideShow(R.id.receiptSettingsGroup, GONE);
    }

    private void showReceiptsSettings() {
        hideShow(R.id.receiptSettingsGroup, VISIBLE);
    }

    private void hideDeviceSettings() {
        hideShow(R.id.deviceSettingsGroup, GONE);
    }

    private void showDeviceSettings() {
        hideShow(R.id.deviceSettingsGroup, VISIBLE);

        if (Build.MODEL.startsWith("P1") || Build.MODEL.startsWith("V1") || Build.MODEL.startsWith("N3")) {
            ((BluDroidTextView) findViewById(R.id.cashDrawLabel)).setTextColor(getResources().getColor(R.color.mediumGrey));
            ((BluDroidSwitch) findViewById(R.id.cashDrawSwitch)).setChecked(false);
            findViewById(R.id.cashDrawSwitch).setEnabled(false);
            updatePreference(PREF_CASH_DRAWER, PREF_FALSE);
        }
    }

    private void hideStoreSettings() {
        hideShow(R.id.storeSettingsGroup, GONE);
    }

    private void showStoreSettings() {
        hideShow(R.id.storeSettingsGroup, VISIBLE);
    }

    private void hideAccountBalanceSettings() {
        hideShow(R.id.accountBalanceGroup, GONE);
    }

    private void showAccountBalanceSettings() {
        hideShow(R.id.accountBalanceGroup, VISIBLE);
    }

    private void populateAccounts() {
        accountNumbers.clear();
        String accountInfo = getPreference(PREF_ACCOUNT_DETAILS);
        Log.w("ProfDispRead", "read from prefs: " + accountInfo);
        try {
            Gson gson = new GsonBuilder().serializeNulls().create();
            ArrayList<CommonResponseAccountMessage> accounts = gson.fromJson(accountInfo, new TypeToken<ArrayList<CommonResponseAccountMessage>>() {
            }.getType());
            if (accounts != null) {
                for (CommonResponseAccountMessage acc : accounts) {
                    accountNumbers.add(acc.getText());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            logger.error("populateAccounts exception" + e);
        }
        displayAccountLayout();
    }

    private void hideLoyaltySettings() {
        hideShow(R.id.loyaltyGroup, GONE);
    }

    private void showLoyaltySettings() {
        hideShow(R.id.loyaltyGroup, VISIBLE);
    }

    private void showToggleErrors() {
        if (receiptSettingsHaserrors) {
            hideShow(R.id.receiptsError, VISIBLE);
        }
        if (deviceUserSettingsHaserrors) {
            hideShow(R.id.deviceUserError, VISIBLE);
        }
        if (storeSettingsHaserrors) {
            hideShow(R.id.storeError, VISIBLE);
        }
        if (accountBalanceSettingsHaserrors) {
            hideShow(R.id.accountBalanceError, VISIBLE);
        }
    }

    private void hideToggleErrors() {
        removeDeviceToggleErrors();
        hideShow(R.id.receiptsError, GONE);
        hideShow(R.id.deviceUserError, GONE);
        hideShow(R.id.storeError, GONE);
        hideShow(R.id.accountBalanceError, GONE);
    }

    private void setAlertPositiveButton() {
        if (alert != null) {
            alert.setNegativeOption(getResources().getString(R.string.leave), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    gotoMainScreen();
                }
            });
        }
    }

    private void setAlertNegativeButton() {
        if (alert != null) {
            alert.setPositiveOption(getResources().getString(R.string.save), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (layout.validate()) {
                        saveSettings();
                    }
                }
            });
        }
    }

    private void setAlertNeutralButton() {
        if (alert != null) {
            alert.setNeutralOption(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alert.dismiss();
                }
            });
        }
    }

    public void affirmativeButton(View view) {
        Log.d(TAG, "affirmativeButton confirmationType=" + confirmationType);
        if (confirmationType == 1) {
            dismissConfirmation();
            confirmationType = 3;
        }
        if (confirmationType == 2) {
            confirmation.dismiss();
            Toast.makeText(this, "THIS IS NOT YET IMPLEMENTED.  AWAITING FURTHER INFORMATION", Toast.LENGTH_LONG).show();
            confirmationType = 0;
        }
        if (confirmationType == 3) {
            Log.d(TAG, "saving");
            confirmationType = 0;
        }
    }

    public void negativeButton(View view) {
        Log.d(TAG, "negativeButton");
        confirmationType = 0;
        gotoMainScreen();
    }

    public void neutralButton(View view) {
        Log.d(TAG, "neutralButton");
        confirmationType = 0;
        confirmation.dismiss();
    }

    private String getBalanceSelection(String userLevel, String account) {
        int accountIndex = -1;
        int userIndex = -1;
        for (int i = 0; i < accountNumbers.size(); i++) {
            if (accountNumbers.get(i).equals(account)) {
                accountIndex = i;
                break;
            }
        }
        switch (userLevel) {
            case "Supervisor":
                userIndex = 0;
                break;
            case "CashierPlus":
                userIndex = 1;
                break;
            case "Cashier":
                userIndex = 2;
                break;
        }

        if (accountIndex != -1 && userIndex != -1) {
            RadioGroup rg = rgBalances.get(accountIndex).get(userIndex);
            int radioButtonIdx = rg.getCheckedRadioButtonId();
            RadioButton rb = rg.findViewById(radioButtonIdx);
            return rb.getText().toString();
        } else {
            Log.e("ProfDisp", "accountIndex=" + accountIndex + " userIndex=" + userIndex);
        }
        return null;
    }

    private String getProfitSelection(String userLevel, String account) {
        int accountIndex = -1;
        int userIndex = -1;
        for (int i = 0; i < accountNumbers.size(); i++) {
            if (accountNumbers.get(i).equals(account)) {
                accountIndex = i;
                break;
            }
        }
        switch (userLevel) {
            case "Supervisor":
                userIndex = 0;
                break;
            case "CashierPlus":
                userIndex = 1;
                break;
            case "Cashier":
                userIndex = 2;
                break;
        }

        if (accountIndex != -1 && userIndex != -1) {
            RadioGroup rg = rgProfits.get(accountIndex).get(userIndex);
            int radioButtonIdx = rg.getCheckedRadioButtonId();
            RadioButton rb = rg.findViewById(radioButtonIdx);
            return rb.getText().toString();
        } else {
            Log.e("ProfDisp", "accountIndex=" + accountIndex + " userIndex=" + userIndex);
        }
        return null;
    }

    private String getBalanceAmountEntered(String account) {
        int accountIndex = -1;
        for (int i = 0; i < accountNumbers.size(); i++) {
            if (accountNumbers.get(i).equals(account)) {
                accountIndex = i;
                break;
            }
        }

        if (accountIndex != -1) {
            BluDroidMoneyEditText txt = warnAmounts.get(accountIndex);
            return txt.getText().toString();
        } else {
            Log.e("ProfDisp", "accountIndex=" + accountIndex);
        }
        return null;
    }

    @Override
    public void onBackPressed() {

        if (//hasChanges(R.id.screenTimeOutSetting, PREF_SCREEN_TIMEOUT) ||
                hasChanges(R.id.storeNameSetting, PREF_STORE_NAME)
                        || hasChanges(R.id.addressSetting, PREF_STORE_ADDRESS)
                        || hasChanges(R.id.vatRegNoSetting, PREF_VAT_REG_NO)
                        || hasChanges(R.id.merchantVouchersSwitch, PREF_PRINT_MERCHANT_VOUCHER)
                        || hasChanges(R.id.merchantTicketsSwitch, PREF_PRINT_MERCHANT_VOUCHER_TICKETS)
                        || hasChanges(R.id.cashierEndShiftSwitch, PREF_CASHIER_END_SHIFT)
                        || hasChanges(R.id.useBasketSwitch, PREF_USE_BASKET)
                        || hasChanges(R.id.salesReceiptSwitch, PREF_PRINT_SALES_RECEIPT)
                        || hasChanges(R.id.reportPreviewSwitch, PREF_PRINT_PREVIEWS)
                        || hasChanges(R.id.cashDrawSwitch, PREF_CASH_DRAWER)
                        || hasChanges(R.id.bpLimitSetting, PREF_BP_LIMIT)

                || hasChanges(R.id.loyaltySwitch, PREF_LOYALTY_ENABLE_USER)
                || hasBalanceChanges()
                || hasProfitChanges()) {

            alert = createLeaveNoSaveConfirmation();

            setAlertNeutralButton();
            setAlertNegativeButton();
            setAlertPositiveButton();
            alert.show();
        } else {
            gotoMainScreen();
        }

    }

    List<List<RadioGroup>> rgBalances = new ArrayList<>();
    List<BluDroidMoneyEditText> warnAmounts = new ArrayList<>();
    List<List<RadioGroup>> rgProfits = new ArrayList<>();

    private void displayAccountLayout() {
        LinearLayout accountGroup = findViewById(R.id.accountBalanceGroup);
        for (int i = 0; i < accountNumbers.size() && i < MAX_ACCOUNT_DISPLAY; i++) {
            String acc = accountNumbers.get(i);
            LayoutInflater accountInflater = getLayoutInflater();
            View accountLayout = accountInflater.inflate(R.layout.layout_account, accountGroup, false);

            LinearLayout layoutBalance = accountLayout.findViewById(R.id.layoutBalance);

            TextView txtAccount = accountLayout.findViewById(R.id.txtAccount);
            txtAccount.setText("Account: " + acc);
            List<RadioGroup> rgBalance = new ArrayList<>();
            RadioGroup rgBalanceSupervisor = accountLayout.findViewById(R.id.rgBalanceSupervisor);
            RadioGroup rgBalanceCashierPlus = accountLayout.findViewById(R.id.rgBalanceCashierPlus);
            RadioGroup rgBalanceCashier = accountLayout.findViewById(R.id.rgBalanceCashier);
            rgBalance.add(rgBalanceSupervisor);
            rgBalance.add(rgBalanceCashierPlus);
            rgBalance.add(rgBalanceCashier);
            rgBalances.add(rgBalance);
            String superBalance = getBalancePref("Supervisor", acc);
            rgBalanceSupervisor.check(superBalance.equals("Off") ? R.id.rbBalanceSuperOff
                    : superBalance.equals("Warn") ? R.id.rbBalanceSuperWarn
                    : R.id.rbBalanceSuperOn);
            String cashierPlusBalance = getBalancePref("CashierPlus", acc);
            rgBalanceCashierPlus.check(cashierPlusBalance.equals("Off") ? R.id.rbBalanceCplusOff
                    : cashierPlusBalance.equals("Warn") ? R.id.rbBalanceCplusWarn
                    : R.id.rbBalanceCplusOn);
            String cashierBalance = getBalancePref("Cashier", acc);
            rgBalanceCashier.check(cashierBalance.equals("Off") ? R.id.rbBalanceCashOff
                    : cashierBalance.equals("Warn") ? R.id.rbBalanceCashWarn
                    : R.id.rbBalanceCashOn);

            int errorId = View.generateViewId();
            BluDroidErrorTextView errorText = accountLayout.findViewWithTag("amountError");
            errorText.setId(errorId);
            BluDroidMoneyEditText warnAmount = accountLayout.findViewById(R.id.lowBalanceAmountSetting);
            warnAmount.setErrorFieldResourceId(errorId);
            String warnAmt = getBalanceAmountPref(acc);
            if (warnAmt.isEmpty()) {
                warnAmt = new BluDroidUtils().formatMoney(getResources().getString(R.string.low_balance_amount_default));
            }
            warnAmount.setText(warnAmt);
            warnAmounts.add(warnAmount);

            LinearLayout layoutProfit = accountLayout.findViewById(R.id.layoutProfit);
            List<RadioGroup> rgProfit = new ArrayList<>();
            RadioGroup rgProfitSupervisor = accountLayout.findViewById(R.id.rgProfitSupervisor);
            RadioGroup rgProfitCashierPlus = accountLayout.findViewById(R.id.rgProfitCashierPlus);
            RadioGroup rgProfitCashier = accountLayout.findViewById(R.id.rgProfitCashier);
            rgProfit.add(rgProfitSupervisor);
            rgProfit.add(rgProfitCashierPlus);
            rgProfit.add(rgProfitCashier);
            rgProfits.add(rgProfit);
            String superProfit = getProfitPref("Supervisor", acc);
            rgProfitSupervisor.check(superProfit.equals("Off") ? R.id.rbProfitSuperOff : R.id.rbProfitSuperOn);
            String cashierPlusProfit = getProfitPref("CashierPlus", acc);
            rgProfitCashierPlus.check(cashierPlusProfit.equals("Off") ? R.id.rbProfitCplusOff : R.id.rbProfitCplusOn);
            String cashierProfit = getProfitPref("Cashier", acc);
            rgProfitCashier.check(cashierProfit.equals("Off") ? R.id.rbProfitCashOff : R.id.rbProfitCashOn);

            if (profitDisplayEnabled) {
                Log.d("ProfDisp", "setting profit visible");
                layoutProfit.setVisibility(VISIBLE);
            } else {
                Log.d("ProfDisp", "setting profit gone");
                layoutProfit.setVisibility(GONE);
            }

            if (balanceDisplayEnabled) {
                Log.d("ProfDisp", "setting balance visible");
                layoutBalance.setVisibility(VISIBLE);
            } else {
                Log.d("ProfDisp", "setting balance gone");
                layoutBalance.setVisibility(GONE);
            }

            accountGroup.addView(accountLayout, i, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

    }

}

