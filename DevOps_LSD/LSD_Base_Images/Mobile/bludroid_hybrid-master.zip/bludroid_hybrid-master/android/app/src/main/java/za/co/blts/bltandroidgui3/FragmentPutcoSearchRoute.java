package za.co.blts.bltandroidgui3;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;


/**
 * A simple {@link Fragment} subclass.
 */


public class FragmentPutcoSearchRoute extends BaseFragment implements NeedsAEONResults, View.OnTouchListener, TextView.OnEditorActionListener, View.OnLongClickListener, AdapterView.OnItemSelectedListener {


    private final String TAG = this.getClass().getSimpleName();

    public BluDroidEditText route;

    public BluDroidSpinner departure;
    private BluDroidSpinner destination;

    private BluDroidTextView destinationLabel;

    public BluDroidRelativeLayout layout;

    private boolean isDepartureSpinnerFirstTime = true;
    private boolean isDestinationSpinnerFirstTime = true;

    public final List<String> departures = new ArrayList<>();
    private final List<String> destinations = new ArrayList<>();

    private ArrayAdapter<String> departAdapter, destinationAdapter;

    private String selection;

    public FragmentPutcoSearchRoute() {
        // Required empty public constructor
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume");

        isDepartureSpinnerFirstTime = true;
        isDestinationSpinnerFirstTime = true;

        layout = getView().findViewById(R.id.layout);

        route = getView().findViewById(R.id.routeCode);

        departure = getView().findViewById(R.id.departure);
        departure.setOnTouchListener(this);
        departure.setOnItemSelectedListener(this);


        destination = getView().findViewById(R.id.destination);
        destinationLabel = getView().findViewById(R.id.destinationLabel);
        destination.setOnTouchListener(this);
        destination.setOnItemSelectedListener(this);


        BluDroidButton getRoute = getView().findViewById(R.id.getRoute);

        getRoute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                if (getBaseActivity().searchByRoute) {
                    getBaseActivity().needRoute = true;
                    getBaseActivity().needDepartures = false;
                    getBaseActivity().needDestinations = false;
                    getBaseActivity().routeCode = route.getText().toString();
                    getBaseActivity().authenticateWithTicketPro();

                } else {
                    getBaseActivity().searchRoutes(selection);
                }
            }
        });

        hideDestinations();
        //hideRoutes();

        getBaseActivity().routeCode = "";
        getBaseActivity().departureName = "";
        getBaseActivity().destinationName = "";
        route.setText("");

        getBaseActivity().requestAllPutcoLocationsList();


        route.setImeOptions(EditorInfo.IME_ACTION_NEXT);
        route.setOnEditorActionListener(this);
        route.setOnTouchListener(this);

        departAdapter = new ArrayAdapter<>(getContext(), R.layout.spinner_item, departures);
        departAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        departure.setAdapter(departAdapter);
        departure.setFocusable(true);

        destinationAdapter = new ArrayAdapter<>(getContext(), R.layout.spinner_item, destinations);
        destinationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        destination.setAdapter(destinationAdapter);
        destination.setFocusable(true);

        getBaseActivity().resetTimer();
    }

    public void updateDepartures(List<String> newDepartures) {
        Log.d(TAG, "updateDepartures");
        departures.clear();
        departures.addAll(newDepartures);
        departAdapter.notifyDataSetChanged();
//        departAdapter.notifyDataSetInvalidated();
    }

    public void updateDestinations(List<String> newDestinations) {
        Log.d(TAG, "updateDestinations");
        destinations.clear();
        destinations.addAll(newDestinations);
        destinationAdapter.notifyDataSetChanged();
//        destinationAdapter.notifyDataSetInvalidated();
//        destination.setSelection(0, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d(TAG, "onViewCreated");


    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_putco_search_route, container, false);
    }


    private void clearButton() {
        route.setText("");
        isDepartureSpinnerFirstTime = true;
//        departure.setSelection(0);  // this assumes that there is data in the spinner
        hideDestinations();
    }


    @Override
    public boolean onLongClick(View v) {
        return false;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {

        // lastViewTouched = view;
        //  Log.d(TAG, "last view touched is now " + lastViewTouched);
        if (v.getId() == R.id.departure) {
            isDepartureSpinnerFirstTime = false;
            getBaseActivity().searchByRoute = false;
        } else if (v.getId() == R.id.destination) {
            getBaseActivity().searchByRoute = false;
        } else if (v.getId() == R.id.routeCode) {
            clearButton();
            getBaseActivity().searchByRoute = true;
        }
        return false;
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        Log.d(TAG, "view is " + v);
        if (v.getId() == R.id.routeCode) {
            Log.d(TAG, "route view actionId is " + actionId);
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_NEXT) {
                getBaseActivity().needRoute = true;
                getBaseActivity().needDepartures = false;
                getBaseActivity().needDestinations = false;
                getBaseActivity().routeCode = v.getText().toString();
                Log.d(TAG, "done! got [" + getBaseActivity().routeCode + "]");
                getBaseActivity().searchByRoute = true;
                getBaseActivity().authenticateWithTicketPro();

                return true;
            }
        }
        return false;
    }

    private void hideDestinations() {
        destinationLabel.setVisibility(View.INVISIBLE);
        destination.setVisibility(View.INVISIBLE);
        //getRoute.setVisibility(View.INVISIBLE);
    }

    public void showDestinations() {
        destinationLabel.setVisibility(View.VISIBLE);
        destination.setVisibility(View.VISIBLE);
        // getRoute.setVisibility(View.VISIBLE);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Log.v(TAG, "onItemSelected");

        Object object = parent.getItemAtPosition(position);
        Log.d(TAG, "object is " + object);

        selection = object.toString();

        if (parent.getId() == R.id.departure) {
            isDestinationSpinnerFirstTime = true;
            Log.d(TAG, "searchByRoute-2  " + getBaseActivity().searchByRoute);

            if (!getBaseActivity().searchByRoute) {
                route.setText("");
            }
            Log.d(TAG, "departure spinner to " + selection);
            departure.onItemSelected(parent, view, position, id);

            if (isDepartureSpinnerFirstTime) {
                isDepartureSpinnerFirstTime = false;
                return;
            }

            //
            // find the ID of this departure
            //
            getBaseActivity().departureId = "";
            for (int i = 0; i < getBaseActivity().ticketProResponseAllLocationsMessage.getData().getLocations().size(); i++) {
                if (selection.equals(getBaseActivity().ticketProResponseAllLocationsMessage.getData().getLocations().get(i).getName())) {
                    getBaseActivity().departureName = selection;
                    getBaseActivity().departureId = getBaseActivity().ticketProResponseAllLocationsMessage.getData().getLocations().get(i).getId();
                    break;
                }
            }

            hideDestinations();

            getBaseActivity().searchByRoute = false;
            //
            //now request destinations for this departure
            //
            //getBaseActivity().dismissProgress();
            //
            // only get the voucher list if the current
            // cached list is more than N seconds old
            //


            getBaseActivity().ticketProResponsePossibleDestinationsMessage = getBaseActivity().getCachedPutcoPossibleDestinationsData(getBaseActivity().departureId);
            if (!getBaseActivity().putcoAuthenticationRequired(getBaseActivity().dateLastPutcoPossibleDestinationsCache(getBaseActivity().departureId),
                    getBaseActivity().ticketProResponsePossibleDestinationsMessage,
                    false, false, true)) {

                getBaseActivity().results(getBaseActivity().ticketProResponsePossibleDestinationsMessage);

            }
            // }
            // getBaseActivity().getPutcoDestinationas();

        } else if (parent.getId() == R.id.destination) {
            Log.d(TAG, "destination spinner to " + selection);
            destination.onItemSelected(parent, view, position, id);
            if (isDestinationSpinnerFirstTime) {
                isDestinationSpinnerFirstTime = false;
                return;
            }
//            if (getBaseActivity().destinationSpinnerFirstTime) {
//                getBaseActivity().destinationSpinnerFirstTime = false;
//                return;
//            }
            getBaseActivity().destinationName = selection;
            getBaseActivity().searchRoutes(selection);


        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


}
