package za.co.blts.bltandroidgui3;


import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.telephony.CellInfo;
import android.telephony.CellInfoCdma;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoWcdma;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.File;
import java.lang.ref.WeakReference;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;

//
// attempt to get geo location
//
//import android.net.Network;

class BluDroidLocationServices extends PhoneStateListener implements LocationListener {

    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference;

    private LocationManager locationManager;
    private static WifiManager wifiManager = null;
    //    private BluDroidPhoneStateListener phoneStateListener = null;
    private static TelephonyManager telephonyManager = null;

    private static int previousDBM = 0;

    private String bssid;
    private String simSerialNumber;
    private String simOp;
    private String carrier;
    private String ip;
    private String locationStr;
    private String cellTowerStr;

    private static Long kms = null;

    private long lastSignalUpdate = 0;

    private CellInfo savedCellInfo;
    private Location savedLocation;

    BluDroidLocationServices(BaseActivity baseScreen) {
        this.baseActivityWeakReference = new WeakReference<>(baseScreen);
        bssid = "";
        simSerialNumber = "";
        simOp = "";
        carrier = "";
        ip = "";
        locationStr = "";
        cellTowerStr = "";
        checkWifi();
        checkKMS();
        checkSIM();
        checkIPAddresses();
    }

    public void start() {
        Log.d(TAG, "start");
        startLocationListener();
        startTelephonyListener();
    }

    void stop() {
        Log.d(TAG, "stop");
        stopLocationListener();
        stopTelephonyListener();
    }

    private void startLocationListener() {
        try {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                locationManager = (LocationManager) baseScreen.getSystemService(Context.LOCATION_SERVICE);
                Log.d(TAG, "Locationmanager is " + locationManager);
                BaseActivity.location = "";

                boolean hasGPS = false, hasNetwork = false, hasPassive = false, hasFused = false;

                List<String> providers = locationManager.getAllProviders();
                for (int i = 0; i < providers.size(); i++) {
                    Log.d(TAG, "i=" + i + " " + providers.get(i));
                    if (providers.get(i).equals("gps"))
                        hasGPS = true;
                    if (providers.get(i).equals("network"))
                        hasNetwork = true;
                    if (providers.get(i).equals("passive"))
                        hasPassive = true;
                    if (providers.get(i).equals("fused"))
                        hasFused = true;
                }

                if (hasPassive)
                    startListener("passive");
                if (hasNetwork)
                    startListener("network");
                if (hasGPS)
                    startListener("gps");
                if (hasFused)
                    startListener("fused");

                if (!hasGPS && !hasNetwork && !hasPassive && !hasFused)
                    log("No providers found - unable to get location");

            }
        } catch (SecurityException exception) {
            log("getLocationDetails security exception " + exception);
        } catch (Exception exception) {
            log("getLocationDetails exception " + exception);
        }
    }

    private void startListener(String provider) throws SecurityException {
        LocationProvider locationProvider = locationManager.getProvider(provider);

        if (locationProvider != null) {
            Log.d(TAG, ">>>>>>locationProvider: " + locationProvider.getName());
            Log.d(TAG, "accuracy is " + locationProvider.getAccuracy());
            Criteria criteria = new Criteria();
            criteria.setAccuracy(Criteria.ACCURACY_FINE);

            Log.d(TAG, "supports FINE accuracy " + locationProvider.meetsCriteria(criteria));
            Log.d(TAG, "requires cell network " + locationProvider.requiresCell());
            Log.d(TAG, "requires network " + locationProvider.requiresNetwork());
            Log.d(TAG, "requires satellite " + locationProvider.requiresSatellite());
        } else {
            log(">>>>>>locationProvider is null: " + provider);
        }
        Location location = locationManager.getLastKnownLocation(provider);

        Log.d(TAG, "last known location is " + location);
        if (location != null) {
            onLocationChanged(location);
        } else {
            Log.d(TAG, "setting BaseActivity.location to empty string");
            locationStr = "";
        }
        locationManager.requestLocationUpdates(provider, 10000, 0, this);
        Log.d(TAG, "<<<<<<<requested location updated");
    }

    public void onLocationChanged(Location location) {
        String loc = String.format(Locale.US, "%s %.5f,%.5f acc=%d time=%s", location.getProvider(), location.getLongitude(), location.getLatitude(), (int) location.getAccuracy(), new Date(location.getTime()));
        Log.d(TAG, "new location " + loc);
        if (isBetterLocation(location, savedLocation)) {
            savedLocation = location;
            Log.d(TAG, "=============>SAVED AS BETTER LOCATION");

            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                baseScreen.updatePreference(BluDroidPrefs.PREF_SAVED_LOCATION, getLocString());
            }
        }
    }

    private static final int FIVE_MINUTES = 1000 * 60 * 5;
    private static final int TEN_SECONDS = 1000 * 10;

    /**
     * Determines whether one Location reading is better than the current Location fix
     *
     * @param location            The new Location that you want to evaluate
     * @param currentBestLocation The current Location fix, to which you want to compare the new one
     */
    private boolean isBetterLocation(Location location, Location currentBestLocation) {
        if (currentBestLocation == null) {
            // A new location is always better than no location
            Log.i(TAG, "best = null");
            return true;
        }

        // Check whether the new location fix is newer or older
        long timeDelta = location.getTime() - currentBestLocation.getTime();
        boolean isSignificantlyNewer = timeDelta > FIVE_MINUTES;
        boolean isSignificantlyOlder = timeDelta < -FIVE_MINUTES;
        boolean isNewer = timeDelta > TEN_SECONDS;

        // If it's been more than one minute since the current location, use the new location
        // because the user has likely moved
        if (isSignificantlyNewer) {
            Log.i(TAG, "newer");
            return true;
            // If the new location is more than two minutes older, it must be worse
        } else if (isSignificantlyOlder) {
            Log.i(TAG, "older");
            return false;
        }

        // Check whether the new location fix is more or less accurate
        int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation.getAccuracy());
        boolean isLessAccurate = accuracyDelta > 0;
        boolean isMoreAccurate = accuracyDelta < 0;
        boolean isSignificantlyLessAccurate = accuracyDelta > 200;

        // Check if the old and new location are from the same provider
        boolean isFromSameProvider = isSameProvider(location.getProvider(), currentBestLocation.getProvider());

        // Determine location quality using a combination of timeliness and accuracy
        if (isMoreAccurate) {
            Log.i(TAG, "more accurate");
            return true;
        } else if (isNewer && !isLessAccurate) {
            Log.i(TAG, "newer, same accuracy");
            return true;
        } else if (isNewer && !isSignificantlyLessAccurate && isFromSameProvider) {
            Log.i(TAG, "newer, not sig less accurate, same provider");
            return true;
        }
        return false;
    }

    /**
     * Checks whether two providers are the same
     */
    private boolean isSameProvider(String provider1, String provider2) {
        if (provider1 == null) {
            return provider2 == null;
        }
        return provider1.equals(provider2);
    }

    private void stopLocationListener() {
        if (locationManager != null) {
            locationManager.removeUpdates(this);
            locationManager = null;
        }
    }

    @SuppressLint("HardwareIds")
    private void startTelephonyListener() {
        try {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                Log.d(TAG, "getTelephonyInformation");
                if (telephonyManager == null) {
                    telephonyManager = (TelephonyManager) baseScreen.getSystemService(Context.TELEPHONY_SERVICE);
                    Log.d(TAG, "telephonyManager is " + telephonyManager);
                }

                if (telephonyManager == null)
                    return;

                Log.d(TAG, "Sim state: " + telephonyManager.getSimState());
                if (telephonyManager.getSimState() == TelephonyManager.SIM_STATE_ABSENT) {
                    log("no sim present");
                    return;
                }

//                phoneStateListener = new BluDroidPhoneStateListener();
                telephonyManager.listen(this, PhoneStateListener.LISTEN_CELL_INFO | PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);

                Log.d(TAG, "network operator " + telephonyManager.getNetworkOperator());
                Log.d(TAG, "subscriber ID " + telephonyManager.getSubscriberId());
                // AP level 26 Log.d(TAG, "imei " + telephonyManager.getImei());
                // AP level 26 Log.d(TAG, "meid " + telephonyManager.getMeid());
                Log.d(TAG, "line1Number " + telephonyManager.getLine1Number());
                // AP level 26 Log.d(TAG, "nai " + telephonyManager.getNai());
                Log.d(TAG, "subscriber Id " + telephonyManager.getSubscriberId());
                //simOp = telephonyManager.getSimOperatorName();
                //Log.d(TAG, "sim operator name " + telephonyManager.getSimOperatorName());
                Log.d(TAG, "sim operator name " + simOp);
                Log.d(TAG, "sim serial number " + telephonyManager.getSimSerialNumber());

                onCellInfoChanged(telephonyManager.getAllCellInfo());

//                Log.d(TAG, "Neighbouring cells:");
//                for (NeighboringCellInfo c : telephonyManager.getNeighboringCellInfo()){
//                    Log.d(TAG, "getNetworkType:" + c.getNetworkType() + " getCid:" + c.getCid() + " getLac:" + c.getLac() + " getPsc:" + c.getPsc() + " getRssi:" + c.getRssi());
//                }

                Log.d(TAG, "location " + BaseActivity.location);
            }
        } catch (SecurityException exception) {
            log("startTelephonyListener security exception " + exception);
            cellTowerStr = "";
        } catch (Exception exception) {
            log("startTelephonyListener exception " + exception);
            cellTowerStr = "";
        }
    }

    private void stopTelephonyListener() {
//        if (telephonyManager != null && phoneStateListener != null) {
        if (telephonyManager != null) {
            telephonyManager.listen(this, PhoneStateListener.LISTEN_NONE);
        }
    }

    private void checkIPAddresses() {
        Log.d(TAG, "checkIPAddresses");
        try {
            //
            // from  https://stackoverflow.com/questions/6064510/how-to-get-ip-address-of-the-device-from-code
            //
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                NetworkInterface networkInterface = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = networkInterface.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        //
                        // for now, ignore IPv6
                        //
                        String hostAddress = inetAddress.getHostAddress();
                        if (!hostAddress.contains(":")) {
                            Log.d(TAG, "ip=" + hostAddress);
                            ip = hostAddress;
                        }
                    }
                }
            }
        } catch (Exception exception) {
            log("checkIPAddresses exception " + exception);
        }
    }

    @SuppressLint("HardwareIds")
    private void checkWifi() {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            //
            // see if connected to wifi
            //
            if (wifiManager == null) {
                wifiManager = (WifiManager) baseScreen.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                Log.d(TAG, "wifiManager is " + wifiManager);
            }
            Log.d(TAG, "wifi enabled " + wifiManager.isWifiEnabled());


            ConnectivityManager connectivityManager = (ConnectivityManager) baseScreen.getSystemService(Context.CONNECTIVITY_SERVICE);
            //Network network = connectivityManager.getActiveNetwork();
            //Log.d(TAG, "active network is " + network.toString());
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo != null) {
                Log.d(TAG, "active network info is " + networkInfo.toString());
                Log.d(TAG, "typename [" + networkInfo.getTypeName() + "]");
                Log.d(TAG, "type " + networkInfo.getType());
                Log.d(TAG, "subtypename " + networkInfo.getSubtypeName());
                Log.d(TAG, "isConnected " + networkInfo.isConnected());
                Log.d(TAG, "wifi enabled " + wifiManager.isWifiEnabled());
                if (wifiManager.isWifiEnabled()) {
                    WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                    Log.d(TAG, "wifiInfo " + wifiInfo.toString());
                    Log.d(TAG, "mac address " + wifiInfo.getMacAddress());
                    Log.d(TAG, "Rssi " + wifiInfo.getRssi());
                    Log.d(TAG, "ssid " + wifiInfo.getSSID());
                    Log.d(TAG, "bssid " + wifiInfo.getBSSID());
                    bssid = wifiInfo.getBSSID();
                } else {
                    log("wifiManager not enabled");
                }
            } else {
                log("network info is null");
            }
        }
    }

    private void checkKMS() {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            Log.d(TAG, "checkKMS");
            try {
                if (kms == null) {
                    kms = -1L;
                    Log.d(TAG, "kms app dir is " + baseScreen.kmsAppDir.getPath());
                    File[] list = baseScreen.kmsAppDir.listFiles();
                    for (File file : list) {
                        Log.d(TAG, "file is " + file.getName());
                        if (file.getName().equals("KMS.apk")) {
                            kms = file.length();
                            Log.d(TAG, "kms=" + kms);
                        }
                    }
                }
                Log.d(TAG, "KMS is " + kms);
            } catch (Exception exception) {
                log("checkKMS exception " + exception);
            }
        }
    }

    @SuppressLint("HardwareIds")
    private void checkSIM() {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            Log.d(TAG, "checkSIM");
            try {
                if (telephonyManager == null) {
                    telephonyManager = (TelephonyManager) baseScreen.getSystemService(Context.TELEPHONY_SERVICE);
                    Log.d(TAG, "telephonyManager is " + telephonyManager);
                }
                if (telephonyManager != null) {
                    simSerialNumber = telephonyManager.getSimSerialNumber();
                    simOp = telephonyManager.getSimOperatorName();
                    if (android.os.Build.VERSION.SDK_INT >= 22) {
                        SubscriptionManager subscriptionManager = (SubscriptionManager) baseScreen.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                        Log.d(TAG, "subscription manager is " + subscriptionManager);
                        if (subscriptionManager != null) {
                            List<SubscriptionInfo> list = subscriptionManager.getActiveSubscriptionInfoList();
                            for (int i = 0; i < list.size(); i++) {
                                Log.d(TAG, "i=" + i + " " + list.get(i).getCarrierName());
                            }
                            if ((list.size() > 0)) {
                                carrier = list.get(0).getCarrierName().toString();
                            }
                        }
                    }
                }
                Log.d(TAG, "simSerialNumber=" + simSerialNumber);
                Log.d(TAG, "simOp=" + simOp);
                Log.d(TAG, "carrier=" + carrier);
            } catch (SecurityException exception) {
                log("checkSIM security exception " + exception);
            } catch (Exception exception) {
                log("checkSIM exception " + exception);
            }
        }
    }

    private void log(String st) {
        Log.e(TAG, st);
        if (BaseActivity.logger != null)
            BaseActivity.logger.info(st);
    }

    void getLocationDetails() {
        appendLocation();
        appendBssid();
        appendKms();
        appendCarrier();
        appendIP();

        appendTelephonyInformation();

        Log.d(TAG, "getLocationDetails: " + BaseActivity.location);
    }

    public void onProviderDisabled(String provider) {
        Log.d(TAG, "provider disabled " + provider);
    }

    public void onProviderEnabled(String provider) {
        Log.d(TAG, "provider enabled " + provider);
    }

    public void onStatusChanged(String provider, int status, Bundle extras) {
//    Log.d(TAG, "onStatusChanged provider=" + provider + " status=" + status);
    }

    private void appendLocation() {
        Log.d(TAG, "appendLocation");
        locationStr = getLocString();
        BaseActivity.location = locationStr;
    }

    public Location getSavedLocation() {
        return savedLocation;
    }

    private String getLocString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss", Locale.US);
        if (savedLocation != null) {
            return String.format(Locale.US, "lon=%.5f,lat=%.5f,acc=%d,prov=%s,ts=%s", savedLocation.getLongitude(), savedLocation.getLatitude(), (int) savedLocation.getAccuracy(), savedLocation.getProvider(), sdf.format(new Date(savedLocation.getTime())));
        } else {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                return baseScreen.getPreference(BluDroidPrefs.PREF_SAVED_LOCATION);
            }
        }
        return "";
    }

    private void appendBssid() {
        try {
            Log.d(TAG, "appendBssid");
            if (BaseActivity.location.length() < 1) {
                BaseActivity.location = BaseActivity.location.concat("bssid=" + bssid);
            } else {
                if (!bssid.trim().isEmpty()) {
                    char ch = BaseActivity.location.charAt(BaseActivity.location.length() - 1);
                    if (ch != ',' && ch != ';')
                        BaseActivity.location = BaseActivity.location.concat(",bssid=" + bssid);
                    else
                        BaseActivity.location = BaseActivity.location.concat("bssid=" + bssid);
                }
            }
        } catch (Exception exception) {
            log("problem appending bssid to location " + exception);
        }
    }

    private void appendKms() {
        try {
            Log.d(TAG, "appendKms");
            if (BaseActivity.location.length() < 1) {
                BaseActivity.location = BaseActivity.location.concat("kms=" + kms);
            } else {
                if (!BaseActivity.location.contains("kms=" + kms)) {
                    //if ( !kms.trim().isEmpty() ) {
                    char ch = BaseActivity.location.charAt(BaseActivity.location.length() - 1);
                    if (ch != ',' && ch != ';')
                        BaseActivity.location = BaseActivity.location.concat(",kms=" + kms);
                    else
                        BaseActivity.location = BaseActivity.location.concat("kms=" + kms);
                }
            }
        } catch (Exception exception) {
            log("problem appending kms to location " + exception);
        }
    }

    private void appendCarrier() {
        try {
            Log.d(TAG, "appendCarrier");
            if (BaseActivity.location.length() < 1) {
                BaseActivity.location = BaseActivity.location.concat("carrier=" + carrier);
            } else {
                if (!BaseActivity.location.contains("carrier=" + carrier)) {
                    char ch = BaseActivity.location.charAt(BaseActivity.location.length() - 1);
                    if (ch != ',' && ch != ';')
                        BaseActivity.location = BaseActivity.location.concat(",carrier=" + carrier);
                    else
                        BaseActivity.location = BaseActivity.location.concat("carrier=" + carrier);
                }
            }
        } catch (Exception exception) {
            log("problem appending carrier to location " + exception);
        }
    }

    private void appendIP() {
        try {
            Log.d(TAG, "appendIP");
            if (BaseActivity.location.length() < 1) {
                BaseActivity.location = BaseActivity.location.concat("ip=" + ip);
            } else {
                if (!BaseActivity.location.contains("ip=" + ip)) {
                    char ch = BaseActivity.location.charAt(BaseActivity.location.length() - 1);
                    if (ch != ',' && ch != ';')
                        BaseActivity.location = BaseActivity.location.concat(",ip=" + ip + ";");
                    else
                        BaseActivity.location = BaseActivity.location.concat("ip=" + ip + ";");
                }
            }
        } catch (Exception exception) {
            log("problem appending simOp to location " + exception);
        }
    }

    @SuppressLint("HardwareIds")
    private void getTelephonyInformation() throws SecurityException {
        cellTowerStr = "";
        if (savedCellInfo != null) {
            StringBuilder cellTowersBuffer = new StringBuilder();

            if (savedCellInfo instanceof CellInfoWcdma) {
                CellInfoWcdma cellInfoWcdma = (CellInfoWcdma) savedCellInfo;
                if (cellInfoWcdma.getCellIdentity().getMcc() != 0
                        && cellInfoWcdma.getCellIdentity().getMnc() != 0
                        && cellInfoWcdma.getCellIdentity().getCid() != 0
                        && cellInfoWcdma.getCellIdentity().getLac() != 0) {
                    cellTowersBuffer.append("wcdma,mcc=").append(cellInfoWcdma.getCellIdentity().getMcc()).append(",");
                    cellTowersBuffer.append("mnc=").append(cellInfoWcdma.getCellIdentity().getMnc()).append(",");
                    cellTowersBuffer.append("cid=").append(cellInfoWcdma.getCellIdentity().getCid()).append(",");
                    cellTowersBuffer.append("lac=").append(cellInfoWcdma.getCellIdentity().getLac()).append(",");
                    cellTowersBuffer.append("ss=").append(cellInfoWcdma.getCellSignalStrength().getDbm()).append(",");
                    cellTowersBuffer.append("simop=").append(simOp).append(",");
                    cellTowersBuffer.append("sim=").append(telephonyManager.getSimSerialNumber());
                }

            } else if (savedCellInfo instanceof CellInfoCdma) {
                CellInfoCdma cellInfoCdma = (CellInfoCdma) savedCellInfo;
                cellTowersBuffer.append("cdma,bsid=").append(cellInfoCdma.getCellIdentity().getBasestationId()).append(",");
                cellTowersBuffer.append("ss=").append(cellInfoCdma.getCellSignalStrength().getDbm()).append(",");
                cellTowersBuffer.append("simop=").append(simOp).append(",");
                cellTowersBuffer.append("sim=").append(telephonyManager.getSimSerialNumber());

            } else if (savedCellInfo instanceof CellInfoLte) {
                CellInfoLte cellInfoLte = (CellInfoLte) savedCellInfo;
                if (cellInfoLte.getCellIdentity().getMcc() != 0
                        && cellInfoLte.getCellIdentity().getMnc() != 0
                        && cellInfoLte.getCellIdentity().getCi() != 0
                        && cellInfoLte.getCellIdentity().getTac() != 0) {
                    cellTowersBuffer.append("lte,mcc=").append(cellInfoLte.getCellIdentity().getMcc()).append(",");
                    cellTowersBuffer.append("mnc=").append(cellInfoLte.getCellIdentity().getMnc()).append(",");
                    cellTowersBuffer.append("cid=").append(cellInfoLte.getCellIdentity().getCi()).append(",");
                    cellTowersBuffer.append("lac=").append(cellInfoLte.getCellIdentity().getTac()).append(",");
                    cellTowersBuffer.append("ss=").append(cellInfoLte.getCellSignalStrength().getDbm()).append(",");
                    cellTowersBuffer.append("simop=").append(simOp).append(",");
                    cellTowersBuffer.append("sim=").append(telephonyManager.getSimSerialNumber());
                }

            } else if (savedCellInfo instanceof CellInfoGsm) {
                CellInfoGsm cellInfoGsm = (CellInfoGsm) savedCellInfo;
                if (cellInfoGsm.getCellIdentity().getMcc() != 0
                        && cellInfoGsm.getCellIdentity().getMnc() != 0
                        && cellInfoGsm.getCellIdentity().getCid() != 0
                        && cellInfoGsm.getCellIdentity().getLac() != 0) {
                    cellTowersBuffer.append("gsm,mcc=").append(cellInfoGsm.getCellIdentity().getMcc()).append(",");
                    cellTowersBuffer.append("mnc=").append(cellInfoGsm.getCellIdentity().getMnc()).append(",");
                    cellTowersBuffer.append("cid=").append(cellInfoGsm.getCellIdentity().getCid()).append(",");
                    cellTowersBuffer.append("lac=").append(cellInfoGsm.getCellIdentity().getLac()).append(",");
                    cellTowersBuffer.append("ss=").append(cellInfoGsm.getCellSignalStrength().getDbm()).append(",");
                    cellTowersBuffer.append("simop=").append(simOp).append(",");
                    cellTowersBuffer.append("sim=").append(telephonyManager.getSimSerialNumber());
                }
            }

            cellTowerStr = cellTowersBuffer.toString();
        }
        Log.d(TAG, "cell buffer " + cellTowerStr);
    }

    private void appendTelephonyInformation() {
        try {
            Log.d(TAG, "appendTelephonyInformation");
            getTelephonyInformation();
            if (BaseActivity.location.length() < 1) {
                BaseActivity.location = BaseActivity.location.concat(cellTowerStr);
            } else {
                if (!BaseActivity.location.contains(cellTowerStr)) {
                    char ch = BaseActivity.location.charAt(BaseActivity.location.length() - 1);
                    if (ch != ',' && ch != ';')
                        BaseActivity.location = BaseActivity.location.concat("," + cellTowerStr + ";");
                    else
                        BaseActivity.location = BaseActivity.location.concat(cellTowerStr + ";");
                }
            }
        } catch (Exception exception) {
            log("problem appending cellTowerStr to location " + exception);
        }
    }

    private int dbm(int asu) {
        return -113 + 2 * asu;
    }

    public void onSignalStrengthsChanged(SignalStrength signalStrength) {
        long now = System.currentTimeMillis();
        if (now - lastSignalUpdate > 300000) {
            lastSignalUpdate = now;
            if (previousDBM == 0) {
                Log.d(TAG, "onSignalStrengthsChanged signalStrength is  " + signalStrength.toString());
                Log.d(TAG, "gsmdbm (asu) =" + signalStrength.getGsmSignalStrength() + " " +
                        "gsmdbm (dbm - calculated) =" + dbm(signalStrength.getGsmSignalStrength()));
                previousDBM = dbm(signalStrength.getGsmSignalStrength());
            } else {
                int newDBM = dbm(signalStrength.getGsmSignalStrength());
                if (previousDBM != newDBM) {
                    Log.d(TAG, "onSignalStrengthsChanged signalStrength is  " + signalStrength.toString());
                    Log.d(TAG, "gsmdbm (asu) =" + signalStrength.getGsmSignalStrength() + " " +
                            "gsmdbm (dbm - calculated) =" + dbm(signalStrength.getGsmSignalStrength()));
                    previousDBM = newDBM;
                }
            }
        }
    }

    public void onDataConnectionStateChanged(int state, int networkType) {
        log("onDataConnectionStateChanged state = " + state + " networkType = " + networkType);
        if (state == TelephonyManager.DATA_CONNECTED) {
            Log.d(TAG, "data connected");
        }
        if (state == TelephonyManager.DATA_CONNECTING) {
            Log.d(TAG, "data connecting");
        }
        if (state == TelephonyManager.DATA_DISCONNECTED) {
            Log.d(TAG, "data disconnected");
        }
        if (state == TelephonyManager.DATA_SUSPENDED) {
            Log.d(TAG, "data suspended");
        }
        if (state == TelephonyManager.DATA_ACTIVITY_DORMANT) {
            Log.d(TAG, "data dormant");
        }
    }

    public void onCellInfoChanged(List<CellInfo> cellInfo) {
        Log.d(TAG, "==========>onCellInfoChanged: " + cellInfo);
        if (cellInfo != null) {
            for (int i = 0; i < cellInfo.size(); i++) {
                Log.d(TAG, "i=" + i + " class type is " + cellInfo.get(i).getClass().getName());
                log("i=" + i + " " + cellInfo.get(i).toString());

                if (!cellInfo.get(i).isRegistered()) {
                    log("not registered on this tower - ignoring");
                    continue;
                }
                if (cellInfo.get(i) instanceof CellInfoWcdma) {
                    Log.d(TAG, "wcdma ");
                    CellInfoWcdma cellInfoWcdma = (CellInfoWcdma) cellInfo.get(i);
                    Log.d(TAG, "wcdma " + cellInfoWcdma.toString());
                    Log.d(TAG, "wcdma identity " + cellInfoWcdma.getCellIdentity().toString());
                    Log.d(TAG, "wcdma signal strength " + cellInfoWcdma.getCellSignalStrength().toString());
                    Log.d(TAG, "wcdma signal strength dbm " + cellInfoWcdma.getCellSignalStrength().getDbm());
                    Log.d(TAG, "wcdma signal strength asu " + cellInfoWcdma.getCellSignalStrength().getAsuLevel());
                    savedCellInfo = cellInfo.get(i);

                } else if (cellInfo.get(i) instanceof CellInfoCdma) {
                    Log.d(TAG, "Cdma ");
                    CellInfoCdma cellInfoCdma = (CellInfoCdma) cellInfo.get(i);
                    Log.d(TAG, "cdma " + cellInfoCdma.toString());
                    Log.d(TAG, "cdma identity " + cellInfoCdma.getCellIdentity().toString());
                    Log.d(TAG, "cdma signal strength " + cellInfoCdma.getCellSignalStrength().toString());
                    Log.d(TAG, "cdma signal strength dbm " + cellInfoCdma.getCellSignalStrength().getCdmaDbm());
                    Log.d(TAG, "cdma signal strength asu " + cellInfoCdma.getCellSignalStrength().getAsuLevel());
                    savedCellInfo = cellInfo.get(i);

                } else if (cellInfo.get(i) instanceof CellInfoLte) {
                    Log.d(TAG, "lte ");
                    CellInfoLte cellInfoLte = (CellInfoLte) cellInfo.get(i);
                    Log.d(TAG, "lte " + cellInfoLte.toString());
                    Log.d(TAG, "lte identity " + cellInfoLte.getCellIdentity().toString());
                    Log.d(TAG, "lte signal strength " + cellInfoLte.getCellSignalStrength().toString());
                    Log.d(TAG, "lte signal strength dbm " + cellInfoLte.getCellSignalStrength().getDbm());
                    Log.d(TAG, "lte signal strength asu " + cellInfoLte.getCellSignalStrength().getAsuLevel());
                    savedCellInfo = cellInfo.get(i);

                } else if (cellInfo.get(i) instanceof CellInfoGsm) {
                    Log.d(TAG, "gsm ");
                    CellInfoGsm cellInfoGsm = (CellInfoGsm) cellInfo.get(i);
                    Log.d(TAG, "gsm " + cellInfoGsm.toString());
                    Log.d(TAG, "gsm identity " + cellInfoGsm.getCellIdentity().toString());
                    Log.d(TAG, "gsm signal strength " + cellInfoGsm.getCellSignalStrength().toString());
                    Log.d(TAG, "gsm signal strength dbm " + cellInfoGsm.getCellSignalStrength().getDbm());
                    Log.d(TAG, "gsm signal strength asu " + cellInfoGsm.getCellSignalStrength().getAsuLevel());
                    savedCellInfo = cellInfo.get(i);
                }
            }
        }
    }

}
