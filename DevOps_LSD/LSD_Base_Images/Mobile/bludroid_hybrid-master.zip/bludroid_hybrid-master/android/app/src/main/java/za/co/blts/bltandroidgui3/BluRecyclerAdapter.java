package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.view.MotionEventCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponseSupplierMessage;
import za.co.blts.bltandroidgui3.blt_draggable.ItemTouchAdapter;
import za.co.blts.bltandroidgui3.blt_draggable.ItemTouchViewHolder;
import za.co.blts.bltandroidgui3.blt_draggable.OnStartDragListener;
import za.co.blts.bltandroidgui3.cardviews.CardViewBillPayment;
import za.co.blts.bltandroidgui3.cardviews.CardViewEasyHealth;
import za.co.blts.bltandroidgui3.cardviews.CardViewElectricity;
import za.co.blts.bltandroidgui3.cardviews.CardViewOTT;
import za.co.blts.bltandroidgui3.cardviews.CardviewAdvinne;
import za.co.blts.bltandroidgui3.cardviews.CardviewAfricaPin;
import za.co.blts.bltandroidgui3.cardviews.CardviewAxxess;
import za.co.blts.bltandroidgui3.cardviews.CardviewBetFlash;
import za.co.blts.bltandroidgui3.cardviews.CardviewBluVoucher;
import za.co.blts.bltandroidgui3.cardviews.CardviewCallAll;
import za.co.blts.bltandroidgui3.cardviews.CardviewConnect;
import za.co.blts.bltandroidgui3.cardviews.CardviewDabba;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.cardviews.CardviewDeezer;
import za.co.blts.bltandroidgui3.cardviews.CardviewFNBConnect;
import za.co.blts.bltandroidgui3.cardviews.CardviewGooglePlay;
import za.co.blts.bltandroidgui3.cardviews.CardviewHollywoodBets;
import za.co.blts.bltandroidgui3.cardviews.CardviewLottoStar;
import za.co.blts.bltandroidgui3.cardviews.CardviewLucky365;
import za.co.blts.bltandroidgui3.cardviews.CardviewLycaMobile;
import za.co.blts.bltandroidgui3.cardviews.CardviewMyAir;
import za.co.blts.bltandroidgui3.cardviews.CardviewNeotel;
import za.co.blts.bltandroidgui3.cardviews.CardviewNetflix;
import za.co.blts.bltandroidgui3.cardviews.CardviewPlanetGames;
import za.co.blts.bltandroidgui3.cardviews.CardviewPlaystation;
import za.co.blts.bltandroidgui3.cardviews.CardviewRingas;
import za.co.blts.bltandroidgui3.cardviews.CardviewShowmax;
import za.co.blts.bltandroidgui3.cardviews.CardviewSpotify;
import za.co.blts.bltandroidgui3.cardviews.CardviewStarSat;
import za.co.blts.bltandroidgui3.cardviews.CardviewSteam;
import za.co.blts.bltandroidgui3.cardviews.CardviewSupabets;
import za.co.blts.bltandroidgui3.cardviews.CardviewTelkomWorldCard;
import za.co.blts.bltandroidgui3.cardviews.CardviewTheUnlimited;
import za.co.blts.bltandroidgui3.cardviews.CardviewTicketProCategory;
import za.co.blts.bltandroidgui3.cardviews.CardviewUber;
import za.co.blts.bltandroidgui3.cardviews.CardviewUberEats;
import za.co.blts.bltandroidgui3.cardviews.CardviewVirgin;
import za.co.blts.bltandroidgui3.cardviews.CardviewVoucherMenu;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidChatForChangeConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessBundleConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessTopupAnyAmountConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessTopupConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidUniversalElectricityDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidVoucherPurchaseConfirmationDialog;

/**
 * Created by warrenm on 2016/06/28.
 */
public class BluRecyclerAdapter extends RecyclerView.Adapter<BluRecyclerAdapter.BluViewHolder>

        implements ItemTouchAdapter {

    private final String TAG = this.getClass().getSimpleName();

    private final OnStartDragListener dragStartListener;

    private List<CardviewDataObject> data;
    private List<CardviewDataObject> filteredData;
    private WeakReference<BaseActivity> baseActivityWeakReference;
    private BaseFragment baseFragment = null;

    private boolean isFilterActive = false;
    private Fragment currentFragment = null;

    private String stockIdHolder = null;

    public BluRecyclerAdapter(BaseActivity context, List<CardviewDataObject> data) {
        this.data = data;
        Log.d(TAG, "context is of type " + context.getClass().getName());
        this.baseActivityWeakReference = new WeakReference<>(context);

        this.dragStartListener = null;
    }

    public BluRecyclerAdapter(BaseFragment baseFragment, List<CardviewDataObject> data) {
        this.data = data;
        Log.d(TAG, "context is of type " + baseFragment.getClass().getName());
        this.baseFragment = baseFragment;
        this.baseActivityWeakReference = new WeakReference<>(baseFragment.getBaseActivity());
        this.dragStartListener = null;
    }

    public BluRecyclerAdapter(BaseFragment baseFragment, List<CardviewDataObject> data, OnStartDragListener dragStartListener) {
        this.data = data;
        Log.d(TAG, "context is of type " + baseFragment.getClass().getName());
        this.baseFragment = baseFragment;
        this.baseActivityWeakReference = new WeakReference<>(baseFragment.getBaseActivity());

        this.dragStartListener = dragStartListener;
    }

    public String getStockId() {
        return stockIdHolder;
    }

    public void setStockId(String stockId) {
        this.stockIdHolder = stockId;
    }

    private FragmentManager fm;

    @Override
    public BluViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.d("Optimize", "BluRecyclerAdapter onCreateViewHolder");
        View inflatedView = LayoutInflater.from(parent.getContext()).inflate(R.layout.blu_card, parent, false);
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            fm = baseActivity.getSupportFragmentManager();
            currentFragment = fm.findFragmentById(R.id.content_frame);

            if (currentFragment instanceof FragmentTicketProCategories) {
                inflatedView = LayoutInflater.from(parent.getContext()).inflate(R.layout.bill_card, parent, false);
            }
        }
        return new BluViewHolder(inflatedView);
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onBindViewHolder(final BluViewHolder holder, int position) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {

            boolean hideText = false;
            CardviewDataObject current;
            if (isFilterActive) {
                current = filteredData.get(position);
            } else {
                current = data.get(position);
            }
            Log.d("kuijkencard", current.toString());

            if (holder.card != null) {
                holder.card.setBackgroundColor(current.getCardColor());

                if (current instanceof CardviewNeotel) {
                    holder.card.setBackgroundResource(R.drawable.neotel_card_withborder);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.neotel_border));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.neotel_border));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.neotel_border));
                } else if (current instanceof CardviewVirgin) {
                    holder.card.setBackgroundResource(R.drawable.virgin_card_withborder);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewAxxess) {
                    holder.card.setBackgroundResource(R.drawable.axxess_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewHollywoodBets) {
                    holder.card.setBackgroundResource(R.drawable.hollywoodbets_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                } else if (current instanceof CardviewDeezer) {
                    holder.card.setBackgroundResource(R.drawable.deezer_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                } else if (current instanceof CardviewGooglePlay) {
                    holder.card.setBackgroundResource(R.drawable.google_play_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.google_play_text));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.google_play_text));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.google_play_text));
                } else if (current instanceof CardviewNetflix) {
                    holder.card.setBackgroundResource(R.drawable.netflix_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.netflix_text));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.netflix_text));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.netflix_text));
                } else if (current instanceof CardviewPlanetGames) {
                    holder.card.setBackgroundResource(R.drawable.planet_games_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.planet_games_text));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.planet_games_text));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.planet_games_text));
                } else if (current instanceof CardviewPlaystation) {
                    holder.card.setBackgroundResource(R.drawable.playstation_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.playstation_text));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.playstation_text));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.playstation_text));
                } else if (current instanceof CardviewShowmax) {
                    holder.card.setBackgroundResource(R.drawable.showmax_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.showmax_text));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.showmax_text));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.showmax_text));
                } else if (current instanceof CardviewSpotify) {
                    holder.card.setBackgroundResource(R.drawable.spotify_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.spotify_text));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.spotify_text));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.spotify_text));
                } else if (current instanceof CardviewSteam) {
                    holder.card.setBackgroundResource(R.drawable.steam_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.steam_text));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.steam_text));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.steam_text));
                } else if (current instanceof CardviewUber) {
                    holder.card.setBackgroundResource(R.drawable.uber_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.uber_text));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.uber_text));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.uber_text));
                } else if (current instanceof CardviewUberEats) {
                    holder.card.setBackgroundResource(R.drawable.uber_eats_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.uber_eats_text));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.uber_eats_text));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.uber_eats_text));
                } else if (current instanceof CardviewStarSat) {
                    holder.card.setBackgroundResource(R.drawable.starsat_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.starsat_border));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.starsat_border));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.starsat_border));
                } else if (current instanceof CardviewDabba) {
                    holder.card.setBackgroundResource(R.drawable.dabba_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewSupabets) {
                    holder.card.setBackgroundResource(R.drawable.supabets_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewLottoStar) {
                    holder.card.setBackgroundResource(R.drawable.lottostar_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardViewOTT) {
                    holder.card.setBackgroundResource(R.drawable.ott_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardViewEasyHealth) {
                    holder.card.setBackgroundResource(R.drawable.discovery_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewAfricaPin) {
                    holder.card.setBackgroundResource(R.drawable.africapin_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.africapin_border));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.africapin_border));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.africapin_border));
                } else if (current instanceof CardviewBetFlash) {
                    holder.card.setBackgroundResource(R.drawable.betflash_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.betflash_border));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.betflash_border));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.betflash_border));
                } else if (current instanceof CardviewTelkomWorldCard) {
                    holder.card.setBackgroundResource(R.drawable.telkom_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                }

                // C4C
                else if (current instanceof CardviewAdvinne) {
                    holder.card.setBackgroundResource(R.drawable.advinne_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewTheUnlimited) {
                    holder.card.setBackgroundResource(R.drawable.theunlimited_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewMyAir) {
                    holder.card.setBackgroundResource(R.drawable.myair_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewFNBConnect) {
                    holder.card.setBackgroundResource(R.drawable.fnbconnect_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewLycaMobile) {
                    holder.card.setBackgroundResource(R.drawable.lycamobile_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewRingas) {
                    holder.card.setBackgroundResource(R.drawable.ringas_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewCallAll) {
                    holder.card.setBackgroundResource(R.drawable.callall_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewBluVoucher) {
                    holder.card.setBackgroundResource(R.drawable.bluvoucher_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.bluvoucher_text));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.bluvoucher_text));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.bluvoucher_text));
                } else if (current instanceof CardviewLucky365) {
                    holder.card.setBackgroundResource(R.drawable.lucky365_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewConnect) {
                    holder.card.setBackgroundResource(R.drawable.connect_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (current instanceof CardviewTicketProCategory) {
                    holder.card.setBackgroundResource(R.drawable.ticketpro_category_card);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.darkBlue));
                    holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.darkBlue));
                } else if (current instanceof CardViewElectricity) {
                    if (current.getCardDesc().contains("Eskom")) {
                        holder.icon.setColorFilter(null);
                        holder.card.setBackgroundColor(baseActivity.getResources().getColor(R.color.eskom));
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                        holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.white));
                        holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    } else {
                        if (current.getIconId() == R.drawable.default_electricity) {
                            holder.icon.setColorFilter(ContextCompat.getColor(baseActivity, R.color.colorPrimary));
                            holder.card.setBackgroundResource(R.drawable.electricity_card_withborder);
                            holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                            holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                            holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                        } else {
                            holder.icon.setColorFilter(null);
                            holder.card.setBackgroundResource(R.drawable.electricity_card_withborder);
                            holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                            holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                            holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                        }
                    }
                } else if (current instanceof CardViewBillPayment) {

                    if (currentFragment instanceof FragmentTransact
                            || currentFragment instanceof FragmentTransactAccounts
                            || currentFragment instanceof FragmentTransactTrafficFines
                            || currentFragment instanceof FragmentSearch) {
                        holder.provider.setVisibility(View.VISIBLE);
                    } else {
                        holder.provider.setVisibility(View.GONE);
                    }


                    if (current.getIconId() == (R.drawable.dstv)) {
                        holder.icon.setColorFilter(null);
                        holder.card.setBackgroundResource(R.drawable.dstv_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                        holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.white));
                        holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                        holder.provider.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    } else if (current.getIconId() != (R.drawable.default_transact)) {
                        holder.icon.setColorFilter(null);
                        holder.card.setBackgroundResource(R.drawable.electricity_card_withborder);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                        holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                        holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                        holder.provider.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                    } else {
                        holder.icon.setColorFilter(ContextCompat.getColor(baseActivity, R.color.colorPrimary));
                        holder.card.setBackgroundResource(R.drawable.electricity_card_withborder);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                        holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                        holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                        holder.provider.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimary));
                    }

                } else {
                    //else bus
                    if (current.getCardDesc().equalsIgnoreCase("bus")) {
                        holder.card.setBackgroundResource(R.drawable.longhaulbus_menu_card);
                        hideText = true;
                    } else if (current.getCardDesc().equalsIgnoreCase("nfc bus")) {
                        holder.card.setBackgroundResource(R.drawable.nfcbus_menu_card);
                        hideText = true;
                    } else {
                        if (holder.icon != null) {
                            holder.icon.setColorFilter(null);
                        }
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimaryText));
                        if (holder.textValue != null) {
                            holder.textValue.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimaryText));
                            holder.voucherTypeDesc.setTextColor(baseActivity.getResources().getColor(R.color.colorPrimaryText));
                        }
                    }
                }
            }

            if (holder.icon != null) {
                holder.icon.setImageResource(current.getIconId());
                holder.icon.setTag(current.getTag());
                holder.icon.setVisibility(View.VISIBLE); //visible by default
            }
            if (holder.textDesc != null) {
                holder.textDesc.setText(current.getCardDesc());

                if (holder.textDesc.getText().toString().isEmpty()) {
                    holder.textDesc.setVisibility(View.GONE);
                } else {
                    if (!hideText)
                        holder.textDesc.setVisibility(View.VISIBLE); // hide text for bus services
                    else
                        holder.textDesc.setVisibility(View.GONE); // hide text for bus services
                }
            }
            if (holder.textValue != null) {
                holder.textValue.setText(current.getCardValue());
            }

            if (holder.voucherTypeDesc != null) {
                holder.voucherTypeDesc.setText(current.getVoucherTypeDesc());
            }

            if (holder.provider != null) {
                holder.provider.setText(current.getProvider());
            }

            if (holder.textmunicRealName != null) {
                holder.textmunicRealName.setText(current.getTag());
            }
            holder.setTag(current.getTag());
            holder.setStockId(current.getStockId());
            holder.setSupplierCode(current.getSupplierCode());
            holder.setTopupName(current.getTopupName());
            holder.setVoucherType(current.getVoucherType());
            holder.setDefaultCard(current.getDefaultCard());
            holder.setHasAirtimePlus(current.getHasAirtimePlus());
            holder.setMVNO(current.isMVNO());

            //Mod to gui for  7" % 8" touchscreen devices
            if (baseActivity.getResources().getDisplayMetrics().densityDpi == DisplayMetrics.DENSITY_MEDIUM) {
                if (holder.textDesc != null) {
                    holder.textDesc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                }
                if (holder.textValue != null) {
                    holder.textValue.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
                }
                if (holder.voucherTypeDesc != null) {
                    holder.voucherTypeDesc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
                }

            } else {
                if (holder.voucherTypeDesc != null) {
                    holder.voucherTypeDesc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                }
            }

            if (dragStartListener != null) {
                holder.card.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        if (MotionEventCompat.getActionMasked(motionEvent) == MotionEvent.ACTION_DOWN) {
                            Log.d(TAG, ": onStartDrag()");
                            dragStartListener.onStartDrag(holder);
                        }
                        return false;
                    }
                });
            }


            if (currentFragment instanceof FragmentFavourites || currentFragment instanceof FragmentConfirmConfigFavourites || currentFragment instanceof FragmentSearch) {
                if (holder.voucherTypeDesc != null) {
                    holder.voucherTypeDesc.setVisibility(View.VISIBLE);
                }
            }

            /*
             * Style other voucher menu cards on the favourites screen
             * */
            if (holder.textDesc.getText().toString().equalsIgnoreCase("axxess")) {
                holder.card.setBackgroundResource(R.drawable.axxess_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("top tv")) {
                holder.card.setBackgroundResource(R.drawable.starsat_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("dabba")) {
                holder.card.setBackgroundResource(R.drawable.dabba_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("supabets")) {
                holder.card.setBackgroundResource(R.drawable.supabets_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("Discovery Prepaid Health")) {
                holder.card.setBackgroundResource(R.drawable.discovery_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("lottostar")) {
                holder.card.setBackgroundResource(R.drawable.lottostar_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("hollywood bets")) {
                holder.card.setBackgroundResource(R.drawable.hollywoodbets_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("deezer")) {
                holder.card.setBackgroundResource(R.drawable.deezer_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("google play")) {
                holder.card.setBackgroundResource(R.drawable.google_play_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("netflix")) {
                holder.card.setBackgroundResource(R.drawable.netflix_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("planet games")) {
                holder.card.setBackgroundResource(R.drawable.planet_games_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("playstation")) {
                holder.card.setBackgroundResource(R.drawable.playstation_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("showmax")) {
                holder.card.setBackgroundResource(R.drawable.showmax_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("spotify")) {
                holder.card.setBackgroundResource(R.drawable.spotify_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("steam")) {
                holder.card.setBackgroundResource(R.drawable.steam_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("uber")) {
                holder.card.setBackgroundResource(R.drawable.uber_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("uber eats")) {
                holder.card.setBackgroundResource(R.drawable.uber_eats_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("betflash")) {
                holder.card.setBackgroundResource(R.drawable.betflash_menu_card);
                holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                holder.icon.setVisibility(View.GONE);
                holder.textDesc.setVisibility(View.INVISIBLE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("africapin")) {
                holder.card.setBackgroundResource(R.drawable.africapin_menu_card);
                holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                holder.icon.setVisibility(View.GONE);
                holder.textDesc.setVisibility(View.INVISIBLE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("Ithuba")) {
                holder.card.setBackgroundResource(R.drawable.ithuba_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("putco")) {
                holder.card.setBackgroundResource(R.drawable.putco_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("events")) {
                holder.card.setBackgroundResource(R.drawable.events_menu_card);
                holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.textDesc.getText().toString().equalsIgnoreCase("tickets")) {
                holder.card.setBackgroundResource(R.drawable.tickets_menu_card);
                // holder.textDesc.setVisibility(View.INVISIBLE);
                holder.icon.setVisibility(View.GONE);
            } else if (holder.voucherTypeDesc.getText().toString().equalsIgnoreCase("LongHaulBuses")) {
                holder.voucherTypeDesc.setVisibility(View.GONE);
            } else if (current instanceof CardviewVoucherMenu) {
                //<--------------chat for change providers------------!>
                //we have included a hardcoded c4c string to distinguish between the vouchers hence the contains
                if (holder.textDesc.getText().toString().toLowerCase().contains("advinne")) {
                    holder.card.setBackgroundResource(R.drawable.advinne_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                } else if (holder.textDesc.getText().toString().toLowerCase().contains("theunlimited")) {
                    holder.card.setBackgroundResource(R.drawable.theunlimited_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                } else if (holder.textDesc.getText().toString().toLowerCase().contains("fnbconnect")) {
                    holder.card.setBackgroundResource(R.drawable.fnbconnect_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                } else if (holder.textDesc.getText().toString().toLowerCase().contains("myair")) {
                    holder.card.setBackgroundResource(R.drawable.myair_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                } else if (holder.textDesc.getText().toString().toLowerCase().contains("lycamobile")) {
                    holder.card.setBackgroundResource(R.drawable.lycamobile_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                } else if (holder.textDesc.getText().toString().toLowerCase().contains("ott")) {
                    holder.card.setBackgroundResource(R.drawable.ott_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                } else if (holder.textDesc.getText().toString().toLowerCase().contains("ringas")) {
                    holder.card.setBackgroundResource(R.drawable.ringas_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                } else if (holder.textDesc.getText().toString().toLowerCase().contains("callall")) {
                    holder.card.setBackgroundResource(R.drawable.callall_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                } else if (holder.textDesc.getText().toString().toLowerCase().contains("lucky365")) {
                    holder.card.setBackgroundResource(R.drawable.lucky365_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                } else if (holder.textDesc.getText().toString().toLowerCase().startsWith("connect")) {
                    holder.card.setBackgroundResource(R.drawable.connect_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                } else if (holder.textDesc.getText().toString().toLowerCase().startsWith("bluvoucher")) {
                    holder.card.setBackgroundResource(R.drawable.bluvoucher_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);

                } else if (holder.provider.getText().toString().toLowerCase().startsWith("cell")) {
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    holder.provider.setTextColor(baseActivity.getResources().getColor(R.color.white));
                } else if (holder.provider.getText().toString().toLowerCase().startsWith("mtn")) {
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    holder.provider.setTextColor(baseActivity.getResources().getColor(R.color.white));
                } else if (holder.provider.getText().toString().toLowerCase().startsWith("neotel")) {
                    holder.card.setBackgroundResource(R.drawable.neotel_card_withborder);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.neotel_border));
                    holder.provider.setTextColor(baseActivity.getResources().getColor(R.color.neotel_border));
                } else if (holder.provider.getText().toString().toLowerCase().startsWith("telkom mobile")) {
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    holder.provider.setTextColor(baseActivity.getResources().getColor(R.color.white));
                } else if (holder.provider.getText().toString().toLowerCase().startsWith("virgin")) {
                    holder.card.setBackgroundResource(R.drawable.virgin_card_withborder);
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    holder.provider.setTextColor(baseActivity.getResources().getColor(R.color.black));
                } else if (holder.provider.getText().toString().toLowerCase().startsWith("vodacom")) {
                    holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    holder.provider.setTextColor(baseActivity.getResources().getColor(R.color.white));

                } else if (holder.textDesc.getText().toString().toLowerCase().equals("telkom")) {
                    holder.card.setBackgroundResource(R.drawable.telkom_menu_card);
                    holder.textDesc.setVisibility(View.INVISIBLE);
                    holder.icon.setVisibility(View.GONE);
                }

                if (!holder.provider.getText().toString().isEmpty()) {
                    holder.provider.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
        if (isFilterActive) {
            Collections.swap(filteredData, fromPosition, toPosition);
        } else {
            moveItem(fromPosition, toPosition);
        }
        notifyItemMoved(fromPosition, toPosition);
    }

    private void moveItem(int fromPosition, int toPosition) {
        if (fromPosition < toPosition) {
            for (int i = fromPosition; i < toPosition; i++) {
                Collections.swap(data, i, i + 1);
            }
        } else {
            for (int i = fromPosition; i > toPosition; i--) {
                Collections.swap(data, i, i - 1);
            }
        }
    }

    @Override
    public int getItemCount() {
        if (isFilterActive) {
            return this.filteredData.size();
        } else {
            return this.data.size();
        }
    }

    class BluViewHolder extends RecyclerView.ViewHolder implements ItemTouchViewHolder {

        ImageView icon;
        TextView textDesc;
        TextView textmunicRealName;
        TextView textValue;
        TextView voucherTypeDesc;
        TextView provider;
        CardView card;
        String tag = "";
        //StockId used as productCode too...
        String stockId = "";
        String supplierCode = "";
        String topupName = "";
        String voucherType = "";
        String defaultCard = "";
        boolean hasAirtimePlus;
        boolean isMVNO = false;
        BluDroidAlertDialog alert = null;

        @Override
        public String toString() {
            return "BluViewHolder{" +
                    "textDesc=" + textDesc.getText() +
                    ", textmunicRealName=" + textmunicRealName.getText() +
                    ", voucherTypeDesc=" + voucherTypeDesc.getText() +
                    ", provider=" + provider.getText() +
                    ", tag='" + tag + '\'' +
                    ", stockId='" + stockId + '\'' +
                    ", supplierCode='" + supplierCode + '\'' +
                    ", topupName='" + topupName + '\'' +
                    ", voucherType='" + voucherType + '\'' +
                    ", defaultCard='" + defaultCard + '\'' +
                    '}';
        }

        BluViewHolder(final View itemView) {
            super(itemView);
            final Bundle bundle = new Bundle();
            icon = itemView.findViewById(R.id.cardIcon);
            textDesc = itemView.findViewById(R.id.cardDesc);
            textmunicRealName = itemView.findViewById(R.id.cardRealName);
            textValue = itemView.findViewById(R.id.cardValue);
            voucherTypeDesc = itemView.findViewById(R.id.voucherTypeDesc);
            provider = itemView.findViewById(R.id.provider);

            if (currentFragment instanceof FragmentTicketProCategories) {
                card = itemView.findViewById(R.id.bill_card);
            } else {
                card = itemView.findViewById(R.id.blu_card);
            }

            final BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {

                itemView.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View view) {
                                                    baseActivity.resetTimer();
                                                    baseActivity.isBillPaymentScreen = false;
                                                    baseActivity.hideKeyboard();

                                                    if (currentFragment instanceof FragmentConfirmConfigFavourites) {
                                                        //do nothing
                                                    } else if (currentFragment instanceof FragmentTicketProCategories) {

                                                        baseActivity.ticketProCategoryId = voucherTypeDesc.getText().toString();

                                                        Fragment fragment = new FragmentTicketProEvents();
                                                        String fName = "FragmentTicketProEvents";

                                                        Bundle bundle = new Bundle();
                                                        bundle.putString("filteredCriteria", voucherTypeDesc.getText().toString());
                                                        fragment.setArguments(bundle);

                                                        baseActivity.baseFm.beginTransaction().replace(R.id.content_frame, fragment, fName).commit();

                                                    } else {
                                                        BaseActivity.name = tag;

                                                        baseActivity.voucherType = voucherTypeDesc.getText().toString();

                                                        Log.d(TAG, "create confirm purchase dialog");
                                                        Log.d(TAG, "clicked textDesc=" + textDesc.getText() + " textValue=" + textValue.getText() + " tag=" + tag.toLowerCase() + " stockId=" + stockId + " voucherType=" + voucherType);

                                                        if (voucherType != null && voucherType.equalsIgnoreCase("voucher")) {

                                                            //to decide which logo to print on the slip
                                                            BaseActivity.gettingMvnoVoucher = isMVNO;

                                                            if (textValue.getText().toString().equals(baseActivity.getResources().getString(R.string.anyAmount))) {
                                                                Log.d(TAG, "this is chat for change");
                                                                baseActivity.createChatForChangeConfirmation(baseFragment);
                                                                if (baseActivity.confirmation instanceof BluDroidChatForChangeConfirmationDialog) {
                                                                    Log.v("c4cMinMax", "tag:" + tag);
                                                                    BluDroidChatForChangeConfirmationDialog dialog = (BluDroidChatForChangeConfirmationDialog) baseActivity.confirmation;

                                                                    Chat4ChangeResponseSupplierMessage supplierMessage = baseActivity.getC4CSupplier(tag);
                                                                    Log.v("c4cMinMax", "supplierMessage:" + supplierMessage);
                                                                    if (supplierMessage != null) {
                                                                        try {
                                                                            float min = Float.parseFloat(supplierMessage.getMinAmount());
                                                                            float max = Float.parseFloat(supplierMessage.getMaxAmount());
                                                                            Log.v("c4cMinMax", "min:" + min + " max:" + max);
                                                                            dialog.setMinMaxValues(min, max);
                                                                        } catch (Exception nfe) {
                                                                            BaseActivity.logger.error(nfe.getLocalizedMessage());
                                                                        }
                                                                    }

                                                                    dialog.setIcon(getDrawableResource(tag, icon, defaultCard));
                                                                    dialog.getIcon().setBackgroundColor(getColorResource(tag));
                                                                    dialog.setSupplierCode(supplierCode);
                                                                }
                                                            } else {
                                                                //
                                                                // stockIdHolder keeps the stockId so that the VoucherRecycler
                                                                // can get it
                                                                //

                                                                stockIdHolder = stockId;

                                                                baseActivity.createVoucherPurchaseConfirmation(baseFragment); //, textValue, textDesc, icon);
                                                                Log.d(TAG, "icon is of type " + icon.getClass().getName());
                                                                if (baseActivity.confirmation instanceof BluDroidVoucherPurchaseConfirmationDialog) {
                                                                    BluDroidVoucherPurchaseConfirmationDialog dialog = (BluDroidVoucherPurchaseConfirmationDialog) baseActivity.confirmation;
                                                                    dialog.setMessage(textDesc.getText().toString());
                                                                    dialog.setAmount(textValue.getText().toString());
                                                                    dialog.setSupplierCode(supplierCode);
                                                                    dialog.setIcon(getDrawableResource(tag, icon, defaultCard));
                                                                    dialog.getIcon().setBackgroundColor(getColorResource(tag));
                                                                    dialog.setMVNO(isMVNO);

                                                                    Log.d(TAG, "HideView: " + BluViewHolder.this.toString());

                                                                    Log.d(TAG, "HideView: " + provider.getText().toString());

                                                                    if (isMVNO()
                                                                            || tag.equalsIgnoreCase("Uber")
                                                                            || tag.equalsIgnoreCase("Uber Eats")
                                                                            || tag.equalsIgnoreCase("Netflix")) {
                                                                        dialog.hideView(R.id.multipleVoucherLayout2);
                                                                    }

                                                                    if (baseActivity.isAirtimePlusAllowed && hasAirtimePlus) {
                                                                        dialog.showAirtimePlus();
                                                                    } else {
                                                                        dialog.hideAirtimePlus();
                                                                    }


                                                                } else
                                                                    Toast.makeText(baseActivity, textDesc.getText(), Toast.LENGTH_SHORT).show();
                                                            }
                                                        } else if (voucherType != null && voucherType.equalsIgnoreCase("topup")) {
                                                            Log.d(TAG, "voucher type is topup");

                                                            if (textValue.getText().toString().equals(baseActivity.getResources().getString(R.string.anyAmount))) {
                                                                baseActivity.createPinlessTopupAnyAmountConfirmationDialog(baseFragment);
                                                                if (baseActivity.confirmation instanceof BluDroidPinlessTopupAnyAmountConfirmationDialog) {

                                                                    BluDroidPinlessTopupAnyAmountConfirmationDialog dialog = (BluDroidPinlessTopupAnyAmountConfirmationDialog) baseActivity.confirmation;

                                                                    dialog.setMessage(textDesc.getText().toString());
                                                                    dialog.setAmount(dialog.getAmount());
                                                                    dialog.setTopupName(topupName);
                                                                    dialog.setIcon(getDrawableResource(tag, icon, defaultCard));
                                                                    dialog.getIcon().setBackgroundColor(getColorResource(tag));

                                                                    if (baseActivity.isAirtimePlusAllowed && hasAirtimePlus) {
                                                                        dialog.showAirtimePlus();
                                                                    } else {
                                                                        dialog.hideAirtimePlus();
                                                                    }


                                                                }
                                                            } else {
                                                                baseActivity.createPinlessTopupConfirmation(baseFragment);
                                                                // if (textDesc.getText().toString().toLowerCase().contains("mb"))
                                                                if (baseActivity.confirmation instanceof BluDroidPinlessTopupConfirmationDialog) {
                                                                    BluDroidPinlessTopupConfirmationDialog dialog = (BluDroidPinlessTopupConfirmationDialog) baseActivity.confirmation;
                                                                    dialog.setMessage(textDesc.getText().toString());
                                                                    dialog.setAmount(textValue.getText().toString());
                                                                    dialog.setTopupName(topupName);
                                                                    dialog.setIcon(getDrawableResource(tag, icon, defaultCard));
                                                                    dialog.getIcon().setBackgroundColor(getColorResource(tag));

                                                                    if (baseActivity.isAirtimePlusAllowed && hasAirtimePlus) {
                                                                        dialog.showAirtimePlus();
                                                                    } else {
                                                                        dialog.hideAirtimePlus();
                                                                    }

                                                                }
                                                            }
                                                        } else if (voucherType != null && voucherType.equalsIgnoreCase("bundle")) {
                                                            Log.d(TAG, "need to process bundle");


                                                            if (textValue.getText().toString().equals(baseActivity.getResources().getString(R.string.anyAmount))) {

                                                                baseActivity.createPinlessTopupAnyAmountConfirmationDialog(baseFragment);
                                                                if (baseActivity.confirmation instanceof BluDroidPinlessTopupAnyAmountConfirmationDialog) {

                                                                    BluDroidPinlessTopupAnyAmountConfirmationDialog dialog = (BluDroidPinlessTopupAnyAmountConfirmationDialog) baseActivity.confirmation;

                                                                    dialog.setMessage(textDesc.getText().toString());
                                                                    dialog.setAmount(dialog.getAmount());
                                                                    dialog.setTopupName(topupName);
                                                                    dialog.setIcon(getDrawableResource(tag, icon, defaultCard));
                                                                    dialog.getIcon().setBackgroundColor(getColorResource(tag));


                                                                    if (baseActivity.isAirtimePlusAllowed && hasAirtimePlus) {
                                                                        dialog.showAirtimePlus();
                                                                    } else {
                                                                        dialog.hideAirtimePlus();
                                                                    }

                                                                    Log.d(TAG, "stockId = " + stockId);
                                                                }
                                                            } else {
                                                                baseActivity.createPinlessBundleConfirmation(baseFragment);
                                                                //
                                                                // stockIdHolder keeps the stockId so that the VoucherRecycler
                                                                // can get it
                                                                //
                                                                stockIdHolder = stockId;
                                                                if (baseActivity.confirmation instanceof BluDroidPinlessBundleConfirmationDialog) {
                                                                    BluDroidPinlessBundleConfirmationDialog dialog = (BluDroidPinlessBundleConfirmationDialog) baseActivity.confirmation;
                                                                    //
                                                                    // Warren here is where that print was done
                                                                    //
                                                                    Log.d(TAG, "textDesc " + textDesc.getText().toString());
                                                                    Log.d(TAG, "value " + textValue.getText().toString());
                                                                    dialog.setStockId(stockId);
                                                                    dialog.setMessage(textDesc.getText().toString());
                                                                    dialog.setAmount(textValue.getText().toString());
                                                                    dialog.setTopupName(topupName);
                                                                    dialog.setIcon(getDrawableResource(tag, icon, defaultCard));
                                                                    dialog.getIcon().setBackgroundColor(getColorResource(tag));

                                                                    if (baseActivity.isAirtimePlusAllowed && hasAirtimePlus) {
                                                                        dialog.showAirtimePlus();
                                                                    } else {
                                                                        dialog.hideAirtimePlus();
                                                                    }

                                                                    Log.d(TAG, "stockId = " + stockId);
                                                                }
                                                            }
                                                        } else if (voucherType != null && voucherType.equalsIgnoreCase("munics")) {


                                                            if (tag.trim().equalsIgnoreCase("fbe")) {

                                                                baseActivity.createFreeBasicElectricityDialog(baseFragment);
                                                            } else if (tag.toLowerCase().startsWith("eskom")) {
                                                                baseActivity.baseFm.beginTransaction().replace(R.id.content_frame, new FragmentEskomElectricity(), "FragmentEskomElectricity").commit();
                                                            } else {
                                                                baseActivity.createUniversalElectricityDialog(baseFragment);
                                                                if (baseActivity.confirmation instanceof BluDroidUniversalElectricityDialog) {
                                                                    BluDroidUniversalElectricityDialog dialog = (BluDroidUniversalElectricityDialog) baseActivity.confirmation;
                                                                    dialog.setMunicName(textmunicRealName.getText().toString());
                                                                    dialog.setHeading(textmunicRealName.getText().toString());
                                                                }
                                                            }
                                                        } else if (voucherType != null && voucherType.equalsIgnoreCase("eskomother")) {

                                                            if (textDesc.getText().toString().equalsIgnoreCase("update meter keys")) {
                                                                baseActivity.createUpdateEskomMeterKeysDialog(baseActivity);
                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("update meter cards")) {
                                                                baseActivity.createUpdateEskomMeterCardsDialog(baseActivity);
                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("engineering key codes")) {
                                                                baseActivity.createEskomEngineeringKeyCodesDialog(baseActivity);

                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("trial purchase")) {
                                                                baseActivity.createEskomTrialPurchaseDialog(baseActivity);
                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("token by other")) {
                                                                baseActivity.createEskomTokenByOtherDialog(baseActivity);
                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("redeem token")) {
                                                                baseActivity.isEncodingMagToken = true;
                                                                baseActivity.createEskomRedeemTokenDialog(baseActivity);
                                                            }

                                                        } else if (voucherType != null && voucherType.equals("Add")) {
                                                            baseActivity.getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, new FragmentConfigFavourites(), "FragmentFavourites").commit();
                                                        } else if (voucherType != null && voucherType.equals("bill_payment")) {

                                                            baseActivity.isBillPaymentScreen = true;
                                                            Map<String, String> map;

                                                            if (currentFragment instanceof FragmentFavourites) {
                                                                map = baseActivity.getBillPaymentMap(textDesc.getText().toString(), provider.getText().toString());
                                                            } else {
                                                                map = baseActivity.getBillPaymentMap(textDesc.getText().toString(), provider.getText().toString());
                                                            }

                                                            Bundle bundle = new Bundle();
                                                            Log.v(TAG, "B - logoId  : " + map.get("logoId"));
                                                            Log.v(TAG, "B - providerId  : " + map.get("providerId"));
                                                            Log.v(TAG, "B - productId   : " + map.get("productId"));
                                                            Log.v(TAG, "B - productName : " + map.get("productName"));
                                                            Log.v(TAG, "B - provider : " + tag);

                                                            Fragment fragment;

                                                            if (provider.getText().toString().contains("Blu Bill") && !provider.getText().toString().contains("Traffic")) {
                                                                fragment = new FragmentTransactBillPaymentBluBill();
                                                            } else if (provider.getText().toString().contains("Syntel") && !provider.getText().toString().contains("Traffic")) {
                                                                fragment = new FragmentTransactBillPaymentSyntell();
                                                            } else if (provider.getText().toString().contains("Pay@") && !provider.getText().toString().contains("Fine")) {
                                                                fragment = new FragmentTransactBillPaymentPayAt();
                                                            } else if (provider.getText().toString().contains("SAPO") && !provider.getText().toString().contains("Traffic")) {
                                                                fragment = new FragmentTransactBillPaymentSapo();
                                                                bundle.putString("additionalFields", map.get("additionalFields"));
                                                            } else if (provider.getText().toString().contains("Syntel") && provider.getText().toString().contains("Traffic")) {
                                                                fragment = new FragmentTransactTrafficFinesSyntell();
                                                            } else if (provider.getText().toString().contains("Pay@") && provider.getText().toString().contains("Fine")) {
                                                                fragment = new FragmentTransactTrafficFinesPayAt();
                                                            } else if (provider.getText().toString().contains("MerchantTransfer")) {
                                                                fragment = new FragmentTransactMerchantToMerchantTransfer();
                                                            } else {
                                                                fragment = new FragmentTransact();
                                                            }

                                                            bundle.putString("providerId", map.get("providerId"));
                                                            bundle.putString("productId", map.get("productId"));
                                                            bundle.putString("productName", map.get("productName"));
                                                            bundle.putString("logoId", map.get("logoId"));
                                                            fragment.setArguments(bundle);


                                                            //FragmentManager fm = baseActivity.getSupportFragmentManager();
                                                            FragmentTransaction ft = fm.beginTransaction();
                                                            ft.replace(R.id.content_frame, fragment);
                                                            ft.commit();

                                                        } else if (voucherType == null || voucherType.length() == 0 || voucherType.equalsIgnoreCase("longhaulbuses")) {
                                                            Fragment fragment = null;
                                                            String fName = "";
                                                            boolean goingToNfcBus = false;

                                                            if (textDesc.getText().toString().equalsIgnoreCase("Ithuba")) {
                                                                fragment = new FragmentIthubaMenu();
                                                                fName = "FragmentIthubaMenu";
                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("Putco")) {
                                                                fragment = new FragmentPutco();
                                                                fName = "FragmentPutco";
                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("events")) {
                                                                fragment = new FragmentTicketProCategories();
                                                                baseActivity.isEventsScreen = true;
                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("tickets")) {
                                                                fragment = new FragmentTickets();
                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("nfc bus")) {
                                                                goingToNfcBus = true;
                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("bus")) {
                                                                fragment = new FragmentCarmaSearchRoutesNew();
                                                                fName = "FragmentCarmaSearchRoutesNew";
                                                            } else if (textDesc.getText().toString().equalsIgnoreCase("MVNO")) {
                                                                fragment = new FragmentChatForChange();
                                                                fName = "FragmentChatForChange";
                                                            } else {
                                                                fragment = new FragmentVouchers();
                                                                fName = "FragmentVouchers";
                                                            }

                                                            if (goingToNfcBus) {
                                                                baseActivity.gotoNfcBusScreen();
                                                            } else {
                                                                //we have included a hardcoded c4c string to distinguish between the vouchers hence the contains
                                                                String filteredCriteria = textDesc.getText().toString().replace("C4C", "");
                                                                bundle.putString("filteredCriteria", filteredCriteria);
                                                                bundle.putString("providerName", provider.getText().toString());
                                                                fragment.setArguments(bundle);
                                                                Log.w(TAG, "setting filteredCriteria for FragmentSearch: " + filteredCriteria);

                                                                baseActivity.baseFm.beginTransaction().replace(R.id.content_frame, fragment, fName).commit();
                                                            }
                                                        }

                                                        Log.d(TAG, "Clicked voucher is " + textDesc.getText().toString() + "--" + topupName + "--" + tag + "--" + baseActivity.voucherType);

                                                        // Add Firebase Analytics Event to each product being viewed
                                                        // Add Analytics to where the user buys the product
                                                        Bundle bundle = new Bundle();
                                                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,
                                                                textDesc.getText() + " : " + tag);
                                                        bundle.putString(FirebaseAnalytics.Param.ITEM_CATEGORY,
                                                                baseActivity.voucherType);
                                                        try {
                                                            // Let's use a regex to make sure we get a R value which
                                                            // might be in one of two places... yes, really...
                                                            if (((String) textValue.getText()).matches("^R[\\d.]+$")) {
                                                                bundle.putDouble(FirebaseAnalytics.Param.PRICE,
                                                                        Double.parseDouble((String) textValue.getText().subSequence(1, textValue.getText().length())));
                                                            } else if (((String) textDesc.getText()).matches("^R[\\d.]+$")) {
                                                                bundle.putDouble(FirebaseAnalytics.Param.PRICE,
                                                                        Double.parseDouble((String) textDesc.getText().subSequence(1, textDesc.getText().length())));
                                                            }
                                                        } catch (Exception err) {
                                                            Log.d(TAG, "Exception on creating firebase event: " + err.toString());
                                                        }

                                                        baseActivity.mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.VIEW_ITEM, bundle);
                                                    }
                                                }

                                            }

                );

                /*
                 * MVP
                 * =========================================================================================================================================================
                 * Uncomment the itemView.setOnCreateContextMenuListener code below when you want add things to favourites
                 */

                itemView.setOnCreateContextMenuListener(new View.OnCreateContextMenuListener() {
                    @Override
                    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {

                        baseActivity.resetTimer();
                        baseActivity.hideKeyboard();

                        Log.d("kuijkenfav", "BluRecyclerAdapter: " + currentFragment.getClass().getSimpleName() + " mvno:" + isMVNO + " desc:" + BluViewHolder.this.toString());

                        //MenuItem actionItem = null;

                        if (!baseActivity.isConsumerProfileActive()) {

                            if (currentFragment instanceof FragmentFavourites) {
                                removeFromFavourites();
                            } else if (currentFragment instanceof FragmentConfigFavourites) {
                                //do nothing

                            } else if (currentFragment instanceof FragmentConfirmConfigFavourites) {
                                //do nothing

                            } else if (currentFragment instanceof FragmentAirtime) {
                                if (!voucherType.equalsIgnoreCase("topup")) {
                                    addToFavourites();
                                }
                            } else if (currentFragment instanceof FragmentData) {
                                if (!voucherType.equalsIgnoreCase("bundle")) {
                                    addToFavourites();
                                }
                            } else if (currentFragment instanceof FragmentElectricity) {
                                if (!voucherType.equalsIgnoreCase("topup") && !voucherType.equalsIgnoreCase("bundle")) {
                                    addToFavourites();
                                }
                            } else if (currentFragment instanceof FragmentVouchers) {
                                //do not allow MVNOs or Wallet Topups to be added to favourites
                                if (!isMVNO && !Arrays.asList(baseActivity.getResources().getStringArray(R.array.walletTopupProviders)).contains(tag)) {
                                    addToFavourites();
                                }
                            } else if (currentFragment instanceof FragmentTransact) {
                                addToFavourites();
                            } else if (currentFragment instanceof FragmentTickets) {
                                addToFavourites();
                            }
                        }
                    }
                });

            }
        }

        void addToFavourites() {
            final BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                if (baseActivity.userLevel.equals("1")) {
                    alert = baseActivity.createFavouritesDialog("Add to Favourites?");
                    alert.setPositiveOption(baseActivity.getString(R.string.add), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            baseActivity.resetTimer();
                            if (isMVNO) {
                                provider.setText(supplierCode);
                            }
                            List<String> favourites = new ArrayList<>();
                            String strVoucherTypeDesc = voucherTypeDesc.getText().toString().trim();
                            String strData = (((textDesc.getText().toString()).isEmpty()) ? "N/A" : textDesc.getText().toString())
                                    + ";" + (((textValue.getText().toString()).isEmpty()) ? "N/A" : textValue.getText().toString())
                                    + ";" + ((stockId == null || stockId.isEmpty()) ? "N/A" : stockId)
                                    + ";" + ((voucherType == null || voucherType.isEmpty()) ? "N/A" : voucherType)
                                    + ";" + ((tag == null || (tag.isEmpty()) ? "N/A" : tag)
                                    + ";" + (strVoucherTypeDesc.isEmpty() ? "N/A" : strVoucherTypeDesc)
                                    + ";" + ((provider == null || provider.getText().toString().isEmpty()) ? "N/A" : provider.getText().toString()));
                            favourites.add(strData);

                            if (!baseActivity.checkFavouritesListEntry(strData)) {
                                if ((baseActivity.getFavouritesList()).size() < 21) {
                                    baseActivity.saveFavouritesList(favourites);
                                    baseActivity.getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, new FragmentConfirmConfigFavourites(), "FragmentFavourites").commit();
                                    Toast.makeText(baseActivity, textDesc.getText() + " " + textValue.getText() + " added to Favourites", Toast.LENGTH_SHORT).show();
                                } else {
                                    baseActivity.createAlertDialog(baseActivity.getResources().getString(R.string.dialogTitle), baseActivity.getResources().getString(R.string.dialogMaxFavourites));
                                }
                            } else {
                                baseActivity.createAlertDialog(baseActivity.getResources().getString(R.string.dialogTitle), textDesc.getText() + " already exists in your favourites.");
                            }

                        }
                    });

                    alert.setNegativeOption(baseActivity.getString(R.string.cancel), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            baseActivity.resetTimer();
                            dialog.dismiss();
                        }
                    });

                    alert.show();
                }
            }
        }

        void removeFromFavourites() {
            final BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                if (baseActivity.userLevel.equals("1")) {
                    alert = baseActivity.createFavouritesDialog("Remove from Favourites?");
                    alert.setPositiveOption(baseActivity.getString(R.string.remove), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            baseActivity.resetTimer();
                            String strVoucherTypeDesc = voucherTypeDesc.getText().toString().trim();

                            String strData;
                            if (textValue == null || stockId == null || tag == null || voucherTypeDesc == null) {
                                strData = ((textDesc.getText().toString().isEmpty()) ? "N/A" : textDesc.getText().toString())
                                        + ";" + "N/A"
                                        + ";" + "N/A"
                                        + ";" + "Menu"
                                        + ";" + "N/A"
                                        + ";" + "N/A"
                                        + ";" + "N/A";
                            } else if (isMVNO()) {
                                provider.setText(supplierCode);
                                strData = ((textDesc.getText().toString().isEmpty()) ? "N/A" : textDesc.getText().toString())
                                        + ";" + ((textValue.getText().toString().isEmpty()) ? "N/A" : textValue.getText().toString())
                                        + ";" + ((stockId.isEmpty()) ? "N/A" : stockId)
                                        + ";" + ((voucherType.isEmpty()) ? "N/A" : voucherType)
                                        + ";" + ((textDesc.getText().toString().isEmpty()) ? "N/A" : textDesc.getText().toString())
                                        + ";" + ((strVoucherTypeDesc.isEmpty()) ? "N/A" : strVoucherTypeDesc)
                                        + ";" + ((provider == null) || (provider.getText().toString().isEmpty()) ? "N/A" : provider.getText().toString());
                            } else {
                                strData = (((textDesc.getText().toString()).isEmpty()) ? "N/A" : textDesc.getText().toString())
                                        + ";" + (((textValue.getText().toString()).isEmpty()) ? "N/A" : textValue.getText().toString())
                                        + ";" + ((stockId.isEmpty()) ? "N/A" : stockId)
                                        + ";" + ((voucherType.isEmpty()) ? "N/A" : voucherType)
                                        + ";" + ((tag.isEmpty()) ? "N/A" : tag)
                                        + ";" + ((strVoucherTypeDesc.isEmpty()) ? "N/A" : strVoucherTypeDesc)
                                        + ";" + ((provider.getText().toString().isEmpty()) ? "N/A" : provider.getText().toString());
                            }

                            Log.v(TAG, "Text Descrip: " + textDesc.getText().toString());
                            Log.v(TAG, strData);

                            baseActivity.removeFromFavouritesList(baseActivity.getFavouritesList(), strData);
                            baseActivity.getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, new FragmentFavourites(), "FragmentFavourites").commit();
                            Toast.makeText(baseActivity, textDesc.getText() + " " + textValue.getText() + " removed from Favourites", Toast.LENGTH_SHORT).show();

                        }
                    });

                    alert.setNegativeOption(baseActivity.getString(R.string.cancel), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            baseActivity.resetTimer();
                            dialog.dismiss();
                        }
                    });


                    alert.show();
                }
            }
        }

        void setTag(String tag) {
            this.tag = tag;
        }

        void setStockId(String stockId) {
            this.stockId = stockId;
        }

        void setSupplierCode(String supplierCode) {
            this.supplierCode = supplierCode;
        }

        boolean isMVNO() {
            return isMVNO;
        }

        void setMVNO(boolean MVNO) {
            isMVNO = MVNO;
        }

        void setTopupName(String topupName) {
            this.topupName = topupName;
        }

        void setVoucherType(String voucherType) {
            this.voucherType = voucherType;
        }

        void setDefaultCard(String defaultCard) {
            this.defaultCard = defaultCard;
        }

        void setHasAirtimePlus(boolean hasAirtimePlus) {
            this.hasAirtimePlus = hasAirtimePlus;
        }

        @Override
        public void onItemSelected() {
        }

        @Override
        public void onItemClear() {
        }
    }

    public void setFilter(String searchCriteria) {
        setFilteredItems(searchCriteria, data);
        isFilterActive = true;
        notifyDataSetChanged();
    }

    public void setFilterSearch(String searchCriteria) {
        setFilteredItemsSearch(searchCriteria.toLowerCase(), data);
        isFilterActive = true;
        notifyDataSetChanged();
    }

    public void clearFilter() {
        isFilterActive = false;
        notifyDataSetChanged();
    }

    private void setFilteredItemsSearch(String searchCriteria, List<CardviewDataObject> data) {
        //Split is for 'Cell C' so we can search containing 'Cell' to get all results.
        //Not sure if this is the best search solution?
        filteredData = new ArrayList<>();
        for (CardviewDataObject card : data) {
            if (card.getTag().toLowerCase().contains(searchCriteria) || card.getCardDesc().toLowerCase().contains(searchCriteria)) {
                filteredData.add(card);
            }
        }
    }

    private void setFilteredItems(String searchCriteria, List<CardviewDataObject> data) {
        filteredData = new ArrayList<>();
        for (CardviewDataObject card : data) {
            String cardTag = card.getTag().startsWith("x") ? card.getTag().substring(1) : card.getTag();
            cardTag = cardTag.replaceAll(" ", "");
            searchCriteria = searchCriteria.replaceAll(" ", "");
            if (cardTag.equalsIgnoreCase(searchCriteria)) {
                Log.d(TAG, "equals " + searchCriteria + ": " + card.toString());
                filteredData.add(card);
            }
        }
    }

    public void updateData(String searchCriteria, ArrayList<CardviewDataObject> newData) {
        if (isFilterActive) {
            filteredData.clear();
            setFilteredItems(searchCriteria, newData);
            notifyDataSetChanged();
        } else {
            data.clear();
            data.addAll(newData);
            notifyDataSetChanged();
        }
    }

    private Drawable getDrawableResource(String tag, ImageView icon, String defaultCard) {
        int imgResId;
        Drawable drawable = null;
        try {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                if (tag.toLowerCase().contains("cell c")) {
                    tag = tag.replace(" ", "");
                } else if (tag.toLowerCase().contains("telkom mobile")) {
                    tag = tag.replace(" ", "");
                }
                if (!defaultCard.isEmpty()) {
                    imgResId = baseActivity.getResources().getIdentifier(defaultCard, "drawable", baseActivity.getPackageName());
                } else {
                    imgResId = baseActivity.getResources().getIdentifier(tag.toLowerCase(), "drawable", baseActivity.getPackageName());
                }

                if (imgResId > 0) {
                    drawable = ContextCompat.getDrawable(baseActivity.getApplicationContext(), imgResId);
                } else {
                    drawable = icon.getDrawable();
                }
            }
        } catch (Exception ex) {
            Log.d(TAG, "Problem getting image resource " + ex);
        }
        return drawable;
    }

    private int getColorResource(String tag) {
        Log.d("MPKvouch", "getColorResource for " + tag);
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            int colorResId = R.color.white;
            try {

                tag = tag.replace(" ", "");
                if (tag.toLowerCase().contains("telkom")) {
                    tag = "telkom";
                } else if (tag.toLowerCase().startsWith("x")) {
                    tag = tag.substring(1);
                }

                int lookupColorResId = baseActivity.getResources().getIdentifier(tag.toLowerCase(), "color", baseActivity.getPackageName());

                if (lookupColorResId > 0) {
                    colorResId = lookupColorResId;
                }
            } catch (Exception ex) {
                Log.d(TAG, "Problem getting image resource " + ex);
            }
            return baseActivity.getResources().getColor(colorResId);
        }
        return 0;
    }


}
