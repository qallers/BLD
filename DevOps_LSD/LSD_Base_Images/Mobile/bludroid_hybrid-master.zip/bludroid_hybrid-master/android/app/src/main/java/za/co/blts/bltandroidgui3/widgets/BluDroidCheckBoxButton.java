package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.widget.AppCompatCheckBox;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidCheckBoxButton extends AppCompatCheckBox implements OnClickListener, OnTouchListener {
    @SuppressWarnings("FieldCanBeLocal")
    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference = null;

    private void setTextSize() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                super.setTextSize(baseScreen.getSkinResources().getTextSize());
            }
        }
    }

    private void setTextColor() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                super.setTextColor(baseScreen.getSkinResources().getBackgroundTextColor());

                ColorStateList colorStateList = new ColorStateList(
                        new int[][]{
                                new int[]{android.R.attr.state_checked},
                                new int[]{-android.R.attr.state_checked},
                        },
                        new int[]{
                                baseScreen.getSkinResources().getButtonColor(),
                                baseScreen.getSkinResources().getBackgroundTextColor()
                        }
                );

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    setButtonTintList(colorStateList);
                } else {

                    setSupportButtonTintList(colorStateList);
                }
            }
        }
    }

    private void setup() {
        setTextColor();
        setOnClickListener(this);
        setOnTouchListener(this);

        setFocusableInTouchMode(true);
    }

    public BluDroidCheckBoxButton(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setup();
    }

    //
// http://stackoverflow.com/questions/10254748/how-to-extend-an-android-button-and-use-an-xml-layout-file
//
    public BluDroidCheckBoxButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        boolean needTextSize = true;
        boolean needTextColor = true;
        for (int i = 0; i < attrs.getAttributeCount(); i++) {
            //Log.d(TAG, attrs.getAttributeName(i) + " = " + attrs.getAttributeValue(i));
            if (attrs.getAttributeName(i).equals("textSize"))
                needTextSize = false;
            if (attrs.getAttributeName(i).equals("textColor"))
                needTextColor = false;
        }
        setOnClickListener(this);
        if (context instanceof BaseActivity) {
            try {
                this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
                setup();
                if (needTextColor)
                    setTextColor();
                if (needTextSize)
                    setTextSize();
            } catch (Exception exception) {
                Log.d(TAG, "BluDroidRadioButton exception " + exception);
            }
        }
    }

    public boolean onTouch(View v, MotionEvent event) {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                BaseActivity.logger.info(((Button) v).getText() + ": onTouch()");
                baseScreen.resetTimer();
            }
        }
        requestFocus();
        return false;
    }

    public void onClick(View v) {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                BaseActivity.logger.info(((CheckBox) v).getText() + ": onClick()"); // check for null
                baseScreen.resetTimer();
            }
        }
    }


}

