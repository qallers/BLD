package za.co.blts.bltandroidgui3;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidHeading;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

/**
 * Created by NkosanaM on 3/23/2017.
 */

public class BluDroidReprintListDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, TextWatcher {

    private ListView listView;
    private Animation animShow, animHide;
    private BluDroidReprintListAdapter reprintListAdapter;
    private ArrayList<Reprint> reprintList;
    private BluDroidHeading noTransactions;

    public void setup() {
        super.setup();

        reprintList = new ArrayList<>();
        initAnimation();

        setHeading("Reprints");


        listView = findViewById(R.id.reprintList);
        listView.setTextFilterEnabled(true);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        EditText filterEditText = findViewById(R.id.search);
        filterEditText.addTextChangedListener(this);

        noTransactions = findViewById(R.id.noTransactions);

        hideList();
        generateReprintList();

    }

    @Override
    protected void onStop() {
        if (listView != null) listView.setAdapter(null);
        super.onStop();
    }

    public BluDroidReprintListDialog(BaseActivity context) {
        super(context, R.layout.dialog_reprint_list);
        setup();
        Log.d(TAG, "user details");
    }

    private void generateReprintList() {

        for (int i = 0; i < baseActivity.reprintResponseListByDateMessage.getData().getReprints().size(); i++) {
            String type = baseActivity.reprintResponseListByDateMessage.getData().getReprints().get(i).getType();
            String date = baseActivity.reprintResponseListByDateMessage.getData().getReprints().get(i).getDate();
            String amount = baseActivity.reprintResponseListByDateMessage.getData().getReprints().get(i).getAmount();
            String ref = baseActivity.reprintResponseListByDateMessage.getData().getReprints().get(i).getRef();
            String id = baseActivity.reprintResponseListByDateMessage.getData().getReprints().get(i).getId();

            Reprint reprint = new Reprint(type, date, amount, id, ref);
            reprintList.add(reprint);
        }

        reprintListAdapter = new BluDroidReprintListAdapter(baseActivity, R.layout.reprint_row_item, reprintList);
        listView.setAdapter(reprintListAdapter);
        showList();

        if (reprintList.size() > 0) {
            noTransactions.setVisibility(View.GONE);
        } else {
            showNoTransactions();
        }


    }

    private void initAnimation() {
        animShow = AnimationUtils.loadAnimation(baseActivity, R.anim.view_show);
        animHide = AnimationUtils.loadAnimation(baseActivity, R.anim.view_hide);
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

        if (this != null) {
            reprintListAdapter.getFilter().filter(s);
        } else {
            Log.d("filter", "no filter availible");
        }
    }


    @Override
    public void afterTextChanged(Editable s) {

    }

    private void showList() {
        View view = this.findViewById(R.id.reprintList);
        view.startAnimation(animShow);
        view.setVisibility(VISIBLE);
    }

    private void showNoTransactions() {
        noTransactions.startAnimation(animShow);
        noTransactions.setVisibility(VISIBLE);
    }

    private void hideList() {

        View view = this.findViewById(R.id.reprintList);
        view.startAnimation(animHide);
        view.setVisibility(GONE);
    }

}
