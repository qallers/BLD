const locations = [
  {
    id: 1,
    name: "CAPE TOWN",
    tel: "542-866-4301",
    email: "brenfield0@gmail.com",
    country: "Russia",
  },
  {
    id: 2,
    name: "BELLVILLE",
    tel: "436-643-1234",
    email: "atesche1@hotmail.com",
    country: "Indonesia",
  },
  {
    id: 3,
    name: "THREE SISTERS",
    tel: "682-740-8794",
    email: "cfollett2@boston.com",
    country: "Greece",
  },
];

const bus = [
  {
    id: 1,
    name: "PUTCO",
    type: "COACH",
    price: "R 250",
  },
  {
    id: 2,
    name: "PUTCO",
    type: "PUTCO",
    price: "R 250",
  },
  {
    id: 3,
    name: "PUTCO",
    type: "DREAM LINE",
    price: "R 250",
  },
  {
    id: 4,
    name: "PUTCO",
    type: "MEGA COACH",
    price: "R 450",
  },
  {
    id: 5,
    name: "PUTCO",
    type: "STANDARD",
    price: "R 100",
  },
  {
    id: 6,
    name: "PUTCO",
    type: "LUX",
    price: "R 300",
  },
];
export default { locations, bus };
