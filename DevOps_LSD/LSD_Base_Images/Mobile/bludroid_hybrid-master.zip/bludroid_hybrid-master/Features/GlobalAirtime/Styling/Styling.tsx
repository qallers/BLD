import {StyleSheet, View} from 'react-native';
import styled from 'styled-components';
import {wdp} from '../../../helpers/DeviceScalling';
export const Container = styled(View)`
  flex: 1;
  background-color: #f2f2f2;
  padding: ${wdp(10)}px;
`;

const Style = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F2',
    width: '100%',
  },
  introContainer: {
    backgroundColor: '#fff',
    marginTop: 0,
    width: 400,
    height: 80,
  },
  tile: {
    backgroundColor: '#fff',
    marginTop: 90,
    bottom: 10,
    height: 100,
    width: 350,
    padding: 20,
    borderColor: 'navy',
    borderRadius: 8,
  },
  text: {
    color: 'gray',
    fontSize: 20,
    margin: 10,
    fontWeight: 'bold',
  },
  InnerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F2F2F2',
    marginTop: 270,
    width: 350,
    height: 100,
  },
  inputField: {
    height: 40,
    borderColor: 'navy',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 15,
    paddingHorizontal: 10,
    width: '95%',
    backgroundColor: 'white',
  },
  buttonContainer: {
    backgroundColor: 'navy',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 10,
    padding: 20,
    top: 20,
    width: '48%',
  },
  newButton: {
    backgroundColor: 'navy',
    paddingVertical: 15,
    borderRadius: 10,
  },
  buttonText: {
    textAlign: 'center',
    color: 'white',
    fontSize: 18,
  },
  registerText: {
    textAlign: 'center',
    color: 'navy',
    fontSize: 18,
    marginTop: 10,
  },
  button: {
    backgroundColor: '#004D92',
    bottom: 5,
    paddingHorizontal: 40,
    borderRadius: 5,
    padding: 10,
    width: '95%',
  },
  checkboxContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  checkbox: {
    right: -100,
  },
  radioButton: {left: 300, top: -25},
  FlatList: {marginTop: 16, marginBottom: 16, width: '100%'},
  grayText: {fontSize: 15, margin: 15},
  printText: {fontSize: 15, margin: 6},
  row: {flexDirection: 'row'},
  returnedText: {
    fontSize: 15,
    margin: 6,
    fontWeight: 'bold',
    position: 'absolute',
    right: 5,
  },
  bottomContainer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonGrid: {
    alignItems: 'center',
    backgroundColor: 'white',
    borderColor: 'grey',
    borderWidth: 1,
    padding: 10,
    marginTop: 16,
    marginLeft: 5,
    marginRight: 5,
    borderRadius: 7,
    marginVertical: 10,
    width: 100,
    height: 80,
  },
});
export default Style;
