import React, {useState} from 'react';
import {graphql, useQuery} from 'relay-hooks';
import {Text, View, TouchableOpacity, TextInput} from 'react-native';
import styling from '../Styling/Styling';
import Vouchers from './Vouchers';
import {AppContext} from '../../../context/AuthContext';
const VouchersScreen = ({navigation, route}: any) => {
  const phoneRegEx = /^(\+?\d{0,4})?\s?-?\s?(\(?\d{3}\)?)\s?-?\s?(\(?\d{3}\)?)\s?-?\s?(\(?\d{4}\)?)?$/;
  console.log('params in vouchersScreen: ' + JSON.stringify(route));
  const {setSender} = React.useContext(AppContext);
  const [number, setNum] = useState('');
  const {selectedProduct} = React.useContext(AppContext);

  const handleSubmit = () => {
    if (selectedProduct) {
      if (number.match(phoneRegEx)) {
        setSender(number);
        navigation.navigate('Confirmation', {data: route});
      } else {
        alert('Phone number not valid');
      }
    } else {
      alert('Please select a product');
    }
  };

  return (
    <View style={{flex: 1}}>
      <View style={{top: 10}}>
        <Text style={styling.text}>Available Top-Ups</Text>
        <Vouchers navigation={navigation} route={route} />
      </View>
      <View
        style={{
          position: 'absolute',
          bottom: 0,
          width: '100%',
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: 'white',
        }}
      >
        <Text style={styling.text}>Enter Sender's Number</Text>
        <TextInput
          placeholder="071 121 0000"
          style={styling.inputField}
          value={number}
          keyboardType="decimal-pad"
          onChangeText={(newValue) => setNum(newValue)}
        />

        <TouchableOpacity onPress={handleSubmit} style={styling.button}>
          <Text style={styling.buttonText}>Next</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default VouchersScreen;
