/* tslint:disable */
/* eslint-disable */
// @ts-nocheck

import { ConcreteRequest } from "relay-runtime";
export type MSISDNValidationInput = {
    phoneNumber: string;
    reference: string;
    network?: string | null;
    iaAuth: IAAuth;
    auth: BusAccount;
};
export type IAAuth = {
    deviceId: string;
    transType: string;
    userPin: string;
    deviceSer: string;
    reference?: string | null;
};
export type BusAccount = {
    deviceId: string;
    serialNum: string;
    userPin: string;
    location: string;
    swVer: string;
};
export type VouchersMutationVariables = {
    input: MSISDNValidationInput;
};
export type VouchersMutationResponse = {
    readonly msisdnValidation: {
        readonly success: boolean;
        readonly message: string;
        readonly data: {
            readonly countryCode: string;
            readonly currencyCode: string;
            readonly ref: string;
            readonly reference: string;
            readonly exchangeRate: string;
            readonly productList: ReadonlyArray<{
                readonly type: string;
                readonly network: string;
                readonly description: string;
                readonly productCode: string;
                readonly top5Seller: string;
                readonly amount: string;
            } | null>;
        } | null;
    } | null;
};
export type VouchersMutation = {
    readonly response: VouchersMutationResponse;
    readonly variables: VouchersMutationVariables;
};



/*
mutation VouchersMutation(
  $input: MSISDNValidationInput!
) {
  msisdnValidation(input: $input) {
    success
    message
    data {
      countryCode
      currencyCode
      ref
      reference
      exchangeRate
      productList {
        type
        network
        description
        productCode
        top5Seller
        amount
      }
    }
  }
}
*/

const node: ConcreteRequest = (function(){
var v0 = [
  {
    "defaultValue": null,
    "kind": "LocalArgument",
    "name": "input"
  }
],
v1 = [
  {
    "alias": null,
    "args": [
      {
        "kind": "Variable",
        "name": "input",
        "variableName": "input"
      }
    ],
    "concreteType": "MSISDNValidationResult",
    "kind": "LinkedField",
    "name": "msisdnValidation",
    "plural": false,
    "selections": [
      {
        "alias": null,
        "args": null,
        "kind": "ScalarField",
        "name": "success",
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "kind": "ScalarField",
        "name": "message",
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "MSISDNValidationDataResult",
        "kind": "LinkedField",
        "name": "data",
        "plural": false,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "countryCode",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "currencyCode",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "ref",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "reference",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "exchangeRate",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "concreteType": "IAProduct",
            "kind": "LinkedField",
            "name": "productList",
            "plural": true,
            "selections": [
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "type",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "network",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "description",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "productCode",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "top5Seller",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "amount",
                "storageKey": null
              }
            ],
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "storageKey": null
  }
];
return {
  "fragment": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Fragment",
    "metadata": null,
    "name": "VouchersMutation",
    "selections": (v1/*: any*/),
    "type": "Mutation",
    "abstractKey": null
  },
  "kind": "Request",
  "operation": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Operation",
    "name": "VouchersMutation",
    "selections": (v1/*: any*/)
  },
  "params": {
    "cacheID": "3526bfcff2275e2b35b02d3db17d919e",
    "id": null,
    "metadata": {},
    "name": "VouchersMutation",
    "operationKind": "mutation",
    "text": "mutation VouchersMutation(\n  $input: MSISDNValidationInput!\n) {\n  msisdnValidation(input: $input) {\n    success\n    message\n    data {\n      countryCode\n      currencyCode\n      ref\n      reference\n      exchangeRate\n      productList {\n        type\n        network\n        description\n        productCode\n        top5Seller\n        amount\n      }\n    }\n  }\n}\n"
  }
};
})();
(node as any).hash = '881f7bbe67852937d3c82ecc8ad3f037';
export default node;
