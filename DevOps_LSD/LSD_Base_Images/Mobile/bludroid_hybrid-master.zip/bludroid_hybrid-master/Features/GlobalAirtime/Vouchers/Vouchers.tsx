import React, {useState} from 'react';
import {
  Alert,
  FlatList,
  Text,
  View,
  TouchableOpacity,
  Image,
} from 'react-native';
import {graphql, useQuery} from 'relay-hooks';
import {Box} from '../../../Components/Box';
import styling from '../Styling/Styling';
import {VouchersMutation} from './__generated__/VouchersMutation.graphql';
import {AppContext} from '../../../context/AuthContext';

const query = graphql`
  mutation VouchersMutation($input: MSISDNValidationInput!) {
    msisdnValidation(input: $input) {
      success
      message
      data {
        countryCode
        currencyCode
        ref
        reference
        exchangeRate
        productList {
          type
          network
          description
          productCode
          top5Seller
          amount
        }
      }
    }
  }
`;

interface Props {
  navigation: any;
  route: any;
}
const Vouchers = ({navigation, route}: Props) => {
  const [selected, setSelected] = useState<any>({});
  const {
    setProduct,
    selectedNumber,
    selectedProduct,
    setCurrency,
    setExchangeRate,
  } = React.useContext(AppContext);

  const {props, error, retry} = useQuery<VouchersMutation>(query, {
    input: {
      phoneNumber: selectedNumber,
      reference: route.params.auth.devId + '_1539163763756',
      iaAuth: {
        deviceId: route.params.auth.devId,
        transType: 'IPayBundles',
        userPin: route.params.auth.userPin,
        deviceSer: route.params.auth.serial,
        reference: route.params.auth.devId + '_1539163763756',
      },
      auth: {
        deviceId: route.params.auth.devId,
        serialNum: route.params.auth.serial,
        userPin: route.params.auth.userPin,
        location: '',
        swVer: 'bluShift',
      },
    },
  });
  console.log('data: ' + JSON.stringify(route.params.auth.devId));
  const createErrorAlert = (message: any) => {
    Alert.alert('Error', 'Unable to get Vouchers, please try again later');
    navigation.navigate('NumberLookup');
  };

  const getItem = (item: any) => {
    setSelected(item);
    setProduct(item);
  };

  if (error) createErrorAlert(error.message);

  let list: any[] = [];
  let fixedList: any[] = [];
  var results: any = '';
  if (
    props &&
    props.msisdnValidation?.success === true &&
    props.msisdnValidation?.data?.productList
  ) {
    results = props.msisdnValidation.data;
    setCurrency(props.msisdnValidation.data!.currencyCode);
    setExchangeRate(props.msisdnValidation.data!.exchangeRate);
    fixedList = props.msisdnValidation.data!.productList.filter(
      (item) => item?.type === 'FixedDenomination'
    );
    const {
      msisdnValidation: {
        data: {productList = []},
      },
    } = props;
    list = props.msisdnValidation.data!.productList
      ? productList.map((edge) => edge)
      : [];
  } else {
    if (props?.msisdnValidation?.success === false) {
      alert(props?.msisdnValidation?.message);
      navigation.navigate('NumberLookup');
    }
  }

  console.log('fixed: ' + JSON.stringify(fixedList));
  const ItemView = ({
    item,
    active,
    selectItem,
  }: {
    item: any;
    active: any;
    selectItem: any;
  }) => {
    return (
      // Flat List Item
      <View
        style={{
          padding: 10,
          flexDirection: 'row',
          left: 5,
          margin: 5,
          width: 100,
          height: 100,
        }}
      >
        <TouchableOpacity
          onPress={() => getItem(item)}
          style={{
            width: '100%',
          }}
        >
          <Box>
            <Box
              style={{
                alignItems: 'center',
                backgroundColor:
                  selectedProduct?.productCode === item.productCode
                    ? 'palegreen'
                    : 'white',
                borderColor: 'grey',
                borderWidth: 1,
                padding: 10,
                marginTop: 16,
                marginLeft: 5,
                marginRight: 5,
                borderRadius: 7,
                marginVertical: 10,
                width: 100,
                height: 80,
              }}
            >
              <Text>
                R{' '}
                {(
                  (Number(item.amount) / 100) *
                  Number(results.exchangeRate)
                ).toFixed(2)}
              </Text>
              <Text>
                {results.currencyCode} {(Number(item.amount) / 100).toFixed(2)}
              </Text>
            </Box>
          </Box>
        </TouchableOpacity>
      </View>
    );
  };

  const voucherList = () => {
    return (
      <FlatList
        style={styling.FlatList}
        data={fixedList}
        numColumns={3}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({item}) => {
          return (
            <ItemView
              item={item}
              active={item}
              selectItem={() => {
                getItem(item);
              }}
            />
          );
        }}
      />
    );
  };
  return list.length > 0 ? (
    <View style={{top: 15, height: 300}}>
      <View style={{flexDirection: 'row'}}>
        <Text style={{fontSize: 15, left: 20}}>
          {' '}
          Country Code : {results.countryCode}
        </Text>
        <Text style={{left: 40}}>|</Text>
        <Text style={{left: 60}}>
          Network : {results.productList[0].network}
        </Text>
      </View>

      {voucherList()}
    </View>
  ) : (
    <View style={{flex: 1}}>
      <Box>
        <Text>Loading Vouchers...</Text>
      </Box>
    </View>
  );
};

export default Vouchers;
