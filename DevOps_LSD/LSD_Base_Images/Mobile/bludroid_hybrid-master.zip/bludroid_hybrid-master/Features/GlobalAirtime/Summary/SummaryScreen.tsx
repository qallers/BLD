import React from 'react';
import {Alert, Text, TouchableOpacity, View} from 'react-native';
import styling from '../Styling/Styling';
import {graphql, useQuery} from 'relay-hooks';
import {SummaryScreenMutation} from './__generated__/SummaryScreenMutation.graphql';
import {AppContext} from '../../../context/AuthContext';
import ResultModule from '../../../modules/results/ResultModule';

const query = graphql`
  mutation SummaryScreenMutation($input: IABundleTopupInput!) {
    internationalBundleTopup(input: $input) {
      success
      message
      data {
        transRef
        supplierName
        phoneNumber
        tenderVat
        tenderAmount
        receiveAmount
        ref
        date
        ref
        productCode
        callCenter
        printLines
        merchantPrintLines
      }
    }
  }
`;

const SummaryScreen = ({route}: any) => {
  const {
    selectedNumber,
    selectedSender,
    selectedProduct,
    currency,
    reference,
    exchangeRate,
  } = React.useContext(AppContext);

  var amount = ((Number(selectedProduct.amount) / 100) * Number(exchangeRate))
    .toFixed(2)
    .toString();

  const {props, error, retry} = useQuery<SummaryScreenMutation>(query, {
    input: {
      phoneNumber: selectedNumber,
      senderPhoneNumber: selectedSender,
      amount: amount,
      transType: 'IPayBundles',
      productCode: selectedProduct.productCode,
      network: selectedProduct.network,
      iaAuth: {
        deviceId: route.params.auth.devId,
        transType: 'IPayBundles',
        userPin: route.params.auth.userPin,
        deviceSer: route.params.auth.serial,
        reference: reference,
      },
      auth: {
        deviceId: route.params.auth.devId,
        serialNum: route.params.auth.serial,
        userPin: route.params.auth.userPin,
        location: '',
        swVer: 'bluShift',
      },
    },
  });
  const createErrorAlert = (message: any) => {
    Alert.alert('Error', 'Unable to purchase, please try again later');
  };

  if (error) createErrorAlert(error.message);

  const sendToBlu = (response: any) => {
    ResultModule.returnResult(true, JSON.stringify(response));
  };

  if (props && props.internationalBundleTopup?.success === true) {
    const response = props.internationalBundleTopup;
    const res = {
      result: 'Success',
      transaction: {
        id: response?.data?.ref,
        name: 'Global Airtime',
        productName: response?.data?.supplierName,
        transref: response?.data?.transRef,
        reference: reference,
        amount: (
          (Number(selectedProduct.amount) / 100) *
          Number(exchangeRate)
        ).toFixed(2),
      },
      custSlip: response?.data?.printLines,
      merchSlip: response?.data?.merchantPrintLines,
    };
    ResultModule.returnResult(true, JSON.stringify(res));
    sendToBlu(response);
  } else {
    if (props?.internationalBundleTopup?.success === false)
      Alert.alert(props?.internationalBundleTopup?.message!);
  }

  return (
    <View style={{flex: 1, alignContent: 'center', justifyContent: 'center', alignItems:"center"}}>
      <Text style={{fontSize: 30, fontWeight: 'bold'}}>Please Wait...</Text>
    </View>
  );
};

export default SummaryScreen;
