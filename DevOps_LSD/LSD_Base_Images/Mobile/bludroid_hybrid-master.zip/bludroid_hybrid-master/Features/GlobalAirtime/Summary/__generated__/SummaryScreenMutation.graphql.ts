/* tslint:disable */
/* eslint-disable */
// @ts-nocheck

import { ConcreteRequest } from "relay-runtime";
export type IABundleTopupInput = {
    auth: BusAccount;
    iaAuth: IAAuth;
    transType: string;
    phoneNumber: string;
    amount: string;
    senderPhoneNumber: string;
    productCode: string;
    recon?: IAReconInput | null;
    network: string;
};
export type BusAccount = {
    deviceId: string;
    serialNum: string;
    userPin: string;
    location: string;
    swVer: string;
};
export type IAAuth = {
    deviceId: string;
    transType: string;
    userPin: string;
    deviceSer: string;
    reference?: string | null;
};
export type IAReconInput = {
    batchNumber: string;
    terminalId: string;
    merchantId: string;
    transNumber: string;
    transReference: string;
    sysReference: string;
    transDateTime: string;
    businessDate: string;
    transType: string;
    accountNumber: string;
    productId: string;
    amount: string;
    authoriser: string;
    productName: string;
    auth: BusAccount;
};
export type SummaryScreenMutationVariables = {
    input: IABundleTopupInput;
};
export type SummaryScreenMutationResponse = {
    readonly internationalBundleTopup: {
        readonly success: boolean;
        readonly message: string;
        readonly data: {
            readonly transRef: string;
            readonly supplierName: string;
            readonly phoneNumber: string;
            readonly tenderVat: string;
            readonly tenderAmount: string;
            readonly receiveAmount: string;
            readonly ref: string;
            readonly date: string;
            readonly productCode: string;
            readonly callCenter: string | null;
            readonly printLines: string;
            readonly merchantPrintLines: string;
        } | null;
    } | null;
};
export type SummaryScreenMutation = {
    readonly response: SummaryScreenMutationResponse;
    readonly variables: SummaryScreenMutationVariables;
};



/*
mutation SummaryScreenMutation(
  $input: IABundleTopupInput!
) {
  internationalBundleTopup(input: $input) {
    success
    message
    data {
      transRef
      supplierName
      phoneNumber
      tenderVat
      tenderAmount
      receiveAmount
      ref
      date
      productCode
      callCenter
      printLines
      merchantPrintLines
    }
  }
}
*/

const node: ConcreteRequest = (function(){
var v0 = [
  {
    "defaultValue": null,
    "kind": "LocalArgument",
    "name": "input"
  }
],
v1 = [
  {
    "alias": null,
    "args": [
      {
        "kind": "Variable",
        "name": "input",
        "variableName": "input"
      }
    ],
    "concreteType": "IABundleTopupResult",
    "kind": "LinkedField",
    "name": "internationalBundleTopup",
    "plural": false,
    "selections": [
      {
        "alias": null,
        "args": null,
        "kind": "ScalarField",
        "name": "success",
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "kind": "ScalarField",
        "name": "message",
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "IABundleTopupDataResult",
        "kind": "LinkedField",
        "name": "data",
        "plural": false,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "transRef",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "supplierName",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "phoneNumber",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "tenderVat",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "tenderAmount",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "receiveAmount",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "ref",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "date",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "productCode",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "callCenter",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "printLines",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "merchantPrintLines",
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "storageKey": null
  }
];
return {
  "fragment": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Fragment",
    "metadata": null,
    "name": "SummaryScreenMutation",
    "selections": (v1/*: any*/),
    "type": "Mutation",
    "abstractKey": null
  },
  "kind": "Request",
  "operation": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Operation",
    "name": "SummaryScreenMutation",
    "selections": (v1/*: any*/)
  },
  "params": {
    "cacheID": "8a994bf726e83a9eed49b1901abd01dd",
    "id": null,
    "metadata": {},
    "name": "SummaryScreenMutation",
    "operationKind": "mutation",
    "text": "mutation SummaryScreenMutation(\n  $input: IABundleTopupInput!\n) {\n  internationalBundleTopup(input: $input) {\n    success\n    message\n    data {\n      transRef\n      supplierName\n      phoneNumber\n      tenderVat\n      tenderAmount\n      receiveAmount\n      ref\n      date\n      productCode\n      callCenter\n      printLines\n      merchantPrintLines\n    }\n  }\n}\n"
  }
};
})();
(node as any).hash = '1809111ae14635439b4570172e6fcf69';
export default node;
