import React, {useState} from 'react';
import {graphql, useQuery} from 'relay-hooks';
import {Text, View, TouchableOpacity, TextInput} from 'react-native';
import styling from '../Styling/Styling';
import {iaAuth, Device} from '../../../TestData/TestData';
import {AppContext} from '../../../context/AuthContext';

import VouchersScreen from '../Vouchers/VouchersScreen';
import Confirmation from '../Confirmation/ConfirmationScreen';
import SummaryScreen from '../Summary/SummaryScreen';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';

const Stack = createStackNavigator();
const NumberLookUpScreen = ({navigation}: any) => {
  const [number, setNum] = useState('');
  const {setNumber} = React.useContext(AppContext);
  const phoneRegEx = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;

  const handleSubmit = () => {
    if (number.match(phoneRegEx)) {
      setNumber('+' + number.replace(/\s+/g, ''));
      navigation.navigate('VouchersScreen');
    } else {
      alert('Phone number not valid');
    }
  };

  return (
    <View style={styling.container}>
      <View
        style={{
          width: '100%',
          justifyContent: 'center',
          alignItems: 'center',
          top: 20,
        }}
      >
        <Text style={styling.text}>Enter Number To Recharge</Text>
        <View
          style={{
            borderWidth: 1,
            flexDirection: 'row',
            alignItems: 'center',
            height: 40,
            borderColor: 'navy',
            borderRadius: 5,
            marginBottom: 15,
            paddingHorizontal: 10,
            width: '95%',
            backgroundColor: 'white',
          }}
        >
          <Text style={{top: -2}}>+</Text>
          <TextInput
            placeholder="000 000 0000"
            style={{width: '100%'}}
            value={number}
            keyboardType="decimal-pad"
            onChangeText={(newValue) => setNum(newValue)}
          />
        </View>
        <TouchableOpacity onPress={handleSubmit} style={styling.button}>
          <Text style={styling.buttonText}>Look Up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export function GlobalAirtimeNavigation(props: any) {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerTintColor: 'white',
          headerStyle: {backgroundColor: '#004D92'},
          headerTitle: 'Global Airtime',
          headerTitleAlign: 'center',
        }}
      >
        <Stack.Screen name="NumberLookup" component={NumberLookUpScreen} />
        <Stack.Screen
          initialParams={props}
          name="VouchersScreen"
          component={VouchersScreen}
        />
        <Stack.Screen
          initialParams={props}
          name="Confirmation"
          component={Confirmation}
        />
        <Stack.Screen
          initialParams={props}
          name="Summary"
          component={SummaryScreen}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
export default NumberLookUpScreen;
