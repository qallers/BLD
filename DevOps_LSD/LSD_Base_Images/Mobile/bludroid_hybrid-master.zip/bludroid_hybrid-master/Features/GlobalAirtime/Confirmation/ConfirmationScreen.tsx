import React from 'react';
import {Text, TouchableOpacity, View} from 'react-native';
import {AppContext} from '../../../context/AuthContext';
import styling from '../Styling/Styling';

const ConfirmationScreen = ({navigation, route}: any) => {
  const {
    selectedNumber,
    selectedSender,
    selectedProduct,
    currency,
    exchangeRate,
    setReference,
  } = React.useContext(AppContext);

  const handleSubmit = () => {
    setReference(route.params.auth.devId + '_' + new Date().getTime());
    navigation.navigate('Summary');
  };

  return (
    <View style={styling.container}>
      <View
        style={{
          justifyContent: 'center',
          alignContent: 'center',
          marginBottom: 15,
        }}
      >
        <Text
          style={{
            marginLeft: '1%',
            marginTop: '2%',
            fontSize: 20,
            fontWeight: 'bold',
          }}
        >
          Transaction Details
        </Text>
      </View>
      <View>
        <View style={styling.row}>
          <Text style={styling.printText}>Description :</Text>
          <Text style={styling.returnedText}>
            {selectedProduct.description}
          </Text>
        </View>
        <View style={styling.row}>
          <Text style={styling.printText}>Voucher Type :</Text>
          <Text style={styling.returnedText}>
            {selectedProduct.productCode}
          </Text>
        </View>
        <View style={styling.row}>
          <Text style={styling.printText}>Network :</Text>
          <Text style={styling.returnedText}>{selectedProduct.network}</Text>
        </View>
        <View
          style={{
            borderBottomColor: 'gray',
            borderBottomWidth: 1,
          }}
        />
      </View>
      <View>
        <Text
          style={{
            marginLeft: '1%',
            marginTop: '1%',
            fontSize: 20,
            fontWeight: 'bold',
            marginBottom: 10,
          }}
        >
          Order Summary
        </Text>
        <View style={styling.row}>
          <Text style={styling.printText}>Top-Up Amount :</Text>
          <Text style={styling.returnedText}>
            R{' '}
            {(
              (Number(selectedProduct.amount) / 100) *
              Number(exchangeRate)
            ).toFixed(2)}{' '}
          </Text>
        </View>

        <View style={styling.row}>
          <Text style={styling.printText}>Receiver Gets :</Text>
          <Text style={styling.returnedText}>
            {currency} {(Number(selectedProduct.amount) / 100).toFixed(2)}
          </Text>
        </View>
        <View
          style={{
            borderBottomColor: 'gray',
            borderBottomWidth: 1,
          }}
        />
      </View>
      <View>
        <View style={styling.row}>
          <Text style={styling.printText}>Receiver Number :</Text>
          <Text style={styling.returnedText}>{selectedNumber}</Text>
        </View>
        <View style={styling.row}>
          <Text style={styling.printText}>Sender Number :</Text>
          <Text style={styling.returnedText}> {selectedSender}</Text>
        </View>
        <View style={styling.row}>
          <Text style={styling.printText}>Date :</Text>
          <Text style={styling.returnedText}>
            {new Date().toISOString().slice(0, 10)}
          </Text>
        </View>
      </View>
      <View style={styling.bottomContainer}>
        <TouchableOpacity onPress={handleSubmit} style={styling.button}>
          <Text style={styling.buttonText}>Confirm</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ConfirmationScreen;
