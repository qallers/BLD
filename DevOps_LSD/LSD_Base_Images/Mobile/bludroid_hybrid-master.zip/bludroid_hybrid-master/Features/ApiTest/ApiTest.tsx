import * as React from 'react';
import {Component} from 'react';
import {Button, Text, View,} from 'react-native';
import styling from './ApiTest.style';
import {NavigationContainer} from "@react-navigation/native";
import {createStackNavigator} from "@react-navigation/stack";
import ResultModule from "../../modules/results/ResultModule";


const Stack = createStackNavigator();

interface Props {
  auth: AuthProps;
  target: string;
  theme: string;
  server: {
    url: string;
    token: string;
  }
}

interface AuthProps {
  devId: string;
  serial: string;
  userPin: string;
}

export function ApiTestNavigation(propsIn: any) {
  return (
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name="API Test">
            {() => <ApiTestScreen auth={propsIn.auth} target={propsIn.target} theme={propsIn.theme} server={propsIn.server}/>}
          </Stack.Screen>
        </Stack.Navigator>
      </NavigationContainer>
  );
}

export default class ApiTestScreen extends Component<Props> {
  constructor(props: any) {
    super(props);
    console.log('ApiTest props', props);
  }

  onPress = () => {
    console.log('We will try return a test string here');
    const res = {
      result: 'Success',
      transaction: {
        id: 123546,
        name: 'confirmCheckout',
        transref: 'abcde',
        amount: '123.45',
      },
      custSlip: {
        content: 'Print job goes here',
      },
      merchSlip: {
        content: 'Print job goes here',
      }
    }

    ResultModule.returnResult(true, JSON.stringify(res));
  };

  onCancelPress = () => {
    console.log('We will try return cancelled status');
    ResultModule.returnResult(false, '');
  };

  render() {
    const devId = this.props.auth ? this.props.auth.devId : 'N/A';
    const serial = this.props.auth ? this.props.auth.serial : 'N/A';
    const userPin = this.props.auth ? this.props.auth.userPin : 'N/A';
    const target = this.props.target;
    const theme = this.props.theme;
    const url = this.props.server ? this.props.server.url : 'N/A';
    const token = this.props.server ? this.props.server.token : 'N/A';

    return (
        <View style={styling.container}>
          <Text>Properties received from Bludroid:</Text>
          <Text>Device ID: {devId}</Text>
          <Text>Serial Number: {serial}</Text>
          <Text>User PIN: {userPin}</Text>
          <Text>Target Module: {target}</Text>
          <Text>Theme: {theme}</Text>
          <Text>Url: {url}</Text>
          <Text>Token: {token}</Text>
          <Text/>
          <Button
              title="Send Success"
              color="#841584"
              onPress={this.onPress}
          />
          <Text/>
          <Button
              title="Send Cancel"
              color="#841584"
              onPress={this.onCancelPress}
          />
        </View>
    );
  }
}

