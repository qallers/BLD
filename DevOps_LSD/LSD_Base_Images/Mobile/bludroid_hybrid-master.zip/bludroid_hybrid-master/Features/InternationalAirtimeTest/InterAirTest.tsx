import * as React from 'react';
import {Component} from 'react';
import {Button, Text, View,} from 'react-native';
import styling from './InterAirTest.style';
import {NavigationContainer} from "@react-navigation/native";
import {createStackNavigator} from "@react-navigation/stack";
import ResultModule from "../../modules/results/ResultModule";


const Stack = createStackNavigator();

interface Props {
  auth: AuthProps;
  theme: string;
  target: string;
  extra: any;
}

interface AuthProps {
  devId: string;
  serial: string;
  userPin: string;
  userLevel: string;
}

export function InterAirTestNavigation(propsIn: any) {
  return (
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name="International Airtime Test">
            {() => <InterAirTestScreen auth={propsIn.auth} target={propsIn.target} theme={propsIn.theme} extra={propsIn.extra}/>}
          </Stack.Screen>
        </Stack.Navigator>
      </NavigationContainer>
  );
}

export default class InterAirTestScreen extends Component<Props> {
  constructor(props: any) {
    super(props);
    console.log('International Airtime Test props', props);
  }

  onPress = () => {
    console.log('We will try return a test string here');
    const res = {
      result: 'Success',
      transaction: {
        id: 123546,
        name: 'Global Airtime',
        productName: 'IPay',
        transref: '86809',
        reference: '29149_1539163763756',
        // reference: this.props.auth.devId + '_' + new Date().getTime(),
        amount: '123.45',
      },
      custSlip: '{"printjob":[{"type":"image","url":"https://i.imgur.com/EHeuVSD.gif","id":"0","align":"center"},{"type":"text","align":"center","style":"normal","size":"normal","value":"Blu Approved - the power of"},{"type":"text","align":"center","style":"normal","size":"normal","value":"prepaid"},{"type":"line"},{"type":"text","align":"center","style":"bold","size":"normal","value":"Michael\'s Test Devices"},{"type":"text","align":"center","style":"bold","size":"normal","value":"Global Online Topup"},{"type":"line"},{"type":"text","align":"center","style":"bold","size":"normal","value":"IPay"},{"type":"text","align":"left","style":"normal","size":"normal","value":""},{"type":"text","align":"center","style":"normal","size":"normal","value":"2021-04-28 13:19:00"},{"type":"text","align":"left","style":"normal","size":"normal","value":""},{"type":"text","align":"left","style":"normal","size":"normal","value":"Phone Number : 2650000000"},{"type":"text","align":"left","style":"normal","size":"normal","value":"Amount       : 10.00"},{"type":"text","align":"left","style":"normal","size":"normal","value":"Voucher ID   : 86809"},{"type":"line"},{"type":"text","align":"left","style":"bold","size":"normal","value":"Tender Amount:                 8"},{"type":"line"},{"type":"text","align":"center","style":"normal","size":"normal","value":"- Print Done -"},{"type":"text","align":"left","style":"normal","size":"normal","value":""},{"type":"text","align":"left","style":"normal","size":"normal","value":""},{"type":"text","align":"left","style":"normal","size":"normal","value":""}]}',
      merchSlip: '{"printjob":[{"type":"text","align":"center","style":"bold","size":"normal","value":"Michael\'s Test Devices"},{"type":"text","align":"center","style":"bold","size":"normal","value":"Merchant Receipt - IPay"},{"type":"line"},{"type":"text","align":"left","style":"normal","size":"normal","value":"Device Name: BuildBot Test"},{"type":"text","align":"left","style":"normal","size":"normal","value":"Device"},{"type":"text","align":"left","style":"normal","size":"normal","value":"Product    : Global Online Topup"},{"type":"text","align":"left","style":"normal","size":"normal","value":"Amount     :               10.00"},{"type":"text","align":"left","style":"normal","size":"normal","value":"Ref        :               86809"},{"type":"text","align":"left","style":"normal","size":"normal","value":"Date       : 28/04/2021 13:19:02"},{"type":"text","align":"left","style":"normal","size":"normal","value":"Cashier    :          Supervisor"},{"type":"text","align":"left","style":"normal","size":"normal","value":"Shift ID   :                   1"},{"type":"text","align":"left","style":"normal","size":"normal","value":"TransSeq   :                 174"},{"type":"line"},{"type":"text","align":"center","style":"normal","size":"normal","value":"- Print Done -"},{"type":"text","align":"left","style":"normal","size":"normal","value":""},{"type":"text","align":"left","style":"normal","size":"normal","value":""},{"type":"text","align":"left","style":"normal","size":"normal","value":""}]}'
    }

    ResultModule.returnResult(true, JSON.stringify(res));
  };

  onCancelPress = () => {
    console.log('We will try return cancelled status');
    ResultModule.returnResult(false, '');
  };

  render() {
    const devId = this.props.auth ? this.props.auth.devId : 'N/A';
    const serial = this.props.auth ? this.props.auth.serial : 'N/A';
    const userPin = this.props.auth ? this.props.auth.userPin : 'N/A';
    const userLevel = this.props.auth ? this.props.auth.userLevel : 'N/A';
    const theme = this.props.theme ? this.props.theme : 'N/A';
    const target = this.props.target ? this.props.target : 'N/A';
    const extra = this.props.extra ? this.props.extra : 'N/A';

    return (
        <View style={styling.container}>
          <Text>Properties received from Bludroid:</Text>
          <Text>Device ID: {devId}</Text>
          <Text>Serial Number: {serial}</Text>
          <Text>User PIN: {userPin}</Text>
          <Text>User Level: {userLevel}</Text>
          <Text>Theme: {theme}</Text>
          <Text>Target Module: {target}</Text>
          <Text>Extra: {extra}</Text>
          <Text/>
          <Button
              title="Send Success"
              color="#841584"
              onPress={this.onPress}
          />
          <Text/>
          <Button
              title="Send Cancel"
              color="#841584"
              onPress={this.onCancelPress}
          />
        </View>
    );
  }
}

