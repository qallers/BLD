import {StatusBar} from 'expo-status-bar';
import React, {useState} from 'react';
import {
  Keyboard,
  KeyboardAvoidingView,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableWithoutFeedback,
  View,
  TouchableOpacity,
  Image,
  TextInput,
} from 'react-native';
import styling from './Cance.style';

export default function Confirm({navigation, route}: any) {
  const [cellNumber, setCellphoneNumber] = useState('');
  const [name, setName] = useState('');
  const [checked, setChecked] = React.useState('first');
  const confirm = () => {};

  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={styling.container}>
        <View
          style={{
            backgroundColor: 'white',
            width: '100%',
            borderRadius: 12,
            marginBottom: 10,
            flexDirection: 'row',
            marginTop: -300,
          }}
        >
          <View style={{marginVertical: 50}}>
            <Image
              style={{height: 18, width: 90}}
              source={require('../../../assets/putco.png')}
            />
          </View>
          <View style={{left: 150}}>
            <Text style={styling.text}>{route.params.params.type}</Text>
            <Text style={styling.text}>R{route.params.params.price}</Text>
          </View>
        </View>
      </View>

      <View style={styling.containerInputs}>
        <TouchableOpacity
          onPress={() => navigation.navigate('Tickets')}
          style={styling.buttonContainer}
        >
          <Text style={styling.buttonText}>Done</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
