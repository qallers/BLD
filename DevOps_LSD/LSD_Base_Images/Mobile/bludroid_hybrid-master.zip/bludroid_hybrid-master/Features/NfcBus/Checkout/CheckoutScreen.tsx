import * as React from 'react';
import {Component} from 'react';

import {Box} from '../../../Components/Box';
import {wPerc} from '../../../helpers/DeviceScalling';
import {Label} from '../Form/Form.style';
import {
  Button,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
} from 'react-native';
import {DeviceLibNfc} from 'react-native-device-lib-nfc';
import {useNavigation} from '@react-navigation/native';
import ApolloClient, {from} from 'apollo-boost';
import gql from 'graphql-tag';
type destination = {
  locationId: string;
  type: string;
  stationId: string;
  entityId: string;
  name: string;
};
type carrier = {
  name: string;
  shortName: string;
  companyId: string;
  role: string;
  type: string;
};
type Fare = {
  id: number;
  sessionId: String;
  responseCode: Number;
  responseMessage: String;
  status: Number;
  period: String;
  routeId2: String;
  fareProductId: string;
  code: String;
  routeId1: String;
  companyId: Number;
  weekdays: String;
  created: Date;
  availableFrom: Date;
  availableTo: Date;
  transferCount: Number;
  passValue: Number;
  tripsPerDay: Number;
  passType: String;
  price: Number;
  name: String;
  shortName: String;
  desc: String;
};
type stop = {
  name: string;
  id: string;
  __typename: string;
};

interface Props {
  cardId: string | null;
  selectedCarrier: carrier | null;
  depature: stop | null;
  destination: destination | null;
  selectedFare: Fare | null;
}

export default class CheckoutScreen extends Component<Props> {
  constructor(props: any) {
    super(props);
  }

  state = {
    dialog: false,
    dialogMessage: 'Please wait',
    result: 'Debug info goes here',
  };

  requestCheckout = () => {
    const client = new ApolloClient({uri: 'http://192.168.8.107:5000/graphql'});
    client
      .mutate({
        mutation: gql`
          mutation {
            tickets(
              input: {
                uid: "HUIJNMK26TJNB"
                ticketType: "day_pass"
                referenceId: "Ticket2"
                fareProductId: "1"
                amount: "100"
                companyId: "100010"
                svcData: {
                  sector10: {
                    block0: "5648595544547052544C70746A575752"
                    block1: "6A443031453554374D72494F37614542"
                    block2: "4E394D47712F5574514676682B305A44"
                  }
                  sector11: {
                    block0: "41633779646348743544536745786553"
                    block1: "313476724E706666582F63326F526D62"
                    block2: "4E4633742F7356616958753632595643"
                  }
                  sector12: {
                    block0: "316A77674657356B6F48553677416C39"
                    block1: "30554354387263375A4B30525069555A"
                    block2: "00000000000000000000000000000000"
                  }
                  sector13: {
                    block0: "416efc00000000000000000000000000"
                    block1: "00000000000000000000000000000000"
                    block2: "00000000000000000000000000000000"
                  }
                }
              }
              auth: {
                deviceId: "29851"
                serialNum: "p130189801394"
                userPin: "011234"
                location: ""
                swVer: "bluShift"
              }
            ) {
              totalCount
              edges {
                node {
                  numberOfDaysTrips
                  ticketId
                  ticketNo
                  destinationLocationId
                  departureLocationId
                  fare
                  fareCurrency
                  ticketType
                  expiryDate
                  activationDate
                  numberOfDaysTrips
                }
              }
            }
          }
        `,
      })
      .then((response) => {
        // this.props.setTickets(response.data.tickets.edges);
        // this.props.setCount(response.data.tickets.totalCount);
        this.setState({user_tickets: response.data.tickets.edges});
        this.setState({ticket_count: response.data.tickets.totalCount});
        console.log('nodes: ' + JSON.stringify(response.data.tickets.edges));
      })
      .catch(function (error) {
        console.log('problem with send request: ' + error.message);
        throw error;
      });
  };
  getUid = () => {
    console.log('getUid');
    console.log('DeviceLibNfc = ' + DeviceLibNfc);
    this.setState({dialog: true, dialogMessage: 'Get UID'}, () => {
      DeviceLibNfc.nfcReadUid()
        .then((result) => {
          console.log('result: ' + JSON.stringify(result));
          this.setState({result: JSON.stringify(result, null, 2)});
        })
        .catch((err) => {
          let msg = err.toString();
          console.log('error: ' + msg);
          this.setState({result: msg});
        })
        .finally(() => this.setState({dialog: false, dialogMessage: ''}));
    });
  };

  writeCard = (jsonString: any) => {
    console.log('writeCard: ' + jsonString);
    this.setState({dialog: true, dialogMessage: 'Write Card'}, () => {
      DeviceLibNfc.nfcWriteCard(jsonString)
        .then((result) => {
          console.log('result: ' + JSON.stringify(result));
          this.setState({result: JSON.stringify(result, null, 2)});
        })
        .catch((err) => {
          let msg = err.toString();
          console.log('error: ' + msg);
          this.setState({result: msg});
        })
        .finally(() => this.setState({dialog: false, dialogMessage: ''}));
    });
  };

  readCard = (jsonString: any) => {
    console.log('readCard: ' + jsonString);
    this.setState({dialog: true, dialogMessage: 'Read Card'}, () => {
      DeviceLibNfc.nfcReadCard(jsonString)
        .then((result) => {
          console.log('result: ' + JSON.stringify(result));
          this.setState({result: JSON.stringify(result, null, 2)});
          this.display();
        })
        .catch((err) => {
          let msg = err.toString();
          console.log('error: ' + msg);
          this.setState({result: msg});
        });
      //  .finally(() => this.setState({dialog: false, dialogMessage: ''}));
    });
  };

  cancel = () => {
    console.log('cancel transaction');
    DeviceLibNfc.nfcCancel();
    this.setState({dialog: false, dialogMessage: ''});
  };

  readFormat = () => {
    const job = require('../../../nfcjobs/nfcReadFormat.json');
    this.readCard(JSON.stringify(job));
  };

  writeFormat = () => {
    const job = require('../../../nfcjobs/nfcFormat.json');
    this.writeCard(JSON.stringify(job));
  };

  componentDidMount = () => {
    this.readFormat();
  };

  submit = () => {
    alert('Checkout in progress, please wait');
    // this.requestCheckout();
  };
  display = () => {
    // const {navigate} = this.props.navigation;

    var status = JSON.parse(this.state.result);
    status.status === 'SUCCESS'
      ? Alert.alert(
          'Status',
          'Card read success!',
          [
            {
              text: 'Cancel',
              onPress: () => console.log('Cancel Pressed'),
              style: 'cancel',
            },
            {
              text: 'OK',
              onPress: () => {
                this.submit();
              },
            },
          ],
          {cancelable: false}
        )
      : Alert.alert(
          'Card Status',
          'Card read failed, please try again later',
          [
            {
              text: 'Cancel',
              onPress: () => console.log('Cancel Pressed'),
              style: 'cancel',
            },
            {
              text: 'Register',
              // onPress: () => {Register()},
            },
          ],
          {cancelable: false}
        );
  };
  render() {
    return this.state.dialog ? (
      <NfcOperationDialog
        visible={this.state.dialog}
        message={this.state.dialogMessage}
        onPress={this.cancel}
      />
    ) : (
      <ScrollView style={styles.container}>
        <View style={{width: wPerc(95)}}></View>

        <View style={styles.buttonContainer}>
          <Text style={{fontFamily: 'monospace'}}>{this.state.result}</Text>
        </View>
      </ScrollView>
    );
  }
}

function GridButton({onPress, label}: {label: string; onPress: () => void}) {
  return (
    <TouchableOpacity onPress={onPress} style={{width: '25%'}}>
      <Box>
        <Box></Box>
        <Label>{label}</Label>
      </Box>
    </TouchableOpacity>
  );
}

const NfcOperationDialog = ({visible, message, onPress}: any) => (
  <Modal onRequestClose={() => null} visible={visible}>
    <View
      style={{
        flex: 1,
        backgroundColor: '#dcdcdc',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <View style={{borderRadius: 10, backgroundColor: 'white', padding: 25}}>
        <Text style={{fontSize: 20, fontWeight: '200', marginBottom: 20}}>
          {message}
        </Text>
        <Button title={'Cancel'} onPress={onPress} />
      </View>
    </View>
  </Modal>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 10,
  },
  buttonContainer: {
    margin: 10,
  },
  buttonRowContainer: {
    flexDirection: 'row',
    margin: 10,
  },
  buttonRow: {
    flex: 1,
    marginLeft: 5,
    marginRight: 5,
  },
});
