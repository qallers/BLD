import {graphql, useQuery} from 'relay-hooks';
import {StatusBar} from 'expo-status-bar';
import React, {useEffect, useRef, useState} from 'react';
import styling from './GetRoutes.style';
import * as yup from 'yup';
import {Picker} from 'react-native';
import {Device} from '../../../TestData/TestData';

import {
  Text,
  TouchableWithoutFeedback,
  View,
  TouchableOpacity,
  Image,
  TextInput,
  StyleSheet,
  Button,
  FlatList,
  Alert,
} from 'react-native';
import {Field, Formik} from 'formik';
import * as Yup from 'yup';
import ApolloClient from 'apollo-boost';
import gql from 'graphql-tag';
import {any} from 'prop-types';
import {CarriersQuery} from './__generated__/CarriersQuery.graphql';
import {Item} from 'react-native-paper/lib/typescript/components/List/List';

type stop = {
  name: string;
  id: string;
  __typename: string;
};

type carrier = {
  name: string;
  shortName: string;
  companyId: string;
  role: string;
  type: string;
};

type destination = {
  locationId: string;
  type: string;
  stationId: string;
  entityId: string;
  name: string;
};

interface Props {
  selectedCarrier: carrier;
  setSelectedCarrier: (value: {
    name: string;
    shortName: string;
    companyId: string;
    role: string;
    type: string;
  }) => void;
}

const validationSchema = yup.object().shape({
  depature: yup.string().required('This is a required field'),
  destination: yup
    .string()
    .required('This is a required field')
    .notOneOf(
      [yup.ref('depature')],
      'depature and destination cannot be the same'
    ),
});

const query = graphql`
  query CarriersQuery($input: BusAccount!) {
    carriers(input: $input) {
      totalCount
      pageInfo {
        hasNextPage
        hasPreviousPage
      }
      edges {
        cursor
        node {
          companyId
          shortName
          role
          type
          name
        }
      }
    }
  }
`;
export default function Carriers({setSelectedCarrier, selectedCarrier}: Props) {
  const {props, error, retry} = useQuery<CarriersQuery>(query, {
    input: Device,
  });

  const createErrorAlert = (message: any) => {
    Alert.alert(
      'Error',
      'Unable to get Bus Carriers, please try again later' + message
    );
  };
  const getItem = (item: carrier) => {
    console.log('selected carrier: ' + item.name);
    setSelectedCarrier(item);
  };
  const sel = (item: carrier) => {
    console.log('selected carrier: ' + item.name);
    setSelectedCarrier(item);
  };
  if (error) createErrorAlert(error.message);
  let list: any[] = [];
  if (props && props.carriers.edges) {
    const {
      carriers: {edges = []},
    } = props;
    list = props.carriers?.edges ? edges.map((edge) => edge.node) : [];
  }
  return (
    <View style={{top: 30, height: 50}}>
      <Picker
        style={{width: '100%'}}
        mode="dropdown"
        selectedValue={selectedCarrier.name}
        onValueChange={getItem}
      >
        <Picker.Item label="Select Carrier" value="none" />
        {list.length !== 0 ? (
          list.map((client) => {
            return <Picker.Item label={client.name} value={client} />;
          })
        ) : (
          <Picker.Item label="Loading Carriers..." value="0" />
        )}
      </Picker>
    </View>
  );
}
