/* tslint:disable */
/* eslint-disable */
// @ts-nocheck

import { ConcreteRequest } from "relay-runtime";
export type BusStopsInput = {
    companyId: string;
    auth: BusAccount;
};
export type BusAccount = {
    deviceId: string;
    serialNum: string;
    userPin: string;
    location: string;
    swVer: string;
};
export type DepaturesQueryVariables = {
    input: BusStopsInput;
};
export type DepaturesQueryResponse = {
    readonly stops: {
        readonly totalCount: number | null;
        readonly pageInfo: {
            readonly hasNextPage: boolean | null;
            readonly hasPreviousPage: boolean | null;
        } | null;
        readonly edges: ReadonlyArray<{
            readonly cursor: string | null;
            readonly node: {
                readonly id: string | null;
                readonly name: string;
            };
        }>;
    };
};
export type DepaturesQuery = {
    readonly response: DepaturesQueryResponse;
    readonly variables: DepaturesQueryVariables;
};



/*
query DepaturesQuery(
  $input: BusStopsInput!
) {
  stops(input: $input) {
    totalCount
    pageInfo {
      hasNextPage
      hasPreviousPage
    }
    edges {
      cursor
      node {
        id
        name
      }
    }
  }
}
*/

const node: ConcreteRequest = (function(){
var v0 = [
  {
    "defaultValue": null,
    "kind": "LocalArgument",
    "name": "input"
  }
],
v1 = [
  {
    "alias": null,
    "args": [
      {
        "kind": "Variable",
        "name": "input",
        "variableName": "input"
      }
    ],
    "concreteType": "BusStopsConnection",
    "kind": "LinkedField",
    "name": "stops",
    "plural": false,
    "selections": [
      {
        "alias": null,
        "args": null,
        "kind": "ScalarField",
        "name": "totalCount",
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "PageInfo",
        "kind": "LinkedField",
        "name": "pageInfo",
        "plural": false,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "hasNextPage",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "hasPreviousPage",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "BusStopsEdge",
        "kind": "LinkedField",
        "name": "edges",
        "plural": true,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "cursor",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "concreteType": "BusStopLocation",
            "kind": "LinkedField",
            "name": "node",
            "plural": false,
            "selections": [
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "id",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "name",
                "storageKey": null
              }
            ],
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "storageKey": null
  }
];
return {
  "fragment": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Fragment",
    "metadata": null,
    "name": "DepaturesQuery",
    "selections": (v1/*: any*/),
    "type": "Query",
    "abstractKey": null
  },
  "kind": "Request",
  "operation": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Operation",
    "name": "DepaturesQuery",
    "selections": (v1/*: any*/)
  },
  "params": {
    "cacheID": "05f6abc8df521a6dec97c65ef928cc1a",
    "id": null,
    "metadata": {},
    "name": "DepaturesQuery",
    "operationKind": "query",
    "text": "query DepaturesQuery(\n  $input: BusStopsInput!\n) {\n  stops(input: $input) {\n    totalCount\n    pageInfo {\n      hasNextPage\n      hasPreviousPage\n    }\n    edges {\n      cursor\n      node {\n        id\n        name\n      }\n    }\n  }\n}\n"
  }
};
})();
(node as any).hash = 'c07476a6fc5bcd9c781813729fb660c9';
export default node;
