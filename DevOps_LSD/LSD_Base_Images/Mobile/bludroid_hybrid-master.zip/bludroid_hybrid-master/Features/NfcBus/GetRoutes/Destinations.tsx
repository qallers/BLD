import {graphql, useQuery} from 'relay-hooks';
import {StatusBar} from 'expo-status-bar';
import React, {useEffect, useRef, useState} from 'react';
import {Device} from '../../../TestData/TestData';
import styling from './GetRoutes.style';
import * as yup from 'yup';
import {Picker} from 'react-native';

import {
  Text,
  TouchableWithoutFeedback,
  View,
  TouchableOpacity,
  Image,
  TextInput,
  StyleSheet,
  Button,
  FlatList,
  Alert,
} from 'react-native';
import {Field, Formik} from 'formik';
import * as Yup from 'yup';
import ApolloClient from 'apollo-boost';
import gql from 'graphql-tag';
import {any} from 'prop-types';
import {DestinationsQuery} from './__generated__/DestinationsQuery.graphql';
//import {black} from 'react-native-paper/lib/typescript/styles/colors';
//import {Item} from 'react-native-paper/lib/typescript/src/components/List/List';

type stop = {
  name: string;
  id: string;
  __typename: string;
};

type carrier = {
  name: string;
  shortName: string;
  companyId: string;
  role: string;
  type: string;
};

type destination = {
  locationId: string;
  type: string;
  stationId: string;
  entityId: string;
  name: string;
};

interface Props {
  selectedCarrier: carrier;
  depature: stop;
  destination: destination | null;
  setDestination: (value: {
    locationId: string;
    type: string;
    stationId: string;
    entityId: string;
    name: string;
  }) => void;
}

const validationSchema = yup.object().shape({
  depature: yup.string().required('This is a required field'),
  destination: yup
    .string()
    .required('This is a required field')
    .notOneOf(
      [yup.ref('depature')],
      'depature and destination cannot be the same'
    ),
});

const query = graphql`
  query DestinationsQuery(
    $companyId: ID!
    $departureLocationId: String!
    $auth: BusAccount!
  ) {
    destinations(
      companyId: $companyId
      departureLocationId: $departureLocationId
      auth: $auth
    ) {
      totalCount
      pageInfo {
        hasNextPage
        hasPreviousPage
      }
      edges {
        cursor
        node {
          locationId
          type
          stationId
          entityId
          name
        }
      }
    }
  }
`;

export default function Destinations({
  depature,
  destination,
  setDestination,
  selectedCarrier,
}: Props) {
  const {props, error, retry} = useQuery<DestinationsQuery>(query, {
    companyId: selectedCarrier?.companyId,
    departureLocationId: depature?.id,
    auth: Device,
  });

  const createErrorAlert = (message: any) => {
    Alert.alert(
      'Error',
      'Unable to get Bus Carriers, please try again later' + message
    );
  };
  const getItem = (item: destination) => {
    setDestination(item);
  };

  if (error) createErrorAlert(error.message);
  let list: any[] = [];
  if (props && props.destinations.edges) {
    const {
      destinations: {edges = []},
    } = props;
    list = props.destinations?.edges ? edges.map((edge) => edge.node) : [];
  }
  return (
    <View style={{top: 100, height: 50}}>
      <Picker
        style={{width: '100%'}}
        mode="dropdown"
        selectedValue={destination}
        onValueChange={getItem}
      >
        {list.length !== 0 ? (
          list.map((client) => {
            return <Picker.Item label={client.name} value={client} />;
          })
        ) : (
          <Picker.Item label="Loading Destinations..." value="0" />
        )}
      </Picker>
    </View>
  );
}
