/* tslint:disable */
/* eslint-disable */
// @ts-nocheck

import { ConcreteRequest } from "relay-runtime";
export type BusAccount = {
    deviceId: string;
    serialNum: string;
    userPin: string;
    location: string;
    swVer: string;
};
export type CarriersQueryVariables = {
    input: BusAccount;
};
export type CarriersQueryResponse = {
    readonly carriers: {
        readonly totalCount: number | null;
        readonly pageInfo: {
            readonly hasNextPage: boolean | null;
            readonly hasPreviousPage: boolean | null;
        } | null;
        readonly edges: ReadonlyArray<{
            readonly cursor: string | null;
            readonly node: {
                readonly companyId: string | null;
                readonly shortName: string | null;
                readonly role: string | null;
                readonly type: string | null;
                readonly name: string | null;
            };
        }>;
    };
};
export type CarriersQuery = {
    readonly response: CarriersQueryResponse;
    readonly variables: CarriersQueryVariables;
};



/*
query CarriersQuery(
  $input: BusAccount!
) {
  carriers(input: $input) {
    totalCount
    pageInfo {
      hasNextPage
      hasPreviousPage
    }
    edges {
      cursor
      node {
        companyId
        shortName
        role
        type
        name
      }
    }
  }
}
*/

const node: ConcreteRequest = (function(){
var v0 = [
  {
    "defaultValue": null,
    "kind": "LocalArgument",
    "name": "input"
  }
],
v1 = [
  {
    "alias": null,
    "args": [
      {
        "kind": "Variable",
        "name": "input",
        "variableName": "input"
      }
    ],
    "concreteType": "BusCarriersConnection",
    "kind": "LinkedField",
    "name": "carriers",
    "plural": false,
    "selections": [
      {
        "alias": null,
        "args": null,
        "kind": "ScalarField",
        "name": "totalCount",
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "PageInfo",
        "kind": "LinkedField",
        "name": "pageInfo",
        "plural": false,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "hasNextPage",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "hasPreviousPage",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "BusCarriersEdge",
        "kind": "LinkedField",
        "name": "edges",
        "plural": true,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "cursor",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "concreteType": "BusCarrierLocation",
            "kind": "LinkedField",
            "name": "node",
            "plural": false,
            "selections": [
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "companyId",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "shortName",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "role",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "type",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "name",
                "storageKey": null
              }
            ],
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "storageKey": null
  }
];
return {
  "fragment": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Fragment",
    "metadata": null,
    "name": "CarriersQuery",
    "selections": (v1/*: any*/),
    "type": "Query",
    "abstractKey": null
  },
  "kind": "Request",
  "operation": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Operation",
    "name": "CarriersQuery",
    "selections": (v1/*: any*/)
  },
  "params": {
    "cacheID": "924716cb2e4ac16a650cce66a345c769",
    "id": null,
    "metadata": {},
    "name": "CarriersQuery",
    "operationKind": "query",
    "text": "query CarriersQuery(\n  $input: BusAccount!\n) {\n  carriers(input: $input) {\n    totalCount\n    pageInfo {\n      hasNextPage\n      hasPreviousPage\n    }\n    edges {\n      cursor\n      node {\n        companyId\n        shortName\n        role\n        type\n        name\n      }\n    }\n  }\n}\n"
  }
};
})();
(node as any).hash = '7ae3afb948cad97ddba73b742ab5b452';
export default node;
