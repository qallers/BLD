/* tslint:disable */
/* eslint-disable */
// @ts-nocheck

import { ConcreteRequest } from "relay-runtime";
export type BusAccount = {
    deviceId: string;
    serialNum: string;
    userPin: string;
    location: string;
    swVer: string;
};
export type DestinationsQueryVariables = {
    companyId: string;
    departureLocationId: string;
    auth: BusAccount;
};
export type DestinationsQueryResponse = {
    readonly destinations: {
        readonly totalCount: number | null;
        readonly pageInfo: {
            readonly hasNextPage: boolean | null;
            readonly hasPreviousPage: boolean | null;
        } | null;
        readonly edges: ReadonlyArray<{
            readonly cursor: string | null;
            readonly node: {
                readonly locationId: string | null;
                readonly type: string | null;
                readonly stationId: string | null;
                readonly entityId: string | null;
                readonly name: string | null;
            };
        }>;
    };
};
export type DestinationsQuery = {
    readonly response: DestinationsQueryResponse;
    readonly variables: DestinationsQueryVariables;
};



/*
query DestinationsQuery(
  $companyId: ID!
  $departureLocationId: String!
  $auth: BusAccount!
) {
  destinations(companyId: $companyId, departureLocationId: $departureLocationId, auth: $auth) {
    totalCount
    pageInfo {
      hasNextPage
      hasPreviousPage
    }
    edges {
      cursor
      node {
        locationId
        type
        stationId
        entityId
        name
      }
    }
  }
}
*/

const node: ConcreteRequest = (function(){
var v0 = {
  "defaultValue": null,
  "kind": "LocalArgument",
  "name": "auth"
},
v1 = {
  "defaultValue": null,
  "kind": "LocalArgument",
  "name": "companyId"
},
v2 = {
  "defaultValue": null,
  "kind": "LocalArgument",
  "name": "departureLocationId"
},
v3 = [
  {
    "alias": null,
    "args": [
      {
        "kind": "Variable",
        "name": "auth",
        "variableName": "auth"
      },
      {
        "kind": "Variable",
        "name": "companyId",
        "variableName": "companyId"
      },
      {
        "kind": "Variable",
        "name": "departureLocationId",
        "variableName": "departureLocationId"
      }
    ],
    "concreteType": "BusDestinationsConnection",
    "kind": "LinkedField",
    "name": "destinations",
    "plural": false,
    "selections": [
      {
        "alias": null,
        "args": null,
        "kind": "ScalarField",
        "name": "totalCount",
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "PageInfo",
        "kind": "LinkedField",
        "name": "pageInfo",
        "plural": false,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "hasNextPage",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "hasPreviousPage",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "BusDestinationsEdge",
        "kind": "LinkedField",
        "name": "edges",
        "plural": true,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "cursor",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "concreteType": "BusDestinationLocation",
            "kind": "LinkedField",
            "name": "node",
            "plural": false,
            "selections": [
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "locationId",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "type",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "stationId",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "entityId",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "name",
                "storageKey": null
              }
            ],
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "storageKey": null
  }
];
return {
  "fragment": {
    "argumentDefinitions": [
      (v0/*: any*/),
      (v1/*: any*/),
      (v2/*: any*/)
    ],
    "kind": "Fragment",
    "metadata": null,
    "name": "DestinationsQuery",
    "selections": (v3/*: any*/),
    "type": "Query",
    "abstractKey": null
  },
  "kind": "Request",
  "operation": {
    "argumentDefinitions": [
      (v1/*: any*/),
      (v2/*: any*/),
      (v0/*: any*/)
    ],
    "kind": "Operation",
    "name": "DestinationsQuery",
    "selections": (v3/*: any*/)
  },
  "params": {
    "cacheID": "513f66e0ed8d78252a9cdbc1c4539b3b",
    "id": null,
    "metadata": {},
    "name": "DestinationsQuery",
    "operationKind": "query",
    "text": "query DestinationsQuery(\n  $companyId: ID!\n  $departureLocationId: String!\n  $auth: BusAccount!\n) {\n  destinations(companyId: $companyId, departureLocationId: $departureLocationId, auth: $auth) {\n    totalCount\n    pageInfo {\n      hasNextPage\n      hasPreviousPage\n    }\n    edges {\n      cursor\n      node {\n        locationId\n        type\n        stationId\n        entityId\n        name\n      }\n    }\n  }\n}\n"
  }
};
})();
(node as any).hash = 'cb4d155089ab355190a10fc01c0cc3c1';
export default node;
