import {StatusBar} from 'expo-status-bar';
import React, {useEffect, useRef, useState} from 'react';
import styling from './GetRoutes.style';
import * as yup from 'yup';
import {Picker} from 'react-native';

import {
  Text,
  TouchableWithoutFeedback,
  View,
  TouchableOpacity,
  Image,
  TextInput,
  StyleSheet,
  Button,
  FlatList,
  Alert,
} from 'react-native';
import {Field, Formik} from 'formik';
import * as Yup from 'yup';
import ApolloClient from 'apollo-boost';
import gql from 'graphql-tag';
import {any} from 'prop-types';
import Carriers from './Carriers';
import Depatures from './Depatures';
import Destinations from './Destinations';

type stop = {
  name: string;
  id: string;
  __typename: string;
};

type carrier = {
  name: string;
  shortName: string;
  companyId: string;
  role: string;
  type: string;
};

type destination = {
  locationId: string;
  type: string;
  stationId: string;
  entityId: string;
  name: string;
};

interface Props {
  setCurrentScreen: (value: number) => void;
  selectedCarrier: carrier;
  depature: stop;
  setDepature: (value: {name: string; id: string; __typename: string}) => void;
  destination: destination | null;
  setDestination: (value: {
    locationId: string;
    type: string;
    stationId: string;
    entityId: string;
    name: string;
  }) => void;
  setSelectedCarrier: (value: {
    name: string;
    shortName: string;
    companyId: string;
    role: string;
    type: string;
  }) => void;
}

const validationSchema = yup.object().shape({
  depature: yup.string().required('This is a required field'),
  destination: yup
    .string()
    .required('This is a required field')
    .notOneOf(
      [yup.ref('depature')],
      'depature and destination cannot be the same'
    ),
});

export default function GetRoutes({
  depature,
  setDepature,
  destination,
  setDestination,
  setCurrentScreen,
  selectedCarrier,
  setSelectedCarrier,
}: Props) {
  return (
    <View style={{flex: 1}}>
      <Text style={{fontSize: 17, top: 20, color: 'navy'}}>Select Carrier</Text>
      <Carriers
        selectedCarrier={selectedCarrier}
        setSelectedCarrier={setSelectedCarrier}
      />
      <Text style={{fontSize: 17, top: 50, color: 'navy'}}>
        Select Depature
      </Text>
      <Depatures
        depature={depature}
        setDepature={setDepature}
        selectedCarrier={selectedCarrier}
      />
      <Text style={{fontSize: 17, top: 80, color: 'navy'}}>
        Select Destination
      </Text>
      <Destinations
        depature={depature}
        destination={destination}
        setDestination={setDestination}
        selectedCarrier={selectedCarrier}
      />
    </View>
  );
}
