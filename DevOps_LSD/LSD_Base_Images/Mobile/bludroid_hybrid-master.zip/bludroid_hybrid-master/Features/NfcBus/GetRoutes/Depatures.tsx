import {graphql, useQuery} from 'relay-hooks';
import {StatusBar} from 'expo-status-bar';
import React, {useEffect, useRef, useState} from 'react';
import styling from './GetRoutes.style';
import * as yup from 'yup';
import {Device} from '../../../TestData/TestData';
import {Picker} from 'react-native';

import {
  Text,
  TouchableWithoutFeedback,
  View,
  TouchableOpacity,
  Image,
  TextInput,
  StyleSheet,
  Button,
  FlatList,
  Alert,
} from 'react-native';
import {Field, Formik} from 'formik';
import * as Yup from 'yup';
import ApolloClient from 'apollo-boost';
import gql from 'graphql-tag';
import {any} from 'prop-types';
import {DepaturesQuery} from './__generated__/DepaturesQuery.graphql';

type stop = {
  name: string;
  id: string;
  __typename: string;
};

type carrier = {
  name: string;
  shortName: string;
  companyId: string;
  role: string;
  type: string;
};

type destination = {
  locationId: string;
  type: string;
  stationId: string;
  entityId: string;
  name: string;
};

interface Props {
  selectedCarrier: carrier;
  depature: stop | null;
  setDepature: (value: {name: string; id: string; __typename: string}) => void;
}

const validationSchema = yup.object().shape({
  depature: yup.string().required('This is a required field'),
  destination: yup
    .string()
    .required('This is a required field')
    .notOneOf(
      [yup.ref('depature')],
      'depature and destination cannot be the same'
    ),
});

const query = graphql`
  query DepaturesQuery($input: BusStopsInput!) {
    stops(input: $input) {
      totalCount
      pageInfo {
        hasNextPage
        hasPreviousPage
      }
      edges {
        cursor
        node {
          id
          name
        }
      }
    }
  }
`;
export default function Depatures({
  depature,
  setDepature,
  selectedCarrier,
}: Props) {
  const {props, error, retry} = useQuery<DepaturesQuery>(query, {
    input: {
      companyId: selectedCarrier.companyId,
      auth: Device,
    },
  });

  const createErrorAlert = (message: any) => {
    Alert.alert(
      'Error',
      'Unable to get Bus Carriers, please try again later' + message
    );
  };
  const getItem = (item: stop) => {
    setDepature(item);
  };

  if (error) createErrorAlert(error.message);
  let list: any[] = [];
  if (props && props.stops.edges) {
    const {
      stops: {edges = []},
    } = props;
    list = props.stops?.edges ? edges.map((edge) => edge.node) : [];
  }
  return (
    <View style={{top: 65, height: 50}}>
      <Picker
        style={{width: '100%'}}
        mode="dropdown"
        selectedValue={depature}
        onValueChange={getItem}
      >
        {list.length !== 0 ? (
          list.map((client) => {
            return <Picker.Item label={client.name} value={client} />;
          })
        ) : (
          <Picker.Item label="Loading Depatures..." value="0" />
        )}
      </Picker>
    </View>
  );
}
