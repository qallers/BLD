import {StatusBar} from 'expo-status-bar';
import React, {useState} from 'react';
import styling from './LoginStyle';
import {
  Keyboard,
  KeyboardAvoidingView,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableWithoutFeedback,
  View,
  TouchableOpacity,
  Image,
  TextInput,
} from 'react-native';

interface Props {
  svcNumber: string;
  setSvcNumber: (value: string) => void;
}

export default function LoginScreen({svcNumber, setSvcNumber}: Props) {
  return (
    <View style={styling.logoContainer}>
      <View style={styling.logoContainer}>
        <Image
          style={styling.logo}
          source={require('../../../assets/logo.png')}
        ></Image>
      </View>
      <View style={styling.containerInputs}>
        <TextInput
          style={styling.inputField}
          placeholder="Password:"
          placeholderTextColor="grey"
          defaultValue={svcNumber}
          onChangeText={(number) => setSvcNumber(number)}
        ></TextInput>
      </View>
    </View>
  );
}
