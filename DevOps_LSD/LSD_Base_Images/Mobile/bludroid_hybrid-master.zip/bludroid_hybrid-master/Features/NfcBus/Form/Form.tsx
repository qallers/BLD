import React, {useState} from 'react';
import Carriers from '../Carriers/CarriesList';
import {
  Button,
  Text,
  View,
  Image,
  TouchableOpacity,
  Dimensions,
  StyleSheet,
  Picker,
} from 'react-native';
import {
  HeaderButtons,
  HeaderButton,
  Item,
  HiddenItem,
  OverflowMenu,
} from 'react-navigation-header-buttons';
import {
  BottomView,
  Carousel,
  Container,
  ContainerInner,
  Label,
  LabelContainer,
} from './Form.style';
import {Stepper} from '../../../Components/Steppers';
import {Box} from '../../../Components/Box';
import {wPerc} from '../../../helpers/DeviceScalling';

export default function Form({navigation, route}: any) {
  const [depature, setDepature] = useState('');
  const [destination, setDestination] = useState('');
  const [cellNumber, setCellphoneNumber] = useState('');
  const [name, setName] = useState('');
  const [checked, setChecked] = React.useState('first');
  const [interval, setInterval] = useState(1);
  const [width, setWidth] = useState(0);
  const confirm = () => {};
  const intervals = 3;
  const init = (width: number) => {
    // initialise width
    setWidth(width);
  };

  const getInterval = (offset: number) => {
    for (let i = 1; i <= intervals; i++) {
      if (offset < (width / intervals) * i) {
        return i;
      }
      if (i == intervals) {
        return i;
      }
    }
    return intervals;
  };

  return (
    <Container>
      <View
        style={{
          height: 150,
          width: 100,
          marginTop: -3,
          backgroundColor: 'white',
        }}
      >
        <Image
          source={require('../../../assets/putco.png')}
          style={{width: 100, height: 50}}
        />
      </View>
      <LabelContainer>
        <Label>Search Routes</Label>
        <ContainerInner>
          <Carousel
            horizontal={true}
            contentContainerStyle={{
              width: `${100 * intervals}%`,
              paddingBottom: '10%',
            }}
            showsHorizontalScrollIndicator={false}
            onContentSizeChange={(w: number) => init(w)}
            scrollEventThrottle={200}
            decelerationRate="fast"
            onScroll={(data: any) => {
              setWidth(data.nativeEvent.contentSize.width);
              setInterval(getInterval(data.nativeEvent.contentOffset.x));
            }}
            pagingEnabled
          >
            <View style={{width: wPerc(95)}}>
              <View>
                <View
                  style={{
                    top: 20,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Text> Depature :</Text>
                  <View
                    style={{
                      borderRadius: 10,
                      borderWidth: 1,
                      borderColor: 'navy',
                      overflow: 'hidden',
                    }}
                  >
                    <Picker
                      selectedValue={depature}
                      style={{
                        height: 50,
                        width: 350,
                        borderColor: 'red',
                      }}
                      onValueChange={(val) => setDepature(val)}
                    >
                      <Picker.Item label="Cape Town" value="Cape Town" />
                      <Picker.Item label="Johannesburg" value="Johannesburg" />
                      <Picker.Item label="Soweto" value="Soweto" />
                      <Picker.Item label="Midrand" value="Midrand" />
                      <Picker.Item label="Sandton" value="Sandton" />
                      <Picker.Item label="Bellville" value="Bellville" />
                    </Picker>
                  </View>
                  <Text style={{}}> Destination :</Text>
                  <View
                    style={{
                      borderRadius: 10,
                      borderWidth: 1,
                      borderColor: 'navy',
                      overflow: 'hidden',
                    }}
                  >
                    <Picker
                      selectedValue={destination}
                      style={{
                        height: 50,
                        width: 350,
                        borderColor: 'red',
                      }}
                      onValueChange={(val) => setDestination(val)}
                    >
                      <Picker.Item label="Cape Town" value="Cape Town" />
                      <Picker.Item label="Johannesburg" value="Johannesburg" />
                      <Picker.Item label="Soweto" value="Soweto" />
                      <Picker.Item label="Midrand" value="Midrand" />
                      <Picker.Item label="Sandton" value="Sandton" />
                      <Picker.Item label="Bellville" value="Bellville" />
                    </Picker>
                  </View>

                  <View style={{}}>
                    <TouchableOpacity
                      onPress={() =>
                        navigation.navigate('Carries', {
                          screen: 'Carries',
                          params: {
                            depature: depature,
                            destination: destination,
                          },
                        })
                      }
                      style={{}}
                    >
                      <Text style={{}}>Get Route</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>
            <View>
              <Carriers />
            </View>
          </Carousel>
          <BottomView>
            <Stepper step={interval} total={intervals} />
          </BottomView>
        </ContainerInner>
      </LabelContainer>
    </Container>
  );
}
