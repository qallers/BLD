import styled from 'styled-components';
import {View, TouchableOpacity, ScrollView, Text} from 'react-native';
import {fdp, hPerc, wdp} from '../../../helpers/DeviceScalling';

export const Container = styled(View)`
  flex: 1;
  background-color: #f2f2f2;
  padding: ${wdp(10)}px;
`;

export const ButtonContainer = styled(View)`
  margin-top: ${wdp(5)}px;
`;

export const LabelContainer = styled(View)`
  margin-top: ${wdp(10)}px;
  height: ${hPerc(70) - wdp(40)}px;
`;

export const Label = styled(Text)`
  color: ${({theme}) => theme.colors.textGreyed} 
  margin-bottom: ${wdp(10)}px
`;

export const ContainerInner = styled(View)`
  flex: 1;
  background-color: white;
  align-items: center;
  justify-content: center;
  border-radius: ${wdp(8)}px;
  overflow: hidden;
  font-size: ${fdp(12)}px;
  line-height: ${fdp(14)}px;
  justify-content: flex-start;
`;

export const BottomView = styled(View)`
  position: absolute;
  bottom: ${wdp(16)}px;
`;

export const Carousel = styled(ScrollView)`
  max-height: 90%;
  border-bottom-color: ${({theme}) => theme.colors.fgGreyed};
  border-bottom-width: ${wdp(1)}px;
`;
