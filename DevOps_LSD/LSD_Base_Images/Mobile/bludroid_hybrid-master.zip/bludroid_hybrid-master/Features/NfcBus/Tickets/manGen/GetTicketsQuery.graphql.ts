/* tslint:disable */
/* eslint-disable */
// @ts-nocheck
import {ConcreteRequest} from 'relay-runtime';

 export type BusAccount = {
    deviceId: String!
    serialNum: String!
    userPin: String!
    location: String!
    swVer: String!
  } ;
 
  export type SvcValidation ={
    uid: String!
    svcData: SvcData!
  };
  export type SvcData = {
    sector10: SvcBlock!
    sector11: SvcBlock!
    sector12: SvcBlock!
    sector13: SvcBlock!
  }
  export type SvcBlock = {
    block0: String!
    block1: String!
    block2: String!
  }

export type GetTicketsQueryVariables = {
    input:BusAccount;
    input:SvcValidation;
};
export type GetTicketsQueryResponse = {
  readonly tickets: {
    readonly totalCount: number;
    readonly edges: ReadonlyArray<{
      readonly node: {
        readonly id: number;
        sessionId: string;
        responseCode: number;
        responseMessage: string;
        companyId: number;
        ticketId: number;
        ticketNo: string;
        ticketType: string;
        routeId1: number;
        routeId2: number;
        routeCode1: string;
        routeCode2: string;
        fare: number;
        fareProductId: string;
        departureLocationId: string;
        destinationLocationId: string;
        activationDate: Date;
        expiryDate: Date;
        ticketDate: Date;
        numberOfDaysTrips: number;
        numberOfTransfers: number;
        status: string;
        rules: string;
        fareCurrency: string;
      };
    }> | null;
  };
};
export type GetTicketsQuery = {
  readonly response: GetTicketsQueryVariables;
  readonly variables: GetTicketsQueryResponse;
};

const node: ConcreteRequest = (function () {
  var v0 = [
    {
      alias: null,
      args: null,
      concreteType: 'TicketsList',
      kind: 'LinkedField',
      name: 'getTickets',
      plural: false,
      selections: [
        {
          alias: null,
          args: null,
          kind: 'ScalarField',
          name: 'totalCount',
          storageKey: null,
        },
        {
          alias: null,
          args: null,
          concreteType: 'GetTicketsListEdge',
          kind: 'LinkedField',
          name: 'edges',
          plural: true,
          selections: [
            {
              alias: null,
              args: null,
              concreteType: 'TicketsFound',
              kind: 'LinkedField',
              name: 'node',
              plural: false,
              selections: [
                {
                  alias: null,
                  args: null,
                  kind: 'ScalarField',
                  name: 'id',
                  storageKey: null,
                },
                {
                  alias: null,
                  args: null,
                  kind: 'ScalarField',
                  name: 'sessionId',
                  storageKey: null,
                },
                {
                  alias: null,
                  args: null,
                  kind: 'ScalarField',
                  name: 'responseCode',
                  storageKey: null,
                },
                {
                  alias: null,
                  args: null,
                  kind: 'ScalarField',
                  name: 'responseMessage',
                  storageKey: null,
                },
                {
                  alias: null,
                  args: null,
                  kind: 'ScalarField',
                  name: 'companyId',
                  storageKey: null,
                },
                {
                  alias: null,
                  args: null,
                  kind: 'ScalarField',
                  name: 'ticketId',
                  storageKey: null,
                },
                {
                  alias: null,
                  args: null,
                  kind: 'ScalarField',
                  name: 'ticketNo',
                  storageKey: null,
                },
                {
                  alias: null,
                  args: null,
                  kind: 'ScalarField',
                  name: 'ticketType',
                  storageKey: null,
                },
                {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'routeId1',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'routeId2',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'routeCode1',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'routeCode2',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'fare',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'fareProductId',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'departureLocationId',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'destinationLocationId',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'activationDate',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'expiryDate',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'ticketDate',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'numberOfDaysTrips',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'numberOfTransfers',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'status',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'rules',
                    storageKey: null,
                  },
                  {
                    alias: null,
                    args: null,
                    kind: 'ScalarField',
                    name: 'fareCurrency',
                    storageKey: null,
                  },
              ],
              storageKey: null,
            },
          ],
          storageKey: null,
        },
      ],
      storageKey: null,
    },
  ];
  return {
    fragment: {
      argumentDefinitions: [],
      kind: 'Fragment',
      metadata: null,
      name: 'GetTicketsQuery',
      selections: v0 /*: any*/,
      type: 'Query',
      abstractKey: null,
    },
    kind: 'Request',
    operation: {
      argumentDefinitions: [],
      kind: 'Operation',
      name: 'GetTicketsQuery',
      selections: v0 /*: any*/,
    },
    params: {
      cacheID: '3bb03d599582d789b7edbecb30f116f0',
      id: null,
      metadata: {},
      name: 'GetTicketsQuery',
      operationKind: 'query',
      text:
        'query GetTicketsQuery {\n  tickets {\n    totalCount\n    edges {\n      node {\n        id\n        sessionId\n        responseCode\n        responseMessage\n        companyId\n        ticketId\n        ticketNo\n        ticketType\n      routeId1\n     routeId2\n   routeCode1\n    routeCode2\n    fare\n    fareProductId\n    departureLocationId\n    destinationLocationId\n     activationDate\n    expiryDate\n    ticketDate\n    numberOfDaysTrips\n     numberOfTransfers\n    status\n    rules\n     fareCurrency\n   }\n    }\n  }\n}\n',
    },
  };
})();
(node as any).hash = 'c066239dcb1e5e6b01d27d6e72933200';
export default node;