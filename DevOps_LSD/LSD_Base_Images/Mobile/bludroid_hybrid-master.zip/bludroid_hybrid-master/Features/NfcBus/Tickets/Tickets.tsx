import * as React from 'react';
import {Component} from 'react';
import styling from './Tickets.styles';
import {Box} from '../../../Components/Box';
import {wPerc} from '../../../helpers/DeviceScalling';
import {Label} from '../Form/Form.style';
import {
  Button,
  Modal,
  ScrollView,
  Image,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
  FlatList,
} from 'react-native';
import {DeviceLibNfc} from 'react-native-device-lib-nfc';
import {
  NavigationHelpersContext,
  useNavigation,
} from '@react-navigation/native';
import {ApolloProvider, Query} from 'react-apollo';
import ApolloClient, {from} from 'apollo-boost';
import gql from 'graphql-tag';
import {graphql, useQuery} from 'relay-hooks';
import {TicketsQuery} from './__generated__/TicketsQuery.graphql';
import {Device} from '../../../TestData/TestData';
import {SVC} from '../../../TestData/TestData';
import {NavigationScreenProp, NavigationState} from 'react-navigation';

type Ticket = {
  id: Number;
  sessionId: String;
  responseCode: Number;
  responseMessage: String;
  companyId: Number;
  ticketId: Number;
  ticketNo: String;
  ticketType: String;
  routeId1: Number;
  routeId2: Number;
  routeCode1: String;
  routeCode2: String;
  fare: Number;
  fareProductId: String;
  departureLocationId: String;
  destinationLocationId: String;
  activationDate: Date;
  expiryDate: Date;
  ticketDate: Date;
  numberOfDaysTrips: Number;
  numberOfTransfers: Number;
  status: String;
  rules: String;
  fareCurrency: String;
};
interface Props {
  navigation: NavigationScreenProp<NavigationState>;
  destinationID: number;
  setCurrentScreen: (value: number) => void;
  depatureID: number;
  setDestinationID: (value: number) => void;
  setDepatureID: (value: number) => void;
  setCount: (value: number) => void;
  ticket_count: number;
  setTickets: (value: []) => void;
  user_tickets: any[];
  setRenewTicket: (value: {
    id: Number;
    sessionId: String;
    responseCode: Number;
    responseMessage: String;
    companyId: Number;
    ticketId: Number;
    ticketNo: String;
    ticketType: String;
    routeId1: Number;
    routeId2: Number;
    routeCode1: String;
    routeCode2: String;
    fare: Number;
    fareProductId: String;
    departureLocationId: String;
    destinationLocationId: String;
    activationDate: Date;
    expiryDate: Date;
    ticketDate: Date;
    numberOfDaysTrips: Number;
    numberOfTransfers: Number;
    status: String;
    rules: String;
    fareCurrency: String;
  }) => void;
}

const query = graphql`
  query TicketsQuery($svcValidation: SvcValidation, $auth: BusAccount!) {
    tickets(svcValidation: $svcValidation, auth: $auth) {
      totalCount
      pageInfo {
        hasNextPage
        hasPreviousPage
      }
      edges {
        cursor
        node {
          numberOfDaysTrips
          ticketId
          ticketNo
          destinationLocationId
          departureLocationId
          fare
          fareCurrency
          ticketType
          expiryDate
          activationDate
          numberOfDaysTrips
        }
      }
    }
  }
`;

export default function Tickets({navigation}: Props) {
  const {props, error, retry} = useQuery<TicketsQuery>(query, {
    svcValidation: SVC,
    auth: Device,
  });

  const createErrorAlert = (message: any) => {
    Alert.alert(
      'Error',
      'Unable to get Tickets, please try again later' + message
    );
  };

  const renewItem = (item: Ticket) => {
    navigation.navigate('GetRoutes', {
      item,
    });
  };

  const sendtoAEON = () => {};

  const cancelItem = (item: Ticket) => {
    Alert.alert(
      'Cancel',
      ' Are you sure you want to cancel this ticket?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK',
          onPress: () => {
            sendtoAEON();
          },
        },
      ],
      {cancelable: false}
    );
  };

  const ItemView = ({item}: {item: Ticket}) => {
    return (
      // Flat List Item
      <Box
        paddingSize="medium"
        align="center"
        justify="flex-start"
        row
        width="100%"
      >
        <Box flex={1} align="flex-start" justify="flex-start">
          <Text>{item.numberOfDaysTrips}</Text>
          <Text>{item.fareCurrency}</Text>
        </Box>

        <Box flex={2} align="flex-start" justify="flex-start">
          <Text>{item.fare}</Text>
          <Text>{item.expiryDate}</Text>
        </Box>

        <Box flex={1} padded>
          <Button title={'Renew'} onPress={() => renewItem(item)} />
          <Button title="Cancel" onPress={() => cancelItem(item)} />
        </Box>
      </Box>
    );
  };

  const ItemSeparatorView = () => {
    return (
      // Flat List Item Separator
      <View
        style={{
          height: 0.5,
          width: '100%',
          backgroundColor: '#C8C8C8',
        }}
      />
    );
  };

  if (error) createErrorAlert(error.message);

  let list: any[] = [];
  if (props && props.tickets?.edges) {
    const {
      tickets: {edges = []},
    } = props;
    list = props.tickets?.edges ? edges.map((edge) => edge.node) : [];
  }

  const ticketsList = () => {
    return (
      <FlatList
        style={{marginTop: 16, marginBottom: 16, width: '100%'}}
        data={list}
        keyExtractor={(item, index) => index.toString()}
        ItemSeparatorComponent={ItemSeparatorView}
        renderItem={ItemView}
      />
    );
  };

  return list.length > 0 ? (
    <View style={{flex: 1}}>{ticketsList()}</View>
  ) : (
    <View style={{flex: 1}}>
      <Box>
        <Text>No tickets found</Text>
      </Box>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 10,
  },
  buttonContainer: {
    margin: 10,
  },
  buttonRowContainer: {
    flexDirection: 'row',
    margin: 10,
  },
  buttonRow: {
    flex: 1,
    marginLeft: 5,
    marginRight: 5,
  },
});
