import {StatusBar} from 'expo-status-bar';
import React, {useState} from 'react';
import styling from './HomeStyle';

import {Ionicons} from '@expo/vector-icons';
import moment from 'moment';
//import { Picker } from "@react-native-community/picker";
import {Picker} from 'react-native';
//import DateTimePicker from "@react-native-community/datetimepicker";
import {
  Keyboard,
  KeyboardAvoidingView,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableWithoutFeedback,
  View,
  TouchableOpacity,
  Image,
  TextInput,
  Button,
  Alert,
} from 'react-native';
import {Formik} from 'formik';
import * as Yup from 'yup';

export default function HomeScreen({navigation}: any) {
  const [depature, setDepature] = useState('');
  const [destination, setDestination] = useState('');

  const state = {
    count: 0,
    date: '2016-05-15',
    isVisible: false,
    first: 'Allandale',
    last: 'Midrand',
  };

  return (
    <View style={styling.container}>
      <Text style={{fontSize: 20, color: 'navy', top: 0}}>Search Route</Text>

      <View style={{top: 90, alignItems: 'center', justifyContent: 'center'}}>
        <Text style={styling.text}> Depature :</Text>
        <View
          style={{
            borderRadius: 10,
            borderWidth: 1,
            borderColor: 'navy',
            overflow: 'hidden',
          }}
        >
          <Picker
            selectedValue={depature}
            style={{
              height: 50,
              width: 350,
              borderColor: 'red',
            }}
            onValueChange={(val) => setDepature(val)}
          >
            <Picker.Item label="Cape Town" value="Cape Town" />
            <Picker.Item label="Johannesburg" value="Johannesburg" />
            <Picker.Item label="Soweto" value="Soweto" />
            <Picker.Item label="Midrand" value="Midrand" />
            <Picker.Item label="Sandton" value="Sandton" />
            <Picker.Item label="Bellville" value="Bellville" />
          </Picker>
        </View>
        <Text style={styling.text}> Destination :</Text>
        <View
          style={{
            borderRadius: 10,
            borderWidth: 1,
            borderColor: 'navy',
            overflow: 'hidden',
          }}
        >
          <Picker
            selectedValue={destination}
            style={{
              height: 50,
              width: 350,
              borderColor: 'red',
            }}
            onValueChange={(val) => setDestination(val)}
          >
            <Picker.Item label="Cape Town" value="Cape Town" />
            <Picker.Item label="Johannesburg" value="Johannesburg" />
            <Picker.Item label="Soweto" value="Soweto" />
            <Picker.Item label="Midrand" value="Midrand" />
            <Picker.Item label="Sandton" value="Sandton" />
            <Picker.Item label="Bellville" value="Bellville" />
          </Picker>
        </View>
      </View>
    </View>
  );
}
