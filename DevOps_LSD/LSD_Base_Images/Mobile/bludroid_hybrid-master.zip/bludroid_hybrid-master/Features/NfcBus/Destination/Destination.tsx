import {StatusBar} from 'expo-status-bar';
import React, {useEffect, useState} from 'react';
import styling from './Destination.style';
import * as yup from 'yup';
import {Picker} from 'react-native';

import {
  Text,
  TouchableWithoutFeedback,
  View,
  TouchableOpacity,
  Image,
  TextInput,
  StyleSheet,
  Button,
  FlatList,
  Alert,
} from 'react-native';
import {Field, Formik} from 'formik';
import * as Yup from 'yup';
import ApolloClient from 'apollo-boost';
import gql from 'graphql-tag';

type destination = {
  locationId: String;
  type: String;
  stationId: String;
  entityId: String;
  name: String;
};
interface Props {
  destination: destination | null;
  setDestination: (value: {
    locationId: String;
    type: String;
    stationId: String;
    entityId: String;
    name: String;
  }) => void;
}

const validationSchema = yup.object().shape({
  depature: yup.string().required('This is a required field'),
  destination: yup
    .string()
    .required('This is a required field')
    .notOneOf(
      [yup.ref('depature')],
      'depature and destination cannot be the same'
    ),
});

export default function Destination({destination, setDestination}: Props) {
  const [destinationsTotal, setDestinationsTotal] = useState(0);
  const requestDestination = () => {
    console.log('requestDestination now!');
    const client = new ApolloClient({uri: 'http://192.168.8.107:5000/graphql'});

    client
      .query({
        query: gql`
          query {
            destinations(
              companyId: 251
              departureLocationId: "288"
              auth: {
                deviceId: "29851"
                serialNum: "P130189801394"
                userPin: "011234"
                location: ""
                swVer: ""
              }
            ) {
              totalCount
              pageInfo {
                hasNextPage
                hasPreviousPage
              }
              edges {
                cursor
                node {
                  locationId
                  type
                  stationId
                  entityId
                  name
                }
              }
            }
          }
        `,
      })
      .then((response) => {
        setDestination(response.data.destinations.edges);
        setDestinationsTotal(response.data.destinations.totalCount);
        console.log(
          'destinations found: ' +
            JSON.stringify(response.data.destinations.edges)
        );
      })
      .catch(function (error) {
        console.log('problem with send carriers request: ' + error.message);
        throw error;
      });
  };

  useEffect(() => {
    console.log('inside use effect!');
    requestDestination();
  }, []);

  const getItem = (item: any) => {
    console.log('selected item: ' + item);
    setDestination(item);
  };
  const [dests, setDests] = useState([]);
  let arr1: destination[] = dests;
  const ItemView = ({item, active, selectItem}: any) => {
    return (
      // Single Comes here which will be repeatative for the FlatListItems
      <TouchableOpacity onPress={() => selectItem(item)}>
        <View
          style={{
            backgroundColor: 'white',
            width: '100%',
            borderRadius: 12,
            marginBottom: 10,
            borderColor: active ? 'green' : 'white',
            borderWidth: 1,
            flexDirection: 'row',
          }}
        >
          <View style={{marginVertical: 50}}>
            <Image
              style={{height: 18, width: 90, left: 20}}
              source={require('../../../assets/putco.png')}
            />
          </View>
          <View style={{top: 20, left: 45}}>
            <Text style={styling.text}> {item.node.name}</Text>
          </View>
          <View
            style={{justifyContent: 'center', alignContent: 'center'}}
          ></View>
        </View>
      </TouchableOpacity>
    );
  };

  const ItemSeparatorView = () => {
    return (
      //Item Separator
      <View style={{height: 0.5, width: '100%', backgroundColor: 'ffff'}} />
    );
  };

  return (
    <View style={styling.container}>
      <Text style={{fontSize: 20, color: 'navy', top: -90}}>
        Search Routes for :
      </Text>

      <View style={{top: 0, alignItems: 'center', justifyContent: 'center'}}>
        <Formik
          validationSchema={validationSchema}
          initialValues={{
            depature: destination || '',
          }}
          onSubmit={(values) => {
            //  setDepature(values.depature);
          }}
        >
          {({
            handleChange,
            handleBlur,
            handleSubmit,
            setFieldValue,
            values,
            touched,
            errors,
            isSubmitting,
          }) => (
            <>
              <View>
                <Text style={{color: 'navy', padding: 10}}>
                  {' '}
                  Bus Destinations: {destinationsTotal}
                </Text>
              </View>
              <View style={styles.container}>
                <FlatList
                  data={arr1}
                  //data defined in constructor
                  ItemSeparatorComponent={ItemSeparatorView}
                  //Item Separator View
                  renderItem={({item}) => {
                    return (
                      <ItemView
                        item={item}
                        active={destination?.stationId === item.stationId}
                        selectItem={() => {
                          getItem(item);
                        }}
                      />
                    );
                  }}
                  keyExtractor={(item, index) => index.toString()}
                />
              </View>
            </>
          )}
        </Formik>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    flex: 1,
    marginLeft: 10,
    marginRight: 10,
    marginBottom: 40,
    marginTop: 30,
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44,
  },
});
