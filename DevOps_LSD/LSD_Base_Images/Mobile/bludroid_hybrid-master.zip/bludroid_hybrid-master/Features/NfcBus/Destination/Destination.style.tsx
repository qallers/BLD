import {StyleSheet} from 'react-native';

const GetDestinationsStyle = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F2',
    alignItems: 'center',
    justifyContent: 'center',
  },
  containerInputs: {
    backgroundColor: '#fff',
    position: 'absolute',
    left: 0,

    right: 0,
    bottom: 0,

    padding: 20,
  },
  text: {
    color: 'navy',
    fontSize: 15,
    padding: 10,
    left: -120,
  },
  InnerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    flex: 1,
    marginTop: 80,
    bottom: 50,
    width: 350,
    height: 400,
    borderRadius: 8,
  },
  inputField: {
    height: 40,
    borderColor: 'navy',
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 10,
  },
  buttonContainer: {
    backgroundColor: 'navy',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 10,
    borderColor: 'navy',
    borderWidth: 1,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    width: '90%',
  },
  buttonText: {
    textAlign: 'center',
    color: 'white',
    fontSize: 18,
  },
  registerText: {
    textAlign: 'center',
    color: 'navy',
    fontSize: 18,
    marginTop: 10,
  },
  buttons: {
    flexDirection: 'row',
    padding: 20,
  },
});
export default GetDestinationsStyle;
