import React, {useState} from 'react';
import CheckoutScreen from '../Checkout/CheckoutScreen';
import Tickets from '../Tickets/Tickets';
import styling from './Container.style';

import {Button, TouchableOpacity, View, Text} from 'react-native';
import GetRoutes from '../GetRoutes/GetRoutes';
import Carriers from '../Carriers/CarriesList';
import Destination from '../Destination/Destination';
import Fares from '../Fares/Fares';
import Confirm from '../Confirm/Confirm';

type Ticket = {
  id: Number;
  sessionId: String;
  responseCode: Number;
  responseMessage: String;
  companyId: Number;
  ticketId: Number;
  ticketNo: String;
  ticketType: String;
  routeId1: Number;
  routeId2: Number;
  routeCode1: String;
  routeCode2: String;
  fare: Number;
  fareProductId: String;
  departureLocationId: String;
  destinationLocationId: String;
  activationDate: Date;
  expiryDate: Date;
  ticketDate: Date;
  numberOfDaysTrips: Number;
  numberOfTransfers: Number;
  status: String;
  rules: String;
  fareCurrency: String;
};

type destination = {
  locationId: string;
  type: string;
  stationId: string;
  entityId: string;
  name: string;
};
type carrier = {
  name: string;
  shortName: string;
  companyId: string;
  role: string;
  type: string;
};
type Fare = {
  id: number;
  sessionId: String;
  responseCode: Number;
  responseMessage: String;
  status: Number;
  period: String;
  routeId2: String;
  fareProductId: string;
  code: String;
  routeId1: String;
  companyId: Number;
  weekdays: String;
  created: Date;
  availableFrom: Date;
  availableTo: Date;
  transferCount: Number;
  passValue: Number;
  tripsPerDay: Number;
  passType: String;
  price: Number;
  name: String;
  shortName: String;
  desc: String;
};
type stop = {
  name: string;
  id: string;
  __typename: string;
};
function Container({navigation, route}: any) {
  const [destination, setDestination] = useState<destination>({
    locationId: '',
    type: '',
    stationId: ' ',
    entityId: '',
    name: '',
  });
  const [depature, setDepature] = useState<stop>({
    name: '',
    id: '',
    __typename: '',
  });
  const [userName, setUserName] = useState<string | null>(null);
  const [cellphone, setCellphone] = useState<string | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<string | null>(null);
  const [currentScreen, setCurrentScreen] = useState(0);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [selectedCarrier, setSelectedCarrier] = useState<carrier>({
    name: '',
    shortName: '',
    companyId: '',
    role: '',
    type: '',
  });
  const [renewTicket, setRenewTicket] = useState<Ticket | null>(null);
  const [cancelTicket, setCancelTicket] = useState<Ticket | null>(null);
  const [destinationID, setDestinationID] = useState(0);
  const [depatureID, setDepatureID] = useState(0);
  const [user_tickets, setTickets] = useState([]);
  const [ticket_count, setCount] = useState(0);
  const [selectedFare, setSelectedFare] = useState<Fare | null>(null);
  const [fare, setFare] = useState<Fare | null>(null);
  const [cardId, setCardId] = useState<string | null>(null);

  function ScreenHandler({currentScreen}: {currentScreen: number}) {
    switch (currentScreen) {
      case 0:
        return (
          <Tickets
            destinationID={destinationID}
            depatureID={depatureID}
            setDestinationID={setDestinationID}
            setDepatureID={setDepatureID}
            setCurrentScreen={setCurrentScreen}
            setRenewTicket={setRenewTicket}
            navigation={navigation}
            setTickets={setTickets}
            setCount={setCount}
            ticket_count={ticket_count}
            user_tickets={user_tickets}
          />
        );

      case 1:
        return (
          <GetRoutes
            selectedCarrier={selectedCarrier}
            setSelectedCarrier={setSelectedCarrier}
            depature={depature}
            setDepature={setDepature}
            destination={destination}
            setDestination={setDestination}
            setCurrentScreen={setCurrentScreen}
          />
        );

      case 2:
        return (
          <Fares
            selectedFare={selectedFare}
            setSelectedFare={setSelectedFare}
            setCurrentScreen={setCurrentScreen}
            destination={destination}
            depature={depature}
            selectedCurrier={selectedCarrier}
          />
        );
      case 3:
        return (
          <Confirm
            userName={userName}
            setUserName={(name) => setUserName(name)}
            cellphone={cellphone}
            setCellphone={setCellphone}
            paymentMethod={paymentMethod}
            setPaymentMethod={setPaymentMethod}
            destination={destination}
            depature={depature}
            selectedFare={selectedFare}
            setCurrentScreen={setCurrentScreen}
          />
        );
      case 4:
        return (
          <CheckoutScreen
            cardId={cardId}
            destination={destination}
            depature={depature}
            selectedFare={selectedFare}
            selectedCarrier={selectedCarrier}
          />
        );

      default:
        return null;
    }
  }
  const handlePrevious = () => {
    if (currentScreen > 0) {
      setCurrentScreen(currentScreen - 1);
    }
  };
  const handleNext = () => {
    if (currentScreen < 3) {
      setCurrentScreen(currentScreen + 1);
    }
  };

  const checkNext = () => {
    switch (currentScreen) {
      case 2:
        return Boolean(depature && destination);
      case 1:
        return Boolean(selectedCarrier);
      case 3:
        return Boolean(selectedFare);
      case 4:
        return Boolean(paymentMethod);
      default:
        return true;
    }
  };

  //console.log({userName, cellphone, paymentMethod});
  //console.log({depature, destination});

  console.log(
    'renew ticket from container:  ' + JSON.stringify({selectedCarrier})
  );
  console.log('renew ticket from container:  ' + JSON.stringify({depature}));
  console.log('renew ticket from container:  ' + JSON.stringify({destination}));
  console.log(
    'renew ticket from container:  ' + JSON.stringify({selectedFare})
  );
  console.log('payment:  ' + JSON.stringify({paymentMethod}));
  return (
    <View style={{height: '100%'}}>
      <ScreenHandler currentScreen={currentScreen} />
      <View
        style={{
          bottom: 5,
          top: -50,
          padding: 10,
          flexDirection: 'row',
          justifyContent: 'space-between',
          display: currentScreen === 0 ? 'flex' : 'none',
        }}
      >
        <TouchableOpacity onPress={handleNext} style={styling.buttonContainer}>
          <Text style={styling.buttonText}>Profile</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleNext} style={styling.buttonContainer}>
          <Text style={styling.buttonText}>New Ticket</Text>
        </TouchableOpacity>
      </View>
      <View
        style={{
          bottom: 5,
          flexDirection: 'row',
          justifyContent: 'space-between',
          padding: 10,
          display: currentScreen === 0 ? 'none' : 'flex',
          top: -50,
        }}
      >
        <TouchableOpacity
          onPress={handlePrevious}
          style={styling.buttonContainer}
        >
          <Text style={styling.buttonText}>Back</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={handleNext}
          disabled={!checkNext()}
          style={[styling.buttonContainer, {opacity: !checkNext() ? 0.5 : 1}]}
        >
          <Text style={styling.buttonText}>Next</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default Container;
