import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableWithoutFeedback,
  View,
  TouchableOpacity,
  Image,
  TextInput,
} from "react-native";

export default function NewTicketScreen({ navigation }: any) {
  const [cellNumber, setCellphoneNumber] = useState("");
  const [password, setPassword] = useState("");

  return <View></View>;
}
