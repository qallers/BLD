import {StyleSheet} from 'react-native';

const HomeStyle = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F2',
  },
  introContainer: {
    backgroundColor: '#fff',
    marginTop: 0,
    width: 400,
    height: 80,
  },
  tile: {
    backgroundColor: '#fff',
    marginTop: 90,
    bottom: 10,
    height: 100,
    width: 350,
    padding: 20,
    borderColor: 'navy',
    borderRadius: 8,
  },
  text: {
    color: 'gray',
    fontSize: 13,
    padding: 10,
  },
  InnerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F2F2F2',
    marginTop: 270,
    width: 350,
    height: 100,
  },
  inputField: {
    height: 40,
    borderColor: 'navy',
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 10,
  },
  buttonContainer: {
    backgroundColor: 'navy',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 10,
    padding: 20,
    top: 20,
    width: '48%',
  },
  buttonText: {
    textAlign: 'center',
    color: 'white',
    fontSize: 18,
  },
  registerText: {
    textAlign: 'center',
    color: 'navy',
    fontSize: 18,
    marginTop: 10,
  },
  buttons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
  },
  checkboxContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  checkbox: {
    right: -100,
  },
});
export default HomeStyle;
