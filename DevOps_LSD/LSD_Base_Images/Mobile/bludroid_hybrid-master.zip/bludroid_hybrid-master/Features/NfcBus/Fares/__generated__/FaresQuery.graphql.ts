/* tslint:disable */
/* eslint-disable */
// @ts-nocheck

import { ConcreteRequest } from "relay-runtime";
export type BusFareInput = {
    companyId: string;
    departureLocationId?: string | null;
    destinationLocationId?: string | null;
    routeId?: number | null;
    fareProductId?: string | null;
    auth?: BusAccount | null;
};
export type BusAccount = {
    deviceId: string;
    serialNum: string;
    userPin: string;
    location: string;
    swVer: string;
};
export type FaresQueryVariables = {
    input: BusFareInput;
};
export type FaresQueryResponse = {
    readonly fares: {
        readonly totalCount: number | null;
        readonly pageInfo: {
            readonly hasNextPage: boolean | null;
            readonly hasPreviousPage: boolean | null;
        } | null;
        readonly edges: ReadonlyArray<{
            readonly cursor: string | null;
            readonly node: {
                readonly id: string | null;
                readonly weekdays: string;
                readonly name: string;
                readonly desc: string | null;
                readonly price: string;
                readonly period: string;
                readonly fareProductId: string;
                readonly availableTo: unknown;
                readonly availableFrom: unknown;
            };
        }>;
    };
};
export type FaresQuery = {
    readonly response: FaresQueryResponse;
    readonly variables: FaresQueryVariables;
};



/*
query FaresQuery(
  $input: BusFareInput!
) {
  fares(input: $input) {
    totalCount
    pageInfo {
      hasNextPage
      hasPreviousPage
    }
    edges {
      cursor
      node {
        id
        weekdays
        name
        desc
        price
        period
        fareProductId
        availableTo
        availableFrom
      }
    }
  }
}
*/

const node: ConcreteRequest = (function(){
var v0 = [
  {
    "defaultValue": null,
    "kind": "LocalArgument",
    "name": "input"
  }
],
v1 = [
  {
    "alias": null,
    "args": [
      {
        "kind": "Variable",
        "name": "input",
        "variableName": "input"
      }
    ],
    "concreteType": "BusFaresConnection",
    "kind": "LinkedField",
    "name": "fares",
    "plural": false,
    "selections": [
      {
        "alias": null,
        "args": null,
        "kind": "ScalarField",
        "name": "totalCount",
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "PageInfo",
        "kind": "LinkedField",
        "name": "pageInfo",
        "plural": false,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "hasNextPage",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "hasPreviousPage",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "BusFaresEdge",
        "kind": "LinkedField",
        "name": "edges",
        "plural": true,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "cursor",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "concreteType": "BusFare",
            "kind": "LinkedField",
            "name": "node",
            "plural": false,
            "selections": [
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "id",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "weekdays",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "name",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "desc",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "price",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "period",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "fareProductId",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "availableTo",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "availableFrom",
                "storageKey": null
              }
            ],
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "storageKey": null
  }
];
return {
  "fragment": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Fragment",
    "metadata": null,
    "name": "FaresQuery",
    "selections": (v1/*: any*/),
    "type": "Query",
    "abstractKey": null
  },
  "kind": "Request",
  "operation": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Operation",
    "name": "FaresQuery",
    "selections": (v1/*: any*/)
  },
  "params": {
    "cacheID": "d7ca75ff56db6b11c624ce962e1e31d1",
    "id": null,
    "metadata": {},
    "name": "FaresQuery",
    "operationKind": "query",
    "text": "query FaresQuery(\n  $input: BusFareInput!\n) {\n  fares(input: $input) {\n    totalCount\n    pageInfo {\n      hasNextPage\n      hasPreviousPage\n    }\n    edges {\n      cursor\n      node {\n        id\n        weekdays\n        name\n        desc\n        price\n        period\n        fareProductId\n        availableTo\n        availableFrom\n      }\n    }\n  }\n}\n"
  }
};
})();
(node as any).hash = 'f25319f879e18090911dd889b0933de0';
export default node;
