import React, {useEffect, useState} from 'react';
import styling from './Fares.styles';
import {Field, Formik} from 'formik';
import * as yup from 'yup';
import {Device} from '../../../TestData/TestData';
import {RadioButton} from 'react-native-paper';
import {
  View,
  StyleSheet,
  Image,
  Text,
  FlatList,
  SafeAreaView,
  Button,
  TouchableOpacity,
  CheckBox,
  Alert,
} from 'react-native';
import {ListItem, Avatar} from 'react-native-elements';
import ApolloClient, {from} from 'apollo-boost';
import gql from 'graphql-tag';
import {graphql, useQuery} from 'relay-hooks';
import {FaresQuery} from './__generated__/FaresQuery.graphql';
import {Box} from '../../../Components/Box';
import {LoadingSpinner} from '../../../Components/LoadingSpinner';
import {weekdays} from 'moment';

type stop = {
  name: string;
  id: string;
};
type destination = {
  locationId: string;
  type: string;
  stationId: string;
  entityId: string;
  name: string;
};
type carrier = {
  name: string;
  shortName: string;
  companyId: string;
  role: string;
  type: string;
};

type Fare = {
  id: number;
  sessionId: String;
  responseCode: Number;
  responseMessage: String;
  status: Number;
  period: String;
  routeId2: String;
  fareProductId: string;
  code: String;
  routeId1: String;
  companyId: Number;
  weekdays: String;
  created: Date;
  availableFrom: Date;
  availableTo: Date;
  transferCount: Number;
  passValue: Number;
  tripsPerDay: Number;
  passType: String;
  price: Number;
  name: String;
  shortName: String;
  desc: String;
};

const validationSchema = yup.object().shape({
  name: yup.object().required('Please select a ticket'),
});
//import TouchableScale from "react-native-touchable-scale"; // https://github.com/kohver/react-native-touchable-scale
interface Props {
  setCurrentScreen: (value: number) => void;
  selectedFare: Fare | null;
  setSelectedFare: (value: {
    id: number;
    sessionId: String;
    responseCode: Number;
    responseMessage: String;
    status: Number;
    period: String;
    routeId2: String;
    fareProductId: string;
    code: String;
    routeId1: String;
    companyId: Number;
    weekdays: String;
    created: Date;
    availableFrom: Date;
    availableTo: Date;
    transferCount: Number;
    passValue: Number;
    tripsPerDay: Number;
    passType: String;
    price: Number;
    name: String;
    shortName: String;
    desc: String;
  }) => void;
  destination: destination;
  depature: stop;
  selectedCurrier: carrier;
}

const query = graphql`
  query FaresListQuery($input: BusFareInput!) {
    fares(input: $input) {
      totalCount
      pageInfo {
        hasNextPage
        hasPreviousPage
      }
      edges {
        cursor
        node {
          id
          weekdays
          name
          desc
          price
          period
          fareProductId
          availableTo
          availableFrom
        }
      }
    }
  }
`;
export default function FaresList({
  selectedFare,
  setSelectedFare,
  setCurrentScreen,
  depature,
  destination,
  selectedCurrier,
}: Props) {
  const [checked, setChecked] = React.useState('sorry');
  const {props, error, retry} = useQuery<FaresQuery>(query, {
    input: {
      companyId: selectedCurrier?.companyId,
      departureLocationId: depature?.id,
      destinationLocationId: destination.locationId,
      auth: Device,
    },
  });

  const createErrorAlert = (message: any) => {
    Alert.alert(
      'Error',
      'Unable to get Fares, please try again later' + message
    );
  };

  const getItem = (item: Fare) => {
    setChecked(item.fareProductId);
    setSelectedFare(item);
  };

  const ItemView = ({
    item,
    active,
    selectItem,
  }: {
    item: Fare;
    active: any;
    selectItem: any;
  }) => {
    return (
      // Flat List Item
      <Box
        paddingSize="medium"
        align="center"
        justify="flex-start"
        row
        width="100%"
      >
        <View style={{flexDirection: 'column'}}>
          <Box flex={1} align="flex-start" justify="flex-start">
            <View style={{left: 20}}>
              <Text>{item.name}</Text>
              <Text>Period:{item.period}</Text>
              <Text>Days: {item.weekdays}</Text>
              <Text style={{fontSize: 15, fontWeight: 'bold'}}>
                Price: {item.price}
              </Text>
            </View>
          </Box>
          <View style={{left: 300}}>
            <RadioButton
              value={item.fareProductId}
              status={
                selectedFare?.fareProductId === item.fareProductId
                  ? 'checked'
                  : 'unchecked'
              }
              onPress={() => {
                setSelectedFare(item);
              }}
            />
          </View>
        </View>
      </Box>
    );
  };

  const ItemSeparatorView = () => {
    return (
      // Flat List Item Separator
      <View
        style={{
          height: 0.5,
          width: '100%',
          backgroundColor: '#C8C8C8',
        }}
      />
    );
  };

  if (error) createErrorAlert(error.message);

  let list: any[] = [];
  if (props && props.fares.edges) {
    const {
      fares: {edges = []},
    } = props;
    list = props.fares?.edges ? edges.map((edge) => edge.node) : [];
  }

  const stockList = () => {
    return (
      <FlatList
        style={{marginTop: 16, marginBottom: 16, width: '100%'}}
        data={list}
        keyExtractor={(item, index) => index.toString()}
        ItemSeparatorComponent={ItemSeparatorView}
        renderItem={({item}) => {
          return (
            <ItemView
              item={item}
              active={selectedFare?.id === item.id}
              selectItem={() => {
                getItem(item);
              }}
            />
          );
        }}
      />
    );
  };

  return list.length > 0 ? (
    <View style={{flex: 1}}>{stockList()}</View>
  ) : (
    <View style={{flex: 1}}>
      <Box>
        <Text>Loading Fares...</Text>
      </Box>
    </View>
  );
}
