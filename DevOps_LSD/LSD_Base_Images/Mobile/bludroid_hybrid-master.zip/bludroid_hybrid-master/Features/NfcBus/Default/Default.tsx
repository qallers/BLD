import * as React from 'react';
import {Component} from 'react';
import styling from './Default.style';
import {Box} from '../../../Components/Box';
import {wPerc} from '../../../helpers/DeviceScalling';
import {Label} from '../Form/Form.style';
import {Alert, Button, Modal, ScrollView, StyleSheet, Text, TouchableOpacity, View,} from 'react-native';
import {DeviceLibNfc} from 'react-native-device-lib-nfc';
import {NavigationContainer} from "@react-navigation/native";
import ReadCard from "../ReadCard/ReadCard";
import Tickets from "../Tickets/Tickets";
import GetRoutes from "../GetRoutes/GetRoutes";
import ConfirmScreen from "../Confirm/Confirm";
import NewticketScreen from "../NewTicket/NewTicketScreen";
import CheckoutScreen from "../Checkout/CheckoutScreen";
import CarriesScreen from "../Carriers/CarriesList";
import Container from "../Container/Container";
import {createStackNavigator} from "@react-navigation/stack";

const Stack = createStackNavigator();

interface Props {
  navigation: any;
}

type svcData = {
  sector10: SvcBlock;
  sector11: SvcBlock;
  sector12: SvcBlock;
  sector13: SvcBlock;
};

type SvcBlock = {
  block0: String;
  block1: String;
  block2: String;
};

export default class NfcScreen extends Component<Props> {
  constructor(props: any) {
    super(props);
  }

  componentDidMount() {
    console.log('componentDidMount');
    DeviceLibNfc.nfcInit();
  }

  componentWillUnmount() {
    console.log('componentWillUnmount');
    DeviceLibNfc.nfcTerminate();
  }

  state = {
    dialog: false,
    dialogMessage: 'Please wait',
    result: 'Debug info goes here',
  };

  getUid = () => {
    console.log('getUid');
    console.log('DeviceLibNfc = ' + DeviceLibNfc);
    this.setState({dialog: true, dialogMessage: 'Get UID'}, () => {
      DeviceLibNfc.nfcReadUid()
        .then((result) => {
          console.log('result: ' + JSON.stringify(result));
          this.setState({result: JSON.stringify(result, null, 2), dialog: false});
        })
        .catch((err) => {
          let msg = err.toString();
          console.log('error: ' + msg);
          this.setState({result: msg, dialog: false});
        });
        // .finally(() => this.setState({dialog: false, dialogMessage: ''}));
    });
  };

  checkCard = (jsonString: any) => {
    console.log('checkCard: ' + jsonString);
    this.setState({dialog: true, dialogMessage: 'Check Card'}, () => {
      DeviceLibNfc.nfcCheckCard(jsonString)
        .then((result) => {
          console.log('result: ' + JSON.stringify(result));
          this.setState({result: JSON.stringify(result, null, 2), dialog: false});
          // this.setState({dialog: false, dialogMessage: ''});
          // this.display();
        })
        .catch((err) => {
          let msg = err.toString();
          console.log('error: ' + msg);
          this.setState({result: msg, dialog: false});
        });
      //.finally(() => this.setState({dialog: false, dialogMessage: ''}));
    });
  };

  writeCard = (jsonString: any) => {
    console.log('writeCard: ' + jsonString);
    this.setState({dialog: true, dialogMessage: 'Write Card'}, () => {
      DeviceLibNfc.nfcWriteCard(jsonString)
        .then((result) => {
          console.log('result: ' + JSON.stringify(result));
          this.setState({result: JSON.stringify(result, null, 2)});
        })
        .catch((err) => {
          let msg = err.toString();
          console.log('error: ' + msg);
          this.setState({result: msg});
        });
      //   .finally(() => this.setState({dialog: false, dialogMessage: ''}));
    });
  };

  readCard = (jsonString: any) => {
    console.log('readCard: ' + jsonString);
    this.setState({dialog: true, dialogMessage: 'Read Card'}, () => {
      DeviceLibNfc.nfcReadCard(jsonString)
        .then((result) => {
          console.log('result: ' + JSON.stringify(result));
          this.setState({result: JSON.stringify(result, null, 2)});
          this.setState({dialog: false, dialogMessage: ''});
          this.display();
        })
        .catch((err) => {
          let msg = err.toString();
          console.log('error: ' + msg);
          this.setState({result: msg});
        });
      //  .finally(() => this.setState({dialog: false, dialogMessage: ''}));
    });
  };

  formatCard = (jsonString: any) => {
    console.log('formatCard: ' + jsonString);
    this.setState({dialog: true, dialogMessage: 'Format Card'}, () => {
      DeviceLibNfc.nfcFormatCard(jsonString)
        .then((result) => {
          console.log('result: ' + JSON.stringify(result));
          this.setState({result: JSON.stringify(result, null, 2)});
        })
        .catch((err) => {
          let msg = err.toString();
          console.log('error: ' + msg);
          this.setState({result: msg});
        });
      //  .finally(() => this.setState({dialog: false, dialogMessage: ''}));
    });
  };

  cancel = () => {
    console.log('cancel transaction');
    DeviceLibNfc.nfcCancel();
    this.setState({dialog: false, dialogMessage: ''});
  };

  checkDefault = () => {
    const job = require('../../../nfcjobs/nfcCheck.json');
    this.checkCard(JSON.stringify(job));
  };

  checkFormatted = () => {
    const job = require('../../../nfcjobs/nfcCheckFormat.json');
    this.checkCard(JSON.stringify(job));
  };

  readDefault = () => {
    const job = require('../../../nfcjobs/nfcReadAll.json');
    this.readCard(JSON.stringify(job));
  };

  writeDefault = () => {
    const job = require('../../../nfcjobs/nfcFormat.json');
    this.writeCard(JSON.stringify(job));
  };

  clearDefault = () => {
    const job = require('../../../nfcjobs/nfcFormat.json');
    this.writeCard(JSON.stringify(job));
  };

  format = () => {
    const job = require('../../../nfcjobs/nfcFormat.json');
    this.formatCard(JSON.stringify(job));
  };

  readFormat = () => {
    const job = require('../../../nfcjobs/nfcReadFormat.json');
    this.readCard(JSON.stringify(job));
  };

  writeFormat = () => {
    const job = require('../../../nfcjobs/nfcWriteFormat.json');
    this.writeCard(JSON.stringify(job));
  };

  clearFormat = () => {
    const job = require('../../../nfcjobs/nfcFormat.json');
    this.writeCard(JSON.stringify(job));
  };

  restore = () => {
    const job = require('../../../nfcjobs/nfcRestore.json');
    this.formatCard(JSON.stringify(job));
  };
  showRegister = () => {
    const {navigate} = this.props.navigation;
    navigate('Register');
  };
  display = () => {
    const {navigate} = this.props.navigation;
    const dat = {
      result: {
        status: 'SUCCESS',
        operation: 'READ',
        card: {
          uid: '45CF54B4',
          sectors: [],
          blocks: [
            {num: 40, data: '5648595544547052544C70746A575752'},
            {num: 41, data: '6A443031453554374D72494F37614542'},
            {num: 42, data: '4E394D47712F5574514676682B305A44'},

            {num: 44, data: '41633779646348743544536745786553'},
            {num: 45, data: '313476724E706666582F63326F526D62'},
            {num: 46, data: '4E4633742F7356616958753632595643'},

            {num: 48, data: '316A77674657356B6F48553677416C39'},
            {num: 49, data: '30554354387263375A4B30525069555A'},
            {num: 50, data: '00000000000000000000000000000000'},

            {num: 52, data: '416efc00000000000000000000000000'},
            {num: 53, data: '00000000000000000000000000000000'},
            {num: 54, data: '00000000000000000000000000000000'},
          ],
        },
      },
    };

    var myDat: svcData[];
    var block: SvcBlock[];
    var arr = [];
    var all = [];

    var obj1: SvcBlock = {
      block0: '',
      block1: '',
      block2: '',
    };

    var obj2: SvcBlock = {
      block0: '',
      block1: '',
      block2: '',
    };

    var obj3: SvcBlock = {
      block0: '',
      block1: '',
      block2: '',
    };
    var obj4: SvcBlock = {
      block0: '',
      block1: '',
      block2: '',
    };
    var status = JSON.parse(this.state.result);
    if (status.status === 'SUCCESS') {
      const cardId = status.card.uid;
      for (let p = 0; p < 1; p++) {
        obj1.block0 = dat.result.card.blocks[p].data;
        obj1.block1 = dat.result.card.blocks[p + 1].data;
        obj1.block2 = dat.result.card.blocks[p + 2].data;
      }
      for (let p = 3; p < 4; p++) {
        obj2.block0 = dat.result.card.blocks[p].data;
        obj2.block1 = dat.result.card.blocks[p + 1].data;
        obj2.block2 = dat.result.card.blocks[p + 2].data;
      }
      for (let p = 6; p < 7; p++) {
        obj3.block0 = dat.result.card.blocks[p].data;
        obj3.block1 = dat.result.card.blocks[p + 1].data;
        obj3.block2 = dat.result.card.blocks[p + 2].data;
      }
      for (let p = 9; p < 10; p++) {
        obj4.block0 = dat.result.card.blocks[p].data;
        obj4.block1 = dat.result.card.blocks[p + 1].data;
        obj4.block2 = dat.result.card.blocks[p + 2].data;
      }
      // arr = [];
      // for (let i = 0; i < 3; i++) {
      //block.push
      let objAll: svcData = {
        sector10: obj1,
        sector11: obj2,
        sector12: obj3,
        sector13: obj4,
      };
      arr.push(objAll);
      // }
      // all.push();

      console.log('uid: ' + cardId);

      console.log('arr: ' + JSON.stringify(arr));
      // console.log('all: ' + JSON.stringify());

      Alert.alert(
        'Status',
        'Card ready for use',
        [
          {
            text: 'Cancel',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel',
          },
          {
            text: 'OK',
            onPress: () => {
              navigate('Container');
            },
          },
        ],
        {cancelable: false}
      );
    } else {
      Alert.alert(
        'Card Status',
        'Card not formatted, Please click Register to continue',
        [
          {
            text: 'Cancel',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel',
          },
          {
            text: 'Register',
            // onPress: () => {Register()},
          },
        ],
        {cancelable: false}
      );
    }
  };
  render() {
    return this.state.dialog ? (
      <NfcOperationDialog
        visible={this.state.dialog}
        message={this.state.dialogMessage}
        onPress={this.cancel}
      />
    ) : (
      <ScrollView style={styles.container}>
        <View style={{width: wPerc(95)}}>
          <Box row justify={'flex-start'} style={{}}>
            <GridButton onPress={this.checkFormatted} label="Airtime" />

            <GridButton onPress={this.checkFormatted} label="Electricity" />
            <GridButton onPress={this.restore} label="Ristore" />

            <GridButton onPress={this.writeFormat} label="Write" />
          </Box>

          <Box row justify={'flex-start'} style={{}}>
            <GridButton onPress={this.readFormat} label="Read" />

            <GridButton onPress={this.format} label="Format" />

            <GridButton onPress={this.getUid} label="Get UID" />

            <GridButton onPress={this.readFormat} label="NFC Busses" />
          </Box>
        </View>

        <View style={styles.buttonContainer}>
          <Text style={{fontFamily: 'monospace'}}>{this.state.result}</Text>
        </View>
      </ScrollView>
    );
  }
}

function GridButton({onPress, label}: {label: string; onPress: () => void}) {
  return (
    <TouchableOpacity onPress={onPress} style={{width: '25%'}}>
      <Box>
        <Box style={styling.button}></Box>
        <Label>{label}</Label>
      </Box>
    </TouchableOpacity>
  );
}

function Register(navigation: any) {
  //const navigation = useNavigation();
  navigation.navigate('Register');
}
const NfcOperationDialog = ({visible, message, onPress}: any) => (
  <Modal onRequestClose={() => null} visible={visible}>
    <View
      style={{
        flex: 1,
        backgroundColor: '#dcdcdc',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <View style={{borderRadius: 10, backgroundColor: 'white', padding: 25}}>
        <Text style={{fontSize: 20, fontWeight: '200', marginBottom: 20}}>
          {message}
        </Text>
        <Button title={'Cancel'} onPress={onPress} />
      </View>
    </View>
  </Modal>
);

export function NfcBusNavigation(props: any) {

  return (
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name="Default" component={NfcScreen}/>
          <Stack.Screen name="ReadCard" component={ReadCard}/>
          <Stack.Screen name="Tickets" component={Tickets}/>
          <Stack.Screen name="GetRoutes" component={GetRoutes}/>
          <Stack.Screen name="Confirm" component={ConfirmScreen}/>
          <Stack.Screen name="NewTicket" component={NewticketScreen}/>
          <Stack.Screen name="Checkout" component={CheckoutScreen}/>
          <Stack.Screen name="Carries" component={CarriesScreen}/>
          <Stack.Screen name="Container" component={Container}/>
        </Stack.Navigator>
      </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 10,
  },
  buttonContainer: {
    margin: 10,
  },
  buttonRowContainer: {
    flexDirection: 'row',
    margin: 10,
  },
  buttonRow: {
    flex: 1,
    marginLeft: 5,
    marginRight: 5,
  },
});
