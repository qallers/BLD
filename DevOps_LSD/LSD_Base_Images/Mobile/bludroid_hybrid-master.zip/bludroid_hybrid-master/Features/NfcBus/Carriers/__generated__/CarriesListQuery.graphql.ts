/* tslint:disable */
/* eslint-disable */
// @ts-nocheck

import { ConcreteRequest } from "relay-runtime";
export type BusAccount = {
    deviceId: string;
    serialNum: string;
    userPin: string;
    location: string;
    swVer: string;
};
export type CarriesListQueryVariables = {
    input: BusAccount;
};
export type CarriesListQueryResponse = {
    readonly carriers: {
        readonly totalCount: number | null;
        readonly pageInfo: {
            readonly hasNextPage: boolean | null;
            readonly hasPreviousPage: boolean | null;
        } | null;
        readonly edges: ReadonlyArray<{
            readonly cursor: string | null;
            readonly node: {
                readonly companyId: string | null;
                readonly shortName: string | null;
                readonly role: string | null;
                readonly type: string | null;
                readonly name: string | null;
            };
        }>;
    };
};
export type CarriesListQuery = {
    readonly response: CarriesListQueryResponse;
    readonly variables: CarriesListQueryVariables;
};



/*
query CarriesListQuery(
  $input: BusAccount!
) {
  carriers(input: $input) {
    totalCount
    pageInfo {
      hasNextPage
      hasPreviousPage
    }
    edges {
      cursor
      node {
        companyId
        shortName
        role
        type
        name
      }
    }
  }
}
*/

const node: ConcreteRequest = (function(){
var v0 = [
  {
    "defaultValue": null,
    "kind": "LocalArgument",
    "name": "input"
  }
],
v1 = [
  {
    "alias": null,
    "args": [
      {
        "kind": "Variable",
        "name": "input",
        "variableName": "input"
      }
    ],
    "concreteType": "BusCarriersConnection",
    "kind": "LinkedField",
    "name": "carriers",
    "plural": false,
    "selections": [
      {
        "alias": null,
        "args": null,
        "kind": "ScalarField",
        "name": "totalCount",
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "PageInfo",
        "kind": "LinkedField",
        "name": "pageInfo",
        "plural": false,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "hasNextPage",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "hasPreviousPage",
            "storageKey": null
          }
        ],
        "storageKey": null
      },
      {
        "alias": null,
        "args": null,
        "concreteType": "BusCarriersEdge",
        "kind": "LinkedField",
        "name": "edges",
        "plural": true,
        "selections": [
          {
            "alias": null,
            "args": null,
            "kind": "ScalarField",
            "name": "cursor",
            "storageKey": null
          },
          {
            "alias": null,
            "args": null,
            "concreteType": "BusCarrierLocation",
            "kind": "LinkedField",
            "name": "node",
            "plural": false,
            "selections": [
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "companyId",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "shortName",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "role",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "type",
                "storageKey": null
              },
              {
                "alias": null,
                "args": null,
                "kind": "ScalarField",
                "name": "name",
                "storageKey": null
              }
            ],
            "storageKey": null
          }
        ],
        "storageKey": null
      }
    ],
    "storageKey": null
  }
];
return {
  "fragment": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Fragment",
    "metadata": null,
    "name": "CarriesListQuery",
    "selections": (v1/*: any*/),
    "type": "Query",
    "abstractKey": null
  },
  "kind": "Request",
  "operation": {
    "argumentDefinitions": (v0/*: any*/),
    "kind": "Operation",
    "name": "CarriesListQuery",
    "selections": (v1/*: any*/)
  },
  "params": {
    "cacheID": "1c1b7e896c29b2fa8fe3cea6f4960742",
    "id": null,
    "metadata": {},
    "name": "CarriesListQuery",
    "operationKind": "query",
    "text": "query CarriesListQuery(\n  $input: BusAccount!\n) {\n  carriers(input: $input) {\n    totalCount\n    pageInfo {\n      hasNextPage\n      hasPreviousPage\n    }\n    edges {\n      cursor\n      node {\n        companyId\n        shortName\n        role\n        type\n        name\n      }\n    }\n  }\n}\n"
  }
};
})();
(node as any).hash = '6af189585df81164e811b7de2d717beb';
export default node;
