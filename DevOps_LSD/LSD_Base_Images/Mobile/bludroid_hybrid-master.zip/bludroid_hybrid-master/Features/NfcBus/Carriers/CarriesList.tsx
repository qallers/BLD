import React, {useEffect, useState} from 'react';
import styling from './CarrieStyle';
import {Device} from '../../../TestData/TestData';
import {Field, Formik} from 'formik';
import ApolloClient, {from} from 'apollo-boost';
import gql from 'graphql-tag';
import * as yup from 'yup';
import {
  View,
  StyleSheet,
  Image,
  Text,
  FlatList,
  SafeAreaView,
  Button,
  TouchableOpacity,
  CheckBox,
  Alert,
} from 'react-native';
import {graphql, useQuery} from 'relay-hooks';
import {CarriesListQuery} from './__generated__/CarriesListQuery.graphql';
import {Box} from '../../../Components/Box';
import {RadioButton} from 'react-native-paper';
type carrier = {
  name: string;
  shortName: string;
  companyId: string;
  role: string;
  type: string;
};

const validationSchema = yup.object().shape({
  name: yup.object().required('Please select a ticket'),
});

const query = graphql`
  query CarriesListQuery($input: BusAccount!) {
    carriers(input: $input) {
      totalCount
      pageInfo {
        hasNextPage
        hasPreviousPage
      }
      edges {
        cursor
        node {
          companyId
          shortName
          role
          type
          name
        }
      }
    }
  }
`;

//import TouchableScale from "react-native-touchable-scale"; // https://github.com/kohver/react-native-touchable-scale
interface Props {
  currentScreen: number;
  setCurrentScreen: (value: number) => void;
  selectedCarrier: carrier | null;
  setSelectedCarrier: (value: {
    name: string;
    shortName: string;
    companyId: string;
    role: string;
    type: string;
  }) => void;
}
export default function Carriers({
  selectedCarrier,
  setSelectedCarrier,
  currentScreen,
  setCurrentScreen,
}: Props) {
  const [checked, setChecked] = React.useState('sorry');
  const [carriesTotal, setCarriesTotal] = useState(0);

  const {props, error, retry} = useQuery<CarriesListQuery>(query, {
    input: Device,
  });

  const createErrorAlert = (message: any) => {
    Alert.alert(
      'Error',
      'Unable to get Bus Carriers, please try again later' + message
    );
  };

  const getItem = (item: carrier) => {
    setChecked(item.companyId);
    setSelectedCarrier(item);
    setCurrentScreen(2);
  };

  const ItemView = ({
    item,
    active,
    selectItem,
  }: {
    item: carrier;
    active: any;
    selectItem: any;
  }) => {
    return (
      // Flat List Item
      <Box
        paddingSize="medium"
        align="center"
        justify="flex-start"
        row
        width="100%"
      >
        <View style={{flexDirection: 'column'}}>
          <Box flex={1} align="flex-start" justify="flex-start">
            <View style={{left: 20}}>
              <Text>{item.name}</Text>
              <Text>Name:{item.name}</Text>
              <Text>Role: {item.role}</Text>
              <Text>Type: {item.type}</Text>
            </View>
          </Box>
          <View style={{left: 300}}>
            <RadioButton
              value={item.companyId}
              status={checked === item.companyId ? 'checked' : 'unchecked'}
              onPress={() => getItem(item)}
            />
          </View>
        </View>
      </Box>
    );
  };

  const ItemSeparatorView = () => {
    return (
      // Flat List Item Separator
      <View
        style={{
          height: 0.5,
          width: '100%',
          backgroundColor: '#C8C8C8',
        }}
      />
    );
  };
  if (error) createErrorAlert(error.message);
  let list: any[] = [];
  if (props && props.carriers.edges) {
    const {
      carriers: {edges = []},
    } = props;
    list = props.carriers?.edges ? edges.map((edge) => edge.node) : [];
  }

  const stockList = () => {
    return (
      <FlatList
        style={{marginTop: 16, marginBottom: 16, width: '100%'}}
        data={list}
        keyExtractor={(item, index) => index.toString()}
        ItemSeparatorComponent={ItemSeparatorView}
        renderItem={({item}) => {
          return (
            <ItemView
              item={item}
              active={selectedCarrier?.companyId === item.companyId}
              selectItem={() => {
                getItem(item);
              }}
            />
          );
        }}
      />
    );
  };

  return list.length > 0 ? (
    <View style={{flex: 1}}>{stockList()}</View>
  ) : (
    <View style={{flex: 1}}>
      <Box>
        <Text>Loading Carriers...</Text>
      </Box>
    </View>
  );
}
