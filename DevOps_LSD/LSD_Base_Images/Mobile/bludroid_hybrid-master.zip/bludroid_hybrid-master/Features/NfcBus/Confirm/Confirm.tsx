import {StatusBar} from 'expo-status-bar';
import React, {useState} from 'react';
import {StyledTextInput} from '../../../Components/StyledTextInput';
import {
  Keyboard,
  KeyboardAvoidingView,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableWithoutFeedback,
  View,
  TouchableOpacity,
  Image,
  TextInput,
  Alert,
} from 'react-native';
import {RadioButton} from 'react-native-paper';
import styling from './ConfirmStyle';
import * as yup from 'yup';
import {Field, Formik} from 'formik';
import {Button} from 'react-native-elements';
import {ValuesOfCorrectTypeRule} from 'graphql';
type Ticket = {
  id: Number;
  ticketId: Number;
  ticketNo: String;
  ticketType: String;
  routeId1: Number;
  routeId2: Number;
  routeCode1: String;
  routeCode2: String;
  fare: Number;
  fareProductId: String;
  departureLocationId: String;
  destinationLocationId: String;
  activationDate: Date;
  expiryDate: Date;
  ticketDate: Date;
  numberOfDaysTrips: Number;
  numberOfTransfers: Number;
  status: String;
  rules: String;
  fareCurrency: String;
};
type Fare = {
  id: Number;
  sessionId: String;
  responseCode: Number;
  responseMessage: String;
  status: Number;
  period: String;
  routeId2: String;
  fareProductId: String;
  code: String;
  routeId1: String;
  companyId: Number;
  weekdays: String;
  created: Date;
  availableFrom: Date;
  availableTo: Date;
  transferCount: Number;
  passValue: Number;
  tripsPerDay: Number;
  passType: String;
  price: Number;
  name: String;
  shortName: String;
  desc: String;
};
type stop = {
  name: String;
  id: String;
};
type destination = {
  locationId: String;
  type: String;
  stationId: String;
  entityId: String;
  name: String;
};
interface Props {
  userName: string | null;
  setUserName: (value: string) => void;
  cellphone: string | null;
  setCellphone: (value: string) => void;
  paymentMethod: string | null;
  setPaymentMethod: (value: string) => void;
  destination: destination | null;
  depature: stop | null;
  selectedFare: Fare | null;
  setCurrentScreen: (value: number) => void;
}
export default function Confirm({
  userName,
  setUserName,
  cellphone,
  setCellphone,
  paymentMethod,
  setPaymentMethod,
  destination,
  depature,
  setCurrentScreen,
  selectedFare,
}: Props) {
  const phoneRegEx = /^(\+?\d{0,4})?\s?-?\s?(\(?\d{3}\)?)\s?-?\s?(\(?\d{3}\)?)\s?-?\s?(\(?\d{4}\)?)?$/;
  const validationSchema = yup.object().shape({
    name: yup.string().required('This is a required field'),
    payment: yup.string().required('This is a required field'),
    mobile: yup
      .string()
      .required('This is a required field')
      .matches(phoneRegEx, 'Phone number is not valid'),
  });

  const handleSelect = (item: any) => {
    setPaymentMethod(item);
    setCurrentScreen(4);
  };
  return (
    <SafeAreaView style={{flex: 1}}>
      <Formik
        validateOnBlur
        validationSchema={validationSchema}
        initialValues={{
          name: userName || '',
          payment: paymentMethod || '',
          mobile: cellphone || '',
        }}
        onSubmit={(values) => {
          setCellphone(values.mobile);
          setUserName(values.name);
          setPaymentMethod(values.payment);
        }}
      >
        {({handleSubmit, setFieldValue, values}) => (
          <>
            <View>
              <Text style={{color: 'navy', padding: 10}}>
                {' '}
                Depature:{depature?.name}
              </Text>
              <Text style={{color: 'navy', padding: 10}}>
                {' '}
                Destination:{destination?.name}
              </Text>
            </View>
            <View style={styling.container}>
              <View
                style={{
                  backgroundColor: 'white',
                  width: '100%',
                  borderRadius: 12,
                  marginBottom: 10,
                  flexDirection: 'row',
                  marginTop: -40,
                }}
              >
                <View style={{left: 200}}>
                  <Text style={styling.text}>{selectedFare?.name}</Text>
                  <Text style={styling.text}>
                    {selectedFare?.availableFrom}
                  </Text>
                  <Text style={styling.text}>{selectedFare?.availableTo}</Text>
                  <Text style={styling.text}>R{selectedFare?.price}</Text>
                </View>
              </View>
            </View>
            <KeyboardAvoidingView>
              <View
                style={{
                  marginTop: -30,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Text style={{color: 'navy', padding: 30}}>
                  Select Payment Option
                </Text>
                <View style={{flexDirection: 'row', top: -30}}>
                  <RadioButton
                    value="first"
                    status={
                      values.payment === 'first' ? 'checked' : 'unchecked'
                    }
                    onPress={() => handleSelect('Cash')}
                  />
                  <Text style={{color: 'navy', padding: 10}}>Cash</Text>
                  <RadioButton
                    value="second"
                    status={
                      values.payment === 'second' ? 'checked' : 'unchecked'
                    }
                    onPress={() => handleSelect('Credit')}
                  />
                  <Text style={{color: 'navy', padding: 10}}>Credit</Text>
                  <RadioButton
                    value="third"
                    status={
                      values.payment === 'third' ? 'checked' : 'unchecked'
                    }
                    onPress={() => handleSelect('Debit')}
                  />
                  <Text style={{color: 'navy', padding: 10}}>Debit</Text>
                </View>
              </View>
            </KeyboardAvoidingView>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
}
