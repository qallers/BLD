import React from "react";
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from "react-native-popup-menu";
import { Ionicons } from "@expo/vector-icons";
import { View, TouchableOpacity } from "react-native";
import {
  NavigationHelpersContext,
  useLinkProps,
  useNavigation,
} from "@react-navigation/native";

export default function Header() {
  const navigation = useNavigation();
  return (
    <Menu style={{ shadowColor: "white" }}>
      <MenuTrigger>
        <Ionicons name="ios-more" size={23} color="white" />
      </MenuTrigger>

      <MenuOptions
        optionsContainerStyle={{
          marginTop: 40,
          width: 100,
        }}
      >
        <MenuOption onSelect={() => alert("Account")} text="Account" />
        <MenuOption onSelect={() => alert("Profile")} text="Profile" />

        <MenuOption
          // todo: David to implement logout in auth context
          onSelect={() => navigation.navigate("Login")}
          text="Log out"
        />
      </MenuOptions>
    </Menu>
  );
}
