import React, { useState } from "react";
import { StyleSheet, View } from "react-native";
import ViewPager from "@react-native-community/viewpager";
import PagerIndicator from "./PagerIndicator";

type Props = {
  items: [any]; //array of components/pages
  initial?: number; //optional (default 0) - initial index of items to be displayed
};

export default function Pager(props: Props) {
  const [index, setIndex] = useState(0);

  return (
    <View style={styles.container}>
      <ViewPager
        style={styles.viewPager}
        initialPage={props.initial}
        showPageIndicator={false}
        onPageSelected={(e) => setIndex(e.nativeEvent.position)}
      >
        {props.items}
      </ViewPager>
      {props.items.length > 1 && (
        <View style={styles.indicator}>
          <PagerIndicator length={props.items.length} active={index} />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  viewPager: {
    flex: 1,
  },
  indicator: {
    width: "100%",
    alignItems: "center",
    position: "absolute",
    bottom: 5,
  },
});
