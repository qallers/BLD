import React from 'react';
import styled from 'styled-components/native';
import {TextProps} from 'react-native';

interface TextH1Props extends TextProps {
  type?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'body';
  alignment?: 'left' | 'center' | 'right';
  primary?: boolean;
  secondary?: boolean;
  tertiary?: boolean;
  inverted?: boolean;
  greyed?: boolean;
  color?: string;
  scalable?: boolean;
  noFont?: boolean;
  children: React.ReactNode;
}

// Default background view for all screens
const TextH1Style = styled.Text<TextH1Props>`
  ${({noFont, theme, type = 'body'}) =>
    !noFont && `font-family: ${theme.typography[type].fontFamily}`};
  font-size: ${({theme, type = 'body'}) => theme.typography[type].fontSize}px;
  font-weight: ${({theme, type = 'body'}) => theme.typography[type].weight};
  line-height: ${({theme, type = 'body'}) =>
    theme.typography[type].lineHeight}px;
  color: ${({theme, primary, secondary, tertiary, inverted, greyed, color}) => {
    // if greyed out do that immediately and return no other colour
    if (greyed) {
      return theme.colors.textGreyed;
    } else if (color) {
      return color;
    } else if (inverted) {
      return theme.colors.textInverted;
    } else if (primary) {
      return theme.colors.textPrimary;
    } else if (secondary) {
      return theme.colors.textSecondary;
    } else if (tertiary) {
      return theme.colors.textTertiary;
    } else {
      return theme.colors.textPrimary; // defaults to primary colour if nothing is seleccted
    }
  }};
  text-align: ${({alignment = 'left'}) => {
    return alignment;
  }};
`;

export function Text({scalable, children, ...props}: TextH1Props) {
  return (
    <TextH1Style allowFontScaling={Boolean(scalable)} {...props}>
      {children}
    </TextH1Style>
  );
}
