import React from 'react';
import styled from 'styled-components/native';
import {ScrollView} from 'react-native-gesture-handler';
import {hPerc} from '../helpers/DeviceScalling';

interface ViewBackgroundProps {
  primary?: boolean;
  secondary?: boolean;
  tertiary?: boolean;
  inverted?: boolean;
  greyed?: boolean;

  noScroll?: boolean; // if children shouldn't be wrapped in scroll view
}

// Default background view for all screens
const ViewBackgroundStyle = styled.View<ViewBackgroundProps>`
  height: ${hPerc(100)}px;
  background-color: ${({
    theme,
    primary,
    secondary,
    tertiary,
    inverted,
    greyed,
  }) => {
    // if greyed out do that immediately and return no other colour
    if (greyed) {
      return theme.colors.bgGreyed;
    } else if (inverted) {
      return theme.colors.bgInverted;
    } else if (primary) {
      return theme.colors.bgPrimary;
    } else if (secondary) {
      return theme.colors.bgSecondary;
    } else if (tertiary) {
      return theme.colors.bgTertiary;
    } else {
      return theme.colors.bgPrimary; // defaults to primary colour if nothing is seleccted
    }
  }};
`;

const ViewBackground: React.FunctionComponent<ViewBackgroundProps> = (
  props
) => {
  return (
    <ViewBackgroundStyle {...props}>
      {props.noScroll ? (
        props.children
      ) : (
        <ScrollView>{props.children}</ScrollView>
      )}
    </ViewBackgroundStyle>
  );
};

export {ViewBackground};
