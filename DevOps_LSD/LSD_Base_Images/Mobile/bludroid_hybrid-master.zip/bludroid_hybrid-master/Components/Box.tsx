import React from "react";
import styled from "styled-components/native";
import { StyleProp, ViewStyle } from "react-native";

interface Props {
  aspectRatio?: number;
  row?: boolean;
  padded?: boolean | "horizontal" | "vertical";
  paddingSize?: "tiny" | "small" | "medium" | "large";
  justify?:
    | "flex-start"
    | "flex-end"
    | "center"
    | "space-between"
    | "space-evenly"
    | "space-around";
  align?: "stretch" | "center" | "flex-start" | "flex-end";
  children?: React.ReactNode;
  flex?: number;
  shrink?: number;
  style?: StyleProp<ViewStyle>;
  width?: string;
  height?: string;
  primary?: boolean;
  secondary?: boolean;
  tertiary?: boolean;
  inverted?: boolean;
  greyed?: boolean;
  navyGrey?: boolean;
  background?: boolean;
}

const BoxStyle = styled.View<Props>`
  
  flex-shrink: ${({ shrink }) => (shrink ? shrink : 0)}
  flex-direction: ${({ row }) => (row ? "row" : "column")};
  padding: ${({ padded, paddingSize = "small", theme }) =>
    padded
      ? padded === "vertical"
        ? `${theme.padding[paddingSize]}px 0px ${theme.padding[paddingSize]}px 0px`
        : padded === "horizontal"
        ? `0px ${theme.padding[paddingSize]}px 0px ${theme.padding[paddingSize]}px `
        : `${theme.padding[paddingSize]}px`
      : "0px"};
  justify-content: ${({ justify }) => (justify ? justify : "center")};
  align-items: ${({ align }) => (align ? align : "center")};
  ${({ flex }) => {
    return (flex || flex === 0) && `flex: ${flex};`;
  }}
  ${({ aspectRatio }) => {
    return aspectRatio && `aspect-ratio: ${aspectRatio};`;
  }}
  ${({ width }) => {
    return width && `width: ${width};`;
  }}
  ${({ height }) => {
    return height && `height: ${height};`;
  }}
  background-color: ${({
    theme,
    primary,
    secondary,
    tertiary,
    inverted,
    greyed,
    navyGrey,
    background,
  }) => {
    // if greyed out do that immediately and return no other colour
    if (greyed) {
      return theme.colors.fgGreyed;
    } else if (inverted) {
      return theme.colors.fgInverted;
    } else if (primary) {
      return theme.colors.fgPrimary;
    } else if (secondary) {
      return theme.colors.fgSecondary;
    } else if (tertiary) {
      return theme.colors.fgTertiary;
    } else if (navyGrey) {
      return theme.colors.specific.brandNavy80;
    } else if (primary) {
      return theme.colors.fgPrimary;
    } else if (background) {
      return theme.colors.bgPrimary;
    } else {
      return "transparent";
    }
  }};
`;

export function Box({ children = null, style, ...props }: Props) {
  return (
    <BoxStyle {...props} style={style && style}>
      {children}
    </BoxStyle>
  );
}
