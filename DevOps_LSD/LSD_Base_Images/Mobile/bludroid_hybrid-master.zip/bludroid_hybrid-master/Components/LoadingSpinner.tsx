import LoadingSpinnerImage from '../assets/images/animated/loadingSpinner.gif';
import {wdp} from '../helpers/DeviceScalling';
import {Image} from 'react-native';
import React from 'react';
import {Box} from './Box';

interface Props {
  size: number;
}

export function LoadingSpinner({size}: Props) {
  return (
    <Box>
      <Image
        source={LoadingSpinnerImage}
        style={{width: wdp(size), height: wdp(size)}}
      />
    </Box>
  );
}
