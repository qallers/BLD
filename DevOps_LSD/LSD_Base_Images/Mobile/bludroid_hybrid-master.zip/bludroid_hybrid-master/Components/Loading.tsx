import * as React from 'react';

import {ViewBackground} from './ViewBackground';
import {LoadingSpinner} from './LoadingSpinner';
import {Box} from './Box';
import {Text} from './Text';
import {wdp} from '../helpers/DeviceScalling';
interface Props {
  message?: string;
  noFont?: boolean; // when using loading screen before fonts are loaded, don't use font
}

export function Loading({message, noFont}: Props) {
  return (
    <ViewBackground noScroll>
      <Box flex={1}>
        <LoadingSpinner size={wdp(300)} />
        <Text type="h1" noFont={noFont}>
          {message}
        </Text>
      </Box>
    </ViewBackground>
  );
}
