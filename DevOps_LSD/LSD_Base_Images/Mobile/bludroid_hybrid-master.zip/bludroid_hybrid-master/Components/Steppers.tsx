import React from 'react';
import {View} from 'react-native';
import styled from 'styled-components';

interface Props {
  step: number;
  total: number;
}

const DotContainer = styled(View)`
  display: flex;
  flex-direction: row;
  justify-content: center;
`;

const Dot = styled(View)`
  width: 8px;
  height: 8px;
  margin: 0 8px;
  border-radius: 8px;
  border-width: 2px;
  border-color: gray;
`;

export const Stepper = ({step, total}: Props) => {
  const dots = () => {
    const dotBuilder: JSX.Element[] = [];
    for (let i = 1; i <= total; i++) {
      dotBuilder.push(
        <Dot
          key={`dot-${i}`}
          style={{backgroundColor: step === i ? 'transparent' : 'gray'}}
        />
      );
    }
    return dotBuilder;
  };
  return <DotContainer>{dots().map((dot) => dot)}</DotContainer>;
};
