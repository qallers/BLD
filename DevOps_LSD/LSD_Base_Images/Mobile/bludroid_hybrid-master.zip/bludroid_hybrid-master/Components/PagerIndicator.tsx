import React from "react";
import { StyleSheet, View } from "react-native";

const DEFAULT_PASSIVE_DOT_WIDTH = 6;
const DEFAULT_ACTIVE_DOT_WIDTH = 8;

type Props = {
  length: number;
  active: number;
};

export default function PagerIndicator(props: Props) {
  const list = Array.from(Array(props.length).keys());

  return (
    <View style={styles.container}>
      {list.map((i) => {
        return <View key={i} style={dotStyle(isActive(i, props))} />;
      })}
    </View>
  );
}

function isActive(index: number, props: Props) {
  return props.active === index;
}

function dotStyle(isActive: boolean) {
  const width = isActive ? DEFAULT_ACTIVE_DOT_WIDTH : DEFAULT_PASSIVE_DOT_WIDTH;
  const marginTop = 0;

  let height = width;

  let style = {
    width,
    height,
    marginHorizontal: 2,
    borderRadius: width,
    borderColor: isActive ? "#fff" : "#ddd",
    backgroundColor: isActive ? "transparent" : "#ddd",
    borderWidth: 2,
    marginTop,
  };

  return style;
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    backgroundColor: "transparent",
    alignItems: "center",
  },
});
