import React, {Component} from 'react';
import {ThemeProvider} from 'styled-components';
import {RelayEnvironmentProvider} from 'relay-hooks';

import {ContextController} from './context/AuthContext';
import themeSettings from './theme/themeSettings';
import {createRelayEnv} from './relay/relay';
//Screens
import {NfcBusNavigation} from './Features/NfcBus/Default/Default';

import {MenuProvider} from 'react-native-popup-menu';
import {StatusBar} from 'expo-status-bar';
import {ApiTestNavigation} from './Features/ApiTest/ApiTest';
import {GlobalAirtimeNavigation} from './Features/GlobalAirtime/Lookup/LookupScreen';
import ResultModule from './modules/results/ResultModule';
import {InterAirTestNavigation} from "./Features/InternationalAirtimeTest/InterAirTest";


function getServerUri(props: Props) {
  //.env goes before here.
  if (props.server.url){
    return props.server.url;
  } else if (process.env.APP_SERVER_URI) {
    return process.env.APP_SERVER_URI;
  }
  return 'http://127.0.0.1:5000';
}

interface Props {
  auth: AuthProps;
  target: string;
  theme: string;
  server: {
    url: string;
    token: string;
  }
}

interface AuthProps {
  devId: string;
  serial: string;
  userPin: string;
}

class App extends Component<Props> {

  constructor(props: any) {
    super(props);
  }

  render() {
    return (
      <MenuProvider>
        <StatusBar style="light" />
        <ContextController>
          <AppNetworking props={this.props} />
        </ContextController>
      </MenuProvider>
    );
  }
}

function AppNetworking(props: any) {
  const handleLogout = () => {};

  // if token exists, save it
  // const token = auth.token ? auth.token : '';
  const serverUri = getServerUri(props.props);
  console.log('serverUri', serverUri);
  console.log('auth token', props.props.server.token);
  const environment = createRelayEnv(serverUri, handleLogout, props.props.server.token);

  return (
    <RelayEnvironmentProvider environment={environment}>
      <ThemeProvider theme={themeSettings}>
        {getFeature(props.props)}
      </ThemeProvider>
    </RelayEnvironmentProvider>
  );
}

function getFeature(props: any) {
  switch (props.target) {
    case 'NFC Bus':
      return NfcBusNavigation(props);

    case 'API Test':
      return ApiTestNavigation(props);

    case 'Global Airtime':
      return GlobalAirtimeNavigation(props);

    case 'International Airtime':
      return InterAirTestNavigation(props);

    default:
      ResultModule.returnResult(false, 'Invalid target');
      break;

  }
}

export default App;
