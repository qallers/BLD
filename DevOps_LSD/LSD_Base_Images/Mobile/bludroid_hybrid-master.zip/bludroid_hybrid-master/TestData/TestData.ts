export const Device = {
  deviceId: '29851',
  serialNum: 'P130189801394',
  userPin: '011234',
  location: '',
  swVer: '',
};


  export const iaAuth = {
        deviceId: "29851",
        network: "IPAY",
        userPin: "011234",
        deviceSer: "P130189801394",
        reference: "29149_1539163763756"
  };
  