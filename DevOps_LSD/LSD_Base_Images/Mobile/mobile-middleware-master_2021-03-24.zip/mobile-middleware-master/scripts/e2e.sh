#!/bin/bash
set -e

cd modules/server
yarn test:e2e