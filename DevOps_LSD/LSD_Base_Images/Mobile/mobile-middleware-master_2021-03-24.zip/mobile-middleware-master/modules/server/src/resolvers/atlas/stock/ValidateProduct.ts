import {RepApi} from '@stackworx/bluelabel-atlas';
import {QueryResolvers} from '../../../generated/graphql';
import config from '../../../config';
import {atlasAuthCheck} from '../../auth/AtlasHelpers';

/*
query {
  validateProduct (input: {barcode: "1606891012"}) {
    success
    message
    product {
      product_id
      code
      desc
      qty
    }
  }
}
 */

export const validateProduct: QueryResolvers['validateProduct'] = async function (
  _parent: any,
  {input: {barcode}},
  context: any,
  _info: any
) {
  try {
    const headers = atlasAuthCheck(context);
    const api = new RepApi(config.get('atlasAddress'));
    return await api
      .scanMobileInvoice(barcode, headers)
      .then((res) => {
        return {
          success: res.body.success,
          message: 'Success',
          product: {
            product_id: res.body.data.id,
            code: res.body.data.product_code,
            desc: res.body.data.description,
            qty: res.body.data.qty,
          },
        };
      })
      .catch((err) => {
        return {
          success: false,
          message: err.body.error.message,
          product: null,
        };
      });
  } catch (e) {
    return {success: false, message: e.message, product: null};
  }
};
