import {aeonConnect} from '../AeonConnect';
import {QueryResolvers} from '../../../generated/graphql';
import {isIterable} from '../../../util';

interface Company {
  name: string;
  short_name: string;
  company_id: string;
  role: string;
  type: string;
}

export const carriers: QueryResolvers['Carriers'] = async function (
  _parent: any,
  input: any,
  _context: any,
  _info: any
) {
  try {
    const authData = input.input;
    if (!authData) {
      return {edges: {}};
    }
    const data = await aeonConnect(
      // @ts-ignore
      authData,
      'SmartTapEldo',
      'ListCarriers',
      {}
    );
    // console.log({data: data.response.response})
    let companies =
      // @ts-ignore
      data.response.response.ResponseMessage.companies.companies;
    // console.log({companies});
    if (!isIterable(companies)) {
      companies = [companies];
    }
    const output = companies.map((company: Company) => {
      return {
        cursor: company.company_id,
        node: {
          name: company.name,
          shortName: company.short_name,
          companyId: company.company_id,
          role: company.role,
          type: company.type,
        },
      };
    });
    return {
      totalCount: companies.length,
      edges: output,
    };
  } catch (e) {
    console.log(e);
    return {
      totalCount: 0,
      edges: [],
    };
  }
};
