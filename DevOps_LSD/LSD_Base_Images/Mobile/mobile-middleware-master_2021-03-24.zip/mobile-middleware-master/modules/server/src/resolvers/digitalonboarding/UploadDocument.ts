import got from 'got';
import config from '../../config';
import {getApplicationStatus} from './GetApplicationStatus';

enum DigitalOnboardingDocumentType {
  Contract = 'Contract',
  Supporting = 'SupportingDocument',
}

interface DigitalOnboardingDocument {
  _type: DigitalOnboardingDocumentType;
  Base64encoded_file: string;
  filename: string;
}

interface NameStatus {
  Name: string;
  Status: boolean;
}

const uploadDocument = async (
  applicationId: number,
  document: DigitalOnboardingDocument
) => {
  try {
    //check if document already exists on Digital Onboarding and if so, return successful
    const status = await getApplicationStatus(applicationId);
    const completed = status.find(
      (d: NameStatus) => d.Name === 'Document_' + document._type
    ).Status;
    if (completed) {
      // console.log('Document (' + document._type + ') already uploaded!!');
      return true;
    }

    const uri = `${config.get(
      'mendixAddress'
    )}/digitalonboarding/v1/registration/upload/document`;
    const output = await got.post(uri, {
      headers: {
        Authorization: 'Basic VDNUQXBwOlF3ZXJAMTIzNA==',
        ApplicationId: applicationId.toString(),
      },
      json: document,
      responseType: 'json',
    });
    // console.log(output.body);

    if (!output.body) {
      return false;
    }
    return output.body;
  } catch (ex) {
    console.log(ex.message);
    return false;
  }
};

export {
  uploadDocument,
  DigitalOnboardingDocument,
  DigitalOnboardingDocumentType,
};
