import {QueryResolvers} from '../../../generated/graphql';
import {aeonAuth} from '../AeonAuth';

/*
query {
  bankDetails {
    totalCount
    edges {
      cursor
      node {
        id,
		    bank,
		    accountName,
    		accountNumber,
    		branch,
    		branchCode,
    		universalCode,
    		swift,
    		reference
      }
    }
  }
}
 */

export const bankDetails: QueryResolvers['bankDetails'] = async function (
  _parent: any,
  _args: any,
  context: any,
  _info: any
) {
  const bankDetails: any = [];
  try {
    const authData = await aeonAuth(context);
    if (!authData) {
      return {
        edges: null,
        totalCount: 0,
      };
    } else {
      bankDetails.push({
        cursor: Buffer.from('BankDetail:1').toString('base64'),
        node: {
          id: Buffer.from('BankDetail:1').toString('base64'),
          bank: 'ABSA',
          accountName: 'Blue Label Distribution Senda',
          accountNumber: '40-7781-2446',
          branch: 'Sandton City',
          branchCode: '631005',
          universalCode: '632005',
          swift: 'ABSAZAJJ',
          reference: authData.account,
        },
      });

      /*
      bankDetails.push({
        cursor: Buffer.from('BankDetail:2').toString('base64'),
        node: {
          id: Buffer.from('BankDetail:2').toString('base64'),
          bank: 'FNB',
          accountName: 'Blue Label Distribution Senda',
          accountNumber: '123-456-789',
          branch: 'Branch Name',
          branchCode: '000001',
          universalCode: '000002',
          swift: 'ABCDEF',
          reference: authData.account,
        },
      });
      bankDetails.push({
        cursor: Buffer.from('BankDetail:3').toString('base64'),
        node: {
          id: Buffer.from('BankDetail:3').toString('base64'),
          bank: 'Standard Bank',
          accountName: 'Blue Label Distribution Senda',
          accountNumber: '987-654-321',
          branch: 'Branch name',
          branchCode: '000003',
          universalCode: '000004',
          swift: 'ZYXWVU',
          reference: authData.account,
        },
      });
*/

      return {
        edges: bankDetails,
        totalCount: bankDetails.length,
      };
    }
  } catch (e) {
    return {
      edges: null,
      totalCount: 0,
    };
  }
};
