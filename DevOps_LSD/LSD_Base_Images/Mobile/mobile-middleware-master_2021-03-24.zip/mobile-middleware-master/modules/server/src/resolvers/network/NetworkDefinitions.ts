export const NetworkCellC = {
  name: 'CellC',
  colour: '#F15A23',
  logo: 'https://image-repo.qa.bltelecoms.net/cellc.png',
};

export const NetworkMtn = {
  name: 'MTN',
  colour: '#FFCC01',
  logo: 'https://image-repo.qa.bltelecoms.net/mtn.png',
};

export const NetworkNeotel = {
  name: 'Neotel',
  colour: '#BFD7EA',
  logo: 'https://image-repo.qa.bltelecoms.net/neotel.png',
};

export const NetworkTelkomMobile = {
  name: 'TelkomMobile',
  colour: '#BFD7EA',
  logo: 'https://image-repo.qa.bltelecoms.net/telkom.png',
};

export const NetworkVodacom = {
  name: 'Vodacom',
  colour: '#B11016',
  logo: 'https://image-repo.qa.bltelecoms.net/vodacom.png',
};

export const AtlasNetworkIdMap = {
  MTN: 1,
  CellC: 2,
  TelkomMobile: 4,
  Vodacom: 3,
};
