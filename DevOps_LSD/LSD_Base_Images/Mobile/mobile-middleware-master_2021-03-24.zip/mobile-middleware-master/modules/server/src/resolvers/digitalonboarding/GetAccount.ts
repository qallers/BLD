import got from 'got';
import config from '../../config';

const getAccount = async (applicationId: number) => {
  try {
    const uri = `${config.get(
      'mendixAddress'
    )}/digitalonboarding/v1/registration/account`;
    const output = await got.get(uri, {
      headers: {
        Authorization: 'Basic VDNUQXBwOlF3ZXJAMTIzNA==',
        ApplicationID: applicationId.toString(),
      },
    });

    if (!JSON.parse(output.body)) {
      return false;
    }
    return JSON.parse(output.body);
  } catch (ex) {
    console.log(ex);
    return false;
  }
};

export {getAccount};
