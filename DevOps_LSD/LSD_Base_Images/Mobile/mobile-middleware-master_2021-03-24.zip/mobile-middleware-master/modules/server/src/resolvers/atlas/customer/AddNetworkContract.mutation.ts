import {CustomersApi} from '@stackworx/bluelabel-atlas';
import config from '../../../config';
import {MutationResolvers} from '../../../generated/graphql';
import {atlasAuthCheck} from '../../auth/AtlasHelpers';
import {AtlasNetworkIdMap} from '../../network/NetworkDefinitions';
/*
mutation {
  addNetworkContract(input: {network: MTN, customerId:4000, name:"MPKTest", ogr:1, act:2, sim:3}) {
    success
    message
  }
}
*/

export const addNetworkContract: MutationResolvers['addNetworkContract'] = async function (
  _parent: any,
  {input: {name, customerId, network, isTiered, isSplit, ogr, act, sim}},
  context: any,
  _info: any
) {
  try {
    const headers = atlasAuthCheck(context);
    const api = new CustomersApi(config.get('atlasAddress'));
    const contractResult = await api
      .rep(
        name,
        customerId.toString(),
        AtlasNetworkIdMap[network].toString(),
        isTiered || false,
        isSplit || false,
        ogr.toFixed(2),
        act,
        sim,
        headers
      )
      .then((res) => res.body);

    const success = contractResult.success;
    return {success, message: 'Success'};
  } catch (ex) {
    console.log(ex);
    return {success: false, message: ex.message};
  }
};
