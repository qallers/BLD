import got from 'got';
import {UserApi} from '@stackworx/bluelabel-atlas';
import {MutationResolvers} from '../../generated/graphql';
import config from '../../config';
import {getExternalSystemReference} from '../atlas/customer/ExternalSystemReference';

interface Role {
  id: string;
  description: string;
  slug: string;
}

export const authValidation: MutationResolvers['authValidation'] = async function (
  _parent,
  {input: {username, password, clientMutationId, currentStatus}},
  _context,
  _info
) {
  try {
    // currently manually accessed since could not auto gen swagger login call
    const uri = `${config.get(
      'atlasAddress'
    )}/api/v1/login/alternative?username=${username}&password=${password}`;

    const output = await got.post(uri, {});
    const parsedOutput = JSON.parse(output.body);
    const authToken = `Bearer ${JSON.parse(output.body).access_token}`;
    const headers = {headers: {authorization: authToken}};

    const api = new UserApi(config.get('atlasAddress'));
    const profileResult = await api
      .getProfile(headers)
      .then((res) => res.body.data);
    const typesResult = await api
      .getTypes(headers)
      .then((res) => res.body.data);

    const {
      id: roleId,
      description: roleDescription,
      slug: roleSlug,
    } = typesResult.find((role: Role) => role.id == profileResult.user_type_id);

    let status = 5;
    if (currentStatus !== 5) {
      //getting external system reference
      const registerStatus = await getExternalSystemReference(headers, 4);
      //Get status from registerStatus
      //For rep, agent and consumer, the registerStatus will have no items so will set status to -2
      const regDetails = registerStatus[registerStatus.length - 1]
        ? registerStatus[registerStatus.length - 1]
        : {data: '{"status": 5}'};
      const {data} = regDetails;
      status = JSON.parse(data).status;
    }

    if (parsedOutput && parsedOutput.access_token) {
      return {
        authorized: true,
        token: JSON.parse(output.body).access_token,
        status,
        profile: {
          id: profileResult.id,
          customerId: profileResult.customer.id,
          username: profileResult.username,
          firstName: profileResult.first_name,
          lastName: profileResult.last_name,
          email: profileResult.email,
          userType: {
            id: roleId,
            description: roleDescription,
            slug: roleSlug,
          },
        },
        clientMutationId,
      };
    } else {
      return {
        authorized: false,
        token: null,
        status: 0,
        profile: null,
        clientMutationId,
      };
    }
  } catch (ex) {
    console.warn(ex);
    return {
      authorized: false,
      clientMutationId,
      token: null,
      status: 0,
      profile: null,
    };
  }
};
