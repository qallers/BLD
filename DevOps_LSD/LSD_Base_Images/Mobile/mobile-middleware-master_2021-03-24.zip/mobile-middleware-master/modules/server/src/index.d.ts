declare namespace Express {
  export interface Request {
    user?:
      | {username: string; anonymous: false; roles: string[]}
      | {anonymous: true};
  }
}
