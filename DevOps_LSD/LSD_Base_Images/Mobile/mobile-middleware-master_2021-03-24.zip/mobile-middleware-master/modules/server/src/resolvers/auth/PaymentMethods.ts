import {CustomersApi} from '@stackworx/bluelabel-atlas';
import {QueryResolvers} from '../../generated/graphql';
import config from '../../config';
import {atlasAuthCheck} from './AtlasHelpers';

// @ts-ignore
export const paymentMethods: QueryResolvers['paymentMethods'] = async function (
  _parent,
  _context,
  info
) {
  try {
    const headers = atlasAuthCheck(info);
    const api = new CustomersApi(config.get('atlasAddress'));
    const paymentResult = await api
      .getPaymentMethods(headers)
      .then((res) => res.body.data);

    return paymentResult;
  } catch (ex) {
    console.log(ex);
    // on any errors, do not return profile
    return null;
  }
};
