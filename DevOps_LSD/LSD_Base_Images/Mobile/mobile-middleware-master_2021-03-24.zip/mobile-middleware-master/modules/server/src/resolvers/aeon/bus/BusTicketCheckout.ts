import {aeonConnect} from '../AeonConnect';
import {BusAccount, MutationResolvers} from '../../../generated/graphql';

interface BusTicketCheckoutInput {
  uid: string;
  ticketType: string;
  referenceId: string;
  fareProductId: string;
  amount: string;
  companyId: string;
  svcData: [object];
  auth: BusAccount;
}

interface Input {
  input: BusTicketCheckoutInput;
}

// const testData = {
//   deviceId: 29851,
//   serialNum: 'P130189801394',
//   userPin: '011234',
//   location: '',
//   swVer: 'bluShift',
// };

export const busTicketCheckout: MutationResolvers['BusTicketCheckout'] = async function (
  _parent: any,
  {
    input: {
      uid,
      ticketType,
      referenceId,
      fareProductId,
      amount,
      companyId,
      svcData,
      auth,
    },
  }: Input,
  _context: any,
  _info: any
) {
  let data: any = {};
  try {
    const event = {
      uid: uid,
      ticketType: ticketType,
      referenceId: referenceId,
      fareProductId: fareProductId,
      amount: amount,
      companyId: companyId,
      svcData: svcData,
    };

    //Amount too low error
    // const event = {
    //   AirtimePlus: 0,
    //   Amount: -10,
    //   PhoneNumber: '0736549000',
    //   Print: 0,
    //   Reference: '29853_1600843228610',
    //   SupplierName: 'supplier',
    // };

    //Invalid phone number
    // const event = {
    //   AirtimePlus: 0,
    //   Amount: 10,
    //   PhoneNumber: '0821231234',
    //   Print: 0,
    //   Reference: '29853_1600843228610',
    //   SupplierName: 'supplier',
    // };

    if (!auth) {
      return {success: false, message: data.message};
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    data = await aeonConnect(auth, 'SmartTapEldo', 'Checkout', event);
    const output = data.response.response;
    console.log({output});
    const ticket = output.ResponseMessage.ticket;
    const sectors = output.ResponseMessage.svc_data.svc_data;

    return {
      svcData: {sectors: sectors},
      ticket: {
        id: ticket.ticket_id,
        companyId: ticket.company_id,
        ticketId: ticket.ticket_id,
        ticketNo: ticket.ticket_no,
        ticketType: ticket.ticket_type,
        routes: {
          // routes:ticket.routes.routes
          //TODO fix, pending change from Bpass
          routes: [],
        },
        fare: ticket.fare,
        fareProductId: ticket.fare_product_id,
        departureLocationId: ticket.departure_location_id,
        destinationLocationId: ticket.destination_location_id,
        activationDate: ticket.activation_date,
        expiryDate: ticket.expiry_date,
        ticketDate: ticket.ticket_date,
        numberOfDaysTrips: ticket.no_of_days_trips,
        numberOfTransfers: ticket.no_of_transfers,
        status: ticket.status,
        rules: ticket.rules,
        fareCurrency: ticket.fare_currency,
      },
      transaction: {
        id: output.ResponseMessage.transaction.transaction_id,
        amount: output.ResponseMessage.transaction.amount,
        name: output.ResponseMessage.transaction.reference_id,
        description: output.ResponseMessage.transaction.uid,
      },
      transref: output.ResponseMessage.transref,
    };

    // return {success: true, message: data.message};
  } catch (e) {
    return {success: false, message: e.message};
  }
};
