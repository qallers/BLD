import got from 'got';
import config from '../../config';

const completeRegistration = async (applicationId: number) => {
  try {
    const uri = `${config.get(
      'mendixAddress'
    )}/digitalonboarding/v1/registration/complete`;
    const output = await got.post(uri, {
      headers: {
        Authorization: 'Basic VDNUQXBwOlF3ZXJAMTIzNA==',
        ApplicationID: applicationId.toString(),
      },
    });

    if (!JSON.parse(output.body)) {
      return false;
    }
    return true;
  } catch (ex) {
    console.log(ex);
    return false;
  }
};

export {completeRegistration};
