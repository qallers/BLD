import {UserApi} from '@stackworx/bluelabel-atlas';
import {QueryResolvers} from '../../../generated/graphql';
import config from '../../../config';
import {atlasAuthCheck} from '../../auth/AtlasHelpers';

/*
query {
  customerList {
    totalCount
    edges {
      cursor
      node {
        id
        name
        customerCode
        customerId
      }
    }
  }
}
 */

interface Customer {
  id: number;
  cust_code: string;
  name: string;
}

const getCustomers = async function (context: any) {
  try {
    const headers = atlasAuthCheck(context);
    const api = new UserApi(config.get('atlasAddress'));
    return await api.getUserCustomers(headers).then((res) => res.body.data);
  } catch (ex) {
    console.log(ex);
    return false;
  }
};

export const customerList: QueryResolvers['customerList'] = async function (
  _parent: any,
  _input: any,
  context: any,
  _info: any
) {
  try {
    const customerData = await getCustomers(context);
    if (!customerData) {
      return {
        success: true,
        message: 'Success',
        edges: null,
        totalCount: 0,
      };
    }
    const customers = customerData.map((customer: Customer) => ({
      cursor: Buffer.from('Customer:' + customer.id).toString('base64'),
      node: {
        id: Buffer.from('Customer:' + customer.id).toString('base64'),
        name: customer.name,
        customerCode: customer.cust_code,
        customerId: customer.id,
      },
    }));

    return {
      success: true,
      message: 'Success',
      edges: customers,
      totalCount: customers.length,
    };
  } catch (e) {
    return {success: false, message: e.message, edges: null, totalCount: 0};
  }
};
