import net from 'net';
import tls from 'tls';
import jsonToXml from 'jsontoxml';
import xml2json from 'xml2json';
import config from '../../config';
import {TrxEventType} from './TrxEventType';

interface UserInfo {
  deviceId: string;
  serialNum: string;
  userPin: string;
  location: string;
  swVer: string;
}

const ssl = config.get('env') === 'production';
const address = config.get('aeonAddress');
const port = config.get('aeonPort');

const checkEventCode = (response: string) => {
  const parse: any = xml2json.toJson(response, {object: true});
  return parse.response.event.EventCode === '0';
};

const getAeonErrorText = (response: string) => {
  const parse: any = xml2json.toJson(response, {object: true});
  return parse.response.data.AeonErrorText;
};

const getSessionId = (response: string) => {
  const parse: any = xml2json.toJson(response, {object: true});
  return parse.response.SessionId;
};

const parseResponseData = (response: string) => {
  const parse: any = xml2json.toJson(response, {object: true});
  return parse;
};

export const aeonConnectSingle = async (
  userInfo: UserInfo,
  eventType: string,
  authTrxType: TrxEventType
) => {
  return new Promise((resolve, reject) => {
    try {
      // console.log("trying to connect")
      let response = '';
      // #### AUTH
      const authXml = jsonToXml({
        request: {
          event: {
            DeviceId: userInfo.deviceId,
            DeviceSer: userInfo.serialNum,
            UserPin: userInfo.userPin,
            DeviceVer: userInfo.swVer,
            location: userInfo.location,
            LoyaltyProfileId: '',
            TransType: authTrxType,
          },
          EventType: eventType,
        },
      });
      const client = ssl
        ? tls.connect({port: port, host: address}, function () {
            client.write(`${authXml}\n`); //newline terminal needed to complete send to server.
          })
        : net.connect({port: port, host: address}, function () {
            client.write(`${authXml}\n`); //newline terminal needed to complete send to server.
          });

      client.on('error', function (_err: any) {
        // console.log({err});
        const ret = {
          message: 'Connection error',
        };
        reject(ret);
      });

      client.on('data', function (data: any) {
        response += data.toString();
        if (data.toString().endsWith('\n')) {
          if (!checkEventCode(response)) {
            const ret = {
              message: getAeonErrorText(response),
            };
            reject(ret);
          } else {
            const parse = parseResponseData(response);
            client.end();
            const ret = {
              message: 'Success',
              response: parse,
            };
            resolve(ret);
          }
        }
      });
    } catch (e) {
      console.log({e});
      const ret = {
        message: e.toString(),
      };
      reject(ret);
    }
  });
};

export const aeonConnect = async (
  userInfo: UserInfo,
  authTrxType: TrxEventType,
  reqTrxType: TrxEventType,
  event = {}
) => {
  return new Promise((resolve, reject) => {
    // console.log({event: JSON.stringify(event)})
    try {
      let response = '';
      let sessionId = null;
      let streamStep = 'Auth';
      // #### AUTH
      const authXml = jsonToXml({
        request: {
          event: {
            DeviceId: userInfo.deviceId,
            DeviceSer: userInfo.serialNum,
            UserPin: userInfo.userPin,
            DeviceVer: userInfo.swVer,
            location: userInfo.location,
            LoyaltyProfileId: '',
            TransType: authTrxType,
          },
          EventType: 'Authentication',
        },
      });
      const client = ssl
        ? tls.connect({port: port, host: address}, function () {
            client.write(`${authXml}\n`); //newline terminal needed to complete send to server.
          })
        : net.connect({port: port, host: address}, function () {
            client.write(`${authXml}\n`); //newline terminal needed to complete send to server.
          });

      client.on('error', function (_err: any) {
        // console.log({err});
        const ret = {
          message: 'Connection error',
        };
        reject(ret);
      });

      client.on('data', function (data: any) {
        response += data.toString();
        if (data.toString().endsWith('\n')) {
          // console.log({response});
          if (!checkEventCode(response)) {
            const ret = {
              message: getAeonErrorText(response),
            };
            reject(ret);
          } else if (streamStep == 'Auth') {
            streamStep = 'Lookup';
            sessionId = getSessionId(response);
            response = ''; // Clean response stream to prevent invalid xml
            const xml = jsonToXml({
              request: {
                SessionId: sessionId,
                EventType: reqTrxType,
                event: event,
              },
            });
            console.log({xml});
            client.write(`${xml}\n`); //newline terminal needed to complete send to server.
          } else if (streamStep == 'Lookup') {
            const parse = parseResponseData(response);
            client.end();
            const ret = {
              message: 'Success',
              response: parse,
            };
            resolve(ret);
          } else {
            client.end();
            const ret = {
              message: 'Unknown error',
            };
            reject(ret);
          }
          // res.header('Content-Type', 'application/json').send(xmlParser.toJson(response, options));
          // resolve(response);
        }
      });
    } catch (e) {
      console.log({error: e});
      const ret = {
        message: e.toString(),
      };
      reject(ret);
    }
  });
};

export const aeonConnectElectricity = async (
  userInfo: UserInfo,
  event = {}
) => {
  return new Promise((resolve, reject) => {
    try {
      let response = '';
      let sessionId = null;
      let streamStep = 'Auth';
      // #### AUTH
      const authXml = jsonToXml({
        request: {
          event: {
            DeviceId: userInfo.deviceId,
            DeviceSer: userInfo.serialNum,
            UserPin: userInfo.userPin,
            DeviceVer: userInfo.swVer,
            location: userInfo.location,
            LoyaltyProfileId: '',
            TransType: 'Electricity',
          },
          EventType: 'Authentication',
        },
      });
      const client = ssl
        ? tls.connect({port: port, host: address}, function () {
            client.write(`${authXml}\n`); //newline terminal needed to complete send to server.
          })
        : net.connect({port: port, host: address}, function () {
            client.write(`${authXml}\n`); //newline terminal needed to complete send to server.
          });

      client.on('error', function (err: any) {
        console.log({err});
        const ret = {
          message: 'Connection error',
        };
        reject(ret);
      });

      client.on('data', function (data: any) {
        response += data.toString();
        if (data.toString().endsWith('\n')) {
          if (!checkEventCode(response)) {
            const ret = {
              message: getAeonErrorText(response),
            };
            reject(ret);
          } else if (streamStep == 'Auth') {
            streamStep = 'Confirm';
            sessionId = getSessionId(response);
            response = ''; // Clean response stream to prevent invalid xml
            const xml = jsonToXml({
              request: {
                SessionId: sessionId,
                EventType: 'ConfirmMeter',
                event: event,
              },
            });
            client.write(`${xml}\n`); //newline terminal needed to complete send to server.
          } else if (streamStep == 'Confirm') {
            streamStep = 'Purchase';
            const parse = parseResponseData(response);
            response = ''; // Clean response stream to prevent invalid xml

            const xml = jsonToXml({
              request: {
                SessionId: parse.response.SessionId,
                EventType: 'GetVoucher',
                event: {
                  Print: 0,
                  TransRef: parse.response.data.TransRef,
                  Type: 'TOKEN',
                },
              },
            });
            client.write(`${xml}\n`); //newline terminal needed to complete send to server.
          } else if (streamStep == 'Purchase') {
            const parse = parseResponseData(response);
            client.end();
            const ret = {
              message: 'Success',
              response: parse,
            };
            resolve(ret);
          } else {
            client.end();
            const ret = {
              message: 'Unknown error',
            };
            reject(ret);
          }
        }
      });
    } catch (e) {
      console.log({e});
      const ret = {
        message: e.toString(),
      };
      reject(ret);
    }
  });
};
