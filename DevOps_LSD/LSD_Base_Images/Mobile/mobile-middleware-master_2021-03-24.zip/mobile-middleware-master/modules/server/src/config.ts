import convict from 'convict';

const config = convict({
  env: {
    doc: 'The application environment.',
    format: ['production', 'development', 'test'],
    default: 'development',
    env: 'NODE_ENV',
  },
  stage: {
    doc: 'The application stage.',
    format: ['local', 'development', 'test', 'qa', 'production'],
    default: 'local',
    env: 'APP_STAGE',
  },
  tls: {
    enabled: {
      doc: 'TLS Tracing Enabled',
      format: 'Boolean',
      default: false,
      env: 'TLS_ENABLED',
    },
    cert: {
      doc: 'TLS Certificate file path',
      format: '*',
      env: 'TLS_CERT',
      default: '',
    },
    key: {
      doc: 'TLS Key file path',
      format: '*',
      env: 'TLS_KEY',
      default: '',
    },
  },
  type: {
    doc: 'The application type. e.g. express, worker, etc.',
    format: 'String',
    default: 'Unknown',
    env: 'APP_TYPE',
  },
  gatewayAddress: {
    doc: 'Gateway Address',
    format: 'String',
    // Default url
    default: 'http://105.29.89.194:9001/v1/trade',
    env: 'GATEWAY_ADDRESS',
  },
  atlasAddress: {
    doc: 'Atlas Address',
    format: 'String',
    default: 'https://t3tsa.kportal.qa.bltelecoms.net',
    env: 'ATLAS_ADDRESS',
  },
  mendixAddress: {
    doc: 'Mendix Address',
    format: 'String',
    default: 'https://bluelabel-accp.mendixcloud.com/rest',
    env: 'MENDIX_ADDRESS',
  },
  aeonAddress: {
    doc: 'AEON server Address',
    format: 'String',
    default: '10.22.7.12',
    env: 'AEON_ADDRESS',
  },
  //prod: aeonssl.live.bltelecoms.net port: 443
  aeonPort: {
    doc: 'AEON server Port',
    format: 'Number',
    default: 9011,
    env: 'AEON_PORT',
  },

  //prod: Rica.bltelecoms.net port: 443
  ricaAddress: {
    doc: 'RICA server Address',
    format: 'String',
    default: '10.22.7.17',
    env: 'RICA_ADDRESS',
  },
  ricaPort: {
    doc: 'RICA server Port',
    format: 'Number',
    default: 9013,
    env: 'RICA_PORT',
  },
  //prod 45
  ricaDevice: {
    doc: 'RICA Device ID',
    format: 'Number',
    default: 2,
    env: 'RICA_DEVICE_ID',
  },
  //prod 93n367fvk393
  ricaSerial: {
    doc: 'RICA Serial Number',
    format: 'String',
    default: '3',
    env: 'RICA_SERIAL_NUMBER',
  },

  port: {
    doc: 'The port to bind.',
    format: 'port',
    default: 5000,
    env: 'PORT',
    arg: 'port',
  },
  jwtSecret: {
    doc: 'JWT Secret',
    format: 'String',
    default: 'DSFHGRTYUGFJGHJ',
    env: 'JWT_SECRET',
    sensitive: true,
  },
  debugPort: {
    doc: 'The debug port to bind.',
    format: 'port',
    default: 5001,
    env: 'DEBUG_PORT',
  },
  jaeger: {
    enabled: {
      doc: 'Jeager Tracing Enabled',
      format: 'Boolean',
      default: false,
      env: 'JAEGER_ENABLED',
    },
    agentHost: {
      doc: 'Jaeger Collection Endpoint',
      format: '*',
      env: 'JAEGER_AGENT_HOST',
      default: 'localhost',
    },
  },
  prometheus: {
    enabled: {
      doc: 'Prometheus tracing Enabled',
      format: 'Boolean',
      default: false,
      env: 'PROMETHEUS_ENABLED',
    },
  },
  bugsnag: {
    apiKey: {
      doc: 'Bugsnag API Key',
      format: 'String',
      default: '31a9b5a408fe09696c30ceb0fd1a85f3',
    },
  },
  cellfind: {
    url: {
      doc: 'Cellfind URL',
      format: 'String',
      default: 'https://www.cellportal.co.za/',
      env: 'CELLFIND_URL',
    },
    username: {
      doc: 'Cellfind Username',
      format: 'String',
      default: 'API_starterpacks',
      env: 'CELLFIND_USERNAME',
      sensitive: true,
    },
    password: {
      doc: 'Cellfind Password',
      format: 'String',
      default: 'lHN$=JLN3&',
      env: 'CELLFIND_PASSWORD',
      sensitive: true,
    },
  },
});

// Load .env.json if in dev mode
if (config.get('env') === 'development') {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const fs = require('fs');

  if (fs.existsSync('.env.json')) {
    config.loadFile('.env.json');
  }
}

export default config;
