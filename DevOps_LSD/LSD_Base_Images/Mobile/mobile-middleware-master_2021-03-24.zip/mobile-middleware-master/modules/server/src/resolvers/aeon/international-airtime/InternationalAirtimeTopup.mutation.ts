import {aeonConnect} from '../AeonConnect';
import {MutationResolvers} from '../../../generated/graphql';
import {aeonAuth} from '../AeonAuth';

interface Input {
  input: {
    amount: string;
    phoneNumber: string;
    network: 'MTN' | 'Vodacom' | 'CellC' | 'IPay';
    reference: string;
    senderPhoneNumber: string;
    productCode: string;
  };
}

//@ts-ignore
export const internationalAirtimeTopup: MutationResolvers['internationalAirtimeTopup'] = async function (
  _parent: any,
  {
    input: {
      amount,
      phoneNumber,
      network,
      reference,
      senderPhoneNumber,
      productCode,
    },
  }: Input,
  context: any,
  _info: any
) {
  const authData = await aeonAuth(context);
  if (!authData) {
    return null;
  }
  let data: any = {};
  try {
    const event = {
      Amount: amount,
      PhoneNumber: phoneNumber,
      Reference: reference,
      SupplierName: 'supplier',
      SenderPhoneNumber: senderPhoneNumber,
      ProductCode: productCode,
    };

    data = await aeonConnect(authData, network, 'GetGlobalTopup', event);

    return {success: true, message: data.message};
  } catch (e) {
    return {success: false, message: e.message};
  }
};
