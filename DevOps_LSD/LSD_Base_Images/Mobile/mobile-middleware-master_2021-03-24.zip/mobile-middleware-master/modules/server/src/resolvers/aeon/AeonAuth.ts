// gets user aeon login details
// using atlas api calls

import got from 'got';
import config from '../../config';

export const aeonAuth = async function (context: any) {
  try {
    const authToken = context && context.req && context.req.headers.atlasauth;
    const uri = `${config.get(
      'atlasAddress'
    )}/api/v1/customer/external_system_reference?external_system_id=1`;
    const output = await got.get(uri, {
      headers: {
        Authorization: `${authToken}`,
      },
    });

    if (!JSON.parse(output.body).data) {
      //Atlas down or other error
      return false;
    }
    const {data} = JSON.parse(output.body);

    // atlas returns a sibset of data which first must be parsed
    const parsedData = JSON.parse(data[0].data);
    // helpers to find specific primary and secondary devices
    const primary = parsedData.devices.device.find(
      (item: {type: string; serial_no: string}) => {
        return item.type === 'Primary';
      }
    );
    const secondary = parsedData.devices.device.find(
      (item: {type: string; serial_no: string}) => {
        return item.type === 'Secondary';
      }
    );

    // fetches primary device, else secondary
    const device = primary ? primary : secondary;

    // if no devices are attached to user, return false
    if (!device) {
      return false;
    }

    const deviceId = parsedData.device_id;

    return {
      deviceId,
      serialNum: device.serial_no,
      userPin: '011234',
      location: '',
      swVer: 'bluShift',
      account: parsedData.byd_acc_no,
    };
  } catch (ex) {
    console.warn({ex});
    return false;
  }
};
