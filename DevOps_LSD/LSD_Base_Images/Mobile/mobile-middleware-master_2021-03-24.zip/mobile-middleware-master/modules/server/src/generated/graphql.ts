/* eslint-disable @typescript-eslint/no-explicit-any */
import { GraphQLResolveInfo, GraphQLScalarType, GraphQLScalarTypeConfig } from 'graphql';
import { Context } from '../Context';
export type Maybe<T> = T | null;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type RequireFields<T, K extends keyof T> = { [X in Exclude<keyof T, K>]?: T[X] } & { [P in K]-?: NonNullable<T[P]> };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
  DateTime: Date;
};


export type AeonAuth = {
  __typename?: 'AeonAuth';
  authorized: Scalars['Boolean'];
  clientMutationId: Maybe<Scalars['String']>;
  success: Scalars['Boolean'];
};

export type AeonResult = {
  __typename?: 'AeonResult';
  success: Scalars['Boolean'];
  message: Maybe<Scalars['String']>;
  response: Maybe<Scalars['String']>;
};

export enum DataBundlesInputNetworks {
  Mtn = 'MTN',
  CellC = 'CellC',
  TelkomMobile = 'TelkomMobile',
  Vodacom = 'Vodacom'
}

export type DataBundlesInput = {
  network: DataBundlesInputNetworks;
};

export type DataBundlesResult = {
  __typename?: 'DataBundlesResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
  edges: Maybe<Array<BundlesEdge>>;
  totalCount: Scalars['Int'];
};

export type BundlesEdge = {
  __typename?: 'BundlesEdge';
  node: Bundle;
  cursor: Scalars['String'];
};

export type Bundle = {
  __typename?: 'Bundle';
  id: Scalars['ID'];
  network: Scalars['String'];
  category: Scalars['String'];
  desc: Scalars['String'];
  amount: Scalars['String'];
  code: Scalars['Int'];
};

export type DataBundlesNetworkResult = {
  __typename?: 'DataBundlesNetworkResult';
  success: Scalars['Boolean'];
  message: Maybe<Scalars['String']>;
  cellc: Array<Maybe<BundleNetwork>>;
  mtn: Array<Maybe<BundleNetwork>>;
  telkom: Array<Maybe<BundleNetwork>>;
  vodacom: Array<Maybe<BundleNetwork>>;
};

export type BundleNetwork = {
  __typename?: 'BundleNetwork';
  category: Scalars['String'];
  desc: Scalars['String'];
  amount: Scalars['String'];
  code: Scalars['Int'];
};

export type NetworksInput = {
  type: Scalars['String'];
};

export type NetworksResult = {
  __typename?: 'NetworksResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
  edges: Maybe<Array<NetworkEdge>>;
  totalCount: Scalars['Int'];
};

export type NetworkEdge = {
  __typename?: 'NetworkEdge';
  node: Network;
  cursor: Scalars['String'];
};

export type Network = {
  __typename?: 'Network';
  id: Scalars['ID'];
  network: Scalars['String'];
  colour: Scalars['String'];
  logo: Scalars['String'];
};

export type Response = {
  __typename?: 'Response';
  message: Scalars['String'];
  code: Scalars['Int'];
};

export type Account = {
  __typename?: 'Account';
  balance: Scalars['Float'];
  profit: Scalars['Float'];
  accountNumber: Scalars['String'];
};

export enum Period {
  One = 'ONE',
  OneDay = 'ONE_DAY',
  OneWeek = 'ONE_WEEK',
  Three = 'THREE',
  ThreeDay = 'THREE_DAY',
  Week = 'WEEK'
}

export type AccountRegisterUserInput = {
  userTypeId: Scalars['String'];
  firstName: Scalars['String'];
  lastName: Scalars['String'];
  username: Scalars['String'];
  email: Scalars['String'];
};

export type AccountRegisterUserPayload = {
  __typename?: 'AccountRegisterUserPayload';
  success: Scalars['Boolean'];
};

export type AccountRegisterConsumerInput = {
  username: Scalars['String'];
  password: Scalars['String'];
  email: Scalars['String'];
  firstName: Scalars['String'];
  lastName: Scalars['String'];
  name: Scalars['String'];
  identityTypeId: Scalars['String'];
  identityReference: Scalars['String'];
  identityReferenceExpiryDate: Scalars['String'];
  identityReferenceOriginCountry: Scalars['String'];
  paymentMethodId: Scalars['String'];
};

export type AccountRegisterConsumerPayload = {
  __typename?: 'AccountRegisterConsumerPayload';
  success: Scalars['Boolean'];
  output: Maybe<Scalars['String']>;
  name: Maybe<Scalars['String']>;
  groupId: Maybe<Scalars['String']>;
  identityTypeId: Maybe<Scalars['String']>;
  paymentMethodId: Maybe<Scalars['String']>;
  identityReference: Maybe<Scalars['String']>;
  vatRegistered: Maybe<Scalars['String']>;
  isActive: Maybe<Scalars['String']>;
  userId: Maybe<Scalars['String']>;
  repUserId: Maybe<Scalars['String']>;
  identityReferenceExpiryDate: Maybe<Scalars['String']>;
  identityReferenceOriginCountry: Maybe<Scalars['String']>;
  updatedAt: Maybe<Scalars['String']>;
  createdAt: Maybe<Scalars['String']>;
  id: Maybe<Scalars['String']>;
};

export type Country = {
  __typename?: 'Country';
  id: Scalars['Int'];
  name: Scalars['String'];
  abv: Scalars['String'];
  abv3: Scalars['String'];
  abv3_alt: Maybe<Scalars['String']>;
  code: Scalars['String'];
  slug: Scalars['String'];
  created_at: Maybe<Scalars['String']>;
  updated_at: Maybe<Scalars['String']>;
};

export type IdentityType = {
  __typename?: 'IdentityType';
  id: Scalars['Int'];
  name: Scalars['String'];
  status: Scalars['String'];
  process: Scalars['String'];
  is_active: Scalars['Int'];
  created_at: Scalars['DateTime'];
  updated_at: Scalars['DateTime'];
};

export type PaymentMethod = {
  __typename?: 'PaymentMethod';
  id: Scalars['Int'];
  name: Scalars['String'];
  status: Scalars['String'];
  process: Scalars['String'];
  is_active: Scalars['Int'];
  created_at: Scalars['String'];
  updated_at: Scalars['String'];
};

export type BankDetails = {
  __typename?: 'BankDetails';
  edges: Maybe<Array<BankDetailsEdge>>;
  totalCount: Scalars['Int'];
};

export type BankDetailsEdge = {
  __typename?: 'BankDetailsEdge';
  node: BankDetail;
  cursor: Scalars['String'];
};

export type BankDetail = {
  __typename?: 'BankDetail';
  id: Scalars['ID'];
  bank: Scalars['String'];
  accountName: Scalars['String'];
  accountNumber: Scalars['String'];
  branch: Scalars['String'];
  branchCode: Scalars['String'];
  universalCode: Scalars['String'];
  swift: Scalars['String'];
  reference: Scalars['String'];
};

export type BusAccount = {
  deviceId: Scalars['String'];
  serialNum: Scalars['String'];
  userPin: Scalars['String'];
  location: Scalars['String'];
  swVer: Scalars['String'];
};

export type BusCarriersConnection = {
  __typename?: 'BusCarriersConnection';
  edges: Array<BusCarriersEdge>;
  pageInfo: Maybe<PageInfo>;
  totalCount: Maybe<Scalars['Int']>;
};

export type BusCarriersEdge = {
  __typename?: 'BusCarriersEdge';
  node: BusCarrierLocation;
  cursor: Maybe<Scalars['String']>;
};

export type BusCarrierLocation = {
  __typename?: 'BusCarrierLocation';
  name: Maybe<Scalars['String']>;
  shortName: Maybe<Scalars['String']>;
  companyId: Maybe<Scalars['String']>;
  role: Maybe<Scalars['String']>;
  type: Maybe<Scalars['String']>;
};

export type BusDestinationsConnection = {
  __typename?: 'BusDestinationsConnection';
  edges: Array<BusDestinationsEdge>;
  pageInfo: Maybe<PageInfo>;
  totalCount: Maybe<Scalars['Int']>;
};

export type BusDestinationsEdge = {
  __typename?: 'BusDestinationsEdge';
  node: BusDestinationLocation;
  cursor: Maybe<Scalars['String']>;
};

export type BusDestinationLocation = {
  __typename?: 'BusDestinationLocation';
  locationId: Maybe<Scalars['String']>;
  type: Maybe<Scalars['String']>;
  stationId: Maybe<Scalars['String']>;
  name: Maybe<Scalars['String']>;
  entityId: Maybe<Scalars['String']>;
};

export type BusFaresConnection = {
  __typename?: 'BusFaresConnection';
  totalAmount: Scalars['Int'];
  edges: Array<BusFaresEdge>;
  pageInfo: Maybe<PageInfo>;
  totalCount: Maybe<Scalars['Int']>;
};

export type BusFaresEdge = {
  __typename?: 'BusFaresEdge';
  node: BusFare;
  cursor: Maybe<Scalars['String']>;
};

export type BusFare = {
  __typename?: 'BusFare';
  id: Maybe<Scalars['ID']>;
  sessionId: Scalars['String'];
  responseCode: Scalars['Int'];
  responseMessage: Scalars['String'];
  status: Scalars['Int'];
  period: Scalars['String'];
  fareProductId: Scalars['String'];
  code: Scalars['String'];
  routes: RouteRecursor;
  companyId: Scalars['ID'];
  weekdays: Scalars['String'];
  created: Scalars['DateTime'];
  availableFrom: Scalars['DateTime'];
  availableTo: Scalars['DateTime'];
  transferCount: Scalars['Int'];
  passValue: Scalars['Int'];
  tripsPerDay: Scalars['Int'];
  passType: Scalars['String'];
  price: Scalars['Float'];
  name: Scalars['String'];
  shortName: Scalars['String'];
  desc: Maybe<Scalars['String']>;
};

export type BusFareInput = {
  companyId: Scalars['String'];
  departureLocationId: Maybe<Scalars['ID']>;
  destinationLocationId: Maybe<Scalars['ID']>;
  routeId: Maybe<Scalars['Int']>;
  fareProductId: Maybe<Scalars['ID']>;
  auth: Maybe<BusAccount>;
};

export type BusStopsConnection = {
  __typename?: 'BusStopsConnection';
  edges: Array<BusStopsEdge>;
  pageInfo: Maybe<PageInfo>;
  totalCount: Maybe<Scalars['Int']>;
};

export type BusStopsEdge = {
  __typename?: 'BusStopsEdge';
  node: BusStopLocation;
  cursor: Maybe<Scalars['String']>;
};

export type BusStopLocation = {
  __typename?: 'BusStopLocation';
  id: Maybe<Scalars['ID']>;
  name: Scalars['String'];
};

export type BusStopsInput = {
  companyId: Scalars['ID'];
  auth: BusAccount;
};

export type BusTicketsConnection = {
  __typename?: 'BusTicketsConnection';
  edges: Maybe<Array<BusTicketsEdge>>;
  pageInfo: Maybe<PageInfo>;
  totalCount: Maybe<Scalars['Int']>;
};

export type BusTicketsEdge = {
  __typename?: 'BusTicketsEdge';
  node: BusTicket;
  cursor: Maybe<Scalars['String']>;
};

export type BusTicket = {
  __typename?: 'BusTicket';
  id: Maybe<Scalars['ID']>;
  sessionId: Maybe<Scalars['String']>;
  responseCode: Scalars['Int'];
  responseMessage: Maybe<Scalars['String']>;
  companyId: Scalars['Int'];
  ticketId: Scalars['Int'];
  ticketNo: Scalars['String'];
  ticketType: Scalars['String'];
  routes: Maybe<RouteRecursor>;
  fare: Scalars['Float'];
  fareProductId: Scalars['String'];
  departureLocationId: Scalars['String'];
  destinationLocationId: Scalars['String'];
  activationDate: Scalars['DateTime'];
  expiryDate: Scalars['DateTime'];
  ticketDate: Scalars['DateTime'];
  numberOfDaysTrips: Scalars['Int'];
  numberOfTransfers: Scalars['Int'];
  status: Scalars['String'];
  rules: Scalars['String'];
  fareCurrency: Scalars['String'];
};

export type BusTicketInput = {
  uid: Scalars['String'];
  ticketId: Maybe<Scalars['String']>;
};

export type RouteRecursor = {
  __typename?: 'RouteRecursor';
  routes: Maybe<Array<Maybe<Scalars['String']>>>;
};

export type Query = {
  __typename?: 'Query';
  account: Account;
  bankDetails: BankDetails;
  bus_tickets: Maybe<User>;
  carriers: BusCarriersConnection;
  commissions: CommissionsConnection;
  countries: Maybe<Array<Maybe<Country>>>;
  customerList: CustomerList;
  dataBundles: DataBundlesResult;
  dataBundlesNetwork: DataBundlesNetworkResult;
  destinations: BusDestinationsConnection;
  fares: BusFaresConnection;
  fetchBanners: Maybe<BannersResult>;
  identityTypes: Maybe<Array<Maybe<IdentityType>>>;
  networks: NetworksResult;
  node: Maybe<Node>;
  paymentMethods: Maybe<Array<Maybe<PaymentMethod>>>;
  productDeals: ProductDealList;
  productsByNetwork: ProductsByNetworkResult;
  profile: Maybe<Profile>;
  stockList: StockList;
  stockToReceive: StockReceiveList;
  stops: BusStopsConnection;
  svcValidate: BusTicketsConnection;
  tickets: Maybe<BusTicketsConnection>;
  transactions: TransactionsConnection;
  userPerformance: UserPerformance;
  validateProduct: ValidateProductResult;
};


export type QueryBus_TicketsArgs = {
  card_number: Scalars['String'];
};


export type QueryCarriersArgs = {
  input: BusAccount;
};


export type QueryCommissionsArgs = {
  input: CommissionsInput;
};


export type QueryDataBundlesArgs = {
  input: DataBundlesInput;
};


export type QueryDestinationsArgs = {
  companyId: Scalars['ID'];
  departureLocationId: Scalars['String'];
  auth: Maybe<BusAccount>;
};


export type QueryFaresArgs = {
  input: Maybe<BusFareInput>;
};


export type QueryNetworksArgs = {
  input: NetworksInput;
};


export type QueryNodeArgs = {
  id: Scalars['ID'];
};


export type QueryProductDealsArgs = {
  input: ProductDealInput;
};


export type QueryProductsByNetworkArgs = {
  input: ProductsByNetworkInput;
};


export type QueryStopsArgs = {
  input: BusStopsInput;
};


export type QuerySvcValidateArgs = {
  svcValidation: Maybe<SvcValidation>;
  auth: BusAccount;
};


export type QueryTicketsArgs = {
  svcValidation: Maybe<SvcValidation>;
  auth: BusAccount;
};


export type QueryTransactionsArgs = {
  input: TransactionsInput;
};


export type QueryUserPerformanceArgs = {
  input: UserPerformanceInput;
};


export type QueryValidateProductArgs = {
  input: ValidateProductInput;
};

export type Ticket = {
  __typename?: 'Ticket';
  price: Maybe<Scalars['Int']>;
  type: Maybe<Scalars['String']>;
  depature: Maybe<Scalars['String']>;
  destination: Maybe<Scalars['String']>;
};

export type Card = {
  __typename?: 'Card';
  type: Scalars['String'];
  card_number: Scalars['String'];
};

export type User = {
  __typename?: 'User';
  message: Scalars['String'];
  name: Scalars['String'];
  ticket_count: Maybe<Scalars['Int']>;
  type: Card;
  tickets: Maybe<Array<Ticket>>;
};

export type CommissionsInput = {
  period: Period;
};

export type CommissionsConnection = {
  __typename?: 'CommissionsConnection';
  totalRetail: Scalars['Float'];
  totalProfit: Scalars['Float'];
  edges: Maybe<Array<CommissionEdge>>;
  pageInfo: Maybe<PageInfo>;
  totalCount: Maybe<Scalars['Int']>;
};

export type CommissionEdge = {
  __typename?: 'CommissionEdge';
  node: Commission;
  cursor: Maybe<Scalars['String']>;
};

export type Commission = {
  __typename?: 'Commission';
  id: Maybe<Scalars['ID']>;
  retail: Scalars['Float'];
  profit: Scalars['Float'];
  qty: Scalars['Int'];
  name: Scalars['String'];
};

export type CustomerList = {
  __typename?: 'CustomerList';
  edges: Maybe<Array<CustomerListEdge>>;
  totalCount: Scalars['Int'];
};

export type CustomerListEdge = {
  __typename?: 'CustomerListEdge';
  node: Customer;
  cursor: Scalars['String'];
};

export type Customer = {
  __typename?: 'Customer';
  id: Scalars['ID'];
  name: Scalars['String'];
  customerCode: Scalars['String'];
  customerId: Scalars['Int'];
};

export enum VoucherEnumType {
  Cash = 'CASH',
  Goods = 'GOODS'
}

export type Banner = {
  __typename?: 'Banner';
  id: Scalars['ID'];
  url: Scalars['String'];
};

export type BannerEdge = {
  __typename?: 'BannerEdge';
  node: Banner;
  cursor: Scalars['String'];
};

export type BannersResult = {
  __typename?: 'BannersResult';
  total: Scalars['Int'];
  edges: Maybe<Array<BannerEdge>>;
};

export type AddNetworkContractInput = {
  name: Scalars['String'];
  customerId: Scalars['Int'];
  network: NetworkEnum;
  isTiered: Maybe<Scalars['Boolean']>;
  isSplit: Maybe<Scalars['Boolean']>;
  ogr: Scalars['Float'];
  act: Scalars['Float'];
  sim: Scalars['Float'];
};

export type AddNetworkContractResult = {
  __typename?: 'AddNetworkContractResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
};

export type AddProductDealInput = {
  productId: Scalars['Int'];
  customerId: Scalars['Int'];
  name: Scalars['String'];
  ogr: Scalars['Float'];
  act: Scalars['Float'];
  sim: Scalars['Float'];
};

export type AddProductDealResult = {
  __typename?: 'AddProductDealResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
};

export type AirtimeTopupInput = {
  amount: Scalars['String'];
  phoneNumber: Scalars['String'];
  network: Scalars['String'];
  reference: Scalars['String'];
};

export type AirtimeTopupResult = {
  __typename?: 'AirtimeTopupResult';
  success: Scalars['Boolean'];
  message: Maybe<Scalars['String']>;
};

export type InternationalAirtimeTopupInput = {
  amount: Scalars['String'];
  phoneNumber: Scalars['String'];
  network: Scalars['String'];
  reference: Scalars['String'];
  senderPhoneNumber: Scalars['String'];
  productCode: Scalars['String'];
};

export type InternationalAirtimeTopupResult = {
  __typename?: 'InternationalAirtimeTopupResult';
  success: Scalars['Boolean'];
  message: Maybe<Scalars['String']>;
};

export type AllocateStockInput = {
  stock: Array<AllocateStock>;
  customerId: Scalars['Int'];
  delivery: DeliveryEnum;
};

export enum DeliveryEnum {
  Collection = 'Collection',
  Courier = 'Courier',
  Delivery = 'Delivery'
}

export type AllocateStock = {
  productId: Scalars['Int'];
  qty: Scalars['Int'];
  dealId: Scalars['Int'];
  salePrice: Scalars['Float'];
  barcode: Array<Scalars['String']>;
};

export type AllocateStockResult = {
  __typename?: 'AllocateStockResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
};

export enum ResetMethod {
  Email = 'EMAIL',
  Sms = 'SMS'
}

export type AuthResetPasswordInput = {
  method: ResetMethod;
  detail: Scalars['String'];
  clientMutationId: Maybe<Scalars['String']>;
};

export type AuthResetPasswordPayload = {
  __typename?: 'AuthResetPasswordPayload';
  success: Scalars['Boolean'];
  clientMutationId: Maybe<Scalars['String']>;
};

export type AuthValidationInput = {
  username: Scalars['String'];
  password: Scalars['String'];
  currentStatus: Maybe<Scalars['Int']>;
  clientMutationId: Maybe<Scalars['String']>;
};

export type AuthValidationPayload = {
  __typename?: 'AuthValidationPayload';
  authorized: Scalars['Boolean'];
  token: Maybe<Scalars['String']>;
  status: Scalars['Int'];
  profile: Maybe<Profile>;
  clientMutationId: Maybe<Scalars['String']>;
};

export type AuthValidationLegacyInput = {
  username: Scalars['String'];
  password: Scalars['String'];
  clientMutationId: Maybe<Scalars['String']>;
};

export type AuthValidationLegacyPayload = {
  __typename?: 'AuthValidationLegacyPayload';
  authorized: Scalars['Boolean'];
  clientMutationId: Maybe<Scalars['String']>;
};

export type BusTicketCancelInput = {
  uid: Scalars['String'];
  transref: Scalars['String'];
  svcData: Array<Maybe<Sector>>;
  referenceId: Scalars['String'];
  status: Scalars['String'];
  ticketId: Scalars['String'];
  transactionId: Scalars['String'];
  auth: BusAccount;
};

export type BusTicketCancelPayload = {
  __typename?: 'BusTicketCancelPayload';
  svcData: SvcUpdate;
  ticket: BusTicket;
  transaction: Transaction;
};

export type BusTicketConfirmCancelInput = {
  uid: Scalars['String'];
  transref: Scalars['String'];
  svcData: Array<Maybe<Sector>>;
  status: Scalars['String'];
  ticketId: Scalars['String'];
  transactionId: Scalars['String'];
  auth: BusAccount;
};

export type BusTicketConfirmCancelPayload = {
  __typename?: 'BusTicketConfirmCancelPayload';
  message: Scalars['String'];
  status: Scalars['String'];
  svcData: SvcUpdate;
  ticket: BusTicket;
  transaction: Transaction;
  transref: Scalars['String'];
  printLines: Scalars['String'];
  merchantPrintLines: Scalars['String'];
};

export type BusTicketCheckoutInput = {
  uid: Scalars['String'];
  ticketType: Scalars['String'];
  referenceId: Scalars['String'];
  fareProductId: Scalars['String'];
  amount: Scalars['String'];
  companyId: Scalars['String'];
  svcData: Array<Maybe<Sector>>;
  auth: BusAccount;
};

export type BusTicketCheckoutPayload = {
  __typename?: 'BusTicketCheckoutPayload';
  svcData: SvcUpdate;
  ticket: BusTicket;
  transaction: Transaction;
  transref: Scalars['String'];
};

export type BusTicketConfirmInput = {
  transref: Scalars['String'];
  uid: Scalars['String'];
  status: Scalars['String'];
  ticketId: Scalars['String'];
  transactionId: Scalars['String'];
  amount: Scalars['String'];
  paymentType: Scalars['String'];
  companyId: Scalars['String'];
  svcData: Array<Maybe<Sector>>;
  auth: BusAccount;
};

export type BusTicketConfirmPayload = {
  __typename?: 'BusTicketConfirmPayload';
  message: Scalars['String'];
  status: Scalars['String'];
  svcData: SvcUpdate;
  ticket: BusTicket;
  transaction: Transaction;
  transref: Scalars['String'];
  printLines: Scalars['String'];
  merchantPrintLines: Scalars['String'];
};

export type ConfirmMeterInput = {
  meterNumber: Scalars['String'];
};

export type ConfirmMeterResult = {
  __typename?: 'ConfirmMeterResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
  detail: Maybe<ConfirmMeterDetail>;
};

export type ConfirmMeterDetail = {
  __typename?: 'ConfirmMeterDetail';
  transRef: Scalars['String'];
  customer: Scalars['String'];
  address: Scalars['String'];
  utility: Scalars['String'];
  trxTypeId: Scalars['Int'];
};

export type CustomerOrderInput = {
  order: Array<CustomerOrder>;
  customerId: Scalars['Int'];
  delivery: DeliveryEnum;
};

export type CustomerOrder = {
  productId: Scalars['Int'];
  qty: Scalars['Int'];
  dealId: Scalars['Int'];
  salePrice: Scalars['Float'];
};

export type CustomerOrderResult = {
  __typename?: 'CustomerOrderResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
};

export type DataTopupInput = {
  code: Scalars['Int'];
  phoneNumber: Scalars['String'];
  network: Scalars['String'];
  reference: Scalars['String'];
};

export type DataTopupResult = {
  __typename?: 'DataTopupResult';
  success: Scalars['Boolean'];
  message: Maybe<Scalars['String']>;
};

export type ElectricityTopupInput = {
  amount: Scalars['String'];
  meterNumber: Scalars['String'];
  cellNumber: Scalars['String'];
};

export type ElectricityTopupResult = {
  __typename?: 'ElectricityTopupResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
};

export type ReceiveStockInput = {
  productId: Scalars['Int'];
  barcode: Scalars['String'];
  orderId: Scalars['Int'];
};

export type ReceiveStockResult = {
  __typename?: 'ReceiveStockResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
  qty: Maybe<Scalars['Int']>;
  scannedQty: Maybe<Scalars['Int']>;
};

export type RegisterConsumerInput = {
  username: Scalars['String'];
  password: Scalars['String'];
  name: Scalars['String'];
  lastName: Scalars['String'];
  mobile: Scalars['String'];
  business: Scalars['String'];
  email: Scalars['String'];
  id: Scalars['String'];
  address: RegisterConsumerAddress;
};

export type RegisterConsumerAddress = {
  line1: Scalars['String'];
  line2: Maybe<Scalars['String']>;
  line3: Maybe<Scalars['String']>;
  code: Scalars['Int'];
  city: Scalars['String'];
  province: Scalars['String'];
  latitude: Maybe<Scalars['Float']>;
  longitude: Maybe<Scalars['Float']>;
};

export type RegisterConsumerResult = {
  __typename?: 'RegisterConsumerResult';
  success: Scalars['Boolean'];
  message: Maybe<Scalars['String']>;
  status: Scalars['Int'];
  token: Maybe<Scalars['String']>;
};

export type RepTransferInput = {
  transfer: Array<ProductTransfer>;
};

export type ProductTransfer = {
  productId: Scalars['String'];
  qty: Scalars['String'];
};

export type RepTransferResult = {
  __typename?: 'RepTransferResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
};

export type RicaRegisterInput = {
  simDetails: SimDetails;
  isIndividual: Scalars['Boolean'];
  identity: Identity;
  customer: CustomerDetail;
};

export type SimDetails = {
  network: Scalars['String'];
  simNumber: Scalars['String'];
};

export type Identity = {
  type: IdentityMethod;
  number: Scalars['String'];
  company: Maybe<Scalars['String']>;
};

export enum IdentityMethod {
  RsaId = 'RSA_ID',
  Passport = 'PASSPORT',
  Business = 'BUSINESS'
}

export type CustomerDetail = {
  firstName: Scalars['String'];
  lastName: Scalars['String'];
  address: Scalars['String'];
  suburb: Scalars['String'];
  city: Scalars['String'];
  postCode: Scalars['String'];
  region: Scalars['String'];
};

export type RicaRegisterResult = {
  __typename?: 'RicaRegisterResult';
  success: Scalars['Boolean'];
  message: Maybe<Scalars['String']>;
};

export type UploadImageInput = {
  base64image: Scalars['String'];
};

export type UploadImageResult = {
  __typename?: 'UploadImageResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
  status: Scalars['Int'];
};

export type VoucherRedemptionInput = {
  username: Scalars['String'];
  consumerIdNumber: Maybe<Scalars['String']>;
  requestId: Scalars['String'];
  mobileNumber: Scalars['String'];
  password: Scalars['String'];
  voucherNumber: Scalars['String'];
  transactionType: VoucherEnumType;
  amount: Scalars['Int'];
  clientMutationId: Maybe<Scalars['String']>;
};

export type VoucherRedemptionPayload = {
  __typename?: 'VoucherRedemptionPayload';
  requestId: Scalars['String'];
  dateTime: Maybe<Scalars['DateTime']>;
  balance: Maybe<Scalars['Float']>;
  reference: Maybe<Scalars['String']>;
  clientMutationId: Maybe<Scalars['String']>;
};

export type Mutation = {
  __typename?: 'Mutation';
  addNetworkContract: Maybe<AddNetworkContractResult>;
  addProductDeal: Maybe<AddProductDealResult>;
  airtimeTopup: Maybe<AirtimeTopupResult>;
  allocateStock: Maybe<AllocateStockResult>;
  authRegistrationConsumer: Maybe<AccountRegisterConsumerPayload>;
  authRegistrationUser: Maybe<AccountRegisterUserPayload>;
  authResetPassword: Maybe<AuthResetPasswordPayload>;
  authValidation: Maybe<AuthValidationPayload>;
  authValidationLegacy: Maybe<AuthValidationLegacyPayload>;
  busTicketCancel: Maybe<BusTicketCancelPayload>;
  busTicketCancelConfirm: Maybe<BusTicketConfirmCancelPayload>;
  busTicketCheckout: Maybe<BusTicketCheckoutPayload>;
  busTicketConfirm: Maybe<BusTicketConfirmPayload>;
  confirmMeter: Maybe<ConfirmMeterResult>;
  customerOrder: Maybe<CustomerOrderResult>;
  dataTopup: Maybe<DataTopupResult>;
  electricityTopup: Maybe<ElectricityTopupResult>;
  internationalAirtimeTopup: Maybe<InternationalAirtimeTopupResult>;
  receiveStock: Maybe<ReceiveStockResult>;
  registerConsumer: Maybe<RegisterConsumerResult>;
  repTransfer: Maybe<RepTransferResult>;
  ricaRegister: Maybe<RicaRegisterResult>;
  uploadId: Maybe<UploadImageResult>;
  uploadProofOfResidence: Maybe<UploadImageResult>;
  uploadSelfie: Maybe<UploadImageResult>;
  uploadSignature: Maybe<UploadImageResult>;
  voucherRedemption: Maybe<VoucherRedemptionPayload>;
};


export type MutationAddNetworkContractArgs = {
  input: AddNetworkContractInput;
};


export type MutationAddProductDealArgs = {
  input: AddProductDealInput;
};


export type MutationAirtimeTopupArgs = {
  input: AirtimeTopupInput;
};


export type MutationAllocateStockArgs = {
  input: AllocateStockInput;
};


export type MutationAuthRegistrationConsumerArgs = {
  input: AccountRegisterConsumerInput;
};


export type MutationAuthRegistrationUserArgs = {
  input: AccountRegisterUserInput;
};


export type MutationAuthResetPasswordArgs = {
  input: AuthResetPasswordInput;
};


export type MutationAuthValidationArgs = {
  input: AuthValidationInput;
};


export type MutationAuthValidationLegacyArgs = {
  input: AuthValidationLegacyInput;
};


export type MutationBusTicketCancelArgs = {
  input: BusTicketCancelInput;
};


export type MutationBusTicketCancelConfirmArgs = {
  input: BusTicketConfirmCancelInput;
};


export type MutationBusTicketCheckoutArgs = {
  input: BusTicketCheckoutInput;
};


export type MutationBusTicketConfirmArgs = {
  input: BusTicketConfirmInput;
};


export type MutationConfirmMeterArgs = {
  input: ConfirmMeterInput;
};


export type MutationCustomerOrderArgs = {
  input: CustomerOrderInput;
};


export type MutationDataTopupArgs = {
  input: DataTopupInput;
};


export type MutationElectricityTopupArgs = {
  input: ElectricityTopupInput;
};


export type MutationInternationalAirtimeTopupArgs = {
  input: InternationalAirtimeTopupInput;
};


export type MutationReceiveStockArgs = {
  input: ReceiveStockInput;
};


export type MutationRegisterConsumerArgs = {
  input: RegisterConsumerInput;
};


export type MutationRepTransferArgs = {
  input: RepTransferInput;
};


export type MutationRicaRegisterArgs = {
  input: RicaRegisterInput;
};


export type MutationUploadIdArgs = {
  input: UploadImageInput;
};


export type MutationUploadProofOfResidenceArgs = {
  input: UploadImageInput;
};


export type MutationUploadSelfieArgs = {
  input: UploadImageInput;
};


export type MutationUploadSignatureArgs = {
  input: UploadImageInput;
};


export type MutationVoucherRedemptionArgs = {
  input: VoucherRedemptionInput;
};

export type ProductDealInput = {
  productId: Scalars['Int'];
  customerId: Scalars['Int'];
};

export type ProductDealList = {
  __typename?: 'ProductDealList';
  status: Scalars['String'];
  edges: Maybe<Array<ProductDealListEdge>>;
  totalCount: Scalars['Int'];
};

export type ProductDealListEdge = {
  __typename?: 'ProductDealListEdge';
  node: ProductDeal;
  cursor: Scalars['String'];
};

export type ProductDeal = {
  __typename?: 'ProductDeal';
  id: Scalars['ID'];
  dealId: Scalars['Int'];
  name: Scalars['String'];
  isTiered: Scalars['Boolean'];
  tierId: Maybe<Scalars['Int']>;
  ogr: Scalars['Float'];
  act: Scalars['Float'];
  sim: Scalars['Float'];
  isSplit: Scalars['Boolean'];
};

export enum NetworkEnum {
  Mtn = 'MTN',
  CellC = 'CellC',
  TelkomMobile = 'TelkomMobile',
  Vodacom = 'Vodacom'
}

export type ProductsByNetworkInput = {
  network: NetworkEnum;
};

export type ProductsByNetworkResult = {
  __typename?: 'ProductsByNetworkResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
  edges: Maybe<Array<ProductsByNetworkEdge>>;
  totalCount: Scalars['Int'];
};

export type ProductsByNetworkEdge = {
  __typename?: 'ProductsByNetworkEdge';
  node: ProductByNetwork;
  cursor: Scalars['String'];
};

export type ProductByNetwork = {
  __typename?: 'ProductByNetwork';
  id: Scalars['ID'];
  description: Scalars['String'];
  productCode: Scalars['String'];
  productId: Scalars['Int'];
  costPrice: Maybe<Scalars['String']>;
  salePrice: Maybe<Scalars['String']>;
  actExpenseCode: Maybe<Scalars['String']>;
  ogrExpenseCode: Maybe<Scalars['String']>;
  simExpenseCode: Maybe<Scalars['String']>;
};

export type Profile = {
  __typename?: 'Profile';
  id: Scalars['Int'];
  customerId: Scalars['Int'];
  username: Scalars['String'];
  firstName: Scalars['String'];
  lastName: Scalars['String'];
  email: Scalars['String'];
  userType: Role;
};

export type Role = {
  __typename?: 'Role';
  id: Scalars['Int'];
  description: Scalars['String'];
  slug: Scalars['String'];
};

export type Node = {
  id: Scalars['ID'];
};

export type DummyNode = Node & {
  __typename?: 'DummyNode';
  id: Scalars['ID'];
};

export type PageInfo = {
  __typename?: 'PageInfo';
  hasNextPage: Maybe<Scalars['Boolean']>;
  hasPreviousPage: Maybe<Scalars['Boolean']>;
  startCursor: Maybe<Scalars['String']>;
  endCursor: Maybe<Scalars['String']>;
};


export type StockList = {
  __typename?: 'StockList';
  success: Scalars['Boolean'];
  message: Scalars['String'];
  edges: Maybe<Array<StockListEdge>>;
  totalCount: Scalars['Int'];
};

export type StockListEdge = {
  __typename?: 'StockListEdge';
  node: Stock;
  cursor: Scalars['String'];
};

export type Stock = {
  __typename?: 'Stock';
  id: Scalars['String'];
  productId: Scalars['Int'];
  name: Scalars['String'];
  productCode: Scalars['String'];
  network: Scalars['String'];
  qty: Scalars['Int'];
};

export type StockReceiveList = {
  __typename?: 'StockReceiveList';
  success: Scalars['Boolean'];
  message: Scalars['String'];
  edges: Maybe<Array<StockReceiveListEdge>>;
  totalCount: Scalars['Int'];
};

export type StockReceiveListEdge = {
  __typename?: 'StockReceiveListEdge';
  node: StockReceive;
  cursor: Scalars['String'];
};

export type StockReceive = {
  __typename?: 'StockReceive';
  id: Scalars['String'];
  orderId: Scalars['Int'];
  productId: Scalars['Int'];
  name: Scalars['String'];
  productCode: Scalars['String'];
  network: Scalars['String'];
  qty: Scalars['Int'];
  scannedQty: Scalars['Int'];
};

export type SvcValidation = {
  uid: Scalars['String'];
  svcData: Array<Maybe<Sector>>;
};

export type Sector = {
  sector: Maybe<SvcBlock>;
};

export type SvcBlock = {
  sector_no: Scalars['String'];
  block0: Scalars['String'];
  block1: Scalars['String'];
  block2: Scalars['String'];
};

export type SvcUpdate = {
  __typename?: 'SvcUpdate';
  sectors: Array<Maybe<SvcBlockOutput>>;
};

export type SvcBlockOutput = {
  __typename?: 'SvcBlockOutput';
  sector_no: Scalars['String'];
  block0: Scalars['String'];
  block1: Scalars['String'];
  block2: Scalars['String'];
};

export type BusTicketsRequest = {
  totalAmount: Scalars['Int'];
  edges: Array<BusTicketsEdges>;
  pageInfo: Maybe<Scalars['String']>;
  totalCount: Maybe<Scalars['Int']>;
};

export type BusTicketsEdges = {
  node: TicketBus;
  cursor: Maybe<Scalars['String']>;
};

export type TicketBus = {
  id: Maybe<Scalars['ID']>;
  sessionId: Scalars['String'];
  responseCode: Scalars['Int'];
  responseMessage: Scalars['String'];
  companyId: Scalars['Int'];
  ticketId: Scalars['Int'];
  ticketNo: Scalars['String'];
  ticketType: Scalars['String'];
  routeId1: Scalars['Int'];
  routeId2: Scalars['Int'];
  routeCode1: Scalars['String'];
  routeCode2: Scalars['String'];
  fare: Scalars['Float'];
  fareProductId: Scalars['String'];
  departureLocationId: Scalars['String'];
  destinationLocationId: Scalars['String'];
  activationDate: Scalars['DateTime'];
  expiryDate: Scalars['DateTime'];
  ticketDate: Scalars['DateTime'];
  numberOfDaysTrips: Scalars['Int'];
  numberOfTransfers: Scalars['Int'];
  status: Scalars['String'];
  rules: Scalars['String'];
  fareCurrency: Scalars['String'];
};

export type TransactionsInput = {
  period: Period;
};

export type TransactionsConnection = {
  __typename?: 'TransactionsConnection';
  totalAmount: Scalars['Float'];
  edges: Maybe<Array<TransactionEdge>>;
  pageInfo: Maybe<PageInfo>;
  totalCount: Maybe<Scalars['Int']>;
};

export type TransactionEdge = {
  __typename?: 'TransactionEdge';
  node: Transaction;
  cursor: Maybe<Scalars['String']>;
};

export type Transaction = {
  __typename?: 'Transaction';
  id: Maybe<Scalars['ID']>;
  amount: Scalars['Float'];
  name: Scalars['String'];
  description: Scalars['String'];
};

export type UserPerformanceInput = {
  network: NetworkEnum;
  customerId: Scalars['Int'];
  date: Scalars['String'];
};

export type UserPerformance = {
  __typename?: 'UserPerformance';
  success: Scalars['Boolean'];
  message: Scalars['String'];
  totalActivations: Scalars['Float'];
  ogrAmount: Maybe<Scalars['Float']>;
  totalConnections: Scalars['Float'];
  totalSales: Scalars['Int'];
};

export type ValidateProductInput = {
  barcode: Scalars['String'];
};

export type ValidateProductResult = {
  __typename?: 'ValidateProductResult';
  success: Scalars['Boolean'];
  message: Scalars['String'];
  product: Maybe<Product>;
};

export type Product = {
  __typename?: 'Product';
  product_id: Scalars['Int'];
  code: Scalars['String'];
  desc: Scalars['String'];
  qty: Scalars['Int'];
};

export type WithIndex<TObject> = TObject & Record<string, any>;
export type ResolversObject<TObject> = WithIndex<TObject>;

export type ResolverTypeWrapper<T> = Promise<T> | T;

export type Resolver<TResult, TParent = {}, TContext = {}, TArgs = {}> = ResolverFn<TResult, TParent, TContext, TArgs>;

export type ResolverFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => Promise<TResult> | TResult;

export type SubscriptionSubscribeFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => AsyncIterator<TResult> | Promise<AsyncIterator<TResult>>;

export type SubscriptionResolveFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

export interface SubscriptionSubscriberObject<TResult, TKey extends string, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<{ [key in TKey]: TResult }, TParent, TContext, TArgs>;
  resolve?: SubscriptionResolveFn<TResult, { [key in TKey]: TResult }, TContext, TArgs>;
}

export interface SubscriptionResolverObject<TResult, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<any, TParent, TContext, TArgs>;
  resolve: SubscriptionResolveFn<TResult, any, TContext, TArgs>;
}

export type SubscriptionObject<TResult, TKey extends string, TParent, TContext, TArgs> =
  | SubscriptionSubscriberObject<TResult, TKey, TParent, TContext, TArgs>
  | SubscriptionResolverObject<TResult, TParent, TContext, TArgs>;

export type SubscriptionResolver<TResult, TKey extends string, TParent = {}, TContext = {}, TArgs = {}> =
  | ((...args: any[]) => SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>)
  | SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>;

export type TypeResolveFn<TTypes, TParent = {}, TContext = {}> = (
  parent: TParent,
  context: TContext,
  info: GraphQLResolveInfo
) => Maybe<TTypes> | Promise<Maybe<TTypes>>;

export type IsTypeOfResolverFn<T = {}, TContext = {}> = (obj: T, context: TContext, info: GraphQLResolveInfo) => boolean | Promise<boolean>;

export type NextResolverFn<T> = () => Promise<T>;

export type DirectiveResolverFn<TResult = {}, TParent = {}, TContext = {}, TArgs = {}> = (
  next: NextResolverFn<TResult>,
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

/** Mapping between all available schema types and the resolvers types */
export type ResolversTypes = ResolversObject<{
  AeonAuth: ResolverTypeWrapper<AeonAuth>;
  Boolean: ResolverTypeWrapper<Scalars['Boolean']>;
  String: ResolverTypeWrapper<Scalars['String']>;
  AeonResult: ResolverTypeWrapper<AeonResult>;
  DataBundlesInputNetworks: DataBundlesInputNetworks;
  DataBundlesInput: DataBundlesInput;
  DataBundlesResult: ResolverTypeWrapper<DataBundlesResult>;
  Int: ResolverTypeWrapper<Scalars['Int']>;
  BundlesEdge: ResolverTypeWrapper<BundlesEdge>;
  Bundle: ResolverTypeWrapper<Bundle>;
  ID: ResolverTypeWrapper<Scalars['ID']>;
  DataBundlesNetworkResult: ResolverTypeWrapper<DataBundlesNetworkResult>;
  BundleNetwork: ResolverTypeWrapper<BundleNetwork>;
  NetworksInput: NetworksInput;
  NetworksResult: ResolverTypeWrapper<NetworksResult>;
  NetworkEdge: ResolverTypeWrapper<NetworkEdge>;
  Network: ResolverTypeWrapper<Network>;
  Response: ResolverTypeWrapper<Response>;
  Account: ResolverTypeWrapper<Account>;
  Float: ResolverTypeWrapper<Scalars['Float']>;
  Period: Period;
  AccountRegisterUserInput: AccountRegisterUserInput;
  AccountRegisterUserPayload: ResolverTypeWrapper<AccountRegisterUserPayload>;
  AccountRegisterConsumerInput: AccountRegisterConsumerInput;
  AccountRegisterConsumerPayload: ResolverTypeWrapper<AccountRegisterConsumerPayload>;
  Country: ResolverTypeWrapper<Country>;
  IdentityType: ResolverTypeWrapper<IdentityType>;
  PaymentMethod: ResolverTypeWrapper<PaymentMethod>;
  BankDetails: ResolverTypeWrapper<BankDetails>;
  BankDetailsEdge: ResolverTypeWrapper<BankDetailsEdge>;
  BankDetail: ResolverTypeWrapper<BankDetail>;
  BusAccount: BusAccount;
  BusCarriersConnection: ResolverTypeWrapper<BusCarriersConnection>;
  BusCarriersEdge: ResolverTypeWrapper<BusCarriersEdge>;
  BusCarrierLocation: ResolverTypeWrapper<BusCarrierLocation>;
  BusDestinationsConnection: ResolverTypeWrapper<BusDestinationsConnection>;
  BusDestinationsEdge: ResolverTypeWrapper<BusDestinationsEdge>;
  BusDestinationLocation: ResolverTypeWrapper<BusDestinationLocation>;
  BusFaresConnection: ResolverTypeWrapper<BusFaresConnection>;
  BusFaresEdge: ResolverTypeWrapper<BusFaresEdge>;
  BusFare: ResolverTypeWrapper<BusFare>;
  BusFareInput: BusFareInput;
  BusStopsConnection: ResolverTypeWrapper<BusStopsConnection>;
  BusStopsEdge: ResolverTypeWrapper<BusStopsEdge>;
  BusStopLocation: ResolverTypeWrapper<BusStopLocation>;
  BusStopsInput: BusStopsInput;
  BusTicketsConnection: ResolverTypeWrapper<BusTicketsConnection>;
  BusTicketsEdge: ResolverTypeWrapper<BusTicketsEdge>;
  BusTicket: ResolverTypeWrapper<BusTicket>;
  BusTicketInput: BusTicketInput;
  RouteRecursor: ResolverTypeWrapper<RouteRecursor>;
  Query: ResolverTypeWrapper<{}>;
  Ticket: ResolverTypeWrapper<Ticket>;
  Card: ResolverTypeWrapper<Card>;
  User: ResolverTypeWrapper<User>;
  CommissionsInput: CommissionsInput;
  CommissionsConnection: ResolverTypeWrapper<CommissionsConnection>;
  CommissionEdge: ResolverTypeWrapper<CommissionEdge>;
  Commission: ResolverTypeWrapper<Commission>;
  CustomerList: ResolverTypeWrapper<CustomerList>;
  CustomerListEdge: ResolverTypeWrapper<CustomerListEdge>;
  Customer: ResolverTypeWrapper<Customer>;
  VoucherEnumType: VoucherEnumType;
  Banner: ResolverTypeWrapper<Banner>;
  BannerEdge: ResolverTypeWrapper<BannerEdge>;
  BannersResult: ResolverTypeWrapper<BannersResult>;
  AddNetworkContractInput: AddNetworkContractInput;
  AddNetworkContractResult: ResolverTypeWrapper<AddNetworkContractResult>;
  AddProductDealInput: AddProductDealInput;
  AddProductDealResult: ResolverTypeWrapper<AddProductDealResult>;
  AirtimeTopupInput: AirtimeTopupInput;
  AirtimeTopupResult: ResolverTypeWrapper<AirtimeTopupResult>;
  InternationalAirtimeTopupInput: InternationalAirtimeTopupInput;
  InternationalAirtimeTopupResult: ResolverTypeWrapper<InternationalAirtimeTopupResult>;
  AllocateStockInput: AllocateStockInput;
  DeliveryEnum: DeliveryEnum;
  AllocateStock: AllocateStock;
  AllocateStockResult: ResolverTypeWrapper<AllocateStockResult>;
  ResetMethod: ResetMethod;
  AuthResetPasswordInput: AuthResetPasswordInput;
  AuthResetPasswordPayload: ResolverTypeWrapper<AuthResetPasswordPayload>;
  AuthValidationInput: AuthValidationInput;
  AuthValidationPayload: ResolverTypeWrapper<AuthValidationPayload>;
  AuthValidationLegacyInput: AuthValidationLegacyInput;
  AuthValidationLegacyPayload: ResolverTypeWrapper<AuthValidationLegacyPayload>;
  BusTicketCancelInput: BusTicketCancelInput;
  BusTicketCancelPayload: ResolverTypeWrapper<BusTicketCancelPayload>;
  BusTicketConfirmCancelInput: BusTicketConfirmCancelInput;
  BusTicketConfirmCancelPayload: ResolverTypeWrapper<BusTicketConfirmCancelPayload>;
  BusTicketCheckoutInput: BusTicketCheckoutInput;
  BusTicketCheckoutPayload: ResolverTypeWrapper<BusTicketCheckoutPayload>;
  BusTicketConfirmInput: BusTicketConfirmInput;
  BusTicketConfirmPayload: ResolverTypeWrapper<BusTicketConfirmPayload>;
  ConfirmMeterInput: ConfirmMeterInput;
  ConfirmMeterResult: ResolverTypeWrapper<ConfirmMeterResult>;
  ConfirmMeterDetail: ResolverTypeWrapper<ConfirmMeterDetail>;
  CustomerOrderInput: CustomerOrderInput;
  CustomerOrder: CustomerOrder;
  CustomerOrderResult: ResolverTypeWrapper<CustomerOrderResult>;
  DataTopupInput: DataTopupInput;
  DataTopupResult: ResolverTypeWrapper<DataTopupResult>;
  ElectricityTopupInput: ElectricityTopupInput;
  ElectricityTopupResult: ResolverTypeWrapper<ElectricityTopupResult>;
  ReceiveStockInput: ReceiveStockInput;
  ReceiveStockResult: ResolverTypeWrapper<ReceiveStockResult>;
  RegisterConsumerInput: RegisterConsumerInput;
  RegisterConsumerAddress: RegisterConsumerAddress;
  RegisterConsumerResult: ResolverTypeWrapper<RegisterConsumerResult>;
  RepTransferInput: RepTransferInput;
  ProductTransfer: ProductTransfer;
  RepTransferResult: ResolverTypeWrapper<RepTransferResult>;
  RicaRegisterInput: RicaRegisterInput;
  SimDetails: SimDetails;
  Identity: Identity;
  IdentityMethod: IdentityMethod;
  CustomerDetail: CustomerDetail;
  RicaRegisterResult: ResolverTypeWrapper<RicaRegisterResult>;
  UploadImageInput: UploadImageInput;
  UploadImageResult: ResolverTypeWrapper<UploadImageResult>;
  VoucherRedemptionInput: VoucherRedemptionInput;
  VoucherRedemptionPayload: ResolverTypeWrapper<VoucherRedemptionPayload>;
  Mutation: ResolverTypeWrapper<{}>;
  ProductDealInput: ProductDealInput;
  ProductDealList: ResolverTypeWrapper<ProductDealList>;
  ProductDealListEdge: ResolverTypeWrapper<ProductDealListEdge>;
  ProductDeal: ResolverTypeWrapper<ProductDeal>;
  NetworkEnum: NetworkEnum;
  ProductsByNetworkInput: ProductsByNetworkInput;
  ProductsByNetworkResult: ResolverTypeWrapper<ProductsByNetworkResult>;
  ProductsByNetworkEdge: ResolverTypeWrapper<ProductsByNetworkEdge>;
  ProductByNetwork: ResolverTypeWrapper<ProductByNetwork>;
  Profile: ResolverTypeWrapper<Profile>;
  Role: ResolverTypeWrapper<Role>;
  Node: ResolversTypes['DummyNode'];
  DummyNode: ResolverTypeWrapper<DummyNode>;
  PageInfo: ResolverTypeWrapper<PageInfo>;
  DateTime: ResolverTypeWrapper<Scalars['DateTime']>;
  StockList: ResolverTypeWrapper<StockList>;
  StockListEdge: ResolverTypeWrapper<StockListEdge>;
  Stock: ResolverTypeWrapper<Stock>;
  StockReceiveList: ResolverTypeWrapper<StockReceiveList>;
  StockReceiveListEdge: ResolverTypeWrapper<StockReceiveListEdge>;
  StockReceive: ResolverTypeWrapper<StockReceive>;
  SvcValidation: SvcValidation;
  Sector: Sector;
  SvcBlock: SvcBlock;
  SvcUpdate: ResolverTypeWrapper<SvcUpdate>;
  SvcBlockOutput: ResolverTypeWrapper<SvcBlockOutput>;
  BusTicketsRequest: BusTicketsRequest;
  BusTicketsEdges: BusTicketsEdges;
  TicketBus: TicketBus;
  TransactionsInput: TransactionsInput;
  TransactionsConnection: ResolverTypeWrapper<TransactionsConnection>;
  TransactionEdge: ResolverTypeWrapper<TransactionEdge>;
  Transaction: ResolverTypeWrapper<Transaction>;
  UserPerformanceInput: UserPerformanceInput;
  UserPerformance: ResolverTypeWrapper<UserPerformance>;
  ValidateProductInput: ValidateProductInput;
  ValidateProductResult: ResolverTypeWrapper<ValidateProductResult>;
  Product: ResolverTypeWrapper<Product>;
}>;

/** Mapping between all available schema types and the resolvers parents */
export type ResolversParentTypes = ResolversObject<{
  AeonAuth: AeonAuth;
  Boolean: Scalars['Boolean'];
  String: Scalars['String'];
  AeonResult: AeonResult;
  DataBundlesInput: DataBundlesInput;
  DataBundlesResult: DataBundlesResult;
  Int: Scalars['Int'];
  BundlesEdge: BundlesEdge;
  Bundle: Bundle;
  ID: Scalars['ID'];
  DataBundlesNetworkResult: DataBundlesNetworkResult;
  BundleNetwork: BundleNetwork;
  NetworksInput: NetworksInput;
  NetworksResult: NetworksResult;
  NetworkEdge: NetworkEdge;
  Network: Network;
  Response: Response;
  Account: Account;
  Float: Scalars['Float'];
  AccountRegisterUserInput: AccountRegisterUserInput;
  AccountRegisterUserPayload: AccountRegisterUserPayload;
  AccountRegisterConsumerInput: AccountRegisterConsumerInput;
  AccountRegisterConsumerPayload: AccountRegisterConsumerPayload;
  Country: Country;
  IdentityType: IdentityType;
  PaymentMethod: PaymentMethod;
  BankDetails: BankDetails;
  BankDetailsEdge: BankDetailsEdge;
  BankDetail: BankDetail;
  BusAccount: BusAccount;
  BusCarriersConnection: BusCarriersConnection;
  BusCarriersEdge: BusCarriersEdge;
  BusCarrierLocation: BusCarrierLocation;
  BusDestinationsConnection: BusDestinationsConnection;
  BusDestinationsEdge: BusDestinationsEdge;
  BusDestinationLocation: BusDestinationLocation;
  BusFaresConnection: BusFaresConnection;
  BusFaresEdge: BusFaresEdge;
  BusFare: BusFare;
  BusFareInput: BusFareInput;
  BusStopsConnection: BusStopsConnection;
  BusStopsEdge: BusStopsEdge;
  BusStopLocation: BusStopLocation;
  BusStopsInput: BusStopsInput;
  BusTicketsConnection: BusTicketsConnection;
  BusTicketsEdge: BusTicketsEdge;
  BusTicket: BusTicket;
  BusTicketInput: BusTicketInput;
  RouteRecursor: RouteRecursor;
  Query: {};
  Ticket: Ticket;
  Card: Card;
  User: User;
  CommissionsInput: CommissionsInput;
  CommissionsConnection: CommissionsConnection;
  CommissionEdge: CommissionEdge;
  Commission: Commission;
  CustomerList: CustomerList;
  CustomerListEdge: CustomerListEdge;
  Customer: Customer;
  Banner: Banner;
  BannerEdge: BannerEdge;
  BannersResult: BannersResult;
  AddNetworkContractInput: AddNetworkContractInput;
  AddNetworkContractResult: AddNetworkContractResult;
  AddProductDealInput: AddProductDealInput;
  AddProductDealResult: AddProductDealResult;
  AirtimeTopupInput: AirtimeTopupInput;
  AirtimeTopupResult: AirtimeTopupResult;
  InternationalAirtimeTopupInput: InternationalAirtimeTopupInput;
  InternationalAirtimeTopupResult: InternationalAirtimeTopupResult;
  AllocateStockInput: AllocateStockInput;
  AllocateStock: AllocateStock;
  AllocateStockResult: AllocateStockResult;
  AuthResetPasswordInput: AuthResetPasswordInput;
  AuthResetPasswordPayload: AuthResetPasswordPayload;
  AuthValidationInput: AuthValidationInput;
  AuthValidationPayload: AuthValidationPayload;
  AuthValidationLegacyInput: AuthValidationLegacyInput;
  AuthValidationLegacyPayload: AuthValidationLegacyPayload;
  BusTicketCancelInput: BusTicketCancelInput;
  BusTicketCancelPayload: BusTicketCancelPayload;
  BusTicketConfirmCancelInput: BusTicketConfirmCancelInput;
  BusTicketConfirmCancelPayload: BusTicketConfirmCancelPayload;
  BusTicketCheckoutInput: BusTicketCheckoutInput;
  BusTicketCheckoutPayload: BusTicketCheckoutPayload;
  BusTicketConfirmInput: BusTicketConfirmInput;
  BusTicketConfirmPayload: BusTicketConfirmPayload;
  ConfirmMeterInput: ConfirmMeterInput;
  ConfirmMeterResult: ConfirmMeterResult;
  ConfirmMeterDetail: ConfirmMeterDetail;
  CustomerOrderInput: CustomerOrderInput;
  CustomerOrder: CustomerOrder;
  CustomerOrderResult: CustomerOrderResult;
  DataTopupInput: DataTopupInput;
  DataTopupResult: DataTopupResult;
  ElectricityTopupInput: ElectricityTopupInput;
  ElectricityTopupResult: ElectricityTopupResult;
  ReceiveStockInput: ReceiveStockInput;
  ReceiveStockResult: ReceiveStockResult;
  RegisterConsumerInput: RegisterConsumerInput;
  RegisterConsumerAddress: RegisterConsumerAddress;
  RegisterConsumerResult: RegisterConsumerResult;
  RepTransferInput: RepTransferInput;
  ProductTransfer: ProductTransfer;
  RepTransferResult: RepTransferResult;
  RicaRegisterInput: RicaRegisterInput;
  SimDetails: SimDetails;
  Identity: Identity;
  CustomerDetail: CustomerDetail;
  RicaRegisterResult: RicaRegisterResult;
  UploadImageInput: UploadImageInput;
  UploadImageResult: UploadImageResult;
  VoucherRedemptionInput: VoucherRedemptionInput;
  VoucherRedemptionPayload: VoucherRedemptionPayload;
  Mutation: {};
  ProductDealInput: ProductDealInput;
  ProductDealList: ProductDealList;
  ProductDealListEdge: ProductDealListEdge;
  ProductDeal: ProductDeal;
  ProductsByNetworkInput: ProductsByNetworkInput;
  ProductsByNetworkResult: ProductsByNetworkResult;
  ProductsByNetworkEdge: ProductsByNetworkEdge;
  ProductByNetwork: ProductByNetwork;
  Profile: Profile;
  Role: Role;
  Node: ResolversParentTypes['DummyNode'];
  DummyNode: DummyNode;
  PageInfo: PageInfo;
  DateTime: Scalars['DateTime'];
  StockList: StockList;
  StockListEdge: StockListEdge;
  Stock: Stock;
  StockReceiveList: StockReceiveList;
  StockReceiveListEdge: StockReceiveListEdge;
  StockReceive: StockReceive;
  SvcValidation: SvcValidation;
  Sector: Sector;
  SvcBlock: SvcBlock;
  SvcUpdate: SvcUpdate;
  SvcBlockOutput: SvcBlockOutput;
  BusTicketsRequest: BusTicketsRequest;
  BusTicketsEdges: BusTicketsEdges;
  TicketBus: TicketBus;
  TransactionsInput: TransactionsInput;
  TransactionsConnection: TransactionsConnection;
  TransactionEdge: TransactionEdge;
  Transaction: Transaction;
  UserPerformanceInput: UserPerformanceInput;
  UserPerformance: UserPerformance;
  ValidateProductInput: ValidateProductInput;
  ValidateProductResult: ValidateProductResult;
  Product: Product;
}>;

export type RelayIdDirectiveArgs = {   type: Scalars['String']; };

export type RelayIdDirectiveResolver<Result, Parent, ContextType = Context, Args = RelayIdDirectiveArgs> = DirectiveResolverFn<Result, Parent, ContextType, Args>;

export type AeonAuthResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AeonAuth'] = ResolversParentTypes['AeonAuth']> = ResolversObject<{
  authorized: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  clientMutationId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AeonResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AeonResult'] = ResolversParentTypes['AeonResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  response: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type DataBundlesResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['DataBundlesResult'] = ResolversParentTypes['DataBundlesResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  edges: Resolver<Maybe<Array<ResolversTypes['BundlesEdge']>>, ParentType, ContextType>;
  totalCount: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BundlesEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BundlesEdge'] = ResolversParentTypes['BundlesEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['Bundle'], ParentType, ContextType>;
  cursor: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BundleResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Bundle'] = ResolversParentTypes['Bundle']> = ResolversObject<{
  id: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  network: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  category: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  desc: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  amount: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  code: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type DataBundlesNetworkResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['DataBundlesNetworkResult'] = ResolversParentTypes['DataBundlesNetworkResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  cellc: Resolver<Array<Maybe<ResolversTypes['BundleNetwork']>>, ParentType, ContextType>;
  mtn: Resolver<Array<Maybe<ResolversTypes['BundleNetwork']>>, ParentType, ContextType>;
  telkom: Resolver<Array<Maybe<ResolversTypes['BundleNetwork']>>, ParentType, ContextType>;
  vodacom: Resolver<Array<Maybe<ResolversTypes['BundleNetwork']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BundleNetworkResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BundleNetwork'] = ResolversParentTypes['BundleNetwork']> = ResolversObject<{
  category: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  desc: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  amount: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  code: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type NetworksResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['NetworksResult'] = ResolversParentTypes['NetworksResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  edges: Resolver<Maybe<Array<ResolversTypes['NetworkEdge']>>, ParentType, ContextType>;
  totalCount: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type NetworkEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['NetworkEdge'] = ResolversParentTypes['NetworkEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['Network'], ParentType, ContextType>;
  cursor: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type NetworkResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Network'] = ResolversParentTypes['Network']> = ResolversObject<{
  id: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  network: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  colour: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  logo: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ResponseResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Response'] = ResolversParentTypes['Response']> = ResolversObject<{
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  code: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AccountResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Account'] = ResolversParentTypes['Account']> = ResolversObject<{
  balance: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  profit: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  accountNumber: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AccountRegisterUserPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AccountRegisterUserPayload'] = ResolversParentTypes['AccountRegisterUserPayload']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AccountRegisterConsumerPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AccountRegisterConsumerPayload'] = ResolversParentTypes['AccountRegisterConsumerPayload']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  output: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  groupId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  identityTypeId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  paymentMethodId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  identityReference: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  vatRegistered: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  isActive: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  userId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  repUserId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  identityReferenceExpiryDate: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  identityReferenceOriginCountry: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  updatedAt: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  createdAt: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CountryResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Country'] = ResolversParentTypes['Country']> = ResolversObject<{
  id: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  abv: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  abv3: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  abv3_alt: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  code: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  slug: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  created_at: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  updated_at: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type IdentityTypeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['IdentityType'] = ResolversParentTypes['IdentityType']> = ResolversObject<{
  id: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  status: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  process: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  is_active: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  created_at: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  updated_at: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PaymentMethodResolvers<ContextType = Context, ParentType extends ResolversParentTypes['PaymentMethod'] = ResolversParentTypes['PaymentMethod']> = ResolversObject<{
  id: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  status: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  process: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  is_active: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  created_at: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  updated_at: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BankDetailsResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BankDetails'] = ResolversParentTypes['BankDetails']> = ResolversObject<{
  edges: Resolver<Maybe<Array<ResolversTypes['BankDetailsEdge']>>, ParentType, ContextType>;
  totalCount: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BankDetailsEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BankDetailsEdge'] = ResolversParentTypes['BankDetailsEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['BankDetail'], ParentType, ContextType>;
  cursor: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BankDetailResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BankDetail'] = ResolversParentTypes['BankDetail']> = ResolversObject<{
  id: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  bank: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  accountName: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  accountNumber: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  branch: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  branchCode: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  universalCode: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  swift: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  reference: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusCarriersConnectionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusCarriersConnection'] = ResolversParentTypes['BusCarriersConnection']> = ResolversObject<{
  edges: Resolver<Array<ResolversTypes['BusCarriersEdge']>, ParentType, ContextType>;
  pageInfo: Resolver<Maybe<ResolversTypes['PageInfo']>, ParentType, ContextType>;
  totalCount: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusCarriersEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusCarriersEdge'] = ResolversParentTypes['BusCarriersEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['BusCarrierLocation'], ParentType, ContextType>;
  cursor: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusCarrierLocationResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusCarrierLocation'] = ResolversParentTypes['BusCarrierLocation']> = ResolversObject<{
  name: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  shortName: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  companyId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  role: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusDestinationsConnectionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusDestinationsConnection'] = ResolversParentTypes['BusDestinationsConnection']> = ResolversObject<{
  edges: Resolver<Array<ResolversTypes['BusDestinationsEdge']>, ParentType, ContextType>;
  pageInfo: Resolver<Maybe<ResolversTypes['PageInfo']>, ParentType, ContextType>;
  totalCount: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusDestinationsEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusDestinationsEdge'] = ResolversParentTypes['BusDestinationsEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['BusDestinationLocation'], ParentType, ContextType>;
  cursor: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusDestinationLocationResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusDestinationLocation'] = ResolversParentTypes['BusDestinationLocation']> = ResolversObject<{
  locationId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  type: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  stationId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  entityId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusFaresConnectionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusFaresConnection'] = ResolversParentTypes['BusFaresConnection']> = ResolversObject<{
  totalAmount: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  edges: Resolver<Array<ResolversTypes['BusFaresEdge']>, ParentType, ContextType>;
  pageInfo: Resolver<Maybe<ResolversTypes['PageInfo']>, ParentType, ContextType>;
  totalCount: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusFaresEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusFaresEdge'] = ResolversParentTypes['BusFaresEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['BusFare'], ParentType, ContextType>;
  cursor: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusFareResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusFare'] = ResolversParentTypes['BusFare']> = ResolversObject<{
  id: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  sessionId: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  responseCode: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  responseMessage: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  status: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  period: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  fareProductId: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  code: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  routes: Resolver<ResolversTypes['RouteRecursor'], ParentType, ContextType>;
  companyId: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  weekdays: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  created: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  availableFrom: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  availableTo: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  transferCount: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  passValue: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  tripsPerDay: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  passType: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  price: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  shortName: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  desc: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusStopsConnectionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusStopsConnection'] = ResolversParentTypes['BusStopsConnection']> = ResolversObject<{
  edges: Resolver<Array<ResolversTypes['BusStopsEdge']>, ParentType, ContextType>;
  pageInfo: Resolver<Maybe<ResolversTypes['PageInfo']>, ParentType, ContextType>;
  totalCount: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusStopsEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusStopsEdge'] = ResolversParentTypes['BusStopsEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['BusStopLocation'], ParentType, ContextType>;
  cursor: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusStopLocationResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusStopLocation'] = ResolversParentTypes['BusStopLocation']> = ResolversObject<{
  id: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusTicketsConnectionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusTicketsConnection'] = ResolversParentTypes['BusTicketsConnection']> = ResolversObject<{
  edges: Resolver<Maybe<Array<ResolversTypes['BusTicketsEdge']>>, ParentType, ContextType>;
  pageInfo: Resolver<Maybe<ResolversTypes['PageInfo']>, ParentType, ContextType>;
  totalCount: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusTicketsEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusTicketsEdge'] = ResolversParentTypes['BusTicketsEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['BusTicket'], ParentType, ContextType>;
  cursor: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusTicketResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusTicket'] = ResolversParentTypes['BusTicket']> = ResolversObject<{
  id: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  sessionId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  responseCode: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  responseMessage: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  companyId: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  ticketId: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  ticketNo: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  ticketType: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  routes: Resolver<Maybe<ResolversTypes['RouteRecursor']>, ParentType, ContextType>;
  fare: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  fareProductId: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  departureLocationId: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  destinationLocationId: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  activationDate: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  expiryDate: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  ticketDate: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  numberOfDaysTrips: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  numberOfTransfers: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  status: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  rules: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  fareCurrency: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RouteRecursorResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RouteRecursor'] = ResolversParentTypes['RouteRecursor']> = ResolversObject<{
  routes: Resolver<Maybe<Array<Maybe<ResolversTypes['String']>>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type QueryResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Query'] = ResolversParentTypes['Query']> = ResolversObject<{
  account: Resolver<ResolversTypes['Account'], ParentType, ContextType>;
  bankDetails: Resolver<ResolversTypes['BankDetails'], ParentType, ContextType>;
  bus_tickets: Resolver<Maybe<ResolversTypes['User']>, ParentType, ContextType, RequireFields<QueryBus_TicketsArgs, 'card_number'>>;
  carriers: Resolver<ResolversTypes['BusCarriersConnection'], ParentType, ContextType, RequireFields<QueryCarriersArgs, 'input'>>;
  commissions: Resolver<ResolversTypes['CommissionsConnection'], ParentType, ContextType, RequireFields<QueryCommissionsArgs, 'input'>>;
  countries: Resolver<Maybe<Array<Maybe<ResolversTypes['Country']>>>, ParentType, ContextType>;
  customerList: Resolver<ResolversTypes['CustomerList'], ParentType, ContextType>;
  dataBundles: Resolver<ResolversTypes['DataBundlesResult'], ParentType, ContextType, RequireFields<QueryDataBundlesArgs, 'input'>>;
  dataBundlesNetwork: Resolver<ResolversTypes['DataBundlesNetworkResult'], ParentType, ContextType>;
  destinations: Resolver<ResolversTypes['BusDestinationsConnection'], ParentType, ContextType, RequireFields<QueryDestinationsArgs, 'companyId' | 'departureLocationId'>>;
  fares: Resolver<ResolversTypes['BusFaresConnection'], ParentType, ContextType, RequireFields<QueryFaresArgs, never>>;
  fetchBanners: Resolver<Maybe<ResolversTypes['BannersResult']>, ParentType, ContextType>;
  identityTypes: Resolver<Maybe<Array<Maybe<ResolversTypes['IdentityType']>>>, ParentType, ContextType>;
  networks: Resolver<ResolversTypes['NetworksResult'], ParentType, ContextType, RequireFields<QueryNetworksArgs, 'input'>>;
  node: Resolver<Maybe<ResolversTypes['Node']>, ParentType, ContextType, RequireFields<QueryNodeArgs, 'id'>>;
  paymentMethods: Resolver<Maybe<Array<Maybe<ResolversTypes['PaymentMethod']>>>, ParentType, ContextType>;
  productDeals: Resolver<ResolversTypes['ProductDealList'], ParentType, ContextType, RequireFields<QueryProductDealsArgs, 'input'>>;
  productsByNetwork: Resolver<ResolversTypes['ProductsByNetworkResult'], ParentType, ContextType, RequireFields<QueryProductsByNetworkArgs, 'input'>>;
  profile: Resolver<Maybe<ResolversTypes['Profile']>, ParentType, ContextType>;
  stockList: Resolver<ResolversTypes['StockList'], ParentType, ContextType>;
  stockToReceive: Resolver<ResolversTypes['StockReceiveList'], ParentType, ContextType>;
  stops: Resolver<ResolversTypes['BusStopsConnection'], ParentType, ContextType, RequireFields<QueryStopsArgs, 'input'>>;
  svcValidate: Resolver<ResolversTypes['BusTicketsConnection'], ParentType, ContextType, RequireFields<QuerySvcValidateArgs, 'auth'>>;
  tickets: Resolver<Maybe<ResolversTypes['BusTicketsConnection']>, ParentType, ContextType, RequireFields<QueryTicketsArgs, 'auth'>>;
  transactions: Resolver<ResolversTypes['TransactionsConnection'], ParentType, ContextType, RequireFields<QueryTransactionsArgs, 'input'>>;
  userPerformance: Resolver<ResolversTypes['UserPerformance'], ParentType, ContextType, RequireFields<QueryUserPerformanceArgs, 'input'>>;
  validateProduct: Resolver<ResolversTypes['ValidateProductResult'], ParentType, ContextType, RequireFields<QueryValidateProductArgs, 'input'>>;
}>;

export type TicketResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Ticket'] = ResolversParentTypes['Ticket']> = ResolversObject<{
  price: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  type: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  depature: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  destination: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CardResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Card'] = ResolversParentTypes['Card']> = ResolversObject<{
  type: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  card_number: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UserResolvers<ContextType = Context, ParentType extends ResolversParentTypes['User'] = ResolversParentTypes['User']> = ResolversObject<{
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  ticket_count: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  type: Resolver<ResolversTypes['Card'], ParentType, ContextType>;
  tickets: Resolver<Maybe<Array<ResolversTypes['Ticket']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CommissionsConnectionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CommissionsConnection'] = ResolversParentTypes['CommissionsConnection']> = ResolversObject<{
  totalRetail: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  totalProfit: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  edges: Resolver<Maybe<Array<ResolversTypes['CommissionEdge']>>, ParentType, ContextType>;
  pageInfo: Resolver<Maybe<ResolversTypes['PageInfo']>, ParentType, ContextType>;
  totalCount: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CommissionEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CommissionEdge'] = ResolversParentTypes['CommissionEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['Commission'], ParentType, ContextType>;
  cursor: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CommissionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Commission'] = ResolversParentTypes['Commission']> = ResolversObject<{
  id: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  retail: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  profit: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  qty: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CustomerListResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CustomerList'] = ResolversParentTypes['CustomerList']> = ResolversObject<{
  edges: Resolver<Maybe<Array<ResolversTypes['CustomerListEdge']>>, ParentType, ContextType>;
  totalCount: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CustomerListEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CustomerListEdge'] = ResolversParentTypes['CustomerListEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['Customer'], ParentType, ContextType>;
  cursor: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CustomerResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Customer'] = ResolversParentTypes['Customer']> = ResolversObject<{
  id: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  customerCode: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  customerId: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BannerResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Banner'] = ResolversParentTypes['Banner']> = ResolversObject<{
  id: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  url: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BannerEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BannerEdge'] = ResolversParentTypes['BannerEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['Banner'], ParentType, ContextType>;
  cursor: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BannersResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BannersResult'] = ResolversParentTypes['BannersResult']> = ResolversObject<{
  total: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  edges: Resolver<Maybe<Array<ResolversTypes['BannerEdge']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AddNetworkContractResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AddNetworkContractResult'] = ResolversParentTypes['AddNetworkContractResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AddProductDealResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AddProductDealResult'] = ResolversParentTypes['AddProductDealResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AirtimeTopupResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AirtimeTopupResult'] = ResolversParentTypes['AirtimeTopupResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type InternationalAirtimeTopupResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['InternationalAirtimeTopupResult'] = ResolversParentTypes['InternationalAirtimeTopupResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AllocateStockResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AllocateStockResult'] = ResolversParentTypes['AllocateStockResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AuthResetPasswordPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AuthResetPasswordPayload'] = ResolversParentTypes['AuthResetPasswordPayload']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  clientMutationId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AuthValidationPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AuthValidationPayload'] = ResolversParentTypes['AuthValidationPayload']> = ResolversObject<{
  authorized: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  token: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  status: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  profile: Resolver<Maybe<ResolversTypes['Profile']>, ParentType, ContextType>;
  clientMutationId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AuthValidationLegacyPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AuthValidationLegacyPayload'] = ResolversParentTypes['AuthValidationLegacyPayload']> = ResolversObject<{
  authorized: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  clientMutationId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusTicketCancelPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusTicketCancelPayload'] = ResolversParentTypes['BusTicketCancelPayload']> = ResolversObject<{
  svcData: Resolver<ResolversTypes['SvcUpdate'], ParentType, ContextType>;
  ticket: Resolver<ResolversTypes['BusTicket'], ParentType, ContextType>;
  transaction: Resolver<ResolversTypes['Transaction'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusTicketConfirmCancelPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusTicketConfirmCancelPayload'] = ResolversParentTypes['BusTicketConfirmCancelPayload']> = ResolversObject<{
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  status: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  svcData: Resolver<ResolversTypes['SvcUpdate'], ParentType, ContextType>;
  ticket: Resolver<ResolversTypes['BusTicket'], ParentType, ContextType>;
  transaction: Resolver<ResolversTypes['Transaction'], ParentType, ContextType>;
  transref: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  printLines: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  merchantPrintLines: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusTicketCheckoutPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusTicketCheckoutPayload'] = ResolversParentTypes['BusTicketCheckoutPayload']> = ResolversObject<{
  svcData: Resolver<ResolversTypes['SvcUpdate'], ParentType, ContextType>;
  ticket: Resolver<ResolversTypes['BusTicket'], ParentType, ContextType>;
  transaction: Resolver<ResolversTypes['Transaction'], ParentType, ContextType>;
  transref: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusTicketConfirmPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusTicketConfirmPayload'] = ResolversParentTypes['BusTicketConfirmPayload']> = ResolversObject<{
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  status: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  svcData: Resolver<ResolversTypes['SvcUpdate'], ParentType, ContextType>;
  ticket: Resolver<ResolversTypes['BusTicket'], ParentType, ContextType>;
  transaction: Resolver<ResolversTypes['Transaction'], ParentType, ContextType>;
  transref: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  printLines: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  merchantPrintLines: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ConfirmMeterResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ConfirmMeterResult'] = ResolversParentTypes['ConfirmMeterResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  detail: Resolver<Maybe<ResolversTypes['ConfirmMeterDetail']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ConfirmMeterDetailResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ConfirmMeterDetail'] = ResolversParentTypes['ConfirmMeterDetail']> = ResolversObject<{
  transRef: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  customer: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  address: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  utility: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  trxTypeId: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CustomerOrderResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CustomerOrderResult'] = ResolversParentTypes['CustomerOrderResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type DataTopupResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['DataTopupResult'] = ResolversParentTypes['DataTopupResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ElectricityTopupResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ElectricityTopupResult'] = ResolversParentTypes['ElectricityTopupResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ReceiveStockResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ReceiveStockResult'] = ResolversParentTypes['ReceiveStockResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  qty: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  scannedQty: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RegisterConsumerResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RegisterConsumerResult'] = ResolversParentTypes['RegisterConsumerResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  status: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  token: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RepTransferResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RepTransferResult'] = ResolversParentTypes['RepTransferResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RicaRegisterResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RicaRegisterResult'] = ResolversParentTypes['RicaRegisterResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UploadImageResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UploadImageResult'] = ResolversParentTypes['UploadImageResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  status: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type VoucherRedemptionPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['VoucherRedemptionPayload'] = ResolversParentTypes['VoucherRedemptionPayload']> = ResolversObject<{
  requestId: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  dateTime: Resolver<Maybe<ResolversTypes['DateTime']>, ParentType, ContextType>;
  balance: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  reference: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  clientMutationId: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type MutationResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Mutation'] = ResolversParentTypes['Mutation']> = ResolversObject<{
  addNetworkContract: Resolver<Maybe<ResolversTypes['AddNetworkContractResult']>, ParentType, ContextType, RequireFields<MutationAddNetworkContractArgs, 'input'>>;
  addProductDeal: Resolver<Maybe<ResolversTypes['AddProductDealResult']>, ParentType, ContextType, RequireFields<MutationAddProductDealArgs, 'input'>>;
  airtimeTopup: Resolver<Maybe<ResolversTypes['AirtimeTopupResult']>, ParentType, ContextType, RequireFields<MutationAirtimeTopupArgs, 'input'>>;
  allocateStock: Resolver<Maybe<ResolversTypes['AllocateStockResult']>, ParentType, ContextType, RequireFields<MutationAllocateStockArgs, 'input'>>;
  authRegistrationConsumer: Resolver<Maybe<ResolversTypes['AccountRegisterConsumerPayload']>, ParentType, ContextType, RequireFields<MutationAuthRegistrationConsumerArgs, 'input'>>;
  authRegistrationUser: Resolver<Maybe<ResolversTypes['AccountRegisterUserPayload']>, ParentType, ContextType, RequireFields<MutationAuthRegistrationUserArgs, 'input'>>;
  authResetPassword: Resolver<Maybe<ResolversTypes['AuthResetPasswordPayload']>, ParentType, ContextType, RequireFields<MutationAuthResetPasswordArgs, 'input'>>;
  authValidation: Resolver<Maybe<ResolversTypes['AuthValidationPayload']>, ParentType, ContextType, RequireFields<MutationAuthValidationArgs, 'input'>>;
  authValidationLegacy: Resolver<Maybe<ResolversTypes['AuthValidationLegacyPayload']>, ParentType, ContextType, RequireFields<MutationAuthValidationLegacyArgs, 'input'>>;
  busTicketCancel: Resolver<Maybe<ResolversTypes['BusTicketCancelPayload']>, ParentType, ContextType, RequireFields<MutationBusTicketCancelArgs, 'input'>>;
  busTicketCancelConfirm: Resolver<Maybe<ResolversTypes['BusTicketConfirmCancelPayload']>, ParentType, ContextType, RequireFields<MutationBusTicketCancelConfirmArgs, 'input'>>;
  busTicketCheckout: Resolver<Maybe<ResolversTypes['BusTicketCheckoutPayload']>, ParentType, ContextType, RequireFields<MutationBusTicketCheckoutArgs, 'input'>>;
  busTicketConfirm: Resolver<Maybe<ResolversTypes['BusTicketConfirmPayload']>, ParentType, ContextType, RequireFields<MutationBusTicketConfirmArgs, 'input'>>;
  confirmMeter: Resolver<Maybe<ResolversTypes['ConfirmMeterResult']>, ParentType, ContextType, RequireFields<MutationConfirmMeterArgs, 'input'>>;
  customerOrder: Resolver<Maybe<ResolversTypes['CustomerOrderResult']>, ParentType, ContextType, RequireFields<MutationCustomerOrderArgs, 'input'>>;
  dataTopup: Resolver<Maybe<ResolversTypes['DataTopupResult']>, ParentType, ContextType, RequireFields<MutationDataTopupArgs, 'input'>>;
  electricityTopup: Resolver<Maybe<ResolversTypes['ElectricityTopupResult']>, ParentType, ContextType, RequireFields<MutationElectricityTopupArgs, 'input'>>;
  internationalAirtimeTopup: Resolver<Maybe<ResolversTypes['InternationalAirtimeTopupResult']>, ParentType, ContextType, RequireFields<MutationInternationalAirtimeTopupArgs, 'input'>>;
  receiveStock: Resolver<Maybe<ResolversTypes['ReceiveStockResult']>, ParentType, ContextType, RequireFields<MutationReceiveStockArgs, 'input'>>;
  registerConsumer: Resolver<Maybe<ResolversTypes['RegisterConsumerResult']>, ParentType, ContextType, RequireFields<MutationRegisterConsumerArgs, 'input'>>;
  repTransfer: Resolver<Maybe<ResolversTypes['RepTransferResult']>, ParentType, ContextType, RequireFields<MutationRepTransferArgs, 'input'>>;
  ricaRegister: Resolver<Maybe<ResolversTypes['RicaRegisterResult']>, ParentType, ContextType, RequireFields<MutationRicaRegisterArgs, 'input'>>;
  uploadId: Resolver<Maybe<ResolversTypes['UploadImageResult']>, ParentType, ContextType, RequireFields<MutationUploadIdArgs, 'input'>>;
  uploadProofOfResidence: Resolver<Maybe<ResolversTypes['UploadImageResult']>, ParentType, ContextType, RequireFields<MutationUploadProofOfResidenceArgs, 'input'>>;
  uploadSelfie: Resolver<Maybe<ResolversTypes['UploadImageResult']>, ParentType, ContextType, RequireFields<MutationUploadSelfieArgs, 'input'>>;
  uploadSignature: Resolver<Maybe<ResolversTypes['UploadImageResult']>, ParentType, ContextType, RequireFields<MutationUploadSignatureArgs, 'input'>>;
  voucherRedemption: Resolver<Maybe<ResolversTypes['VoucherRedemptionPayload']>, ParentType, ContextType, RequireFields<MutationVoucherRedemptionArgs, 'input'>>;
}>;

export type ProductDealListResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ProductDealList'] = ResolversParentTypes['ProductDealList']> = ResolversObject<{
  status: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  edges: Resolver<Maybe<Array<ResolversTypes['ProductDealListEdge']>>, ParentType, ContextType>;
  totalCount: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProductDealListEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ProductDealListEdge'] = ResolversParentTypes['ProductDealListEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['ProductDeal'], ParentType, ContextType>;
  cursor: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProductDealResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ProductDeal'] = ResolversParentTypes['ProductDeal']> = ResolversObject<{
  id: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  dealId: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  isTiered: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  tierId: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  ogr: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  act: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  sim: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  isSplit: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProductsByNetworkResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ProductsByNetworkResult'] = ResolversParentTypes['ProductsByNetworkResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  edges: Resolver<Maybe<Array<ResolversTypes['ProductsByNetworkEdge']>>, ParentType, ContextType>;
  totalCount: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProductsByNetworkEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ProductsByNetworkEdge'] = ResolversParentTypes['ProductsByNetworkEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['ProductByNetwork'], ParentType, ContextType>;
  cursor: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProductByNetworkResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ProductByNetwork'] = ResolversParentTypes['ProductByNetwork']> = ResolversObject<{
  id: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  description: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  productCode: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  productId: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  costPrice: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  salePrice: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  actExpenseCode: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  ogrExpenseCode: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  simExpenseCode: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProfileResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Profile'] = ResolversParentTypes['Profile']> = ResolversObject<{
  id: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  customerId: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  username: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  firstName: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  lastName: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  email: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  userType: Resolver<ResolversTypes['Role'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RoleResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Role'] = ResolversParentTypes['Role']> = ResolversObject<{
  id: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  description: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  slug: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type NodeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Node'] = ResolversParentTypes['Node']> = ResolversObject<{
  __resolveType: TypeResolveFn<'DummyNode', ParentType, ContextType>;
  id: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
}>;

export type DummyNodeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['DummyNode'] = ResolversParentTypes['DummyNode']> = ResolversObject<{
  id: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PageInfoResolvers<ContextType = Context, ParentType extends ResolversParentTypes['PageInfo'] = ResolversParentTypes['PageInfo']> = ResolversObject<{
  hasNextPage: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  hasPreviousPage: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  startCursor: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  endCursor: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface DateTimeScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['DateTime'], any> {
  name: 'DateTime';
}

export type StockListResolvers<ContextType = Context, ParentType extends ResolversParentTypes['StockList'] = ResolversParentTypes['StockList']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  edges: Resolver<Maybe<Array<ResolversTypes['StockListEdge']>>, ParentType, ContextType>;
  totalCount: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StockListEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['StockListEdge'] = ResolversParentTypes['StockListEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['Stock'], ParentType, ContextType>;
  cursor: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StockResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Stock'] = ResolversParentTypes['Stock']> = ResolversObject<{
  id: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  productId: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  productCode: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  network: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  qty: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StockReceiveListResolvers<ContextType = Context, ParentType extends ResolversParentTypes['StockReceiveList'] = ResolversParentTypes['StockReceiveList']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  edges: Resolver<Maybe<Array<ResolversTypes['StockReceiveListEdge']>>, ParentType, ContextType>;
  totalCount: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StockReceiveListEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['StockReceiveListEdge'] = ResolversParentTypes['StockReceiveListEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['StockReceive'], ParentType, ContextType>;
  cursor: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StockReceiveResolvers<ContextType = Context, ParentType extends ResolversParentTypes['StockReceive'] = ResolversParentTypes['StockReceive']> = ResolversObject<{
  id: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  orderId: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  productId: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  productCode: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  network: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  qty: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  scannedQty: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SvcUpdateResolvers<ContextType = Context, ParentType extends ResolversParentTypes['SvcUpdate'] = ResolversParentTypes['SvcUpdate']> = ResolversObject<{
  sectors: Resolver<Array<Maybe<ResolversTypes['SvcBlockOutput']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SvcBlockOutputResolvers<ContextType = Context, ParentType extends ResolversParentTypes['SvcBlockOutput'] = ResolversParentTypes['SvcBlockOutput']> = ResolversObject<{
  sector_no: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  block0: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  block1: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  block2: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TransactionsConnectionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['TransactionsConnection'] = ResolversParentTypes['TransactionsConnection']> = ResolversObject<{
  totalAmount: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  edges: Resolver<Maybe<Array<ResolversTypes['TransactionEdge']>>, ParentType, ContextType>;
  pageInfo: Resolver<Maybe<ResolversTypes['PageInfo']>, ParentType, ContextType>;
  totalCount: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TransactionEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['TransactionEdge'] = ResolversParentTypes['TransactionEdge']> = ResolversObject<{
  node: Resolver<ResolversTypes['Transaction'], ParentType, ContextType>;
  cursor: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type TransactionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Transaction'] = ResolversParentTypes['Transaction']> = ResolversObject<{
  id: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  amount: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  name: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  description: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UserPerformanceResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UserPerformance'] = ResolversParentTypes['UserPerformance']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  totalActivations: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  ogrAmount: Resolver<Maybe<ResolversTypes['Float']>, ParentType, ContextType>;
  totalConnections: Resolver<ResolversTypes['Float'], ParentType, ContextType>;
  totalSales: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ValidateProductResultResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ValidateProductResult'] = ResolversParentTypes['ValidateProductResult']> = ResolversObject<{
  success: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  message: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  product: Resolver<Maybe<ResolversTypes['Product']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProductResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Product'] = ResolversParentTypes['Product']> = ResolversObject<{
  product_id: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  code: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  desc: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  qty: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type Resolvers<ContextType = Context> = ResolversObject<{
  AeonAuth: AeonAuthResolvers<ContextType>;
  AeonResult: AeonResultResolvers<ContextType>;
  DataBundlesResult: DataBundlesResultResolvers<ContextType>;
  BundlesEdge: BundlesEdgeResolvers<ContextType>;
  Bundle: BundleResolvers<ContextType>;
  DataBundlesNetworkResult: DataBundlesNetworkResultResolvers<ContextType>;
  BundleNetwork: BundleNetworkResolvers<ContextType>;
  NetworksResult: NetworksResultResolvers<ContextType>;
  NetworkEdge: NetworkEdgeResolvers<ContextType>;
  Network: NetworkResolvers<ContextType>;
  Response: ResponseResolvers<ContextType>;
  Account: AccountResolvers<ContextType>;
  AccountRegisterUserPayload: AccountRegisterUserPayloadResolvers<ContextType>;
  AccountRegisterConsumerPayload: AccountRegisterConsumerPayloadResolvers<ContextType>;
  Country: CountryResolvers<ContextType>;
  IdentityType: IdentityTypeResolvers<ContextType>;
  PaymentMethod: PaymentMethodResolvers<ContextType>;
  BankDetails: BankDetailsResolvers<ContextType>;
  BankDetailsEdge: BankDetailsEdgeResolvers<ContextType>;
  BankDetail: BankDetailResolvers<ContextType>;
  BusCarriersConnection: BusCarriersConnectionResolvers<ContextType>;
  BusCarriersEdge: BusCarriersEdgeResolvers<ContextType>;
  BusCarrierLocation: BusCarrierLocationResolvers<ContextType>;
  BusDestinationsConnection: BusDestinationsConnectionResolvers<ContextType>;
  BusDestinationsEdge: BusDestinationsEdgeResolvers<ContextType>;
  BusDestinationLocation: BusDestinationLocationResolvers<ContextType>;
  BusFaresConnection: BusFaresConnectionResolvers<ContextType>;
  BusFaresEdge: BusFaresEdgeResolvers<ContextType>;
  BusFare: BusFareResolvers<ContextType>;
  BusStopsConnection: BusStopsConnectionResolvers<ContextType>;
  BusStopsEdge: BusStopsEdgeResolvers<ContextType>;
  BusStopLocation: BusStopLocationResolvers<ContextType>;
  BusTicketsConnection: BusTicketsConnectionResolvers<ContextType>;
  BusTicketsEdge: BusTicketsEdgeResolvers<ContextType>;
  BusTicket: BusTicketResolvers<ContextType>;
  RouteRecursor: RouteRecursorResolvers<ContextType>;
  Query: QueryResolvers<ContextType>;
  Ticket: TicketResolvers<ContextType>;
  Card: CardResolvers<ContextType>;
  User: UserResolvers<ContextType>;
  CommissionsConnection: CommissionsConnectionResolvers<ContextType>;
  CommissionEdge: CommissionEdgeResolvers<ContextType>;
  Commission: CommissionResolvers<ContextType>;
  CustomerList: CustomerListResolvers<ContextType>;
  CustomerListEdge: CustomerListEdgeResolvers<ContextType>;
  Customer: CustomerResolvers<ContextType>;
  Banner: BannerResolvers<ContextType>;
  BannerEdge: BannerEdgeResolvers<ContextType>;
  BannersResult: BannersResultResolvers<ContextType>;
  AddNetworkContractResult: AddNetworkContractResultResolvers<ContextType>;
  AddProductDealResult: AddProductDealResultResolvers<ContextType>;
  AirtimeTopupResult: AirtimeTopupResultResolvers<ContextType>;
  InternationalAirtimeTopupResult: InternationalAirtimeTopupResultResolvers<ContextType>;
  AllocateStockResult: AllocateStockResultResolvers<ContextType>;
  AuthResetPasswordPayload: AuthResetPasswordPayloadResolvers<ContextType>;
  AuthValidationPayload: AuthValidationPayloadResolvers<ContextType>;
  AuthValidationLegacyPayload: AuthValidationLegacyPayloadResolvers<ContextType>;
  BusTicketCancelPayload: BusTicketCancelPayloadResolvers<ContextType>;
  BusTicketConfirmCancelPayload: BusTicketConfirmCancelPayloadResolvers<ContextType>;
  BusTicketCheckoutPayload: BusTicketCheckoutPayloadResolvers<ContextType>;
  BusTicketConfirmPayload: BusTicketConfirmPayloadResolvers<ContextType>;
  ConfirmMeterResult: ConfirmMeterResultResolvers<ContextType>;
  ConfirmMeterDetail: ConfirmMeterDetailResolvers<ContextType>;
  CustomerOrderResult: CustomerOrderResultResolvers<ContextType>;
  DataTopupResult: DataTopupResultResolvers<ContextType>;
  ElectricityTopupResult: ElectricityTopupResultResolvers<ContextType>;
  ReceiveStockResult: ReceiveStockResultResolvers<ContextType>;
  RegisterConsumerResult: RegisterConsumerResultResolvers<ContextType>;
  RepTransferResult: RepTransferResultResolvers<ContextType>;
  RicaRegisterResult: RicaRegisterResultResolvers<ContextType>;
  UploadImageResult: UploadImageResultResolvers<ContextType>;
  VoucherRedemptionPayload: VoucherRedemptionPayloadResolvers<ContextType>;
  Mutation: MutationResolvers<ContextType>;
  ProductDealList: ProductDealListResolvers<ContextType>;
  ProductDealListEdge: ProductDealListEdgeResolvers<ContextType>;
  ProductDeal: ProductDealResolvers<ContextType>;
  ProductsByNetworkResult: ProductsByNetworkResultResolvers<ContextType>;
  ProductsByNetworkEdge: ProductsByNetworkEdgeResolvers<ContextType>;
  ProductByNetwork: ProductByNetworkResolvers<ContextType>;
  Profile: ProfileResolvers<ContextType>;
  Role: RoleResolvers<ContextType>;
  Node: NodeResolvers<ContextType>;
  DummyNode: DummyNodeResolvers<ContextType>;
  PageInfo: PageInfoResolvers<ContextType>;
  DateTime: GraphQLScalarType;
  StockList: StockListResolvers<ContextType>;
  StockListEdge: StockListEdgeResolvers<ContextType>;
  Stock: StockResolvers<ContextType>;
  StockReceiveList: StockReceiveListResolvers<ContextType>;
  StockReceiveListEdge: StockReceiveListEdgeResolvers<ContextType>;
  StockReceive: StockReceiveResolvers<ContextType>;
  SvcUpdate: SvcUpdateResolvers<ContextType>;
  SvcBlockOutput: SvcBlockOutputResolvers<ContextType>;
  TransactionsConnection: TransactionsConnectionResolvers<ContextType>;
  TransactionEdge: TransactionEdgeResolvers<ContextType>;
  Transaction: TransactionResolvers<ContextType>;
  UserPerformance: UserPerformanceResolvers<ContextType>;
  ValidateProductResult: ValidateProductResultResolvers<ContextType>;
  Product: ProductResolvers<ContextType>;
}>;


/**
 * @deprecated
 * Use "Resolvers" root object instead. If you wish to get "IResolvers", add "typesPrefix: I" to your config.
 */
export type IResolvers<ContextType = Context> = Resolvers<ContextType>;
export type DirectiveResolvers<ContextType = Context> = ResolversObject<{
  relayId: RelayIdDirectiveResolver<any, any, ContextType>;
}>;


/**
 * @deprecated
 * Use "DirectiveResolvers" root object instead. If you wish to get "IDirectiveResolvers", add "typesPrefix: I" to your config.
 */
export type IDirectiveResolvers<ContextType = Context> = DirectiveResolvers<ContextType>;