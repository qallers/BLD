import {RepApi} from '@stackworx/bluelabel-atlas';
import {MutationResolvers} from '../../../generated/graphql';
import {
  atlasAuthCheck,
  getDeliveryModeId,
  getPaymentModeId,
  getWarehouseId,
} from '../../auth/AtlasHelpers';
import config from '../../../config';
/*
mutation {
  allocateStock(input: {
    customerId: 8263,
    delivery: Delivery,
    stock: [
    {
      productId: 4,
      qty: 100,
      dealId: 8485,
      salePrice: 2
      barcode: [
        "1234567890",
      ]
    }]}) {
    success
    message
  }
}
*/

export const allocateStock: MutationResolvers['allocateStock'] = async function (
  _parent: any,
  {input: {stock, customerId, delivery}},
  context: any,
  _info: any
) {
  try {
    const headers = atlasAuthCheck(context);

    const warehouseId = await getWarehouseId(headers);

    const deliveryId = await getDeliveryModeId(headers, delivery);

    const paymentId = await getPaymentModeId(headers, 'Unpaid');

    const data = stock.map((order) => ({
      customerId: customerId.toString(),
      warehouseId: warehouseId.toString(),
      productId: order.productId.toString(),
      qty: order.qty.toString(),
      salesPrice: order.salePrice.toFixed(2),
      productDeal: order.dealId.toString(),
      splitDealId: '0',
      paymentStatusId: paymentId.toString(),
      deliveryMethodId: deliveryId.toString(),
      barcode: order.barcode,
    }));

    const repApi = new RepApi(config.get('atlasAddress'));
    const allocateResult = await repApi
      .createMobileInvoiceOrderBulkAllocation(data, headers)
      .then((res) => res.body);

    const success = allocateResult.success;
    return {success, message: 'Success'};
  } catch (ex) {
    console.log(ex);
    return {success: false, message: ex.message};
  }
};
