import {OrderApi, UserApi} from '@stackworx/bluelabel-atlas';
import {BaseContext} from '../../Context';
import config from '../../config';

interface AtlasMode {
  id: number;
  name: string;
  status: string;
  process: string;
  is_active: number;
  created_at: string;
  updated_at: string;
}

function atlasAuthCheck(info: BaseContext) {
  // @ts-ignore
  const auth: string | undefined =
    info &&
    info.req && //info.req.headers.authorization ||
    info.req.headers.atlasauth;

  if (!auth) {
    throw Error('No auth token provided for Atlas call');
  }
  return {headers: {authorization: auth}};
}

async function getWarehouseId(headers: any) {
  const userApi = new UserApi(config.get('atlasAddress'));
  return await userApi
    .getProfile(headers)
    .then((res) => res.body.data.warehouse_id)
    .catch((_err) => {
      throw Error('Unable to get warehouse');
    });
}

async function getDeliveryModeId(headers: any, delivery: string) {
  const orderApi = new OrderApi(config.get('atlasAddress'));
  return await orderApi
    .getdeliveryModes(headers)
    .then((res) => res.body.data.find((d: AtlasMode) => d.name === delivery).id)
    .catch((_err) => {
      throw Error('Unable to get delivery mode');
    });
}

async function getPaymentModeId(headers: any, payment: string) {
  const orderApi = new OrderApi(config.get('atlasAddress'));
  return await orderApi
    .getpaymentModes(headers)
    .then((res) => res.body.data.find((p: AtlasMode) => p.name === payment).id)
    .catch((_err) => {
      throw Error('Unable to get payment mode');
    });
}

export {atlasAuthCheck, getWarehouseId, getDeliveryModeId, getPaymentModeId};
