import {OrderApi} from '@stackworx/bluelabel-atlas';
import config from '../../../config';
import {MutationResolvers} from '../../../generated/graphql';
import {
  atlasAuthCheck,
  getDeliveryModeId,
  getPaymentModeId,
  getWarehouseId,
} from '../../auth/AtlasHelpers';
/*
mutation {
  repTransfer(input: { transfer :[
    {
      productId: "8"
      qty: "1"
    }
  ]}) {
    success
    message
  }
}
*/

export const customerOrder: MutationResolvers['customerOrder'] = async function (
  _parent: any,
  {input: {order, customerId, delivery}},
  context: any,
  _info: any
) {
  try {
    const headers = atlasAuthCheck(context);

    const warehouseId = await getWarehouseId(headers);

    const deliveryId = await getDeliveryModeId(headers, delivery);

    const paymentId = await getPaymentModeId(headers, 'Unpaid');

    const data = order.map((order) => ({
      customerId: customerId.toString(),
      warehouseId: warehouseId.toString(),
      productId: order.productId.toString(),
      qty: order.qty.toString(),
      salesPrice: order.salePrice.toFixed(2),
      productDeal: order.dealId.toString(),
      splitDealId: '0',
      paymentStatusId: paymentId.toString(),
      deliveryMethodId: deliveryId.toString(),
    }));

    const orderApi = new OrderApi(config.get('atlasAddress'));
    const orderResult = await orderApi
      .createSalesOrder(data, headers)
      .then((res) => res.body);

    const success = orderResult.success;
    return {success, message: 'Success'};
  } catch (ex) {
    console.log(ex);
    return {success: false, message: ex.message};
  }
};
