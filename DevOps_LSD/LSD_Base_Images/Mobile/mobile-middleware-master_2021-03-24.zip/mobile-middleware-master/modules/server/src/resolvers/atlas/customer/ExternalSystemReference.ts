import {CustomersApi} from '@stackworx/bluelabel-atlas';
import config from '../../../config';

export async function getExternalSystemReference(headers: any, id: number) {
  const customerApi = new CustomersApi(config.get('atlasAddress'));
  return await customerApi
    .getExternalSystemReference(id.toString(), headers)
    .then((res) => res.body.data)
    .catch((_err) => {
      throw Error('Unable to get reference');
    });
}

export async function saveExternalSystemReference(
  headers: any,
  id: number,
  customerId: number,
  ref: string,
  data: string
) {
  const customerApi = new CustomersApi(config.get('atlasAddress'));
  return await customerApi
    .registerExternalSystemReference(
      id.toString(),
      customerId.toString(),
      ref,
      data,
      headers
    )
    .then((res) => res.body.data)
    .catch((_err) => {
      console.log({_err});
      throw Error('Unable to save reference');
    });
}
