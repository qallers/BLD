import got from 'got';
import config from '../../config';

interface DigitalOnboardingAddress {
  AddressLine1: string;
  AddressLine2: string;
  AddressLine3: string;
  AddressCode: string;
  Latitude: number;
  Longitude: number;
}

interface DigitalOnboardingCustomer {
  Firstname: string;
  Lastname: string;
  MobileNo: string;
  IdentityNo: string;
  Email: string;
  PostalAddress: DigitalOnboardingAddress;
  PhysicalAddress: DigitalOnboardingAddress;
}

const createCustomer = async (
  applicationId: number,
  customer: DigitalOnboardingCustomer
) => {
  try {
    // console.log(JSON.stringify(customer));
    const uri = `${config.get(
      'mendixAddress'
    )}/digitalonboarding/v1/registration/customer`;
    const output = await got.post(uri, {
      headers: {
        Authorization: 'Basic VDNUQXBwOlF3ZXJAMTIzNA==',
        ApplicationId: applicationId.toString(),
      },
      json: customer,
      responseType: 'json',
    });
    // console.log(output.body);

    if (!output.body) {
      return false;
    }
    return output.body;
  } catch (ex) {
    console.log(ex.message);
    return false;
  }
};

export {createCustomer, DigitalOnboardingCustomer, DigitalOnboardingAddress};
