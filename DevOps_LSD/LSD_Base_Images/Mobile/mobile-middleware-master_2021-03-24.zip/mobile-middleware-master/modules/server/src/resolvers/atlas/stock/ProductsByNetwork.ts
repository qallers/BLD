import {OrderApi} from '@stackworx/bluelabel-atlas';
import {isIterable} from '../../../util';
import {QueryResolvers} from '../../../generated/graphql';
import config from '../../../config';
import {atlasAuthCheck} from '../../auth/AtlasHelpers';
import {AtlasNetworkIdMap} from '../../network/NetworkDefinitions';

/*
query {
  productsByNetwork(input: {network: CellC}) {
    success,
    message,
    totalCount,
    edges {
      cursor
      node {
        id
        description
        productCode
        productId
        costPrice
        salePrice
        actExpenseCode
        ogrExpenseCode
        simExpenseCode
      }
    }
  }
}
 */

const createEdge = (product: any, index: number) => {
  return {
    cursor: Buffer.from('ProductByNetwork:' + index).toString('base64'),
    node: {
      id: Buffer.from('ProductByNetwork:' + index).toString('base64'),
      description: product.description,
      productCode: product.product_code,
      productId: product.id,
      costPrice: product.cost_price,
      salePrice: product.sale_price,
      actExpenseCode: product.act_expense_code,
      ogrExpenseCode: product.ogr_expense_code,
      simExpenseCode: product.sim_expense_code,
    },
  };
};

const parseProducts = (data: any) => {
  const products: any[] = [];
  let index = 1;

  if (isIterable(data)) {
    for (const product of data) {
      products.push(createEdge(product, index++));
    }
  } else {
    products.push(createEdge(data, index++));
  }
  return products;
};

const getProducts = async function (context: any, networkId: number) {
  try {
    const headers = atlasAuthCheck(context);
    const api = new OrderApi(config.get('atlasAddress'));
    return await api
      .getProductsByNetwork(networkId.toString(), headers)
      .then((res) => res.body.data);
  } catch (ex) {
    console.log(ex);
    return false;
  }
};

export const productsByNetwork: QueryResolvers['productsByNetwork'] = async function (
  _parent: any,
  {input: {network}},
  context: any,
  _info: any
) {
  let products: any = [];
  try {
    const networkId = AtlasNetworkIdMap[network];

    const productData = await getProducts(context, networkId);
    if (!productData) {
      return {
        success: false,
        message: 'Auth Failed',
        edges: null,
        totalCount: 0,
      };
    }
    products = parseProducts(productData);

    return {
      success: true,
      message: 'Success',
      edges: products,
      totalCount: products.length,
    };
  } catch (e) {
    return {success: false, message: e.message, edges: null, totalCount: 0};
  }
};
