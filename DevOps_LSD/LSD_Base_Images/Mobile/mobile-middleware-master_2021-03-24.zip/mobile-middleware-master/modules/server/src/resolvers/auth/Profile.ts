import {UserApi} from '@stackworx/bluelabel-atlas';
import {QueryResolvers} from '../../generated/graphql';
import config from '../../config';
import {atlasAuthCheck} from './AtlasHelpers';

interface Role {
  id: string;
  description: string;
  slug: string;
}

// @ts-ignore
export const profile: QueryResolvers['profile'] = async function (
  _parent,
  _context,
  info
) {
  try {
    const headers = atlasAuthCheck(info);
    const api = new UserApi(config.get('atlasAddress'));
    const profileResult = await api
      .getProfile(headers)
      .then((res) => res.body.data);
    const typesResult = await api
      .getTypes(headers)
      .then((res) => res.body.data);

    const {
      id: roleId,
      description: roleDescription,
      slug: roleSlug,
    } = typesResult.find((role: Role) => role.id == profileResult.user_type_id);

    return {
      id: profileResult.id,
      username: profileResult.username,
      firstName: profileResult.first_name,
      lastName: profileResult.last_name,
      email: profileResult.email,
      userType: {
        id: roleId,
        description: roleDescription,
        slug: roleSlug,
      },
    };
  } catch (ex) {
    console.log(ex);
    // on any errors, do not return profile
    return null;
  }
};
