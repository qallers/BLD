import {fromGlobalId} from 'graphql-relay';

import {MutationResolvers, QueryResolvers} from '../generated/graphql';
import {authValidation} from './auth/AuthValidation.mutation';
// Import for legacy authentication (mainly for legacy voucher redemption code)
import {authValidationLegacy} from './auth/AuthValidationLegacy.mutation';
import {authRegistrationUser} from './auth/AuthRegistrationUser.mutation';
import {authRegistrationConsumer} from './auth/AuthRegistrationConsumer.mutation';
import {authResetPassword} from './auth/AuthResetPassword.mutation';
import {voucherRedemption} from './VoucherRedemption.mutation';
import {countries} from './auth/Countries';
import {identityTypes} from './auth/identityTypes';
import {busTicketCheckout} from './aeon/bus/BusTicketCheckout';
import {busTicketConfirm} from './aeon/bus/BusTicketConfirm';
import {paymentMethods} from './auth/PaymentMethods';
import {profile} from './auth/Profile';
import {carriers} from './aeon/bus/Carriers';
import {airtimeTopup} from './aeon/vas/airtime/AirtimeTopup.mutation';
import {dataBundles} from './aeon/vas/data/DataBundles';
import {dataBundlesNetwork} from './aeon/vas/data/DataBundlesNetwork';
import {dataTopup} from './aeon/vas/data/DataTopup.mutation';
import {stops} from './aeon/bus/Stops';
import {confirmMeter} from './aeon/vas/electricity/ConfirmMeter.mutation';
import {electricityTopup} from './aeon/vas/electricity/ElectricityTopup.mutation';
import {networks} from './network/Networks';
import {tickets} from './aeon/bus/Tickets';
import {ricaRegister} from './rica/RicaRegister.mutation';
import {account} from './aeon/account/Account';
import {transactions} from './aeon/account/Transactions';
import {commissions} from './aeon/account/Commissions';
import {fetchBanners} from './mendix/FetchMendixBanners';
import {svcValidate} from './aeon/bus/SvcValidate';
import {destinations} from './aeon/bus/Destinations';
import {fares} from './aeon/bus/Fares';
import {bankDetails} from './aeon/account/BankDetails';
import {productsByNetwork} from './atlas/stock/ProductsByNetwork';
import {repTransfer} from './atlas/stock/RepTransfer.mutation';
import {customerList} from './atlas/customer/CustomerList';
import {productDeals} from './atlas/customer/ProductDeals';
import {addNetworkContract} from './atlas/customer/AddNetworkContract.mutation';
import {addProductDeal} from './atlas/customer/AddProductDeal.mutation';
import {customerOrder} from './atlas/stock/CustomerOrder.mutation';
import {allocateStock} from './atlas/stock/AllocateStock.mutation';
import {validateProduct} from './atlas/stock/ValidateProduct';
import {stockList} from './atlas/stock/StockList';
import {stockToReceive} from './atlas/stock/StockToReceive';
import {receiveStock} from './atlas/stock/ReceiveStock.mutation';
import {uploadSignature} from './registration/UploadSignature.mutation';
import {uploadSelfie} from './registration/UploadSelfie.mutation';
import {uploadId} from './registration/UploadId.mutation';
import {uploadProofOfResidence} from './registration/UploadProofOfResidence.mutation';
import {registerConsumer} from './registration/RegisterConsumer.mutation';
import {internationalAirtimeTopup} from './aeon/international-airtime/InternationalAirtimeTopup.mutation';
import {userPerformance} from './atlas/stock/UserPerformance';

//@ts-ignore
const Query: QueryResolvers = {
  /* eslint-disable-next-line @typescript-eslint/ban-ts-ignore */
  // @ts-ignore
  node(_parent, {id}, _context, _info) {
    const resolvedId = fromGlobalId(id);

    // TODO: lookup

    return {
      id: resolvedId.id,
      __resolveType: resolvedId.type,
    };
  },
  account,
  bankDetails,
  carriers,
  commissions,
  countries,
  customerList,
  dataBundles,
  dataBundlesNetwork,
  destinations,
  fares,
  fetchBanners,
  identityTypes,
  networks,
  paymentMethods,
  productDeals,
  productsByNetwork,
  profile,
  stockList,
  stockToReceive,
  stops,
  svcValidate,
  tickets,
  transactions,
  userPerformance,
  validateProduct,
};

//@ts-ignore
const Mutation: MutationResolvers = {
  addNetworkContract,
  addProductDeal,
  airtimeTopup,
  allocateStock,
  authValidation,
  authValidationLegacy,
  authResetPassword,
  authRegistrationUser,
  authRegistrationConsumer,
  busTicketCheckout,
  busTicketConfirm,
  confirmMeter,
  customerOrder,
  dataTopup,
  electricityTopup,
  internationalAirtimeTopup,
  receiveStock,
  registerConsumer,
  repTransfer,
  ricaRegister,
  uploadId,
  uploadProofOfResidence,
  uploadSelfie,
  uploadSignature,
  voucherRedemption,
};

export const resolvers = {
  Query,
  Mutation,
};
