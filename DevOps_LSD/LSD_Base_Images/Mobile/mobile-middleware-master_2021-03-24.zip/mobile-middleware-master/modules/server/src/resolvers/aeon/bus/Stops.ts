import {BusAccount, QueryResolvers} from '../../../generated/graphql';
import {aeonConnect} from '../AeonConnect';
import {isIterable} from '../../../util';

interface Input {
  input: {
    companyId: string;
    auth: BusAccount;
  };
}

interface Location {
  location_id: string;
  location_name: string;
}

export const stops: QueryResolvers['Stops'] = async function (
  _parent: any,
  {input}: Input,
  _context: any,
  _info: any
) {
  try {
    const {companyId, auth} = input;
    if (!auth) {
      return null;
    }
    const data = await aeonConnect(
      // @ts-ignore
      auth,
      'SmartTapEldo',
      'ListStops',
      {
        companyId: companyId,
      }
    );
    // @ts-ignore
    let rawData = data.response.response.ResponseMessage.locations.locations;
    if (!isIterable(rawData)) {
      rawData = [rawData];
    }
    // console.log({rawData})
    const output = rawData.map((location: Location) => {
      return {
        cursor: location.location_id,
        node: {
          id: location.location_id,
          name: location.location_name,
        },
      };
    });
    return {
      totalCount: output.length,
      edges: output,
    };
  } catch (e) {
    // console.log({e});
    return {
      totalCount: 0,
      edges: [],
    };
  }
};
