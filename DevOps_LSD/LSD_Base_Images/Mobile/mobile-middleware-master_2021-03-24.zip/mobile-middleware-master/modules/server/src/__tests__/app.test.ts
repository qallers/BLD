// eslint-disable-next-line @typescript-eslint/no-empty-function
test('test', () => {});
