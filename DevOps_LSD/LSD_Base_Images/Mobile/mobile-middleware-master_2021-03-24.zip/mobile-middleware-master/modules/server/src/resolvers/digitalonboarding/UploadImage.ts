import got from 'got';
import config from '../../config';
import {getApplicationStatus} from './GetApplicationStatus';

enum DigitalOnboardingImageType {
  Address = 'POR',
  IdBack = 'ID_BACK',
  IdFront = 'ID_Front',
  Selfie = 'Selfie',
  Outlet = 'Outlet',
}

interface DigitalOnboardingImage {
  _type: DigitalOnboardingImageType;
  Base64encoded_file: string;
  filename: string;
}

interface NameStatus {
  Name: string;
  Status: boolean;
}

const uploadImage = async (
  applicationId: number,
  image: DigitalOnboardingImage
) => {
  try {
    //check if image already exists on Digital Onboarding and if so, return successful
    const status = await getApplicationStatus(applicationId);
    const completed = status.find(
      (d: NameStatus) => d.Name === 'Image_' + image._type
    ).Status;
    if (completed) {
      // console.log('Image (' + image._type + ') already uploaded!!');
      return true;
    }

    const uri = `${config.get(
      'mendixAddress'
    )}/digitalonboarding/v1/registration/upload/image`;
    const output = await got.post(uri, {
      headers: {
        Authorization: 'Basic VDNUQXBwOlF3ZXJAMTIzNA==',
        ApplicationId: applicationId.toString(),
      },
      json: image,
      responseType: 'json',
    });
    // console.log(output.body);

    if (!output.body) {
      return false;
    }
    return true;
  } catch (ex) {
    console.log(ex.message);
    return false;
  }
};

export {uploadImage, DigitalOnboardingImage, DigitalOnboardingImageType};
