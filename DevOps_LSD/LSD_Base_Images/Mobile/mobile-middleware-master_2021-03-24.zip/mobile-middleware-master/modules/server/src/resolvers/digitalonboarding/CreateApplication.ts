import got from 'got';
import config from '../../config';

const createApplication = async (templateId: number) => {
  try {
    const uri = `${config.get(
      'mendixAddress'
    )}/digitalonboarding/v1/registration/application`;
    const output = await got.post(uri, {
      headers: {
        Authorization: 'Basic VDNUQXBwOlF3ZXJAMTIzNA==',
        TemplateID: templateId.toString(),
      },
    });

    if (!JSON.parse(output.body)) {
      return false;
    }
    return JSON.parse(output.body).ApplicationID;
  } catch (ex) {
    console.log(ex);
    return false;
  }
};

export {createApplication};
