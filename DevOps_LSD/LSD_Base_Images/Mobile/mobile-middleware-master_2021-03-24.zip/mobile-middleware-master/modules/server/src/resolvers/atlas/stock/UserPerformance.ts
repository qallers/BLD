import {ReportsApi} from '@stackworx/bluelabel-atlas';
import {QueryResolvers} from '../../../generated/graphql';
import config from '../../../config';
import {atlasAuthCheck} from '../../auth/AtlasHelpers';
import {AtlasNetworkIdMap} from '../../network/NetworkDefinitions';

/*
query {
 userPerformance (input: {network: Vodacom, customerId: 9155, date: "2021-02-15"}) {
  ogrAmount
  totalActivations
  totalConnections
  totalSales
}
}
 */

const getPerformances = async function (
  context: any,
  networkId: number,
  customerId: number,
  date: string
) {
  try {
    const headers = atlasAuthCheck(context);
    const api = new ReportsApi(config.get('atlasAddress'));
    return await api
      .userPerfomance(customerId, networkId, date, headers)
      .then((res) => res.body.data);
  } catch (ex) {
    console.log(ex);
    return false;
  }
};

interface Input {
  input: {
    network: 'MTN' | 'Vodacom' | 'CellC' | 'IPay';
    customerId: string;
    date: string;
  };
}

//@ts-ignore
export const userPerformance: QueryResolvers['userPerformance'] = async function (
  _parent: any,
  {input: {network, customerId, date}}: Input,
  context: any,
  _info: any
) {
  try {
    //@ts-ignore
    const networkId = AtlasNetworkIdMap[network];

    const userPerformance = await getPerformances(
      context,
      //@ts-ignore
      networkId,
      //@ts-ignore
      customerId,
      date
    );

    if (!userPerformance) {
      return {
        success: false,
        message: 'Auth Failed',
        totalActivations: 0,
        ogrAmount: 0,
        totalConnections: 0,
        totalSales: 0,
      };
    }

    return {
      success: true,
      message: 'Success',
      totalActivations: userPerformance.act[0].total_activations,
      ogrAmount: userPerformance.ogr[0].ogr_amount,
      totalConnections: userPerformance.conn[0].total_connections,
      totalSales: userPerformance.sales[0].total_sales,
    };
  } catch (e) {
    return {
      success: false,
      message: 'Auth Failed',
      totalActivations: 0,
      ogrAmount: 0,
      totalConnections: 0,
      totalSales: 0,
    };
  }
};
