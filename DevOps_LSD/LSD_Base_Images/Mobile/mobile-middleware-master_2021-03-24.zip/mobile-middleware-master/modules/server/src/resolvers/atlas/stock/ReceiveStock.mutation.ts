import {RepApi} from '@stackworx/bluelabel-atlas';
import config from '../../../config';
import {MutationResolvers} from '../../../generated/graphql';
import {atlasAuthCheck} from '../../auth/AtlasHelpers';
/*
mutation {
  receiveStock(input:
    {
      productId: 1
      barcode: "1606811787"
      orderId: 172
    }
  ) {
    success
    message
    qty
    scannedQty
  }
}
*/

export const receiveStock: MutationResolvers['receiveStock'] = async function (
  _parent: any,
  {input: {productId, barcode, orderId}},
  context: any,
  _info: any
) {
  try {
    const headers = atlasAuthCheck(context);
    const api = new RepApi(config.get('atlasAddress'));
    const receiveResult = await api
      .scanStockRep(productId.toString(), barcode, orderId.toString(), headers)
      .then((res) => res.body);

    const success = receiveResult.success;
    const qty = parseInt(receiveResult.data.qty);
    const scannedQty = parseInt(receiveResult.data.scanned_qty);
    return {success, message: 'Success', qty, scannedQty};
  } catch (ex) {
    console.log(ex);
    return {success: false, message: ex.message, qty: null, scannedQty: null};
  }
};
