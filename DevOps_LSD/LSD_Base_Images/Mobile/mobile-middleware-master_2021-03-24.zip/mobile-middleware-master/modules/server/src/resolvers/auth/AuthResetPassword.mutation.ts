import {LoginApi} from '@stackworx/bluelabel-atlas';
import {MutationResolvers} from '../../generated/graphql';

import config from '../../config';

interface CommsDataType {
  id: number;
  name: 'Mail Channel' | 'SMS Channel';
  status: 'mail_channel' | 'sms_channel';
  process: 'password_reset_channel';
  is_active: 0 | 1;
  created_at: string;
  updated_at: string;
}

const api = new LoginApi(config.get('atlasAddress'));

// helper function to facilitate getting the comms channel
async function getCommsChannel(value: string, type: 'name' | 'status') {
  const commsListDataArrayResult: CommsDataType[] = await api
    .getCommsChannels({headers: {}})
    .then((res) => res.body.data);

  if (!commsListDataArrayResult) {
    // todo log message didn't find atlas comms list
    return false;
  }

  // ES6 array iterator to find and isolate only the comm being searched for
  // @ts-ignore
  const commsChannel: number = commsListDataArrayResult.find((comm) => {
    return comm[type] === value;
  }).id;

  if (!commsChannel) {
    // todo log message couldn't find comms channel
    return false;
  }

  return commsChannel.toString();
}

async function resetViaEmail(username: string, clientMutationId: string) {
  const commsChannel = await getCommsChannel('mail_channel', 'status');

  // if unable to get the comms channel, don't progress
  if (!commsChannel) {
    return {success: false, clientMutationId};
  }

  const resetEmailResult = await api
    .forgotPassword(
      username, // username,
      commsChannel,
      {headers: {}}
    )
    .then((res) => {
      return res.body.status;
    });
  return {success: resetEmailResult, clientMutationId};
}
async function resetViaSMS(username: string, clientMutationId: string) {
  const commsChannel = await getCommsChannel('sms_channel', 'status');

  // if unable to get the comms channel, don't progress
  if (!commsChannel) {
    return {success: false, clientMutationId};
  }

  const resetSMSResult = await api
    .forgotPassword(
      username, // username,
      commsChannel,
      {headers: {}}
    )
    .then((res) => {
      return res.body.status;
    });
  return {success: resetSMSResult, clientMutationId};
}

export const authResetPassword: MutationResolvers['authResetPassword'] = async function (
  _parent,
  {input: {detail, method, clientMutationId}},
  _context,
  _info
) {
  try {
    switch (method) {
      case 'EMAIL': {
        const result = await resetViaEmail(detail, clientMutationId || '');
        return result;
      }
      case 'SMS': {
        const result = await resetViaSMS(detail, clientMutationId || '');
        return result;
      }
      default:
        return {success: false, clientMutationId: clientMutationId || ''};
    }
  } catch (ex) {
    console.log(ex);
    // on any errors, do not return profile
    return {success: false, clientMutationId: clientMutationId || ''};
  }
};
