import {aeonConnect} from '../AeonConnect';
import {
  BusAccount,
  SvcValidation,
  QueryResolvers,
  RouteRecursor,
} from '../../../generated/graphql';
import {isIterable} from '../../../util';

interface Input {
  svcValidation: SvcValidation;
  auth: BusAccount;
}

interface Ticket {
  company_id: string;
  ticket_id: string;
  ticket_no: string;
  ticket_type: string;
  routes: RouteRecursor;
  fare: string;
  fare_product_id: string;
  departure_location_id: string;
  destination_location_id: string;
  activation_date: string;
  expiry_date: string;
  ticket_date: string;
  no_of_days_trips: string;
  no_of_transfers: string;
  status: string;
  rules: string;
  fare_currency: string;
}

export const tickets: QueryResolvers['Tickets'] = async function (
  _parent: any,
  {svcValidation, auth}: Input,
  _context: any,
  _info: any
) {
  try {
    if (!auth) {
      return null;
    }
    const sectors = svcValidation.svcData;
    const input = {
      uid: svcValidation?.uid || '',
      // ticketId: svcValidation?.ticketId || '',
      svc_data: sectors,
    };
    const data = await aeonConnect(
      // @ts-ignore
      auth,
      'SmartTapEldo',
      'ValidateSVCData',
      {
        ...input,
      }
    );
    // @ts-ignore
    let rawData = data.response.response.ResponseMessage.tickets.tickets;
    // @ts-ignore
    if (!isIterable(rawData)) {
      rawData = [rawData];
    }
    // console.log({rawData: JSON.stringify(rawData)});
    const output = rawData.map((ticket: Ticket) => {
      // console.log({ticket});
      return {
        cursor: ticket.ticket_id,
        node: {
          companyId: ticket.company_id,
          ticketId: ticket.ticket_id,
          ticketNo: ticket.ticket_no,
          ticketType: ticket.ticket_type,
          routes: {
            routes: ticket.routes.routes,
          },
          fare: ticket.fare,
          fareProductId: ticket.fare_product_id,
          departureLocationId: ticket.departure_location_id,
          destinationLocationId: ticket.destination_location_id,
          activationDate: ticket.activation_date,
          expiryDate: ticket.expiry_date,
          ticketDate: ticket.ticket_date,
          numberOfDaysTrips: ticket.no_of_days_trips,
          numberOfTransfers: ticket.no_of_transfers,
          status: ticket.status,
          rules: ticket.rules,
          fareCurrency: ticket.fare_currency,
        },
      };
    });
    return {
      totalCount: output.length,
      edges: output,
    };
  } catch (e) {
    return {edges: []};
  }
};
