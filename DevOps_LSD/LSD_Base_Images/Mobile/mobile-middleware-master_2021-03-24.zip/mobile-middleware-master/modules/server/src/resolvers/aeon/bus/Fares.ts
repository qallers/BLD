import {
  QueryResolvers,
  BusAccount,
  RouteRecursor,
} from '../../../generated/graphql';
import {aeonConnect} from '../AeonConnect';
import {isIterable} from '../../../util';

interface Input {
  input: {
    companyId: string;
    departureLocationId: string;
    destinationLocationId: string;
    routeId: string;
    fareProductId: string;
    auth: BusAccount;
  };
}

interface FareProduct {
  period: string;
  routes: RouteRecursor;
  fare_product_id: string;
  code: string;
  company_id: string;
  weekdays: string;
  created: string;
  available_to: string;
  no_of_transfers: string;
  available_from: string;
  pass_value: string;
  trips_per_day: string;
  pass_type: string;
  price: string;
  name: string;
  short_name: string;
  desc: string;
}

export const fares: QueryResolvers['Fares'] = async function (
  _parent: any,
  {
    input: {
      companyId,
      departureLocationId,
      destinationLocationId,
      routeId,
      fareProductId,
      auth,
    },
  }: Input,
  _context: any,
  _info: any
) {
  try {
    if (!auth) {
      return null;
    }
    const input = {
      // universal formatter, not as unnecessary as it looks
      companyId: companyId,
      departureLocationId: departureLocationId || '',
      destinationLocationId: destinationLocationId || '',
      routeId: routeId || '',
      fareProductId: fareProductId || '',
    };
    const data = await aeonConnect(
      // @ts-ignore
      auth,
      'SmartTapEldo',
      'LookupFareProduct',
      {
        ...input,
      }
    );
    let rawData =
      // @ts-ignore
      data.response.response.ResponseMessage.fare_products.fare_products;
    if (!isIterable(rawData)) {
      rawData = [rawData];
    }
    const output = rawData.map((fareProduct: FareProduct) => {
      const price = parseFloat(fareProduct.price);
      return {
        cursor: fareProduct.code,
        node: {
          period: fareProduct.period,
          fareProductId: fareProduct.fare_product_id,
          code: fareProduct.code,
          routes: {
            routes: fareProduct.routes.routes,
          },
          companyId: fareProduct.company_id,
          weekdays: fareProduct.weekdays,
          created: fareProduct.created,
          availableTo: fareProduct.available_to,
          transferCount: fareProduct.no_of_transfers,
          availableFrom: fareProduct.available_from,
          passValue: fareProduct.pass_value,
          tripsPerDay: fareProduct.trips_per_day,
          passType: fareProduct.pass_type,
          price: price,
          name: fareProduct.name,
          shortName: fareProduct.short_name,
          // desc: fareProduct.desc,
        },
      };
    });

    return {
      totalCount: output.length,
      edges: output,
    };
  } catch (e) {
    // console.log({e});
    return {
      totalCount: 0,
      edges: [],
    };
  }
};
