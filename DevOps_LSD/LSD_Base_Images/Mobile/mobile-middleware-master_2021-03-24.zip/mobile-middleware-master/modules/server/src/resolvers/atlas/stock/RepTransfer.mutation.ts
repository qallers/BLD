import {RepApi} from '@stackworx/bluelabel-atlas';
import config from '../../../config';
import {MutationResolvers} from '../../../generated/graphql';
import {atlasAuthCheck} from '../../auth/AtlasHelpers';
/*
mutation {
  repTransfer(input: { transfer :[
    {
      productId: "8"
      qty: "1"
    }
  ]}) {
    success
    message
  }
}
*/

export const repTransfer: MutationResolvers['repTransfer'] = async function (
  _parent: any,
  {input: {transfer}},
  context: any,
  _info: any
) {
  try {
    const headers = atlasAuthCheck(context);
    const api = new RepApi(config.get('atlasAddress'));
    const repTransferResult = await api
      .createReptransfer(transfer, headers)
      .then((res) => res.body);

    const success = repTransferResult.success;
    return {success, message: 'Success'};
  } catch (ex) {
    console.log(ex);
    return {success: false, message: ex.message};
  }
};
