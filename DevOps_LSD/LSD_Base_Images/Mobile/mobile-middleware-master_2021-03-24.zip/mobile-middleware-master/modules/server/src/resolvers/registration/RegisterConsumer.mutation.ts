/*
mutation {
  registerConsumer(input: {
    username: "MichaelTest5"
    password: "654321"
    name: "Michael"
    lastName: "Test5"
    mobile: "0835649200"
    business: "MichaelTest4"
    email: "michaelk5@blts.co.za"
    id: "1234567890123"
    address: {
      line1: "45 Key West"
      line2: "Poets Avenue"
      line3: "Randhart"
      code: 1449
      city: "Alberton"
      province: "Gauteng"
      latitude: -26.2954
      longitude: 28.1171
    }
  }) {
    success
    message
    status
  }
}
*/
import crypto from 'crypto';
import {AddressApi, ConsumersApi, ContactApi} from '@stackworx/bluelabel-atlas';
import {AuthValidationInput, MutationResolvers} from '../../generated/graphql';
import {
  createCustomer,
  DigitalOnboardingAddress,
  DigitalOnboardingCustomer,
} from '../digitalonboarding/CreateCustomer';
import {createApplication} from '../digitalonboarding/CreateApplication';
import {getAccount} from '../digitalonboarding/GetAccount';
import config from '../../config';
import {authValidation} from '../auth/AuthValidation.mutation';
import {saveExternalSystemReference} from '../atlas/customer/ExternalSystemReference';

export const registerConsumer: MutationResolvers['registerConsumer'] = async function (
  parent: any,
  {
    input: {
      username,
      password,
      name,
      lastName,
      mobile,
      business,
      email,
      id,
      address,
    },
  },
  context: any,
  info: any
) {
  try {
    const doAddress: DigitalOnboardingAddress = {
      AddressLine1: address.line1,
      AddressLine2: address.line2 ? address.line2 : '',
      AddressLine3: address.line3 ? address.line3 : '',
      AddressCode: address.code.toString(),
      Latitude: address.latitude ? address.latitude : 0,
      Longitude: address.longitude ? address.longitude : 0,
    };

    const customer: DigitalOnboardingCustomer = {
      Firstname: name,
      Lastname: lastName,
      MobileNo: mobile,
      IdentityNo: id,
      Email: email,
      PostalAddress: doAddress,
      PhysicalAddress: doAddress,
    };
    const appId = await createApplication(1);
    // console.log({appId});
    if (!appId) {
      return {
        success: false,
        message: 'Unable to create application',
        status: 0,
        token: null,
      };
    }

    const customerResult = await createCustomer(appId, customer);
    // console.log({customerResult});
    if (!customerResult) {
      return {
        success: false,
        message: 'Unable to create customer',
        status: 0,
        token: null,
      };
    }

    const account = await getAccount(appId);
    // console.log({account});
    if (!account) {
      return {
        success: false,
        message: 'Unable to get account',
        status: 0,
        token: null,
      };
    }

    const identityType = '24'; //hardcoded since we do not have an authtoken against which to search for valid identityType Ids
    const paymentMethod = '47'; //hardcoded since we do not have an authtoken against which to search for valid payment methods

    const consumerApi = new ConsumersApi(config.get('atlasAddress'));
    let registerResult;
    try {
      registerResult = await consumerApi.consumerRegister(
        username,
        password,
        email,
        name,
        lastName,
        business,
        identityType,
        id,
        paymentMethod,
        '',
        ''
      );
    } catch (ex) {
      let message = '';
      if (ex.body.error.data.username) {
        message = ex.body.error.data.username[0] + ' ';
      }
      if (ex.body.error.data.email) {
        message += ex.body.error.data.email[0];
      }
      if (message.length == 0) {
        message = ex.message;
      }
      return {success: false, message: message, status: 0, token: null};
    }
    // console.log({registerResult});

    const consumerId = registerResult.body.data.id;
    // console.log({consumerId});

    const auth: AuthValidationInput = {
      username: username,
      password: password,
      clientMutationId: null,
      currentStatus: 1,
    };
    const atlasAuth = await authValidation(
      parent,
      {input: auth},
      context,
      info
    );
    // console.log({atlasAuth});
    if (!atlasAuth || !atlasAuth.authorized) {
      return {
        success: false,
        message: 'Authentication error occurred',
        status: 0,
        token: null,
      };
    }

    const headers = {headers: {authorization: 'Bearer ' + atlasAuth.token}};
    // console.log({headers});

    const serial = crypto.randomBytes(10).toString('hex');
    // console.log({serial});
    const aeonDetail = {
      devices: {
        device: [
          {
            type: 'Primary',
            serial_no: serial,
          },
          {
            type: 'Secondary',
            serial_no: serial,
          },
        ],
      },
      device_id: account.DeviceID,
      byd_acc_no: account.AccountID,
    };
    const aeonDetailUploadResult = await saveExternalSystemReference(
      headers,
      1,
      consumerId,
      account.AccountID,
      JSON.stringify(aeonDetail)
    );
    // console.log({aeonDetailUploadResult});
    if (!aeonDetailUploadResult) {
      return {
        success: false,
        message: 'Unable to save Account details',
        status: 0,
        token: null,
      };
    }

    const physicalAddress = 21;
    const addr2 =
      (address.line2 ? address.line2 : '') +
      (address.line3 ? ', ' + address.line3 : '');
    const location = address.latitude + ',' + address.longitude;
    const addressApi = new AddressApi(config.get('atlasAddress'));
    const addressResult = await addressApi.addAddress(
      consumerId,
      'Customer',
      physicalAddress,
      location,
      address.line1,
      address.code.toString(),
      addr2,
      address.city,
      address.province,
      headers
    );
    if (!addressResult) {
      //do not return an error, do not block the register process
      console.log('Error adding address on Atlas');
    }
    // console.log({addressResult});

    const contactApi = new ContactApi(config.get('atlasAddress'));
    const contactResult = await contactApi.agentContact(
      consumerId,
      'Customer',
      name,
      email,
      mobile,
      '',
      '',
      headers
    );
    if (!contactResult) {
      //do not return an error, do not block the register process
      console.log('Error adding contact on Atlas');
    }
    // console.log({contactResult});

    const regData = {
      status: 1,
    };
    const registerStatusSaved = await saveExternalSystemReference(
      headers,
      4,
      consumerId,
      appId,
      JSON.stringify(regData)
    );
    // console.log({registerStatusSaved});
    if (!registerStatusSaved) {
      return {
        success: false,
        message: 'Unable to save registration status',
        status: 0,
        token: null,
      };
    }

    return {
      success: true,
      message: 'Success',
      status: 1,
      token: atlasAuth.token,
    };
  } catch (ex) {
    console.log(ex);
    return {success: false, message: ex.message, status: 0, token: null};
  }
};
