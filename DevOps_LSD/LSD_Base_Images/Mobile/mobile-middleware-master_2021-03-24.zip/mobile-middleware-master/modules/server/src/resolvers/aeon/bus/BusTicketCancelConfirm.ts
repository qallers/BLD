import {aeonConnect} from '../AeonConnect';
import {BusAccount, MutationResolvers} from '../../../generated/graphql';

interface BusTicketCancelInput {
  uid: string;
  transref: string;
  svcData: [object];
  status: string;
  ticketId: string;
  transactionId: string;
  auth: BusAccount;
}

interface Input {
  input: BusTicketCancelInput;
}

// const testData = {
//   deviceId: 29851,
//   serialNum: 'P130189801394',
//   userPin: '011234',
//   location: '',
//   swVer: 'bluShift',
// };

export const busTicketCancel: MutationResolvers['BusTicketCancelConfirm'] = async function (
  _parent: any,
  {
    input: {uid, transref, svcData, status, ticketId, transactionId, auth},
  }: Input,
  _context: any,
  _info: any
) {
  let data: any = {};
  try {
    const event = {
      uid: uid,
      transref: transref,
      svcData: svcData,
      status: status,
      ticketId: ticketId,
      transactionId: transactionId,
      auth: auth,
    };

    //Amount too low error
    // const event = {
    //   AirtimePlus: 0,
    //   Amount: -10,
    //   PhoneNumber: '0736549000',
    //   Print: 0,
    //   Reference: '29853_1600843228610',
    //   SupplierName: 'supplier',
    // };

    //Invalid phone number
    // const event = {
    //   AirtimePlus: 0,
    //   Amount: 10,
    //   PhoneNumber: '0821231234',
    //   Print: 0,
    //   Reference: '29853_1600843228610',
    //   SupplierName: 'supplier',
    // };

    if (!auth) {
      return {success: false, message: data.message};
    }
    // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
    // @ts-ignore
    data = await aeonConnect(auth, 'SmartTapEldo', 'CancelTicket', event);
    const output = data.response.response;
    const sectors = output.ResponseMessage.svc_data.svc_data;
    console.log({output});
    return {
      message: output.message,
      status: output.status,
      svcData: {sectors: sectors},
      ticket: output.ticket,
      transaction: output.transaction,
    };

    // return {success: true, message: data.message};
  } catch (e) {
    console.log({e});
    return {success: false, message: e.message};
  }
};
