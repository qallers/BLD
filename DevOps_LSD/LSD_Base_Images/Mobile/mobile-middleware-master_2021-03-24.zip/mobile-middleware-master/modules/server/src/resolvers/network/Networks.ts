import {QueryResolvers} from '../../generated/graphql';
import {
  NetworkCellC,
  NetworkMtn,
  NetworkNeotel,
  NetworkTelkomMobile,
  NetworkVodacom,
} from './NetworkDefinitions';

/*
query {
  networks (input: {type: "Data" or "Airtime"}) {
    success
    message
    edges {
      node {
        id
        network
      }
      cursor
    }
    totalCount
  }
}
 */

const createNetwork = (network: any, index: number) => {
  return {
    cursor: Buffer.from('Network:' + index).toString('base64'),
    node: {
      id: Buffer.from('Network:' + index).toString('base64'),
      network: network.name,
      colour: network.colour,
      logo: network.logo,
    },
  };
};

export const networks: QueryResolvers['networks'] = function (
  _parent: any,
  {input: {type}},
  _context: any,
  _info: any
) {
  const networks: any = [];
  let index = 1;

  networks.push(createNetwork(NetworkCellC, index++));
  networks.push(createNetwork(NetworkMtn, index++));
  if (type.toLowerCase() === 'airtime') {
    networks.push(createNetwork(NetworkNeotel, index++));
  }
  networks.push(createNetwork(NetworkTelkomMobile, index++));
  networks.push(createNetwork(NetworkVodacom, index++));

  return {
    success: true,
    message: 'Success',
    edges: networks,
    totalCount: networks.length,
  };
};
