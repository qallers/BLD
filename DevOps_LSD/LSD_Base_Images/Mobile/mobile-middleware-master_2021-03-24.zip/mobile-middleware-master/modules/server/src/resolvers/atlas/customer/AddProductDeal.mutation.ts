import {OrderApi} from '@stackworx/bluelabel-atlas';
import config from '../../../config';
import {MutationResolvers} from '../../../generated/graphql';
import {atlasAuthCheck} from '../../auth/AtlasHelpers';
/*
mutation {
  addProductDeal(input: {productId: 4, customerId:4000, name:"MPKTest", ogr:1, act:2, sim:3}) {
    success
    message
  }
}
*/

export const addProductDeal: MutationResolvers['addProductDeal'] = async function (
  _parent: any,
  {input: {productId, customerId, name, ogr, act, sim}},
  context: any,
  _info: any
) {
  try {
    const headers = atlasAuthCheck(context);
    const api = new OrderApi(config.get('atlasAddress'));
    const startDate = new Date().toISOString().split('T')[0];

    const dealResult = await api
      .changeCustomerDeal(
        productId.toString(),
        customerId.toString(),
        name,
        startDate,
        '2099-12-31',
        ogr.toFixed(2),
        act.toFixed(2),
        sim.toFixed(2),
        headers
      )
      .then((res) => res.body);

    const success = dealResult.success;
    return {success, message: 'Success'};
  } catch (ex) {
    console.log(ex);
    return {success: false, message: ex.message};
  }
};
