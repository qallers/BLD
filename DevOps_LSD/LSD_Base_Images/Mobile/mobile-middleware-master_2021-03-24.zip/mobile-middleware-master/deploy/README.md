# Read Me

Bluelabel Internal environment setup

## visudo
admciaranl ALL=(ALL) NOPASSWD: /opt/deploy/image-load.sh
admciaranl ALL=(ALL) NOPASSWD: /opt/deploy/deploy.sh