Installing Git
==============
Git can be downloaded and installed from https://git-scm.com/downloads

Once installed, setup the following global settings with your own name and email address:
git config --global user.name "Michael Kuijken"
git config --global user.email "michaelk@blts.co.za"

Cloning the BluDroid repo
=========================
On the command line, navigate to the folder where you want BluDroid source to be pulled to.
Enter the following command:

git clone https://gitlab.blts.co.za/michaelsplayground/BLTAndroidGUI3.git

You will likely be asked to enter your AD credentials, and then the git repository will be cloned to
your local machine.

The project can then be opened in Android Studio.  You will notice in the bottom right corner of
Android Studio that you are currently on the master branch.

We will no longer all be working on trunk (or master as it's called on git).  We will create branches
for each CR, Project or Prod Defect as created on Jira.  Once the work on this issue is completed,
and committed back to the branch, a Merge Request can be created so that the branch can be merged
into the master branch.

Creating a branch
=================
Navigate to https://gitlab.blts.co.za/michaelsplayground/BLTAndroidGUI3 and click on Branches.  Click
on the green "New branch" button.  Enter a branch name (no spaces allowed), and click "Create branch".

Once the branch is created, you will need to change to this branch in Android Studio.  Select the VCS
menu item -> Git -> Fetch.  This will refresh the branches and tags from the repository. At the
bottom right of Android Studio, click on Git: master. Select the remote branch that you wish to work
on, and click "Checkout as".  There is no need to change the branch name, so just click "OK" to create
the branch on your local machine.

Committing to branch
====================
Click VCS -> Commit.  Enter a commit message describing your changes. Click the drop down arrow next
to the Commit button, and select "Commit and Push", and then click "Push" on the next dialog.
If you just clicked on Commit, the commit is only stored locally, and must by pushed to the remote
repository manually (VCS -> Git -> Push).

Updating a local branch
=======================
It is possible that multiple developers are working on, and committing to, the same branch.
Click VCS -> Git -> Pull to update your local copy of the branch that is currently selected.

Merging master into your branch
===============================
Your branch will have been created off the master branch, but the master branch may have changed by
the time your branch is ready to be merged.  It is therefore imperative that your branch is updated
with any changes made to the master branch.  To do this, select VCS -> Git -> Pull.  In the dialog
box, make sure that under the "Branches to Merge" both your branch and origin/master are selected
and press the "Pull" button.  Any conflicts from this merge will then have to be resolved, before
committing this update back to your branch.

Creating a Merge Request
========================
A Merge Request must be logged before a branch can be merged into the master branch.  The master
branch is protected, and you cannot commit to master directly.  Navigate to
https://gitlab.blts.co.za/michaelsplayground/BLTAndroidGUI3
again, and select Branches.  Next to your branch, click on the Merge Request button.  In the
description, please provide a comment, and url to the associated Jira task. Set Michael Kuijken
as the Assignee, then Submit Merge Request.

Merging to master
=================
Your Merge Requests will be processed by a user with Master privileges.  If any issues exist, the
Merge Request will be denied, and returned to you with comments.  You will have to make the necessary
changes, and then start the Merge Request process again.

If the Merge Request is accepted, your branch will be merged into master.  Your branch will then
become obsolete and will therefore get deleted from the online repo.

Whenever you perform a Git -> Fetch, Android Studio will reflect the updates to the remote
repositories.  However, all your local branches will remain on your machine until you remove them
manually.

To delete a local branch, click on the branch name on the bottom right of Android Studio, select the
local branch you want to remove, and click Delete.  Please ensure that you delete branches once they
have been successfully merged, and that you are VERY CAREFUL TO DELETE THE CORRECT LOCAL BRANCH ONLY!
