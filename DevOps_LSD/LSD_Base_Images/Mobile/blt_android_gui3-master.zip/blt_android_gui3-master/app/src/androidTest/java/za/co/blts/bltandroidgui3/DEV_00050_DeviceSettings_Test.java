package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BP_LIMIT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASHIER_END_SHIFT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_ENABLE_USER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_PREVIEWS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_SALES_RECEIPT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_STORE_ADDRESS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_STORE_NAME;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_BASKET;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VAT_REG_NO;
/**
 * Created by NkosanaM on 2/21/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00050_DeviceSettings_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
        restoreAllDeviceSettings();
    }

    @After
    public void after() {
        restoreAllDeviceSettings();
        tearDown();
    }

    @Test
    public void T001_LeaveWithoutSaving() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.gotoUserSettings();
            Log.d(TAG, "Go to user settings screen");

            checks.clickOnToobarNavigationButton();

            if (solo.waitForActivity(ActivityMain.class)) {
                Log.d(TAG, "Return to Main screen");
            } else {
                fail("Leave Did not return to Main screen");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_Receipts() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.gotoUserSettings();
            Log.d(TAG, "Go to Device Settings");

            checks.toggleDeviceSetup("receipts");
            Log.d(TAG, "Receipts Setting Section open");

            checks.toggleSwitch("merchantvouchers");
            Log.d(TAG, "Toggle Merchant vouchers Switch");

            checks.toggleSwitch("salesreceipt");
            Log.d(TAG, "Toggle Sales Receipt Switch");

            checks.toggleSwitch("previewreports");
            Log.d(TAG, "Toggle preview reports Switch");

            checks.save();
            Log.d(TAG, "Settings Saved");

            solo.sleep(1000);
            Log.d(TAG, "merchant voucher = " + checks.checkPreference(PREF_PRINT_MERCHANT_VOUCHER));

            if (checks.checkPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_PRINT_MERCHANT_VOUCHER updated");
            } else {
                fail("PREF_PRINT_MERCHANT_VOUCHER not updated");
            }
            if (checks.checkPreference(PREF_PRINT_SALES_RECEIPT).equals(PREF_FALSE)) {
                Log.d(TAG, "PREF_PRINT_SALES_RECEIPT");
            } else {
                fail("PREF_PRINT_SALES_RECEIPT not updated");
            }
            if (checks.checkPreference(PREF_PRINT_PREVIEWS).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_PRINT_PREVIEWS");
            } else {
                fail("PREF_PRINT_SALES_RECEIPT not updated");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T030_Device() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.gotoUserSettings();
            Log.d(TAG, "Go to Device Settings");

            checks.toggleDeviceSetup("device");
            Log.d(TAG, "Device Setting Section open");

            checks.toggleSwitch("cashierendshift");
            Log.d(TAG, "Toggle Cashier End Shift Switch");

            checks.toggleSwitch("calculator");
            Log.d(TAG, "Toggle  Calculator Switch");

            checks.checkDeviceTimeoutRadioGroup("180");
            checks.checkDeviceTimeoutRadioGroup("300");
            checks.checkDeviceTimeoutRadioGroup("600");
            checks.checkDeviceTimeoutRadioGroup("1800");
            checks.checkDeviceTimeoutRadioGroup("3600");
            Log.d(TAG, "Screen Timeout checked");

            checks.enterText(R.id.bpLimitSetting, "200.00");
            Log.d(TAG, "'BillPayment entered");

            checks.save();
            Log.d(TAG, "Settings Saved");

            solo.sleep(500);

            if (checks.checkPreference(PREF_CASHIER_END_SHIFT).equals("false")) {
                Log.d(TAG, "PREF_CASHIER_END_SHIFT updated");
            } else {
                fail("PREF_CASHIER_END_SHIFT not updated");
            }

            if (checks.checkPreference(PREF_USE_BASKET).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_USE_BASKET(CALCULATOR) updated");
            } else {
                fail("PREF_USE_BASKET(CALCULATOR) not updated");
            }

            /*if (checks.checkPreference(PREF_SCREEN_TIMEOUT).equals("150")) {
                Log.d(TAG, "PREF_SCREEN_TIMEOUT updated");
            } else {
                fail("PREF_SCREEN_TIMEOUT not updated");
            }*/

            if (checks.checkPreference(PREF_BP_LIMIT).equals("200.00")) {
                Log.d(TAG, "PREF_BP_LIMIT updated");
            } else {
                fail("PREF_BP_LIMIT not updated");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T040_StoreInfo() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.gotoUserSettings();
            Log.d(TAG, "Go to Device Settings");

            checks.toggleDeviceSetup("store");
            Log.d(TAG, "Store setting section open");

            checks.enterText(R.id.storeNameSetting, "Shop101");
            Log.d(TAG, "Store name changed");

            checks.enterText(R.id.addressSetting, "123 Khayalami Street");
            Log.d(TAG, "Store Address Entered");

            checks.enterText(R.id.vatRegNoSetting, "012345678945");
            Log.d(TAG, "Vat registration number entered");

            checks.save();
            Log.d(TAG, "Settings Saved");

            solo.sleep(1000);

            if (checks.checkPreference(PREF_STORE_NAME).equals("Shop101")) {
                Log.d(TAG, "PREF_STORE_NAME updated");
            } else {
                fail("PREF_STORE_NAME not updated");
            }

            if (checks.checkPreference(PREF_STORE_ADDRESS).equals("123 Khayalami Street")) {
                Log.d(TAG, "PREF_STORE_ADDRESS updated");
            } else {
                fail("PREF_STORE_ADDRESS not updated");
            }

            if (checks.checkPreference(PREF_VAT_REG_NO).equals("012345678945")) {
                Log.d(TAG, "PREF_VAT_REG_NO updated");
            } else {
                fail("PREF_VAT_REG_NO not updated");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T050_Loyalty() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.gotoUserSettings();
            Log.d(TAG, "Go to Device Settings");

            checks.toggleDeviceSetup("loyalty");
            Log.d(TAG, "Loyalty Setting Section open");

            checks.toggleSwitch("loyaltyenabled");
            Log.d(TAG, "Toggle  Loyalty Enabled Switch");

            checks.save();
            Log.d(TAG, "Settings Saved");

            solo.sleep(1000);

            if (checks.checkPreference(PREF_LOYALTY_ENABLE_USER).equals(PREF_TRUE)) {
                Log.d(TAG, "PREF_LOYALTY_ENABLE_USER");
            } else {
                fail("PREF_LOYALTY_ENABLE_USER not updated");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
