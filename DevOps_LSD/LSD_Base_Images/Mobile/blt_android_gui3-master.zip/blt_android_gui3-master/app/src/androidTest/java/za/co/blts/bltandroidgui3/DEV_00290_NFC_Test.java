package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SECURE_USB_PRINTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

/**
 * Created by BoitshokoM on 3/14/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00290_NFC_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
        setLoyaltyEnabledOn();
        setLoyaltySettingsOn();
    }

    @After
    public void after() {
        setLoyaltyEnabledOff();
        restoreLoyaltySettings();
        tearDown();
    }

    @Test
    public void T001_Registration() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.nfcRegistration();
            Log.d(TAG, "NFC New Subscriber menu option selected");

            checks.enterText(R.id.nfc_card_code, checks.nfcLoyaltyCardNo());
            Log.d(TAG, "Entered capture card number");

            checks.enterText(R.id.nfc_name, "Name");
            Log.d(TAG, "Entered name");

            checks.enterText(R.id.nfc_surname, "Surname");
            Log.d(TAG, "Entered surname");

            checks.enterText(R.id.nfc_cell_number, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            checks.enterText(R.id.nfc_id_number, "8904156088083");
            Log.d(TAG, "Entered ID number");

            solo.clickOnButton("Register");
            Log.d(TAG, "Clicked Register");

            solo.waitForDialogToOpen();
            if (solo.searchText("Successful")) {
                solo.clickOnText("OK");
                Log.d(TAG, "Registration successful, clicked ok");
            } else if (solo.searchText("already in use")) {
                solo.clickOnText("OK");
                Log.d(TAG, "Registration successful, clicked ok");
            } else
                fail("Registration not successful");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_Edit() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.nfcEdit();
            Log.d(TAG, "NFC Edit menu option selected");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            checks.enterText(R.id.nfc_name, "");
            checks.enterText(R.id.nfc_name, "EditedName");
            Log.d(TAG, "Edited the name");

            solo.clickOnButton("Update");
            Log.d(TAG, "Clicked Update");

            solo.waitForDialogToOpen();
            if (solo.searchText("Successful")) {
                solo.clickOnText("OK");
                Log.d(TAG, "Editing profile successful, clicked ok");
            } else
                fail("Editing profile not successful");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T020_ExistingConsumer() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeAirtime();
            Log.d(TAG, "Clicked Airtime");

            solo.clickOnText("R2");
            Log.d(TAG, "Clicked on R2 airtime");

            checkStock();
            Log.d(TAG, "Printing..");

            solo.clickOnView(solo.getView(R.id.nfcLogoutOnBar));

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T030_LostCard() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.nfcLostCard();
            Log.d(TAG, "NFC Deactivate menu option selected");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            checks.enterText(R.id.nfc_card_code, checks.nfcLoyaltyCardNo());
            Log.d(TAG, "Entered capture card number");

            solo.clickOnText("Replace Lost Card");
            Log.d(TAG, "Updating card details successful, Clicked yes");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T040_EndActiveSession() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            solo.clickOnView(solo.getView(R.id.nfcLogoutOnBar));
            Log.d(TAG, "Clicked close button");

            solo.sleep(1000);

            if (getBaseActivity().isConsumerProfileActive()) {
                fail("Still in the NFC consumer profile");
            } else {
                Log.d(TAG, "Out the NFC consumer profile");
            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T050_ThemeColorChange() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            Log.d(TAG, "Current skin = " + checks.checkPreference(PREF_SKIN));

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            solo.sleep(500);

            Log.d(TAG, "Changed skin = " + checks.checkPreference(PREF_SKIN));
            String currentSkin = checks.checkPreference(PREF_SKIN);

            if (currentSkin.equals(getBaseActivity().getResources().getString(R.string.skinNFC))) {
                Log.d(TAG, "PREF_SKIN changed");
            } else {
                Log.e(TAG, "Skin=" + currentSkin + " but should =" + getBaseActivity().getResources().getString(R.string.skinNFC));
                fail("PREF_SKIN not changed");
            }

            solo.clickOnView(solo.getView(R.id.nfcLogoutOnBar));

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T060_DisplayConsumer() {
        try {

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            solo.sleep(1000);

            if (BaseActivity.completeConsumerProfile == null) {
                fail("completeConsumerProfile is null");
            } else {
                String name = BaseActivity.completeConsumerProfile.getConsumer().getName();
                String surname = BaseActivity.completeConsumerProfile.getConsumer().getSurname();

                if (name != null || surname != null)
                    Log.d(TAG, "Consumer name is displayed, the name is " + name + " " + surname);
                else
                    fail("Name not displayed");
            }

            solo.clickOnView(solo.getView(R.id.nfcLogoutOnBar));

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T070_ErrorPropagation() {
        try {

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.nfcRegistration();
            Log.d(TAG, "NFC Registration menu option selected");

            solo.clickOnButton("Register");
            Log.d(TAG, "Clicked Register");

            if (!solo.searchText("Required")) {
                fail("Could not find text Required");
            }
            if (!solo.searchText("Cellphone number is required")) {
                fail("Could not find text Cellphone number is required");
            }

            solo.clickOnButton("Cancel");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T080_CancelButton() {
        try {

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            //test cancel register
            checks.nfcRegistration();
            Log.d(TAG, "NFC Register menu option selected");

            solo.sleep(500);

            solo.clickOnButton("Cancel");

            //test cancel edit profile
            checks.nfcEdit();
            Log.d(TAG, "NFC Edit menu option selected");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            solo.sleep(500);

            solo.clickOnButton("Cancel");

            //test cancel lost card
            checks.nfcLostCard();
            Log.d(TAG, "NFC Lost Card menu option selected");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            solo.sleep(500);

            solo.clickOnButton("Cancel");

            //test cancel deactivate
            checks.nfcDeactivate();
            Log.d(TAG, "NFC Deactivate menu option selected");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, "0711234567");
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            solo.sleep(500);

            solo.clickOnButton("Cancel");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T090_Airtime_Test() {
        try {

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN MENU selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 airtime voucher selected");

            if (checkStock()) {
//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//                if (checks.findNfcFavourite("10")) {
//                    Log.d(TAG, "Purchased voucher appears on customer favourites");
//                } else {
//                    fail("Purchased voucher DOES NOT appears on customer favourites");
//                }
            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T100_Data() {
        try {

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "TELKOM  MENU selected");

            selectProviderCellC();
            Log.d(TAG, "TELKOM  MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "TELKOM  MENU selected");

            solo.clickOnText("100MB");
            Log.d(TAG, "Data 100MB data voucher selected");

            if (checkStock()) {
//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//                if (checks.findNfcFavourite("Data")) {
//                    Log.d(TAG, "Purchased voucher appears on customer favourites");
//                } else {
//                    fail("Purchased voucher DOES NOT appear on customer favourites");
//                }
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T110_Electricity() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeElectricity();

            if (solo.waitForFragmentByTag("FragmentElectricity")) {
                Log.d(TAG, "Select Electricity Fragment");
            } else {
                fail("Select Electricity Fragment");
            }

            solo.clickOnText("Eskom");
            Log.d(TAG, "Eskom electricity selected");

            enterMeterNumber("123456789");
            Log.d(TAG, "Meter number entered");

            confirmFBEElectrictyVoucher();
            Log.d(TAG, "FBE confirmed with valid meter number");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm Electricity Voucher Displayed");
            } else {
                fail("Confirm Electricity Voucher NOT Displayed");
            }

            buyElectricityVoucher();
            Log.d(TAG, "FBE Token Purchased");

            selectVoucherTypeElectricity();

            solo.clickOnText("Eskom");
            Log.d(TAG, "Eskom selected");

            enterMeterNumber("123456789");
            Log.d(TAG, "Meter number entered");

            enterAmount("80");
            Log.d(TAG, "Amount entered");

            confirmElectrictyVoucher();
            Log.d(TAG, "Electricity confirmed with valid meter number and amount");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm Electricity Voucher Displayed");
            } else {
                fail("Confirm Electricity Voucher NOT Displayed");
            }

            buyElectricityVoucher();

            Log.d(TAG, "ESKOM Electricity Token Purchased");


//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//            if (checks.findNfcFavourite("Electricity")) {
//                Log.d(TAG, "Electricity appears on customer favourites");
//            } else {
//                fail("Electricity DOES NOT appears on customer favourites");
//            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T120_BillPayment() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            checks.selectBillPaymentType("Accounts");
            Log.d(TAG, "Select accounts tab");

            checks.enterText(R.id.search, "Albert");
            solo.clickOnText("Albert Luthli Municipality");

            Log.d(TAG, "Albert Luthuli municipality selected");

            checks.enterText(R.id.accountNumber, "01234567");

            Log.d(TAG, "Account number entered");
            checks.enterText(R.id.amount, "25");

            Log.d(TAG, "Amount entered");
            checks.clickButton(R.id.cashButton);

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm cash payment dialog");
            } else {
                fail("Can't open confirm payment dialog");
            }

            solo.clickOnText("Cancel");
            Log.d(TAG, "Cancel cash payment");

            solo.waitForDialogToClose();
            checks.clickButton(R.id.creditCardButton);

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm credit card payment dialog");
            } else {
                fail("Can't open confirm payment dialog");
            }

            solo.clickOnText("Cancel");
            Log.d(TAG, "Cancel credit card payment");

            solo.waitForDialogToClose();
            checks.clickButton(R.id.debitCardButton);

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Confirm debit card payment dialog");
            } else {
                fail("Can't open confirm payment dialog");
            }

            solo.clearLog();
            solo.clickOnButton(1);
            Log.d(TAG, "Pay account");

            solo.waitForLogMessage("TenderResponseMessage");

            if (solo.searchText("Provider Application offline")) {
                fail("SAPO is offline");
            }
//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//            if (checks.findNfcFavourite("Albert Luthli Municipality")) {
//                Log.d(TAG, "Albert Luthuli municipality appears on customer favourites");
//            } else {
//                fail("Albert Luthuli municipality DOES NOT appears on customer favourites");
//            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T130_Vouchers() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectProviderHollywoodBet();
            Log.d(TAG, "Hollywood Bets MENU selected");

            solo.clickOnText("R50");
            Log.d(TAG, "R50 Hollywood Bets voucher selected");


            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("-");
            Log.d(TAG, " Voucher quantity decreased");

            if (checkStock()) {
                Log.d(TAG, " Voucher confirmed");

//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//                if (checks.findNfcFavourite("Other")) {
//                    Log.d(TAG, "Other voucher appears on customer favourites");
//                } else {
//                    fail("Other voucher DOES NOT appear on customer favourites");
//                }
            }


        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T140_Carma() {
        try {
            changePreference(PREF_SECURE_USB_PRINTER, PREF_TRUE);
            Log.d(TAG, "SECURE USB PRINTER TRUE");

            //Return trip with parent and infant

            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            //show bus ticket categories
            getBusTickets();
            Log.d(TAG, "Go to Bus Categories");

            //click on Translux
            gotoBusType(0);
            Log.d(TAG, "Go to Translux");

            solo.waitForDialogToClose();

            //OneWay Trip
            indicateWayOfTravel("OneWay");
            Log.d(TAG, "OneWay trip selected");

            selectDepart("CAPE", "CAPE TOWN");
            Log.d(TAG, "departure from Cape town");

            destination("JOH", "JOHANNESBURG");
            Log.d(TAG, "Destination Johannesburg");

            //travel class type
            solo.pressSpinnerItem(0, 0);
            Log.d(TAG, "travel class Full Flexi selected");

            DepartCalendar();
            Log.d(TAG, "Click on Departure Calendar");
            //select a specific date
            departDate();
            solo.clickOnText("Ok");
            Log.d(TAG, "Set departure date");

            View Scroll = solo.getView(R.id.searchScrollView);
            Scroll.scrollBy(0, 360);

            solo.clickOnView(solo.getView(R.id.add_adult_number));
            Log.d(TAG, "Adult added");

            searchBusTicket();

            //Departure ticket
            solo.clickOnView(solo.getView(R.id.parent_layout_id));
            Log.d(TAG, "Click on ticket");

            solo.clickOnView(solo.getView(R.id.next_search_results));
            Log.d(TAG, "Next");

            //Parent details
            Title(4);
            Log.d(TAG, "Title entered");

            initial("RJ");
            Log.d(TAG, "Initials entered");

            Surname("Motsamai");
            Log.d(TAG, "Surname");

            Cellphone("0735780512");
            Log.d(TAG, "Cellphone entered");

            indicateDocumentation("ID");
            Log.d(TAG, "ID selected");

            View BottomF = solo.getView(R.id.fragment_passenger_details_id);
            BottomF.scrollBy(0, 360);

            ID("8903030290081");
            Log.d(TAG, "ID number entered");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            solo.clickOnButton("Next");
            Log.d(TAG, "Next");

            paymentType("credit card");
            Log.d(TAG, "paying using a credit card");

            Book();
            Log.d(TAG, "Booking a ticket");

            Log.d(TAG, "ticket to follow");
            PrintTicket();

//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//            if (checks.findNfcFavourite("Tickets")) {
//                Log.d(TAG, "Tickets appears on customer favourites");
//            } else {
//                fail("Tickets DOES NOT appears on customer favourites");
//            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T150_Event() {
        try {
            Log.d(TAG, "SECURE USB PRINTER FALSE");
            changePreference(PREF_SECURE_USB_PRINTER, PREF_FALSE);

            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            gotoEvents();
            Log.d(TAG, "Goto events");

            solo.waitForDialogToClose();

            chooseCategory("Cricket");
            Log.d(TAG, "get category Events");

            solo.waitForDialogToClose();

            solo.clickInList(1, 1);
            Log.d(TAG, "select first event");

            solo.waitForDialogToClose();

            solo.clickInList(2, 1);
            Log.d(TAG, "select second seat pricing");

            solo.clickOnButton("Next");
            Log.d(TAG, "GOTO next page");

            ListView myList = (ListView) solo.getView(R.id.priceList);
            View til = myList.getChildAt(0);
            ImageView plus = til.findViewById(R.id.plus);

            //plus
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");

            solo.clickOnButton("Next");
            Log.d(TAG, "Click next with 1 Tickets");

            solo.waitForDialogToClose();

            solo.clickOnButton("Next");
            Log.d(TAG, "checkout with 1 Ticket");

            enterName("test name");
            Log.d(TAG, "Name entered");

            enterCell("0731231234");
            Log.d(TAG, "Cell Entered");

            indicatepaymentType("debit card");
            Log.d(TAG, "Payment type indicated");

            confirmPurchaseTicket();
            Log.d(TAG, "Confirm Purchase Ticket clicked");

//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//            if (checks.findNfcFavourite("Tickets")) {
//                Log.d(TAG, "Tickets appears on customer favourites");
//            } else {
//                fail("Tickets DOES NOT appears on customer favourites");
//            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T160_TopUpAirtime() {
        try {

            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "Cell C MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 PINLESS TOP UP airtime voucher selected");

            if (solo.getView(R.id.cellNumberSpinner).isShown()) {
                solo.clickOnView(solo.getView(R.id.cellNumberSpinner));
                solo.clickOnText("Other");
            }

            checks.enterText(R.id.cellNumber, checks.nfcCellNo());
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, checks.nfcCellNo());
            Log.d(TAG, " Valid Cellphone number confirmed");


            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");

//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//            if (checks.findNfcFavourite("Pinless Top Up")) {
//                Log.d(TAG, "Pinless Top Up appears on customer favourites");
//            } else {
//                fail("Pinless Top Up DOES NOT appears on customer favourites");
//            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T170_BillPaymentPayAt() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            checks.selectBillPaymentType("Accounts");

            Log.d(TAG, "Select accounts tab");

            checks.enterText(R.id.search, "Multichoice");

            solo.clickOnText("Multichoice/DSTV");

            Log.d(TAG, "Select Multichoice/DSTV");

            checks.enterText(R.id.accountNumber, "12280246");

            Log.d(TAG, "Account number entered");

            checks.clickButton(R.id.showDetailsButton);
            Log.d(TAG, "Show details button clicked");

            solo.waitForText("Verifying Account");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Customer Details Dialog open");
            } else {
                fail("Can't open Customer Details Dialog");
            }

            checks.enterText(R.id.amount, "25");
            Log.d(TAG, "Amount entered");

            solo.scrollToBottom();

            checks.clickButton(R.id.cashButton);
            Log.d(TAG, "Cash Payment confirmed");

            solo.clearLog();
            solo.clickOnText("Continue");
            Log.d(TAG, "Clicked 'CONTINUE'");

            solo.waitForDialogToOpen();

            solo.sendKey(KeyEvent.KEYCODE_BACK);
            Log.d(TAG, "back button disabled");

            solo.waitForLogMessage("TenderResponseMessage");

//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//            if (checks.findNfcFavourite("Multichoice/DSTV")) {
//                Log.d(TAG, "Multichoice/DSTV appears on customer favourites");
//            } else {
//                fail("Multichoice/DSTV DOES NOT appears on customer favourites");
//            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T180_AirtimeVodacom_Test() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "VODA MENU selected");

            solo.clickOnText("R12");
            Log.d(TAG, "R12 airtime voucher selected");

            if (checkStock()) {
//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//                if (checks.findNfcFavourite("12.00")) {
//                    Log.d(TAG, "Purchased voucher appears on customer favourites");
//                } else {
//                    fail("Purchased voucher DOES NOT appears on customer favourites");
//                }
            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T190_AirtimeCellC() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "Cell C MENU selected");

            solo.clickOnText("R5");
            Log.d(TAG, "R5 airtime voucher selected");

            if (checkStock()) {
//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//                if (checks.findNfcFavourite("5.00")) {
//                    Log.d(TAG, "Purchased voucher appears on customer favourites");
//                } else {
//                    fail("Purchased voucher DOES NOT appears on customer favourites");
//                }
            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T200_AirtimeTelkom() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "Cell C MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "Telkom MENU selected");

            solo.clickOnText("R20");
            Log.d(TAG, "R20 airtime voucher selected");

            if (checkStock()) {
//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//                if (checks.findNfcFavourite("20.00")) {
//                    Log.d(TAG, "Purchased voucher appears on customer favourites");
//                } else {
//                    fail("Purchased voucher DOES NOT appears on customer favourites");
//                }
            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T210_DataVoda() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom  MENU selected");

            solo.clickOnText("50MB");
            Log.d(TAG, "Data 100MB data voucher selected");

            if (checkStock()) {
//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//                if (checks.findNfcFavourite("14.50")) {
//                    Log.d(TAG, "Purchased voucher appears on customer favourites");
//                } else {
//                    fail("Purchased voucher DOES NOT appear on customer favourites");
//                }
            }

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T220_DataCellC() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "Cell C  MENU selected");

            solo.clickOnText("R89");
            Log.d(TAG, "R89 Data & bundles voucher selected");

            if (checkStock()) {
//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//                if (checks.findNfcFavourite("89.00")) {
//                    Log.d(TAG, "Purchased voucher appears on customer favourites");
//                } else {
//                    fail("Purchased voucher DOES NOT appear on customer favourites");
//                }
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T230_DataMTN() {
        try {

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN MENU selected");

            solo.clickOnText("5MB");
            Log.d(TAG, "MTN Data voucher selected");

            if (checkStock()) {
//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//                if (checks.findNfcFavourite("4.00")) {
//                    Log.d(TAG, "Purchased voucher appears on customer favourites");
//                } else {
//                    fail("Purchased voucher DOES NOT appear on customer favourites");
//                }
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }

    }

    @Test
    public void T240_TopUpAirtimeVoda() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            solo.clickOnView(solo.getView(R.id.nfcOnBar));
            Log.d(TAG, "Clicked NFC on bar");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 PINLESS TOP UP airtime voucher selected");

            if (solo.getView(R.id.cellNumberSpinner).isShown()) {
                solo.clickOnView(solo.getView(R.id.cellNumberSpinner));
                solo.clickOnText("Other");
            }

            checks.enterText(R.id.cellNumber, checks.nfcCellNo());
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, checks.nfcCellNo());
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");

//there is a propogation delay between doing the transaction on aeon and updating the loyalty service,
//so we probably wont see the transaction populated immediately
//            if (checks.findNfcFavourite("Pinless Top Up")) {
//                Log.d(TAG, "Pinless Top Up appears on customer favourites");
//            } else {
//                fail("Pinless Top Up DOES NOT appears on customer favourites");
//            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T250_Deactivate() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.nfcDeactivate();
            Log.d(TAG, "NFC Deactivate menu option selected");

            solo.clickOnView(solo.getView(R.id.captureCellNumber));

            checks.enterText(R.id.captureCellNumber, checks.nfcCellNo());
            Log.d(TAG, "Entered cell number");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked Confirm");

            solo.clickOnButton("Confirm");
            Log.d(TAG, "Clicked 'Cancel Subscriber'");

            solo.waitForDialogToOpen();
            solo.clickOnText("Confirm");
            Log.d(TAG, "Dialog opened, Clicked cancel subscriber");

            solo.waitForDialogToOpen();
            if (solo.searchText("Successful")) {
                solo.clickOnText("OK");
                Log.d(TAG, "The account was deactivated, clicked 'Ok'");
            } else {
                fail("The account was not deactivated");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

}
