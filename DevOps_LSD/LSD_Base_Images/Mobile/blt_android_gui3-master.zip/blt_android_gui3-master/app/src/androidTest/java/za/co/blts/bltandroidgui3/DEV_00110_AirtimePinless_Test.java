package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 3/6/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00110_AirtimePinless_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_Vodacom_R10() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 PINLESS TOP UP airtime voucher selected");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with no cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberNotEntered))) {
                Log.d(TAG, "Cellphone number not entered error message displayed");
            } else {
                fail("Cellphone number not entered error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "1121231234");
            Log.d(TAG, "Invalid cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "1121231234");
            Log.d(TAG, "Invalid cellphone number confirmed");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with invalid cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberInvalid))) {
                Log.d(TAG, "Cellphone number invalid error message displayed");
            } else {
                fail("Cellphone number invalid error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Not Matching Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231235");
            Log.d(TAG, "Not Matching Cellphone number confirmed");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with mismatching cellphone numbers");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumbersDontMatch))) {
                Log.d(TAG, "Cellphone numbers don't match error message displayed");
            } else {
                fail("Cellphone numbers don't match error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231234");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T005_Vodacom_Any() {
        try {
            float min = 2.00f;
            float max = 999.00f;

            String errorMessage = String.format(getBaseActivity().getResources().getString(R.string.moneyBadAmount), min, max);

            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount PINLESS TOP UP airtime voucher selected");

            confirmTopUpVoucher(false);
            Log.d(TAG, "Voucher confirmed with no cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberNotEntered))
                    && solo.searchText(errorMessage)) {
                Log.d(TAG, "Bad Amount and Cellphone number not entered error messages displayed");
            } else {
                fail("Bad Amount and Cellphone number not entered error messages NOT displayed");
            }

            checks.enterText(R.id.amount, "50");
            Log.d(TAG, "Valid Amount entered ");

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231234");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T200_Mtn_Any() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount PINLESS TOP UP airtime voucher selected");

            checks.enterText(R.id.amount, "50");
            Log.d(TAG, "Valid Amount entered ");

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231234");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T205_Mtn_R10() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 PINLESS TOP UP airtime voucher selected");

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231234");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T300_CellC_R10() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "Cell C MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 PINLESS TOP UP airtime voucher selected");

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231234");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T305_CellC_Any() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "CEll C MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount PINLESS TOP UP airtime voucher selected");

            checks.enterText(R.id.amount, "50");
            Log.d(TAG, "Valid Amount entered ");

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231234");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T400_Virgin_R20() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            selectProviderTelkom();
            selectProviderNeotel();
            selectProviderVirginMobile();
            Log.d(TAG, "Virgin Mobile MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("R20");
            Log.d(TAG, "R20 PINLESS TOP UP airtime voucher selected");

            checks.enterText(R.id.cellNumber, "0601231235");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0601231235");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T500_Telkom_R10() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            selectProviderTelkom();
            Log.d(TAG, "TELKOM MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 PINLESS TOP UP airtime voucher selected");

            checks.enterText(R.id.cellNumber, "0601231235");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0601231235");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T600_Neotel_R20() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }
            //scroll to cellc so you can see neotel
            selectProviderCellC();

            //scroll to the neotel tab
            selectProviderTelkom();
            Log.d(TAG, "TELKOM  MENU selected");

            selectProviderNeotel();
            Log.d(TAG, "NEOTEL MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("R20");
            Log.d(TAG, "R20 PINLESS TOP UP airtime voucher selected");

            checks.enterText(R.id.cellNumber, "0601231235");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0601231235");
            Log.d(TAG, " Valid Cellphone number confirmed");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

}
