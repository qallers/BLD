package za.co.blts.bltandroidgui3;


import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 1/9/2017.
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00020_Login_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_Login() {
        try {

            //check screen layout
            //checkScreenLayout();

            //test valid login
            if (!checks.validLogin()) {
                fail("Valid Login");
            } else {
                Log.d(TAG, "Valid Login Test Passed Successfully..!");
            }

            checks.logout();

            //test invalid login
            if (!checks.invalidLogin()) {
                fail("Invalid login");
            } else {
                Log.d(TAG, "Invalid Login Test Passed Successfully..!");
            }
        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }

    }

    @Test
    public void T010_UserName() {
        try {
            //check screen layout
            //test valid login
            if (!checks.validLogin()) {
                fail("Valid Login");
            } else {
                Log.d(TAG, "Valid Login Test Passed Successfully..!");
            }

            String user = getBaseActivity().toolbar.getSubtitle().toString();

            if (user.isEmpty()) {
                fail("logged in user is not displayed");
            }

        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }

    }

}
