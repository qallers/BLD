package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by Warren 2.0 on 04/05/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00270_Favourites_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_AirtimeVoucher_Mtn_R2() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN menu selected");

            checks.addToFavourites("R2");
            Log.d(TAG, "R2 airtime voucher selected");

            solo.waitForDialogToOpen();

            checks.clickButton("Cancel");
            Log.d(TAG, "Cancel button clicked");

            checks.addToFavourites("R2");
            Log.d(TAG, "R2 airtime voucher selected");

            solo.waitForDialogToOpen();

            solo.clickOnButton("Add");
            Log.d(TAG, "Add Button clicked");

            solo.scrollToBottom();

            checks.clickButton("Save");
            Log.d(TAG, " Favourites list updated");

            solo.scrollToBottom();

            if (solo.searchText("R2 Call-a-lot")) {
                Log.d(TAG, "R2 MTN voucher found in favourites");
            } else {
                fail("R2 MTN voucher not found in favourites");
            }

            checks.removeFromFavourites("R2 Call-a-lot");
            Log.d(TAG, "Long press on MTN R2 airtime voucher");

            solo.waitForDialogToOpen();

            solo.clickOnButton("Remove");
            Log.d(TAG, "Remove Button clicked");

            solo.scrollToBottom();

            if (solo.searchText("R2 Call-a-lot")) {
                fail("R2 MTN voucher not removed from favourites");
            } else {
                Log.d(TAG, "R2 MTN voucher removed from favourites");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_Electricity_UniPin_R30() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeElectricity();

            if (solo.waitForFragmentByTag("FragmentElectricity")) {
                Log.d(TAG, "Select Electricity Fragment");
            } else {
                fail("Select Electricity Fragment");
            }

            solo.scrollDownRecyclerView(0);
            Log.d(TAG, "Scrolled to bottom");

            checks.addToFavourites("R30");
            Log.d(TAG, "R30 UniPin card selected");

            solo.waitForDialogToOpen();

            checks.clickButton("Cancel");
            Log.d(TAG, "Cancel button clicked");

            solo.waitForDialogToClose();

            checks.addToFavourites("R30");
            Log.d(TAG, "R30 UniPin card selected");

            solo.waitForDialogToOpen();

            solo.clickOnButton("Add");
            Log.d(TAG, "Add Button clicked");

            solo.scrollDownRecyclerView(0);

            checks.clickButton("Save");
            Log.d(TAG, "Favourites list updated");

            solo.scrollToBottom();

            if (solo.searchText("R30")) {
                Log.d(TAG, "R30 UniPin found in favourites");
            } else {
                fail("R30 UniPin not found in favourites");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


}
