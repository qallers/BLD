package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 3/3/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00250_VouchersMvno_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T140_MvnoMenu() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }
            selectC4C();
            Log.d(TAG, "Go to MVNO menu");

            selectMVNOAdvinne();
            Log.d(TAG, "Go to Advinne");

            solo.goBack();

            selectC4C();
            Log.d(TAG, "Go to MVNO menu");

            selectMVNOTheUnlimited();
            Log.d(TAG, "Go to TheUnlimited");

            solo.goBack();

            selectC4C();
            Log.d(TAG, "Go to MVNO menu");

            selectMVNOMyAir();
            Log.d(TAG, "Go to MyAir");

            solo.goBack();

            selectC4C();
            Log.d(TAG, "Go to MVNO menu");

            selectMVNOFNBConnect();
            Log.d(TAG, "Go to FNBConnect");

            solo.goBack();

            selectMVNOLycaMobile();
            Log.d(TAG, "Go to LycaMobile");

            solo.goBack();

            selectC4C();
            Log.d(TAG, "Go to MVNO menu");

            selectMVNOCallAll();
            Log.d(TAG, "Go to CallAll");

            solo.goBack();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T150_Advinne_R20() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectC4C();
            Log.d(TAG, "C4C MENU selected");

            selectMVNOAdvinne();
            Log.d(TAG, "Advinne MENU selected");

            solo.clickOnText("R20");
            Log.d(TAG, "R20 Advinne voucher selected");

            checkStock();
            Log.d(TAG, " Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T160_Advinne_AnyAmount() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select voucher Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectC4C();
            Log.d(TAG, "Go to MVNO Vouchers Menu");

            selectMVNOAdvinne();
            Log.d(TAG, "Advinne MENU selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Entered an amount below minimum");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Entered an amount exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "100");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
            Log.d(TAG, " Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T170_TheUnlimited_R50() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectC4C();
            Log.d(TAG, "C4C MENU selected");

            selectMVNOTheUnlimited();
            Log.d(TAG, "TheUnlimited MENU selected");

            solo.clickOnText("R50");
            Log.d(TAG, "R50 TheUnlimited voucher selected");

            checkStock();
            Log.d(TAG, " Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T180_TheUnlimited_AnyAmount() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select voucher Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectC4C();
            Log.d(TAG, "C4C MENU selected");

            selectMVNOTheUnlimited();
            Log.d(TAG, "TheUnlimited MENU selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");
            checks.enterText(R.id.amount, "1");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "100");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
            Log.d(TAG, " Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T190_MyAir_R10() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectC4C();
            Log.d(TAG, "C4C MENU selected");

            selectMVNOMyAir();
            Log.d(TAG, "MyAir MENU selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 MyAir voucher selected");

            checkStock();
            Log.d(TAG, " Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T200_MyAir_AnyAmount() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select voucher Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectC4C();
            Log.d(TAG, "C4C MENU selected");

            selectMVNOMyAir();
            Log.d(TAG, "MyAir MENU selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");
            checks.enterText(R.id.amount, "1");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "100");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
            Log.d(TAG, " Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T210_FNBConnect_R10() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectC4C();
            Log.d(TAG, "C4C MENU selected");

            selectMVNOFNBConnect();
            Log.d(TAG, "FNBConnect MENU selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 FNBConnect voucher selected");

            checkStock();
            Log.d(TAG, " Voucher confirmed");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T220_FNBConnect_AnyAmount() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select voucher Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectC4C();
            Log.d(TAG, "FNBConnect Vouchers Fragment");

            selectMVNOFNBConnect();
            Log.d(TAG, "FNBConnect MENU selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");
            checks.enterText(R.id.amount, "1");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "100");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T230_LycaMobile_R100() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectC4C();
            Log.d(TAG, "C4C MENU selected");

            selectMVNOLycaMobile();
            Log.d(TAG, "LycaMobile MENU selected");

            solo.clickOnText("R100");
            Log.d(TAG, "R100 LycaMobile voucher selected");

            checkStock();
            Log.d(TAG, " Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T240_LycaMobile_AnyAmount() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select voucher Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectC4C();
            Log.d(TAG, "LycaMobile Vouchers Fragment");

            selectMVNOLycaMobile();
            Log.d(TAG, "LycaMobile MENU selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");
            checks.enterText(R.id.amount, "1");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "100");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T250_CallAll_R100() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            selectC4C();
            Log.d(TAG, "C4C MENU selected");

            selectMVNOCallAll();
            Log.d(TAG, "CallAll MENU selected");

            solo.clickOnText("R100");
            Log.d(TAG, "R100 CallAll voucher selected");

            checkStock();
            Log.d(TAG, "Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T260_CallAll_AnyAmount() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select voucher Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectC4C();
            Log.d(TAG, "CallAll Vouchers Fragment");

            selectMVNOCallAll();
            Log.d(TAG, "CallAll MENU selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");
            checks.enterText(R.id.amount, "1");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "100");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    @Test
    public void T280_BluVoucher_AnyAmount() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeOtherVouchers();

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select voucher Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectC4C();
            Log.d(TAG, "C4C MENU selected");

            selectMVNOBluVoucher();
            Log.d(TAG, "TheUnlimited MENU selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");
            checks.enterText(R.id.amount, "1");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1001");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "10");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
            Log.d(TAG, " Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
