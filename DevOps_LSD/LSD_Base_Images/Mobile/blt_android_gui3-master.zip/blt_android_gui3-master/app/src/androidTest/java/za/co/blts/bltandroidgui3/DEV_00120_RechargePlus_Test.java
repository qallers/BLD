package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 3/3/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00120_RechargePlus_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_Vodacom_Voucher_R5() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            solo.clickOnText("R5");
            Log.d(TAG, "R5 airtime voucher selected");

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Airtime plus selected");

            checkStock();
            Log.d(TAG, " Voucher confirmed");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T300_CellC_Topup_R10() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "Cell C MENU selected");

            gotoPinless();
            Log.d(TAG, "PINLESS TOP UP airtime vouchers selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 PINLESS TOP UP airtime voucher selected");

            solo.clickOnText("TopUp");
            Log.d(TAG, "Voucher confirmed with no cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberNotEntered))) {
                Log.d(TAG, "Cellphone number not entered error message displayed");
            } else {
                fail("Cellphone number not entered error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "1121231234");
            Log.d(TAG, "Invalid cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "1121231234");
            Log.d(TAG, "Invalid cellphone number confirmed");

            solo.clickOnText("TopUp");
            Log.d(TAG, "Voucher confirmed with invalid cellphone number");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumberInvalid))) {
                Log.d(TAG, "Cellphone number invalid error message displayed");
            } else {
                fail("Cellphone number invalid error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Not Matching Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231235");
            Log.d(TAG, "Not Matching Cellphone number confirmed");

            solo.clickOnText("TopUp");
            Log.d(TAG, "Voucher confirmed with mismatching cellphone numbers");

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.cellNumbersDontMatch))) {
                Log.d(TAG, "Cellphone numbers don't match error message displayed");
            } else {
                fail("Cellphone numbers don't match error message NOT displayed");
            }

            checks.enterText(R.id.cellNumber, "0721231234");
            Log.d(TAG, "Valid Cellphone number entered");

            checks.enterText(R.id.confirmCellNumber, "0721231234");
            Log.d(TAG, " Valid Cellphone number confirmed");

            solo.clickOnCheckBox(0);
            Log.d(TAG, "Airtime plus selected");

            confirmTopUpVoucher(true);
            Log.d(TAG, "Voucher confirmed with valid cellphone numbers");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


}
