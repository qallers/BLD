package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SECURE_USB_PRINTER;

/**
 * Created by warrenm
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00220_TicketProEvent_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
        changePreference(PREF_SECURE_USB_PRINTER, PREF_FALSE);
    }

    @After
    public void after() {
        changePreference(PREF_SECURE_USB_PRINTER, PREF_FALSE);
        tearDown();
    }

    @Test
    public void T001_FirstCategory() {
        try {
            Log.d(TAG, "SECURE USB PRINTER FALSE");

            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            gotoEvents();
            Log.d(TAG, "Goto events");

            solo.waitForDialogToClose();

//      chooseCategory("Golf");
            solo.clickInRecyclerView(0);
            Log.d(TAG, "get category Events");

            solo.clickInList(1, 0);
            Log.d(TAG, "select first event");

            solo.waitForDialogToClose();

            solo.clickInList(1, 0);
            Log.d(TAG, "select second seat pricing");

            solo.clickOnButton("Next");
            Log.d(TAG, "GOTO next page");

            ListView myList = (ListView) solo.getView(R.id.priceList); //
            View til = myList.getChildAt(0);
            ImageView plus = til.findViewById(R.id.plus);
            ImageView minus = til.findViewById(R.id.minus);

            //plus
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");

            //minus
            solo.clickOnView(minus);
            Log.d(TAG, "quantity decreased");

            solo.clickOnButton("Next");
            Log.d(TAG, "Click next with 0 Tickets");

            solo.waitForDialogToOpen();
            Log.d(TAG, "0 tickets dialog open");
            solo.clickOnText("OK");
            Log.d(TAG, "Ok Button Click");

            //plus
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");

            solo.clickOnButton("Next");
            Log.d(TAG, "Click next with 2 Tickets");

            solo.waitForDialogToClose();

            ListView cartList = (ListView) solo.getView(R.id.priceList); //
            View deleteView = cartList.getChildAt(0);
            ImageView remove = deleteView.findViewById(R.id.selectSeat);

            solo.clickOnView(remove);
            solo.waitForDialogToClose();
            Log.d(TAG, "1 ticket removed");

            solo.clickOnButton("Next");
            Log.d(TAG, "checkout with 1 Ticket");

            enterName("test name");
            Log.d(TAG, "Name entered");

            enterCell("0731231234");
            Log.d(TAG, "Cell Entered");

            indicatepaymentType("debit card");
            Log.d(TAG, "Payment type indicated");

            confirmPurchaseTicket();
            Log.d(TAG, "Confirm Purchase Ticket clicked");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T080_SoldOut() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            gotoEvents();
            Log.d(TAG, "Goto events");

            solo.waitForDialogToClose();

//      chooseCategory("Rugby");
            solo.clickInRecyclerView(0);
            Log.d(TAG, "get category Events");

            solo.waitForDialogToClose();

            solo.clickInList(1, 0);
            Log.d(TAG, "select first event");

            solo.waitForDialogToClose();

            solo.scrollListToBottom(0);
            solo.clickInList(3, 0);
            Log.d(TAG, "select sold out seat pricing");

            if (solo.waitForDialogToOpen() && solo.waitForText("sold out")) {
                Log.d(TAG, "Seat category sold out dialog showing");
            } else {
                fail("Seat category not sold out");
            }

            solo.clickOnButton("OK");
            Log.d(TAG, "Seat category sold out dialog dismissed");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T090_ViewVenueLayout() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            gotoEvents();
            Log.d(TAG, "Goto events");

            solo.waitForDialogToClose();

            solo.clickInRecyclerView(0);
            Log.d(TAG, "get category Events");

            solo.clickInList(1, 0);
            Log.d(TAG, "select first event");

            solo.waitForDialogToClose();

            solo.waitForDialogToClose();

            ImageView viewLayout = (ImageView) solo.getView(R.id.layoutIcon);
            solo.clickOnView(viewLayout);
            Log.d(TAG, "click to view venue layout");

            solo.waitForDialogToOpen();
            Log.d(TAG, "Venue layout dialog open");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T100_Search() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            gotoEvents();
            Log.d(TAG, "Goto events");

            checks.enterText(R.id.search, "sun");
            Log.d(TAG, "Searched event");

            solo.clickInList(0);
            Log.d(TAG, "Selected event");

            solo.clickInList(0, 0);
            Log.d(TAG, "select second seat pricing");

            solo.clickOnButton("Next");
            Log.d(TAG, "GOTO next page");

            ListView myList = (ListView) solo.getView(R.id.priceList); //
            View til = myList.getChildAt(0);
            ImageView plus = til.findViewById(R.id.plus);
            ImageView minus = til.findViewById(R.id.minus);

            //plus
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");

            //minus
            solo.clickOnView(minus);
            Log.d(TAG, "quantity decreased");

            solo.clickOnButton("Next");
            Log.d(TAG, "Click next with 0 Tickets");

            solo.waitForDialogToOpen();
            Log.d(TAG, ") tickets dialog open");
            solo.clickOnText("OK");
            Log.d(TAG, "Ok Button Click");

            //plus
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");

            solo.clickOnButton("Next");
            Log.d(TAG, "Click next with 2 Tickets");

            solo.waitForDialogToClose();

            ListView cartList = (ListView) solo.getView(R.id.priceList); //
            View deleteView = cartList.getChildAt(0);
            ImageView remove = deleteView.findViewById(R.id.selectSeat);

            solo.clickOnView(remove);
            solo.waitForDialogToClose();
            Log.d(TAG, "1 ticket removed");

            solo.clickOnButton("Next");
            Log.d(TAG, "checkout with 1 Ticket");

            enterName("test name");
            Log.d(TAG, "Name entered");

            enterCell("0731231234");
            Log.d(TAG, "Cell Entered");

            indicatepaymentType("debit card");
            Log.d(TAG, "Payment type indicated");

            confirmPurchaseTicket();
            Log.d(TAG, "Confirm Purchase Ticket clicked");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    @Test
    public void T110_Collection() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            solo.clickOnText("Collection");
            Log.d(TAG, "Clicked on 'COLLECTION'");

            solo.waitForDialogToOpen();

            solo.clickOnText("Cancel");
            Log.d(TAG, "Clicked on 'CANCEL'");

            solo.clickOnText("Collection");
            Log.d(TAG, "Clicked on 'COLLECTION'");

            solo.enterText(0, "123456789");
            Log.d(TAG, "Entered ref number");

            solo.clickOnText("Collect");
            Log.d(TAG, "Clicked on 'COLLECT'");

            solo.sleep(5000);
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T120_EventCart() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            gotoEvents();
            Log.d(TAG, "Goto events");

//      chooseCategory("Lifestyle");
            solo.clickInRecyclerView(0);
            Log.d(TAG, "Category 0 selected");

            solo.clickInList(1, 0);
            Log.d(TAG, "select First event");

            solo.clickInList(1, 0);
            Log.d(TAG, "select first seat pricing");

            solo.clickOnButton("Next");
            Log.d(TAG, "GOTO next page");

            ListView myList = (ListView) solo.getView(R.id.priceList);
            View til = myList.getChildAt(0);
            ImageView plus = til.findViewById(R.id.plus);

            //plus
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");

            solo.clickOnButton("Next");
            Log.d(TAG, "Click next");

            solo.waitForDialogToClose();

            ListView cartList = (ListView) solo.getView(R.id.priceList);
            View deleteView = cartList.getChildAt(0);
            ImageView remove = deleteView.findViewById(R.id.selectSeat);

            solo.clickOnView(remove);
            Log.d(TAG, "1 ticket removed");

            solo.clickOnImage(1);
            Log.d(TAG, "Closed TicketPro events");

            gotoEvents();
            Log.d(TAG, "Goto events");

//      chooseCategory("Cricket");
            solo.clickInRecyclerView(1);
            Log.d(TAG, "Category 1 selected");

            solo.clickInList(1, 0);
            Log.d(TAG, "select First event");

            solo.clickInList(1, 0);
            Log.d(TAG, "select first seat pricing");

            solo.clickOnButton("Next");
            Log.d(TAG, "GOTO next page");

            //plus
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");

            solo.clickOnButton("Next");
            Log.d(TAG, "Click next");

            solo.waitForDialogToClose();

            solo.clickOnView(remove);
            Log.d(TAG, "1 ticket removed");

            solo.clickOnImage(1);
            Log.d(TAG, "Closed TicketPro events");

            gotoEvents();
            Log.d(TAG, "Goto events");

//      chooseCategory("Golf");
//      Log.d(TAG, "Golf selected");
            solo.clickInRecyclerView(2);
            Log.d(TAG, "Category 2 selected");

            solo.clickInList(1, 0);
            Log.d(TAG, "select First event");

            solo.clickInList(1, 0);
            Log.d(TAG, "select first seat pricing");

            solo.clickOnButton("Next");
            Log.d(TAG, "GOTO next page");

            //plus
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");

            solo.clickOnButton("Next");
            Log.d(TAG, "Click next");

            solo.waitForDialogToClose();

            solo.clickOnButton("Next");

            Log.d(TAG, "checkout with 1 ticket");

            enterName("test");
            Log.d(TAG, "Name Entered");

            enterCell("0731231234");
            Log.d(TAG, "Cell Entered");

            indicatepaymentType("cash");
            Log.d(TAG, "payment type indicated");

            confirmPurchaseTicket();
            Log.d(TAG, "Confirm Purchase Ticket clicked");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T130_EventCartButton() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeTickets();
            Log.d(TAG, "Goto tickets menu");

            gotoEvents();
            Log.d(TAG, "Goto events");

            chooseCategory("Lifestyle");
            Log.d(TAG, "Lifestyle selected");

            solo.clickInList(2, 0);
            Log.d(TAG, "select First event");

            solo.clickInList(1, 0);
            Log.d(TAG, "select first seat pricing");

            solo.clickOnButton("Next");
            Log.d(TAG, "GOTO next page");

            ListView myList = (ListView) solo.getView(R.id.priceList);
            View til = myList.getChildAt(0);
            ImageView plus = til.findViewById(R.id.plus);

            //plus
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");

            solo.clickOnButton("Next");
            Log.d(TAG, "Click next");

            solo.clickOnButton("Back");
            Log.d(TAG, "Click back");


            solo.clickOnImage(1);
            Log.d(TAG, "Back to Tickets screen");

            gotoEvents();
            Log.d(TAG, "Goto events");

            chooseCategory("Cricket");
            Log.d(TAG, "Cricket selected");

            solo.clickInList(1, 0);
            Log.d(TAG, "select First event");

            solo.clickInList(1, 0);
            Log.d(TAG, "select first seat pricing");

            solo.clickOnButton("Next");
            Log.d(TAG, "GOTO next page");

            myList = (ListView) solo.getView(R.id.priceList);
            til = myList.getChildAt(0);
            plus = til.findViewById(R.id.plus);

            //plus
            solo.clickOnView(plus);
            Log.d(TAG, "quantity increased");

            solo.clickOnButton("Next");
            Log.d(TAG, "GOTO next page");

            solo.clickOnButton("Next");
            Log.d(TAG, "checkout with 1 Ticket");

            enterName("test name");
            Log.d(TAG, "Name entered");

            enterCell("0731231234");
            Log.d(TAG, "Cell Entered");

            indicatepaymentType("debit card");
            Log.d(TAG, "Payment type indicated");

            confirmPurchaseTicket();
            Log.d(TAG, "Confirm Purchase Ticket clicked");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
