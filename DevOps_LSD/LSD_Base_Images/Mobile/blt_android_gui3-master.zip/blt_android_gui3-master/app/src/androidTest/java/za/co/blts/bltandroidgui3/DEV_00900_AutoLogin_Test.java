package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;

/**
 * Created by BoitshokoM on 1/5/2018.
 */

@RunWith(AndroidJUnit4.class)
public class DEV_00900_AutoLogin_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        checks.setWifi(true);  //in case test fails, ensure wifi turned on again before next test
        tearDown();
    }


    @Test
    public void testAutoLogin() {
        try {
            checks.clearCache();

            Log.d(TAG, "Turning wifi off");
            checks.setWifi(false);

            Log.d(TAG, "Try login with wifi off");
            checks.login("011234");

            solo.sleep(500);

            solo.clickOnButton("Auto Login");

            solo.clickOnButton("Auto Login");

            solo.clickOnText("OK");

            Log.d(TAG, "Try login again");
            checks.login("011234");

            Log.d(TAG, "Turning wifi on and waiting 10s");
            checks.setWifi(true);

            solo.sleep(10000);

            Log.d(TAG, "Try auto login");
            solo.clickOnButton("Auto Login");

            solo.sleep(10000);
//      solo.waitForActivity("ActivityMain");

            Log.d(TAG, "Try logout");
            checks.logout();

            Log.d(TAG, "Turning wifi off");
            checks.setWifi(false);

            Log.d(TAG, "Try invalid login");
            checks.invalidLogin();

            Log.d(TAG, "Try auto login");
            solo.clickOnButton("Auto Login");

            solo.sleep(4000);

            Log.d(TAG, "Turning wifi on and waiting 3s");
            checks.setWifi(true);

            solo.sleep(3000);

            Log.d(TAG, "Try auto login");
            solo.clickOnButton("Auto Login");

            solo.sleep(4000);

        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }

    }


}


