package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 3/6/2017.
 */

@RunWith(AndroidJUnit4.class)
public class DEV_00080_VoucherTabs_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void testVoucherTabs() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            selectProviderMTN();
            Log.d(TAG, "MTN MENU selected");

            selectProviderCellC();
            Log.d(TAG, "CELL C MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "TELKOM MENU selected");

            selectProviderNeotel();
            Log.d(TAG, "NEOTEL MENU selected");

            selectProviderVirginMobile();
            Log.d(TAG, "VIRGIN MOBILE MENU selected");

            selectProviderAllProviders();
            Log.d(TAG, "ALL MENU selected");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
