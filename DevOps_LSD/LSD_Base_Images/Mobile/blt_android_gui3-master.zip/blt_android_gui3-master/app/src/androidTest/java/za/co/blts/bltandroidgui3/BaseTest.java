package za.co.blts.bltandroidgui3;

import android.content.res.AssetManager;
import android.os.Build;
import android.util.Log;

import com.robotium.solo.Solo;

import java.util.Properties;

import static androidx.test.platform.app.InstrumentationRegistry.getInstrumentation;
import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AEON_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AWS_HEARTBEAT_MINUTES;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BLUKEY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BP_LIMIT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASHIER_END_SHIFT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASH_DRAWER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DISPLAY_BALANCE1;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_EPUB_MANUAL_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_EPUB_READER_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FDROID_REPO_DIR;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FDROID_REPO_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HEARTBEAT_ENABLE_TECH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HEARTBEAT_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOG_DAYS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOG_LEVEL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_ENABLE_TECH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_ENABLE_USER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MANUAL_OVERRIDE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PAPER_CUTTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINTER_WIDTH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_PREVIEWS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_SALES_RECEIPT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_CAN_BOXRICA;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_USE_SSL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SCANNING_APP;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SCREEN_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SECURE_USB_PRINTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_STORE_ADDRESS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_STORE_NAME;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TECH_PIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRANSACTION_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_BASKET;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_SSL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VAT_REG_NO;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VOUCHER_SECONDS;

//===============================================
// logcat regex filter while running tests:
// BaseTest|DEV_|(to|from) AEON|Checks|Exception
//===============================================

class BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    Solo solo;

    Checks checks;
    String[] providers;

    Properties testProperties = null;

    public void setUp(BaseActivity activityClass) throws Exception {
        Log.d(TAG, "setUp executing");

        solo = new Solo(getInstrumentation(), activityClass);

        BaseActivity.TEST_MODE = true;

        Log.d(TAG, "baseActivity is " + solo.getCurrentActivity());
        checks = new Checks(solo);
        providers = solo.getCurrentActivity().getResources().getStringArray(R.array.networkProviders);

        AssetManager assetManager = getInstrumentation().getContext().getAssets();
        testProperties = new Properties();
        testProperties.load(assetManager.open(Build.SERIAL + ".test.properties"));
        Log.d(TAG, "deviceId " + testProperties.getProperty("deviceId"));

        //force the first login of each test to be online
        BaseActivity.loginResponseMessage = null;
    }

    BaseActivity getBaseActivity() {
        return (BaseActivity) solo.getCurrentActivity();
    }

    public void tearDown() {
        getBaseActivity().cancelTimer();
        solo.finishOpenedActivities();
    }

    void changePreference(String prefName, String prefValue) {
        try {
            getBaseActivity().updatePreference(prefName, prefValue);

        } catch (Exception exception) {
            Log.d(TAG, "changePreference throws " + exception);
            fail("changePreference throws " + exception);
        }
    }

    void restoreAllDeviceSettings() {
        try {
            restoreDeviceSettingsReceipts();
            restoreDeviceSettingsDevice();
            restoreDeviceSettingsStoreInfo();
            setLoyaltySettingsOn();
            setLoyaltyEnabledOff();
        } catch (Exception e) {
            fail("Exception ex " + e.toString());
        }
    }

    void restoreAllDefaultSettings() {
        try {
            restorePrinterSettings();
            restoreDeviceSettings();
            restoreRicaSettings();
            restoreRepositorySettings();
            restoreApiGatewaySetting();
            restoreBluKeySetting();
            restoreTechnicianPinSettings();
            restoreTimeoutSettings();
            restoreThemeSettings();
            restoreUserSettings();
            restoreTechnicianCashDrawerSettings();
            restoreErrorLoggingSettings();
            restoreScanningSettings();
            restoreTrainingAppSettings();
            restoreHeartbeatSettings();
            restoreManualOverrideSetting();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }


    private void restoreManualOverrideSetting() {
        changePreference(PREF_MANUAL_OVERRIDE, PREF_FALSE);
    }


    private void restoreDeviceSettings() {

        //DEVICE SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_HOST, "10.22.7.12");
        changePreference(PREF_PORT, "9011");
        changePreference(PREF_USE_SSL, PREF_FALSE);

        changePreference(PREF_DEVICE_ID, testProperties.getProperty("deviceId"));
    }

    private void restoreTimeoutSettings() {
        //TIMEOUT SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_AEON_TIMEOUT, "300");
        changePreference(PREF_TRANSACTION_TIMEOUT, "60");
    }

    private void restorePrinterSettings() {
        BaseActivity baseActivity = (BaseActivity) solo.getCurrentActivity();

        //PRINTER SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_PAPER_CUTTER, PREF_FALSE);
        baseActivity.configurePrinter();
        changePreference(PREF_SECURE_USB_PRINTER, PREF_FALSE);
        changePreference(PREF_PRINT_SALES_RECEIPT, PREF_TRUE);
        changePreference(PREF_PRINT_PREVIEWS, PREF_FALSE);
        changePreference(PREF_PRINTER_WIDTH, testProperties.getProperty("printerWidth"));
        changePreference(PREF_VOUCHER_SECONDS, "5");
    }

    private void restoreTechnicianPinSettings() {
        //TECHNICIAN PIN SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_TECH_PIN, "2596");
    }

    private void restoreRicaSettings() {
        //RICA SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_RICA_HOST, "10.22.7.17");
        changePreference(PREF_RICA_PORT, "9013");
        changePreference(PREF_RICA_DEVICE_ID, "2");
        changePreference(PREF_RICA_DEVICE_SER, "3");
        changePreference(PREF_RICA_USE_SSL, PREF_TRUE);
        changePreference(PREF_RICA_CAN_BOXRICA, PREF_FALSE);
    }

    private void restoreRepositorySettings() {
        //REPOSITORY SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_FDROID_REPO_URL, "https://10.22.7.23:80");
        changePreference(PREF_FDROID_REPO_DIR, "/touchscreen/bd3/");
    }

    private void restoreBluKeySetting() {
        //BLUKEY SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_BLUKEY_URL, "https://blutrader.qa.bltelecoms.net");
    }

    private void restoreApiGatewaySetting() {
        //API GATEWAY SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_LOYALTY_URL, "https://10.22.7.12:9013");
        changePreference(PREF_LOYALTY_ENABLE_TECH, PREF_FALSE);
    }


    void setLoyaltySettingsOn() {
        //REPOSITORY SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_LOYALTY_URL, "http://10.22.7.12:9013");
        changePreference(PREF_LOYALTY_ENABLE_TECH, PREF_TRUE);
    }

    void setLoyaltyEnabledOn() {
        changePreference(PREF_LOYALTY_ENABLE_USER, PREF_TRUE);
    }

    void setLoyaltyEnabledOff() {
        changePreference(PREF_LOYALTY_ENABLE_USER, PREF_FALSE);
    }

    void restoreLoyaltySettings() {
        //REPOSITORY SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_LOYALTY_URL, "http://10.22.7.12:9013");
        changePreference(PREF_LOYALTY_ENABLE_USER, PREF_FALSE);
        changePreference(PREF_LOYALTY_ENABLE_TECH, PREF_FALSE);
    }

    private void restoreHeartbeatSettings() {
        //REPOSITORY SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_HEARTBEAT_ENABLE_TECH, PREF_TRUE);
        changePreference(PREF_HEARTBEAT_URL, "https://sqs.eu-west-1.amazonaws.com/834031529481/device_heartbeat_dev-queue?Action=SendMessage&amp;MessageBody=");
        changePreference(PREF_AWS_HEARTBEAT_MINUTES, "3");
    }

    private void restoreUserSettings() {
        //DEVICE  SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_PRINT_MERCHANT_VOUCHER, PREF_FALSE);
        changePreference(PREF_CASHIER_END_SHIFT, PREF_TRUE);
        changePreference(PREF_USE_BASKET, PREF_FALSE);
        changePreference(PREF_PRINT_SALES_RECEIPT, PREF_TRUE);
        changePreference(PREF_PRINT_PREVIEWS, PREF_FALSE);
        changePreference(PREF_CASH_DRAWER, PREF_FALSE);
        changePreference(PREF_LOYALTY_ENABLE_USER, PREF_FALSE);
        changePreference(PREF_SCREEN_TIMEOUT, "280");
        changePreference(PREF_BP_LIMIT, "9999.00");
        changePreference(PREF_STORE_NAME, "Test Store Name");
        changePreference(PREF_STORE_ADDRESS, "Test Address");
        changePreference(PREF_VAT_REG_NO, "000000000001");
    }

    private void restoreDeviceSettingsReceipts() {
        //DEVICE  SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_PRINT_MERCHANT_VOUCHER, PREF_FALSE);
        changePreference(PREF_PRINT_SALES_RECEIPT, PREF_TRUE);
        changePreference(PREF_PRINT_PREVIEWS, PREF_FALSE);
    }

    private void restoreDeviceSettingsDevice() {
        //DEVICE  SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_CASHIER_END_SHIFT, PREF_TRUE);
        changePreference(PREF_USE_BASKET, PREF_FALSE);
        changePreference(PREF_SCREEN_TIMEOUT, "280");
        changePreference(PREF_BP_LIMIT, "9999.00");
    }

    private void restoreDeviceSettingsStoreInfo() {
        //DEVICE  SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_STORE_NAME, "Test Store Name");
        changePreference(PREF_STORE_ADDRESS, "Test Address");
        changePreference(PREF_VAT_REG_NO, "000000000001");
    }

    private void restoreThemeSettings() {
        BaseActivity baseActivity = (BaseActivity) solo.getCurrentActivity();
        //THEME SETTINGS RESET PREFERENCES TO DEFAULT
        changePreference(PREF_SKIN, baseActivity.getResources().getString(R.string.blt));
    }

    private void restoreTechnicianCashDrawerSettings() {
        changePreference(PREF_CASH_DRAWER, PREF_FALSE);
    }

    private void restoreErrorLoggingSettings() {
        changePreference(PREF_LOG_LEVEL, "INFO");
        changePreference(PREF_LOG_DAYS, "4");
    }

    private void restoreScanningSettings() {
        changePreference(PREF_SCANNING_APP, "com.codecorp.cortex_scan");
    }

    private void restoreTrainingAppSettings() {
        changePreference(PREF_EPUB_READER_URL, "http://196.38.158.102/touchscreen/bd3/LithiumEPUBReader.apk");
        changePreference(PREF_EPUB_MANUAL_URL, "http://196.38.158.102/touchscreen/bd3/Training.epub");
    }

    public void enableCallMe() {
        getBaseActivity().cacheCallMeData("{\"menu\":[{\"id\":\"device\",\"desc\":\"Get help with your device\"},{\"id\":\"account\",\"desc\":\"Get help with your account\"},{\"id\":\"deposit\",\"desc\":\"Please watsapp a copy of your deposit slip to 123-4567\"}]}");
    }

    public void disableCallMe() {
        getBaseActivity().removeCallMeCache();
    }
}
