package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.KeyEvent;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 3/3/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00100_AirtimeVouchers_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_Vodacom_R5() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            solo.clickOnText("R5");
            Log.d(TAG, "R5 airtime voucher selected");
            solo.clickOnCheckBox(0);

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");
            solo.clickOnButton("-");
            Log.d(TAG, " Voucher quantity decreased");

            checkStock();
            Log.d(TAG, " Voucher confirmed");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T005_Vodacom_R5_Multiple() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            solo.clickOnText("R5");
            Log.d(TAG, "R5 airtime voucher selected");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("-");
            Log.d(TAG, " Voucher quantity decreased");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T005_Vodacom_R5_Multiple_With_RechargePlus() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            solo.clickOnText("R5");
            Log.d(TAG, "R5 airtime voucher selected");
            solo.clickOnCheckBox(0);

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("-");
            Log.d(TAG, " Voucher quantity decreased");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_Vodacom_Any() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            scrollToText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");

            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "100");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T100_Mtn_Any() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN MENU selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");


            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "100");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T105_Mtn_R10() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN MENU selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 airtime voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T300_CellC_R10() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "CELL C  MENU selected");

            solo.clickOnText("R10");
            Log.d(TAG, "R10 airtime voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T305_CellC_Any() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "CELL C MENU selected");

            solo.scrollDownRecyclerView(0);
            Log.d(TAG, "Scrolled downed to Any Amount");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "100");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    //Disabled since Virgin Mobile has no any amount voucher
//  @Test
    public void T400_Virgin_Any() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            //scroll to the neotel tab
            selectProviderCellC();
            Log.d(TAG, "Cell C  MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "TELKOM  MENU selected");

            selectProviderNeotel();
            Log.d(TAG, "NEOTEL  MENU selected");

            selectProviderVirginMobile();
            Log.d(TAG, "Virgin Mobile  MENU selected");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "100");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T405_Virgin_R500() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            //scroll to the neotel tab
            selectProviderCellC();
            Log.d(TAG, "Cell C  MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "TELKOM  MENU selected");

            selectProviderNeotel();
            Log.d(TAG, "NEOTEL  MENU selected");

            selectProviderVirginMobile();
            Log.d(TAG, "Virgin Mobile  MENU selected");

            solo.clickOnText("R500");
            Log.d(TAG, "R500 airtime voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T500_Telkom_R5() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "Cell C  MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "TELKOM  MENU selected");

            solo.clickOnText("R5");
            Log.d(TAG, "R5 airtime voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T505_Telkom_Any() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN MENU selected");

            selectProviderCellC();
            Log.d(TAG, "Cell C  MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "TELKOM MENU selected");

            solo.scrollDownRecyclerView(0);

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");


            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.scrollDownRecyclerView(0);

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.scrollDownRecyclerView(0);

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "50");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T600_Neotel_R25() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            //scroll to the neotel tab
            selectProviderCellC();
            Log.d(TAG, "Cell C  MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "TELKOM  MENU selected");

            selectProviderNeotel();
            Log.d(TAG, "NEOTEL  MENU selected");

            solo.clickOnText("R25");
            Log.d(TAG, "R25 airtime voucher selected");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("-");
            Log.d(TAG, " Voucher quantity decreased");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T700_Any_Any() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderMTN();
            Log.d(TAG, "MTN MENU selected");

            selectProviderCellC();
            Log.d(TAG, "Cell C  MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "TELKOM MENU selected");

            selectProviderNeotel();
            Log.d(TAG, "Neotel MENU selected");

            selectProviderVirginMobile();
            Log.d(TAG, "Virgin Mobile MENU selected");

            selectProviderAllProviders();
            Log.d(TAG, "All Providers MENU selected");

            solo.scrollDownRecyclerView(0);
            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "1");
            Log.d(TAG, "Any Amount below minimum entered");

            solo.clickOnButton("Print");
            Log.d(TAG, "Voucher confirmed");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "600");
            Log.d(TAG, "Any Amount entered exceeding limit");

            solo.clickOnButton("Print");

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Bad amount error message displayed");
            } else {
                fail("Bad amount error message NOT displayed");
            }

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked the Cancel button");

            //solo.scrollDownRecyclerView(0);
            solo.clickOnText("Any Amount");
            Log.d(TAG, "Any Amount airtime voucher selected");

            checks.enterText(R.id.amount, "50");
            Log.d(TAG, "Correct Any Amount entered");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T705_Any_CellC_R60() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderCellC();
            Log.d(TAG, "Cell C  MENU selected");

            selectProviderTelkom();
            Log.d(TAG, "TELKOM  MENU selected");


            selectProviderNeotel();
            Log.d(TAG, "NEOTEL  MENU selected");

            selectProviderVirginMobile();
            Log.d(TAG, "Virgin Mobile menu selected");

            selectProviderAllProviders();
            Log.d(TAG, "All providers menu selected");

            scrollToText("R60");
            Log.d(TAG, "R60 Cell c airtime voucher selected");

            checkStock();
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T800_BackButton() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            selectVoucherTypeAirtime();

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom MENU selected");

            solo.clickOnText("R2");
            Log.d(TAG, "R2 airtime voucher selected");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clickOnButton("+");
            Log.d(TAG, " Voucher quantity increased");

            solo.clearLog();
            confirmPrintVoucher();
            Log.d(TAG, "Attempting to get vouchers..");

            solo.sendKey(KeyEvent.KEYCODE_BACK);
            Log.d(TAG, "back button disabled");

            solo.sendKey(KeyEvent.KEYCODE_BACK);
            Log.d(TAG, "back button disabled");

            solo.sendKey(KeyEvent.KEYCODE_BACK);
            Log.d(TAG, "back button disabled");

            solo.waitForLogMessage("TenderResponseMessage");
            Log.d(TAG, "***Back button disabled during transaction***");
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
