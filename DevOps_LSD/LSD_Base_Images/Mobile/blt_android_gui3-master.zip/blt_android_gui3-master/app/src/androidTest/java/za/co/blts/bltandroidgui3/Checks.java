package za.co.blts.bltandroidgui3;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;

import com.robotium.solo.Solo;

import za.co.blts.bltandroidgui3.widgets.BluDroidDeviceIdEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidPinEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static androidx.test.platform.app.InstrumentationRegistry.getInstrumentation;
import static junit.framework.Assert.fail;

/**
 * Created by NkosanaM on 1/9/2017.
 */

class Checks { // extends BaseTest{

    private final String TAG = this.getClass().getSimpleName();

    private Solo solo;

    public Checks(Solo solo) {
        this.solo = solo;
    }


    public boolean superVisorLogin(BaseTest test) {
        return validLogin(test.testProperties.getProperty("supervisorPin"));
    }

    public boolean cashierLogin(BaseTest test) {
        return validLogin(test.testProperties.getProperty("cashierPin"));
    }

    public boolean cashierPlusLogin(BaseTest test) {
        return validLogin(test.testProperties.getProperty("cashierPlusPin"));
    }


    /*
       User  Login
     */
    public void login(String pin) {

        BluDroidPinEditText edtPassword = (BluDroidPinEditText) solo.getView(R.id.loginPassword);

        Log.d(TAG, "baseActivity is " + solo.getCurrentActivity());

        Log.d(TAG, "Got Password editText");

        solo.clickOnView(edtPassword);

        solo.enterText(edtPassword, pin);
        Log.d(TAG, "Password entered");

        if (pin.length() < 6) {

            solo.pressSoftKeyboardDoneButton();
        }
    }

    public boolean validLogin() {
        Log.d(TAG, "Testing login");

        solo.clickInRecyclerView(0);

        login("011234");

//    if(solo.waitForDialogToOpen(1000) == true){
//      solo.clickOnButton("No");
//    }

        if (solo.waitForActivity(ActivityMain.class)) {
            solo.assertCurrentActivity("Expected menu Screen shown...", ActivityMain.class);
            Log.d(TAG, "User successfully logged in");
            waitForLoginToFinish();
            return true;
        } else {
            return false;
        }
    }

    public boolean validLogin(String pin) {

        Log.d(TAG, "Testing login");
        solo.clickInRecyclerView(0);
        login(pin);

        if (solo.waitForActivity(ActivityMain.class)) {
            solo.assertCurrentActivity("Expected menu Screen shown...", ActivityMain.class);
            Log.d(TAG, "User successfully logged in");

            waitForLoginToFinish();
            return true;

        } else {
            return false;
        }
    }

    public boolean invalidLogin() {

        Log.d(TAG, "Testing Incorrect Login");
        solo.clickInRecyclerView(0);
        login("222222");

        //
        //AEON can change the error message...!!
        //
        String errorMessage = "Invalid user";

        if (solo.waitForText(errorMessage)) {
            Log.d(TAG, "Invalid user error message displayed");
            return true;
        } else {
            return false;
        }

    }

    private void waitForLoginToFinish() {
        Log.d(TAG, "Waiting for dialogs to close");
        int num = 0;

        while (solo.waitForDialogToOpen(2000)) {
            solo.waitForDialogToClose();
            Log.d(TAG, "Dialog closed " + (++num));
        }
    }

    /*
       Technician  Login
     */
    private void loginTechnician(String pin) {

        gotoTechnicanLogin();

        if (solo.waitForActivity(ActivityTechnicianLogin.class)) {

            EditText edtPassword = (EditText) solo.getView(R.id.techLoginPassword);
            Log.d(TAG, "Got Password editText");

            solo.enterText(edtPassword, pin);
            Log.d(TAG, "Password entered");
        } else {
            fail("Could not get Technician Login Screen");
        }

    }

    public boolean validTechnicianLogin() {


        Log.d(TAG, "Testing Technician login");
        loginTechnician("2596");

        if (solo.waitForActivity(ActivityTechnicianConfig.class)) {
            solo.assertCurrentActivity("Expected technician config Screen shown...", ActivityTechnicianConfig.class);
            Log.d(TAG, "Technician successfully logged in");
            return true;

        } else {
            return false;
        }

    }

    public boolean invalidTechnicianLogin() {

        Log.d(TAG, "Testing Incorrect Technician Login");
        loginTechnician("0123");

        String errorMessage = solo.getCurrentActivity().getResources().getString(R.string.techPinInvalid);

        if (solo.waitForText(errorMessage)) {
            Log.d(TAG, "Invalid technician error message displayed");
            return true;
        } else {
            return false;
        }

    }

    private void gotoTechnicanLogin() {
        String techConfigText = solo.getCurrentActivity().getResources().getString(R.string.technicianSignIn);
        solo.clickOnView(solo.getView(R.id.fab));
        solo.clickOnMenuItem(techConfigText);
    }

    public void gotoKMS() {
        solo.clickInRecyclerView(1);
    }

    public void gotoDigitalOnboarding() {
        solo.clickInRecyclerView(2);
    }

    public void gotoTrainingManuals() {
        solo.clickInRecyclerView(3);
    }

    public void bluKey() {
        solo.clickInRecyclerView(2);
        solo.waitForLogMessage("loading completed");
    }

    public void callMe() {
        solo.clickInRecyclerView(4);
    }

    public void clearCache() {
        String refresh = solo.getCurrentActivity().getResources().getString(R.string.refresh);
        solo.clickOnView(solo.getView(R.id.fab));
        solo.clickOnMenuItem(refresh);
    }

    public void gotoReportsScreen() {
        String reportsText = solo.getCurrentActivity().getResources().getString(R.string.reports);
        clickOnActionBarMenuItem(reportsText);
    }

    public void gotoUsersScreen() {
        String usersText = solo.getCurrentActivity().getResources().getString(R.string.users);
        clickOnActionBarMenuItem(usersText);
    }

    public void enterDeviceID(String deviceId) {

        BluDroidDeviceIdEditText deviceIdEditText = (BluDroidDeviceIdEditText) solo.getView(R.id.deviceIdSetting);
        solo.clearEditText(deviceIdEditText);
        solo.enterText(deviceIdEditText, deviceId);
        Log.d(TAG, "Device ID Entered");
    }

    public void changePrinterWidth(String width) {

        RadioButton widthRadio = null;

        switch (width.toLowerCase()) {
            case "32":
                widthRadio = (RadioButton) solo.getView(R.id.width32);
                break;
            case "42":
                widthRadio = (RadioButton) solo.getView(R.id.width42);
                break;
            default:
        }

        solo.clickOnView(widthRadio);
        Log.d(TAG, "Width changed to " + width);
    }

    public void selectTheme(String theme) {
        RadioButton themeRadio = null;

        switch (theme.toLowerCase()) {
            case "tspc":
                themeRadio = (RadioButton) solo.getView(R.id.tspcRadio);
                break;
            case "blt":
                themeRadio = (RadioButton) solo.getView(R.id.bltRadio);
                break;
            default:
        }

        solo.clickOnView(themeRadio);
        Log.d(TAG, theme + " Theme selected");
    }

    public void toggleTechSetup(String section) {
        BluDroidLinearLayout sectionView = null;

        switch (section.toLowerCase()) {
            case "devicesettings":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.deviceSettingsGroupToggle);
                break;
            case "themesettings":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.themeSettingsGroupToggle);
                break;
            case "printersettings":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.printerSettingsGroupToggle);
                break;
            case "timeoutsettings":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.timeoutSettingsGroupToggle);
                break;
            case "ricasettings":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.ricaSettingsGroupToggle);
                break;
            case "repositorysettings":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.fdroidSettingsGroupToggle);
                break;
            case "cashdrawersetting":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.cashDrawGroupToggle);
                break;
            case "errorlogging":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.errorLoggingGroupToggle);
                break;
            case "scanning":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.scannerGroupToggle);
                break;
            case "trainingapp":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.epubGroupToggle);
                break;
            case "loyalty":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.loyaltySettingsGroupToggle);
                break;
            case "heartbeat":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.heartbeatSettingsGroupToggle);
                break;
            case "blukey":
                sectionView = (BluDroidLinearLayout) solo.getView(R.id.merchantSettingsGroupToggle);
                break;

            default:
                break;
        }

        solo.clickOnView(sectionView);

    }

    public void toggleDeviceSetup(String section) {
        ViewGroup sectionView = null;

        switch (section.toLowerCase()) {
            case "receipts":
                sectionView = (ViewGroup) solo.getView(R.id.receiptSettingsGroup);
                break;
            case "device":
                sectionView = (ViewGroup) solo.getView(R.id.deviceSettingsGroupToggle);
                break;
            case "store":
                sectionView = (ViewGroup) solo.getView(R.id.storeSettingsGroupToggle);
                break;
            case "account_balance":
                sectionView = (LinearLayout) solo.getView(R.id.accountBalanceGroupToggle);
                break;
            case "loyalty":
                sectionView = (ViewGroup) solo.getView(R.id.loyaltyGroupToggle);
                break;
            default:
                break;
        }

        solo.clickOnView(sectionView);

    }

    public void toggleSwitch(String desc) {

        View switchView = null;

        switch (desc.toLowerCase()) {
            case "papercutter":
                switchView = solo.getView(R.id.paperCutterSwitch);
                break;
            case "usbprinter":
                switchView = solo.getView(R.id.secureUsbPrinterSwitch);
                break;
            case "salesreceipt":
                switchView = solo.getView(R.id.salesReceiptSwitch);
                break;
            case "previewreports":
                switchView = solo.getView(R.id.reportPreviewSwitch);
                break;
            case "ssl":
                switchView = solo.getView(R.id.sslSwitch);
                break;
            case "ricassl":
                switchView = solo.getView(R.id.ricaSSLSwitch);
                break;
            case "boxrica":
                switchView = solo.getView(R.id.boxRicaSwitch);
                break;
            case "merchantvouchers":
                switchView = solo.getView(R.id.merchantVouchersSwitch);
                break;
            case "cashierendshift":
                switchView = solo.getView(R.id.cashierEndShiftSwitch);
                break;
            case "calculator":
                switchView = solo.getView(R.id.useBasketSwitch);
                break;
            case "cashdrawer":
                switchView = solo.getView(R.id.cashDrawSwitch);
                break;
            case "loyaltyenabled":
                switchView = solo.getView(R.id.loyaltySwitch);
                break;
            case "heartbeatenable":
                switchView = solo.getView(R.id.heartbeatEnableSwitch);
                break;
            default:
                break;
        }
        solo.clickOnView(switchView);
        Log.d(TAG, desc + " switch toggled");
    }

    public void toggleManualOverrideSwitch() {
        View switchView = solo.getView(R.id.manualOverrideSwitch);
        solo.clickOnView(switchView);
    }

    public boolean isViewEnabled(int viewId) {

        View view = solo.getView(viewId);

        return view.isEnabled();
    }

    public void confirmTechnician() {
        EditText editTextConfirm = (EditText) solo.getView(R.id.techLoginPassword);
        solo.clearEditText(editTextConfirm);
        solo.enterText(editTextConfirm, "2596");

        solo.clickOnView(solo.getView(R.id.affirmativeButton));
    }

    public void selectSecondsRadioButton(String value) {
        RadioButton secondsRadio = null;

        switch (value) {


            case "0":
                secondsRadio = (RadioButton) solo.getView(R.id.zeroRadio);
                break;
            case "5":
                secondsRadio = (RadioButton) solo.getView(R.id.fiveRadio);
                break;
            case "7":
                secondsRadio = (RadioButton) solo.getView(R.id.sevenRadio);
                break;
            case "10":
                secondsRadio = (RadioButton) solo.getView(R.id.tenRadio);
                break;

            default:
        }

        solo.clickOnView(secondsRadio);
        Log.d(TAG, value + " seconds between vouchers selected");
//    solo.sleep(1000);
    }

    public void checkDeviceTimeoutRadioGroup(String value) {
        RadioButton secondsRadio = null;

        switch (value) {
            case "180":
                secondsRadio = (RadioButton) solo.getView(R.id.rbTimeout3);
                break;
            case "300":
                secondsRadio = (RadioButton) solo.getView(R.id.rbTimeout5);
                break;
            case "600":
                secondsRadio = (RadioButton) solo.getView(R.id.rbTimeout10);
                break;
            case "1800":
                secondsRadio = (RadioButton) solo.getView(R.id.rbTimeout30);
                break;
            case "3600":
                secondsRadio = (RadioButton) solo.getView(R.id.rbTimeoutHour);
                break;
        }

        solo.clickOnView(secondsRadio);
        Log.d(TAG, value + " seconds has been selected as the timeout for auto sign out");
//    solo.sleep(1000);
    }

    public void selectHeartbeatIntervalRadioButton(String value) {
        RadioButton secondsRadio = null;

        switch (value) {
            case "3":
                secondsRadio = (RadioButton) solo.getView(R.id.threeMinRadio);
                break;
            case "5":
                secondsRadio = (RadioButton) solo.getView(R.id.fiveMinRadio);
                break;
            case "7":
                secondsRadio = (RadioButton) solo.getView(R.id.sevenMinRadio);
                break;

            default:
        }

        solo.clickOnView(secondsRadio);
        Log.d(TAG, value + " seconds between vouchers selected");
//    solo.sleep(1000);
    }

    public void gotoUserSettings() {
        String userSettingsText = solo.getCurrentActivity().getResources().getString(R.string.device_settings);
        clickOnActionBarMenuItem(userSettingsText);

        if (solo.waitForActivity(ActivityUserSettings.class, 10000)) {
            Log.d(TAG, "Entered device settings screen");
        } else {
            fail("could not get to device settings screen");
        }
//    solo.sleep(1000);

    }


    public void toggleReports(String section) {
        View sectionView = null;

        switch (section.toLowerCase()) {
            case "reprint":
                sectionView = solo.getView(R.id.reprintGroupToggle);
                break;
            case "transactionlist":
                sectionView = solo.getView(R.id.transactionListGroupToggle);
                break;
            case "dailybatch":
                sectionView = solo.getView(R.id.dailyBatchReportGroupToggle);
                break;
            case "accountstatus":
                sectionView = solo.getView(R.id.accountStatusGroupToggle);
                break;
            case "profitreport":
                sectionView = solo.getView(R.id.profitReportGroupToggle);
                break;
            case "statement":
                sectionView = solo.getView(R.id.statementGroupToggle);
                break;
            case "invoicing":
                sectionView = solo.getView(R.id.invoicingGroupToggle);
                break;
            case "viewshift":
                sectionView = solo.getView(R.id.viewShiftGroupToggle);
                break;
            case "emergencytopup":
                sectionView = solo.getView(R.id.emergencyTopUpGroupToggle);
                break;
            default:
                break;
        }

        solo.clickOnView(sectionView);
        solo.sleep(2000);

    }


    /*
        General
     */

    public void clickOnToobarNavigationButton() {
        solo.clickOnImageButton(0);
    }


    private void clickOnActionBarMenuItem(String text) {
        //get the menu up
//        if (Build.MODEL.startsWith("CITAQ")) {
//            Log.d(TAG, "pressMenuItem 1");
//            solo.pressMenuItem(1);
//        }
        Log.d(TAG, "scrolling to top");
	/*
	solo.scrollToTop();
	Log.d(TAG, "send KEYCODE_MENU");
	solo.sendKey(KeyEvent.KEYCODE_MENU);
            if ( Build.MODEL.startsWith("CITAQ") ) {
		Log.d(TAG, "send MENU");
                solo.sendKey(Solo.MENU);
	    }
	*/

//    solo.sleep(1000);
        Log.d(TAG, "trying to click on " + text);

        //select the option
        //solo.clickOnMenuItem(text);
        clickOnActionMenu();
        solo.clickOnText(text);


    }


    public void clickOnActionMenu() {
        //solo.sendKey(Solo.MENU);
        int imgIdx = 0;
        Log.d(TAG, "current activity = " + solo.getCurrentActivity());


        if (solo.getCurrentActivity() instanceof ActivityLanding) {
            imgIdx = 1;
        }

        Log.d(TAG, "imgIdx = " + imgIdx);

        solo.clickOnImage(imgIdx);
    }

    public void logout() {

        String signoutText = solo.getCurrentActivity().getResources().getString(R.string.signOut);

        clickOnActionBarMenuItem(signoutText);

        if (solo.waitForActivity(ActivityLanding.class, 5000)) {
            Log.d(TAG, "User logged out");
        } else {
            fail("could not logout");
        }
//    solo.sleep(1000);

    }

    public void endShift() {

        String endShiftText = solo.getCurrentActivity().getResources().getString(R.string.end_shift);
        clickOnActionBarMenuItem(endShiftText);

        if (solo.waitForDialogToOpen(2000)) {
            Log.d(TAG, "end shift dialog open ");
        } else {
            fail("end shift dialog did not open");
        }
        solo.sleep(1000);

    }

    public void nfcRegistration() {

        //String nfcRegistration = solo.getCurrentActivity().getResources().getString(R.string.nfc_registration);
        //clickOnActionBarMenuItem(nfcRegistration);
        clickOnActionMenu();
        solo.clickOnText("NFC");
        solo.clickOnText("New Subscriber");

        solo.sleep(1000);

    }

    public void nfcEdit() {

        //String nfcRegistration = solo.getCurrentActivity().getResources().getString(R.string.nfc_registration);
        //clickOnActionBarMenuItem(nfcRegistration);
        clickOnActionMenu();
        solo.clickOnText("NFC");
        solo.clickOnText("Edit Subscriber");

        solo.sleep(1000);

    }

    public void nfcDeactivate() {

        //String nfcRegistration = solo.getCurrentActivity().getResources().getString(R.string.nfc_registration);
        //clickOnActionBarMenuItem(nfcRegistration);
        clickOnActionMenu();
        solo.clickOnText("NFC");
        solo.clickOnText("Cancel Subscriber");

        solo.sleep(1000);

    }

    public void nfcLostCard() {

        //String nfcRegistration = solo.getCurrentActivity().getResources().getString(R.string.nfc_registration);
        //clickOnActionBarMenuItem(nfcRegistration);
        clickOnActionMenu();
        solo.clickOnText("NFC");
        solo.clickOnText("Replace Lost Card");

        solo.sleep(1000);

    }

    public String nfcCellNo() {
        return "0711234561";
    }

    public String nfcLoyaltyCardNo() {
        return "21234567";
    }


    public void emergencyTopUp() {

        String endShiftText = solo.getCurrentActivity().getResources().getString(R.string.emergency_topUp);
        clickOnActionBarMenuItem(endShiftText);

        if (solo.waitForDialogToOpen(2000)) {
            Log.d(TAG, "end shift dialog open ");
        } else {
            fail("end shift dialog did not open");
        }
//    solo.sleep(1000);

    }

    public void busReprints() {

        String busReprints = solo.getCurrentActivity().getResources().getString(R.string.bus_tickets_reprints);
        clickOnActionBarMenuItem(busReprints);
//    solo.sleep(1000);

    }

    public void enterText(int fieldID, String text) {
        EditText editText = (EditText) solo.getView(fieldID);

        solo.clearEditText(editText);

        solo.enterText(editText, text);

//    solo.sleep(2000);
    }

    public void clickListItem(int listId, int textview, int index) {
        ListView ListView = (ListView) solo.getView(listId);
        View view = ListView.getChildAt(index);
        BluDroidTextView vouchertype = view.findViewById(textview);
        solo.clickOnView(vouchertype);
    }

    public void save() {
        Button button = (Button) solo.getView(R.id.save);
        solo.clickOnView(button);
    }

    public void clickButton(int buttonID) {
        Button button = (Button) solo.getView(buttonID);
        solo.clickOnView(button);


    }

    public void clickButton(String text) {
        solo.clickOnButton(text);
    }


    public String checkPreference(String key) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(solo.getCurrentActivity().getApplicationContext());

        String value;
        if (key.equals("deviceSerial"))
            value = sharedPreferences.getString(key, Build.SERIAL);
        else
            value = sharedPreferences.getString(key, "");
        return value;

    }


    public void clickOnDialogOption(String option) {
        solo.clickOnButton(option);
    }

    public void selectMenuItem(String name) {
        int index;
        switch (name) {
            default:
                index = 0;
                break;
            case "Airtime":
                index = 1;
                break;
            case "Data":
                index = 2;
                break;
            case "Electricity":
                index = 3;
                break;
            case "Transact":
                index = 4;
                break;
            case "Vouchers":
                index = 5;
                break;
            case "Tickets":
                index = 6;
                break;
            case "Rica":
                index = 7;
                break;
            case "Search":
                index = 8;
                break;
        }
        clickOnToobarNavigationButton();
        solo.clickInRecyclerView(index);
    }

    public void selectProvider(String providerName) {
        solo.clickOnText(providerName);

    }

    public void selectRicaTab(String name) {
        solo.clickOnText(name);

    }

    public void addToFavourites(String amount) {
        solo.clickLongOnText(amount);
    }

    public void removeFromFavourites(String amount) {
        solo.clickLongOnText(amount);
    }

    public void selectBillPaymentType(String type) {
        solo.clickOnText(type);


    }

    void setWifi(boolean enabled) {
        try {
            WifiManager wifiManager = (WifiManager) getInstrumentation()
                    .getTargetContext().getSystemService(Context.WIFI_SERVICE);
            wifiManager.setWifiEnabled(enabled);
        } catch (Exception ignored) {
            // don't interrupt test execution, if there
            // is no permission for that action
        }
    }

    public boolean findNfcFavourite(String text) {
        Log.d(TAG, "Searching for favourite: " + text);
        solo.scrollRecyclerViewToTop(0);
//    solo.scrollToTop();
        int idx = 0;
        while (idx++ < 3) {
            if (solo.searchText(text)) {
                return true;
            }
            solo.scrollDownRecyclerView(0);
//      solo.scrollDown();
            Log.d(TAG, "scrolling down");
        }
        return false;
    }

    public void selectDisplayRadioButton(String userLevel, String value) {
        RadioButton displayRadio = null;

        switch (userLevel) {
            case "Supervisor":
                switch (value) {
                    case "On":
                        displayRadio = (RadioButton) solo.getView(R.id.rbBalanceSuperOn);
                        break;
                    case "Warn":
                        displayRadio = (RadioButton) solo.getView(R.id.rbBalanceSuperWarn);
                        break;
                    case "Off":
                        displayRadio = (RadioButton) solo.getView(R.id.rbBalanceSuperOff);
                        break;
                }
                break;
            case "CashierPlus":
                switch (value) {
                    case "On":
                        displayRadio = (RadioButton) solo.getView(R.id.rbBalanceCplusOn);
                        break;
                    case "Warn":
                        displayRadio = (RadioButton) solo.getView(R.id.rbBalanceCplusWarn);
                        break;
                    case "Off":
                        displayRadio = (RadioButton) solo.getView(R.id.rbBalanceCplusOff);
                        break;
                }
                break;
            case "Cashier":
                switch (value) {
                    case "On":
                        displayRadio = (RadioButton) solo.getView(R.id.rbBalanceCashOn);
                        break;
                    case "Warn":
                        displayRadio = (RadioButton) solo.getView(R.id.rbBalanceCashWarn);
                        break;
                    case "Off":
                        displayRadio = (RadioButton) solo.getView(R.id.rbBalanceCashOff);
                        break;
                }
                break;
        }

        solo.clickOnView(displayRadio);
        Log.d(TAG, userLevel + "-" + value + " display setting selected");
    }

    public void selectProfitRadioButton(String userLevel, String value) {
        RadioButton profitRadio = null;

        switch (userLevel) {
            case "Supervisor":
                switch (value) {
                    case "On":
                        profitRadio = (RadioButton) solo.getView(R.id.rbProfitSuperOn);
                        break;
                    case "Off":
                        profitRadio = (RadioButton) solo.getView(R.id.rbProfitSuperOff);
                        break;
                }
                break;
            case "CashierPlus":
                switch (value) {
                    case "On":
                        profitRadio = (RadioButton) solo.getView(R.id.rbProfitCplusOn);
                        break;
                    case "Off":
                        profitRadio = (RadioButton) solo.getView(R.id.rbProfitCplusOff);
                        break;
                }
                break;
            case "Cashier":
                switch (value) {
                    case "On":
                        profitRadio = (RadioButton) solo.getView(R.id.rbProfitCashOn);
                        break;
                    case "Off":
                        profitRadio = (RadioButton) solo.getView(R.id.rbProfitCashOff);
                        break;
                }
                break;
        }

        solo.clickOnView(profitRadio);
        Log.d(TAG, userLevel + "-" + value + " profit setting selected");
    }
}
