package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;

/**
 * Created by NkosanaM on 3/3/2017.
 */

@RunWith(AndroidJUnit4.class)
public class DEV_00070_LeftMenu_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void testLeftMenu() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            Log.d(TAG, "Bring up the menu");

            solo.sleep(500);

            checks.selectMenuItem("Airtime");

            if (solo.waitForFragmentByTag("FragmentAirtime")) {
                Log.d(TAG, "Select Airtime Fragment");
            } else {
                fail("Select Airtime Fragment");
            }

            checks.selectMenuItem("Data");

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select Data Fragment");
            } else {
                fail("Select Data Fragment");
            }

            checks.selectMenuItem("Electricity");

            if (solo.waitForFragmentByTag("FragmentElectricity")) {
                Log.d(TAG, "Select Electricity Fragment");
            } else {
                fail("Select Electricity Fragment");
            }

            checks.selectMenuItem("Transact");

            if (solo.waitForFragmentByTag("FragmentTransact")) {
                Log.d(TAG, "Select Transact Fragment");
            } else {
                fail("Select Transact Fragment");
            }

            checks.selectMenuItem("Vouchers");

            if (solo.waitForFragmentByTag("FragmentVouchersMenu")) {
                Log.d(TAG, "Select Vouchers Fragment");
            } else {
                fail("Select Vouchers Fragment");
            }

            checks.selectMenuItem("Tickets");

            if (solo.waitForFragmentByTag("FragmentTickets")) {
                Log.d(TAG, "Select Tickets Fragment");
            } else {
                fail("Select Tickets Fragment");
            }

            checks.selectMenuItem("Rica");

            if (solo.waitForFragmentByTag("FragmentRicaLogin") || solo.waitForFragmentByTag("FragmentRicaMenu")) {
                Log.d(TAG, "Select Rica Fragment");
            } else {
                fail("Select Rica Fragment");
            }

            checks.selectMenuItem("Search");

            if (solo.waitForFragmentByTag("FragmentSearch")) {
                Log.d(TAG, "Select Search Fragment");
            } else {
                fail("Select Search Fragment");
            }


        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
