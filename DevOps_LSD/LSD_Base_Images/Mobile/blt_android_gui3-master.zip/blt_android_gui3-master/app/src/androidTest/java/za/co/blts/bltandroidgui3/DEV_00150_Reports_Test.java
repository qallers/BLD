package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import java.util.Calendar;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_PREVIEWS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

/**
 * Created by NkosanaM on 3/14/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00150_Reports_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
        changePreference(PREF_PRINT_PREVIEWS, PREF_FALSE);
    }

    @After
    public void after() {
        changePreference(PREF_PRINT_PREVIEWS, PREF_FALSE);
        tearDown();
    }

    @Test
    public void T001_Menu() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoReportsScreen();

            solo.sleep(500);

            if (solo.searchText("Reprint")) {
                Log.d(TAG, "Reprint report menu is on screen");
            } else {
                fail("Reprint report  menu is not on screen");
            }

            if (solo.searchText("Transaction List")) {
                Log.d(TAG, "Transaction List report menu is on screen");
            } else {
                fail("Transaction List report menu is not on screen");
            }

            if (solo.searchText("Account Status")) {
                Log.d(TAG, "Account Status report menu is on screen");
            } else {
                fail("Account Status report menu is not on screen");
            }

            if (solo.searchText("Profit Report")) {
                Log.d(TAG, "Profit report menu is on screen");
            } else {
                fail("Profit report menu is not on screen");
            }

            if (solo.searchText("Statement")) {
                Log.d(TAG, "Statement report Drawer menu is on screen");
            } else {
                fail("Statement report menu is not on screen");
            }

            if (solo.searchText("Invoicing")) {
                Log.d(TAG, "Invoicing report menu is on screen");
            } else {
                fail("Invoicing report  menu is not on screen");
            }

            if (solo.searchText("View Shift")) {
                Log.d(TAG, "View Shift menu is on screen");
            } else {
                fail("View Shift menu is not on screen");
            }

            if (solo.searchText("Daily Batch Report")) {
                Log.d(TAG, "Daily Batch Report menu is on screen");
            } else {
                fail("Daily Batch Report menu is not on screen");
            }

            if (BaseActivity.loginResponseMessage.getData().canDoEmergencyTopup()) {
                if (solo.searchText(getBaseActivity().getResources().getString(R.string.emergency_topUp))) {
                    Log.d(TAG, "Emergency Top up report menu is on screen");
                } else {
                    fail("Emergency Top up report menu is not on screen");
                }
            }

            //Now testing cashier plus with only 2 report otions [reprint and transaction list]

            checks.clickOnToobarNavigationButton();
            Log.d(TAG, "Exit reports screen");

            checks.logout();
            Log.d(TAG, "logout");

            if (checks.cashierPlusLogin(this)) {
                Log.d(TAG, "Login as a cashier plus");
            } else {
                fail("Could not login as a cashier plus");
            }

            checks.gotoReportsScreen();

            solo.sleep(500);

            if (solo.searchText("Reprint")) {
                Log.d(TAG, "Reprint report menu is on screen");
            } else {
                fail("Reprint report  menu is not on screen");
            }

            if (solo.searchText("Transaction List")) {
                Log.d(TAG, "Transaction List report menu is on screen");
            } else {
                fail("Transaction List report menu is not on screen");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T010_Reprint() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("reprint");
            Log.d(TAG, "Reprint Report section open");

            solo.waitForDialogToOpen();

            checks.clickOnToobarNavigationButton(); //added method

            solo.clickOnImageButton(1);
            Log.d(TAG, "Click on the From date selector");

            DatePicker datePicker = (DatePicker) solo.getView(R.id.datePicker);
            Calendar now = Calendar.getInstance();
            solo.setDatePicker(datePicker, now.get(Calendar.YEAR) - 1, now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));

            solo.clickOnText("Ok");
            Log.d(TAG, "From date selected");

            solo.sleep(500);

            solo.clickOnImageButton(2);
            Log.d(TAG, "Click on the From date selector");

            DatePicker datePicker2 = (DatePicker) solo.getView(R.id.datePicker);
            solo.setDatePicker(datePicker2, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));

            solo.clickOnText("Ok");
            Log.d(TAG, "TO date selected");

            solo.clickOnButton(0);
            Log.d(TAG, "Print the first reprint option");

            solo.sleep(5000);
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T020_TransactionList() {
        try {
            //Testing with Print Previews off
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("transactionlist");
            Log.d(TAG, "Transaction List Report section open");

            checks.enterText(R.id.transactionListdays, "3");
            Log.d(TAG, "Number of days included");

            checks.clickButton(R.id.printTransactionLst);
            Log.d(TAG, "Clicked on 'PRINT'");

//      solo.goBack();
            checks.clickOnToobarNavigationButton();
            Log.d(TAG, "Back to home page");

            //Testing with Print Previews on
            changePreference(PREF_PRINT_PREVIEWS, PREF_TRUE);
            Log.d(TAG, "Turned on Print Previews");

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("transactionlist");
            Log.d(TAG, "Transaction List Report section open");

            checks.enterText(R.id.transactionListdays, "3");
            Log.d(TAG, "Number of days included");

            solo.clickOnText("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.sleep(500);

            checks.clickButton(R.id.cancel_print_button);
            Log.d(TAG, "Clicked on 'CANCEL'");

            solo.clickOnText("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.sleep(500);

            checks.clickButton(R.id.do_print_button);
            Log.d(TAG, "Clicked on 'PRINT'");

            solo.sleep(5000);
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T030_DailyBatch() {
        try {
            //Testing with Print Previews off
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            solo.scrollToBottom();

            checks.toggleReports("dailybatch");
            Log.d(TAG, "Daily Batch Report section open");

            solo.clickOnImageButton(1);
            Log.d(TAG, "Click on the date selector");

            DatePicker datePicker = (DatePicker) solo.getView(R.id.dateDayPicker);
//      solo.setDatePicker(datePicker, 2018, 5, 6);
            Calendar now = Calendar.getInstance();
            solo.setDatePicker(datePicker, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
            solo.clickOnText("Ok");
            Log.d(TAG, "From date selected");

            solo.sleep(500);

            solo.clickOnButton(0);
            Log.d(TAG, "Print the report");

            solo.waitForDialogToClose();

//      solo.goBack();
            checks.clickOnToobarNavigationButton();
            Log.d(TAG, "Back to home page");

            //Testing with Print Previews on
            changePreference(PREF_PRINT_PREVIEWS, PREF_TRUE);
            Log.d(TAG, "Turned on Print Previews");

            solo.waitForText("Favourites");

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            solo.scrollToBottom();

            solo.sleep(500);

            checks.toggleReports("dailybatch");
            Log.d(TAG, "Daily Batch Report section open");

            solo.clickOnImageButton(1);
            Log.d(TAG, "Click on the date selector");

            datePicker = (DatePicker) solo.getView(R.id.dateDayPicker);
//      solo.setDatePicker(datePicker, 2018, 5, 6);
            solo.setDatePicker(datePicker, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
            solo.clickOnText("Ok");
            Log.d(TAG, "From date selected");

            solo.clickOnText("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.sleep(500);

            checks.clickButton(R.id.cancel_print_button);
            Log.d(TAG, "Clicked on 'CANCEL'");

            solo.clickOnText("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.sleep(500);

            checks.clickButton(R.id.do_print_button);
            Log.d(TAG, "Clicked on 'PRINT'");

            solo.sleep(5000);
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T040_AccountStatus() {
        try {
            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }
            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("accountstatus");
            Log.d(TAG, "Account Status Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 1);
            Log.d(TAG, "Select an account");

            solo.pressSpinnerItem(0, 0);
            Log.d(TAG, "Select a different account");

            solo.clickOnButton("Print");
            Log.d(TAG, "Print Account Status report");

            solo.sleep(5000);
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T050_ProfitReport() {
        try {
            //Testing with Print Previews off
            Log.d(TAG, "Turned off Print Previews");

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("profitreport");
            Log.d(TAG, "Profit Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 1);
            Log.d(TAG, "Selected account");

            profitReportByDays("3");
            Log.d(TAG, "Entered number of days");

            solo.clickOnButton("Print");
            Log.d(TAG, "Clicked on 'PRINT'");

            solo.scrollToTop();

            profitReportByShift(1, 1);
            Log.d(TAG, "Selected shift");

            solo.clickOnButton("Print");
            Log.d(TAG, "Clicked on 'PRINT'");

//      solo.goBack();
            checks.clickOnToobarNavigationButton();
            Log.d(TAG, "Back to home page");

            //Testing with Print Previews on
            changePreference(PREF_PRINT_PREVIEWS, PREF_TRUE);
            Log.d(TAG, "Turned on Print Previews");

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("profitreport");
            Log.d(TAG, "Profit Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 1);
            Log.d(TAG, "Selected account");

            //Profit report by days
            profitReportByDays("3");
            Log.d(TAG, "Entered number of days");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked on 'CANCEL'");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Print");
            Log.d(TAG, "Clicked on 'PRINT'");

            solo.clickOnImageButton(0);
            Log.d(TAG, "Closed reports");

            //Profit report by shift
            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("profitreport");
            Log.d(TAG, "Profit Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 1);
            Log.d(TAG, "Selected account");

            profitReportByShift(1, 1);
            Log.d(TAG, "Selected shift");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.sleep(500);

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked on 'CANCEL'");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Print");
            Log.d(TAG, "Clicked on 'PRINT'");

            solo.sleep(5000);
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    private void profitReportByDays(String days) {
        EditText daysEditText = (EditText) solo.getView(R.id.profitReportNumDays);
        solo.enterText(daysEditText, days);
    }

    private void profitReportByShift(int spinner, int item) {
        RadioButton reportByShift = (RadioButton) solo.getView(R.id.radio_shift);
        solo.clickOnView(reportByShift);
        solo.pressSpinnerItem(spinner, item);
    }

    @Test
    public void T060_StatementReport() {
        try {
            //Testing with Print Previews off
            Log.d(TAG, "Turned off Print Previews");

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("statement");
            Log.d(TAG, "Account Status Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 0);
            Log.d(TAG, "Select an account");

            EditText daysEditText = (EditText) solo.getView(R.id.statementNumDays);
            solo.enterText(daysEditText, "5");
            Log.d(TAG, "Number of days entered");

            solo.clickOnButton("Print");
            Log.d(TAG, "Print Statement report");

//      solo.goBack();
            checks.clickOnToobarNavigationButton();
            Log.d(TAG, "Back to home page");

            //Testing with Print Previews on
            changePreference(PREF_PRINT_PREVIEWS, PREF_TRUE);
            Log.d(TAG, "Turned on Print Previews");

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("statement");
            Log.d(TAG, "Account Status Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 0);
            Log.d(TAG, "Select an account");

            daysEditText = (EditText) solo.getView(R.id.statementNumDays);
            solo.enterText(daysEditText, "5");
            Log.d(TAG, "Number of days entered");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked on 'CANCEL'");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Print");
            Log.d(TAG, "Clicked on 'PRINT'");

            solo.sleep(5000);

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T070_InvoicingReport() {
        try {
            //Testing with Print Previews off
            Log.d(TAG, "Turned off Print Previews");

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("invoicing");
            Log.d(TAG, "Invoicing Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 0);
            Log.d(TAG, "Select an account");

            solo.pressSpinnerItem(1, 1);
            Log.d(TAG, "Select a Shift");

            solo.clickOnButton("Print");
            Log.d(TAG, "Print Invoicing report");

//      solo.goBack();
            checks.clickOnToobarNavigationButton();
            Log.d(TAG, "Back to home page");

            changePreference(PREF_PRINT_PREVIEWS, PREF_TRUE);
            Log.d(TAG, "Turned on Print Previews");

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("invoicing");
            Log.d(TAG, "Invoicing Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 0);
            Log.d(TAG, "Select an account");

            solo.pressSpinnerItem(1, 1);
            Log.d(TAG, "Select a Shift");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked on 'CANCEL'");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Print");
            Log.d(TAG, "Clicked on 'PRINT'");

            solo.sleep(5000);

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T080_ViewShiftReport() {
        try {
            //Testing with Print Previews off
            Log.d(TAG, "Turned off Print Previews");

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("viewshift");
            Log.d(TAG, "Invoicing Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 1);
            Log.d(TAG, "Select a Shift");

            solo.clickOnButton("Print");
            Log.d(TAG, "Print View Shift report");

//      solo.goBack();
            checks.clickOnToobarNavigationButton();
            Log.d(TAG, "Back to home page");

            //Testing with Print Previews on

            changePreference(PREF_PRINT_PREVIEWS, PREF_TRUE);
            Log.d(TAG, "Turned on Print Previews");

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            checks.toggleReports("viewshift");
            Log.d(TAG, "Invoicing Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 1);
            Log.d(TAG, "Select a Shift");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked on 'CANCEL'");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Print");
            Log.d(TAG, "Clicked on 'PRINT'");

            solo.sleep(5000);
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T090_EmergencyTopUp_Test() {
        try {
            //Testing with Print Previews off
            Log.d(TAG, "Turned off Print Previews");

            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            solo.scrollToBottom();

            solo.sleep(500);

            checks.toggleReports("emergencytopup");
            Log.d(TAG, "Emergency Top Up Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 0);
            Log.d(TAG, "Select an account");

            checks.enterText(R.id.ETUNumDays, "5");
            Log.d(TAG, "Number of days entered");


            solo.clickOnButton("Print");
            Log.d(TAG, "Clicked on 'PRINT'");

//      solo.goBack();
            checks.clickOnToobarNavigationButton();
            Log.d(TAG, "Back to home page");

            //Testing with Print Previews on

            changePreference(PREF_PRINT_PREVIEWS, PREF_TRUE);
            Log.d(TAG, "Turned on Print Previews");

            checks.gotoReportsScreen();
            Log.d(TAG, "Goto reports Screen");

            solo.scrollToBottom();

            solo.sleep(500);

            checks.toggleReports("emergencytopup");
            Log.d(TAG, "Emergency Top Up Report section open");

            solo.sleep(500);

            solo.pressSpinnerItem(0, 0);
            Log.d(TAG, "Select an account");

            checks.enterText(R.id.ETUNumDays, "5");
            Log.d(TAG, "Number of days entered");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Cancel");
            Log.d(TAG, "Clicked on 'CANCEL'");

            solo.clickOnButton("Preview");
            Log.d(TAG, "Clicked on 'PREVIEW'");

            solo.clickOnButton("Print");
            Log.d(TAG, "Clicked on 'PRINT'");

            solo.sleep(5000);
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

}
