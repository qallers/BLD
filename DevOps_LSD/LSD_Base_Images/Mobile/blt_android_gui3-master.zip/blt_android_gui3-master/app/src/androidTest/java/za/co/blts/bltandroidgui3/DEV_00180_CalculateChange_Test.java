package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.View;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_BASKET;

/**
 * Created by NkosanaM on 3/14/2017.
 */

@RunWith(AndroidJUnit4.class)
public class DEV_00180_CalculateChange_Test extends BaseTestPurchase {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
        changePreference(PREF_USE_BASKET, PREF_TRUE);
    }

    @After
    public void after() {
        changePreference(PREF_USE_BASKET, PREF_FALSE);
        tearDown();
    }

    @Test
    public void testPurchaseVodaDataPrintVoucher() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            selectVoucherTypeData();

            if (solo.waitForFragmentByTag("FragmentData")) {
                Log.d(TAG, "Select FragmentData Fragment");
            } else {
                fail("Select FragmentData Fragment");
            }

            selectProviderVoda();
            Log.d(TAG, "Vodacom  MENU selected");

            solo.clickOnText("15MB");
            Log.d(TAG, "50MB data voucher selected");

            checkStock();
            Log.d(TAG, " Voucher confirmed");

            solo.clickOnView(solo.getView(R.id.calculator));
            Log.d(TAG, "Calculate change screen brought up.");

            checks.clickListItem(R.id.transactionList, R.id.txtVoucherType, 0);
            Log.d(TAG, "50MB Vodacom data bundle selected");

            checks.enterText(R.id.edt_payment, "15");
            Log.d(TAG, "R15 payment amount entered");

            checks.enterText(R.id.edt_payment, "30");
            Log.d(TAG, "Payment amount updated");

            View bottomFrame = solo.getView(R.id.bottomFrame);
            bottomFrame.scrollBy(0, 60);

            solo.clickOnImageButton(4);

            if (solo.waitForDialogToOpen()) {
                Log.d(TAG, "Telkom C4C button clicked");
                Log.d(TAG, "About to purchase Telkom C4C voucher");
                checkStock();
            } else {
                Log.d(TAG, "User does not have C4C permissions.");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
