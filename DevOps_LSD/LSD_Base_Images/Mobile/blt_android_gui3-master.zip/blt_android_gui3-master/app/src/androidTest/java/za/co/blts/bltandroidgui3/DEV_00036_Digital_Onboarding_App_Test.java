package za.co.blts.bltandroidgui3;

import android.os.Build;
import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static junit.framework.TestCase.fail;

/**
 * Created by BoitshokoM on 3/3/2020.
 */
@RunWith(AndroidJUnit4.class)
public class DEV_00036_Digital_Onboarding_App_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }


    @Test
    public void testDigitalOnboardingApp() {

        try {

            checks.gotoDigitalOnboarding();
            Log.d(TAG, "Clicked on 'Download Digital Onboarding App..'");

            solo.waitForDialogToOpen();

            solo.clickOnText("LATER");
            Log.d(TAG, "Dismissed Digital Onboarding App dialog...");

            checks.gotoDigitalOnboarding();
            Log.d(TAG, "Clicked on 'Download Digital Onboarding App..'");

            solo.waitForDialogToOpen();

            solo.clickOnText("NOW");
            Log.d(TAG, "Downloading Digital Onboarding App...");
            //Digital Onboarding App link not accessible on dev, so cannot do this test

            if (Build.MODEL.startsWith("P1"))
                Log.d(TAG, "Opened the Sunmi App Store...");
            else{
                solo.waitForDialogToClose();
                Log.d(TAG, "Downloaded Digital Onboarding App...");
            }


            //solo.clickOnText("INSTALL");



        } catch (Exception ex) {
            fail("Exception " + ex.toString());
        }
    }


}
