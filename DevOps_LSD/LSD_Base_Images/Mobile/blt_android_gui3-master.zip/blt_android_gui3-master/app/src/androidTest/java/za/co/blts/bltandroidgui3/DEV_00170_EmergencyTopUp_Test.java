package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.KeyEvent;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;

/**
 * Created by BoitshokoM on 7/3/2018.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00170_EmergencyTopUp_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_EmergencyTopUp_Test() {
        try {


            if (checks.superVisorLogin(this)) {
                Log.d(TAG, "Login as a supervisor");
            } else {
                fail("Could not login as a supervisor");
            }

            checks.emergencyTopUp();
            Log.d(TAG, "Emergency Top Up menu option selected");

            if (solo.searchText("Amount Available")) {
                Log.d(TAG, "search for amoint available");


                solo.pressSpinnerItem(0, 0);
                Log.d(TAG, "Select an account");


                checks.enterText(R.id.edt_amount, "100");
                Log.d(TAG, "Amount requested entered");

                solo.clickOnButton(1);
                Log.d(TAG, "Clicked the 'CONTINUE' button");

                solo.clickOnCheckBox(0);
                Log.d(TAG, "Accepted terms and conditions");

                solo.clickOnButton(2);
                Log.d(TAG, "Clicked the 'ACCEPT' button");

                if (solo.waitForText("Confirming Emergency Top Up")) {

                    Log.d(TAG, "Voucher purchase confirmation dismissed");
                    solo.waitForText("Emergency Top Up Successful");
                } else {
                    fail("Voucher purchase confirmation NOT dismissed");
                }

                solo.sendKey(KeyEvent.KEYCODE_BACK);
                Log.d(TAG, "back button disabled");
            } else if (solo.searchText("You currently do not qualify")) {
                fail("Do not qualify for emergency topup");
            } else {
                solo.clickOnText("Cancel");
                Log.d(TAG, "Cancel");
                solo.clickOnText("Cancel");
                Log.d(TAG, "Cancel to exit Emergency topup menu");
                // checks.logout();
            }


        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
