package za.co.blts.bltandroidgui3;

import android.os.Build;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import static junit.framework.TestCase.fail;


/**
 * Created by NkosanaM on 2/21/2017.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class DEV_00060_AccountBalanceProfit_Test extends BaseTest {

    private final String TAG = this.getClass().getSimpleName();

    @Rule
    public ActivityTestRule<ActivityLanding> rule = new ActivityTestRule<>(ActivityLanding.class);

    @Before
    public void before() throws Exception {
        setUp(rule.getActivity());
    }

    @After
    public void after() {
        tearDown();
    }

    @Test
    public void T001_TestSupervisor() {
        try {
            Log.e("ProfDisp", "serial: " + Build.SERIAL);
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.gotoUserSettings();
            Log.d(TAG, "Go to Device Settings");

            checks.toggleDeviceSetup("account_balance");
            Log.d(TAG, "Account Balance Section open");

            solo.scrollDown();
            checks.selectDisplayRadioButton("Supervisor", "On");
            checks.selectDisplayRadioButton("CashierPlus", "Warn");
            checks.selectDisplayRadioButton("Cashier", "Off");
            checks.selectProfitRadioButton("Supervisor", "On");
            checks.selectProfitRadioButton("CashierPlus", "Off");
            checks.selectProfitRadioButton("Cashier", "Off");
            Log.d(TAG, "Profit and display settings selected");

            EditText amt = (EditText) solo.getView(R.id.lowBalanceAmountSetting);
            solo.clearEditText(amt);
            solo.enterText(amt, "100");
            Log.d(TAG, "Entered low balance amount");

            solo.clickOnButton("Save");
            Log.d(TAG, "Clicked the 'SAVE' button");

            if (solo.searchText("Account"))
                Log.d(TAG, "Account displayed");
            else
                fail("Account not displayed");

            if (solo.searchText("Profit"))
                Log.d(TAG, "Profit displayed");
            else
                fail("Profit not displayed");



        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T002_TestCashierPlus() {
        try {
            if (checks.cashierPlusLogin(this)) {
                Log.d(TAG, "Login as a Cashier Plus");
            } else {
                fail("Could not login as a Cashier Plus");
            }

            if (solo.searchText("BALANCE OK"))
                Log.d(TAG, "BALANCE OK displayed");
            else
                fail("BALANCE OK not displayed");

            TextView profit = (TextView) solo.getView(R.id.txtAccountProfit);
            if (profit.getVisibility() == View.GONE)
                Log.d(TAG, "Profit not displayed");
            else
                fail("Profit displayed");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T003_TestCashier() {
        try {
            if (checks.cashierLogin(this)) {
                Log.d(TAG, "Login as a Cashier");
            } else {
                fail("Could not login as a Cashier");
            }

            TextView balance = (TextView) solo.getView(R.id.txtAccountBalance);
            if (balance.getVisibility() == View.GONE)
                Log.d(TAG, "Balance not displayed");
            else
                fail("Balance displayed");

            TextView profit = (TextView) solo.getView(R.id.txtAccountProfit);
            if (profit.getVisibility() == View.GONE)
                Log.d(TAG, "Profit not displayed");
            else
                fail("Profit displayed");


        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T004_RestoreSettings() {
        try {
            if (checks.validLogin()) {
                Log.d(TAG, "Login as a user");
            } else {
                fail("Could not login as a user");
            }

            checks.gotoUserSettings();
            Log.d(TAG, "Go to Device Settings");

            checks.toggleDeviceSetup("account_balance");
            Log.d(TAG, "Account Balance Section open");

            solo.scrollDown();
            checks.selectDisplayRadioButton("Supervisor", "On");
            checks.selectDisplayRadioButton("CashierPlus", "On");
            checks.selectDisplayRadioButton("Cashier", "On");
            checks.selectProfitRadioButton("Supervisor", "On");
            checks.selectProfitRadioButton("CashierPlus", "Off");
            checks.selectProfitRadioButton("Cashier", "Off");
            Log.d(TAG, "Profit and display settings restored");

            EditText amt = (EditText) solo.getView(R.id.lowBalanceAmountSetting);
            solo.clearEditText(amt);
            solo.enterText(amt, "1000.00");
            Log.d(TAG, "Restored low balance amount");

            solo.clickOnButton("Save");
            Log.d(TAG, "Clicked the 'SAVE' button");

        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T030_CashierChangeSettings() {
        try {
            if (checks.cashierLogin(this)) {
                Log.d(TAG, "Login as a Cashier");
            } else {
                fail("Could not login as a Cashier");
            }

            checks.clickOnActionMenu();

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.device_settings))) {
                fail("Cashier Allowed To Change Account Settings");
            } else {
                Log.d(TAG, "Cashier Not Allowed To Change Account Settings");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }

    @Test
    public void T040_CashierPlusChangeSettings() {
        try {
            if (checks.cashierPlusLogin(this)) {
                Log.d(TAG, "Login as a CashierPlus");
            } else {
                fail("Could not login as a CashierPlus");
            }

            checks.clickOnActionMenu();

            if (solo.searchText(getBaseActivity().getResources().getString(R.string.device_settings))) {
                fail("CashierPlus Allowed To Change Account Settings");
            } else {
                Log.d(TAG, "CashierPlus Not Allowed To Change Account Settings");
            }
        } catch (Exception ex) {
            fail("Exception ex " + ex.toString());
        }
    }
}
