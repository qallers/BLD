package za.co.blts.bltandroidgui3;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

/**
 * Created by NkosanaM on 7/14/2017.
 */

class RicaRegisterInfopagerAdapter extends FragmentPagerAdapter {

    private Fragment[] f = new Fragment[getCount()];

    public RicaRegisterInfopagerAdapter(FragmentManager fm) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
    }


    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                f[position] = new FragmentRicaConsumerInfo();
                break;
            case 1:
                f[position] = new FragmentRicaAddressInfo();
                break;
            case 2:
                f[position] = new FragmentRicaSimRegistration();
                break;
            default:
                f[position] = new Fragment();
                break;
        }
        return f[position];
    }

    @Override
    public int getCount() {
        return 3;
    }

    public Fragment getItemIndex(int position) {
        return f[position];
    }
}