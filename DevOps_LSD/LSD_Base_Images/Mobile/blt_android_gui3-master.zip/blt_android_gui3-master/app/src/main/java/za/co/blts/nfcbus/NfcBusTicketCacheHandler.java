package za.co.blts.nfcbus;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Calendar;
import java.util.Date;

import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusCheckoutResponseDetailMessage;

public class NfcBusTicketCacheHandler {
    private final String TAG = this.getClass().getSimpleName();
    private final long TICKET_CANCEL_EXPIRY = 12 * 60 * 60 * 1000; //12 Hours

    private File cacheDir;

    public NfcBusTicketCacheHandler(File cacheDir) {
        this.cacheDir = cacheDir;
    }

    public NfcBusCancelTicket getTicketFromCache(Ticket ticket) {
        String filename = ticket.getCompanyId() + "_" + ticket.getTicketId() + ".txt";
        File cache = new File(cacheDir.getPath() + "/" + filename);
        if (cache.exists()) {
            NfcBusCancelTicket cancelTicket = readCancelTicketFromFile(cache);
            Log.v(TAG, "read from cache: " + cancelTicket.toString());
            return cancelTicket;
        }
        return null;
    }

    public NfcBusCancelTicket getTicketFromCache(long companyId, long ticketId) {
        String filename = companyId + "_" + ticketId + ".txt";
        File cache = new File(cacheDir.getPath() + "/" + filename);
        if (cache.exists()) {
            NfcBusCancelTicket cancelTicket = readCancelTicketFromFile(cache);
            Log.v(TAG, "read from cache: " + cancelTicket.toString());
            return cancelTicket;
        }
        return null;
    }

    public void deleteTicketFromCache(String ticketId, String companyId) {
        String filename = companyId + "_" + ticketId + ".txt";
        File cache = new File(cacheDir.getPath() + "/" + filename);
        if (cache.exists()) {
            Log.v(TAG, "removed from cache: " + filename);
            cache.delete();
        }
    }

    public void removeExpiredCaches() {
        File[] files = cacheDir.listFiles();
        for (File f : files) {
            if (isExpired(f)) {
                Log.d(TAG, "deleting expired file: " + f.getAbsolutePath());
                f.delete();
            }
        }
    }

    public void removeCaches() {
        File[] files = cacheDir.listFiles();
        for (File f : files) {
            Log.d(TAG, "deleting expired file: " + f.getAbsolutePath());
            f.delete();
        }
    }

    private NfcBusCancelTicket readCancelTicketFromFile(File f) {
        try {
            NfcBusCancelTicket ticket = null;
            Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").serializeNulls().create();

            BufferedReader bufferedReader = new BufferedReader(new FileReader(f));
            String line;
            if ((line = bufferedReader.readLine()) != null) {
                ticket = gson.fromJson(line, NfcBusCancelTicket.class);
            }
            bufferedReader.close();

            return ticket;
        } catch (Exception e) {
            return null;
        }
    }

    private NfcBusCancelTicket createCancelTicket(NfcBusCheckoutResponseDetailMessage message) {
        try {
            NfcBusCancelTicket ticket = new NfcBusCancelTicket();
            ticket.setCompanyId(String.valueOf(message.getTicket().getCompanyId()));
            ticket.setTransRef(message.getTransRef());
            ticket.setTransId(message.getTransactionId());
            ticket.setTicketId(message.getTicketId());
            ticket.setRefId(message.getTransaction().getReferenceId());
            return ticket;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void cacheCancelTicket(NfcBusCheckoutResponseDetailMessage message) {
        NfcBusCancelTicket ticket = createCancelTicket(message);
        if (ticket != null) {
            Log.v(TAG, "caching " + ticket.toString());
            try {
                String filename = ticket.getCompanyId() + "_" + ticket.getTicketId() + ".txt";
                File cache = new File(cacheDir.getPath() + "/" + filename);
                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
                bufferedWriter.write(ticket.toString());
                bufferedWriter.flush();
                bufferedWriter.close();
                Log.v(TAG, "caching successful");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isExpired(File file) {
        //ticket cannot be cancelled after 12 hours, or if sale was from previous day (will already be invoiced)
        if (System.currentTimeMillis() - file.lastModified() > TICKET_CANCEL_EXPIRY) {
            return true;
        }

        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        Date today = c.getTime();

        Date fileDate = new Date(file.lastModified());
        return fileDate.before(today);
    }


}
