package za.co.blts.nfcbus;

public class Stop implements Comparable<Stop> {
    private long id;
    private String name;

    public Stop() {
    }

    public Stop(long id, String name) {
        this.id = id;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int compareTo(Stop o) {
        return this.getName().compareTo(o.getName());
    }

    @Override
    public String toString() {
        return "{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
