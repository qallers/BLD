package za.co.blts.nfcbus;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import za.co.blts.bltandroidgui3.R;


class FareListAdapter extends ArrayAdapter<Fare> {
    private final String TAG = this.getClass().getSimpleName();

    private Context context;

    public FareListAdapter(Context context, int layoutResourceId, List<Fare> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.context = context;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final Fare fare = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.layout_nfc_fare, parent, false);
        }

        ((TextView) convertView.findViewById(R.id.txtFare)).setText(fare.getName());
        ((TextView) convertView.findViewById(R.id.txtPeriod)).setText("Period: " + fare.getPeriod());
        ((TextView) convertView.findViewById(R.id.txtDays)).setText("Days: " + fare.getWeekdays());
        ((TextView) convertView.findViewById(R.id.txtPrice)).setText("Price: " + fare.getPrice());

        ImageView imgSelect = convertView.findViewById(R.id.imgSelect);
        imgSelect.setImageResource(fare.isSelected() ? R.drawable.ic_checkbox_on : R.drawable.ic_checkbox_off);

        return convertView;
    }


}
