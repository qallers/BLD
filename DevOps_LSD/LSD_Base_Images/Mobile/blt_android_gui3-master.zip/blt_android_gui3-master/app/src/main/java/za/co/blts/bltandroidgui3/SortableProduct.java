package za.co.blts.bltandroidgui3;

import java.util.Comparator;

import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProductMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProviderMessage;

/**
 * Created by WarrenM1 on 2017/07/26.
 */

class SortableProduct extends BillPaymentsResponseProductMessage implements Comparable<BillPaymentsResponseProductMessage> {

    private BillPaymentsResponseProviderMessage provider;

    public SortableProduct(BillPaymentsResponseProductMessage product, BillPaymentsResponseProviderMessage provider) {
        super();
        this.setVerify(product.getVerify());
        this.setFullAmount(product.getFullAmount());
        this.setAdditionalFields(product.getAdditionalFields());
        this.setCategory(product.getCategory());
        this.setRegion(product.getRegion());
        this.setName(product.getName());
        this.setId(product.getId());
        this.provider = provider;
        this.setLogoId(product.getLogoId());
    }

    public SortableProduct(String productName) {
        super();
        this.setVerify("");
        this.setFullAmount("");
        this.setAdditionalFields("");
        this.setCategory("Bill Payment");
        this.setRegion("");
        this.setName(productName);
        this.setId("");
    }

    public BillPaymentsResponseProviderMessage getProvider() {
        return provider;
    }

    public String getProductName() {
        return this.getName();
    }


    public int compareTo(BillPaymentsResponseProductMessage product) {
        return this.getName().toLowerCase().compareTo(product.getName().toLowerCase());

    }

    public static Comparator<SortableProduct> ProductComparator = new Comparator<SortableProduct>() {
        public int compare(SortableProduct product1, SortableProduct product2) {
            return product1.compareTo(product2);
        }
    };
}
