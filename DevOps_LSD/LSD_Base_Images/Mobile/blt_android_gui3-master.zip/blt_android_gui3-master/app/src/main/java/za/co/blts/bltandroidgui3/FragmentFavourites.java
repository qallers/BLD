package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import za.co.blt.consumer.loyalty.api.service.model.response.CompleteConsumerProfile;
import za.co.blt.consumer.loyalty.api.service.model.response.Error;
import za.co.blt.interfaces.external.messages.common.response.CommonResponseAccountMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseProductMessage;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidHeading;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.MAX_ACCOUNT_DISPLAY;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_ACCOUNT_BALANCE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_ACCOUNT_DETAILS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BALANCE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BALANCEAMT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BALANCE_DISPLAY_ENABLED;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEF_ACCOUNT_INDEX;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DISPLAY_BALANCE1;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOW_BALANCE_AMOUNT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PROFIT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PROFIT_DISPLAY_ENABLED;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;

/**
 * Created by warrenm on 2016/10/03.
 */

public class FragmentFavourites extends FavouritesRecycler implements NeedsAEONResults {

    private final String TAG = this.getClass().getSimpleName();
    private boolean consumerActive = false;

    private BluDroidHeading noFavourites;
    private BluDroidAlertDialog alert = null;
    private LinearLayout layAccountDisplay;
    private BluDroidVolley bluDroidVolley;

    public FragmentFavourites() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getBaseActivity().crashLog("Activity", getBaseActivity().getClass().getSimpleName());
        getBaseActivity().crashLog("Fragment", this.getClass().getSimpleName());
        getBaseActivity().crashLog("Progress", null);
        getBaseActivity().crashLog("Dialog", null);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_favourites, container, false);
        recycler = rootView.findViewById(R.id.bluRecycler);

        layAccountDisplay = rootView.findViewById(R.id.layAccountDisplay);

        noFavourites = rootView.findViewById(R.id.noFavourites);

        favouritesSize = 12;

        getBaseActivity().hideKeyboard();
        bluDroidVolley = BluDroidVolley.getInstance(getBaseActivity());

        return rootView;
    }

    @Override
    public void onDestroy() {
        if (bluDroidVolley != null) bluDroidVolley.cancelAll();
        super.onDestroy();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        Log.d(TAG, "onActivityCreated");
        super.onActivityCreated(savedInstanceState);
        getBaseActivity().hideKeyboard();

        if (!BaseActivity.loadFavouritesFirstTime) {
            populateScreen();
        }

        final BaseActivity baseActivity = (BaseActivity) getActivity();

        getBaseActivity().toolbar.removeAppLogo();

        if (BaseActivity.consumerProfile != null && Integer.parseInt(BaseActivity.consumerProfile.getProfileId()) > 0) {
            consumerActive = true;
        }

        if (consumerActive) {
            baseActivity.updatePreference(PREF_SKIN, getString(R.string.skinNFC));
            baseActivity.setTheme(R.style.NFCTheme);
            baseActivity.configureSkin();
            getBaseActivity().toolbar.setup();

            doRequest();
        } else {
            populateScreen();
        }

        menuFragmentClickListener();
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.e("ProfDisp", "onResume");
        String title = getActivity().getResources().getString(R.string.favourites);

        getBaseActivity().logoId = null;

        updateBalanceAndProfitDisplayed();

        int accountIndex = Integer.parseInt(getBaseActivity().getPreference(PREF_DEF_ACCOUNT_INDEX));

        if (accountIndex != 0) {

            if (getBaseActivity().getPreference(PREF_DISPLAY_BALANCE1).equalsIgnoreCase("display")) {
                getActivity().setTitle(getResources().getString(R.string.currency) + getPreference(PREF_ACCOUNT_BALANCE));

            } else if (getBaseActivity().getPreference(PREF_DISPLAY_BALANCE1).equalsIgnoreCase("warn")) {

                float lowBalanceWarningAmount = Float.parseFloat(getBaseActivity().getPreference(PREF_LOW_BALANCE_AMOUNT));
                float accountBalance = Float.parseFloat(getBaseActivity().getPreference(PREF_ACCOUNT_BALANCE));

                int retVal = Double.compare(lowBalanceWarningAmount, accountBalance);
                if (retVal >= 0) {
                    getActivity().setTitle("Low Balance");
                    getBaseActivity().toolbar.setWarnIcon();
                    getBaseActivity().toolbar.setTextColorWarning();
                } else {
                    getBaseActivity().toolbar.setTextColorWhite();
                    getActivity().setTitle(title);
                }
            } else {
                getActivity().setTitle(title);
            }

        } else {
            getActivity().setTitle(title);
        }
    }

    public void populateScreen() {

        if (!consumerActive) {
            Map<String, ArrayList<VoucherListResponseProductMessage>> map = vu.getAllVouchers();

            getBaseActivity().favouritesStockIDs.add("0");

            for (String key : map.keySet()) {
                ArrayList<VoucherListResponseProductMessage> products = map.get(key);
                for (VoucherListResponseProductMessage product : products) {
                    Log.d(TAG, product.toString());
                    if (!getBaseActivity().favouritesStockIDs.contains(product.getText())) {
                        getBaseActivity().favouritesStockIDs.add(product.getText());
                    }
                }
            }

            if (BaseActivity.voucherAuthenticationResponseMessage != null) {
                if (BaseActivity.voucherAuthenticationResponseMessage.getData().getTransTypes().contains("C4C_Voucher")) {
                    getBaseActivity().favouritesStockIDs.add("C4C");
                }
            }

            setupRecycler();
            if (favouritesSize > 0) {
                noFavourites.setVisibility(View.GONE);
            } else {
                noFavourites.setVisibility(View.VISIBLE);
            }
        } else {
            setupRecycler(); // this will be based in the transactions from the Loyalty Server
            getBaseActivity().setTheme(R.style.NFCTheme);
        }
    }

    @Override
    public boolean onBackPressed() {
        return false;
    }

    //----------------------------------------------------------------------------------------------
    private void doRequest() {
        JsonObjectRequest getFavourites = new JsonObjectRequest(Request.Method.GET,
                BaseActivity.loyaltyServerBaseUrl + "complete/" + BaseActivity.cell_or_card_number, null, // URL
                createReqSuccessListener(),
                createReqErrorListener());
        getBaseActivity().createProgress(R.string.nfc_get_customer_profile_favourites);
        bluDroidVolley.addRequestApiGateway(getFavourites); // make sure that this is not null
    }

    //----------------------------------------------------------------------------------------------
    private Response.Listener<JSONObject> createReqSuccessListener() {
        return new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                getBaseActivity().dismissProgress();

                Log.d(TAG, response.toString());
                BaseActivity.completeConsumerProfile = new Gson().fromJson(response.toString(), CompleteConsumerProfile.class);
                populateScreen();
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    private Response.ErrorListener createReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.e("error: " + error);
                String message;
                if (getBaseActivity() != null) {
                    getBaseActivity().dismissProgress();
                    VolleyLog.e("error.getMessage(): " + error.getMessage());
                    VolleyLog.e("error.networkResponse: " + error.networkResponse);
                    String errorMessage;
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            errorMessage = new String(error.networkResponse.data, StandardCharsets.UTF_8); // for UTF-8 encoding
                            VolleyLog.e("errorMessage: " + errorMessage);
                            Error error1 = new Gson().fromJson(errorMessage, Error.class);
                            message = error1.getMessage();
                        } catch (Exception e) {
                            e.printStackTrace();
                            message = "An unknown error occurred";
                        }
                    } else {
                        message = "Could not connect";
                    }


                    handleResponseMessage(false, message); // propagate the server error message
                }
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    private void handleResponseMessage(final boolean responseIsSuccessful, String message) {
        String messageTitle;
        if (responseIsSuccessful) {
            messageTitle = "Successful";
        } else {
            messageTitle = "Failed";
        }

        alert = getBaseActivity().createAlertDialog(messageTitle, message);
        alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (responseIsSuccessful)
                    getBaseActivity().gotoFragment(new FragmentFavourites(), "FragmentFavourites");
                else
                    alert.dismiss(); // retry
            }
        });
    }

    private void updateBalanceAndProfitDisplayed() {
        boolean enableBalanceDisplay = getPreference(PREF_BALANCE_DISPLAY_ENABLED).equals("true");

//        if (enableBalanceDisplay) {
            String accountInfo = getPreference(PREF_ACCOUNT_DETAILS);
            Log.w("ProfDispRead", "read from prefs: " + accountInfo);
            try {
                layAccountDisplay.removeAllViews();
                String userLevel = BaseActivity.loginResponseMessage.getData().getUserLevel();
                String userLevelStr;
                switch (userLevel) {
                    case "1":
                        userLevelStr = "Supervisor";
                        break;
                    case "2":
                        userLevelStr = "CashierPlus";
                        break;
                    default: //cashier = 0
                        userLevelStr = "Cashier";
                        break;
                }
                Log.e("ProfDisp", "userLevel = " + userLevel + " userLevelStr = " + userLevelStr);

                Gson gson = new GsonBuilder().serializeNulls().create();
                ArrayList<CommonResponseAccountMessage> accounts = gson.fromJson(
                        accountInfo,
                        new TypeToken<ArrayList<CommonResponseAccountMessage>>() {
                        }.getType()
                );

                boolean displayAccount = false;
                if (accounts != null) {
                    updateOldBalancePrefs(accounts);
                    boolean balanceDisplayed = false, profitDisplayed = false;
                    List<TextView> balanceViews = new ArrayList<>();
                    List<TextView> profitViews = new ArrayList<>();

                    LayoutInflater headerInflater = getLayoutInflater();
                    View headerLayout = headerInflater.inflate(R.layout.account_balance_profit_header, layAccountDisplay, false);
                    balanceViews.add((TextView) headerLayout.findViewById(R.id.txtAccountBalance));
                    profitViews.add((TextView) headerLayout.findViewById(R.id.txtAccountProfit));
                    layAccountDisplay.addView(headerLayout, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                    for (int i = 0; i < accounts.size() && i < MAX_ACCOUNT_DISPLAY; i++) {
                        CommonResponseAccountMessage acc = accounts.get(i);
                        String balanceSel = getBaseActivity().getBalancePref(userLevelStr, acc.getText());
                        String profitSel = getBaseActivity().getProfitPref(userLevelStr, acc.getText());

//                    if (!getBaseActivity().mFirebaseRemoteConfig.getString("enable_profit_display").equals("true")) {
                        if (!getBaseActivity().getPreference(PREF_PROFIT_DISPLAY_ENABLED).equals("true")) {
                            profitSel = "Off";
                        }
                        if (!getBaseActivity().getPreference(PREF_BALANCE_DISPLAY_ENABLED).equals("true")) {
                            balanceSel = "Off";
                        }
                        Log.e("ProfDisp", "acc:" + acc.getText() + " balanceSel:" + balanceSel + " profitSel:" + profitSel);

                        if (!balanceSel.equals("Off") || !profitSel.equals("Off")) {
                            displayAccount = true;

                            Log.w("ProfDispRead", acc.toString());
                            LayoutInflater accountInflater = getLayoutInflater();
                            View accountLayout = accountInflater.inflate(R.layout.account_balance_profit_display, layAccountDisplay, false);
                            TextView txtAccountNumber = accountLayout.findViewById(R.id.txtAccountNumber);
                            TextView txtAccountBalance = accountLayout.findViewById(R.id.txtAccountBalance);
                            TextView txtAccountProfit = accountLayout.findViewById(R.id.txtAccountProfit);

                            balanceViews.add(txtAccountBalance);
                            profitViews.add(txtAccountProfit);

                            txtAccountNumber.setText(acc.getText());

                            boolean lowBalance = false;
                            String balance;
                            if (balanceSel.equals("Warn")) {
                                double amt = Double.parseDouble(getBaseActivity().getBalanceAmountPref(acc.getText()));
                                balanceDisplayed = true;
                                if (amt > acc.getBalance()) {
                                    lowBalance = true;
                                    balance = "LOW BALANCE";
                                } else {
                                    balance = "BALANCE OK";
                                }
                            } else if (balanceSel.equals("Off")) {
                                balance = "";
                            } else {
                                balanceDisplayed = true;
                                balance = new BluDroidUtils().formatMoney(acc.getBalance());
//                            balance = "Balance: " + new BluDroidUtils().formatMoney(acc.getBalance());
                            }
                            txtAccountBalance.setText(balance);
                            if (lowBalance) {
                                txtAccountBalance.setTextColor(getBaseActivity().getResources().getColor(R.color.accentColorBLT));
                            }

                            String profit;
                            if (profitSel.equals("Off")) {
                                profit = "";
                            } else {
                                profitDisplayed = true;
                                profit = new BluDroidUtils().formatMoney(acc.getRunningProfit());
//                            profit = "Profit: " + new BluDroidUtils().formatMoney(acc.getRunningProfit());
                            }
                            txtAccountProfit.setText(profit);

                            layAccountDisplay.addView(accountLayout, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        }
                    }
                    if (!balanceDisplayed) {
                        for (TextView t : balanceViews) {
                            t.setVisibility(View.GONE);
                        }
                    }
                    if (!profitDisplayed) {
                        for (TextView t : balanceViews) {
                            t.setGravity(Gravity.RIGHT);
                        }
                        for (TextView t : profitViews) {
                            t.setVisibility(View.GONE);
                        }
                    }
                }
                layAccountDisplay.setVisibility(displayAccount ? View.VISIBLE : View.GONE);
                layAccountDisplay.invalidate();
            } catch (Exception e) {
                e.printStackTrace();
                BaseActivity.logger.error("updateBalanceAndProfitDisplayed exception" + e);
                layAccountDisplay.setVisibility(View.GONE);
                layAccountDisplay.invalidate();
            }
//        } else {
//            layAccountDisplay.setVisibility(View.GONE);
//            layAccountDisplay.invalidate();
//        }
    }

    private void updateOldBalancePrefs(ArrayList<CommonResponseAccountMessage> accounts) {
        for (CommonResponseAccountMessage acc : accounts) {
            boolean balancePrefsNotSet = getPreference(PREF_BALANCE + "Supervisor" + acc.getText()).isEmpty();
            if (balancePrefsNotSet) {
                Log.w("ProfDisp", "Setting initial prefs for " + acc.getText());
                getBaseActivity().updatePreference(PREF_BALANCE + "Supervisor" + acc.getText(), "On");
                getBaseActivity().updatePreference(PREF_BALANCE + "CashierPlus" + acc.getText(), "On");
                getBaseActivity().updatePreference(PREF_BALANCE + "Cashier" + acc.getText(), "On");
                getBaseActivity().updatePreference(PREF_PROFIT + "Supervisor" + acc.getText(), "On");
                getBaseActivity().updatePreference(PREF_PROFIT + "CashierPlus" + acc.getText(), "Off");
                getBaseActivity().updatePreference(PREF_PROFIT + "Cashier" + acc.getText(), "Off");
                String warnAmt = new BluDroidUtils().formatMoney(getResources().getString(R.string.low_balance_amount_default));
                getBaseActivity().updatePreference(PREF_BALANCEAMT + acc.getText(), warnAmt);
            }
        }
    }


}