package za.co.blts.bltandroidgui3.cardviews;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewLycaMobile extends CardviewDataObject {

    public CardviewLycaMobile(BaseActivity baseActivity, String cardDesc, String cardValue, String voucherType, String tag, String voucherTypeDesc, boolean isMVNO, String code, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.lycamobile,
                baseActivity.getResources().getColor(R.color.white)
                , voucherType, tag, voucherTypeDesc, "", isMVNO, code);
        super.setHasAirtimePlus(hasAirtimePlus);
    }

}

