package za.co.blts.bltandroidgui3;

import android.util.Base64;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.HttpResponse;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.Volley;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;

import za.co.blts.bltandroidgui3.dynamic.DynamicPrintInfo;
import za.co.blts.bltandroidgui3.dynamic.TLSSocketFactory;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;

public class BluDroidVolley {
    private final String TAG = this.getClass().getSimpleName();

    private static BluDroidVolley requestQueueSingleton;

    private RequestQueue requestQueue;
    private static WeakReference<BaseActivity> baseActivityWeakReference;
    private Map<String, String> headers;

    //----------------------------------------------------------------------------------------------
    private BluDroidVolley(BaseActivity baseActivity) {
        baseActivityWeakReference = new WeakReference<>(baseActivity);

        try {
            SSLContext sslcontext = SSLContext.getInstance("TLSv1.2");
            sslcontext.init(null, null, null);
            requestQueue = Volley.newRequestQueue(baseActivity.getApplicationContext(), new BluDroidHurlStack(null, new TLSSocketFactory()));
        } catch (Exception e) {
            Log.e(TAG, "=================" + e.getMessage());
            e.printStackTrace();
            requestQueue = Volley.newRequestQueue(baseActivity.getApplicationContext(), new BluDroidHurlStack());
        }
    }

    //----------------------------------------------------------------------------------------------
    public static synchronized BluDroidVolley getInstance(BaseActivity baseActivity) {
        if (requestQueueSingleton == null) {
            requestQueueSingleton = new BluDroidVolley(baseActivity);
        } else {
            baseActivityWeakReference = new WeakReference<>(baseActivity);
        }
        return requestQueueSingleton;
    }

    public void cancelAll() {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null && requestQueue != null) requestQueue.cancelAll(baseActivity);
    }

    public void addRequestApiGateway(Request<?> request) {
        headers = new HashMap<>();
        setApiGatewayCredentials();
        Log.d(TAG, "Headers: " + headers.toString());
        requestQueue.add(request);
    }

    public void addRequestDynamicPrints(Request<?> request) {
        headers = new HashMap<>();
        setMendixCredentials();
        addPrintRequestHeader();
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            headers.put("DeviceId", baseActivity.getPreference(PREF_DEVICE_ID));
            headers.put("Theme", baseActivity.getPreference(PREF_SKIN));
            headers.put("SerialNo", baseActivity.getPreference(PREF_DEVICE_SER));
        }
        Log.d(TAG, "Headers: " + headers.toString());
        requestQueue.add(request);
    }

    public void addRequestDynamicBanner(Request<?> request) {
        headers = new HashMap<>();
        setMendixCredentials();
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            headers.put("DeviceId", baseActivity.getPreference(PREF_DEVICE_ID));
            headers.put("Theme", baseActivity.getPreference(PREF_SKIN));
        }
        Log.d(TAG, "Headers: " + headers.toString());
        requestQueue.add(request);
    }

    public void addRequestNotificationCount(Request<?> request) {
        headers = new HashMap<>();
        setMendixCredentials();
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            headers.put("DeviceId", baseActivity.getPreference(PREF_DEVICE_ID));
            headers.put("SerialNo", baseActivity.getPreference(PREF_DEVICE_SER));
        }
        Log.d(TAG, "Headers: " + headers.toString());
        requestQueue.add(request);
    }

    public void setApiGatewayCredentials() {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        Log.d(TAG, "setApiGatewayCredentials : baseActivity " + baseActivity);
        if (baseActivity != null) {
            String username = "bludroid";
            String password = "7m2hu88qgpeb01ir89576rbq9o";
            if (baseActivity.getPreference(PREF_LOYALTY_URL).contains(".live.")) {
                Log.d(TAG, "using PROD credentials");
                password = "437s5j5o6ac67qkjvamfiqo3hq";
            }
            String credentials = username + ":" + password;
            String base64EncodedCredentials = Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
            headers.put("Authorization", "Basic " + base64EncodedCredentials);
        }
    }

    public void setMendixCredentials() {
        String username = "BluDroid";
        String password = "&z)yT38zSMsa$PhJd/V;Dn9Y=%Ygg^'7HzBB^Fc8~FdTrM^gDT";
        String credentials = username + ":" + password;
        String base64EncodedCredentials = Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
        headers.put("Authorization", "Basic " + base64EncodedCredentials);
    }

    public void addPrintRequestHeader() {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            DynamicPrintInfo info = new DynamicPrintInfo(baseActivity);
            headers.put("Counter", info.getCounts());
//            Log.d(TAG, "Counts : " + info.getCounts());
        }
    }

    //----------------------------------------------------------------------------------------------
    class BluDroidHurlStack extends HurlStack {
        public BluDroidHurlStack() {
        }

        public BluDroidHurlStack(UrlRewriter urlRewriter, SSLSocketFactory sslSocketFactory) {
            super(urlRewriter, sslSocketFactory);
        }

        @Override
        public HttpResponse executeRequest(Request<?> request, Map<String, String> additionalHeaders) throws IOException, AuthFailureError {
            request.setRetryPolicy(new DefaultRetryPolicy(5000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            return super.executeRequest(request, headers);
        }
    }
}
