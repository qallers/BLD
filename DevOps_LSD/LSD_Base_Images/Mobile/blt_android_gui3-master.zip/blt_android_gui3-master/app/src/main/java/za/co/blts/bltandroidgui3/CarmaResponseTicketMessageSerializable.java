package za.co.blts.bltandroidgui3;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.UUID;

import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestPassengerMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseTicketMessage;

import static java.util.UUID.randomUUID;

class CarmaResponseTicketMessageSerializable implements Serializable {
    //----------------------------------------------------------------------------------------------
    private UUID uuid;
    private String routeCode;
    private String ticketNumber;
    private String passengerNumber;
    private String amount;
    private String carrier;
    private String reference;
    private String barcode;
    private String departDate;
    private String travelClass;
    private String boardTime;
    private String boardLocation;
    private String boardCity;
    private String arrivalTime;
    private String destLocation;
    private String destCity;
    private String ticketHeader;
    private String ticketFooter;
    private String ticketTimeStamp;
    private String ticketExprirationDate;
    private String carrierDescription;
    private String servicenumber;
    private String seatNumber;


    private ArrayList<CarmaRequestPassengerMessageSerializable> passengers = new ArrayList<>();

    //----------------------------------------------------------------------------------------------
    public CarmaResponseTicketMessageSerializable(BaseActivity baseActivity, CarmaResponseTicketMessage responseTicketMessage) {
        this.uuid = randomUUID();
        this.setRouteCode(responseTicketMessage.getRouteCode());
        this.setTicketNumber(responseTicketMessage.getTicketNumber());
        this.setPassengerNumber(responseTicketMessage.getPassengerNumber());
        this.setAmount(responseTicketMessage.getAmount());
        this.setCarrier(responseTicketMessage.getCarrier());
        this.setReference(responseTicketMessage.getReference());
        this.setBarcode(responseTicketMessage.getBarcode());
        this.setDepartDate(responseTicketMessage.getDepartDate());
        this.setTravelClass(responseTicketMessage.getTravelClass());
        this.setBoardTime(responseTicketMessage.getBoardTime());
        this.setBoardLocation(responseTicketMessage.getBoardLocation());
        this.setBoardCity(responseTicketMessage.getBoardCity());
        this.setArrivalTime(responseTicketMessage.getArrivalTime());
        this.setDestLocation(responseTicketMessage.getDestLocation());
        this.setDestCity(responseTicketMessage.getDestCity());
        this.setTicketHeader(responseTicketMessage.getTicketHeader());
        this.setTicketFooter(responseTicketMessage.getTicketFooter());
        this.setTicketFooter(responseTicketMessage.getTicketFooter());
        this.setCarrierDescription(responseTicketMessage.getCarrierDescription());
        this.setServicenumber(responseTicketMessage.getServiceNumber());
        for (CarmaRequestPassengerMessage carmaRequestPassengerMessage : responseTicketMessage.getPassengers()) {
            this.passengers.add(new CarmaRequestPassengerMessageSerializable(carmaRequestPassengerMessage));
        }
        this.setTicketTimeStamp(baseActivity.todaysDateAndTime());
        this.setTicketExprirationDate(new BluDroidUtils().tenMinutesLaterDateAndTime()); // 10 min from now
        this.setSeatNumber(responseTicketMessage.getPassengers().get(0).getRowSeat());
    }
    //----------------------------------------------------------------------------------------------

    public UUID getUuid() {
        return uuid;
    }

    public void setUuid(UUID uuid) {
        this.uuid = uuid;
    }

    public String getRouteCode() {
        return routeCode;
    }

    private void setRouteCode(String routeCode) {
        this.routeCode = routeCode;
    }

    public String getTicketNumber() {
        return ticketNumber;
    }

    private void setTicketNumber(String ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    public String getPassengerNumber() {
        return passengerNumber;
    }

    private void setPassengerNumber(String passengerNumber) {
        this.passengerNumber = passengerNumber;
    }

    public String getAmount() {
        return amount;
    }

    private void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCarrier() {
        return carrier;
    }

    private void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getReference() {
        return reference;
    }

    private void setReference(String reference) {
        this.reference = reference;
    }

    public String getBarcode() {
        return barcode;
    }

    private void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getDepartDate() {
        return departDate;
    }

    private void setDepartDate(String departDate) {
        this.departDate = departDate;
    }

    public String getTravelClass() {
        return travelClass;
    }

    private void setTravelClass(String travelClass) {
        this.travelClass = travelClass;
    }

    public String getBoardTime() {
        return boardTime;
    }

    private void setBoardTime(String boardTime) {
        this.boardTime = boardTime;
    }

    public String getBoardLocation() {
        return boardLocation;
    }

    private void setBoardLocation(String boardLocation) {
        this.boardLocation = boardLocation;
    }

    public String getBoardCity() {
        return boardCity;
    }

    private void setBoardCity(String boardCity) {
        this.boardCity = boardCity;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    private void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public String getDestLocation() {
        return destLocation;
    }

    private void setDestLocation(String destLocation) {
        this.destLocation = destLocation;
    }

    public String getDestCity() {
        return destCity;
    }

    private void setDestCity(String destCity) {
        this.destCity = destCity;
    }

    public ArrayList<CarmaRequestPassengerMessageSerializable> getPassengers() {
        return passengers;
    }

    public String getTicketHeader() {
        return ticketHeader;
    }

    private void setTicketHeader(String ticketHeader) {
        this.ticketHeader = ticketHeader;
    }

    public String getTicketFooter() {
        return ticketFooter;
    }

    private void setTicketFooter(String ticketFooter) {
        this.ticketFooter = ticketFooter;
    }

    public void setPassengers(ArrayList<CarmaRequestPassengerMessageSerializable> passengers) {
        this.passengers = passengers;
    }

    public String getTicketTimeStamp() {
        return ticketTimeStamp;
    }

    public void setTicketTimeStamp(String ticketTimeStamp) {
        this.ticketTimeStamp = ticketTimeStamp;
    }
    //----------------------------------------------------------------------------------------------

    public String getTicketExprirationDate() {
        return ticketExprirationDate;
    }

    private void setTicketExprirationDate(String ticketExprirationDate) {
        this.ticketExprirationDate = ticketExprirationDate;
    }

    public String getCarrierDescription() {
        return carrierDescription;
    }

    private void setCarrierDescription(String carrierDescription) {
        this.carrierDescription = carrierDescription;
    }

    public String getServicenumber() {
        return servicenumber;
    }

    private void setServicenumber(String servicenumber) {
        this.servicenumber = servicenumber;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

//----------------------------------------------------------------------------------------------

    @Override
    public String toString() {
        return "CarmaResponseTicketMessageSerializable{" +
                "uuid=" + uuid +
                ", routeCode='" + routeCode + '\'' +
                ", ticketNumber='" + ticketNumber + '\'' +
                ", passengerNumber='" + passengerNumber + '\'' +
                ", amount='" + amount + '\'' +
                ", carrier='" + carrier + '\'' +
                ", reference='" + reference + '\'' +
                ", barcode='" + barcode + '\'' +
                ", departDate='" + departDate + '\'' +
                ", travelClass='" + travelClass + '\'' +
                ", boardTime='" + boardTime + '\'' +
                ", boardLocation='" + boardLocation + '\'' +
                ", boardCity='" + boardCity + '\'' +
                ", arrivalTime='" + arrivalTime + '\'' +
                ", destLocation='" + destLocation + '\'' +
                ", destCity='" + destCity + '\'' +
                ", ticketHeader='" + ticketHeader + '\'' +
                ", ticketFooter='" + ticketFooter + '\'' +
                ", ticketTimeStamp='" + ticketTimeStamp + '\'' +
                ", ticketExprirationDate='" + ticketExprirationDate + '\'' +
                ", carrierDescription='" + carrierDescription + '\'' +
                ", servicenumber='" + servicenumber + '\'' +
                ", passengers=" + passengers +
                ", seatNumber=" + seatNumber +
                '}';
    }
}
