package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseAccountValuesMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseInvoiceListMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponsePrintInvoiceMessage;
import za.co.blt.interfaces.external.messages.tender.response.TenderAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.tender.response.TenderResponseMessage;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDatePickerDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDateTimePickerDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidTimePickerDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidMandatoryEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_PREVIEWS;

public class ActivityReports extends BaseActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener, NeedsAEONResults {

    private final String TAG = this.getClass().getSimpleName();

    //Reprint
    private boolean isReportsToggled = false;
    private ImageView reportsToggleImg = null;
    private BluDroidTextView fromDateIndicator;
    private BluDroidTextView toDateIndicator;
    // Spinner reprintCategorySpinner;


    //Transaction List
    private boolean istransactionListToggled = false;
    private ImageView transactionListToggleImg = null;
    private BluDroidEditText transactionListdaysEditText;
    private BluDroidLinearLayout transactionListLayout;

    //Account Status
    private boolean isaccountStatusoggled = false;
    private ImageView accountStatusToggleImg = null;
    private Spinner transListAccountNumberSpinner;


    //Profit Report
    private boolean isprofitReportToggled = false;
    private ImageView profitReportToggleImg = null;
    private BluDroidSpinner profitReportAccountNumberSpinner;
    private BluDroidSpinner profitReportShiftSpinner;
    private BluDroidEditText profitReportNumDays;
    private String profitReportOption = "days";
    private BluDroidLinearLayout profitReportLayout;


    //Statement
    private boolean isStatementToggled = false;
    private ImageView statementToggleImg = null;
    private BluDroidSpinner statementReportAccountNumberSpinner;
    private BluDroidEditText statementReportNumDays;
    private BluDroidLinearLayout statementGroup;

    //invoicing
    private boolean isInvoicingToggled = false;
    private ImageView invoicingToggleImg = null;
    private BluDroidSpinner invoicingReportAccountNumberSpinner;
    private BluDroidSpinner invoicingReportInvoiceListSpinner;

    //View SHift
    private boolean isViewShiftToggled = false;
    private ImageView viewShiftToggleImg = null;
    private BluDroidSpinner viewShiftReportShiftSpinner;

    //Emergency top up
    private boolean isEmergencyTopUpToggled = false;
    private ImageView emergencyToggleImg = null;
    private BluDroidSpinner etuReportAccountNumberSpinner;
    private BluDroidEditText etuReportNumDays;
    private BluDroidLinearLayout emergencyTopUpGroup;

    //DailyBatchReport
    private boolean isDailyBatchReportToggled = false;
    private ImageView dailyBatchReportToggleImg = null;
    private BluDroidTextView dbrDateIndicator;


    private BluDroidDateTimePickerDialog alertDialog = null;

    private BluDroidDatePickerDialog dateAlertDialog = null;

    private String reprintListDateTo, reprintListDateFrom;

    private ArrayList<String> accountNumbers;
    private ArrayList<String> shifts;


    private String account = "";
    private String shiftId = "";
    private String shift = "";
    private String invoiceId;

    private Animation animShow, animHide;

    private BluDroidLinearLayout trxByDays, trxByDateTime;
    private RadioButton rbDays, rbDateTime;
    private BluDroidMandatoryEditText txtStartDate, txtStartTime, txtEndDate, txtEndTime;
    private BluDroidDatePickerDialog dateDialog = null;
    private BluDroidTimePickerDialog timeDialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onActivityCreated");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        if (Boolean.valueOf(getPreference(PREF_PRINT_PREVIEWS))) {
            ifPreviewIsOnSetPrintButtonTextToPreview();
        }

        transListAccountNumberSpinnerComponent();
        datePickerComponents();
        transactionListComponents();
        accountStatus();
        profitReportComponents();
        statementReportComponents();
        invoicingReportComponents();
        viewShiftComponents();
        etuReportComponents();
        dbrComponents();
        toggleComponents();

        toolbar = findViewById(R.id.toolbar);
        String title = "Reports";
        toolbar.setTitle(title);
        toolbar.setNavigationBackIcon();
        toolbar.removeAppLogo();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        File[] notTenderedFiles = getNotTendered();
        if (notTenderedFiles.length > 0) {
            emptyBasket();
        } else {
            authenticateForReports();
        }

        initAnimation();
        initReportsMenuForUser();

        hideReprintSection();
        hideTransactionListSection();
        hideAccountStatusSection();

        hideProfitReportSection();
        hideProfitReportByShift();
        hideProfitReportByDateRange();

        hideStatementSection();
        hideInvoicingSection();
        hideViewShiftSection();
        hideEmergencyTopUpSection();
        hideDailyBatchReportSection();


        // accountNumbers = new ArrayList<>();

        // for(Map.Entry<String,String> entry : getAccountsList().entrySet()) {
        //String key = entry.getKey();
        // String value = entry.getValue();
        // accountNumbers.add(value);
        // }

        //getInvoiceList("");
    }

    @Override
    public void onResume() {
        super.onResume();
        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);
    }

    private void transListAccountNumberSpinnerComponent() {
        transListAccountNumberSpinner = (BluDroidSpinner) findViewById(R.id.accountNumberSpinner);
        transListAccountNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                displayAccountStatus(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void datePickerComponents() {
        ImageButton fromdatePickerImageButton = findViewById(R.id.reprintFromDatePicker);
        fromdatePickerImageButton.setColorFilter(getSkinResources().getButtonColor(), PorterDuff.Mode.SRC_IN);
        fromdatePickerImageButton.setBackground(null);

        ImageButton todatePickerImageButton = findViewById(R.id.reprintToDatePicker);
        todatePickerImageButton.setColorFilter(getSkinResources().getButtonColor(), PorterDuff.Mode.SRC_IN);
        todatePickerImageButton.setBackground(null);

        fromDateIndicator = findViewById(R.id.fromDateTimeIndicator);
        toDateIndicator = findViewById(R.id.toDateTimeIndicator);
        fromdatePickerImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog = createDateTimePickerDialog(ActivityReports.this);
                alertDialog.setPositiveOption("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        fromDateIndicator.setText(alertDialog.getDateAndTime());
                        reprintListDateFrom = alertDialog.getMillies();
                    }
                });

                alertDialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        alertDialog.dismiss();
                    }
                });

                alertDialog.createDialog();
            }
        });

        todatePickerImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog = createDateTimePickerDialog(ActivityReports.this);
                alertDialog.setPositiveOption("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        toDateIndicator.setText(alertDialog.getDateAndTime());
                        reprintListDateTo = alertDialog.getMillies();
                        reprintDateFrom = reprintListDateFrom;
                        reprintDateTo = reprintListDateTo;
                        authenticateForReprints();
                    }
                });

                alertDialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        alertDialog.dismiss();
                    }
                });

                alertDialog.createDialog();
            }
        });
    }

    private void transactionListComponents() {
        //TransactionList Components
        transactionListLayout = findViewById(R.id.transactionListGroup);
        BluDroidButton printTransactionListButton = findViewById(R.id.printTransactionLst);
        transactionListdaysEditText = findViewById(R.id.transactionListdays);
        printTransactionListButton.setOnClickListener(this);

        trxByDays = findViewById(R.id.trxByDays);
        trxByDateTime = findViewById(R.id.trxByDateTime);
        rbDays = findViewById(R.id.rbDays);
        rbDateTime = findViewById(R.id.rbDateTime);

        txtStartDate = findViewById(R.id.txtStartDate);
        txtStartTime = findViewById(R.id.txtStartTime);
        txtEndDate = findViewById(R.id.txtEndDate);
        txtEndTime = findViewById(R.id.txtEndTime);

        ImageButton btnStartDate = findViewById(R.id.btnStartDate);
        btnStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboardFromView(txtStartDate);
                txtStartDate.removeErrorMessage();
                dateDialog = createDatePickerDialog(ActivityReports.this);

                dateDialog.setPositiveOption("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        txtStartDate.setText(dateDialog.getDate());
                    }
                });

                dateDialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dateDialog.dismiss();
                    }
                });

                dateDialog.createDialog();
            }
        });

        ImageButton btnStartTimeUp = findViewById(R.id.btnStartTimeUp);
        btnStartTimeUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboardFromView(txtStartTime);
                txtStartTime.removeErrorMessage();
                timeDialog = createTimePickerDialog(ActivityReports.this);

                timeDialog.setPositiveOption("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        txtStartTime.setText(timeDialog.getTimeString());
                    }
                });

                timeDialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        timeDialog.dismiss();
                    }
                });

                timeDialog.createDialog();

            }
        });

        ImageButton btnEndDate = findViewById(R.id.btnEndDate);
        btnEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboardFromView(txtEndDate);
                txtEndDate.removeErrorMessage();
                dateDialog = createDatePickerDialog(ActivityReports.this);

                dateDialog.setPositiveOption("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        txtEndDate.setText(dateDialog.getDate());
                    }
                });

                dateDialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dateDialog.dismiss();
                    }
                });

                dateDialog.createDialog();
            }
        });

        ImageButton btnEndTimeUp = findViewById(R.id.btnEndTimeUp);
        btnEndTimeUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboardFromView(txtEndTime);
                txtEndTime.removeErrorMessage();
                timeDialog = createTimePickerDialog(ActivityReports.this);

                timeDialog.setPositiveOption("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        txtEndTime.setText(timeDialog.getTimeString());
                    }
                });

                timeDialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        timeDialog.dismiss();
                    }
                });

                timeDialog.createDialog();
            }
        });

        hideTrxListDateTime();
    }

    private void accountStatus() {
        BluDroidButton printAccountStatusButton = findViewById(R.id.printAccountStatus);
        printAccountStatusButton.setOnClickListener(this);
    }

    private void profitReportComponents() {
        //Profit Report Components
        profitReportLayout = findViewById(R.id.layoutDays);
        ImageButton profitReportFromdatePickerImageButton = findViewById(R.id.profit_report_date_from);
        profitReportFromdatePickerImageButton.setColorFilter(getSkinResources().getButtonColor(), PorterDuff.Mode.SRC_IN);
        profitReportFromdatePickerImageButton.setBackground(null);

        ImageButton profitReportTodatePickerImageButton = findViewById(R.id.profit_report_date_to);
        profitReportTodatePickerImageButton.setColorFilter(getSkinResources().getButtonColor(), PorterDuff.Mode.SRC_IN);
        profitReportTodatePickerImageButton.setBackground(null);

        profitReportNumDays = findViewById(R.id.profitReportNumDays);
        BluDroidRadioButton profitReportByDaysRadio = findViewById(R.id.radio_days);
        BluDroidRadioButton profitReportByShiftRadio = findViewById(R.id.radio_shift);
        BluDroidRadioButton profitReportByDateRangeRadio = findViewById(R.id.radio_date_range);
        BluDroidButton btnPrintPortReport = findViewById(R.id.printProfitReport);
        btnPrintPortReport.setOnClickListener(this);

        profitReportByDaysRadio.setOnCheckedChangeListener(this);
        profitReportByShiftRadio.setOnCheckedChangeListener(this);
        profitReportByDateRangeRadio.setOnCheckedChangeListener(this);

        profitReportAccountNumberSpinner = findViewById(R.id.profitReportAccountNumberSpinner);
        profitReportShiftSpinner = findViewById(R.id.profitReportShiftSpinner);

        profitReportAccountNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                account = ((TextView) (parent.getSelectedView())).getText().toString().trim();
                accountId = getselectedAccount(account);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


        profitReportShiftSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    shiftId = "0";
                } else {
                    shift = ((TextView) (parent.getSelectedView())).getText().toString().trim();
                    shiftId = getselectedShift(shift);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void statementReportComponents() {
        //Statement Report components
        statementGroup = findViewById(R.id.statementGroup);
        statementReportNumDays = findViewById(R.id.statementNumDays);
        BluDroidButton btnPrintStatementReport = findViewById(R.id.printStatementReport);
        btnPrintStatementReport.setOnClickListener(this);


        statementReportAccountNumberSpinner = findViewById(R.id.statementAccNumberSpinner);

        statementReportAccountNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                account = ((TextView) (parent.getSelectedView())).getText().toString().trim();
                accountId = getselectedAccount(account);
                // accountId = getselectedAccount(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void invoicingReportComponents() {
        //Invoicing Report components
        BluDroidButton btnPrintInvoiceReport = findViewById(R.id.printInvoicingReport);
        btnPrintInvoiceReport.setOnClickListener(this);


        invoicingReportAccountNumberSpinner = findViewById(R.id.invoicingAccNumberSpinner);
        invoicingReportInvoiceListSpinner = findViewById(R.id.invoiceSpinner);

//        invoicingReportAccountNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//
//
//                if (parent.getSelectedView()!=null) {
//                    account = ((TextView) (parent.getSelectedView())).getText().toString().trim();
//
//                    accountId = getselectedAccount(account);
//
//                  //  getInvoiceList(accountId);
//                    //populateInvoiceListSpinner();
//
//                }
//
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//
//        });

        invoicingReportInvoiceListSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                if (parent.getSelectedView() != null) {

                    String invoice = ((TextView) (parent.getSelectedView())).getText().toString().trim();
                    invoiceId = invoice.substring(invoice.indexOf("-") + 2);

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });


        invoicingReportAccountNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                if (parent.getSelectedView() != null) {
                    account = ((TextView) (parent.getSelectedView())).getText().toString().trim();

                    accountId = getselectedAccount(account);

                    if (!accountId.equalsIgnoreCase("")) {

                        mustgetInvoiceList = true;
                        mustgetAccountList = false;
                        mustgetShiftList = false;

                        authenticateForReports();

                        //getInvoiceList(accountId);
                        //populateInvoiceListSpinner();
                    }

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });
    }

    private void viewShiftComponents() {
        //View Shift
        BluDroidButton btnPrintViewShiftReportReport = findViewById(R.id.printViewShiftReport);
        btnPrintViewShiftReportReport.setOnClickListener(this);


        viewShiftReportShiftSpinner = findViewById(R.id.viewShiftSelectShiftSpinner);

        viewShiftReportShiftSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                if (position == 0) {
                    shiftId = "0";
                } else {

                    shift = ((TextView) (parent.getSelectedView())).getText().toString().trim();
                    shiftId = getselectedShift(shift);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void etuReportComponents() {
        //ETU REport components
        etuReportNumDays = findViewById(R.id.ETUNumDays);
        BluDroidButton btnPrintEtuReport = findViewById(R.id.printEtuReport);
        btnPrintEtuReport.setOnClickListener(this);


        etuReportAccountNumberSpinner = findViewById(R.id.etuAccountNumberSpinner);

        etuReportAccountNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                account = ((TextView) (parent.getSelectedView())).getText().toString().trim();
                accountId = getselectedAccount(account);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void dbrComponents() {
        //DBR components
        ImageButton dbrDatePickerImageButton = findViewById(R.id.dbrDatePicker);
        dbrDatePickerImageButton.setColorFilter(getSkinResources().getButtonColor(), PorterDuff.Mode.SRC_IN);
        dbrDatePickerImageButton.setBackground(null);

        dbrDateIndicator = findViewById(R.id.dbrDate);

        BluDroidButton btnPrintDbrReport = findViewById(R.id.printDbrReport);
        btnPrintDbrReport.setOnClickListener(this);


        dbrDatePickerImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dateAlertDialog = createDatePickerDialog(ActivityReports.this);

                dateAlertDialog.setPositiveOption("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dbrDateIndicator.setText(dateAlertDialog.getDate());

                    }
                });

                dateAlertDialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dateAlertDialog.dismiss();
                    }
                });

                dateAlertDialog.createDialog();
            }
        });
    }

    private void toggleComponents() {
        //Toggling arrows
        reportsToggleImg = findViewById(R.id.reprintToggle);
        transactionListToggleImg = findViewById(R.id.transactionListToggle);
        accountStatusToggleImg = findViewById(R.id.accountStatusToggle);
        profitReportToggleImg = findViewById(R.id.profitReportToggle);
        statementToggleImg = findViewById(R.id.statementToggle);
        invoicingToggleImg = findViewById(R.id.invoicingToggle);
        viewShiftToggleImg = findViewById(R.id.viewShiftToggle);
        emergencyToggleImg = findViewById(R.id.emergencyTopUpToggle);
        dailyBatchReportToggleImg = findViewById(R.id.dailyBatchReportToggle);

        LinearLayout reportsToggle = findViewById(R.id.reprintGroupToggle);
        reportsToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isReportsToggled) {
                    hideReprintSection();
                    reportsToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showReprintSection();

                    reportsToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                    authenticateForReprints();
                }
                isReportsToggled = !isReportsToggled;
            }
        });

        LinearLayout transactionListToggle = findViewById(R.id.transactionListGroupToggle);
        transactionListToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (istransactionListToggled) {
                    hideTransactionListSection();
                    transactionListToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showTransactionListSection();
                    transactionListToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                istransactionListToggled = !istransactionListToggled;
            }
        });

        rbDays.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    hideTrxListDateTime();
                }
            }
        });

        rbDateTime.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    hideTrxListDays();
                }
            }
        });

        LinearLayout accountStatusToggle = findViewById(R.id.accountStatusGroupToggle);
        accountStatusToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isaccountStatusoggled) {
                    hideAccountStatusSection();
                    accountStatusToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {

                    showAccountStatusSection();

                    accountStatusToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isaccountStatusoggled = !isaccountStatusoggled;
            }
        });

        LinearLayout profitReportToggle = findViewById(R.id.profitReportGroupToggle);
        profitReportToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isprofitReportToggled) {
                    hideProfitReportSection();
                    profitReportToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {

                    showProfitReportSection();

                    profitReportToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isprofitReportToggled = !isprofitReportToggled;
            }
        });

        LinearLayout statementToggle = findViewById(R.id.statementGroupToggle);
        statementToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isStatementToggled) {
                    hideStatementSection();
                    statementToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {

                    showStatementSection();

                    statementToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isStatementToggled = !isStatementToggled;
            }
        });


        LinearLayout invoicingToggle = findViewById(R.id.invoicingGroupToggle);
        invoicingToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isInvoicingToggled) {
                    hideInvoicingSection();
                    invoicingToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {

                    showInvoicingSection();

                    invoicingToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isInvoicingToggled = !isInvoicingToggled;
            }
        });

        LinearLayout viewShiftToggle = findViewById(R.id.viewShiftGroupToggle);
        viewShiftToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isViewShiftToggled) {
                    hideViewShiftSection();
                    viewShiftToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {

                    showViewShiftSection();

                    viewShiftToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isViewShiftToggled = !isViewShiftToggled;
            }
        });

        emergencyTopUpGroup = findViewById(R.id.emergencyTopUpGroup);
        LinearLayout emergencyTopUpToggle = findViewById(R.id.emergencyTopUpGroupToggle);
        emergencyTopUpToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isEmergencyTopUpToggled) {
                    hideEmergencyTopUpSection();
                    emergencyToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {

                    showEmergencyTopUpSection();

                    emergencyToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isEmergencyTopUpToggled = !isEmergencyTopUpToggled;
            }
        });

        LinearLayout dailyBatchReportToggle = findViewById(R.id.dailyBatchReportGroupToggle);
        dailyBatchReportToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isDailyBatchReportToggled) {
                    hideDailyBatchReportSection();
                    dailyBatchReportToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {

                    showDailyBatchReportSection();

                    dailyBatchReportToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isDailyBatchReportToggled = !isDailyBatchReportToggled;
            }
        });
    }


    private void ifPreviewIsOnSetPrintButtonTextToPreview() {
        ((BluDroidButton) findViewById(R.id.printTransactionLst)).setText(getResources().getString(R.string.preview));
        //((BluDroidButton) findViewById(R.id.printAccountStatus)).setText(getResources().getString(R.string.preview)); // already viewable
        ((BluDroidButton) findViewById(R.id.printProfitReport)).setText(getResources().getString(R.string.preview));
        ((BluDroidButton) findViewById(R.id.printStatementReport)).setText(getResources().getString(R.string.preview));
        ((BluDroidButton) findViewById(R.id.printInvoicingReport)).setText(getResources().getString(R.string.preview));
        ((BluDroidButton) findViewById(R.id.printViewShiftReport)).setText(getResources().getString(R.string.preview));
        ((BluDroidButton) findViewById(R.id.printEtuReport)).setText(getResources().getString(R.string.preview));
        ((BluDroidButton) findViewById(R.id.printDbrReport)).setText(getResources().getString(R.string.preview));
    }

    private void initAnimation() {
        animShow = AnimationUtils.loadAnimation(this, R.anim.slide_in_right);
        animHide = AnimationUtils.loadAnimation(this, R.anim.slide_out_left);
    }

    private void initReportsMenuForUser() {

        if (!loginResponseMessage.getData().canReprint()) {
            hideShow(R.id.reprintGroupToggle, GONE);
            hideReprintSection();
        }

        if (!loginResponseMessage.getData().canPrintTransactionList()) {
            hideShow(R.id.transactionListGroupToggle, GONE);
            hideTransactionListSection();
        }

        if (!loginResponseMessage.getData().canDoInvoicing()) {
            hideShow(R.id.invoicingGroupToggle, GONE);
            hideInvoicingSection();
        }

        if (!loginResponseMessage.getData().canPrintProfitReport()) {
            hideShow(R.id.profitReportGroupToggle, GONE);
            hideProfitReportSection();
        }

        if (!loginResponseMessage.getData().canPrintStatement()) {
            hideShow(R.id.statementGroupToggle, GONE);
            hideStatementSection();
        }

        if (!loginResponseMessage.getData().canViewShift()) {
            hideShow(R.id.viewShiftGroupToggle, GONE);
            hideViewShiftSection();
        }

        if (!loginResponseMessage.getData().canDoEmergencyTopup()) {
            hideShow(R.id.emergencyTopUpGroupToggle, GONE);
            hideEmergencyTopUpSection();
        }

        if (!loginResponseMessage.getData().canPrintDailyBatchReport()) {
            hideShow(R.id.dailyBatchReportGroupToggle, GONE);
            hideDailyBatchReportSection();
        }

        if (!loginResponseMessage.getData().canPrintAccountStatus()) {
            hideShow(R.id.accountStatusGroupToggle, GONE);
            hideAccountStatusSection();
        }

    }

    private void hideReprintSection() {
        resetTimer();
        hideShow(R.id.reprintGroup, GONE);
    }

    private void showReprintSection() {
        resetTimer();
        hideShow(R.id.reprintGroup, View.VISIBLE);
    }


    private void hideTransactionListSection() {
        resetTimer();
        hideShow(R.id.transactionListGroup, GONE);
        transactionListdaysEditText.setText("");
        transactionListdaysEditText.removeErrorMessage();
        txtStartDate.setText("");
        txtEndDate.setText("");
        txtStartTime.setText("");
        txtEndTime.setText("");
        txtStartDate.removeErrorMessage();
        txtStartTime.removeErrorMessage();
        txtEndDate.removeErrorMessage();
        txtEndTime.removeErrorMessage();
    }

    private void showTransactionListSection() {
        resetTimer();
        hideShow(R.id.transactionListGroup, View.VISIBLE);

        authenticateForReports();
    }

    private void hideTrxListDateTime() {
        resetTimer();
        hideShow(R.id.trxByDateTime, GONE);
        hideShow(R.id.trxByDays, VISIBLE);
        transactionListdaysEditText.setText("");
        transactionListdaysEditText.removeErrorMessage();
        txtStartDate.setText("");
        txtEndDate.setText("");
        txtStartTime.setText("");
        txtEndTime.setText("");
        txtStartDate.removeErrorMessage();
        txtStartTime.removeErrorMessage();
        txtEndDate.removeErrorMessage();
        txtEndTime.removeErrorMessage();
    }

    private void hideTrxListDays() {
        resetTimer();
        hideShow(R.id.trxByDateTime, VISIBLE);
        hideShow(R.id.trxByDays, GONE);
        transactionListdaysEditText.setText("");
        transactionListdaysEditText.removeErrorMessage();
        txtStartDate.setText("");
        txtEndDate.setText("");
        txtStartTime.setText("");
        txtEndTime.setText("");
        txtStartDate.removeErrorMessage();
        txtStartTime.removeErrorMessage();
        txtEndDate.removeErrorMessage();
        txtEndTime.removeErrorMessage();
    }

    private void hideAccountStatusSection() {
        resetTimer();
        hideShow(R.id.accountStatusGroup, GONE);
    }

    private void showAccountStatusSection() {
        // authenticateForAccounts();

        resetTimer();
        hideShow(R.id.accountStatusGroup, View.VISIBLE);

        ArrayList<String> accountNumbers = new ArrayList<>();
        for (ReportsResponseAccountValuesMessage account : getAccounts()) {
            accountNumbers.add(account.getAccountNr());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, accountNumbers);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        transListAccountNumberSpinner.setAdapter(adapter);
        displayAccountStatus(0);
    }

    private void hideProfitReportSection() {
        resetTimer();
        hideShow(R.id.profitReportGroup, GONE);
        profitReportNumDays.setText("");
        profitReportNumDays.removeErrorMessage();

    }

    private void showProfitReportSection() {
        resetTimer();
        hideShow(R.id.profitReportGroup, View.VISIBLE);

        authenticateForReports();

        accountNumbers = new ArrayList<>();

        for (Map.Entry<String, String> entry : getAccountsList().entrySet()) {
            String value = entry.getValue();
            accountNumbers.add(value);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, accountNumbers);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        profitReportAccountNumberSpinner.setAdapter(adapter);
        getselectedAccount("");


        shifts = new ArrayList<>();

        shifts.add("Current Shift");
        for (Map.Entry<String, String> entry : getShiftList().entrySet()) {
            String value = entry.getValue();
            shifts.add(value);
        }

        ArrayAdapter<String> shiftsAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, shifts);
        shiftsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        profitReportShiftSpinner.setAdapter(shiftsAdapter);
        getselectedShift("");


    }

    private void hideStatementSection() {
        resetTimer();
        hideShow(R.id.statementGroup, GONE);
        statementReportNumDays.setText("");
        statementReportNumDays.removeErrorMessage();

    }

    private void showStatementSection() {
        resetTimer();
        hideShow(R.id.statementGroup, View.VISIBLE);

        authenticateForReports();


        accountNumbers = new ArrayList<>();

        for (Map.Entry<String, String> entry : getAccountsList().entrySet()) {
            String value = entry.getValue();
            accountNumbers.add(value);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, accountNumbers);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        statementReportAccountNumberSpinner.setAdapter(adapter);
        getselectedAccount("");
    }

    private void hideInvoicingSection() {
        resetTimer();
        hideShow(R.id.invoicingGroup, GONE);

    }

    private void showInvoicingSection() {
        resetTimer();
        hideShow(R.id.invoicingGroup, View.VISIBLE);

        mustgetInvoiceList = true;
        mustgetAccountList = false;
        mustgetShiftList = false;
        //

        // authenticateForReports();

        accountNumbers = new ArrayList<>();

        // accountNumbers.add("--Select Account--");
        for (Map.Entry<String, String> entry : getAccountsList().entrySet()) {
            String value = entry.getValue();
            accountNumbers.add(value);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, accountNumbers);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        invoicingReportAccountNumberSpinner.setAdapter(adapter);
    }

    private void hideViewShiftSection() {
        resetTimer();
        hideShow(R.id.viewShiftGroup, GONE);

    }

    private void showViewShiftSection() {
        resetTimer();
        hideShow(R.id.viewShiftGroup, View.VISIBLE);

        authenticateForReports();

        shifts = new ArrayList<>();

        shifts.add("Current Shift");
        for (Map.Entry<String, String> entry : getShiftList().entrySet()) {
            String value = entry.getValue();
            shifts.add(value);
        }

        ArrayAdapter<String> shiftsAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, shifts);
        shiftsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        viewShiftReportShiftSpinner.setAdapter(shiftsAdapter);
        getselectedShift("");
    }

    private void hideEmergencyTopUpSection() {
        resetTimer();
        hideShow(R.id.emergencyTopUpGroup, GONE);
        statementReportNumDays.removeErrorMessage();

    }

    private void showEmergencyTopUpSection() {
        resetTimer();
        hideShow(R.id.emergencyTopUpGroup, View.VISIBLE);

        authenticateForReports();
        accountNumbers = new ArrayList<>();

        for (Map.Entry<String, String> entry : getAccountsList().entrySet()) {
            String value = entry.getValue();
            accountNumbers.add(value);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, accountNumbers);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        etuReportAccountNumberSpinner.setAdapter(adapter);
        getselectedAccount("");
    }

    private void hideDailyBatchReportSection() {
        resetTimer();
        hideShow(R.id.dailyBatchReportGroup, GONE);

    }

    private void showDailyBatchReportSection() {
        resetTimer();
        hideShow(R.id.dailyBatchReportGroup, View.VISIBLE);

        authenticateForReports();
    }

    private void displayAccountStatus(int index) {
        BluDroidTextView totalBalance = findViewById(R.id.totalBalanceText);
        BluDroidTextView overDraftLimit = findViewById(R.id.overDraftLimitText);
        BluDroidTextView securityDeposit = findViewById(R.id.securityDepositText);
        BluDroidTextView reservedAmount = findViewById(R.id.reservedAmountText);
        BluDroidTextView availableBalance = findViewById(R.id.availableBalanceText);

        try {
            ReportsResponseAccountValuesMessage accountValues =
                    reportsAccountInfoAuthenticationResponseMessage.
                            getData().getAccountInfo().getAccounts().get(index);

            totalBalance.setText(getResources().getString(R.string.format_amount, accountValues.getTotalBalance()));
            overDraftLimit.setText(getResources().getString(R.string.format_amount, accountValues.getOverdraftLimit()));
            securityDeposit.setText(getResources().getString(R.string.format_amount, accountValues.getSecurityDeposit()));
            reservedAmount.setText(getResources().getString(R.string.format_amount, accountValues.getReservedAmount()));
            availableBalance.setText(getResources().getString(R.string.format_amount, accountValues.getAvailableBalance()));


        } catch (Exception exception) {
            Log.v(TAG, "displayAccountStatus " + exception);
        }
    }

    private void populateInvoiceListSpinner() {

        ArrayList<String> invoices;

        if (reportsResponseInvoiceListMessage != null) {
            invoices = new ArrayList<>();
            for (int i = 0; i < reportsResponseInvoiceListMessage.getData().getInvoices().size(); i++) {
                Log.d(TAG, "adding invoice " + reportsResponseInvoiceListMessage.getData().getInvoices().get(i).getText() + " - " +
                        reportsResponseInvoiceListMessage.getData().getInvoices().get(i).getId());
                invoices.add(reportsResponseInvoiceListMessage.getData().getInvoices().get(i).getText() + " - " +
                        reportsResponseInvoiceListMessage.getData().getInvoices().get(i).getId());
            }


            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, invoices);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            adapter.notifyDataSetChanged();
            invoicingReportInvoiceListSpinner.setAdapter(adapter);


        }
    }


    private String getselectedAccount(String accountNumber) {
        String accountId = "";

        try {

            for (int i = 0; i < reportsResponseAccountListMessage.getData().getAccounts().size(); i++) {
                if (accountNumber.equals(reportsResponseAccountListMessage.getData().getAccounts().get(i).getText())) {
                    accountId = reportsResponseAccountListMessage.getData().getAccounts().get(i).getId();
                }
            }
        } catch (Exception exception) {
            Log.v(TAG, "getAccountStatus " + exception);
        }
        return accountId;
    }

    private String getselectedShift(String shift) {
        String shiftId = "";

        try {

            for (int i = 0; i < reportsResponseShiftListMessage.getData().getShifts().size(); i++) {
                if (shift.equals(reportsResponseShiftListMessage.getData().getShifts().get(i).getText())) {
                    shiftId = reportsResponseShiftListMessage.getData().getShifts().get(i).getId();
                }
            }
        } catch (Exception exception) {
            Log.v(TAG, "getselectedShift " + exception);
        }
        return shiftId;
    }

    @Override
    public void onClick(View v) {
        logger.info("ActivityReports" + ((BluDroidButton) v).getText());
        if (v.getId() == R.id.printTransactionLst) {
            if (rbDays.isChecked()) {
                if (trxByDays.validate()) {
                    mustAuthenticateForAccounts = false;
                    String days = transactionListdaysEditText.getText().toString().trim();
                    getTransactionList(days);
                }
            } else {
                if (trxByDateTime.validate()) {
                    try {
                        String start = txtStartDate.getText().toString() + " " + txtStartTime.getText().toString();
                        String end = txtEndDate.getText().toString() + " " + txtEndTime.getText().toString();

                        SimpleDateFormat sdfDateTime = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US);
                        Date startSelected = sdfDateTime.parse(start);
                        Date endSelected = sdfDateTime.parse(end);

                        Calendar startLimit = Calendar.getInstance();
                        startLimit.set(Calendar.HOUR_OF_DAY, 0);
                        startLimit.set(Calendar.MINUTE, 0);
                        startLimit.set(Calendar.SECOND, 0);
                        startLimit.set(Calendar.MILLISECOND, 0);
                        startLimit.add(Calendar.MONTH, -3);

                        if (endSelected.before(startSelected)) {
                            Toast.makeText(this, "Start date/time cannot be after End date/time", Toast.LENGTH_SHORT).show();
                        } else if (startSelected.before(startLimit.getTime())) {
                            Toast.makeText(this, "Start date cannot be older than 3 months", Toast.LENGTH_SHORT).show();
                        } else {
                            Log.d(TAG, "get transaction list by datetime");

                            Log.v("TrxList", "start cal = " + start);
                            Log.v("TrxList", "end cal = " + end);

                            getTransactionListDateTime(start, end);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Invalid date/time selection", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        } else if (v.getId() == R.id.printAccountStatus) {
            print(reportsAccountInfoAuthenticationResponseMessage.
                    getData().getAccountInfo().getPrintLines());
        } else if (v.getId() == R.id.printProfitReport) {
            //authenticateForReports();
            if (profitReportOption.equalsIgnoreCase("days")) {
                if (profitReportLayout.validate()) {
                    String days = profitReportNumDays.getText().toString().trim();
                    getProfitReportByDays(accountId, days);
                }
            } else if (profitReportOption.equalsIgnoreCase("shift")) {
                getProfitReportByShift(accountId, shiftId);
            }

        } else if (v.getId() == R.id.printStatementReport) {
            if (statementGroup.validate()) {
                String days = statementReportNumDays.getText().toString().trim();
                getStatementReport(accountId, days);
            }

        } else if (v.getId() == R.id.printInvoicingReport) {
            if (accountId != null && invoiceId != null) {
                printInvoiceReport(accountId, invoiceId);
            }
        } else if (v.getId() == R.id.printViewShiftReport) {
            printShiftReport(shiftId);
        } else if (v.getId() == R.id.printEtuReport) {
            if (emergencyTopUpGroup.validate()) {
                String days = etuReportNumDays.getText().toString().trim();
                printETUReport(accountId, days);
            }
        } else if (v.getId() == R.id.printDbrReport) {

            printDailyBatchReport(dbrDateIndicator.getText().toString().trim());
        }

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            if (buttonView.getId() == R.id.radio_days) {
                profitReportOption = "days";
                showProfitReportByDays();
                hideProfitReportByShift();
                hideProfitReportByDateRange();
            } else if (buttonView.getId() == R.id.radio_shift) {
                profitReportOption = "shift";
                showProfitReportByShift();
                hideProfitReportByDateRange();
                hideProfitReportByDays();
            } else if (buttonView.getId() == R.id.radio_date_range) {
                profitReportOption = "dateRange";
                showProfitReportByDateRange();
                hideProfitReportByDays();
                hideProfitReportByShift();
            }
        }
    }


    //Days
    private void hideProfitReportByDays() {
        resetTimer();
        hideShowWithAnimation(R.id.layoutDays, animHide, GONE);

    }

    private void showProfitReportByDays() {
        resetTimer();
        hideShowWithAnimation(R.id.layoutDays, animShow, View.VISIBLE);
    }


    //'Shift
    private void hideProfitReportByShift() {
        resetTimer();
        hideShowWithAnimation(R.id.layoutShift, animHide, GONE);

    }

    private void showProfitReportByShift() {
        resetTimer();
        hideShowWithAnimation(R.id.layoutShift, animShow, View.VISIBLE);
    }

    //Range
    private void hideProfitReportByDateRange() {
        resetTimer();
        hideShowWithAnimation(R.id.layoutDateFrom, animHide, GONE);
        hideShowWithAnimation(R.id.layoutDateTo, animHide, GONE);

    }

    private void showProfitReportByDateRange() {
        resetTimer();
        hideShowWithAnimation(R.id.layoutDateFrom, animShow, View.VISIBLE);
        hideShowWithAnimation(R.id.layoutDateTo, animShow, View.VISIBLE);
    }


    @Override
    public void results(Object object) {

        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(Reports) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }
        if (object instanceof ReportsResponseInvoiceListMessage) {
            Log.d(TAG, "ReportsResponseInvoiceListMessage");
            dismissProgress();
            //dismissProgress();
            reportsResponseInvoiceListMessage = (ReportsResponseInvoiceListMessage) object;

            populateInvoiceListSpinner();

        } else if (object instanceof ReportsResponsePrintInvoiceMessage) {
            Log.d(TAG, "ReportsResponsePrintInvoiceMessage");
            dismissProgress();
            ReportsResponsePrintInvoiceMessage reportsResponsePrintInvoiceMessage = (ReportsResponsePrintInvoiceMessage) object;
            if (Boolean.valueOf(getPreference(PREF_PRINT_PREVIEWS)))
                createBluDroidPreviewInvoicingDialog(reportsResponsePrintInvoiceMessage.getData().getLines());
            else
                print(reportsResponsePrintInvoiceMessage.getData().getLines());

        } else if (object instanceof TenderAuthenticationResponseMessage) {
            Log.v(TAG, "tender authentication received");
            dismissProgress();
            TenderAuthenticationResponseMessage response = (TenderAuthenticationResponseMessage) object;
            if (response.getEvent().getEventCode().equals("0")) {

                clearUntenderd(response);

            } else {
                createSystemErrorConfirmation(response, true);
            }
        } else if (object instanceof TenderResponseMessage) {

            TenderResponseMessage response = (TenderResponseMessage) object;


            if (response.getEvent().getEventCode().equals("0")) {
                saveAccountDetails(response.getData().getAccounts());

                File[] notTendered = getNotTendered();
                for (File file : notTendered) {
                    Log.v(TAG, "deleting is " + file.getPath());
                    //noinspection ResultOfMethodCallIgnored
                    file.delete();
                }

                authenticateForReports();
            }
        } else {
            super.results(object);
        }

        if (object != null && !(object instanceof Socket)) {
            firebaseBundle = new Bundle();
            firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            mFirebaseAnalytics.logEvent("aeon_connection", firebaseBundle);
        }
    }

    @Override
    public void onBackPressed() {
        resetTimer();
        closeAeonSocket(4);
        gotoMainScreen();

    }


}
