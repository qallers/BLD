package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseManufacturerMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseProductMessage;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidSearchEditText;


/**
 * Created by warren2.0 on 2017/04/13.
 */

public class FragmentConfigFavourites extends BaseFragment implements TextWatcher {

    private final String TAG = this.getClass().getSimpleName();
    private Spinner categorySpinner, providerSpinner;
    private ListView optionsList;
    private VoucherUtility vUtility;
    private Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> vouchers = null;
    private ArrayList<Map<String, String>> productList = null;
    private String strMessage;
    private FavouritesListAdapter favouritesListAdapter;

    public FragmentConfigFavourites() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_configure_favourites, container, false);


        categorySpinner = rootView.findViewById(R.id.categorySpinner);
        providerSpinner = rootView.findViewById(R.id.providerSpinner);
        optionsList = rootView.findViewById(R.id.optionsList);
        BluDroidSearchEditText searchEdt = rootView.findViewById(R.id.searchEdt);
        vUtility = new VoucherUtility(getBaseActivity());

        populateCategory();

        /*
         * Cancel button and click event listener
         */
        BluDroidButton cancelConfig = rootView.findViewById(R.id.cancelConfig);
        cancelConfig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                getBaseActivity().getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, new FragmentFavourites(), "FragmentFavourites").commit();
            }
        });

        /*
         * Add to favourites button and click event listener
         */
        BluDroidButton addFavourates = rootView.findViewById(R.id.addFavourates);
        addFavourates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                Log.v(TAG, "Checkbox list size   : " + getBaseActivity().configFavouritesList.size());

                if (getBaseActivity().configFavouritesList.size() > 0) {
                    strMessage = "";
                    for (Map<String, String> option : getBaseActivity().configFavouritesList) {
                        List<String> favourites = new ArrayList<>();
                        String textDesc = option.get("textDesc");

                        if (!textDesc.isEmpty()) {
                            textDesc = getCleanDesc(option.get("textDesc"), option.get("tag"));
                        }

                        String voucherType = getCleanVoucherType(option.get("voucherType"));

                        String strData = ((textDesc.isEmpty()) ? "N/A" : textDesc)
                                + ":" + (((option.get("textValue")).isEmpty()) ? "N/A" : option.get("textValue"))
                                + ":" + ((option.get("stockId").isEmpty()) ? "N/A" : option.get("stockId"))
                                + ":" + ((voucherType.isEmpty()) ? "N/A" : voucherType)
                                + ":" + ((option.get("tag").isEmpty()) ? "N/A" : option.get("tag"))
                                + ":" + ((option.get("voucherTypeDesc").isEmpty()) ? "N/A" : option.get("voucherTypeDesc"));
                        favourites.add(strData);

                        Log.v(TAG, strData);

                        if ((getBaseActivity().getFavouritesList()).size() < 21) {
                            if (!getBaseActivity().checkFavouritesListEntry(strData)) {
                                getBaseActivity().saveFavouritesList(favourites);
                                strMessage += "- " + option.get("textDesc") + " added.\n\n";
                            } else {
                                //getBaseActivity().createAlertDialog(getBaseActivity().getResources().getString(R.string.dialogTitle), option.get("textDesc").toString() + " already exists in your favourites.");
                                if (!strMessage.contains(option.get("textDesc"))) {
                                    strMessage += "- " + option.get("textDesc") + " already exists." + "\n\n";
                                }
                            }
                        } else {
                            strMessage += getBaseActivity().getResources().getString(R.string.dialogMaxFavourites) + "\n\n";
                        }


                    }
                    final BluDroidAlertDialog alert = getBaseActivity().createFavouritesDialog("Add to Favuorites");
                    String strFinalMessage;
                    if (strMessage.isEmpty()) {
                        strFinalMessage = "Selected items have been added to favourites.";
                    } else {
                        strFinalMessage = "Process completed with the following: \n\n" + strMessage;
                    }
                    alert.setTitle("Add to Favuorites");
                    alert.setMessage(strFinalMessage);
                    alert.setPositiveOption(getBaseActivity().getString(R.string.continue_true), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            getBaseActivity().getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, new FragmentConfirmConfigFavourites(), "FragmentFavourites").commit();
                        }
                    });
                    alert.setNegativeOption(getBaseActivity().getString(R.string.addMore), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            getBaseActivity().getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, new FragmentConfigFavourites(), "FragmentFavourites").commit();
                        }
                    });
                    alert.show();


                } else {
                    getBaseActivity().createAlertDialog("Add Favourate", "Please select an option to contiunue");
                }

            }
        });

        searchEdt.addTextChangedListener(this);

        return rootView;
    }

    @Override
    public void onDestroy() {
        if (optionsList != null) optionsList.setAdapter(null);
        super.onDestroy();
    }

    private void populateCategory() {
        ArrayList<String> category = new ArrayList<>();
        category.add(0, BluDroidMenuItems.MENU_AIRTIME.toString());
        category.add(1, BluDroidMenuItems.MENU_DATA.toString());
        category.add(2, BluDroidMenuItems.MENU_ELECTRICITY.toString());
        category.add(3, BluDroidMenuItems.MENU_VOUCHERS.toString());

        ArrayAdapter<String> categoryListAdapter = new ArrayAdapter<>(getContext(), R.layout.spinner_item, category);
        categoryListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        categorySpinner.setAdapter(categoryListAdapter);
        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String strCategory = ((TextView) parent.getSelectedView()).getText().toString().trim();
                populateProvider(strCategory);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void populateProvider(String category) {

        Log.v(TAG, category);
        vouchers = vUtility.getVouchers(category);
        ArrayList<String> providerList = new ArrayList<>();

        int count = 0;

        Log.v(TAG, "Category: " + category);

        if (vouchers != null) {
            for (VoucherListResponseManufacturerMessage key : vouchers.keySet()) {
                String providerName = key.getName();
                providerList.add(count, providerName);
                count++;
                Log.v(TAG, "Provider: " + key);
                Log.v(TAG, "***************************************");
            }
        }


        ArrayAdapter<String> providerListAdapter = new ArrayAdapter<>(getContext(), R.layout.spinner_item, providerList);
        providerListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        providerSpinner.setAdapter(providerListAdapter);
        providerSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String strProvider = ((TextView) parent.getSelectedView()).getText().toString().trim();

                if (vouchers != null) {
                    productList = new ArrayList<>();

                    for (VoucherListResponseManufacturerMessage mapKey : vouchers.keySet()) {

                        String key = mapKey.getName();
                        if (strProvider.equalsIgnoreCase(key)) {
                            ArrayList<VoucherListResponseProductMessage> products = vouchers.get(key);
                            //CheckBox checkBox;
                            for (int i = 0; i < products.size(); i++) {

                                HashMap<String, String> map = new HashMap<>();
                                map.put("textDesc", products.get(i).getName());
                                map.put("textValue", products.get(i).getValue());
                                map.put("stockId", products.get(i).getText());
                                map.put("voucherType", products.get(i).getCategoryDesc());
                                map.put("tag", strProvider);
                                productList.add(map);
                            }
                            favouritesListAdapter = new FavouritesListAdapter(getBaseActivity(), R.layout.favourites_option_item, productList);
                            optionsList.setAdapter(favouritesListAdapter);
                            getBaseActivity().configFavouritesList = new ArrayList<>();
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private String getCleanDesc(String description, String network) {
        //THIS IS ULGY - NOT WRITTEN BY WARREN :P
        //Specifics ESTA wanted :(
        String cleanDescription = "";
        String currency = getBaseActivity().getResources().getString(R.string.currency);
        if (network.startsWith("x")) {
            network = network.replace("x", "");
        }

        Pattern pattern = Pattern.compile(currency + "\\s*\\d*");

        Matcher matcher = pattern.matcher(description);
        description = matcher.replaceAll("");

        pattern = Pattern.compile("\\.[0-9]*");
        matcher = pattern.matcher(description);
        description = matcher.replaceAll("");

        Log.v(TAG, description.trim());

        String[] parts = description.split(" |\\(|\\)|\\,");
        for (String part : parts) {
            if (!part.equalsIgnoreCase(network) &&
                    !part.equalsIgnoreCase("Airtime") &&
                    !part.equalsIgnoreCase("Data") &&
                    !part.equalsIgnoreCase("Cell") &&
                    !part.equalsIgnoreCase("C") &&
                    !part.equalsIgnoreCase("TelkomMobile") &&
                    !part.equalsIgnoreCase("8ta") &&
                    !part.equalsIgnoreCase("TOP") &&
                    !part.equalsIgnoreCase("TV") &&
                    !part.equalsIgnoreCase("Hollywood") &&
                    !part.equalsIgnoreCase("Bets")) {
                cleanDescription += part + " ";
            }
        }


        Log.v(TAG, cleanDescription.trim());

        return cleanDescription.trim();
    }

    private String getCleanVoucherType(String voucherType) {
        String type = "";

        Log.v(TAG, voucherType.trim());

        if (voucherType.equalsIgnoreCase("Airtime") || voucherType.equalsIgnoreCase("Electricity") || voucherType.equalsIgnoreCase("Other")) {
            type = "voucher";
        } else if (voucherType.equalsIgnoreCase("data") || voucherType.equalsIgnoreCase("Data & Bundle")) {
            type = "bundle";
        }


        Log.v(TAG, type.trim());
        Log.v(TAG, "********");

        return type;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        String title = getActivity().getResources().getString(R.string.configure_favourites);
        getActivity().setTitle(title);
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        favouritesListAdapter.getFilter().filter(s);
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}