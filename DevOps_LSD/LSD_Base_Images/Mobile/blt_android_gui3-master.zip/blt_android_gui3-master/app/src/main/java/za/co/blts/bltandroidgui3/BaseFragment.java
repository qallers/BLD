package za.co.blts.bltandroidgui3;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import sunmi.paylib.SunmiPayKernel;
import za.co.blt.interfaces.external.factories.TicketProRequestFactory;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestAllEventsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestAllowedProductsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestCategoriesMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestCheckOutMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestCreateCartMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestEventDetailsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPaymentMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPrintMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseParentAllEventMessage;
import za.co.blts.bltandroidgui3.blt_draggable.ItemTouchCallback;
import za.co.blts.bltandroidgui3.blt_draggable.OnStartDragListener;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.menu.FragmentMenu;
import za.co.blts.bltandroidgui3.widgets.BluRecyclerView;
import za.co.blts.loyalty.BluDroidNFCCardAsyncResponse;
import za.co.blts.loyalty.FragmentNFCCustomerRegistration;
import za.co.blts.loyalty.FragmentNFCEditCustomerProfile;
import za.co.blts.loyalty.FragmentNFCGetConsumerProfile;
import za.co.blts.nfcbus.FragmentCustomerProfile;
import za.co.blts.nfcbus.FragmentFareList;
import za.co.blts.nfcbus.FragmentNewTicket;
import za.co.blts.nfcbus.FragmentNewTicketEnhanced;
import za.co.blts.nfcbus.FragmentPurchaseTicket;
import za.co.blts.nfcbus.FragmentTicketList;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASHIER_END_SHIFT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASH_DRAWER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_ENABLE_TECH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_ENABLE_USER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_BASKET;

/**
 * Created by warrenm on 2016/10/10.
 */

public class BaseFragment extends Fragment implements NeedsAEONResults, OnStartDragListener {

    private final String TAG = this.getClass().getSimpleName();

    List<CardviewDataObject> listOfCardItems = null;
    private ItemTouchHelper itemTouchHelper;

    BluRecyclerView recycler;
    BluRecyclerAdapter adapter;
    protected SunmiPayKernel mSunmiPayKernel = null;
//    protected static int cartCount = 0;
//    TextView countText = null;

//    protected static ArrayList<tenderItem> basketItems = null;

    GridLayoutManager grid;

    boolean canDrag = false;
    LinkedList<Provider> providersList = null;

    public static boolean canDoChatForChange = false;

    private ItemOffsetDecoration itemDecoration;

    public String collectRefNumber;

//    public static ArrayList<String> ricaSerialNumberList;

    @Override
    public void onDestroy() {
        if (recycler != null) recycler.setAdapter(null);
        super.onDestroy();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        collectRefNumber = "";
        itemDecoration = new ItemOffsetDecoration(getActivity(), R.dimen.item_offset);


        getBaseActivity().toolbar.removeAppLogo();
        getBaseActivity().toolbar.setTextColorWhite();

        if (!(this instanceof FragmentNewTicket
                || this instanceof FragmentNewTicketEnhanced
                || this instanceof FragmentTicketList
                || this instanceof FragmentFareList
                || this instanceof FragmentCustomerProfile
                || this instanceof FragmentPurchaseTicket)) {
            getBaseActivity().toolbar.setNavigationDrawable();
            menuFragmentClickListener();

            if (BaseActivity.consumerProfile == null) {
                getBaseActivity().toolbar.setSubtitle(BaseActivity.loggedInUserName);
            } else {
                getBaseActivity().toolbar.setSubtitle(BaseActivity.consumerProfile.getName() + " " + BaseActivity.consumerProfile.getSurname());
            }
        }

        String fragment = this.getClass().getSimpleName();
        getBaseActivity().crashLog("Fragment", fragment);

        /*
         * MVP
         * =========================================================================================================================================================
         */

        listOfCardItems = new ArrayList<CardviewDataObject>() {
        };

        grid = new GridLayoutManager(getActivity(), calculateNumOfColumns(getActivity()));

    }

    public void menuFragmentClickListener() {
        getBaseActivity().toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getBaseActivity().resetTimer();
                getBaseActivity().gotoMenuFragment();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            // Using reflection to get the field which in our case contains the fragment name like "Airtime"
            // PS - This is of course assuming that it has been set correctly elsewhere, we could
            //      of course also maybe get the name of the fragment class and use that... might be easier
            String fragment = this.getClass().getSimpleName();
            if (!(fragment.contains("Rica") ||
                    fragment.contains("TransactTrafficFines") ||
                    fragment.contains("TransactAccounts") ||
                    fragment.contains("Eskom")))
                getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), fragment, null);
        } catch (Exception err) {
            Log.d(TAG, "Exception on obtaining Fragment title for FireBase: " + err);
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onStartDrag(RecyclerView.ViewHolder viewHolder) {
        itemTouchHelper.startDrag(viewHolder);
    }

    //Test code
    private int calculateNumOfColumns(Context context) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        float dpWidth = displayMetrics.widthPixels / displayMetrics.density;
        int noOfColumns;

        if (displayMetrics.densityDpi >= DisplayMetrics.DENSITY_XXXHIGH) {
            noOfColumns = (int) (dpWidth / 204);
        } else if (displayMetrics.densityDpi == DisplayMetrics.DENSITY_XXHIGH) {
            noOfColumns = dpWidth > 600 ? (int) dpWidth / 204 : (int) dpWidth / 120;
        } else if (displayMetrics.densityDpi == DisplayMetrics.DENSITY_XHIGH) {
            noOfColumns = dpWidth > 600 ? (int) dpWidth / 204 : (int) dpWidth / 120;
        } else if (displayMetrics.densityDpi == DisplayMetrics.DENSITY_HIGH) {
            noOfColumns = dpWidth > 600 ? (int) dpWidth / 204 : (int) dpWidth / 120;
        } else if (displayMetrics.densityDpi == DisplayMetrics.DENSITY_MEDIUM) {
            noOfColumns = dpWidth > 600 ? (int) dpWidth / 204 : (int) dpWidth / 120;
        } else {
            noOfColumns = dpWidth > 600 ? (int) dpWidth / 204 : (int) dpWidth / 120;
        }
        return noOfColumns;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();

        boolean nfcEnabled = getBaseActivity().getPreference(PREF_LOYALTY_ENABLE_TECH).equals(PREF_TRUE)
                && getBaseActivity().getPreference(PREF_LOYALTY_ENABLE_USER).equals(PREF_TRUE)
                && !getBaseActivity().isGcrs()
                && !getBaseActivity().isGcrsSkin();

        if (this instanceof FragmentNFCGetConsumerProfile
                || this instanceof FragmentNFCCustomerRegistration
                || this instanceof FragmentNFCEditCustomerProfile) {
            return;
        }

        getActivity().getMenuInflater().inflate(R.menu.options_menu, menu);
        MenuItem nfcLogoutMenuItem = menu.findItem(R.id.nfcLogoutOnBar);
        nfcLogoutMenuItem.setVisible(getBaseActivity().isConsumerProfileActive() && nfcEnabled);

        if (this instanceof FragmentMenu) {
            return;
        }

        //*************************TOOLBAR ICONS********************************************

        //=======only show event cart menu item if seats have been reserved=====
        MenuItem cartItem = menu.findItem(R.id.eventCart);
        boolean hasReservedSeats = getBaseActivity().ticketProResponseReservedSeatsMessage != null && !getBaseActivity().ticketProResponseReservedSeatsMessage.getData().getSeats().isEmpty();
        boolean displayEventCart = hasReservedSeats && (this instanceof FragmentTicketProPriceCategory
                || this instanceof FragmentTicketProCategories
                || this instanceof FragmentTicketProEventDetails
                || this instanceof FragmentTicketProEvents);
        cartItem.setVisible(displayEventCart);
        //======================================================================
        //only show refresh event cache menu item on FragmentTicketProCategories
        MenuItem refreshItem = menu.findItem(R.id.eventCacheRefresh);
        refreshItem.setVisible(this instanceof FragmentTicketProCategories);
        //======================================================================
        MenuItem calculatorMenuItem = menu.findItem(R.id.calculator);
        Drawable calculatorMenuItemDrawable = menu.findItem(R.id.calculator).getIcon();
        calculatorMenuItemDrawable.setColorFilter(getBaseActivity().getSkinResources().getButtonTextColor(), PorterDuff.Mode.SRC_IN);

        if (getPreference(PREF_USE_BASKET).equals(PREF_TRUE)) {
            calculatorMenuItem.setVisible(true);
        } else {
            calculatorMenuItem.setVisible(false);
        }
        //=======================================================================
        //only show nfc icon if consumer is not already logged in
        MenuItem nfcMenuItem = menu.findItem(R.id.nfcOnBar);
        Drawable nfcMenuItemDrawable = menu.findItem(R.id.nfcOnBar).getIcon();
        nfcMenuItemDrawable.setColorFilter(getBaseActivity().getSkinResources().getButtonTextColor(), PorterDuff.Mode.SRC_IN);


        nfcMenuItem.setVisible(!getBaseActivity().isConsumerProfileActive() && nfcEnabled);

        //*************************DROP DOWN OPTIONS MENU********************************************

        //hide the drop down options menu if consumer profile is active
        if (!getBaseActivity().isConsumerProfileActive()) {
            MenuItem aboutItem = menu.findItem(R.id.about);
            aboutItem.setVisible(true);
            MenuItem logoutItem = menu.findItem(R.id.logout);
            logoutItem.setVisible(true);

            if (getBaseActivity().isQa() || getBaseActivity().isDebug()) {
                MenuItem crashItem = menu.findItem(R.id.crashButton);
                crashItem.setVisible(true);
            }

            MenuItem deviceSettingsItem = menu.findItem(R.id.userSettingsMenuItem);
//
//             * MVP
//             * =========================================================================================================================================================
//             * Dont show the emergency top up
            MenuItem reportsItem = menu.findItem(R.id.reports);
            MenuItem usersItem = menu.findItem(R.id.users);
            MenuItem configureFavsItem = menu.findItem(R.id.configureFavourites);
            MenuItem endShiftItem = menu.findItem(R.id.endShift);
            MenuItem cashDrawerMenuItem = menu.findItem(R.id.openCashDrawer);
            MenuItem emergencyTopupItem = menu.findItem(R.id.emerTopUp);


            //nfc
            MenuItem nfc = menu.findItem(R.id.nfc);
            MenuItem nfcRegistration = menu.findItem(R.id.nfcRegistration);
            MenuItem nfcEdit = menu.findItem(R.id.nfcEdit);
            MenuItem nfcLostCard = menu.findItem(R.id.nfcLostCard);
            MenuItem nfcDeactivateProfile = menu.findItem(R.id.nfcDeactivateProfile);

            //P1 device may not register card or replace lost card, since card tap is mandatory
            boolean deviceNfcCapable = !Build.MODEL.startsWith("V1") || getBaseActivity().isDebug();
            //only supervisor or cashier plus is allowed to edit a customer nfc profile
            boolean editNfcAllowed = getBaseActivity().userLevel.equals("1") || getBaseActivity().userLevel.equals("2");
            boolean isGcrs = getBaseActivity().isGcrs() || getBaseActivity().isGcrsSkin();

            nfcRegistration.setVisible(deviceNfcCapable);
            nfcEdit.setVisible(editNfcAllowed);
            nfcLostCard.setVisible(editNfcAllowed && deviceNfcCapable);
            nfcDeactivateProfile.setVisible(editNfcAllowed);
            //do not display NFC menu option if consumer already logged in
            nfc.setVisible(nfcEnabled && (editNfcAllowed || deviceNfcCapable) && !getBaseActivity().isConsumerProfileActive() && !isGcrs);

            //1 supervisor
            //2 cashier plus
            //0 cashier
            if (getBaseActivity().userLevel.equals("1")) {
                deviceSettingsItem.setVisible(true);
                endShiftItem.setVisible(true);
                reportsItem.setVisible(true);
                usersItem.setVisible(true);
                configureFavsItem.setVisible(!getBaseActivity().isConsumerProfileActive());

                if (getPreference(PREF_CASH_DRAWER).equals(PREF_TRUE)) {
                    if (Build.MODEL.startsWith("P1") || Build.MODEL.startsWith("V1") || Build.MODEL.startsWith("N3")) {
                        cashDrawerMenuItem.setVisible(false);
                    } else {
                        cashDrawerMenuItem.setVisible(true);
                    }
                }

                if (BaseActivity.loginResponseMessage != null) {
                    if (BaseActivity.loginResponseMessage.getData().canDoEmergencyTopup()) {
                        emergencyTopupItem.setVisible(true);
                    }
                }

            } else if (getBaseActivity().userLevel.equals("2")) {

                if (BaseActivity.loginResponseMessage != null)
                    if (BaseActivity.loginResponseMessage.getData().canDoEmergencyTopup()) {
                        emergencyTopupItem.setVisible(true);
                    }
                if (BaseActivity.loginResponseMessage != null)
                    if ((BaseActivity.loginResponseMessage.getData().canReprint() ||
                            BaseActivity.loginResponseMessage.getData().canPrintTransactionList() ||
                            BaseActivity.loginResponseMessage.getData().canPrintAccountStatus() ||
                            BaseActivity.loginResponseMessage.getData().canDoInvoicing() ||
                            BaseActivity.loginResponseMessage.getData().canPrintProfitReport() ||
                            BaseActivity.loginResponseMessage.getData().canPrintStatement() ||
                            BaseActivity.loginResponseMessage.getData().canViewShift() ||
                            BaseActivity.loginResponseMessage.getData().canDoEmergencyTopup() ||
                            BaseActivity.loginResponseMessage.getData().canPrintDailyBatchReport())) {

                        reportsItem.setVisible(true);
                    }
                if (BaseActivity.loginResponseMessage != null)
                    if (BaseActivity.loginResponseMessage.getData().canEndShift()) {
                        endShiftItem.setVisible(true);
                    }

                if (getPreference(PREF_CASH_DRAWER).equals(PREF_TRUE)) {
                    if (BaseActivity.loginResponseMessage != null)
                        if (BaseActivity.loginResponseMessage.getData().canOpenCashDrawer()) {

                            if (Build.MODEL.startsWith("P1") || Build.MODEL.startsWith("V1") || Build.MODEL.startsWith("N3")) {
                                cashDrawerMenuItem.setVisible(false);
                            } else {
                                cashDrawerMenuItem.setVisible(true);
                            }
                        }
                }

            } else if (getBaseActivity().userLevel.equals("0")) {
                if (getBaseActivity().getPreference(PREF_CASHIER_END_SHIFT).equals(PREF_TRUE)) {
                    endShiftItem.setVisible(true);
                }
            }
        }

        //only show bus tickets reprint menu item on FragmentCarmaSearchRoutesNew
        MenuItem busTicketsReprints = menu.findItem(R.id.busTicketsReprints);
        busTicketsReprints.setVisible(this instanceof FragmentCarmaSearchRoutesNew);

        //only show bus tickets reprint menu item on FragmentCarmaSearchRoutesNew
        Log.v("RemoteConfig", "bus_cancel_enable = " + getBaseActivity().mFirebaseRemoteConfig.getString("bus_cancel_enable"));
        boolean busCancelEnable = getBaseActivity().mFirebaseRemoteConfig.getString("bus_cancel_enable").equals("true");
        MenuItem busTicketsCancel = menu.findItem(R.id.busTicketsCancellation);
        busTicketsCancel.setVisible(busCancelEnable && this instanceof FragmentCarmaSearchRoutesNew && getBaseActivity().userLevel.equals("1"));


    }

    void configureRecycler(ArrayList<CardviewDataObject> list) {
        recycler.setHasFixedSize(true);

        recycler.removeItemDecoration(itemDecoration);//remove the spacing first if it exists
        recycler.addItemDecoration(itemDecoration);//then add it, or could end up with double spacing when recycler is refreshed

        recycler.setLayoutManager(grid);

        if (canDrag) {
            adapter = new BluRecyclerAdapter(this, list, this);

            ItemTouchHelper.Callback callback = new ItemTouchCallback(adapter);
            itemTouchHelper = new ItemTouchHelper(callback);
            itemTouchHelper.attachToRecyclerView(recycler);

        } else {
            adapter = new BluRecyclerAdapter(this, list);
        }

        recycler.setAdapter(adapter);

    }

    //
    // this is the default where AEONAsyncTask returns
    // results.  This should be overwritten by other
    // fragments
    //
    public void results(Object object) {
        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(Fragment) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }
        if (object instanceof Socket) {
            BaseActivity.socket = (Socket) object;
        } else {
            Log.d(TAG, "unknown return type");
        }
    }

    //
    // this is the default where AEONAsyncTask returns
    // errors.  This should be overwritten by other
    // fragments
    //
    public void error(Object object) {

        Log.d(TAG, "error " + object);
        getBaseActivity().createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, getResources().getString(R.string.slowConnection), true);
    }

    //
    // get preference for baseActivity
    //
    public String getPreference(String st) {
        return ((BaseActivity) getActivity()).getPreference(st);
    }

    BluDroidSkinResources getSkinResources() {
        return ((BaseActivity) getActivity()).getSkinResources();
    }

    public BaseActivity getBaseActivity() {
        return (BaseActivity) getActivity();
    }

    protected ActivityMain getMainActivity() {
        return (ActivityMain) getActivity();
    }

    @SuppressWarnings("unused")
    protected boolean onBackPressed() {
        getBaseActivity().gotoMainScreen();
        return true;
    }

    public void authenticateWithTicketPro() {
        Log.d("MPK", "authWithTp BaseFragment");
        try {
            getBaseActivity().createProgress(R.string.authenticating);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProAuthenticationRequestMessage ticketProAuthenticationRequestMessage =
                    factory.create(BaseActivity.loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER));
            if (BaseActivity.completeConsumerProfile != null) {
                ticketProAuthenticationRequestMessage.getEvent().setLoyaltyProfileId(BaseActivity.completeConsumerProfile.getConsumer().getProfileId());
            }
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProAuthenticationRequestMessage);

        } catch (Exception exception) {
            Log.v(TAG, "authenticate with ticketpro " + exception);
        }
    }

    void getTicketProPermissions() {

        try {
            getBaseActivity().createProgress((R.string.gettingTicketproPermissions));

            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestAllowedProductsMessage ticketProRequestAllowedMessage =
                    factory.createAllowedProducts(getBaseActivity().ticketProAuthenticationResponseMessage);

            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProRequestAllowedMessage);

        } catch (Exception exception) {
            Log.v(TAG, "problem trying to authenticate " + exception);
        }
    }

    void getTicketProCategories() {
        Log.i(TAG, "reading ticketProResponseCategoriesMessage from cache");
        getBaseActivity().ticketProResponseCategoriesMessage = getBaseActivity().getCachedTicketproCategoriesData();

        if (this instanceof FragmentTicketProCategories) {
            ((FragmentTicketProCategories) this).toBeCached = getBaseActivity().ticketProResponseCategoriesMessage == null;
        }

        if (getBaseActivity().ticketProResponseCategoriesMessage == null) {
            Log.i(TAG, "ticketProResponseCategoriesMessage = null. request again");
            try {
                getBaseActivity().createProgress(R.string.gettingTicketProCategories);

                TicketProRequestFactory factory = new TicketProRequestFactory();
                TicketProRequestCategoriesMessage ticketProRequestCategoriesMessage =
                        factory.createCategories(getBaseActivity().ticketProAuthenticationResponseMessage);
                getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProRequestCategoriesMessage);
            } catch (Exception exception) {
                Log.v(TAG, "problem trying to authenticate " + exception);
            }
        } else {
            Log.i(TAG, "calling FragmentTicketProCategories.results()");
            results(getBaseActivity().ticketProResponseCategoriesMessage);
        }
    }

    void createTicketProCart() {

        try {
            getBaseActivity().createProgress(R.string.creatingTicketProCart);
            //buildButtonLayout();
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestCreateCartMessage ticketProRequestCreateCartMessage =
                    factory.createCart(getBaseActivity().ticketProAuthenticationResponseMessage);
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProRequestCreateCartMessage);
        } catch (Exception exception) {
            Log.v(TAG, "problem trying to authenticate " + exception);
        }
    }

    void doTicketProcheckOut(String name, String cell) {
        try {
            getBaseActivity().createProgress(R.string.gettingTicketProTickets);
            Log.v(TAG, "good to check out");
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestCheckOutMessage ticketProRequestCheckOutMessage = factory.createCheckOut(
                    getBaseActivity().ticketProAuthenticationResponseMessage,
                    getBaseActivity().ticketProResponseCreateCartMessage,
                    cell,
                    name, name,
                    "", "");
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProRequestCheckOutMessage);

        } catch (Exception exception) {
            Log.v(TAG, "checking out " + exception);
        }
    }

    void getTicketProTickets() {
        try {

            getBaseActivity().createProgress(R.string.gettingTicketProTickets);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            //
            // by changing the xml to ezpl, it bypasses the xml ticket print
            //
            TicketProRequestPrintMessage ticketProRequestPrintMessage;
            if (getBaseActivity().securePrint) {
                ticketProRequestPrintMessage = factory.createPrint(
                        getBaseActivity().ticketProResponsePaymentMessage, "ezpl", "", "false");
            } else {
                ticketProRequestPrintMessage = factory.createPrint(
                        getBaseActivity().ticketProResponsePaymentMessage, "xml", "", "false");
            }

            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProRequestPrintMessage);
        } catch (Exception exception) {
            Log.v(TAG, "getTickets " + exception);
        }
    }

    void payTicketProTicket(String paymentType) {
        try {

            getBaseActivity().createProgress(R.string.indicatingPaymentType);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestPaymentMessage ticketProRequestPaymentMessage = factory.createPayment(
                    getBaseActivity().ticketProResponseCheckOutMessage,
                    getBaseActivity().ticketProResponseCheckOutMessage.getData().getBalance(),
                    paymentType, "");
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProRequestPaymentMessage);
        } catch (Exception exception) {
            Log.v(TAG, "sendPaymentType " + exception);
        }
    }

    void getTicketProAllEventDetails(TicketProResponseParentAllEventMessage event) {
        try {
            getBaseActivity().createProgress(R.string.gettingTicketProEventDetails);
            //
            // get events for this category
            //
            TicketProRequestFactory factory = new TicketProRequestFactory();

            TicketProRequestEventDetailsMessage ticketProRequestEventDetailsMessage =
                    factory.createEventDetails(getBaseActivity().ticketProAuthenticationResponseMessage,
                            event.getEventId());
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProRequestEventDetailsMessage);

        } catch (Exception exception) {
            Log.v(TAG, "problem trying to authenticate " + exception);
        }
    }

    void getAllTicketProEvents() {

        Log.i(TAG, "reading ticketProResponseAllEventMessage from cache");
        getBaseActivity().ticketProResponseAllEventsMessage = getBaseActivity().getCachedTicketproAllEventsData();
        if (this instanceof FragmentTicketProCategories) {
            ((FragmentTicketProCategories) this).toBeCached = getBaseActivity().ticketProResponseAllEventsMessage == null;
        }

        if (getBaseActivity().ticketProResponseAllEventsMessage == null) {
            Log.i(TAG, "ticketProResponseAllEventsMessage = null. request again");
            try {
                getBaseActivity().createProgress("Getting All Events");
                //
                // get events for this category
                //
                TicketProRequestFactory factory = new TicketProRequestFactory();
                TicketProRequestAllEventsMessage gettingAllTicketProEvents =
                        factory.createAllEvents(getBaseActivity().ticketProAuthenticationResponseMessage);
                getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, gettingAllTicketProEvents);

            } catch (Exception exception) {
                Log.v(TAG, "problem trying to authenticate " + exception);
            }
        } else {
            Log.i(TAG, "calling FragmentTicketProCategories.results()");
            results(getBaseActivity().ticketProResponseAllEventsMessage);
        }
    }

    //----------------------------------------------------------------------------------------------
    void doTicketProReprint(String bookingReference) {
        try {
            Log.v(TAG, "need to reprint now");
            getBaseActivity().createProgress(R.string.gettingTicketProTickets);

            String format;
            if (getBaseActivity().securePrint) {
                format = "ezpl";
            } else {
                format = "xml";
            }
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestPrintMessage ticketProRequestPrintMessage = factory.createPrint(
                    getBaseActivity().ticketProAuthenticationResponseMessage,
                    format,
                    bookingReference,
                    "true");
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProRequestPrintMessage);

        } catch (Exception exception) {
            Log.v(TAG, "reprinting " + exception);
        }
    }


    void doTicketProCollection(String bookingReference) {
        try {
            Log.v(TAG, "need to reprint now");
            getBaseActivity().createProgress(R.string.gettingTicketProTickets);

            String format;
            if (getBaseActivity().securePrint) {
                format = "ezpl";
            } else {
                format = "xml";
            }
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestPrintMessage ticketProRequestPrintMessage = factory.createCollection(
                    getBaseActivity().ticketProAuthenticationResponseMessage,
                    format,
                    bookingReference,
                    "false");
            collectRefNumber = "";
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, ticketProRequestPrintMessage);

        } catch (Exception exception) {
            Log.v(TAG, "reprinting " + exception);
        }
    }


    //----------------------------------------------------------------------------------------------
    public String convertHex(String input) {
        StringBuilder sb = new StringBuilder();
        int length = input.length() / 2;
        for (int i = 0; i < length; i++) {
            String st = input.substring(i * 2, i * 2 + 2);
            int k = 16 * (st.charAt(0) - '0') + (st.charAt(1) - '0');
            sb.append((char) k);
        }
        return sb.toString();
    }


    //NFC

    //----------------------------------------------------------------------------------------------

    protected void startNFCListener(BluDroidNFCCardAsyncResponse delagate) {
        Log.d("NFC", "startNFCListener");

        getBaseActivity().nfcCard.setDelegate(delagate);
        getBaseActivity().nfcCard.openReader();
        getBaseActivity().nfcCard.startListener();
    }

    protected void stopNFCListener() {
        Log.d("NFC", "stopNFCListener");
        try {
            getBaseActivity().nfcCard.stopListener();
            getBaseActivity().nfcCard.closeReader();
            getBaseActivity().nfcCard.setDelegate(null);
        } catch (Exception ex) {
            Log.d(TAG, "stopNFCListener: " + ex.getMessage());
        }
    }

}

