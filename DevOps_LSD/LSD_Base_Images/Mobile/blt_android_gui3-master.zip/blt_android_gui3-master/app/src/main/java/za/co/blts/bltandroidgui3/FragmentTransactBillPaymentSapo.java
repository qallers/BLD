package za.co.blts.bltandroidgui3;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidErrorTextView;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidMandatoryEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextWatcher;
import za.co.blts.bltandroidgui3.widgets.MoneyWatcher;
import za.co.blts.bltandroidgui3.widgets.ScreenFlow;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BP_LIMIT;

/**
 * Created by WarrenM1 on 2017/07/21.
 */

public class FragmentTransactBillPaymentSapo extends BaseFragment implements NeedsAEONResults, ScreenFlow, View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();

    private String providerId;
    private String productId;
    private String productName;
    private String paymentType;
    private String additionalFields;

    private String strAccount, strAmont, strGroupNumber, strSystemNumber, strPaymentCode, strControlCode;

    private BluDroidMandatoryEditText amountEditText;

    private ArrayList<String> receipt = null;

    private View rootView;

    public FragmentTransactBillPaymentSapo() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle bundle = getArguments();
        providerId = bundle.getString("providerId");
        productId = bundle.getString("productId");
        productName = bundle.getString("productName");
        additionalFields = bundle.getString("additionalFields");
        Log.v(TAG, "providerId is " + providerId);
        Log.v(TAG, "productId is " + productId);
        Log.v(TAG, "productName is " + productName);
        Log.v(TAG, "additionalFields is " + additionalFields);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_bill_payment_sapo, container, false);


        BluDroidTextView productNameTextView = rootView.findViewById(R.id.productName);
        productNameTextView.setText(productName);

        amountEditText = rootView.findViewById(R.id.amount);

        BluDroidButton cashButton = rootView.findViewById(R.id.cashButton);
        cashButton.setOnClickListener(this);
        BluDroidButton creditCardButton = rootView.findViewById(R.id.creditCardButton);
        creditCardButton.setOnClickListener(this);
        BluDroidButton debitCardButton = rootView.findViewById(R.id.debitCardButton);
        debitCardButton.setOnClickListener(this);

        configureScreen();

        return rootView;
    }

    private void gone(int resourceId) {
        View view = rootView.findViewById(resourceId);
        view.setVisibility(View.GONE);
    }

    private void show(int resourceId) {
        View view = rootView.findViewById(resourceId);
        view.setVisibility(View.VISIBLE);
    }

    private void configureScreen() {

        //
        // special processing for Telkom
        //
        if (additionalFields.equals("1")) {

            gone(R.id.accountNumberLabel);
            gone(R.id.accountNumber);

            setUpTextWatchers();

            setupSpinnerForGroupSystemPaymentControl();

        } else {
            gone(R.id.groupNumberLabel);
            gone(R.id.groupNumber);
            gone(R.id.groupNumberError);
            gone(R.id.systemNumberLabel);
            gone(R.id.systemNumber);
            gone(R.id.systemNumberError);
            gone(R.id.paymentCodeLabel);
            gone(R.id.paymentCode);
            gone(R.id.paymentCodeError);
            gone(R.id.controlCodeLabel);
            gone(R.id.controlCode);
            gone(R.id.controlCodeError);

            final BluDroidEditText account = rootView.findViewById(R.id.accountNumber);
            account.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView textView, int actionId, KeyEvent event) {
                    Log.v(TAG, "actionId " + actionId + " event " + event);
                    if (actionId == 0) {
                        account.setImeActionLabel(getResources().getString(R.string.next), EditorInfo.IME_ACTION_GO);
                        account.setInputType(InputType.TYPE_CLASS_TEXT);
                        return true;
                    }
                    if (actionId == 2) {
                        getBaseActivity().hideKeyboard();
                        //
                        // http://plainoldstan.blogspot.com/2010/09/android-set-focus-and-show-soft.html
                        //
                        final EditText nextField = rootView.findViewById(R.id.amount);
                        nextField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                            @Override
                            public void onFocusChange(View view, boolean hasFocus) {
                                Log.v(TAG, "view is " + view + " has Focus " + hasFocus);
                                if (hasFocus) {
                                    getBaseActivity().showKeyboard();
                                }
                            }
                        });
                        nextField.requestFocus();
                    }
                    return true;
                }
            });

            EditText editText = rootView.findViewById(R.id.amount);
            editText.addTextChangedListener(new MoneyWatcher(this, editText));

            setupSpinnerForAccount();
        }

    }

    private void setupSpinnerForAccount() {
        final Spinner accountNumberSpinner = rootView.findViewById(R.id.accountNumberSpinner);
        final BluDroidLinearLayout numberLayout = rootView.findViewById(R.id.numberLayout);
        final BluDroidMandatoryEditText accountNumber = rootView.findViewById(R.id.accountNumber);
        final BluDroidMandatoryEditText amount = rootView.findViewById(R.id.amount);

        final List<String> accountNumbers = new ArrayList<>();
        boolean hasAccountNumbers = checkCustomerProfileAccountNumbers(accountNumbers);

        if (hasAccountNumbers) {
            Log.d(TAG, "has account numbers");
            accountNumbers.add(0, "Other");
            accountNumberSpinner.setVisibility(View.VISIBLE);
            numberLayout.setVisibility(View.GONE);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getBaseActivity(), android.R.layout.simple_spinner_item, accountNumbers);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            accountNumberSpinner.setAdapter(dataAdapter);
            //although meterNumber is hidden, update this with the selected spinner value, so the dialog.validate() will pass
            accountNumber.setText(accountNumbers.get(1));
            accountNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i == 0) {
                        onNothingSelected(null);
                    } else {
                        accountNumber.setText(accountNumbers.get(i));
                        numberLayout.setVisibility(View.GONE);
                        amount.requestFocus();
                        getBaseActivity().showKeyboard();
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    accountNumber.setText("");
                    numberLayout.setVisibility(View.VISIBLE);
                    accountNumber.requestFocus();
                    getBaseActivity().showKeyboard();
                }
            });
            accountNumberSpinner.setSelection(1);

        } else {
            Log.d(TAG, "no account numbers");
            accountNumberSpinner.setVisibility(View.GONE);
            numberLayout.setVisibility(View.VISIBLE);
            accountNumber.requestFocus();
            getBaseActivity().showKeyboard();
        }

    }

    private void setupSpinnerForGroupSystemPaymentControl() {
        final Spinner concatSpinner = rootView.findViewById(R.id.concatSpinner);
        final BluDroidMandatoryEditText groupNumber = rootView.findViewById(R.id.groupNumber);
        final BluDroidMandatoryEditText systemNumber = rootView.findViewById(R.id.systemNumber);
        final BluDroidMandatoryEditText paymentCode = rootView.findViewById(R.id.paymentCode);
        final BluDroidMandatoryEditText controlCode = rootView.findViewById(R.id.controlCode);

        final List<String> accountNumbers = new ArrayList<>();
        boolean hasAccountNumbers = checkCustomerProfileAccountNumbersContainAllFourFields(accountNumbers);

        if (hasAccountNumbers) {
            Log.d(TAG, "has account numbers");
            accountNumbers.add(0, "Other");
            concatSpinner.setVisibility(View.VISIBLE);

            gone(R.id.groupNumberLabel);
            gone(R.id.groupNumber);
            gone(R.id.groupNumberError);
            gone(R.id.systemNumberLabel);
            gone(R.id.systemNumber);
            gone(R.id.systemNumberError);
            gone(R.id.paymentCodeLabel);
            gone(R.id.paymentCode);
            gone(R.id.paymentCodeError);
            gone(R.id.controlCodeLabel);
            gone(R.id.controlCode);
            gone(R.id.controlCodeError);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getBaseActivity(), android.R.layout.simple_spinner_item, accountNumbers);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            concatSpinner.setAdapter(dataAdapter);
            //although meterNumber is hidden, update this with the selected spinner value, so the dialog.validate() will pass
            String[] split = accountNumbers.get(1).split("-");

            groupNumber.setText(split[0]);
            systemNumber.setText(split[1]);
            paymentCode.setText(split[2]);
            controlCode.setText(split[3]);


            concatSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i == 0) {
                        onNothingSelected(null);
                    } else {
                        String[] split = accountNumbers.get(i).split("-");
                        groupNumber.setText(split[0]);
                        systemNumber.setText(split[1]);
                        paymentCode.setText(split[2]);
                        controlCode.setText(split[3]);

                        gone(R.id.groupNumberLabel);
                        gone(R.id.groupNumber);
                        gone(R.id.groupNumberError);
                        gone(R.id.systemNumberLabel);
                        gone(R.id.systemNumber);
                        gone(R.id.systemNumberError);
                        gone(R.id.paymentCodeLabel);
                        gone(R.id.paymentCode);
                        gone(R.id.paymentCodeError);
                        gone(R.id.controlCodeLabel);
                        gone(R.id.controlCode);
                        gone(R.id.controlCodeError);
                        getBaseActivity().hideKeyboard();
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    groupNumber.setText("");
                    systemNumber.setText("");
                    paymentCode.setText("");
                    controlCode.setText("");
                    show(R.id.groupNumberLabel);
                    show(R.id.groupNumber);
                    show(R.id.groupNumberError);
                    show(R.id.systemNumberLabel);
                    show(R.id.systemNumber);
                    show(R.id.systemNumberError);
                    show(R.id.paymentCodeLabel);
                    show(R.id.paymentCode);
                    show(R.id.paymentCodeError);
                    show(R.id.controlCodeLabel);
                    show(R.id.controlCode);
                    show(R.id.controlCodeError);
                    groupNumber.requestFocus();
                    getBaseActivity().showKeyboard();
                }
            });
            concatSpinner.setSelection(1);

        } else {
            Log.d(TAG, "no account numbers");
            concatSpinner.setVisibility(View.GONE);
            groupNumber.setText("");
            systemNumber.setText("");
            paymentCode.setText("");
            controlCode.setText("");
            show(R.id.groupNumberLabel);
            show(R.id.groupNumber);
            show(R.id.groupNumberError);
            show(R.id.systemNumberLabel);
            show(R.id.systemNumber);
            show(R.id.systemNumberError);
            show(R.id.paymentCodeLabel);
            show(R.id.paymentCode);
            show(R.id.paymentCodeError);
            show(R.id.controlCodeLabel);
            show(R.id.controlCode);
            show(R.id.controlCodeError);
            groupNumber.requestFocus();
            getBaseActivity().showKeyboard();

        }

    }

    private boolean checkCustomerProfileAccountNumbers(List<String> accountNumbers) {
        Log.d(TAG, "search for account numbers for " + productName);
        if (BaseActivity.consumerProfile != null && getBaseActivity().customerProfileBillPaymentsAccountNumbers != null) {
            String[] accounts = getBaseActivity().customerProfileBillPaymentsAccountNumbers.get(productName);
            if (accounts != null && accounts.length > 0) {
                accountNumbers.addAll(Arrays.asList(accounts));
                return true;
            }
        }
        return false;
    }

    private boolean checkCustomerProfileAccountNumbersContainAllFourFields(List<String> accountNumbers) {
        Log.d(TAG, "search for account numbers for " + productName);
        if (BaseActivity.consumerProfile != null && getBaseActivity().customerProfileBillPaymentsAccountNumbers != null) {
            String[] accounts = getBaseActivity().customerProfileBillPaymentsAccountNumbers.get(productName);
            if (accounts != null && accounts.length > 0) {
                for (String account : accounts) {
                    if (account.split("-").length == 4) {
                        accountNumbers.add(account);
                    }
                }
                return !accountNumbers.isEmpty();
            }
        }
        return false;
    }

    private void setUpTextWatchers() {
        try {
            BluDroidMandatoryEditText editText = rootView.findViewById(R.id.groupNumber);
            editText.addTextChangedListener(
                    new BluDroidTextWatcher(this, editText, 5));

            editText = rootView.findViewById(R.id.systemNumber);
            editText.addTextChangedListener(
                    new BluDroidTextWatcher(this, editText, 10));

            editText = rootView.findViewById(R.id.paymentCode);
            editText.addTextChangedListener(
                    new BluDroidTextWatcher(this, editText, 4));

            editText = rootView.findViewById(R.id.controlCode);
            editText.addTextChangedListener(
                    new BluDroidTextWatcher(this, editText, 3));


        } catch (Exception exception) {
            Log.v(TAG, "problems setting up text watchers " + exception);
        }
    }

    @Override
    public void gotMaxChars(EditText editText) {
        try {
            BluDroidEditText next;
            switch (editText.getId()) {
                case R.id.groupNumber:
                    next = rootView.findViewById(R.id.systemNumber);
                    next.requestFocus();
                    break;
                case R.id.systemNumber:
                    next = rootView.findViewById(R.id.paymentCode);
                    next.requestFocus();
                    break;
                case R.id.paymentCode:
                    next = rootView.findViewById(R.id.controlCode);
                    next.requestFocus();
                    break;
                case R.id.controlCode:
                    next = rootView.findViewById(R.id.amount);
                    next.requestFocus();
                    ScrollView scrollView = rootView.findViewById(R.id.scroller);
                    scrollView.scrollTo(0, scrollView.getBottom());
                    break;
                case R.id.amount:
                    getBaseActivity().hideKeyboard();
                    break;
                default:
                    break;
            }
        } catch (Exception exception) {
            Log.v(TAG, "problems navigating " + exception);
        }
    }

    private void validateScreen() {
        BluDroidMandatoryEditText account = null;
        amountEditText = rootView.findViewById(R.id.amount);
        BluDroidMandatoryEditText groupNumber = null;
        BluDroidMandatoryEditText systemNumber = null;
        BluDroidMandatoryEditText paymentCode = null;
        BluDroidMandatoryEditText controlCode = null;
        if (additionalFields.equals("1")) {
            groupNumber = rootView.findViewById(R.id.groupNumber);
            systemNumber = rootView.findViewById(R.id.systemNumber);
            paymentCode = rootView.findViewById(R.id.paymentCode);
            controlCode = rootView.findViewById(R.id.controlCode);

        } else {
            account = rootView.findViewById(R.id.accountNumber);
        }

        if (groupNumber != null && groupNumber.getText().toString().trim().isEmpty()) {
            BluDroidErrorTextView groupNumberError = rootView.findViewById(R.id.groupNumberError);
            groupNumberError.setText(getResources().getString(R.string.enterGroupNumber));
        } else if (systemNumber != null && systemNumber.getText().toString().trim().isEmpty()) {
            BluDroidErrorTextView systemNumberError = rootView.findViewById(R.id.systemNumberError);
            systemNumberError.setText(getResources().getString(R.string.enterSystemNumber));
        } else if (paymentCode != null && paymentCode.getText().toString().trim().isEmpty()) {
            BluDroidErrorTextView paymentCodeError = rootView.findViewById(R.id.paymentCodeError);
            paymentCodeError.setText(getResources().getString(R.string.enterPaymentCode));
        } else if (controlCode != null && controlCode.getText().toString().trim().isEmpty()) {
            BluDroidErrorTextView controlCodeError = rootView.findViewById(R.id.controlCodeError);
            controlCodeError.setText(getResources().getString(R.string.enterControlCode));
        } else if (account != null && account.getText().toString().trim().isEmpty()) {
            BluDroidErrorTextView accountNumberError = rootView.findViewById(R.id.accountNumberError);
            accountNumberError.setText(getResources().getString(R.string.enterAccount));
        } else if (amountEditText.getText().toString().trim().isEmpty()) {
            BluDroidErrorTextView amountError = rootView.findViewById(R.id.amountError);
            amountError.setText(getResources().getString(R.string.enterAmount));
        } else {


            receipt = new ArrayList<>();
            receipt.add("SAPO " + getResources().getString(R.string.billPayments));
            if (productName.length() > BaseActivity.printWidth) {
                receipt.add(productName.substring(0, BaseActivity.printWidth));
            } else {
                receipt.add(productName);
            }
            if (productName.equals("Telkom")) {
                receipt.add(getBaseActivity().format(getResources().getString(R.string.groupNumber),
                        groupNumber.getText().toString()));
                receipt.add(getBaseActivity().format(getResources().getString(R.string.systemNumber),
                        systemNumber.getText().toString()));
                receipt.add(getBaseActivity().format(getResources().getString(R.string.paymentCode),
                        paymentCode.getText().toString()));
                receipt.add(getBaseActivity().format(getResources().getString(R.string.controlCode),
                        controlCode.getText().toString()));
            } else {
                if (account != null) {
                    receipt.add(getBaseActivity().format(getResources().getString(R.string.accountNumber), account.getText().toString()));
                }
            }
            receipt.add(getBaseActivity().format(getResources().getString(R.string.amount), getBaseActivity().formatMoney(amountEditText.getText().toString())));
            receipt.add(getBaseActivity().format(getResources().getString(R.string.tenderType), paymentType));

            String confirmMessage;
            if (productName.equals("Telkom")) {
                confirmMessage = getResources().getString(R.string.groupNumber) + " : " + groupNumber.getText().toString() + "\n" +
                        getResources().getString(R.string.systemNumber) + " : " + systemNumber.getText().toString() + "\n" +
                        getResources().getString(R.string.paymentCode) + " : " + paymentCode.getText().toString() + "\n" +
                        getResources().getString(R.string.controlCode) + " : " + controlCode.getText().toString() + "\n" +
                        getResources().getString(R.string.amount) + " : " + getResources().getString(R.string.currency) +
                        amountEditText.getText().toString() + "\n" +
                        getResources().getString(R.string.paymentType) + " : " + paymentType;

                strAmont = amountEditText.getText().toString();
                strGroupNumber = groupNumber.getText().toString();
                strSystemNumber = systemNumber.getText().toString();
                strPaymentCode = paymentCode.getText().toString();
                strControlCode = controlCode.getText().toString();
            } else {
                confirmMessage = getResources().getString(R.string.accountNumber) + " : " + account.getText().toString() + "\n" +
                        getResources().getString(R.string.amount) + " : " + getResources().getString(R.string.currency) + " " +
                        amountEditText.getText().toString() + "\n" +
                        getResources().getString(R.string.paymentType) + " : " + paymentType;

                strAccount = account.getText().toString();
                strAmont = amountEditText.getText().toString();
            }

            Double bpLimit = Double.parseDouble(getBaseActivity().getPreference(PREF_BP_LIMIT));
            Double amount = Double.parseDouble(strAmont);


            if (amount <= bpLimit) {
                createConfirmDialog(confirmMessage);
            } else {

                final String message = confirmMessage;
                getBaseActivity().createBillPaymentsAlertDialog("Bill Payment Limit Exceeded",
                        "Do you wish to continue with the payment of R" + getBaseActivity().df2.format(amount) + "?");

                getBaseActivity().alert.setPositiveOption("Continue", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        createConfirmDialog(message);
                    }
                });

                getBaseActivity().alert.show();
            }


        }

    }

    private void createConfirmDialog(String message) {

        final AlertDialog alertDialog = new AlertDialog.Builder(getBaseActivity()).create();
        alertDialog.setTitle(productName);

        if (!message.isEmpty()) {
            alertDialog.setMessage(message);

            alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Pay", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (additionalFields.equals("1")) {
                        alertDialog.dismiss();
                        getBaseActivity().athenticateForSAPOMunicBill(strGroupNumber, strSystemNumber, strPaymentCode, strAmont
                                , paymentType, providerId, productId, additionalFields, receipt, productName, strControlCode);
                    } else {
                        getBaseActivity().athenticateForSAPOMunicBill(strAccount, strAmont, paymentType, providerId, productId,
                                additionalFields, receipt, productName, strControlCode);
                    }
                }
            });

            alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    alertDialog.dismiss();
                }
            });
            alertDialog.show();
        }

    }

    private void cashButton() {
        Log.v(TAG, "cashButton");
        paymentType = "cash";
        validateScreen();
    }

    private void creditCardButton() {
        Log.v(TAG, "creditCardButton");
        paymentType = "creditCard";
        validateScreen();
    }

    private void debitCardButton() {
        Log.v(TAG, "debitCardButton");
        paymentType = "debitCard";
        validateScreen();
    }


    @Override
    public void onClick(View view) {
        try {
            BaseActivity.logger.info(((BluDroidButton) view).getText());
            Log.d(TAG, "onClick");

            if (view.getId() == R.id.cashButton) {
                cashButton();
            } else if (view.getId() == R.id.creditCardButton) {

                creditCardButton();
            } else if (view.getId() == R.id.debitCardButton) {

                debitCardButton();
            }
        } catch (Exception exception) {
            Log.d(TAG, "onClick " + exception);
        }
    }

    @Override
    public boolean onBackPressed() {
        BaseActivity.logger.info(": onBackPressed()");
        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else if (getBaseActivity().navigatedFromSearch) {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentSearch(), "FragmentSearch").commit();
        } else {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentTransact(), "FragmentTransact").commit();
        }
        return true;
    }
}
