package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.util.AttributeSet;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/6/2017.
 */

public class BluDroidNfcCardEditText extends BluDroidIntegerEditText {


    public BluDroidNfcCardEditText(BaseActivity context) {
        super(context);
        setOnFocusChangeListener(null); //remove on focus change listener so validate must be called manually
    }

    public BluDroidNfcCardEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setOnFocusChangeListener(null); //remove on focus change listener so validate must be called manually

    }

    @Override
    public boolean validate() {
        String cardNumber = getText().toString().trim();

        if (cardNumber.isEmpty()) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                setErrorMessage(baseScreen.getResources().getString(R.string.required));
            }
            return false;
        } else {
            removeErrorMessage();
            return true;
        }
    }

}
