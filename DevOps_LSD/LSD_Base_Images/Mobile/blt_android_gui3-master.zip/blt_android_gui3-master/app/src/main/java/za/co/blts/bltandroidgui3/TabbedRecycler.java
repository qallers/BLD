package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.tabs.TabLayout;

/**
 * Created by warrenm on 2017/02/16.
 */

public class TabbedRecycler extends VoucherRecycler {

    private final String TAG = this.getClass().getSimpleName();
    TabLayout tabs = null;
    BluDroidPinlessPrintTabLayout pinlessPrintTabLayout = null;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        tabs = null;
    }

    void setupTabs(final Fragment fragment, TabLayout tabs) {
        providersList = vu.getProviders();
        if (providersList.size() > 0) {
            for (Provider p : providersList) {
                tabs.addTab(tabs.newTab().setText(p.getProviderName()));
            }
        }

        final int tabCount = tabs.getTabCount();

        tabs.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                getBaseActivity().resetTimer();
                if (fragment instanceof FragmentAirtime) {
                    setupPinlessPrintTabs("Airtime", tab.getText().toString().toLowerCase());
                } else if (fragment instanceof FragmentData) {
                    setupPinlessPrintTabs("Data", tab.getText().toString().toLowerCase());
                }

                if (tab.getText().toString().toLowerCase().equals("all") && tab.getPosition() == (tabCount - 1)) {
                    adapter.clearFilter();
                } else {
                    adapter.setFilter(tab.getText().toString());
                }

//                if(pinlessPrintTabLayout != null){
//                    pinlessPrintTabLayout.getTabAt(0).select();
//                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                if (fragment instanceof FragmentAirtime) {
                    setupPinlessPrintTabs("Airtime", tab.getText().toString().toLowerCase());
                } else if (fragment instanceof FragmentData) {
                    setupPinlessPrintTabs("Data", tab.getText().toString().toLowerCase());
                }

                if (tab.getText().toString().toLowerCase().equals("all") && tab.getPosition() == (tabCount - 1)) {
                    adapter.clearFilter();
                } else {
                    adapter.setFilter(tab.getText().toString());
                }

//                if(pinlessPrintTabLayout != null){
//                    pinlessPrintTabLayout.getTabAt(0).select();
//                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }
        });

    }

    private void setupPinlessPrintTabs(final String type, String tabName) {
        if (pinlessPrintTabLayout != null) {
            pinlessPrintTabLayout.removeAllTabs();

            for (Provider p : providersList) {
                if (p.getProviderName().equalsIgnoreCase(tabName)) {
                    Log.d(TAG, "GOT PROVIDER: " + p.getProviderName() + " adding tabs");
                    if (p.isHasVouchers()) {
                        pinlessPrintTabLayout.addTab(pinlessPrintTabLayout.newTab().setText(getResources().getString(R.string.printVoucher)));
                    }
                    if (type.equals("Airtime") && p.isHasTopup()) {
                        pinlessPrintTabLayout.addTab(pinlessPrintTabLayout.newTab().setText(getResources().getString(R.string.pinlessTopUp)));
                    }
                    if (type.equals("Data") && p.isHasBundles()) {
                        pinlessPrintTabLayout.addTab(pinlessPrintTabLayout.newTab().setText(getResources().getString(R.string.pinlessBundles)));
                    }
                }
            }

            pinlessPrintTabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    getBaseActivity().resetTimer();
                    if (tab.getPosition() == 0) {
                        adapter.updateData(tabs.getTabAt(tabs.getSelectedTabPosition()).getText().toString(), createCards(retrieveVoucherMap(type), type));
                    } else {
                        if (type.equals("Airtime")) {
                            adapter.updateData(tabs.getTabAt(tabs.getSelectedTabPosition()).getText().toString(), createPinlessTopupCards());
                        } else if (type.equals("Data")) {
                            adapter.updateData(tabs.getTabAt(tabs.getSelectedTabPosition()).getText().toString(), createBundledPinlessTopupCards(retrieveBundleMap()));
                        }
                    }
                    recycler.scrollToPosition(0);
                }

                @Override
                public void onTabReselected(TabLayout.Tab tab) {
                    getBaseActivity().resetTimer();
                    if (tab.getPosition() == 0) {
                        adapter.updateData(tabs.getTabAt(tabs.getSelectedTabPosition()).getText().toString(), createCards(retrieveVoucherMap(type), type));
                    } else {
                        if (type.equals("Airtime")) {
                            adapter.updateData(tabs.getTabAt(tabs.getSelectedTabPosition()).getText().toString(), createPinlessTopupCards());
                        } else if (type.equals("Data")) {
                            adapter.updateData(tabs.getTabAt(tabs.getSelectedTabPosition()).getText().toString(), createBundledPinlessTopupCards(retrieveBundleMap()));
                        }
                    }
                    recycler.scrollToPosition(0);
                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {

                }
            });
        }
    }

}
