package za.co.blts.bltandroidgui3;

import android.util.Log;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import static androidx.fragment.app.FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT;


/**
 * Created by NkosanaM on 7/14/2017.
 */

class RicaChangeOwnerPagerAdapter extends FragmentStatePagerAdapter {

    private final String TAG = this.getClass().getSimpleName();

    private Fragment[] f = new Fragment[getCount()];

    public RicaChangeOwnerPagerAdapter(FragmentManager fm) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                f[position] = new FragmentRicaChangeConsumerInfo();
                break;
            case 1:
                f[position] = new FragmentRicaChangeNewConsumerInfo();
                break;
            case 2:
                f[position] = new FragmentRicaChangeAddressInfo();
                break;
            case 3:
                f[position] = new FragmentRicaChangeSimRegistration();
                break;
            default:
                f[position] = new Fragment();
                break;
        }
        Log.d(TAG, "getItem: " + position+ " " + f[position].getClass().getSimpleName());
        return f[position];
    }

    @Override
    public int getCount() {
        return 4;
    }

    public Fragment getItemIndex(int position) {
        Log.d(TAG, "getItemIndex: " + position + " " + f[position].getClass().getSimpleName());
        return f[position];
    }


}