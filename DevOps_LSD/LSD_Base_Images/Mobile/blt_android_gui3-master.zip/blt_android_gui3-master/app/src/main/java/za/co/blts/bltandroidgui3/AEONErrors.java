package za.co.blts.bltandroidgui3;

import android.util.Log;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import za.co.blt.interfaces.external.messages.login.response.LoginResponseMessage;

@SuppressWarnings("unused")
public class AEONErrors {

    private final String TAG = this.getClass().getSimpleName();

    //  public static final Integer NO_ERROR = 0;
    public static final Integer INLINE = 1;
    //  public static final Integer USER_ACTION_REQUIRED = 2;
    public static final Integer NO_USER_ACTION_REQUIRED = 3;

    private Map<String, Integer> possibleErrors = new HashMap<>();

    //
// the key will be 
//
//    full classname,eventcode,errorcode,aeonerrorcode
//
// the value will be NO_ERROR, INLINE, or SCREEN
//
    public AEONErrors() {
        String tmp;
        /*              class name                      eventcode    errorcode     aeonerrorcode */
        tmp = LoginResponseMessage.class.getName() + "," + "1" + "," + "2" + "," + "10000";
        possibleErrors.put(tmp, NO_USER_ACTION_REQUIRED);
        tmp = LoginResponseMessage.class.getName() + "," + "1" + "," + "3" + "," + "103";
        possibleErrors.put(tmp, INLINE);
        tmp = LoginResponseMessage.class.getName() + "," + "1" + "," + "2" + "," + "102";
        possibleErrors.put(tmp, NO_USER_ACTION_REQUIRED);
    }

    //
// all assume that eventcode != 0
//
    public Integer process(Object obj) {
        try {
            //
            // we are missing some base class stuff here so
            // we need to do a bit of reflection
            //
            Method method = obj.getClass().getMethod("getEvent");
            Object eventMessage = method.invoke(obj);
            method = eventMessage.getClass().getMethod("getEventCode");
            String eventCode = (String) method.invoke(eventMessage);

            method = obj.getClass().getMethod("getData");
            Object dataMessage = method.invoke(obj);
            method = dataMessage.getClass().getMethod("getErrorCode");
            String errorCode = (String) method.invoke(dataMessage);

            method = dataMessage.getClass().getMethod("getAeonErrorCode");
            String aeonErrorCode = (String) method.invoke(dataMessage);


            String key = obj.getClass().getName() + "," + eventCode + "," + errorCode + "," + aeonErrorCode;
            Integer returnValue = possibleErrors.get(key);
            Log.d(TAG, "returning " + returnValue);
            if (returnValue != null)
                return returnValue;
        } catch (Exception exception) {
            Log.d(TAG, "reflection problem " + exception);
        }
        return NO_USER_ACTION_REQUIRED;
    }

    public String getErrorText(Object obj) {
        String errorText = "";
        String errorCode = "";
        try {
            Method method = obj.getClass().getMethod("getData");
            Object dataMessage = method.invoke(obj);
            method = dataMessage.getClass().getMethod("getAeonErrorText");
            errorText = (String) method.invoke(dataMessage);
        } catch (Exception exception) {
            Log.d(TAG, "reflection problem " + exception);
        }

        try {
            Method method = obj.getClass().getMethod("getData");
            Object dataMessage = method.invoke(obj);
            method = dataMessage.getClass().getMethod("getAeonErrorCode");
            errorCode = "A" + (String) method.invoke(dataMessage);
        } catch (Exception exception) {
            Log.d(TAG, "reflection problem " + exception);
        }

        if (errorText.isEmpty()) {
            try {
                Method method = obj.getClass().getMethod("getData");
                Object dataMessage = method.invoke(obj);
                method = dataMessage.getClass().getMethod("getErrorText");
                errorText = (String) method.invoke(dataMessage);
                method = dataMessage.getClass().getMethod("getErrorCode");
                errorCode = "B" + (String) method.invoke(dataMessage);
            } catch (Exception exception) {
                Log.d(TAG, "reflection problem " + exception);
            }
        }

        if (errorCode.isEmpty()) {
            try {
                Method method = obj.getClass().getMethod("getData");
                Object dataMessage = method.invoke(obj);
                method = dataMessage.getClass().getMethod("getErrorCode");
                errorCode = "B" + (String) method.invoke(dataMessage);
            } catch (Exception exception) {
                Log.d(TAG, "reflection problem " + exception);
            }
        }

        errorCode = errorCode.isEmpty() ? "(Error C9999)" : "(Error " + errorCode + ")";

        errorText = errorText.isEmpty() ? "An unknown error occurred.\nIf the problem persists, please contact Support." : errorText;
        return errorText + "\n\n" + errorCode;
    }

}
