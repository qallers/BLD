package za.co.blts.bltandroidgui3;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Date;

import javax.net.ssl.HttpsURLConnection;

import static za.co.blts.bltandroidgui3.BaseActivity.queue;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AWS_HEARTBEAT_MINUTES;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HEARTBEAT_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_UNKNOWN;


/*
AWS Account - Development
https://eu-west-1.console.aws.amazon.com/sqs/home?region=eu-west-1#queue-browser:selected=https://sqs.eu-west-1.amazonaws.com/834031529481/device_heartbeat_dev-queue;noRefresh=true;prefix=
Account ID: 834031529481
Username: blumaps
Password: !u8ULRMJhFTRRe-
 */


public class AwsHeartbeatService extends Service {
    private final String TAG = this.getClass().getSimpleName();

    private static long interval = 10000;  //interval between two services, can increase when we backoff after failed heartbeat
    private static long intervalDefault = 10000;  //initial interval between two services
    private Handler mHandler = new Handler();
    private int lastSignalStrength;
    private int minimumSignal;
    private int maximumSignal;
    private int averageSignal;
    private int medianSignal;

    private static boolean running = false;

    private TelephonyManager telephonyManager;
    private awsPhoneStateListener psListener;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand");
        String minutes = getPreference(PREF_AWS_HEARTBEAT_MINUTES);


        Log.d(TAG, "minutes pref = " + minutes);
        try {
            intervalDefault = Long.parseLong(minutes) * 60 * 1000;

        } catch (Exception e) {
            intervalDefault = 5 * 60 * 1000;
        }
        //intervalDefault /= 60; //debug test in seconds instead of minutes

        interval = intervalDefault;
        Log.d(TAG, "interval set to " + intervalDefault);

        telephonyManager.listen(psListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);

        mHandler = new Handler();
        running = true;
        mHandler.post(runnable);

        return START_STICKY;
    }

    @Override
    public void onCreate() {
        Log.d(TAG, "onCreate");
        psListener = new awsPhoneStateListener();

        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //signalList.clear();
        mHandler.removeCallbacks(runnable);
        running = false;
        if (telephonyManager != null && psListener != null) {
            telephonyManager.listen(psListener, PhoneStateListener.LISTEN_NONE);
        }
        Log.d(TAG, "Destroyed");
    }

    public static boolean isRunning() {
        Log.d("AwsHeartbeatService", "Running: " + running);
        return running;
    }

    private String getPreference(String key) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        return sharedPreferences.getString(key, PREF_UNKNOWN);
    }

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            try {

                //immediately reschedule the next heartbeat, so the interval remains constant & not affected by the heartbeat connect/transmit delay
                mHandler.postDelayed(this, interval);

                Log.d(TAG, "*****Sending heartbeat***** interval=" + interval);

                // String url = "https://sqs.eu-west-1.amazonaws.com/834031529481/device_heartbeat_dev-queue?Action=SendMessage&MessageBody=Your%20message%20text&Version=2012-11-05";
                AwsHeartbeat hb = new AwsHeartbeat(getPreference(PREF_DEVICE_ID), String.valueOf(lastSignalStrength),
                        String.valueOf(averageSignal), String.valueOf(medianSignal), String.valueOf(minimumSignal), String.valueOf(maximumSignal));
                String msg = hb.toJson();
                try {
                    msg = URLEncoder.encode(msg, "UTF-8");
                } catch (Exception e) {
                    e.printStackTrace();
                    msg = e.getLocalizedMessage().replaceAll(" ", "");
                }


                String url = getPreference(PREF_HEARTBEAT_URL) + msg;

                HeartbeatAsyncTask asyncTask = new HeartbeatAsyncTask();
                asyncTask.execute(this, url);
            } catch (Exception e) {
                //since the next heartbeat has already been scheduled, the backoff will only take effect the following time
                backOff();
                Log.e(TAG, "Exception " + e);
                e.printStackTrace();
            }
        }
    };


    private void backOff() {
        //max backoff is 24 hours
        interval = Math.min(2 * interval, 24 * 60 * 60 * 1000);
    }


    static class HeartbeatTimer extends CountDownTimer {

        private final String TAG = this.getClass().getSimpleName();

        HeartbeatAsyncTask heartbeatAsyncTask;

        HeartbeatTimer(HeartbeatAsyncTask task, long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
            heartbeatAsyncTask = task;
        }

        public void onFinish() {
            try {
                Log.v(TAG, "HeartbeatTimer finished");
                heartbeatAsyncTask.disconnectHTTP();
                Log.v(TAG, "disconnected http");
                boolean b = heartbeatAsyncTask.cancel(true);
                Log.v(TAG, "b is " + b);
            } catch (Exception exception) {
                Log.v(TAG, "problems with cancelling asynctask " + exception);
            }
        }

        public void onTick(long millisUntilFinished) {
            Log.v(TAG, "ticking for HTTP task " + heartbeatAsyncTask + " " + millisUntilFinished + " left to go");
        }

    }


    static class HeartbeatAsyncTask extends AsyncTask<Object, String, byte[]> {

        private final String TAG = this.getClass().getSimpleName();

        HeartbeatTimer httpTimer;
        HttpsURLConnection httpURLConnection;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            try {
                int timeout = 10000;
                httpTimer = new HeartbeatTimer(HeartbeatAsyncTask.this, timeout, 1000);
                httpTimer.start();
            } catch (Exception exception) {
                Log.e(TAG, "timer exception " + exception);
            }
        }

        @Override
        protected byte[] doInBackground(Object... params) {
            try {
                Log.v(TAG, "doInBackground got " + params.length + " parameters");

                String url = (String) params[1];
                Date startTime = new Date();
                Log.d(TAG, "starting http at : " + startTime.getTime());
                byte[] bytes = getData(url);
                Date endTime = new Date();
                Log.d(TAG, "gotback http at : " + endTime.getTime() + " " + (endTime.getTime() - startTime.getTime()));
                httpTimer.cancel();
                return bytes;
            } catch (Exception e) {
                Log.e(TAG, "Exception " + e);
                e.printStackTrace();
                httpTimer.cancel();
                return "HTTP GET FAIL".getBytes();
            }
        }

        byte[] getData(String urlString) throws Exception { // UnknownHostException {
            try {
                URL url = new URL(urlString);
                URLConnection urlConnection = url.openConnection();
                Log.v(TAG, "urlConnection is " + urlConnection);

                if (urlConnection instanceof HttpsURLConnection) {
                    httpURLConnection = (HttpsURLConnection) urlConnection;
                    Log.d(TAG, "host is " + httpURLConnection.getURL().getHost());
                    Log.d(TAG, "protocol is " + httpURLConnection.getURL().getProtocol());
                    Log.v(TAG, "reading payload");
                    byte[] data = readPayload(httpURLConnection);
                    Log.v(TAG, "read payload");
                    return data;
                } else {
                    return null;
                }
            } catch (UnknownHostException uhe) {
                Log.e(TAG, "3-Networking Exception " + uhe);
                throw uhe;
            } catch (Exception t) {
                Log.e(TAG, "getData throwing " + t);
                throw t;
            }
        }

        private byte[] readPayload(HttpsURLConnection httpURLConnection) throws Exception {
            httpURLConnection.setConnectTimeout(5000);

            Log.v(TAG, "response code: " + httpURLConnection.getResponseCode());
            Log.v(TAG, "content type: " + httpURLConnection.getContentType());
            Log.v(TAG, "contentLength: " + httpURLConnection.getContentLength());
            Log.v(TAG, "contentLength via header: " + httpURLConnection.getHeaderField("content-length"));
            Log.v(TAG, "content encoding: " + httpURLConnection.getContentEncoding());
            Log.v(TAG, "Location via header: " + httpURLConnection.getHeaderField("Location"));
            try {
                if (httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    interval = intervalDefault;
                    InputStream is = new BufferedInputStream(httpURLConnection.getInputStream());
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buffer = new byte[102400];   // 100KB
                    int count;
                    while ((count = is.read(buffer)) > 0) {
                        bos.write(buffer, 0, count);
                        Log.d(TAG, "HTTP GET byte count: " + count + " total: " + bos.size() + " encoding: " +
                                httpURLConnection.getContentEncoding());
                    }
                    bos.close();
                    return bos.toByteArray();
                } else {
                    throw new Exception("did not receive HTTP OK");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                throw ex;
            }
        }

        void disconnect() {
            Log.v(TAG, "trying to break http connection " + httpURLConnection);
            if (httpURLConnection != null) {
                httpURLConnection.disconnect();
            }
        }

        protected void onProgressUpdate(String... value) {
            Log.d(TAG, "onProgressUpdate");
        }

        protected void onPostExecute(byte[] bytes) {
            try {
                Log.v(TAG, "cancelling httpTimer");
                httpTimer.cancel();
                Log.v(TAG, "onPostExecute received " + bytes.length + " bytes");
            } catch (Exception exception) {
                Log.v(TAG, "onPostExecute exception " + exception);
            }
        }

        protected void onCancelled(byte[] bytes) {
            Log.v(TAG, "onCancelled with byte array" + Arrays.toString(bytes));
            if (!isCancelled()) {
                Log.v(TAG, "now trying to disconnect a hung http connection");
                disconnect();
                Log.v(TAG, "done");
            }

        }

        @Override
        protected void onCancelled() {
            Log.v(TAG, "onCancelled with no params ");
            if (!isCancelled()) {
                Log.v(TAG, "now trying to disconnect a hung http connection");
                disconnect();
                Log.v(TAG, "done");
            }

        }

        void disconnectHTTP() {
            try {
                Log.v(TAG, "cancel me");
                disconnect();
                Log.v(TAG, "httpUtils disconnected");
            } catch (Exception exception) {
                Log.v(TAG, "exception " + exception);
            }
        }


    }


    class awsPhoneStateListener extends PhoneStateListener {

        public void onSignalStrengthsChanged(SignalStrength ss) {
            super.onSignalStrengthsChanged(ss);
            if (ss.isGsm()) {
                if (ss.getGsmSignalStrength() != 99)
                    lastSignalStrength = ss.getGsmSignalStrength() * 2 - 113;
                else
                    lastSignalStrength = ss.getGsmSignalStrength();
            } else {
                lastSignalStrength = ss.getCdmaDbm();
            }


            //Queue
            long start1 = System.currentTimeMillis();
            queue.add(lastSignalStrength);
            Object[] arr = queue.toArray();
            Integer[] integerArray = new Integer[arr.length];

            for (int i = 0; i < arr.length; i++) {
                integerArray[i] = (Integer) arr[i];
            }

            Arrays.sort(integerArray);

            int arraySize = integerArray.length;

            averageSignal = mean(integerArray, arraySize);
            medianSignal = median(integerArray, arraySize);
            minimumSignal = integerArray[0];
            maximumSignal = lastSignalStrength;
            if (integerArray.length > 1)
                maximumSignal = integerArray[integerArray.length - 1];
            long end1 = System.currentTimeMillis();
            long diff1 = (end1 - start1);


            Log.d(TAG, "Signal strength: " + lastSignalStrength);
            Log.d(TAG, "Queue head: " + queue.peek());
            Log.d(TAG, "Signal time queue: " + diff1);
            Log.d(TAG, "Signal average1: " + averageSignal);
            Log.d(TAG, "Signal min1: " + minimumSignal);
            Log.d(TAG, "Signal max1: " + maximumSignal);
            Log.d(TAG, "Queue size: " + arraySize);
            Log.d(TAG, "Signal median: " + medianSignal);

            if (arraySize > 999)
                queue.poll();
        }


        private int mean(Integer[] arr, int size) {
            int total = 0;
            int mean;
            for (int i = 0; i < size; i++) {
                total += arr[i];
            }

            mean = total / size;

            return mean;

        }

        private int median(Integer[] arr, int size) {
            int median;
            if (size % 2 == 0)
                median = (arr[size / 2] + arr[size / 2 - 1]) / 2;
            else
                median = arr[size / 2];

            return median;

        }

    }


}
