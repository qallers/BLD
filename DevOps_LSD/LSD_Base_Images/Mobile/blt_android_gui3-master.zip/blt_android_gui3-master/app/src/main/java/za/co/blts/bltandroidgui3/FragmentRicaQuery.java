package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidFlowable;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;


public class FragmentRicaQuery extends BaseFragment implements BluDroidFlowable {

    private final String TAG = this.getClass().getSimpleName();

    private BluDroidCellphoneEditText CellphoneEditText;


    private BluDroidRelativeLayout layout;

    public FragmentRicaQuery() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_rica_query, container, false);

        if (getBaseActivity().isInRicaFirstTime) {
            getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), TAG, null);
            getBaseActivity().isInRicaFirstTime = false;
        }

        layout = rootView.findViewById(R.id.layout);
        BluDroidButton btnQuery = rootView.findViewById(R.id.query);

        CellphoneEditText = rootView.findViewById(R.id.cellNumber);

        CellphoneEditText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    String cellNumber = getCellNumber();
                    switch (keyCode) {

                        case KeyEvent.KEYCODE_DPAD_CENTER:
                        case KeyEvent.KEYCODE_ENTER:
                            if (layout.validate()) {
                                Log.d(TAG, "onClick() rica auto Query cell number");
                                getMainActivity().authenticateRica(cellNumber);
                            }
                            return true;
                        default:
                            break;
                    }
                }
                return false;
            }
        });

        btnQuery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                String cellNumber = getCellNumber();
                Log.d(TAG, "onClick() rica auto manual cell number");
                if (layout.validate()) {
                    getMainActivity().authenticateRica(cellNumber);
                }
            }
        });

        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        clearAll();

    }

    private String getCellNumber() {
        return CellphoneEditText.getText().toString().replace(" ", "");
    }

    @Override
    public boolean onBackPressed() {
        getBaseActivity().gotoMainScreen();
        return true;
    }

    @Override
    public void flow(View view) {
        if (layout.validate()) {
            getMainActivity().authenticateRica(getCellNumber());
        }
        getBaseActivity().cancelTimer();
    }

    public void clearAll() {
        if (CellphoneEditText != null) {
            CellphoneEditText.setText("");
            CellphoneEditText.removeErrorMessage();
        }
    }
}
