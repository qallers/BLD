package za.co.blts.bltandroidgui3;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;

public class FragmentIthubaBase extends BaseFragment {
    private final String TAG = this.getClass().getSimpleName();
    private String namePreviousScreen = "";
    private String boardsPreviousScreen = "";
    private String drawsPreviousScreen = "";

    public FragmentIthubaBase() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    String getNamePreviousScreen() {
        return namePreviousScreen;
    }

    public void setNamePreviousScreen(String namePreviousScreen) {
        this.namePreviousScreen = namePreviousScreen;
    }

    String getBoardsPreviousScreen() {
        return boardsPreviousScreen;
    }

    public void setBoardsPreviousScreen(String boardsPreviousScreen) {
        this.boardsPreviousScreen = boardsPreviousScreen;
    }

    String getDrawsPreviousScreen() {
        return drawsPreviousScreen;
    }

    public void setDrawsPreviousScreen(String drawsPreviousScreen) {
        this.drawsPreviousScreen = drawsPreviousScreen;
    }

    int pxInDIP(int pixels) {
        //Converts pixels to DIP
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, pixels, getResources().getDisplayMetrics());
    }

    /*
     * Method used to determine whether device is a tablet
     * http://stackoverflow.com/questions/11330363/how-to-detect-device-is-android-phone-or-android-tablet
     * http://www.androiddesignpatterns.com/2012/06/compatability-manager-utility-class.html
     */
    static boolean isTablet(Context context) {
        return (context.getResources().getConfiguration().screenLayout
                & Configuration.SCREENLAYOUT_SIZE_MASK)
                >= Configuration.SCREENLAYOUT_SIZE_LARGE;
    }

    @Override
    public boolean onBackPressed() {
        BaseActivity.logger.info(": onBackPressed()");
        return super.onBackPressed();
    }
}
