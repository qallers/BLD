package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentChatForChange extends VoucherRecycler {

    private final String TAG = this.getClass().getSimpleName();
    //----------------------------------------------------------------------------------------------
    public FragmentChatForChange() {
        // Required empty public constructor
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_chat_for_change, container, false);
        recycler = rootView.findViewById(R.id.bluRecycler);
        getBaseActivity().hideKeyboard();

//        getBaseActivity().toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (getMainActivity() != null) {
//                    getMainActivity().gotoFragment(new FragmentFavourites(), "FragmentFavourites");
//                }
//            }
//        });
        return rootView;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            grid = new GridLayoutManager(getActivity(), 3);
        } else {
            grid = new GridLayoutManager(getActivity(), 3);
        }

        populateScreen();
        setTitle("Vouchers");
        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();
    }

    //----------------------------------------------------------------------------------------------
    private void setTitle(String title) {
        getActivity().setTitle(title);
    }

    //----------------------------------------------------------------------------------------------
    private void populateScreen() {
        setupRecyclerForChat4Change();
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean onBackPressed() {

        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentVouchersMenu(), "FragmentVouchersMenu").commit();
        }

        return true;
    }
    //----------------------------------------------------------------------------------------------
}
