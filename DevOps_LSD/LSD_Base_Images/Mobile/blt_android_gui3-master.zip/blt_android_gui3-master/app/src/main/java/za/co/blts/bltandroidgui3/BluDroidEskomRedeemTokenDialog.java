package za.co.blts.bltandroidgui3;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;

import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTokenNumberEditText;

/**
 * Created by NkosanaM on 3/29/2017.
 */

public class BluDroidEskomRedeemTokenDialog extends BluDroidConfirmationDialog implements BluDroidSetupable {
    @SuppressWarnings("FieldCanBeLocal")
    private final String TAG = this.getClass().getSimpleName();

    public void setup() {
        super.setup();
        setAffirmativeButtonLabel(R.string.encodeToken);
        hideView(R.id.neutralButton);
        setNegativeButtonLabel(R.string.cancel);
        setHeading("Redeem Token");

        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }

    public BluDroidEskomRedeemTokenDialog(BaseActivity context) {
        super(context, R.layout.dialog_eskom_redeem_token);
        setup();
        Log.d(TAG, "redeem token");
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public String getTokenNumber() {
        BluDroidTokenNumberEditText tokenEditText = findViewById(R.id.encodeToken);
        if (tokenEditText != null) {
            return tokenEditText.getText().toString();
        } else {
            return "";
        }
    }

    public void setTokenNumber(String tokenNumber) {
        BluDroidTokenNumberEditText tokenEditText = findViewById(R.id.encodeToken);
        if (tokenEditText != null) {
            tokenEditText.setText(tokenNumber);
        }
    }


    public void setTokenNumberErrorMessage(String errorMessage) {
        BluDroidTokenNumberEditText tokenEditText = findViewById(R.id.encodeToken);
        if (tokenEditText != null) {
            tokenEditText.setErrorMessage(errorMessage);
        }
    }

}
