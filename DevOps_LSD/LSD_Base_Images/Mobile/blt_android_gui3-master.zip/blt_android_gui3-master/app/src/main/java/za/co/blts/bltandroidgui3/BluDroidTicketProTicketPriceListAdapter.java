package za.co.blts.bltandroidgui3;

import android.graphics.PorterDuff;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 4/5/2017.
 */

class BluDroidTicketProTicketPriceListAdapter extends ArrayAdapter<TicketProPriceCategory> {
    private final String TAG = this.getClass().getSimpleName();
    private WeakReference<BaseActivity> baseActivityWeakReference;

    private LayoutInflater inflater;

    public BluDroidTicketProTicketPriceListAdapter(BaseActivity context, int layoutResourceId, ArrayList<TicketProPriceCategory> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.baseActivityWeakReference = new WeakReference<>(context);

        inflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            final TicketProPriceCategory priceCategory = getItem(position);
            final BluDroidTicketProTicketPriceListAdapter.ViewHolder holder;

            if (convertView == null) {

                holder = new BluDroidTicketProTicketPriceListAdapter.ViewHolder();

                convertView = inflater.inflate(R.layout.ticketpro_price_row_item, parent, false);
                holder.txtSeatlabel = convertView.findViewById(R.id.seatLabel);
                holder.txtprice = convertView.findViewById(R.id.fare);
                holder.imgLogo = convertView.findViewById(R.id.logo);
                holder.quantity = convertView.findViewById(R.id.quantity);
                holder.btnPlus = convertView.findViewById(R.id.plus);
                holder.btnMinus = convertView.findViewById(R.id.minus);
                convertView.setTag(holder);

            } else {
                holder = (BluDroidTicketProTicketPriceListAdapter.ViewHolder) convertView.getTag();
            }


            holder.btnMinus.setTag(position);
            holder.btnPlus.setTag(position);

            holder.btnMinus.setEnabled(false);

            holder.btnPlus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Log.d(TAG, " Increase Ticket Quantity");
                    int qty = priceCategory.getQuantity();
                    priceCategory.setQuantity(++qty);
                    holder.quantity.setText(String.valueOf(priceCategory.getQuantity()));

                    if (priceCategory.getQuantity() == 0) {
                        holder.btnMinus.setColorFilter(baseActivity.getResources().getColor(R.color.lightGrey),
                                android.graphics.PorterDuff.Mode.SRC_IN);
                        holder.btnMinus.setEnabled(false);
                    } else {
                        holder.btnMinus.setColorFilter(baseActivity.getResources().getColor(R.color.accentColorDEF),
                                android.graphics.PorterDuff.Mode.SRC_IN);
                        holder.btnMinus.setEnabled(true);
                    }
                }
            });

            holder.btnMinus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Log.d(TAG, " Decrease Ticket Quantity");

                    int qty = priceCategory.getQuantity();
                    priceCategory.setQuantity(--qty);
                    holder.quantity.setText(String.valueOf(priceCategory.getQuantity()));

                    if (priceCategory.getQuantity() == 0) {
                        holder.btnMinus.setColorFilter(baseActivity.getResources().getColor(R.color.lightGrey),
                                PorterDuff.Mode.SRC_IN);
                        holder.btnMinus.setEnabled(false);
                    } else {
                        holder.btnMinus.setColorFilter(baseActivity.getResources().getColor(R.color.accentColorDEF),
                                android.graphics.PorterDuff.Mode.SRC_IN);
                        holder.btnMinus.setEnabled(true);
                    }
                }
            });


            String priceLabel = priceCategory.getLabel();
            String price = priceCategory.getPrice();
            int qty = priceCategory.getQuantity();

            // int iconSelected =priceCategory.getIconSelected();


            holder.txtSeatlabel.setText(priceLabel);
            String disp = "R" + price;
            holder.txtprice.setText(disp);
            holder.quantity.setText(String.valueOf(qty));
            holder.imgLogo.setTag(baseActivity.ticketProResponseEventDetailsMessage.getData().getSmallImage());

            if (holder.imgLogo != null) {

                Picasso picasso = Picasso.get();
                picasso.setIndicatorsEnabled(baseActivity.isDebug());
                picasso
                        .load(baseActivity.ticketProResponseEventDetailsMessage.getData().getSmallImage())
                        .placeholder(R.drawable.ticketpro_loading)
                        .error(R.drawable.ticketpro_loading)
                        .into(holder.imgLogo);
            }
        }

        return convertView;
    }

    static class ViewHolder {
        BluDroidTextView txtSeatlabel;
        TextView txtprice;
        ImageView imgLogo;
        ImageView btnMinus;
        ImageView btnPlus;
        TextView quantity;
    }

}

