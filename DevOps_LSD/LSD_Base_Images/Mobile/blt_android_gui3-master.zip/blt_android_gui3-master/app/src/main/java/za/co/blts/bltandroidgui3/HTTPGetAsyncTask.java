package za.co.blts.bltandroidgui3;

import android.os.AsyncTask;
import android.util.Log;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Date;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AEON_TIMEOUT;


class HTTPGetAsyncTask extends AsyncTask<Object, String, byte[]> {

    private final String TAG = this.getClass().getSimpleName();

    public WeakReference<BaseActivity> baseActivityWeakReference;

    private HTTPTimer httpTimer = null;
    private HTTPUtils httpUtils = null;

    //
// this constructor was added much later than everything
// else.  we need to change the doInBackground to remove
// it but I just don't have the time right now.
//
    public HTTPGetAsyncTask(BaseActivity baseScreen) {
        this.baseActivityWeakReference = new WeakReference<>(baseScreen);
    }


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        try {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                int timeout = Integer.parseInt(baseActivity.getPreference(PREF_AEON_TIMEOUT));
                timeout *= 1000;
                httpTimer = new HTTPTimer(this, (timeout / 2), 60000); // was 5000 and Masi changed it to 60000 because it was logging to much frequent
                //httpTimer = new HTTPTimer(this, timeout, 5000);
                httpTimer.start();
                Log.v(TAG, "timer started for " + baseActivity.getClass().getSimpleName());
            }
        } catch (Exception exception) {
            Log.v(TAG, "timer exception " + exception);
        }
    }

    @Override
    protected byte[] doInBackground(Object... params) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            try {
                Log.v(TAG, "doInBackground got " + params.length + " parameters");

                baseActivity = (BaseActivity) params[0];

                String url = (String) params[1];
                Date startTime = new Date();
                Log.d(TAG, "starting http at : " + startTime.getTime());
                httpUtils = new HTTPUtils(baseActivity.isDebug());

                byte[] bytes = httpUtils.getData(url, baseActivity);
                Date endTime = new Date();
                Log.d(TAG, "gotback http at : " + endTime.getTime() + " " + (endTime.getTime() - startTime.getTime()));
                httpTimer.cancel();
                return bytes;
            } catch (Exception exception) {
                if (BaseActivity.logger != null) {
                    BaseActivity.logger.error("Problems with HTTP get " + exception);
                    StringWriter sw = new StringWriter();
                    PrintWriter pw = new PrintWriter(sw);
                    exception.printStackTrace(pw);
                    Log.d(TAG, sw.toString());
                }
                Log.v(TAG, "Exception " + exception);
            }
        }
        return "HTTP GET FAIL".getBytes();
    }

    protected void onPostExecute(byte[] bytes) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            try {
                Log.v(TAG, "cancelling httpTimer");
                httpTimer.cancel();
                Log.v(TAG, "onPostExecute received " + bytes.length + " bytes");
                ((NeedsAEONResults) baseActivity).results(bytes);
            } catch (Exception exception) {
                Log.v(TAG, "onPostExecute exception " + exception);
                exception.printStackTrace();
            }
        }
    }

    protected void onCancelled(byte[] bytes) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            Log.v(TAG, "onCancelled with byte array" + Arrays.toString(bytes));
            if (!isCancelled()) {
                ((NeedsAEONResults) baseActivity).error(new byte[0]);
                Log.v(TAG, "now trying to disconnect a hung http connection");
                httpUtils.disconnect();
                Log.v(TAG, "done");
            }
        }
    }

    @Override
    protected void onCancelled() {
        Log.v(TAG, "onCancelled with no params ");
        if (!isCancelled()) {
            Log.v(TAG, "now trying to disconnect a hung http connection");
            httpUtils.disconnect();
            Log.v(TAG, "done");
        }

    }

    void disconnectHTTP() {
        try {
            Log.v(TAG, "cancel me");
            httpUtils.disconnect();
            Log.v(TAG, "httpUtils disconnected");
        } catch (Exception exception) {
            Log.v(TAG, "exception " + exception);
        }
    }


}
