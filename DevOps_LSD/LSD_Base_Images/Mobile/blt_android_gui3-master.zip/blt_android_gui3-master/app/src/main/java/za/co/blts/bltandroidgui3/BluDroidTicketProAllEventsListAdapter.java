package za.co.blts.bltandroidgui3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseParentAllEventMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 4/5/2017.
 */

class BluDroidTicketProAllEventsListAdapter extends ArrayAdapter<TicketProResponseParentAllEventMessage> implements View.OnClickListener {

    private Filter filter;
    private ArrayList<TicketProResponseParentAllEventMessage> dataSet;

    private WeakReference<BaseActivity> baseActivityWeakReference;

    private LayoutInflater inflater;


    public BluDroidTicketProAllEventsListAdapter(BaseActivity context, int layoutResourceId, ArrayList<TicketProResponseParentAllEventMessage> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.dataSet = dataSet;
        this.baseActivityWeakReference = new WeakReference<>(context);

        inflater = LayoutInflater.from(context);
    }

    @Override
    public void onClick(View v) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            String id = v.getTag().toString();
            baseActivity.reprint(id);
        }
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if (convertView == null) {

            holder = new ViewHolder();

            convertView = inflater.inflate(R.layout.event_row_item, parent, false);
            holder.txtName = convertView.findViewById(R.id.eventName);
            holder.txtDate = convertView.findViewById(R.id.date);
            holder.imgLogo = convertView.findViewById(R.id.logo);
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        TicketProResponseParentAllEventMessage event = dataSet.get(position);

        String eventName = event.getName();

        String date = event.getStartDate().substring(0, 10);
        String time = event.getStartDate().substring(10);

        holder.txtName.setText(eventName);
        String disp = date + " @ " + time;
        holder.txtDate.setText(disp);

        holder.imgLogo.setTag(event.getSmallImage());


        if (holder.imgLogo != null) {
            Picasso picasso = Picasso.get();
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                picasso.setIndicatorsEnabled(baseActivity.isDebug());
            }
            picasso
                    .load(event.getSmallImage())
                    .placeholder(R.drawable.ticketpro_loading)
                    .error(R.drawable.ticketpro_loading)
                    .into(holder.imgLogo);
        }

        return convertView;
    }


    static class ViewHolder {
        BluDroidTextView txtName;
        TextView txtDate;
        ImageView imgLogo;
    }

    @Override
    public Filter getFilter() {
        if (filter == null)
            filter = new BluDroidTicketProAllEventsListAdapter.AppFilter<>(dataSet);
        return filter;
    }


    private class AppFilter<T> extends Filter {

        private ArrayList<T> sourceObjects;

        AppFilter(ArrayList<T> objects) {
            sourceObjects = new ArrayList<>();
            synchronized (this) {
                sourceObjects.addAll(objects);
            }
        }

        @Override
        protected FilterResults performFiltering(CharSequence chars) {
            String filterSeq = chars.toString().toLowerCase();
            FilterResults result = new FilterResults();
            if (filterSeq.length() > 0) {
                ArrayList<T> filter = new ArrayList<>();

                for (T object : sourceObjects) {
                    // the filtering itself:
                    TicketProResponseParentAllEventMessage event = (TicketProResponseParentAllEventMessage) object;
                    if (event.getName().toLowerCase().contains(filterSeq))
                        filter.add(object);
                }
                result.count = filter.size();
                result.values = filter;
            } else {
                // add all objects
                synchronized (this) {
                    result.values = sourceObjects;
                    result.count = sourceObjects.size();
                }
            }
            return result;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint,
                                      FilterResults results) {
            // NOTE: this function is *always* called from the UI thread.
            ArrayList<T> filtered = (ArrayList<T>) results.values;
            notifyDataSetChanged();
            clear();
            for (int i = 0, l = filtered.size(); i < l; i++)
                add((TicketProResponseParentAllEventMessage) filtered.get(i));
            notifyDataSetInvalidated();
        }
    }
}

