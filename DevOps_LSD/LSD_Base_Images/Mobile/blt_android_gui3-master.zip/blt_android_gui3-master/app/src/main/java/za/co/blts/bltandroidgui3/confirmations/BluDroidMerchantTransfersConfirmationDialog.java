package za.co.blts.bltandroidgui3.confirmations;

import android.content.DialogInterface;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 3/23/2017.
 */

public class BluDroidMerchantTransfersConfirmationDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, View.OnClickListener {
    private final String TAG = this.getClass().getSimpleName();
    private String supplierCode;

    private BluDroidRelativeLayout layout;

    public void setup() {
        super.setup();
        // setIcon(baseActivity.getResources().getDrawable(R.drawable.eskom_confirm));
        hideView(R.id.neutralButton);
        setAffirmativeButtonLabel(R.string.print);
        setNegativeButtonLabel(R.string.cancel);
        setHeading(R.string.confirm_purchase);
        setClickListeners();
        layout = findViewById(R.id.layout);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }


    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }

    private void setClickListeners() {
        BluDroidButton cashButton = findViewById(R.id.cashButton);
        BluDroidButton debitButton = findViewById(R.id.debitCardButton);
        BluDroidButton creditButton = findViewById(R.id.creditCardButton);

        cashButton.setOnClickListener(this);
        debitButton.setOnClickListener(this);
        creditButton.setOnClickListener(this);
    }

    public String getSupplierCode() {
        return supplierCode;
    }


    public BluDroidMerchantTransfersConfirmationDialog(BaseActivity context) {
        super(context, R.layout.confirmation_merchant_transfers);
        setup();
        String TAG = this.getClass().getSimpleName();
        Log.d(TAG, "Purchase confirmation with activity");
        BaseActivity.logger.info(": construction with BaseActivity");
    }

    public void setAccountNumber(String accountNumber) {
        BluDroidTextView accountNumberView = findViewById(R.id.accountNumber);
        if (accountNumberView != null) {
            accountNumberView.setText(accountNumber);
        }
    }


    public void setAccountHolder(String accountHolder) {
        BluDroidTextView amountTextView = findViewById(R.id.customer);
        if (amountTextView != null) {
            amountTextView.setText(accountHolder);
        }
    }


    public void setConvienceFee(String convienceFee) {
        BluDroidTextView amountTextView = findViewById(R.id.convenience);
        if (amountTextView != null) {
            amountTextView.setText(convienceFee);
        }
    }

    public void setAmount(String amount) {
        BluDroidTextView amountTextView = findViewById(R.id.amount);
        if (amountTextView != null) {
            amountTextView.setText(amount);
        }
    }

    private String getAmount() {
        BluDroidTextView amountTextView = findViewById(R.id.amount);
        String amount = "";
        if (amountTextView != null) {
            amount = amountTextView.getText().toString();
        }

        return amount;
    }

    public void setTotalpayable(String total) {
        BluDroidTextView totalTextView = findViewById(R.id.total);
        if (totalTextView != null) {
            totalTextView.setText(total);
        }
    }

    public String getTotalPayable() {
        BluDroidTextView totalTextView = findViewById(R.id.total);
        String amount = "";
        if (totalTextView != null) {
            amount = totalTextView.getText().toString();
        }

        return amount;
    }


    @Override
    public void onClick(View view) {
        //BaseActivity.logger.info(": onClick()");
        BaseActivity.logger.info(((BluDroidButton) view).getText());
        if (layout.validate()) {

            Double min = Double.parseDouble(baseActivity.merchantTransferResponseGetInfoMessage.getData().getMinAmount());
            Double max = Double.parseDouble(baseActivity.merchantTransferResponseGetInfoMessage.getData().getMaxAmount());
            Double amount = Double.parseDouble(getAmount());

//            Double bpLimit = Double.parseDouble(baseActivity.getPreference(PREF_BP_LIMIT));

            if (view.getId() == R.id.cashButton) {

                if (amount > max || amount < min) {

                    baseActivity.createBillPaymentsAlertDialog("Merchant Transfer", "Amount must be between R" + baseActivity.df2.format(min) + "and R" + baseActivity.df2.format(max));

                    baseActivity.alert.setPositiveOption("Ok", new OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            baseActivity.alert.dismiss();
                            baseActivity.confirmation.dismiss();
                        }
                    });

                    baseActivity.alert.show();
                } else {
                    baseActivity.confirmation.dismiss();
                    baseActivity.transferToMerchant("cash");
                }


            } else if (view.getId() == R.id.debitCardButton) {

                if (amount > max || amount < min) {

                    baseActivity.createBillPaymentsAlertDialog("Merchant Transfer", "Amount must be between R" + baseActivity.df2.format(min) + "and R" + baseActivity.df2.format(max));

                    baseActivity.alert.setPositiveOption("Ok", new OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            baseActivity.alert.dismiss();
                            baseActivity.confirmation.dismiss();
                        }
                    });

                    baseActivity.alert.show();
                } else {
                    baseActivity.confirmation.dismiss();
                    baseActivity.transferToMerchant("debitCard");
                }


            } else if (view.getId() == R.id.creditCardButton) {

                if (amount > max || amount < min) {

                    baseActivity.createBillPaymentsAlertDialog("Merchant Transfer", "Amount must be between R" + baseActivity.df2.format(min) + "and R" + baseActivity.df2.format(max));

                    baseActivity.alert.setPositiveOption("Ok", new OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            baseActivity.alert.dismiss();
                            baseActivity.confirmation.dismiss();
                        }
                    });

                    baseActivity.alert.show();
                } else {
                    baseActivity.confirmation.dismiss();
                    baseActivity.transferToMerchant("creditCard");
                }
            }
        }
    }


}
