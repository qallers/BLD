package za.co.blts.magcard;

import androidx.annotation.NonNull;

/**
 * Created by NkosanaM on 3/26/2018.
 */

public class MagCardData {

    private String track2;
    private String track3;

    //----------------------------------------------------------------------------------------------
    public MagCardData() {
    }

    //----------------------------------------------------------------------------------------------
    public String getTrack2() {
        return track2;
    }

    //----------------------------------------------------------------------------------------------
    public void setTrack2(String track2) {
        this.track2 = track2;
    }

    //----------------------------------------------------------------------------------------------
    public String getTrack3() {
        return track3;
    }

    //----------------------------------------------------------------------------------------------
    public void setTrack3(String track3) {
        this.track3 = track3;
    }

    //----------------------------------------------------------------------------------------------
    @NonNull
    @Override
    public String toString() {
        return "MagCardData{" +
                "track2='" + track2 + '\'' +
                ", track3='" + track3 + '\'' +
                '}';
    }
    //----------------------------------------------------------------------------------------------
}
