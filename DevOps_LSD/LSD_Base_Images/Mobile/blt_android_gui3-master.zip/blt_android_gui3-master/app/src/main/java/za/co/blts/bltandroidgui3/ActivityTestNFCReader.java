package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import sunmi.paylib.SunmiPayKernel;
import za.co.blts.loyalty.BluDroidNFCCardAsyncResponse;
import za.co.blts.loyalty.ExternalNFCCard;
import za.co.blts.loyalty.NexgoN3NFCCard;
import za.co.blts.loyalty.P1NFCCard;

public class ActivityTestNFCReader extends BaseActivity implements BluDroidNFCCardAsyncResponse {

    private final String TAG = this.getClass().getName();
    private EditText txtTrack1;
    private SunmiPayKernel mSunmiPayKernel = null;

    //----------------------------------------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.MODEL.startsWith("CITAQ")) {
            nfcCard = new ExternalNFCCard(this);
        } else if (Build.MODEL.startsWith("N3")) {
            nfcCard = new NexgoN3NFCCard(this);
        } else if (Build.MODEL.startsWith("P1")) {
            nfcCard = new P1NFCCard(this);
            conn();
        } else {
            Toast.makeText(this, "NFC not supported", Toast.LENGTH_SHORT).show();
            gotoTestPeripheralsScreen();
            return;
        }

        nfcCard.setDelegate(this);

        setContentView(R.layout.activity_test_nfc_reader);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        TextView txtDebug = findViewById(R.id.txtDebug);
        txtDebug.setMovementMethod(new ScrollingMovementMethod());

        txtTrack1 = findViewById(R.id.txtTrack1);


        Button btnRead = findViewById(R.id.btnRead);
        btnRead.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                createCustomAlertDialog("NFC Card", "Please tap card to read");
                alert.setPositiveOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        alert.dismiss();
                    }
                });

                alert.show();
                nfcCard.startListener();
            }
        });


        Log.d(TAG, "Leave onCreate");
    }

    private void conn() {
        mSunmiPayKernel = SunmiPayKernel.getInstance();
        mSunmiPayKernel.connectPayService(getApplicationContext(), mConnCallback);
    }

    private SunmiPayKernel.ConnCallback mConnCallback = new SunmiPayKernel.ConnCallback() {
        @Override
        public void onServiceConnected() {
            try {
                BluDroidApplication.mReadCardOpt = mSunmiPayKernel.mReadCardOpt;

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected() {
        }
    };

    //----------------------------------------------------------------------------------------------
    protected void onStop() {
        Log.d(TAG, "Enter onStop");
        super.onStop();
        Log.d(TAG, "Leave onStop");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    protected void onDestroy() {
        Log.d(TAG, "Enter onDestroy");


        super.onDestroy();

        try {
            nfcCard.stopListener();
            nfcCard.closeReader();
            nfcCard.setDelegate(null);
        } catch (Exception ex) {
            Log.d(TAG, "onDestroy: " + ex.getMessage());
        }

        Log.d(TAG, "Leave onDestroy");
    }

    //----------------------------------------------------------------------------------------------
    public void onStart() {
        Log.d(TAG, "Enter onStart");
        super.onStart();
        Log.d(TAG, "Leave onStart");
    }

    //----------------------------------------------------------------------------------------------
    public void onResume() {
        Log.d(TAG, "Enter onResume");
        super.onResume();
        String action = getIntent().getAction();
        Log.d(TAG, "onResume:" + action);


    }

    //----------------------------------------------------------------------------------------------

    @Override
    public void onError(String msg) {

    }

    @Override
    public void onReady() {

    }

    @Override
    public void onCardNumberRead(String cardNumber) {
        if (alert != null) {
            alert.dismiss();
        }
        createAlertDialog("NFC Card", cardNumber);
        txtTrack1.setText(nfcCard.getCardNumber());
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onBackPressed() {
        gotoTestPeripheralsScreen();
    }
}
