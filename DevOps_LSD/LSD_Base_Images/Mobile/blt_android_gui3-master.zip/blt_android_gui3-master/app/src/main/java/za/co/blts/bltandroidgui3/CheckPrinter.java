package za.co.blts.bltandroidgui3;

import android.os.AsyncTask;
import android.util.Log;

import java.lang.ref.WeakReference;

class CheckPrinter extends AsyncTask<String, Void, Integer> {
    private BluDroidUSBPrint usbPrint = null;
    private String[] params;
    private String printError;

    private WeakReference<BaseActivity> baseActivityWeakReference;

    public CheckPrinter(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    @Override
    protected Integer doInBackground(String... strings) {
        params = strings;
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {

/*
          Let's first test the USB printer connectivity here before we go and book the tickets
          So that we can at least get this sorted before we continue and get an error when we
          need to actually print (might still happen, but should be the exception)
*/
            if (baseActivity.isRunningInEmulator()) {
                usbPrint = new BluDroidUSBPrint(baseActivity, baseActivity.ticket);
            } else {
                usbPrint = new BluDroidUSBPrint(baseActivity, baseActivity.ticket);
            }

            try {
                if (!usbPrint.checkUSBReadyStatus()) {
                    Log.d("FragmentPutco", "printer error");
                    printError = usbPrint.getUSBPrinterErrorString();
                    return 1;
                }
//paper check is done only here
//        if (!usbPrint.checkUSBPrinterPaperAvailable()) {
//          Log.d("FragmentPutco", "paper check failed");
//          printError = usbPrint.getUSBPrinterErrorString();
//          return 2;
//        }
            } catch (Exception exception) {
                Log.d("FragmentPutco", "checkUSBPrinter Exception " + exception);
                return 3;
            }
            Log.d("FragmentPutco", "printer ok");
            return 0;
        }
        return 3;
    }

    @Override
    protected void onPostExecute(Integer integer) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            usbPrint.unregisterReceiver();
            baseActivity.handlePrintCheckResult(params, integer, printError);
        }
    }
}