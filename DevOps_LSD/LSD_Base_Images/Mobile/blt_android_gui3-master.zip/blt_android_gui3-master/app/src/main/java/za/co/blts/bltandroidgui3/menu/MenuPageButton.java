package za.co.blts.bltandroidgui3.menu;

public class MenuPageButton {
    private String label;
    private int img;

    public MenuPageButton(String label, int img) {
        this.label = label;
        this.img = img;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
