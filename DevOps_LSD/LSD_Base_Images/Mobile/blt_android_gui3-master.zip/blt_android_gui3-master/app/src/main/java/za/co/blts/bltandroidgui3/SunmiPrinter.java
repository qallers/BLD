package za.co.blts.bltandroidgui3;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import woyou.aidlservice.jiuiv5.ICallback;
import woyou.aidlservice.jiuiv5.IWoyouService;
import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blts.bltandroidgui3.dynamic.DynamicPrintUtil;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PAPER_CUTTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VOUCHER_SECONDS;


public class SunmiPrinter implements SmartPrinter {

    private final String TAG = this.getClass().getSimpleName();

    // WeakReference used to avoid memory leak
    private WeakReference<BaseActivity> baseActivityWeakReference = null;

    private IWoyouService woyouService;


    private final String ENDTEXT = "\n\n\n================================";
    private IBinder Iservice;

    private ServiceConnection connService = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
            woyouService = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.v(TAG, "onServiceConnected name=" + name.toString());
            Iservice = service;
            woyouService = IWoyouService.Stub.asInterface(service);
            Log.v(TAG, "woyouService is " + woyouService);

            try {
                woyouService.printerInit(callback);
                if (Build.MODEL.startsWith("P1")) {
                    byte[] result = new byte[3];
                    result[0] = 0x1B;
                    result[1] = 69;
                    result[2] = 0xF;
                    woyouService.sendRAWData(result, callback);
                }
            } catch (RemoteException e) {
                Log.v(TAG, "registerCallback failed.");
            }
        }
    };

    private ICallback callback = new ICallback.Stub() {
        @Override
        public void onRunResult(boolean isSuccess) {
            Log.v(TAG, "print result" + isSuccess);
        }

        @Override
        public void onReturnString(String result) {
            Log.v(TAG, "onReturnString ICallback--->" + result);
        }

        @Override
        public void onRaiseException(int code, String msg) {
            Log.v(TAG, "onRaiseException--->" + msg);
        }

        @Override
        public void onPrintResult(int code, String msg) {
            Log.d("PRINTER RESULT", msg);
        }
    };


    public SunmiPrinter() {
    }

    public void initialise(BaseActivity baseScreen) {
        try {
            Log.d(TAG, ": initialise() with BaseActivity");
            Log.d(TAG, "initialise executing");
            this.baseActivityWeakReference = new WeakReference<>(baseScreen);
            Intent intent = new Intent();
            intent.setPackage("woyou.aidlservice.jiuiv5");
            intent.setAction("woyou.aidlservice.jiuiv5.IWoyouService");
            baseScreen.startService(intent);
            baseScreen.bindService(intent, connService, Context.BIND_AUTO_CREATE);
            Log.d(TAG, "initialise finished");
        } catch (Exception exception) {
            Log.v(TAG, "initialise throwing " + exception);
        }
    }

    public void terminate() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                try {
                    Intent intent = new Intent();
                    intent.setPackage("woyou.aidlservice.jiuiv5");
                    intent.setAction("woyou.aidlservice.jiuiv5.IWoyouService");
                    baseScreen.stopService(intent);
                    baseScreen.unbindService(connService);
                } catch (Exception e) {
                    //ignore exception
                }
            }
        }
    }

    private void restartServiceIfNecessary() {
        try {
            if (woyouService == null) {
                woyouService = IWoyouService.Stub.asInterface(Iservice);
                woyouService.printerInit(callback);
            }
        } catch (RemoteException e) {
            Log.v(TAG, "registerCallback failed.");
        }
    }

    @Override
    public void print(ArrayList<CommonResponseLineMessage> lines, boolean feed) {

        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            try {
                restartServiceIfNecessary();

                String barcodeNumber;
                int barcodeWidth = BaseActivity.printWidth * 12;

                Log.d(TAG, ": print()");

                baseScreen.choosePrintLogo();

                woyouService.setAlignment(ALIGN_CENTER, callback);
                woyouService.printBitmap(baseScreen.bluLogo, callback);
                woyouService.printText("\n", callback);
                woyouService.setAlignment(ALIGN_LEFT, callback);

                if (lines.size() > 0) {
                    for (CommonResponseLineMessage line : lines) {

                        switch (line.getF()) {
                            // center
                            case "H":
                                line.setText(baseScreen.center(line.getText()));
                                woyouService.printText(line.getText() + "\n", callback);
                                break;

                            // left align (should be default)
                            case "O":
                                if (line.getText() != null) {
                                    woyouService.printText(line.getText() + "\n", callback);
                                }
                                break;

                            //print horizontal line
                            case "N":
                                if (line.getText() != null && !line.getText().isEmpty()) {
                                    woyouService.printText(line.getText() + "\n", callback);
                                }
                                woyouService.printText(BaseActivity.HORIZONTAL_LINE + "\n", callback);
                                break;

                            // need to generate EAN 13 barcode
                            case "P":
                                barcodeNumber = line.getText();
                                woyouService.setAlignment(ALIGN_CENTER, callback);
                                woyouService.printBitmap(baseScreen.generateBarcode("ean13", line.getText(), barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13), callback);
                                woyouService.setAlignment(ALIGN_LEFT, callback);
                                woyouService.printText(baseScreen.center(barcodeNumber) + "\n", callback);
                                break;

                            // need to generate Code 39 barcode
                            case "Q":
                                barcodeNumber = line.getText();
                                woyouService.setAlignment(ALIGN_CENTER, callback);
                                woyouService.printBitmap(baseScreen.generateBarcode("code39", line.getText(), barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13), callback);
                                woyouService.setAlignment(ALIGN_LEFT, callback);
                                woyouService.printText(baseScreen.center(barcodeNumber) + "\n", callback);
                                break;

                            // need to generate ITF barcode for Lotto
                            case "U":
                                BaseActivity.isLotto = true;
                                String specialChar = ";";
                                String barcodeText = line.getText();
                                String printableBarcode = barcodeText.substring(0, barcodeText.indexOf(specialChar));
                                woyouService.setAlignment(ALIGN_CENTER, callback);
                                woyouService.printBitmap(baseScreen.generateBarcode("itf", printableBarcode, barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13), callback);
                                woyouService.setAlignment(ALIGN_LEFT, callback);
                                woyouService.printText(baseScreen.center(printableBarcode) + "\n", callback);
                                //line.setText("BARCODE_PRINT");
                                break;

                            // need to generate code128 barcode
                            case "X":
                                barcodeNumber = line.getText();
                                woyouService.setAlignment(ALIGN_CENTER, callback);
                                woyouService.printBitmap(baseScreen.generateBarcode("code128", line.getText(), barcodeWidth, baseScreen.BARCODE_HEIGHT_EAN_13), callback);
                                woyouService.setAlignment(ALIGN_LEFT, callback);
                                woyouService.printText(baseScreen.center(barcodeNumber) + "\n", callback);
                                break;

                            //normal
                            case "A":
                            case "G":
                            case "K":
                            case "M":
                                woyouService.printText(line.getText() + "\n", callback);
                                break;

                            //bold
                            case "B":
                            case "C":
                            case "D":
                                //bold
                                woyouService.sendRAWData(new byte[]{0x1b, 0x45, 0x01}, callback);
                                woyouService.printText(line.getText() + "\n", callback);
                                //unbold
                                woyouService.sendRAWData(new byte[]{0x1B, 0x45, 0x0}, callback);
                                break;

                            // center bold
                            case "E":
                                boolean pin = new BluDroidUtils().isPinFormat(line.getText());
                                if (pin) {
                                    line.setText(line.getText().replaceAll("\\s{2,}", " "));
                                }
                                ArrayList<String> wrappedLines = BluDroidUtils.wordWrap(line.getText(), pin ? 16 : 32);
                                for (String s : wrappedLines) {
                                    printText(s, ALIGN_CENTER, pin ? FONT_LARGE : FONT_NORMAL, true);
                                }
                                break;

                            case "F":
                            case "L":
                                break;

                            default:
                        }
                    }
                }

                if (feed && baseScreen.getPreference(PREF_PAPER_CUTTER).equals(PREF_FALSE)) {
                    woyouService.printText(ENDTEXT, callback);
                }
                int millis = Integer.parseInt(baseScreen.getPreference(PREF_VOUCHER_SECONDS)) * 1000;
                Thread.sleep(millis);
                BaseActivity.isVoucherPrinted = true;
                Log.d(TAG, ": done printing lotto()");

            } catch (Exception ex) {
                Log.d(TAG, "print: " + ex);
                BaseActivity.isVoucherPrinted = false;
                BaseActivity.logger.error("Printing Error: " + ex);
                baseScreen.cleanUp();

            }
        }
    }

    @Override
    public void print(List<String> lines) {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {

            try {
                Log.d(TAG, ": print()");
                restartServiceIfNecessary();

                Log.d(TAG, "Printing");
                StringBuilder sb = new StringBuilder();
                for (String line : lines) {
                    sb.append(line).append("\n");
                }
                Log.d(TAG, sb.toString());
                Log.d(TAG, "callback is " + callback);
                Log.d(TAG, "woyouService is " + woyouService);
                if (baseScreen.getPreference(PREF_PAPER_CUTTER).equals(PREF_FALSE)) {
                    woyouService.printText(sb.toString() + ENDTEXT, callback);
                }
                int millis = Integer.parseInt(baseScreen.getPreference(PREF_VOUCHER_SECONDS)) * 1000;
                Thread.sleep(millis);
                BaseActivity.isVoucherPrinted = true;
                BaseActivity.logger.info(": done printing");
            } catch (Exception exception) {
                BaseActivity.isVoucherPrinted = false;
                BaseActivity.logger.error("Printing Error: " + exception);
                baseScreen.cleanUp();
                Log.v(TAG, "exception " + exception);
            }
        }
    }

    @Override
    public void print(Bitmap logo, List<String> lines, Bitmap barcode, String barcodeNumber) {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {

            try {
                BaseActivity.logger.info(": print()");

                restartServiceIfNecessary();

                BaseActivity.logger.info("Printing");

                StringBuilder sb = new StringBuilder();
                for (String line : lines) {
                    sb.append(line).append("\n");
                }
                Log.d(TAG, sb.toString());

                if (logo != null) {
                    woyouService.setAlignment(ALIGN_CENTER, callback);
                    woyouService.printBitmap(logo, callback);
                    woyouService.printText("               ", callback);
                    woyouService.setAlignment(ALIGN_LEFT, callback);
                }

                woyouService.printText(sb.toString() + "\n", callback);
                if (barcode != null) {
                    woyouService.setAlignment(ALIGN_CENTER, callback);
                    woyouService.printBitmap(barcode, callback);
                    woyouService.setAlignment(ALIGN_LEFT, callback);
                }

                if (baseScreen.getPreference(PREF_PAPER_CUTTER).equals(PREF_FALSE)) {
                    woyouService.printText(barcodeNumber + ENDTEXT, callback);
                }
                int millis = Integer.parseInt(baseScreen.getPreference(PREF_VOUCHER_SECONDS)) * 1000;
                Thread.sleep(millis);
                BaseActivity.isVoucherPrinted = true;
                BaseActivity.logger.info(": done printing()");
            } catch (Exception exception) {

                BaseActivity.isVoucherPrinted = false;
                BaseActivity.logger.error("Printing Error: " + exception);
                baseScreen.cleanUp();
                Log.v(TAG, "exception " + exception);
            }
        }
    }

    @Override
    public void print(Bitmap logo, List<CommonResponseLineMessage> lines, Bitmap barcode, boolean feed) {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {

            try {
                restartServiceIfNecessary();

                Log.d(TAG, ": print()");

                woyouService.setAlignment(ALIGN_CENTER, callback);
                woyouService.printBitmap(logo, callback);
                woyouService.printText("\n", callback);
                woyouService.setAlignment(ALIGN_LEFT, callback);

                if (lines.size() > 0) {
                    for (CommonResponseLineMessage line : lines) {

                        switch (line.getF()) {
                            // center
                            case "H":
                                line.setText(baseScreen.center(line.getText()));
                                woyouService.printText(line.getText() + "\n", callback);
                                break;

                            // left align (should be default)
                            case "O":
                                if (line.getText() != null) {
                                    woyouService.printText(line.getText() + "\n", callback);
                                }
                                break;

                            //print horizontal line
                            case "N":
                                if (line.getText() != null && !line.getText().isEmpty()) {
                                    woyouService.printText(line.getText() + "\n", callback);
                                }
                                woyouService.printText(BaseActivity.HORIZONTAL_LINE + "\n", callback);
                                break;

                            case "A":
                                woyouService.printText(line.getText() + "\n", callback);
                                break;

                            // center bold
                            case "E":
                                boolean pin = new BluDroidUtils().isPinFormat(line.getText());
                                if (pin) {
                                    line.setText(line.getText().replaceAll("\\s{2,}", " "));
                                }
                                ArrayList<String> wrappedLines = BluDroidUtils.wordWrap(line.getText(), pin ? 16 : 32);
                                for (String s : wrappedLines) {
                                    printText(s, ALIGN_CENTER, pin ? FONT_LARGE : FONT_NORMAL, true);
                                }
                                break;

                            case "L":
                                break;

                            default:
                        }

                    }
                }
                if (barcode != null) {
                    woyouService.setAlignment(ALIGN_CENTER, null);
                    woyouService.printBitmap(barcode, callback);
                    woyouService.printText("\n", callback);
                    woyouService.setAlignment(ALIGN_LEFT, null);
                }

                if (feed && baseScreen.getPreference(PREF_PAPER_CUTTER).equals(PREF_FALSE)) {
                    woyouService.printText(ENDTEXT, callback);
                }
                int millis = Integer.parseInt(baseScreen.getPreference(PREF_VOUCHER_SECONDS)) * 1000;
                Thread.sleep(millis);
                BaseActivity.isVoucherPrinted = true;
                BaseActivity.logger.info(": done printing lotto()");

            } catch (Exception ex) {
                Log.d(TAG, "print: " + ex);
                BaseActivity.isVoucherPrinted = false;
                BaseActivity.logger.error("Printing Error: " + ex);
                baseScreen.cleanUp();

            }
        }
    }

    public Bitmap convertBitMatrixToBitMap(BitMatrix bitMatrix) {
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {

            try {

                Bitmap bitmap = Bitmap.createBitmap(bitMatrix.getWidth(), bitMatrix.getHeight(), Bitmap.Config.ARGB_8888);

                for (int k = 0; k < bitMatrix.getWidth(); k++) {
                    for (int j = 0; j < bitMatrix.getHeight(); j++) {
                        try {
                            bitmap.setPixel(k, j, bitMatrix.get(k, j) ? Color.BLACK : Color.WHITE);
                        } catch (Exception exception) {
                            Log.v(TAG, "problems " + exception);
                        }
                    }
                }
                return bitmap;

            } catch (Exception exception) {
                Log.d(TAG, "problem generating bitmap " + exception);
            }
        }
        return null;
    }


    public int getBitmapMaxWidth() {
        return 384;
    }

    public int getStatus() {
        try {
            return woyouService.updatePrinterState();
        } catch (Exception e) {
            e.printStackTrace();
            BaseActivity.logger.error("getStatus exception" + e);
        }
        return -1;
    }

    private void printText(JSONObject obj) throws Exception {
        boolean bold;
        int align, size;

        try {
            bold = obj.getString("style").equals("bold");
        } catch (Exception ignore) {
            bold = false;
        }

        try {
            switch (obj.getString("align").toLowerCase()) {
                case "center":
                    align = ALIGN_CENTER;
                    break;
                case "right":
                    align = ALIGN_RIGHT;
                    break;
                default:
                    align = ALIGN_LEFT;
                    break;
            }
        } catch (Exception ignore) {
            align = ALIGN_LEFT;
        }

        try {
            if ("large".equals(obj.getString("size").toLowerCase())) {
                size = FONT_LARGE;
            } else {
                size = FONT_NORMAL;
            }
        } catch (Exception ignore) {
            size = FONT_NORMAL;
        }
        printText(obj.getString("value"), align, size, bold);
    }

    private void printText(String text, int align, int size, boolean bold) throws Exception {
        byte style = bold ? (byte) 0x01 : (byte) 0x00;
        woyouService.sendRAWData(new byte[]{0x1b, 0x45, style}, null);
        woyouService.setAlignment(align, null);
        woyouService.setFontSize(size, null);
        woyouService.printText(text + "\n", null);
        //restore to normal, left align, no bold
        woyouService.sendRAWData(new byte[]{0x1b, 0x45, 0x00}, null);
        woyouService.setAlignment(ALIGN_LEFT, null);
        woyouService.setFontSize(FONT_NORMAL, null);
    }

    private void printLine() throws Exception {
        char[] array = new char[32];
        Arrays.fill(array, '=');
        printText(new String(array), ALIGN_LEFT, FONT_NORMAL, false);
    }

    private void printBarcode(JSONObject obj) throws Exception {
        BarcodeFormat barcodeFormat;
        int height = 100;
        String format = obj.getString("format").toLowerCase();
        switch (format) {
            case "ean13":
                barcodeFormat = BarcodeFormat.EAN_13;
                break;
            case "code39":
                barcodeFormat = BarcodeFormat.CODE_39;
                break;
            case "itf":
                barcodeFormat = BarcodeFormat.ITF;
                break;
            case "code128":
                barcodeFormat = BarcodeFormat.CODE_128;
                break;
            case "pdf417":
                barcodeFormat = BarcodeFormat.PDF_417;
                height = 200;
                break;
            default:
                return;
        }
        String barcode = obj.getString("value");
        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
//            BitMatrix bitMatrix = multiFormatWriter.encode(barcode, barcodeFormat, 384, height, null);
        BitMatrix bitMatrix = multiFormatWriter.encode(barcode, barcodeFormat, 411, height, null);

        Bitmap bitmap = convertBitMatrixToBitMap(bitMatrix);
        woyouService.setAlignment(ALIGN_CENTER, null);
        woyouService.printBitmap(bitmap, null);
        printText(barcode, ALIGN_CENTER, FONT_NORMAL, false);
    }

    private void printImage(JSONObject obj) throws Exception {
        Log.d("DynamicPrint", "printImage: " + obj.toString());
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            Bitmap logo = new DynamicPrintUtil(baseActivity).getLogoForPrint(obj.getString("id"));
            Log.d("DynamicPrint", "logo: " + logo);
            if (logo != null) {
                int align;
                try {
                    switch (obj.getString("align").toLowerCase()) {
                        case "center":
                            align = ALIGN_CENTER;
                            break;
                        case "right":
                            align = ALIGN_RIGHT;
                            break;
                        default:
                            align = ALIGN_LEFT;
                            break;
                    }
                } catch (Exception ignore) {
                    align = ALIGN_LEFT;
                }

                woyouService.setAlignment(align, null);
                woyouService.printBitmap(logo, null);
                woyouService.printText("\n", null);
            }
        }
    }

    public void print(JSONArray printJob) {
        try {
            restartServiceIfNecessary();
            for (int i = 0; i < printJob.length(); i++) {
                JSONObject obj = printJob.getJSONObject(i);
                switch (obj.getString("type").toLowerCase()) {
                    case "text":
                        printText(obj);
                        break;
                    case "line":
                        printLine();
                        break;
                    case "barcode":
                        printBarcode(obj);
                        break;
                    case "image":
                        printImage(obj);
                        break;
                }
            }
            woyouService.printText(ENDTEXT, null);
        } catch (Exception e) {
            e.printStackTrace();
            BaseActivity.logger.error("print exception" + e);
        }
    }

}
