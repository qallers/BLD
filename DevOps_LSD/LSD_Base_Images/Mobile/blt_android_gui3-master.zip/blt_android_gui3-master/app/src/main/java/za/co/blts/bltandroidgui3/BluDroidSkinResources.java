package za.co.blts.bltandroidgui3;


import android.graphics.Color;
import android.util.DisplayMetrics;

import java.lang.ref.WeakReference;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;

//
// this class holds skin resources for a BluDroid 
public class BluDroidSkinResources {

    //
// the company logo for printing
//
    private int printLogoId;

    //
// accent color
//
    private int accentColor;

    //
// the button color, action bar color
//
    private int buttonColor;

//
// the color when an item is highlighted 
//
//int highlightColor;

    //
// the back ground color, probably white
//
    private int backgroundColor;

    //
// the color of the text on a button or actionn bar
//
    private int buttonTextColor;

    //
// the color of the text against the background
//
    private int backgroundTextColor;

    //
// the primary size of the text
//
    private int textSize;

    //
// a slightly lighter color than buttonColor
//
    private int lightColor;

    //
// the color of error messages
//
    private int errorColor;

    private WeakReference<BaseActivity> baseActivityWeakReference;

    private int getColor(int resourceId) {
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                return baseActivity.getResources().getColor(resourceId);
            }
        }
        return 0;
    }

    private int getTextSizeFromResource(int resourceId) {
        try {
            if (baseActivityWeakReference != null) {
                BaseActivity baseActivity = baseActivityWeakReference.get();
                if (baseActivity != null) {
                    return Integer.parseInt(baseActivity.getResources().getString(resourceId));
                }
            }
        } catch (Exception ignored) {
        }
        return 18;
    }

    private void calculateLightColor() {
        //
        // see http://stackoverflow.com/questions/4928772/android-color-darker
        //
        //Color color = new Color(buttonColor);
        float factor = 0.40f;
        int red = (int) ((Color.red(buttonColor) * (1 - factor) / 255 + factor) * 255);
        int green = (int) ((Color.green(buttonColor) * (1 - factor) / 255 + factor) * 255);
        int blue = (int) ((Color.blue(buttonColor) * (1 - factor) / 255 + factor) * 255);
        lightColor = Color.argb(Color.alpha(buttonColor), red, green, blue);
    }

    public BluDroidSkinResources(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);

        String skin = baseActivity.getPreference(PREF_SKIN);

        if (skin.equals(baseActivity.getResources().getString(R.string.skinGCRS))) {
            buttonColor = getColor(R.color.buttonColorGCRS);
            accentColor = getColor(R.color.accentColorGCRS);
            backgroundColor = getColor(R.color.backgroundColorGCRS);
            buttonTextColor = getColor(R.color.buttonTextColorGCRS);
            backgroundTextColor = getColor(R.color.backgroundTextColorGCRS);
            errorColor = getColor(R.color.errorColorGCRS);

            if (baseActivity.getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
                textSize = getTextSizeFromResource(R.string.textSizeBLTLarge);
            } else {
                textSize = getTextSizeFromResource(R.string.textSizeBLT);
            }

        } else if (skin.equals(baseActivity.getResources().getString(R.string.skinNFC))) {
            buttonColor = getColor(R.color.buttonColorNFC);
            accentColor = getColor(R.color.accentColorNFC);
            backgroundColor = getColor(R.color.backgroundColorNFC);
            buttonTextColor = getColor(R.color.buttonTextColorNFC);
            backgroundTextColor = getColor(R.color.backgroundTextColorNFC);
            errorColor = getColor(R.color.errorColorNFC);

            if (baseActivity.getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
                textSize = getTextSizeFromResource(R.string.textSizeBLTLarge);
            } else {
                textSize = getTextSizeFromResource(R.string.textSizeBLT);
            }

        } else {
            buttonColor = getColor(R.color.buttonColorBLT);
            accentColor = getColor(R.color.accentColorBLT);
            backgroundColor = getColor(R.color.backgroundColorBLT);
            buttonTextColor = getColor(R.color.buttonTextColorBLT);
            backgroundTextColor = getColor(R.color.backgroundTextColorBLT);
            errorColor = getColor(R.color.errorColorBLT);

            if (baseActivity.getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
                textSize = getTextSizeFromResource(R.string.textSizeBLTLarge);
            } else {
                textSize = getTextSizeFromResource(R.string.textSizeBLT);
            }

        }

        calculateLightColor();
    }

    public int getErrorColor() {
        return errorColor;
    }

    public void setErrorColor(int errorColor) {
        this.errorColor = errorColor;
    }

    public int getLightColor() {
        return lightColor;
    }

    public void setLightColor(int lightColor) {
        this.lightColor = lightColor;
    }

    public int getAccentColor() {
        return accentColor;
    }

    public void setAccentColor(int accentColor) {
        this.accentColor = accentColor;
    }

    public int getTextSize() {
        return textSize;
    }

    public void setTextSize(int textSize) {
        this.textSize = textSize;
    }

    public int getPrintLogoId() {
        return printLogoId;
    }

    public void setPrintLogoId(int printLogoId) {
        this.printLogoId = printLogoId;
    }

    public int getButtonColor() {
        return buttonColor;
    }

    public void setButtonColor(int buttonColor) {
        this.buttonColor = buttonColor;
    }

    public int getBackgroundColor() {
        return backgroundColor;
    }

    public void setBackgroundColor(int backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public int getButtonTextColor() {
        return buttonTextColor;
    }

    public void setButtonTextColor(int buttonTextColor) {
        this.buttonTextColor = buttonTextColor;
    }

    public int getBackgroundTextColor() {
        //Log.d(TAG, "returning backgroundTextColor = " + String.format("0x%08x", backgroundTextColor));
        return backgroundTextColor;
    }

    public void setBackgroundTextColor(int backgroundTextColor) {
        this.backgroundTextColor = backgroundTextColor;
    }

    public String toString() {
        return String.format("buttonColor %6x backgroundColor %6x buttonTextColor %6x buttonBackgroundColor %6x",
                buttonColor, backgroundColor, buttonTextColor, backgroundTextColor);
    }

}

