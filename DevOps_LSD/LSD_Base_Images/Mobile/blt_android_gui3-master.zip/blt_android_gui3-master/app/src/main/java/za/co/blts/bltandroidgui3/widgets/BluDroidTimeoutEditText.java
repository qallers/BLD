package za.co.blts.bltandroidgui3.widgets;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 2/16/2017.
 */

public class BluDroidTimeoutEditText extends BluDroidIntegerEditText {
    private final String TAG = this.getClass().getSimpleName();
    private String fieldname;
    private int minValue;
    private int maxValue;

    private String editTextCategory;

    public BluDroidTimeoutEditText(BaseActivity context) {
        super(context);
    }

    public BluDroidTimeoutEditText(Context context, AttributeSet attrs) {
        super(context, attrs);


        @SuppressLint("CustomViewStyleable") TypedArray timeoutAttributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidEditText);

        try {
            editTextCategory = timeoutAttributesArray.getString(R.styleable.BluDroidEditText_EditTextCategory);
        } catch (Exception e) {
            e.printStackTrace();
        }
        timeoutAttributesArray.recycle();

        TypedArray attributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidTimeoutEditText);

        try {
            fieldname = attributesArray.getString(R.styleable.BluDroidTimeoutEditText_fieldName);
            minValue = attributesArray.getInt(R.styleable.BluDroidTimeoutEditText_minTimeout, -1);
            maxValue = attributesArray.getInt(R.styleable.BluDroidTimeoutEditText_maxTimeout, -1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        attributesArray.recycle();
    }

    @Override
    public boolean validate() {
        BaseActivity.logger.info(": validate(): ");
        Log.d(TAG, "validate");

        String timeoutString = getText().toString().trim();
        boolean isvalidated = false;

        if (tryParseInt(timeoutString)) {

            int timeout = Integer.parseInt(timeoutString);

            if (timeout >= minValue && timeout <= maxValue) {
                removeErrorMessage();
                isvalidated = true;
            } else {
                setErrorMessage(fieldname + " must be between " + minValue + " and " + maxValue);
                BaseActivity baseScreen = baseActivityWeakReference.get();
                if (baseScreen != null) {

                    if (editTextCategory.equalsIgnoreCase("timeoutSettings")) {
                        baseScreen.timeoutSettingsHaserrors = true;

                    } else if (editTextCategory.equalsIgnoreCase("screenTimeoutSettings")) {
                        baseScreen.deviceUserSettingsHaserrors = true;
                    }
                }
            }

        } else {
            setErrorMessage(fieldname + " cannot be empty..!");
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                if (editTextCategory.equalsIgnoreCase("timeoutSettings")) {
                    baseScreen.timeoutSettingsHaserrors = true;

                } else if (editTextCategory.equalsIgnoreCase("screenTimeoutSettings")) {
                    baseScreen.deviceUserSettingsHaserrors = true;
                }
            }
        }
        return isvalidated;
    }

    boolean tryParseInt(String value) {
        try {
            Integer.parseInt(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
