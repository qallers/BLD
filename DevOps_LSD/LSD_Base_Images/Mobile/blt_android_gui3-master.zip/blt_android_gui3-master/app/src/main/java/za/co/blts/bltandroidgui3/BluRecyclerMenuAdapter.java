package za.co.blts.bltandroidgui3;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.blt_draggable.ItemTouchAdapter;
import za.co.blts.bltandroidgui3.blt_draggable.ItemTouchViewHolder;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SECURE_USB_PRINTER;

/**
 * Created by warrenm on 2016/06/28.
 */
public class BluRecyclerMenuAdapter extends RecyclerView.Adapter<BluRecyclerMenuAdapter.BluMenuHolder>
        implements ItemTouchAdapter {
    /*
     * Class created from the standard BluRecyclerAdapter
     * with a lot of fluff removed, with mainly the
     * onItemClickListener changed to create a
     * new fragment to display filtered vouchers.
     */

    private final String TAG = this.getClass().getSimpleName();

    private List<CardviewDataObject> data;
    private WeakReference<BaseActivity> baseActivityWeakReference;
    private BaseFragment baseFragment = null;
    private Fragment currentFragment = null;

    private Fragment fragment = null;
    private FragmentManager fm;

    public BluRecyclerMenuAdapter(Context context, List<CardviewDataObject> data) {
        this.data = data;
        if (context instanceof BaseActivity) {
            this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
        }
    }

    public BluRecyclerMenuAdapter(BaseFragment baseFragment, List<CardviewDataObject> data) {
        this.data = data;
        this.baseFragment = baseFragment;
        this.baseActivityWeakReference = new WeakReference<>(baseFragment.getBaseActivity());
    }

    @Override
    public BluMenuHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.blu_card, parent, false);
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                fm = baseActivity.getSupportFragmentManager();
                currentFragment = fm.findFragmentById(R.id.content_frame);

                if (currentFragment instanceof FragmentTransact) {
                    view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bill_card, parent, false);
                } else if (currentFragment instanceof FragmentVouchersMenu || currentFragment instanceof FragmentIthubaMenu) {
                    view = LayoutInflater.from(parent.getContext()).inflate(R.layout.menu_card, parent, false);
                }
            }
        }
        return new BluMenuHolder(view);
    }

    @Override
    public void onBindViewHolder(final BluMenuHolder holder, int position) {
        CardviewDataObject current = data.get(position);
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {

                if (holder.textDesc != null) {
                    if (current.getIconId() != 0) {
                        holder.textDesc.setVisibility(View.INVISIBLE);
                    } else {
                        holder.textDesc.setVisibility(View.VISIBLE);
                    }
                }

                if (holder.textDesc != null) {
                    holder.textDesc.setText(current.getCardDesc());
                }

                if (holder.card != null) {
                    holder.card.setBackgroundColor(current.getCardColor());

                    if (holder.textDesc.getText().toString().equalsIgnoreCase("axxess")) {
                        holder.card.setBackgroundResource(R.drawable.axxess_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("top tv")) {
                        holder.card.setBackgroundResource(R.drawable.starsat_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.starsat_border));
                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("dabba")) {
                        holder.card.setBackgroundResource(R.drawable.dabba_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("supabets")) {
                        holder.card.setBackgroundResource(R.drawable.supabets_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("discovery prepaid health")) {
                        holder.card.setBackgroundResource(R.drawable.discovery_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.discovery_border));

                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("lottostar")) {
                        holder.card.setBackgroundResource(R.drawable.lottostar_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));

                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("hollywood bets")) {
                        holder.card.setBackgroundResource(R.drawable.hollywoodbets_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));

                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("betflash")) {
                        holder.card.setBackgroundResource(R.drawable.betflash_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));

                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("africapin")) {
                        holder.card.setBackgroundResource(R.drawable.africapin_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));

                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("telkom")) {
                        holder.card.setBackgroundResource(R.drawable.telkom_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                        holder.textDesc.setVisibility(View.INVISIBLE);

                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("Ithuba")) {
                        holder.card.setBackgroundResource(R.drawable.ithuba_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.ithuba_lotto));
                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("Lotto")) {
                        holder.card.setBackgroundResource(R.drawable.ithuba_lotto_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.ithuba_lotto));
                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("Lotto Quickpick")) {
                        holder.card.setBackgroundResource(R.drawable.ithuba_lotto_quickpick_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.ithuba_lotto));
                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("Powerball")) {
                        holder.card.setBackgroundResource(R.drawable.ithuba_powerball_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.ithuba_powerball));
                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("Powerball Quickpick")) {
                        holder.card.setBackgroundResource(R.drawable.ithuba_powerball_quickpick_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.ithuba_powerball));

                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("putco")) {
                        holder.card.setBackgroundResource(R.drawable.putco_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));

                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("events")) {
                        holder.card.setBackgroundResource(R.drawable.events_menu_card);
                        holder.textDesc.setVisibility(View.INVISIBLE);
                        holder.icon.setVisibility(View.GONE);

                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("bus")) {
                        holder.card.setBackgroundResource(R.drawable.longhaulbus_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.black));
                    } else if (holder.textDesc.getText().toString().equalsIgnoreCase("nfc bus")) {
                        holder.card.setBackgroundResource(R.drawable.nfcbus_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    }
                    //<--------------chat for change providers------------!>
                    //we have included a hardcoded c4c string to distinguish between the vouchers hence the contains
                    else if (holder.textDesc.getText().toString().toLowerCase().contains("advinne")) {
                        holder.card.setBackgroundResource(R.drawable.advinne_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));

                    } else if (holder.textDesc.getText().toString().toLowerCase().equals("mvno")) {
                        holder.card.setBackgroundResource(R.drawable.mvno_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));

                    } else if (holder.textDesc.getText().toString().toLowerCase().contains("theunlimited")) {
                        holder.card.setBackgroundResource(R.drawable.theunlimited_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.theunlimited_border));

                    } else if (holder.textDesc.getText().toString().toLowerCase().contains("fnbconnect")) {
                        holder.card.setBackgroundResource(R.drawable.fnbconnect_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.fnbconnect));

                    } else if (holder.textDesc.getText().toString().toLowerCase().contains("myair")) {
                        holder.card.setBackgroundResource(R.drawable.myair_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.myair_border));

                    } else if (holder.textDesc.getText().toString().toLowerCase().contains("lycamobile")) {
                        holder.card.setBackgroundResource(R.drawable.lycamobile_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.lycamobile_border));

                    } else if (holder.textDesc.getText().toString().toLowerCase().contains("ott")) {
                        holder.card.setBackgroundResource(R.drawable.ott_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.lycamobile_border));

                    } else if (holder.textDesc.getText().toString().toLowerCase().contains("ringas")) {
                        holder.card.setBackgroundResource(R.drawable.ringas_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.ringas_border));

                    } else if (holder.textDesc.getText().toString().toLowerCase().contains("callall")) {
                        holder.card.setBackgroundResource(R.drawable.callall_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.callall_border));

                    } else if (holder.textDesc.getText().toString().toLowerCase().contains("lucky365")) {
                        holder.card.setBackgroundResource(R.drawable.lucky365_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.lucky365));

                    } else if (holder.textDesc.getText().toString().toLowerCase().equals("connect")) {
                        holder.card.setBackgroundResource(R.drawable.connect_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));

                    } else if (holder.textDesc.getText().toString().toLowerCase().contains("bluvoucher")) {
                        holder.card.setBackgroundResource(R.drawable.bluvoucher_menu_card);
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));

                    } else {
                        holder.textDesc.setVisibility(View.VISIBLE);
                        holder.icon.setImageResource(current.getIconId());
                        holder.textDesc.setTextColor(baseActivity.getResources().getColor(R.color.white));
                    }
                }
            }
        }
    }

    @Override
    public void onItemMove(int fromPosition, int toPosition) {
    }

    @Override
    public int getItemCount() {
        return this.data.size();
    }

    class BluMenuHolder extends RecyclerView.ViewHolder implements ItemTouchViewHolder {

        ImageView icon;
        TextView textDesc;
        CardView card;

        BluMenuHolder(final View itemView) {
            super(itemView);

            icon = itemView.findViewById(R.id.cardIcon);
            textDesc = itemView.findViewById(R.id.cardDesc);

            if (currentFragment instanceof FragmentTransact || currentFragment instanceof FragmentEskomOther) {
                card = itemView.findViewById(R.id.bill_card);
            } else if (currentFragment instanceof FragmentVouchersMenu || currentFragment instanceof FragmentIthubaMenu) {
                card = itemView.findViewById(R.id.menu_card);
            } else {
                card = itemView.findViewById(R.id.blu_card);
            }

            if (baseActivityWeakReference != null) {
                final BaseActivity baseActivity = baseActivityWeakReference.get();
                if (baseActivity != null) {
                    itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            //BaseActivity.logger.info(((BluDroidButton)view).getText());
                            if (currentFragment instanceof FragmentIthubaMenu) {
                                if (textDesc.getText().toString().equalsIgnoreCase("Lotto")) {
                                    goToNextScreen("lotto_ps");
                                } else if (textDesc.getText().toString().equalsIgnoreCase("Lotto Quickpick")) {
                                    goToNextScreen("lotto_qp");
                                } else if (textDesc.getText().toString().equalsIgnoreCase("Powerball")) {
                                    goToNextScreen("powerball_ps");
                                } else if (textDesc.getText().toString().equalsIgnoreCase("Powerball Quickpick")) {
                                    goToNextScreen("powerball_qp");
                                }
                            } else {
                                boolean goingToNfcBus = false;
                                FragmentTransaction ft = fm.beginTransaction();
                                baseActivity.resetTimer();
                                Bundle bundle = new Bundle();
                                bundle.putString("filteredCriteria", textDesc.getText().toString().replace("C4C", ""));

                                if (textDesc.getText().toString().equalsIgnoreCase(baseActivity.getString(R.string.ithuba))) {
                                    //baseActivity.gotoIthubaScreen();
                                    fragment = new FragmentIthubaMenu();
                                } else if (textDesc.getText().toString().equalsIgnoreCase("putco")) {
                                    //
                                    // make sure that secure USB printing is enabled
                                    //
                                    if (baseFragment.getPreference(PREF_SECURE_USB_PRINTER).equals(PREF_FALSE)) {
//                                        baseActivity.createAlertDialog("Secure USB Printer", baseFragment.getResources().getString(R.string.connectSecurePrinter));
                                        baseActivity.createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorSecurePrinterConfig, false);
                                        return;
                                    }

                                    baseActivity.isEventsScreen = false;
                                    fragment = new FragmentPutco();
                                } else if (textDesc.getText().toString().equalsIgnoreCase("events")) {
                                    fragment = new FragmentTicketProCategories();
                                    baseActivity.isEventsScreen = true;
                                } else if (textDesc.getText().toString().equalsIgnoreCase("bus")) {
                                    fragment = new FragmentCarmaSearchRoutesNew();
                                } else if (textDesc.getText().toString().equalsIgnoreCase("nfc bus")) {
                                    goingToNfcBus = true;
                                } else if (textDesc.getText().toString().equalsIgnoreCase("MVNO")) {
                                    fragment = new FragmentChatForChange();
                                } else {
                                    fragment = new FragmentVouchers();
                                }

                                if (goingToNfcBus) {
                                    baseActivity.gotoNfcBusScreen();
                                } else {
                                    fragment.setArguments(bundle);
                                    ft.replace(R.id.content_frame, fragment);
                                    ft.commit();
                                }
                            }
                        }
                    });

                    itemView.setOnCreateContextMenuListener(new View.OnCreateContextMenuListener() {
                        @Override
                        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
                            Log.d("kuijkenfav", "BluRecyclerMenuAdapter: " + currentFragment.getClass().getSimpleName());
                            baseActivity.resetTimer();
                            //MenuItem actionItem = null;
                            if (!baseActivity.isConsumerProfileActive()) {
                                if (currentFragment instanceof FragmentVouchersMenu) {
                                    addToFavourites();
                                } else if (currentFragment instanceof FragmentTickets) {
                                    addToFavourites();
                                } else if (currentFragment instanceof FragmentChatForChange) {
                                    addToFavourites();
                                }
                            }
                        }
                    });
                }
            }
        }

        void addToFavourites() {
            if (baseActivityWeakReference != null) {
                final BaseActivity baseActivity = baseActivityWeakReference.get();
                if (baseActivity != null) {
                    if (baseActivity.userLevel.equals("1")) {
                        BluDroidAlertDialog alert = baseActivity.createFavouritesDialog("Add to Favourites?");
                        alert.setPositiveOption(baseActivity.getString(R.string.add), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                baseActivity.resetTimer();
                                List<String> favourites = new ArrayList<>();
                                String strData = (((textDesc.getText().toString()).isEmpty()) ? "N/A" : textDesc.getText().toString())
                                        + ";" + "N/A"
                                        + ";" + "N/A"
                                        + ";" + "Menu"
                                        + ";" + "N/A"
                                        + ";" + "N/A"
                                        + ";" + "N/A";
                                favourites.add(strData);

                                Log.v(TAG, "Text Descrip: " + textDesc.getText().toString());
                                Log.v(TAG, strData);

                                if (!baseActivity.checkFavouritesListEntry(strData)) {
                                    if ((baseActivity.getFavouritesList()).size() < 21) {
                                        baseActivity.saveFavouritesList(favourites);
                                        baseActivity.getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, new FragmentConfirmConfigFavourites(), "FragmentFavourites").commit();
                                        Toast.makeText(baseActivity, textDesc.getText() + " " + textDesc.getText() + " added to Favourites", Toast.LENGTH_SHORT).show();
                                    } else {
                                        baseActivity.createAlertDialog(baseActivity.getResources().getString(R.string.dialogTitle), baseActivity.getResources().getString(R.string.dialogMaxFavourites));
                                    }
                                } else {
                                    baseActivity.createAlertDialog(baseActivity.getResources().getString(R.string.dialogTitle), textDesc.getText() + " already exists in your favourites.");
                                }

                            }
                        });

                        alert.setNegativeOption(baseActivity.getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                baseActivity.resetTimer();
                                dialog.dismiss();
                            }
                        });

                        alert.show();
                    }
                }
            }
        }

        void goToNextScreen(String name) {
            if (baseActivityWeakReference != null) {
                BaseActivity baseActivity = baseActivityWeakReference.get();
                if (baseActivity != null) {
                    baseActivity.cancelTimer();
                    if (name.contains("qp")) {
                        fragment = new FragmentIthubaQPick();
                    } else {
                        fragment = new FragmentIthubaPSelect();
                    }

                    Log.d(TAG, "NAME:" + name);
                    // FragmentTransaction ft = baseActivity.baseFm .beginTransaction();
                    Bundle bundle = new Bundle();
                    bundle.putString("thisScreen", this.getClass().getName());
                    bundle.putString("name", name);

                    fragment.setArguments(bundle);
                    baseActivity.baseFm.beginTransaction().replace(R.id.content_frame, fragment).commit();
                }
            }
        }

        @Override
        public void onItemSelected() {
        }

        @Override
        public void onItemClear() {
        }
    }

}
