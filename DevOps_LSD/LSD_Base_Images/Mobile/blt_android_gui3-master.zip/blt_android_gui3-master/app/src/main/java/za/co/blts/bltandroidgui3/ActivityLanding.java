package za.co.blts.bltandroidgui3;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import za.co.blt.interfaces.external.factories.LoginRequestFactory;
import za.co.blt.interfaces.external.factories.NfcBusRequestFactory;
import za.co.blt.interfaces.external.factories.ProfitDisplayRequestFactory;
import za.co.blt.interfaces.external.factories.SoldUnprintedRequestFactory;
import za.co.blt.interfaces.external.factories.UnprintedRequestFactory;
import za.co.blt.interfaces.external.fdroid.FdroidApplication;
import za.co.blt.interfaces.external.fdroid.FdroidFdroid;
import za.co.blt.interfaces.external.messages.common.request.CommonRequestMessage;
import za.co.blt.interfaces.external.messages.common.response.CommonResponseEventMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusConfirmCancelTicketResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusConfirmCheckoutResponseMessage;
import za.co.blt.interfaces.external.messages.profitdisplay.request.ProfitDisplayRequestMessage;
import za.co.blt.interfaces.external.messages.profitdisplay.response.ProfitDisplayResponseMessage;
import za.co.blt.interfaces.external.messages.soldunprinted.request.SoldUnprintedRequestMessage;
import za.co.blt.interfaces.external.messages.soldunprinted.response.SoldUnprintedResponseMessage;
import za.co.blt.interfaces.external.messages.unprinted.request.UnprintedAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.unprinted.request.UnprintedRequestMessage;
import za.co.blt.interfaces.external.messages.unprinted.response.UnprintedAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.unprinted.response.UnprintedResponseMessage;
import za.co.blt.interfaces.external.processors.SimpleXMLProcessor;
import za.co.blts.bltandroidgui3.confirmations.BluDroidLoginDialog;
import za.co.blts.bltandroidgui3.dynamic.DynamicBannerUtil;
import za.co.blts.bltandroidgui3.dynamic.DynamicPrintInfo;
import za.co.blts.bltandroidgui3.dynamic.DynamicPrintUtil;
import za.co.blts.bltandroidgui3.widgets.BluRecyclerView;
import za.co.blts.blukey.ActivityBluKey;
import za.co.blts.nfcbus.NfcBusRecovery;

import static android.provider.Settings.Secure.LOCATION_MODE_BATTERY_SAVING;
import static android.provider.Settings.Secure.LOCATION_MODE_HIGH_ACCURACY;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BALANCE_DISPLAY_ENABLED;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BLUKEY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CREATE_ICON;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CREATE_LANDING_ICON;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CURRENT_VERSION;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_EPUB_MANUAL_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_EPUB_READER_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FDROID_REPO_DIR;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FDROID_REPO_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HEARTBEAT_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_INSTALL_DECLINE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LAST_LOGIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOCATION_CHECK;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MANUAL_OVERRIDE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MENDIX_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PREVIOUS_SKIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER_TICKETS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PROFIT_DISPLAY_ENABLED;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RESET_DECLINE_COUNT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_USE_SSL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_UNKNOWN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_UPDATE_DATE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_SSL;

public class ActivityLanding extends BaseActivity implements NeedsAEONResults, BluLandingRecyclerAdapter.ItemClickListener {

    private final String TAG = this.getClass().getSimpleName();

    private BluLandingRecyclerAdapter adapter;
    private Boolean isKMSAppInstalled = false;
    private Boolean isDigitalOnboardingAppInstalled = false;
    private BluDroidLoginDialog loginDialog;
    private BluDroidLocationServices locationServices;
    private BluRecyclerView recyclerView;
    private ViewFlipper mViewFlipper;
    private List<Bitmap> bannerImages = new ArrayList<>();
    private BluDroidVolley bluDroidVolley;
    private List<LandingPageButton> buttons;
    private boolean loginForCard = false;
    private boolean goingToSetup = true;

    private final String GETSTARTED_CHAT = "MessageCount";
    private final String GETSTARTED_NOTIFICATION = "NotificationCount";
    private final String GETSTARTED_QUERY = "Queries";
    private final String GETSTARTED_TRAINING = "Training";
    private boolean getStartedChatSupported = false;
    private boolean getStartedNotificationSupported = false;
    private boolean getStartedQuerySupported = false;
    private boolean getStartedTrainingSupported = false;
    private int chatCount = 0;
    private int notificationCount = 0;

    private List<NfcBusRecovery> nfcBusRecoveries;
    private int recoveryIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String deviceId = getPreference(PREF_DEVICE_ID);
        Log.d("CheckSetup", "deviceId = " + deviceId);
        // checking to see if the deviceId is setup.  if not, this is
        // probably the first time the app is being run
        if (!deviceId.trim().isEmpty()) {
            goingToSetup = false;

            setContentView(R.layout.activity_landing);

            mViewFlipper = findViewById(R.id.flipper);

            nfcBusRecoveries = null;

            mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

            if (getPreference(PREF_LAST_LOGIN) == null || getPreference(PREF_LAST_LOGIN).equals("")) {
                updatePreference(PREF_LAST_LOGIN, String.valueOf(System.currentTimeMillis()));
            }

            mViewFlipper = findViewById(R.id.flipper);

            cancelTimer();

            String previousSkin = getPreference(PREF_PREVIOUS_SKIN);
            updatePreference(PREF_SKIN, previousSkin);

            if (!getPreference(PREF_CREATE_ICON).equals(PREF_UNKNOWN)) {
                removePreference(PREF_CREATE_ICON);
                removePreference(PREF_CREATE_LANDING_ICON);
                removeAliases();
            }

            if (getPreference(PREF_PRINT_MERCHANT_VOUCHER_TICKETS).equals(PREF_UNKNOWN)) {
                updatePreference(PREF_PRINT_MERCHANT_VOUCHER_TICKETS, PREF_TRUE);
            }

            if (getPreference(PREF_SKIN).equals(getResources().getString(R.string.skinTSPC))) {
                updatePreference(PREF_SKIN, getResources().getString(R.string.skinBLT));
            }
            configureSkin();

            bluDroidVolley = BluDroidVolley.getInstance(this);

            GridLayoutManager grid;
            if (getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
                grid = new GridLayoutManager(this, 5);
            } else {
                grid = new GridLayoutManager(this, 4);
            }
            RecyclerView.LayoutManager manager = grid;
            ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(this, R.dimen.item_offset);
            recyclerView = findViewById(R.id.buttonRecycler);
            recyclerView.addItemDecoration(itemDecoration);
            recyclerView.setLayoutManager(manager);

            buttons = new ArrayList<>();
            adapter = new BluLandingRecyclerAdapter(this, buttons);
            adapter.setClickListener(this);
            recyclerView.setAdapter(adapter);

            removeOldPrintLogos();
            checkApplicationUpdated();

            if (restartBluDroidForFirebase) {
                displayRestartDialog();
            } else {
                //AUto lgin stuff
                if (isForcedLogout) {
                    if (autoLoginRetryCap > 0) {
                        login(userPin);
                        isForcedLogout = false;
                        autoLoginRetryCap--;

                    } else {
                        autoLoginRetryCap = 2;
                    }
                }

                clearNFCActiveConsumer(false);

                FloatingActionButton fab = findViewById(R.id.fab);
                if (isGcrsSkin()) {
                    fab.setBackgroundTintList(ColorStateList.valueOf(getSkinResources().getAccentColor()));
                } else {
                    fab.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimaryDark)));
                }
                registerForContextMenu(fab);
                fab.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        openContextMenu(view);
                    }
                });

                locationServices = new BluDroidLocationServices(this);
                locationServices.start();

            }
            if (isDebug()) {
                getScreenDensity();
            }
        }

        remoteConfigInit();
    }

    private void remoteConfigInit() {
        mFirebaseAnalytics.setUserProperty("environment", "1");
        int minFetchInterval = 60 * 60 * 4; //4 hours
        if (isDebug()) {
            mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_config_defaults_dev);
            minFetchInterval = 20;
        } else if (isQa()) {
            mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_config_defaults_qa);
            minFetchInterval = 20;
        } else if (isGcrs()) {
            mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_config_defaults_gcrs);
        } else {
            mFirebaseRemoteConfig.setDefaultsAsync(R.xml.remote_config_defaults);
        }
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(minFetchInterval)
                .build();
        mFirebaseRemoteConfig.setConfigSettingsAsync(configSettings);
        Log.d("RemoteConfig", "default performance_monitoring: " + mFirebaseRemoteConfig.getBoolean("performance_monitoring"));
        fetchRemoteConfig();
    }

    private void fetchRemoteConfig() {
        mFirebaseRemoteConfig.fetchAndActivate()
                .addOnCompleteListener(this, new OnCompleteListener<Boolean>() {
                    @Override
                    public void onComplete(@NonNull Task<Boolean> task) {
                        if (task.isSuccessful()) {

                            Boolean updated = task.getResult();

                            if (updated != null && updated) {
                                if (getPreference(PREF_MANUAL_OVERRIDE).equals(PREF_FALSE)) {
                                    updatePreference(PREF_PORT, mFirebaseRemoteConfig.getString("aeon_port"));
                                    updatePreference(PREF_HOST, mFirebaseRemoteConfig.getString("aeon_host"));
                                    updatePreference(PREF_HEARTBEAT_URL, mFirebaseRemoteConfig.getString("heartbeat_url"));
                                    updatePreference(PREF_BLUKEY_URL, mFirebaseRemoteConfig.getString("blukey_url"));
                                    updatePreference(PREF_LOYALTY_URL, mFirebaseRemoteConfig.getString("api_gateway"));
                                    updatePreference(PREF_FDROID_REPO_URL, mFirebaseRemoteConfig.getString("repo_url"));
                                    updatePreference(PREF_RICA_DEVICE_SER, mFirebaseRemoteConfig.getString("rica_serial_number"));
                                    updatePreference(PREF_RICA_DEVICE_ID, mFirebaseRemoteConfig.getString("rica_device_id"));
                                    updatePreference(PREF_RICA_USE_SSL, mFirebaseRemoteConfig.getString("rica_ssl"));
                                    updatePreference(PREF_RICA_PORT, mFirebaseRemoteConfig.getString("rica_port"));
                                    updatePreference(PREF_RICA_HOST, mFirebaseRemoteConfig.getString("rica_host"));
                                    updatePreference(PREF_USE_SSL, mFirebaseRemoteConfig.getString("aeon_ssl"));
                                    updatePreference(PREF_MENDIX_URL, mFirebaseRemoteConfig.getString("mendix_url"));
                                }
                                firebaseBundle = new Bundle();
                                firebaseBundle.putLong("last_fetch", mFirebaseRemoteConfig.getInfo().getFetchTimeMillis());
                                mFirebaseAnalytics.logEvent("remote_config_update", firebaseBundle);
                            }
                            Log.i("RemoteConfig", "Config params updated: " + updated);

                        } else {
                            Log.e("RemoteConfig", "Config params downlaod failed " + Objects.requireNonNull(task.getException()).getMessage());
                        }
                    }
                });
    }

    private void updateBalanceProfitDisplayConfig(CommonResponseEventMessage event) {
        boolean enableBalanceDisplay = false;
        if (event != null && event.getBalanceDisplayEnabled() != null) {
            enableBalanceDisplay = event.getBalanceDisplayEnabled().equals("1");
        }
        updatePreference(PREF_BALANCE_DISPLAY_ENABLED, String.valueOf(enableBalanceDisplay));
        Log.v("ProfDisp", "PREF_BALANCE_DISPLAY_ENABLED = " + enableBalanceDisplay);

        boolean enableProfitDisplay = false;
        if (event != null && event.getProfitDisplayEnabled() != null) {
            enableProfitDisplay = event.getProfitDisplayEnabled().equals("1");
        }
        updatePreference(PREF_PROFIT_DISPLAY_ENABLED, String.valueOf(enableProfitDisplay));
        Log.v("ProfDisp", "PREF_PROFIT_DISPLAY_ENABLED = " + enableProfitDisplay);
    }

    private void getScreenDensity() {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        String msg;
        switch (metrics.densityDpi) {
            case DisplayMetrics.DENSITY_LOW:
                msg = "ldpi";
                break;
            case DisplayMetrics.DENSITY_MEDIUM:
                msg = "mdpi";
                break;
            case DisplayMetrics.DENSITY_HIGH:
                msg = "hdpi";
                break;
            case DisplayMetrics.DENSITY_XHIGH:
                msg = "xhdpi";
                break;
            case DisplayMetrics.DENSITY_XXHIGH:
                msg = "xxhdpi";
                break;
            case DisplayMetrics.DENSITY_XXXHIGH:
                msg = "xxxhdpi";
                break;
            default:
                msg = "unknown";
                break;
        }
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        Log.d(TAG, "***********Screen for " + Build.MODEL + " : " + msg + " - " + width + "x" + height);
    }

    private void displayRestartDialog() {
        final String msg = "The application needs to restart.\nRestarting in:  ";
        alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setCancelable(false);
        alertDialog.setTitle("Warning");
        alertDialog.setMessage(msg + "00:10");
        alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Restart Now", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                restartBluDroid();
            }
        });
        alertDialog.show();   //

        new CountDownTimer(10000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                alertDialog.setMessage(msg + "00:0" + (millisUntilFinished / 1000));
            }

            @Override
            public void onFinish() {
                restartBluDroid();
            }
        }.start();
    }

    @Override
    protected void onDestroy() {
        if (recyclerView != null) recyclerView.setAdapter(null);
        if (locationServices != null) locationServices.stop();
        if (bluDroidVolley != null) bluDroidVolley.cancelAll();
        super.onDestroy();
    }

    @Override
    public void onResume() {
        super.onResume();

        if (!goingToSetup) {
            isKMSAppInstalled = isPackageInstalled("com.ubits.payflow.kms_network", getPackageManager());
            isDigitalOnboardingAppInstalled = isPackageInstalled("io.mxapps.bluenovusdigitalon", getPackageManager());
//        isDigitalOnboardingAppInstalled = isPackageInstalled("io.mxapps.bluenovusdigitalonlocal", getPackageManager()); //test apk package during card testing

            if (isDigitalOnboardingAppInstalled) {
                File apk = new File(digitalOnboardingAppDir, "DigitalOnboarding.apk");
                if (apk.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    apk.delete();
                }

                String serNum = getPreference(PREF_DEVICE_SER);
                //chat feature disabled since CIC requirements not finalized
//                getStartedChatSupported = isMendixFeatureSupported(GETSTARTED_CHAT, serNum);
                getStartedNotificationSupported = isMendixFeatureSupported(GETSTARTED_NOTIFICATION, serNum);
                getStartedQuerySupported = isMendixFeatureSupported(GETSTARTED_QUERY, serNum);
                getStartedTrainingSupported = isMendixFeatureSupported(GETSTARTED_TRAINING, serNum);
            }

            if (checkToInstallNewVersion()) {
                installBluDroidUpdate();
            } else if (checkToInstallDigitalOnboarding()) {
                installDigitalOnboardingUpdate();
            }

            if (!isGcrsSkin()) {
                if (getStartedChatSupported || getStartedNotificationSupported) {
                    getNotificationMessageCount();
                } else {
                    doAreaCheck();
                }
            } else {
                checkDynamicBannerCache();
            }

            startBannerAnimation();
            drawButtons();

            if (isAirplaneModeOn()) {
                createUpdateAlertDialog("Error - Airplane Mode", "Please disable Airplane Mode on the following screen, then click the Back button to return to BluDroid.");
                alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent1 = new Intent("android.settings.WIRELESS_SETTINGS");
                        intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent1);
                    }
                });
                alert.show();
            }
        }
    }

    public void startBannerAnimation() {
        Log.d("DynamicBanner", "-----startBannerAnimation-----");
        loadBannerImages();
        mViewFlipper.removeAllViews();
        if (bannerImages.isEmpty()) {
            Log.d("BANNER", "adding default banner");
            if (isGcrsSkin()) {
                bannerImages.add(BitmapFactory.decodeResource(getResources(), R.drawable.banner_gcrs_green));
            } else {
                bannerImages.add(BitmapFactory.decodeResource(getResources(), R.drawable.banner));
            }
        }

        Log.d("BANNER", "bannerImages: " + bannerImages.size());

        for (Bitmap bm : bannerImages) {
            ImageView imageView = new ImageView(this);
            imageView.setImageBitmap(bm);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 0);
            imageView.setLayoutParams(lp);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            imageView.setAdjustViewBounds(true);
            mViewFlipper.addView(imageView);
        }
        mViewFlipper.invalidate();

        if (bannerImages.size() > 1) {
            mViewFlipper.setInAnimation(AnimationUtils.loadAnimation(this, R.anim.in_from_left));
            mViewFlipper.setOutAnimation(AnimationUtils.loadAnimation(this, R.anim.out_from_left));
            mViewFlipper.setAutoStart(true);
            mViewFlipper.setFlipInterval(5000);
            mViewFlipper.startFlipping();
        } else {
            mViewFlipper.stopFlipping();
        }
    }

    public void drawButtons() {
        buttons.clear();

        buttons.add(new LandingPageButton("Sell", R.drawable.sell));

        if (!isGcrsSkin()) {
            buttons.add(new LandingPageButton(isKMSAppInstalled ? "KMS" : "Download KMS", R.drawable.kms));

            buttons.add(new LandingPageButton("BluKey", R.drawable.blukey));

            if (Build.MODEL.startsWith("P1") || Build.MODEL.startsWith("N3") || getPreference(PREF_DEVICE_SER).startsWith("V1111")) {
                buttons.add(new LandingPageButton("Get Started", R.drawable.onboarding));
            }

            if (getPreference(PREF_SKIN).equals(getString(R.string.blt))) {
                buttons.add(new LandingPageButton("Training Manuals", R.drawable.manual));
            }

            if (cardTransactionPresent()) {
                buttons.add(new LandingPageButton("Swipe", R.drawable.payments));
            }

            String callMeData = getCachedCallMeData();
            try {
                JSONObject callme = new JSONObject(callMeData);
                callme.getJSONArray("menu");
                Log.d("CallMe", "valid callmedata: " + callMeData);
                buttons.add(new LandingPageButton("Please Call Me", R.drawable.callme));
            } catch (Exception ignore) {
                Log.e("CallMe", "invalid callmedata: " + callMeData);
            }

        }
//        for (int i=0; i<100; i++){
//            buttons.add(new LandingPageButton("Test " + i, R.drawable.callme));
//        }

        if (getStartedChatSupported) {
            buttons.add(new LandingPageButton("Chat", R.drawable.chat, chatCount));
        }
        if (getStartedNotificationSupported) {
            buttons.add(new LandingPageButton("Notifications", R.drawable.messages, notificationCount));
        }
        if (getStartedTrainingSupported) {
            buttons.add(new LandingPageButton("Training", R.drawable.training2));
        }
        if (getStartedQuerySupported) {
            buttons.add(new LandingPageButton("Deposit Queries", R.drawable.queries));
        }


//        if (isDebug() || isQa()) {
//            buttons.add(new LandingPageButton("NFC", R.drawable.nfc));
//        }

        adapter.notifyDataSetChanged();
    }

    private boolean isAirplaneModeOn() {
        return Settings.Global.getInt(this.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0;
    }


    @Override
    protected void onPause() {
        super.onPause();
        if (mViewFlipper != null)
            mViewFlipper.stopFlipping();
    }

    @Override
    public void onItemClick(int position) {
        removeZipFolder();

        firebaseBundle = new Bundle();
        firebaseBundle.putString(FirebaseAnalytics.Param.ITEM_ID, String.valueOf(adapter.getItem(position).getImg()));
        firebaseBundle.putString(FirebaseAnalytics.Param.ITEM_NAME, adapter.getItem(position).getLabel().toLowerCase());
        firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "button");

        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_ITEM, firebaseBundle);

        switch (adapter.getItem(position).getLabel().toLowerCase()) {
            case "sell":
                if (locationCheck()) {
                    loginForCard = false;
                    loginDialog = new BluDroidLoginDialog(this);
                    loginDialog.show();
                    locationServices.getLocationDetails(); // LB added
                }
                break;

            case "kms":
                if (isKMSAppInstalled) {
                    launchApp("com.ubits.payflow.kms_network",
                            adapter.getItem(position).getLabel().toUpperCase());
                }
                break;

            case "download kms":
                if (!isKMSAppInstalled) {
                    createUpdateAlertDialog("KMS", "KMS is not installed, would you like to download and install?");
                    alert.setPositiveOption("NOW", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            getKMS();
                        }
                    });
                    alert.setNegativeOption("LATER", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            alert.dismiss();
                        }
                    });
                    alert.show();
                }
                break;

            case "blukey":
                Intent intent = new Intent(ActivityLanding.this, ActivityBluKey.class);
                startActivity(intent);
                break;

            case "training manuals":
                if (isPackageInstalled("com.faultexception.reader", getPackageManager())) {
                    getEmanual();
                } else {
                    createUpdateAlertDialog("E-Pub reader", "E-pub reader is not installed, would you like to download and install?");
                    alert.setPositiveOption("NOW", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            getEpubReader();
                        }
                    });
                    alert.setNegativeOption("LATER", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            alert.dismiss();
                        }
                    });
                    alert.show();
                }
                break;

            case "please call me":
                gotoMerchantSupportScreen();
                break;

            case "get started":
                if (!isDigitalOnboardingAppInstalled) {
                    String message = "Would you like to download the Get Started application?\n\nNote: You will still be able to vend while the download continues";
                    if (Build.MODEL.startsWith("P1")) {
                        message = "Would you like to download the Get Started application?";
                    }

                    createUpdateAlertDialog("Get Started", message);
                    alert.setPositiveOption("NOW", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (Build.MODEL.startsWith("P1")) {
                                launchPlayStore();
                            } else {
                                getDigitalOnboardingAppFromRepo();
                            }
                        }
                    });
                    alert.setNegativeOption("LATER", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            alert.dismiss();
                        }
                    });
                    alert.show();
                } else {
                    launchApp("io.mxapps.bluenovusdigitalon",
                            adapter.getItem(position).getLabel().toUpperCase());
                }
                break;

            case "swipe":
                checkDeviceCanDoCard();
                break;

            case "nfc":
                gotoTestNfcOperationScreen();
                break;

            case "chat":
                launchGetStartedForFeature(GETSTARTED_CHAT, getPreference(PREF_DEVICE_SER));
                break;

            case "notifications":
                launchGetStartedForFeature(GETSTARTED_NOTIFICATION, getPreference(PREF_DEVICE_SER));
                break;

            case "deposit queries":
                launchGetStartedForFeature(GETSTARTED_QUERY, getPreference(PREF_DEVICE_SER));
                break;

            case "training":
                launchGetStartedForFeature(GETSTARTED_TRAINING, getPreference(PREF_DEVICE_SER));
                break;
        }
    }

    public void doRequest(String devId) {
        String url = getPreference(PREF_LOYALTY_URL) + "/customer/support/help/v1/callme/area";

        Map<String, String> params = new HashMap<>();
        params.put("deviceId", devId);

        JSONObject parameters = new JSONObject(params);

        JsonObjectRequest areaReq = new JsonObjectRequest(Request.Method.POST, url, parameters,
                createReqSuccessListener(),
                createReqErrorListener());
        areaReq.setTag(this);

        bluDroidVolley.addRequestApiGateway(areaReq); // make sure that this is not null
        Log.d("CallMe", ">>>>>>>>>area request to: " + url);
    }

    //----------------------------------------------------------------------------------------------
    public Response.Listener<JSONObject> createReqSuccessListener() {
        return new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("CallMe", response.toString());
                cacheCallMeData(response.toString());
                drawButtons();
                checkDynamicBannerCache();
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    public Response.ErrorListener createReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("CallMe", error.toString());
                Log.e("CallMe", "error.getMessage(): " + error.getMessage());
                Log.e("CallMe", "error.networkResponse.status: " + (error.networkResponse == null ? null : error.networkResponse.statusCode));
                if (error.networkResponse != null && error.networkResponse.statusCode == 403) {
                    //if we receive 403 response, Call Me button must be disabled, so we cache an empty string
                    Log.e("CallMe", "clear CallMeCache");
                    cacheCallMeData("");
                } else {
                    //for any other error response, we re-cache the existing data for the next 12 hours
                    Log.e("CallMe", "re-caching CallMeCache");
                    cacheCallMeData(getCachedCallMeData());
                }
                drawButtons();
                checkDynamicBannerCache();
            }
        };
    }

    private void getEpubReader() {
        try {
            gettingEpubReader = true;
            checkingVersion = false;
            createProgress("Getting e-pub reader...");

            String url = getPreference(PREF_EPUB_READER_URL);

            HTTPGetAsyncTask httpGetAsyncTask = new HTTPGetAsyncTask(this);
            httpGetAsyncTask.execute(this, url);

            Log.d("ConnectEPUB", url);
        } catch (Exception exception) {
            Log.d(TAG, "problems with HTTPGet " + exception);
        }
    }

    private void getKMS() {
        try {
            gettingKMS = true;
            checkingVersion = false;
            createProgress("Getting KMS App...");
            String url = "http://196.38.158.102/touchscreen/kms/KMS.apk";

            if (Build.MODEL.startsWith("N3")) {
                url = "http://196.38.158.102/Nexgo/kms/KMS.apk";
            }
            HTTPGetAsyncTask httpGetAsyncTask = new HTTPGetAsyncTask(this);
            httpGetAsyncTask.execute(this, url);
            Log.d("ConnectKMS", url);
        } catch (Exception exception) {
            Log.d(TAG, "problems with HTTPGet " + exception);
        }
    }


    private void getDigitalOnboardingAppFromRepo() {
        gettingDigitalOnboardingApp = true;
        Toast.makeText(this, "Downloading APK, you will be notified when download is complete", Toast.LENGTH_LONG).show();

        HTTPGetAsyncTask httpGetAsyncTask = new HTTPGetAsyncTask(this);
        String url = getPreference(PREF_FDROID_REPO_URL);
        url = url.concat(getPreference(PREF_FDROID_REPO_DIR) + "DigitalOnboarding.apk");

        httpGetAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, this, url);
        Log.d("ConnectDoB", url);
    }

    private void launchApp(String appPackage, String appName) {
        Intent LaunchIntent = getPackageManager()
                .getLaunchIntentForPackage(appPackage);
        startActivity(LaunchIntent);
        Log.i(TAG, appName + " is already installed.");
    }

    private void getEmanual() {
        try {
            gettingManual = true;
            createProgress("Getting manual...");

            String url = getPreference(PREF_EPUB_MANUAL_URL);

            HTTPGetAsyncTask asyncTask = new HTTPGetAsyncTask(this);
            asyncTask.execute(this, url);
            Log.d("ConnectEPUB", url);
            // }
        } catch (Exception exception) {
            Log.d(TAG, "problems with HTTPGet " + exception);
        }

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.login_options_menu, menu);

        if (!Build.MODEL.contains("P1")) {
            menu.add("Download APK");
            MenuItem downloadAPk = menu.getItem(menu.size() - 1);

            downloadAPk.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    getFdroidIndex();
                    return false;
                }
            });
        }

        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            SpannableString spanString = new SpannableString(menu.getItem(i).getTitle().toString());
            spanString.setSpan(new ForegroundColorSpan(Color.WHITE), 0, spanString.length(), 0); //fix the color to white
            item.setTitle(spanString);
        }

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        logger.info("ActivityLanding " + item.getTitle());
        switch (item.getItemId()) {

            case R.id.technicianLogin:
                gotoTechnicianLoginScreen();
                isForcedLogout = false;
                return true;

            case R.id.refresh:
                refresh();
                drawButtons();
                startBannerAnimation();
                return true;

            case R.id.testPeripherals:
                gotoTestPeripheralsScreen();
                isForcedLogout = false;
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //
// called by AEONAsyncTask
//
    public void results(Object object) {
        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(Landing) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }
        //
        // NB:  the order of these tests.  Be sure to do the Unprint tests first,
        //      then the  sold tests, and lastly the loginResponseMessage test
        //

        if (object instanceof UnprintedAuthenticationResponseMessage) {
            UnprintedAuthenticationResponseMessage unprintedAuthenticationResponseMessage = (UnprintedAuthenticationResponseMessage) object;
            loginResponseMessage.setSessionId(unprintedAuthenticationResponseMessage.getSessionId());
            UnprintedRequestFactory factory = new UnprintedRequestFactory();
            UnprintedRequestMessage request = factory.create(unprintedAuthenticationResponseMessage);
            startAEONAsyncTask(this, socket, request);

        } else if (object instanceof UnprintedResponseMessage) {
            Log.d(TAG, "unprintedresponsemessage");
            unprintedResponseMessage = (UnprintedResponseMessage) object;

            if (unprintedResponseMessage.getEvent().getEventCode().equals("0")) {
                printWithDynamic(unprintedResponseMessage.getData().getReprint(), getPrintBarcode());
                printQueue--;
                loginResponseMessage.getData().setPrintQueue(String.valueOf(printQueue));
            } else {
                printQueue = 0;
            }

            if (isVoucherPrinted) {
                SoldUnprintedRequestFactory factory = new SoldUnprintedRequestFactory();
                SoldUnprintedRequestMessage request = factory.create(loginResponseMessage);
                startAEONAsyncTask(ActivityLanding.this, socket, request);
            } else {
                cleanUp();
                createPrintErrorConfirmation();
            }

        } else if (object instanceof SoldUnprintedResponseMessage) {
            Log.d(TAG, "soldunprintedresponsemessage");

            if (printQueue > 0) {
                UnprintedRequestFactory factory = new UnprintedRequestFactory();
                UnprintedRequestMessage request = factory.create(loginResponseMessage);
                startAEONAsyncTask(ActivityLanding.this, socket, request);
            } else {
                dismissProgress();
                dismissLoginDialog();
                cacheLoginData(loginResponseMessage);
                firebaseSessionStart();
                if (onlineLogin) {
                    getProfitDisplay();
                } else {
                    gotoMainScreen();
                }
            }
        } else if (object instanceof ProfitDisplayResponseMessage) {
            ProfitDisplayResponseMessage response = (ProfitDisplayResponseMessage) object;
            if (response.getEvent().getEventCode().equals("0")) {
                saveAccountDetails(response.getAccounts());
            }
            nfcBusRecoveries = recoveryCacheHandler.getRecoveries();
            if (!nfcBusRecoveries.isEmpty()) {
                recoveryIndex = 0;

                createProgress(getResources().getString(R.string.authenticating));
                NfcBusRequestFactory factory = new NfcBusRequestFactory();
                NfcBusAuthenticationRequestMessage req = factory.auth(loginResponseMessage.getData().getUserPin(),
                        getPreference(PREF_DEVICE_ID),
                        getPreference(PREF_DEVICE_SER),
                        "SmartTapEldo");
                startAEONAsyncTask(this, socket, req);

            } else {
                getFdroidIndex();
            }
        } else if (object instanceof NfcBusAuthenticationResponseMessage) {
            if (((NfcBusAuthenticationResponseMessage) object).getEvent().getEventCode().equals("0")) {
                handleRecovery(((NfcBusAuthenticationResponseMessage) object).getSessionId());
            } else {
                onlineLogin = true;
                createSystemErrorConfirmation(object, true);
            }

        } else if (object instanceof NfcBusConfirmCheckoutResponseMessage) {

            if (((NfcBusConfirmCheckoutResponseMessage) object).getEvent().getEventCode().equals("0")) {
                saveAccountDetails(((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getAccounts());

                if (((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getStatus().equals("1")) {
                    recoveryCacheHandler.deleteRecoveryFromCache(nfcBusRecoveries.get(recoveryIndex).getTransRef());

                    if (!((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getPrintLines().isEmpty()) {
                        printWithDynamic(((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getPrintLines(), getPrintBarcode());
                    }
                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)
                            && !((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getMerchantPrintLines().isEmpty()) {
                        print(((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getMerchantPrintLines());
                    }
                    recoveryIndex++;
                    handleRecovery(((NfcBusConfirmCheckoutResponseMessage) object).getSessionId());
                } else {
                    onlineLogin = true;
                    loginRequestMessage = null;
                    loginResponseMessage = null;
                    createSystemErrorConfirmation(((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getMessage(), true);
                }
            } else {
                onlineLogin = true;
                loginRequestMessage = null;
                loginResponseMessage = null;
                createSystemErrorConfirmation(object, true);
            }

        } else if (object instanceof NfcBusConfirmCancelTicketResponseMessage) {
            if (((NfcBusConfirmCancelTicketResponseMessage) object).getEvent().getEventCode().equals("0")) {
                saveAccountDetails(((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getAccounts());

                if (((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getStatus().equals("1")) {
                    recoveryCacheHandler.deleteRecoveryFromCache(nfcBusRecoveries.get(recoveryIndex).getTransRef());

                    if (!((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getPrintLines().isEmpty()) {
                        printWithDynamic(((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getPrintLines(), getPrintBarcode());
                    }

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)
                            && !((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getMerchantPrintLines().isEmpty()) {
                        print(((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getMerchantPrintLines());
                    }

                    recoveryIndex++;
                    handleRecovery(((NfcBusConfirmCancelTicketResponseMessage) object).getSessionId());
                } else {
                    onlineLogin = true;
                    loginRequestMessage = null;
                    loginResponseMessage = null;
                    createSystemErrorConfirmation(((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getMessage(), true);
                }
            } else {
                onlineLogin = true;
                loginRequestMessage = null;
                loginResponseMessage = null;
                createSystemErrorConfirmation(object, true);
            }


        } else if (object instanceof LoginResponseMessage) {
            dismissProgress();
            loginResponseMessage = (LoginResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(loginResponseMessage.getEvent());
            updateBalanceProfitDisplayConfig(loginResponseMessage.getEvent());

            if (loginResponseMessage.getEvent().getEventCode().equals("0")) {
                //
                // DO NOT REMOVE THIS LOG ENTRY.
                // IT IS USED FOR TESTING
                Log.d(TAG, "TEST: SUCCESSFUL LOGIN");
                dismissLoginDialog();
                saveFirebaseAeonFlag();

                if (onlineLogin || loginForCard) {
                    cacheLoginData(loginResponseMessage);
                }
                if (loginForCard) {
                    checkLoginForCard();
                } else {
                    loggedInUserName = loginResponseMessage.getData().getUserName();
                    cancelTimer();
                    if (loginResponseMessage.getData().getPrintQueue() == null ||
                            loginResponseMessage.getData().getPrintQueue().trim().isEmpty() ||
                            loginResponseMessage.getData().getPrintQueue().equals("0")) {
                        //
                        // successful login
                        //


                        firebaseSessionStart();


                        if (!onlineLogin) {
                            closeAeonSocket(0);
                            gotoMainScreen();
                        } else {
                            getProfitDisplay();
                        }
                    } else {
                        //
                        // some vouchers to print
                        //
                        try {
                            printQueue = Integer.parseInt(loginResponseMessage.getData().getPrintQueue());
                        } catch (Exception exception) {
                            Log.v(TAG, "PrintQueue is non numeric " + exception);
                        }
                        if (printQueue > 0) {

                            alert = createCustomAlertDialog("Reprints", "The Device will now print out vouchers that might not have printed.");

                            alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    createProgress(R.string.gettingUnprintedVouchers);
                                    UnprintedRequestFactory factory = new UnprintedRequestFactory();
                                    UnprintedAuthenticationRequestMessage request =
                                            factory.create(loginResponseMessage.getData().getUserPin(),
                                                    getPreference(PREF_DEVICE_ID),
                                                    getPreference(PREF_DEVICE_SER));

                                    startAEONAsyncTask(ActivityLanding.this, socket, request);
                                }
                            });
                            alert.show();
                        } else {
                            closeAeonSocket(1);
                        }
                    }
                }
            } else {
                closeAeonSocket(2);
                if (loginDialog != null) {
                    loginDialog.clearPassword();
                }
                Integer messageType = aeonErrors.process(loginResponseMessage);
                if (loginDialog != null && messageType.equals(AEONErrors.INLINE)) {
                    loginDialog.displayError(loginResponseMessage.getData().getAeonErrorText());
                } else {
                    createSystemErrorConfirmation(loginResponseMessage, true);
                }
            }

        } else {
            //
            // handle other data types such as Socket
            //
            super.results(object);
        }

        if (object != null && !(object instanceof Socket) && !(object instanceof byte[]) && connectedToAEON) {
            connectedToAEON = false;
            firebaseBundle = new Bundle();
            firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            mFirebaseAnalytics.logEvent("aeon_connection", firebaseBundle);
        }
    }

    private void firebaseSessionStart() {
        firebaseBundle = new Bundle();
        firebaseSessionStart = System.currentTimeMillis();
        firebaseSessionId = getPreference(PREF_DEVICE_ID) + "_" + firebaseSessionStart;
        firebaseBundle.putString("bd_session_id", firebaseSessionId);
        String sessionType = "offline";
        if (onlineLogin)
            sessionType = "online";
        firebaseBundle.putString("bd_session_type", sessionType);
        mFirebaseAnalytics.logEvent("bd_session_start", firebaseBundle);

        long lastLogin = Long.parseLong(getPreference(PREF_LAST_LOGIN));
        long timePassed = System.currentTimeMillis() - lastLogin;
        if (timePassed > ONE_MONTH) {
            firebaseBundle = new Bundle();
            firebaseBundle.putLong("last_login", lastLogin);
            firebaseBundle.putLong("time_passed", timePassed);
            mFirebaseAnalytics.logEvent("first_time_login", firebaseBundle);
        }

        updatePreference(PREF_LAST_LOGIN, String.valueOf(System.currentTimeMillis()));
    }

    //
    // called by AEONAsyncTask
    //
    public void error(Object object) {
        Log.d(TAG, "error object " + object);
        super.error(null);
    }

    @Override
    public void onBackPressed() {
        alert = exitApplicationDialog("Exit Application", "Are you sure you want to close this activity?");

        alert.setPositiveOption(getString(R.string.exit), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alert.dismiss();
            }
        });

        alert.show();
    }

    public void doAreaCheck() {
        Date now = new Date();
        Date callMeCacheDate = dateCallMeCache();
        Log.d(TAG, "cache expired " + ((now.getTime() - callMeCacheDate.getTime()) > CACHE_12_HOURS));
        Log.d(TAG, "maxCacheAgeMillis " + CACHE_12_HOURS);
        Log.d(TAG, "now.getTime() " + now.getTime());
        Log.d(TAG, "now " + now);
        Log.d(TAG, "callMeCacheDate.getTime() " + callMeCacheDate.getTime());
        Log.d(TAG, "callMeCacheDate " + callMeCacheDate);
        Log.d(TAG, "diff is " + (now.getTime() - callMeCacheDate.getTime()));

        if ((now.getTime() - callMeCacheDate.getTime()) > CACHE_12_HOURS) {
            doRequest(getPreference(PREF_DEVICE_ID));//54453
        } else {
            checkDynamicBannerCache();
        }
    }

    public void login(String pin) {
        Log.d(TAG, "Logging in");
        try {
            getLoginCache(pin);
            //
            // NB: temporarily clear all caches
            //
            // Nkosana, if the caching is really not working well,
            // just uncommment this refresh line below.  That will
            // for all data to be read on every login
            //
            //refresh();
//            Log.d(TAG, "this pin = " + pin);
//            Log.d(TAG, "loginRequestMessage = " + loginRequestMessage);
//            Log.d(TAG, "loginResponseMessage = " + loginResponseMessage);

            userPin = pin;
            String previousPin = null;
            if (loginRequestMessage != null) {
                previousPin = loginRequestMessage.getEvent().getUserPin();
            }
//            Log.d(TAG, "previous pin = " + previousPin);
            Log.d(TAG, "pins !equals? " + !pin.equals(previousPin));

            Date now = new Date();
            Date lastOnlineLoginDate = dateLastLoginCache(pin);

            if (loginRequestMessage == null || loginResponseMessage == null || !pin.equals(previousPin)
                    || !loginResponseMessage.getEvent().getEventCode().equals("0") || now.getTime() - lastOnlineLoginDate.getTime() > CACHE_12_HOURS) {
                //
                // setting these voucher values to null is a temporary thing
                // until the max cache age is implemented in the setup page
                //
                Log.d(TAG, "Online login");

                createProgress(R.string.signingIn);
                //
                // now do a login
                //
                Log.d(TAG, "host is [" + getPreference(PREF_HOST) + "]");
                Log.d(TAG, "port is [" + getPreference(PREF_PORT) + "]");
                Log.d(TAG, "device id is [" + getPreference(PREF_DEVICE_ID) + "]");
                Log.d(TAG, "device serial is [" + getPreference(PREF_DEVICE_SER) + "]");
                Log.d(TAG, "location is [" + location + "]");
                LoginRequestFactory factory = new LoginRequestFactory();
                loginRequestMessage = factory.create(pin,
                        getPreference(PREF_DEVICE_ID),
                        getPreference(PREF_DEVICE_SER),
                        getVersionName(),
                        location);

                startAEONAsyncTask(this, loginRequestMessage);
                onlineLogin = true;

            } else {
                Log.d(TAG, "FAKE LOGIN");
                Log.d(TAG, "loginRequestMessage = " + loginRequestMessage);
                Log.d(TAG, "loginResponseMessage = " + loginResponseMessage);
                Log.d(TAG, "loginResponse event code " + loginResponseMessage.getEvent().getEventCode());
                Log.d(TAG, "Offline login");
                onlineLogin = false;
                results(loginResponseMessage);

                //getAccountBalanceIfNecessary();
            }
        } catch (Exception exception) {
            Log.d(TAG, "exception trying to generate login message " + exception);
            logger.error("exception trying to generate login message" + exception);
        }
    }

    private boolean checkToInstallNewVersion() {
        try {
            // http://stackoverflow.com/questions/32628985/run-apk-from-inside-android-application
            final File indexFile = new File(appDir.getPath() + "/" + getResources().getString(R.string.downloadCacheDir)
                    + "/index.xml");

            final String apkName = getResources().getString(
                    isDebug() ? R.string.downloadApkNameDebug
                            : isQa() ? R.string.downloadApkNameQa
                            : isGcrs() ? R.string.downloadApkNameGcrs
                            : R.string.downloadApkName);

            File apkFile = new File(appDir.getPath() + "/" + getResources().getString(R.string.downloadCacheDir) + "/" + apkName);

            SimpleXMLProcessor simpleXMLProcess = new SimpleXMLProcessor();

            if (indexFile.exists()) {

                FileInputStream is = new FileInputStream(indexFile);
                int size = is.available();
                byte[] buffer = new byte[size];
                //noinspection ResultOfMethodCallIgnored
                is.read(buffer);
                is.close();
                String inputString = new String(buffer).replace("<?xml version=\"1.0\" ?>", "");

                Log.d(TAG, "Back from downloads " + inputString);
                fdroid = (FdroidFdroid) simpleXMLProcess.unmarshal(inputString, FdroidFdroid.class);

                for (int i = 0; i < fdroid.getApplications().size(); i++) {
                    FdroidApplication application = fdroid.getApplications().get(i);
                    Log.d(TAG, "i=" + i + " fdroid name:" + application.getName() + "(" + application.getId() + ") app name:" + getApplicationName() + "(" + getApplicationId() + ")");
                    if (application.getName().equals(getApplicationName()) || application.getId().equals(getApplicationId())) {  // this second test is for historical reasons
                        int versionOnFdroid = Integer.parseInt(application.getPackage().getVersionCode());
                        version = application.getPackage().getVersion();
                        Log.d(TAG, "version on fdroid is " + version);
                        if (versionCode < versionOnFdroid && apkFile.exists()) {
                            return true;
                        }
                        break;
                    }
                }

            }

        } catch (Exception ex) {
            Log.d(TAG, "onCreate: " + ex.getMessage());
        }
        return false;
    }

    private void dismissLoginDialog() {
        if (loginDialog != null) {
            loginDialog.dismiss();
        }
    }

    private void checkApplicationUpdated() {
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            String verCode = String.valueOf(pInfo.versionCode);
            String savedCode = getPreference(PREF_CURRENT_VERSION);
            Log.d("DECLINE", "version codes - saved=" + savedCode + " current=" + verCode);
            if (!verCode.equals(savedCode)) {
                String date = new SimpleDateFormat("yyyyMMddHHmm", Locale.US).format(new Date());

                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString(PREF_CURRENT_VERSION, verCode);
                editor.putString(PREF_UPDATE_DATE, date);
                editor.putString(PREF_RESET_DECLINE_COUNT, PREF_TRUE);
                editor.apply();
                Log.d("DECLINE", "updated PREF_CURRENT_VERSION: " + verCode);
                Log.d("DECLINE", "updated PREF_UPDATE_DATE: " + date);
                Log.d("DECLINE", "updated PREF_RESET_DECLINE_COUNT: " + PREF_TRUE);
            }

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            logger.error("checkApplicationUpdated " + e);
        }
    }

    private boolean cardTransactionPresent() {
        boolean trxTypePresent = false;
        try {
            long mostRecent = 0;
            File mostRecentFile = null;
            File dir = new File(loginCacheDir.getPath());
            for (File f : dir.listFiles()) {
                if (f.lastModified() > mostRecent) {
                    mostRecent = f.lastModified();
                    mostRecentFile = f;
                }
            }

            if (mostRecentFile != null && mostRecentFile.exists()) {
                Log.d("CardAcq", "cache age (ms): " + (System.currentTimeMillis() - mostRecentFile.lastModified()));
                InputStream is = new FileInputStream(mostRecentFile);
                BufferedReader buf = new BufferedReader(new InputStreamReader(is));
                String line = buf.readLine();
                StringBuilder sb = new StringBuilder();

                while (line != null) {
                    sb.append(line).append("\n");
                    line = buf.readLine();
                }
                String fileAsString = sb.toString();

                SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
                LoginResponseMessage loginResponseMessage = (LoginResponseMessage) xmlProcessor.unmarshal(fileAsString, LoginResponseMessage.class);
                trxTypePresent = loginResponseMessage.getData().canDo("CardPayment");
            }

        } catch (Exception exception) {
            Log.d(TAG, "problems reading login cache " + exception);
            logger.error(TAG + " problems reading login cache " + exception);
        }
        Log.d("CardAcq", "trxTypePresent: (" + "CardPayment" + ")" + trxTypePresent);
        return trxTypePresent;
    }

    private void checkDeviceCanDoCard() {
        if (isDigitalOnboardingAppInstalled) {
            authForCard();
        } else if (Build.MODEL.startsWith("P1") || Build.MODEL.startsWith("N3") || getPreference(PREF_DEVICE_SER).startsWith("V1111")) {
            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorInstallGetStarted, false);
        } else {
            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorDeviceCannotSwipe, false);
        }
    }

    private void authForCard() {
        loginForCard = true;
        loginRequestMessage = null; //force online login
        loginDialog = new BluDroidLoginDialog(this);
        loginDialog.show();
        locationServices.getLocationDetails(); // LB added
    }

    private void checkLoginForCard() {
        closeAeonSocket(32);
        if (loginResponseMessage.getData().canDo("CardPayment")) {
            String userLevel = loginResponseMessage.getData().getUserLevel();
            Log.d("CardAcq", "userLevel = " + userLevel);
//            Toast.makeText(this, "Launching Mendix for card", Toast.LENGTH_SHORT).show();
            launchGetStartedForCard(userLevel);
        } else {
            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorSwipeNotAllowed, false);
            //clear login cache to remove Swipe button
            removeLoginCache();
            drawButtons();
        }
    }

    private void launchGetStartedForCard(String userLevel) {
        try {
            String url = "https://getstarted/cardacquiring?deviceID=" + getPreference(PREF_DEVICE_ID) + "&userRole=" + userLevel;
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            browserIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(browserIntent);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("launchGetStartedForCard " + e);
            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorCannotLaunchGetStarted, false);
        }
    }

    private void installBluDroidUpdate() {
        createUpdateAlertDialog("Update", "The new version has been downloaded. Would you like to install?");

        alert.setPositiveOption("NOW", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final String apkName = getResources().getString(
                        isDebug() ? R.string.downloadApkNameDebug
                                : isQa() ? R.string.downloadApkNameQa
                                : isGcrs() ? R.string.downloadApkNameGcrs
                                : R.string.downloadApkName);

                firebaseBundle = new Bundle();
                firebaseBundle.putInt("decline_install_count", getDeclineCount(PREF_INSTALL_DECLINE));
                mFirebaseAnalytics.logEvent("accept_install", firebaseBundle);

                Intent intent = new Intent(Intent.ACTION_VIEW)
                        .setDataAndType(Uri.parse("file://" + appDir.getPath() + "/" +
                                        getResources().getString(R.string.downloadCacheDir) + "/" + apkName),
                                "application/vnd.android.package-archive");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });

        alert.setNegativeOption("LATER", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                installDeclineIncrement();
                firebaseBundle = new Bundle();
                firebaseBundle.putInt("decline_install_count", getDeclineCount(PREF_INSTALL_DECLINE));
                mFirebaseAnalytics.logEvent("decline_install", firebaseBundle);
                alert.dismiss();
            }
        });

        alert.show();
    }

    private boolean checkToInstallDigitalOnboarding() {
        File apk = new File(digitalOnboardingAppDir, "DigitalOnboarding.apk");
        return apk.exists();
    }

    private void installDigitalOnboardingUpdate() {
        createUpdateAlertDialog("Update", "The Digital Onboarding application has been downloaded. Would you like to install?");

        alert.setPositiveOption("NOW", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Intent.ACTION_VIEW)
                        .setDataAndType(Uri.parse("file://" + appDir.getPath() + "/" +
                                        getResources().getString(R.string.digitalOnboardingAppDir) + "/DigitalOnboarding.apk"),
                                "application/vnd.android.package-archive");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        alert.setNegativeOption("LATER", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alert.dismiss();
            }
        });

        alert.show();
    }

    private void checkDynamicPrintCache() {
        Date now = new Date();
        Date cache = dateDynamicPrintCache();
        Log.d("DynamicPrint", "print cache age: " + (now.getTime() - cache.getTime()));

        if ((now.getTime() - cache.getTime()) > CACHE_7_DAYS) {
            //if cache older than 7 days, consider all dynamic prints expired and remove the cache
            removeDynamicPrintCache();
        }

        if ((now.getTime() - cache.getTime()) > CACHE_12_HOURS) {
            //if cache older than 12 hours, request an update
            getDynamicPrints();
        } else {
//            startBannerAnimation();
            DynamicPrintUtil util = new DynamicPrintUtil(ActivityLanding.this);
            util.updatePrintImages();
        }
    }

    private void getDynamicPrints() {
        Location location = locationServices.getSavedLocation();
        String url = getPreference(PREF_MENDIX_URL) + "/rest/advert/v1/print";
        String locStr = location == null ? "?lat&long" : "?lat=" + location.getLatitude() + "&long=" + location.getLongitude();
        url += locStr;
        Log.d("DynamicPrint", "request to : " + url);
        logger.info("DynamicPrint request to : " + url);
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.i("DynamicPrint", "response: " + response.toString());
                        logger.info("DynamicPrint response: " + response.toString());
                        cacheDynamicPrint(response.toString());
                        DynamicPrintUtil util = new DynamicPrintUtil(ActivityLanding.this);
                        DynamicPrintInfo info = new DynamicPrintInfo(ActivityLanding.this);
                        info.clear(ActivityLanding.this);
                        util.updatePrintImages();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        cacheDynamicPrint("[]");
                        logger.error("DynamicPrint", error);
                        Log.e("DynamicPrint", error.toString());
                        Log.e("DynamicPrint", "error.getMessage(): " + error.getMessage());
                        Log.e("DynamicPrint", "error.networkResponse.status: " + (error.networkResponse == null ? null : error.networkResponse.statusCode));
                        startBannerAnimation();
                    }
                });
        bluDroidVolley.addRequestDynamicPrints(request);
    }

    private void checkBannerImages() {
        final DynamicBannerUtil dynamicBannerUtil = new DynamicBannerUtil(ActivityLanding.this);
        new Thread() {
            public void run() {
                dynamicBannerUtil.updateBannerImages();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        checkDynamicPrintCache();
                    }
                });
            }
        }.start();
    }

    private void checkDynamicBannerCache() {
        Date now = new Date();
        Date cache = dateBannerCache();
        Log.d("DynamicBanner", "banner cache age: " + (now.getTime() - cache.getTime()));

        if ((now.getTime() - cache.getTime()) > CACHE_7_DAYS) {
            //if cache older than 7 days, consider all dynamic banners expired and remove the cache
            removeBannerCache();
        }

        if ((now.getTime() - cache.getTime()) > CACHE_12_HOURS) {
            //if cache older than 12 hours, request an update
            getDynamicBanner();
        } else {
            checkBannerImages();
        }
    }


    public void getDynamicBanner() {
        String url = getPreference(PREF_MENDIX_URL) + "/rest/advert/v1/banner";
        Log.d("DynamicBanner", "request to : " + url);
        logger.info("DynamicBanner request to : " + url);

        JsonObjectRequest bannerReq = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("DynamicBanner", response.toString());
                        logger.info("DynamicBanner response " + response.toString());
                        try {
                            JSONObject obj = new JSONObject(response.toString()); //test for valid json object
                            JSONArray arr = obj.getJSONArray("banners"); //test if valid json array
                            cacheBannerData(response.toString());
                        } catch (JSONException je) {
                            je.printStackTrace();
                        }
                        checkBannerImages();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        logger.error("DynamicBanner", error);
                        Log.e("DynamicBanner", error.toString());
                        Log.e("DynamicBanner", "error.getMessage(): " + error.getMessage());
                        Log.e("DynamicBanner", "error.networkResponse.status: " + (error.networkResponse == null ? null : error.networkResponse.statusCode));
                        checkDynamicPrintCache();
                    }
                });
        bannerReq.setTag(this);

        bluDroidVolley.addRequestDynamicBanner(bannerReq);
    }

    private void loadBannerImages() {
        bannerImages.clear();
        try {
            JSONObject cache = new JSONObject(getCachedBannerData());
            JSONArray arr = cache.getJSONArray("banners");

            for (int i = 0; i < arr.length(); i++) {
                String id = arr.getJSONObject(i).getString("id");
                String fileName = id + ".png";

                File imageFile = new File(bannerDir, fileName);
                if (imageFile.exists()) {
                    Bitmap image = BitmapFactory.decodeFile(imageFile.getPath());
                    Log.d("DynamicBanner", "adding " + fileName + " to bannerList");
                    bannerImages.add(image);
                } else {
                    Log.w("DynamicBanner", fileName + " does not exist??");
                }
            }
        } catch (Exception je) {
            je.printStackTrace();
            logger.error("loadBannerImages " + je);
        }
    }

    private void getProfitDisplay() {
        createProgress(R.string.gettingAccounts);
        ProfitDisplayRequestFactory factory = new ProfitDisplayRequestFactory();
        ProfitDisplayRequestMessage profitDisplayRequestMessage =
                factory.create(loginResponseMessage.getData().getUserPin(),
                        getPreference(PREF_DEVICE_ID),
                        getPreference(PREF_DEVICE_SER));
        startAEONAsyncTask(this, socket, profitDisplayRequestMessage);
    }

    private void handleRecovery(String sessionId) {
        if (recoveryIndex < nfcBusRecoveries.size()) {
            NfcBusRecovery rec = nfcBusRecoveries.get(recoveryIndex);
            Log.w("NfcBus", rec.toString());
            createProgress(R.string.confirming_transaction);
            NfcBusRequestFactory factory = new NfcBusRequestFactory();

            CommonRequestMessage req;
            if (rec.getType().equals("checkout")) {
                req = factory.confirmCheckout(sessionId,
                        rec.getTransRef(),
                        rec.getUid(),
                        rec.getStatus(),
                        rec.getTicketId(),
                        rec.getTransactionId(),
                        rec.getAmount(),
                        rec.getPaymentType(),
                        rec.getCompanyId(),
                        rec.getSvcData(),
                        rec.getDeparture(),
                        rec.getDestination());
            } else {
                req = factory.confirmCancelTicket(sessionId,
                        rec.getTransRef(),
                        rec.getUid(),
                        rec.getStatus(),
                        rec.getTicketId(),
                        rec.getTransactionId(),
                        rec.getSvcData(),
                        rec.getDeparture(),
                        rec.getDestination(),
                        rec.getCompanyId());
            }
            startAEONAsyncTask(this, BaseActivity.socket, req);

        } else {
            getFdroidIndex();
        }

    }

    private boolean locationCheck() {
        if (getPreference(PREF_LOCATION_CHECK).equals(PREF_TRUE)) {
            Log.d("LocCheck", "PREF_LOCATION_CHECK: true");

            boolean locEnabled = isLocationEnabled();
            int locMode = getLocationMode();
            boolean locCheckOk;
            int instructionStringId = R.string.locationSettingsInstruction;

            if (Build.MODEL.startsWith("V1")) {
                instructionStringId = R.string.locationSettingsInstructionV1;
                locCheckOk = locEnabled && (locMode == LOCATION_MODE_BATTERY_SAVING);
            } else {
                if (Build.MODEL.startsWith("CITAQ")) {
                    instructionStringId = R.string.locationSettingsInstructionCitaq;
                }
                locCheckOk = locEnabled && (locMode == LOCATION_MODE_HIGH_ACCURACY);
            }

            if (!locCheckOk) {
//                createUpdateAlertDialog("Error - Location Settings", "Please enable Location and select High Accuracy Mode on the following screen, allow any permission requests, then press back to return to BluDroid.");
                createUpdateAlertDialog(getString(R.string.error_location_check), getString(instructionStringId));
                alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent1 = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent1);
                    }
                });
                alert.show();
                return false;
            }
        }
        return true;
    }

    private boolean isLocationEnabled() {
        Log.d("LocCheck", Build.MANUFACTURER + " " + Build.MODEL + " " + Build.SERIAL);
//        if (Build.MODEL.startsWith("CITAQ")) {
//            return true;
//        } else {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        boolean gps_enabled = false, network_enabled = false, passive_enabled = false;

        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            passive_enabled = lm.isProviderEnabled(LocationManager.PASSIVE_PROVIDER);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d("LocCheck", "isLocationEnabled gps:" + gps_enabled + " network:" + network_enabled + " passive:" + passive_enabled);
        return gps_enabled | network_enabled | passive_enabled;
//        }
    }

    private int getLocationMode() {
//        0 = LOCATION_MODE_OFF
//        1 = LOCATION_MODE_SENSORS_ONLY
//        2 = LOCATION_MODE_BATTERY_SAVING
//        3 = LOCATION_MODE_HIGH_ACCURACY
        int locationMode = 0;
        try {
            locationMode = Settings.Secure.getInt(getContentResolver(), Settings.Secure.LOCATION_MODE);
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        Log.d("LocCheck", "getLocationMode: " + locationMode);
        return locationMode;
    }

    private boolean isMendixFeatureSupported(String type, String data) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://getstarted/genericintent?data=" + data + "&type=" + type));
        // Verify the intent will resolve to at least one activity
        if (browserIntent.resolveActivity(getPackageManager()) != null) {
            Log.i("GetStarted", type + " supported!!!");
            return true;
        } else {
            Log.w("GetStarted", type + " not supported!!!");
            return false;
        }
    }


    private void launchGetStartedForFeature(String type, String data) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://getstarted/genericintent?data=" + data + "&type=" + type));
        String title = "Choose app";
        Intent chooser = Intent.createChooser(browserIntent, title);
        // Verify the intent will resolve to at least one activity
        if (browserIntent.resolveActivity(getPackageManager()) != null) {
            Log.d("GetStarted", type + " resolved!!!");
            //Force Mendix not to open in a native webview
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(chooser);
        } else {
            logger.error("GetStarted: " + type + " NOT resolved!!!");
            Toast.makeText(this, type + " not supported", Toast.LENGTH_SHORT).show();
        }
    }

    private void getNotificationMessageCount() {
        String url = getPreference(PREF_MENDIX_URL) + "/rest/notification/v1/notifications/total";
        logger.info("Notifications request to : " + url);

        JsonObjectRequest notificationCountReq = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        logger.info("Notifications response " + response.toString());
                        try {
                            JSONObject obj = new JSONObject(response.toString()); //test for valid json object
                            JSONArray arr = obj.getJSONArray("data"); //test if valid json array
                            for (int i = 0; i < arr.length(); i++) {
                                JSONObject data = arr.getJSONObject(i);
                                if (data.getString("type").equals("Notifications")) {
                                    notificationCount = data.getInt("count");
                                } else if (data.getString("type").equals("Messages")) {
                                    chatCount = data.getInt("count");
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            chatCount = 0;
                            notificationCount = 0;
                        }
                        drawButtons();
                        doAreaCheck();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        logger.error("Notifications", error);
                        Log.e("Notifications", error.toString());
                        Log.e("Notifications", "error.getMessage(): " + error.getMessage());
                        Log.e("Notifications", "error.networkResponse.status: " + (error.networkResponse == null ? null : error.networkResponse.statusCode));
                        chatCount = 0;
                        notificationCount = 0;
                        drawButtons();
                        doAreaCheck();
                    }
                });
        notificationCountReq.setTag(this);

        bluDroidVolley.addRequestNotificationCount(notificationCountReq);
    }

}