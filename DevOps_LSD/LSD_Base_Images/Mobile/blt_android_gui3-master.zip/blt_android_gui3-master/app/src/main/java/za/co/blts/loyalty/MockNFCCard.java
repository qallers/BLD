package za.co.blts.loyalty;

/**
 * Created by MasiS on 8/14/2018.
 */

public class MockNFCCard implements NFCCardInterface {

    //----------------------------------------------------------------------------------------------
    public MockNFCCard() {
    }

    //---------------------------------------------------------------------------------------------

    //----------------------------------------------------------------------------------------------
    @Override
    public void setDelegate(BluDroidNFCCardAsyncResponse delegate) {
    }

    @Override
    public void openReader() {

    }

    @Override
    public void closeReader() {

    }

    @Override
    public void startListener() {

    }

    @Override
    public void stopListener() {

    }

    @Override
    public String getCardNumber() {
        return "";
    }


    //----------------------------------------------------------------------------------------------
}
