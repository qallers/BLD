package za.co.blts.bltandroidgui3.widgets;


import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidTextView extends androidx.appcompat.widget.AppCompatTextView implements BluDroidSetupable {
    @SuppressWarnings("FieldCanBeLocal")
    private final String TAG = this.getClass().getSimpleName();
    
    WeakReference<BaseActivity> baseActivityWeakReference = null;

    public void setTextSize(int size) {
        //Log.d(TAG, "setting textSize to " + size);
        super.setTextSize(size);

    }

    public void setTextColor(int color) {
        super.setTextColor(color);
    }

    public void setup() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                setTextSize(baseScreen.getSkinResources().getTextSize());
                setTextColor(baseScreen.getSkinResources().getBackgroundTextColor());
            }
        }
    }

    BluDroidTextView(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setup();
        //scaleUp();

    }

    //
// sometimes from Dialogs, the context
// is not set properly.  I don't understand
// but this solves the problem
    public void setContext(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    public BluDroidTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        boolean needTextSize = true;
        boolean needTextColor = true;
        for (int i = 0; i < attrs.getAttributeCount(); i++) {
            //Log.d(TAG, attrs.getAttributeName(i) + " = " + attrs.getAttributeValue(i));
            if (attrs.getAttributeName(i).equals("textSize"))
                needTextSize = false;
            if (attrs.getAttributeName(i).equals("textColor"))
                needTextColor = false;
        }

        if (context instanceof BaseActivity) {
            try {
                this.baseActivityWeakReference = new WeakReference<>(((BaseActivity) context));
                if (needTextSize) {
                    setTextSize(((BaseActivity) context).getSkinResources().getTextSize());
                }
                if (needTextColor) {
                    setTextColor(((BaseActivity) context).getSkinResources().getBackgroundTextColor());
                }
            } catch (Exception exception) {
                Log.d(TAG, "BluDroidTextView exception " + exception);
            }
        }
    }
}

