package za.co.blts.bltandroidgui3.menu;

import android.annotation.SuppressLint;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.lang.ref.WeakReference;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class BluMenuRecyclerAdapter extends RecyclerView.Adapter<BluMenuRecyclerAdapter.ViewHolder> {

    private final String TAG = this.getClass().getSimpleName();

    private List<MenuPageButton> data;
    WeakReference<BaseActivity> baseActivityWeakReference;
    private ItemClickListener clickListener;


    public BluMenuRecyclerAdapter(BaseActivity context, List<MenuPageButton> data) {
        this.data = data;
        Log.d(TAG, "context is of type " + context.getClass().getName());
        this.baseActivityWeakReference = new WeakReference<>(context);
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.menu_page_button, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            MenuPageButton current = data.get(position);
            Drawable image = baseActivity.getResources().getDrawable(current.getImg());
            holder.btnImage.setImageDrawable(image);
            Drawable roundDrawable = baseActivity.getResources().getDrawable(R.drawable.button_bg_shadow_rounded);
            roundDrawable.setColorFilter(baseActivity.getSkinResources().getButtonColor(), PorterDuff.Mode.MULTIPLY);
            holder.btnImage.setBackground(roundDrawable);
            holder.txtLabel.setText(current.getLabel());
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void setClickListener(ItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }

    public MenuPageButton getItem(int id) {
        return data.get(id);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnTouchListener {
        TextView txtLabel;
        ImageButton btnImage;

        @SuppressLint("ClickableViewAccessibility")
        ViewHolder(View itemView) {
            super(itemView);
            txtLabel = itemView.findViewById(R.id.txt);
            btnImage = itemView.findViewById(R.id.img);
            btnImage.setOnClickListener(this);
            btnImage.setOnTouchListener(this);
        }

        @Override
        public void onClick(View view) {
            if (clickListener != null) clickListener.onItemClick(getAdapterPosition());
        }

        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View view, MotionEvent event) {
            try {
                BaseActivity baseActivity = baseActivityWeakReference.get();
                if (baseActivity != null) {
                    baseActivity.resetTimer();
                    baseActivity.hideKeyboard();
                }
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        view.getBackground().setAlpha(128);
                        view.invalidate();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_OUTSIDE:
                    case MotionEvent.ACTION_CANCEL:
                        view.getBackground().setAlpha(255);
                        view.invalidate();
                        break;
                }
            } catch (Exception exception) {
                Log.v(TAG, "onTouch exception " + exception);
            }
            return false;
        }
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(int position);
    }


}
