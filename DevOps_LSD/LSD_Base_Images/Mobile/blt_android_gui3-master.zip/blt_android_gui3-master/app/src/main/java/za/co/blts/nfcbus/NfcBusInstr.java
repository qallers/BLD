package za.co.blts.nfcbus;

import java.util.ArrayList;
import java.util.Arrays;

import za.co.blt.interfaces.external.messages.nfcbus.NfcBusSvcSector;
import za.co.blts.nfc.NfcInstr;

public class NfcBusInstr {

    static final String defKey = "FFFFFFFFFFFF";
    static final String defAccess = "ff078000";

    static final String keyA = "f5f4d4db4c13";
    static final String keyB = "9ccd9ba37681";
    static final String access = "ff078000";

    public static NfcInstr uid(boolean isDefault, String uid) {
        NfcInstr instr = new NfcInstr();
        instr.setUid(uid);
        if (isDefault) {
            instr.setKey(new NfcInstr.Key(defKey, false));
        } else {
            instr.setKey(new NfcInstr.Key(keyA, false));
        }
        instr.getBlocks().add(new NfcInstr.Block(0));
        return instr;
    }

    public static NfcInstr check(boolean isDefault) {
        NfcInstr instr = new NfcInstr();
        if (isDefault) {
            instr.setKey(new NfcInstr.Key(defKey, false));
        } else {
            instr.setKey(new NfcInstr.Key(keyA, false));
        }
        instr.setSectors(new ArrayList<>(Arrays.asList(10, 11, 12, 13)));
        return instr;
    }

    public static NfcInstr read(boolean isDefault, String uid) {
        NfcInstr instr = new NfcInstr();
        instr.setUid(uid);
        if (isDefault) {
            instr.setKey(new NfcInstr.Key(defKey, false));
        } else {
            instr.setKey(new NfcInstr.Key(keyA, false));
        }
        for (int i = 40; i < 56; i++) {
            if ((i + 1) % 4 != 0) { //exclude sector trailers
                instr.getBlocks().add(new NfcInstr.Block(i));
            }
        }
        return instr;
    }

    public static NfcInstr write(boolean isDefault, ArrayList<NfcBusSvcSector> svcData, String uid) {
        NfcInstr instr = new NfcInstr();
        instr.setUid(uid);
        if (isDefault) {
            instr.setKey(new NfcInstr.Key(defKey, false));
        } else {
            instr.setKey(new NfcInstr.Key(keyA, false));
        }
        for (NfcBusSvcSector sector : svcData) {
            instr.getBlocks().add(new NfcInstr.Block(sector.getSectorNum() * 4, sector.getBlock0()));
            instr.getBlocks().add(new NfcInstr.Block(sector.getSectorNum() * 4 + 1, sector.getBlock1()));
            instr.getBlocks().add(new NfcInstr.Block(sector.getSectorNum() * 4 + 2, sector.getBlock2()));
        }
        return instr;
    }

    public static NfcInstr clear(boolean isDefault) {
        NfcInstr instr = new NfcInstr();
        if (isDefault) {
            instr.setKey(new NfcInstr.Key(defKey, false));
        } else {
            instr.setKey(new NfcInstr.Key(keyA, false));
        }
        for (int i = 40; i < 56; i++) {
            if ((i + 1) % 4 != 0) {  //exclude sector trailers
                instr.getBlocks().add(new NfcInstr.Block(i, "00000000000000000000000000000000"));
            }
        }
        return instr;
    }

    public static NfcInstr format(boolean isDefault, String uid) {
        NfcInstr instr = new NfcInstr();
        instr.setUid(uid);
        if (isDefault) {
            instr.setKey(new NfcInstr.Key(defKey, false));
            instr.setFormat(new NfcInstr.Format(keyA, keyB, access));
        } else {
            instr.setKey(new NfcInstr.Key(keyA, false));
            instr.setFormat(new NfcInstr.Format(defKey, defKey, defAccess));
        }
        instr.setSectors(new ArrayList<>(Arrays.asList(10, 11, 12, 13)));
        for (int i = 40; i < 56; i++) {
            if ((i + 1) % 4 != 0) { //exclude sector trailers
                instr.getBlocks().add(new NfcInstr.Block(i, "00000000000000000000000000000000"));
            }
        }
        return instr;
    }


}
