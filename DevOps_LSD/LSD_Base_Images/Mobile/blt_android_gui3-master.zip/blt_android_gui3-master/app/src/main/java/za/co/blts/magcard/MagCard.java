package za.co.blts.magcard;

import android.content.Context;
import android.hardware.usb.UsbManager;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import tw.com.prolific.driver.pl2303.PL2303Driver;

/**
 * Created by NkosanaM on 6/22/2017.
 */

public class MagCard implements MagcardInterface {

    private static final String TAG = MagCard.class.getSimpleName();

    private static BluDroidMagCardAsyncReponse delegate = null;

    //----------------------------------------------------------------------------------------------
    public enum CommandType {
        NO_RESPONSE,    //command expects no response
        NORMAL,         //command expects normal response (ESC status eg 1B30 = success)
        HICO_LOCO,      //read status return either hico or loco
        MODEL,          //model request returns a model number
        COMMS,          //comms check returns 1B79 = commsOk
        READ,           //read request returns card data
        WRITE,          //not used - a write command returns a NORMAL response
    }

    private static String track1, track2, track3;
    private static String result;

    private static boolean isMsreReady = false;

    private static String MsrResponse;

    private Context mContext;

    //usb to serial adapter
    private static PL2303Driver mSerial;
    /* DEFAULTS
    private PL2303Driver.BaudRate mBaudrate = PL2303Driver.BaudRate.B9600;
    private PL2303Driver.DataBits mDataBits = PL2303Driver.DataBits.D8;
    private PL2303Driver.Parity mParity = PL2303Driver.Parity.NONE;
    private PL2303Driver.StopBits mStopBits = PL2303Driver.StopBits.S1;
    private PL2303Driver.FlowControl mFlowControl = PL2303Driver.FlowControl.OFF;
    */
    private static final String ACTION_USB_PERMISSION = "za.co.blt.msretest.USB_PERMISSION";

    //command bytes for MSRE mag encoder
    private final byte[] cmdReset = {(byte) 0x1b, (byte) 0x61};
    private final byte[] cmdCheckComms = {(byte) 0x1b, (byte) 0x65};
    private final byte[] cmdCheckModel = {(byte) 0x1b, (byte) 0x74};
    private final byte[] cmdSetHiCo = {(byte) 0x1b, (byte) 0x78};
    private final byte[] cmdSetLoCo = {(byte) 0x1b, (byte) 0x79};
    private final byte[] cmdGetHiLoCoStatus = {(byte) 0x1b, (byte) 0x64};
    private final byte[] cmdClearLeds = {(byte) 0x1b, (byte) 0x81};
    private final byte[] cmdSetLedAll = {(byte) 0x1b, (byte) 0x82};
    private final byte[] cmdSetLedGreen = {(byte) 0x1b, (byte) 0x83};
    private final byte[] cmdSetLedYellow = {(byte) 0x1b, (byte) 0x84};
    private final byte[] cmdSetLedRed = {(byte) 0x1b, (byte) 0x85};
    private final byte[] cmdRead = {(byte) 0x1b, (byte) 0x72};
    @SuppressWarnings("unused")
    private final byte[] cmdReadRaw = {(byte) 0x1b, (byte) 0x6d};

    //----------------------------------------------------------------------------------------------
    public MagCard(Context c) {
        Log.d(TAG, "new Magcard");
        mContext = c;
        // get service
        UsbManager manager = (UsbManager) c.getSystemService(Context.USB_SERVICE);
        mSerial = new PL2303Driver(manager, c, ACTION_USB_PERMISSION);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public String getResult() {
        return result;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTracks(List<String> tracks) {
        if (tracks.size() != 3) return; //3 tracks must always be provided

        track1 = tracks.get(0);
        track2 = tracks.get(1);
        track3 = tracks.get(2);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTrack1(String track1) {
        MagCard.track1 = track1;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTrack2(String track2) {
        MagCard.track2 = track2;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTrack3(String track3) {
        MagCard.track3 = track3;
    }

    //----------------------------------------------------------------------------------------------
    public List<String> getTracks() {
        List<String> list = new ArrayList<>();
        list.add(track1);
        list.add(track2);
        list.add(track3);
        return list;
    }

    //----------------------------------------------------------------------------------------------
    public boolean featureSupported() {
        if (mSerial != null && !mSerial.PL2303USBFeatureSupported()) {
            mSerial = null;
            Log.d(TAG, "featureSupported - No");
            return false;
        }
        Log.d(TAG, "featureSupported - Yes");
        return true;
    }

    //----------------------------------------------------------------------------------------------
    public boolean isOpen() {
        return (mSerial != null);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void closeAdapter() {
        Log.d(TAG, "closeAdapter");
        isMsreReady = false;
        if (mSerial != null) mSerial.end();
        mSerial = null;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setDelegate(BluDroidMagCardAsyncReponse delegate) {
        MagCard.delegate = delegate;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean isConnected() {
        return mSerial != null && mSerial.isConnected();
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean enumerate() {
        return mSerial != null && mSerial.enumerate();
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void openUsbSerial() {
        Log.d(TAG, "Enter  openUsbSerial");

        isMsreReady = false;
        if (null == mSerial)
            return;

        //check adapter is connected
        if (mSerial.isConnected()) {
            Log.d(TAG, "openUsbSerial : isConnected ");
            PL2303Driver.BaudRate mBaudrate = PL2303Driver.BaudRate.B9600;
            Log.d(TAG, "baudRate:" + 9600);
            //only baud rate needs to be configured, keep everything else as default
            if (!mSerial.InitByBaudRate(mBaudrate, 700)) {
                //check usb permission
                if (!mSerial.PL2303Device_IsHasPermission()) {
                    Toast.makeText(mContext, "cannot open, maybe no permission", Toast.LENGTH_SHORT).show();
                }
                //check if adapter is PL2303 type
                if (mSerial.PL2303Device_IsHasPermission() && (!mSerial.PL2303Device_IsSupportChip())) {
                    Toast.makeText(mContext, "cannot open, maybe this chip has no support, please use PL2303HXD / RA / EA chip.", Toast.LENGTH_SHORT).show();
                }
            } else {
                isMsreReady = true;
                Toast.makeText(mContext, "connected : ", Toast.LENGTH_SHORT).show();
            }
        }//isConnected

        Log.d(TAG, "Leave openUsbSerial");
    }//openUsbSerial

    //----------------------------------------------------------------------------------------------
    private static void readDataFromSerial() {

        int len;
        byte[] rbuf = new byte[1024];

//        Log.d(TAG, "Enter readDataFromSerial");

        if ((!isMsreReady) || (mSerial == null) || (!mSerial.isConnected())) {
            isMsreReady = false;
            return;
        }

        len = mSerial.read(rbuf);
        if (len < 0) {
            Log.d(TAG, "Fail to bulkTransfer(read data)");
            isMsreReady = false;
            return;
        }

        if (len > 0) {
            //since we could sample the response midway through the message,
            //we concat the bytes read onto MsrResponse to build the entire
            //message received
            MsrResponse += bytesToHex(rbuf).substring(0, len * 2);
            Log.d(TAG, "PL2303Driver Read 2(" + len + ") : " + MsrResponse);
        } else {
//            Log.d(TAG, "read len : 0 ");
            MsrResponse = "";
            return;
        }

        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

//        Log.d(TAG, "Leave readDataFromSerial");
    }//readDataFromSerial

    //----------------------------------------------------------------------------------------------
    private static void writeDataToSerial(byte[] MsrCommand) {

        Log.d(TAG, "Enter writeDataToSerial");

        if ((!isMsreReady) || (mSerial == null) || (!mSerial.isConnected())) {
            isMsreReady = false;
            return;
        }

        Log.d(TAG, "PL2303Driver Write 2(" + MsrCommand.length + ") : " + bytesToHex(MsrCommand));

        int res = mSerial.write(MsrCommand, MsrCommand.length);

        if (res < 0) {
            Log.d(TAG, "setup2: fail to controlTransfer: " + res);
            isMsreReady = false;
            return;
        }
        Log.d(TAG, "Leave writeDataToSerial");
    }//writeDataToSerial

    //----------------------------------------------------------------------------------------------
    private final static char[] hexArray = "0123456789ABCDEF".toCharArray();

    //----------------------------------------------------------------------------------------------
    //convert byte array to hex string
    private static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    //----------------------------------------------------------------------------------------------
    //convert hex string to byte array
    private static byte[] hexToBytes(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];

        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void resetMsr() {
        Log.d(TAG, "Enter resetMsr");
        writeDataToSerial(cmdReset);
        track1 = track2 = track3 = "";
        result = "Reset";
        // activity.displayResults();
        Log.d(TAG, "Leave resetMsr");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendCheckCommsReq() {
        Log.d(TAG, "Enter sendCheckCommsReq");
        track1 = track2 = track3 = result = "";
        performMsrCmd commsTask = new performMsrCmd();
        commsTask.execute(CommandType.COMMS, bytesToHex(cmdCheckComms), 200);
        Log.d(TAG, "Leave sendCheckCommsReq");
    }

    //----------------------------------------------------------------------------------------------
    private static void getCheckComsResponse() {
        Log.d(TAG, "Enter getCheckComsResponse");


        if (MsrResponse.equals("1B79")) {
            Log.d(TAG, "Comms ok");
            result = "Comms ok";
        } else {
            Log.d(TAG, "Comms error");
            result = "Comms error";
            isMsreReady = false;
        }
        // activity.displayResults();
        Log.d(TAG, "Leave getCheckComsResponse");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendModelReq() {
        Log.d(TAG, "Enter sendModelReq");
        track1 = track2 = track3 = result = "";
        performMsrCmd commsTask = new performMsrCmd();
        commsTask.execute(CommandType.MODEL, bytesToHex(cmdCheckModel), 200);
        Log.d(TAG, "Leave sendModelReq");
    }

    //----------------------------------------------------------------------------------------------
    private static void readModelResponse() {
        Log.d(TAG, "Enter readModelResponse");
        int modelnum = 0;
        if (MsrResponse.length() >= 4) {
            modelnum = Integer.parseInt(MsrResponse.substring(2, 4)) - 30;
            Log.d(TAG, "modelnum = " + modelnum);
        }

        switch (modelnum) {
            case 1:
                Log.d(TAG, "Model 1 - Track 2");
                result = "Model 1 - Track 2";
                break;
            case 2:
                Log.d(TAG, "Model 2 - Tracks 2,3");
                result = "Model 2 - Tracks 2,3";
                break;
            case 3:
                Log.d(TAG, "Model 3 - Tracks 1,2,3");
                result = "Model 3 - Tracks 1,2,3";
                break;
            case 5:
                Log.d(TAG, "Model 5 - Tracks 1,2");
                result = "Model 5 - Tracks 1,2";
                break;
            default:
                Log.d(TAG, "Invalid model number");
                result = "Error reading model number";
                break;
        }
        //activity.displayResults();
        Log.d(TAG, "Leave readModelResponse");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setHiCo() {
        Log.d(TAG, "Enter setHiCo");
        track1 = track2 = track3 = result = "";
        performMsrCmd commsTask = new performMsrCmd();
        commsTask.execute(CommandType.NORMAL, bytesToHex(cmdSetHiCo), 200);
        Log.d(TAG, "Leave setHiCo");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setLoCo() {
        Log.d(TAG, "Enter setLoCo");
        track1 = track2 = track3 = result = "";
        performMsrCmd commsTask = new performMsrCmd();
        commsTask.execute(CommandType.NORMAL, bytesToHex(cmdSetLoCo), 200);
        Log.d(TAG, "Leave setLoCo");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendHiLoCoStatusReq() {
        Log.d(TAG, "Enter sendHiLoCoStatusReq");
        track1 = track2 = track3 = result = "";
        performMsrCmd commsTask = new performMsrCmd();
        commsTask.execute(CommandType.HICO_LOCO, bytesToHex(cmdGetHiLoCoStatus), 200);
        Log.d(TAG, "Enter sendHiLoCoStatusReq");
    }

    //----------------------------------------------------------------------------------------------
    private static void getHiLoCoStatusResponse() {
        Log.d(TAG, "Enter getHiLoCoStatusResponse");

        if (MsrResponse.equals("1B48")) {
            Log.d(TAG, "Get status success - HiCo");
            result = "HiCo";
        } else if (MsrResponse.substring(0, 4).equals("1B4C")) {
            Log.d(TAG, "Get status success - LoCo");
            result = "LoCo";
        } else {
            result = "Error reading HiCo/LoCo status";
        }

        Log.d(TAG, "Leave getHiLoCoStatusResponse");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void eraseCard(boolean trk1, boolean trk2, boolean trk3) {
        Log.d(TAG, "Enter eraseCard");
        track1 = track2 = track3 = "";
        result = "Please swipe card to erase";
        // activity.displayResults();
        // activity.displayResults();
        if (!trk1 && !trk2 && !trk3)
            return;

        //bit is set for each track that must be erased
        byte selectByte = 0;
        if (trk1)
            selectByte += 1;//0b00000001;
        if (trk2)
            selectByte += 2;//0b00000010;
        if (trk3)
            selectByte += 4;//0b00000100;

        byte[] eraseCmd = new byte[]{(byte) 0x1b, (byte) 0x63, selectByte};
        performMsrCmd commsTask = new performMsrCmd();
        commsTask.execute(CommandType.NORMAL, bytesToHex(eraseCmd), 100);

        Log.d(TAG, "Leave eraseCard");
    }

    //----------------------------------------------------------------------------------------------
    public void setLedOff() {
        Log.d(TAG, "Enter setLedOff");
        performMsrCmd commsTask = new performMsrCmd();
        commsTask.execute(CommandType.NO_RESPONSE, bytesToHex(cmdClearLeds), 0);
        Log.d(TAG, "Leave setLedOff");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendLedCommand(boolean green, boolean yellow, boolean red) {
        Log.d(TAG, "Enter sendLedCommand");
        if (green && yellow && red) {
            performMsrCmd commsTask = new performMsrCmd();
            commsTask.execute(CommandType.NO_RESPONSE, bytesToHex(cmdSetLedAll), 0);
        } else {
            if (green) {
                performMsrCmd commsTask = new performMsrCmd();
                commsTask.execute(CommandType.NO_RESPONSE, bytesToHex(cmdSetLedGreen), 0);
            }
            if (yellow) {
                performMsrCmd commsTask = new performMsrCmd();
                commsTask.execute(CommandType.NO_RESPONSE, bytesToHex(cmdSetLedYellow), 0);
            }
            if (red) {
                performMsrCmd commsTask = new performMsrCmd();
                commsTask.execute(CommandType.NO_RESPONSE, bytesToHex(cmdSetLedRed), 0);
            }
        }
        Log.d(TAG, "Leave sendLedCommand");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendReadCommand() {
        Log.d(TAG, "Enter sendReadCommand");
        track1 = track2 = track3 = "";
        // result = "Please swipe card to read";

        performMsrCmd commsTask = new performMsrCmd();
        commsTask.execute(CommandType.READ, bytesToHex(cmdRead), 10000);
        Log.d(TAG, "Leave sendReadCommand");

        //return result;
    }

    //----------------------------------------------------------------------------------------------
    private static void getReadResponse() {
        Log.d(TAG, "Enter getReadResponse");

        int readLen = MsrResponse.length();

        if (readLen < 4) {
            result = "Read failed";
            //activity.displayResults();
            return;
        }

        if (!(MsrResponse.substring(readLen - 4, readLen)).equals("1B30")) {
            Log.d(TAG, "read failed " + MsrResponse.substring(readLen - 4, readLen));
            result = "Read failed";
            //activity.displayResults();
            return;
        } else {
            Log.d(TAG, "read ok " + MsrResponse.substring(readLen - 4, readLen));
        }

        int pos1 = MsrResponse.indexOf("1B01"); //start sentinel for track 1
        int pos2 = MsrResponse.indexOf("1B02"); //start sentinel for track 2
        int pos3 = MsrResponse.indexOf("1B03"); //start sentinel for track 3
        int pos4 = MsrResponse.indexOf("3F1C"); //end sentinel

        Log.d(TAG, "pos1=" + pos1 + " pos2=" + pos2 + " pos3=" + pos3 + " pos4=" + pos4);

        if (pos1 < 0) {
            Log.d(TAG, "start track 1 not found");
            result = "Read error - track1 data not found";
            // activity.displayResults();
            return;
        }
        if (pos2 < 0) {
            Log.d(TAG, "start track 2 not found");
        }
        if (pos3 < 0) {
            Log.d(TAG, "start track 3 not found");
        }
        if (pos4 < 0) {
            Log.d(TAG, "end not found");
            result = "Read error - end not found";
            //activity.displayResults();
            return;
        }

        int trk1start, trk1end, trk2start, trk2end, trk3start, trk3end;

        trk1start = pos1 + 4;
        //find end of track1 data
        if (pos2 > 0) //track2 data present, therefore track1 data ends at start of track2
            trk1end = pos2;
        else if (pos3 > 0) //no track 2, but track3 data present, therefore track1 data ends at start of track3
            trk1end = pos3;
        else    //no track2 or track3, therefore track1 ends at pos4 (end sentinel)
            trk1end = pos4;
        track1 = new String(hexToBytes(MsrResponse.substring(trk1start + 2, trk1end - 2))); //remove % prefix and ? suffix

        if (pos2 > 0) {
            trk2start = pos2 + 4;
            //find end of track2 data
            if (pos3 > 0) //track3 present, therefore track2 data ends at start of track3
                trk2end = pos3;
            else //no track3, therefore track2 ends at pos4
                trk2end = pos4;
            track2 = new String(hexToBytes(MsrResponse.substring(trk2start + 2, trk2end - 2))); //remove ; prefix and ? suffix
        } else //no track2
        {
            track2 = "";
        }

        if (pos3 > 0) {
            //if track 3 present, it must end at pos4 (end sentinel)
            trk3start = pos3 + 4;
            trk3end = pos4;
            track3 = new String(hexToBytes(MsrResponse.substring(trk3start + 2, trk3end - 2))); //remove ; prefix and ? suffix
        }
//        else
//        {
//            track3 = "";
//        }

        Log.d(TAG, "track1 = " + track1);
        Log.d(TAG, "track2 = " + track2);
        Log.d(TAG, "track3 = " + track3);
        result = "Card read success";
        //activity.displayResults();
        Log.d(TAG, "Leave getReadResponse");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendWriteCommand() {
        Log.d(TAG, "Enter sendWriteCommand");
        if (track1 != null) {
            Log.d(TAG, "Track1 = " + track1);
        }
        if (track2 != null) {
            Log.d(TAG, "Track2 = " + track2);
        }
        if (track3 != null) {
            Log.d(TAG, "Track3 = " + track3);
        }

        // result = "Swipe card to write";
        //activity.displayResults();

//        if (track1 ==null && track2 ==null && track3==null) {
//            return;
//        }else{
//            if ((track1.length() == 0) && (track2.length() == 0) && (track3.length() == 0)) {
//                Log.d(TAG, "all tracks have no data");
//                result = "Write error - no track data supplied";
//                //activity.displayResults();
//                // return result;
//                return;
//            }
//        }

        byte[] header = {(byte) 0x1b, (byte) 0x77, (byte) 0x1b, (byte) 0x73}; //write command
        byte[] start1 = {(byte) 0x1b, (byte) 0x01}; //indicates start of track 1 data
        byte[] start2 = {(byte) 0x1b, (byte) 0x02}; //indicates start of track 2 data
        byte[] start3 = {(byte) 0x1b, (byte) 0x03}; //indicates start of track 3 data
        byte[] end = {(byte) 0x3f, (byte) 0x1c};

        //if a track does not need to be written, we can exclude that track along with it's start sentinel from the entire command
        //so only build command for the tracks that must be written
        int cmdLen = header.length + end.length;
        if (track1 != null && track1.length() > 0)
            cmdLen += start1.length + track1.getBytes().length;
        if (track2 != null && track2.length() > 0)
            cmdLen += start2.length + track2.getBytes().length;
        if (track3 != null && track3.length() > 0)
            cmdLen += start3.length + track3.getBytes().length;

        byte[] cmdWrite = new byte[cmdLen];

        int index = 0;
        System.arraycopy(header, 0, cmdWrite, index, header.length);
        index += header.length;
        if (track1 != null && track1.length() > 0) {
            System.arraycopy(start1, 0, cmdWrite, index, start1.length);
            index += start1.length;
            System.arraycopy(track1.getBytes(), 0, cmdWrite, index, track1.getBytes().length);
            index += track1.getBytes().length;
        }
        if (track2 != null && track2.length() > 0) {
            System.arraycopy(start2, 0, cmdWrite, index, start2.length);
            index += start2.length;
            System.arraycopy(track2.getBytes(), 0, cmdWrite, index, track2.getBytes().length);
            index += track2.getBytes().length;
        }
        if (track3 != null && track3.length() > 0) {
            System.arraycopy(start3, 0, cmdWrite, index, start3.length);
            index += start3.length;
            System.arraycopy(track3.getBytes(), 0, cmdWrite, index, track3.getBytes().length);
            index += track3.getBytes().length;
        }
        System.arraycopy(end, 0, cmdWrite, index, end.length);

        performMsrCmd commsTask = new performMsrCmd();
        commsTask.execute(CommandType.NORMAL, bytesToHex(cmdWrite), 10000);
        Log.d(TAG, "Leave sendWriteCommand");

        // return result;
    }

    //----------------------------------------------------------------------------------------------
    //async task responsible for sending the command, and waiting for the relevant response
    private static class performMsrCmd extends AsyncTask<Object, Void, String> {
        CommandType cmdType;
        String sendCommand;
        int timeout;
        int readLen;

        //------------------------------------------------------------------------------------------
        @Override
        protected String doInBackground(Object... params) {
            Log.d(TAG, "Enter doInBackground");
            try {
                cmdType = (CommandType) params[0];
                Log.d(TAG, "cmdType = " + cmdType);
                sendCommand = (String) params[1];
                Log.d(TAG, "sendCommand = " + sendCommand);
                timeout = (int) params[2];
                Log.d(TAG, "timeout = " + timeout);
            } catch (Exception ex) {
                Log.d(TAG, "Exception " + ex);
                return "Exception";
            }
            MsrResponse = "";
            writeDataToSerial(hexToBytes(sendCommand));

            for (int i = 0; i < timeout / 100; i++) {
                readDataFromSerial();
                readLen = MsrResponse.length();
                //it is possible that we sample the response midway through the message
                //so we must ensure we wait for the entire response
                //all response messages end with "ESC status" so ensure that received message is
                //at least 4 bytes (*2 because of hex format), and that 2nd last byte is ESC
                if ((readLen > 3) && (MsrResponse.substring(readLen - 4, readLen - 2).equals("1B"))) {
                    Log.d(TAG, "response received (" + readLen + ") - exiting");
                    break;
                }
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.interrupted();
                }
            }
            Log.d(TAG, "Leave doInBackground");
            return "Executed";
        }

        //------------------------------------------------------------------------------------------
        @Override
        protected void onPostExecute(String temp) {
            Log.d(TAG, "Enter onPostExecute");
            if (MsrResponse.length() > 0) {
                label:
                switch (cmdType) {
                    case NO_RESPONSE:
                        //this is not necessary since a NO_RESPONSE type will never have readLen > 0
                        break;
                    case NORMAL:
                        if (MsrResponse.length() >= 4) {
                            switch (MsrResponse) {
                                case "1B30":
                                    Log.d(TAG, "Successful");
                                    result = "Successful";
                                    break label;
                                case "1B31":
                                    Log.d(TAG, "Read or Write error");
                                    result = "Read or Write error";
                                    break label;
                                case "1B32":
                                    Log.d(TAG, "Command format error");
                                    result = "Command format error";
                                    break label;
                                case "1B34":
                                    Log.d(TAG, "Invalid command error");
                                    result = "Invalid command error";
                                    break label;
                                case "1B39":
                                    Log.d(TAG, "Card moving error");
                                    result = "Card moving error";
                                    break label;
                            }
                        }
                        Log.d(TAG, "Error occurred");
                        result = "Error occurred";
                        break;
                    case HICO_LOCO:
                        getHiLoCoStatusResponse();
                        break;
                    case MODEL:
                        readModelResponse();
                        break;
                    case COMMS:
                        getCheckComsResponse();
                        break;
                    case READ:
                        getReadResponse();
                        break;
                    case WRITE:
                    default:
                        break;
                }
            } else {
                Log.d(TAG, "Timeout - no response from magcard");
                result = "Timeout - no response from magcard";
            }
            delegate.processFinish(result);

            Log.d(TAG, "Leave onPostExecute");
        }

        //------------------------------------------------------------------------------------------
        @Override
        protected void onPreExecute() {
        }

        //------------------------------------------------------------------------------------------
        @Override
        protected void onProgressUpdate(Void... values) {
        }
        //------------------------------------------------------------------------------------------
    }


}
