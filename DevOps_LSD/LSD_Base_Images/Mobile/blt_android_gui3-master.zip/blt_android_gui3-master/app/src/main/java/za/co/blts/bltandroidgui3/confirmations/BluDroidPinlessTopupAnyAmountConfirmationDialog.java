package za.co.blts.bltandroidgui3.confirmations;

import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidCheckBoxButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidMoneyEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;
import za.co.blts.bltandroidgui3.widgets.BluDroidValidatable;

/**
 * Created by NkosanaM on 3/7/2017.
 */

public class BluDroidPinlessTopupAnyAmountConfirmationDialog extends BluDroidConfirmationDialog implements BluDroidValidatable, BluDroidSetupable, View.OnClickListener, TextWatcher, CompoundButton.OnCheckedChangeListener {
    private final String TAG = this.getClass().getSimpleName();

    private String topupName;

    boolean alreadyCalledFlow = false;

    private BluDroidCellphoneEditText cell;
    private BluDroidCellphoneEditText confirmCell;

    private BluDroidCheckBoxButton playAirtimePlus;

    public void setup() {
        super.setup();
        hideView(R.id.neutralButton);
        setAffirmativeButtonLabel(R.string.topUp);
        setNegativeButtonLabel(R.string.cancel);
        setHeading(R.string.confirm_purchase);
        //this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }

    public void setupButton(int resourceId) {
        BluDroidButton button = findViewById(resourceId);
        if (button != null) {
            button.setOnClickListener(this);
        }
    }

    public void showAirtimePlus() {
        BluDroidLinearLayout layout = findViewById(R.id.airtimeplusLayout);
        if (layout != null) {
            layout.setVisibility(View.VISIBLE);
            setAirtimePlusAmount();

            playAirtimePlus = findViewById(R.id.airtimePlusCheckBox);
            playAirtimePlus.setOnCheckedChangeListener(this);

            calculateAmountDue();
        }
    }

    public void hideAirtimePlus() {
        BluDroidLinearLayout layout = findViewById(R.id.airtimeplusLayout);
        if (layout != null) {
            layout.setVisibility(View.INVISIBLE);
        }
    }

    void setAirtimePlusAmount() {
        BluDroidTextView amountTextView = findViewById(R.id.airtimeplus);
        if (amountTextView != null) {
            try {
                String disp = amountTextView.getText().toString() + "(R" + baseActivity.df2.format(Double.parseDouble(baseActivity.airtimePlusValue)) + ")";
                amountTextView.setText(disp);

            } catch (Exception ex) {
                Log.d(TAG, "setAirtimePlusAmount: " + ex.getMessage());
            }
        }
    }


    public void setTopupName(String topupName) {
        Log.d(TAG, "setTopupName " + topupName);
        this.topupName = topupName;
        setupSpinner();
    }

    public String getTopupName() {
        return topupName;
    }

    public BluDroidPinlessTopupAnyAmountConfirmationDialog(BaseFragment context) {
        super(context, R.layout.confirmation_pinless_topup_anyamount);

        Log.d(TAG, "BluDroidPinlessTopupAnyAmountConfirmationDialog BaseFragment " + topupName);

        cell = findViewById(R.id.cellNumber);
        confirmCell = findViewById(R.id.confirmCellNumber);

        BluDroidMoneyEditText amount = findViewById(R.id.amount);
        amount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (playAirtimePlus != null)
                    if (playAirtimePlus.isChecked()) {
                        calculateAmountDueWithAirtimePlus();
                    } else {
                        calculateAmountDue();
                    }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        cell.addTextChangedListener(this);

        setup();
        Log.d(TAG, "Purchase confirmation with fragment");
        BaseActivity.logger.info(": construction with BaseFragment");
    }

    private void setupSpinner() {
        final Spinner cellNumberSpinner = findViewById(R.id.cellNumberSpinner);
        final BluDroidLinearLayout numberLayout = findViewById(R.id.numberLayout);
        final BluDroidCellphoneEditText cellNumber = findViewById(R.id.cellNumber);
        final BluDroidCellphoneEditText confirmCellNumber = findViewById(R.id.confirmCellNumber);

        final List<String> cellNumbers = new ArrayList<>();
        boolean hasCellNumbers;

        if (this instanceof BluDroidPinlessBundleConfirmationDialog) {
            hasCellNumbers = checkCustomerProfileBundlesAccountNumbers(cellNumbers, ((BluDroidPinlessBundleConfirmationDialog) this).getStockId());
        } else {
            hasCellNumbers = checkCustomerProfileAccountNumbers(cellNumbers);
        }

        if (hasCellNumbers) {
            Log.d(TAG, "has cell numbers");
            cellNumbers.add(0, "Other");
            cellNumberSpinner.setVisibility(View.VISIBLE);
            numberLayout.setVisibility(View.GONE);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(baseActivity, android.R.layout.simple_spinner_item, cellNumbers);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            cellNumberSpinner.setAdapter(dataAdapter);
            //although meterNumber is hidden, update this with the selected spinner value, so the dialog.validate() will pass
            cellNumber.setText(cellNumbers.get(1));
            confirmCellNumber.setText(cellNumbers.get(1));
            cellNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i == 0) {
                        onNothingSelected(null);
                    } else {
                        cellNumber.setText(cellNumbers.get(i));
                        confirmCellNumber.setText(cellNumbers.get(i));
                        numberLayout.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    cellNumber.setText("");
                    confirmCellNumber.setText("");
                    numberLayout.setVisibility(View.VISIBLE);
                }
            });
            cellNumberSpinner.setSelection(1);

        } else {
            Log.d(TAG, "no cell numbers");
            cellNumberSpinner.setVisibility(View.GONE);
            numberLayout.setVisibility(View.VISIBLE);
        }

    }

    private boolean checkCustomerProfileAccountNumbers(List<String> accountNumbers) {
        if (BaseActivity.consumerProfile != null && baseActivity.customerProfileTopupAccountNumbers != null) {
            String[] accounts = baseActivity.customerProfileTopupAccountNumbers.get(topupName.toLowerCase());
            if (accounts != null && accounts.length > 0) {
                accountNumbers.addAll(Arrays.asList(accounts));
                return true;
            }
        }
        return false;
    }

    private boolean checkCustomerProfileBundlesAccountNumbers(List<String> accountNumbers, String stockId) {
        String key = stockId + topupName.toLowerCase() + "bundles";
        Log.d(TAG, "search for key " + key);
        if (BaseActivity.consumerProfile != null && baseActivity.customerProfileBundlesAccountNumbers != null) {
            String[] accounts = baseActivity.customerProfileBundlesAccountNumbers.get(key);
            if (accounts != null && accounts.length > 0) {
                accountNumbers.addAll(Arrays.asList(accounts));
                return true;
            }
        }
        return false;
    }

    public void setAmount(String amount) {
        BluDroidMoneyEditText amountEditText = findViewById(R.id.amount);
        if (amountEditText != null) {
            amountEditText.setText(amount);
        }
    }

    public void setAmountErrorMessage(String errorMessage) {
        BluDroidMoneyEditText amountEditText = findViewById(R.id.amount);
        if (amountEditText != null) {
            amountEditText.setErrorMessage(errorMessage);
        }
    }

    public String getAmount() {
        BluDroidMoneyEditText amountEditText = findViewById(R.id.amount);
        if (amountEditText != null) {
            return amountEditText.getText().toString();
        } else {
            return "0.00";
        }
    }

    public String getCellNumber() {
        BluDroidEditText cellNumber = findViewById(R.id.cellNumber);
        if (cellNumber != null) {
            return cellNumber.getText().toString().replace(" ", "");
        } else {
            return "";
        }
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public ImageView getIcon() {
        return findViewById(R.id.icon);
    }

    public boolean validate() {
        if (super.validate()) {
            //
            // two cell numbers must be the dame
            //
            BluDroidCellphoneEditText cellphoneEditText = findViewById(R.id.cellNumber);
            String cellNumber = cellphoneEditText.getText().toString();
            String cellNumberConfirm = ((BluDroidCellphoneEditText) findViewById(R.id.confirmCellNumber)).getText().toString();
            if (cellNumber.equals(cellNumberConfirm)) {
                return true;
            } else {
                cellphoneEditText.setErrorMessage(baseActivity.getResources().getString(R.string.cellNumbersDontMatch));
                return false;
            }
        } else
            return false;
    }

    public void onClick(View view) {
        BaseActivity.logger.info(((BluDroidButton) view).getText());
        try {
            BaseActivity.logger.info(": onClick()");
            Log.d(TAG, "onClick");
            if (view.getId() == R.id.negativeButton) {
                Log.d(TAG, "negative Button");
                super.onClick(view);
            } else if (view.getId() == R.id.affirmativeButton) {
                Log.d(TAG, "affirmative Button");
                super.onClick(view);
            }

        } catch (Exception exception) {
            Log.d(TAG, "onClick " + exception);
        }

    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

        //Log.d(TAG, "onTextChanged [" + getText().toString().trim() + "]");


        if (baseActivity != null)
            baseActivity.resetTimer();
        if (alreadyCalledFlow)
            baseActivity.cancelTimer();
        //Log.d(TAG, "maxLength is " + maxLength);
        //Log.d(TAG, "baseScreen flowable? " + (baseScreen instanceof BluDroidFlowable) );
        int ccnt = cell.getText().toString().trim().length();
        if (ccnt > 0) {
            cell.removeErrorMessage();
        }
        if ((cell.maxLength != -1)) {
            int cnt = cell.getText().toString().trim().length();
            Log.d(TAG, "cell count is " + cnt);

            Log.d(TAG, "text changed");

            if (cnt == cell.maxLength) {
                Log.d(TAG, "calling topup flow");

                confirmCell.requestFocus();
            }
        }

    }

    @Override
    public void afterTextChanged(Editable s) {
        int cnt = cell.getText().length();
        if (cnt == cell.maxLength) {
            Log.d(TAG, "validating cell");

            cell.validate();
        }
    }

    void calculateAmountDueWithAirtimePlus() {

        try {

            BluDroidTextView totalText = findViewById(R.id.Total);

            double total;
            if (getAmount().isEmpty()) {
                total = 0.00;
            } else {
                total = Double.parseDouble(baseActivity.airtimePlusValue) + Double.parseDouble(getAmount().replace("R", ""));
            }
            String disp = "R" + baseActivity.df2.format(total);
            totalText.setText(disp);
        } catch (Exception ex) {
            Log.d(TAG, "calculateAmountDueWithAirtimePlus: " + ex.getMessage());
        }
    }

    void calculateAmountDue() {
        try {
            BluDroidTextView totalText = findViewById(R.id.Total);

            double total;
            if (getAmount().isEmpty()) {
                total = 0.00;
            } else {
                total = Double.parseDouble(getAmount().replace("R", ""));
            }
            String disp = "R" + baseActivity.df2.format(total);
            totalText.setText(disp);
        } catch (Exception ex) {
            Log.d(TAG, "calculateAmountDue: " + ex.getMessage());
        }

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            calculateAmountDueWithAirtimePlus();
            baseActivity.airtimePlusPlayed = "1";
        } else {
            calculateAmountDue();
            baseActivity.airtimePlusPlayed = "0";
        }
    }
}
