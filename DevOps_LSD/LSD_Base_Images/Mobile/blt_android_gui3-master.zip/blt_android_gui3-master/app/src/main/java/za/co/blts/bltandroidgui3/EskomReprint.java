package za.co.blts.bltandroidgui3;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponseMeterMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponseTokenMessage;

/**
 * Created by NkosanaM on 4/21/2017.
 */

class EskomReprint extends Reprint {

    private ArrayList<CommonResponseLineMessage> printLines;
    private String printMagCard;
    private ElectricityVoucherResponseMeterMessage meter;
    private ArrayList<ElectricityVoucherResponseTokenMessage> tokens;

    public EskomReprint(String vouchertType, String date, String amount, ArrayList<CommonResponseLineMessage> printLines, String printMagCard, ElectricityVoucherResponseMeterMessage meter, ArrayList<ElectricityVoucherResponseTokenMessage> tokens) {
        super(vouchertType, date, amount);
        this.printLines = printLines;
        this.printMagCard = printMagCard;
        this.meter = meter;
        this.tokens = tokens;
    }

    public ArrayList<CommonResponseLineMessage> getPrintLines() {
        return printLines;
    }

    public void setPrintLines(ArrayList<CommonResponseLineMessage> printLines) {
        this.printLines = printLines;
    }

    public String getPrintMagCard() {
        return printMagCard;
    }

    public void setPrintMagCard(String printMagCard) {
        this.printMagCard = printMagCard;
    }

    public ElectricityVoucherResponseMeterMessage getMeter() {
        return meter;
    }

    public void setMeter(ElectricityVoucherResponseMeterMessage meter) {
        this.meter = meter;
    }

    public ArrayList<ElectricityVoucherResponseTokenMessage> getTokens() {
        return tokens;
    }

    public void setTokens(ArrayList<ElectricityVoucherResponseTokenMessage> tokens) {
        this.tokens = tokens;
    }
}
