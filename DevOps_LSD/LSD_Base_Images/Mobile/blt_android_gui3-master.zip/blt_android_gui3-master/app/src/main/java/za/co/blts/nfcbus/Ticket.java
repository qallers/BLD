package za.co.blts.nfcbus;

import java.util.ArrayList;
import java.util.List;

import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusRouteMessage;

public class Ticket {
    private long companyId;
    private String company;
    private long ticketId;
    private String ticketNo;
    private String ticketType;
    private String fare;
    private long fareProductId;
    private long departureId;
    private String departure;
    private long destinationId;
    private String destination;
    private String startDate;
    private String endDate;
    private String status;
    private List<NfcBusRouteMessage> routes;
    private String rules;
    private boolean cancelable;

    public Ticket() {
        routes = new ArrayList<>();
    }

    public Ticket(long companyId, String company, long ticketId, String ticketNo, String ticketType,
                  String fare, long fareProductId, long departureId, String departure, long destinationId,
                  String destination, String startDate, String endDate, String status,
                  ArrayList<NfcBusRouteMessage> routes, String rules, boolean cancelable) {
        this.companyId = companyId;
        this.company = company;
        this.ticketId = ticketId;
        this.ticketNo = ticketNo;
        this.ticketType = ticketType;
        this.fare = fare;
        this.fareProductId = fareProductId;
        this.departureId = departureId;
        this.departure = departure;
        this.destinationId = destinationId;
        this.destination = destination;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.routes = new ArrayList<>();
        this.routes.addAll(routes);
        this.rules = rules;
        this.cancelable = cancelable;
    }

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public long getTicketId() {
        return ticketId;
    }

    public void setTicketId(long ticketId) {
        this.ticketId = ticketId;
    }

    public String getTicketNo() {
        return ticketNo;
    }

    public void setTicketNo(String ticketNo) {
        this.ticketNo = ticketNo;
    }

    public String getTicketType() {
        return ticketType;
    }

    public void setTicketType(String ticketType) {
        this.ticketType = ticketType;
    }

    public String getFare() {
        return fare;
    }

    public void setFare(String fare) {
        this.fare = fare;
    }

    public long getFareProductId() {
        return fareProductId;
    }

    public void setFareProductId(long fareProductId) {
        this.fareProductId = fareProductId;
    }

    public long getDepartureId() {
        return departureId;
    }

    public void setDepartureId(long departureId) {
        this.departureId = departureId;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public long getDestinationId() {
        return destinationId;
    }

    public void setDestinationId(long destinationId) {
        this.destinationId = destinationId;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<NfcBusRouteMessage> getRoutes() {
        return routes;
    }

    public void setRoutes(List<NfcBusRouteMessage> routes) {
        this.routes = routes;
    }

    public String getRules() {
        return rules;
    }

    public void setRules(String rules) {
        this.rules = rules;
    }

    public boolean isCancelable() {
        return cancelable;
    }

    public void setCancelable(boolean cancelable) {
        this.cancelable = cancelable;
    }

    //    public class Route {
//        private String departUp;
//        private String destUp;
//        private String departDown;
//        private String destDown;
//
//        public Route(String departUp, String destUp, String departDown, String destDown) {
//            this.departUp = departUp;
//            this.destUp = destUp;
//            this.departDown = departDown;
//            this.destDown = destDown;
//        }
//
//        public String getDepartUp() {
//            return departUp;
//        }
//
//        public void setDepartUp(String departUp) {
//            this.departUp = departUp;
//        }
//
//        public String getDestUp() {
//            return destUp;
//        }
//
//        public void setDestUp(String destUp) {
//            this.destUp = destUp;
//        }
//
//        public String getDepartDown() {
//            return departDown;
//        }
//
//        public void setDepartDown(String departDown) {
//            this.departDown = departDown;
//        }
//
//        public String getDestDown() {
//            return destDown;
//        }
//
//        public void setDestDown(String destDown) {
//            this.destDown = destDown;
//        }
//    }
}
