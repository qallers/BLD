package za.co.blts.nfcbus;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import za.co.blt.interfaces.external.factories.NfcBusRequestFactory;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusLookupDestinationsRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListStopsResponseLocationMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupDestinationsResponseLocationMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupDestinationsResponseMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.NeedsAEONResults;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;


public class FragmentNewTicket extends BaseFragment implements NeedsAEONResults {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidSpinner spinCarrier, spinDepart, spinDest;
    private final List<Stop> departList = new ArrayList<>();
    private final List<Stop> destList = new ArrayList<>();

    private StopAdapter departAdapter, destAdapter;
    private BluDroidButton btnNext;

    public FragmentNewTicket() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "New ticket");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_new_ticket, container, false);

        spinCarrier = rootView.findViewById(R.id.spinCarrier);
        spinDepart = rootView.findViewById(R.id.spinDepart);
        spinDest = rootView.findViewById(R.id.spinDest);

        BluDroidButton btnCancel = rootView.findViewById(R.id.btnCancel);
        btnNext = rootView.findViewById(R.id.btnNext);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getBaseActivity().firebaseBundle = new Bundle();
                getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, TAG + " " + ((ActivityNfcBus) getActivity()).getCardUid());
                getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_purchase_cancel", getBaseActivity().firebaseBundle);

                ((ActivityNfcBus) getActivity()).setDepart(null);
                ((ActivityNfcBus) getActivity()).setDest(null);
                ((ActivityNfcBus) getActivity()).gotoTicketList();
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityNfcBus) getActivity()).gotoListFares();
            }
        });

        setupSpinners();
        enableDisableNextButton();

        return rootView;
    }

    private void enableDisableNextButton() {
        if (((ActivityNfcBus) getActivity()).getDest() == null) {
            btnNext.setEnabled(false);
            btnNext.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        } else {
            btnNext.setEnabled(true);
            btnNext.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());

            Log.v(TAG, "carrier: " + ((ActivityNfcBus) getActivity()).getCarrier());
            Log.v(TAG, "depart: " + ((ActivityNfcBus) getActivity()).getDepart());
            Log.v(TAG, "dest: " + ((ActivityNfcBus) getActivity()).getDest());

            Log.v(TAG, "map depart: " + ((ActivityNfcBus) getActivity()).stopsMap.get(((ActivityNfcBus) getActivity()).getCarrier().getCompanyId()).get(((ActivityNfcBus) getActivity()).getDepart().getId()));
            Log.v(TAG, "map dest: " + ((ActivityNfcBus) getActivity()).stopsMap.get(((ActivityNfcBus) getActivity()).getCarrier().getCompanyId()).get(((ActivityNfcBus) getActivity()).getDest().getId()));


        }
    }

    private void resetDepartSpinner() {
        ((ActivityNfcBus) getActivity()).setDepart(null);
        departList.clear();
        departList.add(null);
        departAdapter.notifyDataSetChanged();
        spinDepart.setSelection(0, false);
        enableDisableNextButton();
    }

    private void resetDestSpinner() {
        ((ActivityNfcBus) getActivity()).setDest(null);
        destList.clear();
        destList.add(null);
        destAdapter.notifyDataSetChanged();
        spinDest.setSelection(0, false);
        enableDisableNextButton();
    }

    private void setupSpinners() {
        final CarrierAdapter carrierAdapter = new CarrierAdapter(getContext(), android.R.layout.simple_list_item_1,
                ((ActivityNfcBus) getActivity()).getNfcBusListCarriersResponseMessage().getDetail().getCompanies());
        spinCarrier.setAdapter(carrierAdapter);
        spinCarrier.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((ActivityNfcBus) getActivity()).setCarrier(((ActivityNfcBus) getActivity()).getNfcBusListCarriersResponseMessage().getDetail().getCompanies().get(position));
                Log.d(TAG, "Carrier selected : " + ((ActivityNfcBus) getActivity()).getCarrier().getName());

                if (((ActivityNfcBus) getActivity()).getCarrier() != null) {
                    getBaseActivity().firebaseBundle = new Bundle();
                    getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, ((ActivityNfcBus) getActivity()).getCarrier().getName());
                    getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_carrier_select", getBaseActivity().firebaseBundle);
                }

                resetDepartSpinner();
                resetDestSpinner();
                getStops();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        departAdapter = new StopAdapter(getContext(), android.R.layout.simple_list_item_1, departList);
        spinDepart.setAdapter(departAdapter);
        spinDepart.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((ActivityNfcBus) getActivity()).setDepart(departList.get(position));
                Log.d(TAG, "Depart selected : " + (((ActivityNfcBus) getActivity()).getDepart() == null ? "null" : ((ActivityNfcBus) getActivity()).getDepart().getName()));

                if (((ActivityNfcBus) getActivity()).getDepart() != null) {
                    getBaseActivity().firebaseBundle = new Bundle();
                    getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, ((ActivityNfcBus) getActivity()).getDepart().getName());
                    getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_depart_select", getBaseActivity().firebaseBundle);
                }

                resetDestSpinner();
                if (((ActivityNfcBus) getActivity()).getDepart() != null) {
                    ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentNewTicket.this);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        destAdapter = new StopAdapter(getContext(), android.R.layout.simple_list_item_1, destList);
        spinDest.setAdapter(destAdapter);
        spinDest.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((ActivityNfcBus) getActivity()).setDest(destList.get(position));
                Log.d(TAG, "Dest selected : " + (((ActivityNfcBus) getActivity()).getDest() == null ? "null" : ((ActivityNfcBus) getActivity()).getDest().getName()));

                if (((ActivityNfcBus) getActivity()).getDest() != null) {
                    getBaseActivity().firebaseBundle = new Bundle();
                    getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, ((ActivityNfcBus) getActivity()).getDest().getName());
                    getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_dest_select", getBaseActivity().firebaseBundle);
                }
                enableDisableNextButton();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void getStops() {
        departList.clear();
        HashMap<Long, NfcBusListStopsResponseLocationMessage> map = ((ActivityNfcBus) getActivity()).stopsMap.get(((ActivityNfcBus) getActivity()).getCarrier().getCompanyId());
        if (map != null) {
            for (Map.Entry<Long, NfcBusListStopsResponseLocationMessage> entry : map.entrySet()) {
                departList.add(new Stop(entry.getValue().getId(), entry.getValue().getName()));
            }
        }
        Collections.sort(departList);
        departList.add(0, null);

        departAdapter.notifyDataSetChanged();
    }

    private void getDestinations(String sessionId) {
        getBaseActivity().createProgress(getResources().getString(R.string.getting_destinations));
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusLookupDestinationsRequestMessage req = factory.lookupDestinations(sessionId, ((ActivityNfcBus) getActivity()).getCarrier().getCompanyId(), ((ActivityNfcBus) getActivity()).getDepart().getId());
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    @Override
    public void results(Object object) {
        if (object instanceof NfcBusAuthenticationResponseMessage) {
            if (((NfcBusAuthenticationResponseMessage) object).getEvent().getEventCode().equals("0")) {
                getDestinations(((NfcBusAuthenticationResponseMessage) object).getSessionId());
            } else {
                getBaseActivity().createSystemErrorConfirmation(object, true);
            }
        } else if (object instanceof NfcBusLookupDestinationsResponseMessage) {
            getBaseActivity().closeAeonSocket(36);
            if (((NfcBusLookupDestinationsResponseMessage) object).getEvent().getEventCode().equals("0")) {
                getBaseActivity().dismissProgress();
                destList.clear();
                for (NfcBusLookupDestinationsResponseLocationMessage dest : ((NfcBusLookupDestinationsResponseMessage) object).getDetail().getLocations()) {
                    destList.add(new Stop(dest.getId(), dest.getName()));
                }
                Collections.sort(destList);
                destList.add(0, null);
                destAdapter.notifyDataSetChanged();
            } else {
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }
        }

        if (object != null && !(object instanceof Socket)) {
            getBaseActivity().firebaseBundle = new Bundle();
            getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            getBaseActivity().mFirebaseAnalytics.logEvent("aeon_connection", getBaseActivity().firebaseBundle);
        }
    }

}