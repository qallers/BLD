package za.co.blts.nfc;

import java.util.ArrayList;
import java.util.List;

public class NfcInstr {
    private String uid;
    private Key key;
    private List<Integer> sectors;
    private List<Block> blocks;
    private Format format;

    public NfcInstr() {
        uid = "";
        sectors = new ArrayList<>();
        blocks = new ArrayList<>();
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public Key getKey() {
        return key;
    }

    public void setKey(Key key) {
        this.key = key;
    }

    public List<Integer> getSectors() {
        return sectors;
    }

    public void setSectors(List<Integer> sectors) {
        this.sectors = sectors;
    }

    public List<Block> getBlocks() {
        return blocks;
    }

    public void setBlocks(List<Block> blocks) {
        this.blocks = blocks;
    }

    public Format getFormat() {
        return format;
    }

    public void setFormat(Format format) {
        this.format = format;
    }

    public static class Key {
        private String val;
        private boolean useB;

        public Key() {
        }

        public Key(String val, boolean useB) {
            this.val = val;
            this.useB = useB;
        }

        public String getVal() {
            return val;
        }

        public void setVal(String val) {
            this.val = val;
        }

        public boolean isUseB() {
            return useB;
        }

        public void setUseB(boolean useB) {
            this.useB = useB;
        }
    }


    public static class Format {
        private String keyA;
        private String keyB;
        private String access;

        public Format() {
        }

        public Format(String keyA, String keyB, String access) {
            this.keyA = keyA;
            this.keyB = keyB;
            this.access = access;
        }

        public String getKeyA() {
            return keyA;
        }

        public void setKeyA(String keyA) {
            this.keyA = keyA;
        }

        public String getKeyB() {
            return keyB;
        }

        public void setKeyB(String keyB) {
            this.keyB = keyB;
        }

        public String getAccess() {
            return access;
        }

        public void setAccess(String access) {
            this.access = access;
        }
    }

    public static class Block {
        private int num;
        private String val;

        public Block() {
        }

        public Block(int num) {
            this.num = num;
        }

        public Block(int num, String val) {
            this.num = num;
            this.val = val;
        }

        public int getNum() {
            return num;
        }

        public void setNum(int num) {
            this.num = num;
        }

        public String getVal() {
            return val;
        }

        public void setVal(String val) {
            this.val = val;
        }
    }

}


