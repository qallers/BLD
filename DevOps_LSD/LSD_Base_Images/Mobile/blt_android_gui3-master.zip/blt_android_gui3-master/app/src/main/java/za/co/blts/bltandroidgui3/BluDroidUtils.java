package za.co.blts.bltandroidgui3;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


/*
 * common utilities which are needed often
 */
@SuppressWarnings("unused")
public class BluDroidUtils {

    private final String TAG = this.getClass().getSimpleName();

    public BluDroidUtils() {
    }

    public String formatMoney(String input) {
        try {
            BigDecimal temp = new BigDecimal(input);
            String returnValue = temp.toString();
            int pos = returnValue.indexOf(".");
            if (pos == -1) {
                returnValue = returnValue.concat(".00");
            } else if (pos == temp.toString().length() - 2) {
                returnValue = returnValue.concat("0");
            }
            return returnValue;
        } catch (Exception exception) {
            Log.v(TAG, "problems formatting money " + exception);
        }
        return "";
    }

    public String formatMoney(double input) {
        try {
            return String.format(Locale.US, "%.2f", input);
        } catch (Exception exception) {
            Log.v(TAG, "problems formatting money " + exception);
        }
        return "";
    }

    //
// generate todays date and time
//
    public String todaysDateAndTime(String format) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.US);
            Calendar calendar = Calendar.getInstance();
            StringBuffer sb = new StringBuffer();
            sdf.format(calendar.getTime(), sb, new FieldPosition(0));
            return sb.toString();
        } catch (Exception exception) {
            Log.v(TAG, "problems formatting todays date " + exception);
        }
        return "";
    }

    // BluDroidUtils
    public String tenMinutesLaterDateAndTime() {
        try {
            String format = "dd-MM-yyyy HH-mm-ss"; // include minutes
            SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.US);
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.MINUTE, 10); // implementation
            StringBuffer sb = new StringBuffer();
            sdf.format(calendar.getTime(), sb, new FieldPosition(0));
            return sb.toString();
        } catch (Exception exception) {
            Log.v(TAG, "problems formatting todays date " + exception);
        }
        return "";
    }

    public boolean compareNowAndTicketReprintExpiration(String ticketReprintExpiration) {
        // remove seconds from both dates if any
        // include times and second since we are
        boolean isExpired = false;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH-mm-ss", Locale.US);
        try {
            Date now = simpleDateFormat.parse(todaysDateAndTime("dd-MM-yyyy HH-mm-ss")); // now
            Date ticketReprintExpirationDate = simpleDateFormat.parse(ticketReprintExpiration);
            return now.after(ticketReprintExpirationDate);
        } catch (ParseException e) {
            e.printStackTrace();
            BaseActivity.logger.error("compareNowAndTicketReprintExpiration exception" + e);
        }

        return isExpired;
    }


//
// format string
//    left justify left
//    right justify right
// but use printWidth

    public String format(int printWidth, String left, String right) {
        try {
            Log.d(TAG, "printWidth is " + printWidth);
            int leftLength = left.length();
            Log.d(TAG, "left [" + left + "] " + left.length());
            Log.d(TAG, "right [" + right + "] " + right.length());
            int half = printWidth / 2;
            String format;
            if (left.length() < half && right.length() < half) {
                format = "%-" + half + "." + half + "s%" + half + "." + half + "s";
            } else {
                format = "%-" + (leftLength) + "." + (leftLength) + "s%" + (printWidth - leftLength) + "." + (printWidth - leftLength) + "s";
            }
            Log.v(TAG, "format is " + format);
            String result = String.format(format, left, right);
            Log.d(TAG, "result is [" + result + "]");
            return result;
        } catch (Exception exception) {
            Log.v(TAG, "problem format " + exception);
        }
        return "";
    }

    public String format(int printWidth, int firstColumn, String left, String right) {
        int secondColumn = 0;
        try {
            if (printWidth == 42) {
                secondColumn = 42 - firstColumn;
            } else {
                if (firstColumn == 30) {
                    firstColumn = 25;
                }
                secondColumn = 32 - firstColumn;
            }
            String formatString = "%-" + firstColumn + "." + firstColumn + "s%" + secondColumn + "." + secondColumn + "s";
            return String.format(formatString, left, right);
        } catch (Exception exception) {
            Log.v(TAG, "printWidth " + printWidth + " firstColumn " + firstColumn + " secondColumn " + secondColumn);
            Log.v(TAG, "problems with format " + exception);
        }
        return "";
    }

    //
// center string in printWidth
//
    public String center(int printWidth, String st) {
        if (st == null) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < printWidth; i++) {
                sb.append(" ");
            }
            return sb.toString();
        } else {
            int len = st.trim().length();
            int half = (printWidth - len) / 2;
            if (half == 0) {
                return st;
            } else {
                String format = "%" + half + "s%s";
                return String.format(format, "", st.trim());
            }
        }
    }

    public String right(int printWidth, String st) {
        if (st == null) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < printWidth; i++) {
                sb.append(" ");
            }
            return sb.toString();
        } else {
            int len = st.trim().length();
            int spaces = printWidth - len;
            if (spaces <= 0) {
                return st;
            } else {
                String format = "%" + spaces + "s%s";
                return String.format(format, "", st.trim());
            }
        }
    }

    //
// generate a bar code and convert it into a Bitmap
//
    public Bitmap generateBarcode(String barcodeType, String barcodeContents, int width, int height) {
        try {
            Log.d(TAG, "received barcodeType " + barcodeType);
            Log.d(TAG, "received barcodeContents " + barcodeContents);
            MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
            BarcodeFormat barcodeFormat = null;
            if (barcodeType.startsWith("code128")) {
                barcodeFormat = BarcodeFormat.CODE_128;
            } else if (barcodeType.startsWith("pdf417")) {
                barcodeFormat = BarcodeFormat.PDF_417;
            } else if (barcodeType.equals("ean13")) {
                barcodeFormat = BarcodeFormat.EAN_13;
            } else if (barcodeType.equals("code39")) {
                barcodeFormat = BarcodeFormat.CODE_39;
            } else if (barcodeType.equals("itf")) {
                barcodeFormat = BarcodeFormat.ITF;
            }
            Log.d(TAG, "barcodeFormat " + barcodeFormat);

            try {
                if (width > BaseActivity.smartPrinter.getBitmapMaxWidth()) {
                    width = BaseActivity.smartPrinter.getBitmapMaxWidth();
                }
            } catch (Exception exception) {
                Log.d(TAG, "problems getting printer width " + exception);
            }

            Log.d(TAG, "width " + width);
            Log.d(TAG, "height " + height);
            BitMatrix bitMatrix = multiFormatWriter.encode(barcodeContents,
                    barcodeFormat,
                    width,
                    height,
                    null);

            Bitmap bitmap = Bitmap.createBitmap(bitMatrix.getWidth(), bitMatrix.getHeight(), Bitmap.Config.ARGB_8888);

            try {
                bitmap = BaseActivity.smartPrinter.convertBitMatrixToBitMap(bitMatrix);
            } catch (Exception exception) {
                Log.d(TAG, "problem converting bit matrix " + exception);
            }

            if (barcodeFormat == BarcodeFormat.PDF_417) {
                bitmap = Bitmap.createScaledBitmap(bitmap, width, height, false);
            }

            Log.d(TAG, "returning bitmap is " + bitmap);
            Log.d(TAG, "bitmap height " + bitmap.getHeight());
            return bitmap;
        } catch (Exception exception) {
            Log.v(TAG, "problems generating barcode " + barcodeType + ":" + barcodeContents + " - " + exception);
        }
        return null;
    }


    //
// this code was supplied by Anthony Shumba of Tactile Products
// anthony@tactileproducts.co.za
// June 18 2015
//
//
// convert a bitmap into a byte array
//
    public byte[] convert(Bitmap bm) {
        try {
            //get width and height of the image
            int width = bm.getWidth();
            int height = bm.getHeight();

            //get pixel of the original picture
            int pixR;
            int pixG;
            int pixB;

            //define pixel array
            int[] pixels = new int[width * height];

            int widArray = ((width - 1) / 8) + 1;//bytes in width
            int lenArray = widArray * height;//bytes in length
            byte[] dataArray = new byte[lenArray + 8];//define a transformed dataArray

            dataArray[0] = 0x1D;
            dataArray[1] = 0x76;
            dataArray[2] = 0x30;
            dataArray[3] = 0x00;

            dataArray[4] = (byte) widArray;//xL
            dataArray[5] = (byte) (widArray / 256);//xH
            dataArray[6] = (byte) height;
            dataArray[7] = (byte) (height / 256);

            //get pixel of the original picture
            bm.getPixels(pixels, 0, width, 0, 0, width, height);

            int indexByte = 8;
            dataArray[indexByte] = 0;
            int indexBit = 0;
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {//transform each line，after transforming，data of the last byte may need to be moved up
                    //get the r part of current pixels
                    pixR = Color.red(pixels[i * width + j]);
                    //get the g part of current pixels
                    pixG = Color.green(pixels[i * width + j]);
                    //get the b part of current pixels
                    pixB = Color.blue(pixels[i * width + j]);
                    //A temporary variable, saving the converted value
                    //int temp = (int)(0.299*pixR + 0.587*pixG + 0.114*pixB + 0.5);
                    if ((pixR + pixG + pixB) < 384) {
                        dataArray[indexByte] += 0x01;
                    }

                    ++indexBit;

                    if (indexBit < 8) {
                        dataArray[indexByte] *= 2;//equal to moving one byte left
                    } else {
                        indexBit = 0;
                        ++indexByte;
                        if (indexByte < lenArray) {
                            dataArray[indexByte] = 0;
                        }
                    }
                }

                if (indexBit != 0)//there are incomplete bytes，1－7 valid
                {
                    while (indexBit < 8) {
                        dataArray[indexByte] *= 2;//equal to moving one byte left
                        ++indexBit;
                    }

                    indexBit = 0;
                    ++indexByte;
                    if (indexByte < lenArray) {
                        dataArray[indexByte] = 0;
                    }
                }
            }
            return dataArray;

        } catch (Exception exception) {
            Log.v(TAG, "problem converting bitmap to byte array " + exception);
        }

        return new byte[1];

    }

    public static Gson getGsonDateAsLong() {
        //returns a Gson object that has the custom Date deserializer below
        GsonBuilder builder = new GsonBuilder();
        builder.registerTypeAdapter(Date.class, new JsonDeserializer<Date>() {
            //Gson usually expects a Date in UTC format.  This deserializer will handle Dates that are received in milliseconds instead of a UTC String representation

            public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
                return new Date(json.getAsJsonPrimitive().getAsLong());
            }
        });

        return builder.create();
    }

    public static String hexToDecimalString(String hex) {
        byte[] cardUid = new byte[8];  //long is 8 bytes in length
        System.arraycopy(toByteArray(hex), 0, cardUid, 4, 4);  //copy unsigned int (4 bytes) into lower half of long
        ByteBuffer wrapped = ByteBuffer.wrap(cardUid); // big-endian by default
        //format the card uid as a 10 digit string
        return String.format(Locale.US, "%010d", wrapped.getLong());
    }


    private static byte[] toByteArray(String hexString) {
        if (hexString.length() % 2 == 1) {
            hexString = "0" + hexString;
        }
        int hexStringLength = hexString.length();
        byte[] byteArray;
        int count = 0;
        char c;
        int i;
        // Count number of hex characters
        for (i = 0; i < hexStringLength; i++) {
            c = hexString.charAt(i);
            if (c >= '0' && c <= '9' || c >= 'A' && c <= 'F' || c >= 'a'
                    && c <= 'f') {
                count++;
            }
        }

        byteArray = new byte[(count + 1) / 2];
        boolean first = true;
        int len = 0;
        int value;
        for (i = 0; i < hexStringLength; i++) {
            c = hexString.charAt(i);
            if (c >= '0' && c <= '9') {
                value = c - '0';
            } else if (c >= 'A' && c <= 'F') {
                value = c - 'A' + 10;
            } else if (c >= 'a' && c <= 'f') {
                value = c - 'a' + 10;
            } else {
                value = -1;
            }

            if (value >= 0) {
                if (first) {
                    byteArray[len] = (byte) (value << 4);
                } else {
                    byteArray[len] |= value;
                    len++;
                }
                first = !first;
            }
        }
        return byteArray;
    }

    private final static char[] decimalArray = "0123456789".toCharArray();

    public static String bytesToDecimal(byte[] bytes) {
        char[] decimalChars = new char[bytes.length * 4];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            decimalChars[j * 4] = decimalArray[v / 100];
            decimalChars[j * 4 + 1] = decimalArray[(v / 10) % 10];
            decimalChars[j * 4 + 2] = decimalArray[v % 10];
            decimalChars[j * 4 + 3] = ' ';
        }
        return new String(decimalChars);
    }


    public static int getAgeInMonths(Date dob) {
        Calendar cal = Calendar.getInstance();
        Date now = new Date();
        if (now.before(dob)) {
            return -1;
        } else {
            cal.setTime(dob);
        }
        int c = 0;
        while (cal.getTime().before(now)) {
            cal.add(Calendar.MONTH, 1);
            c++;
        }
        return c - 1;
    }

    public static ArrayList<String> wordWrap(String s, int width) {
        ArrayList<String> lines = new ArrayList();
        if (s != null) {
            String newLine = "";
            if (s.length() > width) {
                String[] words = s.split(" ");
                for (int i = 0; i < words.length; i++) {
                    if ((newLine.length() + words[i].length() + 1) < width) {
                        //The first should not have space before it
                        if (newLine.isEmpty()) {
                            newLine += words[i];
                        } else {
                            newLine += " " + words[i];
                        }
                    } else {
                        lines.add(newLine);
                        if (words[i].length() > width) {
                            String tmpWord = words[i];
                            while (tmpWord.length() > width) {
                                lines.add(tmpWord.substring(0, width - 1));
                                tmpWord = tmpWord.substring(width - 1);
                            }
                            lines.add(tmpWord);
                        } else {
                            newLine = words[i];
                        }
                    }
                }
            } else {
                newLine = s;
            }
            lines.add(newLine);
        }
        return lines;
    }

    public boolean isPinFormat(String text) {
        if (text != null && !text.isEmpty()) {
            if (text.length() <= 4) {
                return text.matches("^[0-9]*$");
            } else {
                return text.matches("^(\\d{4}[ ]{1,}\\d{1}).*$") || text.matches("^(\\d{3}[ ]{1,}\\d{1}).*$");
            }
        }
        return false;
    }
}
