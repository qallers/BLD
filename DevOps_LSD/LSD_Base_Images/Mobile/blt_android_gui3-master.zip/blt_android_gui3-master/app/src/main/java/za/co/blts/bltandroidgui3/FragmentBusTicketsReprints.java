package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by MasiS on 2018/02/15.
 */

public class FragmentBusTicketsReprints extends BaseFragment {

    private final String TAG = this.getClass().getSimpleName();

    private ListView tickets_list_view;
    private TextView no_results_message;

    public FragmentBusTicketsReprints() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        View rootView = inflater.inflate(R.layout.fragment_ticket_reprints, container, false);
        tickets_list_view = rootView.findViewById(R.id.tickets_list_view);
        no_results_message = rootView.findViewById(R.id.no_results_message);
        populateScreen();
        return rootView;
    }

    @Override
    public void onDestroy() {
        if (tickets_list_view != null) tickets_list_view.setAdapter(null);
        super.onDestroy();
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    //----------------------------------------------------------------------------------------------
    private void populateScreen() {
        getBaseActivity().removeExpiredTickets();
        configureTicketsListView();
    }

    //----------------------------------------------------------------------------------------------
    private void configureTicketsListView() {
        configureAdapter(getBaseActivity().readCachedTicketReprints());
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean onBackPressed() {
        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else {
            getBaseActivity().gotoFragment(new FragmentCarmaSearchRoutesNew(), "FragmentCarmaSearchRoutesNew");
        }
        return true;
    }

    //----------------------------------------------------------------------------------------------
    private void configureAdapter(ArrayList<CarmaResponseTicketMessageSerializable> tickets) {
        if (tickets.size() > 0)
            tickets_list_view.setAdapter(new BluDroidTicketsReprintsAdapter(getBaseActivity(), R.layout.reprint_bus_ticket_layout_item, tickets));
        else {
            tickets_list_view.setVisibility(View.GONE);
            no_results_message.setVisibility(View.VISIBLE);
        }
    }


    //----------------------------------------------------------------------------------------------
}