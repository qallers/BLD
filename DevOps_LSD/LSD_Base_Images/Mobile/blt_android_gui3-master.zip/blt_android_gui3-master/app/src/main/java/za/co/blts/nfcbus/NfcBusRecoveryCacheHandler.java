package za.co.blts.nfcbus;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import za.co.blt.interfaces.external.messages.nfcbus.NfcBusSvcSector;

public class NfcBusRecoveryCacheHandler {
    private final String TAG = this.getClass().getSimpleName();

    private File cacheDir;

    public NfcBusRecoveryCacheHandler(File cacheDir) {
        this.cacheDir = cacheDir;
    }

    public List<NfcBusRecovery> getRecoveries() {
        List<NfcBusRecovery> list = new ArrayList<>();
        File[] files = cacheDir.listFiles();
        for (File f : files) {
            NfcBusRecovery recovery = readRecoveryFromFile(f);
            if (recovery != null) {
                Log.v(TAG, "read from cache: " + recovery.toString());
                list.add(recovery);
            }
        }

        return list;
    }

    public void deleteRecoveryFromCache(String transref) {
        String filename = transref + ".txt";
        File cache = new File(cacheDir.getPath() + "/" + filename);
        if (cache.exists()) {
            Log.v(TAG, "removed from cache: " + filename);
            cache.delete();
        }
    }

    public void removeCaches() {
        File[] files = cacheDir.listFiles();
        for (File f : files) {
            f.delete();
        }
    }

    private NfcBusRecovery readRecoveryFromFile(File f) {
        try {
            NfcBusRecovery recovery = null;
            Gson gson = new GsonBuilder().serializeNulls().create();

            BufferedReader bufferedReader = new BufferedReader(new FileReader(f));
            String line;
            if ((line = bufferedReader.readLine()) != null) {
                recovery = gson.fromJson(line, NfcBusRecovery.class);
            }
            bufferedReader.close();

            return recovery;
        } catch (Exception e) {
            return null;
        }
    }

    public NfcBusRecovery createRecoveryCheckout(String transRef, String uid, String status, long ticketId, long transactionId, String amount, int paymentType, long companyId, ArrayList<NfcBusSvcSector> svcData, String departure, String destination) {
        try {
            NfcBusRecovery recovery = new NfcBusRecovery();
            recovery.setType("checkout");
            recovery.setTransRef(transRef);
            recovery.setUid(uid);
            recovery.setStatus(status);
            recovery.setTicketId(ticketId);
            recovery.setTransactionId(transactionId);
            recovery.setSvcData(svcData);
            recovery.setDeparture(departure);
            recovery.setDestination(destination);
            recovery.setCompanyId(companyId);
            recovery.setAmount(amount);
            recovery.setPaymentType(paymentType);
            return recovery;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public NfcBusRecovery createRecoveryCancel(String transRef, String uid, String status, long ticketId, long transactionId, ArrayList<NfcBusSvcSector> svcData, String departure, String destination, long companyId) {
        try {
            NfcBusRecovery recovery = new NfcBusRecovery();
            recovery.setType("cancel");
            recovery.setTransRef(transRef);
            recovery.setUid(uid);
            recovery.setStatus(status);
            recovery.setTicketId(ticketId);
            recovery.setTransactionId(transactionId);
            recovery.setSvcData(svcData);
            recovery.setDeparture(departure);
            recovery.setDestination(destination);
            recovery.setCompanyId(companyId);
            return recovery;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void cacheRecovery(NfcBusRecovery recovery) {
        if (recovery != null) {
            Log.v(TAG, "caching " + recovery.toString());
            try {
                String filename = recovery.getTransRef() + ".txt";
                File cache = new File(cacheDir.getPath() + "/" + filename);
                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
                bufferedWriter.write(recovery.toString());
                bufferedWriter.flush();
                bufferedWriter.close();
                Log.v(TAG, "caching successful");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


}
