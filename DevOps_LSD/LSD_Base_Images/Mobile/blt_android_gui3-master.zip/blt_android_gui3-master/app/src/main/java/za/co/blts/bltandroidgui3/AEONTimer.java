package za.co.blts.bltandroidgui3;

import android.os.CountDownTimer;
import android.util.Log;

class AEONTimer extends CountDownTimer {

    private final String TAG = this.getClass().getSimpleName();

    private AEONAsyncTask aeonAsyncTask;

    public AEONTimer(AEONAsyncTask task, long millisInFuture, long countDownInterval) {
        super(millisInFuture, countDownInterval);
        aeonAsyncTask = task;
    }

    public void onFinish() {
        try {
            Log.v(TAG, "AEONTIMER finished");
            boolean b = aeonAsyncTask.cancel(true);
            //
            // this doesn't seem to actually cancel the
            // asynctask, so we will notify the activity
            // directly
            //
            BaseActivity baseScreen = aeonAsyncTask.baseActivityWeakReference.get();
            if (baseScreen != null) {

                if (b) {
                    //Nkosana
                    //Need to dismiss progress
                    //And show error dialog when result is null
                    baseScreen.dismissProgress();
                    baseScreen.error(null);
                }

                baseScreen.createNetworkErrorConfirmation();
            }
        } catch (Exception exception) {
            Log.v(TAG, "problems with cancelling asynctask " + exception);
        }
    }

    public void onTick(long millisUntilFinished) {
        Log.v(TAG, "ticking for AEON task " + aeonAsyncTask + " " + millisUntilFinished + " left to go");
    }

}
