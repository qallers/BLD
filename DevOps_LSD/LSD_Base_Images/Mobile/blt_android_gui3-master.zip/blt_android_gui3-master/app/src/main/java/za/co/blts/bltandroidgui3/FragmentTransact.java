package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by warrenm on 2016/10/03.
 */

public class FragmentTransact extends TransactTabRecycler {

    private final String TAG = this.getClass().getSimpleName();


    public FragmentTransact() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_transact, container, false);
        String title = getActivity().getResources().getString(R.string.transact);
        getActivity().setTitle(title);
        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();

        tabs = rootView.findViewById(R.id.tabLayout);
        viewPager = rootView.findViewById(R.id.viewpager);

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public boolean onBackPressed() {

        getBaseActivity().gotoMainScreen();

        return true;
    }

}
