package za.co.blts.bltandroidgui3;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponseSupplierMessage;
import za.co.blts.bltandroidgui3.confirmations.BluDroidChatForChangeConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDialogable;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

public class ActivityCalculateChange extends BaseActivity implements View.OnClickListener, TextWatcher, BluDroidDialogable {

    private final String TAG = this.getClass().getSimpleName();

    private BluDroidTextView txtAmountDue, txtChangeDue;
    private BluDroidEditText edt_payment;
    private boolean doChatForChange = false;
    private ImageButton vodacomC4C, mtnC4C, cellcC4C, telkomC4C;
    private BluDroidChatForChangeConfirmationDialog dialog = null;
    private boolean selectedItem = false;

    private Chat4ChangeResponseSupplierMessage c4cVodacom = null;
    private Chat4ChangeResponseSupplierMessage c4cMtn = null;
    private Chat4ChangeResponseSupplierMessage c4cCellC = null;
    private Chat4ChangeResponseSupplierMessage c4cTelkom = null;

    private ArrayList<CalculateChangeDataModel> dataModels;
    private ListView listView;
    private CalculateChangeListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate_change);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        toolbar = findViewById(R.id.toolbar);
        String title = "Calculate Change";
        toolbar.setTitle(title);
        toolbar.setNavigationBackIcon();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logger.info("User closed the ActivityCalculateChange screen");
                resetTimer();
                gotoMainScreen();
            }
        });

        if (chat4ChangeResponseListSuppliersMessage == null) {
            chat4ChangeResponseListSuppliersMessage = getCachedMVNOData();
        }
        c4cVodacom = getC4CSupplier("vodacom");
        c4cMtn = getC4CSupplier("mtn");
        c4cCellC = getC4CSupplier("cellc");
        c4cTelkom = getC4CSupplier("telkommobile");

        txtAmountDue = findViewById(R.id.txtAmountDue);
        txtChangeDue = findViewById(R.id.txtChangeDue);
        edt_payment = findViewById(R.id.edt_payment);
        BluDroidButton done = findViewById(R.id.done);
        listView = findViewById(R.id.transactionList);
        BluDroidLinearLayout chatForChangeLayout = findViewById(R.id.chatForChangeLayout);
        BluDroidLinearLayout chatForChangeLayout2 = findViewById(R.id.chatForChangeLayout2);
        vodacomC4C = findViewById(R.id.vodacomC4C);
        mtnC4C = findViewById(R.id.mtnC4C);
        cellcC4C = findViewById(R.id.cellcC4C);
        telkomC4C = findViewById(R.id.telkomC4C);
        deactivateButtons();

        // int maxLength = 6;
        // edt_payment.setFilters(new InputFilter[] {new InputFilter.LengthFilter(maxLength)});

        dataModels = extractCalculatorData(getTransactionList());

        adapter = new CalculateChangeListAdapter(dataModels, this);

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                resetTimer();

                CalculateChangeDataModel dataModel = dataModels.get(position);
                BluDroidTextView txtAmount = view.findViewById(R.id.txtAmount);

                selectedItem = dataModel.canCalculate();
                String strAmt = txtAmountDue.getText().toString()
                        .replace(getString(R.string.currency), "")
                        .replace(" ", "");
                double dblAmt = Double.parseDouble(strAmt);
                String strViewAmount = txtAmount.getText().toString()
                        .replace(getString(R.string.amount), "")
                        .replace(getString(R.string.currency), "")
                        .replace(" ", "");
                double viewAmount = Double.parseDouble(strViewAmount);
                double paymentAmt = 0;

                if (edt_payment != null && !edt_payment.getText().toString().equalsIgnoreCase("")) {
                    paymentAmt = Double.parseDouble(edt_payment.getText().toString());
                }

                double totalAmount;
                double changeDue;
                if (!selectedItem) {
                    dataModel.setCanCalculate(true);
                    dataModel.setIconSelected(R.drawable.ic_checkbox_on);
                    totalAmount = dblAmt + viewAmount;

                    txtAmountDue.setText(getString(R.string.format_amount, df2.format(totalAmount)));
                    if (paymentAmt != 0) {
                        changeDue = paymentAmt - totalAmount;
                        if (changeDue < 0) {
                            txtChangeDue.setText(getString(R.string.format_payment_short, String.valueOf(df2.format(changeDue)).replace("-", "")));
                            txtChangeDueStyle(true);
                            doChatForChange = false;
                        } else if (changeDue == 0) {
                            txtChangeDue.setText(getString(R.string.format_amount, "0.00"));
                            txtChangeDueStyle(false);
                            doChatForChange = false;
                        } else {
                            txtChangeDueStyle(false);
                            txtChangeDue.setText(getString(R.string.format_amount, df2.format(changeDue)));
                            doChatForChange = true;
                        }
                    }
                } else {
                    dataModel.setCanCalculate(false);
                    dataModel.setIconSelected(R.drawable.ic_checkbox_off);
                    totalAmount = (dblAmt - viewAmount);
                    txtAmountDue.setText(getString(R.string.format_amount, df2.format(totalAmount)));

                    if (paymentAmt != 0) {
                        changeDue = paymentAmt - totalAmount;
                        if (changeDue < 0) {
                            txtChangeDue.setText(getString(R.string.format_payment_short, String.valueOf(df2.format(changeDue)).replace("-", "")));
                            txtChangeDueStyle(true);
                            doChatForChange = false;
                        } else if (changeDue == 0) {
                            txtChangeDue.setText(getString(R.string.format_amount, "0.00"));
                            txtChangeDue.setTextColor(getSkinResources().getBackgroundTextColor());
                            txtChangeDue.setTextSize(getSkinResources().getTextSize());
                            doChatForChange = false;
                        } else {
                            txtChangeDueStyle(false);
                            txtChangeDue.setText(getString(R.string.format_amount, df2.format(changeDue)));
                            doChatForChange = true;
                        }
                    }
                }

                if (totalAmount <= 0) {
                    txtAmountDue.setText(getString(R.string.format_amount, "0.00"));
                    deactivateButtons();
                } else if (BaseFragment.canDoChatForChange && doChatForChange) {
                    Log.d(TAG, "activateButtons");
                    activateButtons();
                } else {
                    Log.d(TAG, "deactivateButtons");
                    deactivateButtons();
                }

                adapter.notifyDataSetChanged();
                adapter.notifyDataSetInvalidated();

            }
        });

        edt_payment.addTextChangedListener(this);

        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logger.info("ActivityCalculateChange" + ((BluDroidButton) v).getText());
                gotoMainScreen();
            }
        });

        if (BaseFragment.canDoChatForChange) {
            if (doChatForChange) {
                activateButtons();
            } else {
                deactivateButtons();
            }
        } else {
            chatForChangeLayout.setVisibility(View.INVISIBLE);
            chatForChangeLayout2.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    protected void onDestroy() {
        if (listView != null) listView.setAdapter(null);
        super.onDestroy();
    }

    private ArrayList<CalculateChangeDataModel> extractCalculatorData(ArrayList<String> rawData) {
        ArrayList<CalculateChangeDataModel> calculatorData = new ArrayList<>();
        int defaultIcon = R.drawable.ic_checkbox_off;

        if (rawData != null) {

            for (int i = rawData.size() - 1; i >= 0; i--) {
                String[] dataArray = rawData.get(i).split(":");
                String provider = sanitize(dataArray[0]);
                String productName = sanitize(dataArray[1]);
                double amount = Double.parseDouble(sanitize(dataArray[2]));
                calculatorData.add(new CalculateChangeDataModel(provider, productName, amount, false, defaultIcon));
            }
        }

        return calculatorData;
    }


    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        double amtDue = Double.parseDouble(txtAmountDue.getText().toString().replace("R ", ""));

        Log.d(TAG, "validated true");
        if (edt_payment != null && !edt_payment.getText().toString().equalsIgnoreCase("")) {


            double paymentAmt = Double.parseDouble(edt_payment.getText().toString());

            if (paymentAmt <= 999999.99) {
                double totalAmount = paymentAmt - amtDue;
                if (totalAmount < 0) {
                    txtChangeDue.setText(getString(R.string.format_payment_short, String.valueOf(df2.format(totalAmount)).replace("-", "")));
                    txtChangeDueStyle(true);
                    doChatForChange = false;
                } else if (totalAmount == 0) {
                    txtChangeDue.setText(getString(R.string.format_amount, "0.00"));
                    txtChangeDueStyle(false);
                    doChatForChange = false;
                } else {
                    txtChangeDue.setText(getString(R.string.format_amount, df2.format(totalAmount)));
                    txtChangeDueStyle(false);
                    doChatForChange = true;
                }
            } else {
                Log.d(TAG, "validated false");
                createAlertDialog("Payment Amount Exceeded", "You have exceeded the payment amount, Please enter an amount between R1 and R999 999.99");
                edt_payment.setText("");
            }

        } else if (edt_payment.getText().toString().equalsIgnoreCase("")) {
            txtChangeDueStyle(false);
            txtChangeDue.setText(getString(R.string.format_amount, "0.00"));
            doChatForChange = false;
        }

        if (doChatForChange && BaseFragment.canDoChatForChange) {
            if (amtDue > 0) {
                activateButtons();
            } else {
                deactivateButtons();
            }
        } else {
            deactivateButtons();
        }

    }

    @Override
    public void afterTextChanged(Editable s) {

    }

    private void txtChangeDueStyle(boolean hasError) {
        if (hasError) {
            txtChangeDue.setTextSize(getSkinResources().getTextSize() - 4);
            txtChangeDue.setTextColor(getResources().getColor(R.color.errorColorDEF));
        } else {
            txtChangeDue.setTextColor(getSkinResources().getBackgroundTextColor());
            txtChangeDue.setTextSize(getSkinResources().getTextSize());
        }
    }

    private void deactivateButtons() {
        vodacomC4C.setOnClickListener(null);
        vodacomC4C.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        mtnC4C.setOnClickListener(null);
        mtnC4C.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        cellcC4C.setOnClickListener(null);
        cellcC4C.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        telkomC4C.setOnClickListener(null);
        telkomC4C.setBackgroundColor(getResources().getColor(R.color.lightGrey));
    }

    private void activateButtons() {
        double changeDue = Double.parseDouble(txtChangeDue.getText().toString().replace("R ", ""));
        double min, max;

        boolean enableVodacom = false;
        if (c4cVodacom != null) {
            try {
                min = Double.parseDouble(c4cVodacom.getMinAmount());
                max = Double.parseDouble(c4cVodacom.getMaxAmount());
            } catch (Exception e) {
                min = 2.0;
                max = 1000.0;
            }
            if (changeDue >= min && changeDue <= max) {
                enableVodacom = true;
                vodacomC4C.setOnClickListener(this);
                vodacomC4C.setBackgroundColor(getResources().getColor(R.color.vodacom));
            }
        }
        if (!enableVodacom) {
            vodacomC4C.setOnClickListener(null);
            vodacomC4C.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        }

        boolean enableMtn = false;
        if (c4cMtn != null) {
            try {
                min = Double.parseDouble(c4cMtn.getMinAmount());
                max = Double.parseDouble(c4cMtn.getMaxAmount());
            } catch (Exception e) {
                min = 2.0;
                max = 1000.0;
            }
            if (changeDue >= min && changeDue <= max) {
                enableMtn = true;
                mtnC4C.setOnClickListener(this);
                mtnC4C.setBackgroundColor(getResources().getColor(R.color.mtn));
            }
        }
        if (!enableMtn) {
            mtnC4C.setOnClickListener(null);
            mtnC4C.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        }

        boolean enableCellC = false;
        if (c4cCellC != null) {
            try {
                min = Double.parseDouble(c4cCellC.getMinAmount());
                max = Double.parseDouble(c4cCellC.getMaxAmount());
            } catch (Exception e) {
                min = 2.0;
                max = 1000.0;
            }
            if (changeDue >= min && changeDue <= max) {
                enableCellC = true;
                cellcC4C.setOnClickListener(this);
                cellcC4C.setBackgroundColor(getResources().getColor(R.color.cellc));
            }
        }
        if (!enableCellC) {
            cellcC4C.setOnClickListener(null);
            cellcC4C.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        }

        boolean enableTelkom = false;
        if (c4cTelkom != null) {
            try {
                min = Double.parseDouble(c4cTelkom.getMinAmount());
                max = Double.parseDouble(c4cTelkom.getMaxAmount());
            } catch (Exception e) {
                min = 2.0;
                max = 1000.0;
            }
            if (changeDue >= min && changeDue <= max) {
                enableTelkom = true;
                telkomC4C.setOnClickListener(this);
                telkomC4C.setBackgroundColor(getResources().getColor(R.color.telkom));
            }
        }
        if (!enableTelkom) {
            telkomC4C.setOnClickListener(null);
            telkomC4C.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        }
    }

    @Override
    public void onClick(View v) {
        double changeDue = Double.parseDouble(txtChangeDue.getText().toString().replace("R ", ""));
        createChatForChangeConfirmation(this);
        dialog = (BluDroidChatForChangeConfirmationDialog) confirmation;
        dialog.disableTextBox();
        dialog.setAmount(String.valueOf(changeDue));
        Drawable drawable;
        String supplierCode;
        int color;

        resetTimer();

        switch (v.getId()) {
            case R.id.vodacomC4C:
                name = "Vodacom";
                drawable = getResources().getDrawable(R.drawable.vodacom);
                color = getResources().getColor(R.color.vodacom);
                supplierCode = "1";
                break;
            case R.id.mtnC4C:
                name = "MTN";
                drawable = getResources().getDrawable(R.drawable.mtn);
                color = getResources().getColor(R.color.mtn);
                supplierCode = "2";
                break;
            case R.id.cellcC4C:
                name = "Cell C";
                drawable = getResources().getDrawable(R.drawable.cellc);
                color = getResources().getColor(R.color.cellc);
                supplierCode = "3";
                break;
            case R.id.telkomC4C:
                name = "Telkom Mobile";
                drawable = getResources().getDrawable(R.drawable.telkommobile);
                color = getResources().getColor(R.color.telkom);
                supplierCode = "4";
                break;

            default:
                return;
        }

//        Chat4ChangeResponseSupplierMessage supplierMessage = getC4CSupplier(name);
//        Log.v("c4cMinMax", "supplierMessage:" + supplierMessage);
//        if (supplierMessage != null) {
//            try {
//                float min = Float.parseFloat(supplierMessage.getMinAmount());
//                float max = Float.parseFloat(supplierMessage.getMaxAmount());
//                Log.v("c4cMinMax", "min:" + min + " max:" + max);
//                dialog.setMinMaxValues(min, max);
//            } catch (NumberFormatException nfe) {
//                BaseActivity.logger.error(nfe.getLocalizedMessage());
//            }
//        }

        dialog.getIcon().setBackgroundColor(color);
        dialog.setIcon(drawable);
        dialog.setSupplierCode(supplierCode);

    }

    @Override
    public void affirmativeButton(View view) {
        resetTimer();
        String supplierCode = dialog.getSupplierCode();
        String amount = dialog.getAmount();
        Log.d(TAG, "supplierCode is " + supplierCode);

        if (dialog.validate()) {
            confirmation.dismiss();
            authenticateForChatForChange(supplierCode, amount);
        }
    }

    @Override
    public void negativeButton(View view) {
        confirmation.dismiss();
    }

    @Override
    public void neutralButton(View view) {

    }
}
