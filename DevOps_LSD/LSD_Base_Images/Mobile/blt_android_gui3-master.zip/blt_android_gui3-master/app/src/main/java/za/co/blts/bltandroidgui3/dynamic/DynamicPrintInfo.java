package za.co.blts.bltandroidgui3.dynamic;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DYNAMIC_PRINT_COUNTS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DYNAMIC_PRINT_INDEX;

public class DynamicPrintInfo {
    transient private final String TAG = this.getClass().getSimpleName();

    private int index;
    private List<PrintCount> counts;

    public DynamicPrintInfo(BaseActivity baseActivity) {
        this.index = -1;
        this.counts = new ArrayList<>();
        if (baseActivity != null) {
            String indexPref = baseActivity.getPreference(PREF_DYNAMIC_PRINT_INDEX);
            String countsPref = baseActivity.getPreference(PREF_DYNAMIC_PRINT_COUNTS);
            Log.d(TAG, "pref index: " + indexPref);
            Log.d(TAG, "pref counts: " + countsPref);
            try {
                this.index = Integer.parseInt(indexPref);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (!countsPref.isEmpty()) {
                try {
                    this.counts = new Gson().fromJson(countsPref, new TypeToken<List<PrintCount>>() {
                    }.getType());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        Log.d(TAG, "index: " + index);
        Log.d(TAG, "counts: " + getCounts());
    }

    public void clear(BaseActivity baseActivity) {
        if (baseActivity != null) {
            baseActivity.updatePreference(PREF_DYNAMIC_PRINT_INDEX, "");
            baseActivity.updatePreference(PREF_DYNAMIC_PRINT_COUNTS, "");
        }
    }

    public int getIndex() {
        return index;
    }

    public void updateIndex(BaseActivity baseActivity, int index) {
        if (baseActivity != null) {
            this.index = index;
            baseActivity.updatePreference(PREF_DYNAMIC_PRINT_INDEX, String.valueOf(index));
        }
    }

    public void updateCount(BaseActivity baseActivity, String id) {
        if (baseActivity != null && id != null) {
            int pccount = -1;
            boolean found = false;
            for (PrintCount pc : counts) {
                if (pc.id.equals(id)) {
                    pc.count = pc.count + 1;
                    pccount = pc.count;
                    found = true;
                    break;
                }
            }
            if (!found) {
                PrintCount pc = new PrintCount();
                pc.id = id;
                pc.count = 1;
                pccount = pc.count;
                counts.add(pc);
            }
            baseActivity.updatePreference(PREF_DYNAMIC_PRINT_COUNTS, getCounts());
            Log.d(TAG, "updated " + id + " count = " + pccount);
        }
    }

    public int getCount(String id) {
        for (PrintCount pc : counts) {
            if (pc.id.equals(id)) {
                return pc.count;
            }
        }
        return 0;
    }

    public String getCounts() {
        return new Gson().toJson(counts);
    }

    public String toString() {
        return new Gson().toJson(this);
    }

    private class PrintCount {
        String id;
        int count;
    }
}
