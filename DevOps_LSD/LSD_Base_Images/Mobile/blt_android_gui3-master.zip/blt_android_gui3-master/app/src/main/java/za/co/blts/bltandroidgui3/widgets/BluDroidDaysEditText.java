package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/27/2017.
 */

public class BluDroidDaysEditText extends BluDroidIntegerEditText {

    private final String TAG = this.getClass().getSimpleName();

    private int minValue = 0;
    private int maxValue = 0;


    public BluDroidDaysEditText(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray attributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidDaysEditText);

        try {
            minValue = attributesArray.getInt(R.styleable.BluDroidDaysEditText_minV, -Integer.MAX_VALUE);
            maxValue = attributesArray.getInt(R.styleable.BluDroidDaysEditText_maxV, Integer.MAX_VALUE);
        } catch (Exception e) {
            e.printStackTrace();
        }
        attributesArray.recycle();

    }


    public BluDroidDaysEditText(BaseActivity context) {
        super(context);
    }

    @Override
    public boolean validate() {
        Log.d(TAG, "validate days");
        //BaseActivity.logger.info(": validate()");
        String text = getText().toString().trim();
        boolean isvalidated = false;
        int days;
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            if (!text.trim().isEmpty()) {
                days = Integer.parseInt(text);
                if (days >= minValue && days <= maxValue) {

                    removeErrorMessage();
                    isvalidated = true;
                } else {
                    setErrorMessage(String.format(baseScreen.getResources().getString(R.string.daysBadValue), minValue, maxValue));
                    isvalidated = false;
                }
            } else {
                setErrorMessage(baseScreen.getResources().getString(R.string.numDaysEmpty));
            }
        }

        return isvalidated;
    }
}

