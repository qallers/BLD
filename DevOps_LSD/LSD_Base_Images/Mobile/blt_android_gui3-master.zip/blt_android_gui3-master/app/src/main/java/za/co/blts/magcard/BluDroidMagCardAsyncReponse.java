package za.co.blts.magcard;

/**
 * Created by NkosanaM on 6/23/2017.
 */

public interface BluDroidMagCardAsyncReponse {
    void processFinish(String output);
}
