package za.co.blts.bltandroidgui3;

public class LandingPageButton {
    private String label;
    private int img;
    private int count;

    public LandingPageButton(String label, int img) {
        this.label = label;
        this.img = img;
        this.count = 0;
    }

    public LandingPageButton(String label, int img, int count) {
        this.label = label;
        this.img = img;
        this.count = count;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
