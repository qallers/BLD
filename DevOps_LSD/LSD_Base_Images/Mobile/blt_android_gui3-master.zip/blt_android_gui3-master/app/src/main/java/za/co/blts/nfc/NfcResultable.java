package za.co.blts.nfc;

import android.content.Context;

public interface NfcResultable {
    Context getContext();

    void handleNfcResult(NfcResult result);
}
