package za.co.blts.bltandroidgui3;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;


/**
 * Created by NkosanaM on 7/14/2017.
 */

public class PutcoPagerAdapter extends FragmentPagerAdapter {

//    public PutcoPagerAdapter(FragmentManager fm) {
//        super(fm);
//    }

    private Fragment[] f = new Fragment[getCount()];

    public PutcoPagerAdapter(FragmentManager fm, int behavior) {
        super(fm, behavior);
    }

    @Override
    public Fragment getItem(int position) {
        f[position] = new Fragment();
        switch (position) {
            case 0:
                f[position] = new FragmentPutcoSearchRoute();
                break;
            case 1:
                f[position] = new FragmentPutcoSelectTrip();
                break;
            case 2:
                f[position] = new FragmentPutcoPurchaseTicket();
                break;
        }
        return f[position];
    }

    @Override
    public int getCount() {
        return 3;
    }

    public Fragment getItemIndex(int position) {
        return f[position];
    }
}