package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.lang.ref.WeakReference;
import java.util.List;

public class BluLandingRecyclerAdapter extends RecyclerView.Adapter<BluLandingRecyclerAdapter.ViewHolder> {

    private final String TAG = this.getClass().getSimpleName();

    private List<LandingPageButton> data;
    WeakReference<BaseActivity> baseActivityWeakReference;
    private ItemClickListener clickListener;


    public BluLandingRecyclerAdapter(BaseActivity context, List<LandingPageButton> data) {
        this.data = data;
        Log.d(TAG, "context is of type " + context.getClass().getName());
        this.baseActivityWeakReference = new WeakReference<>(context);
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.d("Optimize", "BluLandingRecyclerAdapter onCreateViewHolder");
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.landing_page_button, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            LandingPageButton current = data.get(position);
            Drawable image = baseActivity.getResources().getDrawable(current.getImg());
            holder.btnImage.setImageDrawable(image);
            Drawable roundDrawable = baseActivity.getResources().getDrawable(R.drawable.button_bg_shadow_rounded);
            roundDrawable.setColorFilter(baseActivity.getSkinResources().getButtonColor(), PorterDuff.Mode.MULTIPLY);
            holder.btnImage.setBackground(roundDrawable);
            holder.txtLabel.setText(current.getLabel());
            String countTxt = current.getCount() > 99 ? "99" : "" + current.getCount();
//            String countTxt = current.getCount() > 99 ? "99+" :
//                    current.getCount() > 10 ? " " + current.getCount() :
//                            " " + current.getCount() + " ";
            holder.txtCount.setText(countTxt);
            holder.txtCount.setVisibility(current.getCount() > 0 ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    void setClickListener(ItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }

    public LandingPageButton getItem(int id) {
        return data.get(id);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnTouchListener {
        TextView txtLabel, txtCount;
        ImageButton btnImage;

        @SuppressLint("ClickableViewAccessibility")
        ViewHolder(View itemView) {
            super(itemView);
            txtLabel = itemView.findViewById(R.id.txt);
            txtCount = itemView.findViewById(R.id.count);
            btnImage = itemView.findViewById(R.id.img);
            btnImage.setOnClickListener(this);
            btnImage.setOnTouchListener(this);
        }

        @Override
        public void onClick(View view) {
            if (clickListener != null) clickListener.onItemClick(getAdapterPosition());
        }

        @SuppressLint("ClickableViewAccessibility")
        public boolean onTouch(View view, MotionEvent event) {
            try {
                BaseActivity baseActivity = baseActivityWeakReference.get();
                if (baseActivity != null) {
                    baseActivity.resetTimer();
                    baseActivity.hideKeyboard();
                }
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        btnImage.getBackground().setAlpha(128);
                        btnImage.invalidate();
                        txtCount.getBackground().setAlpha(128);
                        txtCount.invalidate();
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_OUTSIDE:
                    case MotionEvent.ACTION_CANCEL:
                        btnImage.getBackground().setAlpha(255);
                        btnImage.invalidate();
                        txtCount.getBackground().setAlpha(255);
                        txtCount.invalidate();
                        break;
                }
            } catch (Exception exception) {
                Log.v(TAG, "onTouch exception " + exception);
            }
            return false;
        }
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(int position);
    }


}
