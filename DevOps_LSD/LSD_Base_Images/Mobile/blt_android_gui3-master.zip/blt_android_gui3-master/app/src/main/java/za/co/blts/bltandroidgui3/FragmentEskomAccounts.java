package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidMeterNumberEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMoneyEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.magcard.BluDroidMagCardAsyncReponse;
import za.co.blts.magcard.MagCardData;

import static android.view.View.GONE;


public class FragmentEskomAccounts extends BaseFragment implements BluDroidMagCardAsyncReponse {

    private final String TAG = this.getClass().getSimpleName();

    private BluDroidMeterNumberEditText meterNumberEditText;
    private BluDroidMoneyEditText amountEditText;


    private BluDroidRelativeLayout layout;
    private View rootView;

    public FragmentEskomAccounts() {
        // Required empty public constructor
    }

    private String municName = "EskomDirect";


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_eskom_accounts, container, false);

        layout = rootView.findViewById(R.id.layout);
        BluDroidButton confirm = rootView.findViewById(R.id.confirm);
        BluDroidButton fbe = rootView.findViewById(R.id.fbe);
        BluDroidButton swipeCard = rootView.findViewById(R.id.swipeCard);


        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                String meterNumber = getMeterNumber();
                String amount = getAmount();
                String purchaseType = "TOKEN";

                if (layout.validate()) {

                    Log.d(TAG, "need to validate for eskom electricity");
                    Log.d(TAG, "municName is " + municName);
                    Log.d(TAG, "meterNumber is " + meterNumber);
                    Log.d(TAG, "amount is " + amount);
                    getMainActivity().authenticateForUniversalElectricity(municName, meterNumber, amount, purchaseType);
                }

            }
        });

        fbe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                String meterNumber = getMeterNumber();
                setAmount("0.00");
                String amount = getAmount();
                String purchaseType = "FBE";

                if (layout.validate()) {

                    Log.d(TAG, "need to validate for eskom electricity");
                    Log.d(TAG, "municName is " + municName);
                    Log.d(TAG, "meterNumber is " + meterNumber);
                    Log.d(TAG, "amount is " + amount);

                    getMainActivity().authenticateForUniversalElectricity(municName, meterNumber, amount, purchaseType);


                }

            }
        });

        if (getBaseActivity().openMagEncoder()) {
            getBaseActivity().magCard.setDelegate(this);
            swipeCard.setVisibility(View.VISIBLE);
            swipeCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    BaseActivity.logger.info(((BluDroidButton) v).getText());
                    getBaseActivity().magCard.openUsbSerial();
                    getBaseActivity().createMagEncoderAlertDialog("Mag Card", "Please swipe card to read");
                    getBaseActivity().magCard.sendReadCommand();
                    getBaseActivity().magCardAction = "read";
                }
            });
        } else {
            swipeCard.setVisibility(GONE);
        }

        setupSpinner();
        return rootView;
    }

    private void setupSpinner() {
        final Spinner meterNumberSpinner = rootView.findViewById(R.id.meterNumberSpinner);
        final BluDroidLinearLayout buttonLayout = rootView.findViewById(R.id.buttonLayout);
        final BluDroidMeterNumberEditText meterNumber = rootView.findViewById(R.id.meterNumber);

        final List<String> meterNumbers = new ArrayList<>();

        if (checkCustomerProfileAccountNumbers(meterNumbers)) {
            meterNumbers.add(0, "Other");
            meterNumberSpinner.setVisibility(View.VISIBLE);
            buttonLayout.setVisibility(View.GONE);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getBaseActivity(), android.R.layout.simple_spinner_item, meterNumbers);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            meterNumberSpinner.setAdapter(dataAdapter);
            //although meterNumber is hidden, update this with the selected spinner value, so the dialog.validate() will pass
            meterNumber.setText(meterNumbers.get(1));
            meterNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i == 0) {
                        onNothingSelected(null);
                    } else {
                        meterNumber.setText(meterNumbers.get(i));
                        buttonLayout.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    meterNumber.setText("");
                    buttonLayout.setVisibility(View.VISIBLE);

                }
            });
            meterNumberSpinner.setSelection(1);

        } else {
            meterNumberSpinner.setVisibility(View.GONE);
            buttonLayout.setVisibility(View.VISIBLE);
        }

    }

    private boolean checkCustomerProfileAccountNumbers(List<String> accountNumbers) {
        if (BaseActivity.consumerProfile != null && getBaseActivity().customerProfileElectricityAccountNumbers != null) {
            String[] accounts = getBaseActivity().customerProfileElectricityAccountNumbers.get(municName);
            if (accounts != null && accounts.length > 0) {
                accountNumbers.addAll(Arrays.asList(accounts));
                return true;
            }
        }
        return false;
    }

    private String getMeterNumber() {
        meterNumberEditText = rootView.findViewById(R.id.meterNumber);

        return meterNumberEditText.getText().toString();
    }


    private void setMeterNumber(String meterNumber) {
        meterNumberEditText = rootView.findViewById(R.id.meterNumber);

        meterNumberEditText.setText(meterNumber);
    }

    private String getAmount() {
        amountEditText = rootView.findViewById(R.id.amount);

        return amountEditText.getText().toString();
    }

    private void setAmount(String amount) {
        amountEditText = rootView.findViewById(R.id.amount);

        amountEditText.setText(amount);
    }

    @Override
    public boolean onBackPressed() {
        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentElectricity(), "FragmentElectricity").commit();
        }
        return true;
    }

    @Override
    public void processFinish(String output) {
        // getBaseActivity().createAlertDialog("Mag Encoder",output);
        if (getBaseActivity() != null) {
            if (getBaseActivity().alert != null) {
                getBaseActivity().alert.dismiss();
            }

            if (getBaseActivity().magCardAction.equalsIgnoreCase("read")) {
                if (output.toLowerCase().contains("success")) {
                    setMeterNumber(getBaseActivity().magCard.getTracks().get(1));
                } else {
                    getBaseActivity().createMagCardAlertDialog("Mag Encoder", output);
                }


            } else {

                //createAlertDialog("Mag Encoder",output);

                if (output.toLowerCase().contains("success")) {

                    getBaseActivity().createMagCardAlertDialog("Mag Encoder", output);

                    getBaseActivity().alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            getBaseActivity().magCardDataList.remove(0);

                            if (getBaseActivity().magCardDataList.size() > 0) {
                                getBaseActivity().cardNumber++;
                                getBaseActivity().isElectricityResponseFirstTime = false;
                                getMainActivity().results(getBaseActivity().electricityVoucherResponseMessage);
                            } else {
                                if (BaseActivity.isVoucherPrinted) {
                                    getMainActivity().printElectricityVoucher();
                                } else {
                                    getBaseActivity().cleanUp();
                                    getBaseActivity().createPrintErrorConfirmation();
                                }
                            }

                            dialog.dismiss();
                        }
                    });
                    getBaseActivity().alert.show();
                } else {
                    getBaseActivity().createMagCardAlertDialog("Mag Encoder", output + ", Would You like to retry?");
                    getBaseActivity().alert.setPositiveOption("Retry", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            getBaseActivity().magCard.resetMsr();

                            MagCardData cardData = getBaseActivity().magCardDataList.get(0);
                            getBaseActivity().magCard.setTrack2(cardData.getTrack2());
                            getBaseActivity().magCard.setTrack3(cardData.getTrack3());

                            getBaseActivity().magCard.sendWriteCommand();
                            getBaseActivity().magCardAction = "write";
                            getBaseActivity().createNotifyAlertDialog("Mag Card", "Please swipe card to write " + getBaseActivity().cardNumber + "/" + getBaseActivity().tokensSize);
                        }
                    });

                    getBaseActivity().alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    getBaseActivity().alert.show();
                }
            }
        }
    }


}
