package za.co.blts.magcard;

import android.util.Log;
import android.util.SparseArray;

import com.nexgo.oaf.apiv3.device.led.LEDDriver;
import com.nexgo.oaf.apiv3.device.led.LightModeEnum;
import com.nexgo.oaf.apiv3.device.reader.CardInfoEntity;
import com.nexgo.oaf.apiv3.device.reader.CardReader;
import com.nexgo.oaf.apiv3.device.reader.CardSlotTypeEnum;
import com.nexgo.oaf.apiv3.device.reader.OnCardInfoListener;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;

import static com.nexgo.oaf.apiv3.APIProxy.getDeviceEngine;

/**
 * Created by MasiS on 4/19/2018.
 */

public class NexgoN3MagCard implements MagcardInterface, OnCardInfoListener {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidMagCardAsyncReponse delegate = null;

    private CardReader cardReader;
    private LEDDriver ledDriver;
    private String track1, track2, track3;
    private WeakReference<BaseActivity> baseActivityWeakReference;

    private final SparseArray<LightModeEnum> hashMap = new SparseArray<>();

    //----------------------------------------------------------------------------------------------
    public NexgoN3MagCard(BaseActivity context) {
        this.baseActivityWeakReference = new WeakReference<>(context);
        context.deviceEngine = getDeviceEngine();
        ledDriver = context.deviceEngine.getLEDDriver();
        cardReader = context.deviceEngine.getCardReader();
        hashMap.put(0, LightModeEnum.RED);
        hashMap.put(1, LightModeEnum.GREEN);
        hashMap.put(2, LightModeEnum.YELLOW);
        hashMap.put(3, LightModeEnum.BLUE);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendLedCommand(boolean green, boolean yellow, boolean red) {
        ledDriver.setLed(hashMap.get(1), green);
        ledDriver.setLed(hashMap.get(2), yellow);
        ledDriver.setLed(hashMap.get(0), red);
        ledDriver.setLed(hashMap.get(3), false);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setDelegate(BluDroidMagCardAsyncReponse delegate) {
        this.delegate = delegate;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean isConnected() {
        return true;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean isOpen() {
        return true;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void closeAdapter() {

    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean enumerate() {
        return true;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean featureSupported() {
        return true;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void openUsbSerial() {

    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTrack1(String track1) {
        this.track1 = track1;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTrack2(String track2) {
        this.track2 = track2;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTrack3(String track3) {
        this.track3 = track3;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public String getResult() {
        return "getResult()";
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTracks(List<String> tracks) {
        if (tracks.size() != 3) return; //3 tracks must always be provided
        this.track1 = tracks.get(0);
        this.track2 = tracks.get(1);
        this.track3 = tracks.get(2);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public List<String> getTracks() {
        List<String> list = new ArrayList<>();
        list.add(this.track1);
        list.add(this.track2);
        list.add(this.track3);
        return list;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void resetMsr() {
        track1 = track2 = track3 = "";
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendCheckCommsReq() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendModelReq() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setHiCo() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setLoCo() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendHiLoCoStatusReq() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void eraseCard(boolean trk1, boolean trk2, boolean trk3) {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setLedOff() {
    }

    //----------------------------------------------------------------------------------------------
    private void results() {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            if (baseActivity.alert != null) {
                baseActivity.alert.dismiss();
            }

            if (BaseActivity.isReadingMag) {
                baseActivity.createAlertDialog("Mag Encoder", baseActivity.magCard.getTracks().toString());
            } else {
                baseActivity.createAlertDialog("NFC Reader", baseActivity.magCard.getTracks().toString());
            }
        }
        delegate.processFinish("success");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendReadCommand() {
        BaseActivity.isReadingMag = true;
        swingCard();
    }

    //----------------------------------------------------------------------------------------------
    private void swingCard() {
        HashSet<CardSlotTypeEnum> slotTypes = new HashSet<>();
        slotTypes.add(CardSlotTypeEnum.SWIPE); // maybe we need a check on this
        cardReader.searchCard(slotTypes, 60, this);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendWriteCommand() {

    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onCardInfo(final int retCode, final CardInfoEntity cardInfo) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            if (cardInfo != null) {
                baseActivity.magCard.setTrack1(cardInfo.getTk1());
                baseActivity.magCard.setTrack2(cardInfo.getTk2());
                baseActivity.magCard.setTrack3(cardInfo.getTk3());
            }
            baseActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    results();
                }
            });
        }
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onSwipeIncorrect() {
        Log.i(TAG, "onSwipeIncorrect()");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onMultipleCards() {
        Log.i(TAG, "onMultipleCards()");
    }
    //----------------------------------------------------------------------------------------------
}