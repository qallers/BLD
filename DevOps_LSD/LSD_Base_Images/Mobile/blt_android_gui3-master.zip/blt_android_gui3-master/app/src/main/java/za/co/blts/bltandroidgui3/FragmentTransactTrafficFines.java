package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;

import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProductMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProviderMessage;
import za.co.blts.bltandroidgui3.cardviews.CardViewBillPayment;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.widgets.BluDroidSearchEditText;
import za.co.blts.bltandroidgui3.widgets.BluRecyclerView;


public class FragmentTransactTrafficFines extends BaseFragment implements View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();

    private BluDroidSearchEditText search = null;

    private ArrayList<CardviewDataObject> list;

    public FragmentTransactTrafficFines() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_transact_traffic_fines, container, false);

        search = rootView.findViewById(R.id.search_fine);


        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        String title = getActivity().getResources().getString(R.string.transact);
        getBaseActivity().toolbar.setTitle(title);
        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();

        //if(((BaseActivity) getActivity()).billPaymentsResponseProductListMessage != null) {
        configureRecycler();
        //}

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
                adapter.setFilterSearch(search.getText().toString());
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
        });
    }


    @Override
    public void onClick(View view) {

    }

    private void configureRecycler() {
        BluRecyclerView recycler = getActivity().findViewById(R.id.billRecycler_fine);
        recycler.setHasFixedSize(true);

        list = new ArrayList<>();
        ArrayList<SortableProduct> products = new ArrayList<>();

        if (BaseActivity.billPaymentsResponseProductListMessage != null && BaseActivity.billPaymentsResponseProductListMessage.getData().getProviders().size() > 0) {

            for (int i = 0; i < BaseActivity.billPaymentsResponseProductListMessage.getData().getProviders().size(); i++) {
                BillPaymentsResponseProviderMessage provider = BaseActivity.billPaymentsResponseProductListMessage.getData().getProviders().get(i);
                for (int j = 0; j < provider.getProducts().size(); j++) {
                    BillPaymentsResponseProductMessage product = provider.getProducts().get(j);
                    SortableProduct newProduct = new SortableProduct(product, provider);
                    products.add(newProduct);
                }
            }
            Collections.sort(products, SortableProduct.ProductComparator);

            for (int i = 0; i < products.size(); i++) {
                SortableProduct product = products.get(i);
                BillPaymentsResponseProviderMessage provider = product.getProvider();

                //
                // ignore bus tickets right now
                //
                if (provider.getName().equals("Pay@ Bus Tickets"))
                    continue;

                //
                // ignore insurance premiums right now
                //
                if (provider.getName().equals("Pay@ Insurance Payment"))
                    continue;

                //
                // ignore account payments and bill payments
                //
                if (provider.getName().endsWith("Bill Payment") ||
                        provider.getName().endsWith("Account Payment"))
                    continue;

                if (provider.getName().equals("SAPO Account Payment"))
                    addToProductList(product.getName(), provider.getName());
                if (provider.getName().equals("Pay@ Account Payment"))
                    addToProductList(product.getName(), provider.getName());
                if (provider.getName().equals("Pay@ Fine Payment"))
                    addToProductList(product.getName(), provider.getName());
                if (provider.getName().equals("Syntell Traffic Fines"))
                    addToProductList(product.getName(), provider.getName());
                if (provider.getName().equals("Blu Bill Payment"))
                    addToProductList(product.getName(), provider.getName());
                if (provider.getName().equals("Syntell Account Payment"))
                    addToProductList(product.getName(), provider.getName());
            }

        }

        GridLayoutManager grid;

        if (getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            grid = new GridLayoutManager(getActivity(), 3);
        } else {
            grid = new GridLayoutManager(getActivity(), 2);
        }

        RecyclerView.LayoutManager manager = grid;

        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getActivity(), R.dimen.item_offset);
        recycler.addItemDecoration(itemDecoration);

        recycler.setLayoutManager(manager);

        Log.v("BaseActivity", "Final List: " + list.size());

        adapter = new BluRecyclerAdapter(getBaseActivity(), list);

        recycler.setAdapter(adapter);

    }

    private void addToProductList(String product, String provider) {

        String shortname = getBaseActivity().getShortName(product);
        int resId = getBaseActivity().getDrawableResource(shortname);

        if (resId != 0) {
//            Log.v(TAG, "Short Name:" + shortname);
            if (!shortname.isEmpty()) {
                int colorResId = getBaseActivity().getColourResource(shortname);
                list.add(new CardViewBillPayment(product, "", resId, colorResId, "", "bill_payment", "Bill", "Traffic Fine", provider));
            } else {
                list.add(new CardViewBillPayment(getBaseActivity(), product, "", resId, "", "bill_payment", "Bill", "Traffic Fine", provider));
            }
        } else {
            resId = getBaseActivity().getDrawableResource("default_transact");
            list.add(new CardViewBillPayment(getBaseActivity(), product, "", resId, "", "bill_payment", "Bill", "Traffic Fine", provider));
        }
    }

    @Override
    public boolean onBackPressed() {
        getBaseActivity().gotoMainScreen();
        return true;
    }


}
