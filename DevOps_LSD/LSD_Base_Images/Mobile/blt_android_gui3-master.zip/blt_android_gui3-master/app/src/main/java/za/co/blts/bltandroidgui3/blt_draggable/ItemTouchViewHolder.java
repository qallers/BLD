package za.co.blts.bltandroidgui3.blt_draggable;

/**
 * Created by warrenm on 2016/12/02.
 */

public interface ItemTouchViewHolder {
    void onItemSelected();

    void onItemClear();
}
