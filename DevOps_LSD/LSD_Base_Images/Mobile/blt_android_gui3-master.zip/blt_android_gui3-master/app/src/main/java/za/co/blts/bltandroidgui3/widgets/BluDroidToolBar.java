package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//
// view and button stuff
//


public class BluDroidToolBar extends Toolbar implements BluDroidSetupable {
    @SuppressWarnings("FieldCanBeLocal")
    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference = null;

    public void setContext(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    public void setup() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                setBackgroundColor(baseActivity.getSkinResources().getButtonColor());
                setTitleTextColor(baseActivity.getSkinResources().getButtonTextColor());
                setSubtitleTextColor(baseActivity.getSkinResources().getButtonTextColor());
                removeAppLogo();

                Drawable drawable = getOverflowIcon();
                if (drawable != null) {
                    drawable.setColorFilter(baseActivity.getSkinResources().getButtonTextColor(), Mode.MULTIPLY);
                    setOverflowIcon(drawable);
                }
            }
        }
    }

    private TextView getTitleTextView(Toolbar toolbar) {
        try {
            Class<?> toolbarClass = Toolbar.class;
            Field titleTextViewField = toolbarClass.getDeclaredField("mTitleTextView");
            titleTextViewField.setAccessible(true);
            return (TextView) titleTextViewField.get(toolbar);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }

        return null;
    }

    private void scaleUp() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                //Mod to gui for  7" % 8" touchscreen devices
                if (baseActivity.getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
                    TextView textView = getTitleTextView(this);
                    int textSize = (baseActivity.getSkinResources().getTextSize() * 3) / 3;
                    if (textView != null) {

                        textView.setTextSize(textSize);
                    }
                }
            }
        }
    }

    public void setTextColorWarning() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                setTitleTextColor(baseActivity.getSkinResources().getAccentColor());
            }
        }
    }

    public void setTextColorWhite() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                setTitleTextColor(baseActivity.getSkinResources().getButtonTextColor());
            }
        }
    }

    @Override
    public void setTitle(CharSequence title) {
        super.setTitle(title);
        //baseActivity.setTitle(title);
        scaleUp();
    }

    public BluDroidToolBar(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setup();

    }

    //
// http://stackoverflow.com/questions/10254748/how-to-extend-an-android-button-and-use-an-xml-layout-file
//
    public BluDroidToolBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (context instanceof BaseActivity) {
            try {
                this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
                setup();
            } catch (Exception exception) {
                Log.d(TAG, "BluDroidToolBar exception " + exception);
            }
        } else {
            Log.d(TAG, "context type is " + context.getClass().getName());
        }
    }

    public void setNavigationDrawable() {
        setNavigationIcon(getResources().getDrawable(R.drawable.ic_menu));
        getNavigationIcon().setColorFilter(getResources().getColor(R.color.white), Mode.SRC_IN);
    }


    public void setNavigationCloseIcon() {
        setNavigationIcon(R.drawable.ic_action_close);
    }

    public void setNavigationBackIcon() {
        setNavigationIcon(R.drawable.ic_action_back);
    }

    public void removeNavigationIcon() {
        setNavigationIcon(null);
    }

    public void setWarnIcon() {
        if (baseActivityWeakReference != null) {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                Drawable warning = baseActivity.getResources().getDrawable(R.drawable.warning);
                warning.setColorFilter(baseActivity.getSkinResources().getAccentColor(), PorterDuff.Mode.SRC_ATOP);
                setLogo(warning);
            }
        }
    }

    public void removeAppLogo() {
        setLogo(null);
    }


}

