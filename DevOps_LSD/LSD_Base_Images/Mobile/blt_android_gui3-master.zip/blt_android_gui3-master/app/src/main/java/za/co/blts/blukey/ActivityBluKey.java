package za.co.blts.blukey;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.net.http.SslError;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.gson.Gson;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BLUKEY_URL;

public class ActivityBluKey extends BaseActivity implements View.OnClickListener {
    private final String TAG = this.getClass().getSimpleName();
    private WebView webview;


    @SuppressLint({"ClickableViewAccessibility", "SetJavaScriptEnabled"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant_portal);

        findViewById(R.id.btnBack).setOnClickListener(this);
        findViewById(R.id.btnRefresh).setOnClickListener(this);
        findViewById(R.id.btnClose).setOnClickListener(this);

        createProgress("Loading");
        Log.d(TAG, "loading webview");
        webview = findViewById(R.id.webview);
        WebSettings settings = webview.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setDefaultTextEncodingName("utf-8");
        settings.setDomStorageEnabled(true);

        Log.d(TAG, "user-agent: " + settings.getUserAgentString());


        String url = getPreference(PREF_BLUKEY_URL);
        logger.info("launching merchant portal: " + url);
        Log.d(TAG, "launching merchant portal: " + url);

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webview, true);
        } else {
            CookieManager.getInstance().setAcceptCookie(true);
        }

        webview.loadUrl(url);

        webview.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                resetTimer();
                return false;
            }
        });


        webview.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView view, String url) {
                //this is called when page loading ends, even if an error occurred
                Log.d(TAG, "loading completed");
                resetTimer();
                dismissProgress();
                logger.info("merchant portal loaded in webview");
                Log.d(TAG, "merchant portal loaded in webview");

            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                //this is called on an error in later webview versions (eg P1 running webview 62)
                //eg connection drop: ERR_CONNECTION_TIMED_OUT (-8)
                // disconnected: ERR_INTERNET_DISCONNECTED (-2)
                // wrong url: ERR_NAME_NOT_RESOLVED (-2)
                // firewall/apn no permission: ERR_TIMED_OUT (-8)
                Log.e(TAG, "onReceivedError1: " + (error == null ? "null" : new Gson().toJson(error)));
                logger.error("error loading merchant portal onReceivedError1: " + (error == null ? "null" : new Gson().toJson(error)));
                dismissProgress();
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                //this is called on an error in earlier webview versions (eg V1 and N3 running webview 39)
                Log.e(TAG, "onReceivedError2: " + errorCode + " " + description);
                logger.error("error loading merchant portal onReceivedError2: " + errorCode + " " + description);
                dismissProgress();
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse error) {
                //http errors are handled by the merchant portal itself, do not need to do anything
                Log.e(TAG, "onReceivedHttpError: " + (error == null ? "null" : new Gson().toJson(error)));
                logger.error("error loading merchant portal onReceivedHttpError: " + (error == null ? "null" : new Gson().toJson(error)));
                dismissProgress();
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                Log.e(TAG, "onReceivedSslError: " + (error == null ? "null" : new Gson().toJson(error)));
                logger.error("error loading merchant portal onReceivedSslError: " + (error == null ? "null" : new Gson().toJson(error)));
                dismissProgress();
            }
        });

    }

    @Override
    public void onBackPressed() {
        webview.goBack();
    }

    @Override
    public void onClick(View view) {
        resetTimer();
        switch (view.getId()) {
            case R.id.btnBack:
                Log.d(TAG, "Back clicked");
                webview.goBack();
                break;

            case R.id.btnRefresh:
                Log.d(TAG, "Refresh clicked");
                createProgress("Loading");
                webview.reload();
                break;

            case R.id.btnClose:
                Log.d(TAG, "Close clicked");
                alert = exitApplicationDialog("Exit BluKey", "Are you sure you want to leave BluKey?");
                alert.setPositiveOption(getString(R.string.exit), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        alert.dismiss();
                        dismissProgress();
                        finish();
                    }
                });
                alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        alert.dismiss();
                    }
                });
                alert.show();
                break;
        }
    }
}
