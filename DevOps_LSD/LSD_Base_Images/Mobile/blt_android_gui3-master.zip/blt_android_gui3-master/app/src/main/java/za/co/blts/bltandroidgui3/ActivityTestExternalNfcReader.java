package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;
import za.co.blts.loyalty.BluDroidNFCCardAsyncResponse;
import za.co.blts.loyalty.ExternalNFCCard;

public class ActivityTestExternalNfcReader extends BaseActivity implements View.OnClickListener, BluDroidNFCCardAsyncResponse {
    private final String TAG = this.getClass().getSimpleName();

    private ExternalNFCCard card;

    private BluDroidTextView txtCardNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_external_nfc_reader);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        txtCardNumber = findViewById(R.id.txtCardNumber);

        BluDroidButton btnRefresh = findViewById(R.id.btnRefresh);
        btnRefresh.setOnClickListener(this);

        card = new ExternalNFCCard(this);
        card.setDelegate(this);
        card.openReader();
    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onCardNumberRead(String cardNumber) {
        Log.i(TAG, "returned: " + cardNumber);
        txtCardNumber.setText(cardNumber);
    }

    @Override
    public void onError(String msg) {
        Toast.makeText(this, "Error: " + msg, Toast.LENGTH_SHORT).show();
        card.closeReader();
    }

    @Override
    public void onReady() {
        Toast.makeText(this, "External NFC Reader is ready", Toast.LENGTH_SHORT).show();
        card.startListener();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        card.closeReader();
    }

    @Override
    public void onBackPressed() {
        gotoTestPeripheralsScreen();
    }
}
