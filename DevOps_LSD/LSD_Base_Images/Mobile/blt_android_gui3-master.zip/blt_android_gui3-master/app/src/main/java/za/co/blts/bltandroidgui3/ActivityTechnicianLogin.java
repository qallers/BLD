package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;

import za.co.blts.bltandroidgui3.widgets.BluDroidFlowable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTechPinEditText;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TECH_PIN;

public class ActivityTechnicianLogin extends BaseActivity implements BluDroidFlowable {

    private final String TAG = this.getClass().getSimpleName();

    private BluDroidTechPinEditText techLoginPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_technician_login);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);


        toolbar = findViewById(R.id.toolbar);
        String title = "Technician Sign-In";
        toolbar.setTitle(title);
        toolbar.setNavigationCloseIcon();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                gotoLandingScreen();
            }
        });


        techLoginPassword = findViewById(R.id.techLoginPassword);

        techLoginPassword.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    switch (keyCode) {
                        case KeyEvent.KEYCODE_DPAD_CENTER:
                        case KeyEvent.KEYCODE_ENTER:

                            if (techLoginPassword.validate()) {

                                loginTechnician(techLoginPassword.getText().toString());
                            }

                            return true;
                        default:
                            break;
                    }
                }
                return false;
            }
        });

    }

    @Override
    public void onBackPressed() {
        gotoLandingScreen();
    }

    private void loginTechnician(String pin) {
        String errorMesage;

        if (getPreference(PREF_TECH_PIN).equals(pin.trim())) {

            gotoTechnicianSettingsScreen();

        } else {
            techLoginPassword.setText("");
            errorMesage = getString(R.string.techPinInvalid);
            techLoginPassword.setErrorMessage(errorMesage);
        }

    }


    @Override
    public void flow(View view) {

        cancelTimer();
        Log.d(TAG, "flow called now calling login technician");
        loginTechnician(((BluDroidTechPinEditText) view).getText().toString().trim());
        Log.d(TAG, "Technician login called");
    }
}
