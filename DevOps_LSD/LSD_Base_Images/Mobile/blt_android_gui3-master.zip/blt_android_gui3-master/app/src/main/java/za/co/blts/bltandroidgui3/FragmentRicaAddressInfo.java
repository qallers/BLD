package za.co.blts.bltandroidgui3;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidScrollView;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentRicaAddressInfo extends BaseFragment {

    private final String TAG = this.getClass().getSimpleName();

    public BluDroidEditText addressLine1, addressLine2, suburb, city, postalCode;
    public String selectedProvince, selectedCounty;

    public BluDroidRelativeLayout layout;
    public BluDroidLinearLayout bottomPortionLayout;

    private ViewGroup viewGroup;

    public FragmentRicaAddressInfo() {
        // Required empty public constructor
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        bottomPortionLayout = getView().findViewById(R.id.addressBottomPortionLayout);
        layout = getView().findViewById(R.id.layout);

        addressLine1 = getView().findViewById(R.id.addressLine1);
        addressLine2 = getView().findViewById(R.id.addressLine2);
        suburb = getView().findViewById(R.id.suburb);
        city = getView().findViewById(R.id.city);
        postalCode = getView().findViewById(R.id.postalCode);

        BluDroidSpinner provinceSpinner = getView().findViewById(R.id.provinceSpinner);
        BluDroidSpinner countrySpinner = getView().findViewById(R.id.countrySpinner);

        final String[] provinces = getResources().getStringArray(R.array.provinces);
        ArrayAdapter<String> provincesAdapter = new ArrayAdapter<>(getBaseActivity(), R.layout.spinner_item, provinces);
        provinceSpinner.setAdapter(provincesAdapter);
        provinceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                selectedProvince = adapterView.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                selectedProvince = "";
            }
        });


        final String[] countries = getResources().getStringArray(R.array.countryCodes);
        ArrayAdapter<String> countriesAdapter = new ArrayAdapter<>(getBaseActivity(), R.layout.spinner_item, countries);
        countrySpinner.setAdapter(countriesAdapter);
        countrySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                selectedCounty = adapterView.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                selectedCounty = "";
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_rica_address_info, container, false);
        viewGroup = container;
        return v;
    }

    public void clearAll() {
        View view;
        if (viewGroup != null) {

            for (int i = 0; i <= viewGroup.getChildCount(); i++) {

                view = viewGroup.getChildAt(i);

                if (view instanceof BluDroidRelativeLayout) {

                    BluDroidRelativeLayout layout = (BluDroidRelativeLayout) view;

                    for (int j = 0; j <= layout.getChildCount(); j++) {

                        view = layout.getChildAt(j);

                        if (view instanceof BluDroidScrollView) {

                            BluDroidScrollView scrollView = (BluDroidScrollView) view;

                            for (int k = 0; k <= scrollView.getChildCount(); k++) {

                                view = scrollView.getChildAt(k);

                                if (view instanceof BluDroidLinearLayout) {

                                    BluDroidLinearLayout lin = (BluDroidLinearLayout) view;

                                    for (int l = 0; l <= lin.getChildCount(); l++) {

                                        view = lin.getChildAt(l);

                                        if (view instanceof BluDroidEditText) {

                                            BluDroidEditText editText = (BluDroidEditText) view;
                                            editText.setText("");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public boolean onBackPressed() {

        getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentRicaConsumerInfo(), "FragmentRicaRegister").commit();
        return true;

    }

}
