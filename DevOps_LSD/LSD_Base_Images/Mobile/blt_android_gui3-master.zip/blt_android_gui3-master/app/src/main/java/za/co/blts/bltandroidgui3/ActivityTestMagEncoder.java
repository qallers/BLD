package za.co.blts.bltandroidgui3;

import android.os.Build;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import sunmi.paylib.SunmiPayKernel;
import za.co.blts.magcard.BluDroidMagCardAsyncReponse;
import za.co.blts.magcard.MagCard;
import za.co.blts.magcard.NexgoN3MagCard;
import za.co.blts.magcard.P1MagCard;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MAG_READER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

public class ActivityTestMagEncoder extends BaseActivity implements BluDroidMagCardAsyncReponse {

    private final String TAG = this.getClass().getName();
    private EditText txtTrack1, txtTrack2, txtTrack3;
    private boolean usingExternalEncoder = true;
    private SunmiPayKernel mSunmiPayKernel = null;

    //----------------------------------------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.MODEL.startsWith("CITAQ")) {
            magCard = new MagCard(this);
            usingExternalEncoder = true;
        } else if (Build.MODEL.startsWith("N3")) {
            magCard = new NexgoN3MagCard(this);
            usingExternalEncoder = false;
        } else if (Build.MODEL.startsWith("P1")) {

            //use external mag encoder
            if (getPreference(PREF_MAG_READER).equals(PREF_TRUE)) {
                magCard = new MagCard(this);
                usingExternalEncoder = true;
            } else {
                //use internal mag encoder
                magCard = new P1MagCard(this);
                usingExternalEncoder = false;
                conn();
            }
        } else {
            Toast.makeText(this, "Mag encoder not supported", Toast.LENGTH_SHORT).show();
            gotoTestPeripheralsScreen();
            return;
        }


        magCard.setDelegate(this);

        setContentView(R.layout.activity_test_mag_encoder);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        TextView txtDebug = findViewById(R.id.txtDebug);
        txtDebug.setMovementMethod(new ScrollingMovementMethod());

        txtTrack1 = findViewById(R.id.txtTrack1);
        txtTrack2 = findViewById(R.id.txtTrack2);
        txtTrack3 = findViewById(R.id.txtTrack3);

        Button btnConnect = findViewById(R.id.btnConnect);
        btnConnect.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.openUsbSerial();

            }
        });

        Button btnReset = findViewById(R.id.btnReset);
        btnReset.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.resetMsr();
            }
        });

        Button btnCheck = findViewById(R.id.btnCheck);
        btnCheck.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.sendCheckCommsReq();
            }
        });

        Button btnModel = findViewById(R.id.btnModel);
        btnModel.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.sendModelReq();
            }
        });

        Button btnHico = findViewById(R.id.btnHico);
        btnHico.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.setHiCo();
            }
        });

        Button btnLoco = findViewById(R.id.btnLoco);
        btnLoco.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.setLoCo();
            }
        });

        Button btnStatus = findViewById(R.id.btnStatus);
        btnStatus.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.sendHiLoCoStatusReq();
            }
        });

        Button btnErase = findViewById(R.id.btnErase);
        btnErase.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.eraseCard(true, true, true);
            }
        });

        Button btnLedOff = findViewById(R.id.btnLedOff);
        btnLedOff.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.setLedOff();
            }
        });

        Button btnLedOn = findViewById(R.id.btnLedOn);
        btnLedOn.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.sendLedCommand(true, true, true);
            }
        });

        Button btnLedGreen = findViewById(R.id.btnLedGreen);
        btnLedGreen.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.sendLedCommand(true, false, false);
            }
        });

        Button btnLedYellow = findViewById(R.id.btnLedYellow);
        btnLedYellow.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.sendLedCommand(false, true, false);
            }
        });

        Button btnLedRed = findViewById(R.id.btnLedRed);
        btnLedRed.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.sendLedCommand(false, false, true);
            }
        });

        Button btnRead = findViewById(R.id.btnRead);
        btnRead.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                magCard.sendReadCommand();
                createMagEncoderAlertDialog("Mag Card", "Please swipe card to read");
            }
        });

        Button btnWrite = findViewById(R.id.btnWrite);
        btnWrite.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {

                String track1 = txtTrack1.getText().toString();
                String track2 = txtTrack2.getText().toString();
                String track3 = txtTrack3.getText().toString();

                List<String> list = new ArrayList<>();
                list.add(track1);
                list.add(track2);
                list.add(track3);

                magCard.setTracks(list);
                magCard.sendWriteCommand();

                createMagEncoderAlertDialog("Mag Card", "Please swipe card to write");
            }
        });
        btnWrite.setEnabled(usingExternalEncoder);

        Button btnFill = findViewById(R.id.btnFill);
        btnFill.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                String tk2 = "600727010500200157===0107100010011";
                String tk3 = "12345678901234567890";
                txtTrack1.setText("");
                txtTrack2.setText(tk2);
                txtTrack3.setText(tk3);
            }
        });

        Button btnClear = findViewById(R.id.btnClear);
        btnClear.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                txtTrack1.setText("");
                txtTrack2.setText("");
                txtTrack3.setText("");
            }
        });

        // check USB host function.
        if (!magCard.featureSupported()) {

            Toast.makeText(this, "No Support USB host API", Toast.LENGTH_SHORT).show();

            Log.d(TAG, "No Support USB host API");
        }

        Log.d(TAG, "Leave onCreate");
    }

    private void conn() {
        mSunmiPayKernel = SunmiPayKernel.getInstance();
        mSunmiPayKernel.connectPayService(getApplicationContext(), mConnCallback);
    }

    /**
     *
     */
    private SunmiPayKernel.ConnCallback mConnCallback = new SunmiPayKernel.ConnCallback() {
        @Override
        public void onServiceConnected() {
            try {
                BluDroidApplication.mReadCardOpt = mSunmiPayKernel.mReadCardOpt;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected() {
        }
    };

    //----------------------------------------------------------------------------------------------
    protected void onStop() {
        Log.d(TAG, "Enter onStop");
        super.onStop();
        Log.d(TAG, "Leave onStop");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    protected void onDestroy() {
        Log.d(TAG, "Enter onDestroy");

        if (magCard != null && magCard.isOpen()) {
            magCard.closeAdapter();
        }

        super.onDestroy();
        Log.d(TAG, "Leave onDestroy");
    }

    //----------------------------------------------------------------------------------------------
    public void onStart() {
        Log.d(TAG, "Enter onStart");
        super.onStart();
        Log.d(TAG, "Leave onStart");
    }

    //----------------------------------------------------------------------------------------------
    public void onResume() {
        Log.d(TAG, "Enter onResume");
        super.onResume();
        String action = getIntent().getAction();
        Log.d(TAG, "onResume:" + action);
        if (usingExternalEncoder && magCard != null) {
            if (!magCard.isConnected()) {
                Log.d(TAG, "New instance of adapter");

                if (!magCard.enumerate()) {

//                    createAlertDialog("Mag Card", "No devices found, please check if mag encoder is connected");
                    createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorMagEncoder, false);
                    //  Toast.makeText(this, "no more devices found", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    Log.d(TAG, "onResume:enumerate succeeded!");
                }
            }//if isConnected
            Toast.makeText(this, "attached", Toast.LENGTH_SHORT).show();
            magCard.openUsbSerial();

            Log.d(TAG, "Leave onResume");
        }
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void processFinish(String output) {

        if (alert != null) {
            alert.dismiss();
        }
        createAlertDialog("Mag Card", output);

        txtTrack1.setText(magCard.getTracks().get(0));
        txtTrack2.setText(magCard.getTracks().get(1));
        txtTrack3.setText(magCard.getTracks().get(2));
    }
    //----------------------------------------------------------------------------------------------


    @Override
    public void onBackPressed() {
        gotoTestPeripheralsScreen();
    }
}
