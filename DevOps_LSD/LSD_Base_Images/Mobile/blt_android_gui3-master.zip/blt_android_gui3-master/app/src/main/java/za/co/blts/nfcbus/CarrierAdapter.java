package za.co.blts.nfcbus;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListCarriersResponseCompanyMessage;


class CarrierAdapter extends ArrayAdapter<NfcBusListCarriersResponseCompanyMessage> {
    private final String TAG = this.getClass().getSimpleName();

    public CarrierAdapter(Context context, int layoutResourceId, ArrayList<NfcBusListCarriersResponseCompanyMessage> dataSet) {
        super(context, layoutResourceId, dataSet);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final NfcBusListCarriersResponseCompanyMessage carrier = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_spinner_dropdown_item, parent, false);
        }
        TextView textCarrierName = convertView.findViewById(android.R.id.text1);
        textCarrierName.setText(carrier.getName());

        return convertView;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        final NfcBusListCarriersResponseCompanyMessage carrier = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_spinner_dropdown_item, parent, false);
        }
        TextView textCarrierName = convertView.findViewById(android.R.id.text1);
        textCarrierName.setText(carrier.getName());

        return convertView;
    }

}
