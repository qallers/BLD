package za.co.blts.bltandroidgui3;


import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.net.Socket;
import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseEventsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseParentAllEventMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTicketProEvents extends TicketProRecycler implements NeedsAEONResults {

    private final String TAG = this.getClass().getSimpleName();

    private ListView listView;

    private ArrayList<TicketProResponseParentAllEventMessage> categoryEventsList;

    public FragmentTicketProEvents() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View rootView = inflater.inflate(R.layout.fragment_ticket_pro_events, container, false);

        listView = rootView.findViewById(R.id.eventsList);
        BluDroidButton btnBack = rootView.findViewById(R.id.back);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                getBaseActivity().gotoFragment(new FragmentTicketProCategories(), "FragmentTicketProCategories");
            }
        });

        getBaseActivity().isTicketProReprint = false;

        getTicketProEvents(getBaseActivity().ticketProCategoryId);

        return rootView;
    }

    @Override
    public void onDestroy() {
        if (listView != null) listView.setAdapter(null);
        super.onDestroy();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        Log.i(TAG, "onCreate");
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            grid = new GridLayoutManager(getActivity(), 2);
        } else {
            grid = new GridLayoutManager(getActivity(), 1);
        }

//        getBaseActivity().toolbar.setNavigationDrawable();
//        getBaseActivity().toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                getBaseActivity().gotoMenuFragment();
//            }
//        });

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void getTicketProEvents(String categoryID) {

        try {
            // getBaseActivity().createProgress(R.string.gettingTicketProEvents);
            //
            // get events for this category
            //

            categoryEventsList = new ArrayList<>();

            for (TicketProResponseParentAllEventMessage ticketProResponseParentAllEventMessage : getBaseActivity().ticketProResponseAllEventsMessage.getData().getEvents()) {
                if (ticketProResponseParentAllEventMessage.getCategoryId().equalsIgnoreCase(categoryID)) {

                    categoryEventsList.add(ticketProResponseParentAllEventMessage);
                }

            }

            BluDroidTicketProEventsListAdapter ticketProEventsListAdapter = new BluDroidTicketProEventsListAdapter(getBaseActivity(), R.layout.event_row_item, categoryEventsList);
            listView.setAdapter(ticketProEventsListAdapter);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    //getBaseActivity().ticketProEvent = categoryEventsList.get(position);
                    getBaseActivity().ticketProAllProEvent = categoryEventsList.get(position);

                    //ignore sold out check since this is cached data
//                    if (getBaseActivity().ticketProAllProEvent.getSoldOut().equalsIgnoreCase("false")) {
                    getBaseActivity().gotoFragment(new FragmentTicketProEventDetails(), "FragmentTicketProEventDetails");
//                     }else{
//                        getBaseActivity().createAlertDialog("Event sold out","Sorry. This Event has been sold out.");
//                     }


                }
            });

        } catch (Exception exception) {
            Log.v(TAG, "problem trying to authenticate " + exception);
        }
    }

    public void results(Object object) {

        try {
            Log.d(TAG, "results object " + object);
            Log.d(TAG, "(Events) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }
        if (object instanceof Socket) {
            BaseActivity.socket = (Socket) object;
        } else if (object instanceof TicketProResponseEventsMessage) {
            getBaseActivity().dismissProgress();
            // configureActionBar(getResources().getString(R.string.ticketpro) + ": " + categoryName.replaceAll("\n", " "));
            getBaseActivity().ticketProResponseEventsMessage = (TicketProResponseEventsMessage) object;

            //
            // do not remove this log message
            // it iis used for testing purposes
            //
            Log.d(TAG, "TEST : RECEIVED TICKETPRO EVENTS LIST");
        }

        if (object != null && !(object instanceof Socket)) {
            getBaseActivity().firebaseBundle = new Bundle();
            getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            getBaseActivity().mFirebaseAnalytics.logEvent("aeon_connection", getBaseActivity().firebaseBundle);
        }

    }

    @Override
    public boolean onBackPressed() {

        getBaseActivity().gotoFragment(new FragmentTicketProCategories(), "FragmentTicketProCategories");

        return true;
    }
}
