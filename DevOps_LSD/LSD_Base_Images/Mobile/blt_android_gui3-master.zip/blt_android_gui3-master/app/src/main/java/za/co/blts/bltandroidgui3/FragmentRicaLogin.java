package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidPasswordEditText;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_PASSWORD;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_USERNAME;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_UNKNOWN;

/**
 * Created by warrenm on 2016/10/03.
 */

public class FragmentRicaLogin extends BaseFragment {

    private final String TAG = this.getClass().getSimpleName();

    private String username;
    private String password;

    private BluDroidEditText usernameEditText;
    private BluDroidPasswordEditText passwordEditText;

    public FragmentRicaLogin() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(za.co.blts.bltandroidgui3.R.layout.fragment_rica_login, container, false);

        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), TAG, null);

        getBaseActivity().toolbar = getActivity().findViewById(R.id.toolbar);

        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();
        usernameEditText = rootView.findViewById(R.id.userName);
        passwordEditText = rootView.findViewById(R.id.password);

        passwordEditText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER) {
                    username = usernameEditText.getText().toString().trim();
                    password = passwordEditText.getText().toString().trim();

                    getBaseActivity().authenticateRica(username, password);
                }
                return false;
            }
        });

        BluDroidButton btnLogin = rootView.findViewById(R.id.signIn);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                BaseActivity.logger.info(((BluDroidButton) view).getText());
                Log.d(TAG, "onClick() rica manual login");
                username = usernameEditText.getText().toString().trim();
                password = passwordEditText.getText().toString().trim();
                getBaseActivity().authenticateRica(username, password);
            }
        });
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        String title = getActivity().getResources().getString(R.string.rica);
        getActivity().setTitle(title);

        if (!getPreference(PREF_RICA_USERNAME + "_" + getBaseActivity().firstTwoDigitsPin()).equals(PREF_UNKNOWN) &&
                !getPreference(PREF_RICA_PASSWORD + "_" + getBaseActivity().firstTwoDigitsPin()).equals(PREF_UNKNOWN)) {
            String username = getBaseActivity().getEncryptedPreference(PREF_RICA_USERNAME + "_" + getBaseActivity().firstTwoDigitsPin());
            String password = getBaseActivity().getEncryptedPreference(PREF_RICA_PASSWORD + "_" + getBaseActivity().firstTwoDigitsPin());

            if (username != null && password != null) {
                Log.d(TAG, "onClick() rica auto login");
                usernameEditText.setText(username);
                passwordEditText.setText(password);
                getBaseActivity().authenticateRica(username, password);
            }
        }
    }

    @Override
    public boolean onBackPressed() {
        BaseActivity.logger.info("onBackPressed()");
        getBaseActivity().gotoMainScreen();
        return true;
    }
}