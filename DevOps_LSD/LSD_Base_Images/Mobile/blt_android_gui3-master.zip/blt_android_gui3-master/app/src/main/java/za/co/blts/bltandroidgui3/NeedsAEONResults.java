package za.co.blts.bltandroidgui3;

//
// needs results from AEON
//
public interface NeedsAEONResults {

    void results(Object object);

    void error(Object object);

}
