package za.co.blts.bltandroidgui3;

import android.os.Build;
import android.util.Log;

import androidx.recyclerview.widget.GridLayoutManager;

import java.util.ArrayList;

import za.co.blts.bltandroidgui3.cardviews.CardViewBillPayment;
import za.co.blts.bltandroidgui3.cardviews.CardViewEasyHealth;
import za.co.blts.bltandroidgui3.cardviews.CardViewElectricity;
import za.co.blts.bltandroidgui3.cardviews.CardViewOTT;
import za.co.blts.bltandroidgui3.cardviews.CardviewAdvinne;
import za.co.blts.bltandroidgui3.cardviews.CardviewAfricaPin;
import za.co.blts.bltandroidgui3.cardviews.CardviewAxxess;
import za.co.blts.bltandroidgui3.cardviews.CardviewBetFlash;
import za.co.blts.bltandroidgui3.cardviews.CardviewBluVoucher;
import za.co.blts.bltandroidgui3.cardviews.CardviewCallAll;
import za.co.blts.bltandroidgui3.cardviews.CardviewCellC;
import za.co.blts.bltandroidgui3.cardviews.CardviewConnect;
import za.co.blts.bltandroidgui3.cardviews.CardviewDabba;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.cardviews.CardviewDefaultAirtime;
import za.co.blts.bltandroidgui3.cardviews.CardviewDefaultData;
import za.co.blts.bltandroidgui3.cardviews.CardviewFNBConnect;
import za.co.blts.bltandroidgui3.cardviews.CardviewHollywoodBets;
import za.co.blts.bltandroidgui3.cardviews.CardviewLottoStar;
import za.co.blts.bltandroidgui3.cardviews.CardviewLycaMobile;
import za.co.blts.bltandroidgui3.cardviews.CardviewMTN;
import za.co.blts.bltandroidgui3.cardviews.CardviewMyAir;
import za.co.blts.bltandroidgui3.cardviews.CardviewNeotel;
import za.co.blts.bltandroidgui3.cardviews.CardviewRingas;
import za.co.blts.bltandroidgui3.cardviews.CardviewStarSat;
import za.co.blts.bltandroidgui3.cardviews.CardviewSupabets;
import za.co.blts.bltandroidgui3.cardviews.CardviewTelkom;
import za.co.blts.bltandroidgui3.cardviews.CardviewTelkomWorldCard;
import za.co.blts.bltandroidgui3.cardviews.CardviewTheUnlimited;
import za.co.blts.bltandroidgui3.cardviews.CardviewUnipin;
import za.co.blts.bltandroidgui3.cardviews.CardviewVirgin;
import za.co.blts.bltandroidgui3.cardviews.CardviewVodacom;
import za.co.blts.bltandroidgui3.cardviews.CardviewVoucherMenu;

/**
 * Created by NkosanaM on 3/17/2017.
 */

class FavouritesRecycler extends VoucherRecycler {

    private final String TAG = this.getClass().getSimpleName();

    int favouritesSize;

    void setupRecycler() {

        if (Build.MODEL.startsWith("CITAQ")) {
            grid = new GridLayoutManager(getActivity(), 4);
        }

        configureRecycler(createFavoriteCards(retrieveRawData()));
    }

    private ArrayList<String> retrieveRawData() {

        ArrayList<String> rawData = null;
        if (BaseActivity.loginResponseMessage != null) {
            if (BaseActivity.completeConsumerProfile != null && BaseActivity.completeConsumerProfile.getFavourites() != null && BaseActivity.consumerProfile != null && Integer.parseInt(BaseActivity.consumerProfile.getProfileId()) > 0) {
                rawData = getBaseActivity().getConsumerFavouritesList(); // there is an active consumer
            } else {
                Log.d("FavsReadCall", "retrieveRawData");
                rawData = getBaseActivity().getFavouritesList(); // the normal
            }
        }
        favouritesSize = rawData == null ? 0 : rawData.size();
        return rawData;
    }

    private ArrayList<CardviewDataObject> createFavoriteCards(ArrayList<String> rawData) {

        ArrayList<CardviewDataObject> list = new ArrayList<>();

        String topup = getResources().getString(R.string.topup);
        String anyAmount = getResources().getString(R.string.anyAmount);

        if (rawData != null) {
            for (String data : rawData) {

                String[] dataArray = data.split(";");
                String cardDesc = ((getBaseActivity().sanitize(dataArray[0]).equals("N/A")) ? "" : getBaseActivity().sanitize(dataArray[0]));
                String cardValue = ((getBaseActivity().sanitize(dataArray[1]).equals("N/A")) ? "" : getBaseActivity().sanitize(dataArray[1]));
                String stockId = ((getBaseActivity().sanitize(dataArray[2]).equals("N/A")) ? "" : getBaseActivity().sanitize(dataArray[2]));
                String voucherType = ((getBaseActivity().sanitize(dataArray[3]).equals("N/A")) ? "" : getBaseActivity().sanitize(dataArray[3]));
                String tag = ((getBaseActivity().sanitize(dataArray[4]).equals("N/A")) ? "" : getBaseActivity().sanitize(dataArray[4]));
                String voucherTypeDesc = ((getBaseActivity().sanitize(dataArray[5]).equals("N/A")) ? "" : getBaseActivity().sanitize(dataArray[5]));
                String provider = ((getBaseActivity().sanitize(dataArray[6]).equals("N/A")) ? "" : getBaseActivity().sanitize(dataArray[6]));

//                boolean hasAirtimePlus = getBaseActivity().isAirtimePlusAllowed;
                boolean hasAirtimePlus = checkAirtimePlus(tag);

                Log.d("kuijkenfav", data + " >>>>> " + hasAirtimePlus);

                if (tag.equals("Vodacom") || tag.contains("Vodacom")) {
                    if (voucherType.equals("Data")) {
                        list.add(new CardviewVodacom(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    } else if (voucherType.equals("topup")) {
                        list.add(new CardviewVodacom(getBaseActivity(), cardDesc, anyAmount, "", topup, cardDesc, voucherTypeDesc, hasAirtimePlus));
                    } else {
                        list.add(new CardviewVodacom(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    }
                } else if (tag.equals("MTN") || tag.contains("MTN")) {
                    if (voucherType.equals("Data")) {
                        list.add(new CardviewMTN(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    } else if (voucherType.equals("topup")) {
                        list.add(new CardviewMTN(getBaseActivity(), cardDesc, anyAmount, "", topup, cardDesc, voucherTypeDesc, hasAirtimePlus));
                    } else {
                        list.add(new CardviewMTN(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    }
                } else if (tag.equals("Cell C") || tag.contains("CellC")) {
                    if (voucherType.equals("Data")) {
                        list.add(new CardviewCellC(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    } else if (voucherType.equals("topup")) {
                        list.add(new CardviewCellC(getBaseActivity(), cardDesc, anyAmount, "", topup, cardDesc, voucherTypeDesc, hasAirtimePlus));
                    } else {
                        list.add(new CardviewCellC(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    }
                } else if (tag.equals("Telkom Mobile") || tag.contains("TelkomMobile")) {
                    if (voucherType.equals("Data")) {
                        list.add(new CardviewTelkom(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    } else if (voucherType.equals("topup")) {
                        list.add(new CardviewTelkom(getBaseActivity(), cardDesc, anyAmount, "", topup, cardDesc, voucherTypeDesc, hasAirtimePlus));
                    } else {
                        list.add(new CardviewTelkom(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    }
                } else if (tag.equals("Telkom")) {
                    if (voucherType.equals("Data")) {
                        list.add(new CardviewTelkomWorldCard(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    } else if (voucherType.equals("topup")) {
                        list.add(new CardviewTelkomWorldCard(getBaseActivity(), cardDesc, anyAmount, "", topup, cardDesc, voucherTypeDesc, hasAirtimePlus));
                    } else {
                        list.add(new CardviewTelkomWorldCard(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    }
                } else if (tag.equals("Neotel") || tag.contains("Neotel")) {
                    if (voucherType.equals("Data")) {
                        list.add(new CardviewNeotel(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    } else if (voucherType.equals("topup")) {
                        list.add(new CardviewNeotel(getBaseActivity(), cardDesc, anyAmount, "", topup, cardDesc, voucherTypeDesc, hasAirtimePlus));
                    } else {
                        list.add(new CardviewNeotel(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    }
                } else if (tag.equals("Virgin Mobile")) {
                    if (voucherType.equals("Data")) {
                        list.add(new CardviewVirgin(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    } else if (voucherType.equals("topup")) {
                        list.add(new CardviewVirgin(getBaseActivity(), cardDesc, anyAmount, "", topup, cardDesc, voucherTypeDesc, hasAirtimePlus));
                    } else {
                        list.add(new CardviewVirgin(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    }
                } else if (tag.equals("UniPin")) {
                    list.add(new CardviewUnipin(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));

                } else if (tag.equals("Connect")) {
                    list.add(new CardviewConnect(cardDesc, cardValue, stockId, voucherType, tag, true, provider, hasAirtimePlus));

                } else if (tag.equals("BluVoucher")) {
                    list.add(new CardviewBluVoucher(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, false, stockId, hasAirtimePlus));

                } else {
                    if (voucherType.equals("munics")) {
                        if (cardDesc.equalsIgnoreCase("FBE")) {
                            list.add(new CardViewElectricity(getBaseActivity(), "Free Basic Electricity", "", "", "munics", "FBE", voucherTypeDesc));
                        } else if (cardDesc.contains("Eskom")) {
                            list.add(new CardViewElectricity(getBaseActivity(), cardDesc, "", R.drawable.eskom, "", "munics", tag, voucherTypeDesc));
                        } else if (cardDesc.equalsIgnoreCase("electricity")) {
                            list.add(new CardViewElectricity(getBaseActivity(), cardDesc, "", "", "munics", tag, voucherTypeDesc));
                        } else if (cardDesc.equalsIgnoreCase("tshwane")) {
                            list.add(new CardViewElectricity(getBaseActivity(), cardDesc, "", R.drawable.tshwane, "", "munics", tag, voucherTypeDesc));
                        } else if (cardDesc.equalsIgnoreCase("ekurhuleni")) {
                            list.add(new CardViewElectricity(getBaseActivity(), cardDesc, "", R.drawable.ekurhuleni, "", "munics", tag, voucherTypeDesc));
                        } else {
                            list.add(new CardViewElectricity(getBaseActivity(), cardDesc, "", "", "munics", tag, voucherTypeDesc));
                        }
                    } else if (voucherType.equalsIgnoreCase("Data")) {
                        list.add(new CardviewDefaultData(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    } else if (voucherTypeDesc.equalsIgnoreCase("Data")) {
                        list.add(new CardviewDefaultData(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    } else if (voucherType.equalsIgnoreCase("Menu")) {
                        if (cardDesc.equals("Axxess")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.axxess, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.equals("Hollywood Bets")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.hollywoodbets, R.color.hollywoodbets, cardDesc, cardDesc));
                        } else if (cardDesc.equals("Top TV")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.starsat, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.equals("Dabba")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.dabba, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.equals("LottoStar")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.lottostar, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.equals("xBetFlash")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.betflash, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.equals("ott")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ott, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.equals("AfricaPIN")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.africapin, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.equals("Ithuba")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ithuba, R.color.ithuba, getResources().getString(R.string.ithuba), getResources().getString(R.string.ithuba)));

                        } else if (cardDesc.equals("Telkom")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.telkom, R.color.telkom, cardDesc, cardDesc));
                        } else if (cardDesc.equals("MVNO")) {// use the
                            list.add(new CardviewVoucherMenu(getBaseActivity(), 0, R.color.telkom, cardDesc, cardDesc));
                        }
                        //<--------------chat for change providers------------!>
                        //we have included a hardcoded c4c string to distinguish between the vouchers hence the contains
                        else if (cardDesc.contains("Advinne")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.advinne, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.contains("FNBConnect")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.fnbconnect, R.color.fnbconnect, cardDesc, cardDesc));
                        } else if (cardDesc.contains("TheUnlimited")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.theunlimited, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.contains("MyAir")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.myair, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.contains("LycaMobile")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.lycamobile, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.toLowerCase().contains("ringas")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ringas, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.toLowerCase().contains("bluvoucher")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.bluvoucher, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.contains("CallAll")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.callall, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.contains("BluVoucher")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.bluvoucher, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.toLowerCase().contains("vodacom")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.vodacom, R.color.vodacom, cardDesc, cardDesc));
                        } else if (cardDesc.toLowerCase().contains("mtn")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.mtn, R.color.mtn, cardDesc, cardDesc));
                        } else if (cardDesc.toLowerCase().contains("cellc")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.cellc, R.color.cellc, cardDesc, cardDesc));
                        } else if (cardDesc.toLowerCase().contains("telkommobile")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.telkommobile, R.color.telkom, cardDesc, cardDesc));
                        }
//                        else if (cardDesc.equalsIgnoreCase("neotel")){
//                            list.add(new CardviewVoucherMenu(getBaseActivity(),R.drawable.neotel,R.color.neotel, cardDesc, cardDesc));
//                        }
//                        else if (cardDesc.equalsIgnoreCase("virgin mobile")){
//                            list.add(new CardviewVoucherMenu(getBaseActivity(),R.drawable.virgin,R.color.virgin, cardDesc, cardDesc));
//                        }
                        else if (cardDesc.equals("putco")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.putco, R.color.white, cardDesc, cardDesc));
                        } else if (cardDesc.equals("Events")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.tickets, R.color.black, cardDesc, cardDesc));

                        } else if (cardDesc.equals("Tickets")) {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.tickets, R.color.black, cardDesc, cardDesc));

                        } else {
                            list.add(new CardviewVoucherMenu(getBaseActivity(), cardDesc, cardDesc));
                        }
                    } else if (voucherType.equalsIgnoreCase("Voucher")) {
                        Log.d("MPKvouch", tag);
                        if (tag.equals("Axxess")) {

                            if (voucherTypeDesc.contains("Data")) {
                                list.add(new CardviewAxxess(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {
                                list.add(new CardviewAxxess(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        } else if (tag.equals("xHollywood Bets")) {

                            if (voucherTypeDesc.contains("Data")) {
                                list.add(new CardviewHollywoodBets(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {
                                list.add(new CardviewHollywoodBets(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        } else if (tag.equals("Top TV")) {

                            if (voucherTypeDesc.contains("Data")) {
                                list.add(new CardviewStarSat(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {

                                list.add(new CardviewStarSat(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        } else if (tag.equals("xDabba")) {

                            if (voucherTypeDesc.contains("Data")) {
                                list.add(new CardviewDabba(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {
                                list.add(new CardviewDabba(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        } else if (tag.equalsIgnoreCase("xSupabets")) {

                            if (voucherTypeDesc.contains("Data")) {
                                list.add(new CardviewSupabets(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {
                                list.add(new CardviewSupabets(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        } else if (tag.equals("xLottoStar")) {

                            if (voucherTypeDesc.contains("Data")) {
                                list.add(new CardviewLottoStar(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {
                                list.add(new CardviewLottoStar(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        } else if (tag.equalsIgnoreCase("ott")) {
                            if (voucherTypeDesc.contains("Data")) {
                                list.add(new CardViewOTT(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {
                                list.add(new CardViewOTT(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        } else if (tag.equalsIgnoreCase("Discovery Prepaid Health")) {
                            if (voucherTypeDesc.contains("Data")) {
                                list.add(new CardViewEasyHealth(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {
                                list.add(new CardViewEasyHealth(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        } else if (tag.equalsIgnoreCase("AfricaPin")) {

                            if (voucherTypeDesc.equals("Data")) {
                                list.add(new CardviewAfricaPin(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {
                                list.add(new CardviewAfricaPin(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        } else if (tag.equalsIgnoreCase("xBetFlash")) {

                            if (voucherTypeDesc.equals("Data")) {
                                list.add(new CardviewBetFlash(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {
                                list.add(new CardviewBetFlash(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        }


                        // Chat 4 Change Denominations
                        else if (tag.equalsIgnoreCase("Advinne")) {// use this
                            list.add(new CardviewAdvinne(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, voucherTypeDesc, true, provider, hasAirtimePlus));
                        } else if (tag.equalsIgnoreCase("FNBConnect")) {
                            list.add(new CardviewFNBConnect(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, voucherTypeDesc, true, provider, hasAirtimePlus));
                        } else if (tag.equalsIgnoreCase("TheUnlimited")) {
                            list.add(new CardviewTheUnlimited(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, voucherTypeDesc, true, provider, hasAirtimePlus));
                        } else if (tag.equalsIgnoreCase("MyAir")) {
                            list.add(new CardviewMyAir(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, voucherTypeDesc, true, provider, hasAirtimePlus));
                        } else if (tag.equalsIgnoreCase("LycaMobile")) {
                            list.add(new CardviewLycaMobile(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, voucherTypeDesc, true, provider, hasAirtimePlus));
                        } else if (tag.equalsIgnoreCase("Ringas")) {
                            list.add(new CardviewRingas(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, voucherTypeDesc, true, provider, hasAirtimePlus));
                        } else if (tag.equalsIgnoreCase("CallAll")) {
                            list.add(new CardviewCallAll(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, voucherTypeDesc, true, provider, hasAirtimePlus));
                        } else {
                            if (voucherTypeDesc.contains("Data")) {
                                list.add(new CardviewDefaultData(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            } else {
                                list.add(new CardviewDefaultAirtime(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                            }
                        }
                    } else if (voucherType.equalsIgnoreCase("bill_payment") || tag.contains("bill") || voucherTypeDesc.contains("bill")) {
                        int resId;
                        String logoId = getBaseActivity().getBillPayLogoId(cardDesc);
                        Log.v("Easypay", "favourites logoId=" + logoId);
                        if (logoId != null && logoId.equals("30")) {
                            resId = R.drawable.billpayment_easypay;
                        } else if (logoId != null && logoId.equals("31")) {
                            resId = R.drawable.billpayment_unipay;
                        } else {
                            resId = getBaseActivity().getDrawableResource(getBaseActivity().getShortName(cardDesc));
                        }

                        if (voucherTypeDesc.equalsIgnoreCase("traffic fine")) {

                            if (resId != 0) {
                                String shortname = getBaseActivity().getShortName(cardDesc);

                                if (!shortname.isEmpty()) {
                                    int colorResId = getBaseActivity().getColourResource(shortname);
                                    list.add(new CardViewBillPayment(cardDesc, "", resId, colorResId, "", voucherType, tag, voucherTypeDesc, provider));
                                } else {
                                    list.add(new CardViewBillPayment(getBaseActivity(), cardDesc, "", resId, "", voucherType, tag, voucherTypeDesc, provider));
                                }
                            } else {
                                resId = getBaseActivity().getDrawableResource("default_transact");
                                list.add(new CardViewBillPayment(getBaseActivity(), cardDesc, "", resId, "", voucherType, tag, voucherTypeDesc, provider));
                            }

                        } else {
                            if (resId != 0) {
                                String shortname = getBaseActivity().getShortName(cardDesc);
                                Log.v(TAG, "Short Name:" + shortname);
                                if (!shortname.isEmpty()) {
                                    int colorResId = getBaseActivity().getColourResource(shortname);
                                    list.add(new CardViewBillPayment(cardDesc, "", resId, colorResId, "", voucherType, tag, voucherTypeDesc, provider));
                                } else {
                                    list.add(new CardViewBillPayment(getBaseActivity(), cardDesc, "", resId, "", voucherType, tag, voucherTypeDesc, provider));
                                }
                            } else {
                                resId = getBaseActivity().getDrawableResource("default_transact");
                                list.add(new CardViewBillPayment(getBaseActivity(), cardDesc, "", resId, "", voucherType, tag, voucherTypeDesc, provider));
                            }
                        }

                    }
                    // Chat4Change
                    else if (cardDesc.equalsIgnoreCase("MVNO")) {
                        list.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.mvno_menu_card, R.color.mvno, cardDesc, cardDesc));
                    } else {
                        list.add(new CardviewDefaultAirtime(getBaseActivity(), cardDesc, cardValue, stockId, voucherType, tag, voucherTypeDesc, hasAirtimePlus));
                    }
                }
            }
        }

        listOfCardItems = list;

        return list;
    }
}
