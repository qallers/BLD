package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import za.co.blt.interfaces.external.factories.CarmaRequestFactory;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestPassengerMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseCompleteBookingMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseReserveSeatsMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseTicketMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static java.lang.String.format;
import static java.lang.String.valueOf;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;

/**
 * Created by MasiS on 2018/02/17.
 */

public class FragmentCarmaConfirmPurchaseTicketNew extends BaseFragment implements NeedsAEONResults {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidTextView amount_due_value;
    private ListView listRoutes;
    private TextView txtNoRoutes;
    private BluDroidButton bookButton;

    private String paymentType = "1";

    public FragmentCarmaConfirmPurchaseTicketNew() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        View rootView = inflater.inflate(R.layout.fragment_carma_confirm_tickets_new, container, false);
        listRoutes = rootView.findViewById(R.id.listRoutes);
        txtNoRoutes = rootView.findViewById(R.id.txtNoRoutes);

        rootView.findViewById(R.id.cancel_bus_ticket).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // quick fix, abort the whole thing altogether
                    // init all variables
                    getBaseActivity().bluDroidRoutesAndTimesTrips.clear();
                    getBaseActivity().departureRoutes.clear();
                    getBaseActivity().returnRoutes.clear();
                    getBaseActivity().bluDroidRoutesAndTimesReturn = null;
                    getBaseActivity().carmaResponseTitleListMessage = null;
                    getBaseActivity().availabilitySearchQuery = null; // we use this on the passenger seats thingy
                    getBaseActivity().carrierCode = "";
                    getBaseActivity().departureRoutes.clear();
                    getBaseActivity().returnRoutes.clear();
                    getBaseActivity().initLongHaulVariables(); // solves the caching issue
                    if (getBaseActivity().navigatedFromFavourites) {
                        getBaseActivity().gotoMainScreen();
                    } else {
                        getBaseActivity().gotoFragment(new FragmentTickets(), "FragmentTickets");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    BaseActivity.logger.error("onCreateView exception" + e);
                }
            }
        });

        rootView.findViewById(R.id.back_bus_ticket).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        bookButton = rootView.findViewById(R.id.book_bus_ticket);
        bookButton.setEnabled(false);
        bookButton.setBackgroundColor(getBaseActivity().getResources().getColor(R.color.lightGrey));
        bookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    completeBooking();
                } catch (Exception e) {
                    e.printStackTrace();
                    BaseActivity.logger.error("onCreateView exception" + e);
                }
            }
        });

        BluDroidRadioButton cash_payment = rootView.findViewById(R.id.cash_payment);
        cash_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paymentType = "1";
            }
        });
        cash_payment.setChecked(true); // default to cash

        BluDroidRadioButton credit_card_payment = rootView.findViewById(R.id.credit_card_payment);
        credit_card_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paymentType = "2";
            }
        });

        //----------------------------------------------------------------------------------------------
        BluDroidRadioButton debit_order_payment = rootView.findViewById(R.id.debit_order_payment);
        debit_order_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paymentType = "3";
            }
        });

        amount_due_value = rootView.findViewById(R.id.amount_due_value);

        BaseActivity.isSearchResultsScreen = false;

        return rootView;
    }

    @Override
    public void onDestroy() {
        if (listRoutes != null) listRoutes.setAdapter(null);
        super.onDestroy();
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();

        if (BaseActivity.socket == null || BaseActivity.socket.isClosed() || getBaseActivity().carmaAuthenticationRequestMessage == null) {
            authForCarma();
        } else {
            requestPassengerMessage();
        }
    }

    private void authForCarma() {
        try {
            getBaseActivity().availabilitySearchQuery.setCarrierName(getBaseActivity().carrierCode);
            getBaseActivity().createProgress(R.string.authenticating);
            CarmaRequestFactory factory = new CarmaRequestFactory();

            getBaseActivity().carmaAuthenticationRequestMessage =
                    factory.create(
                            BaseActivity.loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER));

            if (BaseActivity.completeConsumerProfile != null) {
                getBaseActivity().carmaAuthenticationRequestMessage.getEvent().setLoyaltyProfileId(BaseActivity.completeConsumerProfile.getConsumer().getProfileId());
            }
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, getBaseActivity().carmaAuthenticationRequestMessage);
        } catch (Exception exception) {
            //Log.v(TAG, "prepareCarma throws " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    private void populateScreen() {
        try {
            List<BluDroidRoutesAndTimes> routes = new ArrayList<>();
            double total = 0.0;

            txtNoRoutes.setVisibility(View.GONE);

            Map<String, BluDroidRoutesAndTimes> routeMap = new LinkedHashMap<>();

            for (CarmaResponseTicketMessage ticket : getBaseActivity().carmaResponseReserveSeatsMessage.getData().getTickets()) {
                Log.d(TAG, ticket.toString());
                total += Double.valueOf(ticket.getAmount());

//        BluDroidRoutesAndTimes route = routeMap.get(ticket.getRouteCode());
                BluDroidRoutesAndTimes route = routeMap.get(ticket.getBoardTime());

                if (route == null) {
                    route = new BluDroidRoutesAndTimes();
//        route.setCarrier(getBaseActivity().bluDroidRoutesAndTimes.getCarrier());
                    route.setCarrier(ticket.getCarrier());
                    route.setCarrierName(ticket.getCarrierDescription());
                    route.setPositionInList(1);
                    route.setAdultPrice(new BluDroidUtils().formatMoney(ticket.getAmount()));
                    route.setArriveTime(ticket.getArrivalTime());
                    route.setBoardTime(ticket.getBoardTime());
                    route.setBoardLocation(ticket.getBoardCity());
                    route.setDestLocation(ticket.getDestCity());
                    route.setTravelClass(ticket.getTravelClass());
                    route.setMediaUrl(getBaseActivity().carmaResponseCarrierListMessage.getData().getMediaUrl());
//          routeMap.put(ticket.getRouteCode(), route);
                    routeMap.put(ticket.getBoardTime(), route);
                } else {
                    route.setPositionInList(route.getPositionInList() + 1);
                    double ticketPrice = Double.parseDouble(ticket.getAmount());
                    double price = Double.parseDouble(route.getAdultPrice());
                    route.setAdultPrice(new BluDroidUtils().formatMoney(String.valueOf(price + ticketPrice)));
//          routeMap.put(ticket.getRouteCode(), route);
                    routeMap.put(ticket.getBoardTime(), route);
                }
            }

            for (Map.Entry<String, BluDroidRoutesAndTimes> pair : routeMap.entrySet()) {
                routes.add(pair.getValue());
            }

            BluDroidCarmaRoutesAdapter routeAdapter = new BluDroidCarmaRoutesAdapter(getBaseActivity(), R.layout.bus_trip_info_layout_item, routes, true);
            listRoutes.setAdapter(routeAdapter);

            amount_due_value.setText(format("R %s", valueOf(new BluDroidUtils().formatMoney(getBaseActivity().df2.format(total))))); // format to 2 decimal places
            bookButton.setEnabled(true);
            bookButton.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());
        } catch (Exception e) {
            BaseActivity.logger.error(e.getMessage(), e);
            getBaseActivity().createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorCarmaUnexpectedResponse, true);
        }

    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean onBackPressed() {
        Log.d(TAG, "back pressed");
        getBaseActivity().gotoFragment(getBaseActivity().fragmentCarmaPassengerDetailsWizard, "FragmentCarmaPassengerDetailsWizard");
        return true;
    }

    //----------------------------------------------------------------------------------------------
    private void addPassengerToReserveSeasMessage() {
        getBaseActivity().carmaRequestReserveSeatsMessage.getEvent().getPassengers().clear(); // this is needed to reset the list
        // loop through adults passenger fragments
        for (CarmaPassenger passenger : getBaseActivity().passengerDetails) { // the data collected from the passenger details wizard
            // add adult passenger
            if (passenger instanceof CarmaPassengerAdult) {
                CarmaRequestPassengerMessage carmaRequestPassengerMessage = new CarmaRequestPassengerMessage();
                carmaRequestPassengerMessage.setTitle(passenger.getTitle());
                carmaRequestPassengerMessage.setInitials(passenger.getInitials());
                carmaRequestPassengerMessage.setLastName(passenger.getLastName());
                carmaRequestPassengerMessage.setIdNumber(passenger.getIdNumber());
                carmaRequestPassengerMessage.setPassengerType("A");
                carmaRequestPassengerMessage.setCellNum(((CarmaPassengerAdult) passenger).getCellNumber());
                carmaRequestPassengerMessage.setInfant(((CarmaPassengerAdult) passenger).isInfantOnLap() ? "1" : "0");
                getBaseActivity().carmaRequestReserveSeatsMessage.getEvent().getPassengers().add(carmaRequestPassengerMessage);
            }

            // add child passenger
            if (passenger instanceof CarmaPassengerChild) {
                CarmaRequestPassengerMessage carmaRequestPassengerMessage = new CarmaRequestPassengerMessage();
                carmaRequestPassengerMessage.setTitle(passenger.getTitle());
                carmaRequestPassengerMessage.setInitials(passenger.getInitials());
                carmaRequestPassengerMessage.setLastName(passenger.getLastName());
                carmaRequestPassengerMessage.setIdNumber("" + (BluDroidUtils.getAgeInMonths(((CarmaPassengerChild) passenger).getDob()) / 12));
                carmaRequestPassengerMessage.setPassengerType("C");
                carmaRequestPassengerMessage.setCellNum("");
                carmaRequestPassengerMessage.setInfant("0");
                getBaseActivity().carmaRequestReserveSeatsMessage.getEvent().getPassengers().add(carmaRequestPassengerMessage);
            }

            // add infant passenger
            if (passenger instanceof CarmaPassengerInfant) {
                CarmaRequestPassengerMessage carmaRequestPassengerMessage = new CarmaRequestPassengerMessage();
                carmaRequestPassengerMessage.setTitle(passenger.getTitle());
                carmaRequestPassengerMessage.setInitials(passenger.getInitials());
                carmaRequestPassengerMessage.setLastName(passenger.getLastName());
                carmaRequestPassengerMessage.setIdNumber("" + (BluDroidUtils.getAgeInMonths(((CarmaPassengerInfant) passenger).getDob()) / 12));
                carmaRequestPassengerMessage.setPassengerType("I");
                carmaRequestPassengerMessage.setCellNum("");
                carmaRequestPassengerMessage.setInfant("0");
                getBaseActivity().carmaRequestReserveSeatsMessage.getEvent().getPassengers().add(carmaRequestPassengerMessage);
            }

        }
        bookTickets();
    }

    //----------------------------------------------------------------------------------------------
    private void requestPassengerMessage() {
        try {
            if (getBaseActivity().carmaRequestReserveSeatsMessage == null) {
                CarmaRequestFactory factory = new CarmaRequestFactory();
                if (getBaseActivity().availabilitySearchQuery.isReturnTrip()) {
                    getBaseActivity().carmaRequestReserveSeatsMessage = factory.createReserveSeats(
                            getBaseActivity().carmaAuthenticationResponseMessage,
                            getBaseActivity().bluDroidRoutesAndTimes.getRouteCode(),
                            getBaseActivity().bluDroidRoutesAndTimesReturn.getRouteCode());
                } else {
                    getBaseActivity().carmaRequestReserveSeatsMessage = factory.createReserveSeats(
                            getBaseActivity().carmaAuthenticationResponseMessage,
                            getBaseActivity().bluDroidRoutesAndTimes.getRouteCode());
                }
            } else {
                Log.d(TAG, "carmaRequestReserveSeatsMessage is NOT null");
            }
        } catch (Exception exception) {
            Log.d(TAG, "requestPassengerMessage exception " + exception);
        }

        if (getBaseActivity().bluDroidRoutesAndTimes.getCarrierName().toLowerCase().contains("greyhound")) {
            getBaseActivity().carmaRequestReserveSeatsMessage.getEvent().setEmergencyContactName(getBaseActivity().emergencyName);
            getBaseActivity().carmaRequestReserveSeatsMessage.getEvent().setEmergencyContactNumber(getBaseActivity().emergencyNumber);
        } else {
            getBaseActivity().carmaRequestReserveSeatsMessage.getEvent().setEmergencyContactName("");
            getBaseActivity().carmaRequestReserveSeatsMessage.getEvent().setEmergencyContactNumber("");
        }

        addPassengerToReserveSeasMessage();
    }

    //----------------------------------------------------------------------------------------------
    private void bookTickets() {
        //use the number of passengers as the number of seats
        BaseActivity.gettingCarmaTicket = true;
        getBaseActivity().carmaRequestReserveSeatsMessage.getEvent().setSeats(String.valueOf(getBaseActivity().carmaRequestReserveSeatsMessage.getEvent().getPassengers().size()));
        getBaseActivity().createProgress(R.string.gettingTickets);
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, getBaseActivity().carmaRequestReserveSeatsMessage);
    }

    //----------------------------------------------------------------------------------------------
    private void completeBooking() {
        getBaseActivity().createProgress(R.string.completingBooking);
        BigDecimal total = BigDecimal.ZERO;
        for (int i = 0; i < getBaseActivity().carmaResponseReserveSeatsMessage.getData().getTickets().size(); i++) {
            BigDecimal amount = new BigDecimal(
                    getBaseActivity().carmaResponseReserveSeatsMessage.getData().getTickets().get(i).getAmount());
            total = total.add(amount);
        }
        getBaseActivity().paymentType = "cash";
        if (paymentType.equals("2"))
            getBaseActivity().paymentType = "credit";
        else if (paymentType.equals("3"))
            getBaseActivity().paymentType = "debit";
        CarmaRequestFactory factory = new CarmaRequestFactory();
        getBaseActivity().carmaRequestCompleteBookingMessage = factory.createCompleteBooking(
                getBaseActivity().carmaResponseReserveSeatsMessage,
                //lit_payment,
                paymentType,
                total.toString());

        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, getBaseActivity().carmaRequestCompleteBookingMessage);
    }

    //----------------------------------------------------------------------------------------------
    public void results(Object obj) { // Gets tickets and prints them out using the getBaseActivity()

        try {
            Log.d(TAG, "results object " + obj);
            Log.d("MPKresults", "(CarmaConfirm) class " + obj.getClass().getSimpleName());
        } catch (Exception ignore) {
        }

        if (obj instanceof CarmaAuthenticationResponseMessage) {
            getBaseActivity().carmaAuthenticationResponseMessage = (CarmaAuthenticationResponseMessage) obj;
            if (getBaseActivity().carmaAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                requestPassengerMessage();
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaAuthenticationResponseMessage, true);
            }

        } else if (obj instanceof CarmaResponseReserveSeatsMessage) {
            getBaseActivity().carmaResponseReserveSeatsMessage = (CarmaResponseReserveSeatsMessage) obj;
            if (getBaseActivity().carmaResponseReserveSeatsMessage.getEvent().getEventCode().equals("0")) {
                populateScreen();
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaResponseReserveSeatsMessage, true);
            }
        } else if (obj instanceof CarmaResponseCompleteBookingMessage) {
            getBaseActivity().carmaResponseCompleteBookingMessage = (CarmaResponseCompleteBookingMessage) obj;
            if (getBaseActivity().carmaResponseCompleteBookingMessage.getEvent().getEventCode().equals("0")) {
                String carrierName = getBaseActivity().bluDroidRoutesAndTimes.getCarrierName();

                int total = 0;
                String tenderTotal;
                for (int i = 0; i < getBaseActivity().carmaResponseReserveSeatsMessage.getData().getTickets().size(); i++) {
                    total += Double.parseDouble(getBaseActivity().carmaResponseReserveSeatsMessage.getData().getTickets().get(i).getAmount());
                }

                tenderTotal = String.valueOf(total);
                getBaseActivity().saveDetailsUntilPaid(getBaseActivity().carmaResponseReserveSeatsMessage.getData().getTransRef(), carrierName, "Bus ticket", new BluDroidUtils().formatMoney(tenderTotal));
                getBaseActivity().printTickets();
            } else {
                getBaseActivity().createSystemErrorConfirmation(getBaseActivity().carmaResponseCompleteBookingMessage, true);
            }
        }

        /*if (obj != null && !(obj instanceof Socket)) {
            getBaseActivity().firebaseBundle = new Bundle();
            getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, obj.getClass().getSimpleName());
            getBaseActivity().mFirebaseAnalytics.logEvent("aeon_connection", getBaseActivity().firebaseBundle);
        }*/
    }
    //----------------------------------------------------------------------------------------------
}