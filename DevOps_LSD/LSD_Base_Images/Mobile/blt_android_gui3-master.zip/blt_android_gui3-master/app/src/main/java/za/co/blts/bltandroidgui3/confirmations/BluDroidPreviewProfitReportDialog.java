package za.co.blts.bltandroidgui3.confirmations;

import java.util.ArrayList;

import za.co.blts.bltandroidgui3.BaseActivity;

/**
 * Created by MasiS on 3/23/2018.
 */

public class BluDroidPreviewProfitReportDialog extends BluDroidPrintPreviewDialog {
    private final String TAG = this.getClass().getSimpleName();
    //----------------------------------------------------------------------------------------------
    public BluDroidPreviewProfitReportDialog(final BaseActivity context, ArrayList lines) {
        super(context, lines);
        setup();
        setHeading("Preview Profits Report");
    }
    //----------------------------------------------------------------------------------------------
}


