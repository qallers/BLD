package za.co.blts.nfcbus;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.net.Socket;

import za.co.blt.interfaces.external.factories.NfcBusRequestFactory;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusUpdateCustomerRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusUpdateCustomerResponseMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.NeedsAEONResults;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMandatoryEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;
import za.co.blts.nfc.NfcResult;
import za.co.blts.nfc.NfcResultable;
import za.co.blts.nfc.NfcTappable;


public class FragmentCustomerProfile extends BaseFragment implements NeedsAEONResults, NfcResultable {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidRelativeLayout layout;
    private BluDroidMandatoryEditText txtName, txtSurname;
    private BluDroidCellphoneEditText txtCell;

    public FragmentCustomerProfile() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((ActivityNfcBus) getActivity()).setResultable(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_customer_profile, container, false);

        layout = rootView.findViewById(R.id.layout);
        txtName = rootView.findViewById(R.id.txtName);
        txtSurname = rootView.findViewById(R.id.txtSurname);
        txtCell = rootView.findViewById(R.id.txtCell);
        BluDroidTextView txtUid = rootView.findViewById(R.id.txtUid);
        txtUid.setText(((ActivityNfcBus) getActivity()).getCardUid());

        BluDroidButton btnCancel = rootView.findViewById(R.id.btnCancel);
        BluDroidButton btnNext = rootView.findViewById(R.id.btnNext);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getBaseActivity().firebaseBundle = new Bundle();
                getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, ((ActivityNfcBus) getActivity()).getCardUid());
                getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_profile_cancel", getBaseActivity().firebaseBundle);

                ((ActivityNfcBus) getActivity()).gotoTicketList();
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate();
            }
        });

        loadData();

        return rootView;
    }

    private void loadData() {
        if (((ActivityNfcBus) getActivity()).getCustomerResponseDataMessage() != null) {
            txtName.setText(((ActivityNfcBus) getActivity()).getCustomerResponseDataMessage().getName());
            txtSurname.setText(((ActivityNfcBus) getActivity()).getCustomerResponseDataMessage().getSurname());
            txtCell.setText(((ActivityNfcBus) getActivity()).getCustomerResponseDataMessage().getCellNumber());
        }
    }

    private void validate() {
        if (layout.validate()) {
            Log.d(TAG, "format card and update customer");
//            ((ActivityNfcBus)getActivity()).authForNfcBus(this);
            if (((ActivityNfcBus) getActivity()).getCustomerResponseDataMessage() == null) {
                if (((ActivityNfcBus) getActivity()).isCardFormatted()) {
                    ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentCustomerProfile.this);
                } else {
                    String message = "The card will now be formatted. All data on the card will be cleared.";
                    getBaseActivity().alert = new BluDroidAlertDialog(getContext());
                    getBaseActivity().alert.setTitle("CONFIRM");
                    getBaseActivity().alert.setMessage(message);
                    getBaseActivity().alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            getBaseActivity().alert.dismiss();
                        }
                    });
                    getBaseActivity().alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            getBaseActivity().alert.dismiss();
                            promptForCard();
                        }
                    });
                    getBaseActivity().alert.show();
                }
            } else {
                if (profileDataChanged()) {
                    ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentCustomerProfile.this);
                } else {
                    ((ActivityNfcBus) getActivity()).gotoTicketList();
                }
            }
        } else {
            Log.w(TAG, "validate failed");
        }
    }

    private boolean profileDataChanged() {
        String name = txtName.getText().toString().trim();
        String surname = txtSurname.getText().toString().trim();
        String cell = txtCell.getText().toString().trim().replaceAll(" ", "");

        if (!name.equals(((ActivityNfcBus) getActivity()).getCustomerResponseDataMessage().getName())) {
            return true;
        } else if (!surname.equals(((ActivityNfcBus) getActivity()).getCustomerResponseDataMessage().getSurname())) {
            return true;
        } else if (!cell.equals(((ActivityNfcBus) getActivity()).getCustomerResponseDataMessage().getCellNumber())) {
            return true;
        }

        return false;
    }

    private void updateCustomer(String sessionId) {
        getBaseActivity().firebaseBundle = new Bundle();
        getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, ((ActivityNfcBus) getActivity()).getCardUid());
        getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_profile_update", getBaseActivity().firebaseBundle);

        getBaseActivity().createProgress(getResources().getString(R.string.updating_customer));
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusUpdateCustomerRequestMessage req = factory.updateCustomer(sessionId,
                ((ActivityNfcBus) getActivity()).getCardUid(),
                txtName.getText().toString().trim(),
                txtSurname.getText().toString().trim(),
                txtCell.getText().toString().trim().replaceAll(" ", ""));
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    @Override
    public void results(Object object) {
        if (object instanceof NfcBusAuthenticationResponseMessage) {
            if (((NfcBusAuthenticationResponseMessage) object).getEvent().getEventCode().equals("0")) {
                updateCustomer(((NfcBusAuthenticationResponseMessage) object).getSessionId());
            } else {
                getBaseActivity().createSystemErrorConfirmation(object, true);
            }
        } else if (object instanceof NfcBusUpdateCustomerResponseMessage) {
            if (((NfcBusUpdateCustomerResponseMessage) object).getEvent().getEventCode().equals("0")) {
                if (((NfcBusUpdateCustomerResponseMessage) object).getDetail().getStatus().equals("1")) {
                    getBaseActivity().dismissProgress();
                    Log.i(TAG, "customer created successfully");
                    ((ActivityNfcBus) getActivity()).gotoTicketList();
                } else {
                    Log.e(TAG, "did not receive correct status flag");
                    getBaseActivity().createSystemErrorConfirmation(((NfcBusUpdateCustomerResponseMessage) object).getDetail().getMessage(), true);
                }
            } else {
                getBaseActivity().createSystemErrorConfirmation(object, true);
            }
        }

        if (object != null && !(object instanceof Socket)) {
            getBaseActivity().firebaseBundle = new Bundle();
            getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            getBaseActivity().mFirebaseAnalytics.logEvent("aeon_connection", getBaseActivity().firebaseBundle);
        }
    }

    private void promptForCard() {
        Log.d(TAG, "prompt for card");
        String message = "Please place your SmartTap card with ID " + ((ActivityNfcBus) getActivity()).getCardUid();
        message += "\n\nDO NOT REMOVE CARD TILL TRANSACTION COMPLETES";
        getBaseActivity().alert = new BluDroidAlertDialog(getContext());
        getBaseActivity().alert.setTitle("NFC");
        getBaseActivity().alert.setMessage(message);
        getBaseActivity().alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                getBaseActivity().alert.dismiss();
                ((ActivityNfcBus) getActivity()).gotoTicketList();
            }
        });
        getBaseActivity().alert.show();
        ((ActivityNfcBus) getActivity()).getTappable().formatCard(NfcBusInstr.format(true, ((ActivityNfcBus) getActivity()).getCard().getUid()));
    }

    @Override
    public void handleNfcResult(final NfcResult result) {
        BaseActivity.logger.info(result.toString());

        Log.i(TAG, "operation: " + result.getOperation());
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                getBaseActivity().alert.dismiss();
                if (result.getOperation() == NfcTappable.NfcOperation.FORMAT) {
                    if (result.getStatus() == NfcTappable.NfcStatus.SUCCESS) {
                        ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentCustomerProfile.this);
                    } else {
                        String message = "An error occurred preparing card, please try again";
                        if (result.getStatus() == NfcTappable.NfcStatus.INVALID_CARD) {
                            message = "Incorrect card placed, please try again";
                        }

                        getBaseActivity().firebaseBundle = new Bundle();
                        getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, message);
                        getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_card_error", getBaseActivity().firebaseBundle);

                        getBaseActivity().alert = new BluDroidAlertDialog(getContext());
                        getBaseActivity().alert.setTitle("Error");
                        getBaseActivity().alert.setMessage(message);
                        getBaseActivity().alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                getBaseActivity().alert.dismiss();
                                promptForCard();
                            }
                        });
                        getBaseActivity().alert.show();
                    }
                }
            }
        });
    }
}