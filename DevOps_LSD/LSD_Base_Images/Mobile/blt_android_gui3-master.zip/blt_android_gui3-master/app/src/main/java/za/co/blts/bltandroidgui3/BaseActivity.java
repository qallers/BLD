package za.co.blts.bltandroidgui3;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.StatFs;
import android.preference.PreferenceManager;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.nexgo.oaf.apiv3.DeviceEngine;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

import za.co.blt.consumer.loyalty.api.service.model.response.CompleteConsumerProfile;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfile;
import za.co.blt.consumer.loyalty.api.service.model.response.Favourite;
import za.co.blt.interfaces.external.exceptions.AEONCommsException;
import za.co.blt.interfaces.external.factories.BillPaymentsRequestFactory;
import za.co.blt.interfaces.external.factories.Chat4ChangeRequestFactory;
import za.co.blt.interfaces.external.factories.ElectricityVoucherRequestFactory;
import za.co.blt.interfaces.external.factories.EmergencyLoanRequestFactory;
import za.co.blt.interfaces.external.factories.IthubaRequestFactory;
import za.co.blt.interfaces.external.factories.MerchantTransferRequestFactory;
import za.co.blt.interfaces.external.factories.ReportsRequestFactory;
import za.co.blt.interfaces.external.factories.ReprintRequestFactory;
import za.co.blt.interfaces.external.factories.RicaRequestFactory;
import za.co.blt.interfaces.external.factories.TenderRequestFactory;
import za.co.blt.interfaces.external.factories.TicketProRequestFactory;
import za.co.blt.interfaces.external.factories.UsersRequestFactory;
import za.co.blt.interfaces.external.fdroid.FdroidApplication;
import za.co.blt.interfaces.external.fdroid.FdroidFdroid;
import za.co.blt.interfaces.external.messages.airtimetopup.response.AirtimeTopupResponsePurchaseMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsBluBillAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsPayAtAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestBluBillConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestBluBillGetInfoMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestPayAtAccountPaymentMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestPayAtConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestProductListMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestSapoAccountPaymentMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestSapoConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestSyntellAccountPaymentMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsRequestSyntellConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsSapoAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.billpayments.request.BillPaymentsSyntellAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsBluBillAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsPayAtAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseBluBillConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseBluBillGetInfoMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponsePayAtAccountPaymentMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponsePayAtConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponsePrintedMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProductListDataMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProductListMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProductMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProviderMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseSapoAccountPaymentMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseSapoConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseSyntellAccountPaymentMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseSyntellConfirmMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsSapoAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsSyntellAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseCategoryMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseDoBundleTopupMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseGetProductListDataMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseGetProductListMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseProductMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestAvailabilityExtendedMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestCompleteBookingMessage;
import za.co.blt.interfaces.external.messages.carma.request.CarmaRequestReserveSeatsMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseAvailabilityExtendedMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseAvailabilityMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseCarrierListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseCityListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseClassListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseCompleteBookingMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseDestinationsListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseItemMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponsePassengerTypeListMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseReserveSeatsMessage;
import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseTitleListMessage;
import za.co.blt.interfaces.external.messages.chat4change.request.Chat4ChangeAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.chat4change.request.Chat4ChangeRequestListSuppliersMessage;
import za.co.blt.interfaces.external.messages.chat4change.request.Chat4ChangeRequestMessage;
import za.co.blt.interfaces.external.messages.chat4change.request.Chat4ChangeRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponseListSuppliersMessage;
import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponseMessage;
import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponsePrintedMessage;
import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponseSupplierMessage;
import za.co.blt.interfaces.external.messages.common.response.CommonResponseAccountMessage;
import za.co.blt.interfaces.external.messages.common.response.CommonResponseEventMessage;
import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blt.interfaces.external.messages.common.response.CommonResponseMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.request.ElectricityVoucherRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponseDataMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponseMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponseMeterMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponseTokenMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.request.EmergencyLoanAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.request.EmergencyLoanRequestListAccountsMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.request.EmergencyLoanRequestLoanConfirmationMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.request.EmergencyLoanRequestPrintEmergencyTopupMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanResponseAccountMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanResponseListAccountsMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanResponseLoanApplicationMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanResponseLoanConfirmationMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanResponsePrintEmergencyTopupMessage;
import za.co.blt.interfaces.external.messages.eskomdirectreprint.response.EskomDirectReprintResponseMessage;
import za.co.blt.interfaces.external.messages.ithuba.request.IthubaAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.ithuba.request.IthubaRequestItbConfirmMessage;
import za.co.blt.interfaces.external.messages.ithuba.request.IthubaRequestItbLotteryMessage;
import za.co.blt.interfaces.external.messages.ithuba.request.IthubaRequestItbPowerballMessage;
import za.co.blt.interfaces.external.messages.ithuba.request.IthubaRequestItbPrintedMessage;
import za.co.blt.interfaces.external.messages.ithuba.response.IthubaAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.ithuba.response.IthubaResponseItbConfirmMessage;
import za.co.blt.interfaces.external.messages.ithuba.response.IthubaResponseItbLotteryMessage;
import za.co.blt.interfaces.external.messages.ithuba.response.IthubaResponseItbPowerballMessage;
import za.co.blt.interfaces.external.messages.ithuba.response.IthubaResponseItbPrintedMessage;
import za.co.blt.interfaces.external.messages.login.request.LoginRequestMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseDataMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseGroupMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseTransactionTypeMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.request.MerchantTransferAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.request.MerchantTransferRequestConfirmMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.request.MerchantTransferRequestGetInfoMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.request.MerchantTransferRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.response.MerchantTransferAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.response.MerchantTransferResponseConfirmMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.response.MerchantTransferResponseGetInfoMessage;
import za.co.blt.interfaces.external.messages.merchanttransfer.response.MerchantTransferResponsePrintedMessage;
import za.co.blt.interfaces.external.messages.multiplevouchers.request.MultipleVouchersAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.multiplevouchers.response.MultipleVouchersAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusCancelTicketResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusCheckoutResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusConfirmCancelTicketResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusConfirmCheckoutResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusFindTicketsResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusGetCustomerResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListCarriersResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListStopsResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupDestinationsResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupFaresResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusUpdateCustomerResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusValidateSvcResponseMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsAccountInfoAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestAccountListMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestBatchMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestEndShiftMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestInvoiceListMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestPrintInvoiceMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestPrintShiftMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestProfitMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestShiftListMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestShiftProfitMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestStatementMessage;
import za.co.blt.interfaces.external.messages.reports.request.ReportsRequestTransListMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsAccountInfoAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseAccountListMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseAccountValuesMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseBatchMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseEndShiftMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseInvoiceListMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponsePrintShiftMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseProfitMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseShiftListMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseShiftProfitMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseStatementMessage;
import za.co.blt.interfaces.external.messages.reports.response.ReportsResponseTransListMessage;
import za.co.blt.interfaces.external.messages.reprint.request.ReprintAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.reprint.request.ReprintRequestListByDateMessage;
import za.co.blt.interfaces.external.messages.reprint.request.ReprintRequestReprintMessage;
import za.co.blt.interfaces.external.messages.reprint.response.ReprintAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.reprint.response.ReprintResponseListByDateMessage;
import za.co.blt.interfaces.external.messages.reprint.response.ReprintResponseReprintMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestBoxNumberMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestBoxNumberSIMSMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestChangeOwnerMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestCheckUserMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestMultipleRegisterMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestQueryMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestRegisterMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestRegistrationMessage;
import za.co.blt.interfaces.external.messages.rica.request.RicaRequestUserMessage;
import za.co.blt.interfaces.external.messages.rica.response.RicaAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.rica.response.RicaResponseBoxNumberSIMSMessage;
import za.co.blt.interfaces.external.messages.rica.response.RicaResponseChangeOwnerMessage;
import za.co.blt.interfaces.external.messages.rica.response.RicaResponseCheckUserMessage;
import za.co.blt.interfaces.external.messages.rica.response.RicaResponseMultipleRegisterMessage;
import za.co.blt.interfaces.external.messages.rica.response.RicaResponseQueryMessage;
import za.co.blt.interfaces.external.messages.rica.response.RicaResponseRegisterMessage;
import za.co.blt.interfaces.external.messages.rica.response.RicaResponseSIMSMessage;
import za.co.blt.interfaces.external.messages.tender.request.TenderAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.tender.request.TenderRequestMessage;
import za.co.blt.interfaces.external.messages.tender.response.TenderAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.tender.response.TenderResponseMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestAllLocationsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestClearCartMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPossibleDestinationsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoAutoCancelMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoCheckOutMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoCreateCartMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoDoCompleteTrxMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoPaymentMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestPutcoPrintMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestRouteAndQuantityMessage;
import za.co.blt.interfaces.external.messages.ticketpro.request.TicketProRequestRouteMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseAllEventsDataMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseAllEventsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseAllLocationsDataMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseAllLocationsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseAllowedProductsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseBookRouteMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseCategoriesDataMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseCategoriesMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseCheckOutMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseCreateCartMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseEventDetailsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseEventsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseParentAllEventMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePaymentMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePossibleDestinationsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePrintEZPLMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePrintMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePutcoAutoCancelMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePutcoCheckOutMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePutcoCreateCartMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePutcoDoCompleteTrxMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePutcoPaymentMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePutcoPrintMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseReservedSeatsMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseRouteInfoMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseRouteMessage;
import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseTicketMessage;
import za.co.blt.interfaces.external.messages.unprinted.response.UnprintedResponseMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersRequestAddUserMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersRequestListMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersRequestListPermissionTypesMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersRequestPermissionMessage;
import za.co.blt.interfaces.external.messages.users.request.UsersRequestUpdateUserMessage;
import za.co.blt.interfaces.external.messages.users.response.UsersAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.users.response.UsersResponseAddUserMessage;
import za.co.blt.interfaces.external.messages.users.response.UsersResponseListMessage;
import za.co.blt.interfaces.external.messages.users.response.UsersResponseListPermissionTypesMessage;
import za.co.blt.interfaces.external.messages.users.response.UsersResponseUpdateUserMessage;
import za.co.blt.interfaces.external.messages.voucher.response.VoucherAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseDataMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseManufacturerMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseProductMessage;
import za.co.blt.interfaces.external.processors.SimpleXMLProcessor;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAddUserInfoDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidBillPaymentsConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidChatForChangeConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidCommunicationErrorConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDatePickerDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDatePickerDialogSpinner;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDateTimePickerDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidElectricityPurchaseConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidEskomEngineeringKeyCodesDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidEskomTrialPurchaseDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidFreeBasicElectricityDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidMerchantTransfersConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidNetworkErrorConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessBundleConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessTopupAnyAmountConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPinlessTopupConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPreviewBatchReportDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPreviewEmergencyTopUpReportDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPreviewInvoicingReportDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPreviewProfitReportDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPreviewShiftProfitReportDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPreviewStatementReportDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPreviewTransactionListReportDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidPrintErrorConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidSystemErrorConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidSystemErrorLogoutConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidTechPinConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidTestScannerDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidTicketCollectDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidTimePickerDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidTrafficFineConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidUniversalElectricityDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidUpdateUserInfoDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidVenueLayoutDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidVoucherPurchaseConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewBluBillDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewC4cDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewLottoDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewMerchantTransfersDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewPayAtDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewPowerballDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewReprintDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewSapo;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewSyntellDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.PrintJob;
import za.co.blts.bltandroidgui3.dynamic.DynamicPrintInfo;
import za.co.blts.bltandroidgui3.dynamic.DynamicPrintUtil;
import za.co.blts.bltandroidgui3.longhaul.cancellations.FragmentBusTicketCancellations;
import za.co.blts.bltandroidgui3.longhaul.cancellations.TicketCacheHandler;
import za.co.blts.bltandroidgui3.menu.FragmentMenu;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidNotification;
import za.co.blts.bltandroidgui3.widgets.BluDroidProgressBar;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidSwitch;
import za.co.blts.bltandroidgui3.widgets.BluDroidToolBar;
import za.co.blts.callme.BluMerchantSupport;
import za.co.blts.callme.BluMerchantSupportConfirm;
import za.co.blts.callme.BluMerchantSupportResponse;
import za.co.blts.loyalty.FragmentNFCCustomerRegistration;
import za.co.blts.loyalty.FragmentNFCEditCustomerProfile;
import za.co.blts.loyalty.FragmentNFCGetConsumerProfile;
import za.co.blts.loyalty.NFCCardInterface;
import za.co.blts.magcard.MagCardData;
import za.co.blts.magcard.MagcardInterface;
import za.co.blts.nfcbus.ActivityNfcBus;
import za.co.blts.nfcbus.ActivityTestNfcOperation;
import za.co.blts.nfcbus.NfcBusRecoveryCacheHandler;
import za.co.blts.nfcbus.NfcBusTicketCacheHandler;

import static com.nexgo.oaf.apiv3.APIProxy.getDeviceEngine;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_ACCOUNT_BALANCE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_ACCOUNT_DETAILS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AEON_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AWS_HEARTBEAT_MINUTES;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BALANCE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BALANCEAMT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BLUKEY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BP_LIMIT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASHIER_END_SHIFT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASH_DRAWER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEF_ACCOUNT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEF_ACCOUNT_INDEX;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DISPLAY_BALANCE1;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DOWNLOAD_DECLINE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_EPUB_MANUAL_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_EPUB_READER_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FAVOURITES_VERSION;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FDROID_REPO_DIR;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FDROID_REPO_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_GRAY_LOG_LEVEL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_GRAY_LOG_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HEARTBEAT_ENABLE_TECH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HEARTBEAT_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_INSTALL_DECLINE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_IOT_FLAG_ENABLE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LAST_LOGIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOCATION_CHECK;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOG_DAYS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOG_LEVEL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOW_BALANCE_AMOUNT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_ENABLE_TECH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_ENABLE_USER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MAG_READER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MANUAL_OVERRIDE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MAX_CACHE_AGE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MENDIX_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PAPER_CUTTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PREVIOUS_SKIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINTER_WIDTH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_APP_VERSION;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_BARCODE_RECEIPT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER_TICKETS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_PREVIEWS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_PREVIEW_RECEIPTS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_SALES_RECEIPT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PROFIT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PUTCO_PAPER_CHECK_SLEEP_TIME;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PUTCO_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RESET_DECLINE_COUNT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_CAN_BOXRICA;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_PASSWORD;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_USERNAME;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_USER_PIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_USE_SSL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SCANNING_APP;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SCREEN_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SECURE_USB_PRINTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_STORE_ADDRESS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_STORE_NAME;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TECH_PIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRANSACTION_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_UNKNOWN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USB_PRINT_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_BASKET;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_SSL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VAT_REG_NO;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VOUCHER_SECONDS;

/**
 * Created by warrenm on 2016/11/21.
 */

public abstract class BaseActivity extends AppCompatActivity implements NeedsAEONResults, NeedsUSBResults {

    private final String TAG = this.getClass().getSimpleName();

    public String virginMobileSupplierCode = "";

    public static boolean TEST_MODE = false;
    private static final long OLD_LOGO_THRESHOLD = 1000 * 60 * 60 * 24 * 7; //1 week
    public static boolean lockBackButton = false;

    public String userLevel = "-1";
    public static String userPin = "";
    public static boolean isForcedLogout = false;

    int printQueue;
    public static int autoLoginRetryCap = 2;

    private static Boolean DEBUG = null;
    private SharedPreferences sharedPreferences = null;
    public FragmentManager baseFm = getSupportFragmentManager();

    List<String> bundleProviders = null;

    public ArrayList<String> favouritesStockIDs = new ArrayList<>();

    String reprintDateFrom;
    String reprintDateTo;

    private final String ORIGINAL_CONFIG_TXT = "originalConfig.txt";
    private final String CONFIG_TXT = "config.txt";

    public final int BARCODE_HEIGHT_128 = 104; // Telpo printer requires HEIGHT to be multiple of 8  was  100;

    public final int BARCODE_HEIGHT_EAN_13 = 104; // Telpo printer requires HEIGHT to be multiple of 8  was 100;

    public final int BARCODE_WIDTH_PDF417 = 384; // Telpo printer requiries HEIGHT to be multiple of 8 was 150;
    public final int BARCODE_HEIGHT_PDF417 = 192; // Telpo printer requiries HEIGHT to be multiple of 8 was 150;

    public static Socket socket = null;
    private static AEONAsyncTask asyncTask = null;

    //
    // these two fields are for cached logins
    //
    public static LoginResponseMessage loginResponseMessage = null;

    public static LoginRequestMessage loginRequestMessage = null;

    //
    // these fields are for voucher memory caching
    //
    public static VoucherListResponseMessage voucherListResponseMessage = null;
    public static VoucherAuthenticationResponseMessage voucherAuthenticationResponseMessage = null;

    //
    // this field is for bundle memory caching
    //
    public static Map<String, BundlesResponseGetProductListMessage> bundlesResponseGetProductListMessages = null;

    //
    //Users
    //
    UsersAuthenticationResponseMessage usersAuthenticationResponseMessage = null;
    UsersResponseListMessage usersResponseListMessage = null;
    public UsersResponseListPermissionTypesMessage usersResponseListPermissionTypesMessage = null;

    //reports
    private ReportsAuthenticationResponseMessage reportsAuthenticationResponseMessage = null;
    ReportsAccountInfoAuthenticationResponseMessage reportsAccountInfoAuthenticationResponseMessage = null;
    ReportsResponseAccountListMessage reportsResponseAccountListMessage = null;
    ReportsResponseShiftListMessage reportsResponseShiftListMessage = null;
    ReportsResponseInvoiceListMessage reportsResponseInvoiceListMessage = null;

    //Online reprints
    private ReprintAuthenticationResponseMessage reprintAuthenticationResponseMessage;
    public ReprintResponseListByDateMessage reprintResponseListByDateMessage;

    Chat4ChangeResponseMessage chat4ChangeResponseMessage;

    //unprinted
    UnprintedResponseMessage unprintedResponseMessage;

    //Eskom reprints
    public EskomDirectReprintResponseMessage eskomDirectReprintResponseMessage;

    //Emergency Top Up
    EmergencyLoanAuthenticationResponseMessage emergencyLoanAuthenticationResponseMessage = null;
    EmergencyLoanResponseListAccountsMessage emergencyLoanResponseListAccountsMessage = null;
    EmergencyLoanResponseLoanConfirmationMessage emergencyLoanResponseLoanConfirmationMessage = null;
    EmergencyLoanResponseLoanApplicationMessage emergencyLoanResponseLoanApplicationMessage = null;

    // Ithuba
    private IthubaAuthenticationResponseMessage ithubaAuthenticationResponseMessage = null;

    private RicaAuthenticationResponseMessage ricaAuthenticationResponseMessage = null;
    private RicaRequestUserMessage ricaRequestUserMessage = null;
    public RicaRequestRegistrationMessage ricaRegistrationMessage = null;

    public ElectricityVoucherResponseMessage electricityVoucherResponseMessage = null;

    private String ref = "";
    private Map<String, String> requestMap = null;
    private Date date = new Date();

    //Lotto
    private String numBoards;
    private String numDraws;
    private String playPlusBox;
    private String playPlus2Box;
    private String gameName;
    private String yesNoCheckBox = "";
    private String yesNoCheckBox2 = "";
    private boolean passesChecks;
    private Map<String, LottoNumberCollection> boardNumbers = new TreeMap<>();

    //RICA
    private String username;
    private String password;
    private String ricaQueryCell;
    private String boxRicareference;
    private boolean isRicaLogin = true;
    private boolean isRicaRegister = false;
    private boolean isRicaChangeOnwer = false;
    private boolean isRicaboxRica = false;
    private boolean isRicaQuery = false;
    public boolean ricaMultiRegistration = false;

    BundlesAuthenticationResponseMessage bundlesAuthenticationResponseMessage = null;

    private Chat4ChangeAuthenticationResponseMessage chat4ChangeAuthenticationResponseMessage = null;

    ArrayList<String> accountNumbers;

    //Bill payments
    private static BillPaymentsAuthenticationResponseMessage billPaymentsAuthenticationResponseMessage = null;
    public static BillPaymentsResponseProductListMessage billPaymentsResponseProductListMessage = null;
    private BillPaymentsRequestBluBillGetInfoMessage billPaymentsRequestBluBillGetInfoMessage = null;
    private BillPaymentsResponseBluBillGetInfoMessage billPaymentsResponseBluBillGetInfoMessage = null;
    private BillPaymentsBluBillAuthenticationResponseMessage billPaymentsBluBillAuthenticationResponseMessage = null;
    private BillPaymentsResponseBluBillConfirmMessage billPaymentsResponseBluBillConfirmMessage = null;

    private BillPaymentsSyntellAuthenticationResponseMessage billPaymentsSyntellAuthenticationResponseMessage = null;
    private BillPaymentsRequestSyntellAccountPaymentMessage billPaymentsRequestSyntellAccountPaymentMessage = null;
    private BillPaymentsResponseSyntellAccountPaymentMessage billPaymentsResponseSyntellAccountPaymentMessage = null;

    private BillPaymentsRequestPayAtAccountPaymentMessage billPaymentsRequestPayAtAccountPaymentMessage = null;
    private BillPaymentsResponsePayAtAccountPaymentMessage billPaymentsResponsePayAtAccountPaymentMessage = null;
    private BillPaymentsPayAtAuthenticationResponseMessage billPaymentsPayAtAuthenticationResponseMessage = null;

    private String strAccount;
    private String strAmont;
    private String strGroupNumber;
    private String strSystemNumber;
    private String strPaymentCode;
    private String strControlCode;
    public String paymentType = "cash";
    public String providerId;
    public String productId;
    private String additionalFields;
    public String possibleTitle;
    public String productName;
    public String logoId;
    private String accountNumber;
    private String transRef;
    private String reference;
    private ArrayList<String> receipt = null;
    private int state = 0;

    //fine payments
    private boolean isTraficFinePayment = false;
    public boolean isBillPaymentScreen = false;
    private boolean isbillPayementPayed = false;

    private MerchantTransferAuthenticationResponseMessage merchantTransferAuthenticationResponseMessage = null;
    private MerchantTransferRequestGetInfoMessage merchantTransferRequestGetInfoMessage = null;
    public MerchantTransferResponseGetInfoMessage merchantTransferResponseGetInfoMessage = null;
    private MerchantTransferResponseConfirmMessage merchantTransferResponseConfirmMessage = null;

    //Putco
    public TicketProAuthenticationResponseMessage ticketProAuthenticationResponseMessage = null;
    public TicketProResponseAllLocationsMessage ticketProResponseAllLocationsMessage = null;
    private TicketProResponsePutcoCreateCartMessage ticketProResponsePutcoCreateCartMessage = null;
    public TicketProResponsePossibleDestinationsMessage ticketProResponsePossibleDestinationsMessage = null;
    public TicketProResponseRouteMessage ticketProResponseRouteMessage = null;
    private TicketProResponsePutcoCheckOutMessage ticketProResponsePutcoCheckOutMessage = null;
    private TicketProResponsePutcoPaymentMessage ticketProResponsePutcoPaymentMessage = null;
    private TicketProResponsePutcoDoCompleteTrxMessage ticketProResponsePutcoDoCompleteTrxMessage = null;
    public boolean doPuctoStuff = false;

    //TicketPro
    public TicketProResponseCreateCartMessage ticketProResponseCreateCartMessage = null;
    public TicketProResponseReservedSeatsMessage ticketProResponseReservedSeatsMessage = null;
    public TicketProResponseCheckOutMessage ticketProResponseCheckOutMessage = null;
    public TicketProResponsePaymentMessage ticketProResponsePaymentMessage = null;
    public TicketProResponseAllowedProductsMessage ticketProResponseAllowedProductsMessage = null;
    public TicketProResponseCategoriesMessage ticketProResponseCategoriesMessage = null;
    public TicketProResponseEventsMessage ticketProResponseEventsMessage = null;
    public TicketProResponseAllEventsMessage ticketProResponseAllEventsMessage = null;
    public TicketProResponseEventDetailsMessage ticketProResponseEventDetailsMessage = null;
    public TicketProResponsePrintMessage ticketProResponsePrintMessage = null;
    public TicketProResponsePrintEZPLMessage ticketProResponsePrintEZPLMessage = null;

    // Carma
    public CarmaAuthenticationResponseMessage carmaAuthenticationResponseMessage = null;
    public CarmaAuthenticationRequestMessage carmaAuthenticationRequestMessage = null;
    public CarmaResponseTitleListMessage carmaResponseTitleListMessage = null;
    public CarmaResponseClassListMessage carmaResponseClassListMessage = null;
    public CarmaResponsePassengerTypeListMessage carmaResponsePassengerTypeListMessage = null;
    public CarmaResponseCityListMessage carmaResponseCityListMessage = null;
    public CarmaResponseCarrierListMessage carmaResponseCarrierListMessage;
    public CarmaResponseDestinationsListMessage carmaResponseDestinationsMessage = null;

    public CarmaRequestAvailabilityExtendedMessage carmaRequestAvailabilityExtendedMessage = null;

    public CarmaResponseAvailabilityMessage carmaResponseAvailabilityMessage = null;
    public CarmaResponseAvailabilityExtendedMessage carmaResponseAvailabilityExtendedMessage = null;

    public CarmaRequestReserveSeatsMessage carmaRequestReserveSeatsMessage = null;
    public CarmaResponseReserveSeatsMessage carmaResponseReserveSeatsMessage = null;
    public CarmaRequestCompleteBookingMessage carmaRequestCompleteBookingMessage = null;
    public CarmaResponseCompleteBookingMessage carmaResponseCompleteBookingMessage = null;
    public AvailabilitySearchQuery availabilitySearchQuery = null;
    public BluDroidRoutesAndTimes bluDroidRoutesAndTimes = null;
    public BluDroidRoutesAndTimes bluDroidRoutesAndTimesReturn = null;
    public List<CarmaPassenger> passengerDetails = new ArrayList<>();
    public static boolean isSearchResultsScreen = false;

    public boolean authenticatingForTitles = true;

    public String carrierCode;

    public String ticketProCategoryId;
    public TicketProResponseParentAllEventMessage ticketProAllProEvent;
    public TicketProSeatCategory ticketProSeatCategory;
    public double ticketProTotal;

    public boolean isEventsScreen = false;
    public boolean isCollectionScreen = false;

    public boolean needDepartures = false;
    public boolean needRoute = false;
    public boolean needDestinations = false;
    public boolean searchByRoute = false;
    public String routeCode = "";
    public String departureName;
    public String destinationName;
    public String departureId = "";
    private String destinationId = "";
    public int routeIndex;

    public ArrayList<PutcoTrip> putcoTrips = new ArrayList<>();
    public PutcoTrip putcoTrip;

    // skin resources
    //
    private BluDroidSkinResources skinResources = null;

    //
    // printer values
    //
    public static SmartPrinter smartPrinter = null;
    public static int printWidth = 0;
    public static String HORIZONTAL_LINE = null;

    public Bitmap bluLogo = null;

    //
    // screen time out
    //
    private BluDroidTimer timer = null;

    //Main menu for ActivityMain
    public static Map<String, ArrayList<String>> menuMap = null;

    static AEONErrors aeonErrors = null;

    public BluDroidConfirmationDialog confirmation = null;
    public BluDroidAlertDialog alert = null;
    AlertDialog alertDialog = null;
    BluDroidProgressBar progressBar = null;

    //
    //Tech Settings Error Handling
    //
    public boolean deviceSettingsHaserrors = false;
    public boolean timeoutSettingsHaserrors = false;
    public boolean ricaSettingsHaserrors = false;
    public boolean repositorySettingsHaserrors = false;
    public boolean ePubSettingsHaserrors = false;
    public boolean heartbeatSettingsHaserrors = false;
    public boolean apiGatewaySettingsHaserrors = false;
    public boolean mendixApiSettingsHaserrors = false;
    public boolean bluKeySettingsHaserrors = false;
    public boolean errorLoggingSettingsHaserrors = false;

    //
    //Device Settings Error Handling
    //
    boolean receiptSettingsHaserrors = false;
    public boolean deviceUserSettingsHaserrors = false;
    public boolean storeSettingsHaserrors = false;
    public boolean accountBalanceSettingsHaserrors = false;

    // protected boolean canDoChatForChange =false;

    public BluDroidUser user = null;
    BluDroidUserListAdapter userListAdapter;
    public ArrayList<UsersRequestPermissionMessage> permissions;

    public ArrayList<Map<String, String>> configFavouritesList;

    public final int CACHE_12_HOURS = 43_200_000;   // 12 hours
    public final int CACHE_7_DAYS = 604_800_000;   // 7 days
    public final long ONE_MONTH = 2_629_800_000L; //1 month

    //manual updates
    static int versionCode = -1;
    private static Boolean newVersionAvailable = null;

    private boolean downloadingApk = false;
    boolean checkingVersion = false;
    FdroidFdroid fdroid = null;
    String version = "";
    boolean gettingManual = false;
    boolean gettingEpubReader = false;
    boolean gettingKMS = false;
    boolean gettingDigitalOnboardingApp = false;

    //
    // various directories
    //
    File appDir;
    private File privateDir;
    private File pendingDir;
    private File notTenderdDir;
    private File autoCancelDir;
    private File voucherCacheDir;
    public File loginCacheDir;
    private File bundlesCacheDir;
    private File favouritesDir;
    private File calculatorDir;
    private File trainingDir;
    public File kmsAppDir;
    public File digitalOnboardingAppDir;
    private File billPaymentCacheDir;
    public File logsDir;
    private File downloadCacheDir;
    private File putcoCacheDir;
    private File carmaCacheDir;
    private File bustTicketsReprintsDir;
    private File ticketProAllEventsDir;
    private File ticketProCategoriesDir;
    public File privateLogsDir;
    public File printLogoCacheDir;
    public File callMeDir;
    public File dynamicPrintDir;
    public File bannerDir;
    public File searchDir;
    private File longhaulLogoCacheDir;
    public File ticketCancelCacheDir;
    public File nfcBusCacheDir;
    public File nfcBusTicketCacheDir;
    public File nfcBusRecoveryCacheDir;

    // FdroidFdroid fdroid = null;

    //handle Authentications
    boolean mustAuthenticateForAccounts = true;
    boolean mustgetAccountList = true;
    boolean mustgetInvoiceList = false;
    boolean mustgetShiftList = true;
    boolean isEndShiftState = false;
    boolean isClearingUntenderdState = false;
    private boolean needsToRetryAutoCancel = false;

    String accountId = "";

    //when not using a basket, the base activity does the tendering
    private String tenderAmount = null;
    private String tenderDescription = null;
    String supplierCode;
    public String amount;
    public String voucherType;

    int quantity;
    private int count;

    //name to be used for sales receipt
    public static String name = "";

    //back handling for categories
    public boolean navigatedFromFavourites = true;
    public boolean navigatedFromSearch = false;

    //
    // Log4j
    //
    public static Logger logger = null;

    //USB Print ticket
    public byte[] ticket;
    public byte[] logo = null;
    public boolean isTesting = false;
    public Boolean securePrint = null;
    public boolean isTicketProReprint = false;

    public static boolean loadFavouritesFirstTime = true;

    //BP
    public Double bpConvienceFee = 0.0;

    //Electricity
    public String meterNum;
    public MagcardInterface magCard;
    public NFCCardInterface nfcCard;
    public String magCardAction;
    public List<MagCardData> magCardDataList;
    List<MagCardData> magCardUpdateDataList;
    public static boolean isReadingMag = true;
    public boolean isEncodingMagToken = false;

    public int tokensSize;
    public int cardNumber = 1;
    public boolean isElectricityResponseFirstTime = true;
    boolean isKeyChange = false;

    public DeviceEngine deviceEngine;

    //multiple voucher messages
    MultipleVouchersAuthenticationRequestMessage multipleVouchersAuthenticationRequestMessage = null;
    MultipleVouchersAuthenticationResponseMessage multipleVouchersAuthenticationResponseMessage = null;

    AirtimeTopupResponsePurchaseMessage AirtimeTopupResponsePurchaseMessage = null;
    BundlesResponseDoBundleTopupMessage bundlesResponseDoBundleTopupMessage = null;

    public DecimalFormat df2;

    // Carma ticket fragments instance
    public FragmentCarmaSearchResults fragmentCarmaSearchResults = null;
    public FragmentCarmaPassengerDetailsWizard fragmentCarmaPassengerDetailsWizard = null;
    public FragmentCarmaConfirmPurchaseTicketNew fragmentCarmaConfirmPurchaseTicket = null;
    public FragmentCarmaEmergencyContactDetails fragmentCarmaEmergencyContactDetails = null;
    public FragmentBusTicketsReprints fragmentBusTicketsReprints = null;
    //Carma data
    public String emergencyName, emergencyNumber;
    public ArrayList<BluDroidRoutesAndTimes> bluDroidRoutesAndTimesTrips = new ArrayList<>();
    public ArrayList<BluDroidRoutesAndTimes> departureRoutes = new ArrayList<>();
    public ArrayList<BluDroidRoutesAndTimes> returnRoutes = new ArrayList<>();
    //updates
    boolean onlineLogin = false;

    public static ConcurrentHashMap<Integer, CountDownTimer> timers = null;

    public static boolean isVoucherPrinted = true;
    public boolean gettingWalletTopup = false;
    public static ArrayList<String> walletTopupProviders;

    public BluDroidToolBar toolbar;

    String accountBalance;
    private View accountBalanceGrouptoggle = null;

    public static String loggedInUserName;

    static String location; // LB added for location services

    // memory size things
    private static String externalSize = "";
    private static String internalSize = "";
    private static String ramSize = "";

    private String busTicketDateTime;

    public static boolean isLotto = false;

    public Map<String, String[]> customerProfileElectricityAccountNumbers = new HashMap<>();
    public Map<String, String[]> customerProfileTopupAccountNumbers = new HashMap<>();
    public Map<String, String[]> customerProfileBundlesAccountNumbers = new HashMap<>();
    public Map<String, String[]> customerProfileBillPaymentsAccountNumbers = new HashMap<>();

    //airtimePlus
    public boolean isAirtimePlusAllowed = false;
    public String airtimePlusValue;
    public String airtimePlusPlayed = "0";

    // Chat for Change mvno
    static Chat4ChangeResponseListSuppliersMessage chat4ChangeResponseListSuppliersMessage = null;
    // for auth or getting voucher, since getting supplier list authenticates and its response is handled at the same point as getting of voucher
    public static boolean gettingVouchers = false;
    public static boolean gettingMvnoVoucher = false;
    public static String supplierName = "";
    public static boolean gettingCarmaTicket = false;

    // NFC
    public static ConsumerProfile consumerProfile = null;
    public static CompleteConsumerProfile completeConsumerProfile = null;
    public static String loyaltyServerBaseUrl = null;
    public static String cell_or_card_number = null;
    static boolean restartBluDroidForFirebase;

    //Heartbeat
    private static String AEONheartbeat = "0";
    public static Queue<Integer> queue = new PriorityQueue<>();

    private BluDroidScreenBrightnessReceiver brightnessReceiver;

    // Google Firebase  Analytics
    private FdroidUtils fdroidUtils;
    public FirebaseAnalytics mFirebaseAnalytics;
    public Bundle firebaseBundle;
    public Boolean connectedToAEON = false;
    public long firebaseSessionLength;
    public static long firebaseSessionStart;
    public long firebaseSessionEnd;
    public static String firebaseSessionId;
    public Boolean isInRicaFirstTime = false;
    //Used for Firebase
    public FirebaseRemoteConfig mFirebaseRemoteConfig;
    private static boolean firebaseEnabled;

    public boolean returnToFavouritesScreen = false;

    //Dynamic printing
    private RequestQueue mQueue;

    private TicketCacheHandler ticketCacheHandler;
    public NfcBusRecoveryCacheHandler recoveryCacheHandler;
    private BillPaymentsResponseSapoConfirmMessage sapoResponseMessage;
    private IthubaResponseItbLotteryMessage responseItbLotteryMessage;
    private BillPaymentsResponseSyntellConfirmMessage responseSyntellConfirmMessage;
    private BillPaymentsResponsePayAtConfirmMessage responsePayAtConfirmMessage;


    private void setFirebaseEnabled(boolean enabled) {
        firebaseEnabled = enabled;
        mFirebaseAnalytics.setAnalyticsCollectionEnabled(enabled);
        FirebaseCrashlytics.getInstance().setUserId(getPreference(PREF_DEVICE_ID));
        FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(enabled);
    }

    void saveFirebaseAeonFlag() {
        boolean enable = loginResponseMessage.getEvent().getDT_IotEnable().equals("1");
        boolean currentPref = getPreference(PREF_IOT_FLAG_ENABLE).equals(PREF_TRUE);
        Log.d("firebase", "from aeon = " + enable + " current pref = " + currentPref);
        if (enable != currentPref) {
            updatePreference(PREF_IOT_FLAG_ENABLE, String.valueOf(enable));
            restartBluDroidForFirebase = true;
        } else {
            restartBluDroidForFirebase = false;
        }
    }

    public void firebaseSessionEnd(String endingType) {
        firebaseBundle = new Bundle();

        firebaseBundle.putString("ending_type", endingType);
        firebaseBundle.putString("bd_session_id", firebaseSessionId);
        firebaseSessionEnd = System.currentTimeMillis();
        firebaseSessionLength = firebaseSessionEnd - firebaseSessionStart;
        firebaseBundle.putLong("bd_session_length", firebaseSessionLength);
        mFirebaseAnalytics.logEvent("bd_session_end", firebaseBundle);
    }

    public void firebaseErrorLogging(String errorType) {
        firebaseBundle = new Bundle();

        firebaseBundle.putString("error_type", errorType);

        mFirebaseAnalytics.logEvent("bd_error", firebaseBundle);
    }

    public void crashLog(String tag, String msg) {
        if (firebaseEnabled) {
            FirebaseCrashlytics.getInstance().log(tag + " " + msg);
        }
    }

    void restartBluDroid() {
        Intent mStartActivity = new Intent(BaseActivity.this, ActivityLanding.class);
        int mPendingIntentId = 123456;
        PendingIntent mPendingIntent = PendingIntent.getActivity(BaseActivity.this, mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager mgr = (AlarmManager) BaseActivity.this.getSystemService(Context.ALARM_SERVICE);
        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
        System.exit(0);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createDirsIfNecessary();
        configureLog4j();
        fdroidUtils = new FdroidUtils();

        ticketCacheHandler = new TicketCacheHandler(ticketCancelCacheDir);
        recoveryCacheHandler = new NfcBusRecoveryCacheHandler(nfcBusRecoveryCacheDir);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        mFirebaseAnalytics.setUserProperty("user_id", getPreference(PREF_DEVICE_ID));
        mFirebaseAnalytics.setUserId(getPreference(PREF_DEVICE_ID));

        String release = Build.VERSION.RELEASE;
        int sdkVersion = Build.VERSION.SDK_INT;
        String osVersion = sdkVersion + " (" + release + ")";

        mFirebaseAnalytics.setUserProperty("device_model", Build.MODEL);
        mFirebaseAnalytics.setUserProperty("device_serial_number", getPreference(PREF_DEVICE_SER));
        mFirebaseAnalytics.setUserProperty("os_version", osVersion);
        mFirebaseAnalytics.setUserProperty("bd3_version", fdroidUtils.getVersionName(this));

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);
        mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();

        boolean enableFirebaseAeon = getPreference(PREF_IOT_FLAG_ENABLE).equals(PREF_TRUE);

        Log.d("firebase", this.getClass().getSimpleName() + " firebase set to = " + enableFirebaseAeon);
        setFirebaseEnabled(enableFirebaseAeon);

        crashLog("Activity", this.getClass().getSimpleName());

        //dynamic printing request
        mQueue = Volley.newRequestQueue(this);

        setUpBrightnessreceiver();

        checkPreference();

        String currentTheme = getPreference(PREF_SKIN);

        gettingVouchers = false;

        if (currentTheme.equals("BLT")) {
            setTheme(R.style.BLTTheme);
            updatePreference(PREF_PREVIOUS_SKIN, getString(R.string.blt));
        } else if (currentTheme.equals("TSPC")) {
            setTheme(R.style.TSPCTheme);
            updatePreference(PREF_PREVIOUS_SKIN, getString(R.string.tspc));
        } else if (currentTheme.equals("GCRS")) {
            setTheme(R.style.GCRSTheme);
            updatePreference(PREF_PREVIOUS_SKIN, getString(R.string.gcrs));
        } else {
            setTheme(R.style.BLTTheme);
            updatePreference(PREF_PREVIOUS_SKIN, getString(R.string.blt));
        }

        configureSkin();

        checkPermissions();
        configurePrinter();

        //get wallet topup providers
        walletTopupProviders = new ArrayList<>(Arrays.asList(getResources().getStringArray(R.array.walletTopupProviders)));
    }

    private void setUpBrightnessreceiver() {
        //setUp the screen off broadcast receiver
        if (!(this instanceof ActivitySetup)) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            brightnessReceiver = new BluDroidScreenBrightnessReceiver(this);
            registerReceiver(brightnessReceiver, filter);
        }
    }

    private void initialize() {

        createDirsIfNecessary();

        if (logger == null) {
            configureLog4j();
        }
        resetTimer();

        Log.d(TAG, "calling check preference");

        securePrint = getPreference(PREF_SECURE_USB_PRINTER).equals(PREF_TRUE);

        NumberFormat nf = NumberFormat.getNumberInstance(Locale.US);
        df2 = (DecimalFormat) nf;
        df2.applyPattern("0.00");

        if (aeonErrors == null)
            aeonErrors = new AEONErrors();

        if (timers == null) {
            timers = new ConcurrentHashMap<>();
        }
        if (smartPrinter == null) {
            configurePrinter();
        }

        versionCode = fdroidUtils.getVersionCode(this);
        String versionName = fdroidUtils.getVersionName(this);

        Log.d(TAG, "versionCode = " + versionCode);
        Log.d(TAG, "versionName = " + versionName);

        Log.d(TAG, "skin is " + getPreference(PREF_SKIN));
//            Log.d(TAG, "text color is " + skinResources.getBackgroundTextColor());
        if (externalSize.isEmpty() || internalSize.isEmpty() || ramSize.isEmpty()) {
            externalSize = getAvailableExternalMemorySize();
            internalSize = getAvailableInternalMemorySize();
            ramSize = getRAMSize();

            if (logger != null) {
                logger.info("Available external memory size: " + getAvailableExternalMemorySize() + " Available internal memory size: " + getTotalInternalMemorySize() + " Available RAM size: " + getRAMSize());
            }
        }


        loyaltyServerBaseUrl = getPreference(PREF_LOYALTY_URL) + "/consumer/loyalty/v1/profile/";

        if (readCompleteFavouritesList().isEmpty()) {
            createDefaultFavouritesList();
        }

        checkSetup();
    }

    public boolean isConsumerProfileActive() {
        return consumerProfile != null && Integer.parseInt(consumerProfile.getProfileId()) > 0;
    }

    public void clearNFCActiveConsumer(boolean loadMainScreen) {
        consumerProfile = null;
        completeConsumerProfile = null;
        cell_or_card_number = null;

        String previousSkin = getPreference(PREF_PREVIOUS_SKIN);
        updatePreference(PREF_SKIN, previousSkin);

        if (previousSkin.equals("BLT")) {
            setTheme(R.style.BLTTheme);
        } else if (previousSkin.equals("TSPC")) {
            setTheme(R.style.TSPCTheme);
        } else {
            setTheme(R.style.AppTheme);
        }
        configureSkin();

        customerProfileElectricityAccountNumbers = new HashMap<>();
        customerProfileTopupAccountNumbers = new HashMap<>();
        customerProfileBundlesAccountNumbers = new HashMap<>();
        customerProfileBillPaymentsAccountNumbers = new HashMap<>();
        if (loadMainScreen) {
            gotoMainScreen();
            toolbar.setup();
        }

    }

    //
    // NB:  this must run after createDirsIfNecessary
    //
    private void configureLog4j() {
        BluDroidLogging logging = new BluDroidLogging(this);
        logger = logging.getLogger();
    }

    //Warren - This little check check to see what bundle transaction types the user has on their AEON Account
    List<String> getAllBundleProviders() {
        List<String> list = new ArrayList<>();
        if (loginResponseMessage != null) {
            LoginResponseDataMessage data = loginResponseMessage.getData();
            for (int i = 0; i < data.getTransactionTypes().size(); i++) {
                LoginResponseGroupMessage group = data.getTransactionTypes().get(i);
                for (int j = 0; j < group.getTransactionTypes().size(); j++) {
                    LoginResponseTransactionTypeMessage transactionType = group.getTransactionTypes().get(j);
                    String transactionName = transactionType.getDisplayName();
                    String type = transactionType.getType().toLowerCase();
                    if (type.equalsIgnoreCase("bundles") && !transactionName.equalsIgnoreCase("lucky365")) {
                        list.add(transactionName);
                    }

                }
            }
        }
        return list;
    }

    void removeTechToggleErrors() {
        deviceSettingsHaserrors = false;
        ricaSettingsHaserrors = false;
        timeoutSettingsHaserrors = false;
        repositorySettingsHaserrors = false;
        ePubSettingsHaserrors = false;
        heartbeatSettingsHaserrors = false;
        apiGatewaySettingsHaserrors = false;
        bluKeySettingsHaserrors = false;
    }

    void removeDeviceToggleErrors() {
        receiptSettingsHaserrors = false;
        deviceUserSettingsHaserrors = false;
        storeSettingsHaserrors = false;
    }

    void configurePrinter() {
        try {
            smartPrinter = new MockSmartPrinter();

            if (TEST_MODE) {
                return;
            }

            Log.d(TAG, "model is [" + Build.MODEL + "]");
            if (Build.MODEL.contains("CITAQ")) {
                smartPrinter = new CitaqSmartPrinter();
            } else if (Build.MODEL.startsWith("V1") || Build.MODEL.startsWith("P1")) {
                smartPrinter = new SunmiPrinter();
            } else if (Build.MODEL.equals("N3")) {
                smartPrinter = new NexgoN3SmartPrinter();
            }

            if (!(this instanceof ActivitySetup)) {
                smartPrinter.initialise(this);
            }

            printWidth = Integer.parseInt(getPreference(PREF_PRINTER_WIDTH));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < printWidth; i++) {
                sb.append("_");
            }
            HORIZONTAL_LINE = sb.toString();
        } catch (Exception exception) {
            if (logger != null) {
                Log.d(TAG, "problem initialsing printer " + exception);
                logger.error("problem initialising printer " + exception);
            }
        }
    }

    void removeZipFolder() {
        try {
            File[] zipFolder = logsDir.listFiles();
            for (File file : zipFolder) {
                if (file.delete()) {
                    Log.d(TAG, file.getName() + " removed.");
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems removing old zip folder " + exception);
        }
    }

    //
    // internal directories used by various functions
    //
    @SuppressWarnings("ResultOfMethodCallIgnored")
    void createDirsIfNecessary() {
        try {
            Log.d("Create Directories", Environment.getExternalStorageDirectory().getPath());

            appDir = new File(Environment.getExternalStorageDirectory().getPath() + "/" + getResources().getString(R.string.app_name));
            privateDir = new File(this.getFilesDir().getPath() + "/" + getResources().getString(R.string.app_name));
            privateLogsDir = new File(this.getFilesDir().getPath() + "/" + getString(R.string.pvtlogs));
            printLogoCacheDir = new File(this.getFilesDir().getPath() + "/" + getString(R.string.printLogoCache));
            callMeDir = new File(this.getFilesDir().getPath() + "/" + getString(R.string.callMeDir));
            dynamicPrintDir = new File(this.getFilesDir().getPath() + "/" + getString(R.string.dynamicPrintDir));
            bannerDir = new File(this.getFilesDir().getPath() + "/" + getString(R.string.bannerDir));
            searchDir = new File(this.getFilesDir().getPath() + "/" + getString(R.string.searchDir));

            if (!appDir.exists()) {
                appDir.mkdir();
            }

            if (!privateDir.exists()) {
                privateDir.mkdir();
            }

            if (!printLogoCacheDir.exists()) {
                printLogoCacheDir.mkdir();
            }

            if (!callMeDir.exists()) {
                callMeDir.mkdir();
            }

            if (!dynamicPrintDir.exists()) {
                dynamicPrintDir.mkdir();
            }

            if (!bannerDir.exists()) {
                bannerDir.mkdir();
            }

            if (!searchDir.exists()) {
                searchDir.mkdir();
            }

            logsDir = new File(appDir.getPath() + "/" + getResources().getString(R.string.logsDir));
            if (!logsDir.exists()) {
                logsDir.mkdir();
            }

            if (!privateLogsDir.exists()) {
                privateLogsDir.mkdir();

                File[] logs = logsDir.listFiles();

                //move files from logsDir to privateLogsDir
                for (int i = 0; i < logs.length; i++) {
                    InputStream inStream;
                    OutputStream outStream;

                    try {
                        File sourceFile = new File(logs[i].getPath());
                        File destinationFile = new File(privateLogsDir.getPath() + "/" + logs[i].getName());

                        inStream = new FileInputStream(sourceFile);
                        outStream = new FileOutputStream(destinationFile);

                        byte[] buffer = new byte[1024];

                        int length;
                        //copy the file content in bytes
                        while ((length = inStream.read(buffer)) > 0) {
                            outStream.write(buffer, 0, length);
                        }

                        inStream.close();
                        outStream.close();

                        //delete the original file
                        sourceFile.delete();

                        Log.d(TAG, "createDirsIfNecessary: " + logs[i].getName() + " is copied successful!");
                        Log.d(TAG, "createDirsIfNecessary: " + i);

                    } catch (IOException e) {
                        e.printStackTrace();
                        logger.error("createDirsIfNecessary exception " + e);
                    }
                }
            }

            pendingDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.pendingDir));
            if (!pendingDir.exists()) {
                pendingDir.mkdir();
            }

            notTenderdDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.notTenderedDir));
            if (!notTenderdDir.exists()) {
                notTenderdDir.mkdir();
            }

            autoCancelDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.autoCancelDir));
            if (!autoCancelDir.exists()) {
                autoCancelDir.mkdir();
            }

            loginCacheDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.loginCacheDir));
            if (!loginCacheDir.exists()) {
                loginCacheDir.mkdir();
            }

            voucherCacheDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.voucherCacheDir));
            if (!voucherCacheDir.exists()) {
                voucherCacheDir.mkdir();
            }

            bundlesCacheDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.bundlesCacheDir));
            if (!bundlesCacheDir.exists()) {
                bundlesCacheDir.mkdir();
            }

            favouritesDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.favouritesDir));
            if (!favouritesDir.exists()) {
                favouritesDir.mkdir();
            }

            File reprintsDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.reprintsDir));
            if (!reprintsDir.exists()) {
                reprintsDir.mkdir();
            }

            trainingDir = new File(appDir.getPath() + "/" + getResources().getString(R.string.trainingDir));
            if (!trainingDir.exists()) {
                trainingDir.mkdir();
            }

            kmsAppDir = new File(appDir.getPath() + "/" + getResources().getString(R.string.kmsAppDir));
            if (!kmsAppDir.exists()) {
                kmsAppDir.mkdir();
            }

            digitalOnboardingAppDir = new File(appDir.getPath() + "/" + getResources().getString(R.string.digitalOnboardingAppDir));
            if (!digitalOnboardingAppDir.exists()) {
                digitalOnboardingAppDir.mkdir();
            }

            calculatorDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.calculatorDir));
            if (!calculatorDir.exists()) {
                calculatorDir.mkdir();
            }

            billPaymentCacheDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.billPaymentCacheDir));
            if (!billPaymentCacheDir.exists()) {
                billPaymentCacheDir.mkdir();
            }

            downloadCacheDir = new File(appDir.getPath() + "/" + getResources().getString(R.string.downloadCacheDir));
            if (!downloadCacheDir.exists()) {
                downloadCacheDir.mkdir();
            }

            putcoCacheDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.putcoCacheDir));
            if (!putcoCacheDir.exists()) {
                putcoCacheDir.mkdir();
            }

            carmaCacheDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.carmaCacheDir));
            if (!carmaCacheDir.exists()) {
                carmaCacheDir.mkdir();
            }

            longhaulLogoCacheDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.longhaulLogos));
            if (!longhaulLogoCacheDir.exists()) {
                longhaulLogoCacheDir.mkdir();
            }

            bustTicketsReprintsDir = new File(privateDir.getPath() + "/" + getResources().getString(R.string.bustTicketsReprintsDir));
            if (!bustTicketsReprintsDir.exists()) {
                bustTicketsReprintsDir.mkdir();
            }

            ticketProCategoriesDir = new File(appDir.getPath() + "/" + getResources().getString(R.string.ticketProCategoriesDir));
            if (!ticketProCategoriesDir.exists()) {
                ticketProCategoriesDir.mkdir();
            }

            ticketProAllEventsDir = new File(appDir.getPath() + "/" + getResources().getString(R.string.ticketProAllEventsDir));
            if (!ticketProAllEventsDir.exists()) {
                ticketProAllEventsDir.mkdir();
            }

            ticketCancelCacheDir = new File(appDir.getPath() + "/" + getResources().getString(R.string.ticketProAllEventsDir));
            if (!ticketCancelCacheDir.exists()) {
                ticketCancelCacheDir.mkdir();
            }

            nfcBusCacheDir = new File(appDir.getPath() + "/" + getString(R.string.nfcBusDir));
            if (!nfcBusCacheDir.exists()) {
                nfcBusCacheDir.mkdir();
            }

            nfcBusTicketCacheDir = new File(appDir.getPath() + "/" + getString(R.string.nfcBusTicketDir));
            if (!nfcBusTicketCacheDir.exists()) {
                nfcBusTicketCacheDir.mkdir();
            }

            nfcBusRecoveryCacheDir = new File(appDir.getPath() + "/" + getString(R.string.nfcBusRecoveryDir));
            if (!nfcBusRecoveryCacheDir.exists()) {
                nfcBusRecoveryCacheDir.mkdir();
            }

            deleteOldApks();

        } catch (Exception ex) {
//            ex.printStackTrace();
//            createAlertDialog("Create Directories", "Failed to create directories with reason :" + ex);
            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorCreateDirectories, true);
            if (logger != null)
                logger.error("Create Directories" + "Failed to create directories with reason :" + ex);
        }
    }

    public void saveDetailsUntilPaid(String transRef, String provider, String productName, String amount) {
        try {
            Log.d(TAG, "saveDetailsUntilPaid ");

            String description = provider + " " + productName;
            tenderAmount = amount;
            tenderDescription = description;

            this.transRef = transRef;
            this.amount = amount;

            String calculatorString = provider + ":" + productName + ":" + amount;

            saveTransactionList(calculatorString);

            saveUnTenderedTransactions(transRef, amount);
        } catch (Exception exception) {
            Log.d(TAG, "saveDetailsUntilPaid throws " + exception);
            logger.error("saveDetailsUntilPaid throws " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    private void saveUnTenderedTransactions(String transRef, String amount) {
        try {
            Log.d(TAG, "saveDetailsUntilPaid ");

            createDirsIfNecessary();
            File transRefFile = new File(notTenderdDir.getPath() + "/" + transRef + ".txt");
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(transRefFile));
            bufferedWriter.write(transRef + ", " + amount);
            bufferedWriter.flush();
            bufferedWriter.close();
            logger.info("UnTenderedTransactions" + transRef + "-" + amount + " saved");

        } catch (Exception exception) {
            Log.d(TAG, "saveUnTenderedTransactions throws " + exception);
            logger.error("saveUnTenderedTransactions throws " + exception);
        }
    }

    private void saveAutoCancelTransaction(String transRef, String ref) {
        try {
            Log.d(TAG, "saveDetailsUntilPaid ");

            createDirsIfNecessary();
            File transRefFile = new File(autoCancelDir.getPath() + "/" + transRef + ".txt");
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(transRefFile));
            bufferedWriter.write(transRef + "," + ref);
            bufferedWriter.flush();
            bufferedWriter.close();
            logger.info("saveAutoCancelTransaction " + transRef + "saved");

        } catch (Exception exception) {
            Log.d(TAG, "saveAutoCancelTransaction throws " + exception);
            logger.error("saveAutoCancelTransaction throws " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------

    private void saveDetailsUntilPaidC4C(String transRef, String provider, String productName, String amount) {
        try {
            Log.d(TAG, "saveDetailsUntilPaid ");
            String description = provider + " " + productName;
            tenderAmount = amount;
            tenderDescription = description;

            this.transRef = transRef;
            this.amount = amount;

            String calculatorString = provider + ":C4C Voucher:" + amount;

            saveTransactionList(calculatorString);
//            }
        } catch (Exception exception) {
            Log.d(TAG, "saveDetailsUntilPaid throws " + exception);
            logger.error("saveDetailsUntilPaid throws " + exception);
        }
    }

    void saveDetailsUntilPaidRechargePlus(String transRef, String provider, String productName, String amount) {
        try {
            Log.d(TAG, "saveDetailsUntilPaidRechargePlus ");
            logger.info("saving tranasction Until Paid /Tendered");

            String calculatorString = provider + ":" + productName + ":" + amount;

            saveTransactionList(calculatorString);

            saveUnTenderedTransactions(transRef, amount);

        } catch (Exception exception) {
            Log.d(TAG, "saveDetailsUntilPaid throws " + exception);
            logger.error("saveDetailsUntilPaid throws " + exception);
        }
    }

    private void saveDetailsUntilPaidLotto(String transRef, String description, String amount) {
        try {
            Log.d(TAG, "saveDetailsUntilPaid ");
            tenderAmount = amount;
            tenderDescription = description;

            this.transRef = transRef;
            this.amount = amount;

            String calculatorString = "Ithuba" + ":" + description + ":" + amount;

            saveTransactionList(calculatorString);
        } catch (Exception exception) {
            Log.d(TAG, "saveDetailsUntilPaid throws " + exception);
            logger.error("saveDetailsUntilPaid throws " + exception);
        }
    }

    private void resetTraining(String pinString) {
        try {
            createDirsIfNecessary();
            if (pinString.length() > 2) {
                String userId = pinString.substring(0, 2);
                //Log.d(TAG, "resetTraining pinString " + pinString + " userId " + userId);
                File file = new File(trainingDir.getPath() + "/" + userId + ".txt");
                //Log.d(TAG, "resetTraining file exists is " + file.exists());
                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file));
                bufferedWriter.write("0");
                bufferedWriter.flush();
                bufferedWriter.close();

                updatePreference(PREF_RICA_USERNAME + "_" + userId, PREF_UNKNOWN);
                updatePreference(PREF_RICA_PASSWORD + "_" + userId, PREF_UNKNOWN);
            }
        } catch (Exception exception) {
            Log.d(TAG, "updateTraining " + exception);
            logger.error("updateTraining " + exception);
        }
    }

    void hideShow(int resourceId, int visibility) {
        View view = findViewById(resourceId);
        view.setVisibility(visibility);
    }

    void hideShowWithAnimation(int resourceId, Animation anim, int visibility) {
        View view = findViewById(resourceId);
        view.startAnimation(anim);
        view.setVisibility(visibility);
    }

    void enableDisableConfigField(int fieldId, boolean isFieldEnabled) {
        View view = findViewById(fieldId);
        view.setEnabled(isFieldEnabled);
        // view.setFocusable(isFieldEnabled);
    }

    protected Date dateCallMeCache() {
        try {
            createDirsIfNecessary();
            Log.d(TAG, "callMeDir " + callMeDir);
            Log.d(TAG, "callMeDir.getPath() " + callMeDir.getPath());
            File cache = new File(callMeDir.getPath() + "/callme.txt");
            Log.d(TAG, "cache is " + cache);
            Log.d(TAG, "cache.lastModified is " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            Log.d(TAG, "problem with callme cache " + exception);
            logger.error(TAG + "problem with callme cache " + exception);
            return new Date(0L);
        }
    }

    protected void cacheCallMeData(String message) {
        try {
            File cache = new File(callMeDir.getPath() + "/callme.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
            bufferedWriter.write(message);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error(TAG + "marshaling exception " + exception);
        }
    }

    protected String getCachedCallMeData() {
        try {
            createDirsIfNecessary();
            File file = new File(callMeDir.getPath() + "/callme.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            return line;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading callme cache " + exception);
            logger.error(TAG + "problems reading callme cache " + exception);
        }
        return null;
    }

    protected void removeCallMeCache() {
        try {
            File file = new File(callMeDir.getPath() + "/callme.txt");
            file.delete();

        } catch (Exception exception) {
            Log.d(TAG, "problems removing callme cache " + exception);
            logger.error(TAG + "problems removing callme cache " + exception);
        }
    }

    //dynamic print
    protected Date dateDynamicPrintCache() {
        try {
            createDirsIfNecessary();
            File cache = new File(dynamicPrintDir.getPath() + "/dynamicprint.txt");
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            logger.error(TAG + "problem with dynamic print cache " + exception);
            return new Date(0L);
        }
    }

    public String getCachedDynamicPrint() {
        try {
            createDirsIfNecessary();
            File file = new File(dynamicPrintDir.getPath() + "/dynamicprint.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            return line;
        } catch (Exception exception) {
            logger.error(TAG + "problems reading dynamic printing cache " + exception);
        }
        return null;
    }

    protected void cacheDynamicPrint(String message) {
        try {
            File cache = new File(dynamicPrintDir.getPath() + "/dynamicprint.txt");
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
            bufferedWriter.write(message);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error(TAG + "problems writing dynamic printing cache " + exception);
        }
    }

    public void removeDynamicPrintCache() {
        try {
            File file = new File(dynamicPrintDir.getPath() + "/dynamicprint.txt");
            file.delete();
            if (dynamicPrintDir.exists() && dynamicPrintDir.isDirectory()) {
                deleteDir(dynamicPrintDir, false);
            }

        } catch (Exception exception) {
            logger.error(TAG + "problems removing dynamic print cache " + exception);
        }
    }

    protected Date dateBannerCache() {
        try {
            createDirsIfNecessary();
            Log.d(TAG, "bannerDir " + bannerDir);
            Log.d(TAG, "bannerDir.getPath() " + bannerDir.getPath());
            File cache = new File(bannerDir.getPath() + "/banner.txt");
            Log.d(TAG, "cache is " + cache);
            Log.d(TAG, "cache.lastModified is " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            logger.error(TAG + "problem with banner cache " + exception);
            return new Date(0L);
        }
    }

    protected void cacheBannerData(String message) {
        try {
            File cache = new File(bannerDir.getPath() + "/banner.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
            bufferedWriter.write(message);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error(TAG + "marshaling exception " + exception);
        }
    }

    public String getCachedBannerData() {
        try {
            createDirsIfNecessary();
            File file = new File(bannerDir.getPath() + "/banner.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            return line;
        } catch (Exception exception) {
            logger.error(TAG + "problems reading banner cache " + exception);
        }
        return null;
    }

    protected void removeBannerCache() {
        try {
            if (bannerDir.exists() && bannerDir.isDirectory()) {
                deleteDir(bannerDir, false);
            }
        } catch (Exception exception) {
            logger.error(TAG + "problems removing banner cache " + exception);
        }
    }

    //
    // search cache
    //
    protected void cacheSearchData(String message) {
        try {
            File cache = new File(searchDir.getPath() + "/search.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
            bufferedWriter.write(message);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error(TAG + "marshaling exception " + exception);
        }
    }

    public String getCachedSearchData() {
        try {
            createDirsIfNecessary();
            File file = new File(searchDir.getPath() + "/search.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            return line;
        } catch (Exception exception) {
            logger.error(TAG + "problems reading search cache " + exception);
        }
        return null;
    }

    protected void cacheSearchData1(List<CardviewDataObject> list) {
        try {
            FileOutputStream fos = openFileOutput("search.txt", Context.MODE_PRIVATE);
            ObjectOutputStream os = new ObjectOutputStream(fos);
            os.writeObject(list);
            os.close();
            fos.close();
        } catch (Exception exception) {
            logger.error(TAG + "marshaling exception " + exception);
        }
    }

    public List<CardviewDataObject> getCachedSearchData1() {
        try {
            createDirsIfNecessary();
            FileInputStream fis = openFileInput("search.txt");
            ObjectInputStream is = new ObjectInputStream(fis);
            List<CardviewDataObject> list = (List<CardviewDataObject>) is.readObject();
            is.close();
            fis.close();
            return list;
        } catch (Exception exception) {
            logger.error(TAG + "problems reading search cache " + exception);
        }
        return null;
    }

    protected void removeSearchCache() {
        try {
            Log.w("FragmentSearch", "removing search cache");
            File dir = getFilesDir();
            File file = new File(dir, "search.txt");
            file.delete();
        } catch (Exception exception) {
            logger.error(TAG + "problems removing search cache " + exception);
        }
    }


    //
    // voucher cache
    //
    Date dateLastVoucherCache() {
        try {
            createDirsIfNecessary();
            Log.d(TAG, "voucherCacheDir " + voucherCacheDir);
            Log.d(TAG, "voucherCacheDir.getPath() " + voucherCacheDir.getPath());
            File cache = new File(voucherCacheDir.getPath() + "/voucherdata.txt");
            Log.d(TAG, "cache is " + cache);
            Log.d(TAG, "cache.lastModified is " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            Log.d(TAG, "problem with voucher cache " + exception);
            logger.error("problem with voucher cache " + exception);
            return new Date(0L);
        }
    }

    void cacheVoucherData(VoucherListResponseMessage message) {
        try {
            removeSearchCache();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            String st = xmlProcessor.marshal(message.getData());

            File cache = new File(voucherCacheDir.getPath() + "/voucherdata.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
            bufferedWriter.write(st);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error("marshaling exception " + exception);
        }
    }

    VoucherListResponseMessage getCachedVoucherData() {
        try {
            createDirsIfNecessary();
            File file = new File(voucherCacheDir.getPath() + "/voucherdata.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            VoucherListResponseMessage msg = new VoucherListResponseMessage();
            msg.getEvent().setEventCode("0");
            msg.setData((VoucherListResponseDataMessage) xmlProcessor.unmarshal(line, VoucherListResponseDataMessage.class));
            return msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading voucher cache " + exception);
            logger.error("problems reading voucher cache " + exception);
        }
        return null;
    }

    void removeVoucherCache() {
        try {
            File file = new File(voucherCacheDir.getPath() + "/voucherdata.txt");
            file.delete();

        } catch (Exception exception) {
            Log.d(TAG, "problems removing voucher cache " + exception);
            logger.error("problems removing voucher cache " + exception);
        }
    }

    Date dateLastLoginCache(String pin) {
        try {
            createDirsIfNecessary();
            Log.d(TAG, "loginCacheDir " + loginCacheDir);
            Log.d(TAG, "loginCacheDir.getPath() " + loginCacheDir.getPath());
            File cache = new File(loginCacheDir.getPath() + "/logindata" + pin + ".txt");
            if (cache.exists()) {
                return new Date(cache.lastModified());
            } else {
                return new Date(0L);
            }
        } catch (Exception exception) {
            Log.d(TAG, "problem with voucher cache " + exception);
            logger.error("problem with voucher cache " + exception);
            return new Date(0L);
        }
    }

    void cacheLoginData(LoginResponseMessage message) {
        try {
            removeSearchCache();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            String st = xmlProcessor.marshal(message);

            File cache = new File(loginCacheDir.getPath() + "/logindata" + message.getData().getUserPin() + ".txt");

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
            bufferedWriter.write(st);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error("marshaling exception " + exception);
        }
    }

    void getLoginCache(String pin) {
        try {

            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();

            Log.d(TAG, "loginCacheDir " + loginCacheDir);
            Log.d(TAG, "loginCacheDir.getPath() " + loginCacheDir.getPath());
            File cache = new File(loginCacheDir.getPath() + "/logindata" + pin + ".txt");

            if (cache.exists()) {

                InputStream is = new FileInputStream(cache);
                BufferedReader buf = new BufferedReader(new InputStreamReader(is));
                String line = buf.readLine();
                StringBuilder sb = new StringBuilder();

                while (line != null) {
                    sb.append(line).append("\n");
                    line = buf.readLine();
                }
                String fileAsString = sb.toString();

                loginResponseMessage = (LoginResponseMessage) xmlProcessor.unmarshal(fileAsString, LoginResponseMessage.class);
                Log.d(TAG, "cache is " + cache);
                Log.d(TAG, "cache.lastModified is " + cache.lastModified());
            } else {
                loginResponseMessage = null;
            }
        } catch (Exception exception) {
            Log.d(TAG, "problem with voucher cache " + exception);
            logger.error("problem with voucher cache " + exception);
            loginResponseMessage = null;
        }
    }


    public void removeLoginCache() {
        try {
            File file = new File(loginCacheDir.getPath());
            for (File f : file.listFiles()) {
                f.delete();
            }

        } catch (Exception exception) {
            Log.d(TAG, "problems removing login cache " + exception);
            logger.error("problems removing login cache " + exception);
        }
    }

    //
    // bundles cache
    //
    Date dateLastBundlesCache() {
        try {
            createDirsIfNecessary();
            Log.d(TAG, "bundlesCacheDir " + bundlesCacheDir);
            Log.d(TAG, "bundlesCacheDir.getPath() " + bundlesCacheDir.getPath());
            File cache = new File(bundlesCacheDir.getPath()); //  + "/voucherdata.txt");
            Log.d(TAG, "cache is " + cache);
            Log.d(TAG, "cache.lastModified is " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            Log.d(TAG, "problem with bundles cache " + exception);
            logger.error("problem with bundles cache " + exception);
            return new Date(0L);
        }
    }

    void cacheBundlesData(String bundleName, BundlesResponseGetProductListMessage message) {
        try {
            removeSearchCache();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            String st = xmlProcessor.marshal(message.getData());

            File cache = new File(bundlesCacheDir.getPath() + "/" + bundleName + ".txt"); //voucherdata.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
            bufferedWriter.write(st);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            Log.d(TAG, "marshaling exception " + exception);
            logger.error("marshaling exception " + exception);
        }
    }

    BundlesResponseGetProductListMessage getCachedBundlesData(String bundleName) {
        try {
            createDirsIfNecessary();
            File file = new File(bundlesCacheDir.getPath() + "/" + bundleName + ".txt"); //voucherdata.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            BundlesResponseGetProductListMessage msg = new BundlesResponseGetProductListMessage();
            msg.getEvent().setEventCode("0");
            msg.setData((BundlesResponseGetProductListDataMessage) xmlProcessor.unmarshal(line, BundlesResponseGetProductListDataMessage.class));
            return msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading bundles cache " + exception);
            logger.error("problems reading bundles cache " + exception);
        }
        return null;
    }

    void removeAllBundlesCache() {
        try {
            File bundleDir = new File(bundlesCacheDir.getPath());
            for (File f : bundleDir.listFiles()) {
                f.delete();
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems removing bundles cache " + exception);
            logger.error("problems removing bundles cache " + exception);
        }
    }

    //
    // billpayment cache
    //
    private Date dateLastBillPaymentCache() {
        try {
            Log.d(TAG, "billPaymentCacheDir " + billPaymentCacheDir);
            Log.d(TAG, "billPaymentCacheDir.getPath() " + billPaymentCacheDir.getPath());

            File cache = new File(billPaymentCacheDir.getPath() + "/billpaymentdata.txt");
            Log.d(TAG, "dateLastBillPaymentCache : " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            logger.error("problem with bill payment cache " + exception);
            return new Date(0L);
        }
    }

    //
    // only the V1-G* models have security for caching
    //
    private void cacheBillPaymentData(BillPaymentsResponseProductListMessage message) {
        try {
            removeSearchCache();
            Log.d(TAG, "Build.MODEL " + Build.MODEL);
            if (Build.MODEL.startsWith("lcsh6580") || Build.MODEL.startsWith("V1-G") || Build.MODEL.startsWith("Android SDK")) {
                SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
                String st = xmlProcessor.marshal(message.getData());
                //Log.d(TAG, "billPaymentCacheDir is " + billPaymentCacheDir.getPath());
                File cache = new File(billPaymentCacheDir.getPath() + "/billpaymentdata.txt");
                //Log.d(TAG, "last modified is " + new Date(cache.lastModified()));
                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
                bufferedWriter.write(st);
                bufferedWriter.flush();
                bufferedWriter.close();
            }
        } catch (Exception exception) {
            Log.d(TAG, "marshaling exception " + exception);
            logger.error("marshaling exception " + exception);
        }
    }

    private BillPaymentsResponseProductListMessage getCachedBillPaymentData() {
        try {
            File file = new File(billPaymentCacheDir.getPath() + "/billpaymentdata.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            BillPaymentsResponseProductListMessage msg = new BillPaymentsResponseProductListMessage();
            msg.setData((BillPaymentsResponseProductListDataMessage) xmlProcessor.unmarshal(line, BillPaymentsResponseProductListDataMessage.class));
            return msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading bill payment cache " + exception);
            logger.error("problems reading bill payment cache " + exception);
        }
        return null;
    }

    private boolean isCachingRequired(File cacheFile) {
        // Let's make sure we are checking against a file and not a directory
        if (cacheFile.isDirectory()) {
            cacheFile.delete();
        }
        // Check the provided file's last modified time against the cache timeout
        return (((new Date()).getTime() - cacheFile.lastModified()) > CACHE_12_HOURS);
    }

    private void writeCacheDataToFile(File cacheFile, Object dataForSerialisation) throws Exception {
        SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
        String serialisedData = xmlProcessor.marshal(dataForSerialisation);
        if (!cacheFile.exists()) {
            cacheFile.createNewFile();
        }
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cacheFile));
        bufferedWriter.write(serialisedData);
        bufferedWriter.flush();
        bufferedWriter.close();
    }

    void removeBillPaymentCache() {
        try {
            File file = new File(billPaymentCacheDir.getPath() + "/billpaymentdata.txt");
            file.delete();
        } catch (Exception exception) {
            Log.d(TAG, "problems removing billpayment cache " + exception);
            logger.error("problems removing billpayment cache " + exception);
        }
    }

    public void removeCarmaCache() {
        try {
            File file = new File(carmaCacheDir.getPath());

            File[] files = file.listFiles();
            for (File f : files) {
                f.delete();
            }

            file.delete();
        } catch (Exception exception) {
            Log.d(TAG, "problems removing carma cache " + exception);
            logger.error("problems removing carma cache " + exception);
        }
    }

    protected void removeLonghaulLogosCache() {
        try {
            File file = new File(longhaulLogoCacheDir.getPath());

            File[] files = file.listFiles();
            for (File f : files) {
                f.delete();
            }

            //file.delete();
        } catch (Exception exception) {
            Log.d(TAG, "problems removing longhaul cache " + exception);
            logger.error(TAG + "problems removing longhaul cache " + exception);
        }
    }

    protected void removeTicketCancelCache() {
        try {
            File file = new File(ticketCancelCacheDir.getPath());

            File[] files = file.listFiles();
            for (File f : files) {
                f.delete();
            }

            //file.delete();
        } catch (Exception exception) {
            Log.d(TAG, "problems removing ticket cancel cache " + exception);
            logger.error(TAG + "problems removing ticket cancel cache " + exception);
        }
    }

    protected void removePrintLogoCache() {
        try {
            File file = new File(printLogoCacheDir.getPath());

            File[] files = file.listFiles();
            for (File f : files) {
                f.delete();
            }

            //file.delete();
        } catch (Exception exception) {
            Log.d(TAG, "problems removing print logo cache " + exception);
            logger.error(TAG + "problems removing print logo cache " + exception);
        }
    }

    protected void removeOldPrintLogos() {
        try {
            File[] files = printLogoCacheDir.listFiles();
            long now = System.currentTimeMillis();
            for (File f : files) {
                if (now - f.lastModified() > OLD_LOGO_THRESHOLD) {
                    f.delete();
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems removing print logo cache " + exception);
            logger.error(TAG + "problems removing print logo cache " + exception);
        }
    }

    void removePutcoCache() {
        try {
            File file = new File(putcoCacheDir.getPath());

            File[] files = file.listFiles();
            for (File f : files) {
                f.delete();
            }

            file.delete();
        } catch (Exception exception) {
            Log.d(TAG, "problems removing putco cache " + exception);
            logger.error("problems removing putco cache " + exception);
        }
    }

    void removeMVNOCache() {
        try {
            File file = new File(voucherCacheDir.getPath() + "/mvnodata.txt");
            file.delete();
        } catch (Exception exception) {
            Log.d(TAG, "problems removing mvno cache " + exception);
            logger.error("problems removing mvno cache " + exception);
        }
    }


//Caching of carrier and stop data is not implemented, since destinations for selected departure point are looked up in real time.
//If by any chance a new destination has been added that is not in the cached data, errors will occur since they cannot be looked
//up in the ActivityNfcBus.stopsMap.
/*
    public Date dateNfcBusCarrierCache() {
        try {
            createDirsIfNecessary();
            File cache = new File(nfcBusCacheDir.getPath() + "/carriers.txt");
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            logger.error(TAG + "problem with nfc bus carrier cache " + exception);
            return new Date(0L);
        }
    }

    public void cacheNfcBusCarriers(NfcBusListCarriersResponseMessage message) {
        try {
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            String st = xmlProcessor.marshal(message);

            File cache = new File(nfcBusCacheDir.getPath() + "/carriers.txt");
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
            bufferedWriter.write(st);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error(TAG + "problems writing nfc bus carrier cache " + exception);
        }
    }

    public NfcBusListCarriersResponseMessage getCachedNfcBusCarriers() {
        try {
            createDirsIfNecessary();
            File file = new File(nfcBusCacheDir.getPath() + "/carriers.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            return (NfcBusListCarriersResponseMessage) xmlProcessor.unmarshal(line, NfcBusListCarriersResponseMessage.class);
        } catch (Exception exception) {
            logger.error(TAG + "problems reading nfc bus carrier cache " + exception);
        }
        return null;
    }

    public void removeNfcBusCache() {
        try {
            createDirsIfNecessary();
            File[] files = nfcBusCacheDir.listFiles();
            for (File file : files) {
                file.delete();
            }
        } catch (Exception exception) {
            logger.error(TAG + "problems removing nfc bus cache " + exception);
        }
    }

    public void cacheNfcBusStops(long carrierId, NfcBusListStopsResponseMessage message) {
        try {
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            String st = xmlProcessor.marshal(message);

            File cache = new File(nfcBusCacheDir.getPath() + "/stops" + carrierId + ".txt");
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
            bufferedWriter.write(st);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error(TAG + "problems writing nfc bus stops cache for carrier "+ carrierId + ": " + exception);
        }
    }

    public NfcBusListStopsResponseMessage getCachedNfcBusStops(long carrierId) {
        try {
            createDirsIfNecessary();
            File file = new File(nfcBusCacheDir.getPath() + "/stops" + carrierId + ".txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            return (NfcBusListStopsResponseMessage) xmlProcessor.unmarshal(line, NfcBusListStopsResponseMessage.class);
        } catch (Exception exception) {
            logger.error(TAG + "problems reading nfc bus stops cache for carrier "+ carrierId + ": " + exception);
        }
        return null;
    }
*/


    public boolean isDebug() {
        return BuildConfig.BUILD_TYPE.contentEquals("debug");
    }

    public boolean isQa() {
        return BuildConfig.BUILD_TYPE.contentEquals("qa");
    }

    public boolean isGcrs() {
        return BuildConfig.BUILD_TYPE.contentEquals("gcrs");
    }

    public boolean isRelease() {
        return BuildConfig.BUILD_TYPE.contentEquals("release");
    }

    public boolean isRunningInEmulator() {
        return getPreference(PREF_DEVICE_SER).equals("unknown");
    }

    //
    // get a preference
    //
    @SuppressLint("HardwareIds")
    public String getPreference(String key) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String value;
        if (key.equals(PREF_DEVICE_SER)) {
            value = sharedPreferences.getString(key, Build.SERIAL);
        } else if (key.equals(PREF_SECURE_USB_PRINTER) && Build.MODEL.startsWith("V1")) {
            value = PREF_FALSE;
        } else {
            value = sharedPreferences.getString(key, PREF_UNKNOWN);
        }
        return value;
    }

    //
    // update a preference
    //
    @SuppressLint("ApplySharedPref")
    public void updatePreference(String preferenceName, String preferenceValue) {
        String currentPref = getPreference(preferenceName);
        Log.d(TAG, "RemoteConfig " + preferenceName + " is currently " + currentPref);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = this.sharedPreferences.edit();
        editor.putString(preferenceName, preferenceValue);
        editor.commit();

        if (!currentPref.equals(preferenceValue))
            Log.d(TAG, "RemoteConfig " + preferenceName + " updated to " + preferenceValue);
    }

    //
    // remove a preference
    //
    @SuppressLint("ApplySharedPref")
    public void removePreference(String preferenceName) {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = this.sharedPreferences.edit();
        editor.remove(preferenceName);
        editor.commit();
    }

    private void updateEncryptedPreference(String preferenceName, String preferenceValue) {
        try {
            BluDroidSecurity security = new BluDroidSecurity(this);
            byte[] key = security.getKey();
            updatePreference(preferenceName, security.encrypt(key, preferenceValue));
        } catch (Exception exception) {
            logger.error("updateEncryptedPreference exception " + exception);
        }
    }

    //
    //decrypt preference before returning
    //
    public String getEncryptedPreference(String preferenceName) {
        try {
            BluDroidSecurity security = new BluDroidSecurity(this);
            byte[] key = security.getKey();
            return security.decrypt(key, getPreference(preferenceName));
        } catch (Exception exception) {
            Log.d(TAG, "getEncryptedPreference exception " + exception);
            logger.error("getEncryptedPreference exception " + exception);
        }
        return "";
    }

    public void configureSkin() {
        Log.d(TAG, "CONFIGURE SKIN");
        skinResources = new BluDroidSkinResources(this);
        Log.d(TAG, "background text color is " + skinResources.getBackgroundTextColor());
    }

    public BluDroidSkinResources getSkinResources() {
        return skinResources;
    }

    @SuppressLint({"ApplySharedPref", "HardwareIds"})
    void checkPreference() {
        try {
            sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

            //Preferences on Technician Screen
            String prefHost;
            String prefPort;
            String prefUseSSL;

            if (isDebug()) {
                prefHost = sharedPreferences.getString(PREF_HOST, getResources().getString(R.string.server));
                prefPort = sharedPreferences.getString(PREF_PORT, getResources().getString(R.string.portNumber));
                prefUseSSL = sharedPreferences.getString(PREF_USE_SSL, getResources().getString(R.string.defaultUseSSL));
            } else {
                prefHost = sharedPreferences.getString(PREF_HOST, getResources().getString(R.string.prodServer));
                prefPort = sharedPreferences.getString(PREF_PORT, getResources().getString(R.string.prodPort));
                prefUseSSL = sharedPreferences.getString(PREF_USE_SSL, getResources().getString(R.string.prodUseSSL));
            }
            String deviceId = sharedPreferences.getString(PREF_DEVICE_ID, "");
            String techPin = sharedPreferences.getString(PREF_TECH_PIN, getResources().getString(R.string.techPinDefault));
            //
            // if the device Ser is empty, then take the deviceSer off the
            // android device
            //

            @SuppressLint("HardwareIds") String deviceSer = sharedPreferences.getString(PREF_DEVICE_SER, Build.SERIAL);

            if (Build.MODEL.startsWith("N3")) {
                deviceSer = getDeviceEngine().getDeviceInfo().getSn();
            }
            Log.d(TAG, "deviceSer is " + deviceSer);
            if (deviceSer.trim().isEmpty() || deviceSer.trim().equals("unknown")) {
                deviceSer = Build.SERIAL;
            }
            String aeonTimeout = sharedPreferences.getString(PREF_AEON_TIMEOUT, getResources().getString(R.string.aeonTimeoutDefault));
            String screenTimeout = sharedPreferences.getString(PREF_SCREEN_TIMEOUT, getResources().getString(R.string.screenTimeoutDefault));
            String transactionTimeout = sharedPreferences.getString(PREF_TRANSACTION_TIMEOUT, getResources().getString(R.string.transactionTimeoutDefault));

            String useBasket = sharedPreferences.getString(PREF_USE_BASKET, getResources().getString(R.string.useBasketDefault));
            String cashDrawer = sharedPreferences.getString(PREF_CASH_DRAWER, getResources().getString(R.string.cashDrawerDefault));
            String printMerchantVoucher = sharedPreferences.getString(PREF_PRINT_MERCHANT_VOUCHER, getResources().getString(R.string.printMerchantVoucherDefault));
            String cashierEndShift = sharedPreferences.getString(PREF_CASHIER_END_SHIFT, getResources().getString(R.string.allowCashierEndShiftDefault));
            String printSalesReceipt = sharedPreferences.getString(PREF_PRINT_SALES_RECEIPT, getResources().getString(R.string.printSalesReceiptDefault));

            String printPreviewReceipt = sharedPreferences.getString(PREF_PRINT_PREVIEW_RECEIPTS, PREF_FALSE);

            String securePrinter = sharedPreferences.getString(PREF_SECURE_USB_PRINTER, getResources().getString(R.string.secureUSBPrinterDefault));
            String printerWidth = sharedPreferences.getString(PREF_PRINTER_WIDTH, getResources().getString(R.string.printerWidthDefault));

            String paperCutter = sharedPreferences.getString(PREF_PAPER_CUTTER, getResources().getString(R.string.paperCutterDefault));
            String voucherSeconds = sharedPreferences.getString(PREF_VOUCHER_SECONDS, getResources().getString(R.string.voucherSecondsDefault));
            String maxCacheAge = sharedPreferences.getString(PREF_MAX_CACHE_AGE, getResources().getString(R.string.maxCacheAgeDefault));

            String storeName = sharedPreferences.getString(PREF_STORE_NAME, getResources().getString(R.string.store_name_def));
            String storeAddress = sharedPreferences.getString(PREF_STORE_ADDRESS, getResources().getString(R.string.address_def));
            String vatRegNo = sharedPreferences.getString(PREF_VAT_REG_NO, getResources().getString(R.string.vat_def));

            //
            // possible grayLog integration
            //
            String grayLogURL;
            String grayLogLevel;
            if (isDebug()) {
                grayLogURL = sharedPreferences.getString(PREF_GRAY_LOG_URL, getResources().getString(R.string.grayLogURLDefault));
                grayLogLevel = sharedPreferences.getString(PREF_GRAY_LOG_LEVEL, getResources().getString(R.string.logNONE));
            } else {
                grayLogURL = sharedPreferences.getString(PREF_GRAY_LOG_URL, getResources().getString(R.string.prodGrayLogURL));
                grayLogLevel = sharedPreferences.getString(PREF_GRAY_LOG_LEVEL, getResources().getString(R.string.logNONE));
            }

            String fileLogLevel = sharedPreferences.getString(PREF_LOG_LEVEL, getResources().getString(R.string.log_level_default));
            String fileLogDays = sharedPreferences.getString(PREF_LOG_DAYS, getResources().getString(R.string.log_days_default));

            String bpLimit = sharedPreferences.getString(PREF_BP_LIMIT, getResources().getString(R.string.bp_limit_default));

            String defAcount = sharedPreferences.getString(PREF_DEF_ACCOUNT, getResources().getString(R.string.account_default));
            String defAcountIndex = sharedPreferences.getString(PREF_DEF_ACCOUNT_INDEX, getResources().getString(R.string.account_index_default));
            String displayBalance = sharedPreferences.getString(PREF_DISPLAY_BALANCE1, getResources().getString(R.string.display_low_balance_default));
            String lowBalanceAmount = sharedPreferences.getString(PREF_LOW_BALANCE_AMOUNT, getResources().getString(R.string.low_balance_amount_default));
            String accountBalance = sharedPreferences.getString(PREF_ACCOUNT_BALANCE, "0");

            //F
            // new rica stuff
            //
            String ricaHost;
            String ricaUseSSL;

            if (isDebug() || isQa()) {
                ricaHost = sharedPreferences.getString(PREF_RICA_HOST, getResources().getString(R.string.ricaHostDefault));
                ricaUseSSL = sharedPreferences.getString(PREF_RICA_USE_SSL, getResources().getString(R.string.ricaUseSSLDefault));
            } else {
                ricaHost = sharedPreferences.getString(PREF_RICA_HOST, getResources().getString(R.string.prodRicaHost));
                ricaUseSSL = sharedPreferences.getString(PREF_RICA_USE_SSL, getResources().getString(R.string.prodRicaUseSSL));
            }

            String ricaPort;
            if (isDebug() || isQa()) {
                ricaPort = sharedPreferences.getString(PREF_RICA_PORT, getResources().getString(R.string.ricaPortDefault));
            } else {
                ricaPort = sharedPreferences.getString(PREF_RICA_PORT, getResources().getString(R.string.prodRicaPort));
            }

            String ricaDeviceId;
            String ricaDeviceSer;
            if (isDebug() || isQa()) {
                ricaDeviceId = sharedPreferences.getString(PREF_RICA_DEVICE_ID, getResources().getString(R.string.ricaDeviceIdDefault));
                ricaDeviceSer = sharedPreferences.getString(PREF_RICA_DEVICE_SER, getResources().getString(R.string.ricaDeviceSerDefault));
            } else {
                ricaDeviceId = sharedPreferences.getString(PREF_RICA_DEVICE_ID, getResources().getString(R.string.prodRicaDeviceId));
                ricaDeviceSer = sharedPreferences.getString(PREF_RICA_DEVICE_SER, getResources().getString(R.string.prodRicaDeviceSer));
            }

            String ricaUserPin = sharedPreferences.getString(PREF_RICA_USER_PIN, PREF_UNKNOWN);
            String ricaCanBoxRica = sharedPreferences.getString(PREF_RICA_CAN_BOXRICA, getResources().getString(R.string.defaultCanBoxRica));

            String scanningApp = sharedPreferences.getString(PREF_SCANNING_APP, getResources().getString(R.string.defaultScanningApp2));

            String epubReaderHost = sharedPreferences.getString(PREF_EPUB_READER_URL, getResources().getString(R.string.defaultEpubReaderHost));
            String epubManualDirectory = sharedPreferences.getString(PREF_EPUB_MANUAL_URL, getResources().getString(R.string.defaultEpubManualDirectory));

            String magEncoder = sharedPreferences.getString(PREF_MAG_READER, getResources().getString(R.string.externalMagReaderDefault));

            //
            // fdroid fields
            //
            String fdroidRepoHost;
            String fdroidRepoDir;

            String loyaltyEnabledTech = sharedPreferences.getString(PREF_LOYALTY_ENABLE_TECH, "false");
            String loyaltyEnabledUser = sharedPreferences.getString(PREF_LOYALTY_ENABLE_USER, "false");
            String loyaltyRepoHost;

            String merchantHost;

            String mendixUrl;

            if (isDebug() || isQa()) {

                if (Build.MODEL.startsWith("N3")) {
                    fdroidRepoDir = sharedPreferences.getString(PREF_FDROID_REPO_DIR, getResources().getString(R.string.prodFdroidRepoDirNexgoDefault));
                } else {
                    fdroidRepoDir = sharedPreferences.getString(PREF_FDROID_REPO_DIR, getResources().getString(R.string.prodFdroidRepoDirDefault));
                }

                fdroidRepoHost = sharedPreferences.getString(PREF_FDROID_REPO_URL, getResources().getString(R.string.fdroidRepoHostDefault));

                loyaltyRepoHost = sharedPreferences.getString(PREF_LOYALTY_URL, getResources().getString(R.string.loyalty_server));

                merchantHost = sharedPreferences.getString(PREF_BLUKEY_URL, getResources().getString(R.string.merchant_server));

                mendixUrl = sharedPreferences.getString(PREF_MENDIX_URL, getResources().getString(R.string.mendixUrlDefault));

            } else if (isGcrs()) {

                if (Build.MODEL.startsWith("N3")) {
                    fdroidRepoDir = sharedPreferences.getString(PREF_FDROID_REPO_DIR, getResources().getString(R.string.prodFdroidRepoDirGcrsNexgoDefault));
                } else {
                    fdroidRepoDir = sharedPreferences.getString(PREF_FDROID_REPO_DIR, getResources().getString(R.string.prodFdroidRepoDirGcrsDefault));
                }

                fdroidRepoHost = sharedPreferences.getString(PREF_FDROID_REPO_URL, getResources().getString(R.string.prodFdroidRepoHostDefault));

                loyaltyRepoHost = sharedPreferences.getString(PREF_LOYALTY_URL, getResources().getString(R.string.loyalty_server_prod));

                merchantHost = sharedPreferences.getString(PREF_BLUKEY_URL, getResources().getString(R.string.merchant_server_prod));

                mendixUrl = sharedPreferences.getString(PREF_MENDIX_URL, getResources().getString(R.string.mendixUrlProd));

            } else {

                if (Build.MODEL.startsWith("N3")) {
                    fdroidRepoDir = sharedPreferences.getString(PREF_FDROID_REPO_DIR, getResources().getString(R.string.prodFdroidRepoDirNexgoDefault));
                } else {
                    fdroidRepoDir = sharedPreferences.getString(PREF_FDROID_REPO_DIR, getResources().getString(R.string.prodFdroidRepoDirDefault));
                }

                fdroidRepoHost = sharedPreferences.getString(PREF_FDROID_REPO_URL, getResources().getString(R.string.prodFdroidRepoHostDefault));

                loyaltyRepoHost = sharedPreferences.getString(PREF_LOYALTY_URL, getResources().getString(R.string.loyalty_server_prod));

                merchantHost = sharedPreferences.getString(PREF_BLUKEY_URL, getResources().getString(R.string.merchant_server_prod));

                mendixUrl = sharedPreferences.getString(PREF_MENDIX_URL, getResources().getString(R.string.mendixUrlProd));
            }

            //Heartbeat fields
            String heartbeat = sharedPreferences.getString(PREF_HEARTBEAT_ENABLE_TECH, getResources().getString(R.string.hearbeatDefault));
            String heartbeatInterval = sharedPreferences.getString(PREF_AWS_HEARTBEAT_MINUTES, getResources().getString(R.string.hearbeatIntervalDefault));
            String heartbeatURL;

            if (isDebug()) {
                heartbeatURL = sharedPreferences.getString(PREF_HEARTBEAT_URL, getResources().getString(R.string.heartbeatDebugURL));
            } else if (isQa()) {
                heartbeatURL = sharedPreferences.getString(PREF_HEARTBEAT_URL, getResources().getString(R.string.heartbeatQaURL));
            } else {
                heartbeatURL = sharedPreferences.getString(PREF_HEARTBEAT_URL, getResources().getString(R.string.heartbeatProdURL));
            }

            //
            // skin stuff
            //
            String skin;
            if (isGcrs()) {
                skin = sharedPreferences.getString(PREF_SKIN, getResources().getString(R.string.skinGCRS));
            } else {
                skin = sharedPreferences.getString(PREF_SKIN, getResources().getString(R.string.skinDEF));
            }
            //
            // putco stuff
            //
            String putcoURL;
            String putcoPaperCheckSleepTime = sharedPreferences.getString(PREF_PUTCO_PAPER_CHECK_SLEEP_TIME, getResources().getString(R.string.putcoPaperCheckSleepTimeDefault));
            if (isDebug() || isQa()) {
                putcoURL = sharedPreferences.getString(PREF_PUTCO_URL, getResources().getString(R.string.putcoPrintResultsUrlDebug));
            } else {
                putcoURL = sharedPreferences.getString(PREF_PUTCO_URL, getResources().getString(R.string.putcoPrintResultsUrlProd));
            }
            String usbPrintTimeout = sharedPreferences.getString(PREF_USB_PRINT_TIMEOUT, getResources().getString(R.string.usbPrintTimeoutDefault));

            String manualOverride = sharedPreferences.getString(PREF_MANUAL_OVERRIDE, getResources().getString(R.string.manual_override_default));

            String lastLogin = sharedPreferences.getString(PREF_LAST_LOGIN, "0");

            String printBarcodeOverride = sharedPreferences.getString(PREF_PRINT_BARCODE_RECEIPT, getResources().getString(R.string.print_barcode_default));

            String manualOverrideDeviceTimeout = sharedPreferences.getString(PREF_MANUAL_OVERRIDE, getResources().getString(R.string.manual_override_device_timeout));

            String printAppVersion = sharedPreferences.getString(PREF_PRINT_APP_VERSION, PREF_FALSE);

            String checkLocation = sharedPreferences.getString(PREF_LOCATION_CHECK, PREF_TRUE);

            SharedPreferences.Editor editor = this.sharedPreferences.edit();
            editor.putString(PREF_PRINT_PREVIEW_RECEIPTS, printPreviewReceipt);
            editor.putString(PREF_PRINT_BARCODE_RECEIPT, printBarcodeOverride);
            editor.putString(PREF_MANUAL_OVERRIDE, manualOverride);
            editor.putString(PREF_PRINT_APP_VERSION, printAppVersion);
            editor.putString(PREF_SCREEN_TIMEOUT, manualOverrideDeviceTimeout);
            editor.putString(PREF_SKIN, skin);
            editor.putString(PREF_HOST, prefHost);
            editor.putString(PREF_PORT, prefPort);
            editor.putString(PREF_USE_SSL, prefUseSSL);
            editor.putString(PREF_DEVICE_ID, deviceId);
            editor.putString(PREF_TECH_PIN, techPin);
            editor.putString(PREF_DEVICE_SER, deviceSer);
            editor.putString(PREF_AEON_TIMEOUT, aeonTimeout);
            editor.putString(PREF_SCREEN_TIMEOUT, screenTimeout);
            editor.putString(PREF_TRANSACTION_TIMEOUT, transactionTimeout);
            editor.putString(PREF_USE_BASKET, useBasket);
            editor.putString(PREF_CASH_DRAWER, cashDrawer);
            editor.putString(PREF_PAPER_CUTTER, paperCutter);
            editor.putString(PREF_VOUCHER_SECONDS, voucherSeconds);
            editor.putString(PREF_MAX_CACHE_AGE, maxCacheAge);
            editor.putString(PREF_CASHIER_END_SHIFT, cashierEndShift);
            editor.putString(PREF_PRINT_SALES_RECEIPT, printSalesReceipt);
            editor.putString(PREF_PRINT_MERCHANT_VOUCHER, printMerchantVoucher);
            editor.putString(PREF_STORE_NAME, storeName);
            editor.putString(PREF_STORE_ADDRESS, storeAddress);
            editor.putString(PREF_VAT_REG_NO, vatRegNo);
            editor.putString(PREF_PRINTER_WIDTH, printerWidth);
            editor.putString(PREF_RICA_HOST, ricaHost);
            editor.putString(PREF_RICA_PORT, ricaPort);
            editor.putString(PREF_RICA_USER_PIN, ricaUserPin);
            editor.putString(PREF_RICA_DEVICE_ID, ricaDeviceId);
            editor.putString(PREF_RICA_DEVICE_SER, ricaDeviceSer);
            editor.putString(PREF_RICA_CAN_BOXRICA, ricaCanBoxRica);
            editor.putString(PREF_RICA_USE_SSL, ricaUseSSL);
            editor.putString(PREF_SECURE_USB_PRINTER, securePrinter);
            editor.putString(PREF_FDROID_REPO_URL, fdroidRepoHost);
            editor.putString(PREF_FDROID_REPO_DIR, fdroidRepoDir);
            editor.putString(PREF_MENDIX_URL, mendixUrl);
            // NFC
            editor.putString(PREF_LOYALTY_ENABLE_TECH, loyaltyEnabledTech);
            editor.putString(PREF_LOYALTY_ENABLE_USER, loyaltyEnabledUser);
            editor.putString(PREF_LOYALTY_URL, loyaltyRepoHost);

            editor.putString(PREF_BLUKEY_URL, merchantHost);

            //Logging
            editor.putString(PREF_LOG_LEVEL, fileLogLevel);
            editor.putString(PREF_LOG_DAYS, fileLogDays);
            editor.putString(PREF_GRAY_LOG_URL, grayLogURL);
            editor.putString(PREF_GRAY_LOG_LEVEL, grayLogLevel);

            //Scanner
            editor.putString(PREF_SCANNING_APP, scanningApp);

            //bpLimit
            editor.putString(PREF_BP_LIMIT, bpLimit);

            //putco
            editor.putString(PREF_PUTCO_URL, putcoURL);
            editor.putString(PREF_PUTCO_PAPER_CHECK_SLEEP_TIME, putcoPaperCheckSleepTime);
            editor.putString(PREF_USB_PRINT_TIMEOUT, usbPrintTimeout);

            editor.putString(PREF_EPUB_READER_URL, epubReaderHost);
            editor.putString(PREF_EPUB_MANUAL_URL, epubManualDirectory);

            editor.putString(PREF_DEF_ACCOUNT, defAcount);
            editor.putString(PREF_DEF_ACCOUNT_INDEX, defAcountIndex);
            editor.putString(PREF_DISPLAY_BALANCE1, displayBalance);
            editor.putString(PREF_LOW_BALANCE_AMOUNT, lowBalanceAmount);
            editor.putString(PREF_ACCOUNT_BALANCE, accountBalance);

            editor.putString(PREF_HEARTBEAT_ENABLE_TECH, heartbeat);
            editor.putString(PREF_AWS_HEARTBEAT_MINUTES, heartbeatInterval);
            editor.putString(PREF_HEARTBEAT_URL, heartbeatURL);

            editor.putString(PREF_MAG_READER, magEncoder);

            editor.putString(PREF_LAST_LOGIN, lastLogin);

            editor.putString(PREF_LOCATION_CHECK, checkLocation);

            editor.commit();

        } catch (Exception exception) {
            logger.error("checkPreference throwing " + exception);
        }
    }


    public void results(Object object) {
        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(Base) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }

        resetTimer();

        lockBackButton = false;
        if (object == null) {
            return;
        }

        if (object instanceof Socket) {
            socket = (Socket) object;
        } else if (object instanceof AEONCommsException) {
            Log.d(TAG, "AEONCommsException " + object);
            logger.error("AEONCommsException " + object);
            isLotto = false;
            AEONCommsException exception = (AEONCommsException) object;
            dismissProgress();
            createNetworkErrorConfirmation();

            // logout();
        } else if (object instanceof UsersResponseUpdateUserMessage) {
            Log.d(TAG, "UsersResponseUpdateUserListMessage");
            UsersResponseUpdateUserMessage usersResponseUpdateUserMessage = (UsersResponseUpdateUserMessage) object;
            dismissProgress();
            if (usersResponseUpdateUserMessage.getEvent().getEventCode().equals("0")) {
                if (usersResponseUpdateUserMessage.getData().getSuccess().equals("1")) {

                    createCustomAlertDialog("Update User", usersResponseUpdateUserMessage.getData().getMessage());
                    alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            authenticateForUsers();
                        }
                    });

                    alert.show();

                    dismissConfirmation();

                } else {
                    createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, usersResponseUpdateUserMessage.getData().getMessage(), true);
                }
            } else {
                createSystemErrorConfirmation(usersResponseUpdateUserMessage, true);
            }

        } else if (object instanceof UsersResponseAddUserMessage) {
            Log.d(TAG, "UsersResponseAddUserListMessage");
            UsersResponseAddUserMessage usersResponseAddUserMessage = (UsersResponseAddUserMessage) object;
            dismissProgress();
            if (usersResponseAddUserMessage.getEvent().getEventCode().equals("0")) {
                if (usersResponseAddUserMessage.getData().getSuccess().equals("1")) {
                    dismissProgress();
                    createCustomAlertDialog("Add User", usersResponseAddUserMessage.getData().getMessage());
                    alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            authenticateForUsers();
                        }
                    });
                    alert.show();
                    dismissConfirmation();
                } else {
                    createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, usersResponseAddUserMessage.getData().getMessage(), true);
                }
            } else {
                createSystemErrorConfirmation(usersResponseAddUserMessage, true);
            }

        } else if (object instanceof UsersResponseListPermissionTypesMessage) {
            Log.d(TAG, "UsersResponseListPermissionTypesMessage");

            dismissProgress();

            usersResponseListPermissionTypesMessage = (UsersResponseListPermissionTypesMessage) object;

        } else if (object instanceof ReportsAuthenticationResponseMessage) {
            Log.d(TAG, "ReportsAuthenticationResponseMessage");

            dismissProgress();

            reportsAuthenticationResponseMessage = (ReportsAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(reportsAuthenticationResponseMessage.getEvent());

            if (reportsAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

                //loginResponseMessage.setSessionId(reportsAuthenticationResponseMessage.getSessionId());

                if (mustgetShiftList) {
                    mustgetShiftList = false;
                    getShifts();
                }

                if (isEndShiftState) {

                    createEndShiftConfirmation();
                    isEndShiftState = false;
                }

                if (mustgetInvoiceList) {

                    getInvoiceList(accountId);
                    mustgetInvoiceList = false;
                }

            } else {
                createSystemErrorConfirmation(reportsAuthenticationResponseMessage, true);
            }

        } else if (object instanceof ReportsResponseTransListMessage) {
            Log.d(TAG, "ReportsResponseTransListMessage");
            ReportsResponseTransListMessage response = (ReportsResponseTransListMessage) object;
            dismissProgress();

            // check if the user wants to preview, if not just print
            if (Boolean.valueOf(getPreference(PREF_PRINT_PREVIEWS)))
                // create the dialog
                createBluDroidPreviewTransactionListDialog(response.getData().getLines());
            else
                print(response.getData().getLines());
            Log.d(TAG, "PRINTED: TRANSACTION LIST REPORT DAYS");

        } else if (object instanceof ReportsAccountInfoAuthenticationResponseMessage) {
            Log.d(TAG, "ReportsAccountInfoAuthenticationResponseMessage");

            reportsAccountInfoAuthenticationResponseMessage = (ReportsAccountInfoAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(reportsAccountInfoAuthenticationResponseMessage.getEvent());

            if (reportsAccountInfoAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                dismissProgress();

                if (reportsAccountInfoAuthenticationResponseMessage.getData().getAccountInfo().getAccounts().size() > 1) {
                    if (accountBalanceGrouptoggle != null) {
                        accountBalanceGrouptoggle.setEnabled(false);
                        accountBalanceGrouptoggle.setOnClickListener(null);
                        accountBalanceGrouptoggle.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                    }

                    updatePreference(PREF_DISPLAY_BALANCE1, getString(R.string.display_low_balance_default));
                    updatePreference(PREF_DEF_ACCOUNT, getString(R.string.account_default));
                    updatePreference(PREF_DEF_ACCOUNT_INDEX, getString(R.string.account_index_default));
                    toolbar.setTextColorWhite();
                    toolbar.setTitle("Favourites");
                } else {

                    int accountIndex = Integer.parseInt(getPreference(PREF_DEF_ACCOUNT_INDEX));

                    if (accountIndex != 0) {
                        try {
                            ReportsResponseAccountValuesMessage accountValues =
                                    reportsAccountInfoAuthenticationResponseMessage.getData().getAccountInfo().getAccounts().get(--accountIndex);

                            accountBalance = accountValues.getAvailableBalance();
                            updatePreference(PREF_ACCOUNT_BALANCE, accountBalance);

                            if (this instanceof ActivityMain) {
                                if (getPreference(PREF_DISPLAY_BALANCE1).equalsIgnoreCase("display")) {
                                    toolbar.setTitle(getResources().getString(R.string.currency) + getPreference(PREF_ACCOUNT_BALANCE));
                                    toolbar.removeAppLogo();
                                } else if (getPreference(PREF_DISPLAY_BALANCE1).equalsIgnoreCase("warn")) {

                                    float lowBalanceWarningAmount = Float.parseFloat(getPreference(PREF_LOW_BALANCE_AMOUNT));
                                    float accountBalance = Float.parseFloat(getPreference(PREF_ACCOUNT_BALANCE));
                                    int retVal = Float.compare(lowBalanceWarningAmount, accountBalance);
                                    if (retVal >= 0) {
                                        toolbar.setTitle(getString(R.string.low_balance));
                                        toolbar.setWarnIcon();
                                        toolbar.setTextColorWarning();
                                    } else {
                                        toolbar.setTextColorWhite();
                                        toolbar.setTitle(getString(R.string.favourites));
                                    }
                                }
                            }
                        } catch (Exception ex) {
                            logger.error("Account Balance Error: " + ex);
                        }

                    } else if (this instanceof ActivityMain) {
                        toolbar.setTextColorWhite();
                        toolbar.setTitle(getString(R.string.favourites));
                    }
                    closeAeonSocket(6);
                }
            }

        } else if (object instanceof ReportsResponseAccountListMessage) {
            Log.d(TAG, "ReportsResponseAccountListMessage");
            dismissProgress();
            reportsResponseAccountListMessage = (ReportsResponseAccountListMessage) object;

            if (mustAuthenticateForAccounts) {
                mustAuthenticateForAccounts = false;
                authenticateForAccounts();
            }

        } else if (object instanceof ReprintAuthenticationResponseMessage) {
            dismissProgress();
            reprintAuthenticationResponseMessage = (ReprintAuthenticationResponseMessage) object;
            //Heartbeat flag
            updateHeartbeatFlag(reprintAuthenticationResponseMessage.getEvent());

            loginResponseMessage.setSessionId(reprintAuthenticationResponseMessage.getSessionId());
            if (reprintAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                getReprintList();
            }

        } else if (object instanceof ReprintResponseListByDateMessage) {
            dismissProgress();
            reprintResponseListByDateMessage = (ReprintResponseListByDateMessage) object;
            if (reprintResponseListByDateMessage.getEvent().getEventCode().equals("0")) {
                createReprintListDialog();
            } else {
                createSystemErrorConfirmation(reprintResponseListByDateMessage, true);
            }

        } else if (object instanceof ReprintResponseReprintMessage) {
            ReprintResponseReprintMessage reprintResponseReprintMessage = (ReprintResponseReprintMessage) object;
            dismissProgress();
            if (reprintResponseReprintMessage.getEvent().getEventCode().equals("0")) {
//                ArrayList<CommonResponseLineMessage> reprintLines = reprintResponseReprintMessage.getData().getReprint();
//                printWithDynamic(reprintLines, getPrintBarcode());
//                Log.d(TAG, "PRINTED: Reprint");

                if (previewSlipsEnabled()) {
                    List<PrintJob> printJobs = new ArrayList<>();
                    printJobs.add(new PrintJob(reprintResponseReprintMessage.getData().getReprint(), true, getPrintBarcode()));
                    new BluDroidSlipPreviewReprintDialog(this, printJobs);

                } else {
                    printWithDynamic(reprintResponseReprintMessage.getData().getReprint(), getPrintBarcode());
                }

            }

        } else if (object instanceof ReportsResponseProfitMessage) {
            Log.d(TAG, "ReportsResponseProfitMessage");
            ReportsResponseProfitMessage reportsResponseProfitMessage = (ReportsResponseProfitMessage) object;
            dismissProgress();
            // check if the user wants to preview, if not just print
            if (Boolean.valueOf(getPreference(PREF_PRINT_PREVIEWS))) {
                createBluDroidPreviewProfitReportDialog(reportsResponseProfitMessage.getData().getLines());
            } else {
                print(reportsResponseProfitMessage.getData().getLines());
            }
            Log.d(TAG, "PRINTED: PROFIT REPORT DAYS");

        } else if (object instanceof ReportsResponseShiftProfitMessage) {
            ReportsResponseShiftProfitMessage reportsResponseShiftProfitMessage = (ReportsResponseShiftProfitMessage) object;
            dismissProgress();
            Log.d(TAG, "ReportsResponseShiftProfitMessage");
            if (Boolean.valueOf(getPreference(PREF_PRINT_PREVIEWS))) {
                // create the dialog
                createBluDroidPreviewProfitReportDialog(reportsResponseShiftProfitMessage.getData().getLines());
            } else {
                print(reportsResponseShiftProfitMessage.getData().getLines());
            }

        } else if (object instanceof ReportsResponseShiftListMessage) {
            Log.d(TAG, "ReportsResponseShiftListMessage");

            dismissProgress();
            reportsResponseShiftListMessage = (ReportsResponseShiftListMessage) object;

            if (mustgetAccountList) {
                mustgetAccountList = false;
                requestAccountList();
            }

        } else if (object instanceof ReportsResponseStatementMessage) {
            dismissProgress();

            ReportsResponseStatementMessage reportsResponseStatementMessage = (ReportsResponseStatementMessage) object;

            // check if the user wants to preview, if not just print
            if (Boolean.valueOf(getPreference(PREF_PRINT_PREVIEWS))) {
                createBluDroidPreviewStatementDialog(reportsResponseStatementMessage.getData().getLines());
            } else {
                print(reportsResponseStatementMessage.getData().getLines());
            }
            Log.d(TAG, "ReportsResponseStatementMessage");


        } else if (object instanceof ReportsResponsePrintShiftMessage) {
            dismissProgress();

            ReportsResponsePrintShiftMessage response = (ReportsResponsePrintShiftMessage) object;
            // check if the user wants to preview, if not just print
            if (Boolean.valueOf(getPreference(PREF_PRINT_PREVIEWS))) {
                createBluDroidPreviewShiftProfitDialog(response.getData().getLines());
            } else {
                print(response.getData().getLines());
            }
            Log.d(TAG, "ReportsResponsePrintShiftMessage");

        } else if (object instanceof EmergencyLoanResponsePrintEmergencyTopupMessage) {
            dismissProgress();
            EmergencyLoanResponsePrintEmergencyTopupMessage response = (EmergencyLoanResponsePrintEmergencyTopupMessage) object;

            if (Boolean.valueOf(getPreference(PREF_PRINT_PREVIEWS))) {
                createBluDroidPreviewEmergencyTopUpDialog(response.getData().getLines());
            } else {
                print(response.getData().getLines());
            }
            Log.d(TAG, "EmergencyLoanResponsePrintEmergencyTopupMessage");

        } else if (object instanceof ReportsResponseBatchMessage) {
            ReportsResponseBatchMessage response = (ReportsResponseBatchMessage) object;
            dismissProgress();

            // check if the user wants to preview, if not just print
            if (Boolean.valueOf(getPreference(PREF_PRINT_PREVIEWS))) {
                createBluDroidPreviewBatchDialog(response.getData().getLines());
            } else {
                print(response.getData().getLines());
            }
            Log.d(TAG, "ReportsResponseBatchMessage");

        } else if (object instanceof ReportsResponseEndShiftMessage) {
            Log.v(TAG, "ReportsResponseEndShiftMessage");
            dismissProgress();
            closeAeonSocket(7);
            ReportsResponseEndShiftMessage response = (ReportsResponseEndShiftMessage) object;
            print(response.getData().getLines());

        } else if (object instanceof Chat4ChangeAuthenticationResponseMessage) {
            dismissProgress();
            Log.d(TAG, "chat 4 change authentication");
            chat4ChangeAuthenticationResponseMessage = (Chat4ChangeAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(chat4ChangeAuthenticationResponseMessage.getEvent());

            if (chat4ChangeAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                if (!gettingVouchers) {

                    Date mvnoCacheDate = dateLastMvnoCache();
                    Date now = new Date();
                    if (((now.getTime() - mvnoCacheDate.getTime()) > CACHE_12_HOURS) || Build.MODEL.startsWith("CITAQ")) {
                        getChat4ChangeSuppliers();
                    } else {
                        closeAeonSocket(8);
                        Log.d(TAG, "Using cache");
                        chat4ChangeResponseListSuppliersMessage = getCachedMVNOData();
                    }
                } else {
                    getChat4ChangeVoucher(chat4ChangeAuthenticationResponseMessage, supplierCode, amount);
                }
            } else {
                createSystemErrorConfirmation(chat4ChangeAuthenticationResponseMessage, true);
            }

        } else if (object instanceof Chat4ChangeResponseListSuppliersMessage) {
            dismissProgress();
            Log.d(TAG, "chat 4 change authentication");
            connectedToAEON = true;
            chat4ChangeResponseListSuppliersMessage = (Chat4ChangeResponseListSuppliersMessage) object;
            if (chat4ChangeResponseListSuppliersMessage.getEvent().getEventCode().equals("0")) {

/*                chat4ChangeResponseListSuppliersMessage.getData().getSuppliers().get(0).setMinAmount(null);
                chat4ChangeResponseListSuppliersMessage.getData().getSuppliers().get(0).setMaxAmount(null);
                chat4ChangeResponseListSuppliersMessage.getData().getSuppliers().get(1).setMinAmount(null);
                chat4ChangeResponseListSuppliersMessage.getData().getSuppliers().get(1).setMaxAmount(null);
                chat4ChangeResponseListSuppliersMessage.getData().getSuppliers().get(2).setMinAmount(null);
                chat4ChangeResponseListSuppliersMessage.getData().getSuppliers().get(2).setMaxAmount(null);
                chat4ChangeResponseListSuppliersMessage.getData().getSuppliers().get(3).setMinAmount(null);
                chat4ChangeResponseListSuppliersMessage.getData().getSuppliers().get(3).setMaxAmount(null);
*/

                // do the caching here
                cacheMVNOData();
                retryFailedCancellationsAndTenders();
            } else {
                createSystemErrorConfirmation(chat4ChangeAuthenticationResponseMessage, true);
            }

        } else if (object instanceof Chat4ChangeResponseMessage) {
            Log.d(TAG, "chat 4 change response message");
//            dismissProgress();
            gettingVouchers = false;

            chat4ChangeResponseMessage = (Chat4ChangeResponseMessage) object;
            if (chat4ChangeResponseMessage.getEvent().getEventCode().equals("0")) {
//                createProgress(R.string.printingVoucher);
//                printWithDynamic(chat4ChangeResponseMessage.getData().getPrintLines(), getPrintBarcode());
//
//                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
//                    print(chat4ChangeResponseMessage.getData().getMerchantPrintLines());
//                }
//                supplierName = "";
//                gettingMvnoVoucher = false;
//
//                logger.info("Voucher printed:" + isVoucherPrinted);
//                if (isVoucherPrinted) {
//                    printChat4Change(chat4ChangeResponseMessage);
//                } else {
//                    cleanUp();
//                    createPrintErrorConfirmation();
//                }

                saveDetailsUntilPaidC4C(chat4ChangeResponseMessage.getData().getTransRef(),
                        name, chat4ChangeResponseMessage.getData().getReference(),
                        chat4ChangeResponseMessage.getData().getAmount());

                if (previewSlipsEnabled()) {
                    List<PrintJob> printJobs = new ArrayList<>();
                    printJobs.add(new PrintJob(chat4ChangeResponseMessage.getData().getPrintLines(), true, getPrintBarcode()));
                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        printJobs.add(new PrintJob(chat4ChangeResponseMessage.getData().getMerchantPrintLines(), false, false));
                    }
                    new BluDroidSlipPreviewC4cDialog(this, printJobs);

                } else {

                    printWithDynamic(chat4ChangeResponseMessage.getData().getPrintLines(), getPrintBarcode());

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        print(chat4ChangeResponseMessage.getData().getMerchantPrintLines());
                    }
                    completeC4cPrint();
                }

            } else {
                createSystemErrorConfirmation(chat4ChangeResponseMessage, true);
            }

        } else if (object instanceof Chat4ChangeResponsePrintedMessage) {
            Log.d(TAG, "chat 4 change printed messsage");
            dismissProgress();
            dismissConfirmation();
            //Chat for change
            Chat4ChangeResponsePrintedMessage chat4ChangeResponsePrintedMessage = (Chat4ChangeResponsePrintedMessage) object;
            if (chat4ChangeResponsePrintedMessage.getEvent().getEventCode().equals("0")) {
                count++;
                if (count < quantity) {
                    // need another voucher
                    getChat4ChangeVoucher(chat4ChangeAuthenticationResponseMessage, supplierCode, amount);
                }
                emptyBasket();
            } else {
                createSystemErrorConfirmation(chat4ChangeResponsePrintedMessage, true);
            }

        } else if (object instanceof TenderAuthenticationResponseMessage) {
            Log.v(TAG, "tender authentication received");
//            dismissProgress();
            TenderAuthenticationResponseMessage response = (TenderAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(response.getEvent());

            if (response.getEvent().getEventCode().equals("0")) {

                createProgress("Tendering");
                if (isClearingUntenderdState) {

                    clearUntenderd(response);
                    isClearingUntenderdState = false;

                } else {
                    loginResponseMessage.setSessionId(response.getSessionId());
                    TenderRequestFactory factory = new TenderRequestFactory();
                    TenderRequestMessage request = null;
                    if (multipleVouchersAuthenticationResponseMessage != null) {
                        Log.v("c4cMinMax", ">>>>>>>>>>>>>>tender with multipleVouchersAuthenticationResponseMessage");

                        BigDecimal total = new BigDecimal("0.0");

                        for (int i = 0; i < multipleVouchersAuthenticationResponseMessage.getData().getVouchers().size(); ++i) {
                            BigDecimal voucherAmount = new BigDecimal(multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getAmount());

                            total = total.add(voucherAmount);
                            if (multipleVouchersAuthenticationRequestMessage.getEvent().getAirtimePlus().equals("1")) {
                                total = total.add(new BigDecimal(airtimePlusValue));
                            }
                        }
                        request = factory.create(response.getSessionId(),
                                total.toString(), //cash.toString(),
                                "0.00", //creditCard.toString(),
                                "0.00", //debitCard.toString(),
                                "0.00", // cheque
                                "0.00", // other
                                total.toString(), //total.toString(),
                                "0.00");

                        for (int i = 0; i < multipleVouchersAuthenticationResponseMessage.getData().getVouchers().size(); ++i) {
                            request.getEvent().getItems().add(multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getTransRef());
                        }

                        if (multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().size() > 0) {
                            for (int i = 0; i < multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().size(); ++i) {
                                request.getEvent().getItems().add(multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().get(i).getTransRef());
                            }
                        }

                    } else {
                        Log.v("c4cMinMax", ">>>>>>>>>>>>>>tender with amount: " + amount);

                        BigDecimal total = new BigDecimal(amount);

                        ArrayList<String> rechargePlusTransRefs = new ArrayList<>();

                        //recharge plus tendering
                        if (AirtimeTopupResponsePurchaseMessage != null) {

                            if (AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().size() > 0) {
                                for (int i = 0; i < AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().size(); ++i) {
                                    if (AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().get(i).getTransSeq() != null) {
                                        rechargePlusTransRefs.add(AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().get(i).getTransRef());
                                        total = total.add(BigDecimal.valueOf(Double.parseDouble(AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().get(i).getValue())));
                                    }
                                }
                            }
                        } else if (bundlesResponseDoBundleTopupMessage != null) {
                            if (bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().size() > 0) {
                                for (int i = 0; i < bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().size(); ++i) {
                                    if (bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().get(i).getTransSeq() != null) {
                                        rechargePlusTransRefs.add(bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().get(i).getTransRef());
                                        total = total.add(BigDecimal.valueOf(Double.parseDouble(bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().get(i).getValue())));
                                    }
                                }
                            }
                        }


                        if (paymentType.toLowerCase().contains("cash")) {

                            request = factory.create(response.getSessionId(),
                                    total.toString(), //cash.toString(),
                                    "0.00", //creditCard.toString(),
                                    "0.00", //debitCard.toString(),
                                    "0.00", // cheque
                                    "0.00", // other
                                    total.toString(), //total.toString(),
                                    "0.00"); // change.toString());
                            request.getEvent().getItems().add(transRef);

                        } else if (paymentType.toLowerCase().contains("debit")) {
                            request = factory.create(response.getSessionId(),
                                    "0.00", //cash.toString(),
                                    "0.00", //creditCard.toString(),
                                    total.toString(), //debitCard.toString(),
                                    "0.00", // cheque
                                    "0.00", // other
                                    total.toString(), //total.toString(),
                                    "0.00"); // change.toString());
                            request.getEvent().getItems().add(transRef);
                        } else if (paymentType.toLowerCase().contains("credit")) {
                            request = factory.create(response.getSessionId(),
                                    "0.00", //cash.toString(),
                                    total.toString(), //creditCard.toString(),
                                    "0.00", //debitCard.toString(),
                                    "0.00", // cheque
                                    "0.00", // other
                                    total.toString(), //total.toString(),
                                    "0.00"); // change.toString());
                            request.getEvent().getItems().add(transRef);
                        }

                        for (String ref : rechargePlusTransRefs) {
                            request.getEvent().getItems().add(ref);
                        }

                    }

                    Log.d(TAG, "tendering");

                    startAEONAsyncTask(this, socket, request);
                }

            } else {
                createSystemErrorConfirmation(response, true);
            }

        } else if (object instanceof TenderResponseMessage) {
            dismissProgress();

            connectedToAEON = true;
            gettingMvnoVoucher = false;

            Log.v(TAG, "tender response message");
            TenderResponseMessage response = (TenderResponseMessage) object;
            if (response.getEvent().getEventCode().equals("0")) {
                Log.v(TAG, "ok");
                saveAccountDetails(response.getData().getAccounts());

                if (multipleVouchersAuthenticationResponseMessage != null) {
                    Log.v(TAG, "tender response message");
                    if (response.getEvent().getEventCode().equals("0")) {
                        Log.v(TAG, "ok");
                        /*
                         */
                        if (getPreference(PREF_PRINT_SALES_RECEIPT).equals(PREF_TRUE)) {
                            ArrayList<CommonResponseLineMessage> merchantSalesReceipt;
                            merchantSalesReceipt = new ArrayList<>();
                            if (!getPreference(PREF_STORE_NAME).trim().equalsIgnoreCase("")) {
                                merchantSalesReceipt.add(printLine("H", getPreference(PREF_STORE_NAME)));
                            }

                            if (!getPreference(PREF_STORE_ADDRESS).trim().equalsIgnoreCase("")) {
                                merchantSalesReceipt.add(printLine("H", getPreference(PREF_STORE_ADDRESS)));
                            }

                            if (!getPreference(PREF_VAT_REG_NO).trim().equalsIgnoreCase("")) {
                                merchantSalesReceipt.add(printLine("H", getPreference(PREF_VAT_REG_NO)));
                            }
                            merchantSalesReceipt.add(printLine("H", "Sales Receipt"));
                            merchantSalesReceipt.add(printLine("N", ""));
                            merchantSalesReceipt.add(printLine("O", format("Date", todaysDateAndTime())));
                            merchantSalesReceipt.add(printLine("O", format("Cashier", loginResponseMessage.getData().getUserName())));
                            merchantSalesReceipt.add(printLine("N", ""));

                            BigDecimal total = new BigDecimal("0.0");
                            for (int i = 0; i < multipleVouchersAuthenticationResponseMessage.getData().getVouchers().size(); i++) {
                                merchantSalesReceipt.add(printLine("O",
                                        format(30, multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getProductName(),
                                                formatMoney(multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getAmount()))));
                                BigDecimal amount = new BigDecimal(multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getAmount());
                                total = total.add(amount);
                            }

                            if (multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().size() > 0) {
                                for (int i = 0; i < multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().size(); ++i) {
                                    if (multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().get(i).getTransSeq() != null) {
                                        merchantSalesReceipt.add(printLine("O",
                                                format(30, multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().get(i).getVoucherDescription(),
                                                        formatMoney(multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().get(i).getValue()))));
                                        BigDecimal amount = new BigDecimal(multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().get(i).getValue());
                                        total = total.add(amount);
                                    }
                                }
                            }
                            merchantSalesReceipt.add(printLine("O", format(30, "Total", total.toString())));
                            merchantSalesReceipt.add(printLine("N", ""));
                            merchantSalesReceipt.add(printLine("O", format(30, "Cash", total.toString())));

                            merchantSalesReceipt.add(printLine("N", ""));
                            merchantSalesReceipt.add(printLine("H", getResources().getString(R.string.printDone)));

                            print(merchantSalesReceipt);
                        }
                        File[] pending = getPendingToTender();
                        for (File file : pending) {
                            Log.v(TAG, "deleting is " + file.getPath());
                            file.delete();
                        }

                        File[] pending2 = getNotTendered();
                        for (File file : pending2) {
                            Log.v(TAG, "deleting is " + file.getPath());
                            file.delete();
                        }
                        Log.d(TAG, "pref-cash-drawer is " + getPreference(PREF_CASH_DRAWER));
                        if (getPreference(PREF_CASH_DRAWER).equals(PREF_TRUE)) {
                            Log.d(TAG, "Opening Cash Drawer");
                            if (!(Build.MODEL.startsWith("P1") || Build.MODEL.startsWith("V1") || Build.MODEL.startsWith("N3")))
                                CashDrawerUtil.openCash();
                        }
                    }

                } else {
                    if (getPreference(PREF_PRINT_SALES_RECEIPT).equals(PREF_TRUE)) {
                        ArrayList<CommonResponseLineMessage> merchantSalesReceipt;
                        merchantSalesReceipt = new ArrayList<>();

                        if (!getPreference(PREF_STORE_NAME).trim().equalsIgnoreCase("")) {
                            merchantSalesReceipt.add(printLine("H", getPreference(PREF_STORE_NAME)));
                        }

                        if (!getPreference(PREF_STORE_ADDRESS).trim().equalsIgnoreCase("")) {
                            merchantSalesReceipt.add(printLine("H", getPreference(PREF_STORE_ADDRESS)));
                        }

                        if (!getPreference(PREF_VAT_REG_NO).trim().equalsIgnoreCase("")) {
                            merchantSalesReceipt.add(printLine("H", getPreference(PREF_VAT_REG_NO)));
                        }

                        merchantSalesReceipt.add(printLine("H", "Sales Receipt"));
                        merchantSalesReceipt.add(printLine("N", ""));
                        merchantSalesReceipt.add(printLine("O", format("Date", todaysDateAndTime())));
                        merchantSalesReceipt.add(printLine("O", format("Cashier", loginResponseMessage.getData().getUserName())));
                        merchantSalesReceipt.add(printLine("N", ""));

                        merchantSalesReceipt.add(printLine("O", format(30, tenderDescription, formatMoney(tenderAmount))));

                        BigDecimal total = new BigDecimal("0.0");
                        try {
                            total = new BigDecimal(tenderAmount);
                        } catch (Exception ex) {
                            Log.d(TAG, "results: " + ex);
                        }

                        //recharge plus tendering
                        if (AirtimeTopupResponsePurchaseMessage != null) {

                            if (AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().size() > 0) {
                                for (int i = 0; i < AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().size(); ++i) {
                                    if (AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().get(i).getTransSeq() != null) {
                                        merchantSalesReceipt.add(printLine("O",
                                                format(30, AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().get(i).getVoucherDescription(),
                                                        formatMoney(AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().get(i).getValue()))));
                                        BigDecimal amount = new BigDecimal(
                                                AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().get(i).getValue());
                                        total = total.add(amount);
                                    }
                                }
                            }
                        } else if (bundlesResponseDoBundleTopupMessage != null) {
                            if (bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().size() > 0) {

                                for (int i = 0; i < bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().size(); ++i) {
                                    if (bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().get(i).getTransSeq() != null) {
                                        merchantSalesReceipt.add(printLine("O",
                                                format(30, bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().get(i).getVoucherDescription(),
                                                        formatMoney(bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().get(i).getValue()))));
                                        BigDecimal amount = new BigDecimal(
                                                bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().get(i).getValue());
                                        total = total.add(amount);
                                    }
                                }
                            }
                        }

                        merchantSalesReceipt.add(printLine("O", format(30, "Total", formatMoney(total.toString()))));
                        merchantSalesReceipt.add(printLine("N", ""));
                        merchantSalesReceipt.add(printLine("O", format(30, paymentType.substring(0, 1).toUpperCase() + paymentType.substring(1).toLowerCase(), formatMoney(total.toString()))));

                        merchantSalesReceipt.add(printLine("N", ""));
                        merchantSalesReceipt.add(printLine("H", getResources().getString(R.string.printDone)));

                        print(merchantSalesReceipt);
                    } else {
                        //
                        // don't print sales receipt but you must remove the files
                        //
                        File[] pending = getPendingToTender();
                        for (File file : pending) {
                            Log.v(TAG, "deleting is " + file.getPath());
                            file.delete();
                        }
                    }
                }
                Log.d(TAG, "pref-cash-drawer is " + getPreference(PREF_CASH_DRAWER));
                if (getPreference(PREF_CASH_DRAWER).equals(PREF_TRUE)) {
                    Log.d(TAG, "Opening Cash Drawer");
                    if (!(Build.MODEL.startsWith("P1") || Build.MODEL.startsWith("V1") || Build.MODEL.startsWith("N3"))) {
                        CashDrawerUtil.openCash();
                    }
                }
                paymentType = "cash";

                cleanUp();

                if (needsToRetryAutoCancel) {
                    retryPutcoAutoCancel();
                } else {
                    gotoMainScreen();
                    getAccountBalanceIfNecessary();
                }

                File[] notTendered = getNotTendered();
                for (File file : notTendered) {
                    Log.v(TAG, "deleting is " + file.getPath());
                    file.delete();
                }

            } else {
                createSystemErrorConfirmation(response, true);
            }
            lockBackButton = false;
            isLotto = false;

        } else if (object instanceof IthubaAuthenticationResponseMessage) {
            ithubaAuthenticationResponseMessage = (IthubaAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(ithubaAuthenticationResponseMessage.getEvent());

            loginResponseMessage.setSessionId(ithubaAuthenticationResponseMessage.getSessionId());
            if (ithubaAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                dismissProgress();
                preConfirm(gameName, numBoards, numDraws, playPlusBox, playPlus2Box);
            } else {
                dismissProgress();
                createSystemErrorConfirmation(ithubaAuthenticationResponseMessage, true);
            }

        } else if (object instanceof IthubaResponseItbConfirmMessage) {
            IthubaResponseItbConfirmMessage ithubaResponseItbConfirmMessage = (IthubaResponseItbConfirmMessage) object;
            if (ithubaResponseItbConfirmMessage.getEvent().getEventCode().equals("0")) {
                dismissProgress();

                isLotto = true;
                String plusLottoOrPowerball = "";
                String plus2Lotto = "";
                if (gameName.contains("lotto")) {
                    plusLottoOrPowerball = "Lotto Plus 1";
                    plus2Lotto = "Lotto Plus 2";
                } else if (gameName.contains("powerball")) {
                    plusLottoOrPowerball = "Powerball Plus";
                    //plus2Lotto = "Powerball Plus 2";
                }

                double amountDue = Double.parseDouble(ithubaResponseItbConfirmMessage.getData().getAmt()) / 100;

                String confirmMessage;
                if (!yesNoCheckBox.isEmpty() && !yesNoCheckBox2.isEmpty()) {
                    confirmMessage = " \nBoards: " + numBoards +
                            " \nDraws: " + numDraws +
                            " \n" + plusLottoOrPowerball + ": " + yesNoCheckBox +
                            ((plus2Lotto.isEmpty()) ? "" : " \n" + plus2Lotto + ": " + yesNoCheckBox2) +
                            " \n" +
                            " \nAmount due: R" + df2.format(amountDue);

                    if (passesChecks) {

                        printConfirm();

                        final AlertDialog alertDialog = new AlertDialog.Builder(this).create();

                        if (name.contains("lotto")) {
                            alertDialog.setTitle(getResources().getString(R.string.lottoPSConfirmation)); //"Lotto Choose Numbers Confirmation");
                        } else if (name.contains("powerball")) {
                            alertDialog.setTitle(getResources().getString(R.string.powerballPSConfirmation)); //"Powerball Choose Numbers Confirmation");
                        }

                        alertDialog.setMessage(confirmMessage);

                        alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                buyTicket(requestMap);
                            }
                        });

                        alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                closeAeonSocket(30);
                                alertDialog.dismiss();
                                isLotto = false;
                            }
                        });
                        alertDialog.show();
                    }

                } else {
                    confirmMessage = "Amount due: " + df2.format(amountDue) + "\n";

                    final AlertDialog alertDialog = new BluDroidAlertDialog(this);

                    if (gameName.contains("lotto")) {
                        alertDialog.setTitle(getResources().getString(R.string.lottoQPConfirmation));
                    } else if (gameName.contains("powerball")) {
                        alertDialog.setTitle(getResources().getString(R.string.powerballQPConfirmation));
                    }

                    alertDialog.setMessage(confirmMessage);

                    alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            buyTicket(requestMap);
                        }
                    });

                    alertDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            closeAeonSocket(29);
                            alertDialog.dismiss();
                            isLotto = false;
                        }
                    });
                    alertDialog.show();
                }

            } else {
                dismissProgress();
                createSystemErrorConfirmation(ithubaResponseItbConfirmMessage, true);
            }

        } else if (object instanceof IthubaResponseItbLotteryMessage) {
            dismissProgress();
            responseItbLotteryMessage = (IthubaResponseItbLotteryMessage) object;
            if (responseItbLotteryMessage.getEvent().getEventCode().equals("0")) {

                String description = "";

                if (!yesNoCheckBox.isEmpty() && !yesNoCheckBox2.isEmpty()) {
                    if (name.contains("lotto")) {
                        description = "Lotto Player Selection";
                    } else if (name.contains("powerball")) {
                        description = "Powerball Player Selection";
                    }
                } else {
                    if (gameName.contains("lotto")) {
                        description = getResources().getString(R.string.lottoQP); //"Lotto Quickpick";
                    } else if (gameName.contains("powerball")) {
                        description = getResources().getString(R.string.powerballQP); //"Powerball Quickpick";
                    }
                }

                saveDetailsUntilPaidLotto(responseItbLotteryMessage.getData().getTransRef(),
                        description, //.getProductName(),
                        String.valueOf(Double.parseDouble(responseItbLotteryMessage.getData().getAmt()) / 100));

                /*ArrayList<CommonResponseLineMessage> printLottoLines = responseItbLotteryMessage.getData().getPrintLines();
                printWithDynamic(printLottoLines, true);
                logger.info("Lotto printed:" + isVoucherPrinted);

                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    print(responseItbLotteryMessage.getData().getMerchantPrintLines());
                }*/

                if (previewSlipsEnabled()) {
                    List<PrintJob> printJobs = new ArrayList<>();
                    printJobs.add(new PrintJob(responseItbLotteryMessage.getData().getPrintLines(), true, getPrintBarcode()));
                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        printJobs.add(new PrintJob(responseItbLotteryMessage.getData().getMerchantPrintLines(), false, false));
                    }
                    new BluDroidSlipPreviewLottoDialog(this, printJobs);

                } else {

                    printWithDynamic(responseItbLotteryMessage.getData().getPrintLines(), getPrintBarcode());

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        print(responseItbLotteryMessage.getData().getMerchantPrintLines());
                    }
                    completeLotto();
                }

            } else {
                isLotto = false;
                createSystemErrorConfirmation(responseItbLotteryMessage, true);
            }

        } else if (object instanceof IthubaResponseItbPowerballMessage) {
            IthubaResponseItbPowerballMessage ithubaResponseItbPowerballMessage = (IthubaResponseItbPowerballMessage) object;
            if (ithubaResponseItbPowerballMessage.getEvent().getEventCode().equals("0")) {
                dismissProgress();

                String description = "";

                if (!yesNoCheckBox.isEmpty() && !yesNoCheckBox2.isEmpty()) {
                    if (name.contains("lotto")) {
                        description = "Lotto Player Selection";
                    } else if (name.contains("powerball")) {
                        description = "Powerball Player Selection";
                    }
                } else {
                    if (gameName.contains("lotto")) {
                        description = getResources().getString(R.string.lottoQP); //"Lotto Quickpick";
                    } else if (gameName.contains("powerball")) {
                        description = getResources().getString(R.string.powerballQP); //"Powerball Quickpick";
                    }
                }

                saveDetailsUntilPaidLotto(ithubaResponseItbPowerballMessage.getData().getTransRef(),
                        description, //.getProductName(),
                        String.valueOf(Double.parseDouble(ithubaResponseItbPowerballMessage.getData().getAmt()) / 100));

                /*ArrayList<CommonResponseLineMessage> printPowerballLines = ithubaResponseItbPowerballMessage.getData().getPrintLines();
                printWithDynamic(printPowerballLines, true);
                logger.info("Lotto printed:" + isVoucherPrinted);

                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    print(ithubaResponseItbPowerballMessage.getData().getMerchantPrintLines());
                }*/

                if (previewSlipsEnabled()) {
                    List<PrintJob> printJobs = new ArrayList<>();
                    printJobs.add(new PrintJob(ithubaResponseItbPowerballMessage.getData().getPrintLines(), true, getPrintBarcode()));
                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        printJobs.add(new PrintJob(ithubaResponseItbPowerballMessage.getData().getMerchantPrintLines(), false, false));
                    }
                    new BluDroidSlipPreviewPowerballDialog(this, printJobs);

                } else {

                    printWithDynamic(ithubaResponseItbPowerballMessage.getData().getPrintLines(), getPrintBarcode());

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        print(ithubaResponseItbPowerballMessage.getData().getMerchantPrintLines());
                    }
                    completePowerball();
                }

            } else {
                isLotto = false;
                createSystemErrorConfirmation(ithubaResponseItbPowerballMessage, true);
            }

        } else if (object instanceof IthubaResponseItbPrintedMessage) {
            IthubaResponseItbPrintedMessage ithubaResponseItbPrintedMessage = (IthubaResponseItbPrintedMessage) object;
            if (ithubaResponseItbPrintedMessage.getEvent().getEventCode().equals("0")) {

                if (getPreference(PREF_CASH_DRAWER).equals(PREF_TRUE)) {
                    Log.d(TAG, "Opening Cash Drawer");
                    if (!(Build.MODEL.startsWith("P1") || Build.MODEL.startsWith("V1") || Build.MODEL.startsWith("N3")))
                        CashDrawerUtil.openCash();
                }
                cleanUp();
                emptyBasket();
                Log.i(TAG, "PRINTED: Ithuba Lotto quickpick");
            } else {
                createSystemErrorConfirmation(ithubaResponseItbPrintedMessage, true);
            }

        } else if (object instanceof RicaAuthenticationResponseMessage) {
            ricaAuthenticationResponseMessage = (RicaAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(ricaAuthenticationResponseMessage.getEvent());

            if (ricaAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

                if (isRicaLogin) {
                    checkRicaUser();
                } else if (isRicaRegister) {
                    if (ricaMultiRegistration) {
                        ricaRegisterMultipleSims();
                    } else {
                        ricaRegisterSim();
                    }
                } else if (isRicaQuery) {
                    doRicaQuery();
                } else if (isRicaChangeOnwer) {
                    ricaChangeOwner();
                } else if (isRicaboxRica) {
                    ricaBoxRegister();
                }
            } else {
                createSystemErrorConfirmation(ricaAuthenticationResponseMessage, true);
            }

        } else if (object instanceof RicaResponseCheckUserMessage) {
            dismissProgress();
            Log.v(TAG, "got rica checkUser response");
            RicaResponseCheckUserMessage ricaResponseCheckUserMessage =
                    (RicaResponseCheckUserMessage) object;
            Log.v(TAG, "eventcode is " + ricaResponseCheckUserMessage.getEvent().getEventCode());
            if (ricaResponseCheckUserMessage.getEvent().getEventCode().equals("0")) {
                Log.v(TAG, "ok to go");

                // store username and password for fast future access
                updateEncryptedPreference(PREF_RICA_USERNAME + "_" + firstTwoDigitsPin(), username);
                updateEncryptedPreference(PREF_RICA_PASSWORD + "_" + firstTwoDigitsPin(), password);

                //gotoRicaMenu
                FragmentRicaMenu fragmentRicaMenu = new FragmentRicaMenu();
                FragmentTransaction transaction = baseFm.beginTransaction();

                transaction.replace(R.id.content_frame, fragmentRicaMenu);
                transaction.commit();
            } else {
                createSystemErrorConfirmation(ricaResponseCheckUserMessage, true);
            }

        } else if (object instanceof RicaResponseQueryMessage) {
            dismissProgress();
            Log.v(TAG, "got rica query response");
            RicaResponseQueryMessage ricaResponseQueryMessage =
                    (RicaResponseQueryMessage) object;
            Log.v(TAG, "eventcode is " + ricaResponseQueryMessage.getEvent().getEventCode());
            if (ricaResponseQueryMessage.getEvent().getEventCode().equals("0")) {
                Log.v(TAG, "success");
                createRicaAlertDialog("RICA", ricaResponseQueryMessage.getData().getMessageDetails() + " in terms of the the RICA act.");

            } else {
                Log.v(TAG, "NOT success");
                // this is a kluge.  sometimes we get Invalid Session ID and I don't
                // understand why.  So let's just log in again
                if (ricaResponseQueryMessage.getEvent().getEventCode().equals("1") &&
                        ricaResponseQueryMessage.getData().getMessage().equals("Invalid Session ID")) {
                    Log.v(TAG, "trying to login again");
                    gotoMainScreen();
                } else
                    createAlertDialog("RICA", ricaResponseQueryMessage.getData().getMessageDetails());
            }

        } else if (object instanceof RicaResponseRegisterMessage) {
            dismissProgress();
            Log.v(TAG, "got rica register response");
            RicaResponseRegisterMessage ricaResponseRegisterMessage = (RicaResponseRegisterMessage) object;
            Log.v(TAG, "eventcode is " + ricaResponseRegisterMessage.getEvent().getEventCode());
            if (ricaResponseRegisterMessage.getEvent().getEventCode().equals("0")) {
                Log.v(TAG, "success");
                //  success = true;
                createRicaAlertDialog("RICA Register", ricaResponseRegisterMessage.getData().getMessageDetails());

            } else {
                Log.v(TAG, "NOT success");

                //  success = false;
                //
                // this is a kluge.  sometimes we get Invalid Session ID and I don't
                // understand why.  So let's just log in again
                //
                if (ricaResponseRegisterMessage.getEvent().getEventCode().equals("1") &&
                        ricaResponseRegisterMessage.getData().getMessage().equals("Invalid Session ID")) {
                    Log.v(TAG, "trying to login again");
                    gotoMainScreen();
                } else {
                    createAlertDialog(ricaResponseRegisterMessage.getData().getMessage(), ricaResponseRegisterMessage.getData().getMessageDetails());
                }
            }

        } else if (object instanceof RicaResponseMultipleRegisterMessage) {
            dismissProgress();
            Log.v(TAG, "got rica multipleregister response");
            RicaResponseMultipleRegisterMessage ricaResponseMultipleRegisterMessage =
                    (RicaResponseMultipleRegisterMessage) object;
            Log.v(TAG, "eventcode is " + ricaResponseMultipleRegisterMessage.getEvent().getEventCode());
            if (ricaResponseMultipleRegisterMessage.getEvent().getEventCode().equals("0")) {
                Log.v(TAG, "success");
                // success = true;
                StringBuilder sb = new StringBuilder();
                ArrayList<CommonResponseLineMessage> errors = new ArrayList<>();

                boolean needToPrint = false;
                boolean hasErrors = false;
                for (int i = 0; i < ricaResponseMultipleRegisterMessage.getData().getSims().size(); i++) {
                    RicaResponseSIMSMessage sim = ricaResponseMultipleRegisterMessage.getData().getSims().get(i);
                    if (sim.getErrorCode().equals("0")) {
                        needToPrint = true;
                        hasErrors = false;
                        errors.add(printLine("H", "Success"));
                        errors.add(printLine("N", ""));
                        errors.add(printLine("O", format("SIM Serial", "")));

                        errors.add(printLine("O", format(sim.getSerial(), "")));
                        errors.add(printLine("N", sim.getMessageDetails()));

                        sb.append("<BR>").append(sim.getSerial()).append(" ").append(sim.getResultCode()).append(" ").append(sim.getMessage()).append(" ").append(sim.getMessageDetails());

                    } else {

                        needToPrint = true;
                        hasErrors = true;
                        errors.add(printLine("H", "Errors"));
                        errors.add(printLine("N", ""));
                        errors.add(printLine("O", format("SIM Serial", "")));
                        sb.append("<BR>").append(sim.getSerial()).append(" ").append(sim.getResultCode()).append(" ").append(sim.getMessage()).append(" ").append(sim.getMessageDetails());
                        errors.add(printLine("O", format(sim.getSerial(), "")));
                        errors.add(printLine("N", sim.getMessageDetails()));
                    }
                }
                if (needToPrint && hasErrors) {
                    print(errors);
                    createAlertDialog("Rica Multiple registrations", Html.fromHtml(sb.toString()).toString());
                }
                if (!hasErrors) {
                    print(errors);
                    createRicaAlertDialog("Rica Multiple registrations", Html.fromHtml(sb.toString()).toString());
                }

            } else {
                createAlertDialog("Rica Multiple registrations", ricaResponseMultipleRegisterMessage.getData().getMessageDetails());
            }

        } else if (object instanceof RicaResponseChangeOwnerMessage) {
            dismissProgress();
            Log.v(TAG, "got rica ChangeOwner response");
            RicaResponseChangeOwnerMessage ricaResponseChangeOwnerMessage =
                    (RicaResponseChangeOwnerMessage) object;
            Log.v(TAG, "eventcode is " + ricaResponseChangeOwnerMessage.getEvent().getEventCode());
            if (ricaResponseChangeOwnerMessage.getEvent().getEventCode().equals("0")) {
                Log.v(TAG, "success");
                //  success = true;
                createRicaAlertDialog("RICA Change Owner", ricaResponseChangeOwnerMessage.getData().getMessageDetails());

            } else {
                Log.v(TAG, "NOT success");
                // success = false;
                //
                // this is a kluge.  sometimes we get Invalid Session ID and I don't
                // understand why.  So let's just log in again
                //
                if (ricaResponseChangeOwnerMessage.getEvent().getEventCode().equals("1") &&
                        ricaResponseChangeOwnerMessage.getData().getMessage().equals("Invalid Session ID")) {
                    Log.v(TAG, "trying to login again");
                    gotoMainScreen();
                } else {
                    createAlertDialog(ricaResponseChangeOwnerMessage.getData().getMessage(), ricaResponseChangeOwnerMessage.getData().getMessageDetails());
                }
            }

        } else if (object instanceof RicaResponseBoxNumberSIMSMessage) {
            dismissProgress();
            Log.v(TAG, "got box rica response");
            RicaResponseBoxNumberSIMSMessage ricaResponseBoxNumberSIMSMessage =
                    (RicaResponseBoxNumberSIMSMessage) object;
            if (ricaResponseBoxNumberSIMSMessage.getEvent().getEventCode().equals("0")) {
                Log.v(TAG, "success");
                // success = true;
                StringBuilder sb = new StringBuilder();
                ArrayList<CommonResponseLineMessage> errors = new ArrayList<>();
                errors.add(printLine("H", "Errors"));
                errors.add(printLine("N", ""));
                errors.add(printLine("O", format("SIM Serial", "")));
                boolean needToPrint = false;
                for (int i = 0; i < ricaResponseBoxNumberSIMSMessage.getData().getSims().size(); i++) {
                    RicaResponseSIMSMessage sim = ricaResponseBoxNumberSIMSMessage.getData().getSims().get(i);
                    if (sim.getErrorCode().equals("0")) {
                        sb.append("<BR>").append(sim.getSerial()).append(" ").append(sim.getResultCode());
                    } else {
                        needToPrint = true;
                        sb.append("<BR>").append(sim.getSerial()).append(" ").append(sim.getResultCode()).append(" ").append(sim.getMessage()).append(" ").append(sim.getMessageDetails());
                        errors.add(printLine("O", format(sim.getSerial(), "")));
                        errors.add(printLine("N", sim.getMessageDetails()));
                    }
                }
                if (needToPrint) {
                    print(errors);
                }
                createRicaAlertDialog("Box RICA", Html.fromHtml(sb.toString()).toString());
            } else {
                createAlertDialog("Box RICA", ricaResponseBoxNumberSIMSMessage.getData().getMessageDetails());
            }

        } else if (object instanceof BillPaymentsAuthenticationResponseMessage) {
            billPaymentsAuthenticationResponseMessage = (BillPaymentsAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(billPaymentsAuthenticationResponseMessage.getEvent());

            //
            // LB added this if statement
            //
            if (billPaymentsAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

                Date billPaymentCacheDate = dateLastBillPaymentCache();
                Date now = new Date();
                Log.d(TAG, "now.getTime() " + now.getTime());
                Log.d(TAG, "billPaymentCacheDate.getTime() " + billPaymentCacheDate.getTime());
                Log.d(TAG, "maxCacheAgeMillis " + CACHE_12_HOURS);
                Log.d(TAG, "now-cachedate " + (now.getTime() - billPaymentCacheDate.getTime()));
                if (((now.getTime() - billPaymentCacheDate.getTime()) > CACHE_12_HOURS) ||
                        Build.MODEL.startsWith("CITAQ")) {
                    //dismissProgress();
                    authenticateforBillPaymentsProductList();
                } else {
                    Log.d(TAG, "Using cache");
                    //dismissProgress();
                    billPaymentsResponseProductListMessage = getCachedBillPaymentData();
                    if (billPaymentsResponseProductListMessage != null && billPaymentsResponseProductListMessage.getData().getProviders().size() > 0) {
                        //prepareBillPaymentArray();
                        //
                        // do not change this log.  it is used for testing
                        //
                        Log.d(TAG, "TEST : RECEIVED PRODUCT LIST");
                        gettingVouchers = false;
                        if (voucherAuthenticationResponseMessage != null) {
                            if (voucherAuthenticationResponseMessage.getData().getTransTypes().contains("C4C_Voucher")) {
                                authenticateForChatForChange();
                            }
                        }
                    } else {
                        authenticateforBillPaymentsProductList();
                    }
                }
            } else {
                dismissProgress();
                createSystemErrorConfirmation(billPaymentsAuthenticationResponseMessage, true);
            }

        } else if (object instanceof BillPaymentsResponseProductListMessage) {
            billPaymentsResponseProductListMessage = (BillPaymentsResponseProductListMessage) object;

            cacheBillPaymentData(billPaymentsResponseProductListMessage);
            // prepareBillPaymentArray();
            dismissProgress();
            //
            // do not change this log.  it is used for testing
            //
            gettingVouchers = false;
            if (voucherAuthenticationResponseMessage != null && voucherAuthenticationResponseMessage.getData().getTransTypes().contains("C4C_Voucher")) {
                authenticateForChatForChange();
            } else {
                retryFailedCancellationsAndTenders();
            }
            Log.d(TAG, "TEST : RECEIVED PRODUCT LIST Final chained network call");

        } else if (object instanceof BillPaymentsSapoAuthenticationResponseMessage) {
            dismissProgress();
            createProgress(getResources().getString(R.string.payingAccount));
            possibleTitle = "SAPO ";

            BillPaymentsSapoAuthenticationResponseMessage response = (BillPaymentsSapoAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(response.getEvent());

            if (response.getEvent().getEventCode().equals("0")) {
                BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();

                BillPaymentsRequestSapoAccountPaymentMessage request;
                if (additionalFields.equals("1")) {
                    accountNumber = "Telkom " + strGroupNumber + "-" +
                            strSystemNumber + "-" +
                            strPaymentCode + "-" +
                            strControlCode;
                    request = factory.createSapoTelkomAccountPayment(
                            response.getSessionId(),
                            providerId,
                            productId,
                            strGroupNumber,
                            strSystemNumber,
                            strPaymentCode,
                            strControlCode,
                            strAmont,
                            paymentType);
                } else {
                    accountNumber = strAccount;
                    request = factory.createSapoAccountPayment(
                            response.getSessionId(),
                            providerId,
                            productId,
                            accountNumber,
                            strAmont,
                            paymentType);
                }
                possibleTitle = possibleTitle.concat(accountNumber);
                startAEONAsyncTask(this, socket, request);

            } else {
                createSystemErrorConfirmation(response, true);
            }

        } else if (object instanceof BillPaymentsResponseSapoAccountPaymentMessage) {
            dismissProgress();
            BillPaymentsResponseSapoAccountPaymentMessage response = (BillPaymentsResponseSapoAccountPaymentMessage) object;
            if (response.getEvent().getEventCode().equals("0")) {
                createProgress(getResources().getString(R.string.confirmingPayment));
                receipt.add(format(getResources().getString(R.string.transRef), response.getData().getTransRef()));
                receipt.add(format(getResources().getString(R.string.date), todaysDateAndTime()));
                receipt.add(format(getResources().getString(R.string.cashier), loginResponseMessage.getData().getUserName()));
                //receipt.add(response.getData().getRefNo());
                transRef = response.getData().getTransRef();
                reference = response.getData().getRefNo();
                BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
                BillPaymentsRequestSapoConfirmMessage request = factory.createConfirmation(response);
                startAEONAsyncTask(this, socket, request);
            } else {
                createSystemErrorConfirmation(response, true);
            }

        } else if (object instanceof BillPaymentsResponseSapoConfirmMessage) {
            // dismissProgress();
            sapoResponseMessage = (BillPaymentsResponseSapoConfirmMessage) object;

            if (sapoResponseMessage.getEvent().getEventCode().equals("0")) {
                saveDetailsUntilPaid(transRef, "SAPO", productName, strAmont); // as per Brian's request
                /*receipt.add(HORIZONTAL_LINE);
                receipt.add(getResources().getString(R.string.printDone));
                //print(receipt);
                printWithDynamic(sapoResponseMessage.getData().getPrintLines(), getPrintBarcode());
                Log.v(TAG, "possible Title is " + possibleTitle);
                Log.v(TAG, "receipt has " + receipt.size() + " lines");
                //save(possibleTitle, receipt);
                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    print(sapoResponseMessage.getData().getMerchantPrintLines());
                }*/
                if (previewSlipsEnabled()) {
                    List<PrintJob> printJobs = new ArrayList<>();
                    printJobs.add(new PrintJob(sapoResponseMessage.getData().getPrintLines(), true, getPrintBarcode()));
                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        printJobs.add(new PrintJob(sapoResponseMessage.getData().getMerchantPrintLines(), false, false));
                    }
                    new BluDroidSlipPreviewSapo(this, printJobs);

                } else {

                    printWithDynamic(sapoResponseMessage.getData().getPrintLines(), getPrintBarcode());

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        print(bundlesResponseDoBundleTopupMessage.getData().getMerchantPrintLines());
                    }
                    completeSapo();
                }

            } else {
                dismissProgress();
                createSystemErrorConfirmation(sapoResponseMessage, true);
            }

        } else if (object instanceof BillPaymentsSyntellAuthenticationResponseMessage) {
            Log.d(TAG, "authentication response");
            possibleTitle = "Syntell ";
            billPaymentsSyntellAuthenticationResponseMessage = (BillPaymentsSyntellAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(billPaymentsSyntellAuthenticationResponseMessage.getEvent());

            if (billPaymentsSyntellAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                Log.d(TAG, "want to pay account ");
                createProgress(getResources().getString(R.string.verifyingAccount));
                receipt = new ArrayList<>();
                receipt.add("Syntell Bill Payment");
                receipt.add(productName);
                possibleTitle = possibleTitle.concat(accountNumber);
                BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
                if (state == 0) {
                    if (isTraficFinePayment) {
                        billPaymentsRequestSyntellAccountPaymentMessage = factory.createSyntellFinePayment(
                                billPaymentsSyntellAuthenticationResponseMessage.getSessionId(),
                                providerId,
                                productId,
                                accountNumber,
                                "0.0",
                                "cash");
                    } else {
                        billPaymentsRequestSyntellAccountPaymentMessage = factory.createSyntellAccountPayment(
                                billPaymentsSyntellAuthenticationResponseMessage.getSessionId(),
                                providerId,
                                productId,
                                accountNumber,
                                "20.0",
                                "cash");
                    }
                    startAEONAsyncTask(this, socket, billPaymentsRequestSyntellAccountPaymentMessage);

                } else if (state == 1) {
                    if (isTraficFinePayment) {
                        billPaymentsRequestSyntellAccountPaymentMessage = factory.createSyntellFinePayment(
                                billPaymentsSyntellAuthenticationResponseMessage.getSessionId(),
                                providerId,
                                productId,
                                accountNumber,
                                amount,
                                paymentType);
                    } else {
                        billPaymentsRequestSyntellAccountPaymentMessage = factory.createSyntellAccountPayment(
                                billPaymentsSyntellAuthenticationResponseMessage.getSessionId(),
                                providerId,
                                productId,
                                accountNumber,
                                amount,
                                paymentType);
                    }
                    startAEONAsyncTask(this, socket, billPaymentsRequestSyntellAccountPaymentMessage);
                }

            } else {
                dismissProgress();
                createSystemErrorConfirmation(billPaymentsSyntellAuthenticationResponseMessage, true);
            }

        } else if (object instanceof BillPaymentsResponseSyntellAccountPaymentMessage) {

            dismissProgress();

            billPaymentsResponseSyntellAccountPaymentMessage = (BillPaymentsResponseSyntellAccountPaymentMessage) object;
            if (billPaymentsResponseSyntellAccountPaymentMessage.getEvent().getEventCode().equals("0")) {
                Log.d(TAG, "state " + state + "");

                transRef = billPaymentsResponseSyntellAccountPaymentMessage.getData().getTransRef();
                if (billPaymentsResponseSyntellAccountPaymentMessage.getData().getTransactionStatus().equals("Pending") || billPaymentsResponseSyntellAccountPaymentMessage.getData().getFine().getPaymentAllowed().equals(PREF_TRUE)) {
                    //
                    // this just confirms the account number and rolls back the transaction
                    //
                    if (state == 0) {
                        Log.d(TAG, "valid account");
                        //configureScreen(View.VISIBLE);

                        if (isTraficFinePayment) {

                            createTrafficFineConfirmationDialog(this);

                            if (confirmation instanceof BluDroidTrafficFineConfirmationDialog) {

                                BluDroidTrafficFineConfirmationDialog dialog = (BluDroidTrafficFineConfirmationDialog) confirmation;

                                dialog.setIcon(getResources().getDrawable(R.drawable.billpayment_syntell));
                                dialog.setNoticeNumber(billPaymentsResponseSyntellAccountPaymentMessage.getData().getFine().getNoticeNumber());
                                dialog.setVehicleRegNumber(billPaymentsResponseSyntellAccountPaymentMessage.getData().getFine().getVehicleRegNumber());
                                dialog.setOnwerId(billPaymentsResponseSyntellAccountPaymentMessage.getData().getFine().getOwnerIdNumber());
                                dialog.setlocation(billPaymentsResponseSyntellAccountPaymentMessage.getData().getFine().getOffenceLocation());
                                dialog.setDate(billPaymentsResponseSyntellAccountPaymentMessage.getData().getFine().getOffenceDateTime());
                                dialog.setAmountDue(billPaymentsResponseSyntellAccountPaymentMessage.getData().getFine().getAmountDue());
                                dialog.setConvienceFee(billPaymentsResponseSyntellAccountPaymentMessage.getData().getConvenienceFee());

                                try {
                                    Double amountDue = Double.parseDouble(billPaymentsResponseSyntellAccountPaymentMessage.getData().getFine().getAmountDue());
                                    Double convenienceFee = Double.parseDouble(billPaymentsResponseSyntellAccountPaymentMessage.getData().getConvenienceFee());
                                    Double total = amountDue + convenienceFee;
                                    bpConvienceFee = convenienceFee;
                                    dialog.setTotalPayable(df2.format(total));

                                    dialog.setAmount(df2.format(amountDue));

                                } catch (Exception exception) {
                                    Log.v(TAG, "number exception " + exception);
                                    logger.error("number exception " + exception);
                                }

                                dialog.setpartPayment("No");

                                BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
                                BillPaymentsRequestSyntellConfirmMessage
                                        billPaymentsRequestSyntellConfirmMessage = factory.createSyntellFineConfirm(
                                        billPaymentsResponseSyntellAccountPaymentMessage.getSessionId(),
                                        providerId,
                                        productId,
                                        "0.0",
                                        billPaymentsResponseSyntellAccountPaymentMessage.getData().getFine().getNoticeNumber(),
                                        "cash",
                                        "rollback");
                                startAEONAsyncTask(this, socket, billPaymentsRequestSyntellConfirmMessage);
                            }

                        } else {
                            createBillPaymentsConfirmationDialog(this);

                            if (confirmation instanceof BluDroidBillPaymentsConfirmationDialog) {

                                BluDroidBillPaymentsConfirmationDialog dialog = (BluDroidBillPaymentsConfirmationDialog) confirmation;

                                dialog.setAccountNumber(billPaymentsResponseSyntellAccountPaymentMessage.getData().getAccountNo());
                                dialog.setAccountHolder("-");
                                dialog.setAmountDue("-");
                                dialog.setConvienceFee(billPaymentsResponseSyntellAccountPaymentMessage.getData().getConvenienceFee());
                                bpConvienceFee = Double.parseDouble(billPaymentsResponseSyntellAccountPaymentMessage.getData().getConvenienceFee());

                                dialog.setTotalPayable("-");
                                dialog.setIcon(getResources().getDrawable(R.drawable.billpayment_syntell));
                                dialog.hideComponents();

                                BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
                                BillPaymentsRequestSyntellConfirmMessage
                                        billPaymentsRequestSyntellConfirmMessage = factory.createSyntellConfirm(
                                        billPaymentsSyntellAuthenticationResponseMessage,
                                        billPaymentsRequestSyntellAccountPaymentMessage,
                                        billPaymentsResponseSyntellAccountPaymentMessage,
                                        "rollback");
                                startAEONAsyncTask(this, socket, billPaymentsRequestSyntellConfirmMessage);
                            }
                        }
                    }
                    //
                    // this commits the transaction
                    //
                    else if (state == 1) {
                        dismissProgress();
                        createProgress(getResources().getString(R.string.confirmingPayment));
                        BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
                        if (isTraficFinePayment) {
                            BillPaymentsRequestSyntellConfirmMessage
                                    billPaymentsRequestSyntellConfirmMessage = factory.createSyntellFineConfirm(
                                    billPaymentsSyntellAuthenticationResponseMessage,
                                    billPaymentsRequestSyntellAccountPaymentMessage,
                                    billPaymentsResponseSyntellAccountPaymentMessage,
                                    paymentType,
                                    "commit");
                            startAEONAsyncTask(this, socket, billPaymentsRequestSyntellConfirmMessage);
                        } else {
                            BillPaymentsRequestSyntellConfirmMessage
                                    billPaymentsRequestSyntellConfirmMessage = factory.createSyntellConfirm(
                                    billPaymentsSyntellAuthenticationResponseMessage,
                                    billPaymentsRequestSyntellAccountPaymentMessage,
                                    billPaymentsResponseSyntellAccountPaymentMessage,
                                    "commit");
                            startAEONAsyncTask(this, socket, billPaymentsRequestSyntellConfirmMessage);
                        }
                    }
                } else {
                    createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, "Provider error - " + billPaymentsResponseSyntellAccountPaymentMessage.getData().getFine().getPaymentNotAllowedReason(), true);
                }

            } else {
                dismissProgress();
                createSystemErrorConfirmation(billPaymentsResponseSyntellAccountPaymentMessage, true);
            }

        } else if (object instanceof BillPaymentsResponseSyntellConfirmMessage) {
            Log.d(TAG, "got back confirm message");
            //dismissProgress();
            responseSyntellConfirmMessage = (BillPaymentsResponseSyntellConfirmMessage) object;
            if (responseSyntellConfirmMessage.getEvent().getEventCode().equals("0")) {
                if (responseSyntellConfirmMessage.getData().getResultDescription().contains("Success")) {
                    saveDetailsUntilPaid(transRef, possibleTitle, productName, amount);
                    /*printWithDynamic(responseSyntellConfirmMessage.getData().getPrintLines(), getPrintBarcode());

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        print(responseSyntellConfirmMessage.getData().getMerchantPrintLines());
                    }*/
                    if (previewSlipsEnabled()) {
                        List<PrintJob> printJobs = new ArrayList<>();
                        printJobs.add(new PrintJob(responseSyntellConfirmMessage.getData().getPrintLines(), true, getPrintBarcode()));
                        if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                            printJobs.add(new PrintJob(responseSyntellConfirmMessage.getData().getMerchantPrintLines(), false, false));
                        }
                        new BluDroidSlipPreviewSyntellDialog(this, printJobs);

                    } else {

                        printWithDynamic(responseSyntellConfirmMessage.getData().getPrintLines(), getPrintBarcode());

                        if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                            print(responseSyntellConfirmMessage.getData().getMerchantPrintLines());
                        }
                        completeSyntell();
                    }

                } else {
                    Log.d(TAG, "positioning screen");
                }
            } else {
                dismissProgress();
                createSystemErrorConfirmation(responseSyntellConfirmMessage, true);
            }

        } else if (object instanceof BillPaymentsBluBillAuthenticationResponseMessage) {
            dismissProgress();
            Log.d(TAG, "authentication response");
            possibleTitle = "BluBill ";

            billPaymentsBluBillAuthenticationResponseMessage = (BillPaymentsBluBillAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(billPaymentsBluBillAuthenticationResponseMessage.getEvent());

            if (billPaymentsBluBillAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                verifyBluBillAccount();
            } else {
                createSystemErrorConfirmation(billPaymentsBluBillAuthenticationResponseMessage, true);
            }

        } else if (object instanceof BillPaymentsResponseBluBillGetInfoMessage) {

            dismissProgress();

            billPaymentsResponseBluBillGetInfoMessage = (BillPaymentsResponseBluBillGetInfoMessage) object;

            if (billPaymentsResponseBluBillGetInfoMessage.getEvent().getEventCode().equals("0")) {
                Log.d(TAG, "valid account");

                createBillPaymentsConfirmationDialog(this);

                if (confirmation instanceof BluDroidBillPaymentsConfirmationDialog) {

                    BluDroidBillPaymentsConfirmationDialog dialog = (BluDroidBillPaymentsConfirmationDialog) confirmation;

                    // float minAmount = new Float(billPaymentsResponseBluBillGetInfoMessage.getData().);

                    dialog.setAccountNumber(accountNumber);
                    dialog.setAccountHolder(billPaymentsResponseBluBillGetInfoMessage.getData().getSubscriberName());
                    dialog.setAmountDue(billPaymentsResponseBluBillGetInfoMessage.getData().getAmount());
                    dialog.setConvienceFee(billPaymentsResponseBluBillGetInfoMessage.getData().getConvenienceFee());
                    dialog.setpartPayment(billPaymentsResponseBluBillGetInfoMessage.getData().getAcceptPartialPayment());

                    if (logoId != null && logoId.equals("30")) {
                        dialog.setIcon(getResources().getDrawable(R.drawable.billpayment_easypay));
                    } else if (logoId != null && logoId.equals("31")) {
                        dialog.setIcon(getResources().getDrawable(R.drawable.billpayment_unipay));
                    }

                    try {
                        Double amountDue = Double.parseDouble(billPaymentsResponseBluBillGetInfoMessage.getData().getAmount());
                        Double convenienceFee = Double.parseDouble(billPaymentsResponseBluBillGetInfoMessage.getData().getConvenienceFee());
                        Double total = amountDue + convenienceFee;
                        bpConvienceFee = convenienceFee;
                        dialog.setTotalPayable(df2.format(total));

                        if (billPaymentsResponseBluBillGetInfoMessage.getData().getAcceptPartialPayment().toLowerCase().contains("n") ||
                                billPaymentsResponseBluBillGetInfoMessage.getData().getAcceptPartialPayment().toLowerCase().contains("false")) {
                            dialog.setAmount(df2.format(amountDue));
                        }

                    } catch (Exception exception) {
                        Log.v(TAG, "problem number format exception " + exception);
                        logger.error("problem number format exception " + exception);
                    }
                }

            } else {
                EditText accountNumber = findViewById(R.id.accountNumber);
                if (accountNumber != null) accountNumber.setText("");

                //AEON returns error messages differently each time
                createSystemErrorConfirmation(billPaymentsResponseBluBillGetInfoMessage, true);
            }

        } else if (object instanceof BillPaymentsResponseBluBillConfirmMessage) {
            // dismissProgress();

            billPaymentsResponseBluBillConfirmMessage = (BillPaymentsResponseBluBillConfirmMessage) object;
            if (billPaymentsResponseBluBillConfirmMessage.getEvent().getEventCode().equals("0")) {

                transRef = billPaymentsResponseBluBillConfirmMessage.getData().getConfirmPaymentResponse().getTransID();

                saveDetailsUntilPaid(transRef, "BluBill", productName, amount);

                /*printWithDynamic(billPaymentsResponseBluBillConfirmMessage.getData().getPrintLines(), getPrintBarcode());

                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    print(billPaymentsResponseBluBillConfirmMessage.getData().getMerchantPrintLines());
                }*/
                if (previewSlipsEnabled()) {
                    List<PrintJob> printJobs = new ArrayList<>();
                    printJobs.add(new PrintJob(billPaymentsResponseBluBillConfirmMessage.getData().getPrintLines(), true, getPrintBarcode()));
                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        printJobs.add(new PrintJob(billPaymentsResponseBluBillConfirmMessage.getData().getMerchantPrintLines(), false, false));
                    }
                    new BluDroidSlipPreviewBluBillDialog(this, printJobs);

                } else {

                    printWithDynamic(billPaymentsResponseBluBillConfirmMessage.getData().getPrintLines(), getPrintBarcode());

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        print(billPaymentsResponseBluBillConfirmMessage.getData().getMerchantPrintLines());
                    }
                    completeBluBillPayments();
                }


            } else {
                dismissProgress();
                EditText accountNumber = findViewById(R.id.accountNumber);
                if (accountNumber != null) accountNumber.setText("");
                createSystemErrorConfirmation(billPaymentsResponseBluBillConfirmMessage, true);
            }

        } else if (object instanceof BillPaymentsResponsePrintedMessage) {
            BillPaymentsResponsePrintedMessage billPaymentsResponsePrintedMessage = (BillPaymentsResponsePrintedMessage) object;
            // dismissProgress();

            if (billPaymentsResponsePrintedMessage.getEvent().getEventCode().equals("0")) {
                emptyBasket();
                isbillPayementPayed = true;
            } else {
                createSystemErrorConfirmation(billPaymentsResponsePrintedMessage, true);
            }

        } else if (object instanceof BillPaymentsPayAtAuthenticationResponseMessage) {
            Log.d(TAG, "authentication response");
            possibleTitle = "Pay@";

            billPaymentsPayAtAuthenticationResponseMessage = (BillPaymentsPayAtAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(billPaymentsPayAtAuthenticationResponseMessage.getEvent());

            if (billPaymentsPayAtAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

                if (isTraficFinePayment) {
                    verifyPayAtTrafficFineAccount();
                } else {
                    verifyPayAtAccount();
                }

            } else {
                createSystemErrorConfirmation(billPaymentsPayAtAuthenticationResponseMessage, true);
            }

        } else if (object instanceof BillPaymentsResponsePayAtAccountPaymentMessage) {
            dismissProgress();

            billPaymentsResponsePayAtAccountPaymentMessage =
                    (BillPaymentsResponsePayAtAccountPaymentMessage) object;
            if (billPaymentsResponsePayAtAccountPaymentMessage.getEvent().getEventCode().equals("0")) {
                //
                // verification only
                //
                if (billPaymentsResponsePayAtAccountPaymentMessage.getData().getTransactionId().trim().isEmpty() ||
                        billPaymentsResponsePayAtAccountPaymentMessage.getData().getTransactionId().trim().equals("0")) {
                    //validBillIssuer = true;

                    if (isTraficFinePayment) {

                        createTrafficFineConfirmationDialog(this);

                        if (confirmation instanceof BluDroidTrafficFineConfirmationDialog) {

                            BluDroidTrafficFineConfirmationDialog dialog = (BluDroidTrafficFineConfirmationDialog) confirmation;

                            dialog.setIcon(getResources().getDrawable(R.drawable.billpayment_payat));
                            dialog.setNoticeNumber(accountNumber);
                            dialog.setVehicleRegNumber(billPaymentsResponsePayAtAccountPaymentMessage.getData().getClientDeailtAccount().getAdditionalField5());
                            dialog.setOnwerId(billPaymentsResponsePayAtAccountPaymentMessage.getData().getIdNumber());
                            dialog.setlocation(billPaymentsResponsePayAtAccountPaymentMessage.getData().getClientDeailtAccount().getAdditionalField2());
                            dialog.setDate(billPaymentsResponsePayAtAccountPaymentMessage.getData().getClientDeailtAccount().getAdditionalField4());
                            dialog.setAmountDue(billPaymentsResponsePayAtAccountPaymentMessage.getData().getAmountDue());
                            dialog.setConvienceFee(billPaymentsResponsePayAtAccountPaymentMessage.getData().getConvenienceFee());

                            try {
                                Double amountDue = Double.parseDouble(billPaymentsResponsePayAtAccountPaymentMessage.getData().getAmountDue());
                                Double convenienceFee = Double.parseDouble(billPaymentsResponsePayAtAccountPaymentMessage.getData().getConvenienceFee());
                                Double total = amountDue + convenienceFee;
                                bpConvienceFee = convenienceFee;
                                dialog.setTotalPayable(df2.format(total));

                                if (billPaymentsResponsePayAtAccountPaymentMessage.getData().getAcceptPartPayment().toLowerCase().contains("n") ||
                                        billPaymentsResponsePayAtAccountPaymentMessage.getData().getAcceptPartPayment().toLowerCase().contains("false")) {
                                    dialog.setAmount(df2.format(amountDue));
                                }
                            } catch (Exception exception) {
                                Log.v(TAG, "number exception " + exception);
                                logger.error(" number exception " + exception);
                            }

                            dialog.setpartPayment(billPaymentsResponsePayAtAccountPaymentMessage.getData().getAcceptPartPayment());

                        }
                    } else {

                        createBillPaymentsConfirmationDialog(this);

                        if (confirmation instanceof BluDroidBillPaymentsConfirmationDialog) {

                            BluDroidBillPaymentsConfirmationDialog dialog = (BluDroidBillPaymentsConfirmationDialog) confirmation;

                            dialog.setIcon(getResources().getDrawable(R.drawable.billpayment_payat));
                            dialog.setAccountNumber(accountNumber);
                            dialog.setAccountHolder(billPaymentsResponsePayAtAccountPaymentMessage.getData().getFirstName() + " " +
                                    billPaymentsResponsePayAtAccountPaymentMessage.getData().getLastName());

                            dialog.setAmountDue(billPaymentsResponsePayAtAccountPaymentMessage.getData().getAmountDue());
                            dialog.setConvienceFee(billPaymentsResponsePayAtAccountPaymentMessage.getData().getConvenienceFee());


                            try {
                                Double amountDue = Double.parseDouble(billPaymentsResponsePayAtAccountPaymentMessage.getData().getAmountDue());
                                Double convenienceFee = Double.parseDouble(billPaymentsResponsePayAtAccountPaymentMessage.getData().getConvenienceFee());
                                Double total = amountDue + convenienceFee;
                                bpConvienceFee = convenienceFee;
                                dialog.setTotalPayable(df2.format(total));

                                if (billPaymentsResponsePayAtAccountPaymentMessage.getData().getAcceptPartPayment().toLowerCase().contains("n") ||
                                        billPaymentsResponsePayAtAccountPaymentMessage.getData().getAcceptPartPayment().toLowerCase().contains("false")) {
                                    dialog.setAmount(df2.format(amountDue));
                                }

                            } catch (Exception exception) {
                                Log.v(TAG, "number exception " + exception);
                                logger.error(" number exception " + exception);
                            }

                            dialog.setpartPayment(billPaymentsResponsePayAtAccountPaymentMessage.getData().getAcceptPartPayment());
                        }
                    }

                } else {
                    confirmPayAtPayment();
                }
            } else {
                createSystemErrorConfirmation(billPaymentsResponsePayAtAccountPaymentMessage, true);
            }

        } else if (object instanceof BillPaymentsResponsePayAtConfirmMessage) {
            //dismissProgress();
            responsePayAtConfirmMessage = (BillPaymentsResponsePayAtConfirmMessage) object;
            if (responsePayAtConfirmMessage.getEvent().getEventCode().equals("0")) {
                saveDetailsUntilPaid(transRef, possibleTitle, productName, amount);

                /*printWithDynamic(responsePayAtConfirmMessage.getData().getPrintLines(), getPrintBarcode());

                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    print(responsePayAtConfirmMessage.getData().getMerchantPrintLines());
                }*/

                if (previewSlipsEnabled()) {
                    List<PrintJob> printJobs = new ArrayList<>();
                    printJobs.add(new PrintJob(responsePayAtConfirmMessage.getData().getPrintLines(), true, getPrintBarcode()));
                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        printJobs.add(new PrintJob(responsePayAtConfirmMessage.getData().getMerchantPrintLines(), false, false));
                    }
                    new BluDroidSlipPreviewPayAtDialog(this, printJobs);

                } else {

                    printWithDynamic(responsePayAtConfirmMessage.getData().getPrintLines(), getPrintBarcode());

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        print(responsePayAtConfirmMessage.getData().getMerchantPrintLines());
                    }
                    completePayAt();
                }

            } else {
                createSystemErrorConfirmation(responsePayAtConfirmMessage, true);
            }

        } else if (object instanceof MerchantTransferAuthenticationResponseMessage) {
            merchantTransferAuthenticationResponseMessage = (MerchantTransferAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(merchantTransferAuthenticationResponseMessage.getEvent());

            if (merchantTransferAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                getMerchantInfo();
            } else {
                dismissProgress();
                createSystemErrorConfirmation(merchantTransferAuthenticationResponseMessage, true);
            }
        } else if (object instanceof MerchantTransferResponseGetInfoMessage) {
            dismissProgress();
            merchantTransferResponseGetInfoMessage = (MerchantTransferResponseGetInfoMessage) object;
            if (merchantTransferResponseGetInfoMessage.getEvent().getEventCode().equals("0")) {
                createMerchantTransferConfirmationDialog(this);

                if (confirmation instanceof BluDroidMerchantTransfersConfirmationDialog) {
                    BluDroidMerchantTransfersConfirmationDialog dialog = (BluDroidMerchantTransfersConfirmationDialog) confirmation;
                    dialog.setAccountNumber(merchantTransferResponseGetInfoMessage.getData().getTransfereeAccount());
                    dialog.setAccountHolder(merchantTransferResponseGetInfoMessage.getData().getTransfereeName());
                    dialog.setAmount(merchantTransferRequestGetInfoMessage.getEvent().getAmount());
                    dialog.setConvienceFee(merchantTransferResponseGetInfoMessage.getData().getConvenienceFee());
                    dialog.setTotalpayable(merchantTransferResponseGetInfoMessage.getData().getTotalAmount());
                }
            } else {
                createSystemErrorConfirmation(merchantTransferResponseGetInfoMessage, true);
            }

        } else if (object instanceof MerchantTransferResponseConfirmMessage) {
            merchantTransferResponseConfirmMessage = (MerchantTransferResponseConfirmMessage) object;
            if (merchantTransferResponseConfirmMessage.getEvent().getEventCode().equals("0")) {

                saveDetailsUntilPaid(merchantTransferResponseGetInfoMessage.getData().getTransRef(),
                        getString(R.string.merchantTransfer),
                        merchantTransferResponseGetInfoMessage.getData().getTransfereeAccount(),
                        merchantTransferResponseGetInfoMessage.getData().getTotalAmount());

                /* printWithDynamic(merchantTransferResponseConfirmMessage.getData().getPrintLines(), getPrintBarcode());
                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    print(merchantTransferResponseConfirmMessage.getData().getMerchantPrintLines());
                }*/

                if (previewSlipsEnabled()) {
                    List<PrintJob> printJobs = new ArrayList<>();
                    printJobs.add(new PrintJob(merchantTransferResponseConfirmMessage.getData().getPrintLines(), true, getPrintBarcode()));
                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        printJobs.add(new PrintJob(merchantTransferResponseConfirmMessage.getData().getMerchantPrintLines(), false, false));
                    }
                    new BluDroidSlipPreviewMerchantTransfersDialog(this, printJobs);

                } else {

                    printWithDynamic(merchantTransferResponseConfirmMessage.getData().getPrintLines(), getPrintBarcode());

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        print(merchantTransferResponseConfirmMessage.getData().getMerchantPrintLines());
                    }
                    completeMerchantTransfers();
                }

            } else {
                dismissProgress();
                createSystemErrorConfirmation(merchantTransferResponseConfirmMessage, true);
            }

        } else if (object instanceof MerchantTransferResponsePrintedMessage) {
            MerchantTransferResponsePrintedMessage merchantTransferResponsePrintedMessage = (MerchantTransferResponsePrintedMessage) object;
            if (merchantTransferResponsePrintedMessage.getEvent().getEventCode().equals("0")) {
                emptyBasket();
            } else {
                createSystemErrorConfirmation(merchantTransferResponsePrintedMessage, true);
            }

        } else if (object instanceof TicketProAuthenticationResponseMessage) {
            Log.d(TAG, "ticketpro authentication response");
            dismissProgress();
            ticketProAuthenticationResponseMessage = (TicketProAuthenticationResponseMessage) object;

            //Heartbeat flag
            updateHeartbeatFlag(ticketProAuthenticationResponseMessage.getEvent());

            if (ticketProAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

                if (doPuctoStuff) {
                    if (needDepartures) {
                        getPutcoDepartures();
                    } else if (needRoute) {
                        getPutcoRoute();
                    } else if (needDestinations) {
                        getPutcoDestinationas();
                    }
                }

                if (needsToRetryAutoCancel) {

                    try {
                        Log.d(TAG, "sending TicketProRequestPutcoAutoCancelMessage");
                        createProgress("Cancelling Putco Ticket");
                        TicketProRequestFactory factory = new TicketProRequestFactory();
                        TicketProRequestPutcoAutoCancelMessage request = factory.doPutcoTicketAutoCancel(loginResponseMessage.getData().getUserPin(),
                                getPreference(PREF_DEVICE_ID),
                                getPreference(PREF_DEVICE_SER), transRef, ref);
                        startAEONAsyncTask(this, socket, request);

                        Log.d(TAG, "Retrying Putco auto cancel");
                        needsToRetryAutoCancel = false;
                    } catch (Exception ex) {
                        logger.error(ex.getMessage());
                    }

                }
            } else {
                createSystemErrorConfirmation(ticketProAuthenticationResponseMessage, true);
            }

        } else if (object instanceof TicketProResponsePossibleDestinationsMessage) {
            Log.d(TAG, "ticketpro response possible destinations");
            dismissProgress();
            closeAeonSocket(25);
            ticketProResponsePossibleDestinationsMessage = (TicketProResponsePossibleDestinationsMessage) object;
            if (ticketProResponsePossibleDestinationsMessage.getEvent().getEventCode().equals("0")) {

                cachePutcoPossibleDestinationsData(departureId, ticketProResponsePossibleDestinationsMessage);
                List<String> destinations = new ArrayList<>();
                for (int i = 0; i < ticketProResponsePossibleDestinationsMessage.getData().getLocations().size(); i++) {
                    destinations.add(ticketProResponsePossibleDestinationsMessage.getData().getLocations().get(i).getName());
                }

                Fragment f = getCurrentFragment();
                Log.d("MPKPUTCO", "current fragment = " + f);
                if (f instanceof FragmentPutco) {
                    ((FragmentPutcoSearchRoute) ((FragmentPutco) f)._adapter.getItemIndex(0)).updateDestinations(destinations);
                    ((FragmentPutcoSearchRoute) ((FragmentPutco) f)._adapter.getItemIndex(0)).showDestinations();
                }

            } else {
                Log.d(TAG, "putco " + ticketProResponsePossibleDestinationsMessage.getData().getErrorText());
                createSystemErrorConfirmation(ticketProResponsePossibleDestinationsMessage, true);
            }

        } else if (object instanceof TicketProResponseAllLocationsMessage) {
            Log.d(TAG, "ticketpro response all locations");
            dismissProgress();
            closeAeonSocket(23);
            ticketProResponseAllLocationsMessage = (TicketProResponseAllLocationsMessage) object;
            if (ticketProResponseAllLocationsMessage.getEvent().getEventCode().equals("0")) {
                ticketProResponseAllLocationsMessage = (TicketProResponseAllLocationsMessage) object;

                cachePutcoAllLocationsData(ticketProResponseAllLocationsMessage);
                List<String> departures = new ArrayList<>();

                for (int i = 0; i < ticketProResponseAllLocationsMessage.getData().getLocations().size(); i++) {
                    departures.add(ticketProResponseAllLocationsMessage.getData().getLocations().get(i).getName());
                }
                Log.d("MPKPUTCO", "There are " + departures.size() + " departures");
                Fragment f = getCurrentFragment();
                Log.d("MPKPUTCO", "current fragment = " + f);
                if (f instanceof FragmentPutco) {
                    ((FragmentPutcoSearchRoute) ((FragmentPutco) f)._adapter.getItemIndex(0)).updateDepartures(departures);
                }

                Log.d(TAG, "should be displayed now");

            } else {
                Log.e(TAG, "putco " + ticketProResponseAllLocationsMessage.getData().getErrorText());
                createSystemErrorConfirmation(ticketProResponseAllLocationsMessage, true);
            }

        } else if (object instanceof TicketProResponseRouteMessage) {
            Log.d(TAG, "ticketpro response route message");
            dismissProgress();
            ticketProResponseRouteMessage = (TicketProResponseRouteMessage) object;
            Fragment f = getCurrentFragment();
            Log.d("MPKPUTCO", "current fragment = " + f);
            if (f instanceof FragmentPutco) {
                FragmentPutcoSearchRoute fragmentPutcoSearchRoute = (FragmentPutcoSearchRoute) ((FragmentPutco) f)._adapter.getItemIndex(0);

                if (ticketProResponseRouteMessage.getEvent().getEventCode().equals("0")) {
                    fragmentPutcoSearchRoute.showDestinations();

                    if (searchByRoute) {
                        for (int i = 0; i < fragmentPutcoSearchRoute.departures.size(); i++) {
                            Log.d(TAG, "i=" + i + " " + fragmentPutcoSearchRoute.departures.get(i));
                            if (ticketProResponseRouteMessage.getData().getRoutes().get(0).getDeparture().equals(fragmentPutcoSearchRoute.departures.get(i))) {
                                fragmentPutcoSearchRoute.departure.setSelection(i);
                                Log.d(TAG, "searchByRoute-1 " + searchByRoute);
                                searchByRoute = true;
                                break;
                            }
                        }

                        ArrayList<String> destinations = new ArrayList<>();
                        destinations.add(ticketProResponseRouteMessage.getData().getRoutes().get(0).getDestination());
                        Log.d(TAG, "added " + ticketProResponseRouteMessage.getData().getRoutes().get(0).getDestination() + " to arraylist");

                        fragmentPutcoSearchRoute.updateDestinations(destinations);

                        departureName = ticketProResponseRouteMessage.getData().getRoutes().get(0).getDeparture();
                        destinationName = ticketProResponseRouteMessage.getData().getRoutes().get(0).getDestination();

                        Log.d(TAG, "should have correct destination");
                    } else {
                        fragmentPutcoSearchRoute.route.setText(ticketProResponseRouteMessage.getData().getRoutes().get(0).getCode());
                    }

                    try {

                        Collections.sort(ticketProResponseRouteMessage.getData().getRoutes(),
                                new Comparator<TicketProResponseRouteInfoMessage>() {
                                    @Override
                                    public int compare(TicketProResponseRouteInfoMessage route1, TicketProResponseRouteInfoMessage route2) {
                                        double route1Fare = Double.parseDouble(route1.getFare());
                                        double route2Fare = Double.parseDouble(route2.getFare());
                                        return Double.compare(route1Fare, route2Fare);
                                    }
                                }
                        );
                    } catch (Exception exception) {
                        logger.error(exception);
                    }

                    Log.d(TAG, "size is " + ticketProResponseRouteMessage.getData().getRoutes().size());

                    putcoTrips.clear();
                    for (int i = 0; i < ticketProResponseRouteMessage.getData().getRoutes().size(); i++) {
                        Log.d(TAG, "added i=" + i + " " + ticketProResponseRouteMessage.getData().getRoutes().get(i));

                        int defaultIcon = R.drawable.ic_checkbox_off;

                        String travelClass = ticketProResponseRouteMessage.getData().getRoutes().get(i).getTravelClass();
                        String fare = ticketProResponseRouteMessage.getData().getRoutes().get(i).getFare();
                        String routeId = ticketProResponseRouteMessage.getData().getRoutes().get(i).getRouteId();
                        String route = ticketProResponseRouteMessage.getData().getRoutes().get(i).getCode();
                        String nipType = ticketProResponseRouteMessage.getData().getRoutes().get(i).getNipType();

                        PutcoTrip putcoTrip = new PutcoTrip(travelClass, fare, defaultIcon, false, routeId, route, nipType);
                        putcoTrips.add(putcoTrip);
                    }

                } else {
                    fragmentPutcoSearchRoute.route.setText("");
                    searchByRoute = false;
                    createSystemErrorConfirmation(ticketProResponseRouteMessage, true);
                }
            }

        } else if (object instanceof TicketProResponsePutcoCreateCartMessage) {
            Log.d(TAG, "ticketpro response putco create cart");

            dismissProgress();

            ticketProResponsePutcoCreateCartMessage = (TicketProResponsePutcoCreateCartMessage) object;

            if (ticketProResponsePutcoCreateCartMessage.getEvent().getEventCode().equals("0")) {

                // do not remove this log message
                // it is used for testing purposes
                Log.d(TAG, ticketProResponsePutcoCreateCartMessage.toString());

                Log.d(TAG, "TEST : RECEIVED TICKETPRO CART MESSAGE");

                Fragment f = getCurrentFragment();
                Log.d("MPKPUTCO", "current fragment = " + f);
                if (f instanceof FragmentPutco) {
                    ((FragmentPutco) f)._mViewPager.setCurrentItem(2);
                }
            }

        }

        //nolonger used
        else if (object instanceof TicketProResponseBookRouteMessage) {
            Log.d(TAG, "ticketpro putco response BookRoute");
            dismissProgress();
            TicketProResponseBookRouteMessage ticketProResponseBookRouteMessage = (TicketProResponseBookRouteMessage) object;
            if (ticketProResponseBookRouteMessage.getEvent().getEventCode().equals("0")) {

                Fragment f = getCurrentFragment();
                Log.d("MPKPUTCO", "current fragment = " + f);
                if (f instanceof FragmentPutco) {
                    FragmentPutcoPurchaseTicket fragmentPutcoPurchaseTicket = (FragmentPutcoPurchaseTicket) ((FragmentPutco) f)._adapter.getItemIndex(2);
                    buyPutcoTicket(fragmentPutcoPurchaseTicket.cellNumber.getText().toString());
                }

            } else {
                createSystemErrorConfirmation(ticketProResponseBookRouteMessage, true);
            }

        } else if (object instanceof TicketProResponsePutcoCheckOutMessage) {
            Log.d(TAG, "ticketpro putco response CheckOut");
            dismissProgress();
            ticketProResponsePutcoCheckOutMessage = (TicketProResponsePutcoCheckOutMessage) object;
            if (ticketProResponsePutcoCheckOutMessage.getEvent().getEventCode().equals("0")) {
                payPutcoTicket(paymentType);
            } else {
                createSystemErrorConfirmation(ticketProResponsePutcoCheckOutMessage, true);
            }

        } else if (object instanceof TicketProResponsePutcoPaymentMessage) {
            Log.d(TAG, "ticketpro putco response Payment");
            dismissProgress();

            ticketProResponsePutcoPaymentMessage = (TicketProResponsePutcoPaymentMessage) object;

            if (ticketProResponsePutcoPaymentMessage.getEvent().getEventCode().equals("0")) {
                printPutcoTicket();
            } else {
                createSystemErrorConfirmation(ticketProResponsePutcoPaymentMessage, true);
            }

        } else if (object instanceof TicketProResponsePutcoPrintMessage) {
            Log.d(TAG, "ticketpro putco response Print");
            Log.d(TAG, "LB got PutcoPrint " + (new Date()).getTime());
            TicketProResponsePutcoPrintMessage ticketProResponsePutcoPrintMessage = (TicketProResponsePutcoPrintMessage) object;
            if (ticketProResponsePutcoPrintMessage.getEvent().getEventCode().equals("0")) {
                saveDetailsUntilPaid(ticketProResponsePutcoPaymentMessage.getData().getTransRef(), getResources().getString(R.string.putco)
                        , ticketProResponsePutcoPaymentMessage.getData().getReference(), ticketProResponsePutcoCheckOutMessage.getData().getBalance());
                Log.d(TAG, "LB starting HTTP " + (new Date()).getTime());
                HTTPGetAsyncTask getAsyncTask = new HTTPGetAsyncTask(this);
                getAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, this, ticketProResponsePutcoPrintMessage.getData().getTickets());
            } else {
                createSystemErrorConfirmation(ticketProResponsePutcoPrintMessage, true);
            }

        } else if (object instanceof TicketProResponsePutcoDoCompleteTrxMessage) {
            Log.d(TAG, "ticketpro putco do complete trx response");
            Log.d(TAG, "TEST got DoCompleteTrx " + (new Date()).getTime());
            Log.d(TAG, "TEST got DoCompleteTrx");
            dismissProgress();

            ticketProResponsePutcoDoCompleteTrxMessage = (TicketProResponsePutcoDoCompleteTrxMessage) object;
            if (ticketProResponsePutcoDoCompleteTrxMessage.getEvent().getEventCode().equals("0")) {

                Log.d(TAG, "LB starting HTTP " + (new Date()).getTime());

                createProgress("Getting Putco Ticket(s)");
                HTTPGetAsyncTask getAsyncTask = new HTTPGetAsyncTask(this);
                getAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, this, ticketProResponsePutcoDoCompleteTrxMessage.getData().getTickets());
            } else {
                ticket = null;
                createSystemErrorConfirmation(ticketProResponsePutcoDoCompleteTrxMessage, true);
                returnToFavouritesScreen = true;
            }

        } else if (object instanceof TicketProResponsePutcoAutoCancelMessage) {
            dismissProgress();
            Log.d(TAG, "TicketProResponsePutcoAutoCancelMessage");
            TicketProResponsePutcoAutoCancelMessage response = (TicketProResponsePutcoAutoCancelMessage) object;

            if (response.getEvent().getEventCode().equals("0")) {
                File[] notCancelledTickets = getNotCancelledTickets();
                Log.d(TAG, "TicketProResponsePutcoAutoCancelMessage eventcode:0 start delete " + notCancelledTickets.length);
                for (File notCancelledTicket : notCancelledTickets) {
                    Log.v(TAG, "deleting " + notCancelledTicket.getPath());
                    notCancelledTicket.delete();
                }

                Log.d(TAG, "TicketProResponsePutcoAutoCancelMessage display auto cancel dialog");
                createCustomAlertDialog("Putco Auto Cancel", "Your Booking has been Cancelled\n\nPLEASE TURN THE PRINTER OFF AND ON AGAIN.\n\nThis application will now restart.");
                alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Intent mStartActivity = new Intent(BaseActivity.this, ActivityLanding.class);
                        int mPendingIntentId = 123456;
                        PendingIntent mPendingIntent = PendingIntent.getActivity(BaseActivity.this, mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
                        AlarmManager mgr = (AlarmManager) BaseActivity.this.getSystemService(Context.ALARM_SERVICE);
                        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
                        System.exit(0);

                    }
                });

                alert.show();

            } else {
                createSystemErrorConfirmation(response, true);
            }

        } else if (object instanceof USBCommsException) {
            dismissProgress();
            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorSecurePrinterComs, true);

        } else if (object instanceof LoginResponseMessage) {
            if (isBillPaymentScreen && isbillPayementPayed) {
                emptyBasket();
            }
            if (!(object instanceof CarmaAuthenticationResponseMessage)) {
                closeAeonSocket(9);
            }

        } else if (object instanceof byte[]) {
            if (downloadingApk) {
                dismissProgress();
                byte[] bytes = (byte[]) object;

                final String apkName = getResources().getString(
                        isDebug() ? R.string.downloadApkNameDebug
                                : isQa() ? R.string.downloadApkNameQa
                                : isGcrs() ? R.string.downloadApkNameGcrs
                                : R.string.downloadApkName);

                saveApk(apkName, bytes);
                saveApk("" + version.replaceAll("\\.", "-").replaceAll(" ", "-") + "-" + apkName, bytes);
                Log.d(TAG, "version is [" + version + "]");
                Log.d(TAG, "version is [" + version.replaceAll("\\.", "-").replaceAll(" ", "-") + "]");
                downloadingApk = false;

                Toast.makeText(this, "Download Complete, Install at next Login", Toast.LENGTH_LONG).show();

            } else if (checkingVersion) {
                dismissProgress();

                try {
                    SimpleXMLProcessor simpleXMLProcess = new SimpleXMLProcessor();
                    String inputString = new String((byte[]) object).replace("<?xml version=\"1.0\" ?>", "");
                    Log.d(TAG, "Back from Repo " + inputString);

                    //hhtp get failed, display error dialog then go to main screen
                    if (inputString.contains("FAIL") || inputString.equalsIgnoreCase("HTTP GET FAIL")) {

                        if (onlineLogin) {
                            gotoMainScreen();
                        } else {
                            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorUnableToCheckForUpdates, true);
                        }

                    } else {
                        if (getPreference(PREF_RESET_DECLINE_COUNT).equals(PREF_TRUE)) {
                            resetDeclineCounts();
                        }

                        fdroid = (FdroidFdroid) simpleXMLProcess.unmarshal(inputString, FdroidFdroid.class);
                        int applicationCount = fdroid.getApplications().size();
                        newVersionAvailable = Boolean.FALSE;

                        //save index file to device to check if it is already installed
                        final byte[] bytes = (byte[]) object;

                        boolean applicationFoundInIndex = false;

                        for (int i = 0; i < applicationCount; i++) {
                            FdroidApplication application = fdroid.getApplications().get(i);
//                            Log.d(TAG, "i=" + i + " application name " + application.getName() + " app_name " + getResources().getString(R.string.app_name));
                            Log.d(TAG, "i=" + i + " fdroid name:" + application.getName() + "(" + application.getId() + ") app name:" + getApplicationName() + "(" + getApplicationId() + ")");
                            if (application.getName().equals(getApplicationName()) || application.getId().equals(getApplicationId())) {  // this second test is for historical reasons
//                            if (application.getName().equals(getResources().getString(R.string.app_name)) || application.getId().equals("za.co.blts.bltandroidgui3")) {  // this second test is for historical reasons
                                applicationFoundInIndex = true;

                                int versionOnFdroid = Integer.parseInt(application.getPackage().getVersionCode());
                                version = application.getPackage().getVersion();
                                Log.d(TAG, "version on fdroid is " + version);
                                if (versionCode < versionOnFdroid) {
                                    newVersionAvailable = Boolean.TRUE;
                                    StringBuilder msgBody = new StringBuilder(getResources().getString(R.string.newVersionAvailable));
                                    msgBody.append("\n").append(getResources().getString(R.string.doYouWantToUpgradeNow));
                                    if (Build.MODEL.contains("P1")) {
                                        createCustomAlertDialog("Update", "Would you like to go to the Sunmi App Store to download a new version of BluDroid?");
                                        alert.setPositiveOption("Yes", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                firebaseBundle = new Bundle();
                                                firebaseBundle.putInt("decline_upgrade_count", getDeclineCount(PREF_INSTALL_DECLINE));
                                                mFirebaseAnalytics.logEvent("accept_upgrade", firebaseBundle);

                                                launchPlayStore();
                                            }
                                        });

                                        alert.setNegativeOption("No", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                downloadDeclineIncrement();
                                                gotoMainScreen();
                                                firebaseBundle = new Bundle();
                                                firebaseBundle.putInt("decline_upgrade_count", getDeclineCount(PREF_INSTALL_DECLINE));
                                                mFirebaseAnalytics.logEvent("decline_upgrade", firebaseBundle);
                                            }
                                        });

                                    } else {
                                        createUpdateAlertDialog("Update", msgBody.toString());

                                        alert.setPositiveOption(getString(R.string.yes), new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (fdroid != null) {
                                                    downloadingApk = true;
                                                    cancelTimer();
                                                    firebaseBundle = new Bundle();
                                                    firebaseBundle.putInt("decline_upgrade_count", getDeclineCount(PREF_INSTALL_DECLINE));
                                                    mFirebaseAnalytics.logEvent("accept_upgrade", firebaseBundle);

                                                    saveApk("index.xml", bytes);
                                                    getApkFromFdroid(getFdroidApkName());
                                                    //new updates continue to main screen
                                                    if (onlineLogin) {
                                                        gotoMainScreen();
                                                    }
                                                }
                                            }
                                        });

                                        alert.setNegativeOption(getString(R.string.no), new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                downloadDeclineIncrement();
                                                firebaseBundle = new Bundle();
                                                firebaseBundle.putInt("decline_upgrade_count", getDeclineCount(PREF_DOWNLOAD_DECLINE));
                                                mFirebaseAnalytics.logEvent("decline_upgrade", firebaseBundle);
                                                newVersionAvailable = null;
                                                //new updates didn't download continue to main screen
                                                if (onlineLogin) {
                                                    gotoMainScreen();
                                                }
                                                alert.dismiss();
                                            }
                                        });
                                    }
                                    alert.show();

                                } else {
                                    if (!onlineLogin) {
                                        createUpdateAlertDialog("Update", "No updates available");

                                        alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                newVersionAvailable = null;
                                                alert.dismiss();
                                            }
                                        });

                                        alert.show();

                                    } else {
                                        //no updates on online login therefore proceed to main screen
                                        gotoMainScreen();
                                    }
                                }
                            }
                        }
                        if (!applicationFoundInIndex) {
                            gotoMainScreen();
                        }
                        checkingVersion = false;
                    }
                } catch (Exception exception) {
                    Log.d(TAG, "problems unmarshalling from fdroid " + exception);
                    logger.error("problems unmarshalling from fdroid " + exception);
                    gotoMainScreen();
                }

            } else if (gettingManual) {
                dismissProgress();
                byte[] bytes = (byte[]) object;
                saveManual(bytes);

                Intent intent = new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("file://" + appDir.getPath() + "/" +
                        getResources().getString(R.string.training) + "/Training.epub"), "application/epub+zip");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                gettingManual = false;

            } else if (gettingEpubReader) {
                dismissProgress();
                byte[] bytes = (byte[]) object;
                saveEpubReader(bytes);

                Intent intent = new Intent(Intent.ACTION_VIEW)
                        .setDataAndType(Uri.parse("file://" + appDir.getPath() + "/" +
                                        getResources().getString(R.string.training) + "/LithiumEPUBReader.apk"),
                                "application/vnd.android.package-archive");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                gettingEpubReader = false;

            } else if (gettingKMS) {
                dismissProgress();
                byte[] bytes = (byte[]) object;
                saveFile(bytes, "KMS", kmsAppDir.getPath() + "/KMS.apk");

                Intent intent = new Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("file://" + appDir.getPath() + "/" + getResources().getString(R.string.launchKMS) + "/KMS.apk"),
                        "application/vnd.android.package-archive");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                finish();
                startActivity(intent);
                gettingKMS = false;

            } else if (isEventsScreen || isCollectionScreen) {
                if (isEventsScreen) {
                    printTicketProMerchantReceipt(securePrint);
                }

                if (securePrint) {
                    createProgress(R.string.printingTickets);
                    ticket = (byte[]) object;
                    if (checkUSBPrinter()) {
                        securePrint();
                    }

                }

                supplierName = "";
                gettingMvnoVoucher = false;

                if (isTicketProReprint || isCollectionScreen) {
                    gotoMainScreen();

                } else {
                    //the secure print results will handle the empty basket
                    if (!securePrint) {
                        emptyBasket();
                    }
                }

                isCollectionScreen = false;

            } else if (gettingDigitalOnboardingApp) {
                dismissProgress();
                byte[] bytes = (byte[]) object;
                saveFile(bytes, "DigitalOnboardingApp", digitalOnboardingAppDir.getPath() + "/DigitalOnboarding.apk");
                gettingDigitalOnboardingApp = false;
                Toast.makeText(this, "Download Complete, Install at next Login", Toast.LENGTH_LONG).show();

                //putco
            } else {

                ticket = (byte[]) object;

                // special return HTTP GET FAIL
                if (ticket.length == 13) {
                    dismissProgress();
                    String msg = new String(ticket);
                    if (msg.equals("HTTP GET FAIL")) {
                        ArrayList<String> failReport = new ArrayList<>();
                        failReport.add("**** WARNING ****");
                        failReport.add("Product " + getResources().getString(R.string.putco).toUpperCase() + " " +
                                ticketProResponsePutcoDoCompleteTrxMessage.getData().getReference().toUpperCase());
                        failReport.add("did not download properly.");
                        failReport.add("It will not print.");
                        failReport.add("Save this receipt for ");
                        failReport.add("reconcilliation");
                        print(failReport);
                        ticket = null;

                        saveAutoCancelTransaction(ticketProResponsePutcoDoCompleteTrxMessage.getData().getTransRef(), ticketProResponsePutcoDoCompleteTrxMessage.getData().getReference());
                        autoCancelPutcoTicket();
                    }

                } else {
                    if (checkUSBPrinter()) {

                        //only save the transaction when the ticket can be printed
                        saveDetailsUntilPaid(ticketProResponsePutcoDoCompleteTrxMessage.getData().getTransRef(),
                                getResources().getString(R.string.putco),
                                ticketProResponsePutcoDoCompleteTrxMessage.getData().getReference(),
                                ticketProResponsePutcoDoCompleteTrxMessage.getData().getBalance());
                        printPutcoMerchantReceipt();
                        printReceipt();
                        securePrint();
                        supplierName = "";
                        gettingMvnoVoucher = false;

                    } else {
                        dismissProgress();
                        if (logger != null) {
                            logger.warn("we have a ticket but USB printer is now not ready");
                        }

                        ArrayList<String> failReport = new ArrayList<>();
                        failReport.add("**** WARNING ****");
                        failReport.add("Product " + getResources().getString(R.string.putco).toUpperCase() + " " +
                                ticketProResponsePutcoDoCompleteTrxMessage.getData().getReference().toUpperCase());
                        failReport.add("did not print properly.");
                        failReport.add("It will not print.");
                        failReport.add("Save this receipt for ");
                        failReport.add("reconcilliation");
                        print(failReport);
                        ticket = null;

                        //dismiss the check usb printer dialog and create a new one
                        if (alert != null) {
                            alert.dismiss();
                        }

                        saveAutoCancelTransaction(ticketProResponsePutcoDoCompleteTrxMessage.getData().getTransRef(),
                                ticketProResponsePutcoDoCompleteTrxMessage.getData().getReference());
                        autoCancelPutcoTicket();
                    }
                }

            }

        } else if (object instanceof String) {
            String msg = (String) object;
            dismissProgress();

            if (!isEventsScreen) {

                if (msg.contains("USB Print")) {        // String format: "USB Print (OK|FAILED),(PrintResultCode)"

                    final String resultCode = msg.split(",")[1];
                    if (msg.contains("USB Print OK")) {
                        ticket = null;
                        cleanUp();
                        if (!isTesting) {
                            emptyBasket();
                        }

                        if (msg.contains("With Condition")) {
                            printPutcoWarningSlip();
                        }

                    } else {
                        if (isTesting) {
                            ArrayList<String> failReport = new ArrayList<>();
                            failReport.add("**** WARNING ****");
                            failReport.add("Testing Secure USB Print");
                            failReport.add("did not print within " + getPreference(PREF_USB_PRINT_TIMEOUT) + " seconds.");
                            failReport.add("There is a possibility that");
                            failReport.add("it did not print");
                            failReport.add("Please turn the printer off and on again");
                            print(failReport);
                        } else {
                            printPutcoWarningSlip();
                            Log.d(TAG, "Print failed with: " + resultCode);
                            ticket = null;
                            cleanUp();

                            //dismiss the check usb printer dialog and create a new one
                            if (alert != null) {
                                alert.dismiss();
                            }

                            saveAutoCancelTransaction(ticketProResponsePutcoDoCompleteTrxMessage.getData().getTransRef(),
                                    ticketProResponsePutcoDoCompleteTrxMessage.getData().getReference());

                            File[] pending = getPendingToTender();
                            for (File file : pending) {
                                if (file.getPath().contains(ticketProResponsePutcoDoCompleteTrxMessage.getData().getTransRef())) {
                                    Log.v(TAG, "deleting is " + file.getPath());
                                    file.delete();
                                    break;
                                }
                            }

                            File[] pending2 = getNotTendered();
                            for (File file : pending2) {
                                if (file.getPath().contains(ticketProResponsePutcoDoCompleteTrxMessage.getData().getTransRef())) {
                                    Log.v(TAG, "deleting is " + file.getPath());
                                    file.delete();
                                    break;
                                }
                            }

                            autoCancelPutcoTicket();
                        }
                    }

                    if (!isTesting) {
                        // Finally we always report back to putco server on print results obtained @res:putcoPrintResultsUrl
                        String putcoTicketEzplUrl = ticketProResponsePutcoDoCompleteTrxMessage.getData().getTickets();
                        // We want to get the following out of the ezpl url:
                        // ex. https://qapc.ticketpros.co.za/ticketprosBO/cache/tmp/d80d0f7f-6453-6a06-6740-59a4fbe3bd76.ezpl
                        //                                                         ^<----------- trxID ---------------->^
                        final String putcoTrxID = putcoTicketEzplUrl.substring(putcoTicketEzplUrl.lastIndexOf("/") + 1,
                                putcoTicketEzplUrl.lastIndexOf("."));
                        String url = getPreference(PREF_PUTCO_URL);
                        //
                        // only do this fancy putco print results thing IF we have a valid URL
                        //
                        if (!url.trim().isEmpty()) {
                            HashMap<String, String> mapUrlParams;
                            Log.d(TAG, "Print Reporting back with code: " + resultCode);
                            File resultsFile = new File(privateDir.getPath() + "/putcoPrintResults.txt");
                            try {
                                mapUrlParams = getHashMapFromFile(resultsFile);
                            } catch (Exception e) {
                                e.printStackTrace();
                                Log.d(TAG, "Exception: " + e);
                                logger.error("Exception: " + e);
                                mapUrlParams = new HashMap<>();
                            }
                            mapUrlParams.put(putcoTrxID, resultCode);
                            UsbResultHttpPutAsyncTask putcoResultsAsync = new UsbResultHttpPutAsyncTask(this);
                            Log.d(TAG, "UsbResultHttpPutAsyncTask starting HTTP PUT " + (new Date()).getTime());
                            putcoResultsAsync.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, this, url, mapUrlParams);
                        }
                    }
                }

            } else {
                //ticketPRo
                if (!isTicketProReprint) { //no need to tender after a reprint
                    emptyBasket();
                }
            }

        } else if (object instanceof HashMap) {    // UsbResultHttpPutAsyncTask results
            @SuppressWarnings("unchecked")
            HashMap<String, String> usbPrintResults = (HashMap<String, String>) object;
            if (!getPreference(PREF_PUTCO_URL).trim().isEmpty()) {
                saveUsbPrintResultsUntilAcked("putcoPrintResults", usbPrintResults);
            }

        } else if (object instanceof CarmaResponseCompleteBookingMessage) {
            //do not dismissProgress, will be handled in FragmentCarmaConfirmPurchaseTicketNew
        } else if (object instanceof TicketProResponsePrintMessage) {
            //do not dismissProgress, will be handled in FragmentTicketProPayment
        } else if (object instanceof TicketProResponsePrintEZPLMessage) {
            //do not dismissProgress, will be handled in FragmentTicketProPayment

        } else if (object instanceof NfcBusAuthenticationResponseMessage
                || object instanceof NfcBusCancelTicketResponseMessage
                || object instanceof NfcBusCheckoutResponseMessage
                || object instanceof NfcBusConfirmCancelTicketResponseMessage
                || object instanceof NfcBusConfirmCheckoutResponseMessage
                || object instanceof NfcBusFindTicketsResponseMessage
                || object instanceof NfcBusGetCustomerResponseMessage
                || object instanceof NfcBusListCarriersResponseMessage
                || object instanceof NfcBusListStopsResponseMessage
                || object instanceof NfcBusLookupDestinationsResponseMessage
                || object instanceof NfcBusLookupFaresResponseMessage
                || object instanceof NfcBusUpdateCustomerResponseMessage
                || object instanceof NfcBusValidateSvcResponseMessage
        ) {
            //do not dismissProgress here, let the clas that handles the response handle the progress bar

        } else {
            dismissProgress();
            Log.d(TAG, "unknown return type");
        }
    }

    public void launchPlayStore() {
        Intent LaunchIntent = getPackageManager().getLaunchIntentForPackage("woyou.market");
        startActivity(LaunchIntent);
        Log.i("launchPlayStore()", "Application launched");
    }

    private void printPutcoWarningSlip() {
        ArrayList<String> failReport = new ArrayList<>();
        failReport.add("**** WARNING ****");
        failReport.add("Product " + getResources().getString(R.string.putco).toUpperCase() + " " +
                ticketProResponsePutcoDoCompleteTrxMessage.getData().getReference().toUpperCase());
        failReport.add("If the ticket did not print");
        failReport.add("please contact the Call Centre");
        failReport.add("0800 014 942");
        failReport.add("Please turn the printer off and on again.");
        failReport.add("Save this receipt for");
        failReport.add("reconcilliation");
        failReport.add("");
        failReport.add("");
        failReport.add("");
        failReport.add("");
        print(failReport);

    }

    void authenticateForUsers() {

        createProgress(R.string.authenticating);
        UsersRequestFactory factory = new UsersRequestFactory();
        UsersAuthenticationRequestMessage usersAuthenticationRequestMessage =
                factory.create(loginResponseMessage.getData().getUserPin(),
                        getPreference(PREF_DEVICE_ID),
                        getPreference(PREF_DEVICE_SER));
        startAEONAsyncTask(this, socket, usersAuthenticationRequestMessage);
    }

    void getUsers() {
        Log.v(TAG, "getUsers");
        try {
            createProgress("Getting Users");
            UsersRequestFactory factory = new UsersRequestFactory();
            UsersRequestListMessage request = factory.create(usersAuthenticationResponseMessage);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "getUsers exception " + exception);
            logger.error("getUsers exception " + exception);
        }
    }

    void getPermissionTypes() {

        Log.v(TAG, "getpermisions");
        try {
            //get user permisions
            createProgress("Getting Permission Types");
            UsersRequestFactory factory = new UsersRequestFactory();
            UsersRequestListPermissionTypesMessage request = factory.createRequestPermissions(usersAuthenticationResponseMessage);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "getpermisions " + exception);
            logger.error("getpermisions " + exception);
        }
    }

    void updateUser(BluDroidUser user, ArrayList<UsersRequestPermissionMessage> permissions) {
        Log.v(TAG, "update user");
        try {
            createProgress(R.string.updatingUser);
            UsersRequestFactory factory = new UsersRequestFactory();
            UsersRequestUpdateUserMessage request = factory.create(usersAuthenticationResponseMessage,
                    user.getId(),
                    user.getName(),
                    user.getPin(),
                    user.getUserLevel(),
                    permissions);
            startAEONAsyncTask(this, socket, request);
            //reset the incrypted user details when the user is update
            resetTraining(user.getPin());

        } catch (Exception exception) {
            Log.v(TAG, "update user " + exception);
            logger.error("update user " + exception);
        }
    }

    void addUser(BluDroidUser user, ArrayList<UsersRequestPermissionMessage> permissions) {
        Log.v(TAG, "add user");
        try {
            dismissProgress();
            createProgress(R.string.addingUser);
            UsersRequestFactory factory = new UsersRequestFactory();
            UsersRequestAddUserMessage request = factory.create(usersAuthenticationResponseMessage,
                    user.getName(),
                    user.getPin(),
                    user.getUserLevel(),
                    permissions);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "add user " + exception);
            logger.error("add user " + exception);
        }
    }

    void authenticateForEmergencyTopup() {

        try {
            Log.v(TAG, "authenticateforreports");
            createProgress(R.string.authenticating);
            EmergencyLoanRequestFactory factory = new EmergencyLoanRequestFactory();
            EmergencyLoanAuthenticationRequestMessage request =
                    factory.create(loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticateforreports " + exception);
            logger.error("authenticateforreports " + exception);
        }
    }

    void getEmergencyTopUpAccountList() {
        Log.v(TAG, "authenticateforreports");
        try {
            createProgress("Prepare Accounts");
            EmergencyLoanRequestFactory factory = new EmergencyLoanRequestFactory();
            EmergencyLoanRequestListAccountsMessage request =
                    factory.list(emergencyLoanAuthenticationResponseMessage,
                            loginResponseMessage.getData().getUserName());
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticateforreports " + exception);
            logger.error("authenticateforreports " + exception);
        }
    }

    ArrayList<EmergencyLoanResponseAccountMessage> getTopUpAccountList() {
        ArrayList<EmergencyLoanResponseAccountMessage> accounts = new ArrayList<>();
        try {
            accounts.addAll(emergencyLoanResponseListAccountsMessage.getData().getAccounts());
        } catch (Exception exception) {
            Log.v(TAG, "getTopUpAccountList " + exception);
            logger.error("getTopUpAccountList " + exception);
        }
        return accounts;
    }

    void confirmEmegerncyTopup(String accountNumber, String amountRequested, String amountAvailable) {
        try {
            createProgress("Confirming Emergency Top Up");
            EmergencyLoanRequestFactory factory = new EmergencyLoanRequestFactory();
            EmergencyLoanRequestLoanConfirmationMessage request = factory.confirm(
                    emergencyLoanAuthenticationResponseMessage,
                    emergencyLoanResponseLoanApplicationMessage.getData().getReference(),
                    accountNumber,
                    amountRequested,
                    amountAvailable,
                    emergencyLoanResponseLoanApplicationMessage.getData().getStatus().getTransRef(),
                    "1");
            startAEONAsyncTask(this, socket, request);

        } catch (Exception exception) {
            logger.error(exception);
        }
    }


    void authenticateForReports() {

        Log.v(TAG, "authenticateforreports");
        try {
            createProgress(R.string.authenticating);
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsAuthenticationRequestMessage
                    reportsAuthenticationRequestMessage =
                    factory.create(loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                reportsAuthenticationRequestMessage.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, reportsAuthenticationRequestMessage);
        } catch (Exception exception) {
            Log.v(TAG, "authenticateforreports " + exception);
            logger.error("authenticateforreports " + exception);
        }
    }

    void getTransactionList(String days) {
        try {
            createProgress("Getting Accounts");
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestTransListMessage request = factory.createTransList(reportsAuthenticationResponseMessage,
                    days);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "getTransactionList " + exception);
            logger.error("getTransactionList " + exception);
        }
    }

    void getTransactionListDateTime(String startDate, String endDate) {
        try {
            createProgress("Getting Accounts");
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestTransListMessage request = factory.createTransListDateTime(reportsAuthenticationResponseMessage,
                    startDate, endDate);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "getTransactionList " + exception);
            logger.error("getTransactionList " + exception);
        }
    }

    private void authenticateForAccounts() {
        Log.v(TAG, "authenticateForAccount");
        try {
            createProgress("Getting Accounts");
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsAccountInfoAuthenticationRequestMessage request =
                    factory.createAccountInfo(loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticateForAccount " + exception);
            logger.error("authenticateForAccount " + exception);
        }
    }

    //used to hide account balance settings when there is more than 1 account
    void authenticateForAccounts(View view) {
        Log.v(TAG, "authenticateForAccount");
        try {
            //this view will be hidden when there is more than 1 accoun
            this.accountBalanceGrouptoggle = view;
            createProgress("Getting Accounts");
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsAccountInfoAuthenticationRequestMessage request =
                    factory.createAccountInfo(loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticateForAccount " + exception);
            logger.error("authenticateForAccount " + exception);
        }
    }

    private void getAccountBalanceIfNecessary() {
        Log.v(TAG, "authenticateForAccount");
        try {

            String defAccount = getPreference(PREF_DEF_ACCOUNT);
            String displayBalance = getPreference(PREF_DISPLAY_BALANCE1);

            if (!displayBalance.equalsIgnoreCase("OFF") && !defAccount.equalsIgnoreCase("N/A")) {
                authenticateForAccounts();
            } else {
                closeAeonSocket(10);
            }
        } catch (Exception exception) {
            Log.v(TAG, "authenticateForAccount " + exception);
            logger.error("authenticateForAccount " + exception);
        }
    }

    private void requestAccountList() {
        try {
            createProgress("Getting Accounts");
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestAccountListMessage reportsRequestAccountListMessage = factory.createAccountList(reportsAuthenticationResponseMessage);
            startAEONAsyncTask(this, socket, reportsRequestAccountListMessage);
        } catch (Exception exception) {
            Log.v(TAG, "getAccountList " + exception);
            logger.error("getAccountList " + exception);
        }
    }

    Map<String, String> getAccountsList() {
        Map<String, String> accounts = new TreeMap<>();
        if (reportsResponseAccountListMessage != null) {
            Log.v(TAG, "account cnt " + reportsResponseAccountListMessage.getData().getAccounts().size());
            for (int i = 0; i < reportsResponseAccountListMessage.getData().getAccounts().size(); i++) {
                accounts.put(reportsResponseAccountListMessage.getData().getAccounts().get(i).getId(), reportsResponseAccountListMessage.getData().getAccounts().get(i).getText());
                Log.v(TAG, "i=" + i + " " + reportsResponseAccountListMessage.getData().getAccounts().get(i).getText());
            }
        }
        return accounts;
    }

    ArrayList<ReportsResponseAccountValuesMessage> getAccounts() {
        ArrayList<ReportsResponseAccountValuesMessage> accounts = new ArrayList<>();
        try {
            for (int i = 0; i < reportsAccountInfoAuthenticationResponseMessage.getData().getAccountInfo().getAccounts().size(); i++) {

                accounts = reportsAccountInfoAuthenticationResponseMessage.getData().getAccountInfo().getAccounts();
            }
        } catch (Exception exception) {
            Log.v(TAG, "getAccounts " + exception);
            logger.error("getAccounts " + exception);
        }
        return accounts;
    }

    void authenticateForBillPayments() {
        try {
            createProgress(R.string.authenticating);
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsAuthenticationRequestMessage request =
                    factory.create(loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            logger.error(exception);
        }
    }

    private void authenticateforBillPaymentsProductList() {
        try {
            createProgress(getResources().getString(R.string.gettingProvidersAndProducts));
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsRequestProductListMessage request = factory.createProductList(
                    billPaymentsAuthenticationResponseMessage);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    public Map<String, String> getBillPaymentMap(String textDesc, String strProvider) {
        Map<String, String> map = new HashMap<>();
        try {
            //
            // first put all products in the array
            //
            Log.v(TAG, "List Count: " + billPaymentsResponseProductListMessage.getData().getProviders().size());
            for (int i = 0; i < billPaymentsResponseProductListMessage.getData().getProviders().size(); i++) {
                BillPaymentsResponseProviderMessage provider = billPaymentsResponseProductListMessage.getData().getProviders().get(i);
                for (int j = 0; j < provider.getProducts().size(); j++) {
                    BillPaymentsResponseProductMessage product = provider.getProducts().get(j);
                    if (product.getName().equalsIgnoreCase(textDesc) && provider.getName().equalsIgnoreCase(strProvider)) {
                        map.put("providerId", provider.getId());
                        map.put("productId", product.getId());
                        map.put("productName", product.getName());
                        map.put("additionalFields", product.getAdditionalFields());
                        map.put("logoId", product.getLogoId());
                    }
                }
            }
        } catch (Exception exception) {
            Log.v(TAG, "prepareSortedArray " + exception);
            logger.error("prepareSortedArray " + exception);
        }
        return map;
    }

    public void athenticateForSAPOMunicBill(String strAccount, String strAmont, String paymentType, String providerId,
                                            String productId, String additionalFields, ArrayList<String> receipt, String productName, String strControlCode) {
        try {
            createProgress(getResources().getString(R.string.authenticatingSAPO));

            isbillPayementPayed = false;

            this.amount = strAmont;
            this.strAccount = strAccount;
            this.strAmont = strAmont;
            this.paymentType = paymentType;
            this.providerId = providerId;
            this.productId = productId;
            this.additionalFields = additionalFields;
            this.receipt = receipt;
            this.productName = productName;
            this.strControlCode = strControlCode;

            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsSapoAuthenticationRequestMessage request = factory.prepareSapoAccountPayment(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "yesButton exception " + exception);
            logger.error("yesButton exception " + exception);
        }
    }

    public void athenticateForSAPOMunicBill(String strGroupNumber, String strSystemNumber, String strPaymentCode,
                                            String strAmont, String paymentType, String providerId, String productId,
                                            String additionalFields, ArrayList<String> receipt, String productName, String strControlCode) {
        try {
            isbillPayementPayed = false;

            createProgress(getResources().getString(R.string.authenticatingSAPO));

            this.amount = strAmont;
            this.strGroupNumber = strGroupNumber;
            this.strSystemNumber = strSystemNumber;
            this.strPaymentCode = strPaymentCode;
            this.strAmont = strAmont;
            this.paymentType = paymentType;
            this.providerId = providerId;
            this.productId = productId;
            this.additionalFields = additionalFields;
            this.receipt = receipt;
            this.productName = productName;
            this.strControlCode = strControlCode;

            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsSapoAuthenticationRequestMessage request = factory.prepareSapoAccountPayment(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "yesButton exception " + exception);
            logger.error("yesButton exception " + exception);
        }
    }

    public void authenticateForSyntellPayments(String accountNumber) {
        try {
            dismissProgress();
            this.accountNumber = accountNumber;
            isbillPayementPayed = false;
            isTraficFinePayment = false;
            state = 0;
            // this.amount ="100";

            createProgress(getResources().getString(R.string.authenticatingSyntell));
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsSyntellAuthenticationRequestMessage request = factory.prepareSyntellAccountPayment(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    public void authenticateForSyntellFinePayments(String noticeNumber) {
        try {
            this.accountNumber = noticeNumber;
            isTraficFinePayment = true;
            isbillPayementPayed = false;
            state = 0;

            createProgress(getResources().getString(R.string.authenticatingSyntell));
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsSyntellAuthenticationRequestMessage request = factory.prepareSyntellFinePayment(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    public void authenticateForBluBillPayments(String accountNumber) {

        try {
            isbillPayementPayed = false;

            this.accountNumber = accountNumber;

            createProgress(getResources().getString(R.string.authenticatingBluBill));
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsBluBillAuthenticationRequestMessage request = factory.prepareBluBillAccountPayment(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    private void verifyBluBillAccount() {

        try {

            Log.d("BlueBill", productId);
            Log.d("BlueBill", providerId);
            Log.d("BlueBill", accountNumber);

            createProgress(getResources().getString(R.string.verifyingAccount));
            receipt = new ArrayList<>();
            receipt.add("Blu Bill Payment");
            receipt.add(productName);
            possibleTitle = possibleTitle.concat(accountNumber);
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            billPaymentsRequestBluBillGetInfoMessage = factory.getBluBillInfo(
                    billPaymentsBluBillAuthenticationResponseMessage.getSessionId(),
                    providerId,
                    productId,
                    accountNumber);
            startAEONAsyncTask(this, socket, billPaymentsRequestBluBillGetInfoMessage);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    public void payBluBillAccount(String amount, String paymentType) {

        try {
            this.amount = amount;
            this.paymentType = paymentType;
            dismissProgress();
            createProgress(R.string.payingAccount);
            Log.d(TAG, "should submit real payment now");
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsRequestBluBillConfirmMessage billPaymentsRequestBluBillConfirmMessage = factory.getBluBillConfirm(
                    billPaymentsRequestBluBillGetInfoMessage,
                    billPaymentsResponseBluBillGetInfoMessage,
                    amount.replace(".00", ""),
                    paymentType);
            startAEONAsyncTask(this, socket, billPaymentsRequestBluBillConfirmMessage);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    private void setPrintedBluPayment() {
        try {
            dismissProgress();
            createProgress(getResources().getString(R.string.confirmingPrinted));
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsRequestPrintedMessage request = factory.confirmPrinted(billPaymentsResponseBluBillConfirmMessage.getSessionId(),
                    billPaymentsResponseBluBillConfirmMessage.getData().getConfirmPaymentResponse().getTransID(),
                    billPaymentsResponseBluBillConfirmMessage.getData().getConfirmPaymentResponse().getRequestID());
            startAEONAsyncTask(this, socket, request);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    public void paySyntellAccount(String amount, String paymentType) {
        try {

            this.amount = amount;
            this.paymentType = paymentType;
            dismissProgress();
            createProgress(R.string.payingAccount);
            Log.d(TAG, "should submit real payment now");
            state = 1;
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            if (isTraficFinePayment) {
                billPaymentsRequestSyntellAccountPaymentMessage = factory.createSyntellFinePayment(
                        billPaymentsResponseSyntellAccountPaymentMessage.getSessionId(),
                        providerId,
                        productId,
                        accountNumber,
                        amount,
                        paymentType);
            } else {
                billPaymentsRequestSyntellAccountPaymentMessage = factory.createSyntellAccountPayment(
                        billPaymentsResponseSyntellAccountPaymentMessage.getSessionId(),
                        providerId,
                        productId,
                        accountNumber,
                        amount,
                        paymentType);
            }
            startAEONAsyncTask(this, socket, billPaymentsRequestSyntellAccountPaymentMessage);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    public void authenticateForPayAtBillPayments(String accountNumber) {
        try {
            isTraficFinePayment = false;
            isbillPayementPayed = false;
            this.accountNumber = accountNumber;

            createProgress(getResources().getString(R.string.authenticatingPayAt));
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsPayAtAuthenticationRequestMessage request = factory.preparePayAtAccountPayment(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    public void authenticateForPayAtTraficFinePayments(String accountNumber) {
        try {
            isTraficFinePayment = true;
            isbillPayementPayed = false;
            this.accountNumber = accountNumber;

            createProgress(getResources().getString(R.string.authenticatingPayAt));
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsPayAtAuthenticationRequestMessage request = factory.preparePayAtFinePayment(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    private void verifyPayAtAccount() {
        try {
            createProgress(getResources().getString(R.string.verifyingAccount));
            possibleTitle = possibleTitle.concat(accountNumber);
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();

            billPaymentsRequestPayAtAccountPaymentMessage = factory.createPayAtAccountPayment(
                    billPaymentsPayAtAuthenticationResponseMessage.getSessionId(),
                    providerId,
                    productId,
                    accountNumber,
                    "10.0",
                    "0.0",
                    "1");
            startAEONAsyncTask(this, socket, billPaymentsRequestPayAtAccountPaymentMessage);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    private void verifyPayAtTrafficFineAccount() {
        try {
            createProgress(getResources().getString(R.string.verifyingAccount));
            possibleTitle = possibleTitle.concat(accountNumber);
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            billPaymentsRequestPayAtAccountPaymentMessage = factory.createPayAtAccountPayment(
                    billPaymentsPayAtAuthenticationResponseMessage.getSessionId(),
                    providerId,
                    productId,
                    accountNumber,
                    "0.0",
                    "0.0",
                    "1");
            startAEONAsyncTask(this, socket, billPaymentsRequestPayAtAccountPaymentMessage);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }


    public void payPayAtAccount(String amount, String paymentType) {
        dismissProgress();
        createProgress(getResources().getString(R.string.payingAccount));
        try {
            this.amount = amount;
            this.paymentType = paymentType;

            Log.d(TAG, "should submit real payment now");
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            billPaymentsRequestPayAtAccountPaymentMessage = factory.createPayAtAccountPayment(
                    billPaymentsResponsePayAtAccountPaymentMessage.getSessionId(),
                    providerId,
                    productId,
                    accountNumber,
                    amount,
                    "0.0",
                    "0");
            startAEONAsyncTask(this, socket, billPaymentsRequestPayAtAccountPaymentMessage);
        } catch (Exception exception) {
            logger.error(exception);
        }
    }

    private void confirmPayAtPayment() {
        try {
            createProgress(getResources().getString(R.string.confirmingPayment));

            transRef = billPaymentsResponsePayAtAccountPaymentMessage.getData().getTransRef();

            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsRequestPayAtConfirmMessage request = factory.createConfirmation(
                    billPaymentsRequestPayAtAccountPaymentMessage,
                    billPaymentsResponsePayAtAccountPaymentMessage, paymentType);
            Log.d(TAG, "confirmation amountDue " +
                    request.getEvent().getAmountDue());
            startAEONAsyncTask(this, socket, request);
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    public void authenticateForMerchantTransfers(String accountNumber, String amount) {
        try {
            this.accountNumber = accountNumber;
            this.amount = amount;

            createProgress(R.string.authenticating);
            MerchantTransferRequestFactory factory = new MerchantTransferRequestFactory();
            //Merchant Transfers
            MerchantTransferAuthenticationRequestMessage merchantTransferAuthenticationRequestMessage = factory.create(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                merchantTransferAuthenticationRequestMessage.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, merchantTransferAuthenticationRequestMessage);
        } catch (Exception exception) {
            Log.v(TAG, "authenticate exception " + exception);
            logger.error("authenticate exception " + exception);
        }
    }

    private void getMerchantInfo() {
        try {
            createProgress(getResources().getString(R.string.gettingMerchantInformation));
            MerchantTransferRequestFactory factory = new MerchantTransferRequestFactory();
            merchantTransferRequestGetInfoMessage = factory.create(merchantTransferAuthenticationResponseMessage,
                    accountNumber,
                    amount);
            startAEONAsyncTask(this, socket, merchantTransferRequestGetInfoMessage);
        } catch (Exception exception) {
            Log.v(TAG, "getInfo exception " + exception);
            logger.error("getInfo exception " + exception);
        }
    }

    public void transferToMerchant(String paymentType) {
        try {
            this.paymentType = paymentType;
            createProgress(getResources().getString(R.string.confirmingTransfer));
            MerchantTransferRequestFactory factory = new MerchantTransferRequestFactory();
            MerchantTransferRequestConfirmMessage merchantTransferRequestConfirmMessage = factory.create(merchantTransferRequestGetInfoMessage,
                    merchantTransferResponseGetInfoMessage,
                    paymentType);
            startAEONAsyncTask(this, socket, merchantTransferRequestConfirmMessage);
        } catch (Exception exception) {
            Log.v(TAG, "getInfo exception " + exception);
            logger.error("getInfo exception " + exception);
        }
    }

    private void confirmMerchantTranferPrinted() {
        try {
            createProgress(getResources().getString(R.string.confirmingPrinted));
            MerchantTransferRequestFactory factory = new MerchantTransferRequestFactory();
            MerchantTransferRequestPrintedMessage merchantTransferRequestPrintedMessage = factory.create(merchantTransferResponseConfirmMessage);
            startAEONAsyncTask(this, socket, merchantTransferRequestPrintedMessage);
        } catch (Exception exception) {
            Log.v(TAG, "getInfo exception " + exception);
            logger.error("getInfo exception " + exception);
        }
    }

    void authenticateForReprints() {

        try {
            createProgress(R.string.authenticating);

            ReprintRequestFactory factory = new ReprintRequestFactory();
            ReprintAuthenticationRequestMessage request = factory.create(loginResponseMessage, getPreference(PREF_DEVICE_ID), getPreference(PREF_DEVICE_SER));

            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticate exception: " + exception);
            logger.error("authenticate exception: " + exception);
        }
    }

    private void getReprintList() {
        try {
            createProgress(R.string.gettingReprints);

            if (reprintDateFrom == null || reprintDateFrom.isEmpty()) {
                reprintDateFrom = todaysDateInMillies();
            }
            if (reprintDateTo == null || reprintDateTo.isEmpty()) {
                reprintDateTo = todaysDateInMillies();
            }

            ReprintRequestFactory factory = new ReprintRequestFactory();
            ReprintRequestListByDateMessage request = factory.createListByDate(reprintAuthenticationResponseMessage, reprintDateFrom, reprintDateTo);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "reprint list exception: " + exception);
            logger.error(TAG + "reprint list exception: " + exception);
        }
    }

    public void reprint(String id) {
        try {
            createProgress(R.string.printing);

            ReprintRequestFactory factory = new ReprintRequestFactory();
            ReprintRequestReprintMessage request = factory.create(reprintAuthenticationResponseMessage, id);
            //reprintResponseListByDateMessage.getData().getReprints().get(id).getId());

            Log.v(TAG, "reprint REQUEST: " + request);

            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "reprint exception: " + exception);
            logger.error("reprint exception: " + exception);
        }
    }

    void getProfitReportByDays(String accountId, String days) {
        try {
            createProgress(R.string.gettingReport);
            ReportsRequestFactory factory = new ReportsRequestFactory();

            ReportsRequestProfitMessage request = factory.createProfit(
                    reportsAuthenticationResponseMessage, accountId, days);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "getProfitReportByDays exception: " + exception);
            logger.error("getProfitReportByDays exception: " + exception);
        }
    }

    void getProfitReportByShift(String accountId, String shiftId) {
        try {
            createProgress(R.string.gettingReport);
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestShiftProfitMessage request = factory.createShiftProfit(
                    reportsAuthenticationResponseMessage, accountId, shiftId);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "getProfitReportByDays exception: " + exception);
            logger.error("getProfitReportByDays exception: " + exception);
        }
    }

    private void getShifts() {
        try {
            createProgress("Gettings Shifts");
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestShiftListMessage reportsRequestShiftListMessage =
                    factory.createShiftList(reportsAuthenticationResponseMessage);
            startAEONAsyncTask(this, socket, reportsRequestShiftListMessage);
        } catch (Exception exception) {
            Log.v(TAG, "getProfitReportByDays exception: " + exception);
            logger.error("getProfitReportByDays exception: " + exception);
        }
    }

    Map<String, String> getShiftList() {
        Map<String, String> shifts = new TreeMap<>();

        // shifts.put("0",getResources().getString(R.string.currentShift));
        Log.v(TAG, "account cnt " + reportsResponseShiftListMessage.getData().getShifts().size());
        for (int i = 0; i < reportsResponseShiftListMessage.getData().getShifts().size(); i++) {
            shifts.put(reportsResponseShiftListMessage.getData().getShifts().get(i).getId(), reportsResponseShiftListMessage.getData().getShifts().get(i).getText());
            Log.v(TAG, "i=" + i + " " + reportsResponseShiftListMessage.getData().getShifts().get(i).getText());
        }
        return shifts;
    }

    private void getInvoiceList(String accountId) {
        try {
            createProgress(R.string.gettingInvoices);
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestInvoiceListMessage reportsRequestInvoiceListMessage =
                    factory.createInvoiceList(reportsAuthenticationResponseMessage, accountId);
            startAEONAsyncTask(this, socket, reportsRequestInvoiceListMessage);
        } catch (Exception exception) {
            Log.v(TAG, "getInvoice st exception: " + exception);
            logger.error("getInvoice st exception: " + exception);
        }
    }

    void getStatementReport(String accountId, String days) {
        try {
            createProgress(R.string.gettingReport);
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestStatementMessage request = factory.createStatement(reportsAuthenticationResponseMessage,
                    accountId, days);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "get Statement report exception: " + exception);
            logger.error("get Statement report exception: " + exception);
        }
    }

    void printInvoiceReport(String accountId, String invoiceId) {
        try {
            createProgress(R.string.gettingReport);
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestPrintInvoiceMessage request =
                    factory.createPrintInvoice(reportsAuthenticationResponseMessage,
                            accountId, invoiceId);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "printInvoiceList exception: " + exception);
            logger.error("printInvoiceList exception: " + exception);
        }
    }

    void printShiftReport(String shiftId) {
        try {
            createProgress(R.string.gettingReport);
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestPrintShiftMessage request = factory.createPrintShift(reportsAuthenticationResponseMessage, shiftId);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "printShiftReport exception: " + exception);
            logger.error("printShiftReport exception: " + exception);
        }
    }

    void printETUReport(String accountId, String days) {
        try {
            createProgress(R.string.gettingReport);
            EmergencyLoanRequestFactory factory = new EmergencyLoanRequestFactory();
            EmergencyLoanRequestPrintEmergencyTopupMessage request =
                    factory.printReport(reportsAuthenticationResponseMessage.getSessionId(), accountId, days);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "printShiftReport exception: " + exception);
            logger.error("printShiftReport exception: " + exception);
        }
    }

    void printDailyBatchReport(String dateString) {
        try {
            createProgress(R.string.gettingReport);
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestBatchMessage request = factory.createBatch(reportsAuthenticationResponseMessage, dateString);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "printShiftReport exception: " + exception);
            logger.error("printShiftReport exception: " + exception);
        }
    }

    private void endShift() {
        try {
            Log.v(TAG, "endShift");
            createProgress(R.string.endingShift);
            //
            // authenticate with Reports subsystem
            //
            ReportsRequestFactory factory = new ReportsRequestFactory();
            ReportsRequestEndShiftMessage request = factory.createEndShift(reportsAuthenticationResponseMessage);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "problems ending shift " + exception);
            logger.error("problems ending shift " + exception);
        }
    }

    public void error(Object obj) {
        cleanUp();
        logger.error("timeout on AEON");
        createNetworkErrorConfirmation();
    }

    public void cleanUp() {
        Log.d(TAG, " cleanUp() ");
        if (asyncTask != null && asyncTask.getStatus() != AEONAsyncTask.Status.FINISHED) {
            // clean up cached user in session, create a method that cleans up user in SharedPreferences
            // issue raised where user is logged out but can still be auto logged in without authentication
            asyncTask.cancel(true);
        }
        resetTimer();
        dismissProgress();
        dismissConfirmation();

        departureName = "";
        destinationName = "";
    }

    private void about() {
        try {
            createAboutConfirmation();
        } catch (Exception exception) {
            logger.error(exception);
        }
    }

    public void logout() {
        try {
            if (!(this instanceof ActivityLanding || this instanceof ActivitySetup)) {
                logger.info(" logout() ");
                cleanUp();
                closeAeonSocket(26);
                clearNFCActiveConsumer(false);
                gotoLandingScreen();
            }
        } catch (Exception exception) {
            Log.d(TAG, "logout throws " + exception);
            logger.error("logout throws " + exception);
        }
    }

    public void crash() {
        Log.d(TAG, "App about to crash");
        throw new RuntimeException("App was Crashed!");
    }

    //
    // this is called by a timer
    //
    void timeOut() {
        logger.info(" timeOut() ");
        firebaseSessionEnd("time_out");
        logout();
    }

    private Fragment getCurrentFragment() {
        List<Fragment> fragmentList = baseFm.getFragments();
        if (fragmentList.isEmpty()) {
            return null;
        } else {
            return fragmentList.get(fragmentList.size() - 1);
        }
    }

    public void resetTimer() {
        try {
            //logger.info(TAG+" resetTimer() " + timer);
            cancelTimer();
            List<Fragment> fragmentList = baseFm.getFragments();

            //searches through the fragments if there are any open
            if (!fragmentList.isEmpty()) {

                //gets the current fragment
                Fragment f = fragmentList.get(fragmentList.size() - 1);

//                Log.d(TAG, "fragment: " + f.getClass().getSimpleName());
                //if the fragment is part of a RICA menu fragment
                //The time does not get reset, it is only cancelled
                if (!(f instanceof FragmentRicaMenu
                        || f instanceof FragmentRicaLogin
                        || f instanceof FragmentRicaRegister
                        || f instanceof FragmentRicaChangeOwner
                        || f instanceof FragmentRicaQuery
                        || f instanceof FragmentRicaBoxRegister
                        || f instanceof FragmentRicaConsumerInfo)) {

                    if (!getPreference(PREF_SCREEN_TIMEOUT).equalsIgnoreCase("never")) {
                        int timeout = Integer.parseInt(getPreference(PREF_SCREEN_TIMEOUT));
                        timeout *= 1000;
                        timer = BluDroidTimer.getInstance(this, timeout, 60000);
                    } else {
                        BluDroidTimer.cancelTimer();
                    }
                }
            } else {
                if (!getPreference(PREF_SCREEN_TIMEOUT).equalsIgnoreCase("never")) {
                    //The Timer gets reset for all other activities
                    int timeout = Integer.parseInt(getPreference(PREF_SCREEN_TIMEOUT));
                    timeout *= 1000;
                    timer = BluDroidTimer.getInstance(this, timeout, 60000);
                } else {
                    BluDroidTimer.cancelTimer();
                }
            }

        } catch (Exception exception) {
            logger.error("problems with timer " + exception);
            exception.printStackTrace();
        }
    }

    public void cancelTimer() {
        Log.d(TAG, "trying to cancel " + timer);
        timer = BluDroidTimer.cancelTimer();
    }

    public void createProgress(final String message) {
        crashLog("Progress", message);
//        dismissProgress();

        if (progressBar == null) {
            Log.d(TAG, ": createProgress(" + message + ")");
            progressBar = new BluDroidProgressBar(BaseActivity.this);
        } else {
            Log.d(TAG, ": updateProgress(" + message + ")");
        }
        progressBar.setMessage(message);
    }

    public void createProgress(int messageResourceId) {
        createProgress(getResources().getString(messageResourceId));
    }

    public void dismissProgress() {
        if (progressBar != null) {
            Log.d(TAG, ": dismissProgress()");
            progressBar.dismiss();
            progressBar = null;
        }
    }

    private void createAboutConfirmation() {
        try {
            Log.d(TAG, ": createAboutConfirmation()");
            alert = new BluDroidAlertDialog(this);

            alert.setTitle(getApplicationName());
            alert.setMessage(getVersionName() + "\n\n" + getResources().getString(R.string.build) + ": " + BuildConfig.GitHash + "\n\n" + BuildConfig.GitDate);

            alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alert.dismiss();
                }
            });

            alert.show();

            TextView messageView = alert.findViewById(android.R.id.message);
            messageView.setGravity(Gravity.CENTER);

        } catch (Exception exception) {
            Log.d(TAG, "default createAboutConfirmation " + exception);
            logger.error("default createAboutConfirmation " + exception);
        }
    }

    private void createEndShiftConfirmation() {
        try {
            Log.d(TAG, ": createEndShiftConfirmation()");

            alert = new BluDroidAlertDialog(this);

            alert.setTitle(getString(R.string.end_shift));
            alert.setMessage(getString(R.string.end_shift_confirm));

            alert.setPositiveOption(getString(R.string.end_shift), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    endShift();
                    clearTransactionList();
                }
            });

            alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    closeAeonSocket(11);
                    alert.dismiss();
                }
            });

            alert.show();

        } catch (Exception exception) {
            Log.d(TAG, "default createAboutConfirmation " + exception);
            logger.error("default createAboutConfirmation " + exception);
        }
    }

    public void createSystemErrorConfirmation(int messageType, String message, boolean closeSocket) {
        if (closeSocket) closeAeonSocket(12);
        try {
            Log.d(TAG, "createSystemErrorConfirmation no parameters this=" + this);
            supplierName = "";
            dismissProgress();
            dismissConfirmation();
            firebaseErrorLogging("system_error");
            confirmation = new BluDroidSystemErrorConfirmationDialog(this);
            BluDroidSystemErrorConfirmationDialog dialog = (BluDroidSystemErrorConfirmationDialog) confirmation;
            dialog.setErrorType(messageType);
            dialog.setMessage(message);
        } catch (Exception exception) {
            Log.d(TAG, "default createSystemErrorConfirmation " + exception);
        }
    }

    public void createSystemErrorConfirmation(int messageType, int messageId, boolean closeSocket) {
        if (closeSocket) closeAeonSocket(33);
        try {
            String message = getResources().getString(messageId);
            createSystemErrorConfirmation(messageType, message, closeSocket);
        } catch (Exception exception) {
            Log.d(TAG, "resource createSystemErrorConfirmation " + exception);
            logger.error("resource createSystemErrorConfirmation " + exception);
        }
    }

    public void createSystemErrorConfirmation(Object message, boolean closeSocket) {
        Log.d(TAG, "message: " + message);
        Log.d(TAG, "class: " + message.getClass().getSimpleName());
        if (closeSocket) closeAeonSocket(16);
        try {
            if (message instanceof String) {
                createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, (String) message, closeSocket);
            } else {
                createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, aeonErrors.getErrorText(message), closeSocket);
            }
        } catch (Exception exception) {
            logger.error("createSystemErrorConfirmation()" + exception.toString());
        }
    }

    public void createSystemLogoutErrorConfirmation(Object message, boolean closeSocket) {
        Log.d(TAG, "message: " + message);
        Log.d(TAG, "class: " + message.getClass().getSimpleName());
        if (closeSocket) closeAeonSocket(45);
        try {
            if (message instanceof String) {
                createSystemLogoutErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, (String) message, closeSocket);
            } else {
                createSystemLogoutErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, aeonErrors.getErrorText(message), closeSocket);
            }
        } catch (Exception exception) {
            logger.error("createSystemErrorConfirmation()" + exception.toString());
        }
    }

    public void createSystemLogoutErrorConfirmation(int messageType, String message, boolean closeSocket) {
        if (closeSocket) closeAeonSocket(46);
        try {
            Log.d(TAG, "createSystemLogoutErrorConfirmation no parameters this=" + this);
            supplierName = "";
            dismissProgress();
            dismissConfirmation();
            firebaseErrorLogging("system_logout_error");
            confirmation = new BluDroidSystemErrorLogoutConfirmationDialog(this);
            BluDroidSystemErrorLogoutConfirmationDialog dialog = (BluDroidSystemErrorLogoutConfirmationDialog) confirmation;
            dialog.setErrorType(messageType);
            dialog.setMessage(message);
        } catch (Exception exception) {
            Log.d(TAG, "default createSystemLogoutErrorConfirmation " + exception);
        }
    }


    private void createCommunicationErrorConfirmation() {
        closeAeonSocket(13);
        try {
            String message = getResources().getString(R.string.errorUnexpectedCommunication);
            logger.error("createCommunicationErrorConfirmation: " + message);
            dismissProgress();
            dismissConfirmation();
            firebaseErrorLogging("communication_error");
            confirmation = new BluDroidCommunicationErrorConfirmationDialog(this);
            BluDroidCommunicationErrorConfirmationDialog dialog = (BluDroidCommunicationErrorConfirmationDialog) confirmation;
            dialog.setErrorType(AEONErrors.NO_USER_ACTION_REQUIRED);
            dialog.setMessage(message);
        } catch (Exception exception) {
            Log.d(TAG, "default createCommunicationErrorConfirmation " + exception);

        }
    }

    public void createNetworkErrorConfirmation() {
        closeAeonSocket(14);
        try {
            String message = getResources().getString(R.string.errorConnectionError);
            logger.error("createNetworkErrorConfirmation: " + message);
            dismissProgress();
            dismissConfirmation();
            firebaseErrorLogging("network_error");
            confirmation = new BluDroidNetworkErrorConfirmationDialog(this);
            ((BluDroidNetworkErrorConfirmationDialog) confirmation).setErrorType(AEONErrors.NO_USER_ACTION_REQUIRED);
            confirmation.setMessage(message);
        } catch (Exception exception) {
            Log.d(TAG, "default createSystemErrorConfirmation " + exception);

        }
    }

    public void createPrintErrorConfirmation() {
        closeAeonSocket(15);
        try {
            String message = getResources().getString(R.string.errorPrintingError);
            logger.error("createPrintErrorConfirmation: " + message);
            dismissProgress();
            dismissConfirmation();
            firebaseErrorLogging("print_error");
            confirmation = new BluDroidPrintErrorConfirmationDialog(this);
            ((BluDroidPrintErrorConfirmationDialog) confirmation).setErrorType(AEONErrors.NO_USER_ACTION_REQUIRED);
            confirmation.setMessage(message);
        } catch (Exception exception) {
            Log.d(TAG, "default createSystemErrorConfirmation " + exception);

        }
    }

    public BluDroidAlertDialog confirmDeactivateCardDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(message);
        } catch (Exception exception) {
            Log.d(TAG, "createAlert " + exception);
        }
        return alert;
    }

    void createTechPinConfirmation() {
        try {
            confirmation = new BluDroidTechPinConfirmationDialog(this);
        } catch (Exception exception) {
            logger.error("createTechPinConfirmation " + exception);
        }
    }

    public void createVoucherPurchaseConfirmation(BaseFragment baseFragment) {
        try {
            dismissConfirmation();
            confirmation = new BluDroidVoucherPurchaseConfirmationDialog(baseFragment);
        } catch (Exception exception) {
            logger.error("createVoucherPurchaseConfirmation " + exception);
        }
    }

    public void createChatForChangeConfirmation(BaseFragment baseFragment) {
        try {
            confirmation = new BluDroidChatForChangeConfirmationDialog(baseFragment);
        } catch (Exception exception) {
            logger.error("baseFragment createChatForChangeConfirmation " + exception);
        }
    }

    void createChatForChangeConfirmation(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidChatForChangeConfirmationDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("baseActivity createChatForChangeConfirmation " + exception);
        }
    }

    public void createPinlessTopupConfirmation(BaseFragment baseFragment) {
        try {
            confirmation = new BluDroidPinlessTopupConfirmationDialog(baseFragment);
        } catch (Exception exception) {
            logger.error("createPinlessTopupConfirmation " + exception);
        }
    }

    public void createPinlessBundleConfirmation(BaseFragment baseFragment) {
        try {
            confirmation = new BluDroidPinlessBundleConfirmationDialog(baseFragment);
        } catch (Exception exception) {
            logger.error("createPinlessBundleConfirmation " + exception);
        }
    }

    public void createPinlessTopupAnyAmountConfirmationDialog(BaseFragment baseFragment) {
        try {
            confirmation = new BluDroidPinlessTopupAnyAmountConfirmationDialog(baseFragment);
        } catch (Exception exception) {
            logger.error("createPinlessTopupAnyAmountConfirmationDialog " + exception);
        }
    }

    public void createBluDroidCustomDialog(BaseFragment baseFragment) {
        try {
            Dialog dialog = new BluDroidTicketCollectDialog(baseFragment);
            dialog.show();
        } catch (Exception exception) {
            logger.error("createBluDroidCustomDialog " + exception);
        }
    }

    private void createBillPaymentsConfirmationDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidBillPaymentsConfirmationDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createBillPaymentsConfirmationDialog " + exception);
        }
    }

    private void createTrafficFineConfirmationDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidTrafficFineConfirmationDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createTrafficFineConfirmationDialog " + exception);
        }
    }

    private void createMerchantTransferConfirmationDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidMerchantTransfersConfirmationDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createMerchantTransferConfirmationDialog " + exception);
        }
    }

    public void createFreeBasicElectricityDialog(BaseFragment baseFragment) {
        try {
            confirmation = new BluDroidFreeBasicElectricityDialog(baseFragment);
        } catch (Exception exception) {
            logger.error("createFreeBasicElectricityDialog " + exception);
        }
    }

    public void createUniversalElectricityDialog(BaseFragment baseFragment) {
        try {
            confirmation = new BluDroidUniversalElectricityDialog(baseFragment);
        } catch (Exception exception) {
            logger.error("createUniversalElectricityDialog " + exception);
        }
    }

    void createElectricityPurchaseConfirmationDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidElectricityPurchaseConfirmationDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createElectricityPurchaseConfirmationDialog " + exception);
        }
    }

    public void createUpdateEskomMeterKeysDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidUpdateEskomMeterKeysDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createUpdateEskomMeterKeysDialog " + exception);
        }
    }

    public void createUpdateEskomMeterCardsDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidUpdateEskomMeterCardsDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createUpdateEskomMeterCardsDialog " + exception);
        }
    }

    public void createEskomEngineeringKeyCodesDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidEskomEngineeringKeyCodesDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createEskomEngineeringKeyCodesDialog " + exception);
        }
    }

    public void createEskomTrialPurchaseDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidEskomTrialPurchaseDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createEskomTrialPurchaseDialog " + exception);
        }
    }

    public void createEskomTokenByOtherDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidEskomTokenByOtherDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createEskomTokenByOtherDialog " + exception);
        }
    }

    public void createEskomRedeemTokenDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidEskomRedeemTokenDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createEskomRedeemTokenDialog " + exception);
        }
    }

    public void createPassengerConfirmDialog(BaseActivity baseActivity, List<CarmaPassenger> passengerDetails) {
        try {
            confirmation = new BluDroidConfirmPassengerDialog(baseActivity);
            ((BluDroidConfirmPassengerDialog) confirmation).setPassengers(passengerDetails);
        } catch (Exception exception) {
            logger.error("createPassengerConfirmDialog " + exception);
        }
    }

    public void createUpdateUserinfoDialog() {
        try {
            confirmation = new BluDroidUpdateUserInfoDialog(this);
        } catch (Exception exception) {
            logger.error("createUpdateUserinfoDialog " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    private void createBluDroidPreviewProfitReportDialog(ArrayList lines) {
        try {
            new BluDroidPreviewProfitReportDialog(this, lines);
        } catch (Exception exception) {
            logger.error("createBluDroidPreviewProfitReportDialog " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------

    private void createBluDroidPreviewTransactionListDialog(ArrayList<CommonResponseLineMessage> lines) {
        try {
            new BluDroidPreviewTransactionListReportDialog(this, lines);
        } catch (Exception exception) {
            logger.error("createBluDroidPreviewTransactionListDialog " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------

    private void createBluDroidPreviewStatementDialog(ArrayList<CommonResponseLineMessage> lines) {
        try {
            new BluDroidPreviewStatementReportDialog(this, lines);
        } catch (Exception exception) {
            logger.error("createBluDroidPreviewStatementDialog " + exception);
        }
    }

    private void createBluDroidPreviewEmergencyTopUpDialog(ArrayList<CommonResponseLineMessage> lines) {
        try {
            new BluDroidPreviewEmergencyTopUpReportDialog(this, lines);
        } catch (Exception exception) {
            logger.error("createBluDroidPreviewEmergencyTopUpDialog " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------

    void createBluDroidPreviewInvoicingDialog(ArrayList<CommonResponseLineMessage> lines) {
        try {
            new BluDroidPreviewInvoicingReportDialog(this, lines);
        } catch (Exception exception) {
            logger.error("createBluDroidPreviewInvoicingDialog " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------

    private void createBluDroidPreviewBatchDialog(ArrayList<CommonResponseLineMessage> lines) {
        try {
            new BluDroidPreviewBatchReportDialog(this, lines);
        } catch (Exception exception) {
            logger.error("createBluDroidPreviewBatchDialog " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------

    private void createBluDroidPreviewShiftProfitDialog(ArrayList<CommonResponseLineMessage> lines) {
        try {
            new BluDroidPreviewShiftProfitReportDialog(this, lines);
        } catch (Exception exception) {
            logger.error("createBluDroidPreviewShiftProfitDialog " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    void createAddUserinfoDialog() {
        try {
            confirmation = new BluDroidAddUserInfoDialog(this);
        } catch (Exception exception) {
            logger.error("createAddUserinfoDialog " + exception);
        }
    }

    private void createReprintListDialog() {
        try {
            confirmation = new BluDroidReprintListDialog(this);
            String screen = confirmation.getClass().getSimpleName();
            mFirebaseAnalytics.setCurrentScreen(this, screen, null);
        } catch (Exception exception) {
            logger.error("createReprintListDialog " + exception);
        }
    }

    void createEskomReprintListDialog() {
        try {
            confirmation = new BluDroidEskomReprintListDialog(this);
        } catch (Exception exception) {
            logger.error("createEskomReprintListDialog " + exception);
        }
    }

    public void createVenueLayoutDialog() {
        confirmation = new BluDroidVenueLayoutDialog(this);
    }

    BluDroidAlertDialog createLeaveNoSaveConfirmation() {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(R.string.leaveWithoutSaving);
            alert.setMessage(getResources().getString(R.string.saveChanges));
        } catch (Exception exception) {
            logger.error("createLeaveNoSaveConfirmation " + exception);
        }
        return alert;
    }

    void createTestScannerDialog(BaseActivity baseActivity) {
        try {
            confirmation = new BluDroidTestScannerDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createTestScannerDialog " + exception);
        }
    }

    public BluDroidAlertDialog createAlertDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(message);
            alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alert.dismiss();
                }
            });
            alert.show();
        } catch (Exception exception) {
            logger.error("createAlertDialog " + exception);
        }
        return alert;
    }

    BluDroidAlertDialog createElectricityAlertDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(Html.fromHtml(message));
        } catch (Exception exception) {
            logger.error("createElectricityAlertDialog " + exception);
        }
        return alert;
    }

    void createUpdateAlertDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(message);
        } catch (Exception exception) {
            logger.error("createUpdateAlertDialog " + exception);
        }
    }

    public BluDroidAlertDialog createMagCardAlertDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(message);
        } catch (Exception exception) {
            logger.error("createMagCardAlertDialog " + exception);
        }
        return alert;
    }

    BluDroidAlertDialog createCustomAlertDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(message);
        } catch (Exception exception) {
            logger.error("createCustomAlertDialog " + exception);
        }
        return alert;
    }

    public BluDroidAlertDialog createMagEncoderAlertDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(message);
            alert.setPositiveOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alert.dismiss();
                }
            });
            alert.show();
        } catch (Exception exception) {
            logger.error("createMagEncoderAlertDialog " + exception);
        }
        return alert;
    }

    public void createNotifyAlertDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(message);
            alert.show();
        } catch (Exception exception) {
            logger.error("createNotifyAlertDialog " + exception);
        }
    }

    private void createRicaAlertDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(message);
            alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alert.dismiss();
                    gotoMainScreen();
                }
            });
            alert.show();
        } catch (Exception exception) {
            logger.error("createRicaAlertDialog " + exception);
        }
    }

    protected BluDroidAlertDialog exitApplicationDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(message);
        } catch (Exception exception) {
            logger.error("exitApplicationDialog " + exception);
        }
        return alert;
    }

    public void createBillPaymentsAlertDialog(String title, String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setTitle(title);
            alert.setMessage(message);
            alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    closeAeonSocket(17);
                    alert.dismiss();
                }
            });
        } catch (Exception exception) {
            logger.error("createBillPaymentsAlertDialog " + exception);
        }
    }

    public BluDroidAlertDialog createFavouritesDialog(String message) {
        try {
            alert = new BluDroidAlertDialog(this);
            alert.setMessage(message);
        } catch (Exception exception) {
            logger.error("createFavouritesDialog " + exception);
        }
        return alert;
    }

    BluDroidUpdateMeterKeysAlertDialog createUpdateMeterKeysAlertDialog(BaseActivity baseActivity, String type) {
        try {
            return new BluDroidUpdateMeterKeysAlertDialog(baseActivity, type);
        } catch (Exception exception) {
            logger.error("createUpdateMeterKeysAlertDialog " + exception);
        }
        return null;
    }

    BluDroidDateTimePickerDialog createDateTimePickerDialog(BaseActivity baseActivity) {
        try {
            return new BluDroidDateTimePickerDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createDateTimePickerDialog " + exception);
        }
        return null;
    }

    public BluDroidDatePickerDialog createDatePickerDialog(BaseActivity baseActivity) {
        try {
            return new BluDroidDatePickerDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createDateTimePickerDialog " + exception);
        }
        return null;
    }

    public BluDroidTimePickerDialog createTimePickerDialog(BaseActivity baseActivity) {
        try {
            return new BluDroidTimePickerDialog(baseActivity);
        } catch (Exception exception) {
            logger.error("createTimePickerDialog " + exception);
        }
        return null;
    }

    public BluDroidDatePickerDialogSpinner createDatePickerDialogSpinner(BaseActivity baseActivity) {
        try {
            return new BluDroidDatePickerDialogSpinner(baseActivity);
        } catch (Exception exception) {
            logger.error("BluDroidDatePickerDialogSpinner " + exception);
        }
        return null;
    }

    public void dismissConfirmation() {
        try {
            if (confirmation != null) {
                Log.d(TAG, ": dismissConfirmation()");
                confirmation.cancel();
            }
        } catch (Exception exception) {
            logger.error("dismissConfirmation " + exception);
        }
    }

    void dismissAlert() {
        try {
            if (alert != null) {
                Log.d(TAG, ": dismissAlert()");
                alert.dismiss();
                alert.cancel();
            }
        } catch (Exception exception) {
            logger.error("dismissAlert " + exception);
        }
    }

    //
    // see
    //
    // http://stackoverflow.com/questions/7075349/android-clear-activity-stack
    //
    private void gotoScreen(Class cls) {
        try {
            Log.d(TAG, ": gotoScreen(): " + cls.getSimpleName());
            cleanUp();
            Intent intent = new Intent(this, cls);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TOP |
                    Intent.FLAG_ACTIVITY_NO_ANIMATION);
            finish();
            startActivityForResult(intent, 0);
            overridePendingTransition(0, 0);
        } catch (Exception exception) {
            if (logger != null)
                logger.error("gotoScreen " + cls.getName() + " : " + exception);
        }
    }

    public void gotoNfcBusScreen() {
        gotoScreen(ActivityNfcBus.class);
    }

    public void gotoMainScreen() {
        try {
            Log.d(TAG, ": gotoMainScreen(): " + ActivityMain.class.getSimpleName());
            cleanUp();
            Intent intent = new Intent(this, ActivityMain.class);
            intent.putExtra("loadFavourites", true);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TOP |
                    Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
            overridePendingTransition(0, 0);
            finish();
        } catch (Exception exception) {
            logger.error("gotoMainScreen " + ActivityMain.class.getName() + " : " + exception);
        }
    }

    public void gotoMenuFragment() {
        gotoFragment(new FragmentMenu(), FragmentMenu.class.getSimpleName());
    }

    public void gotoFragment(Fragment fragment, String FragmentName) {
        if (fragment != null) {
            Log.d(TAG, "gotoFragment(): " + FragmentName);
            baseFm.beginTransaction().replace(R.id.content_frame, fragment, FragmentName).commit();
        } else {
            logger.error("gotoFragment " + FragmentName);
        }
    }

    public void gotoLandingScreen() {
        gotoScreen(ActivityLanding.class);
    }

    void gotoSetupScreen() {
        gotoScreen(ActivitySetup.class);
    }

    public void gotoMerchantSupportConfirmScreen(String issue) {
        try {
            Log.d(TAG, ": gotoMerchantSupportConfirmScreen(): " + BluMerchantSupportConfirm.class.getSimpleName());
            cleanUp();
            Intent intent = new Intent(this, BluMerchantSupportConfirm.class);
            intent.putExtra("checkId", issue);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TOP |
                    Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
            overridePendingTransition(0, 0);
            finish();
        } catch (Exception exception) {
            logger.error("gotoMerchantSupportConfirmScreen " + BluMerchantSupportConfirm.class.getName() + " " + exception);
        }
    }

    public void gotoMerchantSupportMessageScreen(String response) {
        try {
            Log.d(TAG, ": gotoMerchantSupportMessageScreen(): " + BluMerchantSupportResponse.class.getSimpleName());
            cleanUp();
            Intent intent = new Intent(this, BluMerchantSupportResponse.class);
            intent.putExtra("msg", response);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TOP |
                    Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
            overridePendingTransition(0, 0);
            finish();
        } catch (Exception exception) {
            logger.error("gotoMerchantSupportMessageScreen " + BluMerchantSupportResponse.class.getName() + " " + exception);
        }
    }

    void gotoMerchantSupportScreen() {
        gotoScreen(BluMerchantSupport.class);
    }

    void gotoTestNfcOperationScreen() {
        gotoScreen(ActivityTestNfcOperation.class);
    }

    void gotoTechnicianLoginScreen() {
        gotoScreen(ActivityTechnicianLogin.class);
    }

    void gotoTestPeripheralsScreen() {
        gotoScreen(ActivityTestPeripherals.class);
    }

    void gotoUserSettingsScreen() {
        gotoScreen(ActivityUserSettings.class);
    }

    void gotoCalculatorScreen() {
        gotoScreen(ActivityCalculateChange.class);
    }

    void gotoEmergencyTopUpScreen() {
        gotoScreen(ActivityEmergencyTopUp.class);
    }

    void gotoTechnicianSettingsScreen() {
        gotoScreen(ActivityTechnicianConfig.class);
    }

    void gotoUsersScreen() {
        gotoScreen(ActivityUsers.class);
    }

    void gotoReportsScreen() {
        gotoScreen(ActivityReports.class);
    }

    void gotoTestMagEncoderScreen() {
        gotoScreen(ActivityTestMagEncoder.class);
    }

    void gotoTestNFCReaderScreen() {
        gotoScreen(ActivityTestNFCReader.class);
    }

    void gotoTestExternalNFCReaderScreen() {
        gotoScreen(ActivityTestExternalNfcReader.class);
    }

    void gotoNFCRegistrationScreen() {
        gotoFragment(new FragmentNFCCustomerRegistration(), "FragmentNFCCustomerRegistration");
    }

    void gotoNFCGetConsumerProfile(String fromFragment) {
        Bundle bundle = new Bundle();
        bundle.putString("fromFragment", fromFragment);
        FragmentNFCGetConsumerProfile fragmentNFCGetConsumerProfile = new FragmentNFCGetConsumerProfile();
        fragmentNFCGetConsumerProfile.setArguments(bundle);
        gotoFragment(fragmentNFCGetConsumerProfile, "FragmentNFCGetConsumerProfile");
    }

    public void gotoNFCEditProfileScreen(Bundle fromFragment) {
        FragmentNFCEditCustomerProfile fragmentNFCEditCustomerProfile = new FragmentNFCEditCustomerProfile();
        fragmentNFCEditCustomerProfile.setArguments(fromFragment);
        gotoFragment(fragmentNFCEditCustomerProfile, "FragmentNFCEditCustomerProfile");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.d(TAG, ": onOptionsItemSelected(): " + item.getItemId());
        switch (item.getItemId()) {
            case R.id.about:
                about();
                return true;

            case R.id.logout:
                logout();
                return true;

            default:
                return false;
        }
    }

    public String center(String st) {
        return (new BluDroidUtils()).center(printWidth, st);
    }

    void compareUpdate(String preferenceName, int fieldId) {
        View view = findViewById(fieldId);
        if (view instanceof EditText) {
            EditText tmp = (EditText) view;
            String preferenceValue = tmp.getText().toString().trim();
            Log.v(TAG, preferenceName + " should set to " + tmp.getText().toString());
            updatePreference(preferenceName, preferenceValue);
            Log.v(TAG, preferenceName + " updated to " + getPreference(preferenceName));
        } else if (view instanceof SwitchCompat) {
            SwitchCompat tmp = (SwitchCompat) view;
            Log.v(TAG, preferenceName + " should set to " + tmp.isChecked());
            if (tmp.isChecked()) {
                updatePreference(preferenceName, PREF_TRUE);
            } else {
                updatePreference(preferenceName, PREF_FALSE);
            }
            Log.v(TAG, preferenceName + " updated to " + getPreference(preferenceName));
        } else if (view instanceof RadioGroup) {
            RadioGroup tmp = (RadioGroup) view;
            for (int i = 0; i < tmp.getChildCount(); i++) {
                View v = tmp.getChildAt(i);
                if (v instanceof RadioButton) {
                    if (((RadioButton) v).isChecked()) {
                        Log.v(TAG, preferenceName + " should set to " + ((RadioButton) v).isChecked());
                        updatePreference(preferenceName, ((RadioButton) v).getText().toString().trim());
                    }
                }
            }

        } else if (view instanceof Spinner) {
            Spinner tmp = (Spinner) view;
            if (tmp.getSelectedItem() != null) {
                String preferenceValue = tmp.getSelectedItem().toString();
                Log.v(TAG, preferenceName + " should set to " + tmp.getSelectedItem().toString());
                updatePreference(preferenceName, preferenceValue);
                Log.v(TAG, preferenceName + " updated to " + getPreference(preferenceName));
            }
        }
    }

    void setUpImageView(int id, Drawable image) {
        ImageView imageView = findViewById(id);
        imageView.setImageDrawable(image);
    }

    void setupEditText(int id, String value) {
        EditText tmp = findViewById(id);
        tmp.setText(getPreference(value));
    }

    void setupSwitch(int id, String value) {
        SwitchCompat tmp = findViewById(id);
        tmp.setChecked(getPreference(value).equals(PREF_TRUE));
    }

    void setupRadioGroup(int id, String value) {
        RadioGroup tmp = findViewById(id);
        for (int i = 0; i < tmp.getChildCount(); i++) {
            View v = tmp.getChildAt(i);
            if (v instanceof RadioButton) {
                if (((RadioButton) v).getText().toString().equals(getPreference(value))) {
                    ((RadioButton) v).setChecked(true);
                }
            }
        }
    }

    void setupSpinner(int id, String value, ArrayList<String> list) {
        BluDroidSpinner tmp = findViewById(id);
        tmp.setSelection(list.indexOf(getPreference(value)));
    }

    public boolean getPrintBarcode() {
        return getPreference(PREF_PRINT_BARCODE_RECEIPT).equals(PREF_TRUE);
    }

    public void createNotification(String message) {
        if (!message.toLowerCase().contains("pin")) {
            Log.d(TAG, ": createNotification() with message: " + message);
        }
        BluDroidNotification notification = new BluDroidNotification(this);
        notification.createNotification(message);
    }

    boolean hasChanges(int viewId, String prefName) {
        boolean hasChanges = false;

        View v = findViewById(viewId);

        if (v instanceof BluDroidEditText) {
            String text = ((BluDroidEditText) v).getText().toString();
            String pref = getPreference(prefName);
            hasChanges = !text.equals(pref);

        } else if (v instanceof BluDroidSwitch) {
            boolean bool = ((BluDroidSwitch) v).isChecked();
            boolean pref = getPreference(prefName).equals(PREF_TRUE);
            hasChanges = !bool == pref;

        } else if (v instanceof RadioGroup) {
            RadioGroup tmp = findViewById(viewId);
            for (int i = 0; i < tmp.getChildCount(); i++) {
                View view = tmp.getChildAt(i);
                if (view instanceof BluDroidRadioButton) {
                    boolean bool = ((BluDroidRadioButton) view).isChecked();

                    if (bool) {
                        String pref = getPreference(prefName);
                        String text = ((BluDroidRadioButton) view).getText().toString();

                        hasChanges = !text.equals(pref);
                    }
                }
            }


        } else if (v instanceof Spinner) {
            if (((Spinner) v).getSelectedItem() != null) {

                String text = ((Spinner) v).getSelectedItem().toString();
                String pref = getPreference(prefName);

                hasChanges = !text.equals(pref);
            }

        }

        return hasChanges;
    }

    @Override
    public void finish() {
        super.finish();
        cancelTimer();
    }

    @SuppressWarnings("unchecked")
    public void print(ArrayList lines) {
        try {
            if (lines.get(0) instanceof CommonResponseLineMessage) {
                if (!getPrintBarcode()) {
                    lines = removeBarcodesFromList(lines);
                }

                if (Boolean.parseBoolean(getPreference(PREF_PRINT_APP_VERSION))){
                    Log.d("PrintAppVersion", "App version: " + getVersionName());
                    lines.add(0, printLine("H", getVersionName()));
                    if (isDebug() || isQa()) {
                        lines.add(0, printLine("H", BuildConfig.GitHash));
                        Log.d("PrintAppVersion", "Git hash: " + BuildConfig.GitHash);
                    }
                }else
                    Log.d("PrintAppVersion", "App version was not requested.");

                smartPrinter.print((ArrayList<CommonResponseLineMessage>) lines, true);
            } else {
                if (Boolean.parseBoolean(getPreference(PREF_PRINT_APP_VERSION))){
                    Log.d("PrintAppVersion", "App version: " + getVersionName());
                    lines.add(0, printLine("H", getVersionName()));
                    if (isDebug() || isQa()) {
                        lines.add(0, printLine("H", BuildConfig.GitHash));
                        Log.d("PrintAppVersion", "Git hash: " + BuildConfig.GitHash);
                    }
                }else
                    Log.d("PrintAppVersion", "App version was not requested.");

                smartPrinter.print((ArrayList<String>) lines);
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems printing " + exception);
            logger.error("problems printing " + exception);
        }
    }

    public void printWithDynamic(ArrayList<CommonResponseLineMessage> lines, boolean printBarcodes) {
        JSONArray dynamic = null;
        DynamicPrintUtil util = new DynamicPrintUtil(this);
        try {
            JSONObject printjob = util.getDynamicPrint();
            if (printjob != null) {
                dynamic = printjob.getJSONArray("print");
                if (dynamic != null) {
                    lines = util.removeLastEmptyLines(lines);
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems printing " + exception);
            logger.error("problems printing " + exception);
        }

        if (!printBarcodes) {
            lines = removeBarcodesFromList(lines);
        }

        if (Boolean.parseBoolean(getPreference(PREF_PRINT_APP_VERSION))){
            Log.d("PrintAppVersion", "App version: " + getVersionName());
            lines.add(0, printLine("H", getVersionName()));
            if (isDebug() || isQa()) {
                lines.add(0, printLine("H", BuildConfig.GitHash));
                Log.d("PrintAppVersion", "Git hash: " + BuildConfig.GitHash);
            }
        }else
            Log.d("PrintAppVersion", "App version was not requested.");

        smartPrinter.print(lines, dynamic == null);
        if (dynamic != null) {
            smartPrinter.print(dynamic);
            util.updateDynamicInfo();
        }

    }

    public ArrayList<CommonResponseLineMessage> removeBarcodesFromList(ArrayList<CommonResponseLineMessage> lines) {
        ArrayList<CommonResponseLineMessage> results = new ArrayList<CommonResponseLineMessage>();
        if (lines.size() > 0) {
            for (CommonResponseLineMessage line : lines) {
                if (!line.getF().equals("P") &&
                        !line.getF().equals("Q") &&
                        !line.getF().equals("U") &&
                        !line.getF().equals("X")) {
                    results.add(line);
                }
            }
        }

        return results;
    }

    public void printWithDynamic(Bitmap logo, ArrayList<CommonResponseLineMessage> lines, Bitmap barcode) {
        JSONArray dynamic = null;
        String id = null;
        DynamicPrintUtil util = new DynamicPrintUtil(this);
        try {
            JSONObject printjob = util.getDynamicPrint();
            if (printjob != null) {
                dynamic = printjob.getJSONArray("print");
                if (dynamic != null) {
                    lines = util.removeLastEmptyLines(lines);
                }
            }

            if (Boolean.parseBoolean(getPreference(PREF_PRINT_APP_VERSION))){
                Log.d("PrintAppVersion", "App version: " + getVersionName());
                lines.add(0, printLine("H", getVersionName()));
                if (isDebug() || isQa()) {
                    lines.add(0, printLine("H", BuildConfig.GitHash));
                    Log.d("PrintAppVersion", "Git hash: " + BuildConfig.GitHash);
                }
            }else
                Log.d("PrintAppVersion", "App version was not requested.");

        } catch (Exception exception) {
            Log.d(TAG, "problems printing " + exception);
            logger.error("problems printing " + exception);
        }
        smartPrinter.print(logo, lines, barcode, dynamic == null);
        if (dynamic != null) {
            smartPrinter.print(dynamic);
            util.updateDynamicInfo();
        }

    }


    private String splitToken(String tokenNumber) {

        List<String> strings = new ArrayList<>();
        int index = 0;
        while (index < tokenNumber.length()) {
            strings.add(tokenNumber.substring(index, Math.min(index + 4, tokenNumber.length())));
            index += 4;
        }
        String part1 = strings.get(0);
        String part2 = strings.get(1);
        String part3 = strings.get(2);
        String part4 = strings.get(3);
        String part5 = "";

        if (strings.size() == 5) {
            part5 = strings.get(4);
        }

        return part1 + " " + part2 + " " + part3 + " " + part4 + " " + part5;
    }

    void printRedeemTokenSlip(String tokenNumber) {
        try {
            ArrayList<CommonResponseLineMessage> testPrint = new ArrayList<>();

            CommonResponseLineMessage lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("L");
            lineMessage.setText("0");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("H");
            lineMessage.setText("Blu Approved - the power of");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("H");
            lineMessage.setText("prepaid");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("N");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("E");
            lineMessage.setText(format("Date: ", todaysDateAndTime()));
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("N");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("H");
            lineMessage.setText("Encoded Token");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("N");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("E");
            lineMessage.setText(splitToken(tokenNumber));
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("N");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("H");
            lineMessage.setText("- Print Done -");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("Z");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            printWithDynamic(testPrint, getPrintBarcode());
            Log.d(TAG, "called print");
        } catch (Exception exception) {
            Log.d(TAG, "problems printing");
            logger.error("problems printing" + exception);
            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorPrinter, true);
        }
    }

    public void printTickets() {
        createProgress("Printing Tickets");
        ticketCacheHandler.cacheCancelTicket(carmaResponseReserveSeatsMessage, bluDroidRoutesAndTimes.getCarrier());
        for (int i = 0; i < carmaResponseReserveSeatsMessage.getData().getTickets().size(); i++) {
            printTicket(i);
            CarmaResponseTicketMessageSerializable ticketMessageSerializable = new CarmaResponseTicketMessageSerializable(this, carmaResponseReserveSeatsMessage.getData().getTickets().get(i));
            ticketMessageSerializable.setTicketTimeStamp(busTicketDateTime);
            cacheTicket(ticketMessageSerializable);
        }
        printBusTicketsMerchantReceipt();

        supplierName = "";
        gettingMvnoVoucher = false;

        //do the tender
        emptyBasket();
        gettingCarmaTicket = false;
    }

    private void printTicket(int index) {
        Log.d(TAG, "caching bus ticket" + carmaResponseReserveSeatsMessage.getData().getTickets().get(index).toString());
        try {
            busTicketDateTime = todaysDateAndTime();
            ArrayList<CommonResponseLineMessage> ticket = new ArrayList<>();
            ticket.add(printLine("N", ""));
            ticket.add(printLine("H", "Bus Ticket"));
            // Header for Intercape
            if (!carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getTicketHeader().isEmpty()) {
                ticket.add(printLine("O", ""));
                String header = carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getTicketHeader().replace("used", " used");
                ticket.add(printLine("O", header));
            }
            ticket.add(printLine("N", ""));

            ticket.add(printLine("O", format("Carrier:", carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getCarrierDescription())));

            ticket.add(printLine("O", format("Service Number:", carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getServiceNumber())));

            ticket.add(printLine("O", format("Passenger Class:", carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getTravelClass())));
            ticket.add(printLine("O", format("Ticket Amount:", "R" + (new BluDroidUtils().formatMoney(carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getAmount())))));
            ticket.add(printLine("O", format("Issue Date:", busTicketDateTime)));
            ticket.add(printLine("N", ""));
            ticket.add(printLine("O", format("Ticket Number:", carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getTicketNumber())));

            String seatNumber = carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getRowSeat();
            if (seatNumber != null && !seatNumber.isEmpty()) {
                ticket.add(printLine("O", format("Seat Number:", seatNumber)));
            }

            ticket.add(printLine("O", format("Transaction ID:", carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getReference())));
            ticket.add(printLine("O", format("Boarding At:", "")));
            ticket.add(printLine("O", carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getBoardLocation()));
            ticket.add(printLine("O", format("Destination:", "")));
            ticket.add(printLine("O", carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getDestLocation()));
            ticket.add(printLine("O", format("Departure Time:", carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getBoardTime().trim())));
            ticket.add(printLine("O", format("Arrival Time:", carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getArrivalTime().trim())));

            StringBuilder name = new StringBuilder();
            if (!carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getTitle().equalsIgnoreCase("")
                    || !(carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getTitle().length() == 0)) {
                name.append(carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getTitle()).append(" ");
            }
            if (!carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getInitials().equalsIgnoreCase("")
                    || !(carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getInitials().length() == 0)) {
                name.append(carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getInitials()).append(" ");
            }
            if (!carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getLastName().equalsIgnoreCase("")
                    || !(carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getLastName().length() == 0)) {
                name.append(carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getLastName());
            }
            ticket.add(printLine("O", format("Name:", name.toString())));

            switch (carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getPassengers().get(0).getPassengerType()) {
                case "A":
                    ticket.add(printLine("O", format("PassengerType:", "ADULT")));
                    break;
                case "C":
                    ticket.add(printLine("O", format("PassengerType:", "CHILD")));
                    break;
                case "I":
                    ticket.add(printLine("O", format("PassengerType:", "INFANT")));
                    break;
            }
            ticket.add(printLine("N", ""));
            ticket.add(printLine("H", "KEEP YOUR TICKET SAFE"));
            // intercape footer
            if (!carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getTicketFooter().isEmpty()) {
                ticket.add(printLine("O", ""));
                String footer = carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getTicketFooter().replace("30", " 30");
                ticket.add(printLine("O", footer));
                ticket.add(printLine("O", ""));
            }
            ticket.add(printLine("H", "For enquiries and cancellations"));
            ticket.add(printLine("H", "please contact"));

            //contact
            for (CarmaResponseItemMessage carrier : carmaResponseCarrierListMessage.getData().getItems()) {
                if (carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getCarrier().equalsIgnoreCase(carrier.getCode()) || carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getCarrier().equalsIgnoreCase(carrier.getName())) {
                    ticket.add(printLine("H", carrier.getCallCentre()));
                }
            }

            ticket.add(printLine("H", "For Terms and Conditions, visit"));

            //website
            for (CarmaResponseItemMessage carrier : carmaResponseCarrierListMessage.getData().getItems()) {
                if (carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getCarrier().equalsIgnoreCase(carrier.getCode()) || carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getCarrier().equalsIgnoreCase(carrier.getName())) {
                    ticket.add(printLine("H", carrier.getWebsite()));
                    break;
                }
            }

            //barcode and logo
            String barcodeType = "";
            String barcodeNumber = "";
            for (CarmaResponseItemMessage carrier : carmaResponseCarrierListMessage.getData().getItems()) {
                if (carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getCarrier().equalsIgnoreCase(carrier.getCode()) || carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getCarrier().equalsIgnoreCase(carrier.getName())) {
                    supplierName = carrier.getCode();
                    barcodeType = carrier.getBarcodeType();
                    barcodeNumber = carmaResponseReserveSeatsMessage.getData().getTickets().get(index).getBarcode();
                    break;
                }
            }

            switch (barcodeType.toLowerCase()) {
                case "128b":
                case "128b-special":
                    ticket.add(printLine("X", processBarcode128B(barcodeNumber)));
                    break;

                case "code39":
                    ticket.add(printLine("Q", barcodeNumber));
                    break;

                case "ean13":
                    ticket.add(printLine("P", barcodeNumber));
                    break;

                case "itf":
                    ticket.add(printLine("U", barcodeNumber));
                    break;

                case "128a":
                case "128c":
                default:
                    //defaults to code 128
                    ticket.add(printLine("X", barcodeNumber));
                    break;
            }

            ticket.add(printLine("N", ""));
            ticket.add(printLine("H", "-Print Done-"));

            printWithDynamic(ticket, true);

        } catch (Exception exception) {
            Log.d(TAG, "problem printing ticket " + exception);
            logger.error("problem printing ticket " + exception);
        }
    }

    // reprint ticket
    public void reprintTicket(CarmaResponseTicketMessageSerializable carmaResponseTicketMessage) {
        try {
            gettingCarmaTicket = true;
            ArrayList<CommonResponseLineMessage> ticket = new ArrayList<>();
            ticket.add(printLine("N", ""));
            ticket.add(printLine("H", "Bus Ticket"));
            // Intercape header
            if (!carmaResponseTicketMessage.getTicketHeader().isEmpty()) {
                ticket.add(printLine("O", ""));
                String header = carmaResponseTicketMessage.getTicketHeader().replace("used", " used");
                ticket.add(printLine("O", header));
            }

            ticket.add(printLine("N", ""));
            ticket.add(printLine("H", "REPRINT"));
            ticket.add(printLine("N", ""));

            ticket.add(printLine("O", format("Carrier:", carmaResponseTicketMessage.getCarrierDescription())));

            ticket.add(printLine("O", format("Service Number:", carmaResponseTicketMessage.getServicenumber())));

            ticket.add(printLine("O", format("Passenger Class:", carmaResponseTicketMessage.getTravelClass())));
            ticket.add(printLine("O", format("Ticket Amount:", "R" + new BluDroidUtils().formatMoney(carmaResponseTicketMessage.getAmount()))));
            ticket.add(printLine("O", format("Issue Date:", carmaResponseTicketMessage.getTicketTimeStamp())));
            ticket.add(printLine("N", ""));
            ticket.add(printLine("O", format("Ticket Number:", carmaResponseTicketMessage.getTicketNumber())));

            String seatNumber = carmaResponseTicketMessage.getSeatNumber();
            if (seatNumber != null && !seatNumber.isEmpty()) {
                ticket.add(printLine("O", format("Seat Number:", seatNumber)));
            }

            ticket.add(printLine("O", format("Transaction ID:", carmaResponseTicketMessage.getReference())));
            ticket.add(printLine("O", format("Boarding At:", "")));
            ticket.add(printLine("O", carmaResponseTicketMessage.getBoardLocation()));
            ticket.add(printLine("O", format("Destination:", "")));
            ticket.add(printLine("O", carmaResponseTicketMessage.getDestLocation()));
            ticket.add(printLine("O", format("Departure Time:", carmaResponseTicketMessage.getBoardTime().trim())));
            ticket.add(printLine("O", format("Arrival Time:", carmaResponseTicketMessage.getArrivalTime().trim())));

            StringBuilder name = new StringBuilder();
            if (!carmaResponseTicketMessage.getPassengers().get(0).getTitle().equalsIgnoreCase("")
                    || !(carmaResponseTicketMessage.getPassengers().get(0).getTitle().length() == 0)) {
                name.append(carmaResponseTicketMessage.getPassengers().get(0).getTitle()).append(" ");
            }
            if (!carmaResponseTicketMessage.getPassengers().get(0).getInitials().equalsIgnoreCase("")
                    || !(carmaResponseTicketMessage.getPassengers().get(0).getInitials().length() == 0)) {
                name.append(carmaResponseTicketMessage.getPassengers().get(0).getInitials()).append(" ");
            }
            if (!carmaResponseTicketMessage.getPassengers().get(0).getLastName().equalsIgnoreCase("")
                    || !(carmaResponseTicketMessage.getPassengers().get(0).getLastName().length() == 0)) {
                name.append(carmaResponseTicketMessage.getPassengers().get(0).getLastName());
            }
            ticket.add(printLine("O", format("Name:", name.toString())));

            switch (carmaResponseTicketMessage.getPassengers().get(0).getPassengerType()) {
                case "A":
                    ticket.add(printLine("O", format("PassengerType:", "ADULT")));
                    break;
                case "C":
                    ticket.add(printLine("O", format("PassengerType:", "CHILD")));
                    break;
                case "I":
                    ticket.add(printLine("O", format("PassengerType:", "INFANT")));
                    break;
            }

            ticket.add(printLine("N", ""));
            ticket.add(printLine("H", "KEEP YOUR TICKET SAFE"));
            // Intercape footer
            if (!carmaResponseTicketMessage.getTicketFooter().isEmpty()) {
                ticket.add(printLine("O", ""));
                String footer = carmaResponseTicketMessage.getTicketFooter().replace("30", " 30");
                ticket.add(printLine("O", footer));
                ticket.add(printLine("O", ""));
            }
            ticket.add(printLine("H", "For enquiries and cancellations"));
            ticket.add(printLine("H", "please contact"));

            for (CarmaResponseItemMessage carrier : carmaResponseCarrierListMessage.getData().getItems()) {
                if (carmaResponseTicketMessage.getCarrier().equalsIgnoreCase(carrier.getCode())
                        || carmaResponseTicketMessage.getCarrier().equalsIgnoreCase(carrier.getName())) {
                    ticket.add(printLine("H", carrier.getCallCentre()));
                }
            }

            ticket.add(printLine("H", "For Terms and Conditions, visit"));

            //website
            for (CarmaResponseItemMessage carrier : carmaResponseCarrierListMessage.getData().getItems()) {
                if (carmaResponseTicketMessage.getCarrier().equalsIgnoreCase(carrier.getCode())
                        || carmaResponseTicketMessage.getCarrier().equalsIgnoreCase(carrier.getName())) {
                    ticket.add(printLine("H", carrier.getWebsite()));
                    break;
                }
            }

            //barcode
            String barcodeType = "";
            String barcodeNumber = "";
            for (CarmaResponseItemMessage carrier : carmaResponseCarrierListMessage.getData().getItems()) {
                if (carmaResponseTicketMessage.getCarrier().equalsIgnoreCase(carrier.getCode())
                        || carmaResponseTicketMessage.getCarrier().equalsIgnoreCase(carrier.getName())) {
                    supplierName = carrier.getCode();
                    barcodeType = carrier.getBarcodeType();
                    barcodeNumber = carmaResponseTicketMessage.getBarcode();
                    break;
                }
            }

            //we have created our own
            switch (barcodeType.toLowerCase()) {
                case "128b-special":
                case "128b":
                    ticket.add(printLine("X", processBarcode128B(barcodeNumber)));
                    break;

                case "code39":
                    ticket.add(printLine("Q", barcodeNumber));
                    break;

                case "ean13":
                    ticket.add(printLine("P", barcodeNumber));
                    break;

                case "itf":
                    ticket.add(printLine("U", barcodeNumber));
                    break;

                case "128a":
                case "128c":
                default:
                    //defaults to code 128
                    ticket.add(printLine("X", barcodeNumber));
                    break;
            }

            ticket.add(printLine("N", ""));
            ticket.add(printLine("H", "REPRINT"));
            ticket.add(printLine("N", ""));
            ticket.add(printLine("H", "-Print Done-"));
            printWithDynamic(ticket, true);
            gettingCarmaTicket = false;
        } catch (Exception exception) {
            Log.d(TAG, "problem reprinting ticket " + exception);
        }
    }

    private String processBarcode128B(String barcode) {
        // Received as follows from Carma
        // example : "43,85,79,100,90,82,74,58,75,92,76,63,125,47,39,47"
        // pre-processed 128B  = 43,85,79,100,90,82,74,58,75,92,76,63,125,47,39,47
        // post-processed 128B = +UOdZRJ:K\L?}/'/
        String[] tmp = barcode.split(",");
        StringBuilder ret = new StringBuilder();

        if (tmp.length == 16) {
            for (String value : tmp) {
                ret.append((char) Integer.parseInt(value));
            }

            return ret.toString();
        } else {
            return null;
        }
    }

    //----------------------------------------------------------------------------------------------
    private void clearReprintTicket() {
        createDirsIfNecessary(); // creates directory
        File file = new File(privateDir.getPath() + "/" + getResources().getString(R.string.bustTicketsReprintsDir) + "/" + "BusTickets.txt");
        boolean doesExist = file.exists() && file.delete(); // will be created with createDirsIfNecessary();
        if (!doesExist) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //----------------------------------------------------------------------------------------------
    // expire ticket
    public void removeExpiredTickets() {
        ArrayList<CarmaResponseTicketMessageSerializable> carmaResponseTicketMessageSerializables = readCachedTicketReprints(); // read all tickets and compare with time
        if (carmaResponseTicketMessageSerializables != null && carmaResponseTicketMessageSerializables.size() > 0) { // do we even have tickets?, if so process them
            // loop through tickets
            boolean someTicketRemoved = false;

            Iterator<CarmaResponseTicketMessageSerializable> iter = carmaResponseTicketMessageSerializables.iterator();
            while (iter.hasNext()) {
                CarmaResponseTicketMessageSerializable str = iter.next();
                if (new BluDroidUtils().compareNowAndTicketReprintExpiration(str.getTicketExprirationDate())) {
                    iter.remove();
                    someTicketRemoved = true;
                }
            }

            if (someTicketRemoved) { // if something was removed
                Log.d(TAG, "Removing expired tickets from cache");
                // write tickets to flat file
                clearReprintTicket(); // clear / remove file from device
                for (CarmaResponseTicketMessageSerializable carmaResponseTicketMessage : carmaResponseTicketMessageSerializables) {
                    cacheTicket(carmaResponseTicketMessage); // write tickets that have not expired
                }
            }
        }
    }

    private void securePrint(byte[] ticket) {

        try {
            Log.d(TAG, "securePrint() ticket has " + ticket.length + " bytes");
            BluDroidUSBPrinter usbPrint;
            if (isRunningInEmulator()) {
                usbPrint = new BluDroidUSBPrint(this, ticket);
            } else {
                usbPrint = new BluDroidUSBPrint(this, ticket);
            }

            boolean hasPermission;

            do {
                hasPermission = usbPrint.hasPermission();
                if (!hasPermission) {
                    Log.d(TAG, "moving task to back and sleeping");
                    moveTaskToBack(true);
                    Thread.sleep(5000);
                }
            } while (!hasPermission);

            Intent intent = new Intent(this, this.getClass());
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(intent);
            Log.d(TAG, "2-ticket is " + ticket.length + " bytes long");
            usbPrint.print(ticket);
            usbPrint.unregisterReceiver();

        } catch (Exception exception) {
            Log.v(TAG, "exception while printing " + exception);
            logger.error("exception while printing " + exception);
        }
    }

    public CommonResponseLineMessage printLine(String f, String text) {
        CommonResponseLineMessage commonResponseLineMessage = new CommonResponseLineMessage();
        commonResponseLineMessage.setF(f);
        commonResponseLineMessage.setText(text);
        return commonResponseLineMessage;
    }

    public String format(String left, String right) {
        return (new BluDroidUtils()).format(printWidth, left, right);
    }

    private String format(int firstColumn, String left, String right) {
        return (new BluDroidUtils()).format(printWidth, firstColumn, left, right);
    }

    public Bitmap generateBarcode(String barcodeType, String barcodeContents, int width, int height) {
        return (new BluDroidUtils()).generateBarcode(barcodeType, barcodeContents, width, height);
    }

    //
    // generate todays date and time
    //
    public String todaysDateAndTime() {
        return (new BluDroidUtils()).todaysDateAndTime(getResources().getString(R.string.simpleDateTimeFormat));
    }

    public String todaysDateForLogFiles() {
        return (new BluDroidUtils()).todaysDateAndTime(getResources().getString(R.string.dateFormatForLogFiles));
    }

    String todaysDateTimeForLogFiles() {
        return (new BluDroidUtils()).todaysDateAndTime(getResources().getString(R.string.dateTimeFormatForLogFiles));
    }

    private String todaysDateInMillies() {

        Calendar calendar = Calendar.getInstance();
        Log.d("TIMEINMILL", String.valueOf(calendar.getTimeInMillis()));

        calendar.setTime(date);
        return String.valueOf(calendar.getTimeInMillis());
    }

    public String formatMoney(String input) {
        return (new BluDroidUtils()).formatMoney(input);
    }

    private File[] getPendingToTender() {
        try {
            createDirsIfNecessary();
            return pendingDir.listFiles();
        } catch (Exception exception) {
            Log.d(TAG, "getPendingToTender throws " + exception);
            logger.error("getPendingToTender throws " + exception);
            return new File[0];
        }
    }

    File[] getNotTendered() {
        try {
            createDirsIfNecessary();
            return notTenderdDir.listFiles();
        } catch (Exception exception) {
            Log.d(TAG, "getPendingToTender throws " + exception);
            logger.error("getPendingToTender throws " + exception);
            return new File[0];
        }
    }

    private File[] getNotCancelledTickets() {
        try {
            createDirsIfNecessary();
            return autoCancelDir.listFiles();
        } catch (Exception exception) {
            Log.d(TAG, "getPendingToTender throws " + exception);
            logger.error("getPendingToTender throws " + exception);
            return new File[0];
        }
    }

    void removeAliases() {
        List<ComponentName> disableComponents = new ArrayList<>();

        disableComponents.add(new ComponentName("za.co.blts.bltandroidgui3", "za.co.blts.bltandroidgui3.ActivityLanding_blt"));
        disableComponents.add(new ComponentName("za.co.blts.bltandroidgui3", "za.co.blts.bltandroidgui3.ActivityLanding_tspc"));

        for (ComponentName componentName : disableComponents) {
            Log.d("RemoveAlias", "disabled component name is " + componentName);
            try {
                getPackageManager().setComponentEnabledSetting(componentName,
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP);
                Log.d("RemoveAlias", "setComponentDisabled");
            } catch (Exception exception) {
                Log.e("RemoveAlias", "exception on disable: " + exception);
                logger.error("exception " + exception);
            }
        }
    }

    public boolean isPackageInstalled(String packagename, PackageManager packageManager) {
        try {
            packageManager.getPackageInfo(packagename, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    protected void choosePrintLogo() {

        String drawableName = getDrawableName();
        Log.d(TAG, "using print logo: " + drawableName);
        final int resId = getDrawableResource(drawableName);

        if (gettingCarmaTicket) {
            final File carrierLogo = new File(longhaulLogoCacheDir, supplierName + ".gif");
            Date now = new Date();

            if (!carrierLogo.exists() || ((now.getTime() - dateLastCarmaPrintLogo(carrierLogo).getTime()) > CACHE_7_DAYS)) {

                Log.d(TAG, "choosePrintLogo: creating " + supplierName + ".gif");

                GetLongHaulLogoAsync getLogoAsync = new GetLongHaulLogoAsync();
                try {
                    getLogoAsync.execute(carmaResponseCarrierListMessage.getData().getMediaUrl() + "/" + supplierName + ".gif");
                    bluLogo = getLogoAsync.get();


                    Log.d(TAG, "choosePrintLogo: height = " + bluLogo.getHeight() + " width = " + bluLogo.getWidth());

                    if (bluLogo != null) {
                        // save the downloaded Bitmap
                        FileOutputStream fos = new FileOutputStream(carrierLogo.getPath());

                        bluLogo.compress(Bitmap.CompressFormat.PNG, 100, fos);
                        Log.d(TAG, "choosePrintLogo: height = " + bluLogo.getHeight() + " width = " + bluLogo.getWidth());
                        fos.flush();
                        fos.close();
                        bluLogo = BitmapFactory.decodeFile(carrierLogo.getPath());

                    } else
                        bluLogo = BitmapFactory.decodeResource(getResources(), resId);
                } catch (Exception e) {
                    bluLogo = BitmapFactory.decodeResource(getResources(), resId);
                    e.printStackTrace();
                    logger.error("choosePrintLogo " + e);
                }
            } else {
                Log.d(TAG, "choosePrintLogo: " + supplierName + ".gif is already there");
                bluLogo = BitmapFactory.decodeFile(carrierLogo.getPath());
            }

            bluLogo = Bitmap.createScaledBitmap(bluLogo, 260, 80, true);
            Log.d(TAG, "choosePrintLogo: height = " + bluLogo.getHeight() + " width = " + bluLogo.getWidth());
        } else
            bluLogo = BitmapFactory.decodeResource(getResources(), resId);

    }


    public static Bitmap getLogoFromMediaURL(String mediaURL) {
        try {
            URL url = new URL(mediaURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            return BitmapFactory.decodeStream(input);
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("getLogoFromMediaURL " + e);
            return null;
        }
    }

    private static class GetLongHaulLogoAsync extends AsyncTask<String, Void, Bitmap> {
        private Bitmap results;

        @Override
        protected Bitmap doInBackground(String... params) {
            return getLogoFromMediaURL(params[0]);
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            //  return the bitmap by doInBackground and store in result
            results = bitmap;
        }
    }

    private ArrayList<String> readCompleteFavouritesList() {
        ArrayList<String> favouritesList = new ArrayList<>();

        try {
            createDirsIfNecessary();
            File favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(favouritesFile));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                favouritesList.add(line);
            }
            bufferedReader.close();
        } catch (Exception exception) {
            Log.d(TAG, "readCompleteFavouritesList throws " + exception);
            logger.error("readCompleteFavouritesList throws " + exception);
        }
        return favouritesList;
    }

    public ArrayList<String> getFavouritesList() {
        ArrayList<String> favouritesList = new ArrayList<>();

        try {
            createDirsIfNecessary();
            File favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(favouritesFile));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                Log.v("Simon", line);
                String[] lineParts;
                lineParts = line.split(";");
                String name = lineParts[0];
                String stockId = lineParts[2];

                if (favouritesStockIDs.contains(stockId)) {
                    if (!favouritesList.contains(line)) {
                        favouritesList.add(line);
                    }

                } else if (stockId.equals("N/A")) {
                    Log.d("Simon", "stockId = N/A");
                    if (name.replace("[", "").equalsIgnoreCase("electricity")) {
                        Log.d("Simon", "name = Electricity");
                        if (loginResponseMessage.getData().canDo("Electricity")) {
                            Log.d("Simon", "Electricity allowed!!");
                            if (!favouritesList.contains(line)) {
                                favouritesList.add(line);
                            }
                        }
                    } else if (name.replace("[", "").equalsIgnoreCase("bus")) {
                        Log.d("Simon", "name = Bus");
                        if (canDoLongHaulBus()) {
                            Log.d("Simon", "Bus allowed!!");
                            if (!favouritesList.contains(line)) {
                                favouritesList.add(line);
                            }
                        }
                    } else {
                        if (!favouritesList.contains(line)) {
                            favouritesList.add(line);
                        }
                    }
                }
            }
            bufferedReader.close();

        } catch (Exception exception) {
            Log.d(TAG, "getFavouritesList throws " + exception);
            logger.error("getFavouritesList throws " + exception);
        }
        Log.d(TAG, favouritesList.size() + "");

        return favouritesList;
    }


    private String getNetworkName(String network) {
        String serviceProviderName = "";
        if (network.toLowerCase().contains("vodacom")) {
            serviceProviderName = "Vodacom";
        } else if (network.toLowerCase().contains("mtn")) {
            serviceProviderName = "MTN";
        } else if (network.toLowerCase().contains("cellc")) {
            serviceProviderName = "Cell C";
        } else if (network.toLowerCase().equals("Telkom")) {
            serviceProviderName = "Telkom Mobile";
        }
        return serviceProviderName;
    }

    //------------------------------------------------------------------------------------------------
    public ArrayList<String> getConsumerFavouritesList() {
        customerProfileTopupAccountNumbers = new HashMap<>();
        customerProfileElectricityAccountNumbers = new HashMap<>();
        customerProfileBillPaymentsAccountNumbers = new HashMap<>();
        customerProfileBundlesAccountNumbers = new HashMap<>();

        ArrayList<String> favouritesList = new ArrayList<>();
        for (Favourite favourite : completeConsumerProfile.getFavourites()) {
            if (favourite.getTrxGroup().equalsIgnoreCase("Vouchers") && favourite.getTrxType().equalsIgnoreCase("Voucher")) {
                checkPermittedVoucherTransaction(favourite, favouritesList);
            } else if (favourite.getTrxGroup().equalsIgnoreCase("Vouchers") && favourite.getTrxType().equalsIgnoreCase("C4C_Voucher")) {
                checkPermittedC4CTransactions(favourite, favouritesList);
            } else if (favourite.getTrxGroup().equalsIgnoreCase("Topup")) {
                checkPermittedTopupTransaction(favourite, favouritesList); // does tickets as well
            } else if (favourite.getTrxGroup().equalsIgnoreCase("Electricity")) {
                checkPermittedElectricityTransaction(favourite, favouritesList);
            } else if (favourite.getTrxGroup().equalsIgnoreCase("Payments")) {
                checkPermittedBillPaymentsProvider(favourite, favouritesList);
            } else if (favourite.getTrxGroup().equalsIgnoreCase("Tickets")) {
                checkPermittedTicketTransaction(favourite, favouritesList);
            } else if (favourite.getTrxGroup().equalsIgnoreCase("Bundles")) {
                checkPermittedPinlessBundle(favourite, favouritesList);
            } else if (favourite.getTrxGroup().equalsIgnoreCase("Other")) {
                checkPermittedOtherTransaction(favourite, favouritesList);
            }
        }
        return favouritesList;
    }

    //------------------------------------------------------------------------------------------------

    public void restoreDefaultFavouritesList() {
        try {
            createDirsIfNecessary();

            File favouritesFile = new File(favouritesDir.getPath() + "/" + ORIGINAL_CONFIG_TXT);
            favouritesFile.delete();

            favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
            favouritesFile.delete();
        } catch (Exception exception) {
            Log.d(TAG, "restoreDefaultFavouritesList List throws " + exception);
            logger.error("restoreDefaultFavouritesList List throws " + exception);
        }
    }

    void updateFavouritesIfNecessary() {
        String favVersion = getPreference(PREF_FAVOURITES_VERSION);
        int favsVerInt;
        try {
            favsVerInt = Integer.parseInt(favVersion);
        } catch (Exception e) {
            favsVerInt = 0;
        }

        if (favsVerInt < 1) {
            //Release 19 - rename favourites to be in line with prod voucher names so favs can no longer be duplicated
            disableDuplicationOfFavs();
        }
        if (favsVerInt < 2) {
            //Release 20 - universal bus update, change any old long haul bus favourites to long haul bus card
            universalBusFavs();
        }
        if (favsVerInt < 3) {
            //Release 20 - remove mvno products from favourites
            removeMvnoFavs();
        }
        if (favsVerInt < 4) {
            //Release 20.002 - remove lucky365 voucher from favs, but not lucky365 menu
            removeLucky365Favs();
        }
        if (favsVerInt < 5) {
            //Release 20.002 - remove Putco favourite on all devices but CITAQ
            removePutcoFav();
        }

        Log.d("FavList", "=======Favourites list up to date");
    }

    private void disableDuplicationOfFavs() {
        //check if any of the favs are from the old default favs.  If so, rename the descriptions so
        //they match aeon descriptions so we can no longer have duplicates in the fav list
        try {
            createDirsIfNecessary();
            File favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(favouritesFile));
            String s;
            boolean updated = false;
            ArrayList<String> favouritesList = new ArrayList<>();

            Log.d("FavList", "=======disableDuplicationOfFavs");
            while ((s = bufferedReader.readLine()) != null) {
                s = s.replace(":", ";").replace("[", "").replace("]", "");

                switch (s) {
                    case "Vodago;R12;33;voucher;Vodacom;Airtime;N/A":
                        s = "R12 Vodago;R12;33;voucher;Vodacom;Airtime;N/A";
                        updated = true;
                        break;
                    case "Vodago;R29;2;voucher;Vodacom;Airtime;N/A":
                        s = "R29 Vodago;R29;2;voucher;Vodacom;Airtime;N/A";
                        updated = true;
                        break;
                    case "R59;250MB;225;voucher;Vodacom;Data;N/A":
                        s = "R59 250MB;R59;225;voucher;Vodacom;Data;N/A";
                        updated = true;
                        break;
                    case "Call-a-lot;R10;53;voucher;MTN;Airtime;N/A":
                        s = "R10 Call-a-lot;R10;53;voucher;MTN;Airtime;N/A";
                        updated = true;
                        break;
                    case "Call-a-lot;R30;7;voucher;MTN;Airtime;N/A":
                        s = "R30 Call-a-lot;R30;7;voucher;MTN;Airtime;N/A";
                        updated = true;
                        break;
                    case "R45;Bundle  500MB Weekly;257;voucher;MTN;Data;N/A":
                        s = "Bundle R45 500MB Weekly;R45;257;voucher;MTN;Data;N/A";
                        updated = true;
                        break;
                    case "Easy Chat;R10;58;voucher;Cell C;Airtime;N/A":
                        s = "R10 Easy Chat;R10;58;voucher;Cell C;Airtime;N/A";
                        updated = true;
                        break;
                    case "Chat;R25;16;voucher;Cell C;Airtime;N/A":
                        s = "R25 Chat;R25;16;voucher;Cell C;Airtime;N/A";
                        updated = true;
                        break;
                    case "N/A;R50;323;voucher;xHollywood Bets;Other;N/A":
                        s = "R 50;R50;323;voucher;xHollywood Bets;Other;N/A";
                        updated = true;
                        break;
                    case "N/A;R100;100;voucher;UniPin;Electricity;N/A":
                        s = "R100;R100;100;voucher;UniPin;Electricity;N/A";
                        updated = true;
                        break;
                    case "World Card;R50;14;voucher;Telkom;Airtime;N/A":
                        s = "R50 World Card;R50;14;voucher;Telkom;Airtime;N/A";
                        updated = true;
                        break;
                    case "R99;1GB FreeMeBoost;341;voucher;Telkom Mobile;Data;N/A":
                        s = "1GB FreeMeBoost R99;R99;341;voucher;Telkom Mobile;Data;N/A";
                        updated = true;
                        break;
                    default:
                        //check if favourite was for data product, then swap desc and value
                        String[] split = s.split(";");
                        if (split.length == 7) {
                            if (split[5].equalsIgnoreCase("data")) {
                                s = split[1] + ";" + split[0] + ";" + split[2] + ";" + split[3] + ";" + split[4] + ";" + split[5] + ";" + split[6];
                                updated = true;
                            }
                        }
                        break;
                }
                if (!favouritesList.contains(s)) {
                    favouritesList.add(s);
                }
            }
            bufferedReader.close();

            if (updated) {
                Log.d("FavList", "=======New favourites list");
                for (String fav : favouritesList) {
                    Log.d("FavList", fav);
                }
                Log.d("FavList", "=======Updating favourites list");
                updateFavouritesListOrder(favouritesList);
            }

        } catch (Exception exception) {
            Log.d(TAG, "getFavouritesList throws " + exception);
            logger.error("getFavouritesList throws " + exception);
        }

        //update preferences so this function only runs once
        updatePreference(PREF_FAVOURITES_VERSION, "1");
    }

    private void universalBusFavs() {
        //remove translux, eldo, city2city and intercape favs, and ensure bus fav is added
        try {
            createDirsIfNecessary();
            File favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(favouritesFile));
            String s;
            boolean updated = false;
            ArrayList<String> favouritesList = new ArrayList<>();

            Log.d("FavList", "=======universalBusFavs");
            while ((s = bufferedReader.readLine()) != null) {
                s = s.replace(":", ";").replace("[", "").replace("]", "");

                if (s.equals("Translux;0;0;LongHaulBuses;Translux;LongHaulBuses;N/A")
                        || s.equals("Eldo;0;0;LongHaulBuses;Eldo;LongHaulBuses;N/A")
                        || s.equals("City to City;0;0;LongHaulBuses;CitytoCity;LongHaulBuses;N/A")
                        || s.equals("Intercape;0;0;LongHaulBuses;Intercape;LongHaulBuses;N/A")) {
                    s = "Bus;N/A;N/A;Menu;N/A;N/A;N/A";
                    updated = true;
                }

                if (!favouritesList.contains(s)) {
                    favouritesList.add(s);
                }
            }
            bufferedReader.close();

            if (updated) {
                Log.d("FavList", "=======New favourites list");
                for (String fav : favouritesList) {
                    Log.d("FavList", fav);
                }
                Log.d("FavList", "=======Updating favourites list");
                updateFavouritesListOrder(favouritesList);
            }

        } catch (Exception exception) {
            Log.d(TAG, "getFavouritesList throws " + exception);
            logger.error("getFavouritesList throws " + exception);
        }

        //update preferences so this function only runs once
        updatePreference(PREF_FAVOURITES_VERSION, "2");
    }

    private void removeMvnoFavs() {
        //remove mvno favourites
        try {
            createDirsIfNecessary();
            File favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(favouritesFile));
            String s;
            boolean updated = false;
            ArrayList<String> favouritesList = new ArrayList<>();

            Log.d("FavList", "=======removeMvnoFavs");
            while ((s = bufferedReader.readLine()) != null) {
                s = s.replace(":", ";").replace("[", "").replace("]", "");
                String[] split = s.split(";");

                if (split.length > 2 && split[2].equalsIgnoreCase("C4C")) {
                    Log.d("FavList", "remove mvno: " + s);
                    updated = true;
                } else {
                    favouritesList.add(s);
                }
            }
            bufferedReader.close();

            if (updated) {
                Log.d("FavList", "=======New favourites list");
                for (String fav : favouritesList) {
                    Log.d("FavList", fav);
                }
                Log.d("FavList", "=======Updating favourites list");
                updateFavouritesListOrder(favouritesList);
            }

        } catch (Exception exception) {
            Log.d(TAG, "getFavouritesList throws " + exception);
            logger.error("getFavouritesList throws " + exception);
        }

        //update preferences so this function only runs once
        updatePreference(PREF_FAVOURITES_VERSION, "3");
    }

    private void removeLucky365Favs() {
        //remove mvno favourites
        try {
            createDirsIfNecessary();
            File favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(favouritesFile));
            String s;
            boolean updated = false;
            ArrayList<String> favouritesList = new ArrayList<>();

            Log.d("FavList", "=======removeMvnoFavs");
            while ((s = bufferedReader.readLine()) != null) {
                s = s.replace(":", ";").replace("[", "").replace("]", "");
                String[] split = s.split(";");

                if (split.length > 5 && split[5].equalsIgnoreCase("Wallet Top Up")) {
                    Log.d("FavList", "remove lucky365: " + s);
                    updated = true;
                } else {
                    favouritesList.add(s);
                }
            }
            bufferedReader.close();

            if (updated) {
                Log.d("FavList", "=======New favourites list");
                for (String fav : favouritesList) {
                    Log.d("FavList", fav);
                }
                Log.d("FavList", "=======Updating favourites list");
                updateFavouritesListOrder(favouritesList);
            }

        } catch (Exception exception) {
            Log.d(TAG, "getFavouritesList throws " + exception);
            logger.error("getFavouritesList throws " + exception);
        }

        //update preferences so this function only runs once
        updatePreference(PREF_FAVOURITES_VERSION, "4");
    }

    private void removePutcoFav() {
        if (!Build.MODEL.startsWith("CITAQ")) {
            //remove putco favourite
            try {
                createDirsIfNecessary();
                File favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
                BufferedReader bufferedReader = new BufferedReader(new FileReader(favouritesFile));
                String s;
                boolean updated = false;
                ArrayList<String> favouritesList = new ArrayList<>();

                Log.d("FavList", "=======removePutcoFavs");
                while ((s = bufferedReader.readLine()) != null) {
                    if (s.contains("Putco")) {
                        Log.d("FavList", "remove putco: " + s);
                        updated = true;
                    } else {
                        favouritesList.add(s);
                    }
                }
                bufferedReader.close();

                if (updated) {
                    Log.d("FavList", "=======New favourites list");
                    for (String fav : favouritesList) {
                        Log.d("FavList", fav);
                    }
                    Log.d("FavList", "=======Updating favourites list");
                    updateFavouritesListOrder(favouritesList);
                }

            } catch (Exception exception) {
                Log.d(TAG, "getFavouritesList throws " + exception);
                logger.error("getFavouritesList throws " + exception);
            }
        }
        //update preferences so this function only runs once
        updatePreference(PREF_FAVOURITES_VERSION, "5");
    }

    public void createDefaultFavouritesList() {
        try {
            createDirsIfNecessary();

            List<String> favourites = new ArrayList<>();

            if (false) {
                //old favs
                favourites.add("Vodago;R12;33;voucher;Vodacom;Airtime;N/A");
                favourites.add("Vodago;R29;2;voucher;Vodacom;Airtime;N/A");
                favourites.add("R59;250MB;225;voucher;Vodacom;Data;N/A");
                favourites.add("Call-a-lot;R10;53;voucher;MTN;Airtime;N/A");
                favourites.add("Call-a-lot;R30;7;voucher;MTN;Airtime;N/A");
                favourites.add("R45;Bundle  500MB Weekly;257;voucher;MTN;Data;N/A");
                favourites.add("Easy Chat;R10;58;voucher;Cell C;Airtime;N/A");
                favourites.add("Chat;R25;16;voucher;Cell C;Airtime;N/A");
                favourites.add("N/A;R50;323;voucher;xHollywood Bets;Other;N/A");
                favourites.add("N/A;R100;100;voucher;UniPin;Electricity;N/A");
                favourites.add("Electricity;N/A;N/A;munics;Electricity;Electricity;N/A");
                favourites.add("World Card;R50;14;voucher;Telkom;Airtime;N/A");
                favourites.add("R99;1GB FreeMeBoost;341;voucher;Telkom Mobile;Data;N/A");
            } else {
                //new favs
                favourites.add("R12 Vodago;R12;33;voucher;Vodacom;Airtime;N/A");
                favourites.add("R29 Vodago;R29;2;voucher;Vodacom;Airtime;N/A");
                favourites.add("R59 250MB;R59;225;voucher;Vodacom;Data;N/A");
                favourites.add("R10 Call-a-lot;R10;53;voucher;MTN;Airtime;N/A");
                favourites.add("R30 Call-a-lot;R30;7;voucher;MTN;Airtime;N/A");
                favourites.add("Bundle R45 500MB Weekly;R45;257;voucher;MTN;Data;N/A");
                favourites.add("R10 Easy Chat;R10;58;voucher;Cell C;Airtime;N/A");
                favourites.add("R25 Chat;R25;16;voucher;Cell C;Airtime;N/A");
                favourites.add("R 50;R50;323;voucher;xHollywood Bets;Other;N/A");
                favourites.add("R100;R100;100;voucher;UniPin;Electricity;N/A");
                favourites.add("Electricity;N/A;N/A;munics;Electricity;Electricity;N/A");
                favourites.add("R50 World Card;R50;14;voucher;Telkom;Airtime;N/A");
                favourites.add("1GB FreeMeBoost R99;R99;341;voucher;Telkom Mobile;Data;N/A");
            }
            File favouritesFile = new File(favouritesDir.getPath() + "/" + ORIGINAL_CONFIG_TXT);

            PrintWriter bufferedWriter = new PrintWriter(new FileWriter(favouritesFile, false));
            for (String line : favourites) {
                bufferedWriter.println(line);
                Log.d(TAG, "saving " + line);
                Log.d(TAG, "path " + favouritesFile.getAbsolutePath());
            }
            bufferedWriter.flush();
            bufferedWriter.close();

            favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
            bufferedWriter = new PrintWriter(new FileWriter(favouritesFile, true));
            for (String line : favourites) {
                bufferedWriter.println(line);
                Log.d("Favs", "saving to favourites " + line);
                Log.d(TAG, "path favourites" + favouritesFile.getAbsolutePath());
            }
            bufferedWriter.flush();
            bufferedWriter.close();

            //set the preference flag to 1 since the favourites do not need to be checked again in future
            updatePreference(PREF_FAVOURITES_VERSION, "1");


        } catch (Exception exception) {
            Log.d(TAG, "createDefaultFavouritesList List throws " + exception);
            logger.error("createDefaultFavouritesList List throws " + exception);
        }
    }

    public boolean checkFavouritesListEntry(String newEntry) {
        boolean exixts = false;
        try {
            createDirsIfNecessary();

            File favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(favouritesFile));
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                if (newEntry.equals(sanitize(line))) {
                    exixts = true;
                }
            }
            bufferedReader.close();
        } catch (Exception exception) {
            Log.d(TAG, "getFavouritesList throws " + exception);
            logger.error("getFavouritesList throws " + exception);
        }

        return exixts;
    }

    public void saveFavouritesList(List<String> favourites) {
        try {
            createDirsIfNecessary();
            File favouritesFile = new File(favouritesDir.getPath() + "/" + CONFIG_TXT);
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(favouritesFile, true));
            for (String line : favourites) {
                bufferedWriter.write(favourites + "\n");
                Log.d("FavsSave", "saving " + line);
            }
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            Log.e(TAG, "savefavourites List throws " + exception);
            logger.error("savefavourites List throws " + exception);
        }
    }

    public void removeFromFavouritesList(ArrayList<String> favouritesList, String favourite) {

        try {
            if (favouritesList.size() > 0) {
                PrintWriter writer = new PrintWriter(new File(favouritesDir.getPath() + "/" + CONFIG_TXT));
                writer.print("");
                writer.close();
                //List<String> newData = new ArrayList<String>();
                for (String data : favouritesList) {
                    if (!favourite.equals(sanitize(data))) {
                        List<String> newData = new ArrayList<>();
                        newData.add(sanitize(data));
                        saveFavouritesList(newData);
                    }
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "removeFromFavouritesList throws " + exception);
            logger.error("removeFromFavouritesList throws " + exception);
        }
    }

    public void updateFavouritesListOrder(ArrayList<String> favouritesList) {

        try {
            if (favouritesList.size() > 0) {
                PrintWriter writer = new PrintWriter(new File(favouritesDir.getPath() + "/" + CONFIG_TXT));
                writer.print("");
                writer.close();
                Log.v(TAG, "LIST COUNT: " + favouritesList.size());
                for (String data : favouritesList) {
                    List<String> newData = new ArrayList<>();
                    newData.add(sanitize(data));
                    saveFavouritesList(newData);
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "removeFromFavouritesList throws " + exception);
            logger.error("removeFromFavouritesList throws " + exception);
        }
    }

    public String sanitize(String raw) {
        return raw.replaceAll("\\[", "").replaceAll("\\]", "");
    }

    private void saveTransactionList(String transaction) {
        try {
            createDirsIfNecessary();
            File calculatorFile = new File(calculatorDir.getPath() + "/" + CONFIG_TXT);

            BufferedWriter bufferedWriter;
            ArrayList<String> transactionList = getTransactionList();

            if (transactionList.size() < 20) {
                bufferedWriter = new BufferedWriter(
                        new FileWriter(calculatorFile, true));
                bufferedWriter.write(transaction + "\n");
                Log.d(TAG, "saving transaction: " + transaction);

            } else {

                PrintWriter writer = new PrintWriter(calculatorFile);
                writer.print("");
                writer.close();

                bufferedWriter = new BufferedWriter(
                        new FileWriter(calculatorFile, true));

                for (int i = 1; i < transactionList.size(); i++) {
                    String data = transactionList.get(i);
                    bufferedWriter.write(data + "\n");
                    Log.d(TAG, "saving transaction 2: " + data);
                }
                bufferedWriter.write(transaction + "\n");
            }

            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error("saveTransactionList " + exception);
        }
    }

    private void clearTransactionList() {
        try {
            PrintWriter writer = new PrintWriter(new File(calculatorDir.getPath() + "/" + CONFIG_TXT));
            writer.print("");
            writer.close();
            Log.d(TAG, "Transaction list cleared");
        } catch (Exception exception) {
            Log.d(TAG, "clear transaction List throws " + exception);
            logger.error("clearTransactionList " + exception);
        }
    }

    ArrayList<String> getTransactionList() {
        ArrayList<String> transactionList = new ArrayList<>();
        try {
            createDirsIfNecessary();
            File[] list = calculatorDir.listFiles();
            if (list.length > 0) {
                if (list[0].getName().equals(CONFIG_TXT)) {
                    BufferedReader bufferedReader = new BufferedReader(new FileReader(list[0]));
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        Log.v(TAG, line);
                        transactionList.add(line);
                    }
                    bufferedReader.close();
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "getFavouritesList throws " + exception);
            logger.error("getFavouritesList throws " + exception);
        }
        Log.d(TAG, transactionList.size() + "");
        return transactionList;
    }

    public void authenticateForChatForChange(String supplierCode, String amount) {
        this.supplierCode = supplierCode;
        this.amount = amount;
        gettingVouchers = true;
        authenticateForChatForChange();
    }

    private void authenticateForChatForChange() {

        createProgress(R.string.authenticating);
        Chat4ChangeRequestFactory factory = new Chat4ChangeRequestFactory();
        Chat4ChangeAuthenticationRequestMessage request =
                factory.create(
                        loginResponseMessage.getData().getUserPin(),
                        getPreference(PREF_DEVICE_ID),
                        getPreference(PREF_DEVICE_SER));
        if (completeConsumerProfile != null) {
            request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
        }
        startAEONAsyncTask(this, socket, request);
    }

    private void getChat4ChangeSuppliers() {
        createProgress(R.string.gettingChat4ChangeSuppliers);
        if (chat4ChangeAuthenticationResponseMessage != null) {
            Chat4ChangeRequestFactory factory = new Chat4ChangeRequestFactory();
            Chat4ChangeRequestListSuppliersMessage request = factory.listSuppliers(chat4ChangeAuthenticationResponseMessage,
                    "listSuppliers");
            startAEONAsyncTask(this, socket, request);
        }
    }

    private void getChat4ChangeVoucher(Chat4ChangeAuthenticationResponseMessage authenticationResponse,
                                       String supplierCode, String amount) {
        createProgress(R.string.gettingVouchers);
        gettingVouchers = true;
        Chat4ChangeRequestFactory factory = new Chat4ChangeRequestFactory();
        Date now = new Date();
        Chat4ChangeRequestMessage request =
                factory.purchase(authenticationResponse,
                        getPreference(PREF_DEVICE_ID) + "_" + now.getTime(),
                        supplierCode,
                        amount);

        startAEONAsyncTask(this, socket, request);

    }

    private void setPrintedChat4Change(Chat4ChangeResponseMessage response) {
        Chat4ChangeRequestFactory factory = new Chat4ChangeRequestFactory();
        Chat4ChangeRequestPrintedMessage request = factory.print(response);
        startAEONAsyncTask(this, socket, request);
    }

    void emptyBasket() {
        Log.d(TAG, "emptyBasket() authenticating to tender");
        authenticateTender();
    }

    private Date dateLastCache(File cacheDir, String fileName) {
        try {
            createDirsIfNecessary();
            Log.d(TAG, "cacheDir " + cacheDir);
            Log.d(TAG, "cacheDir.getPath() " + cacheDir.getPath());
            File cache = new File(cacheDir.getPath() + "/" + fileName);
            Log.d(TAG, "cache is " + cache);
            Log.d(TAG, "cache.lastModified is " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            Log.d(TAG, "problem with cache " + cacheDir.getPath() + " exception " + exception);
            logger.error("problem with cache " + cacheDir.getPath() + " exception " + exception);
            return new Date(0L);
        }
    }

    private void authenticateTender() {
        Log.v(TAG, "must authenticate to tender");
        try {
            createProgress(R.string.authenticating);
            TenderRequestFactory factory = new TenderRequestFactory();
            TenderAuthenticationRequestMessage request = factory.create(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticateTender " + exception);
            logger.error("authenticateTender " + exception);
        }
    }

    void retryFailedCancellationsAndTenders() {
        try {
            checkPutcoAutoCancellStatus();

            File[] notTenderedFiles = getNotTendered();
            if (notTenderedFiles.length > 0) {
                isClearingUntenderdState = true;
                emptyBasket();

            } else {

                if (needsToRetryAutoCancel) {
                    retryPutcoAutoCancel();
                } else {
                    getAccountBalanceIfNecessary();
                }
            }

        } catch (Exception ex) {
            logger.error("retryFailedCancellationsAndTenders " + ex);
        }

    }

    void clearUntenderd(TenderAuthenticationResponseMessage tenderAuthenticationResponseMessage) {
        try {
            File[] notTenderedFiles = getNotTendered();
            if (notTenderedFiles.length > 0) {


                Double total = 0d;
                ArrayList<String> transRefs = new ArrayList<>();

                for (File tenderedFile : notTenderedFiles) {
                    File notTenderedFile = new File(notTenderdDir.getPath() + "/" + tenderedFile.getName());
                    BufferedReader bufferedReader = new BufferedReader(new FileReader(notTenderedFile));

                    String line;

                    while ((line = bufferedReader.readLine()) != null) {
                        Log.d(TAG, "TENDERLINE: " + line);
                        if (!line.isEmpty()) {
                            String[] lineParts = line.split(",");
                            if (lineParts.length > 1) {
                                String ref = lineParts[0];
                                String amount = lineParts[1];

                                total += Double.parseDouble(amount);
                                transRefs.add(ref);
                            }
                        }
                    }

                }

                if (transRefs.size() > 0) {
                    tenderDescription = transRefs.get(0);
                    tenderAmount = total.toString();
                    paymentType = "cash";
                    TenderRequestFactory factory = new TenderRequestFactory();
                    TenderRequestMessage request = factory.create(tenderAuthenticationResponseMessage.getSessionId(),
                            String.valueOf(total), //cash.toString(),
                            "0.00", //creditCard.toString(),
                            "0.00", //debitCard.toString(),
                            "0.00", // cheque
                            "0.00", // other
                            String.valueOf(total), //total.toString(),
                            "0.00"); // change.toString());
                    for (String transRef : transRefs) {
                        request.getEvent().getItems().add(transRef);
                    }

                    startAEONAsyncTask(this, socket, request);
                    Log.d(TAG, "Tendering");
                } else {
                    dismissProgress();
                    deleteCorruptedTenderFiles();
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            logger.error(ex);
            dismissProgress();
        }
    }

    private void deleteCorruptedTenderFiles() {
        try {
            File[] notTenderedFiles = getNotTendered();
            for (File tenderedFile : notTenderedFiles) {
                File notTenderedFile = new File(notTenderdDir.getPath() + "/" + tenderedFile.getName());
                notTenderedFile.delete();
            }
        } catch (Exception ex) {
            logger.error(ex);
        }
    }

    private void retryPutcoAutoCancel() {
        try {
            File[] autoCancelFiles = getNotCancelledTickets();
            if (autoCancelFiles.length > 0) {

                for (File cancelFile : autoCancelFiles) {
                    File autoCancelFile = new File(autoCancelDir.getPath() + "/" + cancelFile.getName());
                    BufferedReader bufferedReader = new BufferedReader(new FileReader(autoCancelFile));

                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        Log.v(TAG, line);
                        String[] lineParts = line.split(",");

                        this.transRef = lineParts[0];
                        this.ref = lineParts[1];
                    }
                }

                authenticateWithTicketPro();
            }

        } catch (Exception ex) {
            logger.error(ex);

        }
    }

    public void authenticateRica(String username, String password) {
        Log.v("AuthRica", "authenticateRica(String username, String password)");

        try {
            isRicaLogin = true;
            isRicaQuery = false;
            isRicaRegister = false;
            isRicaChangeOnwer = false;
            isRicaboxRica = false;
            createProgress(R.string.authenticating);
            this.username = username;
            this.password = password;
            RicaRequestFactory factory = new RicaRequestFactory();

            RicaAuthenticationRequestMessage request = factory.create(
                    getPreference(PREF_RICA_DEVICE_ID),
                    getPreference(PREF_RICA_DEVICE_SER));
            startAEONAsyncTask(this, socket, request);

        } catch (Exception exception) {
            Log.v(TAG, "problems authenticating with rica " + exception);
            logger.error("problems authenticating with rica " + exception);
        }
    }

    public void authenticateRica(String cellPhone) {
        Log.v("AuthRica", "authenticateRica(String cellPhone)");

        try {

            this.ricaQueryCell = cellPhone;
            isRicaQuery = true;
            isRicaLogin = false;
            isRicaRegister = false;
            isRicaChangeOnwer = false;
            isRicaboxRica = false;
            createProgress(R.string.authenticating);
            RicaRequestFactory factory = new RicaRequestFactory();
            RicaAuthenticationRequestMessage request = factory.create(
                    getPreference(PREF_RICA_DEVICE_ID),
                    getPreference(PREF_RICA_DEVICE_SER));
            startAEONAsyncTask(this, request);

        } catch (Exception exception) {
            Log.v(TAG, "problems authenticating with rica " + exception);
            logger.error("problems authenticating with rica " + exception);
        }

    }

    public void authenticateRica() {
        Log.v("AuthRica", "authenticateRica()");
        try {
            isRicaLogin = false;
            isRicaQuery = false;
            isRicaRegister = true;
            isRicaChangeOnwer = false;
            isRicaboxRica = false;
            createProgress(R.string.authenticating);
            RicaRequestFactory factory = new RicaRequestFactory();
            RicaAuthenticationRequestMessage request = factory.create(
                    getPreference(PREF_RICA_DEVICE_ID),
                    getPreference(PREF_RICA_DEVICE_SER));
            startAEONAsyncTask(this, request);

        } catch (Exception exception) {
            Log.v(TAG, "problems authenticating with rica " + exception);
            logger.error("problems authenticating with rica " + exception);
        }
    }

    public void authenticateRicaChangeOwner() {
        Log.v("AuthRica", "authenticateRicaChangeOwner()");
        try {
            isRicaQuery = false;
            isRicaLogin = false;
            isRicaRegister = false;
            isRicaChangeOnwer = true;
            isRicaboxRica = false;
            createProgress(R.string.authenticating);
            RicaRequestFactory factory = new RicaRequestFactory();
            RicaAuthenticationRequestMessage request = factory.create(
                    getPreference(PREF_RICA_DEVICE_ID),
                    getPreference(PREF_RICA_DEVICE_SER));
            startAEONAsyncTask(this, request);

        } catch (Exception exception) {
            Log.v(TAG, "problems authenticating with rica " + exception);
            logger.error("problems authenticating with rica " + exception);
        }
    }

    public void authenticateBoxRica(String referenceNumber) {
        Log.v("AuthRica", "authenticateBoxRica(String referenceNumber)");
        try {
            isRicaQuery = false;
            isRicaLogin = false;
            isRicaRegister = false;
            isRicaChangeOnwer = false;
            isRicaboxRica = true;

            this.boxRicareference = referenceNumber;

            createProgress(R.string.authenticating);
            RicaRequestFactory factory = new RicaRequestFactory();
            RicaAuthenticationRequestMessage request = factory.create(
                    getPreference(PREF_RICA_DEVICE_ID),
                    getPreference(PREF_RICA_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, request);

        } catch (Exception exception) {
            Log.v(TAG, "problems authenticating with rica " + exception);
            logger.error("problems authenticating with rica " + exception);
        }
    }

    private void checkRicaUser() {
        Log.v(TAG, "checkRicaUser");
        try {
            RicaRequestFactory factory = new RicaRequestFactory();
            ricaRequestUserMessage = new RicaRequestUserMessage();
            ricaRequestUserMessage.setUsername(username);
            ricaRequestUserMessage.setPassword(password);
            ricaRequestUserMessage.setSourceDevice(getPreference(PREF_RICA_DEVICE_ID));
            ricaRequestUserMessage.setSourceRef(getPreference(PREF_RICA_DEVICE_SER));
            RicaRequestCheckUserMessage request =
                    factory.create(ricaAuthenticationResponseMessage, ricaRequestUserMessage);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "problems checking rica user " + exception);
            logger.error("problems checking rica user " + exception);
        }
    }

    private void doRicaQuery() {
        Log.v(TAG, "query");
        createProgress("Querrying Number");
        try {
            // authenticateRica();
            Log.v(TAG, "cellNumber is " + ricaQueryCell);
            Log.v(TAG, "ricaAuthenticationResponseMessage " + ricaAuthenticationResponseMessage);
            Log.v(TAG, "ricaRequestUserMessage " + ricaRequestUserMessage);
            RicaRequestFactory factory = new RicaRequestFactory();
            RicaRequestQueryMessage request = factory.create(
                    ricaAuthenticationResponseMessage,
                    ricaRequestUserMessage,
                    ricaQueryCell);
            startAEONAsyncTask(this, socket, request);

        } catch (Exception exception) {
            Log.v(TAG, "problems " + exception);
            logger.error("problems " + exception);
        }

    }

    private void ricaRegisterSim() {
        Log.v(TAG, "Rica Register");
        try {
            createProgress("Registering");
            RicaRequestFactory factory = new RicaRequestFactory();
            RicaRequestRegisterMessage request = factory.create(
                    ricaAuthenticationResponseMessage,
                    ricaRequestUserMessage,
                    ricaRegistrationMessage);

            startAEONAsyncTask(this, socket, request);

        } catch (Exception exception) {
            Log.v(TAG, "problems registering 1 sim " + exception);
            logger.error("problems registering 1 sim " + exception);
        }
    }

    private void ricaRegisterMultipleSims() {
        try {
            createProgress("Registering");
            RicaRequestFactory factory = new RicaRequestFactory();

            RicaRequestRegisterMessage request = factory.create(ricaAuthenticationResponseMessage, ricaRequestUserMessage, ricaRegistrationMessage);

            RicaRequestMultipleRegisterMessage multipleRequest = new RicaRequestMultipleRegisterMessage();
            multipleRequest.setSessionId(request.getSessionId());
            multipleRequest.setEventType("MultipleRegister");
            multipleRequest.setEvent(request.getEvent());
            startAEONAsyncTask(this, socket, multipleRequest);
        } catch (Exception exception) {
            Log.v(TAG, "problems registering multiple sim " + exception);
            logger.error("problems registering multiple sim " + exception);
        }

    }

    private void ricaBoxRegister() {
        try {

            createProgress("Registering");
            RicaRequestFactory factory = new RicaRequestFactory();
            //LB registration.setReferenceType("");
            RicaRequestBoxNumberMessage boxNumber = new RicaRequestBoxNumberMessage();
            boxNumber.setBoxnumber(boxRicareference);
            RicaRequestBoxNumberSIMSMessage request = factory.createBoxRequest(ricaAuthenticationResponseMessage, ricaRequestUserMessage, boxNumber, ricaRegistrationMessage);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "problems registering multiple sim " + exception);
            logger.error("problems registering multiple sim " + exception);
        }
    }

    private void ricaChangeOwner() {
        try {
            createProgress("Changing Owner");
            RicaRequestFactory factory = new RicaRequestFactory();
            RicaRequestChangeOwnerMessage request = factory.createChangeOwner(ricaAuthenticationResponseMessage, ricaRequestUserMessage, ricaRegistrationMessage);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            logger.error("problems changing owner " + exception);
        }
    }

    public void ithubaAuth(String gameName, String numBoards, String numDraws, String playPlusBox, String playPlus2Box) {
        try {
            createProgress(R.string.authenticating);

            this.gameName = gameName;
            this.numBoards = numBoards;
            this.numDraws = numDraws;
            this.playPlusBox = playPlusBox;
            this.playPlus2Box = playPlus2Box;
            this.yesNoCheckBox = "";
            this.yesNoCheckBox2 = "";

            IthubaRequestFactory factory = new IthubaRequestFactory();
            IthubaAuthenticationRequestMessage request = factory.create(loginResponseMessage,
                    getPreference(PREF_DEVICE_ID), getPreference(PREF_DEVICE_SER));

            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            logger.error("authenticate exception: " + exception);
        }
    }

    public void ithubaAuth(String gameName, String numBoards, String numDraws, String playPlusBox,
                           String playPlus2Box, String yesNoCheckBox, String yesNoCheckBox2, boolean passesChecks,
                           Map<String, LottoNumberCollection> boardNumbers) {

        try {
            createProgress(R.string.authenticating);

            this.gameName = gameName;
            this.numBoards = numBoards;
            this.numDraws = numDraws;
            this.playPlusBox = playPlusBox;
            this.playPlus2Box = playPlus2Box;
            this.yesNoCheckBox = yesNoCheckBox;
            this.yesNoCheckBox2 = yesNoCheckBox2;
            this.passesChecks = passesChecks;
            this.boardNumbers = boardNumbers;

            IthubaRequestFactory factory = new IthubaRequestFactory();
            IthubaAuthenticationRequestMessage request = factory.create(loginResponseMessage,
                    getPreference(PREF_DEVICE_ID), getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticate exception: " + exception);
            logger.error("authenticate exception: " + exception);
        }
    }

    private void preConfirm(String gameName, String numBoards, String numDraws, String playPlusBox, String playPlus2Box) {
        try {
            createProgress(R.string.confirmingIthuba);

            ref = getPreference(PREF_DEVICE_ID) + "_" + date.getTime();

            requestMap = new HashMap<>();
            if (gameName.contains("lotto")) {
                requestMap.put("Game", "Lotto");
            } else if (gameName.contains("powerball")) {
                requestMap.put("Game", "Powerball");
            }
            requestMap.put("NumBoards", numBoards);
            requestMap.put("NumberOfDraws", numDraws);

            if (gameName.contains("ps")) {

                StringBuilder finalNumbers = new StringBuilder();
                for (String key : boardNumbers.keySet()) {
                    finalNumbers.append(boardNumbers.get(key).toString());
                    finalNumbers.append("|");
                }
                String s = finalNumbers.toString().substring(finalNumbers.length() - 1);
                if (s.equals("|")) {
                    finalNumbers.deleteCharAt(finalNumbers.length() - 1);
                }

                requestMap.put("Type", "PlayerSelected");
                requestMap.put("Numbers", finalNumbers.toString());
            } else {
                requestMap.put("Type", "Quickpick");
            }
            requestMap.put("Plus1", playPlusBox);
            requestMap.put("Plus2", playPlus2Box);

            ithubaConfim(requestMap);

        } catch (Exception exception) {
            Log.v(TAG, "Pre-Confirmation exception: " + exception);
            logger.error("Pre-Confirmation exception: " + exception);
        }
    }

    private void ithubaConfim(Map<String, String> requestMap) {
        try {
            IthubaRequestFactory factory = new IthubaRequestFactory();
            IthubaRequestItbConfirmMessage request = factory.createConfirm(loginResponseMessage.getSessionId(), ref, requestMap);

            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "Confirmation exception: " + exception);
            logger.error("Confirmation exception: " + exception);
        }
    }

    private void buyTicket(Map<String, String> requestMap) {
        try {
            createProgress(R.string.puchasingIthuba);
            IthubaRequestFactory factory = new IthubaRequestFactory();
            if (gameName.contains("lotto")) {
                IthubaRequestItbLotteryMessage request = factory.createLottery(ithubaAuthenticationResponseMessage, ref, requestMap);

                startAEONAsyncTask(this, socket, request);
            } else if (gameName.contains("powerball")) {
                IthubaRequestItbPowerballMessage request = factory.createPowerball(ithubaAuthenticationResponseMessage, ref, requestMap);

                startAEONAsyncTask(this, socket, request);
            }
        } catch (Exception exception) {
            Log.v(TAG, "Purchasing of ticket exception: " + exception);
            logger.error("Purchasing of ticket exception: " + exception);
        }
    }

    private void printConfirm() {
        try {
            ArrayList<CommonResponseLineMessage> printConfirmLines = new ArrayList<>();
            printConfirmLines.add(printLine("H", "CUSTOMER NUMBER CONFIRMATION"));
            printConfirmLines.add(printLine("N", ""));

            for (String key : boardNumbers.keySet()) {
                printConfirmLines.add(printLine("N", format(key + ":", boardNumbers.get(key).toString())));
            }
            printConfirmLines.add(printLine("N", ""));
            printConfirmLines.add(printLine("H", "THIS IS NOT A LOTTO TICKET"));
            print(printConfirmLines);
        } catch (Exception exception) {
            Log.v(TAG, "Confirmation printing exception: " + exception);
            logger.error("Confirmation printing exception: " + exception);
        }
    }

    private void ithubaPrinted() {
        IthubaRequestFactory factory = new IthubaRequestFactory();
        IthubaRequestItbPrintedMessage request = factory.createPrinted(ithubaAuthenticationResponseMessage, "true");
        startAEONAsyncTask(this, socket, request);
    }

    public String firstTwoDigitsPin() {
        return loginResponseMessage.getData().getUserPin().substring(0, 2);
    }

    void testPrinter() {
        try {
            if (logoId == null) {
                logoId = "30";
            } else if (logoId.equals("30")) {
                logoId = "31";
            } else {
                logoId = null;
            }

            ArrayList<CommonResponseLineMessage> testPrint = new ArrayList<>();

            CommonResponseLineMessage lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("L");
            lineMessage.setText("0");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("H");
            lineMessage.setText("The Power of Prepaid");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("N");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("E");
            lineMessage.setText("Test Printer");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("E");
            lineMessage.setText("Voucher");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("N");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("E");
            lineMessage.setText("Vodacom-R12 Voucher");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("H");
            lineMessage.setText("How to Recharge:");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("H");
            lineMessage.setText("-Dial*100*01*PIN# and 'Call'");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("N");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("E");
            lineMessage.setText("PIN");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("E");
            lineMessage.setText("1234 5678 9012 3456 7890");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("A");
            lineMessage.setText("Amount  :                  12.00");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("A");
            lineMessage.setText("Serial  :            12516175050");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("A");
            lineMessage.setText("Ref     :              146922960");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("A");
            lineMessage.setText("Date    :    16/02/2018 12:02:42");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("A");
            lineMessage.setText("Cashier :             Supervisor");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("N");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("H");
            lineMessage.setText("Customer Care: Dial 114");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("P");
            lineMessage.setText("6006986000618");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("H");
            lineMessage.setText("- Print Done -");
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("O");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            lineMessage = new CommonResponseLineMessage();
            lineMessage.setF("Z");
            lineMessage.setText(null);
            testPrint.add(lineMessage);

            if (isDebug()) {
                printWithDynamic(testPrint, true);
            } else {
                print(testPrint);
            }
            Log.d(TAG, "called print");
        } catch (Exception exception) {
            Log.d(TAG, "problems printing");
            logger.error("problems printing " + exception);
            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, "There was a problem while testing the Printer, Please contact support for help", true);
        }
    }

    void testDynamicPrint() {
        boolean exit = false;
        ArrayList<CommonResponseLineMessage> lines = new ArrayList<>();
        lines.add(printLine("E", "Test Dynamic Prints"));

        try {
            String cached = getCachedDynamicPrint();
//            String cached = loadJSONFromAsset("dynamic2.json");
            JSONArray array = null;
            if (cached != null && !cached.isEmpty()) {
                array = new JSONArray(cached);
                lines.add(printLine("H", "Number cached  : " + array.length()));
                exit = array.length() == 0;
            } else {
                exit = true;
                lines.add(printLine("H", "No Dynamic Prints available"));
            }


            smartPrinter.print(null, lines, null, exit);
            if (!exit) {
                DynamicPrintInfo info = new DynamicPrintInfo(this);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject obj = array.getJSONObject(i);
                    lines.clear();
                    lines.add(printLine("E", "================"));
                    lines.add(printLine("O", "ID: " + obj.getString("id")));
                    lines.add(printLine("O", "Start: " + obj.getString("start")));
                    lines.add(printLine("O", "End: " + obj.getString("end")));
                    lines.add(printLine("O", "Max: " + obj.getString("max")));
                    lines.add(printLine("O", "Count: " + info.getCount(obj.getString("id"))));
                    smartPrinter.print(null, lines, null, false);
                    smartPrinter.print(obj.getJSONArray("print"));
                }
            }

        } catch (Exception e) {
            createAlertDialog("Error", "An error occurred: " + e.getLocalizedMessage());
        }
    }

    void printTestBarcode() {
        try {
            String line = "1234567890";

            int barcodeWidth = printWidth * 12;

            if (!Build.MODEL.contains("CITAQ POS") && printWidth != 42) {
                barcodeWidth = printWidth * 17;
            }

            String specialChar = ";";
            String barcodeText = "1234567890;";
            String printableBarcode = barcodeText.substring(0, barcodeText.indexOf(specialChar));

            Bitmap barcode = generateBarcode("itf", printableBarcode, barcodeWidth, BARCODE_HEIGHT_EAN_13);

            ArrayList<String> tmp = new ArrayList<>();

            tmp.add("");
            tmp.add("Please Scan the test barcode below");

            smartPrinter.print(bluLogo, tmp, barcode, center(line));

        } catch (Exception ex) {
            Log.d(TAG, ex.getMessage());
        }
    }

    void testSecureUSBPrinter() {
        isTesting = true;
        byte[] bytes = new byte[0];

        try {
            BufferedInputStream buf = new BufferedInputStream(getAssets().open("e84f6f82-484b-62ff-140d-5a449f0743ce.ezpl"));

            int size = buf.available();
            bytes = new byte[size];

            buf.read(bytes, 0, bytes.length);
            buf.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            createAlertDialog("Test Secure USB PRINTER", "FILE NOT FOUND.");
            logger.error("testSecureUSBPrinter " + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("testSecureUSBPrinter " + e.getMessage());
        }

        if (bytes.length > 0) {
            securePrint(bytes);
        } else {
            logger.error("Problem With Test EZPL Ticket");
            createAlertDialog("Test Secure USB PRINTER", "There seems to be a problem with the test ticket, Please contact support for help.");
        }
    }

    public void printElectricityVoucher() {
        Log.v(TAG, "printVoucher");
        try {
            createProgress(R.string.printingVoucher);

            ElectricityVoucherRequestFactory factory = new ElectricityVoucherRequestFactory();

            ElectricityVoucherRequestPrintedMessage request = factory.printed(electricityVoucherResponseMessage);
            Log.v(TAG, request.toString());
            startAEONAsyncTask(this, socket, request);
            Log.v(TAG, "executed");

        } catch (Exception exception) {
            Log.v(TAG, "printVoucher exception " + exception);
            logger.error("printVoucher exception " + exception);
        }
    }

    public void authenticateWithTicketPro() {
        Log.d("MPK", "authWithTp BaseActivity");

        try {
            //temporary Fix for bug in tickets
            doPuctoStuff = true;
            createProgress(R.string.authenticating);
            //
            // authenticate with ticketpro
            //
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProAuthenticationRequestMessage ticketProAuthenticationRequestMessage =
                    factory.create(loginResponseMessage.getData().getUserPin(),
                            getPreference(PREF_DEVICE_ID),
                            getPreference(PREF_DEVICE_SER));
            if (completeConsumerProfile != null) {
                ticketProAuthenticationRequestMessage.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, ticketProAuthenticationRequestMessage);

        } catch (Exception exception) {
            Log.v(TAG, "authenticate with ticketpro " + exception);
            logger.error("authenticate with ticketpro " + exception);
        }
    }

    public boolean putcoAuthenticationRequired(Date cachedDate, CommonResponseMessage msg, Boolean needsRoute,
                                               Boolean needsDepartures, Boolean needsDestinations) {
        Date now = new Date();
        Log.d(TAG, "date of last putco cache " + cachedDate);
        Log.d(TAG, "putcoAuthenticationRequired, busy with class: " + msg);
        if ((now.getTime() - cachedDate.getTime()) > CACHE_12_HOURS || msg == null) {
            needRoute = needsRoute;
            needDepartures = needsDepartures;
            needDestinations = needsDestinations;
            authenticateWithTicketPro();
            return true;
        }
        return false;
    }

    private TicketProResponseAllLocationsMessage getCachedPutcoAllLocationsData() {
        try {
            createDirsIfNecessary();
            File file = new File(putcoCacheDir.getPath() + "/putcoalllocationsdata.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            TicketProResponseAllLocationsMessage msg = new TicketProResponseAllLocationsMessage();
            msg.getEvent().setEventCode("0");
            msg.setData((TicketProResponseAllLocationsDataMessage)
                    xmlProcessor.unmarshal(line, TicketProResponseAllLocationsDataMessage.class));
            return msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading putco all locations cache " + exception);
            logger.error("problems reading putco all locations cache " + exception);
        }
        return null;
    }

    private Date dateLastPutcoAllLocationsCache() {
        return dateLastCache(putcoCacheDir, "putcoalllocationsdata.txt");
    }

    public Date dateLastPutcoPossibleDestinationsCache(String departure) {
        return dateLastCache(putcoCacheDir, departure + ".txt");
    }

    private void cachePutcoPossibleDestinationsData(String departure, TicketProResponseAllLocationsMessage message) {
        try {
            File cache = new File(putcoCacheDir.getPath() + "/" + departure + ".txt");
            if (isCachingRequired(cache)) {
                writeCacheDataToFile(cache, message.getData());
            }
        } catch (Exception exception) {
            Log.d(TAG, "marshaling exception " + exception);
            logger.error("marshaling exception " + exception);
        }
    }

    public TicketProResponsePossibleDestinationsMessage getCachedPutcoPossibleDestinationsData(String departure) {
        try {
            createDirsIfNecessary();
            File file = new File(putcoCacheDir.getPath() + "/" + departure + ".txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            TicketProResponsePossibleDestinationsMessage msg = new TicketProResponsePossibleDestinationsMessage();
            msg.getEvent().setEventCode("0");
            msg.setData((TicketProResponseAllLocationsDataMessage)
                    xmlProcessor.unmarshal(line, TicketProResponseAllLocationsDataMessage.class));
            return msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading putco all locations cache " + exception);
            logger.error("problems reading putco all locations cache " + exception);
        }
        return null;
    }

    public void requestAllPutcoLocationsList() {
        try {
            Log.d(TAG, "requestAllLocationsList executing");
            //
            // only get the voucher list if the current
            // cached list is more than N seconds old
            //
            ticketProResponseAllLocationsMessage = getCachedPutcoAllLocationsData();
            if (!putcoAuthenticationRequired(dateLastPutcoAllLocationsCache(),
                    ticketProResponseAllLocationsMessage,
                    false, true, false)) {
                results(ticketProResponseAllLocationsMessage);
            }
        } catch (Exception exception) {
            Log.d(TAG, "requestAllLocationsList throws " + exception);
        }
    }

    private void cachePutcoAllLocationsData(TicketProResponseAllLocationsMessage message) {
        try {
            File cache = new File(putcoCacheDir.getPath() + "/putcoalllocationsdata.txt");
            if (isCachingRequired(cache)) {
                writeCacheDataToFile(cache, message.getData());
            }
        } catch (Exception exception) {
            Log.d(TAG, "marshaling exception " + exception);
        }
    }

    private void getPutcoDepartures() {
        try {
            createProgress(R.string.gettingPutcoDepartures);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestAllLocationsMessage request = factory.createAllLocations(ticketProAuthenticationResponseMessage);
            startAEONAsyncTask(this, socket, request);

        } catch (Exception exception) {
            Log.v(TAG, "authenticate with ticketpro " + exception);
        }
    }

    private void getPutcoRoute() {
        try {
            createProgress(R.string.gettingPutcoRoutes);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestRouteMessage request;
            if (routeCode.trim().isEmpty()) {
                request = factory.createRoute(
                        ticketProAuthenticationResponseMessage,
                        departureId, destinationId);
            } else {
                request = factory.createRoute(
                        ticketProAuthenticationResponseMessage,
                        routeCode);
            }
            startAEONAsyncTask(this, socket, request);

        } catch (Exception exception) {
            Log.v(TAG, "authenticate with ticketpro " + exception);
        }
    }

    private void getPutcoDestinationas() {
        try {
            createProgress(R.string.gettingPutcoDestinations);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestPossibleDestinationsMessage request = factory.createPossibleDestinations(
                    ticketProAuthenticationResponseMessage,
                    departureId);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticate with ticketpro " + exception);
        }
    }

    public void searchRoutes(String selection) {
        try {
            //
            // find the ID of this destination
            //
            destinationId = "";
            for (int i = 0; i < ticketProResponsePossibleDestinationsMessage.getData().getLocations().size(); i++) {
                if (selection.equals(
                        ticketProResponsePossibleDestinationsMessage.getData().getLocations().get(i).getName())) {
                    destinationId = ticketProResponsePossibleDestinationsMessage.getData().getLocations().get(i).getId();
                    break;
                }
            }
            //
            // now request destinations for this departure
            //
            dismissProgress();

            needRoute = true;
            needDepartures = false;
            needDestinations = false;
            authenticateWithTicketPro();

        } catch (Exception exception) {
            Log.d(TAG, "searchRoutes exception " + exception);
        }
    }

    public void createPutcoCart() {
        try {
            createProgress(R.string.creatingCart);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestPutcoCreateCartMessage request = factory.putcoCreateCart(ticketProAuthenticationResponseMessage);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticate with ticketpro " + exception);
        }
    }

    private void buyPutcoTicket(String cellNumber) {
        try {
            createProgress(R.string.gettingTickets);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            Log.d(TAG, "LB start CheckOut " + (new Date()).getTime());
            TicketProRequestPutcoCheckOutMessage request = factory.putcoCheckOut(ticketProAuthenticationResponseMessage,
                    ticketProResponsePutcoCreateCartMessage,
                    cellNumber, "", "", "", "");
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticate with ticketpro " + exception);
        }

    }

    private void payPutcoTicket(String paymentMethod) {
        try {
            createProgress("paying Putco ticket");
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestPutcoPaymentMessage request = factory.putcoPayment(
                    ticketProAuthenticationResponseMessage,
                    ticketProResponsePutcoCheckOutMessage.getData().getTransactionId(),
                    ticketProResponsePutcoCheckOutMessage.getData().getBalance(),
                    paymentMethod,
                    "");  //binNo doesn't seem to be used
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticate with ticketpro " + exception);
        }

    }

    private void printPutcoTicket() {
        try {
            createProgress(R.string.gettingTickets);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestPutcoPrintMessage request = factory.putcoPrint(ticketProResponsePutcoPaymentMessage);
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "authenticate with ticketpro " + exception);
        }

    }


    public void startPutcoCompleteTrx(String cellPhone, int routeIndex, int quantity) {
        Log.d("FragmentPutco", "startPutcoCompleteTrx " + cellPhone + " " + routeIndex + " " + quantity);
        CheckPrinter checkPrinter = new CheckPrinter(this);
        checkPrinter.execute(cellPhone, String.valueOf(routeIndex), String.valueOf(quantity));
    }

    public void handlePrintCheckResult(String[] params, int result, String printError) {
        dismissProgress();
        String title, message;
        Log.d("FragmentPutco", "params=" + Arrays.toString(params) + " result=" + result);
        switch (result) {
            case 0:
                doPutcoCompleteTrx(params[0], Integer.parseInt(params[1]), Integer.parseInt(params[2]));
                return;
            case 1:
                title = "USB Printer Error";
                message = "Unable to communicate with the USB printer: " + printError;
                break;
            case 2:
                title = "USB Printer Paper check failed";
                message = "USB Printer Error: " + printError;
                break;
            default:
                title = "USB Printer Error";
                message = "Unable to communicate with the USB printer, please restore communication before continuing";
                break;
        }
        createAlertDialog(title, message);
    }

    private void doPutcoCompleteTrx(String cellPhone, int routeIndex, int quantity) {
        try {

            createProgress(R.string.bookingTickets);
            TicketProRequestFactory factory = new TicketProRequestFactory();
            ArrayList<TicketProRequestRouteAndQuantityMessage> routesAndQuantities;
            routesAndQuantities = new ArrayList<>();

            TicketProRequestRouteAndQuantityMessage routeAndQuantity = new TicketProRequestRouteAndQuantityMessage();
            routeAndQuantity.setId(ticketProResponseRouteMessage.getData().getRoutes().get(routeIndex).getRouteId());
            routeAndQuantity.setQuantity("" + quantity);
            routesAndQuantities.add(routeAndQuantity);

            TicketProRequestPutcoDoCompleteTrxMessage request = factory.putcoDoCompleteTrx(ticketProAuthenticationResponseMessage,
                    routesAndQuantities, //LB
                    paymentType,
                    cellPhone.trim(),
                    "", //name
                    "", //surname
                    "", //vendorOutletId
                    "", //vendorOutletName
                    ""); //binNo
            Log.d(TAG, "LB starting DoCompleteTrx " + (new Date()).getTime());
            startAEONAsyncTask(this, socket, request);

            Log.d(TAG, "booking started");
            Log.d(TAG, request.toString());

        } catch (Exception exception) {
            Log.d(TAG, "bookRoute throws " + exception);
        }
    }

    private void autoCancelPutcoTicket() {
        try {
            Log.d(TAG, "sending2 TicketProRequestPutcoAutoCancelMessage");
            createProgress("Cancelling Putco Ticket");
            TicketProRequestFactory factory = new TicketProRequestFactory();
            TicketProRequestPutcoAutoCancelMessage request = factory.doPutcoTicketAutoCancel(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER), ticketProResponsePutcoDoCompleteTrxMessage.getData().getTransRef(), ticketProResponsePutcoDoCompleteTrxMessage.getData().getReference());
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "autoCancelPutcoTicket " + exception);
        }

    }

    private void printPutcoMerchantReceipt() {
        if (getPreference(PREF_PRINT_MERCHANT_VOUCHER_TICKETS).equals(PREF_TRUE)) {
            print(ticketProResponsePutcoDoCompleteTrxMessage.getData().getMerchantPrintLines());

//            try {
//                Log.v(TAG, "printing merchant voucher");
//                ArrayList<CommonResponseLineMessage> merchantReceipt = new ArrayList<>();
//                merchantReceipt.add(printLine("H", format("Merchant Receipt", "")));
//                merchantReceipt.add(printLine("O", format("Device ID", getPreference(PREF_DEVICE_ID))));
//                merchantReceipt.add(printLine("O", format("Shift No.", ticketProResponsePutcoDoCompleteTrxMessage.getData().getShiftId())));
//                merchantReceipt.add(printLine("O", format("Sequence No.", ticketProResponsePutcoDoCompleteTrxMessage.getData().getTransSeq())));
//                merchantReceipt.add(printLine("O", format("Product",
//                        getResources().getString(R.string.putco).toUpperCase() + " " + ticketProResponsePutcoDoCompleteTrxMessage.getData().getReference().toUpperCase())));
//                merchantReceipt.add(printLine("O", format("Amount", formatMoney(ticketProResponsePutcoDoCompleteTrxMessage.getData().getBalance()))));
//                merchantReceipt.add(printLine("O", format("Trans Ref", ticketProResponsePutcoDoCompleteTrxMessage.getData().getTransRef())));
//                merchantReceipt.add(printLine("O", format("Date", todaysDateAndTime())));
//                merchantReceipt.add(printLine("O", format("Cashier", loginResponseMessage.getData().getUserName())));
//                merchantReceipt.add(printLine("O", format("Tender Type", paymentType)));
//                merchantReceipt.add(printLine("N", ""));
//                merchantReceipt.add(printLine("H", getResources().getString(R.string.printDone)));
//
//                print(merchantReceipt);
//                Log.v(TAG, "printed");
//            } catch (Exception exception) {
//                Log.v(TAG, "problem with merchant receipt " + exception);
//            }
        }
    }

    private void printBusTicketsMerchantReceipt() {
        if (getPreference(PREF_PRINT_MERCHANT_VOUCHER_TICKETS).equals(PREF_TRUE)) {
            print(carmaResponseCompleteBookingMessage.getData().getMerchantPrintLines());
        }
    }

    private void printTicketProMerchantReceipt(boolean isSecurePrint) {
        if (getPreference(PREF_PRINT_MERCHANT_VOUCHER_TICKETS).equals(PREF_TRUE)) {
            if (isSecurePrint) {
                print(ticketProResponsePrintEZPLMessage.getData().getMerchantPrintLines());
            } else {
                print(ticketProResponsePrintMessage.getData().getMerchantPrintLines());
            }
        }
    }

    private void printReceipt() {
        try {
            Log.v(TAG, "printing customer voucher");
            ArrayList<CommonResponseLineMessage> receipt = new ArrayList<>();
            receipt.add(printLine("O", format("Receipt", "")));
            receipt.add(printLine("N", ""));
            receipt.add(printLine("O", format("Date", todaysDateAndTime())));
            receipt.add(printLine("O", format("Cashier", loginResponseMessage.getData().getUserName())));
            receipt.add(printLine("N", ""));
            receipt.add(printLine("O", format(
                    getResources().getString(R.string.putco).toUpperCase() + " " +
                            //ticketProResponsePutcoCheckOutMessage.getData().getReference().toUpperCase(),
                            //formatMoney(ticketProResponsePutcoCheckOutMessage.getData().getBalance())
                            ticketProResponsePutcoDoCompleteTrxMessage.getData().getReference().toUpperCase(),
                    formatMoney(ticketProResponsePutcoDoCompleteTrxMessage.getData().getBalance())
            )));
            receipt.add(printLine("O", format("Tender Type", paymentType)));
            receipt.add(printLine("H", getResources().getString(R.string.printDone)));

            print(receipt);
            Log.v(TAG, "printed");
        } catch (Exception exception) {
            Log.v(TAG, "problem with merchant receipt " + exception);
        }
    }

    public void securePrint() {
        try {
            Log.d(TAG, "securePrint() ticket has " + ticket.length + " bytes");
            createProgress(R.string.printingTickets);
            BluDroidUSBPrint usbPrint;
            if (isRunningInEmulator()) {
                usbPrint = new BluDroidUSBPrint(this, ticket);
            } else {
                usbPrint = new BluDroidUSBPrint(this, ticket);
            }
            if (logger != null) {
                Log.d(TAG, "created USBPrint");
            }

            boolean hasPermission;

            do {
                hasPermission = usbPrint.hasPermission();
                if (hasPermission) {
                    Log.d(TAG, "has USB permissions");
                } else {
                    Log.d(TAG, "moving task to back and sleeping");
                    if (logger != null) {
                        logger.debug("need to get USB permissions");
                    }
                    moveTaskToBack(true);
                    Thread.sleep(5000);
                }
            } while (!hasPermission);

            Intent intent = new Intent(this, this.getClass());
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(intent);
            Log.d(TAG, "2-ticket is " + ticket.length + " bytes long");
            if (logger != null) {
                logger.debug("trying to print ticket of length " + ticket.length + " bytes");
            }
            usbPrint.print(ticket);
            Log.d(TAG, "unregistering receiver");
            usbPrint.unregisterReceiver();

        } catch (Exception exception) {
            Log.v(TAG, "exception while printing " + exception);
            if (logger != null) {
                logger.warn("Exception while printing " + exception);
            }
        }
    }

    public boolean checkUSBPrinter() {
        return checkUSBPrinter(false);
    }

    private boolean checkUSBPrinter(boolean checkPaperAvailable) {
        BluDroidUSBPrint usbPrint;
/*
          Let's first test the USB printer connectivity here before we go and book the tickets
          So that we can at least get this sorted before we continue and get an error when we
          need to actually print (might still happen, but should be the exception)
*/
        usbPrint = new BluDroidUSBPrint(this, ticket);

        try {
            if (!usbPrint.checkUSBReadyStatus()) {
//                createAlertDialog("USB Printer Error", "Unable to communicate with the USB printer: " + usbPrint.getUSBPrinterErrorString());
                createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorSecurePrinterComs, false);
                return false;
            }
            if (checkPaperAvailable) {
                if (!usbPrint.checkUSBPrinterPaperAvailable()) {
//                    createAlertDialog("USB Printer Paper check failed", "USB Printer Error: " + usbPrint.getUSBPrinterErrorString());
                    createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorSecurePrinterPaperCheck, false);
                    return false;
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "checkUSBPrinter Exception " + exception);
//            createAlertDialog("USB Printer Error","Unable to communicate with the USB printer, please restore communication before continuing");
            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorSecurePrinterComs, false);
            return false;
        } finally {
            usbPrint.unregisterReceiver();
        }
        return true;
    }

    private <K, V> HashMap<K, V> getHashMapFromFile(File fileName) {
        ObjectInputStream objInStream;
        HashMap<K, V> map;
        //
        // try catch added by LB because sometimes this throws a null pointer exception
        //
        try {
            objInStream = (new ObjectInputStream(new BufferedInputStream(new FileInputStream(fileName))));
            //noinspection unchecked
            map = (HashMap<K, V>) objInStream.readObject();
            objInStream.close();
        } catch (Exception exception) {
            map = new HashMap<>();
        }
        return map;
    }

    private <K, V> void writeHashMapToFile(File fileName, HashMap<K, V> object) throws IOException {
        ObjectOutputStream objOutStream;
        objOutStream = (new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(fileName))));
        objOutStream.writeObject(object);
        objOutStream.close();
    }

    private void saveUsbPrintResultsUntilAcked(String saveFileName, HashMap<String, String> resultsMap) {
        /*
            In order to implement a backoff strategy we will need to check if the result is already in the
            file, if true we then increment a call number that will be used to calculate based on the time when a
            message can be sent again
         */
        try {
            Log.d(TAG, "saveUsbPrintResultsUntilAcked");
            createDirsIfNecessary();
            File resultsFile = new File(privateDir.getPath() + "/" + saveFileName + ".txt");
            if (!resultsFile.exists()) {
                if (!resultsFile.createNewFile()) {
                    throw new IOException("Unable to create file " + resultsFile);
                }
            }

            writeHashMapToFile(resultsFile, resultsMap);
        } catch (Exception exception) {
            Log.d(TAG, "saveUsbPrintResultsUntilAcked throws " + exception);
        }
    }

    private String convertHex(String input) {
        StringBuilder sb = new StringBuilder();
        int length = input.length() / 2;
        for (int i = 0; i < length; i++) {
            String st = input.substring(i * 2, i * 2 + 2);
            int k = 16 * (st.charAt(0) - '0') + (st.charAt(1) - '0');
            sb.append((char) k);
        }
        return sb.toString();
    }

    public void removeTicketProItem(String seatID) {
        createProgress("Removing ticket from cart");
        TicketProRequestFactory factory = new TicketProRequestFactory();
        TicketProRequestClearCartMessage request = factory.createClearCart(
                ticketProAuthenticationResponseMessage,
                ticketProResponseCreateCartMessage,
                seatID);
        Log.v(TAG, "request is " + request);
        startAEONAsyncTask(this, socket, request);
    }

    private void checkPutcoAutoCancellStatus() {
        try {
            File[] notCancelledTicketsFiles = getNotCancelledTickets();
            if (notCancelledTicketsFiles.length > 0) {

                needsToRetryAutoCancel = true;
            }
        } catch (Exception ex) {
            logger.error("checkPutcoAutoCancellStatus " + ex);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (smartPrinter != null) {
            smartPrinter.terminate();
        }

        try {
            unregisterReceiver(brightnessReceiver);
        } catch (IllegalArgumentException ignore) {
        }

        String previousSkin = getPreference(PREF_PREVIOUS_SKIN);
        updatePreference(PREF_SKIN, previousSkin);

        dismissProgress();
        dismissAlert();
        dismissConfirmation();
    }

    @Override
    protected void onPause() {
        super.onPause();
        cancelTimer();
    }

    @Override
    public void onBackPressed() {
        if (!lockBackButton) {
            List<Fragment> fragmentList = baseFm.getFragments();

            boolean handled = false;

            if (!fragmentList.isEmpty()) {

                Fragment f = fragmentList.get(fragmentList.size() - 1);

                if (f instanceof FragmentAirtime) {
                    handled = ((FragmentAirtime) f).onBackPressed();

                } else if (f instanceof FragmentData) {
                    handled = ((FragmentData) f).onBackPressed();

                } else if (f instanceof FragmentElectricity) {
                    handled = ((FragmentElectricity) f).onBackPressed();

                } else if (f instanceof FragmentVouchersMenu) {
                    handled = ((FragmentVouchersMenu) f).onBackPressed();

                } else if (f instanceof FragmentTransact) {
                    handled = ((FragmentTransact) f).onBackPressed();

                } else if (f instanceof FragmentTransactAccounts) {
                    handled = ((FragmentTransactAccounts) f).onBackPressed();

                } else if (f instanceof FragmentTransactTrafficFines) {
                    handled = ((FragmentTransactTrafficFines) f).onBackPressed();

                } else if (f instanceof FragmentTransactBillPaymentBluBill) {
                    handled = ((FragmentTransactBillPaymentBluBill) f).onBackPressed();

                } else if (f instanceof FragmentTransactBillPaymentSapo) {
                    handled = ((FragmentTransactBillPaymentSapo) f).onBackPressed();

                } else if (f instanceof FragmentTransactBillPaymentPayAt) {
                    handled = ((FragmentTransactBillPaymentPayAt) f).onBackPressed();

                } else if (f instanceof FragmentTransactBillPaymentSyntell) {
                    handled = ((FragmentTransactBillPaymentSyntell) f).onBackPressed();

                } else if (f instanceof FragmentTransactMerchantToMerchantTransfer) {
                    handled = ((FragmentTransactMerchantToMerchantTransfer) f).onBackPressed();

                } else if (f instanceof FragmentTransactTrafficFinesPayAt) {
                    handled = ((FragmentTransactTrafficFinesPayAt) f).onBackPressed();

                } else if (f instanceof FragmentTransactTrafficFinesSyntell) {
                    handled = ((FragmentTransactTrafficFinesSyntell) f).onBackPressed();

                } else if (f instanceof FragmentRicaLogin) {
                    handled = ((FragmentRicaLogin) f).onBackPressed();

                } else if (f instanceof FragmentRicaRegister) {
                    handled = ((FragmentRicaRegister) f).onBackPressed();

                } else if (f instanceof FragmentConfirmConfigFavourites) {
                    handled = ((FragmentConfirmConfigFavourites) f).onBackPressed();

                } else if (f instanceof FragmentFavourites) {
                    handled = ((FragmentFavourites) f).onBackPressed();

                } else if (f instanceof FragmentVouchers) {
                    handled = ((FragmentVouchers) f).onBackPressed();

                } else if (f instanceof FragmentEskomElectricity) {
                    handled = ((FragmentEskomElectricity) f).onBackPressed();

                } else if (f instanceof FragmentEskomAccounts) {
                    handled = ((FragmentEskomAccounts) f).onBackPressed();

                } else if (f instanceof FragmentIthubaMenu) {
                    handled = ((FragmentIthubaMenu) f).onBackPressed();

                } else if (f instanceof FragmentIthubaQPick) {
                    handled = ((FragmentIthubaQPick) f).onBackPressed();

                } else if (f instanceof FragmentIthubaPSelect) {
                    handled = ((FragmentIthubaPSelect) f).onBackPressed();

                } else if (f instanceof FragmentIthubaNumberSelection) {
                    handled = ((FragmentIthubaNumberSelection) f).onBackPressed();

                } else if (f instanceof FragmentRicaMenu) {
                    handled = ((FragmentRicaMenu) f).onBackPressed();

                } else if (f instanceof FragmentTickets) {
                    handled = ((FragmentTickets) f).onBackPressed();

                } else if (f instanceof FragmentPutco) {
                    handled = ((FragmentPutco) f).onBackPressed();

                } else if (f instanceof FragmentCarmaSearchRoutesNew) {
                    handled = ((FragmentCarmaSearchRoutesNew) f).onBackPressed();

                } else if (f instanceof FragmentBusTicketCancellations) {
                    handled = ((FragmentBusTicketCancellations) f).onBackPressed();

                } else if (f instanceof FragmentCarmaSearchResults) {
                    handled = ((FragmentCarmaSearchResults) f).onBackPressed();

                } else if (f instanceof FragmentCarmaPassengerDetailsWizard) {
                    handled = ((FragmentCarmaPassengerDetailsWizard) f).onBackPressed();

                } else if (f instanceof FragmentCarmaConfirmPurchaseTicketNew) {
                    handled = ((FragmentCarmaConfirmPurchaseTicketNew) f).onBackPressed();

                } else if (f instanceof FragmentBusTicketsReprints) {
                    handled = ((FragmentBusTicketsReprints) f).onBackPressed();

                } else if (f instanceof FragmentTicketProCategories) {
                    handled = ((FragmentTicketProCategories) f).onBackPressed();

                } else if (f instanceof FragmentTicketProEvents) {
                    handled = ((FragmentTicketProEvents) f).onBackPressed();

                } else if (f instanceof FragmentTicketProEventDetails) {
                    handled = ((FragmentTicketProEventDetails) f).onBackPressed();

                } else if (f instanceof FragmentTicketProPriceCategory) {
                    handled = ((FragmentTicketProPriceCategory) f).onBackPressed();

                } else if (f instanceof FragmentTicketProViewCart) {
                    handled = ((FragmentTicketProViewCart) f).onBackPressed();

                } else if (f instanceof FragmentTicketProPayment) {
                    handled = ((FragmentTicketProPayment) f).onBackPressed();

                } else if (f instanceof FragmentTicketProReprint) {
                    handled = ((FragmentTicketProReprint) f).onBackPressed();

                } else if (f instanceof FragmentChatForChange) {
                    handled = ((FragmentChatForChange) f).onBackPressed();

                } else if (f instanceof FragmentNFCGetConsumerProfile) {
                    handled = ((FragmentNFCGetConsumerProfile) f).onBackPressed();

                } else if (f instanceof FragmentNFCCustomerRegistration) {
                    handled = ((FragmentNFCCustomerRegistration) f).onBackPressed();

                } else if (f instanceof FragmentNFCEditCustomerProfile) {
                    handled = ((FragmentNFCEditCustomerProfile) f).onBackPressed();

                } else if (f instanceof FragmentSearch) {
                    handled = ((FragmentSearch) f).onBackPressed();

                } else if (f instanceof FragmentMenu) {
                    handled = ((FragmentMenu) f).onBackPressed();
                }
            }

            if (!handled) {
                if (isConsumerProfileActive()) {
                    clearNFCActiveConsumer(true);
                } else {
                    alert = exitApplicationDialog("Exit Application", "Are you sure you want to close this activity?");

                    alert.setPositiveOption(getString(R.string.exit), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Log.d(TAG, "Exit: User confirmed exit, calling logout");
                            firebaseSessionEnd("manual");
                            logout();
                        }
                    });

                    alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            alert.dismiss();
                        }
                    });

                    alert.show();
                }
            }
        }
    }

    public void startAEONAsyncTask(Object screenFrag, Object... objs) {
        boolean isFragment = false;
        if (screenFrag instanceof BaseFragment) {
            isFragment = true;
        } else if (!(screenFrag instanceof BaseActivity)) {
            logger.error("Error in startAEONAsyncTask, initialized by " + screenFrag);
            return;
        }

        String requestName = objs.length == 1 ? objs[0].getClass().getSimpleName() : objs[1].getClass().getSimpleName();
        connectedToAEON = true;
        if (asyncTask == null) {
            Log.d("AeonAsyncTask", "startAEONAsyncTask for " + screenFrag.getClass().getSimpleName() + " : " + requestName + "****asyncTask = null");
        } else {
            Log.d("AeonAsyncTask", "startAEONAsyncTask for " + screenFrag.getClass().getSimpleName() + " : " + requestName + "****asyncTask = " + asyncTask.getTaskStatus());

            int count = 0;
            while (asyncTask.getTaskStatus() != AEONAsyncTask.Status.FINISHED && count++ < 30) {
                Log.d("AeonAsyncTask", "****waiting for asyncTask to finish..." + asyncTask.getTaskStatus());
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ie) {
                    ie.printStackTrace();
                }
            }
            if (count >= 30) {
                logger.error("AEONAsyncTask not finished, new request " + requestName);
                createCommunicationErrorConfirmation();
                return;
            }
        }

        asyncTask = isFragment ? new AEONAsyncTask((BaseFragment) screenFrag) : new AEONAsyncTask((BaseActivity) screenFrag);

        if (objs.length == 1) {
            Object obj = objs[0];
            asyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, screenFrag, obj);
        } else if (objs.length == 2) {
            Object obj0 = objs[0];
            Object obj1 = objs[1];
            asyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, screenFrag, obj0, obj1);
        } else {
            Log.d(TAG, "unprepared for this portion of the code");
        }
        lockBackButton = true;
    }

    public void hideKeyboard() {
        // Check if no view has focus:
        View view = this.getCurrentFocus();
        if (view != null) {
            hideKeyboardFromView(view);
        }
    }

    public void hideKeyboardFromView(View view) {
        InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS ^ InputMethodManager.HIDE_IMPLICIT_ONLY);
    }

    public void showKeyboard() {
        // Check if no view has focus:
        View view = this.getCurrentFocus();
        //Log.d(TAG, "view is " + view);
        //
        // do not automatically bring up the keyboard for TPS390
        //
        if (view != null) {
            try {
                InputMethodManager inputManager = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
                if (Build.MODEL.equals("TPS390")) {
                    inputManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                } else {
                    inputManager.showSoftInput(view, InputMethodManager.SHOW_FORCED);
                }
            } catch (Exception exception) {
                Log.d(TAG, "showKeyboard throwing " + exception);
            }
        }
    }

    public int getDrawableResource(String drawableName) {
        return getResources().getIdentifier(drawableName.toLowerCase(), "drawable", getPackageName());
    }

    public String getBillPayLogoId(String name) {
        if (billPaymentsResponseProductListMessage == null) {
            billPaymentsResponseProductListMessage = getCachedBillPaymentData();
        }
        if (billPaymentsResponseProductListMessage != null) {
            for (BillPaymentsResponseProviderMessage provider : billPaymentsResponseProductListMessage.getData().getProviders()) {
                for (BillPaymentsResponseProductMessage product : provider.getProducts()) {
                    if (product.getName().equals(name)) {
                        return product.getLogoId();
                    }
                }
            }
        }
        return null;
    }

    public int getColourResource(String colorName) {
        int resource = 0xffffff;
        try {
            resource = getResources().getColor(getResources().getIdentifier(colorName.toLowerCase(), "color", getPackageName()));
        } catch (Exception ignore) {
        }
        return resource;
    }

    public String getShortName(String product) {
        String shortName;
        if (product.contains("DSTV")) {
            shortName = "dstv";
        } else if (product.contains("Avon")) {
            shortName = "avon";
        } else if (product.contains("Telkom")) {
            shortName = "telkommobile";
        } else if (product.contains("Eskom")) {
            shortName = "eskom";
        } else if (product.contains("Mukuru")) {
            shortName = "mukuru";
        } else if (product.contains("HomeChoice")) {
            shortName = "homechoice";
        } else if (product.contains("Jo'burg") || product.contains("Johannesburg")) {
            shortName = "joburg";
        } else if (product.contains("Tshwane")) {
            shortName = "tshwane";
        } else if (product.contains("Emalahleni")) {
            shortName = "emalahleni";
        } else if (product.contains("Cape Town")) {
            shortName = "coc";
        } else if (product.contains("Emfuleni")) {
            shortName = "emfuleni";
        } else if (product.contains("Matlosana")) {
            shortName = "matlosana";
        } else if (product.contains("Msunduzi")) {
            shortName = "msunduzi";
        } else if (product.contains("Nelson Mandela")) {
            shortName = "nelson";
        } else if (product.contains("EcoCash")) {
            shortName = "ecocash";
        } else if (product.contains("Mama Money")) {
            shortName = "mamamoney";
        } else if (product.contains("Hello Paisa")) {
            shortName = "hellopaisa";
        } else {
            shortName = product.replace(" ", "").toLowerCase();
        }
        return shortName;
    }

    private String getDrawableName() {
        String skin = sharedPreferences.getString(PREF_SKIN, getResources().getString(R.string.skinDEF));
        String drawableName = "blulogo";
//    String drawableName = "phanda_gif";

        if (skin.equals(getResources().getString(R.string.skinGCRS))) {
            drawableName = "glocell_logo";
        }

        Log.d(TAG, "print logo for: " + supplierName);

//        if (gettingMvnoVoucher) {
//            Log.d(TAG, "print logo for mvno: " + supplierName);
        if (supplierName.toLowerCase().contains("ticketpro")) {
            drawableName = "ticketpro";
        }

        if (supplierName.toLowerCase().contains("lycamobile")) {
            drawableName = "lycamobile_logo";
        } else if (supplierName.toLowerCase().contains("ringas")) {
            drawableName = "ringas_logo";
        } else if (supplierName.toLowerCase().contains("advinne")) {
            drawableName = "advinne_logo";
        } else if (supplierName.toLowerCase().contains("unlimited")) {
            drawableName = "theunlimited_logo";
        } else if (supplierName.toLowerCase().contains("fnbconnect")) {
            drawableName = "fnb_logo";
        } else if (supplierName.toLowerCase().contains("myair")) {
            drawableName = "mvnx_logo";
        }
//        } else if (gettingCarmaTicket) {
//            Log.d(TAG, "print logo for busses: " + supplierName);
        if (supplierName.equalsIgnoreCase("ec")) {
            drawableName = "eldo_logo";
        } else if (supplierName.equalsIgnoreCase("c8")) {
            drawableName = "citytocity_logo";
        } else if (supplierName.equalsIgnoreCase("l6")) {
            drawableName = "translux_logo";
        } else if (supplierName.equalsIgnoreCase("im")) {
            drawableName = "intercape_logo";
        }
//        } else
        if (isLotto) {
            Log.d(TAG, "print logo for lotto");
            drawableName = "phanda_gif";
        }

        if (Build.MODEL.startsWith("CITAQ") || Build.MODEL.startsWith("N3")) {
            drawableName += "_large";
        }
        return drawableName;
    }

    private void getApkFromFdroid(String name) {
        try {
            String repoHost = getPreference(PREF_FDROID_REPO_URL);
            Log.d(TAG, "repoHost = " + repoHost);
            if (!repoHost.isEmpty()) {

                Toast.makeText(this, "Downloading APK, you will be notified when download is complete", Toast.LENGTH_LONG).show();

                HTTPGetAsyncTask httpGetAsyncTask = new HTTPGetAsyncTask(this);
                //String url = (getPreference(PREF_FDROID_REPO_SSL).equals(PREF_TRUE)) ? "https://" : "http://";
                String url = getPreference(PREF_FDROID_REPO_URL);

                url = url.concat(getPreference(PREF_FDROID_REPO_DIR) + name);

                httpGetAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, this, url);
                Log.v(TAG, "url = " + url);
                Log.v(TAG, "started HTTPGetAsyncTask");
            }

        } catch (Exception exception) {
            Log.d(TAG, "problems with APK HTTPGet " + exception);
        }
    }

    void getFdroidIndex() {
        try {
            checkingVersion = true;
            newVersionAvailable = null;
            createProgress("Checking for updates...");
            String repoHost = getPreference(PREF_FDROID_REPO_URL).trim();
            if ((newVersionAvailable == null) && (!repoHost.isEmpty())) {
                HTTPGetAsyncTask getAsyncTask = new HTTPGetAsyncTask(this);
                //String url = (getPreference(PREF_FDROID_REPO_SSL).equals(PREF_TRUE) ? "https://" : "http://");
                String url = getPreference(PREF_FDROID_REPO_URL);

                if (Build.MODEL.contains("P1"))
                    url = url.concat(getPreference(PREF_FDROID_REPO_DIR) + "p1-index.xml");
                else
                    url = url.concat(getPreference(PREF_FDROID_REPO_DIR) + "index.xml");

                Log.v(TAG, "fdroid index is at " + url);
                getAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, this, url);
                Log.v(TAG, "started HTTPGetAsyncTask");
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems with HTTPGet " + exception);
        }

    }

    private String getFdroidApkName() {
        if (fdroid != null) {
            for (int i = 0; i < fdroid.getApplications().size(); i++) {
                String id = fdroid.getApplications().get(i).getId();
//                if (id.equals("za.co.blts.bltandroidgui3")) {
                if (id.equals(getApplicationId())) {
                    return fdroid.getApplications().get(i).getPackage().getApkName();
                }
            }
        }
        return "";
    }

    private void saveApk(String name, byte[] bytes) {
        try {
            //Log.d(TAG, "saveAPk with " + name);
            createDirsIfNecessary();

            File file = new File(downloadCacheDir.getPath() + "/" + name);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bytes);
            fos.flush();
            fos.close();
            //Log.d(TAG, "" + name + " saved");
        } catch (Exception exception) {
            Log.d(TAG, "problem saving downloaded apk " + exception);
        }
    }

    private void deleteOldApks() {
        try {
            File folder = new File(downloadCacheDir.getPath());
            File[] files = folder.listFiles();
            Arrays.sort(files, new Comparator<File>() {
                @Override
                public int compare(File f1, File f2) {
                    return Long.compare(f1.lastModified(), f2.lastModified());
                }
            });
            if (files.length > 5) {
                files[0].delete();

            }

        } catch (Exception ex) {
            logger.error("DeleteOld apks" + ex.toString());
        }
    }

    private void saveManual(byte[] bytes) {
        try {
            //Log.d(TAG, "saveAPk with " + name);
            createDirsIfNecessary();
            File file = new File(trainingDir.getPath() + "/Training.epub");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bytes);
            fos.flush();
            fos.close();
            //Log.d(TAG, "" + name + " saved");
        } catch (Exception exception) {
            Log.d(TAG, "problem saving downloaded apk " + exception);
        }
    }

    private void saveEpubReader(byte[] bytes) {
        try {
            //Log.d(TAG, "saveAPk with " + name);
            createDirsIfNecessary();
            File file = new File(trainingDir.getPath() + "/LithiumEPUBReader.apk");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bytes);
            fos.flush();
            fos.close();
            //Log.d(TAG, "" + name + " saved");
        } catch (Exception exception) {
            Log.d(TAG, "problem saving downloaded apk " + exception);
        }
    }

    private void saveFile(byte[] bytes, String fileName, String filePath) {
        try {
            //Log.d(TAG, "saveAPk with " + name);
            Log.d(TAG, "saveFile()");
            createDirsIfNecessary();
            File file = new File(filePath);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bytes);
            fos.flush();
            fos.close();
            //Log.d(TAG, "" + name + " saved");
            logger.info("Done saving " + fileName);
        } catch (Exception exception) {
            logger.error("saveFile " + exception);
        }
    }

    List<MagCardData> getMagCardUpdateByVoucher(ElectricityVoucherResponseDataMessage voucher) {
        List<MagCardData> listCardUpdate = new ArrayList<>();
        MagCardData cardUpdate = new MagCardData();

        ElectricityVoucherResponseMeterMessage meter = new ElectricityVoucherResponseMeterMessage();
        meter.setMeterNum(voucher.getMeter().getMeterNum());
        meter.setSgc(voucher.getMeter().getSgc());
        meter.setTt(voucher.getMeter().getTt());
        meter.setTi(voucher.getMeter().getTi());
        meter.setAlg(voucher.getMeter().getAlg());
        meter.setKrn(voucher.getMeter().getKrn());

        String track2 = formatTrack2(meter);

        cardUpdate.setTrack2(track2);

        //magcard.sendWriteCommand();

        listCardUpdate.add(cardUpdate);
        Log.d("MAgCARD", track2);
        return listCardUpdate;
    }

    List<MagCardData> getMagCardTokens(ElectricityVoucherResponseDataMessage voucher) {
        List<MagCardData> magList = new ArrayList<>();

        if (voucher.getPrintMagCard().equals("true")) {
            if (voucher.getMeter().getTt().equals("01")) {

                for (ElectricityVoucherResponseTokenMessage t : voucher.getBsstTokens()) {
                    MagCardData bsstCard = new MagCardData();
                    bsstCard.setTrack2(formatTrack2(voucher.getMeter()));
                    bsstCard.setTrack3(t.getNumber());
                    magList.add(bsstCard);
                }

                for (ElectricityVoucherResponseTokenMessage t : voucher.getTokens()) {
                    MagCardData paidCard = new MagCardData();
                    paidCard.setTrack2(formatTrack2(voucher.getMeter()));
                    paidCard.setTrack3(t.getNumber());
                    magList.add(paidCard);
                }

            }
        }

        return magList;
    }

    public List<MagCardData> getMagCardReprintTokens(EskomReprint voucher) {
        List<MagCardData> magList = new ArrayList<>();

        if (voucher.getPrintMagCard().equals("true")) {
            if (voucher.getMeter().getTt().equals("01")) {

                for (ElectricityVoucherResponseTokenMessage t : voucher.getTokens()) {
                    MagCardData paidCard = new MagCardData();
                    paidCard.setTrack2(formatTrack2(voucher.getMeter()));
                    paidCard.setTrack3(t.getNumber());
                    magList.add(paidCard);
                }
            }
        }

        return magList;
    }

    private static String formatTrack2(ElectricityVoucherResponseMeterMessage meter) {
        StringBuilder track2 = new StringBuilder();
        track2.append("600727");
        track2.append(meter.getMeterNum());
        track2.append(luhnEnc(track2.toString()));
        track2.append("===");
        track2.append(meter.getTt() == null ? "01" : meter.getTt());
        track2.append(meter.getAlg() == null ? "07" : meter.getAlg());
        track2.append(meter.getSgc() == null ? "000000" : meter.getSgc());
        track2.append(meter.getTi() == null ? "07" : meter.getTi());
        track2.append(meter.getKrn() == null ? "1" : meter.getKrn());

        return track2.toString();
    }

    /**
     * Calculates a LUHN modulus 10 check-digit
     *
     * @param number The Numbers to calculate the check on.
     * @return the check digit
     */
    private static int luhnEnc(String number) {
        int sum = 0;

        boolean alternate = true;
        for (int i = number.length(); i >= 1; i--) {
            int n = Integer.parseInt(number.substring(i - 1, i));

            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n = (n % 10) + 1;
                }
            }
            sum += n;
            alternate = !alternate;
        }

        return (10 - (sum % 10)) % 10;
    }

    public boolean openMagEncoder() {
        Log.d("Magcard", "openMagEncoder");
        boolean isConnected = false;

        if (Build.MODEL.startsWith("CITAQ") || Build.MODEL.startsWith("N3") || Build.MODEL.startsWith("P1")) {
            Log.d("Magcard", "check for magcard");
            if (!magCard.isConnected()) {
                Log.d("Magcard", "not connected");

                if (!magCard.enumerate()) {
                    Log.d("Magcard", "not enumerated");
                    isConnected = false;
                } else {
                    Log.d("Magcard", "enumeratd");
                    isConnected = true;
                }
            } else {
                Log.d("Magcard", "connected");
                isConnected = true;
            }
        }
        return isConnected;
    }

//    public static void writeMagCardTokens(List<MagCardData> cards) {
//        try {
//            if (cards.size() > 0) {
//                LOG.info((" >>> writeMagCards() : track2 data = ").concat(cards.get(0).getTrack2()));
//                JKiosk3.getMagCardPrompt().showMagCodePromptBox(MagCardPrompt.CARD_TOKEN, cards, result, false);
//            }
//        } catch (Exception e) {
//            LOG.log(Level.SEVERE, e.getMessage(), e);
//            JKiosk3.getMsgBox().showMsgBox("Unable to write Mag Card",
//                    e.getMessage() + "\nPlease check Mag Card Reader configuration", null);
//            JKiosk3.getMagCardPrompt().stopMagEncoder();
//        }
//    }

    public void onResume() {
        Log.d(TAG, "Enter onResume");
        super.onResume();
        configureLog4j();
        resetTimer();
//    configurePrinter();

        if (!(this instanceof ActivitySetup)) {
            startHeartbeat();
        }
        Log.d(TAG, "Leave onResume");
    }

    //----------------------------------------------------------------------------------------------
    public String formatDate(String date) { // this substandard work, make sure you come back to this and fix it!!!
        String[] mydate = (date.split(" ")[0]).split("-");
        return mydate[2] + "/" + mydate[1] + "/" + mydate[0] + " " + date.split(" ")[1]; // date + time
    }
    //----------------------------------------------------------------------------------------------

    // write ticket
    private void cacheTicket(CarmaResponseTicketMessageSerializable responseTicketMessage) { // remember to append this message, bufferedWriter.append
        Log.d(TAG, "caching bus ticket" + responseTicketMessage.toString());
        try {
            createDirsIfNecessary(); // creates directory
            try {
                // Write objects to file
                File file = new File(bustTicketsReprintsDir + "/" + "BusTickets.txt");
                if (!file.exists()) {// create it
                    file.createNewFile();
                }
                ArrayList<CarmaResponseTicketMessageSerializable> carmaResponseTicketMessageSerializables = readCachedTicketReprints();
                carmaResponseTicketMessageSerializables.add(responseTicketMessage);
                // remove contents in the file
                clearReprintTicket(); // deletes and recreates the file
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
                objectOutputStream.writeObject(carmaResponseTicketMessageSerializables);
                objectOutputStream.close();
                fileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (Exception exception) {
            logger.error("Problem caching Data " + bustTicketsReprintsDir.getPath() + "/BusTickets" + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    // read tickets
    public ArrayList<CarmaResponseTicketMessageSerializable> readCachedTicketReprints() {
        // read tickets from flat file
        createDirsIfNecessary();
        ArrayList<CarmaResponseTicketMessageSerializable> carmaResponseTicketMessageSerializable = new ArrayList<>();
        File busTickets = new File(bustTicketsReprintsDir + "/" + "BusTickets.txt"); // should create the file
        try {
            if (busTickets.exists()) {
                FileInputStream fileInputStream = new FileInputStream(busTickets);
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                // Read a list of objects
                while (true) {
                    try {
                        //noinspection unchecked
                        carmaResponseTicketMessageSerializable = (ArrayList<CarmaResponseTicketMessageSerializable>) objectInputStream.readObject(); // reads all in one go
                    } catch (EOFException e) {
                        objectInputStream.close();
                        fileInputStream.close();
                        Log.d(TAG, "readCachedTicketReprints() Done reading");
                        return carmaResponseTicketMessageSerializable;
                    }
                }
            } else { // create the file
                busTickets.createNewFile();
                return carmaResponseTicketMessageSerializable;
            }
        } catch (Exception exception) {
            Log.d(TAG, "Done reading not an exception" + exception);
            logger.info("readCachedTicketReprints()" + "Done reading not an exception" + exception);
            return carmaResponseTicketMessageSerializable; // nothing
        }
    }

    //----------------------------------------------------------------------------------------------
    private boolean externalMemoryAvailable() {
        return android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED);
    }

    //----------------------------------------------------------------------------------------------
    private String getAvailableInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSizeLong();
        long availableBlocks = stat.getAvailableBlocksLong();
        return formatSize(availableBlocks * blockSize);
    }

    //----------------------------------------------------------------------------------------------
    private String getTotalInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSizeLong();
        long totalBlocks = stat.getBlockCountLong();
        return formatSize(totalBlocks * blockSize);
    }

    //----------------------------------------------------------------------------------------------
    private String getAvailableExternalMemorySize() {
        if (externalMemoryAvailable()) {
            File path = Environment.getExternalStorageDirectory();
            StatFs stat = new StatFs(path.getPath());
            long blockSize = stat.getBlockSizeLong();
            long availableBlocks = stat.getAvailableBlocksLong();
            return formatSize(availableBlocks * blockSize);
        } else {
            return "Error occured";
        }
    }

    //----------------------------------------------------------------------------------------------
    private String getRAMSize() {
        ActivityManager actManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo memInfo = new ActivityManager.MemoryInfo();
        actManager.getMemoryInfo(memInfo);
        return formatSize(memInfo.totalMem);
    }

    //----------------------------------------------------------------------------------------------
    private String formatSize(long size) {
        String suffix = null;
        if (size >= 1024) {
            suffix = "KB";
            size /= 1024;
            if (size >= 1024) {
                suffix = "MB";
                size /= 1024;
            }
        }

        StringBuilder resultBuffer = new StringBuilder(Long.toString(size));

        int commaOffset = resultBuffer.length() - 3;
        while (commaOffset > 0) {
            resultBuffer.insert(commaOffset, ',');
            commaOffset -= 3;
        }

        if (suffix != null) resultBuffer.append(suffix);
        return resultBuffer.toString();
    }

    //----------------------------------------------------------------------------------------------
    // this method check if the current size values have changed and prints the log out
    // else it ignores it
    public void printSizeLogIfAnySizeValueHasChanged() {
        if (logger != null && (!externalSize.equalsIgnoreCase(getAvailableExternalMemorySize())
                || !internalSize.equalsIgnoreCase(getAvailableInternalMemorySize())
                || !ramSize.equalsIgnoreCase(getRAMSize()))) {
            externalSize = getAvailableExternalMemorySize();
            internalSize = getAvailableInternalMemorySize();
            ramSize = getRAMSize();

            logger.info(" Available external memory size: " + getAvailableExternalMemorySize() + " Available internal memory size: " + getTotalInternalMemorySize() + " Available RAM size: " + getRAMSize());
        }
    }

    //----------------------------------------------------------------------------------------------
    //=========TICKET PRO CATEGORIES==============
    private Date dateLastTicketproCategoriesCache() {
        try {
            createDirsIfNecessary();
            Log.d(TAG, "ticketProCategoriesDir " + ticketProCategoriesDir);
            Log.d(TAG, "ticketProCategoriesDir.getPath() " + ticketProCategoriesDir.getPath());
            File cache = new File(ticketProCategoriesDir.getPath() + "/categories.txt");
            Log.d(TAG, "cache is " + cache);
            Log.d(TAG, "cache.lastModified is " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            Log.d(TAG, "problem with categories cache " + exception);
            logger.error("problem with categories cache " + exception);
            return new Date(0L);
        }
    }

    public void cacheTicketproCategoriesData() {
        if (ticketProResponseCategoriesMessage != null && ticketProResponseCategoriesMessage.getData() != null) {
            try {
                SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
                String st = xmlProcessor.marshal(ticketProResponseCategoriesMessage.getData());

                File cache = new File(ticketProCategoriesDir.getPath() + "/categories.txt");

                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
                bufferedWriter.write(st);
                bufferedWriter.flush();
                bufferedWriter.close();
            } catch (Exception exception) {
                logger.error("marshaling exception " + exception);
            }
        }
    }

    public TicketProResponseCategoriesMessage getCachedTicketproCategoriesData() {
        Date categoriesCacheDate = dateLastTicketproCategoriesCache();
        if ((System.currentTimeMillis() - categoriesCacheDate.getTime()) > CACHE_12_HOURS) {
            Log.i(TAG, "ticketpro categories cache is expired");
            removeTicketproCategoriesCache();
            return null;
        }

        try {
            createDirsIfNecessary();
            File file = new File(ticketProCategoriesDir.getPath() + "/categories.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            TicketProResponseCategoriesMessage msg = new TicketProResponseCategoriesMessage();
            msg.getEvent().setEventCode("0");
            msg.setData((TicketProResponseCategoriesDataMessage)
                    xmlProcessor.unmarshal(line, TicketProResponseCategoriesDataMessage.class));
            return msg;
        } catch (Exception exception) {
            Log.e(TAG, "problems reading categories cache " + exception);
            logger.error("problems reading categories cache " + exception);
        }
        return null;
    }

    void removeTicketproCategoriesCache() {
        try {
            File file = new File(ticketProCategoriesDir.getPath() + "/categories.txt");
            if (file.exists()) {
                file.delete();
                Log.i(TAG, "removeTicketproCategoriesCache complete");
            }
        } catch (Exception exception) {
            Log.e(TAG, "problems removing categories cache " + exception);
            logger.error("problems removing categories cache " + exception);
        }
    }

    //=========TICKET PRO ALL EVENTS==============
    public Date dateLastTicketproAllEventsCache() {
        try {
            createDirsIfNecessary();
            Log.d(TAG, "ticketProAllEventsDir " + ticketProAllEventsDir);
            Log.d(TAG, "ticketProAllEventsDir.getPath() " + ticketProAllEventsDir.getPath());
            File cache = new File(ticketProAllEventsDir.getPath() + "/allevents.txt");
            Log.d(TAG, "cache is " + cache);
            Log.d(TAG, "cache.lastModified is " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            Log.d(TAG, "problem with all events cache " + exception);
            logger.error("problem with all events cache " + exception);
            return new Date(0L);
        }
    }

    public void cacheTicketproAllEventsData() {
        if (ticketProResponseAllEventsMessage != null && ticketProResponseAllEventsMessage.getData() != null) {
            try {
                SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
                String st = xmlProcessor.marshal(ticketProResponseAllEventsMessage.getData());

                File cache = new File(ticketProAllEventsDir.getPath() + "/allevents.txt");

                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
                bufferedWriter.write(st);
                bufferedWriter.flush();
                bufferedWriter.close();
            } catch (Exception exception) {
                logger.error("marshaling exception " + exception);
            }
        }
    }

    public TicketProResponseAllEventsMessage getCachedTicketproAllEventsData() {
        Date allEventsCacheDate = dateLastTicketproAllEventsCache();
        if ((System.currentTimeMillis() - allEventsCacheDate.getTime()) > CACHE_12_HOURS) {
            Log.i(TAG, "ticketpro all events cache is expired");
            removeTicketproAllEventsCache();
            return null;
        }

        try {
            createDirsIfNecessary();
            File file = new File(ticketProAllEventsDir.getPath() + "/allevents.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            TicketProResponseAllEventsMessage msg = new TicketProResponseAllEventsMessage();
            msg.getEvent().setEventCode("0");
            msg.setData((TicketProResponseAllEventsDataMessage)
                    xmlProcessor.unmarshal(line, TicketProResponseAllEventsDataMessage.class));
            return msg;
        } catch (Exception exception) {
            Log.e(TAG, "problems reading all events cache " + exception);
            logger.error("problems reading all events cache " + exception);
        }
        return null;
    }

    void removeTicketproAllEventsCache() {
        try {
            File file = new File(ticketProAllEventsDir.getPath() + "/allevents.txt");
            file.delete();
            Log.i(TAG, "removeTicketproAllEventsCache complete");
        } catch (Exception exception) {
            Log.e(TAG, "problems removing all events cache " + exception);
            logger.error("problems removing all events cache " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    public void initLongHaulVariables() {

        this.fragmentCarmaSearchResults = null;
        this.fragmentCarmaPassengerDetailsWizard = null;

        this.passengerDetails.clear();
        this.fragmentCarmaConfirmPurchaseTicket = null; // be interesting
    }

    public Date dateLastCarmaCache() {
        try {
            Log.d(TAG, "carmaCacheDir " + carmaCacheDir);
            Log.d(TAG, "carmaCacheDir.getPath() " + carmaCacheDir.getPath());

            File cache = new File(carmaCacheDir.getPath() + "/titlesList.txt");
            Log.d(TAG, "dateLastCarmaCache : " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            logger.error("problem with carma cache " + exception);
            return new Date(0L);
        }
    }

    public CarmaResponseCarrierListMessage getCachedCarmaCarrierList() {
        CarmaResponseCarrierListMessage carmaResponseCarrierListMessage = null;
        try {
            createDirsIfNecessary();
            File file = new File(carmaCacheDir.getPath() + "/carrierList.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();

            //msg.getEvent().setEventCode("0");
            Object msg = xmlProcessor.unmarshal(line, CarmaResponseCarrierListMessage.class);
            carmaResponseCarrierListMessage = (CarmaResponseCarrierListMessage) msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading mvno cache " + exception);
            logger.error("problems reading mvno cache " + exception);
        }
        return carmaResponseCarrierListMessage;
    }

    public void cacheCarmaCarrierListData() {
        try {
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            String st = xmlProcessor.marshal(carmaResponseCarrierListMessage);

            File cache = new File(carmaCacheDir.getPath() + "/carrierList.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(
                    new FileWriter(cache));
            bufferedWriter.write(st);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error("marshaling exception " + exception);
        }
    }

    public Date dateLastCarmaPrintLogo(File file) {
        try {
            Log.d(TAG, "dateLastCarmaPrintLogo: " + longhaulLogoCacheDir);
            Log.d(TAG, "longhaulLogoCacheDir.getPath() " + longhaulLogoCacheDir.getPath());

            File cache = new File(file.getPath());
            Log.d(TAG, "dateLastCarmaCache : " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            logger.error(TAG + "problem with carma cache " + exception);
            return new Date(0L);
        }
    }

    public CarmaResponseCityListMessage getCachedCarmaCityList() {
        CarmaResponseCityListMessage carmaResponseCityListMessage = null;
        try {
            createDirsIfNecessary();
            File file = new File(carmaCacheDir.getPath() + "/cityList.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();

            //msg.getEvent().setEventCode("0");
            Object msg = xmlProcessor.unmarshal(line, CarmaResponseCityListMessage.class);
            carmaResponseCityListMessage = (CarmaResponseCityListMessage) msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading mvno cache " + exception);
            logger.error("problems reading mvno cache " + exception);
        }
        return carmaResponseCityListMessage;
    }

    public void cacheCarmaCityListData() {
        try {
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            String st = xmlProcessor.marshal(carmaResponseCityListMessage);

            File cache = new File(carmaCacheDir.getPath() + "/cityList.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(
                    new FileWriter(cache));
            bufferedWriter.write(st);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error("marshaling exception " + exception);
        }
    }

    public CarmaResponseTitleListMessage getCachedCarmaTitlesList() {
        CarmaResponseTitleListMessage carmaResponseTitleListMessage = null;
        try {
            createDirsIfNecessary();
            File file = new File(carmaCacheDir.getPath() + "/titlesList.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();

            //msg.getEvent().setEventCode("0");
            Object msg = xmlProcessor.unmarshal(line, CarmaResponseTitleListMessage.class);
            carmaResponseTitleListMessage = (CarmaResponseTitleListMessage) msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading mvno cache " + exception);
            logger.error("problems reading mvno cache " + exception);
        }
        return carmaResponseTitleListMessage;
    }

    public void cacheCarmaTitlesListData() {
        //only cache this file if it does not currently exist.  otherwise we would keep overwriting the cached file
        //with the cached data, thereby extending the validity by 12h every time it's used, as opposed
        //to 12h since it was downloaded.
        //note that the other carma caches do not matter, since we only check the titles cache date for validity
        try {
            if (getCachedCarmaTitlesList() == null) {

                SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
                String st = xmlProcessor.marshal(carmaResponseTitleListMessage);

                File cache = new File(carmaCacheDir.getPath() + "/titlesList.txt");

                BufferedWriter bufferedWriter = new BufferedWriter(
                        new FileWriter(cache));
                bufferedWriter.write(st);
                bufferedWriter.flush();
                bufferedWriter.close();
            }
        } catch (Exception exception) {
            logger.error("marshaling exception " + exception);
        }
    }

    public CarmaResponseClassListMessage getCachedCarmaTravelClasses() {
        CarmaResponseClassListMessage carmaResponseClassListMessage = null;
        try {
            createDirsIfNecessary();
            File file = new File(carmaCacheDir.getPath() + "/travelClassList.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();

            //msg.getEvent().setEventCode("0");
            Object msg = xmlProcessor.unmarshal(line, CarmaResponseClassListMessage.class);
            carmaResponseClassListMessage = (CarmaResponseClassListMessage) msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading mvno cache " + exception);
            logger.error("problems reading mvno cache " + exception);
        }
        return carmaResponseClassListMessage;
    }

    public void cacheCarmaTravelClassesData() {
        try {
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            String st = xmlProcessor.marshal(carmaResponseClassListMessage);

            File cache = new File(carmaCacheDir.getPath() + "/travelClassList.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(
                    new FileWriter(cache));
            bufferedWriter.write(st);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error("marshaling exception " + exception);
        }
    }

    public CarmaResponsePassengerTypeListMessage getCachedCarmaPassengerTypes() {
        CarmaResponsePassengerTypeListMessage carmaResponsePassengerTypeListMessage = null;
        try {
            createDirsIfNecessary();
            File file = new File(carmaCacheDir.getPath() + "/passengerTypesList.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();

            //msg.getEvent().setEventCode("0");
            Object msg = xmlProcessor.unmarshal(line, CarmaResponsePassengerTypeListMessage.class);
            carmaResponsePassengerTypeListMessage = (CarmaResponsePassengerTypeListMessage) msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading mvno cache " + exception);
            logger.error("problems reading mvno cache " + exception);
        }
        return carmaResponsePassengerTypeListMessage;
    }

    public void cacheCarmaPassengerTypesData() {
        try {
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            String st = xmlProcessor.marshal(carmaResponsePassengerTypeListMessage);

            File cache = new File(carmaCacheDir.getPath() + "/passengerTypesList.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(
                    new FileWriter(cache));
            bufferedWriter.write(st);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error("marshaling exception " + exception);
        }
    }

    //----------------------------------------------------------------------------------------------
    private void cacheMVNOData() {
        try {
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();
            String st = xmlProcessor.marshal(chat4ChangeResponseListSuppliersMessage);

            File cache = new File(voucherCacheDir.getPath() + "/mvnodata.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(
                    new FileWriter(cache));
            bufferedWriter.write(st);
            bufferedWriter.flush();
            bufferedWriter.close();
        } catch (Exception exception) {
            logger.error("marshaling exception " + exception);
        }
    }

    private Date dateLastMvnoCache() {
        try {
            createDirsIfNecessary();
            File cache = new File(voucherCacheDir.getPath() + "/mvnodata.txt");
            Log.d(TAG, "cache is " + cache);
            Log.d(TAG, "cache.lastModified is " + cache.lastModified());
            return new Date(cache.lastModified());
        } catch (Exception exception) {
            Log.d(TAG, "problem with mvno cache " + exception);
            logger.error("problem with mvno cache " + exception);
            return new Date(0L);
        }
    }

    //----------------------------------------------------------------------------------------------
    public Chat4ChangeResponseListSuppliersMessage getCachedMVNOData() {
        Chat4ChangeResponseListSuppliersMessage chat4ChangeResponseListSuppliersMessage = null;
        try {
            createDirsIfNecessary();
            File file = new File(voucherCacheDir.getPath() + "/mvnodata.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = bufferedReader.readLine();
            bufferedReader.close();
            SimpleXMLProcessor xmlProcessor = new SimpleXMLProcessor();

            //msg.getEvent().setEventCode("0");
            Object msg = xmlProcessor.unmarshal(line, Chat4ChangeResponseListSuppliersMessage.class);
            chat4ChangeResponseListSuppliersMessage = (Chat4ChangeResponseListSuppliersMessage) msg;
        } catch (Exception exception) {
            Log.d(TAG, "problems reading mvno cache " + exception);
            logger.error("problems reading mvno cache " + exception);
        }

        if (loginResponseMessage.getData().canDo("Connect")) {
            Log.d("addconnect", "canDo Connect");
            if (chat4ChangeResponseListSuppliersMessage == null) {
                Log.d("addconnect", "getCache = null");
                chat4ChangeResponseListSuppliersMessage = new Chat4ChangeResponseListSuppliersMessage();
            }
            Chat4ChangeResponseSupplierMessage connect = new Chat4ChangeResponseSupplierMessage();
            connect.setCode("0");
            connect.setName("Connect");
            chat4ChangeResponseListSuppliersMessage.getData().getSuppliers().add(connect);
        }

        return chat4ChangeResponseListSuppliersMessage;
    }
    //----------------------------------------------------------------------------------------------

    private void checkPermittedVoucherTransaction(Favourite favourite, ArrayList<String> favouritesList) {
        Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> map = new HashMap<>();
        // get all voucher products
        if (voucherListResponseMessage != null) {
            if (voucherListResponseMessage.getData().getManufacturers().size() > 0) {
                for (VoucherListResponseManufacturerMessage voucherListResponseManufacturerMessage : voucherListResponseMessage.getData().getManufacturers()) {
                    if (voucherListResponseManufacturerMessage.getProducts().size() > 0) {
                        map.put(voucherListResponseManufacturerMessage, voucherListResponseManufacturerMessage.getProducts());
                    }
                }
            }
            for (VoucherListResponseManufacturerMessage mapKey : map.keySet()) {
                ArrayList<VoucherListResponseProductMessage> voucherListResponseProductMessages = map.get(mapKey);
                for (VoucherListResponseProductMessage voucherListResponseProductMessage : voucherListResponseProductMessages) {
                    if (voucherListResponseProductMessage.getText().equalsIgnoreCase(favourite.getProductId())) { // if voucher, since vouchers have productId, other will differ,
                        // build as you would as with cashier favourites
                        String strData;
                        String strVoucherTypeDesc = voucherListResponseProductMessage.getCategoryDesc().trim(); // what's suppose to be here
                        strData = ((mapKey.getName() == null || mapKey.getName().isEmpty()) ? "N/A" : mapKey.getName()) // get this from the manufacture, populate a map dude
                                + ";" + (((voucherListResponseProductMessage.getValue().isEmpty()) ? "N/A" : voucherListResponseProductMessage.getValue())
                                + ";" + ((voucherListResponseProductMessage.getText() == null || voucherListResponseProductMessage.getValue().isEmpty()) ? "N/A" : voucherListResponseProductMessage.getText())
                                + ";" + ((favourite.getTrxType() == null || favourite.getTrxType().isEmpty()) ? "N/A" : favourite.getTrxType())
                                + ";" + ((mapKey.getName() == null || (mapKey.getName().isEmpty()) ? "N/A" : mapKey.getName())
                                + ";" + (strVoucherTypeDesc.isEmpty() ? "N/A" : strVoucherTypeDesc)
                                + ";N/A")); // get this from the manufacture, populate a map dude
                        favouritesList.add(strData); // this will work for vouchers, we can make it work for other things you know
                        return;
                    }
                }
            }
        }
        Log.d(TAG, "Favourite not added: " + favourite);
    }

    private void checkPermittedC4CTransactions(Favourite favourite, ArrayList<String> favouritesList) {
        String c4c = getResources().getString(R.string.c4c);
        if (voucherAuthenticationResponseMessage != null) {
            if (voucherAuthenticationResponseMessage.getData().getTransTypes().contains("C4C_Voucher")) {
                if (getCachedMVNOData() != null && getCachedMVNOData().getData() != null) {
                    for (Chat4ChangeResponseSupplierMessage supplierMessage : getCachedMVNOData().getData().getSuppliers()) {
                        if (favourite.getProductId().equalsIgnoreCase(supplierMessage.getCode())) {
                            String strData = ((supplierMessage.getName() == null || supplierMessage.getName().isEmpty()) ? "N/A" : c4c + " " + supplierMessage.getName()) // get this from the manufacture, populate a map dude
                                    + ";" + "N/A"
                                    + ";" + "N/A"
                                    + ";" + "Menu"
                                    + ";" + "N/A"
                                    + ";" + c4c
                                    + ";" + "N/A";
                            favouritesList.add(strData);
                            return;
                        }
                    }
                }
            }
        }
        Log.d(TAG, "Favourite not added: " + favourite);
    }

    private void checkPermittedTopupTransaction(Favourite favourite, ArrayList<String> favouritesList) {
        String topup = getResources().getString(R.string.pinlessTopUp);
        if (voucherAuthenticationResponseMessage != null) {

            for (LoginResponseGroupMessage lrgm : loginResponseMessage.getData().getTransactionTypes()) {
                for (LoginResponseTransactionTypeMessage lrttm : lrgm.getTransactionTypes()) {
                    if (lrttm.getType().equalsIgnoreCase("topup") && favourite.getTrxType().equalsIgnoreCase(lrttm.getDisplayName())) {
                        String strData = lrttm.getDisplayName()
                                + ";" + "N/A"
                                + ";" + "N/A"
                                + ";" + "topup"
                                + ";" + lrttm.getDisplayName()
                                + ";" + topup
                                + ";" + "N/A";
                        favouritesList.add(strData);
                        List<String> numbers = new ArrayList<>();
                        for (int k = 0; k < favourite.getHistory().size(); k++) {
                            String cellnumber = favourite.getHistory().get(k).getAccount();
                            if (cellnumber.startsWith("27")) {
                                cellnumber = "0" + cellnumber.substring(2);
                            }
                            if (cellnumber.length() == 10) {
                                numbers.add(cellnumber);
                            }
                        }
                        String[] accounts = new String[numbers.size()];
                        accounts = numbers.toArray(accounts);
                        customerProfileTopupAccountNumbers.put(lrttm.getText().toLowerCase(), accounts);
                        Log.d(TAG, "customerProfileTopupAccountNumbers add: " + lrttm.getText() + ":" + Arrays.toString(accounts));
                        return;
                    }
                }
            }
        }
        Log.d(TAG, "Favourite not added: " + favourite);
    }

    private void checkPermittedElectricityTransaction(Favourite favourite, ArrayList<String> favouritesList) {
        //build a map of all the electricity transactions the device is allowed to do
        Map<String, LoginResponseTransactionTypeMessage> map = new HashMap<>();
        if (loginResponseMessage != null) {
            for (LoginResponseGroupMessage lrgm : loginResponseMessage.getData().getTransactionTypes()) {
                for (LoginResponseTransactionTypeMessage lrttm : lrgm.getTransactionTypes()) {
                    if (lrttm.getType().equalsIgnoreCase("electricity")) {
                        map.put(lrttm.getText(), lrttm);
                    }
                }
            }

            //for each electricity favourite, check if device is allowed to do it (exists in map)
            LoginResponseTransactionTypeMessage lrttm = map.get(favourite.getTrxType());
            if (lrttm != null) {
                String strData = lrttm.getDisplayName() + ";N/A;N/A;munics;" + lrttm.getText() + ";" + lrttm.getType() + ";N/A";
                favouritesList.add(strData);

                String[] accounts = new String[favourite.getHistory().size()];
                for (int i = 0; i < favourite.getHistory().size(); i++) {
                    accounts[i] = favourite.getHistory().get(i).getAccount();
                }
                customerProfileElectricityAccountNumbers.put(lrttm.getText(), accounts);
                Log.d(TAG, "customerProfileElectricityAccountNumbers add " + lrttm.getText() + ":" + Arrays.toString(accounts));
                return;
            }
        }
        Log.d(TAG, "Favourite not added: " + favourite);
    }

    private void checkPermittedBillPaymentsProvider(Favourite favourite, ArrayList<String> favouritesList) {
        Log.d(TAG, "====================Favourite incoming: " + favourite);
        // Albert Luthli Municipality;N/A;N/A;bill_payment;Bill;Bill Payment;SAPO Account Payment
        //
        // first put all products in the array
        //
        if (billPaymentsResponseProductListMessage != null) {
            Log.v(TAG, "List Count: " + billPaymentsResponseProductListMessage.getData().getProviders().size());
            for (BillPaymentsResponseProviderMessage provider : billPaymentsResponseProductListMessage.getData().getProviders()) {
                for (int j = 0; j < provider.getProducts().size(); j++) {
                    BillPaymentsResponseProductMessage product = provider.getProducts().get(j);

                    if (product.getId().equals(favourite.getProductId()) && favourite.getTrxType().replace("At", "@").replace("VASSyntellFinePayment", "SyntellTrafficFines").contains(provider.getName().replace(" ", ""))) {

                        String strData = ((product.getName() == null || product.getName().isEmpty()) ? "N/A" : product.getName())
                                + ";" + "N/A"
                                + ";" + "N/A"
                                + ";" + "bill_payment"
                                + ";" + "Bill"
                                + ";" + provider.getName() //"Bill Payment"
                                + ";" + ((provider.getName() == null || provider.getName().isEmpty()) ? "N/A" : provider.getName());

                        favouritesList.add(strData);

                        List<String> accountList = new ArrayList<>();
                        for (int k = 0; k < favourite.getHistory().size(); k++) {
                            String account = favourite.getHistory().get(k).getAccount();

                            //jkiosk populates account number with 36 digit barcode, so we must extract the 10 digit account number from that string
                            if (product.getName().equalsIgnoreCase("Eskom") && account.length() == 36) {
                                account = account.substring(13, 23);
                            }

                            //check if account number exists, since same account number used on jkiosk and bludroid will create 2 separate entries in loyalty server
                            if (!accountList.contains(account)) {
                                accountList.add(account);
                            }
                        }
                        if (!accountList.isEmpty()) {
                            String key = product.getName();
                            String[] accounts = new String[accountList.size()];
                            accounts = accountList.toArray(accounts);
                            customerProfileBillPaymentsAccountNumbers.put(key, accounts);
                            Log.d(TAG, "customerProfileBillPaymentsAccountNumbers add " + key + ":" + Arrays.toString(accounts));
                        }
                        Log.d(TAG, "Favourite added: " + favourite);
                        return;
                    }
                }
            }
        }
        Log.d(TAG, "Favourite not added: " + favourite);
    }

    private void checkPermittedTicketTransaction(Favourite favourite, ArrayList<String> favouritesList) {
        String ticketString = "Tickets;N/A;N/A;Menu;N/A;N/A;N/A";
        if (!favouritesList.contains(ticketString)) {
            //build a map of all the ticket transactions the device is allowed to do
            for (LoginResponseGroupMessage lrgm : loginResponseMessage.getData().getTransactionTypes()) {
                for (LoginResponseTransactionTypeMessage lrttm : lrgm.getTransactionTypes()) {
                    if (lrttm.getType().equalsIgnoreCase("tickets")) {
                        favouritesList.add(ticketString);
                        return;
                    }
                }
            }
        }
        Log.d(TAG, "Favourite not added: " + favourite);
    }

    private static boolean compare(String str1, String str2) {
        return (Objects.equals(str1, str2));
    }

    private void checkPermittedPinlessBundle(Favourite favourite, ArrayList<String> favouritesList) {
        String data = getResources().getString(R.string.pinlessBundles);
        String bundle = getResources().getString(R.string.bundle);

        //Wallet topups with no product ids
        if (favourite.getProductId() == null) {
            // if () { // if voucher, since vouchers have productId, other will differ,
            // build as you would as with cashier favourites
            String strData = (((favourite.getTrxType() == null || favourite.getTrxType().isEmpty()) ? "N/A" : favourite.getTrxType()) // get this from the manufacture, populate a map dude
                    + ";" + "Any Amount"
                    + ";" + "N/A"
                    + ";" + bundle
                    + ";" + favourite.getTrxType()
                    + ";" + data
                    + ";" + "N/A"); // get this from the manufacture, populate a map dude
            favouritesList.add(strData); //

            List<String> numbers = new ArrayList<>();
            for (int k = 0; k < favourite.getHistory().size(); k++) {
                String cellnumber = favourite.getHistory().get(k).getAccount();
                if (cellnumber.startsWith("27")) {
                    cellnumber = "0" + cellnumber.substring(2);
                }
                if (cellnumber.length() == 10) {
                    numbers.add(cellnumber);
                }
            }
            String[] accounts = new String[numbers.size()];
            accounts = numbers.toArray(accounts);
            String key = favourite.getTrxType().toLowerCase();
            customerProfileBundlesAccountNumbers.put(key, accounts);
            Log.d(TAG, "customerProfileBundlesAccountNumbers add " + key + ":" + Arrays.toString(accounts));
            // }
        }

        if (bundlesResponseGetProductListMessages != null) {
            for (String network : bundlesResponseGetProductListMessages.keySet()) {
                if (bundlesResponseGetProductListMessages.get(network) != null) {
                    for (BundlesResponseCategoryMessage list : bundlesResponseGetProductListMessages.get(network).getData().getCategories()) {
                        for (BundlesResponseProductMessage product : list.getProducts()) {

                            if (compare(product.getProductCode(), favourite.getProductId())) {
                                // if () { // if voucher, since vouchers have productId, other will differ,
                                // build as you would as with cashier favourites
                                String strData = (((product.getAmount().isEmpty()) ? "N/A" : product.getAmount())  // get this from the manufacture, populate a map dude
                                        + ";" + ((product.getDescription() == null || product.getDescription().isEmpty()) ? "N/A" : product.getDescription())
                                        + ";" + ((product.getProductCode() == null || product.getProductCode().isEmpty()) ? "N/A" : product.getProductCode())
                                        + ";" + bundle
                                        + ";" + getNetworkName(network)
                                        + ";" + data
                                        + ";" + "N/A"); // get this from the manufacture, populate a map dude
                                favouritesList.add(strData); //

                                List<String> numbers = new ArrayList<>();
                                for (int k = 0; k < favourite.getHistory().size(); k++) {
                                    String cellnumber = favourite.getHistory().get(k).getAccount();
                                    if (cellnumber.startsWith("27")) {
                                        cellnumber = "0" + cellnumber.substring(2);
                                    }
                                    if (cellnumber.length() == 10) {
                                        numbers.add(cellnumber);
                                    }
                                }
                                String[] accounts = new String[numbers.size()];
                                accounts = numbers.toArray(accounts);
                                String key = product.getProductCode() + favourite.getTrxType().toLowerCase();
                                customerProfileBundlesAccountNumbers.put(key, accounts);
                                Log.d(TAG, "customerProfileBundlesAccountNumbers add " + key + ":" + Arrays.toString(accounts));
                                // }
                            }
                        }
                    }
                }
            }
        }
    }

    private void checkPermittedOtherTransaction(Favourite favourite, ArrayList<String> favouritesList) {
        Map<String, LoginResponseTransactionTypeMessage> map = new HashMap<>();
        //build a map of all the ticket transactions the device is allowed to do
        if (loginResponseMessage != null) {
            for (LoginResponseGroupMessage lrgm : loginResponseMessage.getData().getTransactionTypes()) {
                for (LoginResponseTransactionTypeMessage lrttm : lrgm.getTransactionTypes()) {
                    if (lrttm.getType().equalsIgnoreCase("Other")) {
                        map.put(lrttm.getText(), lrttm);
                    }
                }
            }

            //for each ticket favourite, check if device is allowed to do it (exists in map)
            LoginResponseTransactionTypeMessage lrttm = map.get(favourite.getTrxType());
            if (lrttm != null) {
                String strData = lrttm.getDisplayName() + ";N/A;N/A;Menu;N/A;N/A;N/A";
                favouritesList.add(strData);
            }
        }
    }

    void clearPicassoImageDiskCache() {
        File cache = new File(getApplicationContext().getCacheDir(), "picasso-cache");
        if (cache.exists() && cache.isDirectory()) {
            deleteDir(cache, true);
        }
    }

    private static boolean deleteDir(File dir, boolean deleteRoot) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (String child : children) {
                boolean success = deleteDir(new File(dir, child), true);
                if (!success) {
                    return false;
                }
            }
        }
        if (deleteRoot) {
            // The directory is now empty so delete it
            return dir.delete();
        }
        return true;

    }

    private void checkPermissions() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    + ContextCompat.checkSelfPermission(
                    this, Manifest.permission.READ_PHONE_STATE)
                    + ContextCompat.checkSelfPermission(
                    this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {

                // Do something, when permissions not granted
                if (ActivityCompat.shouldShowRequestPermissionRationale(
                        this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        || ActivityCompat.shouldShowRequestPermissionRationale(
                        this, Manifest.permission.READ_PHONE_STATE)
                        || ActivityCompat.shouldShowRequestPermissionRationale(
                        this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                    // If we should give explanation of requested permissions

                    // Show an alert dialog here with request explanation
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Storage, Phone and Location" +
                            " permissions are required.");
                    builder.setTitle("Please grant these permissions");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            ActivityCompat.requestPermissions(
                                    BaseActivity.this,
                                    new String[]{
                                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                            Manifest.permission.READ_PHONE_STATE,
                                            Manifest.permission.ACCESS_FINE_LOCATION
                                    },
                                    0
                            );
                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                } else {
                    // Directly request for required permissions, without explanation
                    ActivityCompat.requestPermissions(
                            this,
                            new String[]{
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                    Manifest.permission.READ_PHONE_STATE,
                                    Manifest.permission.ACCESS_FINE_LOCATION
                            },
                            0
                    );
                }
            } else {
                initialize();
            }
        } else {
            initialize();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 0) {// When request is cancelled, the results array are empty
            if ((grantResults.length > 0) && (grantResults[0] + grantResults[1] + grantResults[2] == PackageManager.PERMISSION_GRANTED)) {
                // Permissions are granted
                Toast.makeText(this, "Permissions granted.", Toast.LENGTH_SHORT).show();
                initialize();
            } else {
                // Permissions are denied
                checkPermissions();
            }
        }
    }

    void updateHeartbeatFlag(CommonResponseEventMessage commonResponseEventMessage) {
        try {
            AEONheartbeat = ((commonResponseEventMessage.getHeartBeatEnable() == null ? "0" : commonResponseEventMessage.getHeartBeatEnable()));
        } catch (Exception e) {
            logger.error(e);
            Log.d(TAG, "updateDynatraceFlag: " + e);
        }
    }

    private void startHeartbeat() {
        try {
            boolean heartBeatEnabled;
            heartBeatEnabled = getPreference(PREF_HEARTBEAT_ENABLE_TECH).equals(PREF_TRUE) && AEONheartbeat.equals("1");

            if (!AwsHeartbeatService.isRunning() && heartBeatEnabled) {
                Intent i = new Intent(this, AwsHeartbeatService.class);
                startService(i);
            } else if (!heartBeatEnabled) {
                stopHeartbeat();
            }
        } catch (Exception e) {
            Log.d("startHeartbeat", e.getMessage());
            logger.error("startHeartbeat" + e);
            updatePreference(PREF_HEARTBEAT_ENABLE_TECH, PREF_FALSE);
        }
    }

    void stopHeartbeat() {
        if (AwsHeartbeatService.isRunning()) {
            Intent i = new Intent(this, AwsHeartbeatService.class);
            stopService(i);
        }
    }

    public void closeAeonSocket(int caller47) {
        //added a caller integer, so its simpler to debug where a socket is getting closed.  be sure to always call with an incremented int
        //increment the caller parameter, so can always easily see what next int should be
        try {
            asyncTask.closeSocket(caller47);
        } catch (Exception ignore) {
        }
    }

    public boolean canDoLongHaulBus() {
        return loginResponseMessage.getData().canDoCarma();
    }

    private void checkSetup() {
        if (this instanceof ActivityLanding) {
            checkPreference();
            String deviceId = getPreference(PREF_DEVICE_ID);
            Log.d("CheckSetup", "deviceId = " + deviceId);
            // checking to see if the deviceId is setup.  if not, this is
            // probably the first time the app is being run
            if (deviceId.trim().equals("unknown") || deviceId.trim().isEmpty()) {
                Log.d("CheckSetup", "Going to ActivitySetup");
                gotoSetupScreen();
            }
        }
    }

    public void printEventTickets() {
        if (ticketProResponsePrintMessage.getData().getTickets().size() > 0) {
            if (isEventsScreen) {
                printTicketProMerchantReceipt(false);
            }

            createProgress(R.string.printingTickets);

            supplierName = "ticketpro";
            choosePrintLogo();

            for (int i = 0; i < ticketProResponsePrintMessage.getData().getTickets().size(); i++) {
                try {
                    TicketProResponseTicketMessage ticket = ticketProResponsePrintMessage.getData().getTickets().get(i);
                    ArrayList<CommonResponseLineMessage> ticketPrintLines = new ArrayList<>();
                    ticketPrintLines.add(printLine("N", ""));
                    ticketPrintLines.add(printLine("H", "TicketPro"));

                    ticketPrintLines.add(printLine("H", ticket.getName().getText()));

                    if (!ticket.getParentEventName().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getParentEventName().getText()));
                    }
                    if (!ticket.getEventName().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getEventName().getText()));
                    }
                    if (!ticket.getVenueName().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getVenueName().getText()));
                    }
                    if (!ticket.getMediumDate().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getMediumDate().getText()));
                    }
                    if (!ticket.getPriceCatLabel().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getPriceCatLabel().getText()));
                    }
                    if (!ticket.getEventDateDay().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getEventDateDay().getText()));
                    }
                    if (!ticket.getEventDateMonth().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getEventDateMonth().getText()));
                    }
                    if (!ticket.getEventDateYear().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getEventDateYear().getText()));
                    }
                    if (!ticket.getStartTime().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getStartTime().getText()));
                    }
                    if (!ticket.getStand().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getStand().getText()));
                    }
                    if (!ticket.getGate().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getGate().getText()));
                    }
                    if (!ticket.getEntrance().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getEntrance().getText()));
                    }
                    if (!ticket.getBlock().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getBlock().getText()));
                    }
                    if (!ticket.getRow().getText().trim().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getRow().getText()));
                    }
                    for (int j = 0; j < ticket.getSeats().size(); j++) {
                        if (!ticket.getSeats().get(j).getText().trim().isEmpty()) {
                            ticketPrintLines.add(printLine("H", ticket.getSeats().get(j).getText()));
                        }
                    }

                    for (int j = 0; j < ticket.getTicketIds().size(); j++) {
                        if (j == 0 || !ticket.getTicketIds().get(j).getText().equals(ticket.getTicketIds().get(j - 1).getText())) {
                            ticketPrintLines.add(printLine("H", ticket.getTicketIds().get(j).getText()));
                        }
                    }
                    if (!ticket.getPrices().isEmpty()) {
                        ticketPrintLines.add(printLine("H", ticket.getPrices().get(0).getText()));
                    }

                    ticketPrintLines.add(printLine("H", ticket.getTransactionNo().getText()));
                    ticketPrintLines.add(printLine("H", ticket.getTimeStamp().getText()));
                    ticketPrintLines.add(printLine("H", getResources().getString(R.string.ticketproTCReference)));
                    ticketPrintLines.add(printLine("H", getResources().getString(R.string.ticketproTCReferenceContinued)));
                    ticketPrintLines.add(printLine("H", getResources().getString(R.string.ticketproWebsite)));
                    ticketPrintLines.add(printLine("H", getResources().getString(R.string.ticketproRefundablePolicy)));

                    ticketPrintLines.add(printLine("H", convertHex(ticket.getBarcode1().getText())));
                    ticketPrintLines.add(printLine("N", ""));

                    int width = printWidth * 10;
                    int height = BARCODE_HEIGHT_128;
                    if (ticket.getBarcode1().getEncoding().equals("pdf417")) {
                        width = BARCODE_WIDTH_PDF417;
                        height = BARCODE_HEIGHT_PDF417;
                    }

                    Bitmap bitmap = generateBarcode(ticket.getBarcode1().getEncoding(),
                            convertHex(ticket.getBarcode1().getText()), width, height);

//                    smartPrinter.print(bluLogo, ticketPrintLines, bitmap);
                    printWithDynamic(bluLogo, ticketPrintLines, bitmap);

                    dismissProgress();

                    Log.v(TAG, "printed");
                } catch (Exception exception) {
                    Log.v(TAG, "problem with merchant receipt " + exception);
                }
            }


            supplierName = "";
            gettingMvnoVoucher = false;
        }
        if (isTicketProReprint || isCollectionScreen) {
            gotoMainScreen();

        } else {
            //the secure print results will handle the empty basket
            if (!securePrint) {
                emptyBasket();
            }
        }

        isCollectionScreen = false;
    }

    int getDeclineCount(String pref) {
        try {
            return Integer.parseInt(getPreference(pref));
        } catch (Exception ignore) {
        }
        return 0;
    }

    void downloadDeclineIncrement() {
        Log.d("DECLINE", "downloadDeclineIncrement");
        int count = getDeclineCount(PREF_DOWNLOAD_DECLINE);
        updatePreference(PREF_DOWNLOAD_DECLINE, String.valueOf(count + 1));
    }

    void installDeclineIncrement() {
        Log.d("DECLINE", "installDeclineIncrement");
        int count = getDeclineCount(PREF_INSTALL_DECLINE);
        updatePreference(PREF_INSTALL_DECLINE, String.valueOf(count + 1));
    }

    void resetDeclineCounts() {
        Log.d("DECLINE", "resetDeclineCounts");
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = this.sharedPreferences.edit();
        editor.putString(PREF_DOWNLOAD_DECLINE, "0");
        editor.putString(PREF_INSTALL_DECLINE, "0");
        editor.putString(PREF_RESET_DECLINE_COUNT, PREF_FALSE);
        editor.commit();
    }

    public String getApplicationId() {
        return BuildConfig.APPLICATION_ID;
    }

    public String getVersionName() {
        return BuildConfig.VERSION_NAME;
    }

    public String getApplicationName() {
        ApplicationInfo applicationInfo = getApplicationInfo();
        int stringId = applicationInfo.labelRes;
        return stringId == 0 ? applicationInfo.nonLocalizedLabel.toString() : getString(stringId);
    }

    public boolean isGcrsSkin() {
        return getPreference(PREF_SKIN).equals(getResources().getString(R.string.skinGCRS))
                || getPreference(PREF_PREVIOUS_SKIN).equals(getResources().getString(R.string.skinGCRS));
    }

    public void refresh() {
        loginResponseMessage = null;
        voucherListResponseMessage = null;
        voucherAuthenticationResponseMessage = null;
        billPaymentsResponseProductListMessage = null;
        bundlesResponseGetProductListMessages = null;

        removeLoginCache();
        removeVoucherCache();
        removeBillPaymentCache();
        removeAllBundlesCache();
        removeMVNOCache();
        removeTicketproCategoriesCache();
        removeTicketproAllEventsCache();
        removeCarmaCache();
        removePutcoCache();
        removeCallMeCache();
        removeLonghaulLogosCache();
        removePrintLogoCache();
        removeDynamicPrintCache();
        removeBannerCache();
        removeSearchCache();
        removeTicketCancelCache();
        recoveryCacheHandler.removeCaches();
//        removeNfcBusCache();
        NfcBusTicketCacheHandler nfcBusTicketCacheHandler = new NfcBusTicketCacheHandler(nfcBusTicketCacheDir);
        nfcBusTicketCacheHandler.removeCaches();

        loadFavouritesFirstTime = true;
        clearPicassoImageDiskCache();
        createNotification("Device Refreshed");
    }

    public void saveAccountDetails(ArrayList<CommonResponseAccountMessage> accounts) {
        if (accounts != null) {
            for (CommonResponseAccountMessage acc : accounts) {
                Log.w("ProfDisp", acc.toString());
            }
        }
        Gson gson = new GsonBuilder().serializeNulls().create();
        String accountStringToSave = accounts == null ? "" : gson.toJson(accounts);
        Log.w("ProfDisp", "write to prefs: " + accountStringToSave);
        updatePreference(PREF_ACCOUNT_DETAILS, accountStringToSave);
    }

    public String getBalancePref(String userLevel, String account) {
        return getPreference(PREF_BALANCE + userLevel + account);
    }

    public void setBalancePref(String userLevel, String account, String value) {
        updatePreference(PREF_BALANCE + userLevel + account, value);
    }

    public String getProfitPref(String userLevel, String account) {
        return getPreference(PREF_PROFIT + userLevel + account);
    }

    public void setProfitPref(String userLevel, String account, String value) {
        updatePreference(PREF_PROFIT + userLevel + account, value);
    }

    public String getBalanceAmountPref(String account) {
        return getPreference(PREF_BALANCEAMT + account);
    }

    public void setBalancePref(String account, String value) {
        updatePreference(PREF_BALANCEAMT + account, value);
    }

    public Chat4ChangeResponseSupplierMessage getC4CSupplier(String supplierName) {
        if (supplierName != null) {
            String name = supplierName.replaceAll(" ", "");
            if (chat4ChangeResponseListSuppliersMessage == null) {
                chat4ChangeResponseListSuppliersMessage = getCachedMVNOData();
            }
            if (chat4ChangeResponseListSuppliersMessage != null) {
                for (Chat4ChangeResponseSupplierMessage supplier : chat4ChangeResponseListSuppliersMessage.getData().getSuppliers()) {
                    if (supplier.getName().equalsIgnoreCase(name)) {
                        return supplier;
                    }
                }
            }
        }
        return null;
    }

    public boolean previewSlipsEnabled() {
        return (isQa() || isDebug()) && Boolean.parseBoolean(getPreference(PREF_PRINT_PREVIEW_RECEIPTS));
    }

    public void completeC4cPrint() {
        supplierName = "";
        gettingMvnoVoucher = false;

        logger.info("Voucher printed:" + isVoucherPrinted);
        if (isVoucherPrinted) {
            setPrintedChat4Change(chat4ChangeResponseMessage);
        } else {
            cleanUp();
            createPrintErrorConfirmation();
        }
    }

    public void completeSapo(){
        supplierName = "";
        gettingMvnoVoucher = false;

        logger.info("Bill payment printed:" + isVoucherPrinted);
        if (isVoucherPrinted) {
            dismissProgress();
            createProgress(getResources().getString(R.string.confirmingPrinted));
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsRequestPrintedMessage requestPrintedMessage = factory.confirmPrinted(sapoResponseMessage.getSessionId(), transRef, reference);
            startAEONAsyncTask(this, socket, requestPrintedMessage);
        } else {
            cleanUp();
            createPrintErrorConfirmation();
        }
    }

    public void  completeLotto(){
        supplierName = "";
        gettingMvnoVoucher = false;

        if (isVoucherPrinted) {
            ithubaPrinted();
        } else {
            cleanUp();
            createPrintErrorConfirmation();
        }
    }

    public void completePowerball(){
        supplierName = "";
                gettingMvnoVoucher = false;

                if (isVoucherPrinted) {
                    ithubaPrinted();
                } else {
                    cleanUp();
                    createPrintErrorConfirmation();
                }
    }

    public void completeSyntell(){
        supplierName = "";
        gettingMvnoVoucher = false;
        logger.info("Bill payment printed:" + isVoucherPrinted);
        if (isVoucherPrinted) {
            dismissProgress();
            createProgress(getResources().getString(R.string.confirmingPrinted));
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();

            BillPaymentsRequestPrintedMessage requestPrintedMessage = factory.confirmPrinted(responseSyntellConfirmMessage.getSessionId(), transRef, accountNumber);

            startAEONAsyncTask(this, socket, requestPrintedMessage);
        } else {
            cleanUp();
            createPrintErrorConfirmation();
        }
    }

    public void completeBluBillPayments(){
        supplierName = "";
                gettingMvnoVoucher = false;

                logger.info("Bill payment printed:" + isVoucherPrinted);
                if (isVoucherPrinted) {
                    setPrintedBluPayment();
                } else {
                    cleanUp();
                    createPrintErrorConfirmation();
                }
    }

    public void completePayAt(){
        supplierName = "";
        gettingMvnoVoucher = false;
        logger.info("Bill payment printed:" + isVoucherPrinted);
        if (isVoucherPrinted) {
            dismissProgress();
            createProgress(getResources().getString(R.string.confirmingPrinted));
            BillPaymentsRequestFactory factory = new BillPaymentsRequestFactory();
            BillPaymentsRequestPrintedMessage request = factory.confirmPrinted(
                    responsePayAtConfirmMessage.getSessionId(),
                    billPaymentsResponsePayAtAccountPaymentMessage.getData().getTransRef(),
                    billPaymentsResponsePayAtAccountPaymentMessage.getData().getTransactionId());
            startAEONAsyncTask(this, socket, request);
        } else {
            cleanUp();
            createPrintErrorConfirmation();
        }
    }

    public void completeMerchantTransfers(){
        supplierName = "";
        gettingMvnoVoucher = false;
        logger.info("M2M printed:" + isVoucherPrinted);
        if (isVoucherPrinted) {
            confirmMerchantTranferPrinted();
        } else {
            cleanUp();
            createPrintErrorConfirmation();
        }
    }
}
