package za.co.blts.loyalty;

import android.util.Log;

import com.nexgo.oaf.apiv3.device.reader.CardInfoEntity;
import com.nexgo.oaf.apiv3.device.reader.CardReader;
import com.nexgo.oaf.apiv3.device.reader.CardSlotTypeEnum;
import com.nexgo.oaf.apiv3.device.reader.OnCardInfoListener;
import com.nexgo.oaf.apiv3.device.reader.TypeAInfoEntity;

import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;

import za.co.blts.bltandroidgui3.BaseActivity;

import static com.nexgo.oaf.apiv3.APIProxy.getDeviceEngine;

/**
 * Created by MasiS on 4/19/2018.
 */

public class NexgoN3NFCCard implements NFCCardInterface, OnCardInfoListener {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidNFCCardAsyncResponse delegate = null;

    private CardReader cardReader;
    private String cardNumber;
    private WeakReference<BaseActivity> baseActivityWeakReference;

    //----------------------------------------------------------------------------------------------
    public NexgoN3NFCCard(BaseActivity context) {
        this.baseActivityWeakReference = new WeakReference<>(context);
        context.deviceEngine = getDeviceEngine();
        cardReader = context.deviceEngine.getCardReader();
    }

    @Override
    public void setDelegate(BluDroidNFCCardAsyncResponse delegate) {
        this.delegate = delegate;
    }

    @Override
    public void openReader() {

    }

    @Override
    public void closeReader() {

    }

    @Override
    public void startListener() {
        Log.d(TAG, "startListener");
        HashSet<CardSlotTypeEnum> slotTypes = new HashSet<>();
        slotTypes.add(CardSlotTypeEnum.RF); // maybe we need a check on this
        cardReader.searchCard(slotTypes, 10000, this); // test this value,
    }

    @Override
    public void stopListener() {
        cardReader.stopSearch();
    }

    @Override
    public String getCardNumber() {
        return this.cardNumber;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onCardInfo(final int retCode, final CardInfoEntity cardInfo) {
        Log.d(TAG, "onCardInfo retcode:" + retCode + " cardInfo:" + cardInfo);
        if (cardInfo != null) {
            Log.d(TAG, "getCardNo:" + cardInfo.getCardNo());
            Log.d(TAG, "getCardExistslot:" + cardInfo.getCardExistslot());
            Log.d(TAG, "getRfCardType:" + cardInfo.getRfCardType());

            TypeAInfoEntity entity = new TypeAInfoEntity();
            int result = cardReader.getRfCardInfo(entity);
            Log.d(TAG, "result:" + result + " entity:" + entity);
            if (entity.getUid() != null) {
                Log.d(TAG, "entity.uid:" + Arrays.toString(entity.getUid()));
                byte[] cardUid = new byte[8];  //long is 8 bytes in length
                System.arraycopy(entity.getUid(), 0, cardUid, 4, 4);  //copy unsigned int (4 bytes) into lower half of long
                ByteBuffer wrapped = ByteBuffer.wrap(cardUid); // big-endian by default
                //format the card uid as a 10 digit string
                cardNumber = String.format(Locale.US, "%010d", wrapped.getLong());
            }
        }
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            baseActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    delegate.onCardNumberRead((cardNumber));
                }
            });
        }
        startListener();
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onSwipeIncorrect() {
        Log.i(TAG, "onSwipeIncorrect: Error Swipe");
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onMultipleCards() {
        Log.i(TAG, "onMultipleCards: Error multiple cards");
    }
    //----------------------------------------------------------------------------------------------
}