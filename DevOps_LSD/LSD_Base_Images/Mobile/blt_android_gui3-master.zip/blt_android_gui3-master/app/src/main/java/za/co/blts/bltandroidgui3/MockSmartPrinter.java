package za.co.blts.bltandroidgui3;

import android.graphics.Bitmap;

import com.google.zxing.common.BitMatrix;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;

//import com.telpo.tps550.api.TelpoException;
//import com.telpo.tps550.api.printer.ThermalPrinter;

public class MockSmartPrinter implements SmartPrinter {

    public void initialise(BaseActivity baseScreen) {
    }

    public void terminate() {
    }

    public void print(ArrayList<CommonResponseLineMessage> lines, boolean feed) {
    }

    public void print(List<String> lines) {
    }

    public void print(Bitmap logo, List<String> lines, Bitmap barcode, String barcodeNumber) {
    }

    public void print(Bitmap logo, List<CommonResponseLineMessage> lines, Bitmap barcode, boolean feed) {
    }

    public int getBitmapMaxWidth() {
        return 100;
    }

    public Bitmap convertBitMatrixToBitMap(BitMatrix bitMatrix) {
        return null;
    }

    public void print(JSONArray printJob) {
    }
}
