package za.co.blts.bltandroidgui3.cardviews;

import android.app.Activity;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewMTN extends CardviewDataObject {

    public CardviewMTN(Activity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.mtn,
                baseActivity.getResources().getColor(R.color.mtn),
                stockId, voucherType, tag);
        super.setHasAirtimePlus(hasAirtimePlus);
    }

    public CardviewMTN(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.mtn,
                baseActivity.getResources().getColor(R.color.mtn),
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(hasAirtimePlus);
    }

    public CardviewMTN(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus, boolean isMvno) {
        super(cardDesc, cardValue,
                R.drawable.mtn,
                baseActivity.getResources().getColor(R.color.mtn),
                stockId, voucherType, tag, voucherTypeDesc);

        super.setHasAirtimePlus(hasAirtimePlus);
        super.setMVNO(isMvno);
    }

    public String getSupplierCode() {
        return "2";
    }

    public String getBundlesName() {
        return "MTNBundles";
    }

    public String getTopupName() {
        return "Mtn";
    }
}

