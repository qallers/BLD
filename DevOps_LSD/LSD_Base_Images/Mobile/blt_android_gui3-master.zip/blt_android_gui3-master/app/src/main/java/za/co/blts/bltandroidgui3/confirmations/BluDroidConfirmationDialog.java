package za.co.blts.bltandroidgui3.confirmations;


import android.app.Dialog;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;
import za.co.blts.bltandroidgui3.widgets.BluDroidToolBar;
import za.co.blts.bltandroidgui3.widgets.BluDroidValidatable;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidConfirmationDialog extends Dialog implements OnClickListener, BluDroidSetupable, BluDroidValidatable {
    protected final String TAG = this.getClass().getSimpleName();

    protected BaseActivity baseActivity = null;
    private BaseFragment baseFragment = null;
    public BluDroidToolBar toolbar = null;
    private boolean showNavigation = true;

    public void hideNavigation() {
        this.showNavigation = false;
    }

    //private static BluDroidRelativeLayout layout;

    void setupButton(int resourceId) {
        try {
            BluDroidButton button = this.findViewById(resourceId);
            if (button != null) {
                button.setOnClickListener(this);
            }
        } catch (Exception exception) {
            Log.d(TAG, "Problem setting up button " + exception);
        }
    }

    public void setContext(BaseActivity baseActivity) {
        this.baseActivity = baseActivity;
    }

    public void setup() {
        try {
            BluDroidRelativeLayout layout = this.findViewById(R.id.layout);
            layout.setContext(baseActivity);
            layout.setup();
            setupButton(R.id.affirmativeButton);
            setupButton(R.id.negativeButton);
            setupButton(R.id.neutralButton);
            for (int i = 0; i < layout.getChildCount(); i++) {
                View view = layout.getChildAt(i);
                if (view instanceof BluDroidSetupable) {
                    BluDroidSetupable setupable = (BluDroidSetupable) view;
                    setupable.setContext(baseActivity);
                    setupable.setup();
                }
            }

            toolbar = findViewById(R.id.toolbar);
            if (showNavigation) {
                toolbar.setNavigationBackIcon();
                toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dismiss();
                        checkToCloseSocket();
                        baseActivity.airtimePlusPlayed = "0";
                    }
                });
            } else {
                toolbar.removeNavigationIcon();
            }
            toolbar.removeAppLogo();

        } catch (Exception exception) {
            Log.d(TAG, "problem setting up confirmation " + exception);
        }
    }

    private void initialize() {
        //
        // this request Feature must execute before the layout is expanded
        //
        this.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
    }

    private void configure() {
        setup();
        this.getWindow().setLayout(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        this.show();
    }

    protected BluDroidConfirmationDialog(BaseActivity context, int layoutResourceId) {
        super(context);
        initialize();
        this.baseActivity = context;
        this.setContentView(layoutResourceId);
        configure();
        String dialog = this.getClass().getSimpleName();
        this.baseActivity.crashLog("Dialog", dialog);
        this.baseActivity.mFirebaseAnalytics.setCurrentScreen(this.baseActivity, dialog, null);
    }

    BluDroidConfirmationDialog(BaseFragment context, int layoutResourceId) {
        super(context.getActivity());
        try {
            initialize();
            this.baseActivity = (BaseActivity) context.getActivity();
            this.baseFragment = context;
            this.setContentView(layoutResourceId);
            configure();
            String dialog = this.getClass().getSimpleName();
            this.baseActivity.crashLog("Dialog", dialog);
            this.baseActivity.mFirebaseAnalytics.setCurrentScreen(this.baseActivity, dialog, null);
        } catch (Exception exception) {
            Log.e(TAG, "BlUuroidConfirmationDialog constructor " + exception);
        }
    }

    public void setMessage(String message) {
        BluDroidTextView textView = this.findViewById(R.id.message);
        if (textView != null)
            textView.setText(message);
    }

    public void setMessage(int messageResourceId) {
        setMessage(baseActivity.getResources().getString(messageResourceId));
    }

    public void setHeading(String heading) {
        toolbar.setTitle(heading);
    }

    void setHeading(int headingResourceId) {
        setHeading(baseActivity.getResources().getString(headingResourceId));
    }

    private void setAffirmativeButtonLabel(String label) {
        BluDroidButton button = this.findViewById(R.id.affirmativeButton);
        if (button != null)
            button.setText(label);
    }

    protected void setAffirmativeButtonLabel(int resourceId) {
        setAffirmativeButtonLabel(baseActivity.getResources().getString(resourceId));
    }

    private void setNegativeButtonLabel(String label) {
        BluDroidButton button = this.findViewById(R.id.negativeButton);
        if (button != null)
            button.setText(label);
    }

    protected void setNegativeButtonLabel(int resourceId) {
        setNegativeButtonLabel(baseActivity.getResources().getString(resourceId));
    }

    void setNeutralButtonLabel(String label) {
        BluDroidButton button = this.findViewById(R.id.neutralButton);
        if (button != null)
            button.setText(label);
    }

    void setNeutralButtonLabel(int resourceId) {
        setNeutralButtonLabel(baseActivity.getResources().getString(resourceId));
    }

    public void hideView(int resourceId) {
        View view = this.findViewById(resourceId);
        if (view != null)
            view.setVisibility(View.INVISIBLE);
    }

    public void goneView(int resourceId) {
        View view = this.findViewById(resourceId);
        if (view != null)
            view.setVisibility(View.GONE);
    }

    void removeView(int resourceId) {
        View view = this.findViewById(resourceId);
        if (view != null)
            view.setVisibility(View.GONE);
    }


    public boolean validate() {
        Log.d(TAG, "validate");
        boolean returnValue = true;
        ViewGroup layout = this.findViewById(R.id.layout);
        for (int i = 0; i < layout.getChildCount(); i++) {
            View view = layout.getChildAt(i);
            if (view instanceof BluDroidValidatable) {
                returnValue = ((BluDroidValidatable) view).validate() && returnValue;
            }
        }
        return returnValue;
    }

    public void onClick(View view) {
        Log.d(TAG, "onClick");
        BaseActivity.logger.info(((BluDroidButton) view).getText());

        BluDroidDialogable dialogable = null;
        if (baseFragment instanceof BluDroidDialogable) {
            dialogable = (BluDroidDialogable) baseFragment;
        } else if (baseActivity instanceof BluDroidDialogable) {
            dialogable = (BluDroidDialogable) baseActivity;
        }

        Log.d(TAG, "dialogable " + dialogable);
        Log.d(TAG, "dialogable baseFragment " + baseFragment);
        Log.d(TAG, "dialogable baseActivity " + baseActivity);

        if (dialogable != null) {
            switch (view.getId()) {
                case R.id.affirmativeButton:
                    Log.d(TAG, "affirmativeButton");
                    dialogable.affirmativeButton(view);
                    break;
                case R.id.negativeButton:
                    Log.d(TAG, "negativeButton");
                    dialogable.negativeButton(view);
                    break;
                case R.id.neutralButton:
                    Log.d(TAG, "neutralButton");
                    dialogable.neutralButton(view);
                    break;
                default:

            }
        } else {
            Log.d(TAG, "screen is not dialogable");
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.d(TAG, "BluDroidConfirmationDialog back pressed");
        checkToCloseSocket();
    }

    private void checkToCloseSocket() {
        if (!(this instanceof BluDroidVenueLayoutDialog)
                && !(this instanceof BluDroidPrintPreviewDialog)) {
            baseActivity.closeAeonSocket(19);
        }
    }
}

