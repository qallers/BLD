package za.co.blts.bltandroidgui3.widgets;

import android.widget.Toast;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;

/**
 * Created by NkosanaM on 3/9/2017.
 */

public class BluDroidNotification extends Toast {

    private WeakReference<BaseActivity> baseActivityWeakReference;

    public BluDroidNotification(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    public void createNotification(String message) {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                makeText(baseScreen, message, Toast.LENGTH_SHORT).show();
            }
        }
    }


}

