package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;

import za.co.blts.bltandroidgui3.R;


/**
 * Created by NkosanaM on 1/30/2017.
 */

public class BluDroidDivider extends LinearLayout {

    public BluDroidDivider(Context context) {
        super(context);
    }

    public BluDroidDivider(Context context, AttributeSet attrs) {
        super(context, attrs);
        setOrientation(HORIZONTAL);
        setGravity(Gravity.TOP);
        setBackgroundColor(getResources().getColor(R.color.lightGrey));

    }
}
