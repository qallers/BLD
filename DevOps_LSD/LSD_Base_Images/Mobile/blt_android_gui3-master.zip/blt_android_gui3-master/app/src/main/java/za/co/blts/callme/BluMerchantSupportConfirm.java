package za.co.blts.callme;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import za.co.blt.consumer.loyalty.api.service.model.response.Error;
import za.co.blts.bltandroidgui3.AEONErrors;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BluDroidVolley;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_URL;

public class BluMerchantSupportConfirm extends BaseActivity implements TextWatcher, View.OnClickListener {

    private BluDroidCellphoneEditText cell;
    private BluDroidCellphoneEditText confirmCell;
    private String checkId;
    private BluDroidVolley bluDroidVolley;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant_confirm);
        Intent intent = getIntent();

        checkId = intent.getStringExtra("checkId");

        cell = findViewById(R.id.cellNumber);
        confirmCell = findViewById(R.id.confirmCellNumber1);

        cell.addTextChangedListener(this);

        ImageView callme = findViewById(R.id.callme);
        Drawable image = getResources().getDrawable(R.drawable.callme);
        callme.setImageDrawable(image);
        Drawable roundDrawable = getResources().getDrawable(R.drawable.button_bg_shadow_rounded);
        roundDrawable.setColorFilter(getSkinResources().getButtonColor(), PorterDuff.Mode.MULTIPLY);
        callme.setBackground(roundDrawable);

        findViewById(R.id.nextButton).setOnClickListener(this);
        findViewById(R.id.cancelButton).setOnClickListener(this);

        bluDroidVolley = BluDroidVolley.getInstance(this);
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        resetTimer();

        int ccnt = cell.getText().toString().trim().length();
        if (ccnt > 0) {
            cell.removeErrorMessage();
        }
        if ((cell.maxLength != -1)) {
            int cnt = cell.getText().toString().trim().length();

            if (cnt == cell.maxLength) {
                confirmCell.requestFocus();
            }
        }
    }

    @Override
    public void afterTextChanged(Editable s) {
        int cnt = cell.getText().length();
        if (cnt == cell.maxLength) {
            cell.validate();
        }
    }

    private boolean validate() {
        if (cell.validate() && confirmCell.validate()) {
            //
            // two cell numbers must be the dame
            //
            String cellNumber = cell.getText().toString();
            String cellNumberConfirm = confirmCell.getText().toString();
            if (cellNumber.equals(cellNumberConfirm)) {
                return true;
            } else {
                cell.setErrorMessage(getResources().getString(R.string.cellNumbersDontMatch));
            }
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        if (bluDroidVolley != null) bluDroidVolley.cancelAll();
        super.onDestroy();
    }

    public void doRequest(String deviceId, String deviceSerialNumber, String telephone, String message) {


        String url = getPreference(PREF_LOYALTY_URL) + "/customer/support/help/v1/callme/bludroid";

        Map<String, String> params = new HashMap<>();
        params.put("deviceId", deviceId);
        params.put("deviceSerialNumber", deviceSerialNumber);
        params.put("telephone", telephone);
        params.put("message", message);

        JSONObject parameters = new JSONObject(params);

        JsonObjectRequest bludroidRequest = new JsonObjectRequest(Request.Method.POST, url, parameters,
                createReqSuccessListener(),
                createReqErrorListener());
        bludroidRequest.setTag(this);

        createProgress("Sending request");
        bluDroidVolley.addRequestApiGateway(bludroidRequest); // make sure that this is not null
        Log.d("CallMe", ">>>>>>>>>area request to: " + url);
    }

    public Response.Listener<JSONObject> createReqSuccessListener() {
        return new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                dismissProgress();
                gotoMerchantSupportMessageScreen(response.toString());
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    public Response.ErrorListener createReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dismissProgress();
                Log.e("CallMe", error.toString());
                Log.e("CallMe", "error.getMessage(): " + error.getMessage());
                Log.e("CallMe", "error.networkResponse.status: " + (error.networkResponse == null ? null : error.networkResponse.statusCode));

                String message;
                String errorMessage;
                if (error.networkResponse != null && error.networkResponse.data != null) {
                    try {
                        errorMessage = new String(error.networkResponse.data, StandardCharsets.UTF_8); // for UTF-8 encoding
                        Log.e("CallMe", "errorMessage: " + errorMessage);
                        Error error1 = new Gson().fromJson(errorMessage, Error.class);
                        message = error1.getMessage();
                    } catch (Exception e) {
                        message = "An unknown error occurred";
                    }
                } else {
                    message = "Could not connect";
                }

                logger.error(" " + message);
                createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, message, true);
            }
        };
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.nextButton:
                if (validate()) {
                    String devId = getPreference(PREF_DEVICE_ID);
                    String serialNum = getPreference(PREF_DEVICE_SER);
                    doRequest(devId, serialNum, cell.getText().toString(), "I have " + checkId);
                }
                break;
            case R.id.cancelButton:
                gotoLandingScreen();
                break;
        }
    }

    @Override
    public void onBackPressed() {
        gotoLandingScreen();
    }
}
