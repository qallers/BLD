package za.co.blts.nfc;

public interface NfcTappable {

    enum NfcOperation {
        UID(1),
        CHECK(2),
        FORMAT(3),
        READ(4),
        WRITE(5),
        ;

        private int value;

        NfcOperation(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    enum NfcStatus {
        SUCCESS(0),
        INVALID_CARD(1),
        INVALID_COMMAND(2),
        ERROR(3),
        ;

        private int value;

        NfcStatus(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    void readUid();

    void checkCard(NfcInstr readInstr);

    void readCard(NfcInstr readInstr);

    void writeCard(NfcInstr writeInstr);

    void formatCard(NfcInstr writeInstr);

    void cancelCard();

    void destroy();
}
