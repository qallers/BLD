package za.co.blts.bltandroidgui3;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.ImageView;

import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMeterNumberEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;

/**
 * Created by NkosanaM on 3/29/2017.
 */

public class BluDroidUpdateEskomMeterCardsDialog extends BluDroidConfirmationDialog implements BluDroidSetupable {


    public void setup() {
        super.setup();
        setAffirmativeButtonLabel(R.string.update);
        hideView(R.id.neutralButton);
        setNegativeButtonLabel(R.string.cancel);
        setHeading("Update Meter Cards");
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    public BluDroidUpdateEskomMeterCardsDialog(BaseActivity context) {
        super(context, R.layout.dialog_update_eskom_meter_cards);
        setup();
        Log.d(TAG, "update meter keys");
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public String getMeterNumber() {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            return meterEditText.getText().toString();
        } else {
            return "";
        }
    }

    public void setMeterNumber(String meterNumber) {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setText(meterNumber);
        }
    }


    public void setMeterNumberErrorMessage(String errorMessage) {
        BluDroidEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setErrorMessage(errorMessage);
        }
    }

}
