package za.co.blts.bltandroidgui3;

import android.content.Context;
import android.graphics.PorterDuff;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by warrenm on 2016/10/03.
 */

class CustomMenuListAdapter extends ArrayAdapter<RowItem> {

    private boolean consumerActive;

    public CustomMenuListAdapter(BaseActivity baseActivity, int resId, List<RowItem> data) {
        super(baseActivity, resId, data);
        consumerActive = baseActivity.isConsumerProfileActive();
    }

    public class ViewHolder {
        ImageView imageView;
        TextView textView;
    }


    public View getView(int position, View view, ViewGroup parent) {
        ViewHolder holder = new ViewHolder();
        RowItem rowItem = getItem(position);
        LayoutInflater mInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (view == null) {
            view = mInflater.inflate(R.layout.listview_item_row, parent, false);
            holder.textView = view.findViewById(R.id.textViewName);
            holder.imageView = view.findViewById(R.id.imageViewIcon);
            view.setTag(holder);

            if (position == (consumerActive ? 0 : 1)) {
                holder.imageView.setColorFilter(((BaseActivity) getContext()).getSkinResources().getAccentColor(), PorterDuff.Mode.SRC_ATOP);
                holder.textView.setTextColor(((BaseActivity) getContext()).getSkinResources().getAccentColor());
            }
        } else {
            holder = (ViewHolder) view.getTag();
        }

        holder.textView.setText(rowItem.getTitle());
        holder.imageView.setImageResource(rowItem.getImageId());

        //Mod to gui for  7" % 8" touchscreen devices
        if (getContext().getResources().getDisplayMetrics().densityDpi == DisplayMetrics.DENSITY_MEDIUM) {
            holder.textView.setTextSize(20);
            holder.textView.setPadding(0, 4, 0, 6);
        }

        return view;
    }


}
