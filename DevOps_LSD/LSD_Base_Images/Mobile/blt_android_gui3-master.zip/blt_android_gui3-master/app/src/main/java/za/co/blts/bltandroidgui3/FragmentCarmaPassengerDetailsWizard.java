package za.co.blts.bltandroidgui3;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseItemMessage;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDatePickerDialogSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidCheckBoxButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidIdNumberPassportEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidOtherEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidScrollView;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by MasiS on 2018/03/03.
 */

public class FragmentCarmaPassengerDetailsWizard extends BaseFragment implements NeedsAEONResults, AdapterView.OnItemSelectedListener {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidSpinner passenger_type_spinner;
    private LinearLayout indicator;
    private BluDroidScrollView scrollView;

    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.US);

    private BluDroidSpinner title_spinner;
    private BluDroidEditText passenger_adult_initials;
    private BluDroidEditText passenger_adult_last_name;
    private BluDroidCellphoneEditText passenger_cell_phone_number;
    private BluDroidLinearLayout passenger_cell_phone_number_layout;
    private BluDroidLinearLayout passenger_id_passport_layout;
    private BluDroidLinearLayout infant_layout;
    private BluDroidLinearLayout child_age_layout;
    private BluDroidLinearLayout layId;
    private BluDroidLinearLayout layPassport;
    private BluDroidCheckBoxButton has_infant_on_lap_checkbox;
    private BluDroidIdNumberPassportEditText passenger_id_number;
    private BluDroidOtherEditText passenger_passport_number;
    private BluDroidRadioButton radio_button_id_selected;
    private BluDroidRadioButton radio_button_passport_selected;
    private BluDroidEditText dateOfBirth;
    private BluDroidTextView infantOnLap;
    private ImageButton btnDatePicker;
    private List<String> titles = new ArrayList<>();

    private BluDroidDatePickerDialogSpinner dateAlertDialog = null;
    private CarmaPassenger currentPassenger;

    private int passengerIndex = 0;
    private int minAge = 0, maxAge = 0;

    public FragmentCarmaPassengerDetailsWizard() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        View rootView = inflater.inflate(R.layout.fragment_passenger_details_wizard2, container, false);
        //----------------------------------------------------------------------------------------------
        BluDroidButton next_passengers_details = rootView.findViewById(R.id.next_passengers_details);
        BluDroidButton cancel_number_of_passengers = rootView.findViewById(R.id.cancel_number_of_passengers);
        BluDroidButton back_number_of_passengers = rootView.findViewById(R.id.back_number_of_passengers);
//    passenger_details_view_pager = (BluDroidViewPager) rootView.findViewById(R.id.passenger_details_view_pager);
        passenger_type_spinner = rootView.findViewById(R.id.passenger_type_spinner);
        indicator = rootView.findViewById(R.id.indicators);
        scrollView = rootView.findViewById(R.id.passenger_details_view_pager);

        title_spinner = rootView.findViewById(R.id.title_spinner);
        passenger_adult_initials = rootView.findViewById(R.id.passenger_adult_initials);
        passenger_adult_last_name = rootView.findViewById(R.id.passenger_adult_last_name);

        passenger_adult_initials.setInputType(InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        passenger_adult_last_name.setInputType(InputType.TYPE_TEXT_FLAG_CAP_WORDS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);

        passenger_cell_phone_number_layout = rootView.findViewById(R.id.passenger_cell_phone_number_layout);
        passenger_cell_phone_number = rootView.findViewById(R.id.passenger_cell_phone_number);
        has_infant_on_lap_checkbox = rootView.findViewById(R.id.has_infant_on_lap_checkbox);
        child_age_layout = rootView.findViewById(R.id.child_age_layout);
        infant_layout = rootView.findViewById(R.id.infant_layout);
        passenger_id_passport_layout = rootView.findViewById(R.id.layIdPassport);
        passenger_id_number = rootView.findViewById(R.id.passenger_id_number);
        passenger_passport_number = rootView.findViewById(R.id.passenger_passport_number);
        radio_button_passport_selected = rootView.findViewById(R.id.radio_button_passport_selected);
        radio_button_id_selected = rootView.findViewById(R.id.radio_button_id_selected);
        infantOnLap = rootView.findViewById(R.id.infantOnLap);
        dateOfBirth = rootView.findViewById(R.id.dateOfBirth);
        btnDatePicker = rootView.findViewById(R.id.btnDatePicker);
        btnDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getBaseActivity().hideKeyboardFromView(btnDatePicker);
                dateOfBirth.removeErrorMessage();
                dateAlertDialog = getBaseActivity().createDatePickerDialogSpinner(getBaseActivity());

                dateAlertDialog.setPositiveOption("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dateOfBirth.setText(dateAlertDialog.getDate());
                    }
                });

                dateAlertDialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dateAlertDialog.dismiss();
                    }
                });

                dateAlertDialog.createDialog();
            }
        });

        layId = rootView.findViewById(R.id.layId);
        layPassport = rootView.findViewById(R.id.layPassport);


        next_passengers_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                next_navigate();
            }
        });

        cancel_number_of_passengers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { // back to
                BaseActivity.logger.info(((BluDroidButton) v).getText());
                getBaseActivity().bluDroidRoutesAndTimes = null;
                getBaseActivity().fragmentCarmaPassengerDetailsWizard = null;
                getBaseActivity().fragmentCarmaConfirmPurchaseTicket = null;
                getBaseActivity().availabilitySearchQuery = null;
                getBaseActivity().fragmentCarmaSearchResults = null;
                getBaseActivity().carmaResponseAvailabilityExtendedMessage = null;
                getBaseActivity().passengerDetails.clear();
                getBaseActivity().gotoFragment(new FragmentTickets(), "FragmentTickets");
            }
        });

        back_number_of_passengers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back_navigate();
            }
        });


        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getBaseActivity().carmaResponseTitleListMessage != null) {
            titles = new ArrayList<>();
            for (int i = 0; i < getBaseActivity().carmaResponseTitleListMessage.getData().getItems().size(); i++) {
                if (getBaseActivity().carmaResponseTitleListMessage.getData().getItems().get(i).getCarrierId().equals(getBaseActivity().bluDroidRoutesAndTimes.getCarrier()))
                    if (!titles.contains(getBaseActivity().carmaResponseTitleListMessage.getData().getItems().get(i).getName()))
                        titles.add(getBaseActivity().carmaResponseTitleListMessage.getData().getItems().get(i).getName());
            }
        }
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        Log.d(TAG, "onActivityCreated");
        Log.d(TAG, "in depart = " + getBaseActivity().bluDroidRoutesAndTimes);
        Log.d(TAG, "in return = " + getBaseActivity().bluDroidRoutesAndTimesReturn);

        Log.d(TAG, "currentPassenger = " + currentPassenger);

        populateScreen();
        setUIPageViewController();

        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
    }

    private void next_navigate() {
        if (validatePassenger()) {
            if (passengerIndex == getBaseActivity().passengerDetails.size() - 1) {

                for (Object p : getBaseActivity().passengerDetails) {
                    Log.d(TAG, p.toString());
                }

                if (!adultCheck()) {
                    getBaseActivity().createAlertDialog("Error", "At least one adult is required for this booking.");
                } else {
                    confirmPassengers();
                }

            } else {
                CarmaPassenger nextPassenger = getBaseActivity().passengerDetails.get(++passengerIndex);
                CarmaPassenger prevPassenger = currentPassenger;
                Log.d(TAG, "next passenger: " + passengerIndex + " - " + nextPassenger.getClass().getSimpleName());
                Log.d(TAG, currentPassenger.toString());
                if (nextPassenger instanceof CarmaPassengerInfant) {
                    currentPassenger = nextPassenger;
                    passenger_type_spinner.setSelection(2);
                    if (prevPassenger instanceof CarmaPassengerInfant) {
                        setInfantPassenger();
                    }
                } else if (nextPassenger instanceof CarmaPassengerChild) {
                    currentPassenger = nextPassenger;
                    passenger_type_spinner.setSelection(1);
                    if (prevPassenger instanceof CarmaPassengerChild) {
                        setChildPassenger();
                    }
                } else if (nextPassenger instanceof CarmaPassengerAdult) {
                    currentPassenger = nextPassenger;
                    passenger_type_spinner.setSelection(0);
                    if (prevPassenger instanceof CarmaPassengerAdult) {
                        setAdultPassenger();
                    }
                } else {
                    currentPassenger = nextPassenger;
                    passenger_type_spinner.setSelection(0);
                    if (prevPassenger instanceof CarmaPassengerAdult) {
                        setAdultPassenger();
                    }
                }
                setUIPageViewController();
            }
        }
    }

    private void confirmPassengers() {
        getBaseActivity().createPassengerConfirmDialog(getBaseActivity(), getBaseActivity().passengerDetails);
    }

    private boolean adultCheck() {
        for (Object cp : getBaseActivity().passengerDetails) {
            if (cp instanceof CarmaPassengerAdult) {
                return true;
            }
        }
        return false;
    }

    //----------------------------------------------------------------------------------------------
    private void back_navigate() {
//    if (view_pager_get_current_item < getBaseActivity().passengerDetails.size()) { // not equals, its an array vs actual size
        if (passengerIndex == 0) {
            if (getBaseActivity().fragmentCarmaSearchResults == null) {
                getBaseActivity().fragmentCarmaSearchResults = new FragmentCarmaSearchResults();
            }

            getBaseActivity().fragmentCarmaSearchResults.state = "Departure";

            getBaseActivity().fragmentCarmaPassengerDetailsWizard = null;
            getBaseActivity().passengerDetails.clear();
            getBaseActivity().gotoFragment(getBaseActivity().fragmentCarmaSearchResults, "FragmentCarmaSearchResults");
//      } else {
//        passenger_details_view_pager.setCurrentItem(view_pager_get_current_item - 1);
//      }
        } else {
            CarmaPassenger nextPassenger = getBaseActivity().passengerDetails.get(--passengerIndex);
            CarmaPassenger prevPassenger = currentPassenger;
            Log.d(TAG, "next passenger: " + passengerIndex + " - " + nextPassenger.getClass().getSimpleName());
            if (nextPassenger instanceof CarmaPassengerInfant) {
                currentPassenger = nextPassenger;
                passenger_type_spinner.setSelection(2);
                if (prevPassenger instanceof CarmaPassengerInfant) {
                    setInfantPassenger();
                }
            } else if (nextPassenger instanceof CarmaPassengerChild) {
                currentPassenger = nextPassenger;
                passenger_type_spinner.setSelection(1);
                if (prevPassenger instanceof CarmaPassengerChild) {
                    setChildPassenger();
                }
            } else if (nextPassenger instanceof CarmaPassengerAdult) {
                currentPassenger = nextPassenger;
                passenger_type_spinner.setSelection(0);
                if (prevPassenger instanceof CarmaPassengerAdult) {
                    setAdultPassenger();
                }
            } else {
                currentPassenger = nextPassenger;
                passenger_type_spinner.setSelection(0);
                if (prevPassenger instanceof CarmaPassengerAdult) {
                    setAdultPassenger();
                }
            }
            setUIPageViewController();
        }
    }

    //----------------------------------------------------------------------------------------------
    private void populateScreen() { // create fragments according to passenger type
//    getBaseActivity().passengerDetails.clear();
//    Log.d(TAG, "number of seats: " + getBaseActivity().availabilitySearchQuery.getTotalNumberOfSeatsToReserve());
//    for (int i = 0; i < getBaseActivity().availabilitySearchQuery.getTotalNumberOfSeatsToReserve(); i++) {
//      getBaseActivity().passengerDetails.add(new CarmaPassenger());
//    }

        String[] types = getResources().getStringArray(R.array.passenger_types);

        ArrayAdapter adapter = new ArrayAdapter<>(getBaseActivity(), android.R.layout.simple_spinner_item, types);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        passenger_type_spinner.setAdapter(adapter);
        passenger_type_spinner.setEnabled(true);

        passenger_type_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d(TAG, "passenger_type_spinner.onItemSelected - position: " + position);

                if (position == 0) {
                    setAdultPassenger();
                } else if (position == 1) {
                    if (currentPassenger instanceof CarmaPassengerAdult && has_infant_on_lap_checkbox.isChecked()) {
                        ((CarmaPassengerAdult) currentPassenger).setInfantOnLap(false);
                        getBaseActivity().passengerDetails.remove(passengerIndex + 1);
                        setUIPageViewController();
                    }
                    setChildPassenger();
                } else if (position == 2) {
                    if (currentPassenger instanceof CarmaPassengerAdult && has_infant_on_lap_checkbox.isChecked()) {
                        ((CarmaPassengerAdult) currentPassenger).setInfantOnLap(false);
                        getBaseActivity().passengerDetails.remove(passengerIndex + 1);
                        setUIPageViewController();
                    }
                    setInfantPassenger();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Log.d(TAG, "passenger_type_spinner.onNothingSelected");
            }
        });

    }

    private void clearValidationErrors() {
        passenger_adult_initials.removeErrorMessage();
        passenger_adult_last_name.removeErrorMessage();
        passenger_cell_phone_number.removeErrorMessage();
        passenger_id_number.removeErrorMessage();
        passenger_passport_number.removeErrorMessage();
        dateOfBirth.removeErrorMessage();
    }

    private void setAdultPassenger() {
        Log.d(TAG, "setAdultPassenger " + passengerIndex);

        boolean populate = true;
        if (!(currentPassenger instanceof CarmaPassengerAdult)) {
            Log.d(TAG, "updating position " + passengerIndex + " to CarmaPassengerAdult");
            currentPassenger = new CarmaPassengerAdult();
            getBaseActivity().passengerDetails.set(passengerIndex, currentPassenger);
            populate = false;
        }
        Log.d(TAG, "loading " + currentPassenger.toString());

        infantOnLap.setVisibility(View.GONE);
        passenger_type_spinner.setEnabled(true);

        child_age_layout.setVisibility(View.GONE);
        infant_layout.setVisibility(View.VISIBLE);
        passenger_cell_phone_number_layout.setVisibility(View.VISIBLE);
        passenger_id_passport_layout.setVisibility(View.VISIBLE);

        has_infant_on_lap_checkbox.setOnCheckedChangeListener(null);
        has_infant_on_lap_checkbox.setChecked(populate && ((CarmaPassengerAdult) currentPassenger).infantOnLap);
        passenger_adult_initials.setText(populate ? currentPassenger.getInitials() : "");
        passenger_adult_last_name.setText(populate ? currentPassenger.getLastName() : "");
        passenger_cell_phone_number.setText(populate ? ((CarmaPassengerAdult) currentPassenger).getCellNumber() : "");
        final String defId = "9009090909090";
        final String defPassport = "reutyeoiuytriutye";
        if (currentPassenger.isPassport()) {
            Log.d(TAG, "==========displaying passport");
            radio_button_passport_selected.setChecked(true);
            radio_button_id_selected.setChecked(false);
            layId.setVisibility(View.GONE);
            layPassport.setVisibility(View.VISIBLE);
            passenger_id_number.setText(defId);
            passenger_passport_number.setText(populate ? currentPassenger.getIdNumber() : "");
        } else {
            Log.d(TAG, "==========displaying id");
            radio_button_passport_selected.setChecked(false);
            radio_button_id_selected.setChecked(true);
            layId.setVisibility(View.VISIBLE);
            layPassport.setVisibility(View.GONE);
            passenger_id_number.setText(populate ? currentPassenger.getIdNumber() : "");
            passenger_passport_number.setText(defPassport);
        }

        radio_button_passport_selected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentPassenger.setPassport(true);
                passenger_id_number.setText(defId); // to bypass validation
                passenger_passport_number.setText(""); // reset text
                layId.setVisibility(View.GONE);
                layPassport.setVisibility(View.VISIBLE);
            }
        });

        radio_button_id_selected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentPassenger.setPassport(false);
                passenger_id_number.setText("");
                passenger_passport_number.setText(defPassport); //to bypass validation
                layId.setVisibility(View.VISIBLE);
                layPassport.setVisibility(View.GONE);
            }
        });

        has_infant_on_lap_checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Log.d(TAG, "infant on lap changed to " + b);
                if (b) {
                    Log.d(TAG, "adding infantOnLap to list at pos " + (passengerIndex + 1));
                    CarmaPassengerInfant infant = new CarmaPassengerInfant();
                    infant.setOnLap(true);
                    getBaseActivity().passengerDetails.add(passengerIndex + 1, infant);
                } else {
                    Log.d(TAG, "removing infantOnLap from list at pos " + (passengerIndex + 1));
                    getBaseActivity().passengerDetails.remove(passengerIndex + 1);
                }
                setUIPageViewController();
            }
        });

        configureTitleSpinner(currentPassenger.getTitle());

        scrollToTop();
    }

    private void setChildPassenger() {
        Log.d(TAG, "setChildPassenger " + passengerIndex);
        boolean populate = true;
        if (!(currentPassenger instanceof CarmaPassengerChild)) {
            Log.d(TAG, "updating position " + passengerIndex + " to CarmaPassengerChild");
            currentPassenger = new CarmaPassengerChild();
            getBaseActivity().passengerDetails.set(passengerIndex, currentPassenger);
            populate = false;
        }
        Log.d(TAG, "loading " + currentPassenger.toString());

        infantOnLap.setVisibility(View.GONE);
        passenger_type_spinner.setEnabled(true);

        child_age_layout.setVisibility(View.VISIBLE);
        infant_layout.setVisibility(View.GONE);
        passenger_cell_phone_number_layout.setVisibility(View.GONE);
        passenger_id_passport_layout.setVisibility(View.GONE);

        passenger_adult_initials.setText(populate ? currentPassenger.getInitials() : "");
        passenger_adult_last_name.setText(populate ? currentPassenger.getLastName() : "");
        dateOfBirth.setText(populate ? sdf.format(((CarmaPassengerChild) currentPassenger).getDob()) : "");

//    child_age.setText(populate ? ((CarmaPassengerChild) currentPassenger).getAgeInYears() + "" : "");

        configureTitleSpinner(currentPassenger.getTitle());

        scrollToTop();
    }

    private void setInfantPassenger() {
        Log.d(TAG, "setInfantPassenger " + passengerIndex);
        boolean populate = true;
        if (!(currentPassenger instanceof CarmaPassengerInfant)) {
            Log.d(TAG, "updating position " + passengerIndex + " to CarmaPassengerInfant");
            currentPassenger = new CarmaPassengerInfant();
            getBaseActivity().passengerDetails.set(passengerIndex, currentPassenger);
            populate = false;
        }
        Log.d(TAG, "loading " + currentPassenger.toString());

        if (((CarmaPassengerInfant) currentPassenger).isOnLap()) {
            infantOnLap.setVisibility(View.VISIBLE);
            passenger_type_spinner.setEnabled(false);
        } else {
            infantOnLap.setVisibility(View.GONE);
            passenger_type_spinner.setEnabled(true);
        }

        child_age_layout.setVisibility(View.VISIBLE);
        infant_layout.setVisibility(View.GONE);
        passenger_cell_phone_number_layout.setVisibility(View.GONE);
        passenger_id_passport_layout.setVisibility(View.GONE);

        passenger_adult_initials.setText(populate ? currentPassenger.getInitials() : "");
        passenger_adult_last_name.setText(populate ? currentPassenger.getLastName() : "");
        if (populate && ((CarmaPassengerInfant) currentPassenger).getDob() != null) {
            dateOfBirth.setText(sdf.format(((CarmaPassengerInfant) currentPassenger).getDob()));
        } else {
            dateOfBirth.setText("");
        }

        configureTitleSpinner(currentPassenger.getTitle());

        scrollToTop();
    }

    private void scrollToTop() {
//    scrollView.postDelayed(new Runnable() {
//      @Override
//      public void run() {
//        scrollView.fullScroll(ScrollView.FOCUS_UP);
//        passenger_adult_initials.requestFocus();
//        clearValidationErrors();
//      }
//    }, 300);

        scrollView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                // Ready, move up
                scrollView.fullScroll(View.FOCUS_UP);
                passenger_adult_initials.requestFocus();
                clearValidationErrors();
                scrollView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });
    }

    private boolean validatePassenger() {
        if (currentPassenger instanceof CarmaPassengerAdult) {
            return validatePassenger((CarmaPassengerAdult) currentPassenger);
        } else if (currentPassenger instanceof CarmaPassengerChild) {
            return validatePassenger((CarmaPassengerChild) currentPassenger);
        } else { //currentPassenger instanceof CarmaPassengerInfant
            return validatePassenger((CarmaPassengerInfant) currentPassenger);
        }
    }

    private boolean validatePassenger(CarmaPassengerAdult passenger) {
        Log.d(TAG, "validate adult");
        boolean ret = true;

        passenger.setInfantOnLap(has_infant_on_lap_checkbox.isChecked());

        if (!passenger_adult_initials.validate()) {
            Log.e(TAG, "error on initials");
            ret = false;
        } else {
            passenger.setInitials(passenger_adult_initials.getText().toString());
        }
        if (!passenger_adult_last_name.validate()) {
            Log.e(TAG, "error on lastname");
            ret = false;
        } else {
            passenger.setLastName(passenger_adult_last_name.getText().toString());
        }
        if (!passenger_cell_phone_number.validate()) {
            Log.e(TAG, "error on cell");
            ret = false;
        } else {
            passenger.setCellNumber(passenger_cell_phone_number.getText().toString());
        }
        if (radio_button_id_selected.isChecked()) {
            if (!passenger_id_number.getText().toString().isEmpty() && !passenger_id_number.validate()) {
                Log.e(TAG, "error on id");
                ret = false;
            } else {
                passenger.setPassport(false);
                passenger.setIdNumber(passenger_id_number.getText().toString());
            }
        } else {
            if (!passenger_passport_number.getText().toString().isEmpty() && !passenger_passport_number.validate()) {
                Log.e(TAG, "error on passport");
                ret = false;
            } else {
                passenger.setPassport(true);
                passenger.setIdNumber(passenger_passport_number.getText().toString());
            }
        }

        Log.d(TAG, "validate success = " + ret);
        return ret;
    }

    private boolean validatePassenger(CarmaPassengerChild passenger) {
        Log.d(TAG, "validate child");
        boolean ret = true;

        if (!passenger_adult_initials.validate()) {
            Log.e(TAG, "error on initials");
            ret = false;
        } else {
            passenger.setInitials(passenger_adult_initials.getText().toString());
        }
        if (!passenger_adult_last_name.validate()) {
            Log.e(TAG, "error on lastname");
            ret = false;
        } else {
            passenger.setLastName(passenger_adult_last_name.getText().toString());
        }

        try {
            passenger.setDob(sdf.parse(dateOfBirth.getText().toString()));
            int months = BluDroidUtils.getAgeInMonths(passenger.getDob());
            Log.d(TAG, "age in months: " + months);
            getMinMaxAges();

            if (months < minAge || months > maxAge) {
                Log.e(TAG, "error on age");
                String minAgeStr = getAgeString(minAge);
                String maxAgeStr = getAgeString(maxAge);
                dateOfBirth.setErrorMessage("Must be between " + minAgeStr + " and " + maxAgeStr);
                ret = false;
            }

        } catch (ParseException e) {
            Log.e(TAG, "error on age");
            Log.e(TAG, e.getMessage(), e);
            dateOfBirth.setErrorMessage("Required");
            ret = false;
        }

        Log.d(TAG, "validate success = " + ret);
        return ret;
    }

    private boolean validatePassenger(CarmaPassengerInfant passenger) {
        Log.d(TAG, "validate infant");
        boolean ret = true;

        if (!passenger_adult_initials.validate()) {
            Log.e(TAG, "error on initials");
            ret = false;
        } else {
            passenger.setInitials(passenger_adult_initials.getText().toString());
        }
        if (!passenger_adult_last_name.validate()) {
            Log.e(TAG, "error on lastname");
            ret = false;
        } else {
            passenger.setLastName(passenger_adult_last_name.getText().toString());
        }

        try {
            passenger.setDob(sdf.parse(dateOfBirth.getText().toString()));
            int months = BluDroidUtils.getAgeInMonths(passenger.getDob());
            Log.d(TAG, "age in months: " + months);
            getMinMaxAges();

            if (months < minAge || months > maxAge) {
                Log.e(TAG, "error on age");
                dateOfBirth.setErrorMessage("Must be " + maxAge + " months or younger");
                ret = false;
            }

        } catch (ParseException e) {
            Log.e(TAG, "error on age");
            Log.e(TAG, e.getMessage(), e);
            dateOfBirth.setErrorMessage("Required");
            ret = false;
        }

        Log.d(TAG, "validate success = " + ret);
        return ret;
    }

    private String getAgeString(int months) {
        if (months <= 36) {
            return months + " months";
        } else {
            int y = months / 12;
            int m = months % 12;
            return ((y > 0 ? y + " years " : "") + (m > 0 ? m + " months" : "")).trim();
        }
    }

    private void getMinMaxAges() {
        Log.d(TAG, "getMinMaxAge for " + currentPassenger.getClass().getSimpleName());
        String carrier = getBaseActivity().bluDroidRoutesAndTimes.getCarrier();
        String type = passenger_type_spinner.getSelectedItem().toString();
        minAge = 0;
        maxAge = 0;
        for (CarmaResponseItemMessage c : getBaseActivity().carmaResponsePassengerTypeListMessage.getData().getItems()) {
            if (c.getCarrierId().equals(carrier) && c.getName().equalsIgnoreCase(type)) {
                Log.d(TAG, c.toString());
                try {
                    minAge = Integer.parseInt(c.getMinAge());
                } catch (NumberFormatException nfe) {
                    nfe.printStackTrace();
                    BaseActivity.logger.error("getMinAge exception" + nfe);
                }
                try {
                    maxAge = Integer.parseInt(c.getMaxAge());
                } catch (NumberFormatException nfe) {
                    nfe.printStackTrace();
                    BaseActivity.logger.error("getMaxAge exception" + nfe);
                }
                break;
            }
        }
        Log.d(TAG, "min=" + minAge + " max=" + maxAge);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean onBackPressed() {
        back_navigate();
        return true;
    }

    private void configureTitleSpinner(String selectTitle) {
        if (titles.isEmpty()) {
            titles.add("Dr");
            titles.add("Mr");
            titles.add("Mrs");
            titles.add("Ms");
        }

        title_spinner.setAdapter(new ArrayAdapter<>(getBaseActivity(), android.R.layout.simple_spinner_item, titles));
        title_spinner.setFocusable(true);
        title_spinner.setOnItemSelectedListener(this);

        // default to Mr/Mrs
        for (int i = 0; i < titles.size(); i++) {
            String title = titles.get(i);
            if (selectTitle == null || selectTitle.isEmpty()) {
                if (title.equalsIgnoreCase("Mister") || title.equalsIgnoreCase("Mrs")) {
                    title_spinner.setSelection(i);
                    break;
                }
            } else {
                if (title.equalsIgnoreCase(selectTitle)) {
                    title_spinner.setSelection(i);
                    break;
                }
            }
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        CarmaPassenger passenger = getBaseActivity().passengerDetails.get(passengerIndex);
        passenger.setTitle((String) parent.getItemAtPosition(position));
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // do nothing
    }

    //----------------------------------------------------------------------------------------------
    public void results(Object obj) {
    }

    //----------------------------------------------------------------------------------------------
    private void setUIPageViewController() {
        int mDotCount = getBaseActivity().passengerDetails.size();
        LinearLayout[] mDots = new LinearLayout[mDotCount];
        indicator.removeAllViews();
        for (int i = 0; i < mDotCount; i++) {
            mDots[i] = new LinearLayout(getBaseActivity());
            if (i == passengerIndex) {
                mDots[i].setBackgroundResource(R.drawable.selected_item);
            } else {
                mDots[i].setBackgroundResource(R.drawable.nonselected_item);
            }
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );

            params.setMargins(4, 0, 4, 0);
            indicator.addView(mDots[i], params);
        }
    }

}