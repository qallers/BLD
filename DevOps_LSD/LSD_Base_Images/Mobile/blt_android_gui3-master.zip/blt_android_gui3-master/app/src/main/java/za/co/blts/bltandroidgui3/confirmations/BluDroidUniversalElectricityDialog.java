package za.co.blts.bltandroidgui3.confirmations;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidMeterNumberEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMoneyEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;
import za.co.blts.magcard.BluDroidMagCardAsyncReponse;

import static android.view.View.GONE;

/**
 * Created by NkosanaM on 3/23/2017.
 */

public class BluDroidUniversalElectricityDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, BluDroidMagCardAsyncReponse {
    private final String TAG = this.getClass().getSimpleName();
    //    private boolean meterNumberFromSpinner = false;

    public void setup() {
        super.setup();
        setAffirmativeButtonLabel(R.string.confirm);
        setNeutralButtonLabel(R.string.fbe);
        setNegativeButtonLabel(R.string.cancel);
        setHeading("Universal Electricity");

        BluDroidButton swipeCard = findViewById(R.id.swipeCard);

        if (baseActivity.openMagEncoder()) {

            baseActivity.magCard.setDelegate(this);

            swipeCard.setVisibility(View.VISIBLE);

            swipeCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    BaseActivity.logger.info(((BluDroidButton) v).getText());
                    baseActivity.magCard.openUsbSerial();
                    baseActivity.createMagEncoderAlertDialog("Mag Card", "Please swipe card to read");
                    baseActivity.magCard.sendReadCommand();
                    baseActivity.magCardAction = "read";
                }
            });
        } else {
            swipeCard.setVisibility(GONE);
        }


        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }

    private void setupSpinner(String municname) {
        final Spinner meterNumberSpinner = findViewById(R.id.meterNumberSpinner);
        final BluDroidLinearLayout buttonLayout = findViewById(R.id.buttonLayout);
        final BluDroidMeterNumberEditText meterNumber = findViewById(R.id.meterNumber);

        final List<String> meterNumbers = new ArrayList<>();

        if (checkCustomerProfileAccountNumbers(municname, meterNumbers)) {
            meterNumbers.add(0, "Other");
            meterNumberSpinner.setVisibility(View.VISIBLE);
            buttonLayout.setVisibility(View.GONE);
//            meterNumberFromSpinner = true;

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(baseActivity, android.R.layout.simple_spinner_item, meterNumbers);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            meterNumberSpinner.setAdapter(dataAdapter);
            //although meterNumber is hidden, update this with the selected spinner value, so the dialog validate() will pass
            meterNumber.setText(meterNumbers.get(1));
            meterNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i == 0) {
                        onNothingSelected(null);
                    } else {
                        meterNumber.setText(meterNumbers.get(i));
                        buttonLayout.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    meterNumber.setText("");
                    buttonLayout.setVisibility(View.VISIBLE);
                }
            });
            meterNumberSpinner.setSelection(1);

        } else {
            meterNumberSpinner.setVisibility(View.GONE);
            buttonLayout.setVisibility(View.VISIBLE);
//            meterNumberFromSpinner = false;
        }

    }

    private boolean checkCustomerProfileAccountNumbers(String municName, List<String> accountNumbers) {
        if (BaseActivity.consumerProfile != null && baseActivity.customerProfileElectricityAccountNumbers != null) {
            String[] accounts = baseActivity.customerProfileElectricityAccountNumbers.get(municName);
            if (accounts != null && accounts.length > 0) {
                accountNumbers.addAll(Arrays.asList(accounts));
                return true;
            }
        }
        return false;
    }

    public BluDroidUniversalElectricityDialog(BaseFragment context) {
        super(context, R.layout.dialog_universal_electricity);
        setup();
        Log.d(TAG, "Purchase confirmation with activity");
        BaseActivity.logger.info(": construction with BaseFragment");
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public void setMunicName(String municName) {
        BluDroidTextView municNameTextView = findViewById(R.id.munic);
        if (municNameTextView != null) {
            municNameTextView.setText(municName);
            setupSpinner(municName);
        }
    }

    public String getMunicName() {
        BluDroidTextView municNameTextView = findViewById(R.id.munic);
        if (municNameTextView != null) {
            return municNameTextView.getText().toString();
        } else {
            return "";
        }
    }

    public String getMeterNumber() {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            return meterEditText.getText().toString();
        }
        return "";

    }

    private void setMeterNumber(String meterNumber) {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setText(meterNumber);
        }
    }

    public String getAmount() {
        BluDroidMoneyEditText amountEditText = findViewById(R.id.amount);
        if (amountEditText != null) {
            return amountEditText.getText().toString();
        } else {
            return "0.00";
        }
    }

    public void setAmount(String amount) {
        BluDroidMoneyEditText amountEditText = findViewById(R.id.amount);
        if (amountEditText != null) {
            amountEditText.setText(amount);
        }
    }

    public void setMeterNumberErrorMessage(String errorMessage) {
        BluDroidEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setErrorMessage(errorMessage);
        }
    }

    public void setAmountrErrorMessage(String errorMessage) {
        BluDroidMoneyEditText amountEditText = findViewById(R.id.amount);
        if (amountEditText != null) {
            amountEditText.setErrorMessage(errorMessage);
        }
    }

    @Override
    public void processFinish(String output) {
        if (baseActivity.alert != null) {
            baseActivity.alert.dismiss();
        }

        if (output.toLowerCase().contains("success")) {
            setMeterNumber(baseActivity.magCard.getTracks().get(1));
        } else {
            baseActivity.createAlertDialog("Mag Encoder", output);
        }

    }
}
