package za.co.blts.nfcbus;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;


class StopAdapter extends ArrayAdapter<Stop> {
    private final String TAG = this.getClass().getSimpleName();

    public StopAdapter(Context context, int layoutResourceId, List<Stop> dataSet) {
        super(context, layoutResourceId, dataSet);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final Stop stop = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_spinner_dropdown_item, parent, false);
        }
        TextView text = convertView.findViewById(android.R.id.text1);
        text.setText(stop == null ? "Please select" : stop.getName());

        return convertView;
    }

    @Override
    public View getDropDownView(final int position, View convertView, ViewGroup parent) {
        final Stop stop = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_spinner_dropdown_item, parent, false);
        }
        TextView text = convertView.findViewById(android.R.id.text1);
        text.setText(stop == null ? "Please select" : stop.getName());

        return convertView;
    }


}
