package za.co.blts.bltandroidgui3.confirmations;

import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMoneyEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BP_LIMIT;

/**
 * Created by NkosanaM on 3/23/2017.
 */

public class BluDroidBillPaymentsConfirmationDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, View.OnClickListener {

    @SuppressWarnings("FieldCanBeLocal")
    private final String TAG = this.getClass().getSimpleName();

    private String supplierCode;
    private BluDroidRelativeLayout layout;

    public void setup() {
        super.setup();
        // setIcon(baseActivity.getResources().getDrawable(R.drawable.eskom_confirm));
        hideView(R.id.neutralButton);
        setAffirmativeButtonLabel(R.string.print);
        setNegativeButtonLabel(R.string.cancel);
        setHeading(R.string.confirm_purchase);
        setClickListeners();
        layout = findViewById(R.id.layout);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }


    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }

    private void setClickListeners() {

        String ecocashWarning = "Please make sure the customer has sufficient funds. No refunds are allowed.";

        if (baseActivity.productName.toLowerCase().contains("ecocash")) {
            TextView ecocashWarningText = findViewById(R.id.ecocashWarning);
            ecocashWarningText.setText(ecocashWarning);
            ecocashWarningText.setTypeface(null, Typeface.BOLD);
            ecocashWarningText.setTextColor(Color.parseColor("#FF0000"));
        }

        BluDroidButton cashButton = findViewById(R.id.cashButton);
        BluDroidButton debitButton = findViewById(R.id.debitCardButton);
        BluDroidButton creditButton = findViewById(R.id.creditCardButton);

        cashButton.setOnClickListener(this);
        debitButton.setOnClickListener(this);
        creditButton.setOnClickListener(this);
    }

    public String getSupplierCode() {
        return supplierCode;
    }


    public BluDroidBillPaymentsConfirmationDialog(BaseActivity context) {
        super(context, R.layout.confirmation_bill_payment);
        setup();
        Log.d(TAG, "Purchase confirmation with activity");
    }

    public void setAccountNumber(String accountNumber) {
        BluDroidTextView accountNumberView = findViewById(R.id.accountNumber);
        if (accountNumberView != null) {
            accountNumberView.setText(accountNumber);
        }
    }


    public void setAccountHolder(String accountHolder) {
        BluDroidTextView amountTextView = findViewById(R.id.customer);
        if (amountTextView != null) {
            amountTextView.setText(accountHolder);
        }
    }


    public void setAmountDue(String amountDue) {
        BluDroidTextView amountTextView = findViewById(R.id.amountDue);
        if (amountTextView != null) {
            amountTextView.setText(amountDue);
        }
    }

    public void setConvienceFee(String convienceFee) {
        BluDroidTextView amountTextView = findViewById(R.id.convenience);
        if (amountTextView != null) {
            amountTextView.setText(convienceFee);
        }
    }

    public void setTotalPayable(String payable) {
        BluDroidTextView amountTextView = findViewById(R.id.total);
        if (amountTextView != null) {
            amountTextView.setText(payable);
        }
    }

    public void setpartPayment(String partPayment) {
        BluDroidTextView amountTextView = findViewById(R.id.partPayment);
        if (amountTextView != null) {
            amountTextView.setText(partPayment);
        }
    }


    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.blubillLogo);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    private String getAmount() {
        BluDroidEditText amountEditText = findViewById(R.id.amount);

        String amount = "";
        if (amountEditText != null) {
            amount = amountEditText.getText().toString();
        }

        return amount;
    }

    public void setAmount(String amount) {
        BluDroidMoneyEditText amountEditText = findViewById(R.id.amount);
        if (amountEditText != null) {
            amountEditText.setText(amount);
            amountEditText.setEnabled(false);
        }
    }


    @Override
    public void onClick(View view) {
        //BaseActivity.logger.info(": onClick()");
        BaseActivity.logger.info(((BluDroidButton) view).getText());
        if (layout.validate()) {


            double amount = Double.parseDouble(getAmount());
            double bpLimit = Double.parseDouble(baseActivity.getPreference(PREF_BP_LIMIT));

            //this is the amount to be displayed as payable on the confirm payment dialog
            final Double total = amount + baseActivity.bpConvienceFee;


            if (view.getId() == R.id.cashButton) {

                if (amount <= bpLimit) {

                    /*if  (baseActivity.productName.toLowerCase().contains("ecocash")) {


                        baseActivity.createEcocashAlertDialog("Confirm Bill Payment", ecocashWarning + "\nAmount Due R" + df2.format(total));
                        baseActivity.alert.setPositiveOption("Continue", new OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                baseActivity.payBluBillAccount(getAmount(), "cash");
                            }
                        });
                    }

                    else {*/
                    baseActivity.createBillPaymentsAlertDialog("Confirm Bill Payment", "Amount Due R" + baseActivity.df2.format(total));

                    baseActivity.alert.setPositiveOption("Continue", new OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (baseActivity.possibleTitle.toLowerCase().contains("blubill")) {

                                baseActivity.payBluBillAccount(getAmount(), "cash");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("pay@")) {

                                baseActivity.payPayAtAccount(getAmount(), "cash");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("syntell")) {

                                baseActivity.paySyntellAccount(getAmount(), "cash");
                            }
                            //this is the amount used for tender

                            baseActivity.amount = total.toString();
                        }
                    });
                    // }
                    baseActivity.alert.show();

                } else {

                    baseActivity.createBillPaymentsAlertDialog("Bill Payment Limit Exceeded",
                            "Do you wish to continue with the payment of R" + baseActivity.df2.format(total) + "?");

                    baseActivity.alert.setPositiveOption("Continue", new OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            if (baseActivity.possibleTitle.toLowerCase().contains("blubill")) {
                                baseActivity.payBluBillAccount(getAmount(), "cash");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("pay@")) {
                                baseActivity.payPayAtAccount(getAmount(), "cash");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("syntell")) {
                                baseActivity.paySyntellAccount(getAmount(), "cash");
                            }

                            //this is the amount used for tender
                            baseActivity.amount = total.toString();
                        }
                    });

                    baseActivity.alert.show();
                }


            } else if (view.getId() == R.id.debitCardButton) {

                if (amount <= bpLimit) {

                    baseActivity.createBillPaymentsAlertDialog("Confirm Bill Payment", "Amount Due R" + baseActivity.df2.format(total));

                    baseActivity.alert.setPositiveOption("Continue", new OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (baseActivity.possibleTitle.toLowerCase().contains("blubill")) {

                                baseActivity.payBluBillAccount(getAmount(), "debitCard");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("pay@")) {

                                baseActivity.payPayAtAccount(getAmount(), "debitCard");
                            } else if (baseActivity.possibleTitle.toLowerCase().contains("syntell")) {

                                baseActivity.paySyntellAccount(getAmount(), "debitCard");
                            }
                            //this is the amount used for tender
                            baseActivity.amount = total.toString();
                        }
                    });
                    baseActivity.alert.show();

                } else {

                    baseActivity.createBillPaymentsAlertDialog("Bill Payment Limit Exceeded",
                            "Do you wish to continue with the payment of R" + baseActivity.df2.format(total) + "?");

                    baseActivity.alert.setPositiveOption("Continue", new OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            if (baseActivity.possibleTitle.toLowerCase().contains("blubill")) {
                                baseActivity.payBluBillAccount(getAmount(), "debitCard");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("pay@")) {
                                baseActivity.payPayAtAccount(getAmount(), "debitCard");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("syntell")) {
                                baseActivity.paySyntellAccount(getAmount(), "debitCard");
                            }

                            //this is the amount used for tender
                            baseActivity.amount = total.toString();
                        }
                    });

                    baseActivity.alert.show();
                }


            } else if (view.getId() == R.id.creditCardButton) {

                if (amount <= bpLimit) {

                    baseActivity.createBillPaymentsAlertDialog("Confirm Bill Payment", "Amount Due R" + baseActivity.df2.format(total));

                    baseActivity.alert.setPositiveOption("Continue", new OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (baseActivity.possibleTitle.toLowerCase().contains("blubill")) {
                                baseActivity.payBluBillAccount(getAmount(), "creditCard");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("pay@")) {
                                baseActivity.payPayAtAccount(getAmount(), "creditCard");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("syntell")) {
                                baseActivity.paySyntellAccount(getAmount(), "creditCard");
                            }

                            //this is the amount used for tender
                            baseActivity.amount = total.toString();
                        }
                    });
                    baseActivity.alert.show();

                } else {
                    baseActivity.createBillPaymentsAlertDialog("Bill Payment Limit Exceeded",
                            "Do you wish to continue with the payment of R" + baseActivity.df2.format(total) + "?");

                    baseActivity.alert.setPositiveOption("Continue", new OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            if (baseActivity.possibleTitle.toLowerCase().contains("blubill")) {
                                baseActivity.payBluBillAccount(getAmount(), "creditCard");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("pay@")) {
                                baseActivity.payPayAtAccount(getAmount(), "creditCard");

                            } else if (baseActivity.possibleTitle.toLowerCase().contains("syntell")) {
                                baseActivity.paySyntellAccount(getAmount(), "creditCard");
                            }

                            //this is the amount used for tender
                            baseActivity.amount = total.toString();
                        }
                    });

                    baseActivity.alert.show();
                }
            }

            dismiss();
        }
    }

    public void hideComponents() {
        removeView(R.id.customerLabel);
        removeView(R.id.customer);
        removeView(R.id.amountDueLabel);
        removeView(R.id.amountDue);
        removeView(R.id.convenienceLabel);
        removeView(R.id.convenience);
        removeView(R.id.totalLabel);
        removeView(R.id.total);
        removeView(R.id.partPaymentLabel);
        removeView(R.id.partPayment);
    }

}
