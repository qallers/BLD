package za.co.blts.bltandroidgui3.confirmations.printPreview;

import java.lang.ref.WeakReference;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;

public class BluDroidSlipPreviewLottoDialog extends BluDroidSlipPreviewDialog {
    private final String TAG = this.getClass().getSimpleName();
    private WeakReference<BaseActivity> activityReference;

    public BluDroidSlipPreviewLottoDialog(final BaseActivity activity, List<PrintJob> printJobs) {
        super(activity, printJobs);
        activityReference = new WeakReference<>(activity);
        setTitle("Lotto Preview");
        setup();
    }

    public void finishTransaction() {
        BaseActivity activity = activityReference.get();
        if (activity != null) {
            activity.completeLotto();
        }
    }
}
