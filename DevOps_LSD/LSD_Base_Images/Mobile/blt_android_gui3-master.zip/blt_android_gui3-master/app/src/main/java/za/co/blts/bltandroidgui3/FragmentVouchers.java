package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import za.co.blt.interfaces.external.messages.chat4change.response.Chat4ChangeResponseSupplierMessage;

/**
 * Created by warrenm on 2016/10/03.
 */

public class FragmentVouchers extends VoucherRecycler {
    private final String TAG = this.getClass().getSimpleName();

    private String filteredCriteria = "";
    private String providerName = "";

    public FragmentVouchers() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_vouchers, container, false);
        recycler = rootView.findViewById(R.id.bluRecycler);

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (getArguments() != null) {
            filteredCriteria = getArguments().getString("filteredCriteria");
            providerName = getArguments().getString("providerName");
        }

        Log.d(TAG, "filteredCriteria: " + filteredCriteria);
        Log.d(TAG, "providerName: " + providerName);

        getActivity().setTitle(filteredCriteria);
        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();

        if (filteredCriteria.equals("Airtime") || filteredCriteria.equals("Data")) {
            setupRecycler(filteredCriteria);
            adapter.setFilter(providerName);
        } else if (filteredCriteria.equals("Pinless Topup")) {
            configureRecycler(createPinlessTopupCards());
            adapter.setFilter(providerName);
        } else if (filteredCriteria.equals("Pinless Bundle")) {
            configureRecycler(createBundledPinlessTopupCards(retrieveBundleMap()));
            adapter.setFilter(providerName);
        } else {

            if (BaseActivity.voucherListResponseMessage != null) {
                boolean isMvNo = false;
                if (((BaseActivity) getActivity()).getCachedMVNOData() != null) {
                    for (Chat4ChangeResponseSupplierMessage message : ((BaseActivity) getActivity()).getCachedMVNOData().getData().getSuppliers()) {
                        if (message.getName().equalsIgnoreCase(filteredCriteria)) {
                            isMvNo = true;
                            //currently selected mvno supplier
                            BaseActivity.supplierName = filteredCriteria;

                            populateScreenWithMVNO();
                            break;
                        }
                    }
                }
                if (!isMvNo) {
                    populateScreen();
                }
            }
        }
    }

    private void populateScreenWithMVNO() {
        setUpMVONRecycler();
        adapter.setFilter(filteredCriteria);
    }

    public void populateScreen() {
        setupRecycler("VoucherOther");
        adapter.setFilter(filteredCriteria);
    }

    @Override
    public boolean onBackPressed() {

        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else if (getBaseActivity().navigatedFromSearch) {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentSearch(), "FragmentSearch").commit();
        } else {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentVouchersMenu(), "FragmentVouchersMenu").commit();
        }

        return true;
    }


}