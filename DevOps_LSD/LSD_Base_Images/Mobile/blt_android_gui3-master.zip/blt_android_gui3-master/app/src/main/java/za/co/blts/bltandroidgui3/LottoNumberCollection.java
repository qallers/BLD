package za.co.blts.bltandroidgui3;

import java.util.Set;
import java.util.TreeSet;

/**
 * Created by warrenm on 2016/03/24.
 */
class LottoNumberCollection {

    private Set<Integer> numbers = new TreeSet<>();

    public Set<Integer> getNumbers() {
        return numbers;
    }

    public void setNumbers(Set<Integer> numbers) {
        this.numbers = numbers;
    }

    public boolean isComplete() {
        return numbers.size() == 6;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();

        for (Integer number : numbers) {
            if (stringBuilder.length() == 0) {
                stringBuilder.append(number);
            } else {
                stringBuilder.append(',');
                stringBuilder.append(number);
            }
        }

        return stringBuilder.toString();
    }

}
