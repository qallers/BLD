package za.co.blts.bltandroidgui3.confirmations;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCheckBoxButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

//
// view and button stuff
//

public class BluDroidVoucherPurchaseConfirmationDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, OnClickListener, CompoundButton.OnCheckedChangeListener {
    private final String TAG = this.getClass().getSimpleName();

    private String supplierCode;
    private boolean isMVNO = false;
    private int qty = 1;
    private boolean isAirtimePlusPlayed;

    public void setup() {
        super.setup();
        setupButtons();
        setAffirmativeButtonLabel(R.string.print);
        setNegativeButtonLabel(R.string.cancel);
        setHeading(R.string.confirm_purchase);
        disableButton(R.id.minusButton);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    void setupButton(int resourceId) {
        BluDroidButton button = findViewById(resourceId);
        if (button != null) {
            button.setOnClickListener(this);
        }
    }

    public void setSupplierCode(String supplierCode) {
        this.supplierCode = supplierCode;
    }

    public String getSupplierCode() {
        return supplierCode;
    }

    private void setupButtons() {
        hideView(R.id.neutralButton);
        setupButton(R.id.plusButton);
        setupButton(R.id.minusButton);

    }

    public void showAirtimePlus() {
        BluDroidLinearLayout layout = findViewById(R.id.airtimeplusLayout);
        if (layout != null) {
            layout.setVisibility(View.VISIBLE);
            setAirtimePlusAmount();

            BluDroidCheckBoxButton playAirtimePlus = findViewById(R.id.airtimePlusCheckBox);
            playAirtimePlus.setOnCheckedChangeListener(this);

            calculateAmountDue(qty);
        }


    }

    public void hideAirtimePlus() {
        BluDroidLinearLayout layout = findViewById(R.id.airtimeplusLayout);
        if (layout != null) {
            layout.setVisibility(View.INVISIBLE);
        }
    }

    private void setAirtimePlusAmount() {
        BluDroidTextView amountTextView = findViewById(R.id.airtimeplus);
        if (amountTextView != null) {
            try {
                String disp = amountTextView.getText().toString() + "(R" + baseActivity.df2.format(Double.parseDouble(baseActivity.airtimePlusValue)) + ")";
                amountTextView.setText(disp);

            } catch (Exception ex) {
                Log.d(TAG, "setAirtimePlusAmount: " + ex.getMessage());
            }
        }
    }


    private void resetAirtimePlusTotal() {
        BluDroidTextView airtimePlusTotal = findViewById(R.id.airtimePlusTotal);


        if (airtimePlusTotal != null) {
            try {
                String disp = "R0.00";
                airtimePlusTotal.setText(disp);
            } catch (Exception ex) {
                Log.d(TAG, "resetAirtimePlusTotal: " + ex.getMessage());
            }
        }
    }


    private void enableButton(int resourceId) {
        BluDroidButton button = findViewById(resourceId);
        if (button != null) {
            button.setEnabled(true);
            button.setBackgroundColor(baseActivity.getSkinResources().getButtonColor());
        }
    }

    private void disableButton(int resourceId) {
        BluDroidButton button = findViewById(resourceId);
        if (button != null) {
            button.setEnabled(false);
            button.setBackgroundColor(baseActivity.getResources().getColor(R.color.lightGrey));
        }
    }

    public BluDroidVoucherPurchaseConfirmationDialog(BaseFragment context) {
        super(context, R.layout.confirmation_purchase_voucher);
        setup();
        Log.d(TAG, "Purchase confirmation with fragment");
        BaseActivity.logger.info(": construction with BaseFragment");
    }


    public void setAmount(String amount) {
        BluDroidTextView amountTextView = findViewById(R.id.amount);
        if (amountTextView != null) {
            amountTextView.setText(amount);
        }
    }

    public String getAmount() {

        BluDroidTextView amountTextView = findViewById(R.id.amount);
        if (amountTextView != null) {
            return amountTextView.getText().toString().replace("R", "");
        } else {
            return "0.00";
        }

    }

    private String getBundleAmount() {

        BluDroidTextView amountTextView = findViewById(R.id.message);
        if (amountTextView != null) {
            return amountTextView.getText().toString();
        } else {
            return "0.00";
        }

    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public ImageView getIcon() {
        return findViewById(R.id.icon);
    }

    public void onClick(View view) {
        try {
            //BaseActivity.logger.info(": onClick()");
            BaseActivity.logger.info(((BluDroidButton) view).getText());
            Log.d(TAG, "onClick");
            BluDroidTextView quantityView = findViewById(R.id.quantity);
            qty = Integer.parseInt(quantityView.getText().toString());
            if (view.getId() == R.id.minusButton) {
                qty--;
            }
            if (view.getId() == R.id.plusButton) {
                qty++;
            }
            quantityView.setText(String.valueOf(qty));
            if (qty == 1)
                disableButton(R.id.minusButton);
            else
                enableButton(R.id.minusButton);

            if (qty == 10)
                disableButton(R.id.plusButton);

            else
                enableButton(R.id.plusButton);

            if ((view.getId() == R.id.affirmativeButton) || (view.getId() == R.id.negativeButton)) {
                if ((view.getId() == R.id.affirmativeButton)) {
//                    baseActivity.createProgress(R.string.authenticating);
                    view.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(final View view) {
                            view.setEnabled(false);
                            view.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    view.setEnabled(true);
                                }
                            }, 5000); // delay for 5 sec
                        }
                    });
                }
                super.onClick(view);
            }

            if (isAirtimePlusPlayed) {
                calculateAmountDueWithAirtimePlus(qty);

            } else {
                calculateAmountDue(qty);
                baseActivity.airtimePlusPlayed = "0";
            }


        } catch (Exception exception) {
            Log.d(TAG, "onClick " + exception);
        }


    }

    private void calculateAmountDueWithAirtimePlus(int qty) {

        BluDroidTextView airtimePlusTotal = findViewById(R.id.airtimePlusTotal);

        String disp;
        BluDroidTextView voucherTotal = findViewById(R.id.voucherTotal);
        if (!baseActivity.airtimePlusValue.isEmpty())
            try {
                disp = "R" + baseActivity.df2.format(Double.parseDouble(baseActivity.airtimePlusValue) * qty);
                airtimePlusTotal.setText(disp);
                disp = "R" + baseActivity.df2.format(Double.parseDouble(getAmount().replace("R", "")) * qty);
                voucherTotal.setText(disp);
            } catch (Exception ex) {
                disp = "R" + baseActivity.df2.format(Double.parseDouble(getBundleAmount().replace("R", "")) * qty);
                voucherTotal.setText(disp);
            }


        BluDroidTextView totalText = findViewById(R.id.Total);

        Double total = Double.parseDouble(voucherTotal.getText().toString().replace("R", "")) + Double.parseDouble(airtimePlusTotal.getText().toString().replace("R", ""));

        disp = "R" + baseActivity.df2.format(total);
        totalText.setText(disp);
    }

    private void calculateAmountDue(int qty) {

        String disp;
        BluDroidTextView voucherTotal = findViewById(R.id.voucherTotal);
        try {
            disp = "R" + baseActivity.df2.format(Double.parseDouble(getAmount().replace("R", "")) * qty);
            voucherTotal.setText(disp);
        } catch (Exception ex) {
            disp = "R" + baseActivity.df2.format(Double.parseDouble(getBundleAmount().replace("R", "")) * qty);
            voucherTotal.setText(disp);
        }


        BluDroidTextView totalText = findViewById(R.id.Total);

        Double total = Double.parseDouble(voucherTotal.getText().toString().replace("R", ""));
        disp = "R" + baseActivity.df2.format(total);
        totalText.setText(disp);
    }

    public int getQuantity() {
        BluDroidTextView quantity = findViewById(R.id.quantity);
        if (quantity != null) {
            int qty = Integer.parseInt(quantity.getText().toString());
            Log.d(TAG, "returning qty=" + qty);
            return qty;
        }
        return 1;
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        if (isChecked) {
            isAirtimePlusPlayed = true;
            calculateAmountDueWithAirtimePlus(qty);
            baseActivity.airtimePlusPlayed = "1";
        } else {
            isAirtimePlusPlayed = false;
            calculateAmountDue(qty);
            baseActivity.airtimePlusPlayed = "0";
            resetAirtimePlusTotal();

        }
    }


    public boolean isMVNO() {
        return isMVNO;
    }

    public void setMVNO(boolean MVNO) {
        isMVNO = MVNO;
    }
}

