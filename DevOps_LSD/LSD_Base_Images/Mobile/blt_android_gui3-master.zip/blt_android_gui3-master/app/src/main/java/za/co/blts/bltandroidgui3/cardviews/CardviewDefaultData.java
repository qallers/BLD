package za.co.blts.bltandroidgui3.cardviews;

import android.app.Activity;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class CardviewDefaultData extends CardviewDataObject {

    public CardviewDefaultData(Activity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.default_data,
                ((BaseActivity) baseActivity).getSkinResources().getButtonColor(),
                stockId, voucherType, tag);
        super.setHasAirtimePlus(hasAirtimePlus);
        setDefaultCard("default_data");
    }

    public CardviewDefaultData(BaseActivity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc, boolean hasAirtimePlus) {
        super(cardDesc, cardValue,
                R.drawable.default_data,
                baseActivity.getSkinResources().getButtonColor(),
                stockId, voucherType, tag, voucherTypeDesc);
        super.setHasAirtimePlus(hasAirtimePlus);
        setDefaultCard("default_data");
    }

    public String getSupplierCode() {
        return "-1";
    }

    public String getBundlesName() {
        return this.getTag() + "Bundles";
    }

    public String getTopupName() {
        return this.getTag();
    }
}

