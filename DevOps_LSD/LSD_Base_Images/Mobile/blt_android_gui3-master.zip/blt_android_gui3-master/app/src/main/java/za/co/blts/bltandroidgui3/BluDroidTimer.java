package za.co.blts.bltandroidgui3;

import android.os.CountDownTimer;
import android.util.Log;

import java.lang.ref.WeakReference;

public class BluDroidTimer extends CountDownTimer {
    private final String TAG = this.getClass().getSimpleName();
    WeakReference<BaseActivity> baseActivityWeakReference;
    private static BluDroidTimer bluDroidTimer;

    private BluDroidTimer(BaseActivity baseActivity, long millisInFuture, long countDownInterval) {
        super(millisInFuture, countDownInterval);
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    //----------------------------------------------------------------------------------------------
    public static BluDroidTimer getInstance(BaseActivity baseActivity, long millisInFuture, long countDownInterval) {
        if (bluDroidTimer == null) {
            bluDroidTimer = new BluDroidTimer(baseActivity, millisInFuture, countDownInterval);
        }

        bluDroidTimer.start();
        return bluDroidTimer;
    }

    //----------------------------------------------------------------------------------------------
    public void onFinish() {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            baseActivity.timeOut();
            BaseActivity.logger.info("Timer Timeout for " + baseActivity.getClass().getName());
        }
    }

    //----------------------------------------------------------------------------------------------
    public void onTick(long millisUntilFinished) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            Log.v(TAG, "Ticking for " + baseActivity.getClass().getName() + ": " + millisUntilFinished + " left");
            if (BaseActivity.logger != null) {
                baseActivity.printSizeLogIfAnySizeValueHasChanged();
            }
        }
    }

    public static BluDroidTimer cancelTimer() {
        if (bluDroidTimer != null) {
            bluDroidTimer.cancel();
            bluDroidTimer = null;
        }
        return null;
    }
    //----------------------------------------------------------------------------------------------
}
