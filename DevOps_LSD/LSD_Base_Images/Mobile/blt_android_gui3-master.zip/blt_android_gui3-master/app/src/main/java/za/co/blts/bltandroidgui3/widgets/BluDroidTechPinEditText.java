package za.co.blts.bltandroidgui3.widgets;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.InputFilter;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidTechPinEditText extends BluDroidIntegerEditText {
    private final String TAG = this.getClass().getSimpleName();

    private void setUpTechPin() {
        addPinTransformer();
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(4);
        setFilters(inputFilters);
        maxLength = 4;
    }

    private void addPinTransformer() {
        setTransformationMethod((new PasswordTransformationMethod()));
    }


    public BluDroidTechPinEditText(BaseActivity context) {
        super(context);
        setUpTechPin();

    }

    public BluDroidTechPinEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpTechPin();

        @SuppressLint("CustomViewStyleable") TypedArray attributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidEditText);

        try {
            String editTextCategory = attributesArray.getString(R.styleable.BluDroidEditText_EditTextCategory);
        } catch (Exception e) {
            e.printStackTrace();
        }
        attributesArray.recycle();
    }


    public boolean validate() {
        BaseActivity.logger.info(": validate(): ");
        Log.d(TAG, "validate");
        String pin = getText().toString().trim();
        int length = pin.length();
        if ((length != 0) && (length != 4)) {
            setErrorMessage(R.string.techPinError);
            return false;
        } else {
            removeErrorMessage();
            return true;
        }
    }

}

