package za.co.blts.bltandroidgui3;

class FdroidUtils {

    public String getVersionName(BaseActivity baseScreen) {
        try {
            return baseScreen.getPackageManager().getPackageInfo(baseScreen.getPackageName(), 0).versionName;
        } catch (Exception exception) {
            return "";
        }
    }

    public int getVersionCode(BaseActivity baseScreen) {
        try {
            return baseScreen.getPackageManager().getPackageInfo(baseScreen.getPackageName(), 0).versionCode;
        } catch (Exception exception) {
            return -1;
        }
    }

}
