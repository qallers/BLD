package za.co.blts.bltandroidgui3.widgets;


import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidHeading extends BluDroidTextView implements BluDroidSetupable {
    private final String TAG = this.getClass().getSimpleName();

    private void setTextSize() {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            super.setTextSize(baseActivity.getSkinResources().getTextSize() + baseActivity.getSkinResources().getTextSize() / 3);
        }
    }

    public void setup() {
        Log.d(TAG, "setup");
        super.setup();
        Log.d(TAG, "called super setup");
        setTextSize();
        Log.d(TAG, "setup finished");
    }

    public BluDroidHeading(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setTextSize();

    }

    public BluDroidHeading(Context context, AttributeSet attrs) {
        super(context, attrs);
        boolean needTextSize = true;
        for (int i = 0; i < attrs.getAttributeCount(); i++) {
            if (attrs.getAttributeName(i).equals("textSize")) {
                needTextSize = false;
            }
        }
        if (context instanceof BaseActivity) {
            this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
            if (needTextSize) {
                setTextSize();
            }
        }
    }


}

