package za.co.blts.bltandroidgui3.cardviews;

import android.app.Activity;

import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/16/2017.
 */

public class CardViewElectricity extends CardviewDataObject {

    public CardViewElectricity(Activity baseActivity, String cardDesc, String cardValue, int logo, String stockId, String voucherType, String tag, String voucherTypeDesc) {
        super(cardDesc, cardValue,
                logo,
                baseActivity.getResources().getColor(R.color.white),
                stockId, voucherType, tag, voucherTypeDesc);
    }

    public CardViewElectricity(Activity baseActivity, String cardDesc, String cardValue, String stockId, String voucherType, String tag, String voucherTypeDesc) {
        super(cardDesc, cardValue,
                R.drawable.default_electricity,
                baseActivity.getResources().getColor(R.color.white),
                stockId, voucherType, tag, voucherTypeDesc);
    }
}