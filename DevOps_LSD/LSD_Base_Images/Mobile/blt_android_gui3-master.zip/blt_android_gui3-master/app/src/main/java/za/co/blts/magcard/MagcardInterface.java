package za.co.blts.magcard;

import java.util.List;

/**
 * Created by NkosanaM on 6/22/2017.
 */

public interface MagcardInterface {
    void setDelegate(BluDroidMagCardAsyncReponse delegate);

    boolean isConnected();

    boolean isOpen();

    void closeAdapter();

    boolean enumerate();

    boolean featureSupported();

    void openUsbSerial();

    void setTrack1(String track1);

    void setTrack2(String track2);

    void setTrack3(String track3);

    void sendWriteCommand();

    void sendReadCommand();

    String getResult();

    void setTracks(List<String> tracks);

    List<String> getTracks();

    void resetMsr();

    void sendCheckCommsReq();

    void sendModelReq();

    void setHiCo();

    void setLoCo();

    void sendHiLoCoStatusReq();

    void eraseCard(boolean trk1, boolean trk2, boolean trk3);

    void setLedOff();

    void sendLedCommand(boolean green, boolean yellow, boolean red);
}
