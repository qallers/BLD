package za.co.blts.loyalty;

import android.os.RemoteException;
import android.util.Log;

import com.sunmi.pay.hardware.aidl.AidlConstants;
import com.sunmi.pay.hardware.aidl.bean.CardInfo;
import com.sunmi.pay.hardware.aidl.readcard.ReadCardCallback;
import com.sunmi.pay.hardware.aidl.readcard.ReadCardOpt;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BluDroidApplication;
import za.co.blts.bltandroidgui3.BluDroidUtils;

/**
 * Created by MasiS on 8/14/2018.
 */

public class P1NFCCard implements NFCCardInterface {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidNFCCardAsyncResponse delegate = null;
    private String cardNumber;
    private WeakReference<BaseActivity> baseActivityWeakReference;
    private ReadCardOpt readCardOpt;


    //----------------------------------------------------------------------------------------------
    public P1NFCCard(BaseActivity context) {
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    //---------------------------------------------------------------------------------------------

    //----------------------------------------------------------------------------------------------
    @Override
    public void setDelegate(BluDroidNFCCardAsyncResponse delegate) {
        this.delegate = delegate;
    }

    @Override
    public void openReader() {

    }

    @Override
    public void closeReader() {

    }

    @Override
    public void startListener() {
        try {
            final int timeOut = 43200000;
            readCardOpt = BluDroidApplication.mReadCardOpt;
            int allType = AidlConstants.CardType.MIFARE.getValue();
            readCardOpt.checkCard(allType, mReadCardCallback, timeOut);  // 10 secs 1000000
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void stopListener() throws RemoteException {
        readCardOpt.cancelCheckCard();
        readCardOpt = null;
    }

    @Override
    public String getCardNumber() {
        return this.cardNumber;
    }

    //----------------------------------------------------------------------------------------------
    private ReadCardCallback mReadCardCallback = new ReadCardCallback.Stub() {

        @Override
        public void onCardDetected(CardInfo cardInfo) {
            if (cardInfo != null) {
                Log.i(TAG, "cardInfo.cardNo: " + cardInfo.toString());
                cardNumber = BluDroidUtils.hexToDecimalString(cardInfo.uuid);

                BaseActivity baseActivity = baseActivityWeakReference.get();
                if (baseActivity != null) {
                    baseActivity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            delegate.onCardNumberRead(cardNumber);
                        }
                    });
                }


                //results("success"); // should be running on UI thread :)
            } else {
                Log.i(TAG, "onCardDetected: cardInfo null");
            }
            //results("failed"); // should be running on UI thread :)
            startListener();
        }

        @Override
        public void onError(int i, String s) {
            //context.nfcCard.
            Log.i(TAG, "onError:" + s);

            //results("failed"); // should be running on UI thread :)
        }

        @Override
        public void onStartCheckCard() {
        }
        //------------------------------------------------------------------------------------------
    };
    //----------------------------------------------------------------------------------------------
}
