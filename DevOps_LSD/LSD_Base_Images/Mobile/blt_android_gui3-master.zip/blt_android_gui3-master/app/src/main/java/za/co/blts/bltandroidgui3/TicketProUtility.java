package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.content.Context;

import java.util.Map;
import java.util.TreeMap;

/**
 * Created by warrenm on 2017/02/07.
 */

class TicketProUtility extends VoucherUtility {

    private Context context;

    public TicketProUtility() {

    }

    @SuppressLint("ValidFragment")
    public TicketProUtility(Context context) {
        this.context = context;
    }

    Map<String, String> getCategories() {

        Map<String, String> categories = new TreeMap<>();

        BaseActivity base = ((BaseActivity) context);
        if (base.ticketProResponseCategoriesMessage != null) {
            for (int i = 0; i < base.ticketProResponseCategoriesMessage.getData().getCategories().size(); i++) {
                String name = base.ticketProResponseCategoriesMessage.getData().getCategories().get(i).getName();
                String id = base.ticketProResponseCategoriesMessage.getData().getCategories().get(i).getId();

                categories.put(id, name);
            }
        }

        return categories;
    }

    protected Map<String, String> getEvents() {

        Map<String, String> events = new TreeMap<>();


        BaseActivity base = ((BaseActivity) context);
        if (base.ticketProResponseEventsMessage != null) {
            for (int i = 0; i < base.ticketProResponseEventsMessage.getData().getEvents().size(); i++) {
                String name = base.ticketProResponseEventsMessage.getData().getEvents().get(i).getName();
                String id = base.ticketProResponseEventsMessage.getData().getEvents().get(i).getEventId();

                events.put(id, name);
            }
        }

        return events;
    }
}
