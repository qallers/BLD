package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 3/6/2017.
 */

public class BluDroidPostalCodeEditText extends BluDroidIntegerEditText {
    private final String TAG = this.getClass().getSimpleName();

    public BluDroidPostalCodeEditText(BaseActivity context) {
        super(context);
        setUpId();

    }

    public BluDroidPostalCodeEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpId();
    }

    private void setUpId() {

        maxLength = 4;
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(maxLength);
        setFilters(inputFilters);
        setOnFocusChangeListener(this);

    }


    @Override
    public boolean validate() {
        BaseActivity.logger.info(": validate()");
        Log.d(TAG, "validate");
        String idString = getText().toString().trim();


        if (this.getVisibility() == VISIBLE) {

            if (idString.length() == 4) {
                removeErrorMessage();
                return true;
            } else {
                BaseActivity baseScreen = baseActivityWeakReference.get();
                if (baseScreen != null) {
                    setErrorMessage(baseScreen.getResources().getString(R.string.invalid_length));
                }
                return false;
            }
        } else {
            return true;
        }
    }

}
