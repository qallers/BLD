package za.co.blts.bltandroidgui3.confirmations;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.DatePicker;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//import android.view.View;

/**
 * Created by NkosanaM on 4/20/2017.
 */

public class BluDroidDateTimePickerDialog extends BluDroidAlertDialog {

    private Builder dialogBuilder = null;
    private Date mDate;
    private int year, month, day, hour, min;
    private Calendar calendar;
    private String dateString;

    public BluDroidDateTimePickerDialog(BaseActivity context) {
        super(context);
        setUp(context);
    }

    public void setUp(BaseActivity context) {
        dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = context.getLayoutInflater();

        mDate = new Date();

        calendar = Calendar.getInstance();
        calendar.setTime(mDate);
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        hour = calendar.get(Calendar.HOUR_OF_DAY);
        min = calendar.get(Calendar.MINUTE);

        dateString = formatDate(day, month, year);

        @SuppressLint("InflateParams") View dialogView = inflater.inflate(R.layout.dialog_date_time_picker, null);
        dialogBuilder.setView(dialogView);

        DatePicker datePicker = dialogView.findViewById(R.id.datePicker);


        datePicker.init(year, month, day, new DatePicker.OnDateChangedListener() {
            public void onDateChanged(DatePicker view, int year, int month, int day) {
                BluDroidDateTimePickerDialog.this.year = year;
                BluDroidDateTimePickerDialog.this.month = month;
                BluDroidDateTimePickerDialog.this.day = day;

                dateString = formatDate(day, month, year);
                // fromDate.setText(date);

                updateDateTime();
            }
        });


        dialogBuilder.setTitle("Date");


    }

    private String formatDate(int temp_day, int temp_month, int temp_year) {
        String dayTmp;
        if (temp_day < 10) {
            dayTmp = "" + 0 + temp_day;
        } else {
            dayTmp = "" + temp_day;
        }

        String monthTmp;
        if (temp_month < 9) {
            monthTmp = "" + 0 + (temp_month + 1);
        } else {
            monthTmp = "" + (temp_month + 1);
        }
        return dayTmp + "/" + monthTmp + "/" + temp_year;
    }

    public void createDialog() {
        AlertDialog dialog = dialogBuilder.create();
        dialog.show();
    }


    @Override
    public void setNegativeOption(String option, DialogInterface.OnClickListener listener) {
        dialogBuilder.setNegativeButton(option, listener);
    }

    @Override
    public void setPositiveOption(String option, DialogInterface.OnClickListener listener) {
        dialogBuilder.setPositiveButton(option, listener);
    }

    @Override
    public void setNeutralOption(String option, DialogInterface.OnClickListener listener) {
        dialogBuilder.setNeutralButton(option, listener);
    }


    private void updateDateTime() {
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);

        try {
            calendar.setTime(df.parse(dateString));

            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, min);
            calendar.set(Calendar.SECOND, 0);

            mDate = new GregorianCalendar(year, month, day, hour, min).getTime();
            // getArguments().putSerializable(EXTRA_DATE, mDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public String getDateAndTime() {

        //return year + "-" + month + "-" + day + "  " + hour + ":" + min;
        return dateString;
    }

    public String getMillies() {

        return String.valueOf(calendar.getTimeInMillis());
    }
}
