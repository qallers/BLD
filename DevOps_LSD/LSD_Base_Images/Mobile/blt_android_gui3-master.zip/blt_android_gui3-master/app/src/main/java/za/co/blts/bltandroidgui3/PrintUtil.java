package za.co.blts.bltandroidgui3;

import android.graphics.Bitmap;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.security.InvalidParameterException;

import android_serialport_api.SerialPort;

class PrintUtil {
    private static final String TAG = PrintUtil.class.getSimpleName();
    private static SerialPort mSerialPortOp = null;

    //----------------------------------------------------------------------------------------------
    private static SerialPort getSerialPort() throws SecurityException, IOException, InvalidParameterException {
        if (mSerialPortOp == null) {
            mSerialPortOp = new SerialPort(new File("/dev/ttyS1"), 115200, 0, true);
        }
        return mSerialPortOp;
    }

    //----------------------------------------------------------------------------------------------
    @SuppressWarnings("unused")
    public static void closeSerialPort() {
        if (mSerialPortOp != null) {
            mSerialPortOp.close();
            mSerialPortOp = null;
        }
    }

    //----------------------------------------------------------------------------------------------
    private static byte[] getBytesWithCharset(String paramString, String charset) {
        byte[] arrayOfByte = null;
        try {
            arrayOfByte = paramString.getBytes(charset);
        } catch (Exception ex) {
            Log.v(TAG, "getBytesWithCharset exception " + ex);
        }
        return arrayOfByte;
    }

    //----------------------------------------------------------------------------------------------
    public static byte[] CutPaper() {
        return new byte[]{0x1D, 0x56, 0x42, 0x00};
    }

    //----------------------------------------------------------------------------------------------
    public static byte[] setBold(boolean paramBoolean) {
        byte[] arrayOfByte = new byte[3];
        arrayOfByte[0] = 0x1B;
        arrayOfByte[1] = 0x45;
        if (paramBoolean) {
            arrayOfByte[2] = 0x01;
        } else {
            arrayOfByte[2] = 0x00;
        }
        return arrayOfByte;
    }

    public static byte[] setLineH(int h) {
        byte[] arrayOfByte = new byte[3];
        arrayOfByte[0] = 0x1B;
        arrayOfByte[1] = 0x33;
        arrayOfByte[2] = (byte) (h & 255);
        return arrayOfByte;
    }

    //----------------------------------------------------------------------------------------------
    public static byte[] setWH(char paramChar) { //GS !
        byte[] arrayOfByte = new byte[3]; //GS ! 11H
        arrayOfByte[0] = 0x1D;
        arrayOfByte[1] = 0x21;

        switch (paramChar) {
            case '2':
                arrayOfByte[2] = 0x10;
                break;
            case '3':
                arrayOfByte[2] = 0x01;
                break;
            case '4':
                arrayOfByte[2] = 0x11;
                break;
            default:
                arrayOfByte[2] = 0x00;
                break;
        }
        return arrayOfByte;
    }

    //----------------------------------------------------------------------------------------------
    public static void printBytes(byte[] printText) {
        try {
            OutputStream mOutputStream = getSerialPort().getOutputStream();
            //printText=CutPaper();
            mOutputStream.flush();
//            Log.v(TAG, "Before mOutputStream.write(printText)");
            mOutputStream.write(printText);
//            Log.v(TAG, "After mOutputStream.write(printText)");
            mOutputStream.flush();
//            Log.v(TAG, "After mOutputStream.flush()");
        } catch (Exception ex) {
            Log.v(TAG, "printBytes exception " + ex);
        }
    }

    //----------------------------------------------------------------------------------------------
    public static void printString(String paramString, String charset) {
        printBytes(getBytesWithCharset(paramString, charset));
    }

    //----------------------------------------------------------------------------------------------

    public static void printPicture(Bitmap bm) {
        byte[] dataArray = (new BluDroidUtils()).convert(bm);

        try {
            OutputStream mOutputStream = getSerialPort().getOutputStream();
            mOutputStream.write(dataArray);
        } catch (Exception ex) {
            Log.v(TAG, "printPicture exception " + ex);
        }
    }

    public static byte[] setAlignment(char paramChar) {
        byte[] arrayOfByte = new byte[3];
        arrayOfByte[0] = 0x1B;
        arrayOfByte[1] = 0x61;

        switch (paramChar) // 1-left 2-center 3-right
        {
            case '2':
                arrayOfByte[2] = 0x01;
                break;
            case '3':
                arrayOfByte[2] = 0x02;
                break;
            default:
                arrayOfByte[2] = 0x00;
                break;
        }
        return arrayOfByte;
    }

}
