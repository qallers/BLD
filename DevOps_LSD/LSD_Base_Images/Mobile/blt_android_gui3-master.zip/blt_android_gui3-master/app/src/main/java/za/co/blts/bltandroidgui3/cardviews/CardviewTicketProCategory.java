package za.co.blts.bltandroidgui3.cardviews;

import android.app.Activity;

public class CardviewTicketProCategory extends CardviewDataObject {

    //this constructor is used for ticketPro categories
    public CardviewTicketProCategory(Activity baseActivity, int iconID, int color, String cardDesc, String tag, String categoryid) {
        super(cardDesc, iconID, baseActivity.getResources().getColor(color), tag, categoryid);
    }
}

