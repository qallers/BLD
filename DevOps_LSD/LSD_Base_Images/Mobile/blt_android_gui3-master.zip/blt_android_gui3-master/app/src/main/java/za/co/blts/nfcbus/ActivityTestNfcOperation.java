package za.co.blts.nfcbus;

import android.content.Context;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

import za.co.blt.interfaces.external.messages.nfcbus.NfcBusSvcSector;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.nfc.NfcInstr;
import za.co.blts.nfc.NfcResult;
import za.co.blts.nfc.NfcResultable;
import za.co.blts.nfc.NfcSunmi;
import za.co.blts.nfc.NfcTappable;

import static za.co.blts.nfcbus.NfcBusInstr.defAccess;
import static za.co.blts.nfcbus.NfcBusInstr.defKey;

public class ActivityTestNfcOperation extends BaseActivity implements View.OnClickListener, NfcResultable {

    private final String TAG = this.getClass().getSimpleName();

    private TextView debug;
    private NfcTappable tappable;
    private ArrayList<NfcBusSvcSector> svcData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_nfc_operation);

        cancelTimer();
        debug = findViewById(R.id.debug);
        debug.setMovementMethod(new ScrollingMovementMethod());

        Button uid = findViewById(R.id.uid);
        uid.setOnClickListener(this);
        Button def = findViewById(R.id.def);
        def.setOnClickListener(this);
        Button formatted = findViewById(R.id.formatted);
        formatted.setOnClickListener(this);
        Button read0 = findViewById(R.id.read0);
        read0.setOnClickListener(this);
        Button write0 = findViewById(R.id.write0);
        write0.setOnClickListener(this);
        Button clear0 = findViewById(R.id.clear0);
        clear0.setOnClickListener(this);
        Button format = findViewById(R.id.format);
        format.setOnClickListener(this);
        Button read1 = findViewById(R.id.read1);
        read1.setOnClickListener(this);
        Button write1 = findViewById(R.id.write1);
        write1.setOnClickListener(this);
        Button clear1 = findViewById(R.id.clear1);
        clear1.setOnClickListener(this);
        Button restore = findViewById(R.id.restore);
        restore.setOnClickListener(this);

        Button x = findViewById(R.id.x);
        x.setOnClickListener(this);
        Button o = findViewById(R.id.o);
        o.setOnClickListener(this);

        tappable = new NfcSunmi(this);

        svcData = new ArrayList<>();
        for (int i = 8; i < 13; i++) {
            NfcBusSvcSector sector = new NfcBusSvcSector();
            sector.setSectorNum(i);
            sector.setBlock0("00112233445566778899AABBCCDDEEFF");
            sector.setBlock1("00112233445566778899AABBCCDDEEFF");
            sector.setBlock2("00112233445566778899AABBCCDDEEFF");
        }
    }

    @Override
    public void onClick(View v) {
        debug.setText("");
        if (v.getId() == R.id.uid) {
            Log.d(TAG, "reading uid");
            tappable.readUid();
        } else if (v.getId() == R.id.def) {
            tappable.checkCard(NfcBusInstr.check(true));
        } else if (v.getId() == R.id.formatted) {
            tappable.checkCard(NfcBusInstr.check(false));
        } else if (v.getId() == R.id.read0) {
            tappable.readCard(NfcBusInstr.read(true, null));
        } else if (v.getId() == R.id.write0) {
            tappable.writeCard(NfcBusInstr.write(true, svcData, null));
        } else if (v.getId() == R.id.clear0) {
            tappable.writeCard(NfcBusInstr.clear(true));
        } else if (v.getId() == R.id.format) {
            tappable.formatCard(NfcBusInstr.format(true, ""));
        } else if (v.getId() == R.id.read1) {
            tappable.readCard(NfcBusInstr.read(false, null));
        } else if (v.getId() == R.id.write1) {
            tappable.writeCard(NfcBusInstr.write(false, svcData, null));
        } else if (v.getId() == R.id.clear1) {
            tappable.writeCard(NfcBusInstr.clear(false));
        } else if (v.getId() == R.id.restore) {
            tappable.formatCard(NfcBusInstr.format(false, ""));
        } else if (v.getId() == R.id.x) {
            NfcInstr otherCardInstr = new NfcInstr();
            otherCardInstr.setKey(new NfcInstr.Key(defKey, false));
            otherCardInstr.setFormat(new NfcInstr.Format("112233445566", "112233445566", defAccess));
            otherCardInstr.setSectors(new ArrayList<>(Arrays.asList(8)));
            tappable.formatCard(otherCardInstr);
        } else if (v.getId() == R.id.o) {
            NfcInstr restoreFromOtherInstr = new NfcInstr();
            restoreFromOtherInstr.setKey(new NfcInstr.Key("112233445566", false));
            restoreFromOtherInstr.setFormat(new NfcInstr.Format(defKey, defKey, defAccess));
            restoreFromOtherInstr.setSectors(new ArrayList<>(Arrays.asList(8)));
            tappable.formatCard(restoreFromOtherInstr);
        }
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public void handleNfcResult(final NfcResult result) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                debug.setText(result.toString());
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        tappable.destroy();
    }

    @Override
    public void onBackPressed() {
        gotoLandingScreen();
    }
}