package za.co.blts.bltandroidgui3.widgets;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidPortEditText extends BluDroidIntegerEditText {
    private final String TAG = this.getClass().getSimpleName();

    private String editTextCategory;

    private void setUpPort() {
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(5);
        setFilters(inputFilters);
    }

    public BluDroidPortEditText(BaseActivity context) {
        super(context);
        setUpPort();

    }

    public BluDroidPortEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpPort();

        @SuppressLint("CustomViewStyleable") TypedArray attributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidEditText);

        try {
            editTextCategory = attributesArray.getString(R.styleable.BluDroidEditText_EditTextCategory);
        } catch (Exception e) {
            e.printStackTrace();
        }
        attributesArray.recycle();
    }

    public boolean validate() {
        //BaseActivity.logger.info(": validate()");
        Log.d(TAG, "validate");
        String port = getText().toString().trim();
        int length = port.length();
        Log.d(TAG, "Port is [" + port + "] length is " + length);
        if ((length >= 2) && (length <= 5)) {
            Log.d(TAG, "port [" + port + "] length " + length + " returning true");
            removeErrorMessage();
            //setErrorMessage("");

            return true;
        } else {
            setErrorMessage(R.string.portError);
            Log.d(TAG, "returning false");
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                if (editTextCategory.equalsIgnoreCase("deviceSettings")) {
                    baseScreen.deviceSettingsHaserrors = true;
                } else if (editTextCategory.equalsIgnoreCase("ricaSettings")) {
                    baseScreen.ricaSettingsHaserrors = true;
                } else if (editTextCategory.equalsIgnoreCase("repositorySettings")) {
                    baseScreen.repositorySettingsHaserrors = true;
                } else if (editTextCategory.equalsIgnoreCase("loyaltySettings")) {
                    baseScreen.apiGatewaySettingsHaserrors = true;
                }
            }

            return false;
        }
    }

}

