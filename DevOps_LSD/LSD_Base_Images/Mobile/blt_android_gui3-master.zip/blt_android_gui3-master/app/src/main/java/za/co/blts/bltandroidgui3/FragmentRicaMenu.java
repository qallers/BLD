package za.co.blts.bltandroidgui3;


import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;


public class FragmentRicaMenu extends RicaTabRecycler {

    private final String TAG = this.getClass().getSimpleName();

    public FragmentRicaMenu() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_rica_menu, container, false);
        getActivity().setTitle("RICA");
        tabs = rootView.findViewById(R.id.tabLayout);

        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), TAG, null);

        viewPager = rootView.findViewById(R.id.viewpager);
        viewPager.setOffscreenPageLimit(1);

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public boolean onBackPressed() {

        if (viewPager.getCurrentItem() == 0) {
            getBaseActivity().gotoMainScreen();

        } else if (viewPager.getCurrentItem() == 1) {
            Fragment f = ((RicaPagerAdapter)viewPager.getAdapter()).getItem(viewPager.getCurrentItem());
            if (((FragmentRicaRegister)f)._mViewPager.getCurrentItem() == 0) {
                getBaseActivity().gotoMainScreen();
            } else if (((FragmentRicaRegister)f)._mViewPager.getCurrentItem() == 1) {
                ((FragmentRicaRegister)f)._mViewPager.setCurrentItem(0);
            } else if (((FragmentRicaRegister)f)._mViewPager.getCurrentItem() == 2) {
                ((FragmentRicaRegister)f)._mViewPager.setCurrentItem(1);
            }

        } else if (viewPager.getCurrentItem() == 2) {
            Fragment f = ((RicaPagerAdapter)viewPager.getAdapter()).getItem(viewPager.getCurrentItem());
            if (((FragmentRicaChangeOwner)f)._mViewPager.getCurrentItem() == 0) {
                getBaseActivity().gotoMainScreen();
            } else if (((FragmentRicaChangeOwner)f)._mViewPager.getCurrentItem() == 1) {
                ((FragmentRicaChangeOwner)f)._mViewPager.setCurrentItem(0);
            } else if (((FragmentRicaChangeOwner)f)._mViewPager.getCurrentItem() == 2) {
                ((FragmentRicaChangeOwner)f)._mViewPager.setCurrentItem(1);
            } else if (((FragmentRicaChangeOwner)f)._mViewPager.getCurrentItem() == 3) {
                ((FragmentRicaChangeOwner)f)._mViewPager.setCurrentItem(2);
            }

        } else if (viewPager.getCurrentItem() == 3) {
            Fragment f = ((RicaPagerAdapter)viewPager.getAdapter()).getItem(viewPager.getCurrentItem());
            if (((FragmentRicaBoxRegister)f)._mViewPager.getCurrentItem() == 0) {
                getBaseActivity().gotoMainScreen();
            } else if (((FragmentRicaBoxRegister)f)._mViewPager.getCurrentItem() == 1) {
                ((FragmentRicaBoxRegister)f)._mViewPager.setCurrentItem(0);
            } else if (((FragmentRicaBoxRegister)f)._mViewPager.getCurrentItem() == 2) {
                ((FragmentRicaBoxRegister)f)._mViewPager.setCurrentItem(1);
            }
        }

        return true;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("RicaMpk", "onResume FragmentRicaMenu");
    }
}


