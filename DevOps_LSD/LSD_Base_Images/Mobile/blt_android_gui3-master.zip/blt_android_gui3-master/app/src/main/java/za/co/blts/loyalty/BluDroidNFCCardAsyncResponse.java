package za.co.blts.loyalty;

/**
 * Created by NkosanaM on 6/23/2017.
 */

public interface BluDroidNFCCardAsyncResponse {
    //    void processFinish(String output);
    void onError(String msg);

    void onReady();

    void onCardNumberRead(String cardNumber);
}
