package za.co.blts.bltandroidgui3.widgets;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;

import java.util.Objects;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidHostEditText extends BluDroidEditText {
    private final String TAG = this.getClass().getSimpleName();
    private String editTextCategory;

    public BluDroidHostEditText(BaseActivity context) {
        super(context);
    }

    public BluDroidHostEditText(Context context, AttributeSet attrs) {
        super(context, attrs);

        @SuppressLint("CustomViewStyleable") TypedArray attributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidEditText);

        try {
            editTextCategory = attributesArray.getString(R.styleable.BluDroidEditText_EditTextCategory);
        } catch (Exception e) {
            e.printStackTrace();
        }
        attributesArray.recycle();
    }

    public boolean validate() {
        Log.d(TAG, "validate");

        String host = Objects.requireNonNull(getText()).toString().trim();
        Log.d(TAG, "host is " + host);

        boolean matchesValidUrl = android.util.Patterns.WEB_URL.matcher(host).matches();

        Log.d(TAG, host + " matchesValidUrl: " + matchesValidUrl);
        if (matchesValidUrl) {
            removeErrorMessage();
            return true;
        } else {
            setErrorMessage(R.string.ipOrDnsError);
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                if (editTextCategory.equalsIgnoreCase("deviceSettings")) {
                    baseScreen.deviceSettingsHaserrors = true;
                } else if (editTextCategory.equalsIgnoreCase("ricaSettings")) {
                    baseScreen.ricaSettingsHaserrors = true;
                } else if (editTextCategory.equalsIgnoreCase("repositorySettings")) {
                    baseScreen.repositorySettingsHaserrors = true;
                } else if (editTextCategory.equalsIgnoreCase("ePubSettings")) {
                    baseScreen.ePubSettingsHaserrors = true;
                } else if (editTextCategory.equalsIgnoreCase("loyaltySettings")) {
                    baseScreen.apiGatewaySettingsHaserrors = true;
                } else if (editTextCategory.equalsIgnoreCase("merchantSettings")) {
                    baseScreen.bluKeySettingsHaserrors = true;
                } else if (editTextCategory.equalsIgnoreCase("mendixSettings")) {
                    baseScreen.mendixApiSettingsHaserrors = true;
                }
            }
            return false;
        }
    }

}

