package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.graphics.LightingColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;

import androidx.appcompat.widget.AppCompatButton;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//
// view and button stuff
//
//
// touchy stuff
//
//
// color filtering
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidButton extends AppCompatButton implements OnTouchListener, BluDroidSetupable {
    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference = null;

    public void setup() {
        setOnTouchListener(this);
        setFocusable(true);
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                setTextColor(baseScreen.getSkinResources().getButtonTextColor());
                setTextSize(baseScreen.getSkinResources().getTextSize());
                setBackgroundResource(R.drawable.btn_background);
                setBackgroundColor(baseScreen.getSkinResources().getButtonColor());
            }
        }
    }

    public BluDroidButton(BaseActivity context) {
        super(context);
        this.baseActivityWeakReference = new WeakReference<>(context);
        setup();
    }

    public void setBackgroundResource(int resourceId) {
        super.setBackgroundResource(resourceId);
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                Drawable drawable = this.getBackground();
                if (drawable instanceof GradientDrawable) {
                    GradientDrawable gradientDrawable = (GradientDrawable) drawable;
                    gradientDrawable.setColor(baseScreen.getSkinResources().getButtonColor());
                }
            }
        }
    }

    public void setBackgroundColor(int color) {
        Drawable drawable = this.getBackground();
        if (drawable instanceof GradientDrawable) {
            GradientDrawable gradientDrawable = (GradientDrawable) drawable;
            gradientDrawable.setColor(color);
        }
    }

    //
// sometimes from Dialogs, the context
// is not set properly.  I don't understand
// but this solves the problem
    public void setContext(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    //
// http://stackoverflow.com/questions/10254748/how-to-extend-an-android-button-and-use-an-xml-layout-file
//
    public BluDroidButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (context instanceof BaseActivity) {
            try {
                this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
                setup();
                Drawable drawable = this.getBackground();
                if (drawable instanceof GradientDrawable) {
                    GradientDrawable gradientDrawable = (GradientDrawable) drawable;
                    gradientDrawable.setColor(((BaseActivity) context).getSkinResources().getButtonColor());
                }
            } catch (Exception exception) {
                Log.d(TAG, "BluDroidButton exception " + exception);
            }
        } else {
            Log.d(TAG, "not a Base Activity!!!!");
            Log.d(TAG, "it is a " + context.getClass().getName());
        }
    }


    //
// http://stackoverflow.com/questions/2604599/android-imagebutton-with-a-selected-state
// http://stackoverflow.com/questions/7048941/how-to-use-the-lightingcolorfilter-to-make-the-image-form-dark-to-light
//
    public boolean onTouch(View view, MotionEvent event) {
        try {
            Log.d(TAG, "ontouch " + ((Button) view).getText());
            if (baseActivityWeakReference != null) {
                BaseActivity baseScreen = baseActivityWeakReference.get();
                if (baseScreen != null) {
                    baseScreen.resetTimer();
                }
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        view.getBackground().setColorFilter(new LightingColorFilter(0xFFFFFFFF, 0x00333333));
                        view.invalidate();
                        break;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_OUTSIDE:
                    case MotionEvent.ACTION_CANCEL: {
                        view.getBackground().clearColorFilter();
                        view.invalidate();
                        break;
                    }
                }
                baseScreen.hideKeyboard();
            }
        } catch (Exception exception) {
            Log.v(TAG, "onTouch exception " + exception);

        }
        return false;
    }


}

