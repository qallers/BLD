package za.co.blts.bltandroidgui3;

import android.util.Log;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.Date;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOG_DAYS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOG_LEVEL;

class BluDroidLogging {

    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference;

    public BluDroidLogging(BaseActivity baseScreen) {
        this.baseActivityWeakReference = new WeakReference<>(baseScreen);
    }

    private void removeOldLogs() {
        try {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                File[] logs = baseScreen.privateLogsDir.listFiles();
                long diff = Integer.parseInt(baseScreen.getPreference(PREF_LOG_DAYS)) * 24 * 60 * 60 * 1000;
                Date now = new Date();
                for (File log : logs) {
                    Date lastModified = new Date(log.lastModified());
                    Log.d(TAG, log.getPath() + " " + lastModified.toString());
                    if ((now.getTime() - log.lastModified()) > diff) {
                        Log.d(TAG, "should remove");
                        log.delete();
                    }
                }
            }
        } catch (Exception exception) {
            Log.d(TAG, "problems removing old log files " + exception);
        }
    }

    public Logger getLogger() {
        Logger logger = null;
        removeOldLogs();

        try {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                String logLevelPreference = baseScreen.getPreference(PREF_LOG_LEVEL);
                Log.d(TAG, "logLevelPreference = " + logLevelPreference);
                Log.d(TAG, "should use info");
                Level level = Level.INFO;

                Log.d(TAG, "level will be " + level.toString());

                Log.d(TAG, "configureLog4j");
                LogConfigurator logConfigurator = new LogConfigurator();
                Log.d(TAG, "created configurator");
                logConfigurator.setFileName(baseScreen.privateLogsDir.getPath() + "/bluDroid-" +
                        baseScreen.todaysDateForLogFiles() + ".log");
                logConfigurator.setRootLevel(Level.ALL);
                logConfigurator.setLevel("org.apache", level);
                logConfigurator.setUseFileAppender(true);
                logConfigurator.setFilePattern("%d{yyyy-MM-dd HH:mm:ss,SSS} %-5p [%c{1}-%M-%L] %m%n");
                logConfigurator.setImmediateFlush(true);
                Log.d(TAG, "configuring");
                logConfigurator.configure();
                logger = Logger.getLogger(baseScreen.getClass());
                logger.setLevel(level);
                Log.d(TAG, "finished");

                logger.setLevel(level);
            }
        } catch (Exception exception) {
            Log.d(TAG, "configureLog4j throws " + exception);
        }

        return logger;
    }

}
