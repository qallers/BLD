package za.co.blts.bltandroidgui3;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidErrorTextView;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidScrollView;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;


/**
 * A simple {@link Fragment} subclass.
 */


public class FragmentRicaChangeNewConsumerInfo extends BaseFragment implements CompoundButton.OnCheckedChangeListener {

    private final String TAG = this.getClass().getSimpleName();

    public String idType = "idNumber";
    public BluDroidEditText consumerName, consumerLastName, consumerId, passportNumber;
    public String selectedNationality;

    private ViewGroup viewGroup;

    private BluDroidTextView idLabel;
    private BluDroidErrorTextView passportNumberError;
    private BluDroidErrorTextView idNumberNumberError;
    public  BluDroidRelativeLayout userInfoLayout;
    public  BluDroidLinearLayout bottomPortionLayout;

    public FragmentRicaChangeNewConsumerInfo() {
        // Required empty public constructor
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        bottomPortionLayout = getView().findViewById(R.id.changeNewBottomPortionLayout);
        userInfoLayout = getView().findViewById(R.id.layout);
        idLabel = getView().findViewById(R.id.idLabel);

        consumerName = getView().findViewById(R.id.changeNewConsumerName);
        consumerLastName = getView().findViewById(R.id.changeNewConsumerLastName);

        consumerId = getView().findViewById(R.id.changeNewIdNumber);
        idNumberNumberError = getView().findViewById(R.id.changeNewIdNumberError);

        passportNumber = getView().findViewById(R.id.changeNewPassportNumber);
        passportNumberError = getView().findViewById(R.id.changeNewPassportNumberError);

        BluDroidSpinner nationalitySpinner = getView().findViewById(R.id.changeNewNationalitySpinner);

        String[] nationalities = getResources().getStringArray(R.array.countryCodes);
        ArrayAdapter<String> nationalityAdapter = new ArrayAdapter<>(getBaseActivity(), R.layout.spinner_item, nationalities);
        nationalitySpinner.setAdapter(nationalityAdapter);
        nationalitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedNationality = adapterView.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                selectedNationality = "";
            }
        });

        BluDroidRadioButton idRadio = getView().findViewById(R.id.changeNewRadio_id);
        BluDroidRadioButton passportRadio = getView().findViewById(R.id.changeNewRadio_passport);
        idRadio.setOnCheckedChangeListener(this);
        passportRadio.setOnCheckedChangeListener(this);

        hidePassportDetails();
    }

    private void hidePassportDetails() {
        passportNumber.setText("");
        passportNumber.removeErrorMessage();

        consumerId.setVisibility(View.VISIBLE);
        idNumberNumberError.setVisibility(View.VISIBLE);

        passportNumber.setVisibility(View.GONE);
        passportNumberError.setVisibility(View.GONE);
    }

    private void showPassportDetails() {
        consumerId.setText("");
        consumerId.removeErrorMessage();

        consumerId.setVisibility(View.GONE);
        idNumberNumberError.setVisibility(View.GONE);

        passportNumber.setVisibility(View.VISIBLE);
        passportNumberError.setVisibility(View.VISIBLE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_rica_change_new_consumer_info, container, false);
        viewGroup = container;
        return v;
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            if (buttonView.getId() == R.id.changeNewRadio_id) {
                idLabel.setText(getResources().getString(R.string.rica_consumer_id_number));
                idType = "idNumber";
                hidePassportDetails();
            } else if (buttonView.getId() == R.id.changeNewRadio_passport) {
                idLabel.setText(getResources().getString(R.string.rica_consumer_passport_number));
                idType = "passportNumber";
                showPassportDetails();
            }
        }
    }

    public void clearAll() {
        View view;
        if (viewGroup != null) {
            for (int i = 0; i <= viewGroup.getChildCount(); i++) {
                view = viewGroup.getChildAt(i);
                if (view instanceof BluDroidRelativeLayout) {
                    BluDroidRelativeLayout layout = (BluDroidRelativeLayout) view;
                    for (int j = 0; j <= layout.getChildCount(); j++) {
                        view = layout.getChildAt(j);
                        if (view instanceof BluDroidScrollView) {
                            BluDroidScrollView scrollView = (BluDroidScrollView) view;
                            for (int k = 0; k <= scrollView.getChildCount(); k++) {
                                view = scrollView.getChildAt(k);
                                if (view instanceof BluDroidLinearLayout) {
                                    BluDroidLinearLayout lin = (BluDroidLinearLayout) view;
                                    for (int l = 0; l <= lin.getChildCount(); l++) {
                                        view = lin.getChildAt(l);
                                        if (view instanceof BluDroidEditText) {
                                            BluDroidEditText editText = (BluDroidEditText) view;
                                            editText.setText("");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }


}
