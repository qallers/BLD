package za.co.blts.nfcbus;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidHeading;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public class NfcBusSelectStopDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, TextWatcher {

    private ListView listStops;
    private NfcBusStopListAdapter stopListAdapter;
    private List<Stop> stops;
    private BluDroidHeading noStops;
    private String title;
    private FragmentNewTicketEnhanced fragment;

    public void setup() {
        super.setup();
        if (stops == null) {
            stops = new ArrayList<>();
        }
        setHeading("Select " + title);

        listStops = findViewById(R.id.stopsList);
        listStops.setTextFilterEnabled(true);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        EditText filterEditText = findViewById(R.id.search);
        filterEditText.addTextChangedListener(this);

        noStops = findViewById(R.id.noStops);

        displayList();
    }

    @Override
    protected void onStop() {
        if (listStops != null) listStops.setAdapter(null);
        super.onStop();
    }

    public NfcBusSelectStopDialog(BaseActivity context, List<Stop> stops, String title, FragmentNewTicketEnhanced fragment) {
        super(context, R.layout.nfcbus_select_stop_dialog);
        this.stops = stops;
        this.title = title;
        this.fragment = fragment;
        Log.w(TAG, "constructor num Stops: " + this.stops.size());
        setup();
    }

    private void displayList() {
        Log.w(TAG, "num Stops: " + stops.size());
        stopListAdapter = new NfcBusStopListAdapter(baseActivity, R.layout.stop_row_item, stops);
        listStops.setAdapter(stopListAdapter);
        listStops.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.v(TAG, "selected item " + stops.get(position));
                fragment.setSelectedStop(stops.get(position));
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS ^ InputMethodManager.HIDE_IMPLICIT_ONLY);
                dismiss();
            }
        });

        if (stops.size() > 0) {
            hideNoStops();
            showList();
        } else {
            showNoStops();
            hideList();
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        stopListAdapter.getFilter().filter(s);
    }


    @Override
    public void afterTextChanged(Editable s) {
    }

    private void showList() {
        listStops.setVisibility(VISIBLE);
    }

    private void hideList() {
        listStops.setVisibility(GONE);
    }

    private void showNoStops() {
        noStops.setVisibility(VISIBLE);
    }

    private void hideNoStops() {
        noStops.setVisibility(GONE);
    }

}
