package za.co.blts.bltandroidgui3;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponsePriceCategoryMessage;

/**
 * Created by NkosanaM on 1/31/2018.
 */

public class TicketProSeatCategory {

    private String categoryId;
    private String seatLabel;
    private String pricing;
    private String soldOut;
    private int iconSelected;
    private boolean isSelected;
    private ArrayList<TicketProResponsePriceCategoryMessage> priceCategories;

    public TicketProSeatCategory(String categoryId, String seatLabel, String pricing, ArrayList<TicketProResponsePriceCategoryMessage> priceCategories, String soldOut, int iconSelected, boolean isSelected) {
        this.categoryId = categoryId;
        this.seatLabel = seatLabel;
        this.pricing = pricing;
        this.priceCategories = priceCategories;
        this.soldOut = soldOut;
        this.iconSelected = iconSelected;
        this.isSelected = isSelected;

    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getSeatLabel() {
        return seatLabel;
    }

    public void setSeatLabel(String seatLabel) {
        this.seatLabel = seatLabel;
    }

    public String getSoldOut() {
        return soldOut;
    }

    public void setSoldOut(String soldOut) {
        this.soldOut = soldOut;
    }

    public int getIconSelected() {
        return iconSelected;
    }

    public void setIconSelected(int iconSelected) {
        this.iconSelected = iconSelected;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getPricing() {
        return pricing;
    }

    public void setPricing(String pricing) {
        this.pricing = pricing;
    }

    public ArrayList<TicketProResponsePriceCategoryMessage> getPriceCategories() {
        return priceCategories;
    }

    public void setPriceCategories(ArrayList<TicketProResponsePriceCategoryMessage> priceCategories) {
        this.priceCategories = priceCategories;
    }
}
