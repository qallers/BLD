package za.co.blts.bltandroidgui3;

/**
 * Created by warrenm on 2017/04/21.
 */

class Provider implements Comparable<Provider> {

    private String providerName;
    private boolean hasVouchers;
    private boolean hasTopup;
    private boolean hasBundles;
    private boolean hasAirtimePlus;

    public Provider(String providerName) {
        this.providerName = providerName;
        this.hasVouchers = false;
        this.hasTopup = false;
        this.hasBundles = false;
        this.hasAirtimePlus = false;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public boolean isHasVouchers() {
        return hasVouchers;
    }

    public void setHasVouchers(boolean hasVouchers) {
        this.hasVouchers = hasVouchers;
    }

    public boolean isHasTopup() {
        return hasTopup;
    }

    public void setHasTopup(boolean hasTopup) {
        this.hasTopup = hasTopup;
    }

    public boolean isHasBundles() {
        return hasBundles;
    }

    public void setHasBundles(boolean hasBundles) {
        this.hasBundles = hasBundles;
    }

    public boolean getHasAirtimePlus() {
        return hasAirtimePlus;
    }

    public void setHasAirtimePlus(boolean hasAirtimePlus) {
        this.hasAirtimePlus = hasAirtimePlus;
    }

    @Override
    public int compareTo(Provider o) {
        return o.getProviderName().compareTo(this.providerName);
    }
}
