package za.co.blts.bltandroidgui3.widgets;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

/**
 * Created by NkosanaM on 1/30/2017.
 */

public class BluDroidToggleView extends androidx.appcompat.widget.AppCompatImageView {

    private WeakReference<BaseActivity> baseActivityWeakReference;

    public BluDroidToggleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);

        super.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));

        setColorFilter(((BaseActivity) context).getSkinResources().getButtonColor());
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (baseActivityWeakReference != null) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                baseScreen.resetTimer();
            }
        }
        return false;
    }

}
