package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.text.InputType;
import android.util.AttributeSet;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

public class BluDroidCharacterEditText extends BluDroidEditText {

    //----------------------------------------------------------------------------------------------
    private void setUpCharacter() {
        setInputType(InputType.TYPE_TEXT_VARIATION_NORMAL | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
    }

    //----------------------------------------------------------------------------------------------
    public BluDroidCharacterEditText(BaseActivity context) {
        super(context);
        setUpCharacter();
    }

    //----------------------------------------------------------------------------------------------
    public BluDroidCharacterEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpCharacter();
    }

    //----------------------------------------------------------------------------------------------
    public boolean validate() {
        BaseActivity.logger.info(": validate()");
        Pattern ps = Pattern.compile("^[a-zA-Z ]+$");
        Matcher ms = ps.matcher(getText().toString().trim());
        boolean isValid = ms.matches();
        BaseActivity baseScreen = baseActivityWeakReference.get();
        if (baseScreen != null) {
            if (isValid) {
                removeErrorMessage();
            } else {
                setErrorMessage(baseScreen.getResources().getString(R.string.invalidCharacters));
            }
        }
        return isValid;
    }
    //----------------------------------------------------------------------------------------------
}