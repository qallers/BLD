package za.co.blts.nfcbus;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import za.co.blt.interfaces.external.factories.NfcBusRequestFactory;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusLookupFaresRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupFaresResponseFareMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupFaresResponseMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.NeedsAEONResults;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;


public class FragmentFareList extends BaseFragment implements NeedsAEONResults {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidButton btnNext;
    private final List<Fare> fareList = new ArrayList<>();
    private FareListAdapter adapter;
    private ListView listFares;
    private TextView txtNoFares;


    public FragmentFareList() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_fare_list, container, false);

        BluDroidTextView departLabel = rootView.findViewById(R.id.departLabel);
        departLabel.setText("Departure: " + ((ActivityNfcBus) getActivity()).getDepart().getName());
        BluDroidTextView destLabel = rootView.findViewById(R.id.destLabel);
        destLabel.setText("Destination: " + ((ActivityNfcBus) getActivity()).getDest().getName());

        txtNoFares = rootView.findViewById(R.id.txtNoFares);
        listFares = rootView.findViewById(R.id.listFares);

        BluDroidButton btnCancel = rootView.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getBaseActivity().firebaseBundle = new Bundle();
                getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, TAG + " " + ((ActivityNfcBus) getActivity()).getCardUid());
                getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_purchase_cancel", getBaseActivity().firebaseBundle);

                ((ActivityNfcBus) getActivity()).gotoTicketList();
            }
        });

        btnNext = rootView.findViewById(R.id.btnNext);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityNfcBus) getActivity()).gotoPurchaseTicket(false);
            }
        });

        adapter = new FareListAdapter(getActivity(), android.R.layout.simple_list_item_1, fareList);
        listFares.setAdapter(adapter);
        listFares.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ((ActivityNfcBus) getActivity()).setFare(null);
                for (int i = 0; i < fareList.size(); i++) {
                    if (i == position) {
                        boolean selected = !fareList.get(i).isSelected();
                        fareList.get(i).setSelected(selected);
                        if (selected) {
                            ((ActivityNfcBus) getActivity()).setFare(fareList.get(i));
                        }
                    } else {
                        fareList.get(i).setSelected(false);
                    }
                }
                adapter.notifyDataSetChanged();
                enableDisableNextButton();
            }
        });

        ((ActivityNfcBus) getActivity()).authForNfcBus(this);
        enableDisableNextButton();
        setVisibleViews();
        return rootView;
    }

    private void setVisibleViews() {
        boolean noFares = fareList.isEmpty();
        txtNoFares.setVisibility(noFares ? View.VISIBLE : View.GONE);
        listFares.setVisibility(noFares ? View.GONE : View.VISIBLE);
    }

    private void enableDisableNextButton() {
        if (((ActivityNfcBus) getActivity()).getFare() == null) {
            btnNext.setEnabled(false);
            btnNext.setBackgroundColor(getResources().getColor(R.color.lightGrey));
        } else {
            btnNext.setEnabled(true);
            btnNext.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());
        }
    }

    private void getFares(String sessionId) {
        getBaseActivity().createProgress(getResources().getString(R.string.getting_fare_products));
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusLookupFaresRequestMessage req = factory.lookupFares(sessionId, ((ActivityNfcBus) getActivity()).getCarrier().getCompanyId(),
                ((ActivityNfcBus) getActivity()).getDepart().getId(),
                ((ActivityNfcBus) getActivity()).getDest().getId());
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    @Override
    public void results(Object object) {
        if (object instanceof NfcBusAuthenticationResponseMessage) {
            if (((NfcBusAuthenticationResponseMessage) object).getEvent().getEventCode().equals("0")) {
                getFares(((NfcBusAuthenticationResponseMessage) object).getSessionId());
            } else {
                getBaseActivity().createSystemErrorConfirmation(object, true);
            }
        } else if (object instanceof NfcBusLookupFaresResponseMessage) {
            getBaseActivity().closeAeonSocket(37);
            if (((NfcBusLookupFaresResponseMessage) object).getEvent().getEventCode().equals("0")) {
                getBaseActivity().dismissProgress();
                fareList.clear();
                for (NfcBusLookupFaresResponseFareMessage fare : ((NfcBusLookupFaresResponseMessage) object).getDetail().getFares()) {
                    fareList.add(new Fare(fare));
                }
                Collections.sort(fareList);
                setVisibleViews();
                adapter.notifyDataSetChanged();
            } else {
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }
        }

        if (object != null && !(object instanceof Socket)) {
            getBaseActivity().firebaseBundle = new Bundle();
            getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            getBaseActivity().mFirebaseAnalytics.logEvent("aeon_connection", getBaseActivity().firebaseBundle);
        }
    }
}