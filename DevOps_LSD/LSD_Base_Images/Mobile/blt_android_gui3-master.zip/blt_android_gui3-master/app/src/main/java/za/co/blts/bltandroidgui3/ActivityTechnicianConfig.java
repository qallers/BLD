package za.co.blts.bltandroidgui3;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

import ir.mahdi.mzip.zip.ZipArchive;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDialogable;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidDirectoryEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidErrorTextView;
import za.co.blts.bltandroidgui3.widgets.BluDroidIntegerEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidSpinner;
import za.co.blts.bltandroidgui3.widgets.BluDroidSwitch;
import za.co.blts.bltandroidgui3.widgets.BluDroidTechPinEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidTimeoutEditText;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_LONG;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AEON_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_AWS_HEARTBEAT_MINUTES;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_BLUKEY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASH_DRAWER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEF_ACCOUNT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEF_ACCOUNT_INDEX;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DISPLAY_BALANCE1;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_EPUB_MANUAL_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_EPUB_READER_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FALSE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FDROID_REPO_DIR;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_FDROID_REPO_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HEARTBEAT_ENABLE_TECH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HEARTBEAT_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_IOT_FLAG_ENABLE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOCATION_CHECK;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOG_DAYS;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_ENABLE_TECH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_LOYALTY_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MAG_READER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MANUAL_OVERRIDE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MENDIX_URL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PAPER_CUTTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINTER_WIDTH;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_SALES_RECEIPT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_CAN_BOXRICA;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_HOST;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_PORT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_RICA_USE_SSL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SCANNING_APP;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SCREEN_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SECURE_USB_PRINTER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_SKIN;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRANSACTION_TIMEOUT;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_USE_SSL;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VAT_REG_NO;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_VOUCHER_SECONDS;

/**
 * Created by warrenm on 2016/11/23.
 */

public class ActivityTechnicianConfig extends BaseActivity implements BluDroidDialogable {

    private final String TAG = this.getClass().getSimpleName();

    //Device Settings
    private boolean isDeviceToggled = false;
    private ImageView deviceToggleImg = null;

    //Theme Settings
    private boolean isThemeToggled = false;
    private ImageView themeToggleImg = null;

    //Location Settings
    private boolean isLocationToggled = false;
    private ImageView locationToggleImg = null;

    //Printer Settings
    private boolean isPrinterToggled = false;
    private ImageView printerToggleImg = null;

    //Timeout Settings
    private boolean isTimeoutToggled = false;
    private ImageView timeoutToggleImg = null;

    //Rica Settings
    private boolean isRicaToggled = false;
    private ImageView ricaToggleImg = null;

    //Fdroid Settings
    private boolean isFdroidToggled = false;
    private ImageView fdroidToggleImg = null;

    //Loyalty Settings
    private boolean isLoyaltyToggled = false;
    private ImageView loyaltyToggleImg = null;

    //Mendix Settings
    private boolean isMendixToggled = false;
    private ImageView mendixToggleImg = null;

    //Merchant Settings
    private boolean isMerchantToggled = false;
    private ImageView merchantToggleImg = null;

    //cashdraw Settings
    private boolean isCashDrawToggled = false;
    private ImageView cashDrawToggleImg = null;
    //Magreader Settings
    private boolean isMagReaderToggled = false;
    private ImageView magReaderToggleImg = null;

    //error Logging Settings
    private boolean isErrorLoggingToggled = false;
    private ImageView errorLoggingToggleImg = null;
    private ProgressDialog progressDialog;
    private BluDroidIntegerEditText logPeriodSetting;

    //scanner Settings
    private boolean isScannerToggled = false;
    private ImageView scannerToggleImg = null;

    //epub Settings
    private boolean isEpubToggled = false;
    private ImageView epubToggleImg = null;

    //heartbeat Settings
    private boolean isHeartbeatToggled = false;
    private ImageView heartbeatToggleImg = null;

    private BluDroidAlertDialog alert = null;
    private int confirmationType = 0;  // 1=leaveNoSave, 2=restoreDefaults, 3=save

    private BluDroidTimeoutEditText aeonTimeoutEditText;
    private BluDroidTimeoutEditText transactionTimeoutEditText;
    private String errorMessage;

    private BluDroidRelativeLayout layout = null;

    private ArrayList<String> scanners;
    private BluDroidEditText scannerSetting;

    private BluDroidSwitch secureUsbPrinterSwitch;
    private BluDroidSwitch manualSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tech_config);
        layout = findViewById(R.id.layout);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        manualSwitch = findViewById(R.id.manualOverrideSwitch);

        setupManualOverrideField();
        disableEnableConfigFields();
        updateConfigFields();

        aeonTimeoutEditText = findViewById(R.id.aeonTimeoutSetting);
        transactionTimeoutEditText = findViewById(R.id.transactionTimeoutSetting);
        logPeriodSetting = findViewById(R.id.logPeriodSetting);

        secureUsbPrinterSwitch = findViewById(R.id.secureUsbPrinterSwitch);

        scannerSetting = findViewById(R.id.scannerSetting);
        BluDroidSpinner scannerSPinner = findViewById(R.id.scannerSpinner);

        scanners = new ArrayList<>();
        scanners.add("com.google.zxing.client.android");
        scanners.add("com.codecorp.cortex_scan");

        ArrayAdapter<String> scannersAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, scanners);
        scannerSPinner.setAdapter(scannersAdapter);

        scannerSPinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                scannerSetting.setText(scanners.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Button techSave = findViewById(R.id.save);
        techSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logger.info("ActivityTechnicianConfig" + ((BluDroidButton) view).getText());
                Log.d(TAG, "techSave onClick");
                confirmationType = 3;
                startSaving();
            }
        });

        BluDroidButton exportLogs = findViewById(R.id.exportLogs);
        exportLogs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportLogFiles();
            }

        });

        toolbar = findViewById(R.id.toolbar);
        String title = "Technician Settings";
        toolbar.setTitle(title);
        toolbar.setNavigationCloseIcon();
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                confirmationType = 1;

                if (
                    //Config
                        hasChanges(R.id.manualOverrideSwitch, PREF_MANUAL_OVERRIDE)

                                //Device settings
                                || hasChanges(R.id.hostSetting, PREF_HOST)
                                || hasChanges(R.id.portSetting, PREF_PORT)
                                || hasChanges(R.id.sslSwitch, PREF_USE_SSL)
                                || hasChanges(R.id.vatRegNoSetting, PREF_VAT_REG_NO)
                                || hasChanges(R.id.deviceIdSetting, PREF_DEVICE_ID)

                                //Location
                                || hasChanges(R.id.locationEnableSwitch, PREF_LOCATION_CHECK)

                                //Theme
                                || hasChanges(R.id.themeRadios, PREF_SKIN)

                                //Printer
                                || hasChanges(R.id.paperCutterSwitch, PREF_PAPER_CUTTER)
                                || hasChanges(R.id.secureUsbPrinterSwitch, PREF_SECURE_USB_PRINTER)
                                || hasChanges(R.id.salesReceiptSwitch, PREF_PRINT_SALES_RECEIPT)
                                || hasChanges(R.id.printerWidthRadios, PREF_PRINTER_WIDTH)
                                || hasChanges(R.id.voucherSecondsRadios, PREF_VOUCHER_SECONDS)

                                //Timeout
                                || hasChanges(R.id.aeonTimeoutSetting, PREF_AEON_TIMEOUT)
                                || hasChanges(R.id.transactionTimeoutSetting, PREF_TRANSACTION_TIMEOUT)

                                //Tech Pin
                                //|| hasChanges(R.id.newPinSetting,PREF_UNKNOWN)
                                //|| hasChanges(R.id.confirmPinSetting,PREF_UNKNOWN)

                                //RICA
                                || hasChanges(R.id.ricaHostSetting, PREF_RICA_HOST)
                                || hasChanges(R.id.ricaPortSetting, PREF_RICA_PORT)
                                || hasChanges(R.id.ricaDeviceIdSetting, PREF_RICA_DEVICE_ID)
                                || hasChanges(R.id.ricaDeviceSerialSetting, PREF_RICA_DEVICE_SER)
                                || hasChanges(R.id.ricaSSLSwitch, PREF_RICA_USE_SSL)
                                || hasChanges(R.id.boxRicaSwitch, PREF_RICA_CAN_BOXRICA)

                                //REPOSITORY
                                || hasChanges(R.id.fdroidHostSetting, PREF_FDROID_REPO_URL)
                                || hasChanges(R.id.fdroidRepoSetting, PREF_FDROID_REPO_DIR)

                                //LOYALTY
                                || hasChanges(R.id.loyaltyEnableSwitch, PREF_LOYALTY_ENABLE_TECH)
                                || hasChanges(R.id.loyaltyHostSetting, PREF_LOYALTY_URL)

                                //MENDIX
                                || hasChanges(R.id.mendixUrlSetting, PREF_MENDIX_URL)

                                //MERCHANT PORTAL
                                || hasChanges(R.id.merchantHostSetting, PREF_BLUKEY_URL)

                                || hasChanges(R.id.cashDrawSwitch, PREF_CASH_DRAWER)

                                || hasChanges(R.id.magReaderSwitch, PREF_MAG_READER)

                                || hasChanges(R.id.logPeriodSetting, PREF_LOG_DAYS)

                                || hasChanges(R.id.scannerSetting, PREF_SCANNING_APP)

                                || hasChanges(R.id.ePubHostSetting, PREF_EPUB_READER_URL)
                                || hasChanges(R.id.epubManualSetting, PREF_EPUB_MANUAL_URL)

                                //HEARTBEAT
                                || hasChanges(R.id.heartbeatEnableSwitch, PREF_HEARTBEAT_ENABLE_TECH)
                                || hasChanges(R.id.heartbeatIntervalsRadios, PREF_AWS_HEARTBEAT_MINUTES)
                                || hasChanges(R.id.heartbeatURLSetting, PREF_HEARTBEAT_URL)) {

                    alert = createLeaveNoSaveConfirmation();

                    setAlertNuetralButton();
                    setAlertNegetiveButton();
                    setAlertPositiveButton();
                    alert.show();
                } else {
                    gotoLandingScreen();
                }
            }
        });

        //Toggling arrows
        deviceToggleImg = findViewById(R.id.deviceToggle);
        locationToggleImg = findViewById(R.id.locationToggle);
        themeToggleImg = findViewById(R.id.themeToggle);
        printerToggleImg = findViewById(R.id.printerToggle);
        timeoutToggleImg = findViewById(R.id.timeoutToggle);
        ricaToggleImg = findViewById(R.id.ricaToggle);
        fdroidToggleImg = findViewById(R.id.fdroidToggle);
        loyaltyToggleImg = findViewById(R.id.loyaltyToggle);
        mendixToggleImg = findViewById(R.id.mendixToggle);
        merchantToggleImg = findViewById(R.id.merchantToggle);
        cashDrawToggleImg = findViewById(R.id.cashDrawToggle);
        magReaderToggleImg = findViewById(R.id.magReaderToggle);
        errorLoggingToggleImg = findViewById(R.id.errorLoggingToggle);
        scannerToggleImg = findViewById(R.id.scannerToggle);
        epubToggleImg = findViewById(R.id.epubToggle);
        heartbeatToggleImg = findViewById(R.id.heartbeatToggle);

        initFields();
        hideDeviceSettings();
        hideLocationSettings();
        hideThemeSettings();
        hidePrinterSettings();
        hideTimeoutSettings();
        hideRicaSettings();
        hideFdroidSettings();
        hideLoyaltySettings();
        hideMendixSettings();
        hideMerchantSettings();
        hideCashDRawSettings();
        hideMagReaderSettings();
        hideErrorLoggingSettings();
        hideScannerSettings();
        hideEpubSettings();
        hideToggleErrors();
        hideHeartbeatSettings();

        LinearLayout deviceToggle = findViewById(R.id.deviceSettingsGroupToggle);
        deviceToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isDeviceToggled) {
                    hideDeviceSettings();
                    deviceToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showDeviceSettings();
                    deviceToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isDeviceToggled = !isDeviceToggled;
            }
        });

        LinearLayout locationToggle = findViewById(R.id.locationSettingsGroupToggle);
        locationToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isLocationToggled) {
                    hideLocationSettings();
                    locationToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showLocationSettings();
                    locationToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isLocationToggled = !isLocationToggled;
            }
        });

        LinearLayout themeToggle = findViewById(R.id.themeSettingsGroupToggle);
        themeToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isThemeToggled) {
                    hideThemeSettings();
                    themeToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showThemeSettings();
                    themeToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isThemeToggled = !isThemeToggled;
            }
        });

        LinearLayout printerToggle = findViewById(R.id.printerSettingsGroupToggle);
        printerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isPrinterToggled) {
                    hidePrinterSettings();
                    printerToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showPrinterSettings();
                    printerToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isPrinterToggled = !isPrinterToggled;
            }
        });

        LinearLayout timeoutToggle = findViewById(R.id.timeoutSettingsGroupToggle);
        timeoutToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isTimeoutToggled) {
                    hideTimeoutSettings();
                    timeoutToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showTimeoutSettings();
                    timeoutToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isTimeoutToggled = !isTimeoutToggled;
            }
        });

        LinearLayout ricaToggle = findViewById(R.id.ricaSettingsGroupToggle);
        ricaToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isRicaToggled) {
                    hideRicaSettings();
                    ricaToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showRicaSettings();
                    ricaToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isRicaToggled = !isRicaToggled;
            }
        });

        LinearLayout fdroidToggle = findViewById(R.id.fdroidSettingsGroupToggle);
        fdroidToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isFdroidToggled) {
                    hideFdroidSettings();
                    fdroidToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showFdroidSettings();
                    fdroidToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isFdroidToggled = !isFdroidToggled;
            }
        });

        LinearLayout loyaltyToggle = findViewById(R.id.loyaltySettingsGroupToggle);
        loyaltyToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetTimer();
                if (isLoyaltyToggled) {
                    hideLoyaltySettings();
                    loyaltyToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showLoyaltySettings();
                    loyaltyToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isLoyaltyToggled = !isLoyaltyToggled;
            }
        });

        LinearLayout mendixToggle = findViewById(R.id.mendixSettingsGroupToggle);
        mendixToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetTimer();
                if (isMendixToggled) {
                    hideMendixSettings();
                    mendixToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showMendixSettings();
                    mendixToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isMendixToggled = !isMendixToggled;
            }
        });

        LinearLayout merchantToggle = findViewById(R.id.merchantSettingsGroupToggle);
        merchantToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetTimer();
                if (isMerchantToggled) {
                    hideMerchantSettings();
                    merchantToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showMerchantSettings();
                    merchantToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isMerchantToggled = !isMerchantToggled;
            }
        });

        LinearLayout cashDrawToggle = findViewById(R.id.cashDrawGroupToggle);
        cashDrawToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isCashDrawToggled) {
                    hideCashDRawSettings();
                    cashDrawToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showCashDrawSettings();
                    cashDrawToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isCashDrawToggled = !isCashDrawToggled;
            }
        });

        LinearLayout magReaderToggle = findViewById(R.id.magReaderGroupToggle);
        magReaderToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();
                if (isMagReaderToggled) {
                    hideMagReaderSettings();
                    magReaderToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showMagReaderSettings();
                    magReaderToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isMagReaderToggled = !isMagReaderToggled;
            }
        });

        LinearLayout errorLoggingToggle = findViewById(R.id.errorLoggingGroupToggle);
        errorLoggingToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isErrorLoggingToggled) {
                    hideErrorLoggingSettings();
                    errorLoggingToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showErrorLoggingSettings();
                    errorLoggingToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isErrorLoggingToggled = !isErrorLoggingToggled;
            }
        });

        LinearLayout scannerToggle = findViewById(R.id.scannerGroupToggle);
        scannerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isScannerToggled) {
                    hideScannerSettings();
                    scannerToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showScannerSettings();
                    scannerToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isScannerToggled = !isScannerToggled;
            }
        });

        LinearLayout ePubToggle = findViewById(R.id.epubGroupToggle);
        ePubToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isEpubToggled) {
                    hideEpubSettings();
                    epubToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showEpubSettings();
                    epubToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isEpubToggled = !isEpubToggled;
            }
        });

        LinearLayout heartbeatToggle = findViewById(R.id.heartbeatSettingsGroupToggle);
        heartbeatToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                resetTimer();

                if (isHeartbeatToggled) {
                    hideHeartbeatSettings();
                    heartbeatToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_right));
                } else {
                    showHeartbeatSettings();
                    heartbeatToggleImg.setImageDrawable(getResources().getDrawable(R.drawable.arrow_down));
                }
                isHeartbeatToggled = !isHeartbeatToggled;
            }
        });
    }

    private void startSaving() {

        //
        // this will loop through all subcomponents and validate
        // them also
        //
        //
        hideToggleErrors();

        if (layout.validate()) {

            int aeonTimeout = Integer.parseInt(aeonTimeoutEditText.getText().toString());
            int transactionTimeout = Integer.parseInt(transactionTimeoutEditText.getText().toString());
            int days = Integer.parseInt(logPeriodSetting.getText().toString());

            if (validateAeonTimeout(aeonTimeout)) {

                if (validateTransactionTimeout(transactionTimeout)) {
                    if (validateFileLogDays(days)) {
                        createTechPinConfirmation();
                    } else {
                        logPeriodSetting.setErrorMessage(errorMessage);
                    }
                } else {
                    transactionTimeoutEditText.setErrorMessage(errorMessage);
                }
            } else {
                aeonTimeoutEditText.setErrorMessage(errorMessage);
            }
        } else {
            showToggleErrors();
        }

    }

    private void exportLogFiles() {

        final String time = todaysDateTimeForLogFiles();
        final File[] logs = privateLogsDir.listFiles();

        progressDialog = new ProgressDialog(ActivityTechnicianConfig.this);
        progressDialog.setMax(logs.length);
        progressDialog.setTitle("Exporting Logs...");
        progressDialog.setMessage("Exporting logs zip folder...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    for (int i = 0; progressDialog.getProgress() <= progressDialog
                            .getMax() && i < logs.length; i++) {

                        long freeSpace = logsDir.getFreeSpace();
                        long bytesNeeded = logs[i].length();

                        if (bytesNeeded * 5 < freeSpace) {

                            String targetPath = logs[i].getPath();
                            String destinationPath = logsDir.getPath() + "/bluDroid-" + time + ".zip";

                            ZipArchive.zip(targetPath, destinationPath, "LogFiles-2019-BD3");
                            Log.d(TAG, "onClick: " + targetPath);
                            Log.d(TAG, "onClick: " + destinationPath);
                            progressDialog.incrementProgressBy(1);
                            if (progressDialog.getProgress() == progressDialog
                                    .getMax()) {
                                Thread.sleep(500);
                                progressDialog.dismiss();
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        createAlertDialog("Export Complete", "The Log files were " +
                                                "exported\nto " + logsDir.getPath());
                                    }
                                });

                            }
                        } else {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    progressDialog.dismiss();
                                    try {
                                        alert = new BluDroidAlertDialog(ActivityTechnicianConfig.this);
                                        alert.setTitle("Export Incomplete");
                                        alert.setMessage("Not enough space " +
                                                "on the device");
                                        alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                alert.dismiss();
                                            }
                                        });
                                        alert.show();
                                    } catch (Exception exception) {
                                        Log.d(TAG, "createAlert " + exception);
                                        logger.error("there was insufficient space to export logs ");
                                    }

                                }
                            });
                        }


                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error("problem exporting file" + e);
                }
            }
        }).start();

    }


    private void showToggleErrors() {
        if (deviceSettingsHaserrors) {
            hideShow(R.id.deviceError, VISIBLE);
        }
        if (timeoutSettingsHaserrors) {
            hideShow(R.id.timeoutError, VISIBLE);
        }
        if (ricaSettingsHaserrors) {
            hideShow(R.id.ricaError, VISIBLE);
        }
        if (repositorySettingsHaserrors) {
            hideShow(R.id.repositoryError, VISIBLE);
        }
        if (ePubSettingsHaserrors) {
            hideShow(R.id.ePubError, VISIBLE);
        }
        if (heartbeatSettingsHaserrors) {
            hideShow(R.id.heartbeatError, VISIBLE);
        }
        if (apiGatewaySettingsHaserrors) {
            hideShow(R.id.loyaltyError, VISIBLE);
        }
        if (mendixApiSettingsHaserrors) {
            hideShow(R.id.mendixError, VISIBLE);
        }
        if (bluKeySettingsHaserrors) {
            hideShow(R.id.merchantError, VISIBLE);
        }
        if (errorLoggingSettingsHaserrors) {
            hideShow(R.id.errorLoggingError, VISIBLE);
        }
    }

    private void hideToggleErrors() {
        removeTechToggleErrors();

        hideShow(R.id.deviceError, GONE);
        hideShow(R.id.ricaError, GONE);
        hideShow(R.id.timeoutError, GONE);
        hideShow(R.id.repositoryError, GONE);
        hideShow(R.id.ePubError, GONE);
        hideShow(R.id.heartbeatError, GONE);
        hideShow(R.id.loyaltyError, GONE);
        hideShow(R.id.mendixError, GONE);
        hideShow(R.id.merchantError, GONE);
        hideShow(R.id.errorLoggingError, GONE);
    }

    private boolean validateAeonTimeout(int aeonTimeout) {
        boolean isValidated = false;

        int screenTimeout = Integer.parseInt(getPreference(PREF_SCREEN_TIMEOUT));
        int transactionTimeout = Integer.parseInt(getPreference(PREF_TRANSACTION_TIMEOUT));

        if (aeonTimeout > screenTimeout) {

            if (aeonTimeout > transactionTimeout) {
                isValidated = true;
            } else {
                timeoutSettingsHaserrors = true;
                errorMessage = "The AEON Timeout cannot be smaller or equal to the Transaction Timeout which is " + transactionTimeout;
                showToggleErrors();
            }

        } else {
            timeoutSettingsHaserrors = true;
            errorMessage = "The AEON Timeout cannot be smaller or equal to the Screen Timeout which is " + screenTimeout;
            showToggleErrors();
        }

        return isValidated;
    }

    private boolean validateTransactionTimeout(int transactionTimeout) {
        boolean isValidated = false;

        int screenTimeout = Integer.parseInt(getPreference(PREF_SCREEN_TIMEOUT));
        int aeonTimeout = Integer.parseInt(getPreference(PREF_AEON_TIMEOUT));

        if (transactionTimeout < screenTimeout) {

            if (transactionTimeout < aeonTimeout) {
                isValidated = true;
            } else {
                timeoutSettingsHaserrors = true;
                errorMessage = "The Transaction Timeout cannot be greater or equal to the AEON Timeout which is " + aeonTimeout;
                showToggleErrors();
            }

        } else {
            timeoutSettingsHaserrors = true;
            errorMessage = "The Transaction Timeout cannot be greater or equal to the Screen Timeout which is " + screenTimeout;
            showToggleErrors();
        }

        return isValidated;
    }

    private boolean validateFileLogDays(int days) {
        boolean isValidated = false;

        if (days > 0 && days < 8) {
            isValidated = true;
        } else {
            errorLoggingSettingsHaserrors = true;
            errorMessage = "Number of days must be between 1 and 7";
            showToggleErrors();
        }

        return isValidated;
    }

    private void initFields() {

        //Config
        setupSwitch(R.id.manualOverrideSwitch, PREF_MANUAL_OVERRIDE);

        //Device Settings
        setupEditText(R.id.hostSetting, PREF_HOST);
        setupEditText(R.id.portSetting, PREF_PORT);
        setupSwitch(R.id.sslSwitch, PREF_USE_SSL);
        setupEditText(R.id.deviceIdSetting, PREF_DEVICE_ID);
        setupEditText(R.id.deviceSerialSetting, PREF_DEVICE_SER);

        //Location Settings
        setupSwitch(R.id.locationEnableSwitch, PREF_LOCATION_CHECK);

        //Theme Settings
        setupRadioGroup(R.id.themeRadios, PREF_SKIN);

        //Printer Settings
        setupSwitch(R.id.paperCutterSwitch, PREF_PAPER_CUTTER);
        setupRadioGroup(R.id.voucherSecondsRadios, PREF_VOUCHER_SECONDS);
        setupSwitch(R.id.secureUsbPrinterSwitch, PREF_SECURE_USB_PRINTER);
        setupSwitch(R.id.salesReceiptSwitch, PREF_PRINT_SALES_RECEIPT);
        setupRadioGroup(R.id.printerWidthRadios, PREF_PRINTER_WIDTH);

        //Timeout Settings
        setupEditText(R.id.aeonTimeoutSetting, PREF_AEON_TIMEOUT);
        setupEditText(R.id.transactionTimeoutSetting, PREF_TRANSACTION_TIMEOUT);

        //Rica Settings
        setupEditText(R.id.ricaHostSetting, PREF_RICA_HOST);
        setupEditText(R.id.ricaPortSetting, PREF_RICA_PORT);
        setupEditText(R.id.ricaDeviceIdSetting, PREF_RICA_DEVICE_ID);
        setupEditText(R.id.ricaDeviceSerialSetting, PREF_RICA_DEVICE_SER);
        setupSwitch(R.id.ricaSSLSwitch, PREF_RICA_USE_SSL);
        setupSwitch(R.id.boxRicaSwitch, PREF_RICA_CAN_BOXRICA);

        //Fdroid Settings
        setupEditText(R.id.fdroidHostSetting, PREF_FDROID_REPO_URL);
        setupEditText(R.id.fdroidRepoSetting, PREF_FDROID_REPO_DIR);

        //Loyalty Settings
        setupEditText(R.id.loyaltyHostSetting, PREF_LOYALTY_URL);
        setupSwitch(R.id.loyaltyEnableSwitch, PREF_LOYALTY_ENABLE_TECH);

        //Mendix Settings
        setupEditText(R.id.mendixUrlSetting, PREF_MENDIX_URL);

        //Merchant Portal Settings
        setupEditText(R.id.merchantHostSetting, PREF_BLUKEY_URL);

        //cashDraw Settings
        setupSwitch(R.id.cashDrawSwitch, PREF_CASH_DRAWER);

        //magReader Settings
        setupSwitch(R.id.magReaderSwitch, PREF_MAG_READER);
        BluDroidSwitch magReaderSwitch = findViewById(R.id.magReaderSwitch);
        magReaderSwitch.setEnabled(Build.MODEL.startsWith("CITAQ") || Build.MODEL.startsWith("P1_4G"));

        //ErrorLogging Settings
        setupEditText(R.id.logPeriodSetting, PREF_LOG_DAYS);
        setupSwitch(R.id.firebaseSwitch, PREF_IOT_FLAG_ENABLE);

        //Scanner Settings
        setupEditText(R.id.scannerSetting, PREF_SCANNING_APP);
        setupSpinner(R.id.scannerSpinner, PREF_SCANNING_APP, scanners);

        setupEditText(R.id.ePubHostSetting, PREF_EPUB_READER_URL);
        setupEditText(R.id.epubManualSetting, PREF_EPUB_MANUAL_URL);

        //Heartbeat Settings
        setupEditText(R.id.heartbeatURLSetting, PREF_HEARTBEAT_URL);
        setupSwitch(R.id.heartbeatEnableSwitch, PREF_HEARTBEAT_ENABLE_TECH);
        setupRadioGroup(R.id.heartbeatIntervalsRadios, PREF_AWS_HEARTBEAT_MINUTES);

        if (isGcrsSkin()) {
            findViewById(R.id.merchantSettingsGroupToggle).setVisibility(View.GONE);
            findViewById(R.id.epubGroupToggle).setVisibility(View.GONE);
            findViewById(R.id.layoutLoyaltyEnable).setVisibility(View.GONE);
        }

        if (isGcrs()) {
            findViewById(R.id.bltRadio).setVisibility(View.GONE);
            findViewById(R.id.tspcRadio).setVisibility(View.GONE);
            ((RadioButton) findViewById(R.id.gcrsRadio)).setChecked(true);
        } else if (isRelease()) {
            findViewById(R.id.gcrsRadio).setVisibility(View.GONE);
        }

    }

    private void setupManualOverrideField() {

        BluDroidLinearLayout manualLinearLayout = findViewById(R.id.manualOverride);

        if (!(isDebug() || isQa())) {
            manualLinearLayout.setVisibility(GONE);
            enableDisableConfigField(R.id.hostSetting, false);
            enableDisableConfigField(R.id.portSetting, false);
            enableDisableConfigField(R.id.sslSwitch, false);
            enableDisableConfigField(R.id.fdroidHostSetting, false);
            enableDisableConfigField(R.id.heartbeatURLSetting, false);
            enableDisableConfigField(R.id.merchantHostSetting, false);
            enableDisableConfigField(R.id.loyaltyHostSetting, false);
            enableDisableConfigField(R.id.ricaDeviceSerialSetting, false);
            enableDisableConfigField(R.id.ricaDeviceIdSetting, false);
            enableDisableConfigField(R.id.ricaPortSetting, false);
            enableDisableConfigField(R.id.ricaHostSetting, false);
            enableDisableConfigField(R.id.ricaSSLSwitch, false);
            enableDisableConfigField(R.id.mendixUrlSetting, false);
        } else {
            if (getPreference(PREF_MANUAL_OVERRIDE).equalsIgnoreCase(PREF_TRUE)) {
                manualSwitch.setChecked(true);
            } else {
                manualSwitch.setChecked(false);
                enableDisableConfigField(R.id.hostSetting, false);
                enableDisableConfigField(R.id.portSetting, false);
                enableDisableConfigField(R.id.sslSwitch, false);
                enableDisableConfigField(R.id.fdroidHostSetting, false);
                enableDisableConfigField(R.id.heartbeatURLSetting, false);
                enableDisableConfigField(R.id.merchantHostSetting, false);
                enableDisableConfigField(R.id.loyaltyHostSetting, false);
                enableDisableConfigField(R.id.ricaDeviceSerialSetting, false);
                enableDisableConfigField(R.id.ricaDeviceIdSetting, false);
                enableDisableConfigField(R.id.ricaPortSetting, false);
                enableDisableConfigField(R.id.ricaHostSetting, false);
                enableDisableConfigField(R.id.ricaSSLSwitch, false);
                enableDisableConfigField(R.id.mendixUrlSetting, false);
            }
        }
    }

    private void disableEnableConfigFields() {

        manualSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    enableDisableConfigField(R.id.hostSetting, true);
                    enableDisableConfigField(R.id.portSetting, true);
                    enableDisableConfigField(R.id.sslSwitch, true);
                    enableDisableConfigField(R.id.fdroidHostSetting, true);
                    enableDisableConfigField(R.id.heartbeatURLSetting, true);
                    enableDisableConfigField(R.id.merchantHostSetting, true);
                    enableDisableConfigField(R.id.loyaltyHostSetting, true);
                    enableDisableConfigField(R.id.ricaDeviceSerialSetting, true);
                    enableDisableConfigField(R.id.ricaDeviceIdSetting, true);
                    enableDisableConfigField(R.id.ricaPortSetting, true);
                    enableDisableConfigField(R.id.ricaHostSetting, true);
                    enableDisableConfigField(R.id.ricaSSLSwitch, true);
                    enableDisableConfigField(R.id.mendixUrlSetting, true);
                } else {
                    updateConfigFields();
                    enableDisableConfigField(R.id.hostSetting, false);
                    enableDisableConfigField(R.id.portSetting, false);
                    enableDisableConfigField(R.id.sslSwitch, false);
                    enableDisableConfigField(R.id.fdroidHostSetting, false);
                    enableDisableConfigField(R.id.heartbeatURLSetting, false);
                    enableDisableConfigField(R.id.merchantHostSetting, false);
                    enableDisableConfigField(R.id.loyaltyHostSetting, false);
                    enableDisableConfigField(R.id.ricaDeviceSerialSetting, false);
                    enableDisableConfigField(R.id.ricaDeviceIdSetting, false);
                    enableDisableConfigField(R.id.ricaPortSetting, false);
                    enableDisableConfigField(R.id.ricaHostSetting, false);
                    enableDisableConfigField(R.id.ricaSSLSwitch, false);
                    enableDisableConfigField(R.id.mendixUrlSetting, true);
                }
            }
        });
    }

    private void updateConfigFields() {
        EditText hostEditText = findViewById(R.id.hostSetting);
        EditText portEditText = findViewById(R.id.portSetting);
        EditText repoUrlEditText = findViewById(R.id.fdroidHostSetting);
        BluDroidSwitch aeonSslSwitch = findViewById(R.id.sslSwitch);
        EditText heartbeatUrlEditText = findViewById(R.id.heartbeatURLSetting);
        EditText blukeyUrlEditText = findViewById(R.id.merchantHostSetting);
        EditText apiGatewayEditText = findViewById(R.id.loyaltyHostSetting);
        EditText ricaSerialNumberEditText = findViewById(R.id.ricaDeviceSerialSetting);
        EditText ricaDeviceIdEditText = findViewById(R.id.ricaDeviceIdSetting);
        EditText ricaPortEditText = findViewById(R.id.ricaPortSetting);
        EditText ricaHostEditText = findViewById(R.id.ricaHostSetting);
        BluDroidSwitch ricaSslSwitch = findViewById(R.id.ricaSSLSwitch);
        EditText mendixUrlEditText = findViewById(R.id.mendixUrlSetting);

        if ((!manualSwitch.isChecked() || getPreference(PREF_MANUAL_OVERRIDE).equalsIgnoreCase(PREF_FALSE))) {
            hostEditText.setText(getPreference(PREF_HOST));
            portEditText.setText(getPreference(PREF_PORT));
            aeonSslSwitch.setChecked(getPreference(PREF_USE_SSL).equals(PREF_TRUE));
            repoUrlEditText.setText(getPreference(PREF_FDROID_REPO_URL));
            heartbeatUrlEditText.setText(getPreference(PREF_HEARTBEAT_URL));
            blukeyUrlEditText.setText(getPreference(PREF_BLUKEY_URL));
            apiGatewayEditText.setText(getPreference(PREF_LOYALTY_URL));
            ricaSerialNumberEditText.setText(getPreference(PREF_RICA_DEVICE_SER));
            ricaDeviceIdEditText.setText(getPreference(PREF_RICA_DEVICE_ID));
            ricaPortEditText.setText(getPreference(PREF_RICA_PORT));
            ricaHostEditText.setText(getPreference(PREF_RICA_HOST));
            ricaSslSwitch.setChecked(getPreference(PREF_RICA_USE_SSL).equals(PREF_TRUE));
            mendixUrlEditText.setText(getPreference(PREF_MENDIX_URL));
        }
    }


    private void hideDeviceSettings() {
        hideShow(R.id.deviceSettingsGroup, GONE);
    }

    private void showDeviceSettings() {
        hideShow(R.id.deviceSettingsGroup, View.VISIBLE);
    }

    private void hideLocationSettings() {
        hideShow(R.id.locationGroup, GONE);
    }

    private void showLocationSettings() {
        hideShow(R.id.locationGroup, View.VISIBLE);
    }

    private void hideThemeSettings() {
        hideShow(R.id.themeSettingsGroup, GONE);
    }

    private void showThemeSettings() {
        hideShow(R.id.themeSettingsGroup, View.VISIBLE);
    }

    private void hidePrinterSettings() {
        hideShow(R.id.printerSettingsGroup, GONE);
    }

    private void showPrinterSettings() {
        hideShow(R.id.printerSettingsGroup, View.VISIBLE);

        if (!Build.MODEL.startsWith("CITAQ")) {
            secureUsbPrinterSwitch.setEnabled(false);
        }
    }


    private void hideTimeoutSettings() {
        hideShow(R.id.timeoutSettingsGroup, GONE);
    }

    private void showTimeoutSettings() {
        hideShow(R.id.timeoutSettingsGroup, View.VISIBLE);
    }

    private void hideRicaSettings() {
        hideShow(R.id.ricaGroup, GONE);
    }

    private void showRicaSettings() {
        hideShow(R.id.ricaGroup, View.VISIBLE);
    }

    private void hideFdroidSettings() {
        hideShow(R.id.fdroidGroup, GONE);
    }

    private void hideLoyaltySettings() {
        hideShow(R.id.loyaltyGroup, GONE);
    }

    private void hideMendixSettings() {
        hideShow(R.id.mendixGroup, GONE);
    }

    private void hideMerchantSettings() {
        hideShow(R.id.merchantGroup, GONE);
    }

    private void showFdroidSettings() {
        hideShow(R.id.fdroidGroup, View.VISIBLE);
    }

    private void showLoyaltySettings() {
        hideShow(R.id.loyaltyGroup, View.VISIBLE);
    }

    private void showMendixSettings() {
        hideShow(R.id.mendixGroup, View.VISIBLE);
    }

    private void showMerchantSettings() {
        hideShow(R.id.merchantGroup, View.VISIBLE);
    }

    private void showCashDrawSettings() {
        hideShow(R.id.cashDrawGroup, View.VISIBLE);
    }

    private void hideCashDRawSettings() {
        hideShow(R.id.cashDrawGroup, GONE);
    }

    private void showMagReaderSettings() {
        hideShow(R.id.magReaderGroup, View.VISIBLE);
    }

    private void hideMagReaderSettings() {
        hideShow(R.id.magReaderGroup, GONE);
    }

    private void hideErrorLoggingSettings() {
        hideShow(R.id.errorLoggingGroup, GONE);
    }

    private void showErrorLoggingSettings() {
        hideShow(R.id.errorLoggingGroup, VISIBLE);
    }

    private void hideScannerSettings() {
        hideShow(R.id.scannerGroup, GONE);
    }

    private void showScannerSettings() {
        hideShow(R.id.scannerGroup, VISIBLE);
    }

    private void hideEpubSettings() {
        hideShow(R.id.epubGroup, GONE);
    }

    private void showEpubSettings() {
        hideShow(R.id.epubGroup, VISIBLE);
    }

    private void hideHeartbeatSettings() {
        hideShow(R.id.heartbeatGroup, GONE);
    }

    private void showHeartbeatSettings() {
        hideShow(R.id.heartbeatGroup, VISIBLE);
    }

    private boolean save() {
        Log.d(TAG, "save");
        try {

            BluDroidTechPinEditText techLoginPassword = confirmation.findViewById(R.id.techLoginPassword);
            Log.d(TAG, "techLoginPassword " + techLoginPassword);

            String thisTechPin = techLoginPassword.getText().toString().trim();
            Log.v(TAG, "thisTechPin " + thisTechPin);

            if (thisTechPin.equals(getPreference("techPin"))) {
                Log.v(TAG, "techPins OK");
                refresh();

                if (hasChanges(R.id.deviceIdSetting, PREF_DEVICE_ID)) {
                    updatePreference(PREF_DISPLAY_BALANCE1, getString(R.string.display_low_balance_default));
                    updatePreference(PREF_DEF_ACCOUNT, getString(R.string.account_default));
                    updatePreference(PREF_DEF_ACCOUNT_INDEX, getString(R.string.account_index_default));
                }
                //Manual Override
                compareUpdate(PREF_MANUAL_OVERRIDE, R.id.manualOverrideSwitch);

                //Device settings
                compareUpdate(PREF_HOST, R.id.hostSetting);
                compareUpdate(PREF_PORT, R.id.portSetting);
                compareUpdate(PREF_USE_SSL, R.id.sslSwitch);
                compareUpdate(PREF_DEVICE_ID, R.id.deviceIdSetting);

                //Location Settings
                compareUpdate(PREF_LOCATION_CHECK, R.id.locationEnableSwitch);

                //Printer Settings
                compareUpdate(PREF_PAPER_CUTTER, R.id.paperCutterSwitch);
                compareUpdate(PREF_VOUCHER_SECONDS, R.id.voucherSecondsRadios);
                compareUpdate(PREF_SECURE_USB_PRINTER, R.id.secureUsbPrinterSwitch);
                compareUpdate(PREF_PRINT_SALES_RECEIPT, R.id.salesReceiptSwitch);
                compareUpdate(PREF_PRINTER_WIDTH, R.id.printerWidthRadios);

                //Timeout Settings
                compareUpdate(PREF_AEON_TIMEOUT, R.id.aeonTimeoutSetting);
                compareUpdate(PREF_TRANSACTION_TIMEOUT, R.id.transactionTimeoutSetting);
                //Rica Settings
                compareUpdate(PREF_RICA_HOST, R.id.ricaHostSetting);
                compareUpdate(PREF_RICA_PORT, R.id.ricaPortSetting);
                compareUpdate(PREF_RICA_DEVICE_ID, R.id.ricaDeviceIdSetting);
                compareUpdate(PREF_RICA_DEVICE_SER, R.id.ricaDeviceSerialSetting);
                compareUpdate(PREF_RICA_USE_SSL, R.id.ricaSSLSwitch);
                compareUpdate(PREF_RICA_CAN_BOXRICA, R.id.boxRicaSwitch);

                //Fdroid settings
                compareUpdate(PREF_FDROID_REPO_URL, R.id.fdroidHostSetting);
                BluDroidDirectoryEditText fdroidRepoSetting = findViewById(R.id.fdroidRepoSetting);
                String folder = fdroidRepoSetting.getText().toString().trim();
                folder += folder.endsWith("/") ? "" : "/";
                fdroidRepoSetting.setText(folder);
                compareUpdate(PREF_FDROID_REPO_DIR, R.id.fdroidRepoSetting);

                //Loyalty settings
                compareUpdate(PREF_LOYALTY_ENABLE_TECH, R.id.loyaltyEnableSwitch);
                compareUpdate(PREF_LOYALTY_URL, R.id.loyaltyHostSetting);

                //mendix settings
                compareUpdate(PREF_MENDIX_URL, R.id.mendixUrlSetting);

                //Merchant portal settings
                compareUpdate(PREF_BLUKEY_URL, R.id.merchantHostSetting);

                //Cash drawer settings
                compareUpdate(PREF_CASH_DRAWER, R.id.cashDrawSwitch);

                //External Mag Encoder
                compareUpdate(PREF_MAG_READER, R.id.magReaderSwitch);

                //error logging settings
                compareUpdate(PREF_LOG_DAYS, R.id.logPeriodSetting);

                compareUpdate(PREF_SCANNING_APP, R.id.scannerSetting);

                compareUpdate(PREF_EPUB_READER_URL, R.id.ePubHostSetting);
                // compareUpdate(PREF_EPUB_READER_DIRECTORY, R.id.epubSetting);
                compareUpdate(PREF_EPUB_MANUAL_URL, R.id.epubManualSetting);


                //Heartbeat settings
                if (hasChanges(R.id.heartbeatEnableSwitch, PREF_HEARTBEAT_ENABLE_TECH)
                        || hasChanges(R.id.heartbeatIntervalsRadios, PREF_AWS_HEARTBEAT_MINUTES)
                        || hasChanges(R.id.heartbeatURLSetting, PREF_HEARTBEAT_URL)) {

                    stopHeartbeat();

                    //compareUpdate(PREF_HEARTBEAT_SSL, R.id.heartbeatSSLSwitch);
                    compareUpdate(PREF_AWS_HEARTBEAT_MINUTES, R.id.heartbeatIntervalsRadios);
                    compareUpdate(PREF_HEARTBEAT_ENABLE_TECH, R.id.heartbeatEnableSwitch);
                    compareUpdate(PREF_HEARTBEAT_URL, R.id.heartbeatURLSetting);
                }

                //
                //THEME Settings
                //
                if (hasChanges(R.id.themeRadios, PREF_SKIN)) {
                    compareUpdate(PREF_SKIN, R.id.themeRadios);
                    createNotification(String.format(getResources().getString(R.string.changesSaved), "Technician"));
                }

                return true;
            } else {
                Log.v(TAG, "techPins not correct");
                //
                // this following line does not seem to work
                // i suspect it is because it is in a dialog
                // and not on an activity screen
                //
                // techLoginPassword.setErrorMessage(R.string.techPinInvalid);

                BluDroidErrorTextView error = confirmation.findViewById(R.id.techLoginPasswordError);
                error.setContext(this);
                error.setup();
                error.setText(getResources().getString(R.string.techPinInvalid));
                return false;
            }

        } catch (Exception ignored) {
        }
        return false;
    }

    private void setAlertPositiveButton() {
        if (alert != null) {
            alert.setPositiveOption(getResources().getString(R.string.save), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    confirmationType = 3;
                    startSaving();
                }
            });
        }
    }

    private void setAlertNegetiveButton() {
        if (alert != null) {
            alert.setNegativeOption(getResources().getString(R.string.leave), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    gotoLandingScreen();
                }
            });
        }
    }

    private void setAlertNuetralButton() {
        if (alert != null) {
            alert.setNeutralOption(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alert.dismiss();
                }
            });
        }
    }

    public void affirmativeButton(View view) {
        Log.d(TAG, "affirmativeButton confirmationType=" + confirmationType);
        if (confirmationType == 1) {
            dismissConfirmation();
            confirmationType = 0;
        } else if (confirmationType == 2) {
            confirmation.dismiss();
            Toast.makeText(this, "THIS IS NOT YET IMPLEMENTED.  AWAITING FURTHER INFORMATION", LENGTH_LONG).show();
            confirmationType = 0;
        } else if (confirmationType == 3) {
            Log.d(TAG, "saving");
            if (save()) {
                Log.d(TAG, "got back true");
                gotoLandingScreen();
                createNotification(String.format(getResources().getString(R.string.changesSaved), "Technician"));
                confirmationType = 0;
            } else {
                Log.d(TAG, "got back false");
            }
        }
    }

    public void negativeButton(View view) {
        Log.d(TAG, "negativeButton");
        Log.d(TAG, "affirmativeButton confirmationType=" + confirmationType);
        if (confirmationType == 1) {
            gotoLandingScreen();
            confirmationType = 0;
        } else if (confirmationType == 2) {
            confirmation.dismiss();
            Toast.makeText(this, "THIS IS NOT YET IMPLEMENTED.  AWAITING FURTHER INFORMATION", LENGTH_LONG).show();
            confirmationType = 0;
        } else if (confirmationType == 3) {
            confirmationType = 0;
            confirmation.dismiss();
        }
    }

    public void neutralButton(View view) {
        Log.d(TAG, "neutralButton");
        confirmationType = 0;
        confirmation.dismiss();
    }

    @Override
    public void onBackPressed() {
        resetTimer();

        if (
            //Config
                hasChanges(R.id.manualOverrideSwitch, PREF_MANUAL_OVERRIDE)

                        || hasChanges(R.id.hostSetting, PREF_HOST)
                        || hasChanges(R.id.portSetting, PREF_PORT)
                        || hasChanges(R.id.sslSwitch, PREF_USE_SSL)
                        || hasChanges(R.id.vatRegNoSetting, PREF_VAT_REG_NO)
                        || hasChanges(R.id.deviceIdSetting, PREF_DEVICE_ID)

                        //Location
                        || hasChanges(R.id.locationEnableSwitch, PREF_LOCATION_CHECK)

                        //Theme
                        || hasChanges(R.id.themeRadios, PREF_SKIN)

                        //Printer
                        || hasChanges(R.id.paperCutterSwitch, PREF_PAPER_CUTTER)
                        || hasChanges(R.id.secureUsbPrinterSwitch, PREF_SECURE_USB_PRINTER)
                        || hasChanges(R.id.salesReceiptSwitch, PREF_PRINT_SALES_RECEIPT)
                        || hasChanges(R.id.printerWidthRadios, PREF_PRINTER_WIDTH)
                        || hasChanges(R.id.voucherSecondsRadios, PREF_VOUCHER_SECONDS)

                        //Timeout
                        || hasChanges(R.id.aeonTimeoutSetting, PREF_AEON_TIMEOUT)
                        || hasChanges(R.id.transactionTimeoutSetting, PREF_TRANSACTION_TIMEOUT)

                        //Tech Pin
                        //|| hasChanges(R.id.newPinSetting,PREF_UNKNOWN)
                        //|| hasChanges(R.id.confirmPinSetting,PREF_UNKNOWN)

                        //Loyalty
                        || hasChanges(R.id.loyaltyEnableSwitch, PREF_LOYALTY_ENABLE_TECH)
                        || hasChanges(R.id.loyaltyHostSetting, PREF_LOYALTY_URL)

                        //Mendix
                        || hasChanges(R.id.mendixUrlSetting, PREF_MENDIX_URL)

                        //Merchant portal
                        || hasChanges(R.id.merchantHostSetting, PREF_BLUKEY_URL)

                        //RICA
                        || hasChanges(R.id.ricaHostSetting, PREF_RICA_HOST)
                        || hasChanges(R.id.ricaPortSetting, PREF_RICA_PORT)
                        || hasChanges(R.id.ricaDeviceIdSetting, PREF_RICA_DEVICE_ID)
                        || hasChanges(R.id.ricaDeviceSerialSetting, PREF_RICA_DEVICE_SER)
                        || hasChanges(R.id.ricaSSLSwitch, PREF_RICA_USE_SSL)
                        || hasChanges(R.id.boxRicaSwitch, PREF_RICA_CAN_BOXRICA)

                        //REPOSITORY
                        || hasChanges(R.id.fdroidHostSetting, PREF_FDROID_REPO_URL)
                        || hasChanges(R.id.fdroidRepoSetting, PREF_FDROID_REPO_DIR)

                        || hasChanges(R.id.cashDrawSwitch, PREF_CASH_DRAWER)

                        || hasChanges(R.id.magReaderSwitch, PREF_MAG_READER)

                        || hasChanges(R.id.logPeriodSetting, PREF_LOG_DAYS)

                        || hasChanges(R.id.scannerSetting, PREF_SCANNING_APP)

                        || hasChanges(R.id.ePubHostSetting, PREF_EPUB_READER_URL)
                        || hasChanges(R.id.epubManualSetting, PREF_EPUB_MANUAL_URL)


                        || hasChanges(R.id.heartbeatEnableSwitch, PREF_HEARTBEAT_ENABLE_TECH)
                        || hasChanges(R.id.heartbeatIntervalsRadios, PREF_AWS_HEARTBEAT_MINUTES)
                        || hasChanges(R.id.heartbeatURLSetting, PREF_HEARTBEAT_URL)) {

            alert = createLeaveNoSaveConfirmation();

            setAlertNuetralButton();
            setAlertNegetiveButton();
            setAlertPositiveButton();
            alert.show();
        } else {
            gotoLandingScreen();
        }
    }
}
