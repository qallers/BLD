package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.text.InputType;
import android.util.AttributeSet;
import android.view.View;

import za.co.blts.bltandroidgui3.BaseActivity;

public class BluDroidNumericEditText extends BluDroidEditText implements View.OnTouchListener {

    public BluDroidNumericEditText(BaseActivity context) {
        super(context);
        setInputType(InputType.TYPE_CLASS_NUMBER);
    }

    public BluDroidNumericEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setInputType(InputType.TYPE_CLASS_NUMBER);
    }

    @Override
    public boolean validate() {
        return true;
    }
}

