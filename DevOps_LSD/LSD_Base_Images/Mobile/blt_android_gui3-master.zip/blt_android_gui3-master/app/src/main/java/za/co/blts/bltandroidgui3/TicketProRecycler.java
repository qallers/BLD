package za.co.blts.bltandroidgui3;

import java.util.ArrayList;
import java.util.Map;

import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.cardviews.CardviewTicketProCategory;

/**
 * Created by NkosanaM on 3/17/2017.
 */

class TicketProRecycler extends VoucherRecycler {

    void setupRecycler() {
        configureRecycler(createCategoryCards(retrieveCategories()));
    }

    private Map<String, String> retrieveCategories() {

        Map<String, String> categories = null;
        BaseActivity base = getBaseActivity();
        if (base.ticketProResponseCategoriesMessage != null) {
            TicketProUtility tpU = new TicketProUtility(getBaseActivity());
            categories = tpU.getCategories();
        }

        return categories;
    }

    private ArrayList<CardviewDataObject> createCategoryCards(Map<String, String> categories) {

        ArrayList<CardviewDataObject> list = new ArrayList<>();

        if (categories != null) {
            for (String categoryId : categories.keySet()) {

                String categoryName = categories.get(categoryId);
                int resId = getBaseActivity().getDrawableResource(
                        "ticketpro_" + categoryName.toLowerCase().replaceAll(" ", "_").replaceAll("&", "and"));
                list.add(new CardviewTicketProCategory(getBaseActivity(), resId, R.color.white, categoryName, categoryId, categoryId));
            }
        }

        return list;
    }

}
