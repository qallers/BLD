package za.co.blts.nfcbus;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import za.co.blts.bltandroidgui3.R;


class TicketListAdapter extends ArrayAdapter<Ticket> {
    private final String TAG = this.getClass().getSimpleName();

    private Context context;
    private FragmentTicketList fragmentTicketList;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    public TicketListAdapter(Context context, int layoutResourceId, List<Ticket> dataSet, FragmentTicketList fragment) {
        super(context, layoutResourceId, dataSet);
        this.context = context;
        this.fragmentTicketList = fragment;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final Ticket ticket = getItem(position);

        if (ticket != null) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.layout_nfc_ticket, parent, false);
            }

            String down = "", up = "";
            up = ((ActivityNfcBus) context).getUpRoute(ticket.getRoutes());
            down = ((ActivityNfcBus) context).getDownRoute(ticket.getRoutes());

            if (!down.isEmpty()) {
                ((TextView) convertView.findViewById(R.id.txtDown)).setText("Down: " + down.substring(0, down.length() - 2));
            } else {
                ((TextView) convertView.findViewById(R.id.txtDown)).setVisibility(View.GONE);
            }
            if (!up.isEmpty()) {
                ((TextView) convertView.findViewById(R.id.txtUp)).setText("Up: " + up.substring(0, up.length() - 2));
            } else {
                ((TextView) convertView.findViewById(R.id.txtUp)).setVisibility(View.GONE);
            }

            Log.w("NfcBus", "Down: " + down);
            Log.w("NfcBus", "Up: " + up);

            try {
                JSONObject rules = new JSONObject(ticket.getRules());
                Log.w("NfcBus", "no_of_days: " + rules.getString("no_of_days"));
                Log.w("NfcBus", "week_days: " + rules.getString("week_days"));
                Log.w("NfcBus", "trips_per_day: " + rules.getString("trips_per_day"));
                Log.w("NfcBus", "period: " + rules.getString("period"));
                Log.w("NfcBus", "validity_period: " + rules.getString("validity_period"));
                ((TextView) convertView.findViewById(R.id.txtWeekdays)).setText(rules.getString("week_days"));
                ((TextView) convertView.findViewById(R.id.txtPeriod)).setText(rules.getString("period"));
            } catch (Exception ignore) {
                ignore.printStackTrace();
            }


            String fare = "Fare: " + ticket.getFareProductId();

            ((TextView) convertView.findViewById(R.id.txtFare)).setText(fare.trim());
            ((TextView) convertView.findViewById(R.id.txtCompany)).setText(ticket.getCompany());
            ((TextView) convertView.findViewById(R.id.txtType)).setText("Type: " + ticket.getTicketType());

            boolean expired = true;
            try {
                Date expiry = sdf.parse(ticket.getEndDate());
                expired = expiry.before(new Date());
            } catch (Exception e) {
                e.printStackTrace();
            }
            String from = "From: " + (ticket.getStartDate().indexOf(" ") > 0 ? ticket.getStartDate().substring(0, ticket.getStartDate().indexOf(" ")) : ticket.getStartDate());
            String to = "To: " + (ticket.getEndDate().indexOf(" ") > 0 ? ticket.getEndDate().substring(0, ticket.getEndDate().indexOf(" ")) : ticket.getEndDate());

            ((TextView) convertView.findViewById(R.id.txtFrom)).setText(from);
            ((TextView) convertView.findViewById(R.id.txtTo)).setText(to);
            if (expired) {
                ((TextView) convertView.findViewById(R.id.txtTo)).setTextColor(getContext().getResources().getColor(R.color.errorColorBLT));
            }

            ImageButton btnRenew = convertView.findViewById(R.id.btnRenew);
            btnRenew.setTag(ticket);
            btnRenew.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Ticket t = (Ticket) v.getTag();
                    ((ActivityNfcBus) context).setCurrentTicket(t);
                    fragmentTicketList.setAuthFor(FragmentTicketList.AuthFor.Fare);
                    ((ActivityNfcBus) context).authForNfcBus(fragmentTicketList);
                }
            });

            ImageButton btnCancel = convertView.findViewById(R.id.btnCancel);
            btnCancel.setTag(ticket);
            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Ticket t = (Ticket) v.getTag();
                    ((ActivityNfcBus) context).setCurrentTicket(t);
                    fragmentTicketList.userConfirmCancelTicket();
                }
            });
            btnCancel.setVisibility(ticket.isCancelable() ? View.VISIBLE : View.INVISIBLE);

        }
        return convertView;
    }

}
