package za.co.blts.nfcbus;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.net.Socket;

import za.co.blt.interfaces.external.factories.NfcBusRequestFactory;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusCheckoutRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusConfirmCheckoutRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusCheckoutResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusConfirmCheckoutResponseMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.NeedsAEONResults;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidRadioButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;
import za.co.blts.nfc.NfcResult;
import za.co.blts.nfc.NfcResultable;
import za.co.blts.nfc.NfcTappable;

import static android.view.View.GONE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;


public class FragmentPurchaseTicket extends BaseFragment implements NeedsAEONResults, NfcResultable {
    private final String TAG = this.getClass().getSimpleName();

    private TextView txtFare, txtPeriod, txtDays, txtPrice;
    private AuthFor authFor = AuthFor.None;
    private NfcBusCheckoutResponseMessage checkoutResponseMessage;
    private boolean cardWriteSuccess = false;
    private final int MAX_ATTEMPTS = 2;
    private int writeAttempt = 0;
    private int paymentType = 1;

    enum AuthFor {
        None,
        Checkout,
        ConfirmCheckout
    }

    public FragmentPurchaseTicket() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((ActivityNfcBus) getActivity()).setResultable(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_purchase_ticket, container, false);

        BluDroidTextView departLabel = rootView.findViewById(R.id.departLabel);
        String departText = "";
        if (((ActivityNfcBus) getActivity()).getDepart() == null) {
            if (((ActivityNfcBus) getActivity()).getCurrentTicket() != null) {
                departText = ((ActivityNfcBus) getActivity()).getUpRoute(((ActivityNfcBus) getActivity()).getCurrentTicket().getRoutes());
                if (!departText.isEmpty()) {
                    departText = "UP: " + departText;
                }
            } else if (((ActivityNfcBus) getActivity()).getFare() != null) {
                departText = "Fare: " + ((ActivityNfcBus) getActivity()).getFare().getId();
            }
        } else {
            departText = "Departure: " + ((ActivityNfcBus) getActivity()).getDepart().getName();
        }
        if (departText.isEmpty()) {
            departLabel.setVisibility(GONE);
        } else {
            departLabel.setText(departText);
        }

        BluDroidTextView destLabel = rootView.findViewById(R.id.destLabel);
        String destText = "";
        if (((ActivityNfcBus) getActivity()).getDest() == null) {
            if (((ActivityNfcBus) getActivity()).getCurrentTicket() != null) {
                destText = ((ActivityNfcBus) getActivity()).getDownRoute(((ActivityNfcBus) getActivity()).getCurrentTicket().getRoutes());
                if (!destText.isEmpty()) {
                    destText = "DOWN: " + destText;
                }
            }
        } else {
            destText = "Destination: " + ((ActivityNfcBus) getActivity()).getDest().getName();
        }
        if (destText.isEmpty()) {
            destLabel.setVisibility(GONE);
        } else {
            destLabel.setText(destText);
        }

        txtFare = rootView.findViewById(R.id.txtFare);
        txtPeriod = rootView.findViewById(R.id.txtPeriod);
        txtDays = rootView.findViewById(R.id.txtDays);
        txtPrice = rootView.findViewById(R.id.txtPrice);
        BluDroidButton btnCancel = rootView.findViewById(R.id.btnCancel);
        BluDroidButton btnPay = rootView.findViewById(R.id.btnPay);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getBaseActivity().firebaseBundle = new Bundle();
                getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, TAG + " " + ((ActivityNfcBus) getActivity()).getCardUid());
                getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_purchase_cancel", getBaseActivity().firebaseBundle);

                ((ActivityNfcBus) getActivity()).gotoTicketList();
            }
        });

        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Pay clicked");
                authFor = AuthFor.Checkout;
                ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentPurchaseTicket.this);
            }
        });

        BluDroidRadioButton rbCash = rootView.findViewById(R.id.cashRadio);
        rbCash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paymentType = 1;
            }
        });
        rbCash.setChecked(true); // default to cash

        BluDroidRadioButton rbCredit = rootView.findViewById(R.id.creditRadio);
        rbCredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paymentType = 2;
            }
        });

        //----------------------------------------------------------------------------------------------
        BluDroidRadioButton rbDebit = rootView.findViewById(R.id.debitRadio);
        rbDebit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paymentType = 3;
            }
        });

        displayFare();
        return rootView;
    }

    private void displayFare() {
        txtFare.setText(((ActivityNfcBus) getActivity()).getFare().getName());
        txtPeriod.setText("Period: " + ((ActivityNfcBus) getActivity()).getFare().getPeriod());
        txtDays.setText("Days: " + ((ActivityNfcBus) getActivity()).getFare().getWeekdays());
        txtPrice.setText("Price: " + ((ActivityNfcBus) getActivity()).getFare().getPrice());
    }

    private void checkoutPurchase(String sessionId) {
        getBaseActivity().createProgress(R.string.getting_ticket);
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusCheckoutRequestMessage req = factory.checkout(sessionId,
                ((ActivityNfcBus) getActivity()).getCardUid(),
                ((ActivityNfcBus) getActivity()).getFare().getPassType(),
                getPreference(PREF_DEVICE_ID) + "_" + System.currentTimeMillis(),
                ((ActivityNfcBus) getActivity()).getFare().getId(),
                ((ActivityNfcBus) getActivity()).getFare().getPrice().replace(",", ""),
                ((ActivityNfcBus) getActivity()).getFare().getCompanyId(),
                ((ActivityNfcBus) getActivity()).getSvcWithoutBlank());
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    private void confirmCheckoutPurchase(String sessionId) {
        Log.w("NfcBus", "Checkout UP: " + ((ActivityNfcBus) getActivity()).getUpRoute(checkoutResponseMessage.getDetail().getTicket().getRoutes()));
        Log.w("NfcBus", "Checkout DOWN: " + ((ActivityNfcBus) getActivity()).getDownRoute(checkoutResponseMessage.getDetail().getTicket().getRoutes()));

        getBaseActivity().createProgress(R.string.confirming_transaction);
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusConfirmCheckoutRequestMessage req = factory.confirmCheckout(sessionId,
                checkoutResponseMessage.getDetail().getTransRef(),
                ((ActivityNfcBus) getActivity()).getCardUid(),
                cardWriteSuccess ? "confirmed" : "canceled",
                checkoutResponseMessage.getDetail().getTransaction().getTicketId(),
                checkoutResponseMessage.getDetail().getTransaction().getTransactionId(),
                checkoutResponseMessage.getDetail().getTransaction().getAmount().replace(",", ""),
                paymentType,
                checkoutResponseMessage.getDetail().getTicket().getCompanyId(),
                checkoutResponseMessage.getDetail().getSvcData(),
                ((ActivityNfcBus) getActivity()).getUpRoute(checkoutResponseMessage.getDetail().getTicket().getRoutes()),
                ((ActivityNfcBus) getActivity()).getDownRoute(checkoutResponseMessage.getDetail().getTicket().getRoutes()));
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    @Override
    public void results(Object object) {
        if (object instanceof NfcBusAuthenticationResponseMessage) {
            if (((NfcBusAuthenticationResponseMessage) object).getEvent().getEventCode().equals("0")) {
                ((ActivityNfcBus) getActivity()).setNfcBusAuthenticationResponseMessage((NfcBusAuthenticationResponseMessage) object);
                switch (authFor) {
                    case Checkout:
                        checkoutPurchase(((NfcBusAuthenticationResponseMessage) object).getSessionId());
                        break;

                    case ConfirmCheckout:
                        confirmCheckoutPurchase(((NfcBusAuthenticationResponseMessage) object).getSessionId());
                        break;

                    default:
                        break;
                }
            } else {
                getBaseActivity().returnToFavouritesScreen = true;
                getBaseActivity().createSystemErrorConfirmation(object, true);
            }
        } else if (object instanceof NfcBusCheckoutResponseMessage) {
            getBaseActivity().dismissProgress();
            getBaseActivity().closeAeonSocket(41);
            if (((NfcBusCheckoutResponseMessage) object).getEvent().getEventCode().equals("0")) {
                if (((NfcBusCheckoutResponseMessage) object).getDetail().getStatus().equals("1")) {
                    checkoutResponseMessage = (NfcBusCheckoutResponseMessage) object;
                    writeAttempt = 1;
                    promptForCard();
                } else {
                    getBaseActivity().returnToFavouritesScreen = false;
                    getBaseActivity().createSystemErrorConfirmation(((NfcBusCheckoutResponseMessage) object).getDetail().getMessage(), false);
                }
            } else {
                getBaseActivity().returnToFavouritesScreen = false;
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }
        } else if (object instanceof NfcBusConfirmCheckoutResponseMessage) {
            getBaseActivity().closeAeonSocket(42);
            if (((NfcBusConfirmCheckoutResponseMessage) object).getEvent().getEventCode().equals("0")) {
                getBaseActivity().saveAccountDetails(((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getAccounts());

                if (((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getStatus().equals("1")) {
                    getBaseActivity().recoveryCacheHandler.deleteRecoveryFromCache(checkoutResponseMessage.getDetail().getTransRef());

                    if (!((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getPrintLines().isEmpty()) {
                        getBaseActivity().printWithDynamic(((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getPrintLines(), getBaseActivity().getPrintBarcode());
                    }
                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)
                            && !((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getMerchantPrintLines().isEmpty()) {
                        getBaseActivity().print(((NfcBusConfirmCheckoutResponseMessage) object).getDetail().getMerchantPrintLines());
                    }

                    getBaseActivity().firebaseBundle = new Bundle();
                    getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, ((ActivityNfcBus) getActivity()).getCardUid());
                    getBaseActivity().mFirebaseAnalytics.logEvent(cardWriteSuccess ? "nfcbus_purchase_success" : "nfcbus_purchase_failed", getBaseActivity().firebaseBundle);

                    getBaseActivity().dismissProgress();
                    getBaseActivity().gotoMainScreen();
                } else {
                    confirmCheckoutError();
                }
            } else {
                confirmCheckoutError();
            }
        }

        if (object != null && !(object instanceof Socket)) {
            getBaseActivity().firebaseBundle = new Bundle();
            getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            getBaseActivity().mFirebaseAnalytics.logEvent("aeon_connection", getBaseActivity().firebaseBundle);
        }
    }

    private void confirmCheckoutError() {
        String result = "THE TICKET PURCHASE WAS " + (cardWriteSuccess ? "SUCCESSFUL" : "CANCELLED");
        String message = result + "\n\nHowever the transaction status could not be sent to the server, and will be retried on the next login.";
        getBaseActivity().createSystemLogoutErrorConfirmation(message, false);

        getBaseActivity().firebaseBundle = new Bundle();
        getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, result + " " + ((ActivityNfcBus) getActivity()).getCardUid());
        getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_confirmcheckout_error", getBaseActivity().firebaseBundle);
    }

    private void promptForCard() {
        Log.d(TAG, "prompt for card");
        String message = "Please place your SmartTap card with ID " + ((ActivityNfcBus) getActivity()).getCardUid();
        if (writeAttempt > 1) {
            message += "\n(Attempt " + writeAttempt + " of " + MAX_ATTEMPTS + ")";
        }
        message += "\n\nDO NOT REMOVE CARD TILL TRANSACTION COMPLETES";
        getBaseActivity().alert = new BluDroidAlertDialog(getContext());
        getBaseActivity().alert.setTitle("NFC");
        getBaseActivity().alert.setMessage(message);
        getBaseActivity().alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                getBaseActivity().alert.dismiss();
                ((ActivityNfcBus) getActivity()).getTappable().cancelCard();
                cancelPurchase();
            }
        });
        getBaseActivity().alert.show();
        ((ActivityNfcBus) getActivity()).getTappable().writeCard(NfcBusInstr.write(false, checkoutResponseMessage.getDetail().getSvcData(),
                ((ActivityNfcBus) getActivity()).getCard().getUid()));
    }

    private void cancelPurchase() {
        cardWriteSuccess = false;
        authFor = AuthFor.ConfirmCheckout;
        ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentPurchaseTicket.this);
    }

    @Override
    public void handleNfcResult(final NfcResult result) {
        BaseActivity.logger.info(result.toString());
        Log.i(TAG, "operation: " + result.getOperation());
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                getBaseActivity().alert.dismiss();

                if (result.getOperation() == NfcTappable.NfcOperation.WRITE) {
                    if (result.getStatus() == NfcTappable.NfcStatus.SUCCESS) {
                        ((ActivityNfcBus) getActivity()).setCard(result.getCard());
                        ((ActivityNfcBus) getActivity()).getTicketCacheHandler().cacheCancelTicket(checkoutResponseMessage.getDetail());
                        cardWriteSuccess = true;
                        authForConfirmCheckout();

                    } else {
                        cardWriteSuccess = false;
                        String message = "An error occurred writing card, please try again";
                        if (writeAttempt >= MAX_ATTEMPTS) {
                            message = "An error occurred writing card. Transaction will be cancelled.";
                        } else if (result.getStatus() == NfcTappable.NfcStatus.INVALID_CARD) {
                            message = "Incorrect card placed, please try again";
                        }

                        getBaseActivity().firebaseBundle = new Bundle();
                        getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, message);
                        getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_card_error", getBaseActivity().firebaseBundle);

                        getBaseActivity().alert = new BluDroidAlertDialog(getContext());
                        getBaseActivity().alert.setTitle("Error");
                        getBaseActivity().alert.setMessage(message);
                        getBaseActivity().alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                getBaseActivity().alert.dismiss();
                                if (writeAttempt < MAX_ATTEMPTS) {
                                    writeAttempt++;
                                    promptForCard();
                                } else {
                                    authForConfirmCheckout();
                                }
                            }
                        });
                        getBaseActivity().alert.show();
                    }
                }
            }
        });
    }

    private void authForConfirmCheckout() {
        NfcBusRecovery recovery = getBaseActivity().recoveryCacheHandler.createRecoveryCheckout(checkoutResponseMessage.getDetail().getTransRef(),
                ((ActivityNfcBus) getActivity()).getCardUid(),
                cardWriteSuccess ? "confirmed" : "canceled",
                checkoutResponseMessage.getDetail().getTransaction().getTicketId(),
                checkoutResponseMessage.getDetail().getTransaction().getTransactionId(),
                checkoutResponseMessage.getDetail().getTransaction().getAmount(),
                paymentType,
                checkoutResponseMessage.getDetail().getTicket().getCompanyId(),
                checkoutResponseMessage.getDetail().getSvcData(),
                ((ActivityNfcBus) getActivity()).getUpRoute(checkoutResponseMessage.getDetail().getTicket().getRoutes()),
                ((ActivityNfcBus) getActivity()).getDownRoute(checkoutResponseMessage.getDetail().getTicket().getRoutes()));
        getBaseActivity().recoveryCacheHandler.cacheRecovery(recovery);

        authFor = AuthFor.ConfirmCheckout;
        ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentPurchaseTicket.this);
    }
}