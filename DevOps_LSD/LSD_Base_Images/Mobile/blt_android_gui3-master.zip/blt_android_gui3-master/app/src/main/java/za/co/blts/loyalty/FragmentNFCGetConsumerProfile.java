package za.co.blts.loyalty;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

import sunmi.paylib.SunmiPayKernel;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfile;
import za.co.blt.consumer.loyalty.api.service.model.response.Error;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.BluDroidApplication;
import za.co.blts.bltandroidgui3.BluDroidVolley;
import za.co.blts.bltandroidgui3.FragmentFavourites;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidNfcCardEditText;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentNFCGetConsumerProfile extends BaseFragment implements BluDroidNFCCardAsyncResponse {

    private final String TAG = this.getClass().getSimpleName();
    private BluDroidVolley bluDroidVolley;
    private BluDroidNfcCardEditText card_number;
    private BluDroidCellphoneEditText cell_phone;
    private boolean isCardNumber = true;
    private Bundle fromFragment = null;
    private BluDroidAlertDialog alert = null;
    private String heading = "";


    //----------------------------------------------------------------------------------------------
    public FragmentNFCGetConsumerProfile() {
        // Required empty public constructor
    }

    //----------------------------------------------------------------------------------------------
    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_nfc_capture_screen, container, false);
        getBaseActivity().hideKeyboard();
        fromFragment = getArguments(); // edit, deactivate card, get customer favourites

        card_number = rootView.findViewById(R.id.nfcCardCode);
        card_number.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    // disable cell input field
                    disableEditText(cell_phone);
                    cell_phone.removeErrorMessage();

                    // enable card input field
                    enableEditText(card_number);

//                    if (getBaseActivity().isDebug()) {
//                        card_number.setText("3685785618");
//                    }
                    // set type to is card
                    isCardNumber = true;
                    // start listening for nfc reader
                }
                return false; // see what this means later
            }
        });
        cell_phone = rootView.findViewById(R.id.captureCellNumber);
        cell_phone.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    // disable card number input field
                    disableEditText(card_number);
                    card_number.removeErrorMessage();

                    // do we want to stop the nfc service? Hmmm

                    // enable cell input field
                    enableEditText(cell_phone);
                    //cell_phone.setText("0878294873");
                    // set type to is cell phone
                    isCardNumber = false;
                    if (mSunmiPayKernel != null) {
                        mSunmiPayKernel.unbindPayService(getBaseActivity());
                    }
                }
                return false; // see what this means later
            }
        });
        BluDroidButton send_cell_card_number = rootView.findViewById(R.id.confirm_nfc);
        send_cell_card_number.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // determine which identifier is being used, cell or card number
                if (isCardNumber) {
                    if (card_number.validate()) {
                        BaseActivity.cell_or_card_number = "filterbyloyaltycard?loyaltycard=" + card_number.getText().toString(); // we will set the value from nfc or cashier
                        doRequest();
                    }
                } else {
                    if (cell_phone.validate()) {
                        BaseActivity.cell_or_card_number = "filterbymobilenumber?mobilenumber=" + cell_phone.getText().toString().replace(" ", ""); // we will set the value from nfc or cashier
                        doRequest();
                    }
                }
            }
        });

        // enable card input field
        disableEditText(cell_phone);
        enableEditText(card_number);

        return rootView;
    }


    //----------------------------------------------------------------------------------------------
    private void disableEditText(EditText view) {
        view.clearFocus();
        view.setText("");
        ((BluDroidEditText) view).removeErrorMessage();
        //view.setEnabled(false);
//    view.setBackgroundColor(getResources().getColor(R.color.lightGrey));
    }

    //----------------------------------------------------------------------------------------------
    private void enableEditText(EditText view) {
        view.requestFocus();
        view.setText("");
//    view.setEnabled(true);
//    view.setBackgroundColor(getResources().getColor(R.color.white));
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCEditConsumerProfile")) {
            heading = getString(R.string.nfc_edit);
        } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateCardScreen")) {
            heading = getString(R.string.replace_card);
        } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCNFCConsumerFavourites")) {
            heading = "Consumer Favourites";
        } else if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCDeactivateProfileScreen")) {
            heading = getString(R.string.nfc_deactivate_profile);
        }

        setTitle(heading);
        bluDroidVolley = BluDroidVolley.getInstance(getBaseActivity());
        //startNFCListener(FragmentNFCGetConsumerProfile.this);
    }

    //----------------------------------------------------------------------------------------------
    private void setTitle(String title) {
        getActivity().setTitle(title);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean onBackPressed() {
        getBaseActivity().gotoFragment(new FragmentFavourites(), "FragmentFavourites");
        return true;
    }

    //----------------------------------------------------------------------------------------------
    private void doRequest() {
        JsonObjectRequest getConsumerProfile = new JsonObjectRequest(Request.Method.GET, BaseActivity.loyaltyServerBaseUrl + BaseActivity.cell_or_card_number, null, // URL
                createReqSuccessListener(),
                createReqErrorListener());

        getBaseActivity().createProgress(R.string.nfc_get_customer_profile);
        bluDroidVolley.addRequestApiGateway(getConsumerProfile); // make sure that this is not null
    }

    //----------------------------------------------------------------------------------------------
    private Response.Listener<JSONObject> createReqSuccessListener() {
        return new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    getBaseActivity().dismissProgress();
                    VolleyLog.v("Response:%n %s", response.toString(4));
                    Log.d(TAG, response.toString());
                    BaseActivity.consumerProfile = new Gson().fromJson(response.toString(), ConsumerProfile.class);
                    // we will put the profile object in the bundle as well, for now we will get this from BaseActivity.consumerProfile
                    //fromFragment.putSerializable("consumerProfile", (Serializable) BaseActivity.consumerProfile);
                    if (BaseActivity.consumerProfile != null && Integer.valueOf(BaseActivity.consumerProfile.getProfileId()) > 0) {
                        BaseActivity.logger.info(" Get subscriber successful - " + BaseActivity.consumerProfile);
                        handleResponseMessage(true, "Get subscriber successful");
                    } else { // failed
                        BaseActivity.logger.error(" Something went wrong. Please try again - " + BaseActivity.consumerProfile);
                        handleResponseMessage(false, "Something went wrong. Please try again");
                    }

                } catch (JSONException e) {
                    BaseActivity.logger.error(" " + e);
                    e.printStackTrace();
                }
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    private Response.ErrorListener createReqErrorListener() {
        return new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.e("error: " + error);
                String message;
                if (getBaseActivity() != null) {
                    getBaseActivity().dismissProgress();
                    VolleyLog.e("error.getMessage(): " + error.getMessage());
                    VolleyLog.e("error.networkResponse: " + error.networkResponse);
                    String errorMessage;
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            if (error.networkResponse.statusCode == 404) {
                                message = "Subscriber not found";
                            } else {
                                errorMessage = new String(error.networkResponse.data, StandardCharsets.UTF_8); // for UTF-8 encoding
                                VolleyLog.e("errorMessage: " + errorMessage);
                                Error error1 = new Gson().fromJson(errorMessage, Error.class);
                                message = error1.getMessage();
                            }
                        } catch (Exception e) {
                            BaseActivity.logger.error(" " + e);
                            e.printStackTrace();
                            message = "An unknown error occurred";
                        }
                    } else {
                        message = "Could not connect";
                    }

                    BaseActivity.logger.error(" " + message);
                    handleResponseMessage(false, message); // propagate the server error message
                }
            }
        };
    }

    //----------------------------------------------------------------------------------------------
    private void handleResponseMessage(final boolean responseIsSuccessful, String message) {
        String messageTitle;
        if (!responseIsSuccessful) {
            messageTitle = "Failed";
            alert = getBaseActivity().createAlertDialog(messageTitle, message);
            alert.setPositiveOption(getString(R.string.nfc_confirm_replace_card), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    alert.dismiss(); // retry
                }
            });
        } else {
            // we will get the favourites from the fav screen
            // if we make than call in this screen then we might get the updated list of products if the consumer
            // wishes to purchase a voucher. So in that case, we decided to rely on FragmentNFCConsumerFavourites for
            // makig that call for us. Each time we get in the FragmentNFCConsumerFavourites screen we will get the list
            // of user favs
            if (fromFragment.getString("fromFragment").equalsIgnoreCase("NFCNFCConsumerFavourites")) {
                getBaseActivity().gotoMainScreen();
            } else {
                getBaseActivity().gotoNFCEditProfileScreen(fromFragment);
            }
        }

    }

    @Override
    public void onError(String msg) {
        BaseActivity.logger.error(" " + msg);
    }

    @Override
    public void onReady() {

    }

    @Override
    public void onCardNumberRead(String cardNumber) {
        disableEditText(cell_phone);
        enableEditText(card_number);
        isCardNumber = true;

        card_number.setText(cardNumber); // put card number on the this


    }

    @Override
    public void onPause() {
        Log.d(TAG, "onPause FragmentNFCGetConsumerProfile");
        super.onPause();
        stopNFCListener();
        if (mSunmiPayKernel != null) {
            mSunmiPayKernel.destroyPaySDK();
        }
        Log.d(TAG, "onPause: ");
    }

    @Override
    public void onResume() {
        super.onResume();
        if (Build.MODEL.startsWith("P1")) {
            mSunmiPayKernel = SunmiPayKernel.getInstance();
            mSunmiPayKernel.connectPayService(getContext(), mConnCallback);
        } else {
            startNFCListener(FragmentNFCGetConsumerProfile.this);
        }
        Log.d(TAG, "onResume: ");
    }

    private SunmiPayKernel.ConnCallback mConnCallback = new SunmiPayKernel.ConnCallback() {
        @Override
        public void onServiceConnected() {
            try {
                //Toast.makeText(ActivityMain.this, "onServiceConnected()", Toast.LENGTH_SHORT).show();
                BluDroidApplication.mReadCardOpt = mSunmiPayKernel.mReadCardOpt;
                startNFCListener(FragmentNFCGetConsumerProfile.this);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected() {
        }
    };
    //----------------------------------------------------------------------------------------------

} 
