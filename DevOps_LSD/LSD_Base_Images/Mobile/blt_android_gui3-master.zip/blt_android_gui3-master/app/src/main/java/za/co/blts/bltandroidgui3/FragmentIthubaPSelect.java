package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidNumericEditText;


/**
 * Created by WarrenM1 on 2017/07/11.
 */

public class FragmentIthubaPSelect extends FragmentIthubaBase implements View.OnFocusChangeListener {

    private final String TAG = this.getClass().getSimpleName();
    private String name;
    private BluDroidNumericEditText numBoards = null;
    private BluDroidNumericEditText numDraws = null;


    public FragmentIthubaPSelect() {
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.fragment_ithuba_player_select, container, false);
        Bundle bundle = getArguments();
        getBaseActivity().resetTimer();


        if (bundle.getString("name") != null) {
            this.name = bundle.getString("name");
        } else {
            this.name = getNamePreviousScreen();
        }

        ImageView pageLogo = rootView.findViewById(R.id.ithuba_lotto_img);

        if (name.contains("lotto")) {
            pageLogo.setImageDrawable(getResources().getDrawable(R.drawable.ic_lotto));
        } else if (name.contains("powerball")) {
            pageLogo.setImageDrawable(getResources().getDrawable(R.drawable.ic_powerball));
        }

        numBoards = rootView.findViewById(R.id.qpNumBoardsBox);
        if (getBoardsPreviousScreen().isEmpty()) {
            numBoards.setText("1");
        } else {
            numBoards.setText(getBoardsPreviousScreen());
        }
        numBoards.setTextSize(getBaseActivity().getSkinResources().getTextSize());
        numBoards.setRawInputType(InputType.TYPE_CLASS_NUMBER);
        numBoards.setFilters(new InputFilter[]{new InputFilterMinMax("1", "20")});
        numBoards.setOnFocusChangeListener(this);

        numDraws = rootView.findViewById(R.id.qpNumDrawsBox);
        if (getDrawsPreviousScreen().isEmpty()) {
            numDraws.setText("1");
        } else {
            numDraws.setText(getDrawsPreviousScreen());
        }
        numDraws.setText("1");
        numDraws.setTextSize(getBaseActivity().getSkinResources().getTextSize());
        numDraws.setRawInputType(InputType.TYPE_CLASS_NUMBER);
        numDraws.setFilters(new InputFilter[]{new InputFilterMinMax("1", "10")});
        numDraws.setOnFocusChangeListener(this);

        BluDroidButton selectBtn = rootView.findViewById(R.id.qpSelectNumbers);
        //selectBtn.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT, 1));\
        selectBtn.setTextSize(getBaseActivity().getSkinResources().getTextSize());
        selectBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BaseActivity.logger.info(((BluDroidButton) view).getText());
                if (numBoards.getText().toString().isEmpty()) {
                    numBoards.setText("1");
                }
                if (numDraws.getText().toString().isEmpty()) {
                    numDraws.setText("1");
                }
                goToNextScreen(name, numBoards, numDraws);
            }
        });

        BluDroidButton cancelBtn = rootView.findViewById(R.id.qpCancel);
        cancelBtn.setTextSize(getBaseActivity().getSkinResources().getTextSize());
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BaseActivity.logger.info(((BluDroidButton) view).getText());
                getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentIthubaMenu(), "FragmentIthubaMenu").commit();
            }
        });

        return rootView;
    }

    private void goToNextScreen(String name, BluDroidNumericEditText boards, BluDroidNumericEditText draws) {
        String numberOfBoards = boards.getText().toString();
        String numberOfDraws = draws.getText().toString();

        getBaseActivity().cancelTimer();

        FragmentManager fm = getBaseActivity().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        Bundle bundle = new Bundle();
        bundle.putString("thisScreen", this.getClass().getName());
        bundle.putString("name", name);
        bundle.putString("numBoardsText", numberOfBoards);
        bundle.putString("numDrawsText", numberOfDraws);

        Fragment fragment = new FragmentIthubaNumberSelection();
        fragment.setArguments(bundle);

        Log.d(TAG, "NAME: " + name);
        Log.d(TAG, "BOARDS: " + numberOfBoards);
        Log.d(TAG, "DRAWS: " + numberOfDraws);

        ft.replace(R.id.content_frame, fragment);
        ft.commit();
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus) {
            switch (v.getId()) {
                case R.id.qpNumBoardsBox:
                    numBoards.setText("");
                    break;
                case R.id.qpNumDrawsBox:
                    numDraws.setText("");
                    break;
            }
        } else {
            switch (v.getId()) {
                case R.id.qpNumBoardsBox:
                    if (numBoards.getText().toString().isEmpty()) {
                        numBoards.setText("1");
                    }
                    break;
                case R.id.qpNumDrawsBox:
                    if (numDraws.getText().toString().isEmpty()) {
                        numDraws.setText("1");
                    }
                    break;
            }
        }
    }

    @Override
    public boolean onBackPressed() {
        getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentIthubaMenu(), "FragmentIthubaMenu").commit();

        return true;
    }
}
