package za.co.blts.bltandroidgui3;

class USBCommsException extends Exception {

    public USBCommsException(String message) {
        super(message);
    }

}
