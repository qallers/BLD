package za.co.blts.bltandroidgui3.longhaul.cancellations;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.squareup.picasso.Picasso;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.List;

import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseItemMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BluDroidUtils;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;


public class BluDroidTicketCancellationsAdapter extends ArrayAdapter<CancelTicket> {

    private WeakReference<BaseActivity> baseActivityWeakReference;

    public BluDroidTicketCancellationsAdapter(BaseActivity context, int resource,
                                              @NonNull List<CancelTicket> objects) {
        super(context, resource, objects);
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            final CancelTicket ticket = getItem(position);
            final BluDroidTicketCancellationsAdapter.ViewHolder viewHolder;

            if (convertView == null) {
                // inflate the layout
                convertView = baseActivity.getLayoutInflater().inflate(R.layout.cancel_bus_ticket_layout_item, parent, false);
                // well set up the ViewHolder
                viewHolder = new BluDroidTicketCancellationsAdapter.ViewHolder();
                viewHolder.bus_icon_image_view = convertView.findViewById(R.id.bus_icon_image_view);
                viewHolder.departure = convertView.findViewById(R.id.departure);
                viewHolder.destination = convertView.findViewById(R.id.destination);
                viewHolder.transaction_date = convertView.findViewById(R.id.transaction_date);
                viewHolder.carrier_name = convertView.findViewById(R.id.carrier_name);

                // store the holder with the view.
                convertView.setTag(viewHolder);
            } else {
                // we've just avoided calling findViewById() on resource everytime
                // just use the viewHolder
                viewHolder = (BluDroidTicketCancellationsAdapter.ViewHolder) convertView.getTag();
            }

            if (ticket != null) { // the object at current position

                viewHolder.carrier_name.setText(ticket.getCarrierName());


                viewHolder.imageURL = baseActivity.carmaResponseCarrierListMessage.getData().getMediaUrl() + "/" + ticket.getCarrierName() + ".png";
                viewHolder.bus_icon_image_view.setTag(viewHolder.imageURL);
                if (viewHolder.bus_icon_image_view != null) {
                    Picasso picasso = Picasso.get();
                    picasso.setIndicatorsEnabled(baseActivity.isDebug());
                    picasso
                            .load(viewHolder.imageURL)
                            .placeholder(R.drawable.longhaul)
                            .error(R.drawable.longhaul)
                            .into(viewHolder.bus_icon_image_view);
                }

                SimpleDateFormat format1 = new SimpleDateFormat("dd/MM/yyyy hh:mm");
                viewHolder.transaction_date.setText(format1.format(ticket.getTransactionDate()));
                viewHolder.departure.setText(ticket.getDeparture());
                viewHolder.destination.setText(ticket.getDestination());
            }
        }
        // Return the completed view to render on screen
        return convertView;
    }

    //----------------------------------------------------------------------------------------------
    static class ViewHolder {
        ImageView bus_icon_image_view;
        TextView transaction_date;
        TextView departure;
        TextView destination;
        BluDroidTextView carrier_name;
        String imageURL;
    }


}
