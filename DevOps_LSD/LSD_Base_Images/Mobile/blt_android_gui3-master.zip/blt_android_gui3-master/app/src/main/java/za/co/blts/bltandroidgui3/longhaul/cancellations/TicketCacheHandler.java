package za.co.blts.bltandroidgui3.longhaul.cancellations;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import za.co.blt.interfaces.external.messages.carma.response.CarmaResponseReserveSeatsMessage;

public class TicketCacheHandler {
    private final String TAG = this.getClass().getSimpleName();
    private final long TICKET_CANCEL_EXPIRY = 30 * 60 * 1000; //30 minutes

    private File ticketCancelCacheDir;

    public TicketCacheHandler(File ticketCancelCacheDir) {
        this.ticketCancelCacheDir = ticketCancelCacheDir;
    }

    public CancelTicket getTicketByRef(String refNumber) {
        String filename = refNumber + ".txt";
        File cache = new File(ticketCancelCacheDir.getPath() + "/" + filename);
        if (cache.exists()) {
            CancelTicket ticket = readCancelTicketFromFile(cache);
            Log.v(TAG, "read from cache: " + ticket.toString());
            return ticket;
        }
        return null;
    }

    public void deleteTicketByRef(String refNumber) {
        String filename = refNumber + ".txt";
        File cache = new File(ticketCancelCacheDir.getPath() + "/" + filename);
        if (cache.exists()) {
            Log.v(TAG, "removed from cache: " + filename);
            cache.delete();
        }
    }

    public void removeExpiredCaches() {
        File[] files = ticketCancelCacheDir.listFiles();
        for (File f : files) {
            if (isExpired(f)) {
                Log.d(TAG, "deleting expired file: " + f.getAbsolutePath());
                f.delete();
            }
        }
    }

    public List<CancelTicket> getCachedTickets() {
        List<CancelTicket> cancelTicketList = new ArrayList<>();
        File[] files = ticketCancelCacheDir.listFiles();
        for (File f : files) {
            CancelTicket ticket = readCancelTicketFromFile(f);
            if (ticket != null) {
                Log.v(TAG, "read from cache: " + ticket.toString());
                cancelTicketList.add(ticket);
            }
        }

        Collections.sort(cancelTicketList);
        return cancelTicketList;
    }

    private CancelTicket readCancelTicketFromFile(File f) {
        try {
            CancelTicket ticket = null;
            Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").serializeNulls().create();

            BufferedReader bufferedReader = new BufferedReader(new FileReader(f));
            String line;
            if ((line = bufferedReader.readLine()) != null) {
                ticket = gson.fromJson(line, CancelTicket.class);
            }
            bufferedReader.close();

            return ticket;
        } catch (Exception e) {
            return null;
        }
    }

    private CancelTicket createCancelTicket(CarmaResponseReserveSeatsMessage
                                                    carmaResponseReserveSeatsMessage, String carrierCode) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            CancelTicket ticket = new CancelTicket();
            ticket.setTransactionDate(sdf.format(new Date()));
            ticket.setCarrier(carrierCode);
            ticket.setCarrierName(carmaResponseReserveSeatsMessage.getData().getTickets().get(0).getCarrierDescription());
            ticket.setTransRef(carmaResponseReserveSeatsMessage.getData().getTransRef());
            ticket.setQty(carmaResponseReserveSeatsMessage.getData().getTickets().size());
            ticket.setDeparture(carmaResponseReserveSeatsMessage.getData().getTickets().get(0).getBoardCity());
            ticket.setDestination(carmaResponseReserveSeatsMessage.getData().getTickets().get(0).getDestCity());
            ticket.setTravelTime(carmaResponseReserveSeatsMessage.getData().getTickets().get(0).getBoardTime());
            return ticket;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void cacheCancelTicket(CarmaResponseReserveSeatsMessage
                                          carmaResponseReserveSeatsMessage, String carrierCode) {
        CancelTicket ticket = createCancelTicket(carmaResponseReserveSeatsMessage, carrierCode);
        if (ticket != null) {
            Log.v(TAG, "caching " + ticket.toString());
            try {
                String filename = carmaResponseReserveSeatsMessage.getData().getTransRef() + ".txt";
                File cache = new File(ticketCancelCacheDir.getPath() + "/" + filename);
                BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(cache));
                bufferedWriter.write(ticket.toString());
                bufferedWriter.flush();
                bufferedWriter.close();
                Log.v(TAG, "caching successful");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isExpired(File file) {
        return System.currentTimeMillis() - file.lastModified() > TICKET_CANCEL_EXPIRY;
    }


}
