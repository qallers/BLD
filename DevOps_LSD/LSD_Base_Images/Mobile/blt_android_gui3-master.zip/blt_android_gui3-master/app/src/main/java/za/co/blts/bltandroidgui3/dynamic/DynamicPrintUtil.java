package za.co.blts.bltandroidgui3.dynamic;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;

import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blts.bltandroidgui3.ActivityLanding;
import za.co.blts.bltandroidgui3.BaseActivity;

public class DynamicPrintUtil {
    private final static String TAG = DynamicPrintUtil.class.getSimpleName();
    private static File printLogoCache;
    private WeakReference<BaseActivity> baseActivityWeakReference;
    private int jobIndex;
    private String jobId;

    public DynamicPrintUtil(BaseActivity context) {
        baseActivityWeakReference = new WeakReference<>(context);
        printLogoCache = context.printLogoCacheDir;
    }

    public Bitmap getLogoForPrint(String id) {
        Bitmap logo = null;

        try {
            final File logoFile = new File(printLogoCache, id + ".gif");

            if (logoFile.exists()) {
                Log.d(TAG, "existing logo " + id + ".gif");
                logo = BitmapFactory.decodeFile(logoFile.getPath());
            }
        } catch (Exception e) {
            logo = null;
            e.printStackTrace();
        }
        return logo;
    }


    public void updatePrintImages() {
        final BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {

            String bannerStr = baseActivity.getCachedDynamicPrint();
            Log.d(TAG, "print cache: " + bannerStr);

            String[] files = printLogoCache.list();
            List<String> printImageFiles = new ArrayList<>();
            for (String s : files) {
                if (!s.endsWith(".txt")) {
                    printImageFiles.add(s);
                }
            }

            for (String s : printImageFiles) {
                Log.d(TAG, "image file: " + s);
            }

            try {
                JSONArray cache = new JSONArray(bannerStr);
                for (int j = 0; j < cache.length(); j++) {
                    JSONObject obj = cache.getJSONObject(j);
                    Log.d(TAG, "checking for images in printjob: " + obj.toString());
                    JSONArray print = obj.getJSONArray("print");
                    for (int i = 0; i < print.length(); i++) {
                        JSONObject element = print.getJSONObject(i);

                        String type = element.getString("type");
                        if (type.equals("image")) {
                            Log.d(TAG, "downloading image for element: " + element.toString());
                            String id = element.getString("id");
                            String url = element.getString("url");
                            String fileName = downloadPrintImage(id, url);
                            printImageFiles.remove(fileName);
                        }
                    }
                }
            } catch (JSONException je) {
                je.printStackTrace();
            }

            for (String s : printImageFiles) {
                Log.d(TAG, "deleting image file: " + s);
                File file = new File(printLogoCache, s);
                file.delete();
            }
//            Toast.makeText(baseActivity, "Print images updated", Toast.LENGTH_SHORT).show();
            if (baseActivity instanceof ActivityLanding) {
                ((ActivityLanding) baseActivity).startBannerAnimation();
            }
        }
    }

    public String downloadPrintImage(String id, String url) {

        try {
            final File logoFile = new File(printLogoCache, id + ".gif");
            Bitmap logo;
            if (!logoFile.exists()) {

                Log.d(TAG, "new logo, creating " + id + ".gif");

                GetLogoAsync getLogoAsync = new GetLogoAsync();
                getLogoAsync.execute(url);
                logo = getLogoAsync.get();

                Log.d(TAG, "downloaded width=" + logo.getWidth() + " height=" + logo.getHeight());
                int w = logo.getWidth();
                int h = logo.getHeight();
                logo = Bitmap.createScaledBitmap(logo, 384, (int) (h * (384.0 / w)), false);
                // save the downloaded Bitmap
                FileOutputStream fos = new FileOutputStream(logoFile.getPath());
                logo.compress(Bitmap.CompressFormat.PNG, 100, fos);
                Log.d(TAG, "saved image, width=" + logo.getWidth() + " height=" + logo.getHeight());
                fos.flush();
                fos.close();
                logo = BitmapFactory.decodeFile(logoFile.getPath());
                if (logo.getByteCount() > 1024 * 1024) {
                    Log.e(TAG, "logo larger than 1MB: " + logo.getByteCount());
                    logoFile.delete();
                    return "";
                }
            } else {
                Log.d(TAG, "existing logo " + id + ".gif");
            }
            return id + ".gif";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private static Bitmap getLogoFromUrl(String urlStr) {
        try {
            Log.d(TAG, "downloading logo: " + urlStr);
            URL url = new URL(urlStr);
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            connection.setSSLSocketFactory(new TLSSocketFactory());
            connection.setDoInput(true);
            connection.setConnectTimeout(3000);
            connection.setReadTimeout(5000);
            connection.connect();
            InputStream input = connection.getInputStream();
            return BitmapFactory.decodeStream(input);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static class GetLogoAsync extends AsyncTask<String, Void, Bitmap> {
        private Bitmap results;

        @Override
        protected Bitmap doInBackground(String... params) {
            return getLogoFromUrl(params[0]);
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            //  return the bitmap by doInBackground and store in result
            results = bitmap;
        }
    }

    public JSONObject getDynamicPrint() {
        try {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                String cached = baseActivity.getCachedDynamicPrint();
//                String cached = baseActivity.loadJSONFromAsset("dynamic2.json");
                if (cached != null) {
                    JSONArray array = new JSONArray(cached);
                    JSONObject selected = selectJobToPrint(baseActivity, array);
                    if (selected == null && array.length() > 0) {
                        //there are no more valid prints, therefor clear cache so we request more
                        baseActivity.removeDynamicPrintCache();
                    }
                    return selected;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private JSONObject selectJobToPrint(BaseActivity baseActivity, JSONArray array) {
        if (baseActivity != null && array != null) {
            try {
                DynamicPrintInfo info = new DynamicPrintInfo(baseActivity);
                int lastIndex = info.getIndex();
                for (int i = lastIndex + 1; i >= 0 && i < array.length(); i++) {
                    JSONObject obj = array.getJSONObject(i);
                    if (printIsValid(obj)) {
                        jobIndex = i;
                        jobId = obj.getString("id");
                        return obj;
                    }
                }
                info.updateIndex(baseActivity, -1);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject obj = array.getJSONObject(i);
                    if (printIsValid(obj)) {
                        jobIndex = i;
                        jobId = obj.getString("id");
                        return obj;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        jobIndex = -1;
        jobId = null;
        return null;
    }

    private boolean printIsValid(JSONObject obj) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            DynamicPrintInfo info = new DynamicPrintInfo(baseActivity);
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                SimpleDateFormat sdfEnd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                String id = obj.getString("id");
                Date start = sdf.parse(obj.getString("start"));
                //add 23:59:59 ro end date specified, so that this end date is inclusive
                String endDate = obj.getString("end") + " 23:59:59";
                Date end = sdfEnd.parse(endDate);
                int max = Integer.parseInt(obj.getString("max"));
                Date now = new Date();
                int count = info.getCount(id);
                if (count < max && now.before(end) && now.after(start)) {
                    Log.i(TAG, "Valid: " + obj.toString());
                    return true;
                }
            } catch (Exception e) {
            }
            Log.w(TAG, "Invalid: " + obj.toString());
        }
        return false;
    }

    public ArrayList<CommonResponseLineMessage> removeLastEmptyLines(ArrayList<CommonResponseLineMessage> lines) {

        ArrayList<CommonResponseLineMessage> newLines = new ArrayList<>(lines);
        for (int i = newLines.size() - 1; i >= 0; i--) {
            if (newLines.get(i).getText() == null) {
                newLines.remove(i);
            } else {
                break;
            }
        }
        Log.d(TAG, "removeLastEmptyLines in=" + lines.size() + " out=" + newLines.size());
        return newLines;
    }

    public void updateDynamicInfo() {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            DynamicPrintInfo info = new DynamicPrintInfo(baseActivity);
            info.updateIndex(baseActivity, jobIndex);
            info.updateCount(baseActivity, jobId);
        }
    }
}
