package za.co.blts.nfcbus;

import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupFaresResponseFareMessage;

public class Fare extends NfcBusLookupFaresResponseFareMessage implements Comparable<Fare> {

    private boolean selected;

    public Fare() {
    }

    public Fare(NfcBusLookupFaresResponseFareMessage fare) {
        setPeriod(fare.getPeriod());
        setRoutes(fare.getRoutes());
        setCode(fare.getCode());
        setId(fare.getId());
        setCompanyId(fare.getCompanyId());
        setWeekdays(fare.getWeekdays());
        setCreated(fare.getCreated());
        setAvailableTo(fare.getAvailableTo());
        setAvailableFrom(fare.getAvailableFrom());
        setNumTransfers(fare.getNumTransfers());
        setPassValue(fare.getPassValue());
        setTripsPerDay(fare.getTripsPerDay());
        setPassType(fare.getPassType());
        setPrice(fare.getPrice());
        setName(fare.getName());
        setShortName(fare.getShortName());
        setDesc(fare.getDesc());
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    @Override
    public int compareTo(Fare o) {
        try {
            //remove comma separator and attempt to convert to double, then compare
            Double thisPrice = Double.parseDouble(getPrice().replace(",", ""));
            Double thatPrice = Double.parseDouble(o.getPrice().replace(",", ""));
            return thisPrice.compareTo(thatPrice);
        } catch (Exception e) {
            //compare as string
            return getPrice().replace(",", "").compareTo(o.getPrice().replace(",", ""));
        }
    }
}
