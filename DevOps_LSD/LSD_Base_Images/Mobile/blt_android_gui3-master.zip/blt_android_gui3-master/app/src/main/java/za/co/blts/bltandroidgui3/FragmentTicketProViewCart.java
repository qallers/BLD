package za.co.blts.bltandroidgui3;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.ticketpro.response.TicketProResponseSeatMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTicketProViewCart extends TicketProRecycler implements View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();

    public static BluDroidTextView txtAmountDue;
    public static BluDroidTextView txtNumTickets;

    private ArrayList<TicketProResponseSeatMessage> reservedSeats;

    public FragmentTicketProViewCart() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment

        View rootView = inflater.inflate(R.layout.fragment_ticket_pro_view_cart, container, false);

        getBaseActivity().ticketProTotal = 0;

        BluDroidButton btnNext = rootView.findViewById(R.id.next);
        BluDroidButton btnBack = rootView.findViewById(R.id.back);
        txtAmountDue = rootView.findViewById(R.id.amountDue);
        txtNumTickets = rootView.findViewById(R.id.numTickets);


        btnNext.setOnClickListener(this);
        btnBack.setOnClickListener(this);


        //  BluDroidHeading txtEventName;
        //  TextView txtVenue, txtDate, txtTime;
        ListView listView = rootView.findViewById(R.id.priceList);

        reservedSeats = new ArrayList<>();
        for (int i = 0; i < getBaseActivity().ticketProResponseReservedSeatsMessage.getData().getSeats().size(); i++) {

            getBaseActivity().ticketProTotal += Double.parseDouble(getBaseActivity().ticketProResponseReservedSeatsMessage.getData().getSeats().get(i).getPrice());
            reservedSeats.add(getBaseActivity().ticketProResponseReservedSeatsMessage.getData().getSeats().get(i));
        }

        BluDroidTicketProReservedSeatsListAdapter ticketProReservedSeatListAdapter = new BluDroidTicketProReservedSeatsListAdapter(getBaseActivity(), R.layout.ticketpro_price_row_item, reservedSeats);
        listView.setAdapter(ticketProReservedSeatListAdapter);

        String disp = "R" + getBaseActivity().df2.format(getBaseActivity().ticketProTotal);
        txtAmountDue.setText(disp);
        txtNumTickets.setText(String.valueOf(getBaseActivity().ticketProResponseReservedSeatsMessage.getData().getSeats().size()));

        return rootView;
    }

    @Override
    public void onClick(View v) {
        BaseActivity.logger.info(((BluDroidButton) v).getText());
        switch (v.getId()) {
            case R.id.next:
                if (reservedSeats.size() > 0) {
                    getBaseActivity().gotoFragment(new FragmentTicketProPayment(), "FragmentTicketProPayment");
                } else {
                    getBaseActivity().createAlertDialog("TicketPro", "Please add tickets to cart before you can continue");
                }
                break;
            case R.id.back:
                reservedSeats = new ArrayList<>();
                getBaseActivity().ticketProTotal = 0;
                getBaseActivity().gotoFragment(new FragmentTicketProCategories(), "FragmentTicketProCategories");
                break;

            default:
                break;
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

//        getBaseActivity().toolbar.setNavigationDrawable();
//        getBaseActivity().toolbar.setNavigationOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                getBaseActivity().gotoMenuFragment();
//            }
//        });
    }

    @Override
    public boolean onBackPressed() {

        reservedSeats = new ArrayList<>();
        getBaseActivity().ticketProTotal = 0;
        getBaseActivity().gotoFragment(new FragmentTicketProPriceCategory(), "FragmentTicketProPriceCategory");

        return true;
    }
}
