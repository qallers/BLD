package za.co.blts.bltandroidgui3;

/**
 * Created by warrenm on 2017/02/15.
 */

public enum BluDroidMenuItems {

    MENU_FAVOURITES("Favourites"),
    MENU_AIRTIME("Airtime"),
    MENU_DATA("Data"),
    MENU_ELECTRICITY("Electricity"),
    MENU_TRANSACT("Transact"),
    MENU_VOUCHERS("Vouchers"),
    MENU_TICKETS("Tickets"),
    MENU_RICA("Rica"),
    MENU_SEARCH("Search");

    private final String name;

    BluDroidMenuItems(final String s) {
        name = s;
    }

    public String toString() {
        return this.name;
    }
}
