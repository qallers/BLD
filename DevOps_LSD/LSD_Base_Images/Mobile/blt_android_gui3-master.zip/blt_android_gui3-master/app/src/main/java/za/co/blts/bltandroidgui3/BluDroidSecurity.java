package za.co.blts.bltandroidgui3;

import android.annotation.SuppressLint;
import android.os.Build;
import android.util.Base64;
import android.util.Log;

import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

//
// http://www.cuelogic.com/blog/using-cipher-to-implement-cryptography-in-android/
//

/*
 * minimal security for encryption
 */
class BluDroidSecurity {

    private final String TAG = this.getClass().getSimpleName();

    private WeakReference<BaseActivity> baseActivityWeakReference;
    private Cipher cipher = null;
    private IvParameterSpec ivSpec = null;
    private SecretKeySpec keySpec = null;


    public BluDroidSecurity(BaseActivity baseScreen) {
        this.baseActivityWeakReference = new WeakReference<>(baseScreen);
    }

    public byte[] getKey() {
        @SuppressLint("HardwareIds") StringBuilder sb = new StringBuilder(Build.FINGERPRINT + Build.SERIAL + Build.MODEL);
        try {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null && BaseActivity.loginResponseMessage != null) {
                sb.append(BaseActivity.loginResponseMessage.getData().getUserPin());
                sb.append(BaseActivity.loginResponseMessage.getData().getUserName());
            }
            MessageDigest md = MessageDigest.getInstance("SHA256");
            md.update(sb.toString().getBytes());
            return md.digest();
        } catch (Exception exception) {
            Log.d(TAG, "problem getting key " + exception);
        }

        return sb.toString().getBytes();
    }

    private void setup() {
        try {
            cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            String iv = "1234567890123456";
            ivSpec = new IvParameterSpec(iv.getBytes());
        } catch (Exception exception) {
            Log.d(TAG, "setup exception " + exception);
        }
    }

    public String encrypt(byte[] key, String data) {
        try {
            setup();
            keySpec = new SecretKeySpec(key, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
            byte[] encoded = Base64.encode(data.getBytes(StandardCharsets.UTF_8), Base64.DEFAULT);
            byte[] encrypted = cipher.doFinal(encoded);
            byte[] encodedAgain = Base64.encode(encrypted, Base64.DEFAULT);
            return new String(encodedAgain);
        } catch (Exception exception) {
            Log.d(TAG, "encrypt exception " + exception);
        }
        return null;
    }

    public String decrypt(byte[] key, String data) {
        try {
            setup();
            byte[] decoded = Base64.decode(data.getBytes(StandardCharsets.UTF_8), Base64.DEFAULT);
            keySpec = new SecretKeySpec(key, "AES");
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            byte[] decrypted = cipher.doFinal(decoded);
            byte[] decodedAgain = Base64.decode(decrypted, Base64.DEFAULT);
            return new String(decodedAgain);
        } catch (Exception exception) {
            Log.d(TAG, "decrypt exception " + exception);
        }
        return null;

    }

}
