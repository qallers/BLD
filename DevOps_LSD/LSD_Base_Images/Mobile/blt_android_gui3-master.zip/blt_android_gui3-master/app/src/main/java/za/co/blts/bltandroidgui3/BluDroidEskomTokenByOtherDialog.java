package za.co.blts.bltandroidgui3;

import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidMeterNumberEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidMoneyEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidSetupable;
import za.co.blts.magcard.BluDroidMagCardAsyncReponse;

import static android.view.View.GONE;

/**
 * Created by NkosanaM on 3/29/2017.
 */

public class BluDroidEskomTokenByOtherDialog extends BluDroidConfirmationDialog implements BluDroidSetupable, BluDroidMagCardAsyncReponse {
    @SuppressWarnings("FieldCanBeLocal")
    private final String TAG = this.getClass().getSimpleName();

    public void setup() {
        super.setup();
        setAffirmativeButtonLabel(R.string.confirm);
        hideView(R.id.neutralButton);
        setNegativeButtonLabel(R.string.cancel);
        setHeading("Token By Other");


        BluDroidButton swipeCard = findViewById(R.id.swipeCard);

        if (baseActivity.openMagEncoder()) {

            baseActivity.magCard.setDelegate(this);
            swipeCard.setVisibility(View.VISIBLE);

            swipeCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    BaseActivity.logger.info(((BluDroidButton) v).getText());
                    baseActivity.magCard.openUsbSerial();
                    baseActivity.createMagEncoderAlertDialog("Mag Card", "Please swipe card to read");
                    baseActivity.magCard.sendReadCommand();
                    baseActivity.magCardAction = "read";
                }
            });
        } else {
            swipeCard.setVisibility(GONE);
        }

        setupSpinner();

        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private void setupSpinner() {
        final Spinner meterNumberSpinner = findViewById(R.id.meterNumberSpinner);
        final BluDroidLinearLayout buttonLayout = findViewById(R.id.buttonLayout);
        final BluDroidMeterNumberEditText meterNumber = findViewById(R.id.meterNumber);

        final List<String> meterNumbers = new ArrayList<>();

        if (checkCustomerProfileAccountNumbers(meterNumbers)) {
            meterNumbers.add(0, "Other");
            meterNumberSpinner.setVisibility(View.VISIBLE);
            buttonLayout.setVisibility(View.GONE);

            // Creating adapter for spinner
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(baseActivity, android.R.layout.simple_spinner_item, meterNumbers);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            meterNumberSpinner.setAdapter(dataAdapter);
            //although meterNumber is hidden, update this with the selected spinner value, so the dialog.validate() will pass
            meterNumber.setText(meterNumbers.get(1));
            meterNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i == 0) {
                        onNothingSelected(null);
                    } else {
                        meterNumber.setText(meterNumbers.get(i));
                        buttonLayout.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    meterNumber.setText("");
                    buttonLayout.setVisibility(View.VISIBLE);
                }
            });
            meterNumberSpinner.setSelection(1);

        } else {
            meterNumberSpinner.setVisibility(View.GONE);
            buttonLayout.setVisibility(View.VISIBLE);
        }

    }

    private boolean checkCustomerProfileAccountNumbers(List<String> accountNumbers) {
        if (BaseActivity.consumerProfile != null && baseActivity.customerProfileElectricityAccountNumbers != null) {
            String[] accounts = baseActivity.customerProfileElectricityAccountNumbers.get("EskomDirect");
            if (accounts != null && accounts.length > 0) {
                accountNumbers.addAll(Arrays.asList(accounts));
                return true;
            }
        }
        return false;
    }

    public BluDroidEskomTokenByOtherDialog(BaseActivity context) {
        super(context, R.layout.dialog_eskom_token_by_other);
        setup();
        Log.d(TAG, "update meter keys");
    }

    public void setIcon(Drawable drawable) {
        ImageView imageView = findViewById(R.id.icon);
        if (imageView != null) {
            imageView.setImageDrawable(drawable);
        }
    }

    public String getMeterNumber() {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            return meterEditText.getText().toString();
        } else {
            return "";
        }
    }

    private void setMeterNumber(String meterNumber) {
        BluDroidMeterNumberEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setText(meterNumber);
        }
    }


    public void setMeterNumberErrorMessage(String errorMessage) {
        BluDroidEditText meterEditText = findViewById(R.id.meterNumber);
        if (meterEditText != null) {
            meterEditText.setErrorMessage(errorMessage);
        }
    }

    public String getAmount() {
        BluDroidMoneyEditText amountEditText = findViewById(R.id.amount);

        return amountEditText.getText().toString();
    }

    public void setAmount(String amount) {
        BluDroidMoneyEditText amountEditText = findViewById(R.id.amount);

        amountEditText.setText(amount);
    }

    public String getTt() {
        BluDroidEditText editText = findViewById(R.id.tt);
        if (editText != null) {
            if (editText.getText().toString().isEmpty()) {
                return "0";
            } else {
                return editText.getText().toString();
            }
        } else {
            return "0";
        }
    }

    private void setTt(String tt) {
        BluDroidEditText editText = findViewById(R.id.tt);
        if (editText != null) {
            editText.setText(tt);
        }
    }

    public String getTi() {
        BluDroidEditText editText = findViewById(R.id.ti);
        if (editText != null) {
            if (editText.getText().toString().isEmpty()) {
                return "0";
            } else {
                return editText.getText().toString();
            }
        } else {
            return "0";
        }
    }

    private void setTi(String ti) {
        BluDroidEditText editText = findViewById(R.id.ti);
        if (editText != null) {
            editText.setText(ti);
        }
    }

    public String getSgc() {
        BluDroidEditText editText = findViewById(R.id.sgc);
        if (editText != null) {
            if (editText.getText().toString().isEmpty()) {
                return "0";
            } else {
                return editText.getText().toString();
            }
        } else {
            return "0";
        }
    }

    private void setSgc(String sgc) {
        BluDroidEditText editText = findViewById(R.id.sgc);
        if (editText != null) {
            editText.setText(sgc);
        }
    }

    public String getKrn() {
        BluDroidEditText editText = findViewById(R.id.krn);
        if (editText != null) {
            if (editText.getText().toString().isEmpty()) {
                return "0";
            } else {
                return editText.getText().toString();
            }
        } else {
            return "0";
        }
    }

    private void setKrn(String krn) {
        BluDroidEditText editText = findViewById(R.id.krn);
        if (editText != null) {
            editText.setText(krn);
        }
    }

    public String getAlg() {
        BluDroidEditText editText = findViewById(R.id.aig);
        if (editText != null) {
            if (editText.getText().toString().isEmpty()) {
                return "0";
            } else {
                return editText.getText().toString();
            }
        } else {
            return "0";
        }
    }

    private void setAlg(String alg) {
        BluDroidEditText editText = findViewById(R.id.aig);
        if (editText != null) {
            editText.setText(alg);
        }
    }

    @Override
    public void processFinish(String output) {
        if (baseActivity.alert != null) {
            baseActivity.alert.dismiss();
        }

        if (baseActivity.magCardAction.equalsIgnoreCase("read")) {

            if (output.toLowerCase().contains("success")) {
                setMeterNumber(baseActivity.magCard.getTracks().get(1));
                String parts = baseActivity.magCard.getTracks().get(1);


                String tt = parts.substring(parts.lastIndexOf("=") + 1, parts.lastIndexOf("=") + 3);
                String alg = parts.substring(parts.lastIndexOf("=") + 3, parts.lastIndexOf("=") + 5);
                String sgc = parts.substring(parts.lastIndexOf("=") + 5, parts.lastIndexOf("=") + 11);
                String ti = parts.substring(parts.lastIndexOf("=") + 11, parts.lastIndexOf("=") + 13);
                String krn = parts.substring(parts.lastIndexOf("=") + 13, parts.lastIndexOf("=") + 14);

                setTt(tt);
                setAlg(alg);
                setSgc(sgc);
                setTi(ti);
                setKrn(krn);
            } else {
                baseActivity.createAlertDialog("Mag Encoder", output);
            }
        }
    }
}
