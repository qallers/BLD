package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;

import za.co.blt.interfaces.external.factories.EmergencyLoanRequestFactory;
import za.co.blt.interfaces.external.messages.common.response.CommonResponseLineMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.request.EmergencyLoanRequestLoanApplicationMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanResponseAccountMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanResponseListAccountsMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanResponseLoanApplicationMessage;
import za.co.blt.interfaces.external.messages.emergencyloan.response.EmergencyLoanResponseLoanConfirmationMessage;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidCheckBoxButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;

public class ActivityEmergencyTopUp extends BaseActivity implements NeedsAEONResults, View.OnClickListener {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidTextView txt_available_amt;
    private BluDroidTextView txt_wish_to_continue;
    private BluDroidTextView txt_payback_period;
    private BluDroidTextView txt_requested_amt;
    private Spinner accountNumberSpinner;
    private BluDroidButton accept;
    private BluDroidButton bcontinue;
    private BluDroidEditText edt_amount;
    private BluDroidLinearLayout paybackPeriodLayout;
    private BluDroidCheckBoxButton termsCheckBox;

    private String accountId = "";
    private String account = "";
    private Double requestedAmt = 0.0;
    private String amtAvailable = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_top_up);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        authenticateForEmergencyTopup();

        txt_available_amt = findViewById(R.id.txt_avalable_amt);
        edt_amount = findViewById(R.id.edt_amount);
        accountNumberSpinner = findViewById(R.id.accountNumberSpinner);

        //hide and show components
        paybackPeriodLayout = findViewById(R.id.paybackPeriodLayout);
        bcontinue = findViewById(R.id.bcontinue);
        txt_wish_to_continue = findViewById(R.id.txt_wish_to_continue);
        txt_payback_period = findViewById(R.id.txt_payback_period);
        txt_requested_amt = findViewById(R.id.txt_requested_amt);

        BluDroidButton cancel = findViewById(R.id.cancel);
        cancel.setOnClickListener(this);

        accept = findViewById(R.id.accept);
        accept.setOnClickListener(this);
        accept.setEnabled(false);
        accept.setBackgroundColor(getResources().getColor(R.color.lightGrey));

        bcontinue = findViewById(R.id.bcontinue);
        bcontinue.setOnClickListener(this);

        toolbar = findViewById(R.id.toolbar);
        String title = "Emergency Top Up";
        toolbar.setTitle(title);
        toolbar.setNavigationBackIcon();


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetTimer();
                gotoMainScreen();
            }
        });

        termsCheckBox = findViewById(R.id.termsCheckBox);
        termsCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()) {
                    accept.setEnabled(true);
                    accept.setBackgroundColor(getSkinResources().getButtonColor());
                } else {
                    accept.setEnabled(false);
                    accept.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        logger.info("ActivityEmergencyTopUp" + ((BluDroidButton) v).getText());
        switch (v.getId()) {
            case R.id.bcontinue:

                if (!edt_amount.getText().toString().isEmpty()) {
                    requestedAmt = Double.parseDouble(edt_amount.getText().toString().trim());
                    amtAvailable = getAmountAvailable() + "";
                    if (requestedAmt > getAmountAvailable() || requestedAmt < 100) {
                        if (emergencyLoanResponseLoanApplicationMessage.getData().getStatus().getQualifyAmount().equals("0.00"))
                            edt_amount.setErrorMessage("Minimum amount must be R100");
                        else
                            edt_amount.setErrorMessage("Must be between R100 and " + txt_available_amt.getText().toString());
                    } else {
                        edt_amount.removeErrorMessage();
                        edt_amount.setVisibility(View.GONE);
                        bcontinue.setVisibility(View.GONE);

                        txt_requested_amt.setText(getString(R.string.format_amount, edt_amount.getText().toString().trim() + ".00"));
                        txt_requested_amt.setVisibility(View.VISIBLE);
                        termsCheckBox.setVisibility(View.VISIBLE);

                        accept.setVisibility(View.VISIBLE);
                        paybackPeriodLayout.setVisibility(View.VISIBLE);
                        txt_wish_to_continue.setVisibility(View.VISIBLE);
                    }
                } else {
                    if (emergencyLoanResponseLoanApplicationMessage.getData().getStatus().getQualifyAmount().equals("0.00"))
                        edt_amount.setErrorMessage("Minimum amount must be R100");
                    else
                        edt_amount.setErrorMessage("Must be between R100 and " + txt_available_amt.getText().toString());
                }
                break;
            case R.id.accept:

                confirmEmegerncyTopup(accountId, requestedAmt + "", amtAvailable);

                break;
            case R.id.cancel:

                gotoMainScreen();
                createNotification("Emergency topup cancelled");

                break;
        }
    }

    @Override
    public void results(Object object) {

        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(ETU) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }
        if (object instanceof EmergencyLoanAuthenticationResponseMessage) {
            Log.v(TAG, "EmergencyLoanAuthenticationResponseMesssage");
            emergencyLoanAuthenticationResponseMessage = (EmergencyLoanAuthenticationResponseMessage) object;
            dismissProgress();
            if (emergencyLoanAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
                getEmergencyTopUpAccountList();
            }
        } else if (object instanceof EmergencyLoanResponseListAccountsMessage) {
            Log.v(TAG, "EmergencyLoanResponseListAccountsMessage");
            dismissProgress();
            emergencyLoanResponseListAccountsMessage = (EmergencyLoanResponseListAccountsMessage) object;
            if (emergencyLoanResponseListAccountsMessage.getEvent().getEventCode().equals("0")) {
                populateETUSpinner();
            }
        } else if (object instanceof EmergencyLoanResponseLoanApplicationMessage) {
            dismissProgress();
            Log.v(TAG, "EmergencyLoanResponseLoanApplicationMessage");
            dismissProgress();
            edt_amount.removeErrorMessage();
            emergencyLoanResponseLoanApplicationMessage = (EmergencyLoanResponseLoanApplicationMessage) object;
            if (emergencyLoanResponseLoanApplicationMessage.getEvent().getEventCode().equals("0")) {
                if (emergencyLoanResponseLoanApplicationMessage.getData().getStatus().getQualify().equals("true")) {
                    txt_available_amt.setText(getString(R.string.format_amount, emergencyLoanResponseLoanApplicationMessage.getData().getStatus().getQualifyAmount()));
                    txt_payback_period.setText(emergencyLoanResponseLoanApplicationMessage.getData().getStatus().getPaybackPeriod());
                    if (emergencyLoanResponseLoanApplicationMessage.getData().getStatus().getQualifyAmount().equals("0.00")) {
                        edt_amount.setEnabled(false);
                        bcontinue.setEnabled(false);
                        bcontinue.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                        createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorEmergencyTopup, true);
                    } else {
                        Log.d(TAG, "all ok");
                        edt_amount.setEnabled(true);
                        edt_amount.setText("");
                        bcontinue.setEnabled(true);
                        bcontinue.setBackgroundColor(getSkinResources().getButtonColor());
                    }
                } else {
                    createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, emergencyLoanResponseLoanApplicationMessage.getData().getStatus().getReason(), true);
                    txt_available_amt.setText(getString(R.string.format_amount, "0.00"));
                    edt_amount.setEnabled(false);
                    bcontinue.setEnabled(false);
                    bcontinue.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                }
            } else {
                //
                // need to popup an error
                //
                createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, emergencyLoanResponseLoanApplicationMessage.getData().getStatus().getReason(), true);
//          edt_amount.setKeyListener(null);
                txt_available_amt.setText(getString(R.string.format_amount, "0.00"));
                edt_amount.setEnabled(false);
                bcontinue.setEnabled(false);
                bcontinue.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            }
        } else if (object instanceof EmergencyLoanResponseLoanConfirmationMessage) {
            dismissProgress();
            Log.v(TAG, "EmergencyLoanResponseLoanConfirmationMessage");
            emergencyLoanResponseLoanConfirmationMessage = (EmergencyLoanResponseLoanConfirmationMessage) object;
            if (emergencyLoanResponseLoanConfirmationMessage.getEvent().getEventCode().equals("0")) {
                //
                // now print a receipt
                //
                ArrayList<CommonResponseLineMessage> merchantReceipt = new ArrayList<>();
                merchantReceipt.add(printLine("O", "Emergency Topup Confirmation"));
                merchantReceipt.add(printLine("O", HORIZONTAL_LINE));
                merchantReceipt.add(printLine("O", format("Requested by",
                        emergencyLoanResponseLoanConfirmationMessage.getData().getUserName())));
                merchantReceipt.add(printLine("O", format("Date",
                        emergencyLoanResponseLoanConfirmationMessage.getData().getTransDate())));
                merchantReceipt.add(printLine("O", format("Trans Ref",
                        emergencyLoanResponseLoanConfirmationMessage.getData().getTransRef())));
                merchantReceipt.add(printLine("O", HORIZONTAL_LINE));
                merchantReceipt.add(printLine("O", format("Account ID",
                        emergencyLoanResponseLoanConfirmationMessage.getData().getAccountId())));
                merchantReceipt.add(printLine("O", format("Account Number", account)));
                merchantReceipt.add(printLine("O", format("Available",
                        emergencyLoanResponseLoanConfirmationMessage.getData().getAmountAvailable())));
                merchantReceipt.add(printLine("O", format("Requested",
                        emergencyLoanResponseLoanConfirmationMessage.getData().getAmountRequested())));
                merchantReceipt.add(printLine("O", format("Allocated",
                        emergencyLoanResponseLoanConfirmationMessage.getData().getAmountAllocated())));
                merchantReceipt.add(printLine("O", format("Balance",
                        emergencyLoanResponseLoanConfirmationMessage.getData().getBalance())));
                merchantReceipt.add(printLine("O", HORIZONTAL_LINE));
                merchantReceipt.add(printLine("H", getResources().getString(R.string.printDone)));
                print(merchantReceipt);
                //save("ETU " + emergencyLoanResponseLoanConfirmationMessage.getData().getTransRef(), merchantReceipt);
                createNotification("Emergency Top Up Successful");
                gotoMainScreen();

            } else {
                createSystemErrorConfirmation(emergencyLoanResponseLoanConfirmationMessage, true);
            }

        } else {
            super.results(object);
        }

        if (object != null && !(object instanceof Socket)) {
            firebaseBundle = new Bundle();
            firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            mFirebaseAnalytics.logEvent("aeon_connection", firebaseBundle);
        }
    }

    private Double getAmountAvailable() {
        String strAmt = txt_available_amt.getText().toString();
        strAmt = strAmt.replace("R ", "");
        return Double.parseDouble(strAmt);
    }

    private void populateETUSpinner() {
        accountNumbers = new ArrayList<>();
        ArrayList<EmergencyLoanResponseAccountMessage> list = getTopUpAccountList();

        Log.v(TAG, "Account List: " + list.size());

        for (int i = 0; i < list.size(); i++) {
            accountNumbers.add(list.get(i).getText());
        }

        ArrayAdapter<String> accountListAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, accountNumbers);
        accountListAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        accountNumberSpinner = findViewById(R.id.accountNumberSpinner);
        accountNumberSpinner.setAdapter(accountListAdapter);
        accountNumberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                account = ((TextView) parent.getSelectedView()).getText().toString().trim();
                accountId = getSelectedAccount(account);
                applyForEmergencyTopup(accountId);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Log.v(TAG, "Account Numbers Size: " + accountNumbers.size());
    }

    private void applyForEmergencyTopup(String accountNumber) {
        Date date = new Date();
        createProgress("Getting available amount");
        EmergencyLoanRequestFactory factory = new EmergencyLoanRequestFactory();
        EmergencyLoanRequestLoanApplicationMessage request = factory.apply(
                emergencyLoanAuthenticationResponseMessage,
                getPreference(PREF_DEVICE_ID) + "_" + date.getTime(),
                accountNumber);

        startAEONAsyncTask(this, socket, request);
    }


    private String getSelectedAccount(String accountNumber) {
        String accountId = "";

        try {

            for (int i = 0; i < emergencyLoanResponseListAccountsMessage.getData().getAccounts().size(); i++) {
                if (accountNumber.equals(emergencyLoanResponseListAccountsMessage.getData().getAccounts().get(i).getText())) {
                    accountId = emergencyLoanResponseListAccountsMessage.getData().getAccounts().get(i).getId();
                }
            }
        } catch (Exception exception) {
            Log.v(TAG, "getSelectedAccount " + exception);
        }
        return accountId;
    }

    @Override
    public void onBackPressed() {


        gotoMainScreen();


    }

}
