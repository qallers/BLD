package za.co.blts.bltandroidgui3.confirmations;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidCellphoneEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidCheckBoxButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidLinearLayout;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

//
// view and button stuff
//


public class BluDroidPinlessBundleConfirmationDialog extends BluDroidPinlessTopupAnyAmountConfirmationDialog implements TextWatcher, CompoundButton.OnCheckedChangeListener {
    private final String TAG = this.getClass().getSimpleName();
    private BluDroidCellphoneEditText cellEditText;
    private BluDroidCellphoneEditText confirmCellEditText;

    private String stockId;

    private boolean alreadyCalledFlow = false;

    public BluDroidPinlessBundleConfirmationDialog(BaseFragment context) {
        super(context);
        setContentView(R.layout.confirmation_pinless_topup);
        cellEditText = findViewById(R.id.cellNumber);
        confirmCellEditText = findViewById(R.id.confirmCellNumber);
        cellEditText.addTextChangedListener(this);
        setup();
        BaseActivity.logger.info(": construction with BaseFragment");
    }

    public void setStockId(String stockId) {
        this.stockId = stockId;
    }

    public String getStockId() {
        return stockId;
    }

    @Override
    public void setAmount(String amount) {
        BluDroidTextView amountTextView = findViewById(R.id.amount);
        if (amountTextView != null) {
            amountTextView.setText(amount);
        }
    }

    @Override
    public String getAmount() {
        BluDroidTextView amountTextView = findViewById(R.id.amount);
        if (amountTextView != null) {
            return amountTextView.getText().toString().replaceAll("R", "");
        } else {
            return "0.00";
        }
    }

    public void showAirtimePlus() {
        BluDroidLinearLayout layout = findViewById(R.id.airtimeplusLayout);
        if (layout != null) {
            layout.setVisibility(View.VISIBLE);
            setAirtimePlusAmount();


            BluDroidCheckBoxButton playAirtimePlus = findViewById(R.id.airtimePlusCheckBox);
            playAirtimePlus.setOnCheckedChangeListener(this);

            calculateAmountDue();
        }
    }

    public void hideAirtimePlus() {
        BluDroidLinearLayout layout = findViewById(R.id.airtimeplusLayout);
        if (layout != null) {
            layout.setVisibility(View.INVISIBLE);
        }
    }

    void setAirtimePlusAmount() {
        BluDroidTextView amountTextView = findViewById(R.id.airtimeplus);
        if (amountTextView != null) {
            try {
                String disp = amountTextView.getText().toString() + "(R" + baseActivity.df2.format(Double.parseDouble(baseActivity.airtimePlusValue)) + ")";
                amountTextView.setText(disp);

            } catch (Exception ex) {
                Log.d(TAG, "setAirtimePlusAmount: " + ex.getMessage());
            }
        }
    }


    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        //Log.d(TAG, "onTextChanged [" + getText().toString().trim() + "]");
        if (baseActivity != null)
            baseActivity.resetTimer();
        if (alreadyCalledFlow)
            baseActivity.cancelTimer();

        int ccnt = cellEditText.getText().toString().trim().length();
        if (ccnt > 0) {
            cellEditText.removeErrorMessage();
        }
        if ((cellEditText.maxLength != -1)) {
            int cnt = cellEditText.getText().toString().trim().length();
            //Log.d(TAG, "count is " + cnt);


            if (cnt < cellEditText.maxLength)
                alreadyCalledFlow = false;

            //Log.d(TAG, "text changed");

            if (cnt == cellEditText.maxLength) {
                //Log.d(TAG, "calling topup flow");

                confirmCellEditText.requestFocus();
            }
        }
    }

    @Override
    public void afterTextChanged(Editable s) {
        int cnt = cellEditText.getText().length();
        if (cnt == cellEditText.maxLength) {
            //Log.d(TAG, "validating cell");

            cellEditText.validate();
        }
    }

    void calculateAmountDueWithAirtimePlus() {


        try {
            BluDroidTextView totalText = findViewById(R.id.Total);

            Double total = Double.parseDouble(baseActivity.airtimePlusValue) + Double.parseDouble(getAmount().replace("R", ""));
            String disp = "R" + baseActivity.df2.format(total);
            totalText.setText(disp);
        } catch (Exception ex) {
            Log.d(TAG, "calculateAmountDueWithAirtimePlus: " + ex.getMessage());
        }
    }

    void calculateAmountDue() {

        try {
            BluDroidTextView totalText = findViewById(R.id.Total);

            Double total = Double.parseDouble(getAmount().replace("R", ""));
            String disp = "R" + baseActivity.df2.format(total);
            totalText.setText(disp);
        } catch (Exception ex) {
            Log.d(TAG, "calculateAmountDue: " + ex.getMessage());
        }


    }


    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            calculateAmountDueWithAirtimePlus();
            baseActivity.airtimePlusPlayed = "1";
        } else {
            calculateAmountDue();
            baseActivity.airtimePlusPlayed = "0";
        }
    }
}

