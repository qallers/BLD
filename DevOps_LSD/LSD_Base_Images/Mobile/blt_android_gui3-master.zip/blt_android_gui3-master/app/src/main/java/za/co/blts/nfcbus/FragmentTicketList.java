package za.co.blts.nfcbus;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.net.Socket;
import java.util.HashMap;

import za.co.blt.interfaces.external.factories.NfcBusRequestFactory;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusCancelTicketRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusConfirmCancelTicketRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusGetCustomerRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusListCarriersRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusListStopsRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusLookupFaresRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusValidateSvcRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusCancelTicketResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusConfirmCancelTicketResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusGetCustomerResponseDataMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusGetCustomerResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListCarriersResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListStopsResponseLocationMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListStopsResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupFaresResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusValidateSvcResponseMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.NeedsAEONResults;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.nfc.NfcResult;
import za.co.blts.nfc.NfcResultable;
import za.co.blts.nfc.NfcTappable;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;


public class FragmentTicketList extends BaseFragment implements NeedsAEONResults, NfcResultable {
    private final String TAG = this.getClass().getSimpleName();

    enum AuthFor {
        None,
        Carriers,
        ValidateSvc,
        GetCustomer,
        Cancel,
        ConfirmCancel,
        Fare
    }

    private AuthFor authFor = AuthFor.None;
    private int carrierIndex = 0;

    private ActivityNfcBus.CardFuntion cardFunction;
    private TicketListAdapter adapter;
    private NfcBusCancelTicketResponseMessage cancelTicketResponseMessage;
    private final int MAX_ATTEMPTS = 2;
    private int writeAttempt = 0;
    private boolean writeSuccess = false;
    private TextView txtNoTickets;
    private ListView listTickets;
    private NfcBusCancelTicket ticketToCancel;


    public FragmentTicketList() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ((ActivityNfcBus) getActivity()).setResultable(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_ticket_list, container, false);

        txtNoTickets = rootView.findViewById(R.id.txtNoTickets);

        listTickets = rootView.findViewById(R.id.listTickets);
        BluDroidButton btnNewTicket = rootView.findViewById(R.id.btnNewTicket);
        btnNewTicket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "New Ticket clicked");
                ((ActivityNfcBus) getActivity()).gotoNewTicket();
            }
        });

        BluDroidButton btnProfile = rootView.findViewById(R.id.btnProfile);
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Profile clicked");
                if (((ActivityNfcBus) getActivity()).getCard() != null) {
                    ((ActivityNfcBus) getActivity()).gotoCustomerProfile();
                }
            }
        });

        adapter = new TicketListAdapter(getActivity(), android.R.layout.simple_list_item_1, ((ActivityNfcBus) getActivity()).getTickets(), this);
        listTickets.setAdapter(adapter);

        if (((ActivityNfcBus) getActivity()).getNfcBusListCarriersResponseMessage() == null) {
            authFor = AuthFor.Carriers;
            ((ActivityNfcBus) getActivity()).authForNfcBus(this);
        } else {
            promptForCardCheck();
        }

        setVisibleViews();

//Caching of carrier and stop data is not implemented, since destinations for selected departure point are looked up in real time.
//If by any chance a new destination has been added that is not in the cached data, errors will occur since they cannot be looked
//up in the ActivityNfcBus.stopsMap.
//        if (!checkCachedDataExists()) {
//            authFor = AuthFor.Carriers;
//            ((ActivityNfcBus) getActivity()).authForNfcBus(this);
//        } else {
//            //delay prompt for card to allow Sunmi Pay SDK to initialize
//            getBaseActivity().createProgress(R.string.initializing);
//            final Handler handler = new Handler();
//            handler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    getBaseActivity().dismissProgress();
//                    promptForCardCheck();
//                }
//            }, 1000);
//        }

        return rootView;
    }

    private void setVisibleViews() {
        boolean noTickets = ((ActivityNfcBus) getActivity()).getTickets().isEmpty();
        txtNoTickets.setVisibility(noTickets ? View.VISIBLE : View.GONE);
        listTickets.setVisibility(noTickets ? View.GONE : View.VISIBLE);
    }

//    private boolean checkCachedDataExists() {
//        boolean allOk = true;
//        long now = System.currentTimeMillis();
//        if (now - getBaseActivity().dateNfcBusCarrierCache().getTime() > getBaseActivity().CACHE_12_HOURS) {
//            allOk = false;
//        } else {
//            NfcBusListCarriersResponseMessage carriersResponseMessage = getBaseActivity().getCachedNfcBusCarriers();
//            if (carriersResponseMessage == null) {
//                allOk = false;
//            } else {
//                ((ActivityNfcBus) getActivity()).setNfcBusListCarriersResponseMessage(carriersResponseMessage);
//
//                for (NfcBusListCarriersResponseCompanyMessage company : carriersResponseMessage.getDetail().getCompanies()) {
//                    NfcBusListStopsResponseMessage stops = getBaseActivity().getCachedNfcBusStops(company.getCompanyId());
//                    if (stops == null) {
//                        allOk = false;
//                        break;
//                    } else {
//                        HashMap<Long, NfcBusListStopsResponseLocationMessage> map = new HashMap<>();
//                        for (NfcBusListStopsResponseLocationMessage stop : stops.getDetail().getLocations()) {
//                            map.put(stop.getId(), stop);
//                        }
//                        ((ActivityNfcBus) getActivity()).stopsMap.put(company.getCompanyId(), map);
//                    }
//                }
//            }
//        }
//
//        if (!allOk) {
//            getBaseActivity().removeNfcBusCache();
//            ((ActivityNfcBus) getActivity()).setNfcBusListCarriersResponseMessage(null);
//            ((ActivityNfcBus) getActivity()).stopsMap.clear();
//        }
//
//        return allOk;
//    }

    private void getCarrierList(String sessionId) {
        getBaseActivity().createProgress(getResources().getString(R.string.getting_carrier_list));
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusListCarriersRequestMessage req = factory.listCarriers(sessionId);
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    private void getCustomer(String sessionId) {
        getBaseActivity().createProgress(getResources().getString(R.string.getting_customer));
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusGetCustomerRequestMessage req = factory.getCustomer(sessionId,
                ((ActivityNfcBus) getActivity()).getCardUid());
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    private void validateSvc(String sessionId) {
        getBaseActivity().createProgress(getResources().getString(R.string.validating_card));
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusValidateSvcRequestMessage req = factory.validateSvc(sessionId,
                ((ActivityNfcBus) getActivity()).getCardUid(),
                ((ActivityNfcBus) getActivity()).getSvc());
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    private void getStopsLists() {
        if (carrierIndex < ((ActivityNfcBus) getActivity()).getNfcBusListCarriersResponseMessage().getDetail().getCompanies().size()) {
            getBaseActivity().createProgress(getResources().getString(R.string.getting_stop_lists));
            NfcBusRequestFactory factory = new NfcBusRequestFactory();
            NfcBusListStopsRequestMessage req = factory.listStops(((ActivityNfcBus) getActivity()).getNfcBusAuthenticationResponseMessage().getSessionId(),
                    ((ActivityNfcBus) getActivity()).getNfcBusListCarriersResponseMessage().getDetail().getCompanies().get(carrierIndex).getCompanyId());
            getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
        } else {
            Log.i(TAG, "Stops for all carriers received");
            getBaseActivity().dismissProgress();
            getBaseActivity().closeAeonSocket(35);
            promptForCardCheck();
        }
    }

    private void lookupFare(String sessionId) {
        getBaseActivity().createProgress(R.string.getting_fare_products);
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusLookupFaresRequestMessage req = factory.lookupFare(sessionId,
                ((ActivityNfcBus) getActivity()).getCurrentTicket().getCompanyId(),
                ((ActivityNfcBus) getActivity()).getCurrentTicket().getFareProductId());
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    @Override
    public void results(Object object) {
        if (object instanceof NfcBusAuthenticationResponseMessage) {
            if (((NfcBusAuthenticationResponseMessage) object).getEvent().getEventCode().equals("0")) {
                ((ActivityNfcBus) getActivity()).setNfcBusAuthenticationResponseMessage((NfcBusAuthenticationResponseMessage) object);
                switch (authFor) {
                    case Carriers:
                        getCarrierList(((NfcBusAuthenticationResponseMessage) object).getSessionId());
                        break;

                    case ValidateSvc:
                        validateSvc(((NfcBusAuthenticationResponseMessage) object).getSessionId());
                        break;

                    case GetCustomer:
                        getCustomer(((NfcBusAuthenticationResponseMessage) object).getSessionId());
                        break;

                    case Cancel:
                        cancelTicket(((NfcBusAuthenticationResponseMessage) object).getSessionId());
                        break;

                    case ConfirmCancel:
                        confirmCancelTicket(((NfcBusAuthenticationResponseMessage) object).getSessionId());
                        break;

                    case Fare:
                        lookupFare(((NfcBusAuthenticationResponseMessage) object).getSessionId());
                        break;

                    default:
                        getBaseActivity().dismissProgress();
                        Log.e(TAG, "unknown auth for");
                        break;
                }
            } else {
                getBaseActivity().returnToFavouritesScreen = true;
                getBaseActivity().createSystemErrorConfirmation(object, true);
            }

        } else if (object instanceof NfcBusListCarriersResponseMessage) {
            if (((NfcBusListCarriersResponseMessage) object).getEvent().getEventCode().equals("0")) {
//                getBaseActivity().cacheNfcBusCarriers((NfcBusListCarriersResponseMessage)object);
                ((ActivityNfcBus) getActivity()).setNfcBusListCarriersResponseMessage((NfcBusListCarriersResponseMessage) object);
                carrierIndex = 0;
                getStopsLists();
            } else {
                getBaseActivity().returnToFavouritesScreen = true;
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }

        } else if (object instanceof NfcBusListStopsResponseMessage) {
            NfcBusListStopsResponseMessage resp = (NfcBusListStopsResponseMessage) object;
            if (resp.getEvent().getEventCode().equals("0")) {
                HashMap<Long, NfcBusListStopsResponseLocationMessage> map = new HashMap<>();
                for (NfcBusListStopsResponseLocationMessage stop : resp.getDetail().getLocations()) {
                    map.put(stop.getId(), stop);
                }
                ((ActivityNfcBus) getActivity()).stopsMap.put(
                        ((ActivityNfcBus) getActivity()).getNfcBusListCarriersResponseMessage().getDetail().getCompanies().get(carrierIndex).getCompanyId(),
                        map);
                carrierIndex++;
                getStopsLists();
            } else {
                getBaseActivity().returnToFavouritesScreen = true;
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }
        } else if (object instanceof NfcBusValidateSvcResponseMessage) {
            getBaseActivity().dismissProgress();
            getBaseActivity().closeAeonSocket(38);
            if (((NfcBusValidateSvcResponseMessage) object).getEvent().getEventCode().equals("0")) {
                if (((NfcBusValidateSvcResponseMessage) object).getDetail().getStatus().equals("1")) {
                    ((ActivityNfcBus) getActivity()).setNfcBusTickets(((NfcBusValidateSvcResponseMessage) object).getDetail().getTickets());
                    setVisibleViews();
                    adapter.notifyDataSetChanged();
                } else {
                    getBaseActivity().returnToFavouritesScreen = false;
                    getBaseActivity().createSystemErrorConfirmation(((NfcBusValidateSvcResponseMessage) object).getDetail().getMessage(), false);
                }
            } else {
                getBaseActivity().returnToFavouritesScreen = false;
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }
        } else if (object instanceof NfcBusGetCustomerResponseMessage) {
            getBaseActivity().dismissProgress();
            getBaseActivity().closeAeonSocket(39);
            if (((NfcBusGetCustomerResponseMessage) object).getEvent().getEventCode().equals("0")) {
                if (((NfcBusGetCustomerResponseMessage) object).getDetail().getStatus().equals("1")
                        && ((NfcBusGetCustomerResponseMessage) object).getDetail().getData().size() > 0) {
                    NfcBusGetCustomerResponseDataMessage customer = ((NfcBusGetCustomerResponseMessage) object).getDetail().getData().get(0);
                    ((ActivityNfcBus) getActivity()).setCustomerResponseDataMessage(customer);
                    authFor = AuthFor.ValidateSvc;
                    ((ActivityNfcBus) getActivity()).authForNfcBus(this);
                } else {
                    ((ActivityNfcBus) getActivity()).setCustomerResponseDataMessage(null);
                    ((ActivityNfcBus) getActivity()).gotoCustomerProfile();
                }
            } else {
                getBaseActivity().returnToFavouritesScreen = false;
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }

        } else if (object instanceof NfcBusLookupFaresResponseMessage) {
            getBaseActivity().dismissProgress();
            getBaseActivity().closeAeonSocket(40);
            if (((NfcBusLookupFaresResponseMessage) object).getEvent().getEventCode().equals("0")) {
                if (((NfcBusLookupFaresResponseMessage) object).getDetail().getStatus().equals("1")) {
                    if (((NfcBusLookupFaresResponseMessage) object).getDetail().getFares().size() == 1) {
                        ((ActivityNfcBus) getActivity()).setFare(new Fare(((NfcBusLookupFaresResponseMessage) object).getDetail().getFares().get(0)));
                        ((ActivityNfcBus) getActivity()).gotoPurchaseTicket(true);
                    } else {
                        getBaseActivity().returnToFavouritesScreen = false;
                        getBaseActivity().createSystemErrorConfirmation("Unable to get Fare details", false);
                    }
                } else {
                    getBaseActivity().returnToFavouritesScreen = false;
                    getBaseActivity().createSystemErrorConfirmation(((NfcBusLookupFaresResponseMessage) object).getDetail().getMessage(), false);
                }
            } else {
                getBaseActivity().returnToFavouritesScreen = false;
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }
        } else if (object instanceof NfcBusCancelTicketResponseMessage) {
            getBaseActivity().dismissProgress();
            getBaseActivity().closeAeonSocket(43);
            if (((NfcBusCancelTicketResponseMessage) object).getEvent().getEventCode().equals("0")) {
                if (((NfcBusCancelTicketResponseMessage) object).getDetail().getStatus().equals("1")) {
                    cancelTicketResponseMessage = (NfcBusCancelTicketResponseMessage) object;
                    writeAttempt = 1;
                    promptForCardCancel();
                } else {
                    getBaseActivity().returnToFavouritesScreen = false;
                    getBaseActivity().createSystemErrorConfirmation(((NfcBusCancelTicketResponseMessage) object).getDetail().getMessage(), false);
                }
            } else {
                getBaseActivity().returnToFavouritesScreen = false;
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }
        } else if (object instanceof NfcBusConfirmCancelTicketResponseMessage) {
            getBaseActivity().closeAeonSocket(44);
            if (((NfcBusConfirmCancelTicketResponseMessage) object).getEvent().getEventCode().equals("0")) {
                getBaseActivity().saveAccountDetails(((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getAccounts());

                if (((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getStatus().equals("1")) {
                    getBaseActivity().recoveryCacheHandler.deleteRecoveryFromCache(cancelTicketResponseMessage.getDetail().getTransRef());

                    if (!((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getPrintLines().isEmpty()) {
                        getBaseActivity().printWithDynamic(((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getPrintLines(), getBaseActivity().getPrintBarcode());
                    }

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)
                            && !((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getMerchantPrintLines().isEmpty()) {
                        getBaseActivity().print(((NfcBusConfirmCancelTicketResponseMessage) object).getDetail().getMerchantPrintLines());
                    }

                    getBaseActivity().dismissProgress();

                    confirmCancelSuccess();

                } else {
                    confirmCancelError();
                }
            } else {
                confirmCancelError();
            }
        }

        if (object != null && !(object instanceof Socket)) {
            getBaseActivity().firebaseBundle = new Bundle();
            getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            getBaseActivity().mFirebaseAnalytics.logEvent("aeon_connection", getBaseActivity().firebaseBundle);
        }
    }

    private void promptForCardCheck() {
        Log.d(TAG, "prompt for card");
        String message = "Please place your SmartTap card on the reader.\n\nDO NOT REMOVE CARD TILL TRANSACTION COMPLETES";
        getBaseActivity().alert = new BluDroidAlertDialog(getContext());
        getBaseActivity().alert.setTitle("NFC");
        getBaseActivity().alert.setMessage(message);
        getBaseActivity().alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                getBaseActivity().alert.dismiss();
                ((ActivityNfcBus) getActivity()).getTappable().cancelCard();
                getBaseActivity().gotoMainScreen();
            }
        });
        getBaseActivity().alert.show();
        cardFunction = ActivityNfcBus.CardFuntion.CHECK_FORMAT;
        ((ActivityNfcBus) getActivity()).getTappable().checkCard(NfcBusInstr.check(false));
    }

    private void promptForCardCancel() {
        Log.d(TAG, "prompt for card");
        String message = "Please place your SmartTap card with ID " + ((ActivityNfcBus) getActivity()).getCardUid();
        if (writeAttempt > 1) {
            message += "\n(Attempt " + writeAttempt + " of " + MAX_ATTEMPTS + ")";
        }
        message += "\n\nDO NOT REMOVE CARD TILL TRANSACTION COMPLETES";


        getBaseActivity().alert = new BluDroidAlertDialog(getContext());
        getBaseActivity().alert.setTitle("NFC");
        getBaseActivity().alert.setMessage(message);
        getBaseActivity().alert.setNegativeOption(getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                getBaseActivity().alert.dismiss();
                ((ActivityNfcBus) getActivity()).getTappable().cancelCard();

                writeSuccess = false;
                authForConfirmCancel();
            }
        });
        getBaseActivity().alert.show();
        cardFunction = ActivityNfcBus.CardFuntion.WRITE_CARD;
        ((ActivityNfcBus) getActivity()).getTappable().writeCard(NfcBusInstr.write(false, cancelTicketResponseMessage.getDetail().getSvcData(),
                ((ActivityNfcBus) getActivity()).getCard().getUid()));
    }


    @Override
    public void handleNfcResult(NfcResult result) {
        BaseActivity.logger.info(result.toString());
        Log.i(TAG, "operation: " + result.getOperation());
        Log.i(TAG, "function: " + cardFunction);
        if (result.getOperation() == NfcTappable.NfcOperation.CHECK) {
            handleCheckCard(result);
        } else if (result.getOperation() == NfcTappable.NfcOperation.READ) {
            handleReadCard(result);
        } else if (result.getOperation() == NfcTappable.NfcOperation.WRITE) {
            handleWriteCard(result);
        }

    }

    private void handleCheckCard(NfcResult result) {
        if (cardFunction == ActivityNfcBus.CardFuntion.CHECK_FORMAT) {
            if (result.getStatus() == NfcTappable.NfcStatus.SUCCESS) {
                Log.i(TAG, "card is formatted");
                ((ActivityNfcBus) getActivity()).setCardFormatted(true);
                cardFunction = ActivityNfcBus.CardFuntion.READ_UID;
                ((ActivityNfcBus) getActivity()).getTappable().readCard(NfcBusInstr.uid(true, result.getCard().getUid()));
            } else {
                ((ActivityNfcBus) getActivity()).setCardFormatted(false);
                Log.i(TAG, "check if card is default");
                cardFunction = ActivityNfcBus.CardFuntion.CHECK_DEFAULT;
                ((ActivityNfcBus) getActivity()).getTappable().checkCard(NfcBusInstr.check(true));
            }
        } else if (cardFunction == ActivityNfcBus.CardFuntion.CHECK_DEFAULT) {
            getBaseActivity().alert.dismiss();
            if (result.getStatus() == NfcTappable.NfcStatus.SUCCESS) {
                Log.i(TAG, "get customer detail and format card");
                ((ActivityNfcBus) getActivity()).setCard(result.getCard());
                ((ActivityNfcBus) getActivity()).setCardFormatted(false);
                cardFunction = ActivityNfcBus.CardFuntion.READ_UID;
                ((ActivityNfcBus) getActivity()).getTappable().readCard(NfcBusInstr.uid(true, result.getCard().getUid()));
            } else {
                Log.i(TAG, "invalid card");
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        cardErrorDialog("Invalid or damaged card, please try another.");
                    }
                });
            }
        }
    }

    private void handleReadCard(final NfcResult result) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                getBaseActivity().alert.dismiss();
                if (cardFunction == ActivityNfcBus.CardFuntion.READ_CARD) {
                    if (result.getStatus() == NfcTappable.NfcStatus.SUCCESS) {
                        Log.i(TAG, "card read successful");
                        ((ActivityNfcBus) getActivity()).setCard(result.getCard());
                        authFor = AuthFor.GetCustomer;
                        ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentTicketList.this);

                    } else {
                        Log.i(TAG, "card read failed");
                        cardErrorDialog("Error reading card, please try again");
                    }
                } else if (cardFunction == ActivityNfcBus.CardFuntion.READ_UID) {
                    if (result.getStatus() == NfcTappable.NfcStatus.SUCCESS) {
                        Log.i(TAG, "uid read successful: " + result.getCard().getBlocks().get(0).getData().substring(0, 14));
                        ((ActivityNfcBus) getActivity()).setCard(result.getCard());
                        ((ActivityNfcBus) getActivity()).setCardUid(result.getCard().getBlocks().get(0).getData().substring(0, 14));
                        if (((ActivityNfcBus) getActivity()).isCardFormatted()) {
                            cardFunction = ActivityNfcBus.CardFuntion.READ_CARD;
                            ((ActivityNfcBus) getActivity()).getTappable().readCard(NfcBusInstr.read(false, result.getCard().getUid()));
                        } else {
                            ((ActivityNfcBus) getActivity()).setCustomerResponseDataMessage(null);
                            ((ActivityNfcBus) getActivity()).gotoCustomerProfile();
                        }
                    } else {
                        Log.i(TAG, "uid read failed");
                        ((ActivityNfcBus) getActivity()).setCard(null);
                        ((ActivityNfcBus) getActivity()).setCardUid(null);
                        cardErrorDialog("Error reading card, please try again");
                    }
                }
            }
        });
    }

    private void handleWriteCard(final NfcResult result) {
        getBaseActivity().alert.dismiss();
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (result.getStatus() == NfcTappable.NfcStatus.SUCCESS) {
                    Log.i(TAG, "card read successful");
                    ((ActivityNfcBus) getActivity()).setCard(result.getCard());
                    writeSuccess = true;
                    authForConfirmCancel();

                } else {
                    Log.i(TAG, "card read failed");
                    String message = "An error occurred writing card, please try again";
                    if (writeAttempt >= MAX_ATTEMPTS) {
                        message = "An error occurred writing card. Transaction will be cancelled.";
                    } else if (result.getStatus() == NfcTappable.NfcStatus.INVALID_CARD) {
                        message = "Incorrect card placed, please try again";
                    }

                    getBaseActivity().firebaseBundle = new Bundle();
                    getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, message);
                    getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_card_error", getBaseActivity().firebaseBundle);

                    getBaseActivity().alert = new BluDroidAlertDialog(getContext());
                    getBaseActivity().alert.setTitle("Error");
                    getBaseActivity().alert.setMessage(message);
                    getBaseActivity().alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            getBaseActivity().alert.dismiss();
                            if (writeAttempt < MAX_ATTEMPTS) {
                                writeAttempt++;
                                promptForCardCancel();
                            } else {
                                writeSuccess = false;
                                authForConfirmCancel();
                            }
                        }
                    });
                    getBaseActivity().alert.show();
                }
            }
        });
    }

    private void authForConfirmCancel() {
        NfcBusRecovery recovery = getBaseActivity().recoveryCacheHandler.createRecoveryCancel(cancelTicketResponseMessage.getDetail().getTransRef(),
                ((ActivityNfcBus) getActivity()).getCardUid(),
                writeSuccess ? "confirmed" : "canceled",
                cancelTicketResponseMessage.getDetail().getTicket().getTicketId(),
                cancelTicketResponseMessage.getDetail().getTransaction().getTransactionId(),
                cancelTicketResponseMessage.getDetail().getSvcData(),
                ((ActivityNfcBus) getActivity()).getUpRoute(((ActivityNfcBus) getActivity()).getCurrentTicket().getRoutes()),
                ((ActivityNfcBus) getActivity()).getDownRoute(((ActivityNfcBus) getActivity()).getCurrentTicket().getRoutes()),
                ((ActivityNfcBus) getActivity()).getCurrentTicket().getCompanyId());
        getBaseActivity().recoveryCacheHandler.cacheRecovery(recovery);

        authFor = AuthFor.ConfirmCancel;
        ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentTicketList.this);
    }

    private void cardErrorDialog(String message) {
        getBaseActivity().firebaseBundle = new Bundle();
        getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, message);
        getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_card_error", getBaseActivity().firebaseBundle);

        getBaseActivity().alert = new BluDroidAlertDialog(getContext());
        getBaseActivity().alert.setTitle("Error");
        getBaseActivity().alert.setMessage(message);
        getBaseActivity().alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                getBaseActivity().alert.dismiss();
                promptForCardCheck();
            }
        });
        getBaseActivity().alert.show();
    }

    public void setAuthFor(AuthFor authFor) {
        this.authFor = authFor;
    }

    public void userConfirmCancelTicket() {
        Log.d(TAG, "Cancel ticket " + ((ActivityNfcBus) getActivity()).getCurrentTicket().getTicketId());

        ticketToCancel = ((ActivityNfcBus) getActivity()).getTicketCacheHandler().getTicketFromCache(((ActivityNfcBus) getActivity()).getCurrentTicket());

        getBaseActivity().alert = new BluDroidAlertDialog(getContext());
        getBaseActivity().alert.setTitle("Cancel Ticket");
        String message;
        if (ticketToCancel != null) {
            String up = ((ActivityNfcBus) getActivity()).getUpRoute(((ActivityNfcBus) getActivity()).getCurrentTicket().getRoutes());
            String down = ((ActivityNfcBus) getActivity()).getDownRoute(((ActivityNfcBus) getActivity()).getCurrentTicket().getRoutes());

            message = "Would you like to cancel this ticket?\n\nUp: " + up;
            if (!down.isEmpty()) {
                message += "\nDown: " + down;
            }
            getBaseActivity().alert.setPositiveOption(getString(R.string.yes), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    getBaseActivity().alert.dismiss();
                    authFor = AuthFor.Cancel;
                    ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentTicketList.this);
                }
            });
            getBaseActivity().alert.setNegativeOption(getString(R.string.no), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    getBaseActivity().alert.dismiss();
                }
            });
        } else {
            message = "This ticket cannot be cancelled.  Please contact Support.";
            getBaseActivity().alert.setNegativeOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    getBaseActivity().alert.dismiss();
                }
            });
        }
        getBaseActivity().alert.setMessage(message);
        getBaseActivity().alert.show();
    }

    private void cancelTicket(String sessionId) {
        getBaseActivity().createProgress(getResources().getString(R.string.cancelling_ticket));
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusCancelTicketRequestMessage req = factory.cancelTicket(sessionId,
                ticketToCancel.getTransRef(),
                ((ActivityNfcBus) getActivity()).getCardUid(),
                ((ActivityNfcBus) getActivity()).getCurrentTicket().getStatus(),
                ticketToCancel.getRefId(),
                ((ActivityNfcBus) getActivity()).getCurrentTicket().getTicketId(),
                Long.parseLong(ticketToCancel.getTransId()),
                ((ActivityNfcBus) getActivity()).getSvc());
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    private void confirmCancelTicket(String sessionId) {
        getBaseActivity().createProgress(R.string.confirming_transaction);
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusConfirmCancelTicketRequestMessage req = factory.confirmCancelTicket(sessionId,
                cancelTicketResponseMessage.getDetail().getTransRef(),
                ((ActivityNfcBus) getActivity()).getCardUid(),
                writeSuccess ? "confirmed" : "canceled",
                cancelTicketResponseMessage.getDetail().getTicket().getTicketId(),
                cancelTicketResponseMessage.getDetail().getTransaction().getTransactionId(),
                cancelTicketResponseMessage.getDetail().getSvcData(),
                ((ActivityNfcBus) getActivity()).getUpRoute(((ActivityNfcBus) getActivity()).getCurrentTicket().getRoutes()),
                ((ActivityNfcBus) getActivity()).getDownRoute(((ActivityNfcBus) getActivity()).getCurrentTicket().getRoutes()),
                ((ActivityNfcBus) getActivity()).getCurrentTicket().getCompanyId());
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    private void confirmCancelError() {
        String result = "TICKET CANCELLATION " + (writeSuccess ? "SUCCESSFUL" : "FAILED");
        String message = result + "\n\nHowever the transaction status could not be sent to the server, and will be retried on the next login.";
        getBaseActivity().createSystemLogoutErrorConfirmation(message, false);

        getBaseActivity().firebaseBundle = new Bundle();
        getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, result + " " + ((ActivityNfcBus) getActivity()).getCardUid());
        getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_confirmcancel_error", getBaseActivity().firebaseBundle);
    }

    private void confirmCancelSuccess() {
        getBaseActivity().firebaseBundle = new Bundle();
        getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, ((ActivityNfcBus) getActivity()).getCardUid());
        getBaseActivity().mFirebaseAnalytics.logEvent(writeSuccess ? "nfcbus_cancel_success" : "nfcbus_cancel_failed", getBaseActivity().firebaseBundle);

        if (writeSuccess) {
            getBaseActivity().gotoMainScreen();
        } else {
            getBaseActivity().alert = new BluDroidAlertDialog(getContext());
            getBaseActivity().alert.setTitle("NFC");
            getBaseActivity().alert.setMessage("Cancellation Failed");
            getBaseActivity().alert.setPositiveOption(getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    getBaseActivity().alert.dismiss();
                    getBaseActivity().gotoMainScreen();
                }
            });
            getBaseActivity().alert.show();
        }
    }

}