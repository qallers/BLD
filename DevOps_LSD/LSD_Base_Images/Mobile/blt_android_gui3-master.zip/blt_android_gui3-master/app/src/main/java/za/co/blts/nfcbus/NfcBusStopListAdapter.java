package za.co.blts.nfcbus;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

class NfcBusStopListAdapter extends ArrayAdapter<Stop> implements View.OnClickListener {
    private final String TAG = this.getClass().getSimpleName();

    private Filter filter;
    private List<Stop> dataSet;

    private WeakReference<BaseActivity> baseActivityWeakReference;
    private int layoutResourceId;

    public NfcBusStopListAdapter(BaseActivity context, int layoutResourceId, List<Stop> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.layoutResourceId = layoutResourceId;
        this.dataSet = dataSet;
        this.baseActivityWeakReference = new WeakReference<>(context);
    }

    @Override
    public void onClick(View v) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            try {
                List<String> tags = (List<String>) v.getTag();
                String id = tags.get(0);
                String name = tags.get(1);
                Log.d(TAG, "id:" + tags.get(0) + " name:" + tags.get(1));
            } catch (Exception ignore) {
                //Unchecked cast or IndexOutOfBounds should never happen
            }
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Stop stop = getItem(position);

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(layoutResourceId, parent, false);
        }

        BluDroidTextView txtName = convertView.findViewById(R.id.txtName);
        txtName.setText(stop.getName());

        return convertView;
    }

    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new NfcBusStopListAdapter.AppFilter<>(dataSet);
        }
        return filter;
    }

    private class AppFilter<T> extends Filter {

        private List<T> sourceObjects;

        AppFilter(List<T> objects) {
            sourceObjects = new ArrayList<>();
            synchronized (this) {
                sourceObjects.addAll(objects);
            }
        }

        @Override
        protected FilterResults performFiltering(CharSequence chars) {
            String filterSeq = chars.toString().toLowerCase();
            FilterResults result = new FilterResults();
            if (filterSeq.length() > 0) {
                ArrayList<T> filter = new ArrayList<>();

                for (T object : sourceObjects) {
                    // the filtering itself:
                    Stop stop = (Stop) object;
                    if (stop.getName().toLowerCase().contains(filterSeq)) {
                        filter.add(object);
                    }
                }
                result.count = filter.size();
                result.values = filter;
            } else {
                // add all objects
                synchronized (this) {
                    result.values = sourceObjects;
                    result.count = sourceObjects.size();
                }
            }
            return result;
        }

        @SuppressWarnings("unchecked")
        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            // NOTE: this function is *always* called from the UI thread.
            List<T> filtered = (List<T>) results.values;
            notifyDataSetChanged();
            clear();
            for (int i = 0, l = filtered.size(); i < l; i++) {
                add((Stop) filtered.get(i));
            }
            notifyDataSetInvalidated();
        }
    }
}

