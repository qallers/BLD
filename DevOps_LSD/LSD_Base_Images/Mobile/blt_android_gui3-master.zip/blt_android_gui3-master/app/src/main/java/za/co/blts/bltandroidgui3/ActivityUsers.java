package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.net.Socket;
import java.util.ArrayList;

import za.co.blt.interfaces.external.messages.users.response.UsersAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.users.response.UsersResponseListMessage;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAddUserInfoDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDialogable;
import za.co.blts.bltandroidgui3.confirmations.BluDroidUpdateUserInfoDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;

public class ActivityUsers extends BaseActivity implements NeedsAEONResults, BluDroidDialogable, View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();

    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        BluDroidButton addUser = findViewById(R.id.add);
        BluDroidButton printUsers = findViewById(R.id.print);

        toolbar = findViewById(R.id.toolbar);
        String title = "Users";
        toolbar.setTitle(title);
        toolbar.setNavigationBackIcon();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        listView = findViewById(R.id.listView);

        authenticateForUsers();

        printUsers.setOnClickListener(this);
        addUser.setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        if (listView != null) listView.setAdapter(null);
        super.onDestroy();
    }

    private void generateUsersList(boolean printUsers) {

        ArrayList<String> userPrintList = new ArrayList<>();

        //
        //User list
        //
        ArrayList<BluDroidUser> usersDataSet = new ArrayList<>();

        userPrintList.add(getResources().getString(R.string.userList));
        userPrintList.add("");
        String PRINT_USERS_FORMAT = "%3s %-20s %4s";
        userPrintList.add(String.format(PRINT_USERS_FORMAT,
                getResources().getString(R.string.num),
                getResources().getString(R.string.name),
                getResources().getString(R.string.type)));


        for (int i = 0; i < usersResponseListMessage.getData().getUsers().size(); i++) {

            String userPin = usersResponseListMessage.getData().getUsers().get(i).getPin().trim();
            if (!userPin.isEmpty()) {
                String number = "";

                if (userPin.length() > 2) {
                    number = userPin.substring(0, 2);
                }


                String pinNumber = userPin.substring(2);

                String userId = usersResponseListMessage.getData().getUsers().get(i).getId().trim();
                String level = usersResponseListMessage.getData().getUsers().get(i).getLevel().trim();
                String name = usersResponseListMessage.getData().getUsers().get(i).getName().trim();
                String userPermissions = usersResponseListMessage.getData().getUsers().get(i).getPermissions().trim();
                String tmp = String.format(PRINT_USERS_FORMAT, number, name, level);

                BluDroidUser user = new BluDroidUser(userId, name, level, pinNumber, userPermissions);

                usersDataSet.add(user);
                userPrintList.add(tmp);

                Log.d(TAG, tmp);
            }

        }

        userPrintList.add(getResources().getString(R.string.printDone));


        userListAdapter = new BluDroidUserListAdapter(this, R.layout.user_row_item, usersDataSet);
        listView.setAdapter(userListAdapter);

        if (printUsers) {
            print(userPrintList);
        }
    }


    @Override
    public void results(Object object) {

        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(Users) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }

        if (object instanceof UsersAuthenticationResponseMessage) {
            dismissProgress();
            Log.d(TAG, "UsersAuthenticationResponseMessage");
            usersAuthenticationResponseMessage = (UsersAuthenticationResponseMessage) object;
            // loginResponseMessage.setSessionId(
            //  usersAuthenticationResponseMessage.getSessionId());
            getUsers();
        } else if (object instanceof UsersResponseListMessage) {
            Log.d(TAG, "UsersResponseListMessage");
            dismissProgress();
            usersResponseListMessage = (UsersResponseListMessage) object;
            if (usersResponseListMessage.getEvent().getEventCode().equals("0")) {
                generateUsersList(false);

                getPermissionTypes();
            } else {
                createSystemErrorConfirmation(usersResponseListMessage, true);
            }

        } else {
            super.results(object);
        }

        if (object != null && !(object instanceof Socket)) {
            firebaseBundle = new Bundle();
            firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            mFirebaseAnalytics.logEvent("aeon_connection", firebaseBundle);
        }
    }

    @Override
    public void affirmativeButton(View view) {

        if (confirmation instanceof BluDroidUpdateUserInfoDialog) {

            BluDroidUpdateUserInfoDialog dialog = (BluDroidUpdateUserInfoDialog) confirmation;

            if (!dialog.getName().equalsIgnoreCase("")) {

                //if (!dialog.getPin().equalsIgnoreCase("")){

                //if(!dialog.getConfirmPin().equalsIgnoreCase("")){

                if (dialog.validate()) {

                    if (dialog.getPin().equals(dialog.getConfirmPin())) {

                        String id = dialog.getUserID();
                        String name = dialog.getName();
                        String pin = dialog.getPin();
                        String level = dialog.getLevel();
                        String userPermissions = dialog.getPermissions();

                        BluDroidUser user = new BluDroidUser(id, name, level, pin, userPermissions);

                        //1 supervisor
                        //2 cashier plus
                        //0 cashier
                        if (user.getUserLevel().equals("2") && permissions.size() == 0) {
                            createAlertDialog("User permissions", "CashierPlus permissions cannot be empty");
                        } else {
                            updateUser(user, permissions);
                        }


                    } else {
                        dialog.setPinError(getResources().getString(R.string.userPinsDontMatch));
                    }
                }
                // }else{
                //    dialog.setConfirmPinError("Please confirm user pin");
                //  }
                //}else{

                // dialog.setPinError("Please enter a user pin");
                // }
            } else {

                dialog.setNameError("Please enter a username");
            }

        } else if (confirmation instanceof BluDroidAddUserInfoDialog) {

            BluDroidAddUserInfoDialog dialog = (BluDroidAddUserInfoDialog) confirmation;

            if (!dialog.getName().equalsIgnoreCase("")) {

                if (!dialog.getPin().equalsIgnoreCase("")) {

                    if (!dialog.getConfirmPin().equalsIgnoreCase("")) {

                        if (dialog.validate()) {

                            if (dialog.getPin().equals(dialog.getConfirmPin())) {


                                String id = dialog.getUserID();
                                String name = dialog.getName();
                                String pin = dialog.getPin();
                                String level = dialog.getLevel();

                                BluDroidUser user = new BluDroidUser(id, name, level, pin, "");

                                //1 supervisor
                                //2 cashier plus
                                //0 cashier
                                if (user.getUserLevel().equals("2") && permissions.size() == 0) {
                                    createAlertDialog("User permissions", "CashierPlus permissions cannot be empty");
                                } else {
                                    addUser(user, permissions);
                                }
                            } else {
                                dialog.setPinError(getResources().getString(R.string.userPinsDontMatch));
                            }
                        }
                    } else {
                        dialog.setConfirmPinError("Please confirm user pin");
                    }
                } else {

                    dialog.setPinError("Please enter a user pin");
                }
            } else {

                dialog.setNameError("Please enter a username");
            }

        }

    }

    @Override
    public void negativeButton(View view) {

        dismissConfirmation();
    }

    @Override
    public void neutralButton(View view) {

    }

    @Override
    public void onClick(View v) {
        logger.info("ActivityUsers " + ((BluDroidButton) v).getText());
        if (v.getId() == R.id.print) {

            generateUsersList(true);

        } else if (v.getId() == R.id.add) {

            createAddUserinfoDialog();
        }
    }

    @Override
    public void onBackPressed() {
        resetTimer();
        closeAeonSocket(5);
        gotoMainScreen();

    }

}
