package za.co.blts.magcard;

import android.util.Log;

import com.sunmi.pay.hardware.aidl.AidlConstants;
import com.sunmi.pay.hardware.aidl.bean.CardInfo;
import com.sunmi.pay.hardware.aidl.readcard.ReadCardCallback;
import com.sunmi.pay.hardware.aidl.readcard.ReadCardOpt;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BluDroidApplication;

/**
 * Created by MasiS on 4/19/2018.
 */

public class P1MagCard implements MagcardInterface {
    private final String TAG = this.getClass().getSimpleName();

    private BluDroidMagCardAsyncReponse delegate = null;
    private String track1, track2, track3;
    private WeakReference<BaseActivity> baseActivityWeakReference;


    //----------------------------------------------------------------------------------------------
    public P1MagCard(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendLedCommand(boolean green, boolean yellow, boolean red) {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setDelegate(BluDroidMagCardAsyncReponse delegate) {
        this.delegate = delegate;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean isConnected() {
        return true;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean isOpen() {
        return true;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void closeAdapter() {

    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean enumerate() {
        return true;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public boolean featureSupported() {
        return true;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void openUsbSerial() {

    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTrack1(String track1) {
        this.track1 = track1;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTrack2(String track2) {
        this.track2 = track2;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTrack3(String track3) {
        this.track3 = track3;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public String getResult() {
        return "getResult()";
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setTracks(List<String> tracks) {
        if (tracks.size() != 3) return; //3 tracks must always be provided
        this.track1 = tracks.get(0);
        this.track2 = tracks.get(1);
        this.track3 = tracks.get(2);
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public List<String> getTracks() {
        List<String> list = new ArrayList<>();
        list.add(this.track1);
        list.add(this.track2);
        list.add(this.track3);
        return list;
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void resetMsr() {
        track1 = track2 = track3 = "";
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendCheckCommsReq() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendModelReq() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setHiCo() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setLoCo() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendHiLoCoStatusReq() {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void eraseCard(boolean trk1, boolean trk2, boolean trk3) {
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void setLedOff() {
    }

    //----------------------------------------------------------------------------------------------
    private void results(final String output) {
        final BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            baseActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (baseActivity.alert != null) {
                        baseActivity.alert.dismiss();
                    }

                    if (output.equalsIgnoreCase("success")) {
                        baseActivity.createAlertDialog("Mag Encoder", baseActivity.magCard.getTracks().toString());
                    } else if (output.equalsIgnoreCase("error")) {
                        BaseActivity.logger.error("MagCard Error");
                    }

                    delegate.processFinish(output);
                }
            });
        }
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendReadCommand() {
        swingCard();
    }

    //----------------------------------------------------------------------------------------------
    @Override
    public void sendWriteCommand() { // will have to be an async task

    }

    //----------------------------------------------------------------------------------------------
    private void swingCard() {
        try {
            ReadCardOpt readCardOpt = BluDroidApplication.mReadCardOpt;
            readCardOpt.checkCard(AidlConstants.CardType.MAGNETIC.getValue(), mReadCardCallback, 5000);  // 10 secs
        } catch (Exception e) {
            BaseActivity.logger.error(e.getMessage(), e);
        }
    }

    //----------------------------------------------------------------------------------------------
    private ReadCardCallback mReadCardCallback = new ReadCardCallback.Stub() {
        @Override
        public void onCardDetected(CardInfo cardInfo) {
            Log.d(TAG, " onCardDetected: " + cardInfo);
            track1 = cardInfo.track1;
            track2 = cardInfo.track2;
            track3 = cardInfo.track3;
            List<String> list = new ArrayList<>();
            list.add(track1);
            list.add(track2);
            list.add(track3);
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                baseActivity.magCard.setTracks(list);
            }
            results(track1 == null && track2 == null && track3 == null ? "failed" : "success"); // should be running on UI thread :)
        }

        @Override
        public void onError(int i, String s) {
            Log.d(TAG, " onError: " + i + " " + s);
        }

        @Override
        public void onStartCheckCard() {
            Log.d(TAG, " onStartCheckCard");
        }
    };
}