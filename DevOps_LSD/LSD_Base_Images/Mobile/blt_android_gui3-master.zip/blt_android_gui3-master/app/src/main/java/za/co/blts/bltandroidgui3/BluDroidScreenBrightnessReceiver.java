package za.co.blts.bltandroidgui3;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.lang.ref.WeakReference;

public class BluDroidScreenBrightnessReceiver extends BroadcastReceiver {


    private WeakReference<BaseActivity> baseActivityWeakReference;


    public BluDroidScreenBrightnessReceiver(BaseActivity baseActivity) {
        this.baseActivityWeakReference = new WeakReference<>(baseActivity);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF) && !(baseActivity instanceof ActivitySetup)) {
                baseActivity.logout();
                baseActivity.firebaseSessionEnd("screen_off");
            }
        }
    }
}
