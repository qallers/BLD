package za.co.blts.bltandroidgui3;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidTextView;

/**
 * Created by NkosanaM on 4/5/2017.
 */

class BluDroidTicketProSeatListAdapter extends ArrayAdapter<TicketProSeatCategory> implements View.OnClickListener {

    private WeakReference<BaseActivity> baseActivityWeakReference;

    private LayoutInflater inflater;

    public BluDroidTicketProSeatListAdapter(BaseActivity context, int layoutResourceId, ArrayList<TicketProSeatCategory> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.baseActivityWeakReference = new WeakReference<>(context);
        inflater = LayoutInflater.from(context);
    }

    @Override
    public void onClick(View v) {
        BaseActivity.logger.info(((BluDroidButton) v).getText());
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TicketProSeatCategory seatCategory = getItem(position);


        BluDroidTicketProSeatListAdapter.ViewHolder holder;
        if (convertView == null) {

            holder = new BluDroidTicketProSeatListAdapter.ViewHolder();

            convertView = inflater.inflate(R.layout.ticketpro_seat_row_item, parent, false);
            holder.txtSeatlabel = convertView.findViewById(R.id.seatLabel);
            holder.txtprice = convertView.findViewById(R.id.fare);
            holder.imgLogo = convertView.findViewById(R.id.logo);
            holder.imgSelected = convertView.findViewById(R.id.selectSeat);
            holder.soldOut = convertView.findViewById(R.id.soldOut);
            convertView.setTag(holder);

        } else {
            holder = (BluDroidTicketProSeatListAdapter.ViewHolder) convertView.getTag();
        }


        String seatLabel = seatCategory.getSeatLabel();
        String pricing = seatCategory.getPricing();
        int iconSelected = seatCategory.getIconSelected();


        holder.txtSeatlabel.setText(seatLabel);
        holder.txtprice.setText(pricing);

        if (seatCategory.getSoldOut().equalsIgnoreCase("true")) {
            holder.soldOut.setVisibility(View.VISIBLE);
        } else {
            holder.soldOut.setVisibility(View.INVISIBLE);
        }

        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            holder.imgLogo.setTag(baseActivity.ticketProResponseEventDetailsMessage.getData().getSmallImage());

            if (holder.imgLogo != null) {

                Picasso picasso = Picasso.get();
                picasso.setIndicatorsEnabled(baseActivity.isDebug());
                picasso
                        .load(baseActivity.ticketProResponseEventDetailsMessage.getData().getSmallImage())
                        .placeholder(R.drawable.ticketpro_loading)
                        .error(R.drawable.ticketpro_loading)
                        .into(holder.imgLogo);
            }
        }

        holder.imgSelected.setImageResource(iconSelected);


        return convertView;
    }

    static class ViewHolder {
        BluDroidTextView txtSeatlabel;
        TextView txtprice;
        ImageView imgLogo;
        ImageView imgSelected;
        ImageView soldOut;
    }

}

