package za.co.blts.bltandroidgui3.widgets;

import android.content.Context;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.util.Log;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidTiEditText extends BluDroidIntegerEditText {
    private final String TAG = this.getClass().getSimpleName();

    private void setUpSGC() {
        InputFilter[] inputFilters = new InputFilter[1];
        inputFilters[0] = new InputFilter.LengthFilter(2);
        setFilters(inputFilters);
    }

    public BluDroidTiEditText(BaseActivity context) {
        super(context);
        setUpSGC();

    }

    public BluDroidTiEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpSGC();

    }

    public boolean validate() {
        Log.d(TAG, "validate");
        //BaseActivity.logger.info(": validate()");
        if (!(getText().toString().length() > 0) || (getText().toString().length() < 2)) {
            setErrorMessage(R.string.tiError);

            return false;
        } else {
            removeErrorMessage();
            return true;
        }
    }

}

