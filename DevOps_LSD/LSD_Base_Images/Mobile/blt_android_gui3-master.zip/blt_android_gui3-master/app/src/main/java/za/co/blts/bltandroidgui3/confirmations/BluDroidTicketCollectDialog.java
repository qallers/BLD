package za.co.blts.bltandroidgui3.confirmations;

import android.app.Dialog;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidMandatoryEditText;
import za.co.blts.bltandroidgui3.widgets.BluDroidRelativeLayout;

/**
 * Created by NkosanaM on 7/26/2018.
 */

public class BluDroidTicketCollectDialog extends Dialog implements View.OnClickListener {
    private final String TAG = this.getClass().getSimpleName();
    private WeakReference<BaseActivity> baseActivityWeakReference;
    private BaseFragment baseFragment;
    private BluDroidMandatoryEditText referenceNumber;
    private BluDroidRelativeLayout layout;

    public BluDroidTicketCollectDialog(BaseFragment baseFragment) {
        super(baseFragment.getActivity());
        this.baseActivityWeakReference = new WeakReference<>(baseFragment.getBaseActivity());
        this.baseFragment = baseFragment;
        String dialog = this.getClass().getSimpleName();
        this.baseFragment.getBaseActivity().crashLog("Dialog", dialog);
        this.baseFragment.getBaseActivity().mFirebaseAnalytics.setCurrentScreen(baseFragment.getBaseActivity(), dialog, null);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseActivity baseActivity = baseActivityWeakReference.get();
        baseActivity.mFirebaseAnalytics.setCurrentScreen(baseActivity, TAG, null);
        if (baseActivity != null) {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            setContentView(R.layout.collect_ticket_dialog);
            layout = findViewById(R.id.layout);
            layout.setContext(baseActivity);
            layout.setup();

            baseActivity.isCollectionScreen = true;
            BluDroidButton cancel = findViewById(R.id.negativeButton);
            BluDroidButton collect = findViewById(R.id.affirmativeButton);
            referenceNumber = findViewById(R.id.reference_number);
            cancel.setOnClickListener(this);
            collect.setOnClickListener(this);
            referenceNumber.setOnKeyListener(new View.OnKeyListener() {
                @Override
                public boolean onKey(View view, int i, KeyEvent keyEvent) {
                    return false;
                }
            });
        }
    }

    @Override
    public void onClick(View v) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            switch (v.getId()) {
                case R.id.negativeButton:
                    dismiss();
                    baseActivity.isCollectionScreen = false;
                    break;
                case R.id.affirmativeButton:
                    if (layout.validate()) {
                        baseFragment.collectRefNumber = referenceNumber.getText().toString();
                        baseFragment.authenticateWithTicketPro();
                        dismiss();
                    }
                    break;
                default:
                    break;
            }
        }
    }
}