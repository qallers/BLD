package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.cardviews.CardviewVoucherMenu;
import za.co.blts.bltandroidgui3.widgets.BluRecyclerView;

/**
 * Created by warrenm on 2016/10/03.
 */

public class FragmentIthubaMenu extends VoucherRecycler {
    private final String TAG = this.getClass().getSimpleName();


    public FragmentIthubaMenu() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_ithuba_menu, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        String title = getActivity().getResources().getString(R.string.ithuba);
        getActivity().setTitle(title);

        configureRecycler();
    }

    private void configureRecycler() {
        BluRecyclerView recycler = getActivity().findViewById(R.id.billRecycler);
        recycler.setHasFixedSize(true);

        List<CardviewDataObject> list = allListItems();
        grid = new GridLayoutManager(getActivity(), 2);

        RecyclerView.LayoutManager manager = grid;


        recycler.setHasFixedSize(true);
        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getActivity(), R.dimen.item_offset);
        recycler.addItemDecoration(itemDecoration);

        recycler.setLayoutManager(manager);

        BluRecyclerMenuAdapter adapter = new BluRecyclerMenuAdapter(getActivity(), list);

        recycler.setAdapter(adapter);
    }

    private List<CardviewDataObject> allListItems() {
        List<CardviewDataObject> allItems = new ArrayList<>();

        allItems.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ithuba_lotto_card, R.color.ithuba_lotto, "Lotto", "Lotto"));
        allItems.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ithuba_powerball_card, R.color.ithuba_powerball, "Powerball", "Powerball"));
        allItems.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ithuba_lotto_quickpick_card, R.color.ithuba_lotto, "Lotto Quickpick", "Lotto Quickpick"));
        allItems.add(new CardviewVoucherMenu(getBaseActivity(), R.drawable.ithuba_powerball_quickpick_card, R.color.ithuba_powerball, "Powerball Quickpick", "Powerball Quickpick"));

        return allItems;
    }

    @Override
    public boolean onBackPressed() {

        if (getBaseActivity().navigatedFromFavourites) {
            getBaseActivity().gotoMainScreen();
        } else if (getBaseActivity().navigatedFromSearch) {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentSearch(), "FragmentSearch").commit();
        } else {
            getBaseActivity().baseFm.beginTransaction().replace(R.id.content_frame, new FragmentVouchersMenu(), "FragmentVouchersMenu").commit();
        }
        return true;
    }
}
