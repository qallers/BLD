package za.co.blts.bltandroidgui3.widgets;


import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;

import java.lang.ref.WeakReference;

import za.co.blts.bltandroidgui3.BaseActivity;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidErrorTextView extends BluDroidTextView implements BluDroidSetupable {
    @SuppressWarnings("FieldCanBeLocal")
    private final String TAG = this.getClass().getSimpleName();

    private void changeTextSize() {
        try {
            BaseActivity baseActivity = baseActivityWeakReference.get();
            if (baseActivity != null) {
                int textSize = (baseActivity.getSkinResources().getTextSize() * 2) / 3;
                setTextSize(textSize);
            }
        } catch (Exception ignored) {
        }
    }

    public void setup() {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            changeTextSize();
            setTextColor(baseActivity.getSkinResources().getErrorColor());
        }
    }

    public BluDroidErrorTextView(BaseActivity context) {
        super(context);
        changeTextSize();
    }

    public BluDroidErrorTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (context instanceof BaseActivity) {
            try {
                this.baseActivityWeakReference = new WeakReference<>((BaseActivity) context);
                setup();
            } catch (Exception exception) {
                Log.d(TAG, "BluDroidErrorTextView exception " + exception);
            }
        }
    }


}

