package za.co.blts.bltandroidgui3;

import android.graphics.Bitmap;

import java.text.Normalizer;
import java.util.List;

import static za.co.blts.bltandroidgui3.PrintUtil.setAlignment;
import static za.co.blts.bltandroidgui3.PrintUtil.setBold;
import static za.co.blts.bltandroidgui3.SmartPrinter.ALIGN_CENTER;
import static za.co.blts.bltandroidgui3.SmartPrinter.ALIGN_RIGHT;
import static za.co.blts.bltandroidgui3.SmartPrinter.FONT_LARGE;

class PrintLines {

    private static CitaqSmartPrinter citaqSmartPrinter = null;

    //----------------------------------------------------------------------------------------------
    public static void setCitaqSmartPrinter(CitaqSmartPrinter printer) {
        citaqSmartPrinter = printer;
    }

    //----------------------------------------------------------------------------------------------
    public static void printStrings(Bitmap logo, List<String> lines, Bitmap barcode, String barcodeNumber) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i) != null)
                sb.append(lines.get(i)).append("\n\r");
        }
        String tmp = Normalizer.normalize(sb.toString(), Normalizer.Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");

        if (logo != null) {
            PrintUtil.printPicture(logo);
            PrintUtil.printBytes("\n".getBytes());
        }

        //
        // set height of line
        //
        PrintUtil.printBytes(PrintUtil.setLineH(30));

        //
        // char size
        //
        PrintUtil.printBytes(PrintUtil.setWH('1'));

        PrintUtil.printString(tmp, "ISO-8859-1");

        if (barcode != null) {
            PrintUtil.printPicture(barcode);
        }

        PrintUtil.printBytes("\n".getBytes());
        PrintUtil.printBytes(barcodeNumber.getBytes());
        PrintUtil.printBytes("\n".getBytes());

        if (citaqSmartPrinter != null && citaqSmartPrinter.paperCutter) {
            PrintUtil.printBytes(PrintUtil.CutPaper());
        }
    }

    public static void printSmartStrings(Bitmap logo, List<String> lines, Bitmap barcode, String barcodeNumber) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i) != null)
                sb.append(lines.get(i)).append("\n\r");
        }
        String tmp = Normalizer.normalize(sb.toString(), Normalizer.Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");

        if (logo != null) {
            PrintUtil.printPicture(logo);
        }

        //
        // set height of line
        //
        PrintUtil.printBytes(PrintUtil.setLineH(30));

        //
        // char size
        //
        PrintUtil.printBytes(PrintUtil.setWH('1'));

        PrintUtil.printString(tmp, "ISO-8859-1");

        if (barcode != null) {
            PrintUtil.printPicture(barcode);
        }

        if (!barcodeNumber.isEmpty()) {
            PrintUtil.printBytes(barcodeNumber.getBytes());
            PrintUtil.printBytes("\n".getBytes());
        }

        if (citaqSmartPrinter != null && citaqSmartPrinter.paperCutter) {
            PrintUtil.printBytes(PrintUtil.CutPaper());
        }
    }

    public static void printText(String text, int align, int size, boolean bold) {

        char w = '1';
        int h = 30;
        char alignment = '1';

        if (size == FONT_LARGE) {
            w = '4';
        }
        switch (align) {
            case ALIGN_CENTER:
                alignment = '2';
                break;

            case ALIGN_RIGHT:
                alignment = '3';
                break;
        }

        String tmp = Normalizer.normalize(text + "\n", Normalizer.Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");

        PrintUtil.printBytes(setAlignment(alignment));
        PrintUtil.printBytes(setBold(bold));
        PrintUtil.printBytes(PrintUtil.setLineH(h));
        PrintUtil.printBytes(PrintUtil.setWH(w));
        PrintUtil.printString(tmp, "ISO-8859-1");
        //restore to normal, left align, no bold
        PrintUtil.printBytes(setBold(false));
        PrintUtil.printBytes(setAlignment('1'));
        PrintUtil.printBytes(PrintUtil.setLineH(h));
        PrintUtil.printBytes(PrintUtil.setWH('1'));
    }
}

