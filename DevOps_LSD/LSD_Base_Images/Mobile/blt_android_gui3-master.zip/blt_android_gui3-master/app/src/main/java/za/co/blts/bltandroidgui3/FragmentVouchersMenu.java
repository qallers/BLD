package za.co.blts.bltandroidgui3;

import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.GridLayoutManager;

/**
 * Created by warrenm on 2016/10/03.
 */

public class FragmentVouchersMenu extends VoucherRecycler {

    public FragmentVouchersMenu() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_vouchers, container, false);
        recycler = rootView.findViewById(R.id.bluRecycler);

        if (Build.MODEL.startsWith("CITAQ")) {
            grid = new GridLayoutManager(getActivity(), 3);
        }

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //
        //Class added for Voucher Other Menu
        //
        String title = getActivity().getResources().getString(R.string.vouchers);
        getActivity().setTitle(title);
        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();

        // if(((BaseActivity) getActivity()).voucherListResponseMessage != null){
        populateScreen();
        // }
    }

    private void populateScreen() {
        setupMenuRecycler("VoucherOther");
    }

    @Override
    public boolean onBackPressed() {

        getBaseActivity().gotoMainScreen();

        return true;
    }
}