package za.co.blts.bltandroidgui3;

/**
 * Created by NkosanaM on 4/5/2017.
 */

public class BluDroidUser {

    private String id;
    private String name;
    private String userLevel;
    private String pin;
    private String permissions;

    public BluDroidUser(String id, String name, String userLevel, String pin, String permissions) {
        this.id = id;
        this.name = name;
        this.userLevel = userLevel;
        this.pin = pin;
        this.permissions = permissions;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(String level) {
        this.userLevel = level;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getPermissions() {
        return permissions;
    }

    public void setPermissions(String permissions) {
        this.permissions = permissions;
    }


}
