package za.co.blts.bltandroidgui3;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.io.File;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import sunmi.paylib.SunmiPayKernel;
import za.co.blt.interfaces.external.factories.AirtimeTopupRequestFactory;
import za.co.blt.interfaces.external.factories.BundlesRequestFactory;
import za.co.blt.interfaces.external.factories.ConfirmMeterRequestFactory;
import za.co.blt.interfaces.external.factories.ElectricityRequestFactory;
import za.co.blt.interfaces.external.factories.ElectricityVoucherRequestFactory;
import za.co.blt.interfaces.external.factories.EskomDirectReprintRequestFactory;
import za.co.blt.interfaces.external.factories.MultipleVouchersRequestFactory;
import za.co.blt.interfaces.external.factories.VoucherListRequestFactory;
import za.co.blt.interfaces.external.factories.VoucherRequestFactory;
import za.co.blt.interfaces.external.messages.airtimetopup.request.AirtimeTopupRequestMessage;
import za.co.blt.interfaces.external.messages.airtimetopup.request.AirtimeTopupRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.airtimetopup.request.AirtimeTopupRequestPurchaseMessage;
import za.co.blt.interfaces.external.messages.airtimetopup.request.WalletTopupRequestPurchaseMessage;
import za.co.blt.interfaces.external.messages.airtimetopup.response.AirtimeTopupResponseMessage;
import za.co.blt.interfaces.external.messages.airtimetopup.response.AirtimeTopupResponsePrintedMessage;
import za.co.blt.interfaces.external.messages.airtimetopup.response.AirtimeTopupResponsePurchaseMessage;
import za.co.blt.interfaces.external.messages.bundles.request.BundlesAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.bundles.request.BundlesRequestDoBundleTopupMessage;
import za.co.blt.interfaces.external.messages.bundles.request.BundlesRequestGetProductListMessage;
import za.co.blt.interfaces.external.messages.bundles.request.BundlesRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseDoBundleTopupMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponseGetProductListMessage;
import za.co.blt.interfaces.external.messages.bundles.response.BundlesResponsePrintedMessage;
import za.co.blt.interfaces.external.messages.confirmmeter.request.ConfirmMeterRequestMessage;
import za.co.blt.interfaces.external.messages.confirmmeter.response.ConfirmMeterResponseMessage;
import za.co.blt.interfaces.external.messages.electricity.request.ElectricityAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.electricity.response.ElectricityAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.request.ElectricityVoucherRequestMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.request.ElectricityVoucherRequestSoldMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponseMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponsePrintedMessage;
import za.co.blt.interfaces.external.messages.electricityvoucher.response.ElectricityVoucherResponseSoldMessage;
import za.co.blt.interfaces.external.messages.eskomdirectreprint.request.EskomDirectReprintAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.eskomdirectreprint.request.EskomDirectReprintRequestMessage;
import za.co.blt.interfaces.external.messages.eskomdirectreprint.response.EskomDirectReprintAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.eskomdirectreprint.response.EskomDirectReprintResponseMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseDataMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseGroupMessage;
import za.co.blt.interfaces.external.messages.login.response.LoginResponseTransactionTypeMessage;
import za.co.blt.interfaces.external.messages.multiplevouchers.request.MultipleVouchersRequestPrintedMessage;
import za.co.blt.interfaces.external.messages.multiplevouchers.response.MultipleVouchersAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.multiplevouchers.response.MultipleVouchersResponsePrintedMessage;
import za.co.blt.interfaces.external.messages.voucher.request.VoucherAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.voucher.response.VoucherAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.voucherlist.request.VoucherListRequestMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseMessage;
import za.co.blts.bltandroidgui3.confirmations.BluDroidAlertDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidDialogable;
import za.co.blts.bltandroidgui3.confirmations.BluDroidElectricityPurchaseConfirmationDialog;
import za.co.blts.bltandroidgui3.confirmations.BluDroidEskomTrialPurchaseDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewBundleDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewElectricityDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewMultipleVouchersDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.BluDroidSlipPreviewTopupDialog;
import za.co.blts.bltandroidgui3.confirmations.printPreview.PrintJob;
import za.co.blts.bltandroidgui3.longhaul.cancellations.CancelTicket;
import za.co.blts.bltandroidgui3.longhaul.cancellations.FragmentBusTicketCancellations;
import za.co.blts.bltandroidgui3.longhaul.cancellations.TicketCacheHandler;
import za.co.blts.loyalty.ExternalNFCCard;
import za.co.blts.loyalty.MockNFCCard;
import za.co.blts.loyalty.NexgoN3NFCCard;
import za.co.blts.loyalty.P1NFCCard;
import za.co.blts.magcard.BluDroidMagCardAsyncReponse;
import za.co.blts.magcard.MagCard;
import za.co.blts.magcard.MagCardData;
import za.co.blts.magcard.NexgoN3MagCard;
import za.co.blts.magcard.P1MagCard;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_CASH_DRAWER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DISK_IMAGE_CACHE_CLEARED_DATE;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_MAG_READER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_PRINT_MERCHANT_VOUCHER;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_TRUE;

public class ActivityMain extends BaseActivity implements NeedsAEONResults, BluDroidDialogable, BluDroidMagCardAsyncReponse {

    private final String TAG = this.getClass().getSimpleName();

    private Boolean firstTimeRun = true;

    protected enum STATUS {
        NONE,
        AUTHENTICATING_FOR_VOUCHER_LIST,
        AUTHENTICATING_FOR_VOUCHER,
        REQUESTING_VOUCHER_LIST,
        PRINTING_VOUCHER,
        AUTHENTICATING_FOR_BUNDLE_LIST,
        AUTHENTICATING_FOR_BUNDLE
    }

    private STATUS status = STATUS.NONE;

    private String stockId;

    private String productCode;
    private String cellNumber;
    private String municName;
    private String purchaseType;

    //EskomDirect Flags
    private String sgc = "";
    private String tt = "";
    private String ti = "";
    private String krn = "";
    private String alg = "";

    private BluDroidAlertDialog alert = null;
    private BluDroidUpdateMeterKeysAlertDialog alertDialog = null;

    //Electricity
    //
    private ElectricityAuthenticationResponseMessage electricityAuthenticationResponseMessage = null;
    private ConfirmMeterResponseMessage confirmMeterResponseMessage = null;

    //
    //Reprint
    //

    private EskomDirectReprintAuthenticationResponseMessage eskomDirectReprintAuthenticationResponseMessage;

    private static boolean alreadyConnected = false;
    private int count;
    private SunmiPayKernel mSunmiPayKernel = null;


    //----------------------------------------------------------------------------------------------

    private void conn() {
        if (!alreadyConnected) {
//            mSunmiPayKernel = SunmiPayKernel.getInstance();
//            mSunmiPayKernel.connectPayService(getApplicationContext(), mConnCallback);
            alreadyConnected = true;
        }
    }

    private SunmiPayKernel.ConnCallback mConnCallback = new SunmiPayKernel.ConnCallback() {
        @Override
        public void onServiceConnected() {
            try {
                //Toast.makeText(ActivityMain.this, "onServiceConnected()", Toast.LENGTH_SHORT).show();
                BluDroidApplication.mReadCardOpt = mSunmiPayKernel.mReadCardOpt;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected() {
        }
    };

    //----------------------------------------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        printQueue = 0;
        if (loginResponseMessage != null) {
            loginResponseMessage.getData().setPrintQueue("0");
        } else {
            //loginResponseMessage should never be null? However Crashlytics has reported 2 NPE's
//            createNetworkErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, "An error occurred on login.  Please login again.");
            Toast.makeText(this, "An error occurred on login.  Please login again.", Toast.LENGTH_SHORT).show();
            logout();
            firebaseSessionEnd("login_error");
            return;
        }
        autoLoginRetryCap = 2;

        setUpMagEncoderAndNFC();

        if (bundlesResponseGetProductListMessages == null) {
            bundlesResponseGetProductListMessages = new HashMap<>();
        }
        if (loginResponseMessage != null) {
            userLevel = loginResponseMessage.getData().getUserLevel();
        } else {
            userLevel = "-1";
        }

        if (bundlesResponseGetProductListMessages == null) {
            bundlesResponseGetProductListMessages = new HashMap<>();
        }
        bundleProviders = getAllBundleProviders();

        Log.d(TAG, "loginRequestMessage " + loginRequestMessage);
        Log.d(TAG, "loginResponseMessage " + loginResponseMessage);

        menuMap = new LinkedHashMap<>();

        menuMap.put(BluDroidMenuItems.MENU_FAVOURITES.toString(), new ArrayList<String>());
        menuMap.put(BluDroidMenuItems.MENU_AIRTIME.toString(), new ArrayList<String>());
        menuMap.put(BluDroidMenuItems.MENU_DATA.toString(), new ArrayList<String>());
        menuMap.put(BluDroidMenuItems.MENU_ELECTRICITY.toString(), new ArrayList<String>());
        menuMap.put(BluDroidMenuItems.MENU_TRANSACT.toString(), new ArrayList<String>());
        menuMap.put(BluDroidMenuItems.MENU_VOUCHERS.toString(), new ArrayList<String>());
        menuMap.put(BluDroidMenuItems.MENU_TICKETS.toString(), new ArrayList<String>());
        menuMap.put(BluDroidMenuItems.MENU_RICA.toString(), new ArrayList<String>());
        menuMap.put(BluDroidMenuItems.MENU_SEARCH.toString(), new ArrayList<String>());

        addToMenuMap(BluDroidMenuItems.MENU_FAVOURITES.toString(), "favourites");
        addToMenuMap(BluDroidMenuItems.MENU_SEARCH.toString(), "search");

        final LoginResponseDataMessage data = loginResponseMessage.getData();

        for (int i = 0; i < data.getTransactionTypes().size(); i++) {
            LoginResponseGroupMessage group = data.getTransactionTypes().get(i);

            for (int j = 0; j < group.getTransactionTypes().size(); j++) {
                LoginResponseTransactionTypeMessage transactionType = group.getTransactionTypes().get(j);

//                Log.d(TAG, "Transaction Type: " + transactionType);

                String transactionName = transactionType.getDisplayName().toLowerCase();
                String type = transactionType.getType().toLowerCase();

                switch (type) {
                    case "vouchers":
                    case "topup":
                    case "bundles":
                        addToMenuMap(BluDroidMenuItems.MENU_AIRTIME.toString(), type);
                        addToMenuMap(BluDroidMenuItems.MENU_DATA.toString(), type);
                        addToMenuMap(BluDroidMenuItems.MENU_VOUCHERS.toString(), type);
                        addToMenuMap(BluDroidMenuItems.MENU_ELECTRICITY.toString(), type);
                        break;

                    case "electricity":
                        addToMenuMap(BluDroidMenuItems.MENU_ELECTRICITY.toString(), type);
                        break;

                    case "payments":
                        addToMenuMap(BluDroidMenuItems.MENU_TRANSACT.toString(), type);
                        break;

                    case "tickets":
                        if (transactionName.equalsIgnoreCase("TKP_TICKET")
                                || loginResponseMessage.getData().canDoCityToCity()
                                || loginResponseMessage.getData().canDoEldo()
                                || loginResponseMessage.getData().canDoTranslux()
                                || loginResponseMessage.getData().canDoIntercape()) {
                            addToMenuMap(BluDroidMenuItems.MENU_TICKETS.toString(), type);
                        }
                        break;

                    case "other":
                        if (transactionName.toLowerCase().equals("rica")) {
                            addToMenuMap(BluDroidMenuItems.MENU_RICA.toString(), type);
                        } else {
                            if (!menuMap.containsKey(BluDroidMenuItems.MENU_VOUCHERS)) {
                                addToMenuMap(BluDroidMenuItems.MENU_VOUCHERS.toString(), type);
                            }
                        }
                        break;

                    default:
                        break;
                }
            }
        }

        removeUnusedMenuItems();

        List<RowItem> menuItems = new LinkedList<>();
        for (String key : menuMap.keySet()) {
            int menuIcon;
            menuIcon = getResources().getIdentifier(key.toLowerCase(), "drawable", getPackageName());

            Log.v(TAG, "KEY: " + key + " id:" + menuIcon);

            if (menuIcon > 0) {
                Log.v(TAG, "KEY-In IF: " + key);
                RowItem item = new RowItem(key, menuIcon);
                menuItems.add(item);
            }

        }

        Date now = new Date();
        Date voucherCacheDate = dateLastVoucherCache();
        Log.d(TAG, "cache expired " + ((now.getTime() - voucherCacheDate.getTime()) > CACHE_12_HOURS));
        Log.d(TAG, "maxCacheAgeMillis " + CACHE_12_HOURS);
        Log.d(TAG, "now.getTime() " + now.getTime());
        Log.d(TAG, "now " + now);
        Log.d(TAG, "voucherCacheDate.getTime() " + voucherCacheDate.getTime());
        Log.d(TAG, "voucherCacheDate " + voucherCacheDate);
        Log.d(TAG, "diff is " + (now.getTime() - voucherCacheDate.getTime()));

        if (loginResponseMessage.getData().canDoVoucher()) {
            if ((voucherListResponseMessage == null) || ((now.getTime() - voucherCacheDate.getTime()) > CACHE_12_HOURS)) {
                status = STATUS.AUTHENTICATING_FOR_VOUCHER_LIST;
                authenticateForVouchers();
            } else
                results(voucherAuthenticationResponseMessage);
        } else {
            boolean payments = false;
            //get all other transactionTypes
            for (int i = 0; i < data.getTransactionTypes().size() && !payments; i++) {
                LoginResponseGroupMessage group = data.getTransactionTypes().get(i);

                for (int j = 0; j < group.getTransactionTypes().size(); j++) {
                    LoginResponseTransactionTypeMessage transactionType = group.getTransactionTypes().get(j);
                    String type = transactionType.getType().toLowerCase();
                    if (type.equals("payments")) {
                        payments = true;
                        break;
                    }
                }
            }
            if (payments) {
                authenticateForBillPayments();
            } else {
                retryFailedCancellationsAndTenders();
            }
        }

        checkPicassoImageDiskCacheExpired();

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        updateFavouritesIfNecessary();

        Fragment favouritesFragment = new FragmentFavourites();

        if (firstTimeRun) {
            baseFm.beginTransaction().add(R.id.content_frame, favouritesFragment, "FragmentFavourites").commit();
            firstTimeRun = false;
        }

        boolean loadFavourites = getIntent().getBooleanExtra("loadFavourites", Boolean.FALSE);
        String previousFragmentName = "";
        Fragment previousFragment = null;

        //LB if (getIntent().getExtras().getString("previousFragment") != null) {
        if (getIntent().getStringExtra("previousFragment") != null) {
            previousFragmentName = getIntent().getExtras().getString("previousFragment");
            try {
                previousFragment = Fragment.instantiate(this, "za.co.blts.bltandroidgui3." + "" + previousFragmentName);
            } catch (Exception e) {
                Log.e("Main", e.getMessage());
            }
        }

        if (loadFavourites && !firstTimeRun) {
            baseFm.beginTransaction().replace(R.id.content_frame, favouritesFragment, "FragmentFavourites").commit();
        } else {
            if (previousFragment != null) {
                baseFm.beginTransaction().replace(R.id.content_frame, previousFragment, previousFragmentName).commit();
            }
        }
    }

    private void setUpMagEncoderAndNFC() {
        if (Build.MODEL.startsWith("CITAQ")) {
            magCard = new MagCard(this);
            nfcCard = new ExternalNFCCard(this);

        } else if (Build.MODEL.startsWith("N3")) {
            magCard = new NexgoN3MagCard(this);
            nfcCard = new NexgoN3NFCCard(this);
        } else if (Build.MODEL.startsWith("P1")) {
            //use external mag encoder
            if (getPreference(PREF_MAG_READER).equals(PREF_TRUE)) {
                magCard = new MagCard(this);
            } else {
                //use internal mag encoder
                conn();
                magCard = new P1MagCard(this);
            }

            nfcCard = new P1NFCCard(this);
        } else {
            nfcCard = new MockNFCCard();
        }


    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        View view = getCurrentFocus();
        if (view != null && (ev.getAction() == MotionEvent.ACTION_UP || ev.getAction() == MotionEvent.ACTION_MOVE) && view instanceof EditText && !view.getClass().getName().startsWith("android.webkit.")) {
            int[] scrcoords = new int[2];
            view.getLocationOnScreen(scrcoords);
            float x = ev.getRawX() + view.getLeft() - scrcoords[0];
            float y = ev.getRawY() + view.getTop() - scrcoords[1];
            if (x < view.getLeft() || x > view.getRight() || y < view.getTop() || y > view.getBottom())
                ((InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow((this.getWindow().getDecorView().getApplicationWindowToken()), 0);
        }
        return super.dispatchTouchEvent(ev);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Fragment fragment;

        resetTimer();

        switch (item.getItemId()) {
            case R.id.eventCart:
                gotoFragment(new FragmentTicketProViewCart(), "FragmentTicketProViewCart");
                return true;

            case R.id.eventCacheRefresh:
                removeTicketproCategoriesCache();
                removeTicketproAllEventsCache();
                ticketProAuthenticationResponseMessage = null;
                gotoFragment(new FragmentTicketProCategories(), "FragmentTicketProCategories");
                return true;

            case R.id.users:
                gotoUsersScreen();
                return true;

            case R.id.reports:
                gotoReportsScreen();
                return true;

            case R.id.endShift:
                mustgetShiftList = false;

                File[] notTenderedFiles = getNotTendered();
                if (notTenderedFiles.length > 0) {
                    alert = createCustomAlertDialog("Untendered Items", "There are untendered items still pending and you cannot end shift" +
                            " before all these items are tendered. Do you want to Tender now");
                    alert.setPositiveOption("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            isClearingUntenderdState = true;
                            emptyBasket();
                        }
                    });
                    alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alert.show();

                } else {
                    isEndShiftState = true;
                    authenticateForReports();
                }
                return true;

            case R.id.openCashDrawer:
                Log.d(TAG, "Opening Cash Drawer");
                CashDrawerUtil.openCash();
                return true;

            case R.id.emerTopUp:
                gotoEmergencyTopUpScreen();
                return true;

            case R.id.userSettingsMenuItem:
                gotoUserSettingsScreen();
                return true;

            case R.id.configureFavourites:
                fragment = new FragmentConfirmConfigFavourites();
                baseFm.beginTransaction().replace(R.id.content_frame, fragment).commit();
                return true;

            case R.id.calculator:
                gotoCalculatorScreen();
                return true;

            case R.id.nfcOnBar:
                gotoNFCGetConsumerProfile("NFCNFCConsumerFavourites");
                return true;

            case R.id.nfcLogoutOnBar:
                clearNFCActiveConsumer(true);
                return true;

            case R.id.nfcRegistration:
                gotoNFCRegistrationScreen();
                return true;

            case R.id.nfcEdit:
                gotoNFCGetConsumerProfile("NFCEditConsumerProfile");
                return true;

            case R.id.nfcLostCard:
                gotoNFCGetConsumerProfile("NFCDeactivateCardScreen");
                return true;

            case R.id.nfcDeactivateProfile:
                gotoNFCGetConsumerProfile("NFCDeactivateProfileScreen");
                return true;

            case R.id.busTicketsReprints:
                fragmentBusTicketsReprints = new FragmentBusTicketsReprints();
                gotoFragment(fragmentBusTicketsReprints, "FragmentBusTicketsReprints");
                return true;

            case R.id.busTicketsCancellation:
                Log.d("TicketCache", "getting cached tickets for cancellation");
                TicketCacheHandler ticketCacheHandler = new TicketCacheHandler(ticketCancelCacheDir);
                List<CancelTicket> tickets = ticketCacheHandler.getCachedTickets();
                Log.d("TicketCache", "number of tickets cached: " + tickets.size());
                for (CancelTicket t : tickets) {
                    Log.d("TicketCache", t.toString());
                }


                fragment = new FragmentBusTicketCancellations();
                gotoFragment(fragment, "FragmentBusTicketCancellations");
                return true;

            case R.id.logout:
                logger.info("Logout: User logging out");
                firebaseSessionEnd("manual");
                logout();
                return true;

            case R.id.crashButton:
                crash();
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }

    }


    private void addToMenuMap(String key, String value) {
        ArrayList<String> list;
        if (menuMap.containsKey(key)) {
            list = menuMap.get(key);
            list.add(value);
        } else {
            list = new ArrayList<>();
            list.add(value);
            menuMap.put(key, list);
        }
    }

    private void removeUnusedMenuItems() {
        Iterator<Map.Entry<String, ArrayList<String>>> iter = menuMap.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<String, ArrayList<String>> entry = iter.next();
            if (entry.getValue().size() == 0) {
                iter.remove();
            }
        }
    }

    public void authenticateForPinlessTopup(String topupName, String cellNumber, String amount) {

        createProgress(R.string.authenticating);
        this.amount = amount;
        this.cellNumber = cellNumber;
        AirtimeTopupRequestFactory factory = new AirtimeTopupRequestFactory();
        AirtimeTopupRequestMessage request = factory.create(
                loginResponseMessage.getData().getUserPin(),
                getPreference(PREF_DEVICE_ID),
                getPreference(PREF_DEVICE_SER),
                topupName);

        if (completeConsumerProfile != null) {
            request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
        }

        startAEONAsyncTask(this, socket, request);
    }

    private void purchasePinlessTopup(AirtimeTopupResponseMessage response) {
        Date now = new Date();
        AirtimeTopupRequestFactory factory = new AirtimeTopupRequestFactory();
        AirtimeTopupRequestPurchaseMessage request = factory.purchase(response,
                "supplier",
                getPreference(PREF_DEVICE_ID) + "_" + now.getTime(),
                cellNumber,
                amount,
                "1", airtimePlusPlayed);

        startAEONAsyncTask(this, socket, request);
    }

    private void purchaseWalletTopup(AirtimeTopupResponseMessage response) {
        Date now = new Date();
        AirtimeTopupRequestFactory factory = new AirtimeTopupRequestFactory();
        WalletTopupRequestPurchaseMessage request = factory.purchaseWalletTopUp(response,
                getPreference(PREF_DEVICE_ID) + "_" + now.getTime(),
                cellNumber,
                amount, "1");

        startAEONAsyncTask(this, socket, request);
    }

    private void setPrintedPinlessTopup(AirtimeTopupResponsePurchaseMessage response) {
        createProgress(R.string.confirmingPrinted);
        AirtimeTopupRequestFactory factory = new AirtimeTopupRequestFactory();
        AirtimeTopupRequestPrintedMessage request = factory.print(response);
        startAEONAsyncTask(this, socket, request);
    }

    private void authenticateForBundles(String bundleProvider) {
        createProgress(R.string.authenticating);
        BundlesRequestFactory factory = new BundlesRequestFactory();
        BundlesAuthenticationRequestMessage request = factory.create(loginResponseMessage.getData().getUserPin(),
                getPreference(PREF_DEVICE_ID),
                getPreference(PREF_DEVICE_SER),
                bundleProvider);
        if (completeConsumerProfile != null) {
            request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
        }
        startAEONAsyncTask(this, socket, request);
    }

    private void getBundlesProductList() {
        createProgress(R.string.gettingBundleLists);
        BundlesRequestFactory factory = new BundlesRequestFactory();
        BundlesRequestGetProductListMessage request = factory.create(bundlesAuthenticationResponseMessage);
        startAEONAsyncTask(this, socket, request);
    }

    private void purchaseBundle(String productCode, String cellNumber) {
        createProgress(getString(R.string.gettingVoucher));
        BundlesRequestFactory factory = new BundlesRequestFactory();
        Date now = new Date();
        BundlesRequestDoBundleTopupMessage request = factory.createBundle(bundlesAuthenticationResponseMessage,
                getPreference(PREF_DEVICE_ID) + "_" + now.getTime(),
                cellNumber,
                productCode,
                airtimePlusPlayed);
        startAEONAsyncTask(this, socket, request);
    }

    private void setPrintedBundle(BundlesResponseDoBundleTopupMessage response) {
        BundlesRequestFactory factory = new BundlesRequestFactory();
        BundlesRequestPrintedMessage request = factory.print(response);
        startAEONAsyncTask(this, socket, request);
    }

    public void getBundle(String bundleProvider, String productCode, String cellNumber) {
        status = STATUS.AUTHENTICATING_FOR_BUNDLE;
        this.productCode = productCode;
        this.cellNumber = cellNumber;
        authenticateForBundles(bundleProvider);
    }

    private void authenticateForVouchers() {
        createProgress(R.string.authenticating);
        VoucherRequestFactory factory = new VoucherRequestFactory();
        VoucherAuthenticationRequestMessage voucherAuthenticationRequestMessage =
                factory.create(loginResponseMessage, // .getData().getUserPin(),
                        getPreference(PREF_DEVICE_ID),
                        getPreference(PREF_DEVICE_SER));
        if (completeConsumerProfile != null) {
            voucherAuthenticationRequestMessage.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
        }
        startAEONAsyncTask(this, socket, voucherAuthenticationRequestMessage);
    }

    private void authenticateForMultipleVouchers() {
        if (quantity > 1) {
            createProgress(R.string.gettingVouchers);
        } else {
            createProgress(R.string.gettingVoucher);
        }
        MultipleVouchersRequestFactory factory = new MultipleVouchersRequestFactory();

        //
        // made by LB - start sending location data with multiple vouchers
        //
        if (location == null) {
            multipleVouchersAuthenticationRequestMessage = factory.createWithAirtimePlus(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER),
                    stockId,
                    String.valueOf(quantity),
                    airtimePlusPlayed,
                    getPreference(PREF_DEVICE_ID) + "_" + new Date().getTime());
        } else {
            multipleVouchersAuthenticationRequestMessage = factory.createWithAirtimePlus(loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER),
                    stockId,
                    String.valueOf(quantity),
                    airtimePlusPlayed,
                    getPreference(PREF_DEVICE_ID) + "_" + new Date().getTime(),
                    location);
        }
        if (completeConsumerProfile != null) {
            multipleVouchersAuthenticationRequestMessage.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
        }
        startAEONAsyncTask(this, socket, multipleVouchersAuthenticationRequestMessage);
        Log.d(TAG, "Message: " + multipleVouchersAuthenticationRequestMessage);
    }

    public void authenticateForUniversalElectricity(String municName, String meterNum, String amount, String purchaseType) {

        try {
            this.municName = municName;
            this.meterNum = meterNum;
            this.amount = amount;
            this.purchaseType = purchaseType;
//            this.sgc=sgc;
//            this.tt=tt;
//            this.ti=ti;
//            this.krn =krn;
//            this.alg=alg;

            createProgress(R.string.authenticating);
            ElectricityRequestFactory factory = new ElectricityRequestFactory();
            ElectricityAuthenticationRequestMessage request = factory.create(
                    loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER),
                    municName);
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.d(TAG, exception.toString());
        }
    }

    public void authenticateForEskomTokenByOther(String municName, String meterNum, String amount, String purchaseType,
                                                 String sgc, String tt, String ti, String krn, String alg) {

        try {
            this.municName = municName;
            this.meterNum = meterNum;
            this.amount = amount;
            this.purchaseType = purchaseType;
            this.sgc = sgc;
            this.tt = tt;
            this.ti = ti;
            this.krn = krn;
            this.alg = alg;

            createProgress(R.string.authenticating);
            ElectricityRequestFactory factory = new ElectricityRequestFactory();
            ElectricityAuthenticationRequestMessage request = factory.create(
                    loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER),
                    municName);
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.d(TAG, exception.toString());
        }
    }

    private void confirmMeterForUpdate(String meterNum, String amount, String municName) {
        Log.v(TAG, "sendConfirmMeter");
        try {

            createProgress("confirming meter");
            ConfirmMeterRequestFactory factory = new ConfirmMeterRequestFactory();
            ConfirmMeterRequestMessage request;
            Log.v(TAG, "munic name is [" + municName + "]");

            if (!meterNum.contains("=")) {
                request = factory.create(electricityAuthenticationResponseMessage.getSessionId(),
                        loginResponseMessage.getData().getUserPin(),
                        getPreference(PREF_DEVICE_ID),
                        getPreference(PREF_DEVICE_SER),
                        meterNum,
                        amount, sgc, tt, ti, krn, alg,
                        location); //LB
            } else {
                this.meterNum = meterNum.substring(6, 17);
                request = factory.createWithTrack2Data(electricityAuthenticationResponseMessage.getSessionId(),
                        loginResponseMessage.getData().getUserPin(),
                        getPreference(PREF_DEVICE_ID),
                        getPreference(PREF_DEVICE_SER),
                        meterNum,
                        amount, sgc, tt, ti, krn, alg,
                        location); //LB
            }

            startAEONAsyncTask(ActivityMain.this, socket, request);
        } catch (Exception exception) {
            Log.v(TAG, "sendConfirmMeter throws " + exception);

        }
    }

    private void ConfirmMeter(String meterNum, String amount, String municName) {
        Log.v(TAG, "sendConfirmMeter");

        try {
            createProgress("confirming meter");
            ConfirmMeterRequestFactory factory = new ConfirmMeterRequestFactory();
            ConfirmMeterRequestMessage request;
            Log.v(TAG, "munic name is [" + municName + "]");

            if (!meterNum.contains("=")) {
                request = factory.create(electricityAuthenticationResponseMessage.getSessionId(),
                        loginResponseMessage.getData().getUserPin(),
                        getPreference(PREF_DEVICE_ID),
                        getPreference(PREF_DEVICE_SER),
                        meterNum,
                        amount, sgc, tt, ti, krn, alg,
                        location); //LB
            } else {
                this.meterNum = meterNum.substring(6, 17);
                request = factory.createWithTrack2Data(electricityAuthenticationResponseMessage.getSessionId(),
                        loginResponseMessage.getData().getUserPin(),
                        getPreference(PREF_DEVICE_ID),
                        getPreference(PREF_DEVICE_SER),
                        meterNum,
                        amount, sgc, tt, ti, krn, alg,
                        location); //LB
            }

            if (municName.equals("Electricity")) {
                request.setSessionId("");
            }

            startAEONAsyncTask(ActivityMain.this, socket, request);

        } catch (Exception exception) {
            Log.v(TAG, "sendConfirmMeter throws " + exception);
        }
    }

    public void authenticateForUpdateMeterKeys(String municName, String meterNum, String amount, String purchaseType, String tt, String alg, String sgc, String krn, String ti) {

        try {
            this.municName = municName;
            this.meterNum = meterNum;
            this.amount = amount;
            this.purchaseType = purchaseType;
            this.sgc = sgc;
            this.tt = tt;
            this.ti = ti;
            this.krn = krn;
            this.alg = alg;

            createProgress(R.string.authenticating);
            ElectricityRequestFactory factory = new ElectricityRequestFactory();
            ElectricityAuthenticationRequestMessage request = factory.create(
                    loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER),
                    municName);
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.d(TAG, exception.toString());
        }
    }

    public void purchaseElectricity() {
        try {
            if (purchaseType.equalsIgnoreCase("update")) {
                createProgress(R.string.updatingMeterKeys);
            } else {
                createProgress(R.string.gettingVoucher);
            }

            ElectricityVoucherRequestFactory factory = new ElectricityVoucherRequestFactory();
            ElectricityVoucherRequestMessage request = factory.create(confirmMeterResponseMessage,
                    purchaseType,
                    "1");

            Log.v(TAG, request.toString());
            startAEONAsyncTask(this, socket, request);
            Log.v(TAG, "executed");

        } catch (Exception exception) {
            Log.v(TAG, "buyElectricity exception " + exception);
        }
    }


    private void soldElectricityVoucher() {
        Log.v(TAG, "soldVoucher");
        try {
            ElectricityVoucherRequestFactory factory = new ElectricityVoucherRequestFactory();
            ElectricityVoucherRequestSoldMessage request = factory.sold(electricityVoucherResponseMessage);
            Log.v(TAG, request.toString());
            startAEONAsyncTask(this, socket, request);
            Log.v(TAG, "executed");
        } catch (Exception exception) {
            Log.v(TAG, "soldVoucher exception " + exception);
        }
    }

    public void authenticateForEskomReprint(String meterNum) {
        try {

            this.meterNum = meterNum;

            createProgress(R.string.authenticating);
            EskomDirectReprintRequestFactory factory = new EskomDirectReprintRequestFactory();
            EskomDirectReprintAuthenticationRequestMessage request = factory.create(
                    loginResponseMessage.getData().getUserPin(),
                    getPreference(PREF_DEVICE_ID),
                    getPreference(PREF_DEVICE_SER));
            Log.v(TAG, request.toString());
            if (completeConsumerProfile != null) {
                request.getEvent().setLoyaltyProfileId(completeConsumerProfile.getConsumer().getProfileId());
            }
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.d(TAG, exception.toString());
        }
    }

    private void getEskomReprints() {
        try {
            createProgress("getting reprint list");
            EskomDirectReprintRequestFactory factory = new EskomDirectReprintRequestFactory();
            EskomDirectReprintRequestMessage request = factory.create(eskomDirectReprintAuthenticationResponseMessage, meterNum);
            Log.v(TAG, request.toString());
            startAEONAsyncTask(this, socket, request);
        } catch (Exception exception) {
            Log.d(TAG, exception.toString());
        }
    }

    private void requestVoucherList() {
        try {
            createProgress(R.string.gettingVoucherList);
            Log.d(TAG, "requesting new voucher list");
            status = STATUS.REQUESTING_VOUCHER_LIST;
            VoucherListRequestFactory factory = new VoucherListRequestFactory();
            VoucherListRequestMessage voucherListRequestMessage = factory.create(loginResponseMessage);
            startAEONAsyncTask(this, socket, voucherListRequestMessage);
            Log.d("VoucherList", voucherListRequestMessage.toString());
        } catch (Exception exception) {
            Log.d(TAG, "problem requesting voucher list " + exception);
        }
    }

    private void setPrintedMultipleVouchers() {
        try {
            createProgress(R.string.confirmingPrinted);
            MultipleVouchersRequestFactory factory = new MultipleVouchersRequestFactory();
            MultipleVouchersRequestPrintedMessage request = factory.create(multipleVouchersAuthenticationRequestMessage,
                    multipleVouchersAuthenticationResponseMessage);
            startAEONAsyncTask(this, socket, request);
            Log.v(TAG, "executed");
            Log.d(TAG, " Message: " + request);
        } catch (Exception exception) {
            Log.v(TAG, "printMultipleVouchers throws " + exception);
            //log.("problems telling AEON voucher printed", "printVoucher", "", exception);
        }

    }


    //
    // this method is called from elsewhere to
    // start the get voucher process
    //
    // the amount and supplierCode are there as a
    // safety fallback in case it has to go
    // chat-4-change
    //
    public void getVoucher(String stockId, int quantity, String supplierCode, String amount) {
        Log.d(TAG, "quantity is " + quantity);
        this.stockId = stockId;
        this.quantity = quantity;
        this.amount = amount;
        this.supplierCode = supplierCode;
        count = 0;
        status = STATUS.AUTHENTICATING_FOR_VOUCHER;

        //authenticateForVouchers();

        authenticateForMultipleVouchers();
    }

    public void results(Object object) {
        try {
            Log.d(TAG, "results object " + object);
            Log.d("MPKresults", "(Main) class " + object.getClass().getSimpleName());
        } catch (Exception ignore) {
        }

        if (object instanceof Socket) {
            socket = (Socket) object;
        } else if (object instanceof VoucherAuthenticationResponseMessage) {
            dismissProgress();
            processVoucherAuthenticationResponseMessage(object);
        } else if (object instanceof MultipleVouchersAuthenticationResponseMessage) {
            processMultipleVouchersAuthenticationResponseMessage(object);

        } else if (object instanceof MultipleVouchersResponsePrintedMessage) {
            dismissProgress();
            MultipleVouchersResponsePrintedMessage response = (MultipleVouchersResponsePrintedMessage) object;
            if (response.getEvent().getEventCode().equals("0")) {
                Log.d(TAG, "emptyBasket() in MultipleVouchersResponsePrintedMessage");
                emptyBasket();
            } else {
                createSystemErrorConfirmation(response, true);
            }
        } else if (object instanceof VoucherListResponseMessage) {
            dismissProgress();
            processVoucherListResponseMessage(object);

        } else if (object instanceof BundlesAuthenticationResponseMessage) {
            dismissProgress();
            processBundlesAuthenticationResponseMessage(object);
        } else if (object instanceof BundlesResponseGetProductListMessage) {
            dismissProgress();
            processBundlesResponseGetProductListMessage(object);
        } else if (object instanceof BundlesResponseDoBundleTopupMessage) {
//            dismissProgress();
            processBundlesResponseDoBundleTopupMessage(object);
        } else if (object instanceof BundlesResponsePrintedMessage) {
            dismissProgress();
            processBundlesResponsePrintedMessage(object);
        } else if (object instanceof AirtimeTopupResponseMessage) {
            dismissProgress();
            processAirtimeTopupResponseMessage(object);
        } else if (object instanceof AirtimeTopupResponsePurchaseMessage) {
//            dismissProgress();
            processAirtimeTopupResponsePurchaseMessage(object);
        } else if (object instanceof AirtimeTopupResponsePrintedMessage) {
            dismissProgress();
            processAirtimeTopupResponsePrintedMessage(object);
        }

        //
        //Electricity
        //

        else if (object instanceof ElectricityAuthenticationResponseMessage) {
            dismissProgress();
            processElectricityAuthenticationResponseMessage(object);
        } else if (object instanceof ConfirmMeterResponseMessage) {
            dismissProgress();
            processConfirmMeterResponseMessage(object);
        } else if (object instanceof ElectricityVoucherResponseMessage) {
//            dismissProgress();
            processElectricityVoucherResponseMessage(object);
        } else if (object instanceof ElectricityVoucherResponsePrintedMessage) {
//            dismissProgress();
            processElectricityVoucherResponsePrintedMessage(object);
        } else if (object instanceof ElectricityVoucherResponseSoldMessage) {
            dismissProgress();
            processElectricityVoucherResponseSoldMessage(object);
        }
        //
        //END Electricity
        //
        else if (object instanceof EskomDirectReprintAuthenticationResponseMessage) {
            dismissProgress();
            processEskomDirectReprintAuthenticationResponseMessage(object);
        } else if (object instanceof EskomDirectReprintResponseMessage) {
            dismissProgress();
            processEskomDirectReprintResponseMessage(object);
        } else {
            super.results(object);
        }


        String responseMessage = object.getClass().getSimpleName();

        if (!(object instanceof Socket) && connectedToAEON) {
            connectedToAEON = false;
            firebaseBundle = new Bundle();
            firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, responseMessage);
            firebaseBundle.putString("param_drop", "drop_this");
            mFirebaseAnalytics.logEvent("aeon_connection", firebaseBundle);
        }
    }


    private void processVoucherAuthenticationResponseMessage(Object object) {
        voucherAuthenticationResponseMessage = (VoucherAuthenticationResponseMessage) object;
        if (voucherAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
            BaseFragment.canDoChatForChange = voucherAuthenticationResponseMessage.getData().getTransTypes().contains("C4C_Voucher");
            loginResponseMessage.setSessionId(voucherAuthenticationResponseMessage.getSessionId());
            Date voucherCacheDate = dateLastVoucherCache();
            Date now = new Date();
            if (status == STATUS.AUTHENTICATING_FOR_VOUCHER_LIST) {
                if (voucherListResponseMessage == null) {
                    Log.d(TAG, "getting cached vouchers");
                    voucherListResponseMessage = getCachedVoucherData();
                    Log.d(TAG, "voucherListResponseMessage == null ?" + (voucherListResponseMessage == null));
                }
                Log.d(TAG, "cache expired " + ((now.getTime() - voucherCacheDate.getTime()) > CACHE_12_HOURS));
                Log.d(TAG, "maxCacheAgeMillis " + CACHE_12_HOURS);
                Log.d(TAG, "now.getTime() " + now.getTime());
                Log.d(TAG, "now " + now);
                Log.d(TAG, "voucherCacheDate.getTime() " + voucherCacheDate.getTime());
                Log.d(TAG, "voucherCacheDate " + voucherCacheDate);
                Log.d(TAG, "diff is " + (now.getTime() - voucherCacheDate.getTime()));
                if ((voucherListResponseMessage == null) || ((now.getTime() - voucherCacheDate.getTime()) > CACHE_12_HOURS)) {
                    requestVoucherList();
                } else {
                    Log.d(TAG, "calling results with " + voucherListResponseMessage);
                    Log.d(TAG, "event code was " + voucherListResponseMessage.getEvent().getEventCode());
                    results(voucherListResponseMessage);
                }
            }
            //all products list are cached, need to retyr auto cancel and tender
            else {
                retryFailedCancellationsAndTenders();

            }

        } else {
            Log.d(TAG, "not authorised for vouchers");
            createSystemErrorConfirmation(voucherAuthenticationResponseMessage, true);
        }
    }

    private void processMultipleVouchersAuthenticationResponseMessage(Object object) {
        Log.d(TAG, "Log test");
        multipleVouchersAuthenticationResponseMessage = (MultipleVouchersAuthenticationResponseMessage) object;

        if (multipleVouchersAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

//            createProgress(R.string.printingVoucher);
            ///  if ( getPreference(PREF_USE_BASKET).equals(PREF_TRUE) ) {
            for (int i = 0; i < multipleVouchersAuthenticationResponseMessage.getData().getVouchers().size(); i++) {
                saveDetailsUntilPaid(multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getTransRef(),
                        name, multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getProductName(),
                        multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getAmount());
            }

            for (int i = 0; i < multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().size(); i++) {
                if (multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().get(i).getTransSeq() != null) {
                    saveDetailsUntilPaidRechargePlus(multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().get(i).getTransRef(),
                            "Recharge Plus", "Recharge Plus",
                            multipleVouchersAuthenticationResponseMessage.getData().getRechargePlusTransactionMessages().get(i).getValue());
                }
            }

//            for (int i = 0; i < multipleVouchersAuthenticationResponseMessage.getData().getVouchers().size(); i++) {
//                printWithDynamic(multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getPrintLines(), getPrintBarcode());
//            }
//
//            if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
//                print(multipleVouchersAuthenticationResponseMessage.getData().getMerchantPrintLines());
//            }
//
//            supplierName = "";
//            gettingMvnoVoucher = false;
//
//            logger.info("Voucher printed:" + isVoucherPrinted);
//            if (isVoucherPrinted) {
//                printMultipleVouchers();
//            } else {
//                cleanUp();
//                createPrintErrorConfirmation();
//            }

            if (previewSlipsEnabled()) {
                List<PrintJob> printJobs = new ArrayList<>();
                for (int i = 0; i < multipleVouchersAuthenticationResponseMessage.getData().getVouchers().size(); i++) {
                    printJobs.add(new PrintJob(multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getPrintLines(), true, getPrintBarcode()));
                }
                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    printJobs.add(new PrintJob(multipleVouchersAuthenticationResponseMessage.getData().getMerchantPrintLines(), false, false));
                }
                new BluDroidSlipPreviewMultipleVouchersDialog(this, printJobs);

            } else {
                for (int i = 0; i < multipleVouchersAuthenticationResponseMessage.getData().getVouchers().size(); i++) {
                    printWithDynamic(multipleVouchersAuthenticationResponseMessage.getData().getVouchers().get(i).getPrintLines(), getPrintBarcode());
                }

                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    print(multipleVouchersAuthenticationResponseMessage.getData().getMerchantPrintLines());
                }
                completeMultipleVoucherPrint();
            }


        } else {
            createSystemErrorConfirmation(multipleVouchersAuthenticationResponseMessage, true);
            //reset airtimePlus flag to not played
            airtimePlusPlayed = "0";
        }

        //reset airtimePlus flag to not played
//        airtimePlusPlayed = "0";
    }

    public void completeMultipleVoucherPrint() {
        supplierName = "";
        gettingMvnoVoucher = false;

        logger.info("Voucher printed:" + isVoucherPrinted);
        if (isVoucherPrinted) {
            setPrintedMultipleVouchers();
        } else {
            cleanUp();
            createPrintErrorConfirmation();
        }
        airtimePlusPlayed = "0";
    }


    private void processVoucherListResponseMessage(Object object) {
        voucherListResponseMessage = (VoucherListResponseMessage) object;
        Log.d("MPK", voucherListResponseMessage.toString());
        if (voucherListResponseMessage.getEvent().getEventCode().equals("0")) {
            cacheVoucherData(voucherListResponseMessage);
            //
            // DO NOT REMOVE THIS LOG ENTRY
            // IT IS USED FOR TESTING
            //
            Log.d(TAG, "TEST: VOUCHER LIST RECEIVED");
            Log.d(TAG, "got back voucher list with correct event code");
            status = STATUS.NONE;
            //Call populate method for each fragment to display vouchers so the user doesn't land on an empty page...
            FragmentAirtime fa = (FragmentAirtime) getSupportFragmentManager().findFragmentByTag("FragmentAirtime");
            if (fa != null) {
                fa.populateScreen();
            }
            //
            // we need a security check here
            //
            count = 0;
            Date bundlesCacheDate = dateLastBundlesCache();
            Date now = new Date();

            boolean doingBundles = false;

            if (bundleProviders != null) {
                if (bundleProviders.size() > 0) {
                    if ((bundlesResponseGetProductListMessages.get(bundleProviders.get(count)) == null) ||
                            ((now.getTime() - bundlesCacheDate.getTime()) > CACHE_12_HOURS)) {
                        status = STATUS.AUTHENTICATING_FOR_BUNDLE_LIST;
                        Log.d("BundleProdListMain", "authenticating for bundles for " + bundleProviders.get(count));
                        //sometimes the connection breaks,now opening a new 1
                        //login();
                        doingBundles = true;
                        authenticateForBundles(bundleProviders.get(count));
                    } else {
                        if (bundlesResponseGetProductListMessages.get(bundleProviders.get(count)) != null) {
                            Log.d("BundleProdListMain", "using cached values for " + bundleProviders.get(count));
                            results(bundlesResponseGetProductListMessages.get(bundleProviders.get(count)));
                        }
                    }
                }
            }
            //
            // we need a security check here
            //
            //count = 0;
            //authenticateForBundles(bundleProviders.get(count));
            FragmentData fd = (FragmentData) getSupportFragmentManager().findFragmentByTag("FragmentData");
            if (fd != null) {
                fd.populateScreen();
            }
            FragmentElectricity fe = (FragmentElectricity) getSupportFragmentManager().findFragmentByTag("FragmentElectricity");
            if (fe != null) {
                fe.populateScreen();
            }

            FragmentVouchers fv = (FragmentVouchers) getSupportFragmentManager().findFragmentByTag("FragmentVouchers");
            if (fv != null) {
                fv.populateScreen();
            }

            FragmentFavourites ff = (FragmentFavourites) getSupportFragmentManager().findFragmentByTag("FragmentFavourites");
            if (ff != null) {
                ff.populateScreen();
                loadFavouritesFirstTime = false;
            }

            if (!doingBundles) {
                authenticateForBillPayments();
            }

        } else {
            Log.d(TAG, "problem getting voucher list");
            createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorProcessingVoucherList, true);
        }
    }

    private void processBundlesAuthenticationResponseMessage(Object object) {
        Log.d(TAG, "bundles authentication response message");
        // dismissProgress();
        // dismissConfirmation();
        bundlesAuthenticationResponseMessage = (BundlesAuthenticationResponseMessage) object;
        if (bundlesAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {
            if (status == STATUS.AUTHENTICATING_FOR_BUNDLE_LIST) {
                Log.d(TAG, "getBUndlesProductList now");
                getBundlesProductList();
            } else if (status == STATUS.AUTHENTICATING_FOR_BUNDLE) {
                purchaseBundle(productCode, cellNumber);
            }
        } else {
            createSystemErrorConfirmation(bundlesAuthenticationResponseMessage, true);
        }
    }

    private void processBundlesResponseGetProductListMessage(Object object) {
        if (count < bundleProviders.size()) {
            Log.d(TAG, "bundles product list for " + bundleProviders.get(count));
        } else {
            Log.d(TAG, "bundles product count is " + count);
        }

        BundlesResponseGetProductListMessage bundlesResponseGetProductListMessage = (BundlesResponseGetProductListMessage) object;

        if (bundlesResponseGetProductListMessage.getEvent().getEventCode().equals("0")) {
            Log.d("BundleProdList", "got bundle list for " + bundleProviders.get(count));
            bundlesResponseGetProductListMessages.put(bundleProviders.get(count), bundlesResponseGetProductListMessage);
            cacheBundlesData(bundleProviders.get(count), bundlesResponseGetProductListMessage);
            Log.d(TAG, "cached them");
            count++;
            if (count < bundleProviders.size()) {
                if ((bundlesResponseGetProductListMessages.size() == 0) || (bundlesResponseGetProductListMessages.get(bundleProviders.get(count)) == null)) {
                    Log.d("BundleProdList", "now getting cached bundles for " + bundleProviders.get(count));
                    bundlesResponseGetProductListMessages.put(bundleProviders.get(count), getCachedBundlesData(bundleProviders.get(count)));
                    if (bundlesResponseGetProductListMessages.get(bundleProviders.get(count)) != null) {
                        Log.d("BundleProdList", "recursing");
                        results(bundlesResponseGetProductListMessages.get(bundleProviders.get(count)));
                        return;
                    }
                }
                Date bundlesCacheDate = dateLastBundlesCache();
                Date now = new Date();
                if ((bundlesResponseGetProductListMessages.get(bundleProviders.get(count)) == null) ||
                        ((now.getTime() - bundlesCacheDate.getTime()) > CACHE_12_HOURS)) {
                    Log.d("BundleProdList", "now authenticating for  bundles for " + bundleProviders.get(count));
                    authenticateForBundles(bundleProviders.get(count));
                }
            } else {

                authenticateForBillPayments();

                status = STATUS.NONE;
            }


        } else {
            createSystemErrorConfirmation(bundlesResponseGetProductListMessage, true);
        }
    }

    private void processBundlesResponseDoBundleTopupMessage(Object object) {
        Log.d(TAG, "bundles topup response");
        bundlesResponseDoBundleTopupMessage =
                (BundlesResponseDoBundleTopupMessage) object;
        if (bundlesResponseDoBundleTopupMessage.getEvent().getEventCode().equals("0")) {
            status = STATUS.NONE;
//            createProgress(R.string.printingVoucher);
//            printWithDynamic(bundlesResponseDoBundleTopupMessage.getData().getPrintLines(), getPrintBarcode());
//
//            if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
//                print(bundlesResponseDoBundleTopupMessage.getData().getMerchantPrintLines());
//            }
//
//            supplierName = "";
//            gettingMvnoVoucher = false;
//
//            logger.info("Voucher printed:" + isVoucherPrinted);
//            if (isVoucherPrinted) {
//                printBundle(bundlesResponseDoBundleTopupMessage);
//            } else {
//                cleanUp();
//                createPrintErrorConfirmation();
//            }

            saveDetailsUntilPaid(bundlesResponseDoBundleTopupMessage.getData().getTransRef(),
                    name, bundlesResponseDoBundleTopupMessage.getData().getSupplierName(),
                    bundlesResponseDoBundleTopupMessage.getData().getAmount());

            for (int i = 0; i < bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().size(); i++) {
                if (bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().get(i).getTransSeq() != null) {
                    saveDetailsUntilPaidRechargePlus(bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().get(i).getTransRef(),
                            "Recharge Plus", "Recharge Plus",
                            bundlesResponseDoBundleTopupMessage.getData().getRechargePlusTransactionMessages().get(i).getValue());
                }
            }

            if (previewSlipsEnabled()) {
                List<PrintJob> printJobs = new ArrayList<>();
                printJobs.add(new PrintJob(bundlesResponseDoBundleTopupMessage.getData().getPrintLines(), true, getPrintBarcode()));
                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    printJobs.add(new PrintJob(bundlesResponseDoBundleTopupMessage.getData().getMerchantPrintLines(), false, false));
                }
                new BluDroidSlipPreviewBundleDialog(this, printJobs);

            } else {

                printWithDynamic(bundlesResponseDoBundleTopupMessage.getData().getPrintLines(), getPrintBarcode());

                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    print(bundlesResponseDoBundleTopupMessage.getData().getMerchantPrintLines());
                }
                completeBundlePrint();
            }


        } else {
            createSystemErrorConfirmation(bundlesResponseDoBundleTopupMessage, true);
            airtimePlusPlayed = "0";
        }

        //reset airtimePlus flag to not played
//        airtimePlusPlayed = "0";
    }

    public void completeBundlePrint() {
        supplierName = "";
        gettingMvnoVoucher = false;

        logger.info("Voucher printed:" + isVoucherPrinted);
        if (isVoucherPrinted) {
            setPrintedBundle(bundlesResponseDoBundleTopupMessage);
        } else {
            cleanUp();
            createPrintErrorConfirmation();
        }
        airtimePlusPlayed = "0";
    }

    private void processBundlesResponsePrintedMessage(Object object) {
        Log.d(TAG, "bundles topup printed response");
        BundlesResponsePrintedMessage bundlesResponsePrintedMessage =
                (BundlesResponsePrintedMessage) object;
        dismissProgress();
        if (bundlesResponsePrintedMessage.getEvent().getEventCode().equals("0")) {
            emptyBasket();
            //gotoMainScreen();
        } else {
            createSystemErrorConfirmation(bundlesResponsePrintedMessage, true);
        }
    }

    private void processAirtimeTopupResponseMessage(Object object) {
        Log.d(TAG, "airtime topup authentication response");
        AirtimeTopupResponseMessage response = (AirtimeTopupResponseMessage) object;
        if (response.getEvent().getEventCode().equals("0")) {
            createProgress(R.string.gettingVoucher);
            if (gettingWalletTopup) {
                purchaseWalletTopup(response);

            } else {
                purchasePinlessTopup(response);
            }
            gettingWalletTopup = false;
        } else {
            createSystemErrorConfirmation(response, true);
        }
    }

    private void processAirtimeTopupResponsePurchaseMessage(Object object) {
        AirtimeTopupResponsePurchaseMessage = (AirtimeTopupResponsePurchaseMessage) object;
        if (AirtimeTopupResponsePurchaseMessage.getEvent().getEventCode().equals("0")) {
//            createProgress(R.string.printingVoucher);
//            printWithDynamic(AirtimeTopupResponsePurchaseMessage.getData().getPrintLines(), getPrintBarcode());
//            if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
//                print(AirtimeTopupResponsePurchaseMessage.getData().getMerchantPrintLines());
//            }
//
//            supplierName = "";
//            gettingMvnoVoucher = false;
//
//            logger.info("Voucher printed:" + isVoucherPrinted);
//            if (isVoucherPrinted) {
//                printPinlessTopup(AirtimeTopupResponsePurchaseMessage);
//            } else {
//                cleanUp();
//                createPrintErrorConfirmation();
//            }

            saveDetailsUntilPaid(AirtimeTopupResponsePurchaseMessage.getData().getTransRef(),
                    name, AirtimeTopupResponsePurchaseMessage.getData().getSupplierName(),
                    AirtimeTopupResponsePurchaseMessage.getData().getAmount());

            for (int i = 0; i < AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().size(); i++) {
                if (AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().get(i).getTransSeq() != null) {
                    saveDetailsUntilPaidRechargePlus(AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().get(i).getTransRef(),
                            "Recharge Plus", "Recharge Plus",
                            AirtimeTopupResponsePurchaseMessage.getData().getRechargePlusTransactionMessages().get(i).getValue());
                }
            }

            if (previewSlipsEnabled()) {
                List<PrintJob> printJobs = new ArrayList<>();
                printJobs.add(new PrintJob(AirtimeTopupResponsePurchaseMessage.getData().getPrintLines(), true, getPrintBarcode()));
                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    printJobs.add(new PrintJob(AirtimeTopupResponsePurchaseMessage.getData().getMerchantPrintLines(), false, false));
                }
                new BluDroidSlipPreviewTopupDialog(this, printJobs);

            } else {

                printWithDynamic(AirtimeTopupResponsePurchaseMessage.getData().getPrintLines(), getPrintBarcode());

                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                    print(AirtimeTopupResponsePurchaseMessage.getData().getMerchantPrintLines());
                }
                completeTopupPrint();
            }

        } else {
            createSystemErrorConfirmation(AirtimeTopupResponsePurchaseMessage, true);
            airtimePlusPlayed = "0";
        }

        //reset airtimePlus flag to not played
//        airtimePlusPlayed = "0";
    }

    public void completeTopupPrint() {
        supplierName = "";
        gettingMvnoVoucher = false;

        logger.info("Voucher printed:" + isVoucherPrinted);
        if (isVoucherPrinted) {
            setPrintedPinlessTopup(AirtimeTopupResponsePurchaseMessage);
        } else {
            cleanUp();
            createPrintErrorConfirmation();
        }
        airtimePlusPlayed = "0";
    }

    private void processAirtimeTopupResponsePrintedMessage(Object object) {
        AirtimeTopupResponsePrintedMessage response = (AirtimeTopupResponsePrintedMessage) object;
        dismissProgress();
        dismissConfirmation();
        if (response.getEvent().getEventCode().equals("0")) {
            emptyBasket();
        } else {
            createSystemErrorConfirmation(response, true);
        }
    }


    private void processElectricityAuthenticationResponseMessage(Object object) {
        resetTimer();
        Log.v(TAG, "ElectricityAuthenticationResponseMessage");
        electricityAuthenticationResponseMessage = (ElectricityAuthenticationResponseMessage) object;
        if (electricityAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

            if (purchaseType.equalsIgnoreCase("update")) {
                confirmMeterForUpdate(meterNum, amount, municName);
            } else {
                ConfirmMeter(meterNum, amount, municName);
            }
        } else {
            createSystemErrorConfirmation(electricityAuthenticationResponseMessage, true);
        }
    }

    private void processConfirmMeterResponseMessage(Object object) {
        resetTimer();
        dismissProgress();
        confirmMeterResponseMessage = (ConfirmMeterResponseMessage) object;
        if (confirmMeterResponseMessage.getEvent().getEventCode().equals("0")) {
            dismissConfirmation();

            createElectricityPurchaseConfirmationDialog(this);

            if (confirmation instanceof BluDroidElectricityPurchaseConfirmationDialog) {

                BluDroidElectricityPurchaseConfirmationDialog dialog =
                        (BluDroidElectricityPurchaseConfirmationDialog) confirmation;

                if (purchaseType.equalsIgnoreCase("fbe")) {
                    dialog.setMeterNumber(meterNum);
                    dialog.setAccountHolder(confirmMeterResponseMessage.getData().getCustomerName());
                    dialog.setAddress(confirmMeterResponseMessage.getData().getCustomerAddress());

                    dialog.hideView(R.id.amountLabel);
                    dialog.hideView(R.id.amount);
                    dialog.hideView(R.id.outstandingAmountLabel);
                    dialog.hideView(R.id.outstandingAmount);
                } else {
                    dialog.setMeterNumber(meterNum);
                    dialog.setAccountHolder(confirmMeterResponseMessage.getData().getCustomerName());
                    dialog.setAddress(confirmMeterResponseMessage.getData().getCustomerAddress());

                    if (confirmMeterResponseMessage.getData().getMin().equals("0.00") || confirmMeterResponseMessage.getData().getMin().equals("0") || confirmMeterResponseMessage.getData().getMin().isEmpty()) {
                        dialog.goneView(R.id.outstandingAmountLabel);
                        dialog.goneView(R.id.outstandingAmount);
                    } else {
                        dialog.setOutstanding(getResources().getString(R.string.currency) + df2.format(Double.parseDouble(confirmMeterResponseMessage.getData().getMin())));
                    }

                    dialog.setAmount(getResources().getString(R.string.currency) + df2.format(Double.parseDouble(amount)));
                }
            }
        } else {
            createSystemErrorConfirmation(confirmMeterResponseMessage, true);
        }
    }

    private void processElectricityVoucherResponseMessage(Object object) {
//        dismissProgress();

        electricityVoucherResponseMessage = (ElectricityVoucherResponseMessage) object;

        //success
        if (electricityVoucherResponseMessage.getEvent().getEventCode().equals("0")) {

            //handle multiple swipes
            if (isElectricityResponseFirstTime) {
                Log.d("MAgCARD", electricityVoucherResponseMessage.getData().getPrintMagCard());

//                //printElectricityVoucher();
//                printWithDynamic(electricityVoucherResponseMessage.getData().getPrintLines(), getPrintBarcode());
//
//                if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
//                    print(electricityVoucherResponseMessage.getData().getMerchantPrintLines());
//                }

                saveDetailsUntilPaid(electricityVoucherResponseMessage.getData().getTransRef(),
                        name + " Electricity", electricityVoucherResponseMessage.getData().getUtility(), amount);

//                supplierName = "";
//                gettingMvnoVoucher = false;
//
//                if (electricityVoucherResponseMessage.getData().getPrintMagCard().equalsIgnoreCase("true")) {
//
//                    if (Build.MODEL.startsWith("CITAQ") || Build.MODEL.startsWith("TPS") || Build.MODEL.contains("N3") || Build.MODEL.contains("P1")) {
//
//                        //magCard = new MagCard(this);
//                        magCard.setDelegate(ActivityMain.this);
//
//                        if (!magCard.isConnected()) {
//                            Log.d(TAG, "New instance of adapter");
//
//                            if (!magCard.enumerate()) {
//
////                                createAlertDialog("Mag Card", "No devices found, please check if mag encoder is connected");
//                                createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorMagEncoder, false);
//                                //Toast.makeText(this, "no more devices found", Toast.LENGTH_SHORT).show();
//                                return;
//                            } else {
//                                Log.d(TAG, "onResume:enumerate succeeded!");
//                            }
//                        }//if isConnected
//
//                        Toast.makeText(this, "attached", Toast.LENGTH_SHORT).show();
//                        magCard.openUsbSerial();
//
//                        magCardDataList = getMagCardTokens(electricityVoucherResponseMessage.getData());
//
//                        if (isKeyChange) {
//                            magCardUpdateDataList = getMagCardUpdateByVoucher(electricityVoucherResponseMessage.getData());
//
//                            if (magCardUpdateDataList.size() > 0) {
//
//                                alert = createMagCardAlertDialog("MAG Encoder", "Please have your ESKOM card ready");
//
//                                alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialog, int which) {
//                                        MagCardData cardData = magCardUpdateDataList.get(0);
//                                        magCard.setTrack2(cardData.getTrack2());
//                                        magCard.sendWriteCommand();
//                                        magCardAction = "write";
//                                        createNotifyAlertDialog("Mag Card", "Please swipe card");
//                                    }
//                                });
//
//                                alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialog, int which) {
//                                        dialog.dismiss();
//                                    }
//                                });
//
//                                alert.show();
//                            }
//                        } else {
//
//                            tokensSize = magCardDataList.size();
//
//                            if (magCardDataList.size() > 0) {
//
//                                alert = createMagCardAlertDialog("MAG Encoder", "Please have " + tokensSize + " paper card(s) ready");
//
//                                alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialog, int which) {
//                                        MagCardData cardData = magCardDataList.get(0);
//                                        magCard.setTrack2(cardData.getTrack2());
//                                        magCard.setTrack3(cardData.getTrack3());
//                                        magCard.sendWriteCommand();
//                                        magCardAction = "write";
//                                        createNotifyAlertDialog("Mag Card", "Please swipe card to write " + cardNumber + "/" + tokensSize);
//                                    }
//                                });
//
//                                alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
//                                    @Override
//                                    public void onClick(DialogInterface dialog, int which) {
//                                        dialog.dismiss();
//                                        if (isVoucherPrinted) {
//                                            printElectricityVoucher();
//
//
//                                        } else {
//                                            cleanUp();
//                                            createPrintErrorConfirmation();
//                                        }
//                                    }
//                                });
//
//                                alert.show();
//                            }
//
//                        }
//
//                    } else {
//
//                        logger.info("Electricity Voucher printed:" + isVoucherPrinted);
//                        if (isVoucherPrinted) {
//                            printElectricityVoucher();
//
//                        } else {
//                            cleanUp();
//                            createPrintErrorConfirmation();
//                        }
//                    }
//
//                } else {
//                    logger.info("Electricity Voucher printed:" + isVoucherPrinted);
//                    if (isVoucherPrinted) {
//                        printElectricityVoucher();
//                    } else {
//                        cleanUp();
//                        createPrintErrorConfirmation();
//                    }
//                }

                if (previewSlipsEnabled()) {
                    List<PrintJob> printJobs = new ArrayList<>();
                    printJobs.add(new PrintJob(electricityVoucherResponseMessage.getData().getPrintLines(), true, getPrintBarcode()));
                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        printJobs.add(new PrintJob(electricityVoucherResponseMessage.getData().getMerchantPrintLines(), false, false));
                    }
                    new BluDroidSlipPreviewElectricityDialog(this, printJobs);

                } else {

                    printWithDynamic(electricityVoucherResponseMessage.getData().getPrintLines(), getPrintBarcode());

                    if (getPreference(PREF_PRINT_MERCHANT_VOUCHER).equals(PREF_TRUE)) {
                        print(electricityVoucherResponseMessage.getData().getMerchantPrintLines());
                    }
                    completeElectricityPrint();
                }

            } else {
                if (electricityVoucherResponseMessage.getData().getPrintMagCard().equalsIgnoreCase("true")) {

                    if (Build.MODEL.startsWith("CITAQ") || Build.MODEL.startsWith("TPS") || Build.MODEL.contains("N3") || Build.MODEL.contains("P1")) {

                        if (!magCard.isConnected()) {
                            Log.d(TAG, "New instance of adapter");

                            if (!magCard.enumerate()) {

//                                createAlertDialog("Mag Card", "No devices found, please check if mag encoder is connected");
                                createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorMagEncoder, false);
                                //Toast.makeText(this, "no more devices found", Toast.LENGTH_SHORT).show();
                                return;
                            } else {
                                Log.d(TAG, "onResume:enumerate succeeded!");
                            }
                        }//if isConnected

                        Toast.makeText(this, "attached", Toast.LENGTH_SHORT).show();
                        magCard.openUsbSerial();

                        if (magCardDataList.size() > 0) {
                            MagCardData cardData = magCardDataList.get(0);
                            magCard.setTrack2(cardData.getTrack2());
                            magCard.setTrack3(cardData.getTrack3());
                            magCard.sendWriteCommand();
                            magCardAction = "write";
                            createNotifyAlertDialog("Mag Card", "Please swipe card to write " + cardNumber + "/" + tokensSize);
                        }
                    }
                }
            }

        } else {
            //error
            if (electricityVoucherResponseMessage.getData().getAeonErrorCode().equals("217")
                    || electricityVoucherResponseMessage.getData().getAeonErrorCode().equals("10012")
                    || electricityVoucherResponseMessage.getData().getAeonErrorCode().equals("10021")
                    || electricityVoucherResponseMessage.getData().getAeonErrorCode().equals("60004")) {

                if (electricityVoucherResponseMessage.getData().getMeter().getTt().equals("01")) {

                    alertDialog = createUpdateMeterKeysAlertDialog(this, "newandold");

                    alertDialog.setPositiveOption("Update", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            //TODO: NKOSANA comms to update meter keys
                        }
                    });

                    alertDialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            alertDialog.dismiss();
                        }
                    });

                    alertDialog.createDialog();
                } else {
                    alertDialog = createUpdateMeterKeysAlertDialog(this, "new");

                    alertDialog.setPositiveOption("Update", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            //TODO: NKOSANA comms to update meter keys new vs old
                        }
                    });

                    alertDialog.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            alertDialog.dismiss();
                        }
                    });

                    alertDialog.createDialog();
                }
            } else if (purchaseType.equalsIgnoreCase("fbe") & (electricityVoucherResponseMessage.getData().getAeonErrorCode().equals("10013")
                    || electricityVoucherResponseMessage.getData().getAeonErrorCode().equals("60000")
                    || electricityVoucherResponseMessage.getData().getAeonErrorCode().equals("10009"))) {
                createAlertDialog(getResources().getString(R.string.fbe), getResources().getString(R.string.meterNotQualifyForFBE));
            } else {
                createSystemErrorConfirmation(electricityVoucherResponseMessage, true);
            }
        }
    }

    public void completeElectricityPrint() {
        supplierName = "";
        gettingMvnoVoucher = false;

        if (electricityVoucherResponseMessage.getData().getPrintMagCard().equalsIgnoreCase("true")) {

            if (Build.MODEL.startsWith("CITAQ") || Build.MODEL.startsWith("TPS") || Build.MODEL.contains("N3") || Build.MODEL.contains("P1")) {

                magCard.setDelegate(ActivityMain.this);

                if (!magCard.isConnected()) {
                    Log.d(TAG, "New instance of adapter");

                    if (!magCard.enumerate()) {
                        createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorMagEncoder, false);
                        return;
                    } else {
                        Log.d(TAG, "onResume:enumerate succeeded!");
                    }
                }

                Toast.makeText(this, "attached", Toast.LENGTH_SHORT).show();
                magCard.openUsbSerial();

                magCardDataList = getMagCardTokens(electricityVoucherResponseMessage.getData());

                if (isKeyChange) {
                    magCardUpdateDataList = getMagCardUpdateByVoucher(electricityVoucherResponseMessage.getData());

                    if (magCardUpdateDataList.size() > 0) {

                        alert = createMagCardAlertDialog("MAG Encoder", "Please have your ESKOM card ready");

                        alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                MagCardData cardData = magCardUpdateDataList.get(0);
                                magCard.setTrack2(cardData.getTrack2());
                                magCard.sendWriteCommand();
                                magCardAction = "write";
                                createNotifyAlertDialog("Mag Card", "Please swipe card");
                            }
                        });

                        alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                        alert.show();
                    }
                } else {

                    tokensSize = magCardDataList.size();

                    if (magCardDataList.size() > 0) {

                        alert = createMagCardAlertDialog("MAG Encoder", "Please have " + tokensSize + " paper card(s) ready");

                        alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                MagCardData cardData = magCardDataList.get(0);
                                magCard.setTrack2(cardData.getTrack2());
                                magCard.setTrack3(cardData.getTrack3());
                                magCard.sendWriteCommand();
                                magCardAction = "write";
                                createNotifyAlertDialog("Mag Card", "Please swipe card to write " + cardNumber + "/" + tokensSize);
                            }
                        });

                        alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                if (isVoucherPrinted) {
                                    printElectricityVoucher();


                                } else {
                                    cleanUp();
                                    createPrintErrorConfirmation();
                                }
                            }
                        });

                        alert.show();
                    }

                }

            } else {

                logger.info("Electricity Voucher printed:" + isVoucherPrinted);
                if (isVoucherPrinted) {
                    printElectricityVoucher();

                } else {
                    cleanUp();
                    createPrintErrorConfirmation();
                }
            }

        } else {
            logger.info("Electricity Voucher printed:" + isVoucherPrinted);
            if (isVoucherPrinted) {
                printElectricityVoucher();
            } else {
                cleanUp();
                createPrintErrorConfirmation();
            }
        }
    }

    private void processElectricityVoucherResponsePrintedMessage(Object object) {
        //dismissProgress();
        dismissConfirmation();

        ElectricityVoucherResponsePrintedMessage response = (ElectricityVoucherResponsePrintedMessage) object;
        if (response.getEvent().getEventCode().equals("0")) {
            soldElectricityVoucher();
        } else {
            createSystemErrorConfirmation(response, true);
        }
    }

    private void processElectricityVoucherResponseSoldMessage(Object object) {
        ElectricityVoucherResponseSoldMessage response = (ElectricityVoucherResponseSoldMessage) object;
        if (response.getEvent().getEventCode().equals("0")) {

            if (getPreference(PREF_CASH_DRAWER).equals(PREF_TRUE)) {
                Log.d(TAG, "Opening Cash Drawer");
                CashDrawerUtil.openCash();
            }
            //cleanUp();
            emptyBasket();
        } else {
            createSystemErrorConfirmation(response, true);
        }
    }

    private void processEskomDirectReprintAuthenticationResponseMessage(Object object) {
        eskomDirectReprintAuthenticationResponseMessage = (EskomDirectReprintAuthenticationResponseMessage) object;

        Log.d(TAG, eskomDirectReprintAuthenticationResponseMessage.toString());

        if (eskomDirectReprintAuthenticationResponseMessage.getEvent().getEventCode().equals("0")) {

            getEskomReprints();
        } else {
            createSystemErrorConfirmation(eskomDirectReprintAuthenticationResponseMessage, true);
        }
    }

    private void processEskomDirectReprintResponseMessage(Object object) {
        eskomDirectReprintResponseMessage = (EskomDirectReprintResponseMessage) object;
        Log.d(TAG, eskomDirectReprintResponseMessage.toString());

        if (eskomDirectReprintResponseMessage.getEvent().getEventCode().equals("0")) {
            createEskomReprintListDialog();
        } else {
            createSystemErrorConfirmation(eskomDirectReprintResponseMessage, true);
        }
    }


    public void error(Object object) {
        Log.d(TAG, "error " + object);
        super.error(null);
    }

    @Override
    public void affirmativeButton(View view) {
        Log.d(TAG, "affirmativeButton " + confirmation.getClass().getSimpleName());

        isElectricityResponseFirstTime = true;

        if (confirmation instanceof BluDroidConfirmPassengerDialog) {
            dismissConfirmation();

            Log.v("Emergency", ">>>>CARRIER: " + bluDroidRoutesAndTimes.getCarrier());
            Log.v("Emergency", ">>>>CARRIERNAME: " + bluDroidRoutesAndTimes.getCarrierName());
            if (bluDroidRoutesAndTimes.getCarrierName().toLowerCase().contains("greyhound")) {
                fragmentCarmaEmergencyContactDetails = new FragmentCarmaEmergencyContactDetails();
                gotoFragment(fragmentCarmaEmergencyContactDetails, "FragmentCarmaEmergencyContactDetails");
            } else {
                fragmentCarmaConfirmPurchaseTicket = new FragmentCarmaConfirmPurchaseTicketNew();
                gotoFragment(fragmentCarmaConfirmPurchaseTicket, "FragmentCarmaConfirmPurchaseTicketNew");
            }

        } else if (confirmation instanceof BluDroidElectricityPurchaseConfirmationDialog) {

            Log.d(TAG, "Electricity Purchase Confirmed");

            BluDroidElectricityPurchaseConfirmationDialog dialog = (BluDroidElectricityPurchaseConfirmationDialog) confirmation;

            dismissConfirmation();
            purchaseElectricity();
            //check if we have an outstanding amount
            //dummy data is the default
//            if (!dialog.getOutstanding().equalsIgnoreCase("Dummy Data") || dialog.getOutstanding().equalsIgnoreCase("0.00")) {
            /*if (!dialog.getOutstanding().isEmpty() || dialog.getOutstanding().equalsIgnoreCase("0.00")) {

                 dismissConfirmation();

                double outstanding = Double.parseDouble(dialog.getOutstanding().replace("R", ""));
                double amount = Double.parseDouble(dialog.getAmount().replace("R", ""));

                if (outstanding >= amount) {

                    alert = createElectricityAlertDialog("Outstanding Amount", "Your outstanding balance of <font color='#FF0000'><b> R" + df2.format(outstanding) + "</b></font>"
                            + " will need to be settled before you can purchase a new voucher. Do you wish to continue?");

                    alert.setPositiveOption("Continue", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //dismissConfirmation();
                            purchaseElectricity();
                        }
                    });

                    alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    alert.show();
                }
                else if (outstanding < amount) {

                    alert = createElectricityAlertDialog("Outstanding Amount", "Your outstanding balance of <font color='#FF0000'><b> R"
                            + df2.format(outstanding) + "</b></font>" + " will need to be settled before you can purchase a new voucher. The value of your token will be <font color='#FF0000'><b>R"
                            + df2.format(amount - outstanding) + "</b></font>. Do you wish to continue?");

                    alert.setPositiveOption("Continue", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //dismissConfirmation();
                            purchaseElectricity();
                        }
                    });

                    alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    alert.show();
                }

            } else {
                dismissConfirmation();
                purchaseElectricity();
            } */

        } else if (confirmation instanceof BluDroidEskomTrialPurchaseDialog) {
            BluDroidEskomTrialPurchaseDialog dialog = (BluDroidEskomTrialPurchaseDialog) confirmation;

            if (dialog.validate()) {

                Log.d(TAG, "Eskom Electricity Purchase Confirmed");

                String municName = "EskomDirect";
                String meterNumber = dialog.getMeterNumber();
                String amount = dialog.getAmount();
                String purchaseType = "Trial";

                dismissConfirmation();
                authenticateForUniversalElectricity(municName, meterNumber, amount, purchaseType);
            }
        } else if (confirmation instanceof BluDroidUpdateEskomMeterKeysDialog) {
            BluDroidUpdateEskomMeterKeysDialog dialog = (BluDroidUpdateEskomMeterKeysDialog) confirmation;

            if (dialog.validate()) {
                String municName = "EskomDirect";
                String meterNumber = dialog.getMeterNumber();
                String amount = "0.00";
                String purchaseType = "Update";
                String tt = dialog.getTt();
                String ti = dialog.getTi();
                String sgc = dialog.getSgc();
                String krn = dialog.getKrn();
                String alg = dialog.getAlg();
                dismissConfirmation();
                authenticateForUpdateMeterKeys(municName, meterNumber, amount, purchaseType, tt, alg, sgc, krn, ti);
            }
        } else if (confirmation instanceof BluDroidEskomTokenByOtherDialog) {
            BluDroidEskomTokenByOtherDialog dialog = (BluDroidEskomTokenByOtherDialog) confirmation;

            if (dialog.validate()) {
                String municName = "EskomDirect";
                String meterNumber = dialog.getMeterNumber();
                String amount = dialog.getAmount();
                String purchaseType = "Token";
                String tt = dialog.getTt();
                String ti = dialog.getTi();
                String sgc = dialog.getSgc();
                String krn = dialog.getKrn();
                String alg = dialog.getAlg();

                dismissConfirmation();
                authenticateForEskomTokenByOther(municName, meterNumber, amount, purchaseType, sgc, tt, ti, krn, alg);
            }
        } else if (confirmation instanceof BluDroidEskomRedeemTokenDialog) {
            BluDroidEskomRedeemTokenDialog dialog = (BluDroidEskomRedeemTokenDialog) confirmation;

            if (dialog.validate()) {
                logger.info(((Button) view).getText());

                if (openMagEncoder()) {

                    tokensSize = 1;

                    magCard.setDelegate(this);

                    magCardDataList = new ArrayList<>();

                    MagCardData magCardData = new MagCardData();
                    magCardData.setTrack3(dialog.getTokenNumber());

                    magCardDataList.add(magCardData);

                    magCard.setTrack3(magCardDataList.get(0).getTrack3());
                    magCard.openUsbSerial();
                    magCard.sendWriteCommand();
                    magCardAction = "write";
                    alert = createMagEncoderAlertDialog("Mag Card", "Please swipe card to write " + cardNumber + "/" + tokensSize);
                } else {
//                    createNotifyAlertDialog("Mag Encoder", "Mag Encoder not detected");
                    createSystemErrorConfirmation(AEONErrors.NO_USER_ACTION_REQUIRED, R.string.errorMagEncoder, false);
                }
            }
        }

        String screen = confirmation.getClass().getSimpleName();
        mFirebaseAnalytics.setCurrentScreen(this, screen, null);
    }

    @Override
    public void negativeButton(View view) {
        Log.d("negativeButton", "cancel pressed on " + confirmation.getClass().getSimpleName());
        dismissConfirmation();
        isEncodingMagToken = false;
        if (confirmation instanceof BluDroidElectricityPurchaseConfirmationDialog) {
            closeAeonSocket(3);
        }
    }

    @Override
    public void neutralButton(View view) {
        Log.d("neutralButton", "ok pressed on " + confirmation.getClass().getSimpleName());
    }

    @Override
    public void processFinish(String output) {

        dismissAlert();

        if (!magCardAction.equalsIgnoreCase("read")) {
            if (output.toLowerCase().contains("success")) {

                if (isReadingMag) {
                    alert = createMagCardAlertDialog("Mag Encoder", output);
                } else {
                    alert = createMagCardAlertDialog("NFC Reader", output);
                }
                alert.setPositiveOption("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        //get The tokennumber to be printed on redeem token slip
                        String tokenNumber = magCardDataList.get(0).getTrack3();

                        magCardDataList.remove(0);

                        if (magCardDataList.size() > 0) {
                            cardNumber++;
                            isElectricityResponseFirstTime = false;
                            results(electricityVoucherResponseMessage);
                        } else {

                            //offline encode token
                            if (isEncodingMagToken) {
                                cleanUp();
                                gotoMainScreen();
                                printRedeemTokenSlip(tokenNumber);

                                isEncodingMagToken = false;
                            } else {
                                //normal token sale
                                if (isVoucherPrinted) {
                                    printElectricityVoucher();

                                } else {
                                    cleanUp();
                                    createPrintErrorConfirmation();
                                }
                            }
                        }

                        dialog.dismiss();
                    }
                });
                alert.show();
            } else {
                alert = createMagCardAlertDialog("Mag Encoder", output + ", Would You like to retry?");
                alert.setPositiveOption("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        magCard.resetMsr();
                        MagCardData cardData = magCardDataList.get(0);
                        magCard.setTrack2(cardData.getTrack2());
                        magCard.setTrack3(cardData.getTrack3());

                        magCard.sendWriteCommand();
                        magCardAction = "write";

                        createNotifyAlertDialog("Mag Card", "Please swipe card to write " + cardNumber + "/" + tokensSize);
                    }
                });

                alert.setNegativeOption("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                        if (isEncodingMagToken) {
                            cleanUp();
                            gotoMainScreen();
                        } else {
                            //normal token sale
                            if (isVoucherPrinted) {
                                printElectricityVoucher();
                            } else {
                                cleanUp();
                                createPrintErrorConfirmation();
                            }
                        }
                    }
                });

                alert.show();
            }
        }
    }

    //----------------------------------------------------------------------------------------------
    public void onDestroy() {
        if (Build.MODEL.startsWith("CITAQ")) {
            if (magCard.isOpen()) {
                magCard.closeAdapter();
            }
        }

        super.onDestroy();
    }

    private void checkPicassoImageDiskCacheExpired() {
        String lastClear = getPreference(PREF_DISK_IMAGE_CACHE_CLEARED_DATE);
        String monthDateString = new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date());
        Log.d(TAG, "Disk image cache last cleared: " + lastClear);
        if (!lastClear.equals(monthDateString)) {
            Log.d(TAG, "Clearing disk image cache");
            clearPicassoImageDiskCache();
            updatePreference(PREF_DISK_IMAGE_CACHE_CLEARED_DATE, monthDateString);
        }
    }
}
