package za.co.blts.bltandroidgui3;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.StringTokenizer;

import za.co.blt.interfaces.external.messages.users.request.UsersRequestPermissionMessage;

/**
 * Created by NkosanaM on 4/5/2017.
 */

public class BluDroidPermissionsListAdapter extends ArrayAdapter<UsersRequestPermissionMessage> implements CompoundButton.OnCheckedChangeListener {


    private final String TAG = this.getClass().getSimpleName();
    private WeakReference<BaseActivity> baseActivityWeakReference;
    private int layoutResourceId;

    public BluDroidPermissionsListAdapter(BaseActivity context, int layoutResourceId, ArrayList<UsersRequestPermissionMessage> dataSet) {
        super(context, layoutResourceId, dataSet);
        this.layoutResourceId = layoutResourceId;
        this.baseActivityWeakReference = new WeakReference<>(context);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {

            UsersRequestPermissionMessage permission = getItem(position);

            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(getContext());
                convertView = inflater.inflate(layoutResourceId, parent, false);
            }

            CheckBox checkBox = convertView.findViewById(R.id.permissionsCheckBox);
            Log.v(TAG, "CHECKBOX" + checkBox);
            Log.v(TAG, "PERMISSION" + permission);
            Log.v(TAG, "PERMISSION TEXT" + permission.getText());
            Log.v(TAG, "===========================================");

            if (checkBox != null) {

                checkBox.setText(permission.getText());

                checkBox.setOnCheckedChangeListener(this);

                String tag = String.valueOf(position).trim();
                checkBox.setTag(Integer.parseInt(tag));

                checkBox.setId(Integer.parseInt(permission.getId()));

                if (baseActivity.user != null) {
                    if (!baseActivity.user.getPermissions().equals("")) {

                        StringTokenizer toks = new StringTokenizer(baseActivity.user.getPermissions(), ",");

                        while (toks.hasMoreTokens()) {
                            String permissionId = toks.nextToken();

                            for (int i = 0; i < baseActivity.usersResponseListPermissionTypesMessage.getData().getPermissions().size(); i++) {

                                //
                                // we are not implementing Emergency Top Up right now
                                //
                                if (baseActivity.usersResponseListPermissionTypesMessage.getData().getPermissions().get(i).getName() != null) {
                                    if (permissionId.equals(String.valueOf(checkBox.getId()))) {
                                        checkBox.setChecked(true);
                                    }
                                }
                            }

                        }
                    }

                }
            }
        }
        // Return the completed view to render on screen
        return convertView;
    }


    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        BaseActivity baseActivity = baseActivityWeakReference.get();
        if (baseActivity != null) {
            int position = (Integer) buttonView.getTag();
            UsersRequestPermissionMessage permission = getItem(position);

            if (isChecked) {
                baseActivity.permissions.add(permission);
            } else {
                baseActivity.permissions.remove(permission);
            }
        }
    }
}
