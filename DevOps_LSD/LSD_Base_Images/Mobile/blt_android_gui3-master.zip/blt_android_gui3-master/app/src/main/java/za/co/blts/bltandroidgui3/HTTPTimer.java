package za.co.blts.bltandroidgui3;

import android.os.CountDownTimer;
import android.util.Log;

class HTTPTimer extends CountDownTimer {

    private final String TAG = this.getClass().getSimpleName();

    private HTTPGetAsyncTask httpAsyncTask;

    public HTTPTimer(HTTPGetAsyncTask task, long millisInFuture, long countDownInterval) {
        super(millisInFuture, countDownInterval);
        httpAsyncTask = task;
    }

    public void onFinish() {
        try {
            Log.v(TAG, "HTTPTIMER finished");

            httpAsyncTask.disconnectHTTP();
            Log.v(TAG, "disconnected http");
            boolean b = httpAsyncTask.cancel(true);
            Log.v(TAG, "b is " + b);
            //
            // this doesn't seem to actually cancel the
            // asynctask, so we will notify the activity
            // directly
            //
            BaseActivity baseActivity = httpAsyncTask.baseActivityWeakReference.get();
            Log.v(TAG, "baseActivity is " + baseActivity);
        } catch (Exception exception) {
            Log.v(TAG, "problems with cancelling asynctask " + exception);
        }
    }

    public void onTick(long millisUntilFinished) {
        Log.v(TAG, "ticking for HTTP task " + httpAsyncTask + " " + millisUntilFinished + " left to go");
    }

}
