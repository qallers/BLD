package za.co.blts.nfcbus;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import za.co.blt.interfaces.external.factories.NfcBusRequestFactory;
import za.co.blt.interfaces.external.messages.nfcbus.NfcBusSvcSector;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusAuthenticationRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusGetCustomerResponseDataMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListCarriersResponseCompanyMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListCarriersResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListStopsResponseLocationMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusRouteMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusTicketMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.nfc.NfcCard;
import za.co.blts.nfc.NfcResult;
import za.co.blts.nfc.NfcResultable;
import za.co.blts.nfc.NfcSunmi;
import za.co.blts.nfc.NfcTappable;

import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_ID;
import static za.co.blts.bltandroidgui3.BluDroidPrefs.PREF_DEVICE_SER;

public class ActivityNfcBus extends BaseActivity implements NfcResultable {

    private final String TAG = this.getClass().getSimpleName();

    private final String EMPTY_DATA_BLOCK = "00000000000000000000000000000000";

    enum CardFuntion {
        CHECK_FORMAT,
        CHECK_DEFAULT,
        FORMAT,
        READ_UID,
        READ_CARD,
        WRITE_CARD,
    }

    public FragmentManager baseFm = getSupportFragmentManager();

    private final List<Ticket> tickets = new ArrayList<>();
    private Ticket currentTicket;
    private Stop depart = null, dest = null;
    private Fare fare = null;

    private NfcTappable tappable;
    private NfcResultable resultable;
    private NfcCard card;
    private String cardUid;
    private boolean cardFormatted = false;
    private NfcBusListCarriersResponseCompanyMessage carrier;
    private NfcBusAuthenticationResponseMessage nfcBusAuthenticationResponseMessage = null;
    private NfcBusListCarriersResponseMessage nfcBusListCarriersResponseMessage = null;
    private NfcBusGetCustomerResponseDataMessage customerResponseDataMessage = null;
    public Map<Long, HashMap<Long, NfcBusListStopsResponseLocationMessage>> stopsMap;
    private Map<Long, String> carriersMap;
    private NfcBusTicketCacheHandler ticketCacheHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nfc_bus);

        mFirebaseAnalytics.setCurrentScreen(this, TAG, null);

        toolbar = findViewById(R.id.toolbar);
        String title = "NFC Bus";
        toolbar.setTitle(title);
        toolbar.setSubtitle("");
        toolbar.setNavigationCloseIcon();

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoMainScreen();
            }
        });

        tappable = new NfcSunmi(this);

        ticketCacheHandler = new NfcBusTicketCacheHandler(nfcBusTicketCacheDir);
        ticketCacheHandler.removeExpiredCaches();

        initData();

        gotoTicketList();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        tappable.destroy();
    }

    private void initData() {
        stopsMap = new HashMap<>();
        carriersMap = new HashMap<>();

        tickets.clear();
//        for (int i = 0; i < 10; i++) {
//            tickets.add(new Ticket(251, "Trans. Corporation", i + 1, String.valueOf(i + 1), "day_pass", (i + 1) * 10 + ".00", i + 1, 314, "7 Star", 315, "Pizza Hutt", "2020-12-01", i % 3 == 0 ? "2020-12-17" : "2021-01-31", "confirmed"));
//        }
    }

    private void gotoFragment(Fragment f) {
        baseFm.beginTransaction().replace(R.id.content_frame, f, f.getClass().getSimpleName()).commit();
    }

    public void gotoTicketList() {
        tickets.clear();
        currentTicket = null;
        depart = null;
        dest = null;
        fare = null;
        card = null;
        cardUid = null;
        cardFormatted = false;
        carrier = null;
        gotoFragment(new FragmentTicketList());
    }

    public void gotoCustomerProfile() {
        gotoFragment(new FragmentCustomerProfile());
    }

    public void gotoNewTicket() {
        depart = null;
        dest = null;
        carrier = null;
        gotoFragment(new FragmentNewTicketEnhanced());
    }

    public void gotoListFares() {
        gotoFragment(new FragmentFareList());
    }

    public void gotoPurchaseTicket(boolean isRenew) {
        if (isRenew) {
            Log.d(TAG, "Purchase ticket " + currentTicket.getTicketId());
            depart = null;
            dest = null;
//            depart = new Stop(currentTicket.getDepartureId(), currentTicket.getDeparture());
//            dest = new Stop(currentTicket.getDestinationId(), currentTicket.getDestination());
        }
        gotoFragment(new FragmentPurchaseTicket());
    }

    @Override
    public void onBackPressed() {
        gotoMainScreen();
    }

    public NfcCard getCard() {
        return card;
    }

    public void setCard(NfcCard card) {
        this.card = card;
    }

    public String getCardUid() {
        return cardUid;
    }

    public void setCardUid(String cardUid) {
        this.cardUid = cardUid;
    }

    public boolean isCardFormatted() {
        return cardFormatted;
    }

    public void setCardFormatted(boolean cardFormatted) {
        this.cardFormatted = cardFormatted;
    }

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets.clear();
        this.tickets.addAll(tickets);
    }

    public NfcBusTicketCacheHandler getTicketCacheHandler() {
        return ticketCacheHandler;
    }

    public void setNfcBusTickets(List<NfcBusTicketMessage> tickets) {
        this.tickets.clear();
        for (NfcBusTicketMessage t : tickets) {
            //pending tickets need to be displayed, since the confirm schedular might not have sent the confirmCheckout to bpass yet
//            if (t.getStatus().equalsIgnoreCase("confirmed")) {
            String carrierName = carriersMap.get(t.getCompanyId()) == null ? "Unknown" : carriersMap.get(t.getCompanyId());

            String departName = "Unknown";
            try {
                departName = stopsMap.get(t.getCompanyId()).get(t.getDepartureId()).getName() == null ? "Unknown" : stopsMap.get(t.getCompanyId()).get(t.getDepartureId()).getName();
            } catch (Exception ignore) {
            }

            String destName = "Unknown";
            try {
                destName = stopsMap.get(t.getCompanyId()).get(t.getDestinationId()).getName() == null ? "Unknown" : stopsMap.get(t.getCompanyId()).get(t.getDestinationId()).getName();
            } catch (Exception ignore) {
            }

            boolean cancelable = ticketCacheHandler.getTicketFromCache(t.getCompanyId(), t.getTicketId()) != null;

            this.tickets.add(new Ticket(t.getCompanyId(), carrierName, t.getTicketId(), t.getTicketNo(), t.getTicketType(),
                    t.getFare(), t.getFareProductId(), t.getDepartureId(), departName, t.getDestinationId(), destName,
                    t.getTicketDate(), t.getExpiryDate(), t.getStatus(), t.getRoutes(), t.getRules(), cancelable));
//            }
        }
    }

    public Ticket getCurrentTicket() {
        return currentTicket;
    }

    public void setCurrentTicket(Ticket currentTicket) {
        this.currentTicket = currentTicket;
    }

    public Stop getDepart() {
        return depart;
    }

    public void setDepart(Stop depart) {
        this.depart = depart;
    }

    public Stop getDest() {
        return dest;
    }

    public void setDest(Stop dest) {
        this.dest = dest;
    }

    public Fare getFare() {
        return fare;
    }

    public void setFare(Fare fare) {
        this.fare = fare;
    }

    public NfcBusAuthenticationResponseMessage getNfcBusAuthenticationResponseMessage() {
        return nfcBusAuthenticationResponseMessage;
    }

    public void setNfcBusAuthenticationResponseMessage(NfcBusAuthenticationResponseMessage nfcBusAuthenticationResponseMessage) {
        this.nfcBusAuthenticationResponseMessage = nfcBusAuthenticationResponseMessage;
    }

    public NfcBusListCarriersResponseMessage getNfcBusListCarriersResponseMessage() {
        return nfcBusListCarriersResponseMessage;
    }

    public void setNfcBusListCarriersResponseMessage(NfcBusListCarriersResponseMessage nfcBusListCarriersResponseMessage) {
        this.nfcBusListCarriersResponseMessage = nfcBusListCarriersResponseMessage;
        carriersMap.clear();
        if (nfcBusListCarriersResponseMessage != null) {
            for (NfcBusListCarriersResponseCompanyMessage c : nfcBusListCarriersResponseMessage.getDetail().getCompanies()) {
                carriersMap.put(c.getCompanyId(), c.getName());
            }
        }
    }

    public NfcBusGetCustomerResponseDataMessage getCustomerResponseDataMessage() {
        return customerResponseDataMessage;
    }

    public void setCustomerResponseDataMessage(NfcBusGetCustomerResponseDataMessage customerResponseDataMessage) {
        this.customerResponseDataMessage = customerResponseDataMessage;
        if (customerResponseDataMessage == null) {
            toolbar.setSubtitle("");
        } else {
            String name = customerResponseDataMessage.getName() + " " + customerResponseDataMessage.getSurname();
            toolbar.setSubtitle(name);
        }
    }

    public NfcBusListCarriersResponseCompanyMessage getCarrier() {
        return carrier;
    }

    public void setCarrier(NfcBusListCarriersResponseCompanyMessage carrier) {
        this.carrier = carrier;
    }

    public NfcTappable getTappable() {
        return tappable;
    }

    public void setResultable(NfcResultable resultable) {
        this.resultable = resultable;
    }

    public void authForNfcBus(BaseFragment frag) {
        createProgress(getResources().getString(R.string.authenticating));
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusAuthenticationRequestMessage req = factory.auth(loginResponseMessage.getData().getUserPin(),
                getPreference(PREF_DEVICE_ID),
                getPreference(PREF_DEVICE_SER),
                "SmartTapEldo");
        startAEONAsyncTask(frag, socket, req);
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public void handleNfcResult(NfcResult result) {
        if (resultable != null) {
            resultable.handleNfcResult(result);
        }
    }

    public ArrayList<NfcBusSvcSector> getSvc() {
        ArrayList<NfcBusSvcSector> svc = new ArrayList<>();
        try {
            for (int i = 10; i < 14; i++) {
                NfcBusSvcSector sector = new NfcBusSvcSector();
                sector.setSectorNum(card.getBlocks().get((i - 10) * 3).getNum() / 4);
                sector.setBlock0(card.getBlocks().get((i - 10) * 3).getData());
                sector.setBlock1(card.getBlocks().get((i - 10) * 3 + 1).getData());
                sector.setBlock2(card.getBlocks().get((i - 10) * 3 + 2).getData());
                svc.add(sector);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return svc;
    }

    public ArrayList<NfcBusSvcSector> getSvcWithoutBlank() {
        ArrayList<NfcBusSvcSector> svc = new ArrayList<>();
        boolean cardEmpty = true;
        try {
            for (int i = 10; i < 14; i++) {
                NfcBusSvcSector sector = new NfcBusSvcSector();
                sector.setSectorNum(card.getBlocks().get((i - 10) * 3).getNum() / 4);
                sector.setBlock0(card.getBlocks().get((i - 10) * 3).getData());
                sector.setBlock1(card.getBlocks().get((i - 10) * 3 + 1).getData());
                sector.setBlock2(card.getBlocks().get((i - 10) * 3 + 2).getData());
                svc.add(sector);
                if (cardEmpty &&
                        (!card.getBlocks().get((i - 10) * 3).getData().equals(EMPTY_DATA_BLOCK)
                                || !card.getBlocks().get((i - 10) * 3 + 1).getData().equals(EMPTY_DATA_BLOCK)
                                || !card.getBlocks().get((i - 10) * 3 + 2).getData().equals(EMPTY_DATA_BLOCK))) {
                    cardEmpty = false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (cardEmpty) {
            svc = new ArrayList<>();
        }
        return svc;
    }

    public String getUpRoute(List<NfcBusRouteMessage> routes) {
        String up = "";
        List<String> stopsUp = new ArrayList<>();
        for (NfcBusRouteMessage route : routes) {
            if (!route.getDepartureUp().isEmpty() && !stopsUp.contains(route.getDepartureUp())) {
                stopsUp.add(route.getDepartureUp());
            }
            if (!route.getDestinationUp().isEmpty() && !stopsUp.contains(route.getDestinationUp())) {
                stopsUp.add(route.getDestinationUp());
            }
        }

        for (String stop : stopsUp) {
            up += stop + ", ";
        }
        return up.isEmpty() ? up : up.substring(0, up.length() - 2);
    }

    public String getDownRoute(List<NfcBusRouteMessage> routes) {
        String down = "";
        List<String> stopsDown = new ArrayList<>();
        for (NfcBusRouteMessage route : routes) {
            if (!route.getDepartureDown().isEmpty() && !stopsDown.contains(route.getDepartureDown())) {
                stopsDown.add(route.getDepartureDown());
            }
            if (!route.getDestinationDown().isEmpty() && !stopsDown.contains(route.getDestinationDown())) {
                stopsDown.add(route.getDestinationDown());
            }
        }

        for (String stop : stopsDown) {
            down += stop + ", ";
        }

        return down.isEmpty() ? down : down.substring(0, down.length() - 2);
    }

}