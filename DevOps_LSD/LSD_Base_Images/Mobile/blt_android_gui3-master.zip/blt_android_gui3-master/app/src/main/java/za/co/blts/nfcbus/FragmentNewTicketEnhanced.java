package za.co.blts.nfcbus;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.analytics.FirebaseAnalytics;

import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import za.co.blt.interfaces.external.factories.NfcBusRequestFactory;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusLookupDestinationsRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.request.NfcBusLookupFaresRequestMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusAuthenticationResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListCarriersResponseCompanyMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusListStopsResponseLocationMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupDestinationsResponseLocationMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupDestinationsResponseMessage;
import za.co.blt.interfaces.external.messages.nfcbus.response.NfcBusLookupFaresResponseMessage;
import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.BaseFragment;
import za.co.blts.bltandroidgui3.NeedsAEONResults;
import za.co.blts.bltandroidgui3.R;
import za.co.blts.bltandroidgui3.confirmations.BluDroidConfirmationDialog;
import za.co.blts.bltandroidgui3.widgets.BluDroidButton;
import za.co.blts.bltandroidgui3.widgets.BluDroidEditText;


public class FragmentNewTicketEnhanced extends BaseFragment implements NeedsAEONResults {
    private final String TAG = this.getClass().getSimpleName();

    private final List<Stop> carriers = new ArrayList<>();
    private final List<Stop> departList = new ArrayList<>();
    private final List<Stop> destList = new ArrayList<>();

    private boolean byFare = false;

    private enum Selection {
        CARRIER,
        DEPARTURE,
        DESTINATION,
    }

    private Selection selection;

    private BluDroidButton btnNext;
    private LinearLayout layByFare, layByStops;
    private RadioGroup rgFareStops;
    private ImageButton btnCarrier, btnDepart, btnDest;
    private BluDroidEditText txtFareNum, txtCarrier, txtDeparture, txtDestination;
    private BluDroidConfirmationDialog dialog;

    public FragmentNewTicketEnhanced() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "New ticket");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_new_ticket_enhanced, container, false);

        layByFare = rootView.findViewById(R.id.layByFare);
        layByStops = rootView.findViewById(R.id.layByStops);

        txtCarrier = rootView.findViewById(R.id.txtCarrier);
        txtDeparture = rootView.findViewById(R.id.txtDeparture);
        txtDestination = rootView.findViewById(R.id.txtDestination);

        txtFareNum = rootView.findViewById(R.id.txtFareNum);
        txtFareNum.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                enableDisableButtons();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        rgFareStops = rootView.findViewById(R.id.rgFareStops);
        rgFareStops.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                Log.d(TAG, "rb selection changed");
                byFare = checkedId == R.id.rbFare;
                txtFareNum.setText("");
                ((ActivityNfcBus) getActivity()).setDepart(null);
                ((ActivityNfcBus) getActivity()).setDest(null);
                displayScreen();
                enableDisableButtons();
            }
        });

        btnCarrier = rootView.findViewById(R.id.btnCarrier);
        btnCarrier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selection = Selection.CARRIER;
                showStopsDialog();
            }
        });

        btnDepart = rootView.findViewById(R.id.btnDepart);
        btnDepart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selection = Selection.DEPARTURE;
                showStopsDialog();
            }
        });
        btnDest = rootView.findViewById(R.id.btnDest);
        btnDest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selection = Selection.DESTINATION;
                showStopsDialog();
            }
        });

        BluDroidButton btnCancel = rootView.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getBaseActivity().firebaseBundle = new Bundle();
                getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, TAG + " " + ((ActivityNfcBus) getActivity()).getCardUid());
                getBaseActivity().mFirebaseAnalytics.logEvent("nfcbus_purchase_cancel", getBaseActivity().firebaseBundle);

                ((ActivityNfcBus) getActivity()).setDepart(null);
                ((ActivityNfcBus) getActivity()).setDest(null);
                ((ActivityNfcBus) getActivity()).gotoTicketList();
            }
        });

        btnNext = rootView.findViewById(R.id.btnNext);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (byFare) {
                    ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentNewTicketEnhanced.this);
                } else {
                    ((ActivityNfcBus) getActivity()).gotoListFares();
                }
            }
        });

        setupCarriers();
        displayScreen();
        enableDisableButtons();

        return rootView;
    }

    private void displayScreen() {
        if (byFare) {
            txtFareNum.setText("");
            layByFare.setVisibility(View.VISIBLE);
            layByStops.setVisibility(View.GONE);
        } else {
            txtFareNum.setText("");
            layByFare.setVisibility(View.GONE);
            layByStops.setVisibility(View.VISIBLE);
        }
    }

    private void enableDisableButtons() {
        if (((ActivityNfcBus) getActivity()).getCarrier() == null) {
            btnCarrier.setEnabled(false);
            btnCarrier.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            btnNext.setEnabled(false);
            btnNext.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            btnDepart.setEnabled(false);
            btnDepart.setBackgroundColor(getResources().getColor(R.color.lightGrey));
            btnDest.setEnabled(false);
            btnDest.setBackgroundColor(getResources().getColor(R.color.lightGrey));

        } else {
            btnCarrier.setEnabled(true);
            btnCarrier.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());

            if (byFare) {
                try {

                    if (txtFareNum.getText().toString().trim().isEmpty()) {
                        btnNext.setEnabled(false);
                        btnNext.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                    } else {
                        Long.parseLong(txtFareNum.getText().toString().trim());
                        btnNext.setEnabled(true);
                        btnNext.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());
                    }
                } catch (Exception e) {
                    Toast.makeText(getContext(), "Invalid Fare ID entered", Toast.LENGTH_SHORT).show();
                    btnNext.setEnabled(false);
                    btnNext.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                }

            } else {

                if (departList.isEmpty()) {
                    btnDepart.setEnabled(false);
                    btnDepart.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                } else {
                    btnDepart.setEnabled(true);
                    btnDepart.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());
                }

                if (destList.isEmpty()) {
                    btnDest.setEnabled(false);
                    btnDest.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                } else {
                    btnDest.setEnabled(true);
                    btnDest.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());
                }

                if (((ActivityNfcBus) getActivity()).getDest() == null) {
                    btnNext.setEnabled(false);
                    btnNext.setBackgroundColor(getResources().getColor(R.color.lightGrey));
                } else {
                    btnNext.setEnabled(true);
                    btnNext.setBackgroundColor(getBaseActivity().getSkinResources().getButtonColor());

                    Log.v(TAG, "carrier: " + ((ActivityNfcBus) getActivity()).getCarrier());
                    Log.v(TAG, "depart: " + ((ActivityNfcBus) getActivity()).getDepart());
                    Log.v(TAG, "dest: " + ((ActivityNfcBus) getActivity()).getDest());

                    Log.v(TAG, "map depart: " + ((ActivityNfcBus) getActivity()).stopsMap.get(((ActivityNfcBus) getActivity()).getCarrier().getCompanyId()).get(((ActivityNfcBus) getActivity()).getDepart().getId()));
                    Log.v(TAG, "map dest: " + ((ActivityNfcBus) getActivity()).stopsMap.get(((ActivityNfcBus) getActivity()).getCarrier().getCompanyId()).get(((ActivityNfcBus) getActivity()).getDest().getId()));
                }
            }
        }
    }

    private void setupCarriers() {
        carriers.clear();
        for (NfcBusListCarriersResponseCompanyMessage c : ((ActivityNfcBus) getActivity()).getNfcBusListCarriersResponseMessage().getDetail().getCompanies()) {
            carriers.add(new Stop(c.getCompanyId(), c.getName()));
        }

        if (!carriers.isEmpty()) {
            txtCarrier.setText(carriers.get(0).getName());
            NfcBusListCarriersResponseCompanyMessage c = new NfcBusListCarriersResponseCompanyMessage();
            c.setCompanyId(carriers.get(0).getId());
            c.setName(carriers.get(0).getName());
            ((ActivityNfcBus) getActivity()).setCarrier(c);
            getStops();
        }

    }

    private void getStops() {
        departList.clear();
        HashMap<Long, NfcBusListStopsResponseLocationMessage> map = ((ActivityNfcBus) getActivity()).stopsMap.get(((ActivityNfcBus) getActivity()).getCarrier().getCompanyId());
        if (map != null) {
            for (Map.Entry<Long, NfcBusListStopsResponseLocationMessage> entry : map.entrySet()) {
                departList.add(new Stop(entry.getValue().getId(), entry.getValue().getName()));
            }
        }
        Collections.sort(departList);
        Log.d(TAG, "number of stops for carrer: " + departList.size());
    }

    private void getDestinations(String sessionId) {
        getBaseActivity().createProgress(getResources().getString(R.string.getting_destinations));
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusLookupDestinationsRequestMessage req = factory.lookupDestinations(sessionId, ((ActivityNfcBus) getActivity()).getCarrier().getCompanyId(), ((ActivityNfcBus) getActivity()).getDepart().getId());
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }

    private void lookupFare(String sessionId) {
        getBaseActivity().createProgress(R.string.getting_fare_products);
        NfcBusRequestFactory factory = new NfcBusRequestFactory();
        NfcBusLookupFaresRequestMessage req = factory.lookupFare(sessionId,
                ((ActivityNfcBus) getActivity()).getCarrier().getCompanyId(),
                Long.parseLong(txtFareNum.getText().toString().trim()));
        getBaseActivity().startAEONAsyncTask(this, BaseActivity.socket, req);
    }


    @Override
    public void results(Object object) {
        if (object instanceof NfcBusAuthenticationResponseMessage) {
            if (((NfcBusAuthenticationResponseMessage) object).getEvent().getEventCode().equals("0")) {
                if (byFare) {
                    lookupFare(((NfcBusAuthenticationResponseMessage) object).getSessionId());
                } else {
                    getDestinations(((NfcBusAuthenticationResponseMessage) object).getSessionId());
                }
            } else {
                getBaseActivity().createSystemErrorConfirmation(object, true);
            }
        } else if (object instanceof NfcBusLookupDestinationsResponseMessage) {
            getBaseActivity().closeAeonSocket(36);
            if (((NfcBusLookupDestinationsResponseMessage) object).getEvent().getEventCode().equals("0")) {
                getBaseActivity().dismissProgress();
                destList.clear();
                for (NfcBusLookupDestinationsResponseLocationMessage dest : ((NfcBusLookupDestinationsResponseMessage) object).getDetail().getLocations()) {
                    destList.add(new Stop(dest.getId(), dest.getName()));
                }
                Collections.sort(destList);
                if (destList.isEmpty()) {
                    Toast.makeText(getContext(), "No destinations found", Toast.LENGTH_SHORT).show();
                }
                enableDisableButtons();
            } else {
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }

        } else if (object instanceof NfcBusLookupFaresResponseMessage) {
            getBaseActivity().dismissProgress();
            getBaseActivity().closeAeonSocket(40);
            if (((NfcBusLookupFaresResponseMessage) object).getEvent().getEventCode().equals("0")) {
                if (((NfcBusLookupFaresResponseMessage) object).getDetail().getStatus().equals("1")) {
                    if (((NfcBusLookupFaresResponseMessage) object).getDetail().getFares().size() == 1) {
                        ((ActivityNfcBus) getActivity()).setFare(new Fare(((NfcBusLookupFaresResponseMessage) object).getDetail().getFares().get(0)));
                        ((ActivityNfcBus) getActivity()).gotoPurchaseTicket(false);
                    } else {
                        getBaseActivity().returnToFavouritesScreen = false;
                        getBaseActivity().createSystemErrorConfirmation("Unable to get Fare details", false);
                    }
                } else {
                    getBaseActivity().returnToFavouritesScreen = false;
                    getBaseActivity().createSystemErrorConfirmation(((NfcBusLookupFaresResponseMessage) object).getDetail().getMessage(), false);
                }
            } else {
                getBaseActivity().returnToFavouritesScreen = false;
                getBaseActivity().createSystemErrorConfirmation(object, false);
            }

        }

        if (object != null && !(object instanceof Socket)) {
            getBaseActivity().firebaseBundle = new Bundle();
            getBaseActivity().firebaseBundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, object.getClass().getSimpleName());
            getBaseActivity().mFirebaseAnalytics.logEvent("aeon_connection", getBaseActivity().firebaseBundle);
        }
    }

    private void showStopsDialog() {
        try {
//            Log.w(TAG, "num Stops: " + (isDestination ? destList.size() : departList.size()));
            dialog = new NfcBusSelectStopDialog((ActivityNfcBus) getActivity(),
                    selection == Selection.DEPARTURE ? departList : selection == Selection.DESTINATION ? destList : carriers,
                    selection == Selection.DEPARTURE ? "Departure" : selection == Selection.DESTINATION ? "Destination " : "Carrier",
                    this);
            String screen = dialog.getClass().getSimpleName();
            ((ActivityNfcBus) getActivity()).mFirebaseAnalytics.setCurrentScreen(getActivity(), screen, null);
        } catch (Exception exception) {
            BaseActivity.logger.error("showStopsDialog " + exception);
            exception.printStackTrace();
        }
    }

    public void setSelectedStop(Stop stop) {
        Log.d(TAG, "setSelectedStop: " + stop + " for " + selection);
        if (selection == Selection.DESTINATION) {
            ((ActivityNfcBus) getActivity()).setDest(stop);
            txtDestination.setText(stop.getName());
        } else if (selection == Selection.DEPARTURE) {
            ((ActivityNfcBus) getActivity()).setDepart(stop);
            ((ActivityNfcBus) getActivity()).setDest(null);
            txtDeparture.setText(stop.getName());
            txtDestination.setText("");
            ((ActivityNfcBus) getActivity()).authForNfcBus(FragmentNewTicketEnhanced.this);
        } else {
            txtCarrier.setText(stop.getName());
            NfcBusListCarriersResponseCompanyMessage c = new NfcBusListCarriersResponseCompanyMessage();
            c.setCompanyId(stop.getId());
            c.setName(stop.getName());
            ((ActivityNfcBus) getActivity()).setCarrier(c);
            getStops();

            ((ActivityNfcBus) getActivity()).setDepart(null);
            txtDeparture.setText("");
            ((ActivityNfcBus) getActivity()).setDest(null);
            txtDestination.setText("");
        }
        enableDisableButtons();
    }

}