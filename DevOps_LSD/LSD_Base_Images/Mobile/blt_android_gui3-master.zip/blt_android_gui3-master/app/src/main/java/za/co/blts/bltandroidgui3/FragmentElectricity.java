package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import za.co.blts.magcard.BluDroidMagCardAsyncReponse;

/**
 * Created by warrenm on 2016/10/03.
 */

public class FragmentElectricity extends ElectricityRecycler implements BluDroidMagCardAsyncReponse {

    private final String TAG = this.getClass().getSimpleName();

    public FragmentElectricity() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_electricity, container, false);
        recycler = rootView.findViewById(R.id.bluRecycler);

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        String title = getActivity().getResources().getString(R.string.electricity);
        getActivity().setTitle(title);
        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();
        populateScreen();
    }

    public void populateScreen() {

        setupRecycler();
    }

    @Override
    public boolean onBackPressed() {

        getBaseActivity().gotoMainScreen();

        return true;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "Enter onDestroy");

//        if (Build.MODEL.startsWith("CITAQ")) {
//            if (!getBaseActivity().magCard.isOpen()) {
//                getBaseActivity().magCard.closeAdapter();
//            }
//        }

        super.onDestroy();
        Log.d(TAG, "Leave onDestroy");
    }

    public void onResume() {
        Log.d(TAG, "Enter onResume");
        super.onResume();
    }

    @Override
    public void processFinish(String output) {

    }
}