package za.co.blts.bltandroidgui3.cardviews;

import android.app.Activity;

import za.co.blts.bltandroidgui3.BaseActivity;

public class CardviewVoucherMenu extends CardviewDataObject {

    public CardviewVoucherMenu(Activity baseActivity, String cardDesc, String tag) {
        super(cardDesc, ((BaseActivity) baseActivity).getSkinResources().getButtonColor(), tag);
    }

    public CardviewVoucherMenu(Activity baseActivity, int iconID, int cardColor, String cardDesc, String tag) {
        super(cardDesc, iconID, baseActivity.getResources().getColor(cardColor), tag);
    }

    public CardviewVoucherMenu(Activity baseActivity, int iconID, int cardColor, String cardDesc, String tag, String provider) {
        super(cardDesc, iconID, baseActivity.getResources().getColor(cardColor), tag);
        setProvider(provider);
    }

}

