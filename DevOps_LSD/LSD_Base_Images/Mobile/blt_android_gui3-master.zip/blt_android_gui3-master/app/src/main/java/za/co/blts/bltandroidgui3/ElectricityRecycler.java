package za.co.blts.bltandroidgui3;

import java.util.ArrayList;
import java.util.Map;

import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseManufacturerMessage;
import za.co.blt.interfaces.external.messages.voucherlist.response.VoucherListResponseProductMessage;
import za.co.blts.bltandroidgui3.cardviews.CardViewElectricity;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.cardviews.CardviewUnipin;

/**
 * Created by NkosanaM on 3/17/2017.
 */

class ElectricityRecycler extends VoucherRecycler {

    private ElectricityUtility eu = null;

    void setupRecycler() {
        configureRecycler(createElectricityCards(retrieveMunics(), retrieveUniPin()));
    }

    private Map<String, String> retrieveMunics() {

        Map<String, String> munics = null;
        if (BaseActivity.loginResponseMessage != null) {
            eu = new ElectricityUtility();
            munics = eu.getElectricity();
        }

        return munics;
    }

    private Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> retrieveUniPin() {


        Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> uniPin = null;
        if (BaseActivity.loginResponseMessage != null) {
            eu = new ElectricityUtility();
            uniPin = eu.getVouchers("Electricity");
        }

        return uniPin;
    }

    private ArrayList<CardviewDataObject> createElectricityCards(Map<String, String> munics, Map<VoucherListResponseManufacturerMessage, ArrayList<VoucherListResponseProductMessage>> uniPinVouchers) {

        String currency = getResources().getString(R.string.currency);
        String voucher = getResources().getString(R.string.voucher);
        ArrayList<CardviewDataObject> list = new ArrayList<>();

        String voucherTypeDesc = "Electricity";
        if (munics != null) {
            for (String municRealName : munics.keySet()) {

                String municName = munics.get(municRealName);
                if (municName.equalsIgnoreCase("electricity") || municName.equalsIgnoreCase("eskom")) {
                    if (municName.equalsIgnoreCase("eskom")) {
                        list.add(new CardViewElectricity(getActivity(), municName, "", R.drawable.eskom, "", "munics", municRealName, voucherTypeDesc));
                    } else {
                        list.add(new CardViewElectricity(getActivity(), municName, "", "", "munics", municRealName, voucherTypeDesc));
                    }
                }
            }
            if (munics.size() > 0)
                list.add(new CardViewElectricity(getActivity(), "Free Basic Electricity", "", "", "munics", "FBE", voucherTypeDesc));

        }

        if (munics != null) {
            for (String municRealName : munics.keySet()) {
                String municName = munics.get(municRealName);
                if (!(municName.equalsIgnoreCase("electricity") || municName.equalsIgnoreCase("eskom"))) {

                    String shortname = getBaseActivity().getShortName(municName);
                    int resId = getBaseActivity().getDrawableResource(shortname);

                    if (resId != 0) {
                        list.add(new CardViewElectricity(getActivity(), municName, "", resId, "", "munics", municRealName, voucherTypeDesc));
                    } else {
                        list.add(new CardViewElectricity(getActivity(), municName, "", "", "munics", municRealName, voucherTypeDesc));
                    }
                }
            }
        }

        if (uniPinVouchers != null) {
            for (VoucherListResponseManufacturerMessage mapKey : uniPinVouchers.keySet()) {
                boolean hasAirtimePlus = mapKey.getAirtimePlus().equals("1");
                ArrayList<VoucherListResponseProductMessage> products = uniPinVouchers.get(mapKey);
                String key = mapKey.getName();
                for (VoucherListResponseProductMessage product : products) {
                    if (key.equals("UniPin")) {
                        list.add(new CardviewUnipin(getBaseActivity(), getCleanDesc(product.getName(), key), currency + product.getValue().replace(".00", ""), product.getText(), voucher, key, product.getCategoryDesc(), hasAirtimePlus));
                    }
                }
            }
        }
        return list;
    }
}
