package za.co.blts.bltandroidgui3.widgets;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;

public class MoneyWatcher implements TextWatcher {

    private final String TAG = this.getClass().getSimpleName();

    private ScreenFlow screenFlow;
    private EditText editText;

    public MoneyWatcher(ScreenFlow screenFlow, EditText editText) {
        super();
        this.screenFlow = screenFlow;
        this.editText = editText;
    }

    public void afterTextChanged(Editable s) {
    }

    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    public void onTextChanged(CharSequence s, int start, int before, int count) {
        int pos = editText.getText().toString().indexOf(".");

        Log.v(TAG, editText.getText().toString() + " pos " + pos);
        if (pos != -1) {
            if (editText.getText().toString().length() == (pos + 3)) {
                screenFlow.gotMaxChars(editText);
            } else if (editText.getText().toString().length() > (pos + 3)) {
                Log.v(TAG, "too many chars");
                String st = editText.getText().toString();
                st = st.substring(0, pos + 3);
                editText.setText(st);
                editText.setSelection(pos + 3);
                screenFlow.gotMaxChars(editText);
            }
        }
    }

}
