package za.co.blts.bltandroidgui3.widgets;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Log;

import java.util.Locale;

import za.co.blts.bltandroidgui3.BaseActivity;
import za.co.blts.bltandroidgui3.R;

//
// view and button stuff
//


//
// this class merely lightens up the button when it is touched
// and returns the color to its original when it is untouched
//
public class BluDroidMoneyEditText extends BluDroidEditText {

    private final String TAG = this.getClass().getSimpleName();

    private String editTextCategory;
    private float minValue;
    private float maxValue;

    private void setUpMoney() {
        setInputType(InputType.TYPE_CLASS_NUMBER);
        setKeyListener(new BluDroidMoneyValueFilter());
        setHintText("0.00");
    }

    public BluDroidMoneyEditText(BaseActivity context) {
        super(context);
        setUpMoney();
    }

    public BluDroidMoneyEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        setUpMoney();
        @SuppressLint("CustomViewStyleable") TypedArray attributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidEditText);

        try {
            editTextCategory = attributesArray.getString(R.styleable.BluDroidEditText_EditTextCategory);
        } catch (Exception e) {
            e.printStackTrace();
        }
        attributesArray.recycle();

        attributesArray = context.obtainStyledAttributes(attrs, R.styleable.BluDroidMoneyEditText);

        try {
            minValue = attributesArray.getFloat(R.styleable.BluDroidMoneyEditText_minValue, -1);
            maxValue = attributesArray.getFloat(R.styleable.BluDroidMoneyEditText_maxValue, -1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        attributesArray.recycle();
    }

    //
// this will add decimal point and two 00s if necessary
//
    public String getAmount() {
        String money = getText().toString();
        if (!money.trim().isEmpty()) {
            int pos = money.indexOf(".");
            if (pos == -1) {
                return money + ".00";
            } else if (pos == money.length() - 1) {
                return money + "00";
            } else if (pos == money.length() - 2) {
                return money + "0";
            }
        }
        return money;
    }

    private void setHintText(String hintText) {
        setHint(hintText);
    }

    @Override
    public boolean validate() {
        //BaseActivity.logger.info(": validate()");
        Log.d(TAG, "validate Money");

        String amountString = getText().toString().trim();
        boolean isValidated = false;

        setText(getAmount());
        Log.d("ProfDisp", "money value = " + getAmount());

        if (tryParseFloat(amountString)) {
            if (minValue == -1 && maxValue == -1){
                Log.d("ProfDisp", "min/max not set");
                //min and max not set
                removeErrorMessage();
                isValidated = true;
            } else {
                float value = Float.parseFloat(amountString);

                if (value >= minValue && value <= maxValue) {
                    Log.d("ProfDisp", "value in range");
                    removeErrorMessage();
                    isValidated = true;
                } else {
                    Log.d("ProfDisp", "value out of range");
                    String msg = String.format(Locale.US, "Must be between R%.2f and R%.2f", minValue, maxValue);
                    setErrorMessage(msg);
                    BaseActivity baseScreen = baseActivityWeakReference.get();
                    if (baseScreen != null) {
                        if ("billPaymentLimitSettings".equalsIgnoreCase(editTextCategory)) {
                            baseScreen.deviceUserSettingsHaserrors = true;
                        } else if ("balanceWarningAmount".equalsIgnoreCase(editTextCategory)) {
                            baseScreen.accountBalanceSettingsHaserrors = true;
                        }
                    }
                }
            }

        } else {
            Log.d("ProfDisp", "parseFloat failed");
            BaseActivity baseScreen = baseActivityWeakReference.get();
            setErrorMessage("Required");
            if (baseScreen != null) {
                if ("billPaymentLimitSettings".equalsIgnoreCase(editTextCategory)) {
                    baseScreen.deviceUserSettingsHaserrors = true;
                } else if ("balanceWarningAmount".equalsIgnoreCase(editTextCategory)) {
                    baseScreen.accountBalanceSettingsHaserrors = true;
                }
            }
        }
        return isValidated;
    }

    private boolean tryParseFloat(String value) {
        try {
            Float.parseFloat(value);
            return true;
        } catch (NumberFormatException e) {
            BaseActivity baseScreen = baseActivityWeakReference.get();
            if (baseScreen != null) {
                setErrorMessage(baseScreen.getResources().getString(R.string.moneyBadAmount));
            }
            return false;
        }
    }

    public void setMinValue(float minValue) {
        this.minValue = minValue;
    }

    public void setMaxValue(float maxValue) {
        this.maxValue = maxValue;
    }
}

