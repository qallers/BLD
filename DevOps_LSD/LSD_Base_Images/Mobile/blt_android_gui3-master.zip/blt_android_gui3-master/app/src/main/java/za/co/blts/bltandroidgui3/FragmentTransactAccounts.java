package za.co.blts.bltandroidgui3;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;

import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProductMessage;
import za.co.blt.interfaces.external.messages.billpayments.response.BillPaymentsResponseProviderMessage;
import za.co.blts.bltandroidgui3.cardviews.CardViewBillPayment;
import za.co.blts.bltandroidgui3.cardviews.CardviewDataObject;
import za.co.blts.bltandroidgui3.widgets.BluDroidSearchEditText;
import za.co.blts.bltandroidgui3.widgets.BluRecyclerView;


public class FragmentTransactAccounts extends BaseFragment implements View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();

    private BluDroidSearchEditText search = null;

    private ArrayList<CardviewDataObject> list;

    public FragmentTransactAccounts() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //getBaseActivity().authenticateForBillPayments();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_transact_accounts, container, false);

        search = rootView.findViewById(R.id.search);

        getBaseActivity().mFirebaseAnalytics.setCurrentScreen(getBaseActivity(), TAG, null);


        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        String title = getActivity().getResources().getString(R.string.transact);
        getBaseActivity().toolbar.setTitle(title);
        getBaseActivity().toolbar.setNavigationDrawable();
        menuFragmentClickListener();
        getBaseActivity().hideKeyboard();

        //if(((BaseActivity) getActivity()).billPaymentsResponseProductListMessage != null) {
        configureRecycler();
        //}

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable editable) {
                adapter.setFilterSearch(search.getText().toString());
            }

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
        });

    }


    @Override
    public void onClick(View view) {

    }

    private void configureRecycler() {
        BluRecyclerView recycler = getActivity().findViewById(R.id.billRecycler);
        recycler.setHasFixedSize(true);

        list = new ArrayList<>();
        ArrayList<SortableProduct> products = new ArrayList<>();

        if (BaseActivity.loginResponseMessage.getData().canDoMerchantTransfer()) {
            Log.d(TAG, "configureRecycler: canDoMerchantTransfer()");
            SortableProduct merchantTransfers = new SortableProduct("Merchant To Merchant Transfer");
            products.add(merchantTransfers);
        }

        if (BaseActivity.billPaymentsResponseProductListMessage != null && BaseActivity.billPaymentsResponseProductListMessage.getData().getProviders().size() > 0) {

            for (int i = 0; i < BaseActivity.billPaymentsResponseProductListMessage.getData().getProviders().size(); i++) {
                BillPaymentsResponseProviderMessage provider = BaseActivity.billPaymentsResponseProductListMessage.getData().getProviders().get(i);
                for (int j = 0; j < provider.getProducts().size(); j++) {
                    BillPaymentsResponseProductMessage product = provider.getProducts().get(j);
                    SortableProduct newProduct = new SortableProduct(product, provider);
                    products.add(newProduct);
                }
            }
            Collections.sort(products, SortableProduct.ProductComparator);

            for (int i = 0; i < products.size(); i++) {
                SortableProduct product = products.get(i);
                BillPaymentsResponseProviderMessage provider = product.getProvider();

                //
                // ignore traffic fines right now
                //
                if (provider != null) {
                    if (provider.getName().contains("Traffic Fine") || provider.getName().contains("Fine Payment")) {
                        continue;
                    }
                    //
                    // ignore bus tickets right now
                    //
                    if (provider.getName().equals("Pay@ Bus Tickets")) {
                        continue;
                    }
                    //
                    // ignore insurance premiums right now
                    //
                    if (provider.getName().equals("Pay@ insurance Payment")) {
                        continue;
                    }

                    if (provider.getName().equals("SAPO Account Payment")) {
                        addToProductList(product.getName(), provider.getName(), product.getLogoId());
                    } else if (provider.getName().equals("Pay@ Account Payment")) {
                        addToProductList(product.getName(), provider.getName(), product.getLogoId());
                    } else if (provider.getName().equals("Blu Bill Payment")) {
                        addToProductList(product.getName(), provider.getName(), product.getLogoId());
                    } else if (provider.getName().equals("Syntell Account Payment")) {
                        addToProductList(product.getName(), provider.getName(), product.getLogoId());
                    }
                }
            }
        }

        //Merchant to Merchant Transfer
        if (BaseActivity.loginResponseMessage.getData().canDoMerchantTransfer()) {
            addToProductList("Merchant To Merchant Transfer", "MerchantTransfer", "");
        }


        GridLayoutManager grid;

        if (getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM) {
            grid = new GridLayoutManager(getActivity(), 3);
        } else {
            grid = new GridLayoutManager(getActivity(), 2);
        }

        RecyclerView.LayoutManager manager = grid;

        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getActivity(), R.dimen.item_offset);
        recycler.addItemDecoration(itemDecoration);

        recycler.setLayoutManager(manager);

        Log.v("BaseActivity", "Final List: " + list.size());

        adapter = new BluRecyclerAdapter(getBaseActivity(), list);

        recycler.setAdapter(adapter);
    }

    private void addToProductList(String product, String provider, String logoId) {
        int resId;

//        if (logoId != null && !logoId.isEmpty()){
//            Log.v("cigicell", "product:" + product + " provider:" + provider + " logoId:" + logoId);
//        }

        if (logoId != null && logoId.equals("30")) {
            resId = R.drawable.billpayment_easypay;
        } else if (logoId != null && logoId.equals("31")) {
            resId = R.drawable.billpayment_unipay;
        } else if (product.toLowerCase().contains("telkom")) {
            resId = getBaseActivity().getDrawableResource("telkomdark");
        } else {
            String shortname = getBaseActivity().getShortName(product);
            resId = getBaseActivity().getDrawableResource(shortname);
        }
        if (resId == 0) {
            resId = getBaseActivity().getDrawableResource("default_transact");
        }
        list.add(new CardViewBillPayment(getBaseActivity(), product, "", resId, "", "bill_payment", "Bill", "Bill Payment", provider));
    }

    @Override
    public boolean onBackPressed() {
        getBaseActivity().gotoMainScreen();
        return true;
    }


}
