package jkiosk3.sales.rmcs;

import aeonmoneytransfer.MoneyTransferDepositReq;
import aeonmoneytransfer.MoneyTransferResponse;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;

/**
 *
 *
 */
public class RmcsCashDepositSummary extends Region {

    public RmcsCashDepositSummary() {
        getChildren().add(getDepositSuccess());
    }

    private GridPane getDepositSuccess() {
        double sp = JKLayout.sp;

        MoneyTransferDepositReq depReq = RmcsDeposit.getInstance().getDepositReq();
        MoneyTransferResponse depResp = RmcsDeposit.getInstance().getDepositResp();

        Label lblSuccess = JKText.getLblDk("Money Transfer Voucher has been successfully created", JKText.FONT_B_XSM);
        lblSuccess.setTranslateX(sp);

        Label lblVoucherNum = JKText.getLblDk("Voucher Number", JKText.FONT_B_XSM);
        lblVoucherNum.setTranslateX(2 * sp);
        Label lblVoucherValue = JKText.getLblDk("Voucher Value", JKText.FONT_B_XSM);
        lblVoucherValue.setTranslateX(2 * sp);
        Label lblRecipient = JKText.getLblDk("Recipient", JKText.FONT_B_XSM);
        lblRecipient.setTranslateX(2 * sp);

        Text txtVoucherNum = JKText.getTxtDk(RmcsUtil.getVoucherDisplayFormat(depResp.getVoucherNum()), JKText.FONT_B_XSM);
        Text txtVoucherValue = JKText.getTxtDk("R " + JKText.getDeciFormat(depReq.getAmount()), JKText.FONT_B_XSM);
        Text txtRecipient = JKText.getTxtDk(JKText.getCellNumFormatted(depReq.getRecipMSISDN()), JKText.FONT_B_XSM);

        GridPane grid = JKLayout.getSummaryGrid2Col(0.5, 0.5);
        grid.setTranslateX(-(2 * sp));

        grid.add(lblSuccess, 0, 0, 2, 1);
        grid.addRow(2, lblVoucherNum, txtVoucherNum);
        grid.addRow(3, lblVoucherValue, txtVoucherValue);
        grid.addRow(4, lblRecipient, txtRecipient);

        return grid;
    }
}
