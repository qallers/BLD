package jkiosk3;

import javafx.animation.FadeTransition;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKMedia;
import jkiosk3._common.JKText;

/**
 *
 * @author Val
 */
public class SceneSplash extends Region {

    public SceneSplash() {
        getChildren().add(getSplashStack());
    }

    private StackPane getSplashStack() {
        StackPane splash = JKLayout.getComponentStackPane();
        splash.getChildren().add(JKiosk3.getMsgBox());
        splash.getChildren().add(JKiosk3.getBusy());

        Label lblCredit = JKText.getLblDk("JKiosk3", JKText.FONT_B_XXLG);
        Label lblText = JKText.getLblDk("Loading...", JKText.FONT_B_SM);

        final VBox vb = JKLayout.getVBox(0, 50);
        vb.getChildren().addAll(lblCredit, lblText);

        FadeTransition ft = new FadeTransition(Duration.millis(2500), vb);
        ft.setFromValue(1.0);
        ft.setToValue(0.05);
        ft.setOnFinished(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.changeScene(new JKioskLogin());
            }
        });
        ft.play();

        splash.getChildren().add(vb);

        return splash;
    }
}
