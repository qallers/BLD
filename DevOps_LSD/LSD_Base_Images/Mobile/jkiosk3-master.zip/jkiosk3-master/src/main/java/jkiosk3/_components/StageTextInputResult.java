package jkiosk3._components;

public abstract class StageTextInputResult {

    public abstract void onDone(String value);
}
