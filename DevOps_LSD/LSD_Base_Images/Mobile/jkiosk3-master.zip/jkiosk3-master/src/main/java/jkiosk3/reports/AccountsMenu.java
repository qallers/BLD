package jkiosk3.reports;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.users.CurrentUser;

/**
 *
 * @author Val
 */
public class AccountsMenu extends Region {

    private final List<String> accountsMenusAllowed;

    public AccountsMenu() {
        accountsMenusAllowed = ReportUtilMenus.getUserAccountReportMenu(CurrentUser.getUser().getUserPin());
        getChildren().add(getMenuGroup());
    }

    private HBox getMenuGroup() {

        List<Button> btnList = new ArrayList<>();

        for (String s : accountsMenusAllowed) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 4, btnList);
        
        HBox hb = JKLayout.getHBoxContent(JKLayout.sp);
        hb.getChildren().add(tile);

        return hb;
    }

    private void getMenuAction(Button b) {
        int n = SceneReports.getVbReportContent().getChildren().size();
        if (n > 1) {
            SceneReports.getVbReportContent().getChildren().remove(1, n);
        }

        switch (b.getText()) {
            case ReportUtilMenus.REP_BTN_ACC_STAT:
                SceneReports.getVbReportContent().getChildren().add(1, new AccountStatus());
                break;
            case ReportUtilMenus.REP_BTN_ACC_PROF:
                SceneReports.getVbReportContent().getChildren().add(1, new ProfitReport());
                break;
            case ReportUtilMenus.REP_BTN_ACC_STMNT:
                SceneReports.getVbReportContent().getChildren().add(1, new Statement());
                break;
            case ReportUtilMenus.REP_BTN_ACC_INV:
                SceneReports.getVbReportContent().getChildren().add(1, new Invoices());
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Account Reports", "No Report Selected", null);
        }
    }
}
