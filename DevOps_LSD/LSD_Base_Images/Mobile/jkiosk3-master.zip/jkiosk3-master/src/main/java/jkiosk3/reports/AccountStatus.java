package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.Account;
import aeonreports.AccountInfo;
import java.util.ArrayList;
import java.util.List;
import javafx.geometry.HPos;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.printing.PrintHandler;
import jkiosk3.reports.ReportUtil.AccountDetailResult;

/**
 *
 * @author Val
 */
public class AccountStatus extends Region {

    private AccountInfo accountInfo;
    private final static double sp = JKLayout.sp;
    private final static double w = JKLayout.contentW;
    private VBox vbDetail;

    public AccountStatus() {
        getAccountsToDisplay();
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().add(getStatusGroup());
        vb.getChildren().add(getPrintControl());
        getChildren().add(vb);
    }

    private void getAccountsToDisplay() {
        ReportUtil.getAccountDetail(new AccountDetailResult() {
            @Override
            public void accountDetailResult(AccountInfo accInfo) {
                accountInfo = accInfo;
                vbDetail.getChildren().addAll(getAccountsGrid(accountInfo.getListAccount()));
            }
        });
    }

    private Group getStatusGroup() {

        VBox vb = JKLayout.getVBox(sp, sp);

        VBox vbHead = JKNode.getReportHeadVB("Account Status");

        vbDetail = JKLayout.getVBox(sp, JKLayout.spNum);

        ScrollPane scroll = new ScrollPane();
        scroll.setMaxSize(w - (2 * sp), (480 - (JKLayout.btnSmH + (2 * sp))));
        scroll.setMinSize(w - (2 * sp), (480 - (JKLayout.btnSmH + (2 * sp))));
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.getStyleClass().add("scrollWhite");
        scroll.setContent(vbDetail);

        vb.getChildren().addAll(vbHead, scroll);

        Group grp = JKNode.getContentGroup(vb);

        return grp;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                AeonPrintJob apj = accountInfo.getPrintLines();
                PrintHandler.handlePrintRequestReport("Account Status", apj);
            }
        };
    }

    private List<GridPane> getAccountsGrid(List<Account> detailList) {
        final List<GridPane> gridList = new ArrayList<>();

        for (Account a : detailList) {

            GridPane grid = new GridPane();
            double wGrid = w - (6 * sp);
            grid.getStyleClass().clear();
            grid.getStyleClass().add("gridDetail");
            ColumnConstraints col0 = new ColumnConstraints();
            col0.setMaxWidth((wGrid * 0.45) - sp);
            col0.setMinWidth((wGrid * 0.45) - sp);
            col0.setHalignment(HPos.LEFT);
            ColumnConstraints col1 = new ColumnConstraints();
            col1.setMaxWidth((wGrid * 0.1) - sp);
            col1.setMinWidth((wGrid * 0.1) - sp);
            col1.setHalignment(HPos.CENTER);
            ColumnConstraints col2 = new ColumnConstraints();
            col2.setMaxWidth(wGrid * 0.45);
            col2.setMinWidth(wGrid * 0.45);
            col2.setHalignment(HPos.RIGHT);
            grid.getColumnConstraints().addAll(col0, col1, col2);

            Label lblAccNo = JKText.getLblDk("Account No.", JKText.FONT_B_XXSM);
            Label lblTotalBal = JKText.getLblDk("Total Balance", JKText.FONT_B_XXSM);
            Label lblOdLimit = JKText.getLblDk("Overdraft Limit", JKText.FONT_B_XXSM);
            Label lblSecDep = JKText.getLblDk("Security Deposit", JKText.FONT_B_XXSM);
            Label lblReserveAmt = JKText.getLblDk("Reserved Amount", JKText.FONT_B_XXSM);
            Label lblAvailBal = JKText.getLblDk("Available Balance", JKText.FONT_B_XXSM);

            Text txtAccNo = JKText.getTxtDk(a.getAccountNo(), JKText.FONT_B_SM);
            Text txtTotalBal = JKText.getTxtDk("R " + JKText.getDeciFormat(a.getTotalBalance()), JKText.FONT_B_XSM);
            Text txtOdLimit = JKText.getTxtDk("R " + JKText.getDeciFormat(a.getOverdraftLimit()), JKText.FONT_B_XSM);
            Text txtSecDep = JKText.getTxtDk("R " + JKText.getDeciFormat(a.getSecurityDeposit()), JKText.FONT_B_XSM);
            Text txtReserveAmt = JKText.getTxtDk("R " + JKText.getDeciFormat(a.getReservedAmount()), JKText.FONT_B_XSM);
            Text txtAvailBal = JKText.getTxtDk("R " + JKText.getDeciFormat(a.getAvailableBalance()), JKText.FONT_B_XSM);

            grid.addRow(0, lblAccNo, getColon(), txtAccNo);
            grid.addRow(1, lblTotalBal, getColon(), txtTotalBal);
            grid.addRow(2, lblOdLimit, getColon(), txtOdLimit);
            grid.addRow(3, lblSecDep, getColon(), txtSecDep);
            grid.addRow(4, lblReserveAmt, getColon(), txtReserveAmt);
            grid.addRow(5, lblAvailBal, getColon(), txtAvailBal);

            grid.add(JKNode.createGridSpanSep(3), 0, 6);

            gridList.add(grid);
        }

        return gridList;
    }

    private Label getColon() {
        Label lbl = JKText.getLblDk(":", JKText.FONT_B_XXSM);
        return lbl;
    }
}
