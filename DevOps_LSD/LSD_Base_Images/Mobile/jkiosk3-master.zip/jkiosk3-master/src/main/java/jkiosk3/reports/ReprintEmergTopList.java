package jkiosk3.reports;

import aeonemergencytopup.EmergTopHistoryItem;
import aeonemergencytopup.EmergTopHistoryReq;
import aeonemergencytopup.EmergTopHistoryResp;
import aeonemergencytopup.EmergTopReprintReq;
import aeonemergencytopup.LoanConfirmResp;
import aeonprinting.AeonPrintJob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Pagination;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.accounts.emerg_topup.EmergencyTopupUtil;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.print_layouts.PrintEmergTop;

/**
 *
 * @author Valerie
 */
public class ReprintEmergTopList extends Region {

    private final EmergTopHistoryReq request;
    private StackPane stack;
    private List<EmergTopHistoryItem> listHistoryItems;
    private List<Node> listReprintItems;
    private final static int pageSize = 10;
    private EmergTopHistoryItem selectedItem;

    public ReprintEmergTopList(EmergTopHistoryReq req) {
        this.request = req;

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getReprintListView());
        vb.getChildren().add(getPrintControl());

        getChildren().addAll(vb);
    }

    private Group getReprintListView() {

        VBox vbHead = JKNode.getReportHeadVB("Emergency Topup - " + request.getAccount().getAccountNumber());

        stack = new StackPane();
        stack.setMaxHeight(505);
        stack.setMinHeight(505);

        getReprints();

        VBox vb = JKLayout.getVBox(JKLayout.sp, JKLayout.spNum);
        vb.setMaxWidth(JKLayout.contentW);

        vb.getChildren().addAll(vbHead, stack);

        Group grp = JKNode.getContentGroup(vb);

        return grp;
    }

    private void getReprints() {
        EmergencyTopupUtil.getEmergTopupHistory(request, new EmergencyTopupUtil.LoanHistoryResult() {

            @Override
            public void loanHistoryResult(EmergTopHistoryResp loanHistory) {
                if (loanHistory.isSuccess()) {
                    listHistoryItems = loanHistory.getListItems();
                    listReprintItems = getReprintRadios();
                    createPagedReprints();
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Emergency Topup", "No Emergency Topup History Found\n\n"
                            + loanHistory.getErrorCode() + " - " + loanHistory.getErrorText(), null, MessageBox.CONTROLS_SHOW,
                            MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    SceneReports.clearAndChangeContent(new ReprintEmergTopSelect());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private List<Node> getReprintRadios() {
        List<Node> listRadios = new ArrayList<>();

        ToggleGroup tgReprint = new ToggleGroup();

        for (final EmergTopHistoryItem item : listHistoryItems) {
            final RadioButton btnReprint = new RadioButton();
            String date = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(item.getItemDate());
            String amtReq = JKText.getDeciFormat(item.getAmountRequested());
            btnReprint.setText(" " + date + "  -  R " + amtReq);
            btnReprint.setToggleGroup(tgReprint);
            btnReprint.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    if (btnReprint.isSelected()) {
                        selectedItem = item;
                    }
                }
            });
            listRadios.add(btnReprint);
        }

        return listRadios;
    }

    private void createPagedReprints() {
        int numPgs = 0;
        if (listReprintItems.isEmpty()) {
            numPgs = 1;
        } else if ((listReprintItems.size() % pageSize) == 0) {
            numPgs = listReprintItems.size() / pageSize;
        } else {
            numPgs = (listReprintItems.size() / pageSize) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedVBox(pg, listReprintItems, pageSize);
            }
        });
        stack.getChildren().add(pages);
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                showReprintReport();
            }
        };
    }

    private void showReprintReport() {
        EmergTopReprintReq req = new EmergTopReprintReq();
        req.setReference(request.getReference());
        if (selectedItem != null) {
            req.setTransRef(selectedItem.getTransRef());
        } else {
            req.setTransRef(listHistoryItems.get(0).getTransRef());
        }

        EmergencyTopupUtil.getEmergTopupReprint(req, new EmergencyTopupUtil.LoanConfirmationResult() {

            @Override
            public void loanConfirmationResult(LoanConfirmResp loanConfirmation) {
                if (loanConfirmation.isSuccess()) {
                    AeonPrintJob apj = PrintEmergTop.getEmergencyTopupConfirmationReceipt(
                            request.getAccount().getAccountNumber(), loanConfirmation, true);
//                    AeonPrintJob apj = loanConfirmation.getAeonPrintJob();
                    PrintHandler.handlePrintRequestReport("Emergency Topup Reprint", apj);
                    SceneReports.getVbReportContent().getChildren().clear();
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Emergency Topup Reprint", "Error retrieving Reprint", null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    SceneReports.getVbReportContent().getChildren().clear();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }

                            });
                }
            }
        });
    }
}
