package jkiosk3.store;

import aeonusers.User;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import jkiosk3.users.UserUtil;

/**
 *
 * @author Val
 */
public class JKUsers {
//    
//    private static List<User> users;
//
//    private static void loadUsers() {
//        if ((users == null) || (users.isEmpty())) {
//            users = (ArrayList<User>) (Store.loadObject(JKUsers.class.getSimpleName()));
//        }
//        if (users == null) {
//            users = new ArrayList();
//        }
//    }
//
//    public static boolean hasUsers() {
//        loadUsers();
//        return users.size() > 0;
//    }
//
//    public static User getUser(String pin) {
//        User user = null;
//        loadUsers();
//        for (User u : users) {
//            if (u.getUserPin().equals(pin)) {
//                user = u;
//                break;
//            }
//        }
//        return user;
//    }
//
//    public static List<User> getUsersList(String pin) {
//        users = null;
//        loadUsers();
//        if (!(JKUsers.hasUsers())) {
//            users = getOnlineUsers(pin);
//        }
//        Collections.sort(users, new Comparator<User>() {
//            @Override
//            public int compare(User u1, User u2) {
//                return Integer.valueOf(u1.getUserName().compareTo(u2.getUserName()));
//            }
//        });
//        return users;
//    }
//
//    private static List<User> getOnlineUsers(String pin) {
//        List<User> userList = new ArrayList();
//
//        try {
//            userList = UserUtil.getOnlineUsersList(pin);
//            for (User u : userList) {
//                JKUsers.saveUser(u);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return userList;
//    }
//
//    public static void saveUser(User u) {
//        loadUsers();
//        if (getUser(u.getUserPin()) == null) {
//            users.add(u);
//            Store.saveObject(JKUsers.class.getSimpleName(), users);
//        }
//    }
//
//    public static User removeUser(int id) {
//        User user = null;
//        loadUsers();
//        for (User u : users) {
//            if (u.getUserId() == id) {
//                user = u;
//                break;
//            }
//        }
//        users.remove(user);
//        Store.saveObject(JKUsers.class.getSimpleName(), users);
//        return user;
//    }
//
//    public static void clearUsers() {
//        if (users != null) {
//            users.clear();
//        }
//        Store.deleteObject(JKUsers.class.getSimpleName());
//    }
}
