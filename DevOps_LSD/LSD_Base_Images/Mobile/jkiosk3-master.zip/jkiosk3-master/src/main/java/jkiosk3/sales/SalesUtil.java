package jkiosk3.sales;

import aeonairtime.AirtimeVoucher;
import aeonairtime.RechargePlusTransaction;
import aeonelectricity.ElectricityVoucher;
import aeonithuba.IthubaLottoRes;
import aeonprinting.AeonPrintJob;
import aeontender.TenderType;
import aeontopup.TopupBundleResp;
import aeontopup.TopupVoucher;
import aeontopup.TopupWalletResp;
import aeonusers.User;
import aeonvarivouchers.VDVoucherResp;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3.SceneMenu;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.*;
import jkiosk3.printing.*;
import jkiosk3.printing.print_layouts.PrintAssorted;
import jkiosk3.reports.ShiftEnd;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.SummaryTableView;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.sales._favourites.nfc.NFCSubscriberFavourites;
import jkiosk3.sales._favourites.nfc.NFCUtil;
import jkiosk3.sales._tender.PaymentTenderResult;
import jkiosk3.sales._tender.TenderAmounts;
import jkiosk3.sales._tender.TenderUtil;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.chat4change.Chat4ChangeSale;
import jkiosk3.sales.coaches.CoachMenu;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.sales.topups.TopupSale;
import jkiosk3.sales.vouchers.VoucherSale;
import jkiosk3.store.*;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.UserUtil;
import jkiosk3.utilities.ResubmitUtil;

import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SalesUtil {

    private final static Logger logger = Logger.getLogger (SalesUtil.class.getName ());

    public final static int SRC_BTN_AMT_DUE = 0;
    public final static int SRC_BTN_CANCEL = 1;
    //
    private static final PrintClient printClient = new PrintClient();

    /**
     * Private Constructor to hide implicit public one.
     */
    private SalesUtil() {
    }

    public static void processSoldVouchers(VoucherSale saleMulti) {
        PrintHandler.handlePrintRequestSaleMultiVoucher(saleMulti);
        for (AirtimeVoucher v : saleMulti.getResponse().getListVouchers()) {
            processSoldItem(v.getTransRef(), saleMulti.getSaleType().getDisplay(), v.getProductName(), v.getPrintLines(), v.getAmount(),
                    saleMulti.isCanCancel(), "online", "", v.getDate(), v.getSerial(), null);
        }
        if (saleMulti.getResponse().getListRechargePlus() != null || !saleMulti.getResponse().getListRechargePlus().isEmpty()) {
            for (RechargePlusTransaction a : saleMulti.getResponse().getListRechargePlus()) {
                processSoldItem(a.getTransRef(), saleMulti.getSaleType().getDisplay(), a.getVoucherDescription(), null,
                        (double) a.getValue() / 100, saleMulti.isCanCancel(), "online", "",
                        new Date(a.getCreationDate()), a.getSerialNumber(), null);
            }
        }
    }

    public static void processTopupAirtime(TopupVoucher voucher) {
        processSoldItem(voucher.getTransRef(), TopupSale.getInstance().getSaleType().getDisplay(),
                TopupSale.getInstance().getProvider().getDisplayName() + " " + TopupSale.getInstance().getCellNum(),
                voucher.getPrintLines(), voucher.getMerchantPrintLines(),
                voucher.getAmount(), false, "online", null);
        // RechargePlus process...
        if (voucher.getListRechargePlus() != null || !voucher.getListRechargePlus().isEmpty()) {
            for (RechargePlusTransaction a : voucher.getListRechargePlus()) {
                processSoldItem(a.getTransRef(), TopupSale.getInstance().getSaleType().getDisplay(),
                        a.getVoucherDescription(), null, null,
                        (double) a.getValue() / 100, false, "online", a.getSerialNumber());
            }
        }
    }

    public static void processTopupData(TopupBundleResp topupBundleResponse) {
        String prodDescript = TopupSale.getInstance().getProvider().getDisplayName() + " "
                + TopupSale.getInstance().getProduct().getDescription() + " - " + TopupSale.getInstance().getCellNum();

        processSoldItem(topupBundleResponse.getTransRef(), TopupSale.getInstance().getSaleType().getDisplay(),
                prodDescript, topupBundleResponse.getPrintLines(), topupBundleResponse.getMerchantPrintLines(),
                topupBundleResponse.getAmount(), false, "online", null);

        // RechargePlus process...
        if (topupBundleResponse.getListRechargePlus() != null || !topupBundleResponse.getListRechargePlus().isEmpty()) {
            for (RechargePlusTransaction a : topupBundleResponse.getListRechargePlus()) {
                processSoldItem(a.getTransRef(), TopupSale.getInstance().getSaleType().getDisplay(),
                        a.getVoucherDescription(), null, null,
                        (double) a.getValue() / 100, false, "online", a.getSerialNumber());
            }
        }
    }

    public static void processTopupWallet(TopupWalletResp topupWalletResp) {
        String prodDescript = TopupSale.getInstance().getProvider().getDisplayName() + " "
                + " - " + TopupSale.getInstance().getCellNum();

        processSoldItem(topupWalletResp.getTransRef(), TopupSale.getInstance().getSaleType().getDisplay(),
                prodDescript, topupWalletResp.getPrintLines(), topupWalletResp.getMerchantPrintLines(),
                topupWalletResp.getAmount(), false, "online", null);

//        // RechargePlus process...
//        if (topupBundleResponse.getListRechargePlus() != null || !topupBundleResponse.getListRechargePlus().isEmpty()) {
//            for (RechargePlusTransaction a : topupBundleResponse.getListRechargePlus()) {
//                processSoldItem(a.getTransRef(), TopupSale.getInstance().getSaleType().getDisplay(),
//                        a.getVoucherDescription(), null, null,
//                        (double) a.getValue() / 100, false, "online", a.getSerialNumber());
//            }
//        }
    }

    // 2017-04-04
    public static void processBillPayment(final String billPayType, final String transRef, final String descript,
                                          final double amtTotal, final String tendered, String merchantMsg, final AeonPrintJob apj, final AeonPrintJob apjM) {

        JKiosk3.getMsgBox().showMsgBox(billPayType, merchantMsg, null,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                    @Override
                    public void onOk() {
                        if (apj != null) {
                            PrintHandler.handlePrintRequestSale(billPayType, apj, transRef);
                        }
                        if (apjM != null) {
                            PrintHandler.handleMerchantCopyPrint(apjM);
                        }
                        processSoldItem(transRef, billPayType, descript, apj, amtTotal,
                                false, "online", null, new Date(), null, tendered);

                        TenderAmounts.addTenderAmount(JKTenderToggles.getTxtForTender(tendered), amtTotal);
                    }

                    @Override
                    public void onCancel() {
                        //
                    }
                });
    }

    // 2017-11-09
    public static void processMerchantTransfer(final String billPayType, final String transRef, String descript,
                                               double amtTotal, String tendered, String merchantMsg, final AeonPrintJob apj, final AeonPrintJob apjM) {

        processSoldItem(transRef, billPayType, descript, apj, amtTotal,
                false, "online", null, new Date(), null, tendered);
        TenderAmounts.addTenderAmount(JKTenderToggles.getTxtForTender(tendered), amtTotal);

        JKiosk3.getMsgBox().showMsgBox(BillPayUtilMisc.TYPE_M2M_TRANSFER, merchantMsg, null,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                    @Override
                    public void onOk() {
                        PrintHandler.handlePrintRequestSale(BillPayUtilMisc.TYPE_M2M_TRANSFER, apj, transRef);
                        PrintHandler.handleMerchantCopyPrint(apjM);
                    }

                    @Override
                    public void onCancel() {
                        //
                    }
                });
    }

    public static void processChat4Change(VDVoucherResp c4cVoucher) {
        String descript = "C4C " + Chat4ChangeSale.getInstance().getSupplier().getName() + " R"
                + JKText.getDeciFormat(Chat4ChangeSale.getInstance().getAmount());

        processSoldItem(c4cVoucher.getTransRef(), SaleType.CHAT4CHANGE.getDisplay(), descript,
                c4cVoucher.getPrintLines(), c4cVoucher.getMerchantPrintLines(),
                c4cVoucher.getAmount(), false, "online", c4cVoucher.getSerial());

        VDVoucherResp c4cReprint = new VDVoucherResp();
        c4cReprint.setPin(c4cVoucher.getPin());
        c4cReprint.setPrintLines(new AeonPrintJob(c4cVoucher.getPrintLines()));
    }

    public static void processIthuba(IthubaLottoRes ithubaLottoRes, String gameType) {
        double amt = (((double) ithubaLottoRes.getAmt()) / 100);

        // Lotto is ALWAYS a CASH-ONLY transaction!
        TenderAmounts.addTenderAmount (TenderAmounts.TENDER_CASH, amt);
        processSoldItem (ithubaLottoRes.getTrxId (), SaleType.LOTTO.getDisplay (), gameType, ithubaLottoRes.getPrintLines (),
                ithubaLottoRes.getMerchantPrintLines (), amt, false, "online", "");
    }

    public static void processElectricity(String electricityType, ElectricityVoucher voucher, double amount) {
        String desc = electricityType + " " + voucher.getMeter().getMeterNum();

        processSoldItem(voucher.getTransRef(), SaleType.ELECTRICITY.getDisplay(), desc,
                voucher.getPrintLines(), voucher.getMerchantPrintLines(), amount, false, "online", voucher.getReference());

        switch (electricityType) {

            case ElectricityUtil.ELEC_ENG_KEY_CHANGE:
            case ElectricityUtil.ELEC_FBE:
            case ElectricityUtil.ELEC_TOKEN:
            case ElectricityUtil.ELEC_UPDATE_M_KEY:

                printElectricity(electricityType, voucher);
                break;

            case ElectricityUtil.ELEC_PAY_ACCOUNT:

                PrintHandler.handlePrintRequestSale(SaleType.ELECTRICITY.getDisplay(), voucher.getPrintLines(), voucher.getTransRef());
                break;

            default:
                logger.info(("Unable to process Electricity Voucher : ").concat(voucher.getMeter().getMeterNum()));
                break;
        }
    }

    private static void printElectricity(final String type, final ElectricityVoucher voucher) {
        // 2019-11-07  -  PRODDEFECT-868
        // Print immediately or later is now handled in PrintHandler
//        if (JKPrintOptions.getPrintOptions().isPrintImmediately()) {
        if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
            JKiosk3.getPrintPreview().showPrintPreview(type, voucher.getPrintLines(), voucher.getTransRef(),
                    PrintPreview.PRN_OK, new PrintPreviewResult() {
                        @Override
                        public void onOk() {
                            writeElectricityMagCards(type, voucher);
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        } else {
//                PrintUtil.sendToPrinter(voucher.getPrintLines(), voucher.getTransRef());
            PrintHandler.handlePrintRequestSale(type, voucher.getPrintLines(), voucher.getTransRef());
            writeElectricityMagCards(type, voucher);
        }
//        } else {
//            PrintQueue.addItem(voucher.getTransRef(), voucher.getPrintLines());
//            writeElectricityMagCards(type, voucher);
//        }
    }

    private static void writeElectricityMagCards(String type, ElectricityVoucher voucher) {
        System.out.println("value of JKCardReader.getCardReaderConfig().isMagCardWrite() : "
                + JKCardReader.getCardReaderConfig().isMagCardWrite());
        if (JKCardReader.getCardReaderConfig().isMagCardWrite()) {
            System.out.println("value of voucher.isPrintMagCard() : " + voucher.isPrintMagCard());
            if (voucher.isPrintMagCard()) {
                List<MagCardData> magListTokens = ElectricityUtil.getMagCardTokens(voucher);
                System.out.println("value of voucher.getMeter().getMeterTt() : " + voucher.getMeter().getMeterTt());
                if (voucher.getMeter().getMeterTt().equals("01")) {
                    // 2019-11-07  -  PRODDEFECT-868
                    // Print immediately or later is now handled in PrintHandler
//                    if (JKPrintOptions.getPrintOptions().isPrintImmediately()) {
                    PrintUtil.writeMagCardTokens(magListTokens, null);
//                    } else {
//                        PrintQueue.addMagCards(magListTokens);
//                    }
                }
            }
            if (type.equalsIgnoreCase(ElectricityUtil.ELEC_UPDATE_M_KEY)
                    || type.equalsIgnoreCase(ElectricityUtil.ELEC_ENG_KEY_CHANGE)) {
                List<MagCardData> magListUpdate = ElectricityUtil.getMagCardTokens(voucher);
                List<MagCardData> cardUpdateList = ElectricityUtil.getMagCardUpdateByVoucher(voucher);
                PrintUtil.writeMagCardUpdate(cardUpdateList, magListUpdate, true);
            }
        }
    }

    // 2017-04-03
    private static void processSoldItem(String transRef, String saleType, String description, AeonPrintJob printjob, AeonPrintJob printjobMerchant,
                                        double amount, boolean canCancel, String onlineOffline, String serial) {
        if (printjob != null) {
            // Electricity is handled differently, because of Mag Card writing
            if (!saleType.equalsIgnoreCase(SaleType.ELECTRICITY.getDisplay())) {
                PrintHandler.handlePrintRequestSale(saleType, printjob, transRef);
            }
        }
        if (printjobMerchant != null) {
            PrintHandler.handleMerchantCopyPrint(printjobMerchant);
        }
        processSoldItem(transRef, saleType, description, printjob, amount, canCancel, onlineOffline, "", new Date(), serial, null);
    }

    // Try to clean up and consolidate all these to have less overloaded methods doing the same thing.
    // Can't do it without visibility, will need to be tested, so has to wait for a JIRA task to be created.
    // 2016-10-13  -  All Bill Payments now use this method, as part of the double-capture CR
    public static void processSoldItem(String transRef, String saleType, String description, AeonPrintJob printjob,
                                       double amount, boolean canCancel, String onlineOffline, String addRef, Date dateTime, String serial, String tenderType) {

        // Should we do this FIRST, so that it goes into the basket for payment before any other action?
        String descript = description.replaceAll("\n", " ");
        SummaryTableView.addSalesItem(descript, amount, transRef, canCancel, onlineOffline, addRef, dateTime, serial, saleType);

        // The 'processReprint()' method checks for SaleType, no need to check here.
//        if (!saleType.equals(SaleType.VOUCHERS.getDisplay()) && !saleType.equals(SaleType.CHAT4CHANGE.getDisplay())) {
        processReprint(transRef, saleType, description, printjob, dateTime);
//        }

        StoreJKPending storeItem = new StoreJKPending(description, amount, transRef, canCancel, onlineOffline, printjob,
                CurrentUser.getSalesUser(), serial, saleType);
        storeItem.setDateTime(dateTime.getTime());
        if (tenderType != null) {
            storeItem.setTenderType(tenderType);
        }
        JKPending.savePendingItem(storeItem);
        if (JKPending.hasPendingItems()) {
            logger.info(("\t\t\t").concat("JKPending item count : ").concat(Integer.toString(JKPending.getPendingList().size())));
        }

        // Still testing, not in use yet.
        // - - - ObservableList not serializable
        // - - - SimpleStringProperty not serializable
//        ObservableList<SaleSummary> pendingSale = SummaryTableView.getSummaryRows();
//        JKPendingSale.savePendingSale(pendingSale);
//
//        for (SaleSummary ss : JKPendingSale.getPendingSaleItemsList()) {
//            System.out.println("item description : " + ss.getItemName() + " ::: item amount : " + ss.getAmount());
//        }

        checkAndResetActiveNFCSubscriber();

        // Set transRef for Promo entry, add to list of entries
//        if (PromoSubmit.getInstance().isSubmit()) {
//            PromoSubmit.getInstance().setTransRef(transRef);
//            PromoSubmit.getInstance().setSalesUser(CurrentUser.getSalesUser());
//            PromoSubmitList.getInstance().getListSubmit().add(PromoSubmit.getInstance());
//            PromoSubmit.resetPromoSubmit();
//            for (PromoSubmit p : PromoSubmitList.getInstance().getListSubmit()) {
//                System.out.println("adding to list... promo name = " + p.getName() + " : promo mobile num = " + p.getMobileNumber());
//            }
//        }
    }

    private static void checkAndResetActiveNFCSubscriber() {
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            String cardnum = "Sale allocated to Card Number : " + ActiveNFCSubscriber.getInstance().getConsumerProfile().getLoyaltyCard();
            String msg = "\nDoes this Subscriber wish to purchase another product?\n";
            Label lblCardnum = JKText.getLblDk(cardnum, JKText.FONT_B_22);
            Label lblMsg = JKText.getLblDk(msg, JKText.FONT_B_18);
            VBox vBox = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
            vBox.setPrefWidth(MessageBox.getMsgWidth());
            vBox.getChildren().addAll(lblCardnum, lblMsg);
//            String msg = "Would You Like to Add Another Purchace to this account";
            JKiosk3.getMsgBox().showMsgBox("Active NFC Subscriber", "", vBox,
                    MessageBox.CONTROLS_SHOW, MessageBox.MSG_YES_NO, new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            SceneSales.clearAndChangeContent(new NFCSubscriberFavourites(ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile()));
                        }

                        @Override
                        public void onCancel() {
                            NFCUtil.resetNFCActiveSubscriber();
                        }
                    });
        }
    }

    private static void processReprint(String transRef, String saleType, String description, AeonPrintJob printjob,
                                       Date dateTime) {
        if (saleType.equals(SaleType.BUSTICKETS.getDisplay()) || saleType.equals(SaleType.COACHTICKETS.getDisplay())) {
            if (printjob != null) {
                AeonPrintJob apj = PrintAssorted.getReprintLayout(printjob);
                JKReprint.saveReprint(transRef, dateTime, saleType, description, apj);
            }
        }
    }

    public static void onSelectAmountDue() {
        // 2019-11-07  -  PRODDEFECT-868
        // Complete change or order of operations.
        ResubmitUtil.resubmitUnprocessedItems(new ResultCallback() {
            @Override
            public void onResult(boolean result) {
                // PRINT ITEMS FIRST, ELSE THIS WILL FAIL
                printSale(new ResultCallback() {
                    @Override
                    public void onResult(boolean result) {
                        processTender();
                    }
                });
            }
        });
    }

    private static void processTender() {
        // 2019-11-06  -  Previous "onSelectAmountDue()" code. Try to get resubmits done before doing this...
        if (JKSalesOptions.getSalesOptions().isEnterTender()) {
            /* Show Tender entry view for Cashier to enter amount(s) paid by Customer.
             * Values ENTERED here are sent to server to be stored. */
            JKiosk3.getPayTender().showPaymentTender(SummaryTableView.getTotalAmt(), new PaymentTenderResult() {
                @Override
                public void onOk() {
                    finaliseSale();
                    NFCUtil.resetNFCActiveSubscriber();
                }

                @Override
                public void onCancel() {
                    //
                }
            });
        } else {
            /* Tender entry view is NOT shown - if items have specific tender types already allocated, balance
             * is calculated as "Cash".  Values CALCULATED are sent to server to be stored. */
            JKiosk3.getPayTender().calculatePaymentTender(SummaryTableView.getTotalAmt(), new PaymentTenderResult() {
                @Override
                public void onOk() {
                    finaliseSale();
                    NFCUtil.resetNFCActiveSubscriber();
                }

                @Override
                public void onCancel() {
                    //
                }
            });
        }
    }

    public static void onSelectMainMenu(final String userPin) {
        UserUtil.getLoggedInUser(userPin, new UserUtil.LoggedInUserResult() {

            @Override
            public void loggedInUserResult(User loggedInUser) {
                if (loggedInUser.isSuccess()) {
                    int userLevel = loggedInUser.getUserLevel();
                    if (userLevel == 0) {
                        JKiosk3.getMsgBox().showMsgBox("Access Denied",
                                "Main Menu not available for this Access Level", null);
                    } else if (userLevel == 1 || userLevel == 2) {
                        JKiosk3.changeScene(new SceneMenu());
                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Login Failed",!loggedInUser.getAeonErrorText ().isEmpty () ?
                            loggedInUser.getAeonErrorCode () + " - " + loggedInUser.getAeonErrorText () :
                            loggedInUser.getErrorCode () +" - "+ loggedInUser.getErrorText (), null);
                }
            }
        });
    }

    public static void onSelectCoachMenu(final String userPin, final String buttonName, final Region theRegion) {
        UserUtil.getLoggedInUser(userPin, new UserUtil.LoggedInUserResult() {

            @Override
            public void loggedInUserResult(User loggedInUser) {
                if (loggedInUser.isSuccess()) {
                    int userLevel = loggedInUser.getUserLevel();
                    if (userLevel == 1) {
                        // JKiosk3.changeScene (theRegion);
                        SceneSales.clearAndChangeContent(theRegion);
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Access Denied",
                                "Coach " + buttonName + " not available for this Access Level", null);
                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Login Failed",
                            loggedInUser.getErrorCode() + " - " + loggedInUser.getErrorText(), null);

                    SceneSales.clearAndChangeContent(new CoachMenu());
                }
            }
        });
    }

    public static void onSelectCashDrawer(final String userPin) {
        UserUtil.getLoggedInUser(userPin, new UserUtil.LoggedInUserResult() {

            @Override
            public void loggedInUserResult(User loggedInUser) {
                if (loggedInUser.isSuccess()) {
                    int userLevel = loggedInUser.getUserLevel();
                    if (userLevel == 0) {
                        /* Cashier */

                        JKiosk3.getMsgBox().showMsgBox("Access Denied",
                                "This function is not available for this Access Level", null);
                    } else if (userLevel == 1) {
                        /* Supervisor */

                        printClient.cashDraw();
                        System.out.println("Cash Drawer for Supervisor now open");
                    } else if (userLevel == 2) {
                        /* Cashier Plus */

                        List<String> perm = UserUtil.getUserPermissionsAsList(userPin);
                        if (!perm.isEmpty()) {
                            if (perm.contains("11")) {
                                printClient.cashDraw();
                                System.out.println("Cash Drawer for Casher Plus User now open");
                            } else {
                                JKiosk3.getMsgBox().showMsgBox("Access Denied",
                                        "This Function is not available for with current permissions", null);
                            }
                        } else {
                            System.out.println("User permission string is null");
                            JKiosk3.getMsgBox().showMsgBox("Cashier Plus Permissions", "No Permissions found for this Cashier Plus", null);
                        }
                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Login Failed",!loggedInUser.getAeonErrorText ().isEmpty () ?
                            loggedInUser.getAeonErrorCode () + " - " + loggedInUser.getAeonErrorText () :
                            loggedInUser.getErrorCode () +" - "+ loggedInUser.getErrorText (), null);
                }
            }
        });
    }

    public static void onSelectShiftEnd(final String userPin) {
        UserUtil.getLoggedInUser(userPin, new UserUtil.LoggedInUserResult() {

            @Override
            public void loggedInUserResult(User loggedInUser) {
                if (loggedInUser.isSuccess()) {
                    ShiftEnd.doEndShift();
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Login Failed",!loggedInUser.getAeonErrorText ().isEmpty () ?
                            loggedInUser.getAeonErrorCode () + " - " + loggedInUser.getAeonErrorText () :
                            loggedInUser.getErrorCode () +" - "+ loggedInUser.getErrorText (), null);
                }
            }
        });
    }

    public static void showChange(double change) {
        if (JKSalesOptions.getSalesOptions().isUseCashDrawer()) {
            // pop cash drawer open...
            new PrintClient().cashDraw();
        }
        if (change > 0) {
            JKiosk3.getMsgBox().showMsgBox("Change Due", "R " + JKText.getDeciFormat(change), null, MessageBox.CONTROLS_SHOW,
                    MessageBox.MSG_OK, new MessageBoxResult() {
                        @Override
                        public void onOk() {
//                            printSale();
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        } else {
//            printSale();
        }
    }

    private static void printSale(final ResultCallback resultCallback) {
        if (PrintQueue.getPrintQueue().size() > 0) {
            PrintHandler.handlePrintRequestFromQueue(PrintQueue.getPrintQueue(), new PrintQueueResult() {
                @Override
                public void onDone(boolean printQueueComplete) {
                    PrintUtil.processSetPrintedItems();
                    PrintQueue.clearQueue();
                    resultCallback.onResult(true);
                }
            });
        } else {
            // If there is nothing in the PrintQueue, sales items have already been printed. Just continue...
            resultCallback.onResult(true);
        }
    }

    private static void finaliseSale() {
        if (PrintQueue.getMagCards().size() > 0) {
            PrintUtil.writeMagCardTokens(PrintQueue.getMagCards(), new MagCardPromptResult() {
                @Override
                public void onDone() {
                    JKiosk3.getMagCardPrompt().stopMagEncoder();
                    printReceipt();
                }
            });
        } else {
            printReceipt();
        }
    }

    private static void printReceipt() {
        if (JKPrintOptions.getPrintOptions().isPrintReceipts()) {
            TenderType tenderTypes = TenderUtil.getTenderTypes();
            logger.info("Print Receipts enabled - printing Sales Receipt");
            if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
                JKiosk3.getPrintPreview().showPrintPreview("Receipt", PrintAssorted.getSalesReceipt(tenderTypes), PrintPreview.PRN_OK,
                        new PrintPreviewResult() {
                            @Override
                            public void onOk() {
//                                submitPromoAndClose();
                                closeSale();
                            }

                            @Override
                            public void onCancel() {
                                //
                            }
                        });
            } else {
                PrintUtil.sendToPrinter(PrintAssorted.getSalesReceipt(tenderTypes));
//                submitPromoAndClose();
                closeSale();
            }
        } else {
            logger.info("Print Receipts disabled - will not print Sales Receipt");
//            submitPromoAndClose();
            closeSale();
        }
    }

//    private static void submitPromoAndClose() {
//
//        if (!PromoSubmitList.getInstance().getListSubmit().isEmpty()) {
//            for (PromoSubmit p : PromoSubmitList.getInstance().getListSubmit()) {
//                System.out.println("promo transRef = " + p.getTransRef() + " : promo id = " + p.getPromoId()
//                        + " : promo name = " + p.getName() + " : promo mobile num = " + p.getMobileNumber());
//            }
//            PromoUtil.setPromoSubmitCount(0);
//            PromoUtil.submitPromos();
//        }
//        closeSale();
//    }

    private static void closeSale() {
        if (JKOptions.getOptions ().isAutoLogout ()) {

            TenderAmounts.resetTenderAmounts ();
            PrintQueue.clearQueue ();
//            PrintQueue.clearMagCardQueue();

            if (JKPending.hasPendingItems ()) {
                JKPending.clearPending ();
            }
            UserUtil.resetSalesUser (SRC_BTN_AMT_DUE);
            JKiosk3.changeScene (new JKioskLogin ());
        }

        UserUtil.resetSalesUser(SRC_BTN_AMT_DUE);

        SceneSales.clearAndShowFavourites();
        SceneSales.getBtnAmtDue().setDisable(true);
        SceneSales.getBtnRemove().setDisable(true);
        SceneSales.refreshSalesTable();
        SummaryTableView.clearSummaryTable();

        TenderAmounts.resetTenderAmounts();

        PrintQueue.clearQueue();
        PrintQueue.clearMagCardQueue();

        if (JKPending.hasPendingItems()) {
            JKPending.clearPending();
        }

        /* Sale complete - check for unprinted items */
        if (JKSetPrintedQueue.hasItems()) {
            logger.info(("JKSetPrintedQueue still has items NOT SET PRINTED : ").concat(Integer.toString(JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs().size())));
            JKiosk3.getMsgBox().showMsgBox("Some Items Are Not Set As Printed", "You will be returned to the Login screen", null,
                    MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                        @Override
                        public void onOk() {
                            SceneSales.getBtnRemove().setDisable(true);
                            JKiosk3.changeScene(new JKioskLogin());
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        }
    }

    public static double getAmountAsDouble(String value, TextField txtfld) {
        System.out.println("value being matched : " + value);
        double amountPaid = 0;
        try {
            // ^(0|[1-9]\d*)+(?:\.\d{0,2})?$ - paste this into 
            // https://www.regexpal.com/
            // and enter required values.  Java adds additional 'escape' characters.
//            Pattern dec = Pattern.compile("^\\d+(?:.\\d{0,2})");
            Pattern dec = Pattern.compile("^(0|[1-9]\\d*)+(?:\\.\\d{0,2})?$");
            Matcher matchDec = dec.matcher(value);
            if (matchDec.matches()) {
                System.out.println("yes, number matches allowed decimal places");
                double amt = Double.parseDouble(value);
                if (amt <= 0) {
                    JKiosk3.getMsgBox().showMsgBox("Invalid Amount", "Amount must be greater than 0", null);
                    if (txtfld != null) {
                        txtfld.clear();
                    }
                } else {
                    amountPaid = amt;
                }
            } else {
                JKiosk3.getMsgBox().showMsgBox("Amount", "Amount must be numeric only,\n\nand not contain more than 2 decimal places", null);
                if (txtfld != null) {
                    txtfld.clear();
                }
            }
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Amount", "Amount must be a valid number", null);
            if (txtfld != null) {
                txtfld.clear();
            }
        }
        return amountPaid;
    }

    public static int getAmountAsInt(String value, TextField txtfld, int max) {
        int number = 0;
        try {
            number = Integer.parseInt(value);
            if (max != 0) {
                if (number <= 0 || number > max) {
                    JKiosk3.getMsgBox().showMsgBox("Invalid Number", "Please enter a number between\n\n" +
                            "1 and " + max, null);
                    if (txtfld != null) {
                        txtfld.clear();
                    }
                }
            }
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Number", "Please enter a valid number", null);
            if (txtfld != null) {
                txtfld.clear();
            }
        }

        return number;
    }

    public static String getUniqueRef() {
        return JKSystem.getSystemConfig().getDeviceId() + "_" + new Date().getTime();
    }

    /* 2018-08-22  -  Was previously moved to UserUtil.  This version is not used.  To be deleted once confirmed all okay.  */
    /* 2017-11-02 */
    /* NOTE : This method is duplicated in 'BillPayUtilMisc' where it was originally defined and needed. */
    /* Really should remove it from there, and use THIS one wherever needed. */
//    public static void getSupervisorOverride(double amount, double amtLimit, final UserUtil.SupervisorOverride supervisorOverride, final TextField... txt) {
//        JKiosk3.getMsgBox().showMsgBox("Amount Too High",
//                "\n\n"
//                        + "R " + JKText.getDeciFormat(amount) + "\n\n"
//                        + "The Amount entered exceeds the allowed limit of\n\n"
//                        + "R " + JKText.getDeciFormat(amtLimit) + "\n\n"
//                        + "Please call a Supervisor to authorise this Amount,\n\n"
//                        + "or press 'Cancel' to enter a new Amount",
//                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL,
//                new MessageBoxResult() {
//
//                    @Override
//                    public void onOk() {
//                        UserUtil.getSupervisorOverride(new UserUtil.SupervisorOverride() {
//
//                            @Override
//                            public void supervisorOverrideResult(Boolean isSupervisor) {
//                                if (isSupervisor) {
//                                    supervisorOverride.supervisorOverrideResult(Boolean.TRUE);
//                                } else {
//                                    supervisorOverride.supervisorOverrideResult(Boolean.FALSE);
//                                }
//                            }
//                        });
//                    }
//
//                    @Override
//                    public void onCancel() {
//                        // Clear TextField items, ready for re-entry
//                        for (TextField t : txt) {
//                            if (t != null) {
//                                t.clear();
//                            }
//                        }
//                    }
//                });
//    }
}
