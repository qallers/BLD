package jkiosk3.sales.ticketpro;

import aeonprinting.AeonPrintJob;
import aeonticketpros.TicketProAllowedProdListResp;
import aeonticketpros.TicketProAllowedProduct;
import aeonticketpros.TicketProsCart;
import aeonticketpros.TicketProsCartClearReq;
import aeonticketpros.TicketProsCartClearResp;
import aeonticketpros.TicketProsCategoryList;
import aeonticketpros.TicketProsCategory;
import aeonticketpros.TicketProsCheckoutReq;
import aeonticketpros.TicketProsCheckoutResp;
import aeonticketpros.TicketProsConnection;
import aeonticketpros.TicketProsEvent;
import aeonticketpros.TicketProsEventDetail;
import aeonticketpros.TicketProsEventList;
import aeonticketpros.TicketProsPaymentReq;
import aeonticketpros.TicketProsPaymentResp;
import aeonticketpros.TicketProsPrintReq;
import aeonticketpros.TicketProsPrintResp;
import aeonticketpros.TicketProsReserveSeatsReq;
import aeonticketpros.TicketProsReserveSeatsResp;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.concurrent.Task;
import javafx.concurrent.Worker.State;
import jkiosk3.JKiosk3;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.PrintUtil;
import jkiosk3.printing.print_layouts.PrintTicketPro;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.sales.ticketpro.cache.CacheControllerTicketPro;
import jkiosk3.sales.ticketpro.cache.CacheTPCatAndEvent;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.store.cache.CacheListTicketProAllowed;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

public class TicketProUtil {

    private final static Logger logger = Logger.getLogger(TicketProUtil.class.getName());
    //
    public final static String TICKETPRO_SALES = "Buy Event Tickets";
    public final static String TICKETPRO_SALES_BUS = "Buy Bus Tickets";
    public final static String TICKETPRO_CANCELLATIONS = "Cancel Tickets";
    public final static String TICKETPRO_REPRINT = "Reprint Tickets";
    public final static String TICKETPRO_COLLECT = "Collect Tickets";
    //
    private static TicketProsConnection tpConn;
    private static String userPin;
    //
    private static CacheControllerTicketPro cacheControllerTicketPro;
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 90;

    private static TicketProsConnection getTicketProConnection() {
        TicketProsConnection tpConnect = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            tpConnect = new TicketProsConnection(server, port, secureConnect);
            tpConnect.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return tpConnect;
    }

    public static boolean isLoggedIn(String pin) throws RuntimeException {
        String loyaltyProfileId = "";
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            loyaltyProfileId = ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId();
        }

        boolean loggedIn = false;
        userPin = pin;
        int deviceId = JKSystem.getSystemConfig().getDeviceId();
        String serial = JKSystem.getSystemConfig().getSerial();
        tpConn = getTicketProConnection();

        try {
            loggedIn = tpConn.login(userPin, deviceId, serial, loyaltyProfileId);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    private static List<TicketProAllowedProduct> getAllowedProductsList() throws RuntimeException {
        List<TicketProAllowedProduct> listAllowedProd = new ArrayList<>();

        if (CacheListTicketProAllowed.hasItems()) {
            listAllowedProd = CacheListTicketProAllowed.getListTicketProAllowed();
        } else {
            TicketProAllowedProdListResp listAllowed = getOnlineAllowedProducts();
            listAllowedProd = listAllowed.getListAllowedProducts();
        }

        return listAllowedProd;
    }

    private static TicketProAllowedProdListResp getOnlineAllowedProducts() throws RuntimeException {
        TicketProAllowedProdListResp listAllowed = new TicketProAllowedProdListResp();
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                listAllowed = tpConn.getAllowedProducts();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Allowed Product List Error", t);
        } finally {
            if (tpConn != null) {
                tpConn.disconnect();
            }
        }
        return listAllowed;
    }

    private static TicketProsCategoryList getTicketProCategoryList() {
        TicketProsCategoryList tpCatList = null;
        if (CacheTPCatAndEvent.getListTPCategories() != null && CacheTPCatAndEvent.hasCategoryItems()) {
            tpCatList = CacheTPCatAndEvent.getListTPCategories();
        } else {
            tpCatList = getTicketProCategoryListOnline();
        }
        if (tpCatList.getListCategories() != null) {
            Collections.sort(tpCatList.getListCategories(), new Comparator<TicketProsCategory>() {
                @Override
                public int compare(TicketProsCategory c1, TicketProsCategory c2) {
                    return c1.getName().compareTo(c2.getName());
                }
            });
        }

        return tpCatList;
    }

    private static TicketProsCategoryList getTicketProCategoryListOnline() throws RuntimeException {
        TicketProsCategoryList tpCatList = null;
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                tpCatList = tpConn.getCategories();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Category List Error", t);
        } finally {
            if (tpConn != null) {
                tpConn.disconnect();
            }
        }
        return tpCatList;
    }

    private static TicketProsEventList getTicketProEventsAllList() {
        TicketProsEventList listAllEvents = null;
        if (CacheTPCatAndEvent.getListTPEvents() != null && CacheTPCatAndEvent.hasEventItems()) {
            listAllEvents = CacheTPCatAndEvent.getListTPEvents();
        } else {
            listAllEvents = getTicketProEventsAllOnline();
        }
        return listAllEvents;
    }

    private static TicketProsEventList getTicketProEventsAllOnline() throws RuntimeException {
        TicketProsEventList tpEventList = null;
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                tpEventList = tpConn.getEventsAllList();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Events Error", t);
        } finally {
            if (tpConn != null) {
                tpConn.disconnect();
            }
        }
        return tpEventList;
    }

    private static List<TicketProsEvent> getTicketProEventList(String catId) {
        List<TicketProsEvent> listEventsForCat = new ArrayList<>();
        if (CacheTPCatAndEvent.getListTPEvents() != null && CacheTPCatAndEvent.hasEventItems()) {
            for (TicketProsEvent e : CacheTPCatAndEvent.getListTPEvents().getListEvents()) {
                if (e.getCategoryId().equalsIgnoreCase(catId)) {
                    listEventsForCat.add(e);
                }
            }
        } else {
            TicketProsEventList tpEventList = getTicketProEventListOnline(catId);
            listEventsForCat = tpEventList.getListEvents();
        }
        if (!listEventsForCat.isEmpty()) {
            Collections.sort(listEventsForCat, new Comparator<TicketProsEvent>() {
                @Override
                public int compare(TicketProsEvent o1, TicketProsEvent o2) {
                    return o1.getStartDate().compareTo(o2.getStartDate());
                }
            });
        }
        return listEventsForCat;
    }

    private static TicketProsEventList getTicketProEventListOnline(String catId) throws RuntimeException {
        TicketProsEventList tpEventList = null;
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                tpEventList = tpConn.getEventList(catId);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Events Error", t);
        } finally {
            if (tpConn != null) {
                tpConn.disconnect();
            }
        }
        return tpEventList;
    }

    private static List<TicketProsEvent> getTicketProEventsSearchedList(String searchTerm, List<TicketProsEvent> listToSearch) {
        List<TicketProsEvent> listEventsSearched = new ArrayList<>();
        if (!listToSearch.isEmpty()) {
            List<TicketProsEvent> srchListEvtTmp = new ArrayList<>();
            for (TicketProsEvent e : listToSearch) {
                if (e.getName().toLowerCase(Locale.ENGLISH).contains(searchTerm.toLowerCase(Locale.ENGLISH))) {
                    srchListEvtTmp.add(e);
                }
            }
            listEventsSearched = srchListEvtTmp;
            Collections.sort(listEventsSearched, new Comparator<TicketProsEvent>() {
                @Override
                public int compare(TicketProsEvent o1, TicketProsEvent o2) {
                    return o1.getStartDate().compareTo(o2.getStartDate());
                }
            });
        }
        return listEventsSearched;
    }

    private static TicketProsEventDetail getTicketProEventDetail(String eventId) throws RuntimeException {
        TicketProsEventDetail eventDetail = new TicketProsEventDetail();
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                eventDetail = tpConn.getEventDetail(eventId);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Event Detail Error", t);
        } finally {
            if (tpConn != null) {
                tpConn.disconnect();
            }
        }
        return eventDetail;
    }

    //
    // From here onwards, SalesUser has logged in and Session must be kept open.
    //
    private static TicketProsCart createTicketProCart() throws RuntimeException {
        TicketProsCart cart = null;
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                cart = tpConn.createTicketProsCart();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Create Cart Error", t);
        }
        return cart;
    }

    private static TicketProsReserveSeatsResp reserveTicketProSeats(TicketProsReserveSeatsReq req) throws RuntimeException {
        TicketProsReserveSeatsResp resp = null;
        try {
            resp = tpConn.reserveTicketProsSeats(req);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Reserve Seats Error", t);
        }
        return resp;
    }

    private static TicketProsCartClearResp clearCart(TicketProsCartClearReq req) throws RuntimeException {
        TicketProsCartClearResp resp = null;
        try {
            resp = tpConn.clearCart(req);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Clear Cart Error", t);
        }

        return resp;
    }

    private static TicketProsCheckoutResp checkoutTicketPro(TicketProsCheckoutReq req) throws RuntimeException {
        TicketProsCheckoutResp resp = null;
        try {
            resp = tpConn.checkout(req);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Checkout Error", t);
        }
        return resp;
    }

    private static TicketProsPaymentResp getTicketProPaymentResponse(int count, TicketProsPaymentReq req) throws RuntimeException {
        TicketProsPaymentResp resp = null;
        try {
            if (count == 1) {
                resp = tpConn.makePayment(req);
            } else {
                userPin = CurrentUser.getSalesUser().getUserPin();
                if (isLoggedIn(userPin)) {
                    resp = tpConn.makePayment(req);
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Payment Error", t);
        }
        return resp;
    }

    private static TicketProsPrintResp getTicketProPrint(int count, TicketProsPrintReq req) throws RuntimeException {
        TicketProsPrintResp resp = null;
        try {
            if (req.isReprint()) {
                userPin = CurrentUser.getSalesUser().getUserPin();
                tpConn = getTicketProConnection();
                if (isLoggedIn(userPin)) {
                    resp = tpConn.getPrint(req);
                }
            } else {
                if (count == 1) {
                    resp = tpConn.getPrint(req);
                } else {
                    userPin = CurrentUser.getSalesUser().getUserPin();
                    if (isLoggedIn(userPin)) {
                        resp = tpConn.getPrint(req);
                    }
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Print Error", t);
        } finally {
            if (tpConn != null) {
                tpConn.disconnect();
            }
        }
        return resp;
    }

    private static TicketProsPrintResp getTicketCollection(TicketProsPrintReq req) throws RuntimeException {
        TicketProsPrintResp resp = null;
        try {
            userPin = CurrentUser.getSalesUser().getUserPin();
            tpConn = getTicketProConnection();

            if (isLoggedIn(userPin)) {
                resp = tpConn.getTicketCollection(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Collection Print Error", t);
        } finally {
            if (tpConn != null) {
                tpConn.disconnect();
            }
        }

        return resp;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getAllowedProducts(final TicketProAllowedProductsListResult result) {
        JKiosk3.getBusy().showBusy("Getting TicketPro Allowed Product List");

        final Task<List<TicketProAllowedProduct>> taskAllowedProd = new Task<List<TicketProAllowedProduct>>() {
            @Override
            protected List<TicketProAllowedProduct> call() throws Exception {
                return getAllowedProductsList();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpAllowedProductsListResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Allowed Products",
                        "Unable to retrieve Allowed Products List", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Allowed Products",
                        "Unable to retrieve Allowed Products List", State.CANCELLED, errorMsg, new TicketProMenu());
            }
        };
        new Thread(taskAllowedProd).start();
        JKiosk3.getBusy().startCountdown(taskAllowedProd, countdownTime);
    }

    public static void getTicketProCategoryList(final boolean isCacheList, final TicketProCategoryListResult result) {
        JKiosk3.getBusy().showBusy("Getting TicketPro Category List");

        final Task<TicketProsCategoryList> taskTPCat = new Task<TicketProsCategoryList>() {
            @Override
            protected TicketProsCategoryList call() throws Exception {
                if (isCacheList) {
                    return getTicketProCategoryListOnline();
                } else {
                    return getTicketProCategoryList();
                }
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpCategoryListResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Categories",
                        "Unable to retrieve Category List", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Categories",
                        "Unable to retrieve Category List", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPCat).start();
        JKiosk3.getBusy().startCountdown(taskTPCat, countdownTime);
    }

    public static void getTicketProEventsAllList(final boolean isCacheList, final TicketProEventListAllResult result) {
        JKiosk3.getBusy().showBusy("Getting Full TicketPro Event List");

        final Task<TicketProsEventList> taskTPEvent = new Task<TicketProsEventList>() {
            @Override
            protected TicketProsEventList call() throws Exception {
                if (isCacheList) {
                    return getTicketProEventsAllOnline();
                } else {
                    return getTicketProEventsAllList();
                }
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpEventListAllResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Events",
                        "Unable to retrieve Events", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Events",
                        "Unable to retrieve Events", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPEvent).start();
        JKiosk3.getBusy().startCountdown(taskTPEvent, countdownTime);
    }

    public static void getTicketProEventList(final String catId, final TicketProEventListResult result) {
        JKiosk3.getBusy().showBusy("Getting TicketPro Event List");

        final Task<List<TicketProsEvent>> taskTPEvent = new Task<List<TicketProsEvent>>() {
            @Override
            protected List<TicketProsEvent> call() throws Exception {
                return getTicketProEventList(catId);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpEventListResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Events",
                        "Unable to retrieve Events", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Events",
                        "Unable to retrieve Events", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPEvent).start();
        JKiosk3.getBusy().startCountdown(taskTPEvent, countdownTime);
    }

    public static void getTicketProEventsSearchedList(final String searchTerm, final List<TicketProsEvent> listToSearch, final TicketProEventListResult result) {
        JKiosk3.getBusy().showBusy("Getting Full TicketPro Event List");
        final Task<List<TicketProsEvent>> taskTPEvent = new Task<List<TicketProsEvent>>() {
            @Override
            protected List<TicketProsEvent> call() throws Exception {
                return getTicketProEventsSearchedList(searchTerm, listToSearch);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpEventListResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Events",
                        "Unable to retrieve Events", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Events",
                        "Unable to retrieve Events", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPEvent).start();
        JKiosk3.getBusy().startCountdown(taskTPEvent, countdownTime);
    }

    public static void getTicketProEventDetail(final String eventId, final TicketProEventDetailResult result) {
        JKiosk3.getBusy().showBusy("Getting TicketPro Event Detail");
        final Task<TicketProsEventDetail> taskTPEventDetail = new Task<TicketProsEventDetail>() {
            @Override
            protected TicketProsEventDetail call() throws Exception {
                return getTicketProEventDetail(eventId);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpEventDetailResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Event Detail",
                        "Unable to retrieve Event Detail", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Event Detail",
                        "Unable to retrieve Event Detail", State.FAILED, errorMsg, new TicketProMenu());
            }
        };
        new Thread(taskTPEventDetail).start();
        JKiosk3.getBusy().startCountdown(taskTPEventDetail, countdownTime);
    }

    public static void createTicketProCart(final TicketProCreateCartResult result) {
        JKiosk3.getBusy().showBusy("Creating TicketPro Cart");

        final Task<TicketProsCart> taskTPCart = new Task<TicketProsCart>() {
            @Override
            protected TicketProsCart call() throws Exception {
                return createTicketProCart();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpCreateCartResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Cart",
                        "Unable to Create TicketPro Cart", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Cart",
                        "Unable to Create TicketPro Cart", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPCart).start();
        JKiosk3.getBusy().startCountdown(taskTPCart, countdownTime);
    }

    public static void reserveTicketProSeats(final TicketProsReserveSeatsReq req, final TicketProReserveSeatsResult result) {
        JKiosk3.getBusy().showBusy("Reserving TicketPro Seats");

        final Task<TicketProsReserveSeatsResp> taskTPReserve = new Task<TicketProsReserveSeatsResp>() {
            @Override
            protected TicketProsReserveSeatsResp call() throws Exception {
                return reserveTicketProSeats(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpReserveSeatsResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Reserve Seats",
                        "Error Reserving Seats", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Reserve Seats",
                        "Error Reserving Seats", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPReserve).start();
        JKiosk3.getBusy().startCountdown(taskTPReserve, countdownTime);
    }

    public static void clearCart(final TicketProsCartClearReq req, final TicketProClearCartResult result) {
        JKiosk3.getBusy().showBusy("Clearing TicketPro Cart");

        final Task<TicketProsCartClearResp> taskTPCartClear = new Task<TicketProsCartClearResp>() {
            @Override
            protected TicketProsCartClearResp call() throws Exception {
                return clearCart(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpClearCartResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Clear Cart",
                        "Error Clearing Cart", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Clear Cart",
                        "Error Clearing Cart", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPCartClear).start();
        JKiosk3.getBusy().startCountdown(taskTPCartClear, countdownTime);
    }

    public static void checkoutTicketPro(final TicketProsCheckoutReq req, final TicketProCheckoutResult result) {
        JKiosk3.getBusy().showBusy("Processing TicketPro Checkout");

        final Task<TicketProsCheckoutResp> taskTPCheckout = new Task<TicketProsCheckoutResp>() {
            @Override
            protected TicketProsCheckoutResp call() throws Exception {
                return checkoutTicketPro(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpCheckoutResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Checkout",
                        "Error Processing Checkout", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Checkout",
                        "Error Processing Checkout", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPCheckout).start();
        JKiosk3.getBusy().startCountdown(taskTPCheckout, countdownTime);
    }

    public static void getTicketProPaymentResponse(final int count, final TicketProsPaymentReq req, final TicketProPaymentResult result) {
        JKiosk3.getBusy().showBusy("Processing TicketPro Payment");

        final Task<TicketProsPaymentResp> taskTPPayment = new Task<TicketProsPaymentResp>() {
            @Override
            protected TicketProsPaymentResp call() throws Exception {
                return getTicketProPaymentResponse(count, req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpPaymentResult(getValue());
            }

            @Override
            protected void cancelled() {
                getCancelledFailedPayment(count, req, result, State.CANCELLED);
            }

            @Override
            protected void failed() {
                getCancelledFailedPayment(count, req, result, State.FAILED);
            }
        };

        new Thread(taskTPPayment).start();
        JKiosk3.getBusy().startCountdown(taskTPPayment, countdownTime);
    }

    private static void getCancelledFailedPayment(final int count, final TicketProsPaymentReq req,
                                                  final TicketProPaymentResult result, final State state) {
        JKiosk3.getBusy().hideBusy();
        String msgReason = "Error Processing TicketPro Payment" + "\n\n" + state + "\n\n";
        if (count == 1) {
            JKiosk3.getMsgBox().showMsgBox("TicketPro Payment", msgReason + "Click 'OK' to retry",
                    null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            getTicketProPaymentResponse(2, req, result);
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        } else {
            showErrorAndPrintNotice("Payment", state);
        }
    }

    public static void getTicketProPrint(final int count, final TicketProsPrintReq req, final TicketProPrintResult result) {
        String strPrint = "Print";
        if (req.isReprint()) {
            strPrint = "Reprint";
        }
        JKiosk3.getBusy().showBusy("Processing TicketPro " + strPrint);

        final Task<TicketProsPrintResp> taskTPPrint = new Task<TicketProsPrintResp>() {
            @Override
            protected TicketProsPrintResp call() throws Exception {
                return getTicketProPrint(count, req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpPrintResult(getValue());
            }

            @Override
            protected void cancelled() {
                getCancelledFailedPrint(count, req, result, State.CANCELLED);
            }

            @Override
            protected void failed() {
                getCancelledFailedPrint(count, req, result, State.FAILED);
            }
        };

        new Thread(taskTPPrint).start();
        JKiosk3.getBusy().startCountdown(taskTPPrint, countdownTime);
    }

    private static void getCancelledFailedPrint(final int count, final TicketProsPrintReq req,
                                                final TicketProPrintResult result, final State state) {
        String strPrint = "Print";
        if (req.isReprint()) {
            strPrint = "Reprint";
        }
        JKiosk3.getBusy().hideBusy();
        String msgReason = "Error Processing TicketPro " + strPrint + "\n\n" + state + "\n\n";
        if (count == 1) {
            JKiosk3.getMsgBox().showMsgBox("TicketPro " + strPrint, msgReason + "Click 'OK' to retry",
                    null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            getTicketProPrint(2, req, result);
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        } else {
            showErrorAndPrintNotice(strPrint, state);
        }
    }

    public static void getTicketCollection(final int count, final TicketProsPrintReq req, final TicketProPrintResult result) {
        JKiosk3.getBusy().showBusy("Processing TicketPro Collection");

        final Task<TicketProsPrintResp> taskTPCollect = new Task<TicketProsPrintResp>() {
            @Override
            protected TicketProsPrintResp call() throws Exception {
                return getTicketCollection(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpPrintResult(getValue());
            }

            @Override
            protected void cancelled() {
                getCancelledFailedCollect(count, req, result, State.CANCELLED);
            }

            @Override
            protected void failed() {
                getCancelledFailedCollect(count, req, result, State.FAILED);
            }
        };
        new Thread(taskTPCollect).start();
        JKiosk3.getBusy().startCountdown(taskTPCollect, countdownTime);
    }

    private static void getCancelledFailedCollect(final int count, final TicketProsPrintReq req,
                                                  final TicketProPrintResult result, final State state) {
        JKiosk3.getBusy().hideBusy();
        String msgReason = "Error Processing TicketPro Collection" + "\n\n" + state + "\n\n";
        if (count == 1) {
            JKiosk3.getMsgBox().showMsgBox("TicketPro Collection", msgReason + "Click 'OK' to retry",
                    null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            getTicketCollection(2, req, result);
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        } else {
            showErrorAndPrintNotice("Collection", state);
        }
    }

    private static void showErrorAndPrintNotice(String tpEventType, State state) {
//        String msgadd = "\n\nPlease check your network connection";       // Do we need to tell the User this???
        String msgadd = "\n";
        String msgReason = "Error Processing TicketPro " + tpEventType + "\n\n" + state + "\n\n";

        if (state == State.CANCELLED) {
            msgReason += "Operation timed out" + msgadd;
        } else if (state == State.FAILED) {
            msgReason += errorMsg + msgadd;
        }
        msgReason += "\n\nClick 'OK' to print details";
        msgReason += "\n\nPlease phone TicketPro Customer Services to cancel this sale";

        JKiosk3.getMsgBox().showMsgBox("TicketPro " + tpEventType, msgReason,
                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                    @Override
                    public void onOk() {
                        PrintTicketPro print = new PrintTicketPro();
                        AeonPrintJob apj = print.getTicketProCancelRequestPrint();
                        PrintUtil.sendToPrinter(apj);
                        SceneSales.clearAndShowFavourites();
                    }

                    @Override
                    public void onCancel() {
                        //
                    }
                });
    }

    // =======================
    // Abstract Result classes
    // =======================
    public static abstract class TicketProAllowedProdListResult {

        public abstract void tpAllowedProdListResult(TicketProAllowedProdListResp tpAllowedProdList);
    }

    public static abstract class TicketProAllowedProductsListResult {

        public abstract void tpAllowedProductsListResult(List<TicketProAllowedProduct> tpAllowedList);
    }

//    public static abstract class TicketProCacheResult {
//        public abstract void tpCacheResult(boolean isTPCacheSuccess);
//    }

    public static abstract class TicketProCategoryListResult {

        public abstract void tpCategoryListResult(TicketProsCategoryList tpCategoryList);
    }

    public static abstract class TicketProEventListAllResult {

        public abstract void tpEventListAllResult(TicketProsEventList tpEventListAllResult);
    }

    public static abstract class TicketProEventListResult {

        public abstract void tpEventListResult(List<TicketProsEvent> tpEventListResult);
    }

    public static abstract class TicketProEventDetailResult {

        public abstract void tpEventDetailResult(TicketProsEventDetail tpEventDetailResult);
    }

    public static abstract class TicketProCreateCartResult {

        public abstract void tpCreateCartResult(TicketProsCart tpCreateCart);
    }

    public static abstract class TicketProReserveSeatsResult {

        public abstract void tpReserveSeatsResult(TicketProsReserveSeatsResp tpReserveSeats);
    }

    public static abstract class TicketProClearCartResult {

        public abstract void tpClearCartResult(TicketProsCartClearResp tpClearCartResp);
    }

    public static abstract class TicketProCheckoutResult {

        public abstract void tpCheckoutResult(TicketProsCheckoutResp tpCheckoutResp);
    }

    public static abstract class TicketProPaymentResult {

        public abstract void tpPaymentResult(TicketProsPaymentResp tpPaymentResp);
    }

    public static abstract class TicketProPrintResult {

        public abstract void tpPrintResult(TicketProsPrintResp tpPrintResp);
    }

    // getters
    public static TicketProsConnection getTpConn() {
        return getTicketProConnection();
    }

    public static CacheControllerTicketPro getCacheControllerTicketPro() {
        if (cacheControllerTicketPro == null) {
            cacheControllerTicketPro = new CacheControllerTicketPro();
            return cacheControllerTicketPro;
        } else {
            return cacheControllerTicketPro;
        }
    }
}
