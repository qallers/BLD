package jkiosk3.sales.coaches;

import aeoncoach.CoachPassenger;
import aeoncoach.CoachPassengerType;
import aeoncoach.CoachPassengerTypeList;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.*;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.TicketingMenu;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.users.UserUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import static jkiosk3.sales._bus_carriers.CoachCarrierLayouts.*;

public class CoachBook4 extends Region {

    private final static Logger logger = Logger.getLogger (CoachBook4.class.getName ());

    private List<CoachPassengerType> listPassengerTypes;
    private GridPane gridPassenger;
    private CheckBox chkInfOnLap;
    private VBox vbFullView;
    private int seatsTotal;
    private int passengerCount;
    private int indexEdit;
    private CoachPassenger passengerCurrent;
    private CoachPassenger passengerEdit;
    private Date passengerDateOfBirth;
    private Button btnAdd;
    private Button btnView;
    private JKioskNav nav;
    private SimpleDateFormat dateformat;
    private double transX;

    public CoachBook4() {
        listPassengerTypes = new ArrayList<> ();
        CoachUtil.getCoachPassengerTypeList (new CoachUtil.CoachPassengerTypeListResult () {
            @Override
            public void coachPassengerTypeListResult(CoachPassengerTypeList coachPassengerTypeListResult) {
                if (coachPassengerTypeListResult.isSuccess ()) {
                    String carrierCode = CoachTicketSale.getInstance ().getCoachCarrierDepart ().getCarrierCode ();
                    for (CoachPassengerType c : coachPassengerTypeListResult.getListCoachPassengerTypes ()) {
                        if (c.getCarrierId ().equalsIgnoreCase (carrierCode)) {
                            listPassengerTypes.add (c);
                        }
                    }

                    if (listPassengerTypes.isEmpty()) {
                        //PRODDEFECT-994
                        //in case AEON does not send the passenger types for the selected carrier,
                        //add the Adult type by default, or else JKiosk cannot capture passenger details
                        //this means only full price tickets can be sold, but better than nothing
                        logger.log(Level.SEVERE, "No passenger types found for " + carrierCode);
                        CoachPassengerType c = new CoachPassengerType();
                        c.setCode("A");
                        c.setCarrierId(carrierCode);
                        c.setName("ADULT");
                        c.setInfo("adult info");
                        listPassengerTypes.add(c);
                    }

                    seatsTotal = CoachTicketSale.getInstance().getSeats();

                    nav = getNav ();

                    dateformat = new SimpleDateFormat ("dd/MM/yyyy");

                    transX = (JKLayout.sp + (JKLayout.sp / 2));

                    VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
                    vb.getChildren ().addAll (showCoachTicketBookStep4 (), nav);
                    getChildren ().add (vb);
                } else {
                    // no passenger type list, show error
                    JKiosk3.getMsgBox ().showMsgBox ("Passenger Type List Error", !coachPassengerTypeListResult.getAeonErrorText ().isEmpty () ?
                                    "A" + coachPassengerTypeListResult.getAeonErrorCode () + " - " + coachPassengerTypeListResult.getAeonErrorText () :
                                    "B" + coachPassengerTypeListResult.getErrorCode () + " - " + coachPassengerTypeListResult.getErrorText (), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    SceneSales.clearAndChangeContent (new TicketingMenu ());
                                }

                                @Override
                                public void onCancel() {
                                }
                            });
                }
            }
        });
    }

    private VBox showCoachTicketBookStep4() {

        Label lblHead1 = JKText.getLblDk (CoachUtil.COACH_PG_HEAD, JKText.FONT_B_24);
        Label lblHead2 = JKText.getLblDk ("Passenger Details", JKText.FONT_B_22);

        VBox vbHead = JKNode.getPageDblHeadVB (0, lblHead1, lblHead2);

        GridPane gridTrip = getGridTripsSelected ();
        gridTrip.setTranslateX (-transX);

        HBox hbViewAdd = getHBoxViewAdd ();

        if (CoachTicketSale.getInstance ().getListPassengers ().size () == seatsTotal) {
            passengerCount = seatsTotal;
            btnAdd.setDisable (true);
            nav.getBtnNext ().setDisable (false);
        } else if (CoachTicketSale.getInstance ().getListPassengers ().isEmpty ()) {
            passengerCount = 0;
        } else {
            passengerCount = CoachTicketSale.getInstance ().getListPassengers ().size () - 1;
        }
        gridPassenger = getGridPassengerEntry (passengerCount, false);

        vbFullView = JKLayout.getVBoxContent (JKLayout.sp);
        vbFullView.getChildren ().addAll (vbHead, gridTrip, gridPassenger, hbViewAdd);

        return vbFullView;
    }

    private GridPane getGridPassengerEntry(int passengerCount, boolean isEdit) {

        String passengerEntry = "";
        if ((passengerCount < seatsTotal) && (!isEdit)) {
            passengerCurrent = new CoachPassenger ();
            passengerEntry = (passengerCount + 1) + " of " + seatsTotal;
        } else if ((passengerCount < seatsTotal) && (isEdit)) {
            passengerCurrent = passengerEdit;
            passengerEntry = "Editing Passenger";
        } else {
            passengerCurrent = new CoachPassenger ();
            passengerEntry = "All Passengers Entered";
        }

        Label lblPassCount = JKText.getLblDk ("Passenger Entry : " + passengerEntry, JKText.FONT_B_20);

        Label lblType = getPassengerLabel ("Type");
        Label lblTitle = getPassengerLabel ("Title");
        final Label lblInfOnLap = getPassengerLabel ("Infant on Lap?");
        final Label lblDOB = getPassengerLabel ("Date of Birth");

        Label lblInitial = getPassengerLabel ("Initials");
        Label lblSurname = getPassengerLabel ("Surname");
        Label lblIdNum = getPassengerLabel ("ID/Passport Number");
        Label lblCellNum = getPassengerLabel ("Contact Number");

        ObservableList types = FXCollections.observableArrayList (listPassengerTypes);

        final ComboBox comType = getComboBoxList (types);
        comType.setTranslateX (-1);

        String[] titleCodes = {"Mr", "Miss", "Ms", "Mrs", "Dr", "Hon", "Prof", "Rev"};
        ObservableList titles = FXCollections.observableArrayList (titleCodes);

        final ComboBox comTitle = getComboBoxList (titles);
        comTitle.setTranslateX (-1);
        comTitle.setVisibleRowCount (15);
        comTitle.getSelectionModel ().selectedItemProperty ().addListener (new ChangeListener () {
            @Override
            public void changed(ObservableValue observableValue, Object o, Object t1) {
                passengerCurrent.setTitle (t1.toString ());
            }
        });

        chkInfOnLap = new CheckBox ();
        chkInfOnLap.setDisable (!CoachTicketSale.getInstance ().getCoachCarrierDepart ().isAllowInfantOnLap ());
        chkInfOnLap.setMaxHeight (35);
        chkInfOnLap.setMinHeight (35);
        chkInfOnLap.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (chkInfOnLap.isSelected ()) {
                    System.out.println ("passengerTypeCode = " + passengerCurrent.getPassengerTypeCode ());
                    if (passengerCurrent.getPassengerType ().getName ().equals ("ADULT")) {
                        passengerCurrent.setInfant (true);
                        getInfantEntry ();
                    }
                } else {
                    // remove infant if already saved
                    if (passengerCurrent.getPassengerType ().getName ().equals ("ADULT")
                            && passengerCurrent.isInfant () && passengerCurrent.getPassengerInfantOnLap () != null) {
                        JKiosk3.getMsgBox ().showMsgBox ("Infant On Lap", "\nThis Adult Passenger has an Infant On Lap." +
                                        "\n\nClick 'OK' to REMOVE (delete) this Infant On Lap \nfrom this Adult Passenger, " +
                                        "\n\nor click 'Cancel' to KEEP this Infant On Lap \nwith this Adult Passenger",
                                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                                    @Override
                                    public void onOk() {
                                        passengerCurrent.setPassengerInfantOnLap (null);
                                        passengerCurrent.setInfant (false);
                                        chkInfOnLap.setSelected (false);
                                    }

                                    @Override
                                    public void onCancel() {
                                        chkInfOnLap.setSelected (true);
                                    }
                                });
                    } else {
                        passengerCurrent.setInfant (false);
                    }
                }
            }
        });

        final TextField txtDateOfBirth = JKNode.getTextField35H ();
        txtDateOfBirth.setPromptText ("dd/MM/yyyy");
        txtDateOfBirth.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (txtDateOfBirth, "Child or Infant Date Of Birth (dd/MM/yyyy)", "",
                        false, true, new KeyboardResult () {
                            @Override
                            public void onDone(String value) {
                                if (validateDateOfBirth (value)) {
                                    if (passengerDateOfBirth != null) {
                                        passengerCurrent.setDateOfBirth (passengerDateOfBirth);
                                        int ageAsId = (int) (getChildAgeInDays (passengerDateOfBirth) / 365.25);
                                        passengerCurrent.setIdNumber (Integer.toString (ageAsId));
                                        txtDateOfBirth.setText (dateformat.format (passengerDateOfBirth));
                                    }
                                } else {
                                    txtDateOfBirth.clear ();
                                }
                            }
                        });
            }
        });

//        VBox vbTitle = getPassengerVBox(lblTitle, comTitle);
//        VBox vbType = getPassengerVBox(lblType, comType);
//        final VBox vbInfOrDOB = getPassengerVBox(lblInfOnLap, chkInfOnLap);

        final TextField txtInitial = JKNode.getTextField35H ();
        txtInitial.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (txtInitial, "Passenger Initials", "", false, true,
                        new KeyboardResult () {
                            @Override
                            public void onDone(String value) {
                                if (!value.matches ("[a-zA-Z ]{1,3}")) {
                                    JKiosk3.getMsgBox ().showMsgBox ("Passenger Initials", "Please enter Initials,"
                                            + "\nnot more than 3 characters", null);
                                    txtInitial.clear ();
                                } else {
                                    passengerCurrent.setInitials (value);
                                }
                            }
                        });
            }
        });
//        VBox vbInitial = getPassengerVBox(lblInitial, txtInitial);

        final TextField txtSurname = JKNode.getTextField35H ();
        txtSurname.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (txtSurname, "Passenger Surname", "", false, true,
                        new KeyboardResult () {
                            @Override
                            public void onDone(String value) {
                                if (!value.matches ("[a-zA-Z ]{1,20}")) {
                                    JKiosk3.getMsgBox ().showMsgBox ("Passenger Surname", "Please enter Passenger Surname, "
                                            + "\nnot more than 20 characters", null);
                                    txtSurname.clear ();
                                } else {
                                    passengerCurrent.setLastName (value);
                                }
                            }
                        });
            }
        });
//        VBox vbSurname = getPassengerVBox(lblSurname, txtSurname);
//        GridPane.setColumnSpan(vbSurname, 3);

        final TextField txtIdNum = JKNode.getTextField35H ();
        txtIdNum.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (txtIdNum, "Passenger ID or Passport Number", "", false, true,
                        new KeyboardResult () {
                            @Override
                            public void onDone(String value) {
                                passengerCurrent.setIdNumber (value);
                            }
                        });
            }
        });
//        VBox vbId = getPassengerVBox(lblIdNum, txtIdNum);

        final TextField txtCellNum = JKNode.getTextField35H ();
        txtCellNum.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad ().showNumPad (txtCellNum, "Passenger Cell Num", "",
                        new NumberPadResult () {
                            @Override
                            public void onDone(String value) {
                                if (validateCellNumber (value)) {
                                    passengerCurrent.setCellNum (value.replaceAll (" ", ""));
                                    txtCellNum.setText (JKText.getCellNumFormatted (value.replaceAll (" ", "")));
                                } else {
                                    txtCellNum.clear ();
                                }
                            }
                        });
            }
        });

        VBox vbTitle = getPassengerVBox (lblTitle, comTitle);
        VBox vbType = getPassengerVBox (lblType, comType);
        final VBox vbInfOrDOB = getPassengerVBox (lblInfOnLap, chkInfOnLap);
        VBox vbInitial = getPassengerVBox (lblInitial, txtInitial);
        VBox vbSurname = getPassengerVBox (lblSurname, txtSurname);
        GridPane.setColumnSpan (vbSurname, 3);
        VBox vbId = getPassengerVBox (lblIdNum, txtIdNum);
        VBox vbCell = getPassengerVBox (lblCellNum, txtCellNum);

        if (isEdit) {
            comType.getSelectionModel ().select (passengerCurrent.getPassengerType ());
            comTitle.getSelectionModel ().select (passengerCurrent.getTitle ());
            chkInfOnLap.setSelected (passengerCurrent.isInfant ());
            txtInitial.setText (passengerCurrent.getInitials ());
            txtSurname.setText (passengerCurrent.getLastName ());
            txtIdNum.setText (passengerCurrent.getIdNumber ());
            txtCellNum.setText (JKText.getCellNumFormatted (passengerCurrent.getCellNum ()));
            if (!passengerCurrent.getPassengerType ().getName ().equalsIgnoreCase ("ADULT")) {
                txtDateOfBirth.setText (dateformat.format (passengerCurrent.getDateOfBirth ()));
                vbInfOrDOB.getChildren ().clear ();
                vbInfOrDOB.getChildren ().addAll (lblDOB, txtDateOfBirth);
            }
        } else if (passengerCount < seatsTotal) {
            passengerCurrent.setPassengerType (((CoachPassengerType) comType.getSelectionModel ().getSelectedItem ()));
            passengerCurrent.setPassengerTypeCode (((CoachPassengerType) comType.getSelectionModel ().getSelectedItem ()).getCode ());
            passengerCurrent.setTitle (comTitle.getSelectionModel ().getSelectedItem ().toString ());
        }

        comType.valueProperty ().addListener (new ChangeListener<CoachPassengerType> () {
            @Override
            public void changed(ObservableValue observableValue, CoachPassengerType o, CoachPassengerType t1) {
                passengerCurrent.setPassengerType ((t1));
                passengerCurrent.setPassengerTypeCode ((t1.getCode ()));
                chkInfOnLap.setSelected (false);
                txtDateOfBirth.clear ();
                switch (t1.getName ()) {
                    case "ADULT":
                        vbInfOrDOB.getChildren ().clear ();
                        vbInfOrDOB.getChildren ().addAll (lblInfOnLap, chkInfOnLap);
                        break;
                    case "CHILD":
                    case "INFANT":
                        vbInfOrDOB.getChildren ().clear ();
                        vbInfOrDOB.getChildren ().addAll (lblDOB, txtDateOfBirth);
                        break;
                    default:
                        vbInfOrDOB.getChildren ().clear ();
                        break;
                }
            }
        });

        GridPane grid = JKLayout.getGridPane4Col (gridCoach, 0.25, 0.25, 0.25, 0.25, 1, HPos.LEFT);
        grid.setVgap (JKLayout.sp);
        grid.setTranslateX (-transX);

        grid.add (lblPassCount, 0, 0, 4, 1);
        grid.addRow (1, vbType, vbTitle, new Region (), vbInfOrDOB);
        grid.addRow (2, vbInitial, vbSurname);
        grid.add (vbId, 0, 3, 2, 1);
        grid.add (vbCell, 2, 3, 2, 1);
        grid.addRow (4, JKNode.createGridSpanSep (4));

        if (passengerCount < seatsTotal) {
            grid.setDisable (false);
        } else {
            grid.setDisable (true);
        }

        return grid;
    }

    private void getInfantEntry() {
        CoachPassengerType infantType = null;
        for (CoachPassengerType c : listPassengerTypes) {
            if (c.getName ().equalsIgnoreCase ("INFANT")) {
                infantType = c;
                break;
            }
        }

        final CoachBook4a infantEntryPopup = new CoachBook4a (infantType);

        JKiosk3.getInputPopup ().showInputBox ("Infant On Lap Entry", infantEntryPopup, new InputPopupResult () {
            @Override
            public void onSave() {
                CoachPassenger passInfantOnLap = infantEntryPopup.getCoachPassengerInfant ();
                if (passInfantOnLap != null) {
                    passengerCurrent.setInfant (true);
                    passengerCurrent.setPassengerInfantOnLap (passInfantOnLap);

                    JKiosk3.getInputPopup ().btnsDisable (true, false, true);
                } else {
                    passengerCurrent.setInfant (false);
                    JKiosk3.getInputPopup ().btnsDisable (false, true, false);
                }
            }

            @Override
            public void onOk() {
                System.out.println ("clicked the ok button");
            }

            @Override
            public void onCancel() {
                chkInfOnLap.setSelected (false);
            }
        });
    }

    private HBox getHBoxViewAdd() {
        btnView = JKNode.getBtnPopupDbl ("view list");
        btnView.setDisable (true);
        if (!CoachTicketSale.getInstance ().getListPassengers ().isEmpty ()
                && CoachTicketSale.getInstance ().getListPassengers ().size () == CoachTicketSale.getInstance ().getSeats ()) {
            btnView.setDisable (false);
        }
        btnView.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event t) {
                if (!CoachTicketSale.getInstance ().getListPassengers ().isEmpty ()) {
                    JKiosk3.getMsgBox ().showMsgBox ("Coach Ticket Sale", "Passenger Summary",
                            getPassengerSummary (),
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_CANCEL, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                }

                                @Override
                                public void onCancel() {
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("No Passengers Entered", "Enter Passengers before viewing the list", null);
                }
            }
        });

        btnAdd = JKNode.getBtnPopupDbl ("add passenger");
        GridPane.setHalignment (btnAdd, HPos.RIGHT);
        btnAdd.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event t) {
                if (validatePassengerDetail ()) {
                    CoachTicketSale.getInstance ().getListPassengers ().add (passengerCurrent);
                    addOrEditPassenger (false);
                }
            }
        });

        HBox hbViewAdd = JKLayout.getHBox (0, 0);
        hbViewAdd.getChildren ().addAll (btnView, JKNode.getHSpacer (), btnAdd);

        return hbViewAdd;
    }

    private void addOrEditPassenger(final boolean isEditing) {
        if (!isEditing) {
            btnAdd.setText ("add passenger");
            if ((passengerCount + 1) < seatsTotal) {
                vbFullView.getChildren ().remove (gridPassenger);
                passengerCount++;
                gridPassenger = getGridPassengerEntry (passengerCount, isEditing);
                btnAdd.setDisable (false);
                btnView.setDisable (true);
                nav.getBtnNext ().setDisable (true);
                vbFullView.getChildren ().add (2, gridPassenger);
            } else {
                JKiosk3.getMsgBox ().showMsgBox ("Passenger Entry Complete", "All Passengers have been entered",
                        null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK,
                        new MessageBoxResult () {
                            @Override
                            public void onOk() {
                                vbFullView.getChildren ().remove (gridPassenger);
                                gridPassenger = getGridPassengerEntry (seatsTotal, isEditing);
                                gridPassenger.setDisable (true);
                                btnAdd.setDisable (true);
                                btnView.setDisable (false);
                                nav.getBtnNext ().setDisable (false);
                                vbFullView.getChildren ().add (2, gridPassenger);
                            }

                            @Override
                            public void onCancel() {

                            }
                        });
            }
        } else {
            vbFullView.getChildren ().remove (gridPassenger);
            gridPassenger = getGridPassengerEntry (indexEdit, isEditing);
            btnAdd.setText ("save passenger");
            btnAdd.setDisable (false);
            btnView.setDisable (true);
            nav.getBtnNext ().setDisable (true);
            vbFullView.getChildren ().add (2, gridPassenger);
        }
    }

    private GridPane getPassengerSummary() {
        final List<CoachPassenger> listPassengersView = CoachTicketSale.getInstance ().getListPassengers ();
        Collections.sort (listPassengersView, new Comparator<CoachPassenger> () {
            @Override
            public int compare(CoachPassenger o1, CoachPassenger o2) {
                return o1.getPassengerType ().getName ().compareTo (o2.getPassengerType ().getName ());
            }
        });

        double gridW2 = (MessageBox.getMsgWidth () - ((5 * JKLayout.sp) + (2 * JKLayout.spNum)));

        GridPane grid = JKLayout.getGridPane4Col (gridW2, 0.12, 0.40, 0.30, 0.18, 0, HPos.RIGHT);
        grid.setVgap (JKLayout.sp);
        grid.setStyle ("-fx-padding: 5px;");
        grid.setTranslateX (-(2 * JKLayout.sp));

        int rowCount = 0;

        for (final CoachPassenger b : listPassengersView) {

            Text txtType = JKText.getTxtDk (b.getPassengerTypeCode (), JKText.FONT_B_15);

            if (b.getPassengerType ().getName ().equals ("ADULT") && b.isInfant ()) {
                String plusInf = b.getPassengerTypeCode () + " + " + "I";
                txtType.setText (plusInf);
            }
            Text txtTitle = JKText.getTxtDk (b.getTitle (), JKText.FONT_B_18);
            Text txtName = JKText.getTxtDk (b.getInitials () + " " + b.getLastName (), JKText.FONT_B_18);
            HBox hbName = JKLayout.getHBoxLeft (0, JKLayout.sp);
            hbName.getChildren ().addAll (txtTitle, txtName);
            Text txtCell = JKText.getTxtDk (JKText.getCellNumFormatted (b.getCellNum ()), JKText.FONT_B_18);

            final Button btnEdit = JKNode.getBtnPopup ("edit");
            btnEdit.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event e) {
                    indexEdit = CoachTicketSale.getInstance ().getListPassengers ().indexOf (b);
                    passengerEdit = b;
                    listPassengersView.remove (b);
                    addOrEditPassenger (true);
                    JKiosk3.getMsgBox ().toBack ();
                    JKiosk3.getMsgBox ().setVisible (false);
                }
            });

            Button btnRem = JKNode.getBtnPopup ("remove");
            btnRem.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event e) {
                    listPassengersView.remove (b);
                    passengerCount = CoachTicketSale.getInstance ().getListPassengers ().size () - 1;
                    addOrEditPassenger (false);
                    JKiosk3.getMsgBox ().toBack ();
                    JKiosk3.getMsgBox ().setVisible (false);
                }
            });
            HBox hb = JKLayout.getHBoxLeft (0, JKLayout.sp);
            hb.getChildren ().addAll (btnEdit, btnRem);
            grid.addRow (rowCount, txtType, hbName, txtCell, hb);
            rowCount++;
        }

        return grid;
    }

    private JKioskNav getNav() {
        JKioskNav jkNav = new JKioskNav ();

        jkNav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (CoachTicketSale.getInstance ().isReturnTrip ()) {
                    SceneSales.clearAndChangeContent (new CoachBook2a (CoachUtil.TRIP_RETURN));
                } else {
                    SceneSales.clearAndChangeContent (new CoachBook2a (CoachUtil.TRIP_DEPART));
                }
            }
        });

        jkNav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent (new TicketingMenu ());
            }
        });

        jkNav.getBtnNext ().setDisable (true);
        jkNav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (!CoachTicketSale.getInstance ().getListPassengers ().isEmpty ()) {
                    if (validatePassengerCount ()) {
//                        logSelections();
                        SceneSales.clearAndChangeContent (new CoachBook5 ());
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Passengers", "Please enter Passenger(s)", null);
                }
            }
        });
        return jkNav;
    }

//    private void logSelections() {
//        StringBuilder sb = new StringBuilder("\r\n");
//        sb.append("Passengers entered: ").append("\n");
//        for (CoachPassenger b : CoachTicketSale.getInstance().getListPassengers()) {
//            sb.append(b.getPassengerTypeCode()).append(" : ")
//                    .append(b.getTitle()).append(" ").append(b.getInitials()).append(" ").append(b.getLastName());
//            if (b.getPassengerType().getName().equals("ADULT")) {
//                sb.append(" : has infant on lap? ").append(b.isInfant());
//            }
//            sb.append("\r\n");
//        }
//        sb.append("Emergency Contact : ").append(CoachTicketSale.getInstance().getEmergencyContactName())
//                .append(" - ").append(CoachTicketSale.getInstance().getEmergencyContactNum());
//
//        logger.info(sb.toString());
//    }

    private int getChildAgeInDays(Date dob) {
        long tuNow = new Date ().getTime ();
        long tuDob = dob.getTime ();
        long tuMillisDiff = tuNow - tuDob;

        return (int) TimeUnit.MILLISECONDS.toDays (tuMillisDiff);
    }

    private boolean validateDateOfBirth(String value) {
        if (!value.matches ("[\\d]{2}\\/[\\d]{2}\\/[\\d]{4}")) {
            JKiosk3.getMsgBox ().showMsgBox ("Date of Birth",
                    "Date of Birth must be entered in format 'dd/MM/yyyy'", null);
            return false;
        }

        try {

            passengerDateOfBirth = dateformat.parse (value);
//            int ageMaxChild = passengerCurrent.getPassengerType().getMaxAge() / 12;
            int ageMaxChild = 0;
            for (CoachPassengerType p : listPassengerTypes) {
                if (p.getName ().equals ("CHILD")) {
                    ageMaxChild = p.getMaxAge () / 12;
                    break;
                }
            }

//            if (getChildAgeInDays(passengerDateOfBirth) >= ((12 * 365.25))) {
            if (getChildAgeInDays (passengerDateOfBirth) >= ((ageMaxChild * 365.25))) {
                JKiosk3.getMsgBox ().showMsgBox ("Passenger Age",
                        "\nChildren older than " + ageMaxChild + " years \n\npay full fare.", null);
                return false;
            }

            Date today = dateformat.parse (JKText.getDateDisplay (new Date ()));

            if (passengerDateOfBirth.after (today)) {
                JKiosk3.getMsgBox ().showMsgBox ("Invalid Date", "\nDate of Birth cannot be after today", null);
                return false;
            }

        } catch (ParseException ex) {
            JKiosk3.getMsgBox ().showMsgBox ("Invalid Date Format", "\nPlease enter date in format 'dd/MM/yyyy'", null);
            logger.log (Level.SEVERE, ex.getMessage (), ex);
            return false;
        }
        return true;
    }

    private boolean validateCellNumber(String value) {
        if (!value.matches ("(^0[678][0123456789]((\\d{7})|( |-)((\\d{3}))( |-)(\\d{4})|( |-)(\\d{7})))")) {
            JKiosk3.getMsgBox ().showMsgBox ("Cell or Contact Number", "Please enter a valid Cell or Contact Number", null);
            return false;
        }
        return true;
    }

    private boolean validatePassengerDetail() {
        if (passengerCurrent.getInitials () == null || passengerCurrent.getInitials ().isEmpty ()
                || passengerCurrent.getLastName () == null || passengerCurrent.getLastName ().isEmpty ()
                || passengerCurrent.getCellNum () == null || passengerCurrent.getCellNum ().isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Passenger Details", "Please enter all Passenger Details", null);
            return false;
        }
        if ((passengerCurrent.getPassengerTypeCode ().equals ("C")
                || passengerCurrent.getPassengerTypeCode ().equals ("CHILD")
                || passengerCurrent.getPassengerTypeCode ().equals ("I")
                || passengerCurrent.getPassengerTypeCode ().equals ("INFANT"))
                && passengerCurrent.getDateOfBirth () == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Passenger Details", "Please enter Date of Birth for Child or Infant", null);
            return false;
        }
        return true;
    }

    private boolean validatePassengerCount() {
        // count list and match infants to adults, etc
        List<CoachPassenger> listPass = CoachTicketSale.getInstance ().getListPassengers ();
        int adultCount = 0;
        int infantCount = 0;
        for (CoachPassenger p : listPass) {
            if (p.getPassengerType ().getName ().equals ("ADULT")) {
                adultCount++;
                if (p.isInfant () && p.getPassengerInfantOnLap () != null) {
                    infantCount++;
                }
            }
        }
        final int diff = infantCount - adultCount;

        if (listPass.size () > CoachTicketSale.getInstance ().getSeats ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Passenger Count", "Passenger Count exceeds Seats requested in step 1", null);
            return false;
        }
        if (infantCount > adultCount) {
            JKiosk3.getMsgBox ().showMsgBox ("Infants on Lap Count", "Not more than 1 Infant on lap can be allocated to each Adult",
                    null);

            return false;
        }
        return true;
    }

}
//
// =======================================================

//    private List<CoachListItem> listPassengerTypes;

//        listPassengerTypes = new ArrayList<>();
//        CoachUtil.getCoachPassengerTypeList(new CoachUtil.CoachPassengerTypeListResult() {
//            @Override
//            public void coachPassengerTypeListResult(CoachListItemResp coachPassengerTypeListResult) {
//                if (coachPassengerTypeListResult.isSuccess()) {
//                    String carrierCode = CoachTicketSale.getInstance().getCoachCarrierDepart().getCarrierCode();
//                    for (CoachListItem c : coachPassengerTypeListResult.getListItems()) {
//                        if (c.getCarrierId().equalsIgnoreCase(carrierCode)) {
//                            listPassengerTypes.add(c);
//                        }
//                    }
////                    listPassengerTypes = coachPassengerTypeListResult.getListItems();
//                    seatsTotal = CoachTicketSale.getInstance().getSeats();
////              this.seatsTotal = CoachTicketSale.getInstance().getSeatsAdult()
////                + CoachTicketSale.getInstance().getSeatsChild()
////                + CoachTicketSale.getInstance().getSeatsInfant();
//
//                    nav = getNav();
//
//                    dateformat = new SimpleDateFormat("dd/MM/yyyy");
//
//                    transX = (JKLayout.sp + (JKLayout.sp / 2));
//
//                    VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
//                    vb.getChildren().addAll(showCoachTicketBookStep4(), nav);
//                    getChildren().add(vb);
//                } else {
//                    // no city list, show error
//                    JKiosk3.getMsgBox().showMsgBox("Passenger Type List Error", "Error retrieving Passenger types\n\n"
//                                    + coachPassengerTypeListResult.getErrorCode() + " - " + coachPassengerTypeListResult.getErrorText(), null,
//                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
//                                @Override
//                                public void onOk() {
//                                    SceneSales.clearAndChangeContent(new TicketingMenu());
//                                }
//
//                                @Override
//                                public void onCancel() {
//                                }
//                            });
//                }
//            }
//        });
// // //
//        this.seatsTotal = CoachTicketSale.getInstance().getSeatsAdult()
//                + CoachTicketSale.getInstance().getSeatsChild()
//                + CoachTicketSale.getInstance().getSeatsInfant();

//        vbFullView.getChildren().addAll(vbHead, gridTrip, gridPassenger, hbViewAdd, getGridEmergencyContact());

//        ObservableList passengerTypes = FXCollections.observableArrayList(listPassengerTypes);

//            passengerCurrent.setPassengerType(((CoachListItem) comType.getSelectionModel().getSelectedItem()));

//                passengerCurrent.setPassengerType(((CoachListItem) t1).getCode());

//                passengerCurrent.setPassengerTypeCode((t1.getCode()));
//                        PassengerType type = PassengerType.byName(t1.getName());
//                        switch (type) {
//                        case ADULT:
////                        if (CoachTicketSale.getInstance().getSeatsAdult() > 0) {
//                        vbInfOrDOB.getChildren().clear();
//                        vbInfOrDOB.getChildren().addAll(lblInfOnLap, chkInfOnLap);
////                        } else {
////                            JKiosk3.getMsgBox().showMsgBox("Invalid Value Selected",
////                                    "No Adult seats were selected in Step 1", null);
////                            comType.getSelectionModel().clearSelection();
////                        }
//                        break;
////                    case CHILD:
////                        if (CoachTicketSale.getInstance().getSeatsChild() > 0) {
////                            vbInfOrDOB.getChildren().clear();
////                            vbInfOrDOB.getChildren().addAll(lblDOB, txtDateOfBirth);
////                        } else {
////                            JKiosk3.getMsgBox().showMsgBox("Invalid Value Selected",
////                                    "No Child seats were selected in Step 1", null);
////                            comType.getSelectionModel().clearSelection();
////                        }
////                        break;
//                        case CHILD:
//                        case INFANT:
////                        if (CoachTicketSale.getInstance().getSeatsInfant() > 0) {
//                        vbInfOrDOB.getChildren().clear();
//                        vbInfOrDOB.getChildren().addAll(lblDOB, txtDateOfBirth);
////                        } else {
////                            JKiosk3.getMsgBox().showMsgBox("Invalid Value Selected",
////                                    "No Infant seats were selected in Step 1", null);
////                            comType.getSelectionModel().clearSelection();
////                        }
//                        break;
//default:
//        vbInfOrDOB.getChildren().clear();
//        break;
//        }
//        }
//        });

//            Text txtType = JKText.getTxtDk(b.getPassengerType().getName(), JKText.FONT_B_18);
//            if (b.getPassengerType().equals(PassengerType.ADULT.getCode()) && b.isInfant()) {

//    private boolean validatePassengerDetail() {
//        if (passengerCurrent.getInitials() == null || passengerCurrent.getInitials().isEmpty()
//                || passengerCurrent.getLastName() == null || passengerCurrent.getLastName().isEmpty()
//                || passengerCurrent.getCellNum() == null || passengerCurrent.getCellNum().isEmpty()) {
//            JKiosk3.getMsgBox().showMsgBox("Passenger Details", "Please enter all Passenger Details", null);
//            return false;
//        }
////        if ((passengerCurrent.getPassengerType().getCode().equals("C")
////        || passengerCurrent.getPassengerType().getCode().equals("CHILD"))
//        if ((passengerCurrent.getPassengerTypeCode().equals("C")
//                || passengerCurrent.getPassengerTypeCode().equals("CHILD"))
////                || passengerCurrent.getPassengerType().getCode().equals("I"))
//                && passengerCurrent.getDateOfBirth() == null) {
//            JKiosk3.getMsgBox().showMsgBox("Passenger Details", "Please enter Date of Birth for Child or Infant", null);
//            return false;
//        }
//        return true;
//    }

//    private GridPane getGridEmergencyContact() {
//        Label lblEmergContactName = getPassengerLabel("Emergency Contact Name");
//        Label lblEmergContactNum = getPassengerLabel("Emergency Contact Number");
//
//        final TextField txtEmergContactName = JKNode.getTextField35H();
//        if (CoachTicketSale.getInstance().getEmergencyContactName() != null) {
//            txtEmergContactName.setText(CoachTicketSale.getInstance().getEmergencyContactName());
//        }
//        txtEmergContactName.setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getKeyboard().showKeyboard(txtEmergContactName, "Emergency Contact Name", "", false, true,
//                        new KeyboardResult() {
//                            @Override
//                            public void onDone(String value) {
//                                CoachTicketSale.getInstance().setEmergencyContactName(value);
//                            }
//                        });
//            }
//        });
//        VBox vbEmergName = getPassengerVBox(lblEmergContactName, txtEmergContactName);
//
//        final TextField txtEmergContactNum = JKNode.getTextField35H();
//        if (CoachTicketSale.getInstance().getEmergencyContactNum() != null) {
//            txtEmergContactNum.setText(JKText.getCellNumFormatted(CoachTicketSale.getInstance().getEmergencyContactNum()));
//        }
//        txtEmergContactNum.setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getNumPad().showNumPad(txtEmergContactNum, "Emergency Contact", "",
//                        new NumberPadResult() {
//                            @Override
//                            public void onDone(String value) {
//                                if (validateCellNumber(value)) {
//                                    CoachTicketSale.getInstance().setEmergencyContactNum(value);
//                                    txtEmergContactNum.setText(JKText.getCellNumFormatted(value));
//                                } else {
//                                    txtEmergContactNum.clear();
//                                }
//                            }
//                        });
//            }
//        });
//        VBox vbEmergNum = getPassengerVBox(lblEmergContactNum, txtEmergContactNum);
//
//        GridPane grid = JKLayout.getGridPane4Col(gridCoach, 0.25, 0.25, 0.25, 0.25, 1, HPos.LEFT);
//        grid.setVgap(JKLayout.sp);
//        grid.setTranslateX(-22);    // can't get this to fit in with anything, measured the space
//        grid.setTranslateX(-transX);    // can't get this to fit in with anything, measured the space
//
//        grid.addRow(0, JKNode.createGridSpanSep(4));
//        grid.add(vbEmergName, 0, 1, 2, 1);
//        grid.add(vbEmergNum, 2, 1, 2, 1);
//
//        return grid;
//    }

//    private boolean validateAllInput() {
//        int countAdult = 0;
//        int countChild = 0;
//        int countInfant = 0;
//        for (CoachPassenger b : CoachTicketSale.getInstance().getListPassengers()) {
//            if (b.getPassengerType().equals(PassengerType.ADULT.getCode())) {
//                countAdult++;
//            } else if (b.getPassengerType().equals(PassengerType.CHILD.getCode())) {
//                countChild++;
//            } else if (b.getPassengerType().equals(PassengerType.INFANT.getCode())) {
//                countInfant++;
//            }
//        }
//        if (countAdult != CoachTicketSale.getInstance().getSeatsAdult()) {
//            JKiosk3.getMsgBox().showMsgBox("Seats Requested", "Adult Passengers entered does not match Seats requested" +
//                    "\n\nAdult Seats requested : " + CoachTicketSale.getInstance().getSeatsAdult() +
//                    "\n\nAdult passengers entered : " + countAdult, null);
//            return false;
//        }
//        if (countChild != CoachTicketSale.getInstance().getSeatsChild()) {
//            JKiosk3.getMsgBox().showMsgBox("Seats Requested", "Child Passengers entered does not match Seats requested" +
//                    "\n\nChild Seats requested : " + CoachTicketSale.getInstance().getSeatsChild() +
//                    "\n\nChild passengers entered : " + countChild, null);
//            return false;
//        }
//        if (countInfant != CoachTicketSale.getInstance().getSeatsInfant()) {
//            JKiosk3.getMsgBox().showMsgBox("Seats Requested", "Infant Passengers entered does not match Seats requested" +
//                    "\n\nInfant Seats requested : " + CoachTicketSale.getInstance().getSeatsInfant() +
//                    "\n\nInfant passengers entered : " + countInfant, null);
//            return false;
//        }
//        if (CoachTicketSale.getInstance().getEmergencyContactName() == null || CoachTicketSale.getInstance().getEmergencyContactName().isEmpty()
//                || CoachTicketSale.getInstance().getEmergencyContactNum() == null || CoachTicketSale.getInstance().getEmergencyContactNum().isEmpty()) {
//            JKiosk3.getMsgBox().showMsgBox("Emergency Contact Details", "Please enter Emergency Contact Details", null);
//            return false;
//        }
//        return true;
//    }
