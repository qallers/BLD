package jkiosk3.sales.billpay._common;

import java.util.List;
import java.util.Locale;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.sales._favourites.nfc.NFCSubscriberFavourites;
import jkiosk3.sales._favourites.nfc.NFCUtilFav;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilMisc;

public class BillPayEntry extends Region {

    public final static String TYPE_ACCOUNT = "Account Number";
    public final static String TYPE_INS_POLICY = "Policy Number";
    public final static String TYPE_TRAFFIC_FINE = "Traffic Fine Notice Number";
    //
    private final String strHeader;
    private final ImageView img;
    private final BillPayProduct product;
    private final String productType;
    private String strPrompt;
    private String strPrompt2;
    private String strDetailToDisplay = "";
    private TextField txtNumber;
    private TextField txtNumber2;
    private ComboBox cbNumber;
    private String entry1;
    private String entry2;
    private String accountNumberConfirmed;
    private Button btnDetail;
    private boolean showFavourites;
    private boolean showProductFavourite;
    private boolean showDblCapture;
    private double inputW;
    //
    private VBox vbHead;
    private GridPane gridEnter;

    public BillPayEntry(String strHeader, ImageView img, BillPayProduct product, String productType, boolean isNFCFavourite, boolean isProductFavourite) {
        this.strHeader = strHeader;
        this.img = img;
        this.product = product;
        this.productType = productType;
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;
        this.inputW = ((JKLayout.contentW - (3 * JKLayout.sp)) / 2);

        switch (product.getProvName()) {
            case BillPayUtilMisc.PAYAT_BILL_PAY:
            case BillPayUtilMisc.PAYAT_INSURANCE:
            case BillPayUtilMisc.PAYAT_TRAFFIC_FINES:
                this.showDblCapture = false;
                break;
            default:
                this.showDblCapture = true;
                break;
        }
        System.out.println("show double capture for this product: " + showDblCapture);

        getSwitchTexts();
//        checkAccNumFav();

        if (showFavourites) {
            if (!NFCUtilFav.getBillPayAccNumsFav(product).isEmpty()) {
                checkAccNumFav();
                getChildren().add(getPageLayout());
            } else {
                JKiosk3.getMsgBox().showMsgBox("Account Numbers", "No Account Numbers saved for this item", null);
                SceneSales.clearAndChangeContent(new NFCSubscriberFavourites(ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile()));
            }
        } else {
            getChildren().add(getPageLayout());
        }

//        getChildren().add(getPageLayout());
    }


    private void getSwitchTexts() {
        switch (productType) {
            case TYPE_ACCOUNT:
                strPrompt = "Enter Account Number";
                strPrompt2 = "Re-enter Account Number";
                strDetailToDisplay = "Customer Name";
                break;
            case TYPE_INS_POLICY:
                strPrompt = "Enter Policy Number";
                strPrompt2 = "Re-enter Policy Number";
                strDetailToDisplay = "Policy Holder";
                break;
            case TYPE_TRAFFIC_FINE:
                strPrompt = "Enter Notice Number";
                strPrompt2 = "Re-enter Notice Number";
                strDetailToDisplay = "Vehicle Registration";
                break;
            default:
                strPrompt = "Enter Number";
                strPrompt2 = "Re-enter Number";
                strDetailToDisplay = "Name";
        }
    }

    private VBox getPageLayout() {
        vbHead = JKLayout.getVBox(0, JKLayout.sp);
        vbHead.getChildren().add(getHeaderLayout());
        vbHead.getChildren().add(getNumberEntry());

        return vbHead;
    }

    private void checkAccNumFav() {
        if (!NFCUtilFav.getBillPayAccNumsFav(product).isEmpty()) {
            List<String> listAccNums = NFCUtilFav.getBillPayAccNumsFav(product);
            cbNumber = new ComboBox();
            cbNumber.setMaxWidth(inputW);
            cbNumber.setMinWidth(inputW);
            cbNumber.setEditable(true);
            cbNumber.setItems(FXCollections.observableArrayList(listAccNums));
            cbNumber.getEditor().setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event event) {
                    JKiosk3.getNumPad().showNumPad(cbNumber.getEditor(), "Account Number", "", new NumberPadResult() {
                        @Override
                        public void onDone(String value) {
//                            accountNumberConfirmed = value;
                            txtNumber.setText(value.toUpperCase(Locale.ENGLISH));
                            // set value of first entry and clear text from field
                            if (!value.trim().equals("")) {
                                entry1 = value.trim();
                                txtNumber2.setDisable(false);
                            } else {
                                JKiosk3.getMsgBox().showMsgBox(productType, productType + " cannot be empty", null);
                                txtNumber2.setDisable(true);
                            }
                        }
                    });
                }
            });
            cbNumber.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue observable, String oldValue, String newValue) {
                    accountNumberConfirmed = newValue;
                    txtNumber.setText(accountNumberConfirmed);
                    txtNumber2.setText(accountNumberConfirmed);
                    System.out.println("accountNumberConfirmed = " + accountNumberConfirmed);
                    btnDetail.setDisable(false);
                }
            });
        }
    }

    private GridPane getHeaderLayout() {
        Label lblAccountPayment = JKText.getLblContentHead(strHeader);

        Label lblProdName;
        if (product != null) {
            lblProdName = JKText.getLblDk(product.getProdName(), JKText.FONT_B_XSM);
        } else {
            lblProdName = JKText.getLblDk("M2M", JKText.FONT_B_XSM);
        }

        HBox hbProv = JKLayout.getHBoxLeft(0, JKLayout.sp);
        hbProv.setPrefWidth(JKLayout.contentW - (2 * JKLayout.sideW));
        hbProv.getChildren().addAll(img, lblProdName);

        GridPane gridHead = JKLayout.getContentGridInner2Col(0.5, 0.5);
        gridHead.add(lblAccountPayment, 0, 0, 2, 1);
        gridHead.add(hbProv, 0, 1, 2, 1);
        gridHead.addRow(2, JKNode.createGridSpanSep(2));

        return gridHead;
    }

    private GridPane getNumberEntry() {

        Label lblPaymentType = JKText.getLblDk(productType, JKText.FONT_B_XSM);

        txtNumber = new TextField();
        txtNumber.setMaxWidth(inputW);
        txtNumber.setMinWidth(inputW);
        txtNumber.setPromptText(strPrompt);
        txtNumber.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getKeyboard().showKeyboard(txtNumber, strPrompt, "", false, false, new KeyboardResult() {

                    @Override
                    public void onDone(String value) {
                        txtNumber.setText(value.toUpperCase(Locale.ENGLISH));
                        // set value of first entry and clear text from field
                        if (!value.trim().equals("")) {
                            entry1 = value.trim();
                            txtNumber2.setDisable(false);
                        } else {
                            JKiosk3.getMsgBox().showMsgBox(productType, productType + " cannot be empty", null);
                            txtNumber2.setDisable(true);
                        }
                        if (!showDblCapture) {
                            // fill in details for second field and continue
                            txtNumber2.setText(value.toUpperCase(Locale.ENGLISH));
                            if (!txtNumber2.getText().trim().equals("")) {
                                entry2 = value.trim();
                                checkEnteredDetails();
                            }
                        }
                        //
                        // below - pre-CR-2155 (Remove double capture)
//                            // set value of first entry and clear text from field
//                            if (!value.trim().equals("")) {
//                                entry1 = value.trim();
//                                txtNumber2.setDisable(false);
//                            } else {
//                                JKiosk3.getMsgBox().showMsgBox(productType, productType + " cannot be empty", null);
//                                txtNumber2.setDisable(true);
//                            }
                    }
                });
//                }
            }
        });

        txtNumber2 = new TextField();
        txtNumber2.setMaxWidth(inputW);
        txtNumber2.setMinWidth(inputW);
        txtNumber2.setPromptText(strPrompt2);
        txtNumber2.setDisable(true);
        txtNumber2.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                txtNumber.setVisible(false);
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getKeyboard().showKeyboard(txtNumber2, strPrompt, "", false, false, new KeyboardResult() {

                    @Override
                    public void onDone(String value) {
                        txtNumber2.setText(value.toUpperCase(Locale.ENGLISH));
                        if (!value.trim().equals("")) {
                            entry2 = value.trim();
                            checkEnteredDetails();
                        } else {
                            JKiosk3.getMsgBox().showMsgBox(productType, productType + " cannot be empty", null);
                            txtNumber2.setDisable(false);
                            btnDetail.setDisable(true);
                        }
                    }
                });
//                }
            }
        });

        btnDetail = JKNode.getBtnMsgBox("show detail");
        btnDetail.setDisable(true);

        gridEnter = JKLayout.getContentGridInner2Col(0.5, 0.5, HPos.RIGHT);

        if (showFavourites) {
            gridEnter.addRow(0, lblPaymentType, cbNumber);
        } else if (showProductFavourite) {
            gridEnter.addRow(0, lblPaymentType, txtNumber);
        } else {
            gridEnter.addRow(0, lblPaymentType, txtNumber);
        }
        if (showDblCapture) {
            gridEnter.addRow(1, new Label(""), txtNumber2);
        }
//        gridEnter.addRow(1, new Label(""), txtNumber2);
        gridEnter.add(btnDetail, 1, 2);
        gridEnter.addRow(3, JKNode.createGridSpanSep(2));

        return gridEnter;
    }

    private void checkEnteredDetails() {
        if (entry2.equals(entry1)) {
            accountNumberConfirmed = entry1.toUpperCase(Locale.ENGLISH);
            if (inputValidAccount()) {
                txtNumber.setVisible(true);
                txtNumber.setDisable(true);
                txtNumber2.setDisable(true);
                btnDetail.setDisable(false);
            }
        } else {
            accountNumberConfirmed = null;
            JKiosk3.getMsgBox().showMsgBox("Account Numbers entered do not match", entry1 + " - " + entry2, null);
            txtNumber.setVisible(true);
            txtNumber.setText("");
            txtNumber.setPromptText(strPrompt);
            txtNumber2.setText("");
            txtNumber2.setPromptText(strPrompt2);
            txtNumber2.setDisable(true);
            btnDetail.setDisable(true);
        }
    }

    private GridPane getDetailDisplay(String field1, String field2, String field3) {

        Label lblField1 = JKText.getLblDk(productType, JKText.FONT_B_XSM);
        Text txtAccNum = JKText.getTxtDk(field1, JKText.FONT_B_XSM);
        Label lblField2 = JKText.getLblDk(strDetailToDisplay, JKText.FONT_B_XSM);
        Text txtCustomer = JKText.getTxtDk(field2, JKText.FONT_B_XSM);
        txtCustomer.setWrappingWidth((JKLayout.contentW - (2 * JKLayout.sp)) * 0.5);
        txtCustomer.setTextAlignment(TextAlignment.RIGHT);

        GridPane gridDetail = JKLayout.getContentGridInner2Col(0.5, 0.5, HPos.RIGHT);
        gridDetail.addRow(0, lblField1, txtAccNum);
        gridDetail.addRow(1, lblField2, txtCustomer);
        gridDetail.addRow(2, JKNode.createGridSpanSep(2));

        return gridDetail;
    }

    private boolean inputValidAccount() {
        if (accountNumberConfirmed.equals("") || accountNumberConfirmed.isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox(productType, productType + " cannot be empty", null);
            return false;
        }
        return true;
    }

    public VBox getVbHead() {
        return vbHead;
    }

    public GridPane getGridEnter() {
        return gridEnter;
    }

    public GridPane getGridDetail(String field1, String field2) {
        return getDetailDisplay(field1, field2, null);
    }

    public GridPane getGridDetail(String field1, String field2, String field3) {
        return getDetailDisplay(field1, field2, field3);
    }

    public TextField getTxtNumber() {
        return txtNumber;
    }

    public Button getBtnDetail() {
        return btnDetail;
    }

    public String getAccountNumberConfirmed() {
        return accountNumberConfirmed;
    }

}
