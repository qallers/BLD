package jkiosk3.sales._tender;

import aeonprinting.AeonPrintJob;
import aeonprinting.AeonPrintLine;
import aeontender.Item;
import aeontender.TenderConnection;
import aeontender.TenderType;
import aeontender.TenderTypeResponse;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.concurrent.Task;
import javafx.concurrent.Worker.State;
import jkiosk3.JKiosk3;
import jkiosk3.printing.print_layouts.PrintAssorted;
import jkiosk3.sales._common.SummaryTableView;
import jkiosk3.store.JKSystem;
import jkiosk3.store.JKTenders;
import jkiosk3.store.StoreJKTenders;
import jkiosk3.users.CurrentUser;

public class TenderUtil {

    private final static Logger logger = Logger.getLogger(TenderUtil.class.getName());
    private static TenderType tenderTypes;
    private static StoreJKTenders updateTenders;
    private static String errorMsg = "An unknown error occurred";

    private static TenderConnection getTenderConnect() {
        TenderConnection tendConn = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();

        try {
            tendConn = new TenderConnection(server, port, secureConnect);
            tendConn.setTimeout(60);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return tendConn;
    }

    private static TenderTypeResponse submitTenderSummary(TenderType tender) throws RuntimeException {
        TenderTypeResponse tenderResponse = new TenderTypeResponse();
        /* This is needed for printing Sales Receipt. */
        tenderTypes = tender;

        TenderConnection tc = getTenderConnect();
        String userPin = "";
        int deviceId = JKSystem.getSystemConfig().getDeviceId();
        String serial = JKSystem.getSystemConfig().getSerial();
        if (CurrentUser.getSalesUser() != null) {
            userPin = CurrentUser.getSalesUser().getUserPin();
        } else {
            userPin = CurrentUser.getUser().getUserPin();
        }
        StringBuilder sb = new StringBuilder("\r\n");
        sb.append("\t > > > > > NUMBER OF ITEMS IN BASKET > > > > > : ").append(SummaryTableView.getSummaryRows().size()).append("\r\n");
        sb.append("\t - - - - - - - - - - - - - - - - - - - - - - - - - - ");
        sb.append("\tTender submit by (PIN) : ").append(userPin).append("\r\n");
        sb.append("\t\tCash        : ").append(tender.getCash()).append("\r\n");
        sb.append("\t\tCheque      : ").append(tender.getCheque()).append("\r\n");
        sb.append("\t\tCredit Card : ").append(tender.getCreditcard()).append("\r\n");
        sb.append("\t\tDebit Card  : ").append(tender.getDebitcard()).append("\r\n");
        sb.append("\t\tOther       : ").append(tender.getOther()).append("\r\n");
        sb.append("\t\tChange      : ").append(tender.getChange()).append("\r\n");
        sb.append("\t\tSale Total  : ").append(tender.getTotal()).append("\r\n");
        for (Item i : tender.getItemList()) {
            sb.append("\t\tRef : ").append(i.getTransRef()).append("\r\n");
        }
        sb.append("\t- - - - - - - - - - - - - - - - - -").append("\r\n");
        try {
            if (tc.login(userPin, deviceId, serial)) {
                tenderResponse = tc.getTenderTypeResponse(tender);
                sb.append("Tender submit response : ").append(tenderResponse.isSuccess());
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Tender Submit Error", t);
        } finally {
            if (tc != null) {
                tc.disconnect();
            }
        }
        logger.info(sb.toString());
        return tenderResponse;
    }

//    public static void processUnsubmittedTenders() {
//        updateTenders = new StoreJKTenders();
//        List<String> listRefs = new ArrayList<>();
//        for (final TenderType tt : JKTenders.getJkTenders().getListTenderTypes()) {
//            listRefs.add(tt.getReference());
//        }
//        submitUnprocessedTenders(0, listRefs);
//    }

//    private static void submitUnprocessedTenders(int count, List<String> listRefs) {
//        String currentRef = listRefs.get(count);
//        for (TenderType tt : JKTenders.getJkTenders().getListTenderTypes()) {
//            if (tt.getReference().equalsIgnoreCase(currentRef)) {
//                submitTender(count, listRefs, tt);
//                break;
//            }
//        }
//    }

//    private static void submitTender(final int count, final List<String> listRefs, final TenderType tender) {
//        TenderUtil.submitTenderSummary(tender, false, new TenderSubmitResult() {
//
//            @Override
//            public void tenderSubmitResult(TenderTypeResponse tenderResponse) {
//                if (tenderResponse != null) {
//                    if (tenderResponse.isSuccess()) {
//                        logger.info(("Tender was submitted successfully - ").concat(Double.toString(tender.getTotal())));
//                        // Nothing to do  -  business as usual.
//                    } else {
//                        updateTenders.getListTenderTypes().add(tender);
//                        String msg = tenderResponse.getErrorCode() + " - " + tenderResponse.getErrorText();
//                        logger.info(("Error - ").concat(msg));
//                    }
//                } else {
//                    updateTenders.getListTenderTypes().add(tender);
//                }
//                //
//                // continue submitting through list, or move on to save any failed items
//                if ((count + 1) < JKTenders.getJkTenders().getListTenderTypes().size()) {
//                    submitUnprocessedTenders((count + 1), listRefs);
//                } else {
//                    updateOrClearUnsubmittedTenders();
//                }
//            }
//        });
//    }

//    private static void updateOrClearUnsubmittedTenders() {
//        if (!updateTenders.getListTenderTypes().isEmpty()) {
//            JKTenders.clearAndSaveTenders(updateTenders);
//            logger.info(("Size of outstanding tender list : ").concat(Integer.toString(updateTenders.getListTenderTypes().size())));
//        } else {
//            JKTenders.clearTendersList();
//            logger.info(("Outstanding tender list is empty"));
//        }
//    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void submitTenderSummary(final TenderType tender, final boolean showChange, final TenderSubmitResult result) {
        JKiosk3.getBusy().showBusy("Submitting Tender");

        final Task<TenderTypeResponse> taskTender = new Task<TenderTypeResponse>() {
            @Override
            protected TenderTypeResponse call() throws Exception {
                return submitTenderSummary(tender);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tenderSubmitResult(getValue());
            }

            @Override
            protected void cancelled() {
                JKiosk3.getBusy().hideBusy();
                JKiosk3.getPayTender().clearAndHidePaymentTender();
                onTaskSubmitCancelledFailed(tender, result, State.CANCELLED, this);
            }

            @Override
            protected void failed() {
                JKiosk3.getBusy().hideBusy();
                JKiosk3.getPayTender().clearAndHidePaymentTender();
                onTaskSubmitCancelledFailed(tender, result, State.FAILED, this);
            }
        };
        new Thread(taskTender).start();
        JKiosk3.getBusy().startCountdown(taskTender, 60);
    }

    private static void onTaskSubmitCancelledFailed(final TenderType tender, final TenderSubmitResult result, State newState, final Task task) {
        String msgadd = "\n\nPlease check your network connection";
        String msgReason = "Error Processing Tender Submit" + "\n\n" + newState + "\n\n";
        JKiosk3.getBusy().hideBusy();
        if (newState == State.CANCELLED) {
            msgReason += "Operation timed out" + msgadd;
        } else if (newState == State.FAILED) {
            msgReason += errorMsg + msgadd;
        }
        AeonPrintJob apj = PrintAssorted.getPrintTenderSubmitFail(tender);
        /* DO NOT REMOVE this logging here. */
        /* It is needed to prevent (potential) fraud. */
        /* Refer: Leo Anwanth */
        /* --- */
        /* 2016-06-30  -  This solution was subsequently rejected. */
        /* BUT  -  this is just log output, so I am keeping it here so that it can be traced if needed. */
        logger.info(msgReason);
        logger.info("  ============ TENDER SUBMIT FAILURE RECORD ============ ");
        StringBuilder sb = new StringBuilder();
        for (AeonPrintLine line : apj.getLines()) {
            sb.append("\t\t").append(line.getLine()).append("\r\n");
        }
        logger.info(sb.toString());
        logger.info("  ====================================================== ");
        result.tenderSubmitResult((TenderTypeResponse) task.getValue());
    }

    public abstract static class TenderSubmitResult {

        public abstract void tenderSubmitResult(TenderTypeResponse tenderResponse);
    }

    public static TenderType getTenderTypes() {
        return tenderTypes;
    }
}
