package jkiosk3.setup;

import java.util.ArrayList;
import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

public class SetupPrintersMenu extends Region {

    private final static String MENU_PRINT_DEFAULT = "Default Printer";
    private final static String MENU_PRINT_TICKET = "Ticket Printer";

    public SetupPrintersMenu() {
        getChildren().add(getMenuGroup());
    }

    private HBox getMenuGroup() {

        List<String> btnLabelsPrint = new ArrayList<>();
        btnLabelsPrint.add(MENU_PRINT_DEFAULT);
        btnLabelsPrint.add(MENU_PRINT_TICKET);

        List<Button> btnList = new ArrayList<>();

        for (String s : btnLabelsPrint) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setStyle(SceneSetup.SETUP_BTN_STYLE);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        HBox hb = JKLayout.getControlsHBox();
        hb.setAlignment(Pos.CENTER_LEFT);
        hb.getChildren().addAll(btnList);
        hb.getChildren().add(JKNode.getHSpacer());

        return hb;
    }

    private void getMenuAction(Button b) {
        if (SceneSetup.getVbSetupContent().getChildren().size() > 1) {
            SceneSetup.getVbSetupContent().getChildren().remove(1);
        }

        switch (b.getText()) {
            case MENU_PRINT_DEFAULT:
                SceneSetup.getVbSetupContent().getChildren().add(1, new SetupPrinter());
                break;
            case MENU_PRINT_TICKET:
                SceneSetup.getVbSetupContent().getChildren().add(1, new SetupPrinterTickets());
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Printers Menu", "Printer Option Not Selected!", null);
        }
    }
}
