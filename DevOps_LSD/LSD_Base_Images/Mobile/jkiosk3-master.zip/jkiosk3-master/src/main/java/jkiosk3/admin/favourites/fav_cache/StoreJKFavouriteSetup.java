package jkiosk3.admin.favourites.fav_cache;

import java.io.Serializable;

public class StoreJKFavouriteSetup implements Serializable {

    private final static long serialVersionUID = 10142L;

    public final static String FAVOURITE_DEFAULT = "Default";
    public final static String FAVOURITE_CUSTOM = "Custom";
    //
    private boolean useDefaultFavourites = true;
    private boolean showVouchers = true;
    private boolean showElectricity = true;
    private boolean showBillPayments = true;
    private int countVouchers = 4;
    private int countElectricity = 2;
    private int countBillPayments = 4;

    public boolean isUseDefaultFavourites() {
        return useDefaultFavourites;
    }

    public void setUseDefaultFavourites(boolean useDefaultFavourites) {
        this.useDefaultFavourites = useDefaultFavourites;
    }

    public boolean isShowVouchers() {
        return showVouchers;
    }

    public void setShowVouchers(boolean showVouchers) {
        this.showVouchers = showVouchers;
    }

    public boolean isShowElectricity() {
        return showElectricity;
    }

    public void setShowElectricity(boolean showElectricity) {
        this.showElectricity = showElectricity;
    }

    public boolean isShowBillPayments() {
        return showBillPayments;
    }

    public void setShowBillPayments(boolean showBillPayments) {
        this.showBillPayments = showBillPayments;
    }

    public int getCountVouchers() {
        return countVouchers;
    }

    public void setCountVouchers(int countVouchers) {
        this.countVouchers = countVouchers;
    }

    public int getCountElectricity() {
        return countElectricity;
    }

    public void setCountElectricity(int countElectricity) {
        this.countElectricity = countElectricity;
    }

    public int getCountBillPayments() {
        return countBillPayments;
    }

    public void setCountBillPayments(int countBillPayments) {
        this.countBillPayments = countBillPayments;
    }

    @Override
    public String toString() {
        if (isUseDefaultFavourites()) {
            return FAVOURITE_DEFAULT;
        } else {
            return FAVOURITE_CUSTOM;
        }
    }
}
