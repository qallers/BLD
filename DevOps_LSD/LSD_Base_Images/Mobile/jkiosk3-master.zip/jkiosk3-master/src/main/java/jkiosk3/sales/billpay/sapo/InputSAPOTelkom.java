package jkiosk3.sales.billpay.sapo;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales._favourites.nfc.NFCUtilFav;
import jkiosk3.sales.billpay.BillPayProduct;

public class InputSAPOTelkom extends Region {

    private final static Logger logger = Logger.getLogger(InputSAPOTelkom.class.getName());

    private BillPayProduct product;
    private TextField txtBarcode;
    private ComboBox cbNumber;
    private TextField txtGroupNo;
    private TextField txtGroupNo2;
    private TextField txtSystemNo;
    private TextField txtSystemNo2;
    private TextField txtPaymentCode;
    private TextField txtPaymentCode2;
    private TextField txtControlCode;
    private TextField txtControlCode2;
    private TextField txtAmountTel;
    private String groupNum;
    private String systemNum;
    private String paymentCode;
    private String controlCode;
    private double amountTel;
    private String accountNum;
    private String accountStr;
    private String additionalString;
    private boolean showFavourites;
    private boolean showProductFavourite;

    public InputSAPOTelkom(BillPayProduct product, boolean isNFCFavourite, boolean isProductFavourite) {
        this.product = product;
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;

        getChildren().add(getTelkomEntryGrid());
    }

    private void checkAccNumFav() {
        if (!NFCUtilFav.getBillPayAccNumsFav(product).isEmpty()) {
            List<String> listAccNums = new ArrayList<>();
            List<String> listAccTmp = NFCUtilFav.getBillPayAccNumsFav(product);
            for (String s : listAccTmp) {
                String strEdit = s.replaceAll("-", "");
                listAccNums.add(strEdit);
            }
            double inputW = (2 * (JKLayout.contentW - (3 * JKLayout.sp)) * 0.33);
            cbNumber = new ComboBox();
            GridPane.setColumnSpan(cbNumber, 2);
            cbNumber.setMaxWidth(inputW);
            cbNumber.setMinWidth(inputW);
            cbNumber.setEditable(true);
            cbNumber.setItems(FXCollections.observableArrayList(listAccNums));
            cbNumber.getEditor().setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event event) {
                    JKiosk3.getNumPad().showNumPad(cbNumber.getEditor(), "Barcode", "", new NumberPadResult() {
                        @Override
                        public void onDone(String value) {
                            if (value.trim().matches("\\d{32}")) {
                                logger.info(("Eskom barcode scanned - ").concat(value));
                                setBarcodeValues(value);
                            } else {
                                txtBarcode.setText("");
                                JKiosk3.getMsgBox().showMsgBox("Invalid Barcode", "Please try scanning Barcode again,\n\nor enter values below manually", null);
                            }
                        }
                    });
                }
            });
            cbNumber.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue observable, String oldValue, String newValue) {
                    setBarcodeValues(newValue);
                }
            });
        }
    }

    private GridPane getTelkomEntryGrid() {

        Label lblBarcode = JKText.getLblDk("Barcode", JKText.FONT_B_XSM);
        Label lblGroupNo = JKText.getLblDk("Group Number", JKText.FONT_B_XSM);
        Label lblSystemNo = JKText.getLblDk("System Number", JKText.FONT_B_XSM);
        Label lblPaymentCode = JKText.getLblDk("Payment Code", JKText.FONT_B_XSM);
        Label lblControlCode = JKText.getLblDk("Control Code", JKText.FONT_B_XSM);
        Label lblAmountTel = JKText.getLblDk("Amount Due", JKText.FONT_B_XSM);

        txtBarcode = new TextField();
        txtBarcode.setPromptText("Scan Barcode");
        GridPane.setColumnSpan(txtBarcode, 2);
        txtBarcode.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtBarcode, "Barcode", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (value.trim().matches("\\d{32}")) {
                            logger.info(("Telkom barcode scanned - ").concat(value));
                            setBarcodeValues(value);
                        } else {
                            txtBarcode.setText("");
                            JKiosk3.getMsgBox().showMsgBox("Barcode", "Please try scanning Barcode again,\n\nor enter values below manually", null);
                        }
                    }
                });
//                }
            }
        });

        txtGroupNo = new TextField();
        txtGroupNo.setPromptText("Enter Group Number");
        txtGroupNo.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtGroupNo, "Group Number", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (!value.trim().equals("")) {
                            if (!value.matches("\\d{5}")) {
                                txtGroupNo.setText("");
                                JKiosk3.getMsgBox().showMsgBox("Group Number", "Group Number must be 5 digits", null);
                            }
                        } else {
                            JKiosk3.getMsgBox().showMsgBox("Group Number", "Group Number cannot be empty", null);
                        }
                    }
                });
//                }
            }
        });

        txtGroupNo2 = new TextField();
        txtGroupNo2.setPromptText("Re-enter Group Number");
        txtGroupNo2.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtGroupNo2, "Group Number", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (!value.trim().equals(txtGroupNo.getText())) {
                            txtGroupNo.setText("");
                            txtGroupNo2.setText("");
                            JKiosk3.getMsgBox().showMsgBox("Group Number", "Group Numbers entered do not match", null);
                        }
                    }
                });
//                }
            }
        });

        txtSystemNo = new TextField();
        txtSystemNo.setPromptText("Enter System Number");
        txtSystemNo.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtSystemNo, "System Number", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (!value.matches("\\d{10}")) {
                            txtSystemNo.setText("");
                            JKiosk3.getMsgBox().showMsgBox("System Number", "System Number must be 10 digits", null);
                        }
                    }
                });
//                }
            }
        });

        txtSystemNo2 = new TextField();
        txtSystemNo2.setPromptText("Re-enter System Number");
        txtSystemNo2.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtSystemNo2, "System Number", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (!value.trim().equals(txtSystemNo.getText())) {
                            txtSystemNo.setText("");
                            txtSystemNo2.setText("");
                            JKiosk3.getMsgBox().showMsgBox("System Number", "System Numbers entered do not match", null);
                        }
                    }
                });
//                }
            }
        });

        txtPaymentCode = new TextField();
        txtPaymentCode.setPromptText("Enter Payment Code");
        txtPaymentCode.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtPaymentCode, "Payment Code", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (!value.matches("\\d{4}")) {
                            txtPaymentCode.setText("");
                            JKiosk3.getMsgBox().showMsgBox("Payment Code", "Payment Code must be 4 digits", null);
                        }
                    }
                });
//                }
            }
        });

        txtPaymentCode2 = new TextField();
        txtPaymentCode2.setPromptText("Re-enter Payment Code");
        txtPaymentCode2.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtPaymentCode2, "Payment Code", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (!value.trim().equals(txtPaymentCode.getText())) {
                            txtPaymentCode.setText("");
                            txtPaymentCode2.setText("");
                            JKiosk3.getMsgBox().showMsgBox("Payment Code", "Payment Codes entered do not match", null);
                        }
                    }
                });
//                }
            }
        });

        txtControlCode = new TextField();
        txtControlCode.setPromptText("Enter Control Code");
        txtControlCode.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtControlCode, "Control Code", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (!value.matches("\\d{3}")) {
                            txtControlCode.setText("");
                            JKiosk3.getMsgBox().showMsgBox("Control Code", "Control Code must be 3 digits", null);
                        }
                    }
                });
//                }
            }
        });

        txtControlCode2 = new TextField();
        txtControlCode2.setPromptText("Re-enter Control Code");
        txtControlCode2.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtControlCode2, "Control Code", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (!value.trim().equals(txtControlCode.getText())) {
                            txtControlCode.setText("");
                            txtControlCode2.setText("");
                            JKiosk3.getMsgBox().showMsgBox("Control Code", "Control Codes entered do not match", null);
                        }
                    }
                });
//                }
            }
        });

        txtAmountTel = new TextField();
        txtAmountTel.setPromptText("Enter Amount Due");
        txtAmountTel.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtAmountTel, "Enter Amount Due", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        amountTel = SalesUtil.getAmountAsDouble(value, txtAmountTel);
                        txtAmountTel.setText(JKText.getDeciFormat(amountTel));
                    }
                });
//                }
            }
        });

        checkAccNumFav();

        GridPane gridTel = JKLayout.getGridPane3Col(0.33, 0.33, 0.33);

        if (showFavourites) {
            gridTel.addRow(1, lblBarcode, cbNumber);
        } else if (showProductFavourite) {
            gridTel.addRow(1, lblBarcode, txtBarcode);
        } else {
            gridTel.addRow(1, lblBarcode, txtBarcode);
        }

//        gridTel.addRow(1, lblBarcode, txtBarcode);
        gridTel.addRow(3, lblGroupNo, txtGroupNo, txtGroupNo2);
        gridTel.addRow(4, lblSystemNo, txtSystemNo, txtSystemNo2);
        gridTel.addRow(5, lblPaymentCode, txtPaymentCode, txtPaymentCode2);
        gridTel.addRow(6, lblControlCode, txtControlCode, txtControlCode2);
        gridTel.addRow(8, lblAmountTel, txtAmountTel);

        return gridTel;
    }

    private void setBarcodeValues(String value) {
        //[07:57:46] Ken: telkom will be the following:
        //[officeCode][AccountNumber][PayCode][ControlCode][AmountDue]
        //with lengths:
        //[5][10][4][3][10]
        //presumably amount in cents, left padded with zeros
        groupNum = value.trim().substring(0, 5);
        systemNum = value.trim().substring(5, (5 + 10));
        paymentCode = value.trim().substring((5 + 10), (5 + 10 + 4));
        controlCode = value.trim().substring((5 + 10 + 4), (5 + 10 + 4 + 3));
        String amountTelStr = value.trim().substring((5 + 10 + 4 + 3));

        txtGroupNo.setText(groupNum);
        txtGroupNo2.setText(groupNum);
        txtSystemNo.setText(systemNum);
        txtSystemNo2.setText(systemNum);
        txtPaymentCode.setText(paymentCode);
        txtPaymentCode2.setText(paymentCode);
        txtControlCode.setText(controlCode);
        txtControlCode2.setText(controlCode);

        txtGroupNo.setDisable(true);
        txtGroupNo2.setDisable(true);
        txtSystemNo.setDisable(true);
        txtSystemNo2.setDisable(true);
        txtPaymentCode.setDisable(true);
        txtPaymentCode2.setDisable(true);
        txtControlCode.setDisable(true);
        txtControlCode2.setDisable(true);

        if (!showFavourites) {
            double amtCents = SalesUtil.getAmountAsDouble(amountTelStr, txtAmountTel);
            amountTel = amtCents / 100;
//            txtAmountTel.setText(Double.toString(amountTel));
            txtAmountTel.setText(JKText.getDeciFormat(amountTel));
        }
//        double amtCents = SalesUtil.getAmountAsDouble(amountTelStr, txtAmountTel);
//        amountTel = amtCents / 100;
//        txtAmountTel.setText(Double.toString(amountTel));
    }

    public void setAdditionalValues() {
        groupNum = txtGroupNo.getText().trim();
        systemNum = txtSystemNo.getText().trim();
        paymentCode = txtPaymentCode.getText().trim();
        controlCode = txtControlCode.getText().trim();
        accountNum = groupNum + "-" + systemNum + "-" + paymentCode + "-" + controlCode;
        accountStr = accountNum;
        double amtDx100 = Math.rint(amountTel * 100);
        int amtAsInt = (int) (amtDx100);
        String amountStr = String.format("%010d", amtAsInt);
        additionalString = "1=" + groupNum + " "
                + "2=" + systemNum + " "
                + "3=" + paymentCode + " "
                + "4=" + controlCode + " "
                + "5=" + amountStr;
    }

    private boolean isInputValidTel() {   // Telkom
        if (txtGroupNo.getText().equals("") || txtGroupNo.getText().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Group Number", "Group Number cannot be empty", null);
            return false;
        }
        if (!txtGroupNo2.getText().equals(txtGroupNo.getText())) {
            JKiosk3.getMsgBox().showMsgBox("Group Number", "Group Numbers entered do not match", null);
            return false;
        }
        if (txtSystemNo.getText().equals("") || txtSystemNo.getText().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("System Number", "System Number cannot be empty", null);
            return false;
        }
        if (!txtSystemNo2.getText().equals(txtSystemNo.getText())) {
            JKiosk3.getMsgBox().showMsgBox("System Number", "System Numbers entered do not match", null);
            return false;
        }
        if (txtPaymentCode.getText().equals("") || txtPaymentCode.getText().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Payment Code", "Payment Code cannot be empty", null);
            return false;
        }
        if (!txtPaymentCode2.getText().equals(txtPaymentCode.getText())) {
            JKiosk3.getMsgBox().showMsgBox("Payment Code", "Payment Codes entered do not match", null);
            return false;
        }
        if (txtControlCode.getText().equals("") || txtControlCode.getText().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Control Code", "Control Code cannot be empty", null);
            return false;
        }
        if (!txtControlCode2.getText().equals(txtControlCode.getText())) {
            JKiosk3.getMsgBox().showMsgBox("Control Code", "Control Codes entered do not match", null);
            return false;
        }
        if (txtAmountTel.getText().equals("") || txtAmountTel.getText().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Amount Due", "Amount Due cannot be empty", null);
            return false;
        }

        return true;
    }

    public boolean isValidInputTelkom() {
        return isInputValidTel();
    }

    public String getGroupNum() {
        return groupNum;
    }

    public String getSystemNum() {
        return systemNum;
    }

    public String getPaymentCode() {
        return paymentCode;
    }

    public String getControlCode() {
        return controlCode;
    }

    public double getAmountTel() {
        return amountTel;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public String getAccountStr() {
        return accountStr;
    }

    public String getAdditionalString() {
        return additionalString;
    }
}
