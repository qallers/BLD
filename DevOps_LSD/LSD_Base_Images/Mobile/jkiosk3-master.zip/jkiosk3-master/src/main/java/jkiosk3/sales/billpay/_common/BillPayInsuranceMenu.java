package jkiosk3.sales.billpay._common;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.insurance.PolicyReg1;
import jkiosk3.sales.billpay.insurance.PolicyRegistration;
import jkiosk3.users.SalesUserLoginResult;

/**
 *
 * @author Valerie
 */
public class BillPayInsuranceMenu extends Region {

    public BillPayInsuranceMenu() {
        getChildren().add(getInsurancePolicyMenu());
    }

    private VBox getInsurancePolicyMenu() {

        VBox vbHead = JKNode.getPageHeadVB("Insurance Policy Options");

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getMenuButtons());

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private List<Button> getMenuButtons() {
        List<Button> btnList = new ArrayList<>();

        // String[] btnLabels = {BillPayUtilMisc.INSURE_PAYMENT, BillPayUtilMisc.INSURE_REGISTER};
        String[] btnLabels = {BillPayUtilMisc.INSURE_PAYMENT};

        for (String s : btnLabels) {
            final Button btn = JKNode.getBtnSmDbl(s);
            btn.setId(s);
            btn.getStyleClass().add("prov_VAS");
            btn.setStyle(JKNode.getBrandButton());
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(btn);
                }
            });

            btnList.add(btn);
        }

        return btnList;
    }

    private void getMenuAction(Button b) {

        switch (b.getId()) {
            case BillPayUtilMisc.INSURE_PAYMENT:
                SceneSales.clearAndChangeContent(new BillPaymentSelect(
                        BillPayUtilMisc.TYPE_INSURE_PAY + " Providers", BillPayUtilMisc.TYPE_INSURE_PAY));
                break;
            case BillPayUtilMisc.INSURE_REGISTER:
//                JKiosk3.getSalesUserLogin().showUserLogin(new PasswordField(), new SalesUserLoginResult() {
                JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
                    @Override
                    public void onDone() {
                        PolicyRegistration.resetPolicyRegistration();
                        SceneSales.clearAndChangeContent(new PolicyReg1());
                    }
                });
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Bill Payments", "Unable to find selected menu item", null,
                        MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                            @Override
                            public void onOk() {
                                SceneSales.clearAndChangeContent(new BillPaymentMenu());
                            }

                            @Override
                            public void onCancel() {
                                //
                            }
                        });
        }
    }
}
