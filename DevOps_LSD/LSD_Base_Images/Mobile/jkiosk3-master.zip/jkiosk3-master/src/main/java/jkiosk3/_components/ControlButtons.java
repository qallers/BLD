package jkiosk3._components;

import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

/**
 *
 * @author Val
 */
public class ControlButtons extends Region {

    private Button btnAccept;
    private Button btnCancel;

    public ControlButtons() {
        getChildren().add(getBtnControls());
    }

    private HBox getBtnControls() {

        btnAccept = JKNode.getBtnSm("Accept");
        btnAccept.setWrapText(true);

        btnCancel = JKNode.getBtnSm("Cancel");

        HBox hb = JKLayout.getControlsHBox();

        hb.getChildren().addAll(JKNode.getHSpacer(), btnAccept, btnCancel);

        return hb;
    }

    public Button getBtnAccept() {
        return btnAccept;
    }

    public Button getBtnCancel() {
        return btnCancel;
    }
}
