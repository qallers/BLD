package jkiosk3.sales.billpay.syntell;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.syntell.SyntellAccPayConfReq;
import aeonbillpayments.syntell.SyntellAccPayConfResp;
import aeonbillpayments.syntell.SyntellAccPayReq;
import aeonbillpayments.syntell.SyntellAccPayResp;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.BillPayUtilSyntell;
import jkiosk3.sales.billpay.BillPayUtilSyntell.SyntellBillPaymentConfirm;
import jkiosk3.sales.billpay.BillPayUtilSyntell.SyntellBillPaymentResponse;
import jkiosk3.sales.billpay._common.BillPayEntry;
import jkiosk3.sales.billpay._common.BillPaymentSelect;
import jkiosk3.store.JKTransactionLimits;
import jkiosk3.users.UserUtil;

public class InputSyntellBillPay extends Region {

    private BillPaymentConnection connection;
    private final BillPayProduct product;
    private final VBox vbContent;
    private BillPayEntry gridAcc;
    private GridPane gridAmtDetail;
    private JKioskNav nav;
    private JKTenderToggles tenders;
    private String tendered;
    private TextField txtAmt;
    private String accountNum;
    private double amountPaid;
    private SyntellAccPayReq request1;
    private SyntellAccPayResp response1;
    private SyntellAccPayReq request2;
    private SyntellAccPayResp response2;
    private boolean showFavourites;
    private boolean showProductFavourite;

    public InputSyntellBillPay(BillPayProduct product, boolean isNFCFavourite, boolean isProductFavourite) {
        this.product = product;
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;

        vbContent = JKLayout.getVBoxContent (JKLayout.spNum);

        VBox vbLayout = JKLayout.getVBox (0, 5);
        vbLayout.getChildren ().add (getAccountNumberEntry ());
        vbLayout.getChildren ().add (getNav ());

        getChildren ().add (vbLayout);
    }

    private VBox getAccountNumberEntry() {

        ImageView img = BillPayUtilMisc.getImageViewBillPay ("prov_Syntell.png");

        gridAcc = new BillPayEntry ("Account Payment", img, product, BillPayEntry.TYPE_ACCOUNT, showFavourites, showProductFavourite);
        gridAcc.getBtnDetail ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (vbContent.getChildren ().contains (gridAmtDetail)) {
                    vbContent.getChildren ().remove (gridAmtDetail);
                    getAccountRequestQuery ();
                } else {
                    getAccountRequestQuery ();
                }
            }
        });

        vbContent.getChildren ().add (gridAcc);

        return vbContent;
    }

    private GridPane getDetailAndAmountEntry() {

        GridPane gridDetail = BillPayUtilMisc.getGridBillPayDetail (response1.getAmountPaid (), response1.getConvenienceFee (),
                null, BPTransType.BILLPAY_SYNTELL_ACCOUNT.getDisplayName ());
//                null, BillPayUtilMisc.SYNTELL_BILL_PAY);

        Label lblAmount = JKText.getLblDk ("Amount", JKText.FONT_B_XSM);

        txtAmt = JKNode.getTextFieldRight ();

        if (product.isFullAmount ()) {
            txtAmt.setDisable (true);
            txtAmt.setPromptText ("Pay amount on confirm summary");
        } else {
            txtAmt.setDisable (false);
            txtAmt.setPromptText ("Enter Amount to Pay");
        }
        txtAmt.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad ().showNumPad (txtAmt,
                        "R " + (JKText.getDeciFormat (response1.getAmountPaid () + response1.getConvenienceFee ())),
                        "", new NumberPadResult () {

                            @Override
                            public void onDone(String value) {
                                amountPaid = SalesUtil.getAmountAsDouble (value, txtAmt);
                            }
                        });
//                }
            }
        });

        gridAmtDetail = JKLayout.getContentGridInner2Col (0.5, 0.5);

        gridAmtDetail.add (gridDetail, 0, 1, 2, 1);
        gridAmtDetail.addRow (2, lblAmount, txtAmt);
        gridAmtDetail.addRow (3, getTenderTypes ());

        return gridAmtDetail;
    }

    private JKTenderToggles getTenderTypes() {
        tenders = new JKTenderToggles (SaleType.BILLPAYMENTS.getDisplay ());
        for (ToggleButton b : tenders.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(javafx.event.Event e) {
                    if (!txtAmt.getText ().trim ().equals ("") && amountPaid != 0) {
                        tendered = tenders.getTenderTypeSelected ();
                        checkAndAuthoriseAmount ();
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("Amount to Pay", "Please enter an Amount", null);
                        tenders.resetTenderType ();
                    }
                }
            });
        }
        return tenders;
    }

    private JKioskNav getNav() {
        nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (gridAcc.getVbHead ().getChildren ().contains (gridAcc.getGridEnter ())) {
                    SceneSales.clearAndChangeContent (new BillPaymentSelect (
                            BillPayUtilMisc.TYPE_BILL_PAY + " Providers", BillPayUtilMisc.TYPE_BILL_PAY));
                } else {
                    SceneSales.clearAndChangeContent (new InputSyntellBillPay (product, showFavourites, showProductFavourite));
                }
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                BillPayUtilMisc.resetBillPayView ();
                if (request1 != null) {
                    submitSyntellBillPaymentRollback (request1, response1, BillPayUtilMisc.CALL_BY_CANCEL);
                }
            }
        });
        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private void showConfirmationSummary() {
        SummarySyntellBillPay summary = new SummarySyntellBillPay (request2, response2);

        JKiosk3.getMsgBox ().showMsgBox (BPTransType.BILLPAY_SYNTELL_ACCOUNT.getDisplayName (), "Confirm all details before proceeding",
                summary, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        submitSyntellBillPaymentCommit (request2, response2);
                    }

                    @Override
                    public void onCancel() {
                        UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                        BillPayUtilMisc.resetBillPayView ();
                        submitSyntellBillPaymentRollback (request2, response2, BillPayUtilMisc.CALL_BY_CANCEL);
                    }
                });
    }

    //====================================
    // above - mostly view
    // below - mostly process
    //====================================
    private void getAccountRequestQuery() {
        accountNum = gridAcc.getAccountNumberConfirmed ();

        request1 = new SyntellAccPayReq ();
        request1.setProviderId (product.getProvId ());
        request1.setProductId (product.getProdId ());
        request1.setAccountNo (accountNum);
        request1.setAmount (20.0);
        if (tendered != null) {
            request1.setTenderType (tendered);
        } else {
            request1.setTenderType ("cash");
        }

        BillPayUtilSyntell.getSyntellBillPaymentResponse (request1, new SyntellBillPaymentResponse () {
            @Override
            public void syntellBillPayResp(BillPaymentConnection connect, SyntellAccPayResp resp) {
                connection = connect;

                if (resp.isSuccess ()) {
                    response1 = resp;
                    gridAcc.getVbHead ().getChildren ().remove (gridAcc.getGridEnter ());
                    gridAcc.getVbHead ().getChildren ().add (gridAcc.getGridDetail (resp.getAccountNo (), "-"));
                    gridAmtDetail = getDetailAndAmountEntry ();
                    vbContent.getChildren ().add (1, gridAmtDetail);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Account Detail Error", !resp.getAeonErrorMessage ().isEmpty () ?
                            resp.getAeonErrorCode () + " - " + resp.getAeonErrorMessage () :
                            resp.getErrorCode () + " - " + resp.getErrorMessage (), null);
                    BillPayUtilMisc.resetBillPayView ();
                }
            }
        });
    }

    private void checkAndAuthoriseAmount() {
        if (amountPaid > JKTransactionLimits.getTransactionLimits ().getTransLimitBillPay ()) {
            BillPayUtilMisc.getSupervisorOverride (amountPaid, new UserUtil.SupervisorOverride () {

                @Override
                public void supervisorOverrideResult(Boolean isSupervisor) {
                    if (isSupervisor) {
                        submitSyntellBillPaymentRollback (request1, response1, BillPayUtilMisc.CALL_BY_TENDER);
                        System.out.println ("supervisor has authorised, show summary and continue...");
                    } else {
                        System.out.println ("no authorisation yet, try again...");
                    }
                }
            }, txtAmt);
            tenders.resetTenderType ();
        } else {
            submitSyntellBillPaymentRollback (request1, response1, BillPayUtilMisc.CALL_BY_TENDER);
        }
    }

    private void getAccountRequestPay() {
        request2 = new SyntellAccPayReq ();
        request2.setProviderId (product.getProvId ());
        request2.setProductId (product.getProdId ());
        request2.setAccountNo (accountNum);
        request2.setAmount (amountPaid);
        request2.setTenderType (tendered);

        BillPayUtilSyntell.getSyntellBillPaymentResponse (request2, new SyntellBillPaymentResponse () {
            @Override
            public void syntellBillPayResp(BillPaymentConnection connect, SyntellAccPayResp resp) {
                connection = connect;

                if (resp.isSuccess ()) {
                    response2 = resp;
                    showConfirmationSummary ();
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Account Detail Error", !resp.getAeonErrorMessage ().isEmpty () ?
                            resp.getAeonErrorCode () + " - " + resp.getAeonErrorMessage () :
                            resp.getErrorCode () + " - " + resp.getErrorMessage (), null);
                    BillPayUtilMisc.resetBillPayView ();
                }
            }
        });
    }

    private void submitSyntellBillPaymentCommit(SyntellAccPayReq reqCommit, SyntellAccPayResp respCommit) {
        final SyntellAccPayConfReq confCommit = new SyntellAccPayConfReq ();

        confCommit.setProviderId (reqCommit.getProviderId ());
        confCommit.setProductId (reqCommit.getProductId ());
        confCommit.setConfirmType ("commit");
        confCommit.setReceiptNo (response2.getReceiptNo ());
        confCommit.setWantPrintJob (true);

        BillPayUtilSyntell.getSyntellBillPaymentConfirm (connection, confCommit, new SyntellBillPaymentConfirm () {
            @Override
            public void syntellBillPayConf(final SyntellAccPayConfResp confResp) {
                if (confResp.isSuccess ()) {
                    double amtTotal = amountPaid + response2.getConvenienceFee ();
                    String descript = product.getProdName () + " - " + request2.getAccountNo ();

                    SalesUtil.processBillPayment (BPTransType.BILLPAY_SYNTELL_ACCOUNT.getDisplayName (), response2.getTransRef (), descript, amtTotal,
                            tendered, confResp.getResultDescription (), confResp.getPrintLines (), confResp.getMerchantPrintLines ());

                } else if (!confResp.getAeonErrorText ().isEmpty ()) {
                    JKiosk3.getMsgBox ().showMsgBox ("Bill Payment Error", "A" + confResp.getAeonErrorCode () + " - " + confResp.getAeonErrorText (), null);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Bill Payment Error", "B" + confResp.getErrorCode () + " - " + confResp.getErrorText (), null);
                }
                BillPayUtilMisc.resetBillPayView ();
            }
        });
    }

    private void submitSyntellBillPaymentRollback(SyntellAccPayReq reqRollback, SyntellAccPayResp respRollback,
                                                  final String calledBy) {
        SyntellAccPayConfReq confRollback = new SyntellAccPayConfReq ();

        confRollback.setProviderId (reqRollback.getProviderId ());
        confRollback.setProductId (reqRollback.getProductId ());
        confRollback.setConfirmType ("rollback");
        confRollback.setReceiptNo (respRollback.getReceiptNo ());

        BillPayUtilSyntell.getSyntellBillPaymentConfirm (connection, confRollback, new SyntellBillPaymentConfirm () {
            @Override
            public void syntellBillPayConf(SyntellAccPayConfResp confResp) {
                if (confResp.isSuccess ()) {
                    switch (calledBy) {
                        case BillPayUtilMisc.CALL_BY_CANCEL:
                            JKiosk3.getMsgBox ().showMsgBox ("Bill Payment", "Transaction cancelled by User", null);
                            BillPayUtilMisc.resetBillPayView ();
                            break;
                        case BillPayUtilMisc.CALL_BY_TENDER:
                            getAccountRequestPay ();
                            break;
                        default:
                            JKiosk3.getMsgBox ().showMsgBox ("Payment Confirm", "Unable to determine Rollback requestor", null);
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Bill Payment Rollback Error", !confResp.getAeonErrorText ().isEmpty () ?
                            "A" + confResp.getAeonErrorCode () + " - " + confResp.getAeonErrorText () :
                            "B" + confResp.getErrorCode () + " - " + confResp.getErrorText (), null);
                }
            }
        });
    }

}
