package jkiosk3._components;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3.StageJKiosk;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.branding.MerchantGroup;
import jkiosk3.callme.CallMeMainMenu;
import jkiosk3.callme.DownloadCategoryService;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._favourites.nfc.ActiveNFCDisplay;
import jkiosk3.sales._favourites.nfc.NFCMenu;
import jkiosk3.store.JKBranding;
import jkiosk3.store.JKNFCReader;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.UserUtil;

public class SceneBackground extends Region {

    private final static double SUPPORT_W = 325;
    private final static double HELP_W = 110;
    private static ImageView imgBrandBg;
    private final MerchantGroup merchantGroup;
    private static AnchorPane anchorBackground;
    private static StackPane stackSupport;
    private static VBox vBoxSupport;

    public SceneBackground(MerchantGroup merchantGroup, Region scene) {
        this.merchantGroup = merchantGroup;

        double suppOffset = ((StageJKiosk.getSceneWidth() / 2) - (SUPPORT_W / 2)) - (HELP_W); // = 267
        double sp = JKLayout.sp;

        StackPane img = getBackgroundImage();
        VBox user = getUserBox();

        HBox centerBox = JKLayout.getHBox(0, 0);
        centerBox.setMaxWidth(SUPPORT_W + (2 * HELP_W));
        centerBox.setMinWidth(SUPPORT_W + (2 * HELP_W));

        HBox callMeBox = JKLayout.getHBox(0, 0);
        callMeBox.setMaxWidth(SUPPORT_W + (2 * HELP_W));
        callMeBox.setMinWidth(SUPPORT_W + (2 * HELP_W));

        stackSupport = new StackPane();
        stackSupport.setMaxSize(SUPPORT_W, 60);
        stackSupport.setMinSize(SUPPORT_W, 60);
        stackSupport.getStyleClass().add("stackContent");

        vBoxSupport = getVBSupport();
        stackSupport.getChildren().add(vBoxSupport);

        if (scene instanceof SceneSales) {
            if (JKNFCReader.getNfcReaderConfig().isNfcCardRead()) {
                if (JKBranding.getBranding().getMerchantGroup().getCode().equals("GLOCELL")) {
                    centerBox.getChildren().addAll(getFavouritesBtn(), JKNode.getHSpacer(), stackSupport, JKNode.getHSpacer());//, getNFCBox() (will be added in the future)
                } else {
                    centerBox.getChildren().addAll(getFavouritesBtn(), JKNode.getHSpacer(), getCallMeBtn(), JKNode.getHSpacer(), stackSupport, JKNode.getHSpacer(), getNFCBox());
                }
            } else {
                if (JKBranding.getBranding().getMerchantGroup().getCode().equals("GLOCELL")) {
                    centerBox.getChildren().addAll(getFavouritesBtn(), JKNode.getHSpacer(), stackSupport, JKNode.getHSpacer(), getLogoBox());
                } else {
                    centerBox.getChildren().addAll(getFavouritesBtn(), JKNode.getHSpacer(), getCallMeBtn(), JKNode.getHSpacer(), stackSupport, JKNode.getHSpacer(), getLogoBox());
                }
            }
        } else {
            centerBox.getChildren().addAll(getHelpBox(), JKNode.getHSpacer(), stackSupport, JKNode.getHSpacer(), getLogoBox());
        }

        anchorBackground = new AnchorPane();
        anchorBackground.setPrefSize(StageJKiosk.getSceneWidth(), StageJKiosk.getSceneHeight());

        AnchorPane.setLeftAnchor(user, sp);
        AnchorPane.setBottomAnchor(user, (sp / 2));
        AnchorPane.setLeftAnchor(centerBox, suppOffset);
        AnchorPane.setBottomAnchor(centerBox, (sp / 2));

        anchorBackground.getChildren().addAll(img, user, centerBox, callMeBox);

        getChildren().add(anchorBackground);
    }

    private StackPane getBackgroundImage() {
        StackPane stack = new StackPane();
        stack.setPrefSize(StageJKiosk.getSceneWidth(), StageJKiosk.getSceneHeight());
        stack.setStyle("-fx-padding: 0;");

        if (merchantGroup == null || merchantGroup.getCode().equalsIgnoreCase("BLD")) {
            imgBrandBg = JKNode.getJKImageView("lg_BLD.png", JKLayout.contentW, 0);
            imgBrandBg.setTranslateY(-(2 * JKLayout.sp));
        } else {
            imgBrandBg = JKNode.getJKImageView("lg_" + merchantGroup.getCode() + ".png", 520, 0);
        }
        showSceneBackgroundImage();

        stack.getChildren().add(imgBrandBg);

        return stack;
    }

    private VBox getUserBox() {
        VBox vb = JKLayout.getVBoxLeft(0, 5);

        Label lblUser = JKText.getLblDk("Logged in as: ", JKText.FONT_B_XXSM);

        Text txtName = JKText.getTxtDk("", JKText.FONT_B_XSM);
        if (CurrentUser.getUser() == null) {
            txtName.setText("");
        } else {
            txtName.setText(CurrentUser.getUser().getUserName());
        }

        vb.getChildren().addAll(lblUser, txtName);

        return vb;
    }

    // Original code, fitted shorter email
//    private VBox getGrpSupport() {
//        Label lblSupp = JKText.getLblDk("Support", JKText.FONT_B_XSM);
////        Label lblTel = JKText.getLblDk(Version.getHelpDeskTelNum(), JKText.FONT_B_XXSM);
//        Label lblTel = JKText.getLblDk(JK3Config.getInfoHelpDeskTelNum(), JKText.FONT_B_XXSM);
//        Label lblSp = JKText.getLblDk(" : ", JKText.FONT_B_XXSM);
////        Label lblMail = JKText.getLblDk(Version.getHelpDeskEmail(), JKText.FONT_B_XXSM);
//        Label lblMail = JKText.getLblDk(JK3Config.getInfoHelpDeskEmail(), JKText.FONT_B_XXSM);
//
//        HBox hb = JKLayout.getHBox(0, JKLayout.spNum);
//        hb.setMinWidth(SUPPORT_W);
//        hb.getChildren().addAll(lblTel, lblSp, lblMail);
//
//        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
//        vb.setMaxSize(SUPPORT_W, 60);
//        vb.setMinSize(SUPPORT_W, 60);
//        vb.getChildren().addAll(lblSupp, hb);
//
//        return vb;
//    }

    private VBox getVBSupport() {
//        Label lblSupport = JKText.getLblDk("Support", JKText.FONT_B_XLG);
//        lblSupport.setStyle("-fx-opacity: 0.075;");

        Label lblHelpTel = JKText.getLblDk("Tel", JKText.FONT_B_XXSM);
        lblHelpTel.setPrefWidth(50);
        Label lblHelpMail = JKText.getLblDk("Email", JKText.FONT_B_XXSM);
        lblHelpMail.setPrefWidth(50);
        Label lblTel;
        Label lblMail;

        lblTel = JKText.getLblDk(JK3Config.getInfoHelpDeskTelNum(), JKText.FONT_B_XXSM);
        lblMail = JKText.getLblDk(JK3Config.getInfoHelpDeskEmail(), JKText.FONT_B_XXSM);

        HBox hbTel = JKLayout.getHBox(0, 0);
        hbTel.setMinWidth(SUPPORT_W - (3 * JKLayout.sp));
        hbTel.getChildren().addAll(lblHelpTel, getLblColon(), JKNode.getHSpacer(), lblTel);

        HBox hbMail = JKLayout.getHBox(0, 0);
        hbMail.setMinWidth(SUPPORT_W - (3 * JKLayout.sp));
        hbMail.getChildren().addAll(lblHelpMail, getLblColon(), JKNode.getHSpacer(), lblMail);

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.setStyle("-fx-padding: 0px 25px 0px 25px;");
        vb.setMaxSize(SUPPORT_W, 60);
        vb.setMinSize(SUPPORT_W, 60);
        vb.getChildren().addAll(hbTel, hbMail);

//        StackPane stackPane = new StackPane();
//        stackPane.getChildren().addAll(lblSupport, vb);
//
//        VBox vbOuter = new VBox();
//        vbOuter.getChildren().add(stackPane);

        return vb;
    }

    private Label getLblColon() {
        return JKText.getLblDk(":", JKText.FONT_B_15);
    }

    private Button getHelpBox() {

        Image imgH = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/help.png"));
        ImageView imgHelp = new ImageView(imgH);

        Button btnHelp = JKNode.getBtnNum("");
        btnHelp.setGraphic(imgHelp);
        btnHelp.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                JKiosk3.getWebPage().showWebPage(JK3Config.getHelpUrl());
            }
        });

        return btnHelp;
    }

    private Button getFavouritesBtn() {
        ImageView img = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/favourites.png")));
        img.setFitHeight(20);
        img.setPreserveRatio(true);

        Label lbl = JKText.getLblDk("fav", JKText.FONT_B_22);
        lbl.setStyle("-fx-text-fill: #FFFFFF;");

        VBox vb = JKLayout.getVBox(0, 0);
        vb.getChildren().addAll(img, lbl);
//        vb.setStyle("-fx-rotate: -17;");

        Button btnFav = JKNode.getBtnNum("");
//        btnFav.setMaxSize(JKLayout.btnNumW, JKLayout.btnNumH);
//        btnFav.setMinSize(JKLayout.btnNumW, JKLayout.btnNumH);
//        btnFav.getStyleClass().add("btnFav");
        btnFav.getStyleClass().add("btnFavMenu");
        btnFav.setGraphic(vb);
//        btnFav.setStyle("-fx-effect: null;");
        btnFav.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                System.out.println("Clicked the FAVOURITES button!");
                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndShowFavourites();
            }
        });
//        Button btnbg = JKNode.getBtnNum("");
//        btnbg.getStyleClass().add("btnFavBg");

//        StackPane stack2 = new StackPane();
//        stack2.getChildren().addAll(btnbg, btnFav);

        return btnFav;
    }

    private Button getCallMeBtn() {
        ImageView img = new ImageView(new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/callme.png")));
        img.setFitHeight(40);
        img.setPreserveRatio(true);

        VBox vb = JKLayout.getVBox(0, 0);
        vb.getChildren().addAll(img);

        Button btnCallMe = JKNode.getBtnNum("");

        btnCallMe.getStyleClass().add("btnFavMenu");
        btnCallMe.setGraphic(vb);

        btnCallMe.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                System.out.println("Clicked the Please Call Me button!");
                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);

                DownloadCategoryService pleaseCallMeUtil = new DownloadCategoryService();
                String restResp = pleaseCallMeUtil.postData();

                if(restResp.isEmpty()){
                    JKiosk3.getMsgBox().showMsgBox("Oops! something went wrong",
                            "Unable to connect to server. \nPlease try again later.", null);
                } else {
                    JKiosk3.changeScene(new CallMeMainMenu());

                    // this is another way of navigating to preferable screen on JKiosk
                    /*getChildren().add(new CallMeMainMenu());*/
                }
            }
        });

        return btnCallMe;
    }

    private ImageView getLogoBox() {

        if (JKBranding.getBranding().getMerchantGroup().getCode().equals("GLOCELL")) {

            Image glo = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/glo_stamp_2020.png"));
            ImageView imgGlo = new ImageView(glo);
            imgGlo.setFitHeight(57);
            imgGlo.setPreserveRatio(true);
            //imgBlu.getStyleClass().add("bluLogo");

            return imgGlo;

        } else {
            Image glo = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/blu_stamp_2018.png"));
            ImageView imgBlu = new ImageView(glo);
            imgBlu.setFitHeight(57);
            imgBlu.setPreserveRatio(true);
            //imgBlu.getStyleClass().add("bluLogo");

            return imgBlu;
        }

    }

    private Button getNFCBox() {

        Image img = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/nfc.png"));
        ImageView imgNfc = new ImageView(img);
        imgNfc.setFitWidth(49);
        imgNfc.setPreserveRatio(true);

        Button btnNfc = JKNode.getBtnNum("");
        btnNfc.setGraphic(imgNfc);
        btnNfc.getStyleClass().add("btnNFC");
        btnNfc.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new NFCMenu());
            }
        });

        return btnNfc;
    }

    public static void fadeSceneBackgroundImage() {
        imgBrandBg.setOpacity(0.10);
    }

    public static void showSceneBackgroundImage() {
        imgBrandBg.setOpacity(0.95);
    }

    public static VBox getvBoxSupport() {
        return vBoxSupport;
    }

    public static void updateSupportView(Region region) {
        stackSupport.getChildren().clear();
        stackSupport.getChildren().add(region);
        if (region instanceof ActiveNFCDisplay) {
            stackSupport.getStyleClass().clear();
            stackSupport.getStyleClass().add("stackNFC");
        } else {
            stackSupport.getStyleClass().clear();
            stackSupport.getStyleClass().add("stackContent");
        }
    }

    public static void setAnchorBackground(boolean isActiveNFC) {
        if (isActiveNFC) {
//            anchorBackground.setStyle("-fx-background-color: #e6fff2;");  // minty fresh!
//            anchorBackground.setStyle("-fx-background-color: #D3E7F8;");
//            anchorBackground.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #D3E7F8 35%, #FFFEE4 75%);");
//            anchorBackground.setStyle("-fx-background-color: linear-gradient(" +
//                    "from 0% 0% to 100% 100%, repeat, #D3E7F8 20%, #FFFEE4 40%, #D3E7F8 60%, #FFFEE4 80%);");
//            anchorBackground.setStyle("-fx-background-color: linear-gradient(" +
//                    "from 0% 0% to 100% 100%, repeat, #C7E1F8 17%, #FFFED3 30%, #C7E1F8 47%, #FFFED3 60%, #C7E1F8 77%, #FFFED3 95%);");
            anchorBackground.setStyle("-fx-background-color: linear-gradient(" +
                    "from 0% 0% to 100% 100%, repeat, #C7E1F8 22%, #FFFED3 44%, #C7E1F8 66%, #FFFED3 88%);");
        } else {
            anchorBackground.setStyle("-fx-background-color: TRANSPARENT;");
        }
    }
}