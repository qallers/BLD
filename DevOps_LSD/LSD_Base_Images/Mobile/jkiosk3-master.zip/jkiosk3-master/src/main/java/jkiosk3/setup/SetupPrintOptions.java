package jkiosk3.setup;

import aeonusers.User;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.PrintUtil;
import jkiosk3.printing.print_layouts.PrintAssorted;
import jkiosk3.store.JKOptions;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.UserUtil;

/**
 *
 * @author Val
 */
public class SetupPrintOptions extends Region {

//    private CheckBox chkPrintPreview;
    private CheckBox chkPrintImmediate;
    private CheckBox chkPrintReceipt;
    private CheckBox chkMerchantCopy;
    private CheckBox chkPrintBarcode;
    private CheckBox chkHideReprintPin;
    private TextField txtMerchantName;
    private TextField txtMerchantAddress;
    private TextField txtMerchantVat;
    private String storeName;
    private String storeAddress;
    private String storeVatReg;

    public SetupPrintOptions() {
        storeName = JKPrintOptions.getPrintOptions().getStoreName();
        storeAddress = JKPrintOptions.getPrintOptions().getStoreAddress();
        storeVatReg = JKPrintOptions.getPrintOptions().getStoreVatReg();

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getPrintOptionsLayout());
        vb.getChildren().add(getControls());

        getChildren().add(vb);
    }

    private VBox getPrintOptionsLayout() {

        VBox vbLayout = JKLayout.getVBoxContent(JKLayout.sp);
        vbLayout.getChildren().add(getPrintOptionsEntry());
        vbLayout.getChildren().add(getMerchantDetailGrid());

        return vbLayout;
    }

    private GridPane getPrintOptionsEntry() {
        GridPane grid = JKLayout.getContentGridInner2Col(1.0, 0.0);
        VBox vbHead = JKNode.getPageHeadVB("Print Options");


//        chkPrintPreview = new CheckBox("Show Print Preview before Printing");
//        chkPrintPreview.setSelected(JKPrintOptions.getPrintOptions().isPrintPreview());

        chkPrintImmediate = new CheckBox("Print Vouchers Immediately");
        chkPrintImmediate.setSelected(JKPrintOptions.getPrintOptions().isPrintImmediately());

        chkPrintReceipt = new CheckBox("Print Receipts");
        chkPrintReceipt.setSelected(JKPrintOptions.getPrintOptions().isPrintReceipts());
        chkPrintReceipt.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (chkPrintReceipt.isSelected()) {
                    txtMerchantName.setDisable(false);
                    txtMerchantAddress.setDisable(false);
                    txtMerchantVat.setDisable(false);
                } else {
                    txtMerchantName.setDisable(true);
                    txtMerchantAddress.setDisable(true);
                    txtMerchantVat.setDisable(true);
                }
            }
        });

        chkMerchantCopy = new CheckBox("Print Merchant Copy of Voucher");
        chkMerchantCopy.setSelected(JKPrintOptions.getPrintOptions().isPrintMerchantCopy());

        chkPrintBarcode = new CheckBox("Print Barcode on Vouchers");
        chkPrintBarcode.setSelected(JKPrintOptions.getPrintOptions().isPrintBarcode());

        //make hide Pin check box available only for technician not supervisor
        if (SceneSetup.userPin.equals("2596")) {
            chkHideReprintPin = new CheckBox("Hide Voucher PIN on Reprint");
            chkHideReprintPin.setSelected(JKPrintOptions.getPrintOptions().isHideReprintPin());

        } else if (CurrentUser.getUser().getUserLevel() == 1) {
            chkHideReprintPin = new CheckBox("Hide Voucher PIN on Reprint");
            chkHideReprintPin.setSelected(JKPrintOptions.getPrintOptions().isHideReprintPin());
            chkHideReprintPin.setDisable(true);
            chkHideReprintPin.setVisible(false);
        }

        grid.add(vbHead, 0, 0, 2, 1);
//       grid.add(chkPrintPreview, 0, 1);
        grid.add(chkPrintImmediate, 0, 1);
        grid.add(chkPrintReceipt, 0, 2);
        grid.add(chkMerchantCopy, 0, 3);
        grid.add(chkPrintBarcode, 0, 4);
        grid.add(chkHideReprintPin, 0, 5);

        return grid;
    }

    private GridPane getMerchantDetailGrid() {
        GridPane grid = JKLayout.getContentGridInner2Col(0.25, 0.75);

        Label lblMerchantDetail = JKText.getLblDk("Enter the details that must appear on Sales Receipts",
                JKText.FONT_B_XSM);

        Label lblMerchantName = JKText.getLblDk("Store Name", JKText.FONT_B_XSM);
        lblMerchantName.setMaxWidth(JKLayout.btnSmW);
        lblMerchantName.setMinWidth(JKLayout.btnSmW);
        Label lblMerchantAddress = JKText.getLblDk("Store Address", JKText.FONT_B_XSM);
        Label lblMerchantVat = JKText.getLblDk("VAT Reg No", JKText.FONT_B_XSM);

        txtMerchantName = new TextField(storeName);
        txtMerchantName.setDisable(!chkPrintReceipt.isSelected());
        txtMerchantName.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!JKOptions.getOptions().isKeyboard()) {
                    JKiosk3.getKeyboard().showKeyboard(txtMerchantName, "Enter Merchant name", storeName, false, true);
                }
            }
        });

        txtMerchantAddress = new TextField(storeAddress);
        txtMerchantAddress.setDisable(!chkPrintReceipt.isSelected());
        txtMerchantAddress.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!JKOptions.getOptions().isKeyboard()) {
                    JKiosk3.getKeyboard().showKeyboard(txtMerchantAddress, "Enter Store address", storeAddress, false, true);
                }
            }
        });

        txtMerchantVat = new TextField(storeVatReg);
        txtMerchantVat.setDisable(!chkPrintReceipt.isSelected());
        txtMerchantVat.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!JKOptions.getOptions().isKeyboard()) {
                    JKiosk3.getNumPad().showNumPad(txtMerchantVat, "VAT Reg No", storeVatReg);
                }
            }
        });

        grid.add(JKNode.createGridSpanSep(2), 0, 0);
        grid.add(lblMerchantDetail, 0, 1, 2, 1);
        grid.addRow(2, lblMerchantName, txtMerchantName);
        grid.addRow(3, lblMerchantAddress, txtMerchantAddress);
        grid.addRow(4, lblMerchantVat, txtMerchantVat);

        return grid;
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("Test Print", true) {
            @Override
            public void onClickTest() {
                if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
                    JKiosk3.getPrintPreview().showPrintPreview("Test Print", PrintAssorted.getTestPrint(),
                            PrintPreview.PRN_OK, new PrintPreviewResult() {
                                @Override
                                public void onOk() {
                                    //
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } else {
                    PrintUtil.sendToPrinter(PrintAssorted.getTestPrint());
                }
            }

            @Override
            public void onClickSave() {
                if (isValid()) {
                    savePrintOptions();
                }
            }
        };
    }

    private void savePrintOptions() {
//        if (chkPrintPreview.isSelected()) {
//            JKPrintOptions.getPrintOptions().setPrintPreview(true);
//        } else {
//            JKPrintOptions.getPrintOptions().setPrintPreview(false);
//        }

        if (chkPrintImmediate.isSelected()) {
            JKPrintOptions.getPrintOptions().setPrintImmediately(true);
        } else {
            JKPrintOptions.getPrintOptions().setPrintImmediately(false);
        }

        if (chkPrintReceipt.isSelected()) {
            JKPrintOptions.getPrintOptions().setPrintReceipts(true);
            JKPrintOptions.getPrintOptions().setStoreName(storeName);
            JKPrintOptions.getPrintOptions().setStoreAddress(storeAddress);
            JKPrintOptions.getPrintOptions().setStoreVatReg(storeVatReg);
        } else {
            JKPrintOptions.getPrintOptions().setPrintReceipts(false);
        }

        if (chkMerchantCopy.isSelected()) {
            JKPrintOptions.getPrintOptions().setPrintMerchantCopy(true);
        } else {
            JKPrintOptions.getPrintOptions().setPrintMerchantCopy(false);
        }

        if (chkPrintBarcode.isSelected()) {
            JKPrintOptions.getPrintOptions().setPrintBarcode(true);
        } else {
            JKPrintOptions.getPrintOptions().setPrintBarcode(false);
        }
        if (chkHideReprintPin.isSelected()) {
            JKPrintOptions.getPrintOptions().setHideReprintPin(true);
        } else {
            JKPrintOptions.getPrintOptions().setHideReprintPin(false);
        }

        if (JKPrintOptions.savePrintOptions()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Print options saved successfully", null);
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Print options not saved", null);
        }
    }

    private boolean isValid() {
        boolean valid = false;
        if (chkPrintReceipt.isSelected()) {
            if (txtMerchantName.getText() == null || txtMerchantName.getText().equals("")) {
                JKiosk3.getMsgBox().showMsgBox("Store Name", "If 'Print Receipts' is selected, you must enter a Store Name", null);
            } else {
                storeName = txtMerchantName.getText();
                storeAddress = txtMerchantAddress.getText();
                if (!txtMerchantVat.getText().equals("") && !txtMerchantVat.getText().matches("\\d{10}")) {
                    JKiosk3.getMsgBox().showMsgBox("VAT Reg No",
                            "Please enter a valid 10-digit VAT Registration number", null);
                } else {
                    storeVatReg = txtMerchantVat.getText();
                    valid = true;
                }
            }
        } else {
            valid = true;
        }
        return valid;
    }
}
