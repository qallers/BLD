package jkiosk3.sales.ticketpro.sale;

import aeonticketpros.TicketProsEvent;
import aeonticketpros.TicketProsEventDetail;
import aeonticketpros.TicketProsSeatCategory;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.web.WebView;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlSearch;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.ticketpro.TicketProMenu;
import jkiosk3.sales.ticketpro.TicketProSale;
import jkiosk3.sales.ticketpro.TicketProUtil;
import jkiosk3.users.SalesUserLoginResult;
import jkiosk3.users.UserUtil;

public class TicketProEvents extends Region {

    private List<TicketProsEvent> listEvents;
    private List<TicketProsEvent> listEventsShow;
    private List<Node> listEventButtons;
    private ControlSearch searchCtrl;
    private StackPane stack;
    private final static int pageSize = 3;

    public TicketProEvents(List<TicketProsEvent> listEvents) {
        this.listEvents = listEvents;
        this.listEventsShow = listEvents;

        setSearchControlActions ();

        getChildren ().add (getEventsLayout ());
    }

    private void setSearchControlActions() {
        searchCtrl = new ControlSearch ();
        searchCtrl.getBtnSearch ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (new TextField (), "Enter search text", "",
                        false, false, new KeyboardResult () {
                            @Override
                            public void onDone(final String value) {
                                TicketProUtil.getTicketProEventsSearchedList (value, listEvents, new TicketProUtil.TicketProEventListResult () {
                                    @Override
                                    public void tpEventListResult(List<TicketProsEvent> tpEventListResult) {
                                        if (!tpEventListResult.isEmpty ()) {
                                            listEventsShow = tpEventListResult;
                                            getEventItems ();
                                        } else {
                                            JKiosk3.getMsgBox ().showMsgBox ("No Matching Events", "No Events found for search term" +
                                                    "\n\n" + value + "\n\nPlease try a different search term", null);
                                        }
                                    }
                                });
                            }
                        });
            }
        });
        searchCtrl.getBtnClear ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                listEventsShow = listEvents;
                getEventItems ();
            }
        });
    }

    private VBox getEventsLayout() {
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (getEventsGroup ());
        vb.getChildren ().add (getNav ());
        return vb;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(javafx.event.Event e) {
                SceneSales.clearAndChangeContent (new TicketProCategories ());
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(javafx.event.Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent (new TicketProMenu ());
            }
        });
        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private VBox getEventsGroup() {

        String category = "searched";
        if (TicketProSale.getInstance ().getSelectedCategory () != null) {
            category = TicketProSale.getInstance ().getSelectedCategory ().getName ();
        }

        Label lblCat = JKText.getLblDk ("Category - " + category, JKText.FONT_B_SM);
        Label lblEvt = JKText.getLblDk ("Choose Event", JKText.FONT_B_XSM);

        VBox vbLbls = JKLayout.getVBoxLeft (0, JKLayout.spNum);
        vbLbls.getChildren ().addAll (lblCat, lblEvt);

        VBox vbHead = JKNode.getPageDblHeadVB (0, vbLbls, searchCtrl);
        vbHead.setMaxWidth (JKLayout.contentW - (2 * JKLayout.sp));

        stack = new StackPane ();
        stack.setStyle ("-fx-padding: 0px 0px 15px 0px;");
        stack.setMaxSize (JKLayout.contentW, 515);
        stack.setMinSize (JKLayout.contentW, 515);

        getEventItems ();

        VBox vb = JKLayout.getVBoxContent (JKLayout.spNum);
        vb.setStyle ("-fx-padding: 15px 0px 0px 0px;");
        vb.setMaxWidth (JKLayout.contentW);
        StackPane.setAlignment (vb, Pos.TOP_CENTER);
        vb.getChildren ().addAll (vbHead, stack);

        return vb;
    }

    private void getEventItems() {
        stack.getChildren ().clear ();
        createPagedEvents ();
    }

    private void createPagedEvents() {
        listEventButtons = getEventButtonList ();

        int numPgs = 0;
        if (listEventButtons.isEmpty ()) {
            numPgs = 1;
        } else if ((listEventButtons.size () % pageSize) == 0) {
            numPgs = listEventButtons.size () / pageSize;
        } else {
            numPgs = (listEventButtons.size () / pageSize) + 1;
        }
        Pagination pages = new Pagination (numPgs);
        pages.setPageFactory (new Callback<Integer, Node> () {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedVBox (pg, listEventButtons, pageSize);
            }
        });
        stack.getChildren ().add (pages);
    }

    private List<Node> getEventButtonList() {
        final List<Node> btnList = new ArrayList<> ();

        for (final TicketProsEvent event : listEventsShow) {
            Button btn = new Button ();
            btn.setId (event.getEventId ());
            btn.getStyleClass ().add ("btnTicketProsEvent");
            double w = (4 * ((JKLayout.contentW - (2 * JKLayout.sp)) / 5) - JKLayout.spNum);
//            double h = 125;         // was 115
            double h = 120;         // was 115
            btn.setMaxSize (w, h);
            btn.setMinSize (w, h);
            String imgUrl;
            Image img = null;
            try {
                imgUrl = event.getSmallImage ();
                img = new Image (imgUrl, true);
            } catch (IllegalArgumentException i) {
                img = JKNode.getImageTicketPro ();
            }
            ImageView imgEvt = new ImageView (img);
            imgEvt.setFitWidth (85);
            imgEvt.setFitHeight (105);
            imgEvt.setPreserveRatio (true);
            StackPane stackImg = new StackPane ();
            stackImg.setMinWidth (95);
            stackImg.getStyleClass ().add ("btnTicketProsEventImage");
            stackImg.getChildren ().add (imgEvt);
            VBox vbBtnTxt = JKLayout.getVBoxLeft (0, 0);

            Text txtName = JKText.getTxtWhWrap (event.getName (), JKText.FONT_B_SM, (w - 130), TextAlignment.LEFT);
            SimpleDateFormat sdf = new SimpleDateFormat ("dd MMM yyyy - HH:mm");

            Text txtDate = JKText.getTxtWh (sdf.format (event.getStartDate ()), JKText.FONT_B_XXSM);
            vbBtnTxt.getChildren ().addAll (txtName, JKNode.getVSpacer (), txtDate);
            HBox hbImgTxt = new HBox (JKLayout.sp);
            hbImgTxt.setStyle ("-fx-padding: 5px 5px 7px 0px;");
            hbImgTxt.getChildren ().addAll (stackImg, vbBtnTxt);
            btn.setGraphic (hbImgTxt);
            btn.setOnMouseReleased (new EventHandler () {
                @Override
                public void handle(Event evt) {
                    TicketProSale.getInstance ().setSelectedEvent (event);
                    setSalesUser ();
                }
            });
            Button btnMore = new Button ("more\ninfo");
            btnMore.setFont (JKText.FONT_B_XXSM);
            btnMore.setMaxSize ((((JKLayout.contentW - (2 * JKLayout.sp)) / 5) - JKLayout.sp + JKLayout.spNum), h);
            btnMore.setMinSize ((((JKLayout.contentW - (2 * JKLayout.sp)) / 5) - JKLayout.sp + JKLayout.spNum), h);
            btnMore.getStyleClass ().add ("btnTicketPros");
            btnMore.setOnMouseReleased (new EventHandler () {
                @Override
                public void handle(Event evt) {
                    TicketProUtil.getTicketProEventDetail (event.getEventId (), new TicketProUtil.TicketProEventDetailResult () {

                        @Override
                        public void tpEventDetailResult(TicketProsEventDetail tpEventDetailResult) {
                            if (tpEventDetailResult.isSuccess ()) {
                                StackPane moreInfo = getEventDetail (tpEventDetailResult);
                                JKiosk3.getMsgBox ().showMsgBox (event.getName (), tpEventDetailResult.getVenueName (), moreInfo);
                            } else {
                                JKiosk3.getMsgBox ().showMsgBox ("error", "no detail - show error", null);
                            }
                        }
                    });
                }
            });

            HBox hbEventButtons = JKLayout.getHBox (0, JKLayout.sp);
            hbEventButtons.getChildren ().addAll (btn, btnMore);

//            if (event.getEventId().equals("a6ecab39-fb12-9763-0fb1-56bb4261bde2")) {
            if (!event.isOpen ()) {
                btn.setDisable (true);
                stackImg.setOpacity (0.50);
                Text txtNotOpen = JKText.getTxtDk ("Booking Opens:", JKText.FONT_B_XSM);
                txtNotOpen.setStyle ("-fx-fill: #FEDA00;");
                txtNotOpen.setTextAlignment (TextAlignment.CENTER);
                Text txtDateOpen = JKText.getTxtDk (sdf.format (event.getOpenDate ()), JKText.FONT_B_SM);
                txtDateOpen.setStyle ("-fx-fill: #FEDA00;");
                txtDateOpen.setTextAlignment (TextAlignment.CENTER);
                VBox vbNotOpen = JKLayout.getVBox (0, JKLayout.spNum);
                vbNotOpen.getChildren ().addAll (txtNotOpen, txtDateOpen);
                StackPane.setAlignment (txtNotOpen, Pos.CENTER_LEFT);
                StackPane stackNotOpen = new StackPane ();
                stackNotOpen.getChildren ().addAll (btn, vbNotOpen);
                hbEventButtons.getChildren ().clear ();
                hbEventButtons.getChildren ().addAll (stackNotOpen, btnMore);
            }
//            if (event.getEventId().equals("3bfb5bda-f9b3-12da-a088-56bb29ecec2e")) {
            if (event.isSoldOut ()) {
                btn.setDisable (true);
                btnMore.setDisable (true);
                stackImg.setOpacity (0.20);
                HBox hbSO = JKLayout.getHBox (0, JKLayout.sp);
                hbSO.getChildren ().addAll (btn, btnMore);
                Text txtSO = JKText.getTxtDk ("Sold\nOut", JKText.FONT_B_XLG);
                txtSO.setStyle ("-fx-fill: red;");
                txtSO.setTextAlignment (TextAlignment.CENTER);
                txtSO.setTranslateX (JKLayout.sp);
                StackPane.setAlignment (txtSO, Pos.CENTER_LEFT);
                StackPane stackSO = new StackPane ();
                stackSO.getChildren ().addAll (hbSO, txtSO);
                hbEventButtons.getChildren ().clear ();
                hbEventButtons.getChildren ().add (stackSO);
            }

            btnList.add (hbEventButtons);
        }

        return btnList;
    }


    private StackPane getEventDetail(TicketProsEventDetail eventDetail) {
        Text txtSO = new Text ();
//        if (eventDetail.getEventId().equals("60bb87a7-209c-c1aa-69be-56b4503a6f42")) {
        if (eventDetail.isSoldOut ()) {
            txtSO = JKText.getTxtDk ("Sold\nOut", JKText.FONT_B_XLG);
            txtSO.setStyle ("-fx-fill: red; -fx-font-size: 150pt; -fx-opacity: 0.75;");
            txtSO.setTextAlignment (TextAlignment.CENTER);
            StackPane.setAlignment (txtSO, Pos.CENTER);
        }
        String imgUrl = eventDetail.getLargeImage ();

        SimpleDateFormat sdf = new SimpleDateFormat ("E dd MMM yyyy HH:mm");

        StringBuilder detail = new StringBuilder ();
        detail.append ("<html><body style='font-family: Tahoma; color: #002349; padding: 15px;'>");
        detail.append ("<p align='center'><img src='").append (imgUrl).append ("' align='center' height='150px' /></p>");
        detail.append ("<table>");
        detail.append ("<tr>");
        detail.append ("<td width='150px'>Event Date:</td>");
        detail.append ("<td>").append (sdf.format (eventDetail.getStartDate ())).append ("</td>");
        detail.append ("</tr>");
        detail.append ("<tr>");
        detail.append ("<td>Booking opens on:</td>");
        detail.append ("<td>").append (sdf.format (eventDetail.getOpenDate ())).append ("</td>");
        detail.append ("</tr>");
        detail.append ("<tr>");
        detail.append ("<td>Pricing:</td>");
        detail.append ("<td>").append (eventDetail.getPricing ()).append ("</td>");
        detail.append ("</tr>");
        detail.append ("</table>");
        detail.append ("<ul>");
        for (TicketProsSeatCategory c : eventDetail.getListSeatCategories ()) {
            detail.append ("<li>").append (c).append ("</li>");
        }
        detail.append ("</ul>");
        detail.append ("</body></html>");

        String evtDetail = detail.toString ();

        double width = MessageBox.getMsgWidth () - (4 * JKLayout.sp);

        WebView webView = new WebView ();
        webView.setMaxWidth (width - (4 * JKLayout.sp));
        webView.setMaxHeight (475);

        webView.getEngine ().loadContent (evtDetail);

        StackPane stackDetail = new StackPane ();
        stackDetail.getChildren ().addAll (webView, txtSO);
        return stackDetail;
    }

    private void setSalesUser() {
        JKiosk3.getSalesUserLogin ().showUserLogin (new SalesUserLoginResult () {
            @Override
            public void onDone() {
                onSelectEvent ();
            }
        });
    }

    private void onSelectEvent() {
        TicketProUtil.getTicketProEventDetail (TicketProSale.getInstance ().getSelectedEvent ().getEventId (), new TicketProUtil.TicketProEventDetailResult () {

            @Override
            public void tpEventDetailResult(TicketProsEventDetail tpEventDetailResult) {
                if (tpEventDetailResult.isSuccess ()) {
                    TicketProSale.getInstance ().setSelectedEventDetail (tpEventDetailResult);
                    SceneSales.clearAndChangeContent (new TicketProTickets ());
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Error",!tpEventDetailResult.getAeonErrorText ().isEmpty () ?
                                    "A" + tpEventDetailResult.getAeonErrorCode () + " - " + tpEventDetailResult.getAeonErrorText () :
                                    "B" + tpEventDetailResult.getErrorCode () + " - " + tpEventDetailResult.getErrorText (), null);
                }
            }
        });
    }
}
