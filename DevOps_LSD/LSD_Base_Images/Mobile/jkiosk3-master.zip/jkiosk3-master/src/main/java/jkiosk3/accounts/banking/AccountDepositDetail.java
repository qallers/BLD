package jkiosk3.accounts.banking;

import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Valerie
 */
public class AccountDepositDetail {

    public static List<AccountType> getAccountTypeList() {
        List<AccountType> listAccTypes = new ArrayList<>();

        try {
            File file = new File(JK3Config.getMediaBankingFile());
            Element listAccounts = new SAXBuilder().build(file).getRootElement().getChild("accounts");
            for (Object acc : listAccounts.getChildren("accountType")) {
                Element accType = (Element) acc;

                AccountType accountType = new AccountType();
                accountType.setAccountPrefix(accType.getChildTextTrim("accountPrefix"));

                for (Object dep : accType.getChildren("depositType")) {
                    Element depType = (Element) dep;

                    DepositType depositType = new DepositType();
                    depositType.setType(depType.getChildTextTrim("type"));

                    for (Object b : depType.getChildren("bank")) {
                        Element bnk = (Element) b;

                        Bank bank = new Bank();
                        bank.setBankName(bnk.getChildTextTrim("bankName"));
                        bank.setAccountHolder(bnk.getChildTextTrim("accountHolder"));
                        bank.setAccountNumber(bnk.getChildTextTrim("accountNumber"));
                        bank.setBranchCode(bnk.getChildTextTrim("branchCode"));

                        depositType.getListBanks().add(bank);
                    }

                    accountType.getListDepositTypes().add(depositType);
                }
                listAccTypes.add(accountType);
            }
        } catch (JDOMException | IOException e) {
            JKiosk3.getMsgBox().showMsgBox("Bank Accounts", e.getMessage(), null);
        }

        return listAccTypes;
    }
}
