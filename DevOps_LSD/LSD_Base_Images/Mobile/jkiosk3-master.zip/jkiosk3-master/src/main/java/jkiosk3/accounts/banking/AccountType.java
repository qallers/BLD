package jkiosk3.accounts.banking;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Valerie
 */
public class AccountType {

    private String accountPrefix;
    private List<DepositType> listDepositTypes = new ArrayList<>();;

    public String getAccountPrefix() {
        return accountPrefix;
    }

    public void setAccountPrefix(String accountPrefix) {
        this.accountPrefix = accountPrefix;
    }

    public List<DepositType> getListDepositTypes() {
        return listDepositTypes;
    }

    public void setListDepositTypes(List<DepositType> listDepositTypes) {
        this.listDepositTypes = listDepositTypes;
    }
}
