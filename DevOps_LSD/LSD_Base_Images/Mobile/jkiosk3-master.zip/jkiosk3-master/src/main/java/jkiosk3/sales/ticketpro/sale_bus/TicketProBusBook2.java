package jkiosk3.sales.ticketpro.sale_bus;

import aeonticketpros.TicketProsCart;
import aeonticketpros.TicketProsCartClearReq;
import aeonticketpros.bus.TicketProBusCartClearResp;
import aeonticketpros.bus.TicketProBusRoute;
import aeonticketpros.bus.TicketProBusRouteBookReq;
import aeonticketpros.bus.TicketProBusRouteBookResp;
import aeonticketpros.bus.TicketProBusSeat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.ticketpro.TicketProBusSale;
import jkiosk3.sales.ticketpro.TicketProUtilBus;
import jkiosk3.users.UserUtil;

public class TicketProBusBook2 extends Region {

    private final static Logger logger = Logger.getLogger (TicketProBusBook2.class.getName ());
    //
    private final List<TicketProBusRoute> listRoutes;
    private TicketProsCart busCart;
    private TicketProBusRoute routeSelected;
    private TicketProBusRouteBookReq request;
    private List<GridPane> listRouteGrids;
    private ToggleGroup toggleRoute;
    private final int routeCount;

    public TicketProBusBook2() {
        this.listRoutes = TicketProBusSale.getInstance ().getListRoutes ().getListBusRoutes ();
        routeCount = listRoutes.size ();
        toggleRoute = new ToggleGroup ();

        Collections.sort (listRoutes, new Comparator<TicketProBusRoute> () {
            @Override
            public int compare(TicketProBusRoute o1, TicketProBusRoute o2) {
                return ((int) o1.getFare () * 100) - ((int) o2.getFare () * 100);
            }
        });

        if (TicketProBusSale.getInstance ().getBusSaleCart () == null) {
            TicketProUtilBus.createTicketProBusCart (new TicketProUtilBus.TicketProBusCreateCartResult () {

                @Override
                public void tpCreateBusCartResult(TicketProsCart tpCreateCart) {
                    if (tpCreateCart.isSuccess ()) {
                        TicketProBusSale.getInstance ().setBusSaleCart (tpCreateCart);
                        busCart = tpCreateCart;
                        addRouteGridsAndContinue ();
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("Failed to Create Cart", "", null);
                        SceneSales.clearAndChangeContent (new TicketProBusBook1 ());
                    }
                }
            });
        } else {
            busCart = TicketProBusSale.getInstance ().getBusSaleCart ();
            addRouteGridsAndContinue ();
        }
    }

    private void addRouteGridsAndContinue() {
        listRouteGrids = new ArrayList<> ();
        for (TicketProBusRoute r : listRoutes) {
            GridPane gridRoute = makeRouteGrid (r);
            listRouteGrids.add (gridRoute);
        }
        getPage2Layout ();
    }

    private VBox getPage2Layout() {
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().addAll (getRouteSelectGrid (), getNav ());
        getChildren ().add (vb);
        return vb;
    }

    private GridPane getRouteSelectGrid() {

        VBox vbHead = JKNode.getPutcoHeader ("Bus Ticket Booking - Step 2");

        Label lblDeparture = JKText.getLblDk ("Departure", JKText.FONT_B_XXSM);
        Label lblDestination = JKText.getLblDk ("Destination", JKText.FONT_B_XXSM);

        String departure = listRoutes.get (0).getLocationDeparture ();
        String destination = listRoutes.get (0).getLocationDestination ();
        Text txtDeparture = JKText.getTxtDk (departure, JKText.FONT_B_XXSM);
        txtDeparture.setWrappingWidth ((3 * JKLayout.btnSmW) + (2 * JKLayout.sp));
        txtDeparture.setTextAlignment (TextAlignment.RIGHT);
        Text txtDestination = JKText.getTxtDk (destination, JKText.FONT_B_XXSM);
        txtDestination.setWrappingWidth ((3 * JKLayout.btnSmW) + (2 * JKLayout.sp));
        txtDestination.setTextAlignment (TextAlignment.RIGHT);

        GridPane grid = JKLayout.getGridContent2Col (0.25, 0.75, HPos.RIGHT);

        grid.add (vbHead, 0, 0, 2, 1);
        grid.addRow (1, lblDeparture, txtDeparture);
        grid.addRow (2, lblDestination, txtDestination);
        grid.add (JKNode.createGridSpanSep (2), 0, 3, 2, 1);

        int rowCount = 4;
        for (int i = 0; i < routeCount; i++) {
            grid.add (listRouteGrids.get (i), 0, rowCount + i, 2, 1);
        }

        return grid;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();

        nav.getBtnBack ().setDisable (false);
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new TicketProBusBook1 ());
            }
        });

        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndShowFavourites ();
            }
        });

        nav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (request != null) {
                    showConfirmation ();
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("No Booking Selected", "Please select a booking", null);
                }
            }
        });
        return nav;
    }

    private GridPane makeRouteGrid(final TicketProBusRoute route) {
        final GridPane gridRoute = makeRouteItemGrid ();
        gridRoute.setId (route.getRouteId ());
        gridRoute.setVgap (JKLayout.sp);
        gridRoute.setTranslateX (2 * JKLayout.sp);

        Label lblTravelClass = JKText.getLblDk (route.getRouteCode (), JKText.FONT_B_XXSM);
        String strDays = "";
        if (route.getTravelClass ().equalsIgnoreCase ("1")) {
            strDays = " day";
        } else {
            strDays = " days";
        }
        Text txtTravelClass = JKText.getTxtDk (route.getTravelClass () + strDays, JKText.FONT_B_XXSM);
        HBox hbTravelClass = JKLayout.getHBox (0, 0);
        hbTravelClass.setTranslateX (JKLayout.sp);
        hbTravelClass.getChildren ().addAll (lblTravelClass, JKNode.getHSpacer (), txtTravelClass);

        Label lblFare = JKText.getLblDk ("Fare", JKText.FONT_B_XXSM);
        Text txtFare = JKText.getTxtDk (JKText.getDeciFormat (route.getFare ()), JKText.FONT_B_XXSM);
        HBox hbFare = JKLayout.getHBox (0, 0);
        hbFare.getChildren ().addAll (lblFare, JKNode.getHSpacer (), txtFare);

//        Label lblSeats = JKText.getLblDk("Tickets", JKText.FONT_B_XXSM);
//        final TextField txtSeats = new TextField();
//        txtSeats.setMaxWidth(65);
//        txtSeats.setAlignment(Pos.CENTER_RIGHT);
//        // do not use original list processed
//        // use results of seats after removing in next step
//        if (TicketProBusSale.getInstance().getSelectedBusSeats() != null) {
//            int seatCountSaved = 0;
//            for (TicketProBusSeat seat : TicketProBusSale.getInstance().getSelectedBusSeats()) {
//                if (seat.getPrice() == (route.getFare())) {
//                    seatCountSaved++;
//                }
//            }
//            seatCount = seatCountSaved;
//            if (seatCount > 0) {
//                txtSeats.setText(Integer.toString(seatCount));
//                addBooking(route.getRouteId());
//            }
//        }
//        txtSeats.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getNumPad().showNumPad(txtSeats, "Tickets", "", new NumberPadResult() {
//
//                    @Override
//                    public void onDone(String value) {
//                        if (value.trim().equals("") || value.trim().equals("0")) {
//                            removeBooking(route.getRouteId());
//                            txtSeats.setText("");
//                        } else if (isValidSeatEntry(txtSeats, value)) {
//                            addBooking(route.getRouteId());
//                        }
//                    }
//                });
//            }
//        });
//
//        HBox hbSeats = JKLayout.getHBox(0, 0);
//        hbSeats.getChildren().addAll(lblSeats, JKNode.getHSpacer(), txtSeats);

        final RadioButton radRoute = new RadioButton ();
        radRoute.setToggleGroup (toggleRoute);
        radRoute.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (radRoute.isSelected ()) {
                    System.out.println ("radio clicked, isSelected is TRUE");
                    routeSelected = route;
                    addBooking (route.getRouteId ());
                } else {
                    System.out.println ("radio clicked, isSelected is FALSE");
                }
            }
        });

        gridRoute.addRow (0, hbTravelClass, makeSeparatorLabel (), hbFare, makeSeparatorLabel (), radRoute);
//        gridRoute.addRow(0, hbTravelClass, makeSeparatorLabel(), hbFare, makeSeparatorLabel(), hbSeats);
        gridRoute.add (JKNode.createGridSpanSep (2), 0, 1, 5, 1);

        return gridRoute;
    }

    private Label makeSeparatorLabel() {
        Label lblSep = JKText.getLblDk (":", JKText.FONT_B_XXSM);
        return lblSep;
    }

    private GridPane makeRouteItemGrid() {
        double gridWidth = JKLayout.contentW - (10 * JKLayout.sp);

        GridPane grid = new GridPane ();
        grid.setMaxWidth (gridWidth);
        grid.setMinWidth (gridWidth);
        grid.setHgap (1 * JKLayout.sp);

        ColumnConstraints col0 = new ColumnConstraints ();
        col0.setMaxWidth (gridWidth * 0.30);
        col0.setMinWidth (gridWidth * 0.30);
        col0.setHalignment (HPos.LEFT);
        ColumnConstraints col1 = new ColumnConstraints ();
        col1.setMaxWidth (gridWidth * 0.10);
        col1.setMinWidth (gridWidth * 0.10);
        col1.setHalignment (HPos.CENTER);
        ColumnConstraints col2 = new ColumnConstraints ();
        col2.setMaxWidth (gridWidth * 0.30);
        col2.setMinWidth (gridWidth * 0.30);
        col2.setHalignment (HPos.LEFT);
        ColumnConstraints col3 = new ColumnConstraints ();
        col3.setMaxWidth (gridWidth * 0.10);
        col3.setMinWidth (gridWidth * 0.10);
        col3.setHalignment (HPos.CENTER);
        ColumnConstraints col4 = new ColumnConstraints ();
        col4.setMaxWidth (gridWidth * 0.20);
        col4.setMinWidth (gridWidth * 0.20);
        col4.setHalignment (HPos.CENTER);

        grid.getColumnConstraints ().addAll (col0, col1, col2, col3, col4);
        return grid;
    }

//    private void removeBooking(String routeId) {
//        List<TicketProBusRouteBookReq> listTmp = new ArrayList<>();
//        if (!listBookings.isEmpty()) {
//            listTmp.addAll(listBookings);
//            for (TicketProBusRouteBookReq r : listTmp) {
//                if (r.getRouteId().equalsIgnoreCase(routeId)) {
//                    listTmp.remove(r);
//                    break;
//                }
//            }
//        }
//        listBookings = listTmp;
//    }

    private void addBooking(String routeId) {
        request = null;
//        List<TicketProBusRouteBookReq> listTmp = new ArrayList<>();
//        if (!listBookings.isEmpty()) {
//            listTmp.addAll(listBookings);
//            for (TicketProBusRouteBookReq r : listTmp) {
//                if (r.getRouteId().equalsIgnoreCase(routeId)) {
//                    listTmp.remove(r);
//                    break;
//                }
//            }
//        }

        TicketProBusRouteBookReq req = new TicketProBusRouteBookReq ();
        req.setCartId (busCart.getCartId ());
        req.setRouteId (routeId);
        req.setQuantity (1);
        request = req;

        System.out.println ("\n*******************************");
        System.out.println (" >>>  After adding new booking >>>");
        System.out.println ("      cartId   = " + req.getCartId ());
        System.out.println ("      routeId  = " + req.getRouteId ());
        System.out.println ("      quantity = " + req.getQuantity ());
//        for (TicketProBusRouteBookReq r : listTmp) {
//            System.out.println("---------------------------------");
//            System.out.println("cartId    = " + r.getCartId());
//            System.out.println("routeId   = " + r.getRouteId());
//            System.out.println("seatCount = " + r.getQuantity());
//            System.out.println("---------------------------------");
//        }
        System.out.println ("*******************************");
//        listBookings = listTmp;
//        System.out.println("count after add : " + listBookings.size());
    }

//    private void processBookingList(int count) {
//        final TicketProBusRouteBookReq request = listBookings.get(count);
//        StringBuilder sb = new StringBuilder();
//        sb.append("\r\n").append("  >>>   Processing booking   >>>");
//        sb.append("\r\n").append("booking position in list         : ").append(count);
//        sb.append("\r\n").append("id of current request            : ").append(request.getRouteId());
//        sb.append("\r\n").append("ticket count for current request : ").append(request.getQuantity());
//        sb.append("\r\n");
//        logger.info(sb.toString());
//        TicketProUtilBus.getTicketProBusRouteBooking(request, new TicketProUtilBus.TicketProBusRouteBookResult() {
//            @Override
//            public void tpBusRouteBookResult(TicketProBusRouteBookResp tpBooking) {
//                if (tpBooking.isSuccess()) {
////                    if (tpBooking.getQuantity() > 15) {
////                        JKiosk3.getMsgBox().showMsgBox("Putco Error", "\nBooking exceeds maximum of 15 tickets"
////                                + "\n\nPlease ensure that total number of tickets requested does not exceed this limit\n", null,
////                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
////
////                                    @Override
////                                    public void onOk() {
////                                        clearCartOnError();
////                                    }
////
////                                    @Override
////                                    public void onCancel() {
////                                        //
////                                    }
////                                });
////                    } else {
//                    logger.info(("Booking successful : ").concat(Integer.toString(tpBooking.getQuantity())));
//                    bookingCount++;
//                    if (bookingCount < listBookings.size()) {
//                        processBookingList(bookingCount);
//                    } else {
//                        TicketProBusSale.getInstance().setTicketProBusRouteBooking(tpBooking);
//                        TicketProBusSale.getInstance().setSelectedBusSeats(tpBooking.getListSeats());
//                        SceneSales.clearAndChangeContent(new TicketProBusBook3());
//                    }
////                    }
//                } else {
//                    logger.info(("Booking failed : ").concat(Integer.toString(tpBooking.getErrorCode())).concat(" - ").concat(tpBooking.getErrorText()));
//                    JKiosk3.getMsgBox().showMsgBox("Putco Error", tpBooking.getErrorCode() + "\n\n" + tpBooking.getErrorText(), null,
//                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
//
//                        @Override
//                        public void onOk() {
//                            clearCartOnError();
//                        }
//
//                        @Override
//                        public void onCancel() {
//                            //
//                        }
//                    });
//                }
//            }
//        });
//    }

    private void makeBooking() {
        StringBuilder sb = new StringBuilder ();
        sb.append ("\r\n").append ("  >>>   Processing booking   >>>");
//        sb.append("\r\n").append("booking position in list         : ").append(count);
        sb.append ("\r\n").append ("id of current cart               : ").append (request.getCartId ());
        sb.append ("\r\n").append ("id of current request            : ").append (request.getRouteId ());
        sb.append ("\r\n").append ("ticket count for current request : ").append (request.getQuantity ());
        sb.append ("\r\n");
        logger.info (sb.toString ());
        TicketProUtilBus.getTicketProBusRouteBooking (request, new TicketProUtilBus.TicketProBusRouteBookResult () {
            @Override
            public void tpBusRouteBookResult(TicketProBusRouteBookResp tpBooking) {
                if (tpBooking.isSuccess ()) {
//                    if (tpBooking.getQuantity() > 15) {
//                        JKiosk3.getMsgBox().showMsgBox("Putco Error", "\nBooking exceeds maximum of 15 tickets"
//                                + "\n\nPlease ensure that total number of tickets requested does not exceed this limit\n", null,
//                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
//
//                                    @Override
//                                    public void onOk() {
//                                        clearCartOnError();
//                                    }
//
//                                    @Override
//                                    public void onCancel() {
//                                        //
//                                    }
//                                });
//                    } else {
                    logger.info (("Booking successful : ").concat (Integer.toString (tpBooking.getQuantity ())));
//                    bookingCount++;
//                    if (bookingCount < listBookings.size()) {
//                        processBookingList(bookingCount);
//                    } else {
                    TicketProBusSale.getInstance ().setTicketProBusRouteBooking (tpBooking);
                    TicketProBusSale.getInstance ().setSelectedBusSeats (tpBooking.getListSeats ());
//                        SceneSales.clearAndChangeContent(new TicketProBusBook3());
                    SceneSales.clearAndChangeContent (new TicketProBusBook4 ());
//                    }
//                    }
                } else {
                    logger.info (("Booking failed : ").concat (Integer.toString (tpBooking.getErrorCode ())).concat (" - ").concat (tpBooking.getErrorText ()));
                    JKiosk3.getMsgBox ().showMsgBox ("Putco Error", !tpBooking.getAeonErrorText ().isEmpty () ?
                                    "A" + tpBooking.getAeonErrorCode () + " - " + tpBooking.getAeonErrorText () :
                                    "B" + tpBooking.getErrorCode () + " - " + tpBooking.getErrorText (), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    clearCartOnError ();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
//    }

    }

    private void clearCartOnError() {
        TicketProsCartClearReq req = new TicketProsCartClearReq ();
        req.setCartId (TicketProBusSale.getInstance ().getBusSaleCart ().getCartId ());
        req.setInventoryId ("");
        TicketProUtilBus.clearBusCart (req, new TicketProUtilBus.TicketProBusClearCartResult () {

            @Override
            public void tpClearBusCartResult(TicketProBusCartClearResp tpClearBusCartResp) {
//                TicketProBusSale.getInstance().getListRouteSoldOut().add(request.getRouteId());
//                SceneSales.clearAndChangeContent(new TicketProBusBook2());
                SceneSales.clearAndShowFavourites ();
            }
        });
    }

//    private boolean isValidSeatEntry(TextField txtFld, String input) {
//        if (!input.matches("\\d+")) {
//            JKiosk3.getMsgBox().showMsgBox("Invalid Input", "Must be a whole numeric number", null);
//            txtFld.setText("");
//            return false;
//        }
//        try {
//            seatCount = Integer.parseInt(input);
//        } catch (NumberFormatException nfe) {
//            System.out.println("failed - NumberFormatException");
//            txtFld.setText("");
//            return false;
//        }
//        return true;
//    }

    private void showConfirmation() {

        Label lblDepart = JKText.getLblDk ("Departure", JKText.FONT_B_XSM);
        Label lblDest = JKText.getLblDk ("Destination", JKText.FONT_B_XSM);
        Label lblDays = JKText.getLblDk ("Days", JKText.FONT_B_XSM);
        Label lblAmount = JKText.getLblDk ("Amount", JKText.FONT_B_XSM);

        Text txtDepart = JKText.getTxtDk (listRoutes.get (0).getLocationDeparture (), JKText.FONT_B_XSM);
        txtDepart.setWrappingWidth (MessageBox.getMsgWidth () * 0.75);
        txtDepart.setTextAlignment (TextAlignment.RIGHT);
        Text txtDest = JKText.getTxtDk (listRoutes.get (0).getLocationDestination (), JKText.FONT_B_XSM);
        txtDest.setWrappingWidth (MessageBox.getMsgWidth () * 0.75);
        txtDest.setTextAlignment (TextAlignment.RIGHT);
        String strDays = "";
        if (routeSelected.getTravelClass ().equalsIgnoreCase ("1")) {
            strDays = " day";
        } else {
            strDays = " days";
        }
        Text txtDays = JKText.getTxtDk (routeSelected.getTravelClass () + strDays, JKText.FONT_B_22);
        Text txtAmount = JKText.getTxtDk (JKText.getDeciFormat (routeSelected.getFare ()), JKText.FONT_B_MID);

        GridPane grid = JKLayout.getSummaryGrid2Col (0.25, 0.75);
        grid.setVgap (JKLayout.sp);
        grid.addRow (1, lblDepart, txtDepart);
        grid.addRow (2, lblDest, txtDest);
        grid.addRow (3, lblDays, txtDays);
        grid.addRow (5, lblAmount, txtAmount);

        JKiosk3.getMsgBox ().showMsgBox ("Putco Ticket", "Please confirm that the details shown are CORRECT", grid,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        makeBooking ();
                    }

                    @Override
                    public void onCancel() {
                        // do nothing - return to screen to select trip
                    }
                });
    }
}
