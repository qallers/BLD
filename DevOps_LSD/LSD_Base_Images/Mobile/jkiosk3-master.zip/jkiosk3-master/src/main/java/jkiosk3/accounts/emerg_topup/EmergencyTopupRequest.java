package jkiosk3.accounts.emerg_topup;

import aeonemergencytopup.Account;
import aeonemergencytopup.LoanApplicationReq;
import aeonemergencytopup.LoanApplicationResp;
import aeonemergencytopup.LoanConfirmReq;
import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.store.JKOptions;
import jkiosk3.users.CurrentUser;

/**
 *
 * @author Valerie
 */
public class EmergencyTopupRequest extends Region {

    private VBox vbContent;
    private final Account selectAcc;
    private LoanApplicationResp loanAppResp;
    private double amount;
    private GridPane gridReq;
    private TextField txtAmt;

    public EmergencyTopupRequest(Account selectedAccount) {
        this.selectAcc = selectedAccount;
        EmergencyTopup.getInstance().setAccount(selectAcc);
        EmergencyTopup.getInstance().setUser(CurrentUser.getUser());

        getChildren().add(getEmergencyTopupRequestLayout());
        getAccountStatus();
    }

    private VBox getEmergencyTopupRequestLayout() {
        VBox vbLayout = JKLayout.getVBox(0, JKLayout.spNum);
        vbLayout.getChildren().add(showEmergencyTopupRequest());
        vbLayout.getChildren().add(getControlButtons());
        return vbLayout;
    }

    private Group showEmergencyTopupRequest() {
        vbContent = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
        vbContent.getChildren().addAll(JKNode.createContentSep(), getRequestGrid());

        return JKNode.getContentGroup(vbContent);
    }

    private void getAccountStatus() {
        LoanApplicationReq req = new LoanApplicationReq();
        req.setReference(SalesUtil.getUniqueRef());
        req.setAccount(selectAcc);
        EmergencyTopup.getInstance().setLoanReq(req);

        EmergencyTopupUtil.getLoanApplication(req, new EmergencyTopupUtil.LoanApplicationResult() {

            @Override
            public void loanApplicationResult(LoanApplicationResp loanApplication) {
                if (loanApplication.isSuccess()) {
                    if (loanApplication.isQualify()) {
                        loanAppResp = loanApplication;
                        EmergencyTopup.getInstance().setLoanResp(loanAppResp);
                        getStatusGrid();
                        gridReq.add(getAmountButtons(), 0, 3, 2, 1);
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Account Error", "This Account does not qualify for Emergency Topup", null);
                        SceneEmergencyTopup.getVbEmergTopContent().getChildren().clear();
                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Account Status Error",
                            loanApplication.getErrorCode() + " - " + loanApplication.getErrorText(), null);
                    SceneEmergencyTopup.getVbEmergTopContent().getChildren().clear();
                }
            }
        });
    }

    private void getStatusGrid() {
        GridPane gridStatus = JKLayout.getContentGridInner2Col(0.5, 0.5, HPos.RIGHT);

        Label lblAcc = JKText.getLblDk("Request to Topup Account", JKText.FONT_B_XSM);
        Label lblAvailable = JKText.getLblDk("Amount Available", JKText.FONT_B_XSM);
        Label lblPayback = JKText.getLblDk("Payback Period (days)", JKText.FONT_B_XSM);
        Label lblFeeNote = JKText.getLblDk("* Please note : a monthly fee of " + "R " + JKText.getDeciFormat(loanAppResp.getFee())
                + " will be charged for ETU facility.\n   See T & C.", JKText.FONT_B_XXSM);
        Label lblContinue = JKText.getLblDk("Do you wish to continue?", JKText.FONT_B_XSM);

        Text txtAcc = JKText.getTxtDk(EmergencyTopup.getInstance().getAccount().getAccountNumber(), JKText.FONT_B_SM);
        Text txtAvailable = JKText.getTxtDk("R " + JKText.getDeciFormat(loanAppResp.getQualifyAmount()), JKText.FONT_B_XSM);
        Text txtPayback = JKText.getTxtDk(Integer.toString(loanAppResp.getPaybackPeriod()), JKText.FONT_B_XSM);

        Button btnYes = JKNode.getBtnPopup("yes");
        btnYes.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                gridReq.setDisable(false);
            }
        });
        Button btnNo = JKNode.getBtnPopup("no");
        btnNo.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneEmergencyTopup.getVbEmergTopContent().getChildren().clear();
            }
        });
        HBox hbBtns = JKLayout.getHBox(0, JKLayout.sp);
        hbBtns.getChildren().addAll(JKNode.getHSpacer(), btnYes, btnNo);

        gridStatus.addRow(0, lblAcc, txtAcc);
        gridStatus.addRow(1, lblAvailable, txtAvailable);
        gridStatus.addRow(2, lblPayback, txtPayback);
        gridStatus.add(lblFeeNote, 0, 4, 2, 1);
        gridStatus.addRow(5, lblContinue, hbBtns);
        gridStatus.addRow(6, JKNode.getHSpacer());

        vbContent.getChildren().add(0, gridStatus);
    }

    private GridPane getRequestGrid() {

        Label lblUser = JKText.getLblDk("Requested by", JKText.FONT_B_XSM);
        Label lblAmt = JKText.getLblDk("Amount requested", JKText.FONT_B_XSM);

        Text txtUser = JKText.getTxtDk(CurrentUser.getUser().getUserName(), JKText.FONT_B_XSM);

        txtAmt = new TextField();
        txtAmt.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!JKOptions.getOptions().isKeyboard()) {
                    JKiosk3.getNumPad().showNumPad(new TextField(), "Enter Amount", "", new NumberPadResult() {
                        @Override
                        public void onDone(String value) {
                            if (validateAmount(value)) {
                                txtAmt.setText(JKText.getDeciFormat(amount));
                            }
                        }
                    });
                }
            }
        });

        gridReq = JKLayout.getContentGridInner2Col(0.5, 0.5, HPos.RIGHT);

        gridReq.addRow(0, lblUser, txtUser);
        gridReq.addRow(1, lblAmt, txtAmt);

        gridReq.setDisable(true);

        return gridReq;
    }

    private FlowPane getAmountButtons() {

        Double[] btnAmts = {500.0, 1000.0, 1500.0, 2000.0};

        List<Button> btnList = new ArrayList<>();
        for (final double d : btnAmts) {
            final Button btn = JKNode.getBtnSm("R " + JKText.getDeciFormatNoDecimals(d));
            btn.setFont(JKText.FONT_B_SM);
            if (d > loanAppResp.getQualifyAmount()) {
                btn.setDisable(true);
            }
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    if (validateAmount(btn.getText().substring(2).replaceAll(" ", ""))) {
                        txtAmt.setText(JKText.getDeciFormat(amount));
                    }
                }
            });
            btnList.add(btn);
        }

        Button btnOther = JKNode.getBtnSmDbl("Other Amount");
        btnOther.setFont(JKText.FONT_B_SM);
        btnOther.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(new TextField(), "Enter Amount", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        if (validateAmount(value)) {
                            txtAmt.setText(JKText.getDeciFormat(amount));
                        }
                    }
                });
            }
        });
        HBox hbOther = JKLayout.getHBox(0, 0);
        hbOther.setPrefWidth(JKLayout.contentW - (2 * JKLayout.sp));
        hbOther.getChildren().addAll(JKNode.getHSpacer(), btnOther, JKNode.getHSpacer());

        FlowPane flow = new FlowPane(JKLayout.sp, JKLayout.sp);
        flow.setMaxWidth(JKLayout.contentW - (2 * JKLayout.sp));
        flow.setPrefWrapLength(JKLayout.contentW - (2 * JKLayout.sp));
        flow.getChildren().addAll(btnList);
        flow.getChildren().add(hbOther);

        return flow;
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons();

        ctrlBtns.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (validateEntry()) {
                    LoanConfirmReq confReq = new LoanConfirmReq();
                    confReq.setReference(loanAppResp.getReference());
                    confReq.setAccountId(loanAppResp.getAccountId());
                    confReq.setAmountRequested(amount);
                    confReq.setQualifyAmount(loanAppResp.getQualifyAmount());
                    confReq.setTransRef(loanAppResp.getTransRef());
                    confReq.setAcceptByUser("1");
                    EmergencyTopup.getInstance().setConfReq(confReq);

                    SceneEmergencyTopup.getVbEmergTopContent().getChildren().clear();
                    SceneEmergencyTopup.getVbEmergTopContent().getChildren().add(new EmergencyTopupConfirm());
                }
            }
        });
        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneEmergencyTopup.getVbEmergTopContent().getChildren().clear();
            }
        });

        return ctrlBtns;
    }

    private boolean validateAmount(String amtRequested) {
        if (amtRequested == null || amtRequested.isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Amount Requested", "Please select or enter an amount", null);
            return false;
        } else {
            try {
                amount = Double.parseDouble(amtRequested);
                if (amount <= 0) {
                    JKiosk3.getMsgBox().showMsgBox("Amount Requested", "Please enter a positive amount greater than zero", null);
                    return false;
                }
            } catch (NumberFormatException nfe) {
                JKiosk3.getMsgBox().showMsgBox("Amount Requested", "Please select or enter a valid amount", null);
                return false;
            }
        }
        return true;
    }

    private boolean validateEntry() {
        if (amount == 0) {
            JKiosk3.getMsgBox().showMsgBox("Amount", "Amount cannot be zero", null);
            return false;
        }
        if (amount > (loanAppResp.getQualifyAmount())) {
            JKiosk3.getMsgBox().showMsgBox("Amount", "Amount may not exceed Amount Available", null);
            return false;
        }
        return true;
    }
}
