package jkiosk3.store;

import MagCard.MagEncoders;
import java.io.Serializable;

/**
 *
 * @author Val
 */
public class StoreJKCardReader implements Serializable {

    private boolean magCardRead = false;
    private boolean magCardWrite = false;
    private String magCardPort = "COM3";
    private int magCardBaud = 9600;
//    private String magCardType = "Loma MR-3";
    private MagEncoders magCardType = MagEncoders.LOMAMR3;

    public int getMagCardBaud() {
        return magCardBaud;
    }

    public void setMagCardBaud(int magCardBaud) {
        this.magCardBaud = magCardBaud;
    }

    public String getMagCardPort() {
        return magCardPort;
    }

    public void setMagCardPort(String magCardPort) {
        this.magCardPort = magCardPort;
    }

    public boolean isMagCardRead() {
        return magCardRead;
    }

    public void setMagCardRead(boolean magCardRead) {
        this.magCardRead = magCardRead;
    }

//    public String getMagCardType() {
//        return magCardType;
//    }
//
//    public void setMagCardType(String magCardType) {
//        this.magCardType = magCardType;
//    }
//    
    public MagEncoders getMagCardType() {
        return magCardType;
    }

    public void setMagCardType(MagEncoders magCardType) {
        this.magCardType = magCardType;
    }

    public boolean isMagCardWrite() {
        return magCardWrite;
    }

    public void setMagCardWrite(boolean magCardWrite) {
        this.magCardWrite = magCardWrite;
    }
}
