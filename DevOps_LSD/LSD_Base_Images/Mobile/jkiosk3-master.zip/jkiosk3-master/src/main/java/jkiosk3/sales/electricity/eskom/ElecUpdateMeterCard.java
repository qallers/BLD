package jkiosk3.sales.electricity.eskom;

import aeonelectricity.ElectricityConfirmation;
import aeonelectricity.ElectricityConnection;
import aeonelectricity.ElectricityMeter;

import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.MagCardData;
import jkiosk3.printing.PrintUtil;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.electricity.ElecConfirm;
import jkiosk3.sales.electricity.ElecEnterMeter;
import jkiosk3.sales.electricity.ElecEnterMeterResult;
import jkiosk3.sales.electricity.ElecShareBtnsLessMore;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.store.JKCardReader;
import jkiosk3.users.UserUtil;

/**
 * @author valerie
 */
public class ElecUpdateMeterCard extends Region {

    private final ElectricityProvider provider;
    private ElecEnterMeter gMeter;
    private ElecShareBtnsLessMore btnsLessMore;
    private String meterNum;
    private String sgc;
    private String tt;
    private String ti;
    private String krn;
    private String alg;

    public ElecUpdateMeterCard(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;
        getChildren ().add (getMeterNumberEntry ());
    }

    private VBox getMeterNumberEntry() {
        gMeter = new ElecEnterMeter (provider, ElectricityUtil.ELEC_UPDATE_M_CARD, new ElecEnterMeterResult () {
            @Override
            public void onDone() {
                if (gMeter.isMagEntry ()) {
                    System.out.println ("onDone : meter number entered : " + gMeter.getMeterNum ());
                    System.out.println ("onDone : did we read mag card? : " + gMeter.isMagEntry ());
                }
            }
        });
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().addAll (gMeter, getElecSaleCtrls ());
        return vb;
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        btnsLessMore = new ElecShareBtnsLessMore ();

        btnsLessMore.getBtnAccept ().setDisable (false);
        btnsLessMore.getBtnAccept ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                if (validateInput ()) {
                    makeElectricityConnection ();
                }
            }
        });
        btnsLessMore.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });

        return btnsLessMore;
    }

    private void makeElectricityConnection() {
        final ElectricityMeter meter = new ElectricityMeter ();
        if (gMeter.isMagEntry ()) {
            meter.setTrack2data (meterNum);
            meter.setMeterSgc ("");
            meter.setMeterTt ("");
            meter.setMeterTi ("");
            meter.setMeterKrn ("");
            meter.setMeterAlg ("");
        } else {
            meter.setMeterNum (meterNum);
            meter.setMeterSgc (sgc);
            meter.setMeterTt (tt);
            meter.setMeterTi (ti);
            meter.setMeterKrn (krn);
            meter.setMeterAlg (alg);
        }

        String transType = provider.getTransactionType ();
        ElectricityUtil.getElectricityConfirmation (transType, meter, 0, true, new ElectricityUtil.ElectricityConfirm () {
            @Override
            public void electricityConfirm(ElectricityConnection connect, final ElectricityConfirmation confirm) {
                if (confirm.isSuccess ()) {
                    ElecConfirm confirmGrid = new ElecConfirm (confirm, meter, 0, ElectricityUtil.ELEC_UPDATE_M_CARD);
                    JKiosk3.getMsgBox ().showMsgBox ("Electricity Meter Confirmation", "Update Meter Card", confirmGrid,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    updateMeterCard (confirm);
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Unable to Confirm", !confirm.getAeonErrorText ().isEmpty () ?
                                    "A" + confirm.getAeonErrorCode () + " - " + confirm.getAeonErrorText () :
                                    "B" + confirm.getErrorCode () + " - " + confirm.getErrorText (),
                            null);
                }
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });
    }

    private void updateMeterCard(final ElectricityConfirmation confirmation) {
        if (JKCardReader.getCardReaderConfig ().isMagCardWrite ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Encode Meter Card", "Do you wish to encode a Meter Card?", null,
                    MessageBox.CONTROLS_SHOW, MessageBox.MSG_YES_NO, new MessageBoxResult () {

                        @Override
                        public void onOk() {
                            List<MagCardData> cardUpdateList = ElectricityUtil.getMagCardUpdateByConfirmation (confirmation);
                            if (!cardUpdateList.isEmpty ()) {
                                PrintUtil.writeMagCardUpdate (cardUpdateList, null);
                            }
                        }

                        @Override
                        public void onCancel() {
                            //
                        }

                    });
        } else {
            JKiosk3.getMsgBox ().showMsgBox ("Unable to write Mag Cards", "Mag Card Read/Write not configured in Setup", null);
        }
    }

    private boolean validateInput() {
        meterNum = gMeter.getMeterNum ().trim ();
        //
        if (meterNum.equals ("") || meterNum == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Meter Number", "Meter Number cannot be blank.\n"
                    + "Please enter Meter Number.", null);
            return false;
        }
        return true;
    }
}
