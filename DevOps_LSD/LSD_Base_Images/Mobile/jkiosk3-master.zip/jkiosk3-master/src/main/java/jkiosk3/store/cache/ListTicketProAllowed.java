package jkiosk3.store.cache;

import aeonticketpros.TicketProAllowedProduct;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author valeriew
 */
public class ListTicketProAllowed implements Serializable {
    
    private final static long serialVersionUID = 20001L;
    
    private final List<TicketProAllowedProduct> listTProAllowed = new ArrayList<>();

    public List<TicketProAllowedProduct> getListTProAllowed() {
        return listTProAllowed;
    }
    
}
