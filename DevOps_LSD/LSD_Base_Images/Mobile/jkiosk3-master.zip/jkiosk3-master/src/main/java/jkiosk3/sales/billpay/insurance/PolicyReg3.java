package jkiosk3.sales.billpay.insurance;

import java.util.ArrayList;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlSearch;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales._common.PagedList;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.users.UserUtil;

public class PolicyReg3 extends Region {

    private final ControlSearch searchCtrlBank;
    private RadioButton radCash;
    private RadioButton radDebit;
    private TextField txtAccHolder;
    private final TextField txtBankName;
    private TextField txtBranchName;
    private TextField txtBranchCode;
    private ComboBox comAccType;
    private TextField txtAccNumber;
    private ComboBox comDebitDate;
    private GridPane gridDebitOrder;
//    private final List<BankDetail> listBanks;

    public PolicyReg3() {
        txtBankName = new TextField();
        searchCtrlBank = new ControlSearch();

//        listBanks = PolicyRegUtil.getBankList();
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().add(polRegStep3());
        vb.getChildren().add(getNav());
        getChildren().add(vb);
        setContent();
//        setGridEnabled();
        setSearchControlActions();
    }

    private void setContent() {
        if (PolicyRegistration.getInstance().isNav3()) {
            switch (PolicyRegistration.getInstance().getPaymentType()) {
                case PolicyRegUtil.POL_PMNT_CASH:
                    radCash.setSelected(true);
                    break;
                case PolicyRegUtil.POL_PMNT_DEBIT:
                    radDebit.setSelected(true);
//                    txtAccHolder.setText(PolicyRegistration.getInstance().getBankAccHolder());
//                    txtBankName.setText(PolicyRegistration.getInstance().getBankName());
//                    txtBranchName.setText(PolicyRegistration.getInstance().getBankBranchName());
//                    txtBranchCode.setText(PolicyRegistration.getInstance().getBankBranchCode());
//                    comAccType.getSelectionModel().select(PolicyRegistration.getInstance().getBankAccType());
//                    txtAccNumber.setText(PolicyRegistration.getInstance().getBankAccNumber());
//                    comDebitDate.getSelectionModel().select(PolicyRegistration.getInstance().getBankDebitDate());
                    break;
                default:
                    //
            }
        }
    }

    private void setSearchControlActions() {
        searchCtrlBank.getBtnSearch().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(new TextField(), "Enter search text", "", false, false, new KeyboardResult() {
                    @Override
                    public void onDone(String value) {
//                        JKiosk3.getMsgBox().showMsgBox("Bank List", "",
//                                getBankPaging(txtBankName, listBanks),
//                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_CANCEL, new MessageBoxResult() {
//                                    @Override
//                                    public void onOk() {
//                                        //
//                                    }
//
//                                    @Override
//                                    public void onCancel() {
//                                        //
//                                    }
//                                });
                    }
                });
            }
        });
        searchCtrlBank.getBtnClear().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                txtBankName.setText("");
            }
        });
    }

    private Group polRegStep3() {

        Label lblHead = JKText.getLblDk("Policy Registration", JKText.FONT_B_SM);
        Label lblStep = JKText.getLblDk("Step 3", JKText.FONT_B_XSM);

        VBox vbHead = JKNode.getPageDblHeadVB(0, lblHead, lblStep);

        Label lblPmntBy = JKText.getLblDk("Payment by", JKText.FONT_B_XXSM);

        ToggleGroup toggle = new ToggleGroup();

        radCash = new RadioButton(PolicyRegUtil.POL_PMNT_CASH);
        radCash.setToggleGroup(toggle);
        radCash.setSelected(true);
//        radCash.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
////                setGridEnabled();
//            }
//        });

        radDebit = new RadioButton(PolicyRegUtil.POL_PMNT_DEBIT);
        radDebit.setToggleGroup(toggle);
        radDebit.setVisible(false);
//        radDebit.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
////                setGridEnabled();
//            }
//        });

        HBox hbPmntBy = JKLayout.getHBox(0, JKLayout.sp);
        hbPmntBy.getChildren().addAll(radCash, JKNode.getHSpacer(), radDebit, JKNode.getHSpacer());

        GridPane grid = JKLayout.getContentGrid2Col(0.25, 0.75);

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblPmntBy, hbPmntBy);
        grid.addRow(2, JKNode.createGridSpanSep(2));
//        grid.add(getDebitOrderDetails(), 0, 3, 2, 1);

        Group grp = JKNode.getContentGroup(grid);

        return grp;
    }

    private GridPane getDebitOrderDetails() {

        Label lblAccHolder = JKText.getLblDk("Account Holder", JKText.FONT_B_XXSM);
        Label lblBankName = JKText.getLblDk("Bank Name", JKText.FONT_B_XXSM);
        Label lblBranchName = JKText.getLblDk("Branch Name", JKText.FONT_B_XXSM);
        Label lblBranchCode = JKText.getLblDk("Branch Code", JKText.FONT_B_XXSM);
        Label lblAccType = JKText.getLblDk("Account Type", JKText.FONT_B_XXSM);
        Label lblAccNumber = JKText.getLblDk("Account Number", JKText.FONT_B_XXSM);
        Label lblDebitDate = JKText.getLblDk("Debit Date", JKText.FONT_B_XXSM);

        txtAccHolder = new TextField();
        txtAccHolder.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getKeyboard().showKeyboard(txtAccHolder, "Enter Account Holder Initials and Surname", "", false, true);
//                }
            }
        });

        HBox.setHgrow(txtBankName, Priority.ALWAYS);
        txtBankName.setPromptText("click to select Bank");
        txtBankName.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                JKiosk3.getMsgBox().showMsgBox("Bank List", "",
//                        getBankPaging(txtBankName, listBanks),
//                        MessageBox.CONTROLS_SHOW, MessageBox.MSG_CANCEL, new MessageBoxResult() {
//                            @Override
//                            public void onOk() {
//                                //
//                            }
//
//                            @Override
//                            public void onCancel() {
//                                //
//                            }
//                        });
            }
        });
        HBox hbBankName = JKLayout.getHBox(0, JKLayout.sp);
        hbBankName.getChildren().addAll(txtBankName, searchCtrlBank);

        txtBranchName = new TextField();
        txtBranchName.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getKeyboard().showKeyboard(txtBranchName, "Enter Branch Name", "", false, true);
//                }
            }
        });

        txtBranchCode = new TextField();
        txtBranchCode.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getNumPad().showNumPad(txtBranchCode, "Branch Code", "");
//                }
            }
        });

        ObservableList listAccType = FXCollections.observableArrayList();
        listAccType.addAll("Cheque", "Savings");
        comAccType = new ComboBox();
        comAccType.setPrefSize((3 * JKLayout.btnSmW) + (2 * JKLayout.sp), 35);
        comAccType.setItems(listAccType);

        txtAccNumber = new TextField();
        txtAccNumber.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getNumPad().showNumPad(txtAccNumber, "Account Number", "");
//                }
            }
        });

        ObservableList listDebitDate = FXCollections.observableArrayList();
        listDebitDate.addAll("1st", "16th", "26th");
        comDebitDate = new ComboBox();
        comDebitDate.setPrefSize((3 * JKLayout.btnSmW) + (2 * JKLayout.sp), 35);
        comDebitDate.setItems(listDebitDate);

        gridDebitOrder = JKLayout.getContentGridInner2Col(0.25, 0.75);
//        setGridEnabled();
        gridDebitOrder.addRow(0, lblAccHolder, txtAccHolder);
        gridDebitOrder.addRow(1, lblBankName, hbBankName);
        gridDebitOrder.addRow(2, lblBranchName, txtBranchName);
        gridDebitOrder.addRow(3, lblBranchCode, txtBranchCode);
        gridDebitOrder.addRow(4, lblAccType, comAccType);
        gridDebitOrder.addRow(5, lblAccNumber, txtAccNumber);
        gridDebitOrder.addRow(6, lblDebitDate, comDebitDate);

        return gridDebitOrder;
    }

    private PagedList getBankPaging(final TextField txtfield, List<BankDetail> bankList) {
        List<Node> bankItems = new ArrayList<>();

        for (final BankDetail i : bankList) {
            Label lbl = JKText.getLblDk(i.getBankName(), JKText.FONT_B_XXSM);
            Button btn = JKNode.getBtnPopup("select");
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    onSelectBank(txtfield, i);
                }
            });
            HBox hb = JKLayout.getHBox(JKLayout.spNum, 0);
            hb.setMaxWidth(MessageBox.getMsgWidth() - (6 * JKLayout.sp));
            hb.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    onSelectBank(txtfield, i);
                }
            });
            hb.getChildren().addAll(lbl, JKNode.getHSpacer(), btn);
            if (!i.getBankName().equals("")) {
                bankItems.add(hb);
            }
        }
        PagedList paging = new PagedList(bankItems, 10);
        return paging;
    }

    private void onSelectBank(TextField txtfield, BankDetail bank) {
//        switch (boardOrDestination) {
//            case CarmaUtil.BOARD:
//                BusTicketSale.getInstance().setBoardingLoc(bank);
//                txtDestination.setText("");
//                txtDestination.setDisable(false);
//                searchCtrlDestination.getBtnSearch().setDisable(false);
//                searchCtrlDestination.getBtnClear().setDisable(false);
//                break;
//            case CarmaUtil.DESTINATION:
//                BusTicketSale.getInstance().setDestinationLoc(city);
//        }
        txtfield.setText(bank.getBankName());
        JKiosk3.getMsgBox().toBack();
        JKiosk3.getMsgBox().setVisible(false);
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav();

        nav.getBtnBack().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new PolicyReg2());
            }
        });

        nav.getBtnCancel().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent(new BillPaymentMenu());
            }
        });

        nav.getBtnNext().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                if (radCash.isSelected()) {
                    PolicyRegistration.getInstance().setNav3(true);
                    PolicyRegistration.getInstance().setPaymentType(PolicyRegUtil.POL_PMNT_CASH);
                    SceneSales.clearAndChangeContent(new PolicyReg4());
                } else if (radDebit.isSelected()) {
                    if (isValidReg3()) {
                        PolicyRegistration.getInstance().setNav3(true);
                        PolicyRegistration.getInstance().setPaymentType(PolicyRegUtil.POL_PMNT_DEBIT);
//                        PolicyRegistration.getInstance().setBankAccHolder(txtAccHolder.getText());
//                        PolicyRegistration.getInstance().setBankName(txtBankName.getText());
//                        PolicyRegistration.getInstance().setBankBranchName(txtBranchName.getText());
//                        PolicyRegistration.getInstance().setBankBranchCode(txtBranchCode.getText());
//                        PolicyRegistration.getInstance().setBankAccType(comAccType.getSelectionModel().getSelectedItem().toString());
//                        PolicyRegistration.getInstance().setBankAccNumber(txtAccNumber.getText());
//                        PolicyRegistration.getInstance().setBankDebitDate(comDebitDate.getSelectionModel().getSelectedItem().toString());
                        SceneSales.clearAndChangeContent(new PolicyReg4());
                    }
                }
            }
        });
        return nav;
    }

    //    private void setGridEnabled() {
//        if (radCash.isSelected()) {
//            gridDebitOrder.setDisable(true);
//        } else if (radDebit.isSelected()) {
//            gridDebitOrder.setDisable(false);
//        }
//    }
    private boolean isValidReg3() {
        if (txtAccHolder.getText() == null || txtAccHolder.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Account Holder", "Please enter Account Holder Name", null);
            return false;
        }
        if (txtBankName.getText() == null || txtBankName.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Bank Name", "Please select a Bank", null);
            return false;
        }
        if (txtBranchName.getText() == null || txtBranchName.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Branch Name", "Please enter a Branch Name", null);
            return false;
        }
        if (txtBranchCode.getText() == null || txtBranchCode.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Branch Code", "Please enter a Branch Code", null);
            return false;
        }
        if (comAccType.getSelectionModel().getSelectedItem() == null
                || comAccType.getSelectionModel().getSelectedItem().toString().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Account Type", "Please select an Account Type", null);
            return false;
        }
        if (txtAccNumber.getText() == null || txtAccNumber.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Account Number", "Please enter an Account Number", null);
            return false;
        }
        if (comDebitDate.getSelectionModel().getSelectedItem() == null
                || comDebitDate.getSelectionModel().getSelectedItem().toString().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Debit Order Date", "Please select a Date for Monthly Debit Order", null);
            return false;
        }

        return true;
    }
}
