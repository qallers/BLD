package jkiosk3.sales.topups.bundles;

import aeonairtime.RechargePlusTransaction;
import aeontopup.TopupBundleProduct;
import aeontopup.TopupBundleReq;
import aeontopup.TopupBundleResp;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._recharge_plus.RechargePlusUtil;
import jkiosk3.sales._favourites.nfc.NFCUtilFav;
import jkiosk3.sales.topups.TopupSale;
import jkiosk3.sales.topups.AirtimeUtil;
import jkiosk3.sales.topups.TopupProvider;
import jkiosk3.users.CurrentUser;

import java.util.List;

public class BundleRecharge extends Region {

    private final TopupProvider provider;
    private final TopupBundleProduct product;
    private TextField txtCellNum;
    private TextField txtCellNum2;
    private ComboBox cbCell;
    private String cellNumber;
    private boolean showRechargePlus = false;
    private boolean isRechargePlus = false;
    private boolean showFavourites;
    private double inputW;

    public BundleRecharge(boolean isFavourite) {
        this.provider = TopupSale.getInstance ().getProvider ();
        this.product = TopupSale.getInstance ().getProduct ();
        this.showFavourites = isFavourite;
        this.inputW = ((JKLayout.contentW - (3 * JKLayout.sp)) / 2);

        TopupSale.getInstance ().setRechargePlus (false);

        List<String> onlineTransTypes = CurrentUser.getUser ().getTransTypes ();
        if (onlineTransTypes.contains ("RechargePlus")) {
            if (provider.isRechargePlus ()) {
                showRechargePlus = true;
            } else {
                showRechargePlus = false;
            }
        }

        checkMobileNumFav ();

        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (getRechargeEntryGrid ());
        vb.getChildren ().add (getControlButtons ());
        getChildren ().addAll (vb);
    }

    private void checkMobileNumFav() {
        if (!NFCUtilFav.getTopAirMobileNumsFav ().isEmpty ()) {
            List<String> listMobileNums = NFCUtilFav.getTopAirMobileNumsFav ();
            cbCell = new ComboBox ();
            cbCell.setMaxWidth (inputW);
            cbCell.setMinWidth (inputW);
            cbCell.setEditable (true);
            cbCell.setItems (FXCollections.observableArrayList (listMobileNums));
            cbCell.getEditor ().setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event event) {
                    JKiosk3.getNumPad ().showNumPad (cbCell.getEditor (), "Mobile Number", "", new NumberPadResult () {
                        @Override
                        public void onDone(String value) {
                            cellNumber = value;
                            txtCellNum.setText (value);
                            txtCellNum2.setDisable (false);
                        }
                    });
                }
            });
            cbCell.getSelectionModel ().selectedItemProperty ().addListener (new ChangeListener<String> () {
                @Override
                public void changed(ObservableValue observable, String oldValue, String newValue) {
                    cellNumber = newValue;
                    txtCellNum.setText (cellNumber);
                    txtCellNum2.setText (cellNumber);
                }
            });
        }
    }

    private GridPane getRechargeEntryGrid() {
        String provStyle = TopupSale.getInstance ().getProviderStyleName ();

        Label lblTopupSaletype = JKText.getLblDk (TopupSale.getInstance ().getSaleType ().getDisplay (), JKText.FONT_B_SM);

        Button btnProvFav = JKNode.getAirtimeProviderButton (provStyle, product.getDescription ());

        VBox vbHead = JKNode.getPageDblHeadVB (0, lblTopupSaletype, btnProvFav);
        GridPane.setColumnSpan (vbHead, 2);

        Button btnBack = JKNode.getBtnPopup ("back");
        btnBack.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new BundleSelectDataOrSMS ());
            }
        });

        Label lblTopupType = JKText.getLblDk (TopupSale.getInstance ().getSaleType ().getDisplay (), JKText.FONT_B_SM);

        Button btnProvider = JKNode.getAirtimeProviderButton (provStyle, product.getDescription ());

        HBox hbHead = JKLayout.getHBox (0, JKLayout.sp);
        hbHead.getChildren ().addAll (lblTopupType, btnProvider);

        VBox vbHead1 = JKNode.getPageDblHeadVB (0, btnBack, hbHead);

        Label lblProduct = JKText.getLblDk (product.getDescription (), JKText.FONT_B_XSM);
        VBox vbHead2 = JKNode.getPageDblHeadVB (0, new Label (""), lblProduct);

        Label lblCellNum = JKText.getLblDk ("Mobile Number", JKText.FONT_B_XSM);
        lblCellNum.setMinWidth (JKLayout.btnSmW);

        Label lblCellNum2 = JKText.getLblDk ("Confirm Mobile Number", JKText.FONT_B_XSM);

        Label lblRechargePlus = JKText.getLblDk (RechargePlusUtil.RECHARGE_PLUS_LBL, JKText.FONT_B_XSM);

        CheckBox chkRechargePlus = new CheckBox ();
        chkRechargePlus.selectedProperty ().addListener (new ChangeListener<Boolean> () {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean aBoolean, Boolean t1) {
                if (t1) {
                    isRechargePlus = true;
                } else {
                    isRechargePlus = false;
                }
            }
        });

        txtCellNum = new TextField ();
        txtCellNum.setMaxWidth (inputW);
        txtCellNum.setMinWidth (inputW);
        txtCellNum.setPromptText ("Enter Mobile Number");
        txtCellNum.setOnMouseReleased (new EventHandler<Event> () {

            @Override
            public void handle(Event t) {
                JKiosk3.getNumPad ().showNumPad (txtCellNum, "Enter Mobile Num", "");
            }
        });

        txtCellNum2 = new TextField ();
        txtCellNum2.setMaxWidth (inputW);
        txtCellNum2.setMinWidth (inputW);
        txtCellNum2.setPromptText ("Confirm Mobile Number");
        txtCellNum2.setOnMouseReleased (new EventHandler<Event> () {

            @Override
            public void handle(Event t) {
                JKiosk3.getNumPad ().showNumPad (txtCellNum2, "Confirm Mobile Num", "");
            }
        });

        GridPane grid = JKLayout.getGridContent2Col (0.5, 0.5);

        if (showFavourites) {
            grid.addRow (0, vbHead);
            grid.add (vbHead2, 0, 1, 2, 1);
            grid.addRow (2, lblCellNum, cbCell);
            grid.addRow (3, lblCellNum2, txtCellNum2);
        } else {
            grid.add (vbHead1, 0, 0, 2, 1);
            grid.add (vbHead2, 0, 1, 2, 1);

            grid.addRow (2, lblCellNum, txtCellNum);
            grid.addRow (3, lblCellNum2, txtCellNum2);
        }

        if (showRechargePlus) {
            grid.addRow (5, lblRechargePlus, chkRechargePlus);
        }

        return grid;
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons ();

        ctrlBtns.getBtnAccept ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (isValidEntry ()) {
                    cellNumber = txtCellNum.getText ();
                    /* NOTE - With RechargePlus added, we need to show the summary regardless of the setting. */
                    showSummary ();
                }
            }
        });
        ctrlBtns.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                SceneSales.clearAndChangeContent(new MenuTopups());
                SceneSales.clearAndShowFavourites ();
            }
        });

        return ctrlBtns;
    }

    private void showSummary() {
        GridPane grid = JKLayout.getSummaryGrid2Col (0.4, 0.6);

        double amtRechargePlus = RechargePlusUtil.getRechargePlusValue ();

        Label lblProv = JKText.getLblDk ("Provider", JKText.FONT_B_XSM);
        Label lblProd = JKText.getLblDk ("Product", JKText.FONT_B_XSM);
        Label lblCell = JKText.getLblDk ("Mobile Number", JKText.FONT_B_XSM);
        Label lblAmt = JKText.getLblDk ("Amount", JKText.FONT_B_XSM);

        Label lblAmtTotal = JKText.getLblDk ("Total Due", JKText.FONT_B_26);

        Text txtProv = JKText.getTxtDk (provider.getDisplayName (), JKText.FONT_B_SM);
        Text txtProd = JKText.getTxtDk (product.getDescription (), JKText.FONT_B_SM);
        Text txtCellNumber = JKText.getTxtDk (JKText.getCellNumFormatted (cellNumber), JKText.FONT_B_SM);
        Text txtAmt = JKText.getTxtDk ("R " + JKText.getDeciFormat (product.getAmount ()), JKText.FONT_B_SM);

        Text txtAmtTotal = JKText.getTxtDk ("", JKText.FONT_B_26);

        grid.addRow (0, lblProv, txtProv);
        grid.addRow (1, lblProd, txtProd);
        grid.addRow (2, lblCell, txtCellNumber);
        grid.addRow (3, lblAmt, txtAmt);

        if (isRechargePlus) {
            Label lblAmtRchgPlus = JKText.getLblDk (RechargePlusUtil.RECHARGE_PLUS_LBL, JKText.FONT_B_XSM);
            Text txtAmtRchgPlus = JKText.getTxtDk ("R " + JKText.getDeciFormat (amtRechargePlus), JKText.FONT_B_SM);
            txtAmtTotal.setText ("R " + JKText.getDeciFormat (product.getAmount () + amtRechargePlus));

            grid.addRow (4, lblAmtRchgPlus, txtAmtRchgPlus);
            grid.addRow (6, lblAmtTotal, txtAmtTotal);
        } else {
            txtAmtTotal.setText ("R " + JKText.getDeciFormat (product.getAmount ()));
            grid.addRow (6, lblAmtTotal, txtAmtTotal);
        }

        JKiosk3.getMsgBox ().showMsgBox (TopupSale.getInstance ().getSaleType ().getDisplay (),
                "Are you sure you want to purchase this Topup?", grid,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        confirmTopupRequest ();
                    }

                    @Override
                    public void onCancel() {
                        //
                    }
                });
    }

    //====================================
    // above - mostly view
    // below - mostly process
    //====================================
    private void confirmTopupRequest() {
        JKiosk3.getMsgBox ().showMsgBox (TopupSale.getInstance ().getSaleType ().getDisplay (), "Topups cannot be reversed.\n\n"
                        + "Please make sure that you get the money for this transaction before proceeding with the sale.",
                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {

                    @Override
                    public void onOk() {
                        processTopupRequest ();
                    }

                    @Override
                    public void onCancel() {
                        SceneSales.clearAndShowFavourites ();
                    }
                });
    }

    private void processTopupRequest() {
        String ref = SalesUtil.getUniqueRef ();

        final TopupBundleReq req = new TopupBundleReq ();
        req.setSupplierName (provider.getName ());
        req.setReference (ref);
        req.setPhoneNumber (cellNumber);
        req.setProduct (product);
        req.setRechargePlus (isRechargePlus);

        TopupSale.getInstance ().setCellNum (cellNumber);
        TopupSale.getInstance ().setAmount (product.getAmount ());
        TopupSale.getInstance ().setBundleReq (req);
        TopupSale.getInstance ().setRef (ref);
        TopupSale.getInstance ().setRechargePlus (isRechargePlus);

        AirtimeUtil.getBundleTopup (req, new AirtimeUtil.TopupBundleRespResult () {
            @Override
            public void topupBundleRespResult(TopupBundleResp topupBundleResponse) {
                if (topupBundleResponse.isSuccess ()) {
                    SalesUtil.processTopupData (topupBundleResponse);
                    SceneSales.clearAndShowFavourites ();
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Topup Bundle Error", !topupBundleResponse.getAeonErrorText ().isEmpty () ?
                                    "A" + topupBundleResponse.getAeonErrorCode () + " - " + topupBundleResponse.getAeonErrorText () :
                                    "B" + topupBundleResponse.getErrorCode () + " - " + topupBundleResponse.getErrorText (), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    SceneSales.clearAndShowFavourites ();
                                }

                                @Override
                                public void onCancel() {

                                }
                            });
                }
            }
        });
    }

    private boolean isValidEntry() {
        if (txtCellNum.getText ().isEmpty () || txtCellNum2.getText ().isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Mobile Number", "Please enter AND confirm Mobile Number", null);
            return false;
        }
        if (!txtCellNum.getText ().equals (txtCellNum2.getText ())) {
            JKiosk3.getMsgBox ().showMsgBox ("Mobile Number", "Mobile Number and Confirm Mobile Number do not match!", null);
            return false;
        }
        if (!txtCellNum.getText ().matches ("\\d{10}")) {
//        if (!txtCellNum.getText().matches("(^0[678][01234689]((\\d{7})|( |-)((\\d{3}))( |-)(\\d{4})|( |-)(\\d{7})))")) {
            JKiosk3.getMsgBox ().showMsgBox ("Customer Cell Number", "Please enter a valid Cell Number", null);
            return false;
        }
        return true;
    }
}
