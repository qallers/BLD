package jkiosk3.store.cache;

import aeonbillpayments.Provider;
import java.util.Collections;
import java.util.List;
import jkiosk3.store.Store;

/**
 *
 * @author valeriew
 */
public class CacheListBillPaymentProviders {

    private static volatile ListBillPaymentProviders listBillPaymentProviders;

    private static ListBillPaymentProviders getListBillPayProviders() {
        if (listBillPaymentProviders == null) {
            listBillPaymentProviders = ((ListBillPaymentProviders) Store.loadObject(CacheListBillPaymentProviders.class.getSimpleName()));
        }
        if (listBillPaymentProviders == null) {
            listBillPaymentProviders = new ListBillPaymentProviders();
        }
        return listBillPaymentProviders;
    }

    private static void saveListBillPaymentProviders(ListBillPaymentProviders listBillPayProv) {
        Store.saveObject(CacheListBillPaymentProviders.class.getSimpleName(), listBillPayProv);
    }

    public static void saveBillPaymentProviders(List<Provider> listBillPayProv) {
        getListBillPayProviders();

        listBillPaymentProviders.getListBillPayProviders().clear();
        listBillPaymentProviders.getListBillPayProviders().addAll(listBillPayProv);
        saveListBillPaymentProviders(listBillPaymentProviders);
    }

    public static boolean hasItems() {
        getListBillPayProviders();
        return !listBillPaymentProviders.getListBillPayProviders().isEmpty();
    }

    public static List<Provider> getListBillPaymentProviders() {
        getListBillPayProviders();
        return Collections.unmodifiableList(listBillPaymentProviders.getListBillPayProviders());
    }
    
    public static void deleteCacheBillPaymentProviders() {
        Store.deleteObject(CacheListBillPaymentProviders.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheListBillPaymentProviders.class.getSimpleName());
    }
}
