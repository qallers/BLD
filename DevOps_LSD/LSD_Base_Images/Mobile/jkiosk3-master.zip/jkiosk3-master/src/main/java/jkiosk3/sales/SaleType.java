package jkiosk3.sales;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum SaleType {

    VOUCHERS("Vouchers", "Vouchers"),
    VOUCHER_AIRTIME("Vouchers", "Airtime Vouchers"),
    VOUCHER_DATA("Vouchers", "Data & Bundle Vouchers"),
    VOUCHER_ELEC("Vouchers", "Electricity Vouchers"),
    VOUCHER_OTHER("Vouchers", "Other Vouchers"),
    CHAT4CHANGE("Vouchers", "Chat 4 Change"),
    TOPUP("Topup", "Topup"),
    TOPUP_AIRTIME("Topup", "Airtime Topup"),
    TOPUP_BUNDLE_DATA("Bundles", "Data Bundle Topup"),
    TOPUP_BUNDLE_SMS("Bundles", "SMS Bundle Topup"),
    TOPUP_WALLET("Wallet", "Wallet Topup"),
    ELECTRICITY("Electricity", "Electricity"),
    BUSTICKETS("Tickets", "Bus Tickets"),
    COACHTICKETS("Tickets", "Coach Tickets"),
    TICKETPRO("Tickets", "TicketPros"),
    TICKETING("Tickets", "Ticketing"),
    BILLPAYMENTS("Payments", "Bill Payments"),
    RICA("Other", "RICA"),
    MONEY_TRANSFER("Other", "Money Transfer"),
    MONEY_TRANSFER_DEPOSIT("Other", "Money Trf Deposit"),
    MONEY_TRANSFER_REDEEM("Other", "Money Trf Redeem"),
    LOTTO("Other", "Ithuba"),
    RECHARGE_PLUS("Vouchers", "RechargePlus"),
    SEARCH_PRODUCT("Search", "Search");

    private final String type;
    private final String display;
    private List<SaleType> listSaleTypes = new ArrayList<>();

    private SaleType(String type, String display) {
        this.type = type;
        this.display = display;
    }

    @Override
    public String toString() {
        return getDisplay();
    }

    public String getType() {
        return type;
    }

    public String getDisplay() {
        return display;
    }
    
    public static List<SaleType> getListSaleTypes() {
        List<SaleType> listSaleTypes = Arrays.asList(SaleType.values());
        return listSaleTypes;
    }
}
