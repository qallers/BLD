package jkiosk3.setup;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.BarcodeHandler;
import jkiosk3.printing.PrintUtil;
import jkiosk3.printing.print_layouts.PrintAssorted;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.store.JKPrinter;

/**
 * Provides all the options necessary for a User to set and save the required Printer configuration for the Device on
 * which the Application is running. Also provides options to select a Barcode type for test printing. The Barcode test
 * and print option is not saved with the Printer configuration.
 *
 */
public class SetupPrinter extends Region {

    private RadioButton radWin;
    private RadioButton radOth;
    private RadioButton rad128A;
    private RadioButton rad128B;
    private RadioButton rad128C;
    private RadioButton radPdf417;
    private ComboBox chcPrintPort;
    private ComboBox chcPrintDriver;
    private ComboBox chcPrintBaud;
    private CheckBox chkFlowCon;
    private GridPane gridOther;
    private String bcFormat = "";
    private String bcData = "";

    /**
     * Sets up the layout for the entry page. Different sections of the page are defined in separate sections for ease
     * of maintenance.
     */
    public SetupPrinter() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getPrinterEntry());
        vb.getChildren().add(getBarcodeTestGroup());
        vb.getChildren().add(getControls());

        setPrinterTypeView();

        getChildren().add(vb);
    }

    /**
     * Layout of components required to allow the selection of either a default Windows Printer, or a Serial Printer. If
     * Serial Printer is selected, a grid is enabled for entry of Serial Port settings.
     *
     * @return a Group made up of a styled Rectangle, and a VBox containing the components required to enter the
     * settings for the selected Printer.
     */
    private VBox getPrinterEntry() {

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);

        GridPane grid = JKLayout.getContentGridInner2Col(0.25, 0.75);

        VBox vbHead = JKNode.getPageHeadVB("Printer Setup");

        ToggleGroup toggle = new ToggleGroup();

        radWin = new RadioButton("Windows Printer");
        radWin.setToggleGroup(toggle);
        radWin.setSelected(JKPrinter.getPrinterConfig().isPrintWin());
        radWin.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setPrinterTypeView();
            }
        });

        radOth = new RadioButton("Other Printer");
        radOth.setToggleGroup(toggle);
        radOth.setSelected(!(JKPrinter.getPrinterConfig().isPrintWin()));
        radOth.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setPrinterTypeView();
            }
        });

        HBox hbPrintType = JKLayout.getHBox(0, JKLayout.sp);
        hbPrintType.getChildren().addAll(radWin, JKNode.getHSpacer(), radOth);

        gridOther = getPrinterOther();

        grid.add(vbHead, 0, 0, 2, 1);
        grid.add(hbPrintType, 1, 1);

        vb.getChildren().addAll(grid, gridOther);

        return vb;
    }

    /**
     * Layout of components required to enter COM Port, Printer Driver, Baud Rate and Flow Control. Combo Boxes are
     * provided with pre-populated lists from which to select.
     *
     * @return a GridPane with components required for entry of COM Port, Printer Driver, Baud Rate and Flow Control.
     */
    private GridPane getPrinterOther() {

        double combo_width = (JKLayout.contentW - (2 * JKLayout.sp));

        GridPane grid = JKLayout.getContentGridInner2Col(0.25, 0.75);

        Label lblPort = JKText.getLblDk("Port", JKText.FONT_B_XSM);
        lblPort.setMinWidth(JKLayout.btnSmW);

        Label lblPrintType = JKText.getLblDk("Printer Type", JKText.FONT_B_XSM);
        Label lblBaud = JKText.getLblDk("Baud Rate", JKText.FONT_B_XSM);

        chcPrintPort = new ComboBox();
        chcPrintPort.setPrefSize((combo_width * 0.75), 35);
        chcPrintPort.getSelectionModel().select(JKPrinter.getPrinterConfig().getPrintPort());
        chcPrintPort.getItems().addAll("COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "LPT1", "LPT2");

        chcPrintDriver = new ComboBox();
        chcPrintDriver.setPrefSize((combo_width * 0.75), 35);
        chcPrintDriver.getSelectionModel().select(JKPrinter.getPrinterConfig().getPrintDriver());
        chcPrintDriver.getItems().addAll(PrintUtil.POS_STAR, PrintUtil.POS_EPSON);

        chcPrintBaud = new ComboBox();
        chcPrintBaud.setPrefSize((combo_width * 0.75), 35);
        chcPrintBaud.getSelectionModel().select(Integer.toString(JKPrinter.getPrinterConfig().getPrintBaud()));
        chcPrintBaud.getItems().addAll("2400", "4800", "9600", "14400", "19200", "38400", "57600", "115200");

        chkFlowCon = new CheckBox("Flow Control");
        chkFlowCon.setSelected(JKPrinter.getPrinterConfig().isPrintFlowControl());

        grid.addRow(0, lblPort, chcPrintPort);
        grid.addRow(1, lblPrintType, chcPrintDriver);
        grid.addRow(2, lblBaud, chcPrintBaud);
        grid.add(chkFlowCon, 1, 3);

        return grid;
    }

    /**
     * Enables or disables the GridPane for entry of Serial Printer settings as required.
     */
    private void setPrinterTypeView() {
        if (radWin.isSelected()) {
            gridOther.setDisable(true);
        } else if (radOth.isSelected()) {
            gridOther.setDisable(false);
        }
    }

    /**
     * Layout of components (RadioButtons) to allow the selection of one of three Barcode types that can be test
     * printed.
     *
     * @return a Group made up of a styled Rectangle, and an HBox containing RadioButtons for the Barcode types that can
     * be test printed.
     */
    private VBox getBarcodeTestGroup() {
        Label lblBarcodeFormat = JKText.getLblContentSubHead("Select Barcode Format for Test Print");
        ToggleGroup toggleBCFormat = new ToggleGroup();

        rad128A = new RadioButton(BarcodeHandler.BARCODE_128A);
        rad128A.setToggleGroup(toggleBCFormat);
        rad128A.setSelected(true);

        rad128B = new RadioButton(BarcodeHandler.BARCODE_128B);
        rad128B.setToggleGroup(toggleBCFormat);

        rad128C = new RadioButton(BarcodeHandler.BARCODE_128C);
        rad128C.setToggleGroup(toggleBCFormat);

        radPdf417 = new RadioButton(BarcodeHandler.BARCODE_PDF417);
        radPdf417.setToggleGroup(toggleBCFormat);

        HBox hb = JKLayout.getHBox(0, 0);
        hb.setPrefWidth(JKLayout.contentW - (2 * JKLayout.sp));
        hb.getChildren().addAll(rad128A, JKNode.getHSpacer(), rad128B, JKNode.getHSpacer(),
                rad128C, JKNode.getHSpacer(), radPdf417, JKNode.getHSpacer());

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(lblBarcodeFormat, hb);

        return vb;
    }

    /**
     * Defines the actions to be taken on clicking any of the Button items shown in the component.
     *
     * @return a SceneSetupControls (custom component) containing the necessary Button items to enable a User to "Save",
     * "Cancel" or "Test Print" the settings made.
     */
    private SceneSetupControls getControls() {
        return new SceneSetupControls("Test Print", true) {
            @Override
            public void onClickTest() {
                getSelectedBarcodeFormats();
                if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
                    JKiosk3.getPrintPreview().showPrintPreview("Test Print",
                            PrintAssorted.getTestBarcodePrint(bcFormat, bcData),
                            PrintPreview.PRN_OK, new PrintPreviewResult() {
                        @Override
                        public void onOk() {
                            //
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
                } else {
                    PrintUtil.sendToPrinter(PrintAssorted.getTestBarcodePrint(bcFormat, bcData));
                }
            }

            @Override
            public void onClickSave() {
                saveSystemPrinter();
            }
        };
    }

    /**
     * Sets the values of the parameters required for printing of the selected Barcode type.
     */
    private void getSelectedBarcodeFormats() {
        BarcodeHandler bh = new BarcodeHandler();
        bcFormat = "";
        bcData = "";
        if (rad128A.isSelected()) {
            bcFormat = BarcodeHandler.BARCODE_128A;
            bcData = ("1509172106RX418");   // no pre-processing required for Code128A.
        } else if (rad128B.isSelected()) {
            bcFormat = BarcodeHandler.BARCODE_128B;
//            bcData = bh.processBarcode128B("43,85,92,114,92,102,58,101,92,102,92,117,61,116,65,57");
            bcData = bh.processBarcode128B("43,85,79,100,90,82,74,58,75,92,76,63,125,47,39,47");
        } else if (rad128C.isSelected()) {
            bcFormat = BarcodeHandler.BARCODE_128C;
            bcData = bh.processBarcode128cPDF417("30303038343730363134393939393930303232353632");
        } else if (radPdf417.isSelected()) {
            bcFormat = BarcodeHandler.BARCODE_PDF417;
            bcData = bh.processBarcode128cPDF417("30303038343730353838393939393930303237393035");
        } else {
            bcFormat = "P";
            bcData = "6006986000601";
        }
    }

    /**
     * Saves the selected settings for printing.
     */
    private void saveSystemPrinter() {
        if (radWin.isSelected()) {
            JKPrinter.getPrinterConfig().setPrintWinOth("Windows");
            JKPrinter.getPrinterConfig().setPrintWin(true);
        } else if (radOth.isSelected()) {
            JKPrinter.getPrinterConfig().setPrintWinOth("Other");
            JKPrinter.getPrinterConfig().setPrintWin(false);
        }
        if (radOth.isSelected()) {
            if (chcPrintPort.getSelectionModel().getSelectedItem() == null
                    || chcPrintDriver.getSelectionModel().getSelectedItem() == null
                    || chcPrintBaud.getSelectionModel().getSelectedItem() == null) {
                JKiosk3.getMsgBox().showMsgBox("Port, Driver or Baud Rate",
                        "Port, Printer Type or Baud Rate cannot be empty", null);
            }
        }

        JKPrinter.getPrinterConfig().setPrintPort(chcPrintPort.getSelectionModel().getSelectedItem().toString());
        JKPrinter.getPrinterConfig().setPrintDriver(chcPrintDriver.getSelectionModel().getSelectedItem().toString());
        JKPrinter.getPrinterConfig().setPrintBaud(Integer.parseInt(chcPrintBaud.getSelectionModel().getSelectedItem().toString()));
        JKPrinter.getPrinterConfig().setPrintFlowControl(chkFlowCon.isSelected());
        //
        if (JKPrinter.savePrinterConfig()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Printer settings saved successfully", null);
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Printer settings not saved", null);
        }
    }
}
