package jkiosk3.accounts.emerg_topup;

import aeonemergencytopup.AccountsList;
import aeonemergencytopup.EmergTopHistoryReq;
import aeonemergencytopup.EmergTopHistoryResp;
import aeonemergencytopup.EmergTopReprintReq;
import aeonemergencytopup.EmergencyTopupConnection;
import aeonemergencytopup.LoanApplicationReq;
import aeonemergencytopup.LoanApplicationResp;
import aeonemergencytopup.LoanConfirmReq;
import aeonemergencytopup.LoanConfirmResp;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.concurrent.Task;
import jkiosk3.JKiosk3;
import jkiosk3.SceneMenu;
import jkiosk3.reports.SceneReports;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

/**
 *
 * @author Valerie
 */
public class EmergencyTopupUtil {

    private final static Logger logger = Logger.getLogger(EmergencyTopupUtil.class.getName());
    private static EmergencyTopupConnection etConn;
    private static String userPin;
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 60;

    private static EmergencyTopupConnection getEmergencyTopupConnection() {
        EmergencyTopupConnection etConnect = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            etConnect = new EmergencyTopupConnection(server, port, secureConnect);
            etConnect.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return etConnect;
    }

    private static boolean isLoggedIn(String pin) throws RuntimeException {
        boolean loggedIn = false;
        userPin = pin;
        int deviceId = JKSystem.getSystemConfig().getDeviceId();
        String serial = JKSystem.getSystemConfig().getSerial();
        etConn = getEmergencyTopupConnection();

        try {
            loggedIn = etConn.login(userPin, deviceId, serial);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    private static AccountsList getListAccounts() throws RuntimeException {
        AccountsList accList = new AccountsList();
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                accList = etConn.getListAccounts(CurrentUser.getUser().getUserName());
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("List Accounts Error", t);
        } finally {
            if (etConn != null) {
                etConn.disconnect();
            }
        }
        return accList;
    }

    private static LoanApplicationResp getLoanApplication(LoanApplicationReq req) throws RuntimeException {
        LoanApplicationResp loanAppResp = new LoanApplicationResp();
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                loanAppResp = etConn.getLoanApplication(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Emergency Topup Application Error", t);
        } finally {
            if (etConn != null) {
                etConn.disconnect();
            }
        }
        return loanAppResp;
    }

    private static LoanConfirmResp getLoanConfirmation(LoanConfirmReq req) throws RuntimeException {
        LoanConfirmResp loanConfResp = new LoanConfirmResp();
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                loanConfResp = etConn.getLoanConfirmation(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Emergency Topup Confirmation Error", t);
        } finally {
            if (etConn != null) {
                etConn.disconnect();
            }
        }
        return loanConfResp;
    }

    private static EmergTopHistoryResp getEmergTopupHistory(EmergTopHistoryReq req) throws RuntimeException {
        EmergTopHistoryResp historyResp = new EmergTopHistoryResp();
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                historyResp = etConn.getEmergTopupHistory(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Emergency Topup History Error", t);
        } finally {
            if (etConn != null) {
                etConn.disconnect();
            }
        }
        return historyResp;
    }

    private static LoanConfirmResp getEmergTopupReprint(EmergTopReprintReq req) throws RuntimeException {
        LoanConfirmResp reprintConf = new LoanConfirmResp();
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                reprintConf = etConn.getEmergTopupReprint(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Emergency Topup Reprint Error", t);
        } finally {
            if (etConn != null) {
                etConn.disconnect();
            }
        }
        return reprintConf;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getListAccounts(final AccountsListResult result) {
        JKiosk3.getBusy().showBusy("Getting List of Accounts");

        final Task<AccountsList> taskListAcc = new Task() {
            @Override
            protected AccountsList call() throws Exception {
                return getListAccounts();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.accountListResult((AccountsList) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Emergency Topup", "Error Retrieving List of Accounts",
                        State.CANCELLED, errorMsg, new SceneMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Emergency Topup", "Error Retrieving List of Accounts",
                        State.FAILED, errorMsg, new SceneMenu());
            }
        };
        new Thread(taskListAcc).start();
        JKiosk3.getBusy().startCountdown(taskListAcc, countdownTime);
    }

    public static void getLoanApplication(final LoanApplicationReq req, final LoanApplicationResult result) {
        JKiosk3.getBusy().showBusy("Getting Account Details");

        final Task<LoanApplicationResp> taskLoanApp = new Task() {
            @Override
            protected LoanApplicationResp call() throws Exception {
                return getLoanApplication(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.loanApplicationResult((LoanApplicationResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Emergency Topup", "Error Retrieving Account Details",
                        State.CANCELLED, errorMsg, new SceneEmergencyTopup());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Emergency Topup", "Error Retrieving Account Details",
                        State.FAILED, errorMsg, new SceneEmergencyTopup());
            }
        };
        new Thread(taskLoanApp).start();
        JKiosk3.getBusy().startCountdown(taskLoanApp, countdownTime);
    }

    public static void getLoanConfirmation(final LoanConfirmReq req, final LoanConfirmationResult result) {
        JKiosk3.getBusy().showBusy("Confirming Emergency Topup Application");

        final Task<LoanConfirmResp> taskLoanConf = new Task() {
            @Override
            protected LoanConfirmResp call() throws Exception {
                return getLoanConfirmation(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.loanConfirmationResult((LoanConfirmResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Emergency Topup Confirm", "Error Confirming Emergency Topup",
                        State.CANCELLED, errorMsg, new SceneEmergencyTopup());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Emergency Topup Confirm", "Error Confirming Emergency Topup",
                        State.FAILED, errorMsg, new SceneEmergencyTopup());
            }
        };
        new Thread(taskLoanConf).start();
        JKiosk3.getBusy().startCountdown(taskLoanConf, countdownTime);
    }

    public static void getEmergTopupHistory(final EmergTopHistoryReq req, final LoanHistoryResult result) {
        JKiosk3.getBusy().showBusy("Getting Emergency Topup History");

        final Task<EmergTopHistoryResp> taskListHistory = new Task() {
            @Override
            protected EmergTopHistoryResp call() throws Exception {
                return getEmergTopupHistory(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.loanHistoryResult((EmergTopHistoryResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Emergency Topup History",
                        "Error Retrieving Emergency Topup History", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Emergency Topup History",
                        "Error Retrieving Emergency Topup History", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskListHistory).start();
        JKiosk3.getBusy().startCountdown(taskListHistory, countdownTime);
    }

    public static void getEmergTopupReprint(final EmergTopReprintReq req, final LoanConfirmationResult result) {
        JKiosk3.getBusy().showBusy("Getting Emergency Topup Reprint");

        final Task<LoanConfirmResp> taskReprintConf = new Task() {
            @Override
            protected LoanConfirmResp call() throws Exception {
                return getEmergTopupReprint(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.loanConfirmationResult((LoanConfirmResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Emergency Topup Reprint",
                        "Error Retrieving Emergency Topup Reprint", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Emergency Topup Reprint",
                        "Error Retrieving Emergency Topup Reprint", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskReprintConf).start();
        JKiosk3.getBusy().startCountdown(taskReprintConf, countdownTime);
    }

    public static abstract class AccountsListResult {

        public abstract void accountListResult(AccountsList listAccounts);
    }

    public static abstract class LoanApplicationResult {

        public abstract void loanApplicationResult(LoanApplicationResp loanApplication);
    }

    public static abstract class LoanConfirmationResult {

        public abstract void loanConfirmationResult(LoanConfirmResp loanConfirmation);
    }

    public static abstract class LoanHistoryResult {

        public abstract void loanHistoryResult(EmergTopHistoryResp loanHistory);
    }
}
