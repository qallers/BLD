package jkiosk3.sales.search;

import aeonvarivouchers.Supplier;
import jkiosk3.sales.chat4change.Chat4ChangeUtil;

import java.util.ArrayList;
import java.util.List;

public class CreateC4CProduct {
    final static String CHAT4CHANGE = "Chat 4 Change";

    public static List<SearchProduct> createC4CProducts() {

        List<SearchProduct> products = new ArrayList<>();
        for (Supplier suppliers : Chat4ChangeUtil.getC4CSuppliersList()) {
            String supplierName = suppliers.getName();
            products.add(createChat4ChangeProduct(supplierName));
        }

        return products;
    }

    public static SearchProduct createChat4ChangeProduct(String supplierName) {
        SearchProduct billPayProduct = new SearchProduct();

        String name = supplierName;
        if (name.toLowerCase().contains("cellc")) {
            name = "Cell C";
        } else if (name.toLowerCase().contains("mtn")) {
            name = "MTN";
        } else if (name.toLowerCase().contains("telkommobile")) {
            name = "Telkom Mobile";
        } else if (name.toLowerCase().contains("virgin")) {
            name = "Virgin Mobile";
        } else if (name.toLowerCase().contains("vodacom")) {
            name = "Vodacom";
        }

        billPayProduct.setProvName(supplierName);
        billPayProduct.setProdName(String.format("%s %s", name, CHAT4CHANGE));
        billPayProduct.setSearchTransType(SearchTransType.CHAT4CHANGE);

        return billPayProduct;
    }
}
