package jkiosk3.reports;

import aeonemergencytopup.Account;
import aeonemergencytopup.AccountsList;
import aeonprinting.AeonPrintJob;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.accounts.emerg_topup.EmergencyTopupUtil;
import jkiosk3.printing.PrintHandler;
import jkiosk3.store.JKOptions;

/**
 *
 * @author Valerie
 */
public class EmergTopTransactions extends Region {

    private final static Logger logger = Logger.getLogger(EmergTopTransactions.class.getName());
    private ObservableList listAccObserv;
    private Account selectedAccount;
    private int numDays;
    private TextField txtDays;

    public EmergTopTransactions() {
        EmergencyTopupUtil.getListAccounts(new EmergencyTopupUtil.AccountsListResult() {

            @Override
            public void accountListResult(AccountsList listAccounts) {
                if (listAccounts.isSuccess()) {
                    listAccObserv = FXCollections.observableArrayList();
                    for (aeonemergencytopup.Account acc : listAccounts.getListAccounts()) {
                        listAccObserv.add(acc);
                    }

                    VBox vb = JKLayout.getVBox(0, 5);

                    vb.getChildren().add(getEmergTopTransGroup());
                    vb.getChildren().add(getPrintControl());

                    getChildren().addAll(vb);
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Emergency Topup Transactions",
                            "Error retrieving list of Accounts\n\n" + listAccounts.getErrorCode() + " - " + listAccounts.getErrorText(),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    SceneReports.getVbReportContent().getChildren().clear();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });

    }

    private GridPane getEmergTopTransGroup() {
        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);

        VBox vbHead = JKNode.getReportHeadVB("Emergency Topup Transactions");

        Label lblAccNo = JKText.getLblDk("Account", JKText.FONT_B_XSM);

        Label lblDays = JKText.getLblDk("No of Days", JKText.FONT_B_XSM);

        final ComboBox comAcc = new ComboBox();
        comAcc.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.75), 35);

        comAcc.setItems(listAccObserv);
        comAcc.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue ov, Object oldValue, Object newValue) {
                if (newValue != null) {
                    selectedAccount = (Account) newValue;
                }
            }
        });

        txtDays = new TextField();
        txtDays.setPromptText("days");
        txtDays.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event arg0) {
                if (!JKOptions.getOptions().isKeyboard()) {
                    JKiosk3.getNumPad().showNumPad(txtDays, "Enter Days", "");
                }
            }
        });

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblAccNo, comAcc);
        grid.addRow(2, lblDays, txtDays);

        return grid;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                showTransactionReport();
            }
        };
    }

    private void showTransactionReport() {
        if (inputValidation()) {
            try {
                ReportUtil.getPrintReport(ReportUtil.REP_EMERG_TOP_TRANS_LIST, selectedAccount.getAccId(), numDays,
                        new ReportUtil.AeonPrintJobResult() {
                            @Override
                            public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                                PrintHandler.handlePrintRequestReport("Emergency Topup Transaction List", aeonPrintJob);
                            }
                        });
            } catch (Exception e) {
                logger.log(Level.SEVERE, e.getMessage(), e);
            }
            resetForm();
        }
    }

    private boolean inputValidation() {
        boolean validated = false;
        try {
            numDays = Integer.parseInt(txtDays.getText());
            validated = true;
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox().showMsgBox("Days", "Number of days must be a whole integer number", null);
            logger.log(Level.SEVERE, nfe.getMessage(), nfe);
        }
        return validated;
    }

    private void resetForm() {
        SceneReports.clearAndChangeContent(new EmergTopTransactions());
    }
}
