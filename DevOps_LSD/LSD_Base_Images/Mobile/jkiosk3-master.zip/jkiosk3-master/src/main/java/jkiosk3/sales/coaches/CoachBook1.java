package jkiosk3.sales.coaches;

import aeoncoach.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlSearch;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.TicketingMenu;
import jkiosk3.sales._bus_carriers.CoachCarrierLayouts;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales._common.PagedList;
import jkiosk3.users.UserUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CoachBook1 extends Region {

    private final static Logger logger = Logger.getLogger (CoachBook1.class.getName ());

    private ControlSearch searchCtrlDeparture;
    private ControlSearch searchCtrlDestination;
    private RadioButton radSingle;
    private RadioButton radReturn;
    private TextField txtDepart;
    private TextField txtDest;
    private TextField txtDateDepart;
    private TextField txtDateReturn;
    private ComboBox<Integer> cbSeats;
    private CoachListItemResp coachListItemRespCities;
    private List<CoachListItem> listCityDepart;
    private List<CoachListItem> listCityDest;
    private CoachListItem selectedDepartureLoc;
    private CoachListItem selectedDestinationLoc;
    private SimpleDateFormat sdf;
    private Date dateDepart;
    private Date dateReturn;
    private final double cityPopupWidth = 750;

    public CoachBook1() {
        if (CoachTicketSale.getInstance ().getDepartureLoc () == null) {
            CoachTicketSale.resetCoachTicketSale ();
        } else {
            selectedDepartureLoc = CoachTicketSale.getInstance ().getDepartureLoc ();
            selectedDestinationLoc = CoachTicketSale.getInstance ().getDestinationLoc ();
        }

        CoachUtil.getCoachCarriersList (new CoachUtil.CoachCarriersListResult () {
            @Override
            public void coachCarriersListResult(CoachCarriersList coachCarriersListResult) {
                // if success, get Departure City list
                if (coachCarriersListResult.isSuccess ()) {
                    CoachTicketSale.getInstance ().getListCarriers ().addAll (coachCarriersListResult.getListCarriers ());
                    CoachUtil.getCityList (new CoachUtil.CoachCityListResult () {
                        @Override
                        public void coachCityListResult(CoachListItemResp coachCityListResult) {
                            if (coachCityListResult.isSuccess ()) {
                                coachListItemRespCities = coachCityListResult;
                                listCityDepart = new ArrayList<> ();
                                listCityDest = new ArrayList<> ();
                                showCoachBook1View ();
                            } else {
                                // no city list, show error
                                JKiosk3.getMsgBox ().showMsgBox ("Cities List Error", !coachCityListResult.getAeonErrorText ().isEmpty () ?
                                                coachCityListResult.getAeonErrorCode () + " - " + coachCityListResult.getAeonErrorText () :
                                                coachCityListResult.getErrorCode () + " - " + coachCityListResult.getErrorText (), null,
                                        MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                            @Override
                                            public void onOk() {
                                                SceneSales.clearAndChangeContent (new TicketingMenu ());
                                            }

                                            @Override
                                            public void onCancel() {
                                            }
                                        });
                            }
                        }
                    });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Coach Carrier Error", !coachCarriersListResult.getAeonErrorText ().isEmpty () ?
                                    "A" + coachCarriersListResult.getAeonErrorCode () + " - " + coachCarriersListResult.getAeonErrorText () :
                                    "B" + coachCarriersListResult.getErrorCode () + " - " + coachCarriersListResult.getErrorText (),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    SceneSales.clearAndChangeContent (new TicketingMenu ());
                                }

                                @Override
                                public void onCancel() {
                                }
                            });
                }
            }
        });
    }

    private void showCoachBook1View() {
        if (!coachListItemRespCities.getListItems ().isEmpty ()) {
            resetCityList (listCityDepart);
            resetCityList (listCityDest);
        }

        sdf = new SimpleDateFormat ("dd/MM/yyyy");

        setSearchControlActions ();

        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().addAll (showCoachTicketBookStep1 (), getNav ());
        getChildren ().add (vb);
    }

    private void setSearchControlActions() {
        // DEPARTURE search and clear
        searchCtrlDeparture = new ControlSearch ();
        searchCtrlDeparture.getBtnSearch ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (new TextField (), "Enter search text", "",
                        false, false, new KeyboardResult () {
                            @Override
                            public void onDone(String value) {
                                if (value != null) {
                                    listCityDepart.clear ();
                                    for (CoachListItem b : coachListItemRespCities.getListItems ()) {
                                        if (b.getName ().toLowerCase (Locale.ENGLISH).contains (value.toLowerCase (Locale.ENGLISH))) {
                                            listCityDepart.add (b);
                                        }
                                    }
                                    if (!listCityDepart.isEmpty ()) {
                                        showCityList (CoachUtil.LOCATION_BOARDING, txtDepart, listCityDepart);
                                    } else {
                                        JKiosk3.getMsgBox ().showMsgBox ("No Search Results",
                                                "Please enter a different search term", null);
                                        showSearchError (txtDepart, listCityDepart);
                                    }
                                }
                            }
                        });
            }
        });
        searchCtrlDeparture.getBtnClear ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                showSearchError (txtDepart, listCityDepart);
            }
        });

        // DESTINATION search and clear
        searchCtrlDestination = new ControlSearch ();
        searchCtrlDestination.getBtnSearch ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (selectedDepartureLoc != null) {
                    JKiosk3.getKeyboard ().showKeyboard (new TextField (), "Enter search text", "",
                            false, false, new KeyboardResult () {
                                @Override
                                public void onDone(String value) {
                                    if (value != null) {
                                        listCityDest.clear ();
                                        for (CoachListItem b : coachListItemRespCities.getListItems ()) {
                                            if (b.getName ().toLowerCase (Locale.ENGLISH).contains (value.toLowerCase (Locale.ENGLISH))) {
                                                listCityDest.add (b);
                                            }
                                        }
                                        if (!listCityDest.isEmpty ()) {
                                            showCityList (CoachUtil.LOCATION_DESTINATION, txtDest, listCityDest);
                                        } else {
                                            JKiosk3.getMsgBox ().showMsgBox ("No Search Results",
                                                    "Please enter a different search term", null);
                                            showSearchError (txtDest, listCityDest);
                                        }
                                    }
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Destination Location", "Please select Departure Location FIRST", null);
                }
            }
        });
        searchCtrlDestination.getBtnClear ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                showSearchError (txtDest, listCityDest);
            }
        });
    }

    private void showSearchError(TextField textField, List<CoachListItem> listCities) {
        if (!textField.getText ().isEmpty ()) {
            textField.clear ();
        }
        resetCityList (listCities);
    }

    private GridPane showCoachTicketBookStep1() {

//        ObservableList<Integer> listseatsA = FXCollections.observableArrayList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        ObservableList<Integer> listseatsA = FXCollections.observableArrayList (1, 2, 3, 4, 5);

        String radStyle = "-fx-font-size: 22px; -fx-font-weight: bold;";

        Label lblHead1 = JKText.getLblDk (CoachUtil.COACH_PG_HEAD, JKText.FONT_B_24);
        Label lblHead2 = JKText.getLblDk ("Select Trips Required", JKText.FONT_B_22);

        VBox vbHead = JKNode.getPageDblHeadVB (0, lblHead1, lblHead2);

        ToggleGroup togTrips = new ToggleGroup ();

        radSingle = new RadioButton ("One Way");
        radSingle.setStyle (radStyle);
        radSingle.setToggleGroup (togTrips);
        radSingle.setSelected (true);

        radReturn = new RadioButton ("Return");
        radReturn.setStyle (radStyle);
        radReturn.setToggleGroup (togTrips);
        if (CoachTicketSale.getInstance ().isReturnTrip ()) {
            radReturn.setSelected (true);
        }

        HBox hbRad = JKLayout.getHBoxLeft (JKLayout.sp, (5 * JKLayout.sp));
        hbRad.getChildren ().addAll (radSingle, radReturn);
        GridPane.setColumnSpan (hbRad, 2);

        Label lblDepart = JKText.getLblDk ("Depart From", JKText.FONT_B_20);
        lblDepart.setMaxWidth (JKLayout.btnSmW);
        lblDepart.setMinWidth (JKLayout.btnSmW);

        Label lblDest = JKText.getLblDk ("Destination", JKText.FONT_B_20);

        Label lblDateDepart = JKText.getLblDk ("Depart Date", JKText.FONT_B_20);
        Label lblDateReturn = JKText.getLblDk ("Return Date", JKText.FONT_B_20);

        txtDepart = new TextField ();
        if (CoachTicketSale.getInstance ().getDepartureLoc () != null) {
            txtDepart.setText (CoachTicketSale.getInstance ().getDepartureLoc ().getName ());
        }
        txtDepart.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                resetCityList (listCityDepart);
                showCityList (CoachUtil.LOCATION_BOARDING, txtDepart, listCityDepart);
            }
        });

        HBox hbDepart = CoachCarrierLayouts.getHBoxCoachBook1 (txtDepart, searchCtrlDeparture);

        txtDest = new TextField ();
        if (CoachTicketSale.getInstance ().getDestinationLoc () != null) {
            txtDest.setText (CoachTicketSale.getInstance ().getDestinationLoc ().getName ());
        }
        txtDest.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (selectedDepartureLoc != null) {
                    resetCityList (listCityDest);
                    showCityList (CoachUtil.LOCATION_DESTINATION, txtDest, listCityDest);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Destination Location", "Please select Departure Location FIRST", null);
                }
            }
        });

        HBox hbDest = CoachCarrierLayouts.getHBoxCoachBook1 (txtDest, searchCtrlDestination);

        txtDateDepart = CoachCarrierLayouts.getTextFieldCoachDateSelect ();
        HBox hbDateDepart = CoachCarrierLayouts.getHBoxCoachBook1 (txtDateDepart, JKNode.getSearchPlaceHolderInactive ());

        txtDateReturn = CoachCarrierLayouts.getTextFieldCoachDateSelect ();
        txtDateReturn.setDisable (true);
        if (CoachTicketSale.getInstance ().isReturnTrip ()) {
            txtDateReturn.setDisable (false);
        }

        HBox hbDateReturn = CoachCarrierLayouts.getHBoxCoachBook1 (txtDateReturn, JKNode.getSearchPlaceHolderInactive ());

        Label lblSeats = JKText.getLblDk ("Seats", JKText.FONT_B_20);
        cbSeats = CoachCarrierLayouts.getComboBoxList (listseatsA);
        cbSeats.getSelectionModel ().select (0);

        Button btnClearAll = JKNode.getBtnPopupDbl ("clear all");
        GridPane.setHalignment (btnClearAll, HPos.RIGHT);
        btnClearAll.setTranslateX (-3);
        btnClearAll.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event t) {
                onClickClearAll ();
            }
        });

        radReturn.selectedProperty ().addListener (new ChangeListener<Boolean> () {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean aBoolean, Boolean t1) {
                if (t1) {
                    txtDateReturn.setDisable (false);
                } else {
                    txtDateReturn.clear ();
                    txtDateReturn.setDisable (true);
                }
            }
        });

        GridPane grid = JKLayout.getGridContent2ColFixedHt (0.25, 0.75, CoachCarrierLayouts.COACH_PG_HT);

        grid.add (vbHead, 0, 0, 2, 1);
        grid.add (hbRad, 0, 1);
        grid.add (JKNode.createGridSpanSep (2), 0, 2);
        grid.addRow (3, lblDepart, hbDepart);
        grid.addRow (4, lblDest, hbDest);
        grid.add (JKNode.createGridSpanSep (2), 0, 5);
        grid.addRow (6, lblDateDepart, hbDateDepart);
        grid.addRow (7, lblDateReturn, hbDateReturn);
        grid.add (JKNode.createGridSpanSep (2), 0, 8);
        grid.addRow (10, lblSeats, cbSeats);

        grid.add (btnClearAll, 1, 12);

        return grid;
    }

    private void resetCityList(List<CoachListItem> listCities) {
        listCities.clear ();
        listCities.addAll (coachListItemRespCities.getListItems ());
    }

    private void showCityList(String departOrDest, TextField txtField, List<CoachListItem> listToShow) {
        JKiosk3.getMsgBox ().showMsgBox (departOrDest, "", getCityPaging (txtField, departOrDest, listToShow), cityPopupWidth,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        //
                    }

                    @Override
                    public void onCancel() {
                        //
                    }
                });
    }

    private PagedList getCityPaging(final TextField txtfield, final String boardOrDestination, List<CoachListItem> cityList) {
        List<Node> cityItems = new ArrayList<> ();

        for (final CoachListItem i : cityList) {
            Label lbl = JKText.getLblDk (i.getName (), JKText.FONT_B_XXSM);
            Button btn = JKNode.getBtnPopup ("select");
            btn.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event evt) {
                    onSelectCity (txtfield, boardOrDestination, i);
                }
            });
            HBox hb = JKLayout.getHBox (JKLayout.spNum, 0);
            hb.setMaxWidth (cityPopupWidth - (4 * JKLayout.sp));
            hb.setMinWidth (cityPopupWidth - (4 * JKLayout.sp));
            hb.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event evt) {
                    onSelectCity (txtfield, boardOrDestination, i);
                }
            });
            hb.getChildren ().addAll (lbl, JKNode.getHSpacer (), btn);
            if (!i.getName ().equals ("")) {
                cityItems.add (hb);
            }
        }
        PagedList paging = new PagedList (cityItems, 10, (cityPopupWidth));
        return paging;
    }

    private void onSelectCity(TextField txtfield, String boardOrDestination, CoachListItem city) {
        switch (boardOrDestination) {
            case CoachUtil.LOCATION_BOARDING:
                selectedDepartureLoc = city;
                txtDest.setText ("");
                txtDest.setDisable (false);
                searchCtrlDestination.getBtnSearch ().setDisable (false);
                searchCtrlDestination.getBtnClear ().setDisable (false);
                break;
            case CoachUtil.LOCATION_DESTINATION:
                selectedDestinationLoc = city;
                break;
            default:
                break;
        }
        txtfield.setText (city.getName ());
        JKiosk3.getMsgBox ().toBack ();
        JKiosk3.getMsgBox ().setVisible (false);
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();

        nav.getBtnBack ().setDisable (true);

        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent (new TicketingMenu ());
            }
        });

        nav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (validateBoardAndDepart () && validateDates () && validateSeats ()) {
                    setSelectedValues ();
                    logSelections ();
                    requestAvailableRoutes ();
                }
            }
        });
        return nav;
    }

    private void setSelectedValues() {
        CoachTicketSale.getInstance().setReturnTrip(radReturn.isSelected());
        CoachTicketSale.getInstance().setDepartureLoc(selectedDepartureLoc);
        CoachTicketSale.getInstance().setDestinationLoc(selectedDestinationLoc);
        CoachTicketSale.getInstance().setDateDepart(dateDepart);
        CoachTicketSale.getInstance().setDateReturn(dateReturn);
        CoachTicketSale.getInstance().setSeats(cbSeats.getValue());

    }

    // Can be removed once all working, just here for reference now
    private void logSelections() {
        StringBuilder sb = new StringBuilder ("\r\n");
        sb.append ("Return trip?         : ").append (CoachTicketSale.getInstance ().isReturnTrip ()).append ("\r\n");
        sb.append ("Departure Location   : ").append (CoachTicketSale.getInstance ().getDepartureLoc ().getName ()).append ("\r\n");
        sb.append ("Destination Location : ").append (CoachTicketSale.getInstance ().getDestinationLoc ().getName ()).append ("\r\n");
        sb.append ("Departure Date       : ").append (sdf.format (CoachTicketSale.getInstance ().getDateDepart ())).append ("\r\n");
        if (radReturn.isSelected ()) {
            sb.append ("Return Date          : ").append (sdf.format (CoachTicketSale.getInstance ().getDateReturn ())).append ("\r\n");
        }
        sb.append ("Seats          : ").append (CoachTicketSale.getInstance ().getSeats ()).append ("\r\n");

        logger.info (sb.toString ());
    }

    private void requestAvailableRoutes() {
        CoachAvailabilityReq availabilityReq = new CoachAvailabilityReq ();
        availabilityReq.setReturnTrip (radReturn.isSelected ());
        availabilityReq.setDepartureLoc (selectedDepartureLoc.getCode ());
        availabilityReq.setDestinationLoc (selectedDestinationLoc.getCode ());
        availabilityReq.setDepartureDate (dateDepart);
        availabilityReq.setReturnDate (dateReturn);
        availabilityReq.setSeats (cbSeats.getValue ());
        availabilityReq.setCarrier ("Carma");
        availabilityReq.setTicketClass ("");

        CoachUtil.getCoachAvailability (availabilityReq, new CoachUtil.CoachAvailabilityResult () {
            @Override
            public void coachAvailabilityResult(CoachAvailabilityResp availabilityResp) {
                if (availabilityResp.isSuccess ()) {
                    if (!availabilityResp.getRoutes ().isEmpty ()) {
                        CoachTicketSale.getInstance ().setCoachAvailabilityResp (availabilityResp);
                        SceneSales.clearAndChangeContent (new CoachBook2a (CoachUtil.TRIP_DEPART));
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("Available Routes",
                                "No Routes found for selected criteria", null);
                    }

                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Error retrieving Routes", !availabilityResp.getAeonErrorMessage ().isEmpty () ?
                            "A" + availabilityResp.getAeonErrorCode () + " - " + availabilityResp.getAeonErrorMessage () :
                            "B" + availabilityResp.getErrorCode () + " - " + availabilityResp.getErrorMessage (), null);
                }
            }
        });
    }

    private boolean validateBoardAndDepart() {
        if (txtDepart.getText ().isEmpty () || txtDest.getText ().isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Departure / Destination", "\nPlease complete both 'Depart From' and 'Destination' fields", null);
            return false;
        }
        if (selectedDepartureLoc.getCode ().equals (selectedDestinationLoc.getCode ())) {
            JKiosk3.getMsgBox ().showMsgBox ("Departure / Destination",
                    "\n'Depart From' and 'Destination' cannot be the same.\n\nPlease select a different Departure or Destination", null);
            return false;
        }
        return true;
    }

    private boolean validateDates() {
        if (txtDateDepart.getText ().isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Invalid Date", "\n'Depart Date' field cannot be empty", null);
            return false;
        }
        if (radReturn.isSelected () && txtDateReturn.getText ().isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Invalid Date", "\nIf 'Return' is selected, \n\n'Return Date' field cannot be empty", null);
            return false;
        }
        try {

            Date today = sdf.parse (JKText.getDateDisplay (new Date ()));

            dateDepart = sdf.parse (txtDateDepart.getText ());

            if (dateDepart.before (today)) {
                JKiosk3.getMsgBox ().showMsgBox ("Invalid Date", "\n'Depart Date' cannot be before today", null);
                return false;
            }

            if (radReturn.isSelected ()) {
                dateReturn = sdf.parse (txtDateReturn.getText ());

                if (dateReturn.before (dateDepart)) {
                    JKiosk3.getMsgBox ().showMsgBox ("Invalid Date", "\n'Return Date' must be AFTER 'Depart Date'", null);
                    return false;
                }
            }
        } catch (ParseException ex) {
            JKiosk3.getMsgBox ().showMsgBox ("Invalid Date Format", "\nPlease enter date in format 'dd/MM/yyyy'", null);
            logger.log (Level.SEVERE, ex.getMessage (), ex);
            return false;
        }
        return true;
    }

    private boolean validateSeats() {
        if (cbSeats.getSelectionModel ().getSelectedItem () == 0) {
            JKiosk3.getMsgBox ().showMsgBox ("Seats", "\nNo seats selected.  Please select number of seats required.", null);
            return false;
        }

        return true;
    }

    private void onClickClearAll() {
        radSingle.setSelected (true);
        txtDepart.clear ();
        txtDest.clear ();
        txtDateDepart.clear ();
        txtDateReturn.clear ();
        cbSeats.getSelectionModel ().selectFirst ();
    }

}
//
// =======================================================

//    private ComboBox<Integer> cbAdult;
//    private ComboBox<Integer> cbChild;
//    private ComboBox<Integer> cbInfant;

//        ObservableList<Integer> listseats = FXCollections.observableArrayList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

//        Label lblSeatsAdult = JKText.getLblDk("Adult", JKText.FONT_B_20);
//        Label lblSeatsAdultInfo = JKText.getLblDk("(13 years and over)", JKText.FONT_B_XXSM);
//        lblSeatsAdult.setTranslateX(3 * JKLayout.sp);
//        cbAdult = CoachCarrierLayouts.getComboBoxList(listseatsA);
//        cbAdult.getSelectionModel().select(0);
//
//        HBox hbAdult = JKLayout.getHBoxLeft(0, (1 * JKLayout.sp));
//        hbAdult.getChildren().addAll(cbAdult, lblSeatsAdultInfo);

//        Label lblSeatsChild = JKText.getLblDk("Child", JKText.FONT_B_20);
//        Label lblSeatsChildInfo = JKText.getLblDk("(Up to 12 years)", JKText.FONT_B_XXSM);
//        lblSeatsChild.setTranslateX(3 * JKLayout.sp);
//        cbChild = CoachCarrierLayouts.getComboBoxList(listseats);
//
//        HBox hbChild = JKLayout.getHBoxLeft(0, (1 * JKLayout.sp));
//        hbChild.getChildren().addAll(cbChild, lblSeatsChildInfo);
//
//        Label lblSeatsInfant = JKText.getLblDk("Infant", JKText.FONT_B_20);
//        Label lblSeatsInfantInfo = JKText.getLblDk("(On own seat, NOT on Adult's lap)", JKText.FONT_B_XXSM);
//        lblSeatsInfant.setTranslateX(3 * JKLayout.sp);
//        cbInfant = CoachCarrierLayouts.getComboBoxList(listseats);
//
//        HBox hbInfant = JKLayout.getHBoxLeft(0, (1 * JKLayout.sp));
//        hbInfant.getChildren().addAll(cbInfant, lblSeatsInfantInfo);

//        grid.addRow(9, lblSeatsAdult, hbAdult);
//        grid.addRow(10, lblSeatsChild, hbChild);
//        grid.addRow(11, lblSeatsInfant, hbInfant);

//        CoachTicketSale.getInstance().setSeatsAdult(cbAdult.getValue());
//        CoachTicketSale.getInstance().setSeatsChild(cbChild.getValue());
//        CoachTicketSale.getInstance().setSeatsInfant(cbInfant.getValue());

//        sb.append("Adult seats          : ").append(CoachTicketSale.getInstance().getSeatsAdult()).append("\r\n");
//        sb.append("Child seats          : ").append(CoachTicketSale.getInstance().getSeatsChild()).append("\r\n");
//        sb.append("Infant seats         : ").append(CoachTicketSale.getInstance().getSeatsInfant()).append("\r\n");

//        availabilityReq.setSeatsAdult(cbAdult.getValue());
//        availabilityReq.setSeatsChild(cbChild.getValue());
//        availabilityReq.setSeatsInfant(cbInfant.getValue());

//        if (cbAdult.getSelectionModel().getSelectedItem() == 0
//                && cbChild.getSelectionModel().getSelectedItem() == 0
//                && cbInfant.getSelectionModel().getSelectedItem() == 0) {
//            JKiosk3.getMsgBox().showMsgBox("Seats", "\nNo seats selected.  Please select number of seats required.", null);
//            return false;
//        }
//        if (cbAdult.getSelectionModel().getSelectedItem() == 0
//                && cbInfant.getSelectionModel().getSelectedItem() > 0) {
//            JKiosk3.getMsgBox().showMsgBox("Seats", "\nInfant seats cannot be booked without an accompanying Adult.", null);
//            return false;
//        }
//        double countAdults = (double) cbAdult.getValue();
//        double countChildren = (double) cbChild.getValue() + cbInfant.getValue();
//
//        System.out.println("adult count = " + countAdults);
//        System.out.println("child count = " + countChildren);
//        double ratio = countChildren / countAdults;
//        System.out.println("ratio = " + ratio);
//        if (ratio > 3.0) {
//            JKiosk3.getMsgBox().showMsgBox("Child and Infant Seats", "\nInfant seats cannot be booked without an accompanying Adult.", null);
//            return false;
//        }

//        cbAdult.getSelectionModel().select(1);
//        cbChild.getSelectionModel().selectFirst();
//        cbInfant.getSelectionModel().selectFirst();