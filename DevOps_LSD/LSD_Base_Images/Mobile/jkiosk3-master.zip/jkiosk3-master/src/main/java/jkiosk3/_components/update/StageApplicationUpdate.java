package jkiosk3._components.update;

import Download.HttpUtils;
import Download.ThreadedDownload;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3.StageJKiosk;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.ResultCallback;

public class StageApplicationUpdate extends Stage {

    private final static Logger logger = Logger.getLogger(StageApplicationUpdate.class.getName());

    private final double stageWidth = StageJKiosk.getSceneWidth();
    private final double stageHeight = StageJKiosk.getSceneHeight();
    private Stage stageAppUpdate;
    private StackPane root;
    private ProgressIndicator prog;
    private final ResultCallback finalResult;
    //
    private ThreadedDownload threadedDownload;
    private Timer t;

    public StageApplicationUpdate(ResultCallback finalResult) {
        this.finalResult = finalResult;
        loadAppUpdateStage();
    }

    private void loadAppUpdateStage() {

        stageAppUpdate = new Stage();
        stageAppUpdate.initOwner(JKiosk3.getMainStage());
        stageAppUpdate.setTitle("Updating Application");
        stageAppUpdate.initStyle(StageStyle.TRANSPARENT);
        stageAppUpdate.initModality(Modality.APPLICATION_MODAL);
        stageAppUpdate.setWidth(stageWidth);
        stageAppUpdate.setHeight(stageHeight);

        root = new StackPane();

        VBox vb = showUpdateAvailable();

        root.getChildren().add(vb);

        Scene scene = new Scene(root, stageWidth, stageHeight);

        scene.getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/default.css").toExternalForm());
        scene.getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/stageupdate.css").toExternalForm());

        stageAppUpdate.setScene(scene);
        stageAppUpdate.showAndWait();
    }

    private VBox showUpdateAvailable() {
        VBox vb = new VBox(45);
        vb.setPrefSize(stageWidth, stageHeight);
        vb.getStyleClass().add("vbDownload");

        Label lblUpdate = new Label("An Application Update is Available");
        lblUpdate.getStyleClass().add("lblLg");

        Label lblInfo = new Label("Update NOW or LATER");
        lblInfo.getStyleClass().add("lblMed");

        Button btnNow = JKNode.getBtnSm("NOW");
        btnNow.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        root.getChildren().clear();
                        root.getChildren().add(showDownloadContent());
                        getZipDownload();
                    }
                });
            }
        });

        Button btnLater = JKNode.getBtnSm("LATER");
        btnLater.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                finalResult.onResult(true);
                stageAppUpdate.close();
            }
        });

        HBox hbBtnsUpdate = JKLayout.getHBox(30, 45);
        hbBtnsUpdate.getChildren().addAll(btnNow, btnLater);

        vb.getChildren().addAll(lblUpdate, lblInfo, hbBtnsUpdate);

        return vb;
    }



    private VBox showDownloadContent() {
        VBox vbDL = new VBox(45);
        vbDL.setPadding(new Insets(30));
        vbDL.getStyleClass().add("vbDownload");
        vbDL.setPrefSize(stageWidth, stageHeight);
        prog = new ProgressIndicator();
        prog.setPrefSize(50, 50);
        prog.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                stageAppUpdate.close();
            }
        });

        Label lblDownloading = new Label("Downloading");
        lblDownloading.getStyleClass().add("lblLg");
        Label lblCurrent = new Label(StageUpdates.DOWNLOAD_APPLICATION_UPDATE);
        lblCurrent.getStyleClass().add("lblXLg");
        Label lblPatience = new Label("Please be patient while JKiosk downloads Application Update");
        lblPatience.getStyleClass().add("lblMed");
        lblPatience.setWrapText(true);
        lblPatience.setTextAlignment(TextAlignment.CENTER);
        Label lblInfo = new Label("When complete, the JKiosk application will close and restart");
        lblInfo.getStyleClass().add("lblMed");
        lblInfo.setWrapText(true);
        lblInfo.setTextAlignment(TextAlignment.CENTER);

        vbDL.getChildren().addAll(prog, lblDownloading, lblCurrent, lblPatience, lblInfo);

        return vbDL;
    }



    private void getZipDownload() {
        threadedDownload = new ThreadedDownload(JK3Config.getAppUpdatePath(), JK3Config.getAppInstallPath().concat(JK3Config.getAppInstallFile()), true);
        t = new Timer();
        t.schedule(new TimerTask() {
            @Override
            public void run() {
                showProgress();
            }
        }, 1000);
    }

    private void showProgress() {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {

                boolean done = false;
                if (threadedDownload.isNotNew()) {
                    done = true;
                    finalResult.onResult(true);
                } else {
                    double percent = threadedDownload.getProgress();
                    prog.setProgress(percent / 100);
                    if (threadedDownload.isDone()) {
                        // this should check the file size of the remote file vs the local file
                        if (HttpUtils.isLocalFileComplete(JK3Config.getAppUpdatePath(),
                                JK3Config.getAppInstallPath().concat(JK3Config.getAppInstallFile()))) {
                            logger.info(("   download is done, files match : ").concat(StageUpdates.DOWNLOAD_APPLICATION_UPDATE));
                            // do not unzip - the AutoUpdater unzips the file
                            doAutoUpdate();
                        }
                    } else if (threadedDownload.isFailed()) {
                        logger.info(("   download failed : ").concat(StageUpdates.DOWNLOAD_APPLICATION_UPDATE));
                        done = true;
                        finalResult.onResult(false);
                        // Do we need this???
                        stageAppUpdate.close();
                    }
                }
                // added 2017-01-31
                if (threadedDownload.isFailed()) {
                    logger.info(("   download failed : ").concat(StageUpdates.DOWNLOAD_APPLICATION_UPDATE));
                    done = true;
                    finalResult.onResult(false);
                    stageAppUpdate.close();
                }
                // end

                if (!done) {
                    t.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            showProgress();
                        }
                    }, 1000);
                } else {
                    t.cancel();
                }
            }
        });
    }

    //    private boolean isUnpackZip() {
//        Installer ins = new Installer(JK3Config.getAppInstallPath().concat(JK3Config.getAppInstallFile()), JK3Config.getAppInstallPath());
//        return ins.install();
//    }
//    
    private void doAutoUpdate() {

        try {
            String javaBin = System.getProperty("java.home") + File.separator + "bin" + File.separator + "java";
            String pathToApp = JK3Config.getAutoUpdater();

            File filePathToAutoUpdater = new File(pathToApp);

            String fileName = filePathToAutoUpdater.getAbsolutePath();
            logger.info(("path to current jar file = ").concat(fileName));

            final ArrayList<String> command = new ArrayList<>();
            command.add(javaBin);
            command.add("-jar");
            /* Path to the AutoUpdater.jar file */
            command.add(filePathToAutoUpdater.getPath());
            /* args 0 - path to the zip file to be unzipped */
            command.add(JK3Config.getAppInstallPath() + JK3Config.getAppInstallFile());
            /* args 1 - path in which to unzip */
            command.add(JK3Config.getAppInstallPath());
            /* args 2 - path to the file to be run when done */
            command.add(JK3Config.getAppInstallPath() + "JKiosk3.jar");

//            /* args 3 - path to the file listing the lib files */
//            command.add(JK3Config.getFileUpdatePath());
//            /* args 4 - filename of the file listing the lib files */
//            command.add(JK3Config.LIST_LIB_FILES);

            logger.info(("command sent to AutoUpdater : ").concat(command.toString()));

            ProcessBuilder proc = new ProcessBuilder(command);
            proc.start();

            System.exit(0);
        } catch (IOException e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
    }
}
