package jkiosk3._common;

/**
 *
 * @author Val
 */
public interface ResultCallback {

    public void onResult(boolean result);
}
