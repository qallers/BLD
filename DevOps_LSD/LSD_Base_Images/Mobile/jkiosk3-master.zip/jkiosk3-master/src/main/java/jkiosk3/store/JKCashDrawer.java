package jkiosk3.store;

/**
 *
 * @author Val
 */
public class JKCashDrawer {

    private static StoreJKCashDrawer cashDrawerConfig;

    public static StoreJKCashDrawer getCashDrawerConfig() {
        if (cashDrawerConfig == null) {
            cashDrawerConfig = ((StoreJKCashDrawer) Store.loadObject(JKCashDrawer.class.getSimpleName()));
        }
        if (cashDrawerConfig == null) {
            cashDrawerConfig = new StoreJKCashDrawer();
        }
        return cashDrawerConfig;
    }

    public static boolean saveCashDrawerConfig() {
        getCashDrawerConfig();
        return Store.saveObject(JKCashDrawer.class.getSimpleName(), cashDrawerConfig);
    }
}
