package jkiosk3.store;

/**
 *
 * @author Val
 */
public class JKSetup {

    private static StoreJKSetup systemSetup;

    public static StoreJKSetup getSystemSetup() {
        if (systemSetup == null) {
            systemSetup = ((StoreJKSetup) Store.loadObject(JKSetup.class.getSimpleName()));
        }
        if (systemSetup == null) {
            systemSetup = new StoreJKSetup();
        }
        return systemSetup;
    }

    public static boolean saveSystemSetup() {
        getSystemSetup();
        return Store.saveObject(JKSetup.class.getSimpleName(), systemSetup);
    }
}
