package jkiosk3.store;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class StoreJKSetPrintedQueue implements Serializable {
    
    private final List<String> listTransRefs = new ArrayList<>();
    
    public List<String> getListTransRefs() {
        return listTransRefs;
    }
}
