package jkiosk3.users;

import aeonusers.*;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.concurrent.Worker.State;
import javafx.scene.control.PasswordField;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3.Version;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.SummaryTableView;
import jkiosk3.store.*;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

public class UserUtil {

    private final static Logger logger = Logger.getLogger(UserUtil.class.getName());
    public final static String USER_NEW = "New User";
    public final static String USER_EDIT = "Edit User";
    //
    public final static int LEVEL_CASHIER = 0;
    public final static int LEVEL_SUPERVISOR = 1;
    public final static int LEVEL_CASHIER_PLUS = 2;
    //
    private static String userPin;
    private final static String serial = JKSystem.getSystemConfig().getSerial();
    private final static String versionNum = Version.getSoftwareVersion() + Version.getVersionNum();
    private static UserConnection uc;
    //
    private static List<User> userList;
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdown = 60;

    private static User currentUser;
    private static int userLevel;

    /**
     * Private Constructor to hide implicit public one.
     */
    private UserUtil() {
    }

    public static UserConnection getUserConnect() {
        UserConnection userConnect = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();

        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            userConnect = new UserConnection(server, port, secureConnect);
            userConnect.setTimeout(countdown);

            JKSystem.getSystemConfig().setServer(server);
            JKSystem.getSystemConfig().setPort(port);
            JKSystem.getSystemConfig().setSecureConn(secureConnect);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
            userConnect = userConnectNonSecureServer();
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
            userConnect = userConnectNonSecureServer();
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
            userConnect = userConnectNonSecureServer();
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
            userConnect = userConnectNonSecureServer();
        }
        return userConnect;
    }

    public static UserConnection getUserConnectOnce() {
        UserConnection userConnect = null;
        String server = JK3Config.getAeonSSL();
        int port = Integer.parseInt(JK3Config.getAeonSSLPort());
        final boolean SSL = true;

        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            userConnect = new UserConnection(server, port, SSL);
            userConnect.setTimeout(countdown);

            JKSystem.getSystemConfig().setServer(server);
            JKSystem.getSystemConfig().setPort(port);
            JKSystem.getSystemConfig().setSecureConn(SSL);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
            userConnect = userConnectNonSecureServer();
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
            userConnect = userConnectNonSecureServer();
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
            userConnect = userConnectNonSecureServer();
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
            userConnect = userConnectNonSecureServer();
        }

            logger.log(Level.INFO, String.format("AEON Server Connected: %s, Port: %s",
                JKSystem.getSystemConfig().getServer(), JKSystem.getSystemConfig().getPort()));

        return userConnect;
    }

    public static UserConnection userConnectNonSecureServer(){
        UserConnection userConnect = null;
        String server = JK3Config.getNonAeonSSL();
        int port = Integer.parseInt(JK3Config.getNonAeonSSLPort());;
        final boolean SSL = false;

        try{
            userConnect = new UserConnection(server, port, SSL);
            userConnect.setTimeout(countdown);

            JKSystem.getSystemConfig().setServer(server);
            JKSystem.getSystemConfig().setPort(port);
            JKSystem.getSystemConfig().setSecureConn(SSL);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
        }
        return userConnect;
    }

    private static User getLoggedInUser(String pin) throws RuntimeException {
        User user = null;

        try {
            uc = getUserConnectOnce();
            userPin = pin;

            UserLoginRequest loginRequest = new UserLoginRequest();
            loginRequest.setUserPin(pin);
            loginRequest.setDeviceID(JKSystem.getSystemConfig().getDeviceId());
            loginRequest.setDeviceSerial(serial);
            loginRequest.setDeviceVersion(versionNum);
            loginRequest.setDeviceLocation(JKDevLocation.getDeviceLocation().getFormattedLocation());

            user = uc.login(loginRequest);

//            user = uc.login(userPin, JKSystem.getSystemConfig().getDeviceId(), serial, versionNum);
            CurrentUser.setLoggedInOnline(true);
            user.setUserPin(pin);

            CurrentUser.setUser(user);
//            if (JKOptions.getOptions().isSalesPersonLogin()) {
//                CurrentUser.setSalesUser(null);
//            } else {
//                CurrentUser.setSalesUser(user);
//            }

            if (userList == null) {
                userList = getOnlineUsersList(userPin);
                //
                /* Only save the Transaction Types if the User is a Supervisor. */
                /* Cashier does not necessarily have all Transaction Types for this Device available. */
                if (user.getUserLevel() == 1) {
                    try {
                        JKTransTypes.saveTransTypes(user.getUserTransactionTypes());
                        System.out.println("no exception - saved new version");
                    } catch (ClassCastException cc) {
                        logger.log(Level.SEVERE, cc.getMessage(), cc);
                        JKTransTypes.deleteJKTransTypeFile();
                        logger.info("JKTransTypes file deleted - saving new version");
                        JKTransTypes.saveTransTypes(user.getUserTransactionTypes());
                    }
                }
            }

        } catch (Throwable t) {
            JKiosk3.getNumPad().hideNumPad();
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("User Login Error", t);
        } finally {
            if (uc != null) {
                uc.disconnect();
            }
        }
        return user;
    }


    public static List<User> getOnlineUsersList(String pin) throws RuntimeException {
        userList = new ArrayList<>();

        if (CurrentUser.getUser() == null) {
            userPin = pin;
        } else {
            userPin = CurrentUser.getUser().getUserPin();
        }

        try {
            uc = getUserConnect();
            if (uc != null) {
                uc.login(userPin, JKSystem.getSystemConfig().getDeviceId(), serial, versionNum);
                userList = uc.getUsersList();

                Collections.sort(userList, new Comparator<User>() {
                    @Override
                    public int compare(User u1, User u2) {
                        return u1.getUserName().compareTo(u2.getUserName());
                    }
                });
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("User List Error", t);
        } finally {
            if (uc != null) {
                uc.disconnect();
            }
        }

        return userList;
    }

    private static UserListResp getUserListResp(String pin) throws RuntimeException {
        UserListResp userListResp = new UserListResp();

        if (CurrentUser.getUser() == null) {
            userPin = pin;
        } else {
            userPin = CurrentUser.getUser().getUserPin();
        }

        try {
            uc = getUserConnect();
            if (uc != null) {
                uc.login(userPin, JKSystem.getSystemConfig().getDeviceId(), serial, versionNum);
                userListResp = uc.getUserListResponse();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("User List Error", t);
        } finally {
            if (uc != null) {
                uc.disconnect();
            }
        }

        return userListResp;
    }

    public static List<UserPermission> getListUserPermissions(String pin) throws RuntimeException {
        List<UserPermission> listPermissions = new ArrayList<>();

        System.out.println("CurrentUser pin = " + CurrentUser.getUser().getUserPin());
        if (CurrentUser.getUser() == null) {
            userPin = pin;
        } else {
            userPin = CurrentUser.getUser().getUserPin();
        }

        try {
            uc = getUserConnect();
            if (uc != null) {
                uc.login(userPin, JKSystem.getSystemConfig().getDeviceId(), serial, versionNum);
                listPermissions = uc.getListPermissionTypes();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("User Permissions Error", t);
        } finally {
            if (uc != null) {
                uc.disconnect();
            }
        }

        return listPermissions;
    }

    public static String getPermissionStringCurrentUser(String pin) {
        String permissionString = "";
        for (User u : userList) {
            if (pin.equals(u.getUserPin())) {
                permissionString = u.getUserPermissionString();
            }
        }
        return permissionString;
    }

    public static void saveNewUser(User newAeonUser) {
        UserResult userRes = addUser(newAeonUser.getUserName(),
                newAeonUser.getUserPin(),
                newAeonUser.getUserLevel(),
                newAeonUser.getUserPermissions());

        String msg = userRes.getMessage();

        if (userRes.getSuccess() == 0) {
            JKiosk3.getMsgBox().showMsgBox("Add User Failed", msg, null);
        } else if (userRes.getSuccess() == 1) {
            JKiosk3.getMsgBox().showMsgBox("Success!", msg, null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK,
                    new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            SceneUsers.getVbUsersContent().getChildren().clear();
                            updateUserListView();
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        }
    }

    private static UserResult addUser(String name, String pin, int lvl, List<UserPermission> permissions) throws RuntimeException {
        UserResult res = new UserResult();

        userPin = CurrentUser.getUser().getUserPin();
        uc = getUserConnect();

        try {
            if (uc != null) {
                uc.login(userPin, JKSystem.getSystemConfig().getDeviceId(), serial, versionNum);
                res = uc.addUser(name, pin, lvl, permissions);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("User Add Error", t);
        } finally {
            if (uc != null) {
                uc.disconnect();
            }
        }

        return res;
    }

    public static void saveEditUser(User editAeonUser, final boolean editSelf) {
        UserResult userRes = updateUserDetails(editAeonUser.getUserId(),
                editAeonUser.getUserName(),
                editAeonUser.getUserPin(),
                editAeonUser.getUserLevel(),
                editAeonUser.getUserPermissions());

        String msg = userRes.getMessage();

        if (userRes.getSuccess() == 0) {
            JKiosk3.getMsgBox().showMsgBox("Edit User Failed", msg, null);
        } else if (userRes.getSuccess() == 1) {
            JKiosk3.getMsgBox().showMsgBox("Success!", msg, null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK,
                    new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            if (editSelf) {
                                JKiosk3.changeScene(new JKioskLogin());
                            } else {
                                SceneUsers.getVbUsersContent().getChildren().clear();
                                updateUserListView();
                            }
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        }
    }

    private static UserResult updateUserDetails(int userId, String name, String pin, int lvl, List<UserPermission> listPermissions) throws RuntimeException {
        UserResult res = new UserResult();

        userPin = CurrentUser.getUser().getUserPin();
        uc = getUserConnect();

        try {
            if (uc != null) {
                uc.login(userPin, JKSystem.getSystemConfig().getDeviceId(), serial, versionNum);
                res = uc.updateUser(userId, name, pin, lvl, listPermissions);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("User Update Error", t);
        } finally {
            if (uc != null) {
                uc.disconnect();
            }
        }

        return res;
    }

    private static void updateUserListView() {
        getOnlineUsersList(CurrentUser.getUser().getUserPin(), new ListUsersResult() {

            @Override
            public void listUsersResult(List<User> listUsers) {
                if (listUsers != null) {
                    userList = listUsers;
                    ObservableList<String> users = getUsersByPin(listUsers);
                    SceneUsers.getListViewUsers().getItems().clear();
                    SceneUsers.getListViewUsers().setItems(users);
                }
            }
        });
    }

    public static ObservableList<String> getUsersByPin(List<User> listUsers) {
        final ObservableList<String> userNames = FXCollections.observableArrayList();
        if (listUsers != null) {
            Collections.sort(listUsers, new Comparator<User>() {
                @Override
                public int compare(User u1, User u2) {
                    return u1.getUserPin().compareTo(u2.getUserPin());
                }
            });

            for (User user : listUsers) {
                String userLvl = "";
                switch (user.getUserLevel()) {
                    case 0:                         // Cashier
                        userLvl = " C";
                        break;
                    case 1:                         // Supervisor
                        userLvl = " S";
                        break;
                    case 2:                         // Cashier Plus
                        userLvl = "CP";
                        break;
                    default:
                        JKiosk3.getMsgBox().showMsgBox("Error", "Invalid User Level found in data", null);
                }
                String showPin = user.getUserPin().substring(0, 2);
                String str = String.format("%-2s" + "%-2s" + "%-2s" + "%-2s" + "%-20s", showPin, "- ", userLvl, "- ", user.getUserName());
                if (!showPin.equals("01")) {
                    userNames.add(str);
                }
            }
        }
        return userNames;
    }

    public static void resetSalesUser(int src) {
        if (JKOptions.getOptions().isSalesPersonLogin()) {
            if (src == SalesUtil.SRC_BTN_AMT_DUE) {
                if (CurrentUser.getSalesUser() != null) {
                    CurrentUser.setSalesUser(null);
                    SceneSales.getLblSalesPerson().setText("");
                }
            } else if (src == SalesUtil.SRC_BTN_CANCEL) {
                if (CurrentUser.getSalesUser() != null && SummaryTableView.getSummaryRows().isEmpty()) {
                    CurrentUser.setSalesUser(null);
                    SceneSales.getLblSalesPerson().setText("");
                }
            }
        }
    }

    private static User getCurrentReportUser(final String userPin) {
        List<User> listUsers = getUserList();
        if (userList.isEmpty()) {
            listUsers = getOnlineUsersList(userPin);
        } else {
            listUsers = getUserList();
        }
        for (User u : listUsers) {
            if (userPin.equals(u.getUserPin())) {
                currentUser = u;
                userLevel = u.getUserLevel();
                break;
            }
        }
        return currentUser;
    }

    private static String getPermissionString(String userPin) {
        return getCurrentReportUser(userPin).getUserPermissionString();
    }

    public static List<String> getUserPermissionsAsList(String userPin) {
        String permString = getPermissionString(userPin);
        if (permString != null) {
            List<String> listPerms = Arrays.asList(permString.split(","));
            return listPerms;
        } else {
            return new ArrayList<>();
        }
    }

    public static void getSupervisorOverride(final SupervisorOverride supervisorOverride) {
        JKiosk3.getNumPad().showNumPad(new PasswordField(), "Supervisor Override", "", new NumberPadResult() {

            @Override
            public void onDone(String value) {
                logger.info(("PIN entered for Supervisor Authorisation : ").concat(value));
                isSupervisor(value, new UserUtil.SupervisorOverride() {

                    @Override
                    public void supervisorOverrideResult(Boolean isSupervisor) {
                        if (isSupervisor) {
                            logger.info(("  -  Supervisor Authorisation success, transaction can continue"));
                            supervisorOverride.supervisorOverrideResult(Boolean.TRUE);
                        } else {
                            supervisorOverride.supervisorOverrideResult(Boolean.FALSE);
                        }
                    }
                });
            }
        });
    }

    private static void isSupervisor(String pin, final SupervisorOverride isSupervisor) {
        List<User> listUsers = getUserList();
        User queryUser = null;
        if (userList.isEmpty()) {
            listUsers = getOnlineUsersList(pin);
        } else {
            listUsers = getUserList();
        }
        for (User u : listUsers) {
            System.out.println("u.getUserPin() = " + u.getUserPin() + "  -  u.getUserLevel() = " + u.getUserLevel());
            if (pin.equals(u.getUserPin())) {
                queryUser = u;
                System.out.println("queryUser = " + queryUser.getUserName());
                if (queryUser.getUserLevel() == 1) {
                    isSupervisor.supervisorOverrideResult(Boolean.TRUE);
                    break;
                } else {
                    showAuthorisationError("Not a Supervisor", isSupervisor);
                }
            }
            if (queryUser == null) {
                showAuthorisationError("Not a valid PIN", isSupervisor);
            }
        }
    }

    private static void showAuthorisationError(String reason, final SupervisorOverride isSupervisor) {
        JKiosk3.getMsgBox().showMsgBox("Authorisation Failed", reason, null,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult() {

                    @Override
                    public void onOk() {
                        isSupervisor.supervisorOverrideResult(Boolean.FALSE);
                        getSupervisorOverride(isSupervisor);
                    }

                    @Override
                    public void onCancel() {
                        isSupervisor.supervisorOverrideResult(Boolean.FALSE);
                    }
                });
    }

    private static SetPrintedResponse setTransactionPrinted(String transRef) throws RuntimeException {
        SetPrintedResponse res = new SetPrintedResponse();

        userPin = CurrentUser.getUser().getUserPin();
        uc = getUserConnect();
        String reference = SalesUtil.getUniqueRef();

        try {
            if (uc != null) {
                logger.info(("REQUEST TO SET PRINTED SENT TO SERVER - TRANSREF : ").concat(transRef));
                res = uc.setPrinted(userPin, JKSystem.getSystemConfig().getDeviceId(), serial, transRef, reference);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Set Transaction Printed Error", t);
        } finally {
            if (uc != null) {
                uc.disconnect();
            }
        }

        return res;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getLoggedInUser(final String pin, final LoggedInUserResult result) {
        JKiosk3.getBusy().showBusy("Checking User Details");

        final Task<User> taskLogin = new Task<User>() {
            @Override
            protected User call() throws Exception {
                return getLoggedInUser(pin);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.loggedInUserResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskUserCancelFail("Logged In User Error",
                        "Error Retrieving User Details - returning to Login", State.CANCELLED, errorMsg, new JKioskLogin());
            }

            @Override
            protected void failed() {
                taskutil.taskUserCancelFail("Logged In User Error",
                        "Error Retrieving User Details - returning to Login", State.FAILED, errorMsg, new JKioskLogin());
            }
        };

        new Thread(taskLogin).start();
        JKiosk3.getBusy().startCountdown(taskLogin, countdown);
    }

    public static void getOnlineUsersList(final String pin, final ListUsersResult result) {
        JKiosk3.getBusy().showBusy("Getting User List");

        final Task<List<User>> taskListUsers = new Task<List<User>>() {
            @Override
            protected List<User> call() throws Exception {
                return getOnlineUsersList(pin);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.listUsersResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskUserCancelFail("User List",
                        "Error Retrieving User List", State.CANCELLED, errorMsg, new JKioskLogin());
            }

            @Override
            protected void failed() {
                taskutil.taskUserCancelFail("User List",
                        "Error Retrieving User List", State.FAILED, errorMsg, new JKioskLogin());
            }
        };

        new Thread(taskListUsers).start();
        JKiosk3.getBusy().startCountdown(taskListUsers, countdown);
    }

    public static void getUserListResp(final String pin, final UserListRespResult result) {
        JKiosk3.getBusy().showBusy("Getting User List");

        final Task<UserListResp> taskListUsers = new Task<UserListResp>() {
            @Override
            protected UserListResp call() throws Exception {
                return getUserListResp(pin);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.userListRespResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskUserCancelFail("User List",
                        "Error Retrieving User List", State.CANCELLED, errorMsg, new JKioskLogin());
            }

            @Override
            protected void failed() {
                taskutil.taskUserCancelFail("User List",
                        "Error Retrieving User List", State.FAILED, errorMsg, new JKioskLogin());
            }
        };

        new Thread(taskListUsers).start();
        JKiosk3.getBusy().startCountdown(taskListUsers, countdown);
    }

    public static void setTransactionPrinted(final String transRef, final SetPrintedResponseResult result) {
        JKiosk3.getBusy().showBusy("Setting Transaction Printed");

        final Task<SetPrintedResponse> taskSetPrinted = new Task<SetPrintedResponse>() {
            @Override
            protected SetPrintedResponse call() throws Exception {
                return setTransactionPrinted(transRef);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.setPrintedResponseResult(getValue());
            }

            @Override
            protected void cancelled() {
                setTransactionPrintedCancelledFailed(State.CANCELLED, transRef, result);
            }

            @Override
            protected void failed() {
                setTransactionPrintedCancelledFailed(State.FAILED, transRef, result);
            }
        };
        new Thread(taskSetPrinted).start();
        JKiosk3.getBusy().startCountdown(taskSetPrinted, countdown);
    }

    private static void setTransactionPrintedCancelledFailed(State taskState, String transRef, SetPrintedResponseResult result) {
        JKiosk3.getBusy().hideBusy();
        logger.info(("Set Transaction Printed - ").concat(taskState.toString()));
        // show and LOG ErrorCode and ErrorText
        // log user out, go back to main login screen
//        JKiosk3.getMsgBox().showMsgBox("Print Error", "The current Transaction could not be marked as 'Printed'."
//                + "\nSystem will return to the Login screen at the end of the sale.", null,
//                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
//
//                    @Override
//                    public void onOk() {
////                        CurrentUser.setSalesUser(null);
////                        CurrentUser.setUser(null);
////                        JKiosk3.changeScene(new JKioskLogin());
//                    }
//
//                    @Override
//                    public void onCancel() {
//                        //
//                    }
//                });
        // -----------------------------
        // 2019-11-04  -  PRODDEFECT-868
//        if (taskState.equals(State.CANCELLED)) {
//            logger.info(("\t\t").concat("RETRY  -  set transaction printed for transRef : ").concat(transRef));
//            setTransactionPrinted(transRef, result);
//        }
    }

    // abstract 'result' classes
    public abstract static class LoggedInUserResult {

        public abstract void loggedInUserResult(User loggedInUser);
    }

    public abstract static class ListUsersResult {

        public abstract void listUsersResult(List<User> listUsers);
    }

    public abstract static class UserListRespResult {

        public abstract void userListRespResult(UserListResp userListResp);
    }

    public abstract static class SetPrintedResponseResult {

        public abstract void setPrintedResponseResult(SetPrintedResponse result);
    }

    public abstract static class SupervisorOverride {

        public abstract void supervisorOverrideResult(Boolean isSupervisor);
    }

    // getters
    public static List<User> getUserList() {
        return userList;
    }

    public static int getUserLevel() {
        return userLevel;
    }

}
