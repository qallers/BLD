package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.DailyBatchReport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.StageComponents;
import jkiosk3.printing.PrintHandler;

/**
 *
 * @author Valerie
 */
public class DailyBatch extends Region {

    private final static Logger logger = Logger.getLogger(DailyBatch.class.getName());
    private TextField txtDateSelect;
    private long dateInMillis;

    public DailyBatch() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getDailyBatchGrid());
        vb.getChildren().add(getPrintControl());

        getChildren().addAll(vb);
    }

    private GridPane getDailyBatchGrid() {

        VBox vbHead = JKNode.getReportHeadVB("View Daily Batch Report");

        Label lblDate = JKText.getLblDk("Select Date", JKText.FONT_B_XSM);
        lblDate.setMinWidth(JKLayout.btnSmW);

        txtDateSelect = new TextField();
        txtDateSelect.setPromptText("dd/MM/yyyy");
        txtDateSelect.setOnMouseReleased(new EventHandler() {

            @Override
            public void handle(Event t) {
//                JKiosk3.getCalendarPickerX().showCalendarPickerX(txtDateSelect);
                StageComponents.showStageCalendar(txtDateSelect);
            }
        });

        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);
        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblDate, txtDateSelect);

        return grid;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                if (isValidEntry()) {
                    showDailyBatchReport();
                }
            }
        };
    }

    private void showDailyBatchReport() {
        try {
            ReportUtil.getDailyBatchReport(dateInMillis, new ReportUtil.DailyBatchReportResult() {

                @Override
                public void dailyBatchReportResult(DailyBatchReport dailyBatchReport) {
                    if (dailyBatchReport.isSuccess()) {
                        AeonPrintJob aeonPrintJob = dailyBatchReport.getApj();
                        PrintHandler.handlePrintRequestReport("Daily Batch Report", aeonPrintJob);
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Daily Batch Report Error",
                                dailyBatchReport.getErrorCode() + " - " + dailyBatchReport.getErrorText(), null);
                    }
                }
            });
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
    }

    private boolean isValidEntry() {
        if (txtDateSelect.getText().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Select Date", "Please select a Date for Report", null);
            return false;
        } else {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                Date today = sdf.parse(JKText.getDateDisplay(new Date()));

                Date dateRequired = sdf.parse(txtDateSelect.getText());
                dateInMillis = dateRequired.getTime();

                if (dateRequired.after(today)) {
                    JKiosk3.getMsgBox().showMsgBox("Invalid Date", "Selected Date cannot be after today", null);
                    return false;
                }

            } catch (ParseException pe) {
                JKiosk3.getMsgBox().showMsgBox("Invalid Date Format", "Please enter date in format 'dd/MM/yyyy'", null);
                logger.log(Level.SEVERE, pe.getMessage(), pe);
                return false;
            }
        }

        return true;
    }
}
