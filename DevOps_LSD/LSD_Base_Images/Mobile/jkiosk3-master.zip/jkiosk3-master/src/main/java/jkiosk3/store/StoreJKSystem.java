package jkiosk3.store;

import java.io.Serializable;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Val
 */
public class StoreJKSystem implements Serializable {

    private String server;
    private int port;
    private int deviceId = 0;
    private boolean secureConn = false;
    private boolean autoConn = false;
    private String autoConnName = "Internet";
    private String serial = "";

    public boolean isAutoConn() {
        return autoConn;
    }

    public void setAutoConn(boolean autoConn) {
        this.autoConn = autoConn;
    }

    public String getAutoConnName() {
        return autoConnName;
    }

    public void setAutoConnName(String autoConnName) {
        this.autoConnName = autoConnName;
    }

    public int getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(int deviceId) {
        this.deviceId = deviceId;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public boolean isSecureConn() {
        return secureConn;
    }

    public void setSecureConn(boolean secureConn) {
        this.secureConn = secureConn;
    }

    public String getSerial() {
        String res = "_";
        try {
            for (NetworkInterface netint : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (netint.getHardwareAddress() != null) {
                    System.out.println(netint.getDisplayName());
                    System.out.println(netint.getHardwareAddress());
                    byte[] mac = netint.getHardwareAddress();
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < mac.length; i++) {
                        sb.append(String.format("%02X", mac[i], (i < mac.length - 1) ? "-" : ""));
                    }
//                    System.out.println(" : mac address : " + sb.toString());
//                    if (sb.charAt(0) != '0') {
                    res = sb.toString();
//                        System.out.println("mac address : " + res);
                    if (!res.isEmpty()) {
                        break;
                    }
//                    }
                }
            }
        } catch (SocketException e) {
            Logger.getLogger(StoreJKSystem.class.getName()).log(Level.SEVERE, e.getMessage(), e);
        }
        return res;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }
}
