package jkiosk3.store;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import jkiosk3.sales.SaleSummary;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class StoreJKPendingSale implements Serializable {

    // S(tore) = 19 : (1 + 9 = 10) (1 + 0 = 1)
    // J(K)  = 10 : (1 + 0 = 1)
    // P(ending) = 16 : (1 + 6 = 7)
    // S(ale) = 19 : (1 + 9 = 10) (1 + 0 = 1)
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 99001171L;
//    private ObservableList<SaleSummary> listSaleSummary = FXCollections.observableArrayList();
    private List<SaleSummary> listSaleSummary = new ArrayList<>();

//    public ObservableList<SaleSummary> getListSaleSummary() {
//        return listSaleSummary;
//    }

    public List<SaleSummary> getListSaleSummary() {
        return listSaleSummary;
    }
}
