package jkiosk3.sales.billpay.sapo;

import java.util.List;
import java.util.logging.Logger;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales._favourites.nfc.NFCUtilFav;
import jkiosk3.sales.billpay.BillPayProduct;

public class InputSAPOEskom extends Region {

    private final static Logger logger = Logger.getLogger(InputSAPOEskom.class.getName());

    private BillPayProduct product;
    private TextField txtBarcode;
    private ComboBox cbNumber;
    private TextField txtAccountNo;
    private TextField txtAccountNo2;
    private TextField txtAmountEsk;
    private boolean scannedBarcode;
    private double amountEsk;
    private String barcode;
    private String accountNum;
    private String accountStr;
    private String checkDigit;
    private String additionalString;
    private boolean showFavourites;
    private boolean showProductFavourite;

    public InputSAPOEskom(BillPayProduct product, boolean isNFCFavourite, boolean isProductFavourite) {
        this.product = product;
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;

        getChildren().add(getEskomEntryGrid());
    }

    private void checkAccNumFav() {
        if (!NFCUtilFav.getBillPayAccNumsFav(product).isEmpty()) {
            List<String> listAccNums = NFCUtilFav.getBillPayAccNumsFav(product);
            double inputW = (1 * (JKLayout.contentW - (3 * JKLayout.sp)) * 0.33);
            cbNumber = new ComboBox();
            cbNumber.setMaxWidth(inputW);
            cbNumber.setMinWidth(inputW);
            cbNumber.setEditable(true);
            cbNumber.setItems(FXCollections.observableArrayList(listAccNums));
            cbNumber.getEditor().setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event event) {
                    JKiosk3.getNumPad().showNumPad(cbNumber.getEditor(), "Account Number", "", new NumberPadResult() {
                        @Override
                        public void onDone(String value) {
                            if (!value.trim().equals("")) {
                                if (value.matches("\\d{10}")) {
                                    txtAccountNo.setText(value);
                                } else {
                                    txtAccountNo.setText("");
                                    JKiosk3.getMsgBox().showMsgBox("Account Number", "Account Number must be 10 digits", null);
                                }
                            } else {
                                JKiosk3.getMsgBox().showMsgBox("Account Number", "Account Number cannot be empty", null);
                            }
                        }
                    });
                }
            });
            cbNumber.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue observable, String oldValue, String newValue) {
                    txtAccountNo.setText(newValue);
                    txtAccountNo2.setText(newValue);
                }
            });
        }
    }

    private GridPane getEskomEntryGrid() {

        Label lblBarcode = JKText.getLblDk("Barcode", JKText.FONT_B_XSM);
        Label lblAccountNo = JKText.getLblDk("Account Number", JKText.FONT_B_XSM);
        Label lblAmountTel = JKText.getLblDk("Amount Due", JKText.FONT_B_XSM);

        txtBarcode = new TextField();
        txtBarcode.setPromptText("Scan Barcode");
        GridPane.setColumnSpan(txtBarcode, 2);
        txtBarcode.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtBarcode, "Barcode", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (value.trim().matches("\\d{36}")) {
                            logger.info(("Eskom barcode scanned - ").concat(value));
                            scannedBarcode = true;
                            setBarcodeValues(value);
                        } else {
                            txtBarcode.setText("");
                            scannedBarcode = false;
                            JKiosk3.getMsgBox().showMsgBox("Invalid Barcode", "Please try scanning Barcode again,\n\nor enter values below manually", null);
                        }
                    }
                });
//                }
            }
        });

        txtAccountNo = new TextField();
        txtAccountNo.setPromptText("Enter Account Number");
        txtAccountNo.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtAccountNo, "Account Number", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (!value.trim().equals("")) {
                            if (!value.matches("\\d{10}")) {
                                txtAccountNo.setText("");
                                JKiosk3.getMsgBox().showMsgBox("Account Number", "Account Number must be 10 digits", null);
                            }
                        } else {
                            JKiosk3.getMsgBox().showMsgBox("Account Number", "Account Number cannot be empty", null);
                        }
                    }
                });
//                }
            }
        });

        txtAccountNo2 = new TextField();
        txtAccountNo2.setPromptText("Re-enter Account Number");
        txtAccountNo2.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtAccountNo2, "Account Number", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (!value.trim().equals(txtAccountNo.getText())) {
                            txtAccountNo.setText("");
                            txtAccountNo2.setText("");
                            JKiosk3.getMsgBox().showMsgBox("Account Number", "Account Numbers entered do not match", null);
                        }
                    }
                });
//                }
            }
        });

        txtAmountEsk = new TextField();
        txtAmountEsk.setPromptText("Enter Amount Due");
        txtAmountEsk.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad().showNumPad(txtAmountEsk, "Enter Amount Due", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        amountEsk = SalesUtil.getAmountAsDouble(value, txtAmountEsk);
                        txtAmountEsk.setText(JKText.getDeciFormat(amountEsk));
                    }
                });
//                }
            }
        });

        checkAccNumFav();

        GridPane gridEsk = JKLayout.getGridPane3Col(0.33, 0.33, 0.33);

        gridEsk.addRow(1, lblBarcode, txtBarcode);
        if (showFavourites) {
            gridEsk.addRow(3, lblAccountNo, cbNumber, txtAccountNo2);
        } else if (showProductFavourite) {
            gridEsk.addRow(3, lblAccountNo, txtAccountNo, txtAccountNo2);
        } else {
            gridEsk.addRow(3, lblAccountNo, txtAccountNo, txtAccountNo2);
        }
//        gridEsk.addRow(3, lblAccountNo, txtAccountNo, txtAccountNo2);
        gridEsk.addRow(5, lblAmountTel, txtAmountEsk);

        return gridEsk;
    }

    private void setBarcodeValues(String value) {
////eskom must be in this format
////[07:48:37] Ken: for the "account number"
////[07:49:00] Ken: [account number][barcode][amountdue][checkdigit]
////[07:49:19] Ken: lengths are [13][10][12][1]
        // // 2016-10-13  -  These were the wrong way round... should be...
        // // 2016-10-13  -  barcode=13  accountnum=10  amountdue=12  checkdigit=1
        //presumably amount in cents, left padded with zeros
        accountNum = value;
        barcode = value.trim().substring(0, 13);
        accountStr = value.trim().substring(13, (13 + 10));
        String amountEskStr = value.trim().substring((13 + 10), (13 + 10 + 12));
        checkDigit = value.substring((13 + 10 + 12));

        txtAccountNo.setText(accountStr);
        txtAccountNo2.setText(accountStr);

        txtAccountNo.setDisable(true);
        txtAccountNo2.setDisable(true);

        double amtCents = SalesUtil.getAmountAsDouble(amountEskStr, txtAmountEsk);
        amountEsk = amtCents / 100;
        txtAmountEsk.setText(JKText.getDeciFormat(amountEsk));
    }

    public void setAdditionalValues() {

        double amtDx100 = Math.rint(amountEsk * 100);
        int amtAsInt = (int) (amtDx100);
        String amountStr = String.format("%012d", amtAsInt);

        if (scannedBarcode) {
            // FROM BARCODE SCAN...
            // barcode already set
            // accountStr already set
            // checkDigit already set
            // accountNum already set
            System.out.println("accountNum if set by barcode scan = " + accountNum);
        } else {
            barcode = "0000000000000";
            accountStr = txtAccountNo.getText().trim();
            checkDigit = "0";
            accountNum = barcode + accountStr + amountStr + checkDigit;
            System.out.println("accountNum if set by account entry = " + accountNum);
        }

        additionalString = "1=" + barcode + " "
                + "2=" + accountStr + " "
                + "3=" + amountStr + " "
                + "4=" + checkDigit;
    }

    private boolean isInputValidEsk() {
        if (txtAccountNo.getText().equals("") || txtAccountNo.getText().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Account Number", "Account Number cannot be empty", null);
            return false;
        }
        if (!txtAccountNo2.getText().equals(txtAccountNo.getText())) {
            JKiosk3.getMsgBox().showMsgBox("Account Number", "Account Numbers entered do not match", null);
            return false;
        }
        if (txtAmountEsk.getText().equals("") || txtAmountEsk.getText().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Amount Due", "Amount Due cannot be empty", null);
            return false;
        }
        return true;
    }

    public boolean isValidInputEskom() {
        return isInputValidEsk();
    }

    public double getAmountEsk() {
        return amountEsk;
    }

    public String getBarcode() {
        return barcode;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public String getAccountStr() {
        return accountStr;
    }

    public String getCheckDigit() {
        return checkDigit;
    }

    public String getAdditionalString() {
        return additionalString;
    }
}
