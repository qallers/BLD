package jkiosk3.sales.coaches;

import aeoncoach.CoachCompleteReq;
import aeoncoach.CoachCompleteResp;
import aeoncoach.CoachReserveResp;
import aeoncoach.CoachTicket;
import aeonprinting.AeonPrintJob;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.print_layouts.PrintCoachTicket;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.TicketingMenu;
import jkiosk3.sales._bus_carriers.CoachCarrierLayouts;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales._tender.TenderAmounts;
import jkiosk3.store.JKCancelTicket;
import jkiosk3.store.StoreJKCancelTicket;
import jkiosk3.users.UserUtil;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

import static jkiosk3.sales._bus_carriers.CoachCarrierLayouts.getGridTripsSelected;
import static jkiosk3.sales._bus_carriers.CoachCarrierLayouts.gridCoach;

public class CoachBook6 extends Region {

    private final static Logger logger = Logger.getLogger(CoachBook6.class.getName());

    private JKTenderToggles tenderToggles;
    private CoachReserveResp coachReserveResp;
    private List<CoachTicket> listTicketsDepart;
    private List<CoachTicket> listTicketsReturn;
    private double costTotalDepart = 0.0D;
    private double costTotalReturn = 0.0D;
    private double costTotal = 0.0D;
    private boolean isReturnTrip;
    private int tenderCode;
    private String tenderSelected;
    private List<CoachTicket> ticketPrintList;
    private List<AeonPrintJob> ticketPrintJobList;
    private int currentPrintJob;

    public CoachBook6() {
        this.coachReserveResp = CoachTicketSale.getInstance().getCoachReserveResp();
        listTicketsDepart = new ArrayList<>();
        listTicketsReturn = new ArrayList<>();

//        long timeBoardDepart = CoachTicketSale.getInstance().getRouteDepart().getBoardingTime().getTime();

        String cityDepart = CoachTicketSale.getInstance().getDepartureLoc().getName();
        String cityDest = CoachTicketSale.getInstance().getDestinationLoc().getName();

        for (CoachTicket t : CoachTicketSale.getInstance ().getCoachReserveResp ().getTickets ()) {
            if (t.getBoardCity ().equalsIgnoreCase (cityDepart) || t.getDestCity ().equalsIgnoreCase (cityDest)) {
//            if (t.getBoardTime().getTime() == timeBoardDepart) {
                listTicketsDepart.add (t);
                costTotalDepart += t.getAmount ();
            } else {
                listTicketsReturn.add (t);
                costTotalReturn += t.getAmount ();
            }
        }
        costTotal = costTotalDepart + costTotalReturn;

        isReturnTrip = CoachTicketSale.getInstance ().isReturnTrip ();

        GridPane gridBook6 = showCoachTicketBookStep6 ();
        tenderToggles = getTenderTypes ();

        AnchorPane anchorPane = new AnchorPane ();
        anchorPane.setMaxHeight (CoachCarrierLayouts.COACH_PG_HT - (2 * JKLayout.sp));
        anchorPane.setMinHeight (CoachCarrierLayouts.COACH_PG_HT - (2 * JKLayout.sp));
        AnchorPane.setTopAnchor (gridBook6, 0.0);
        AnchorPane.setBottomAnchor (tenderToggles, 0.0);
        anchorPane.getChildren ().addAll (gridBook6, tenderToggles);

        VBox vbContent = JKLayout.getVBoxContent (JKLayout.sp);

        vbContent.getChildren ().add (anchorPane);

        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().addAll (vbContent, getNav ());
        getChildren ().add (vb);
    }

    private GridPane showCoachTicketBookStep6() {
        Label lblHead1 = JKText.getLblDk (CoachUtil.COACH_PG_HEAD, JKText.FONT_B_24);
        Label lblHead2 = JKText.getLblDk ("Confirmation and Payment", JKText.FONT_B_22);

        VBox vbHead = JKNode.getPageDblHeadVB (0, lblHead1, lblHead2);

        GridPane gridTrip = getGridTripsSelected ();

        Label lblTotalCost = JKText.getLblDk ("Total Cost", JKText.FONT_B_22);
        GridPane.setHalignment (lblTotalCost, HPos.RIGHT);

        Text txtTotalCost = JKText.getTxtDk (JKText.getDeciFormat (costTotal), JKText.FONT_B_22);
        GridPane.setHalignment (txtTotalCost, HPos.RIGHT);

        GridPane grid = JKLayout.getContentGrid2Col (0.50, 0.50);
        grid.setStyle ("-fx-padding: 0px;");

//        grid.add(vbHead, 0, 0, 2, 1);
//        grid.addRow(1, gridTrip);
//        grid.addRow(2, getGridReservationSummary(costTotalDepart, CoachUtil.TRIP_DEPART));
//        grid.addRow(3, JKNode.createGridSpanSep(2));
//        if (CoachTicketSale.getInstance().isReturnTrip()) {
//            grid.addRow(4, getGridReservationSummary(costTotalReturn, CoachUtil.TRIP_RETURN));
//            grid.addRow(5, JKNode.createGridSpanSep(2));
//            grid.addRow(6, lblTotalCost, txtTotalCost);
//        } else {
//            grid.addRow(4, lblTotalCost, txtTotalCost);
//        }

        grid.add (vbHead, 0, 0, 2, 1);
        grid.addRow (1, gridTrip);
        grid.addRow (2, getPaneReservationSummary ());
        grid.addRow (3, JKNode.createGridSpanSep (2));
        grid.addRow (4, lblTotalCost, txtTotalCost);
//        if (CoachTicketSale.getInstance().isReturnTrip()) {
//            grid.addRow(4, getGridReservationSummary(costTotalReturn, CoachUtil.TRIP_RETURN));
//            grid.addRow(5, JKNode.createGridSpanSep(2));
//            grid.addRow(6, lblTotalCost, txtTotalCost);
//        } else {
//            grid.addRow(4, lblTotalCost, txtTotalCost);
//        }

        return grid;
    }

    private ScrollPane getPaneReservationSummary() {

        VBox vbSummary = JKLayout.getVBox (0, JKLayout.sp);
        vbSummary.setMaxWidth (JKLayout.contentW - (2 * JKLayout.sp));
        vbSummary.setMinWidth (JKLayout.contentW - (2 * JKLayout.sp));

        GridPane gridDepart = getGridReservationSummary (costTotalDepart, CoachUtil.TRIP_DEPART);
        vbSummary.getChildren ().add (gridDepart);

        if (CoachTicketSale.getInstance ().isReturnTrip ()) {
            GridPane gridReturn = getGridReservationSummary (costTotalReturn, CoachUtil.TRIP_RETURN);
            vbSummary.getChildren ().add (gridReturn);
        }

        ScrollPane scrollPane = new ScrollPane ();
        scrollPane.setMaxSize ((JKLayout.contentW - (2 * JKLayout.sp)), 300);
        scrollPane.setMinSize ((JKLayout.contentW - (2 * JKLayout.sp)), 300);
        scrollPane.setStyle ("-fx-background-color: #FFFFFF; -fx-padding: 0px;");
        scrollPane.setHbarPolicy (ScrollPane.ScrollBarPolicy.NEVER);

        scrollPane.setContent (vbSummary);

        return scrollPane;
    }

    private GridPane getGridReservationSummary(double cost, String departOrReturn) {

        Label lblTrip = JKText.getLblDk (departOrReturn, JKText.FONT_B_18);

//        GridPane grid = JKLayout.getGridPane4Col(gridCoach, 0.25, 0.25, 0.25, 0.25, 2, HPos.RIGHT);
        GridPane grid = JKLayout.getGridPane4Col ((gridCoach - (3 * JKLayout.sp)), 0.25, 0.25, 0.25, 0.25, 2, HPos.RIGHT);
        Label lblRef = JKText.getLblDk ("Reference : " + coachReserveResp.getReference (), JKText.FONT_B_XXSM);
        GridPane.setColumnSpan (lblRef, 2);

        grid.add (lblTrip, 0, 0);
        grid.add (lblRef, 1, 0, 2, 1);
        grid.add (JKText.getTxtDk (JKText.getDeciFormat (cost), JKText.FONT_B_18), 3, 0);

        if (departOrReturn.equals (CoachUtil.TRIP_DEPART)) {
            grid.add (getGridTicketDetail (listTicketsDepart), 0, 2, 3, 1);
        } else {
            grid.add (getGridTicketDetail (listTicketsReturn), 0, 2, 3, 1);
        }
        grid.setTranslateX (-(2 * JKLayout.sp));

        return grid;
    }

    private GridPane getGridTicketDetail(List<CoachTicket> listToShow) {

        GridPane gridTickets = JKLayout.getGridSummary2ColVariWidth (0.60, 0.40, ((gridCoach * 0.75) - (2 * JKLayout.sp)));
        gridTickets.setStyle ("-fx-vgap: 5px;");

        int rowCount = 0;
        for (CoachTicket t : listToShow) {
            String pass = t.getPassenger ().toString ();
            Label lblPass = JKText.getLblDk (pass, JKText.FONT_B_XXSM);
            lblPass.setTranslateX (2 * JKLayout.sp);
            Text txtCost = JKText.getTxtDk (JKText.getDeciFormat (t.getAmount ()), JKText.FONT_B_XXSM);

            gridTickets.addRow (rowCount, lblPass, txtCost);
            rowCount++;
        }

        return gridTickets;
    }

    private JKTenderToggles getTenderTypes() {
        final JKTenderToggles tenderTypes = new JKTenderToggles (SaleType.COACHTICKETS.getDisplay ());
        for (ToggleButton b : tenderTypes.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event e) {
                    tenderCode = tenderTypes.getTenderCodeSelected ();
                    tenderSelected = tenderTypes.getTenderTypeSelected ();
                    completeCoachReservation ();
                }
            });
        }
        return tenderTypes;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();

        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new CoachBook5 ());
            }
        });

        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent (new TicketingMenu ());
            }
        });

        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private void completeCoachReservation() {

        CoachCompleteReq coachCompleteReq = new CoachCompleteReq ();
        coachCompleteReq.setTransRef (CoachTicketSale.getInstance ().getCoachReserveResp ().getTransRef ());
        coachCompleteReq.getPayments ().put (tenderCode, costTotal);

        CoachUtil.completeCoachReservation (coachCompleteReq, new CoachUtil.CoachCompleteRespResult () {
            @Override
            public void coachCompleteRespResult(CoachCompleteResp coachCompleteResp) {
                if (coachCompleteResp.isSuccess ()) {
                    switch (tenderCode) {
                        case 1:
                            TenderAmounts.addTenderAmount (TenderAmounts.TENDER_CASH, costTotal);
                            break;
                        case 2:
                            TenderAmounts.addTenderAmount (TenderAmounts.TENDER_CRED_CARD, costTotal);
                            break;
                        case 3:
                            TenderAmounts.addTenderAmount (TenderAmounts.TENDER_DEB_CARD, costTotal);
                            break;
                        case 4:
                            TenderAmounts.addTenderAmount (TenderAmounts.TENDER_CHEQUE, costTotal);
                        default:
                            JKiosk3.getMsgBox ().showMsgBox ("Tender Type", "No Tender Type selected", null);
                    }
                    boolean canCancel = false;
                    String transRef = coachReserveResp.getTransRef ();
                    String bookingRef = coachReserveResp.getReference ();
                    String description = CoachTicketSale.getInstance ().getCoachCarrierDepart ().getCarrierDescription ();
                    for (CoachTicket t : coachReserveResp.getTickets ()) {
                        String ticketNumber = t.getTicketNumber ();
                        AeonPrintJob printjob = PrintCoachTicket.getCoachTicketPrint (coachReserveResp, t);
                        SalesUtil.processSoldItem (transRef, SaleType.COACHTICKETS.getDisplay (),
                                description + " " + ticketNumber + " " + bookingRef, printjob,
                                t.getAmount (), canCancel, "online",
                                ticketNumber, new Date (), null, tenderSelected);
                        // Instead of creating the AeonPrintJob AGAIN,
                        // we could rather make an ArrayList of AeonPrintJob, NOT Ticket.
                        CoachTicketSale.getInstance ().getListCoachTickets ().add (t);
                        CoachTicketSale.getInstance ().getListCoachTicketPrintJobs ().add (printjob);
                    }
//                    MerchantCopy.getInstance().setDetails(coachReserveResp.getShift(), coachReserveResp.getTransSeq(),
//                            description + " " + coachReserveResp.getReference(), costTotal, null,
//                            0, coachReserveResp.getTransRef(), new Date(), CurrentUser.getSalesUser().getUserName(),
//                            tenderToggles.getTenderText());
//                    // This is messy, but will fall away when the prints are received from Aeon.
//                    MerchantCopy.getInstance().setTransType(CoachTicketSale.getInstance().getCoachCarrierDepart().getCarrierTransType());
//                    PrintHandler.handleMerchantCopyPrint(MerchantCopy.getInstance());
                    PrintHandler.handleMerchantCopyPrint (coachCompleteResp.getMerchantCopyPrint ());
                    printCoachTickets ();

                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Coach Ticket Sale Error", !coachCompleteResp.getAeonErrorText ().isEmpty () ?
                            coachCompleteResp.getAeonErrorCode () + " - " + coachCompleteResp.getAeonErrorText () :
                            coachCompleteResp.getErrorCode () + " - " + coachCompleteResp.getErrorText (), null);
                    SceneSales.clearAndShowFavourites ();
                }
            }
        });
    }

    private void printCoachTickets() {

        StoreJKCancelTicket cancelTicket = new StoreJKCancelTicket();
        cancelTicket.setTransType(CoachTicketSale.getInstance().getCoachCarrierDepart().getCarrierTransType());
        cancelTicket.setCarrier(CoachTicketSale.getInstance().getCoachCarrierDepart().getCarrierCode());
        cancelTicket.setCarrierName(CoachTicketSale.getInstance().getCoachCarrierDepart().getCarrierDescription());
        cancelTicket.setDeparture(CoachTicketSale.getInstance().getDepartureLoc().getName());
        cancelTicket.setDestination(CoachTicketSale.getInstance().getDestinationLoc().getName());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        cancelTicket.setTravelTime(sdf.format(CoachTicketSale.getInstance().getListCoachTickets().get(0).getBoardTime()));
        cancelTicket.setTransactionDate(new Date());
        cancelTicket.setQty(CoachTicketSale.getInstance().getListCoachTickets().size());
        cancelTicket.setTransRef(CoachTicketSale.getInstance().getCoachReserveResp().getTransRef());
        cancelTicket.setTransId(CoachTicketSale.getInstance().getCoachReserveResp().getReference());

        JKCancelTicket.saveCancelTicket(cancelTicket);

        ticketPrintList = CoachTicketSale.getInstance().getListCoachTickets();
        int ticketCount = 0;
        List<String> listTransRefs = new ArrayList<> ();
        Map<String, AeonPrintJob> mapPrintJobs = new HashMap<> ();

        for (CoachTicket t : ticketPrintList) {
            String transRef = coachReserveResp.getTransRef () + "-" + (ticketCount);
            AeonPrintJob apj = PrintCoachTicket.getCoachTicketPrint (coachReserveResp, t);
            listTransRefs.add (transRef);
            mapPrintJobs.put (transRef, apj);
            ticketCount++;
        }
        PrintHandler.handlePrintRequestSaleFromMaps (SaleType.COACHTICKETS.getDisplay (), listTransRefs, mapPrintJobs,
                true, true);

//        ticketPrintList = CoachTicketSale.getInstance().getListCoachTickets();
        // 2019-11-07  -  PRODDEFECT-868
        // Print immediately or later is now handled in PrintHandler
        // Print preview or not is now handled in PrintHandler
//        if (JKPrintOptions.getPrintOptions().isPrintImmediately()) {
//            if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
//                currentPrintJob = 0;
//                printTicketsPreviewed();
//            } else {
//                int ticketCount = 0;
//                for (CoachTicket t : ticketPrintList) {
//                    String transRef = coachReserveResp.getTransRef() + "-" + (ticketCount);
//                    AeonPrintJob apj = PrintCoachTicket.getCoachTicketPrint(coachReserveResp, t);
//                    PrintHandler.handlePrintRequestSale(SaleType.COACHTICKETS.getDisplay(), apj, transRef);
////                    PrintUtil.sendToPrinter(PrintCoachTicket.getCoachTicketPrint(coachReserveResp, t), transRef, false);
//                    ticketCount++;
//                }
//            }
//        } else {
//            int ticketCount = 0;
//            for (CoachTicket t : ticketPrintList) {
//                String transRef = coachReserveResp.getTransRef() + "-" + ticketCount;
//                PrintQueue.addItem(transRef, PrintCoachTicket.getCoachTicketPrint(coachReserveResp, t));
//                ticketCount++;
//            }
//        }
        SceneSales.clearAndShowFavourites ();

//        // // // Previous implementation - passed QA, but creates another print job, inefficient.
//        ticketPrintList = CoachTicketSale.getInstance().getListCoachTickets();
//        // DO NOT QUEUE COACH TICKETS!!!
//        // Always make them print immediately!
////        if (JKPrintOptions.getPrintOptions().isPrintImmediately()) {
//            if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
//                currentPrintJob = 0;
//                printTicketsPreviewed();
//            } else {
//                int ticketCount = 0;
//                for (CoachTicket t : ticketPrintList) {
//                    String transRef = coachReserveResp.getTransRef() + "-" + (ticketCount);
//                    PrintUtil.sendToPrinter(PrintCoachTicket.getCoachTicketPrint(coachReserveResp, t), transRef, false, true);
//                    ticketCount++;
//                }
//            }
////        } else {
////            int ticketCount = 0;
////            for (CoachTicket t : ticketPrintList) {
////                String transRef = coachReserveResp.getTransRef() + "-" + ticketCount;
////                PrintQueue.addItem(transRef, PrintCoachTicket.getCoachTicketPrint(coachReserveResp, t));
////                ticketCount++;
////            }
////        }
//        SceneSales.clearAndShowFavourites();
    }

//    private void printTicketsPreviewed() {
//        String transRef = coachReserveResp.getTransRef() + "-" + currentPrintJob;
//        JKiosk3.getPrintPreview().showPrintPreview("Coach Tickets",
//                PrintCoachTicket.getCoachTicketPrint(coachReserveResp, ticketPrintList.get(currentPrintJob)), transRef,
//                PrintPreview.PRN_OK, new PrintPreviewResult() {
//                    @Override
//                    public void onOk() {
//                        currentPrintJob++;
//                        if (currentPrintJob < ticketPrintList.size()) {
//                            printTicketsPreviewed();
//                        }
//                    }
//
//                    @Override
//                    public void onCancel() {
//                        //
//                    }
//                });
//    }
}
//
// =======================================================

