package jkiosk3;

import aeonusers.User;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._components.NumberPadResult;
import jkiosk3._components.SceneBackground;
import jkiosk3.accounts.banking.SceneBanking;
import jkiosk3.accounts.emerg_topup.SceneEmergencyTopup;
import jkiosk3.admin.favourites.SceneFavourites;
import jkiosk3.reports.SceneReports;
import jkiosk3.sales.SalesMenu;
import jkiosk3.sales.SceneSales;
import jkiosk3.setup.SceneSetup;
import jkiosk3.store.JKOptions;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.SceneUsers;
import jkiosk3.users.UserUtil;

public class SceneMenu extends Region {

    private final static Logger logger = Logger.getLogger(SceneMenu.class.getName());
    private final static String MENU_SALES = "Sales";
    private final static String MENU_REPORTS = "Reports";
    private final static String MENU_USERS = "Users";
    private final static String MENU_SETUP = "Setup";
    private final static String MENU_BANK_DETAILS = "Bank Details";
    private final static String MENU_EMERGENCY_TOPUP = "Emergency Topup";
    private final static String MENU_FAVOURITES = "Favourites";
    private final static String MENU_LOGOUT = "Logout";

    public SceneMenu() {
        StackPane stack = JKLayout.getSceneStack(getMenuAnchor(), this);
        stack.setMaxHeight(StageJKiosk.getSceneHeight() - 75);
        stack.setMinHeight(StageJKiosk.getSceneHeight() - 75);
        getChildren().add(stack);

        SceneBackground.fadeSceneBackgroundImage();
    }

    private AnchorPane getMenuAnchor() {
        AnchorPane anchor = new AnchorPane();
        StackPane stackMain = getMainMenuStack();
        anchor.getChildren().addAll(stackMain, getLogoutGroup());

        return anchor;
    }

    private Group getLogoutGroup() {
        Group grp = new Group();

        Rectangle rec = new Rectangle();
        rec.setWidth(JKLayout.btnSmW + (2 * JKLayout.sp));

        final Button btnLogout = JKNode.getBtnSm(MENU_LOGOUT);
        btnLogout.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.changeScene(new JKioskLogin());
            }
        });

        VBox vb = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);

        vb.getChildren().addAll(btnLogout);

        rec.heightProperty().bind(vb.heightProperty());

        grp.getChildren().addAll(rec, vb);
        AnchorPane.setTopAnchor(grp, JKLayout.sp);
        AnchorPane.setRightAnchor(grp, JKLayout.sp);

        return grp;
    }

    private StackPane getMainMenuStack() {
        StackPane stackMain = new StackPane();
        stackMain.setPrefSize(StageJKiosk.getSceneWidth(), (StageJKiosk.getSceneHeight() - 75));

//        Group grp = new Group();
//
//        Rectangle rec = new Rectangle();
//        rec.setWidth(JKLayout.btnLgW + (2 * JKLayout.sp));
//
//        VBox vb = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
//
//        vb.getChildren().addAll(getMenuButtons());
//
//        rec.heightProperty().bind(vb.heightProperty());
//
//        grp.getChildren().addAll(rec, vb);
//        stackMain.getChildren().add(grp);

        List<Button> listMenuBtns = getMenuButtons();

        double flowWd = (2 * JKLayout.btnLgW) + (6 * JKLayout.sp);
        FlowPane flowPane = new FlowPane((2 * JKLayout.sp), (2 * JKLayout.sp));
        flowPane.setMaxWidth(flowWd);
        flowPane.setMinWidth(flowWd);
        flowPane.setMaxHeight(USE_PREF_SIZE);
        flowPane.getStyleClass().add("stackContent");
        flowPane.setStyle("-fx-padding: 30px 15px 30px 15px;");
        flowPane.setAlignment(Pos.CENTER);
        flowPane.getChildren().addAll(listMenuBtns);

        stackMain.getChildren().add(flowPane);

        return stackMain;
    }

    private List<Button> getMenuButtons() {
        List<Button> btns = new ArrayList<>();
        List<String> labelShow = getDemoOrLiveLabels();

        if (!JKOptions.getOptions().isMultipleMenuLogin()) {
            for (String s : labelShow) {
                final Button btn = JKNode.getBtnLg(s);
                btn.setWrapText(true);
                btn.setOnMouseReleased(new EventHandler() {
                    @Override
                    public void handle(Event e) {
                        getMenuSelection(btn);
                    }
                });
                btns.add(btn);
            }
        } else {
            for (String s : labelShow) {
                final Button btn = JKNode.getBtnLg(s);
                btn.setWrapText(true);
                btn.setOnMouseReleased(new EventHandler() {
                    @Override
                    public void handle(Event e) {
                        final PasswordField pwd = new PasswordField();
                        JKiosk3.getNumPad().showNumPad(pwd, "Enter User Pin", "", new NumberPadResult() {

                            @Override
                            public void onDone(String value) {
                                String userPin = pwd.getText();
                                getMenuSelection(btn, userPin);
                            }
                        });
                    }
                });
                btns.add(btn);
            }
        }

        return btns;
    }

    private List<String> getDemoOrLiveLabels() {
        List<String> labels = new ArrayList<>();

        int userLevel = CurrentUser.getUser().getUserLevel();
        String userPermissions = UserUtil.getPermissionStringCurrentUser(CurrentUser.getUser().getUserPin());

        // Supervisor menu
        List<String> menuLive1 = new ArrayList<>();
        menuLive1.add(MENU_SALES);
        menuLive1.add(MENU_REPORTS);
        menuLive1.add(MENU_USERS);
        menuLive1.add(MENU_SETUP);
        menuLive1.add(MENU_BANK_DETAILS);
        if (SalesMenu.isEmergencyTopupAllowed()) {
            menuLive1.add(MENU_EMERGENCY_TOPUP);
        }
        menuLive1.add(MENU_FAVOURITES);

        // Cashier Plus menu
        List<String> menuLive2 = new ArrayList<>();
        menuLive2.add(MENU_SALES);
        menuLive2.add(MENU_REPORTS);
        menuLive2.add(MENU_BANK_DETAILS);
//        if (SalesMenu.isEmergencyTopupAllowed() && (userLevel == 2 && userPermissions.contains("9"))) {
//            menuLive2.add(MENU_EMERGENCY_TOPUP);
//        }
        if (SalesMenu.isEmergencyTopupAllowed()) {
            if ((userLevel == 2) && (userPermissions != null) && (userPermissions.contains("9"))) {
                menuLive2.add(MENU_EMERGENCY_TOPUP);
            }
        }
        menuLive2.add(MENU_FAVOURITES);

        if (userLevel == 1) {
            labels.addAll(menuLive1);
        } else if (userLevel == 2) {
            labels.addAll(menuLive2);
        }
        return labels;
    }

    private void getMenuSelection(final Button b, final String userPin) {

        UserUtil.getLoggedInUser(userPin, new UserUtil.LoggedInUserResult() {

            @Override
            public void loggedInUserResult(User loggedInUser) {
                if (loggedInUser.isSuccess()) {
                    logger.info(("\t\t>>>>> \tUser logged in : \t").concat(loggedInUser.getUserName()));
                    logger.info(("\t\t>>>>> \tSelected menu  : \t").concat(b.getText()));

                    int userLevel = loggedInUser.getUserLevel();
                    String userPermissions = UserUtil.getPermissionStringCurrentUser(CurrentUser.getUser().getUserPin());
                    if (userLevel == 0) {
                        if (b.getText().equals(MENU_SALES)) {
                            JKiosk3.changeScene(new SceneSales(true));
                        } else {
                            JKiosk3.getMsgBox().showMsgBox("Access Denied", b.getText() + " Menu not available for this Access Level", null);
                        }
                    } else if (userLevel == 1 || userLevel == 2) {
                        // 0 = Cashier
                        // 1 = Supervisor
                        // 2 = CashierPlus
                        switch (b.getText()) {
                            case MENU_SALES:
                                JKiosk3.changeScene(new SceneSales(true));
                                break;
                            case MENU_REPORTS:
                                if (userLevel == 1 || userLevel == 2) {
                                    JKiosk3.changeScene(new SceneReports());
                                    break;
                                } else {
                                    JKiosk3.getMsgBox().showMsgBox("Access Denied", MENU_REPORTS + " Menu not available for this Access Level", null);
                                    break;
                                }
                            case MENU_USERS:
                                User cu = CurrentUser.getUser();
                                System.out.println("cu name = " + cu.getUserName() + "  ::  cu pin = " + cu.getUserPin() + "  ::  cu id = " + cu.getUserId());
                                if (userLevel == 1) {
                                    JKiosk3.changeScene(new SceneUsers());
                                    break;
                                } else {
                                    JKiosk3.getMsgBox().showMsgBox("Access Denied", MENU_USERS + " Menu not available for this Access Level", null);
                                    break;
                                }
                            case MENU_SETUP:
                                if (userLevel == 1) {
                                    JKiosk3.changeScene(new SceneSetup(CurrentUser.getUser().getUserPin()));
                                    break;
                                } else {
                                    JKiosk3.getMsgBox().showMsgBox("Access Denied", MENU_SETUP + " Menu not available for this Access Level", null);
                                    break;
                                }
                            case MENU_BANK_DETAILS:
                                if (userLevel == 1 || userLevel == 2) {
                                    JKiosk3.changeScene(new SceneBanking());
                                    break;
                                } else {
                                    JKiosk3.getMsgBox().showMsgBox("Access Denied", MENU_BANK_DETAILS + " Menu not available for this Access Level", null);
                                    break;
                                }
                            case MENU_EMERGENCY_TOPUP:
                                if (userLevel == 1 || (userLevel == 2 && userPermissions.contains("9"))) {
                                    JKiosk3.changeScene(new SceneEmergencyTopup());
                                    break;
                                } else {
                                    JKiosk3.getMsgBox().showMsgBox("Access Denied", MENU_EMERGENCY_TOPUP + " Menu not available for this Access Level", null);
                                    break;
                                }
                            case MENU_FAVOURITES:
                                if (userLevel == 1) {
                                    JKiosk3.changeScene(new SceneFavourites());
                                } else {
                                    JKiosk3.getMsgBox().showMsgBox("Access Denied", MENU_FAVOURITES + " Menu not available for this Access Level", null);
                                    break;
                                }
                                break;
                            default:
                                JKiosk3.changeScene(new SceneSplash());
                        }
                    }
                } else {
                    logger.info(("\t\t>>>>> \tUser login failed : \tpin : ").concat(userPin).concat("\t: ")
                            .concat(Integer.toString(loggedInUser.getErrorCode())).concat("\t").concat(loggedInUser.getErrorText()));
                    JKiosk3.getMsgBox().showMsgBox("Login Failed",
                            !loggedInUser.getAeonErrorText ().isEmpty () ?
                                    "A" + loggedInUser.getAeonErrorCode () + " - " + loggedInUser.getAeonErrorText () :
                                    "B" + loggedInUser.getErrorCode () + " - " + loggedInUser.getErrorText (), null);
                }
            }
        });
    }

    //This method is for not using menu login for each menu item
    private void getMenuSelection(final Button b) {
        switch (b.getText()) {
            case MENU_SALES:
                JKiosk3.changeScene(new SceneSales(true));
                break;
            case MENU_REPORTS:
                JKiosk3.changeScene(new SceneReports());
                break;
            case MENU_USERS:
                User cu = CurrentUser.getUser();
                JKiosk3.changeScene(new SceneUsers());
                break;
            case MENU_SETUP:
                JKiosk3.changeScene(new SceneSetup(CurrentUser.getUser().getUserPin()));
                break;
            case MENU_BANK_DETAILS:
                JKiosk3.changeScene(new SceneBanking());
                break;
            case MENU_EMERGENCY_TOPUP:
                JKiosk3.changeScene(new SceneEmergencyTopup());
                break;
            case MENU_FAVOURITES:
                JKiosk3.changeScene(new SceneFavourites());
                break;
            default:
                JKiosk3.changeScene(new SceneSplash());
        }
    }
}
