package jkiosk3.sales.topups.bundles;

import aeontopup.TopupBundleCategory;
import aeontopup.TopupBundleProduct;
import aeontopup.TopupBundleProductList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlSearch;
import jkiosk3._components.KeyboardResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.topups.AirtimeUtil;
import jkiosk3.sales.topups.TopupProvider;
import jkiosk3.sales.topups.TopupSale;
import jkiosk3.users.SalesUserLoginResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class BundleSelectDataOrSMS extends Region {

    private StackPane stackPane;
    private ControlSearch controlSearch;
    private List<Button> listButtons;
    private final SaleType saleTypeSelected;
    private TopupBundleProductList bundleProductList;
    private List<TopupBundleProduct> listProdData;
    private List<TopupBundleProduct> listProdSMS;
    private String provStyle = "";
    private final static int pageSize = 10;

    public BundleSelectDataOrSMS() {
        this.saleTypeSelected = TopupSale.getInstance ().getSaleType ();
        this.bundleProductList = new TopupBundleProductList ();
        this.provStyle = TopupSale.getInstance ().getProviderStyleName ();

        TopupProvider provider = TopupSale.getInstance ().getProvider ();

        AirtimeUtil.getTopupBundleProductList (provider, new AirtimeUtil.TopupBundleProductListResult () {
            @Override
            public void topupBundleProductListResult(TopupBundleProductList productList) {
                if (productList.isSuccess ()) {
                    if (!productList.getlistCategories ().isEmpty ()) {
                        bundleProductList = productList;

                        setSearchControlActions ();

                        getChildren ().add (getBundleProductsLayout ());
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("Bundle Products", "No Bundles in Selected Bundle Category", null);
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Bundle Products Error", !productList.getAeonErrorText ().isEmpty () ?
                            "A" + productList.getAeonErrorCode () + " - " + productList.getAeonErrorText () :
                            "B" + productList.getErrorCode () + " - " + productList.getErrorText (), null);
                }
            }
        });
    }

    public BundleSelectDataOrSMS(SaleType theSaleTypeSelected, String theProvStyle) {
/*
        this.saleTypeSelected = TopupSale.getInstance().getSaleType();
        this.bundleProductList = new TopupBundleProductList();
        this.provStyle = TopupSale.getInstance().getProviderStyleName();

        Buco
*/

        this.saleTypeSelected = theSaleTypeSelected;
        this.bundleProductList = new TopupBundleProductList();
        this.provStyle = theProvStyle;

        TopupProvider provider = TopupSale.getInstance().getProvider();

        AirtimeUtil.getTopupBundleProductList(provider, new AirtimeUtil.TopupBundleProductListResult() {
            @Override
            public void topupBundleProductListResult(TopupBundleProductList productList) {
                if (productList.isSuccess()) {
                    if (!productList.getlistCategories().isEmpty()) {
                        bundleProductList = productList;

                        setSearchControlActions();

                        getChildren().add(getBundleProductsLayout());
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Bundle Products", "No Bundles in Selected Bundle Category", null);
                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Bundle Products", "Unable to retrieve Bundle Product List\n"
                            + productList.getErrorCode() + " - " + productList.getErrorText(), null);
                }
            }
        });
    }

    private void setSearchControlActions() {
        controlSearch = new ControlSearch ();
        controlSearch.getBtnSearch ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (new TextField (), "Enter search text", "", false, false, new KeyboardResult () {
                    @Override
                    public void onDone(String value) {
                        System.out.println ("searching for : " + value);
                        getBundlesSearched (value.toLowerCase (Locale.ENGLISH));
                    }
                });
            }
        });
        controlSearch.getBtnClear ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                getBundlesAll ();
            }
        });
    }

    private void resetFullLists() {
        List<TopupBundleProduct> listDataTmp = new ArrayList<> ();
        List<TopupBundleProduct> listSMSTmp = new ArrayList<> ();
        for (TopupBundleCategory cat : bundleProductList.getlistCategories ()) {
            if (cat.getType ().contains ("DATA")) {
                for (TopupBundleProduct p : cat.getListProducts ()) {
                    listDataTmp.add (p);
                }

            } else if (cat.getType ().contains ("SMS")) {
                for (TopupBundleProduct p : cat.getListProducts ()) {
                    listSMSTmp.add (p);
                }
            }
        }
        listProdData = listDataTmp;
        listProdSMS = listSMSTmp;
    }

    private void getBundlesAll() {
        resetFullLists ();
        getBundleButtons ();
    }

    private void getBundlesSearched(String searchterm) {
        resetFullLists ();
        if (!searchterm.equals ("")) {
            switch (saleTypeSelected) {
                case TOPUP_BUNDLE_DATA:
                    List<TopupBundleProduct> listDataSearch = listProdData;
                    List<TopupBundleProduct> listDataTmp = new ArrayList<> ();
                    for (TopupBundleProduct p : listDataSearch) {
                        if (p.getDescription ().toLowerCase (Locale.ENGLISH).contains (searchterm)) {
                            listDataTmp.add (p);
                        }
                    }
                    if (!listDataTmp.isEmpty ()) {
                        listProdData = listDataTmp;
                        getBundleButtons ();
                    } else {
                        showSearchError (searchterm);
                    }
                    break;
                case TOPUP_BUNDLE_SMS:
                    List<TopupBundleProduct> listSMSSearch = listProdSMS;
                    List<TopupBundleProduct> listSMSTmp = new ArrayList<> ();
                    for (TopupBundleProduct p : listSMSSearch) {
                        if (p.getDescription ().toLowerCase (Locale.ENGLISH).contains (searchterm)) {
                            listSMSTmp.add (p);
                        }
                    }
                    if (!listSMSTmp.isEmpty ()) {
                        listProdSMS = listSMSTmp;
                        getBundleButtons ();
                    } else {
                        showSearchError (searchterm);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    private void showSearchError(String searchterm) {
        JKiosk3.getMsgBox ().showMsgBox ("Search results for '" + searchterm + "'",
                "\nNo matching products found.\n\nPlease try another search term.", null);
    }

    private VBox getBundleProductsLayout() {

        Button btnBack = JKNode.getBtnPopup ("back");
        btnBack.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new BundleProvidersDataOrSMS ());
            }
        });

        Label lblTopupType = JKText.getLblDk (TopupSale.getInstance ().getSaleType ().getDisplay (), JKText.FONT_B_SM);

        Button btnProvider = JKNode.getAirtimeProviderButton (provStyle, null);

        HBox hbHead = JKLayout.getHBox (0, JKLayout.sp);
        hbHead.getChildren ().addAll (lblTopupType, btnProvider);

        VBox vbHead = JKNode.getPageDblHeadVB (JKLayout.sp, btnBack, hbHead);

        HBox hbSearch = JKLayout.getHBox (0, 0);
        hbSearch.setStyle ("-fx-padding: 0px 15px 15px 0px;");
        hbSearch.getChildren ().addAll (JKNode.getHSpacer (), controlSearch);

        stackPane = new StackPane ();

        getBundlesAll ();

        VBox vb = JKLayout.getVBoxContent (0);
        vb.setStyle ("-fx-padding: 0px 0px 15px 0px;");
        vb.getChildren ().addAll (vbHead, hbSearch, stackPane);

        return vb;
    }

    private void getBundleButtons() {
        listButtons = new ArrayList<> ();
        switch (saleTypeSelected) {
            case TOPUP_BUNDLE_DATA:
                listButtons = getBundleButtons (listProdData);
                break;
            case TOPUP_BUNDLE_SMS:
                listButtons = getBundleButtons (listProdSMS);
                break;
            default:
                break;
        }
        createPagedBundles ();
    }

    private List<Button> getBundleButtons(List<TopupBundleProduct> prods) {
        List<Button> btnList = new ArrayList<> ();
        for (final TopupBundleProduct p : prods) {
            final Button btn = JKNode.getBtnSmDbl (p.getDescription ());
            btn.getStyleClass ().add ("prov_" + provStyle);
            btn.setWrapText (true);
            btn.setOnMouseReleased (new EventHandler () {
                @Override
                public void handle(Event e) {
                    TopupSale.getInstance ().setProduct (p);
                    onSelectProductButton ();
                }
            });
            btnList.add (btn);
        }
        return btnList;
    }

    private void createPagedBundles() {
        stackPane.getChildren ().clear ();
        int numPgs = 0;
        if (listButtons.isEmpty ()) {
            numPgs = 1;
        } else if ((listButtons.size () % pageSize) == 0) {
            numPgs = listButtons.size () / pageSize;
        } else {
            numPgs = (listButtons.size () / pageSize) + 1;
        }
        Pagination pages = new Pagination (numPgs);
        pages.setPageFactory (new Callback<Integer, Node> () {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedTile (pg, 415, 2, pageSize, listButtons);
            }
        });
        stackPane.getChildren ().add (pages);
    }

    private void onSelectProductButton() {
        JKiosk3.getSalesUserLogin ().showUserLogin (new SalesUserLoginResult () {
            @Override
            public void onDone() {
                SceneSales.clearAndChangeContent (new BundleRecharge (false));
            }
        });
    }
}
