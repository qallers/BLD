package jkiosk3._components;

import com.teamdev.jxmaps.*;
import com.teamdev.jxmaps.javafx.MapView;
import javafx.event.EventHandler;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class WebViewJxMaps extends MapView {

    private TextField searchField;

    //    private static final LatLng LAT_LNG = new LatLng(-26.100128, 28.051005);      // Blue Label, Sandton
    //    private final static double ZOOM = 13.0;                                      // zoom for Sandton/
    private static final LatLng LAT_LNG = new LatLng(-30.67663, 24.01312); // De Aar (centre of ZA)
    private final static double ZOOM = 7.0;                                         // zoom for De Aar
    private String latitudeSelected;
    private String longitudeSelected;
    private String addressSelected;

    public WebViewJxMaps(MapViewOptions options, TextField textField) {
        super(options);

        this.searchField = textField;

//        searchField.setText("De Aar");
        searchField.setPromptText("search");

        initMap();

        searchField.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent e) {
                if (e.getCode() == KeyCode.ENTER) {
//                    showSelectedAddress(addressEdit.getText().concat(", ZA"), null, ZOOM);
                    setInitialLocation(searchField.getText().concat(", ZA"), null, 13.0);
                }
            }
        });
    }

    private void initMap() {
        //         Setting of a ready handler to MapView object. onMapReady will be called when map initialization is done and
//         the map object is ready to use. Current implementation of onMapReady customizes the map object.
        setOnMapReadyHandler(new MapReadyHandler() {
            @Override
            public void onMapReady(MapStatus status) {
                // Getting the associated map object
                final Map mapStart = getMap();
                // Setting initial zoom value
                mapStart.setZoom(ZOOM);
                // Creating a map options object
                MapOptions options = new MapOptions();
                // Creating a map type control options object
                MapTypeControlOptions controlOptions = new MapTypeControlOptions();
                // Changing position of the map type control
                controlOptions.setPosition(ControlPosition.TOP_RIGHT);
                // Setting map type control options
                options.setMapTypeControlOptions(controlOptions);
                // Setting map options
                mapStart.setOptions(options);

                setInitialLocation(null, LAT_LNG, ZOOM);
            }
        });
    }

    private void setInitialLocation(String search, LatLng latlng, double zoom) {
        // Getting the associated map object
        final Map mapInitial = getMap();
        mapInitial.setZoom(zoom);
        // Creating a geocode request
        GeocoderRequest request = new GeocoderRequest();
        // Setting address to the geocode request
        if (search == null) {
            request.setLocation(latlng);
        } else if (latlng == null) {
            request.setAddress(search);
        }

//        request.setLocation(latlng);

        // Geocoding position by the entered address
        getServices().getGeocoder().geocode(request, new GeocoderCallback(mapInitial) {
            @Override
            public void onComplete(GeocoderResult[] results, GeocoderStatus status) {
                // Checking operation status
                if ((status == GeocoderStatus.OK) && (results.length > 0)) {
                    // Getting the first result
                    GeocoderResult result = results[0];
                    // Getting a location of the result
                    LatLng location = result.getGeometry().getLocation();
                    // Setting the map center to result location
                    mapInitial.setCenter(location);
                    String address = result.getFormattedAddress();
//                    // Creating a marker object
//                    final Marker marker = new Marker(mapInitial);
//                    // Setting position of the marker to the result location
//                    marker.setPosition(location);
//                    // Creating an information window
//                    final InfoWindow infoWindow = new InfoWindow(mapInitial);
//                    // Putting the address and location to the content of the information window
//                    infoWindow.setContent("<b>" + result.getFormattedAddress() + "</b><br>" + location.toString());
//                    // Moving the information window to the result location
//                    infoWindow.setPosition(location);
//                    // Showing of the information window
//                    infoWindow.open(mapInitial, marker);
                    mapInitial.addEventListener("click", new MapMouseEvent() {
                        @Override
                        public void onEvent(MouseEvent mouseEvent) {
                            // Closing initially created info window
//                            infoWindow.close();
//                            marker.remove();
                            mapInitial.dispose();

                            // Get the zoom level that the User has selected
                            double selectedZoom = mapInitial.getZoom();
                            LatLng clickedLatlng = mouseEvent.latLng();

                            showSelectedAddress(clickedLatlng, selectedZoom);
                        }
                    });
                }
            }
        });
    }

    private void showSelectedAddress(LatLng latlng, double zoom) {

        // Getting the associated map object
        final Map mapSelect = getMap();
        mapSelect.setZoom(zoom);
        // Creating a geocode request
        GeocoderRequest request = new GeocoderRequest();
        // Setting address to the geocode request
        request.setLocation(latlng);

        // Geocoding position by the SELECTED Latitude/Longitude
        getServices().getGeocoder().geocode(request, new GeocoderCallback(mapSelect) {
            @Override
            public void onComplete(GeocoderResult[] results, GeocoderStatus status) {

                // Checking operation status
                if ((status == GeocoderStatus.OK) && (results.length > 0)) {
                    // Getting the first result
                    GeocoderResult result = results[0];
                    // Getting a location of the result
                    LatLng locationSelected = result.getGeometry().getLocation();
                    latitudeSelected = Double.toString(locationSelected.getLat());
                    longitudeSelected = Double.toString(locationSelected.getLng());
                    // Setting the map center to result location
                    mapSelect.setCenter(locationSelected);
                    // Creating a marker object
                    final Marker markerSelected = new Marker(mapSelect);
                    // Setting position of the marker to the result location
                    markerSelected.setPosition(locationSelected);
                    // Get the address to be shown in the info window
                    addressSelected = result.getFormattedAddress();
                    // Creating an information window
                    final InfoWindow infoWindowSelected = new InfoWindow(mapSelect);
                    // Putting the address and location to the content of the information window
                    infoWindowSelected.setContent("<b>" + result.getFormattedAddress() + "</b><br>" + locationSelected.toString());
                    // Moving the information window to the result location
                    infoWindowSelected.setPosition(locationSelected);
                    // Showing of the information window
                    infoWindowSelected.open(mapSelect, markerSelected);
                    // Output to check the details
                    System.out.println("SELECTED LatLng = " + locationSelected);
                    System.out.println("SELECTED result.getFormattedAddress() = " + addressSelected);
                    System.out.println("-------------------------------------");
                    mapSelect.addEventListener("click", new MapMouseEvent() {
                        @Override
                        public void onEvent(MouseEvent mouseEvent) {
                            // Closing info window, marker, and current map
                            infoWindowSelected.close();
                            markerSelected.remove();
                            mapSelect.dispose();
                            // Get the zoom level that the User has selected
                            double selectedZoom = mapSelect.getZoom();
                            // Get the coordinates of the new selection
                            LatLng clickedLatlng = mouseEvent.latLng();
                            System.out.println("mapSelect clicked marker latitude  = " + clickedLatlng.getLat());
                            System.out.println("mapSelect clicked marker longitude = " + clickedLatlng.getLng());

                            // Show the newly selected map with selected coordinates
                            showSelectedAddress(clickedLatlng, selectedZoom);
                        }
                    });
                }
            }
        });
    }

    public String getLatitudeSelected() {
        return latitudeSelected;
    }

    public String getLongitudeSelected() {
        return longitudeSelected;
    }

    public String getAddressSelected() {
        return addressSelected;
    }

    public void closeMap() {
        this.dispose();
    }
}
