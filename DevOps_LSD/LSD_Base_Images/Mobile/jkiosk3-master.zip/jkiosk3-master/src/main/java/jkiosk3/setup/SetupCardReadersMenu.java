package jkiosk3.setup;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

import java.util.ArrayList;
import java.util.List;

public class SetupCardReadersMenu extends Region {

    private final static String MENU_MAG_CARD = "Mag Card Reader";
    private final static String MENU_NFC_CARD = "NFC Card Reader";

    public SetupCardReadersMenu() {
        getChildren().add(getMenuGroup());
    }

    private HBox getMenuGroup() {

        List<String> btnLabelsPrint = new ArrayList<>();
        btnLabelsPrint.add(MENU_MAG_CARD);
        btnLabelsPrint.add(MENU_NFC_CARD);

        List<Button> btnList = new ArrayList<>();

        for (String s : btnLabelsPrint) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setStyle(SceneSetup.SETUP_BTN_STYLE);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        HBox hb = JKLayout.getControlsHBox();
        hb.setAlignment(Pos.CENTER_LEFT);
        hb.getChildren().addAll(btnList);
        hb.getChildren().add(JKNode.getHSpacer());

        return hb;
    }

    private void getMenuAction(Button b) {
        if (SceneSetup.getVbSetupContent().getChildren().size() > 1) {
            SceneSetup.getVbSetupContent().getChildren().remove(1);
        }

        switch (b.getText()) {
            case MENU_MAG_CARD:
                SceneSetup.getVbSetupContent().getChildren().add(1, new SetupMagReader());
                break;
            case MENU_NFC_CARD:
//                System.out.println("make stuff for nfc card reader...");
                SceneSetup.getVbSetupContent().getChildren().add(1, new SetupNFCReader());
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Card Readers Menu", "Card Reader Option Not Selected!", null);
        }
    }
}
