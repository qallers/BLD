package jkiosk3.sales._favourites;

import aeonairtime.AirtimeManufacturer;
import aeonairtime.AirtimeProduct;
import aeonfavourites.FavouriteItem;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.admin.favourites.fav_cache.JKFavouriteSetup;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.users.CurrentUser;
import za.co.blt.consumer.loyalty.api.service.model.response.Favourite;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Favourites extends Region {

    private List<Favourite> listFavourite;
    private List<AirtimeManufacturer> listFavVouch = new ArrayList<>();
    //    private List<Supplier> listFavC4C = new ArrayList<>();
//    private List<TopupProvider> listFavTopProvAir = new ArrayList<>();
//    private List<TopupProvider> listFavTopProvBundles = new ArrayList<>();
    private List<ElectricityProvider> listFavElecSuppliers = new ArrayList<>();
    private List<BillPayProduct> listFavBPProds = new ArrayList<>();
    //    private List<String> listTicketing = new ArrayList<>();
//    private List<String> listIthuba = new ArrayList<>();
    private FavNodes favNodes;
    private boolean isShowVouchers = true;
    private boolean isShowElectricity = true;
    private boolean isShowBillPayments = true;

    public Favourites() {

        checkItemsToShow();

        FavouriteUtil.getListFavouriteProducts(false, new FavouriteUtil.FavouriteProductsResult() {
            @Override
            public void favouriteProductsResult(List<FavouriteItem> favListResp) {
                if (favListResp != null && !favListResp.isEmpty()) {
                    FavouriteUtilLists favUtilList = new FavouriteUtilLists();
                    listFavourite = favUtilList.convertFavouriteItemsToFavourites(favListResp);
                    if (listFavourite.size() > 14) {
                        listFavourite = listFavourite.subList(0, 14);
                    }
                    if (!listFavourite.isEmpty()) {
                        // sort into lists for each product type, make buttons, add to view
                        listFavVouch = favUtilList.getFavouriteVoucherList(listFavourite);
//                        listFavC4C = favUtilList.getFavouriteC4C(listFavourite);
//                        listFavTopProvAir = favUtilList.getFavouriteTopupAirtime(listFavourite);
//                        listFavTopProvBundles = favUtilList.getFavouriteTopupBundles(listFavourite);
                        listFavElecSuppliers = favUtilList.getFavouriteElectricity(listFavourite);
                        listFavBPProds = favUtilList.getFavouriteBillPayProducts(listFavourite);
//                        listTicketing = favUtilList.getFavouriteTicketing(listFavourite);
//                        listIthuba = favUtilList.getFavouriteIthuba(listFavourite);
                        favNodes = new FavNodes(false, listFavourite);

                        getChildren().addAll(getFavouritesView());

                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Favourites",
                                "\nNo Favourites for this Device", null);
                    }
                }
            }
        });
    }

    private void checkItemsToShow() {
        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();
        // Disable as needed
        if ((!onlineTransTypes.contains("Voucher")) && (!onlineTransTypes.contains("VoucherAMS"))) {
            isShowVouchers = false;
        }
        if (!onlineTransTypes.contains("Electricity")) {
            isShowElectricity = false;
        }
        if ((!onlineTransTypes.contains("VASPayAtAccountPayment")) && (!onlineTransTypes.contains("VASPayAtBusTicket"))
                && (!onlineTransTypes.contains("VASPayAtFinePayment")) && (!onlineTransTypes.contains("VASPayAtInsurance"))
                && (!onlineTransTypes.contains("VASSyntellAccountPayment")) && (!onlineTransTypes.contains("VASSyntellFinePayment"))
                && (!onlineTransTypes.contains("VASSAPOAccountPayment")) && (!onlineTransTypes.contains("BluBillPayment"))
                && (!onlineTransTypes.contains("MerchantTransfer"))) {
            isShowBillPayments = false;
        }
    }

    private VBox getFavouritesView() {

        VBox vbHead = JKNode.getPageHeadVB(JKFavouriteSetup.getFavouriteSetupStore().toString() + " Favourites");

//        List<AirtimeManufacturer> listVoucherAir = new ArrayList<>();
//        List<AirtimeManufacturer> listVoucherData = new ArrayList<>();
//        List<AirtimeManufacturer> listVoucherElect = new ArrayList<>();
//        List<AirtimeManufacturer> listVoucherOther = new ArrayList<>();
//        for (AirtimeManufacturer m : listFavVouch) {
//            for (AirtimeProduct p : m.getProducts()) {
//                switch (p.getCategoryId()) {
//                    case 1:
//                        listVoucherAir.add(m);
//                        break;
//                    case 2:
//                        listVoucherData.add(m);
//                        break;
//                    case 3:
//                        listVoucherElect.add(m);
//                        break;
//                    case 4:
//                        listVoucherOther.add(m);
//                        break;
//                    default:
//                        break;
//                }
//            }
//        }
//        listFavVouch.clear();
//        if (!listVoucherAir.isEmpty()) {
//            listFavVouch.addAll(listVoucherAir);
//        }
//        if (!listVoucherData.isEmpty()) {
//            listFavVouch.addAll(listVoucherData);
//        }
//        if (!listVoucherElect.isEmpty()) {
//            listFavVouch.addAll(listVoucherElect);
//        }
//        if (!listVoucherOther.isEmpty()) {
//            listFavVouch.addAll(listVoucherOther);
//        }

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().add(vbHead);

//        // add category Airtime
//        if (!listVoucherAir.isEmpty()) {
//            vb.getChildren().add(getTileVouchers(1));
//        }
//        // add category Data
//        if (!listVoucherData.isEmpty()) {
//            vb.getChildren().add(getTileVouchers(2));
//        }
//        // add category Electricity
//        if (!listVoucherElect.isEmpty()) {
//            vb.getChildren().add(getTileVouchers(3));
//        }
//        // add category Other
//        if (!listVoucherOther.isEmpty()) {
//            vb.getChildren().add(getTileVouchers(4));
//        }
        // add category ALL, don't split categories
        // if this is used, vouchers will be sorted by Provider
//        if (isShowVouchers) {
//            if (!listFavVouch.isEmpty()) {
//                vb.getChildren().add(getTileVouchers());
//            }
//        }

//        if (!listFavTopProvBundles.isEmpty()) {
//            vb.getChildren().add(getTileBundles());
//        }
//        if (isShowBillPayments) {
//            if (!listFavBPProds.isEmpty()) {
//                vb.getChildren().add(getTileBillPayments());
//            }
//        }

//        if (isShowElectricity) {
//            if (!listFavElecSuppliers.isEmpty()) {
//                vb.getChildren().add(getTileElectricity());
//            }
//        }

        List<Button> listBtnsFavourites = new ArrayList<>();

        if (isShowVouchers) {
            if (!listFavVouch.isEmpty()) {
//                List<Button> listBtnsVouchers = getListBtnsVouchers();
                listBtnsFavourites.addAll(getListBtnsVouchers());
            }
        }

        if (isShowBillPayments) {
            if (!listFavBPProds.isEmpty()) {
                List<Button> listBtnsBillPayments = getListBtnsBillPayments();
                listBtnsFavourites.addAll(getListBtnsBillPayments());
            }
        }

        if (isShowElectricity) {
            if (!listFavElecSuppliers.isEmpty()) {
                List<Button> listBtnsElectricity = getListBtnsElectricity();
                listBtnsFavourites.addAll(getListBtnsElectricity());
            }
        }

        if (!listBtnsFavourites.isEmpty()) {
//            JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listBtnsFavourites);
            vb.getChildren().add(JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listBtnsFavourites));
        }

        return vb;
    }

    private List<Button> getListBtnsVouchers() {
        List<Button> listBtnVouchers = new ArrayList<>();
        listBtnVouchers.addAll(favNodes.getListBtnsVouchers(listFavVouch));
        if (!JKFavouriteSetup.getFavouriteSetupStore().isUseDefaultFavourites()) {
            int countVoucher = JKFavouriteSetup.getFavouriteSetupStore().getCountVouchers();
            if (listBtnVouchers.size() > countVoucher) {
                listBtnVouchers = listBtnVouchers.subList(0, countVoucher);
            }
        }
        return listBtnVouchers;
    }

    private List<Button> getListBtnsElectricity() {
        Collections.sort(listFavElecSuppliers, new Comparator<ElectricityProvider>() {
            @Override
            public int compare(ElectricityProvider o1, ElectricityProvider o2) {
                return o1.getDisplayName().compareTo(o2.getDisplayName());
            }
        });
        List<Button> listBtnsElectricity = new ArrayList<>();
        listBtnsElectricity.addAll(favNodes.getListBtnsElectricity(listFavElecSuppliers));
        if (!JKFavouriteSetup.getFavouriteSetupStore().isUseDefaultFavourites()) {
            int countElect = JKFavouriteSetup.getFavouriteSetupStore().getCountElectricity();
            if (listBtnsElectricity.size() > countElect) {
                listBtnsElectricity = listBtnsElectricity.subList(0, countElect);
            }
        }
        return listBtnsElectricity;
    }

    private List<Button> getListBtnsBillPayments() {
        Collections.sort(listFavBPProds, new Comparator<BillPayProduct>() {
            @Override
            public int compare(BillPayProduct o1, BillPayProduct o2) {
                return o1.getProdName().compareTo(o2.getProdName());
            }
        });
        List<Button> listBillPay = new ArrayList<>();
        listBillPay.addAll(favNodes.getListBtnsBillPayments(listFavBPProds));
        if (!JKFavouriteSetup.getFavouriteSetupStore().isUseDefaultFavourites()) {
            int countBillPay = JKFavouriteSetup.getFavouriteSetupStore().getCountBillPayments();
            if (listBillPay.size() > countBillPay) {
                listBillPay = listBillPay.subList(0, countBillPay);
            }
        }
        return listBillPay;
    }

    // // //
    // Use this is we need to keep 'tiles' of transaction types separate
    private TilePane getTileVouchers() {
        List<Button> listVouchers = new ArrayList<>();
        listVouchers.addAll(favNodes.getListBtnsVouchers(listFavVouch));
        if (!JKFavouriteSetup.getFavouriteSetupStore().isUseDefaultFavourites()) {
            int countVoucher = JKFavouriteSetup.getFavouriteSetupStore().getCountVouchers();
            if (listVouchers.size() > countVoucher) {
                listVouchers = listVouchers.subList(0, countVoucher);
            }
        }
        return JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listVouchers);
    }

//    private TilePane getTileVouchers(int category) {
//        List<Button> listVouchers = new ArrayList<>();
//        listVouchers.addAll(favNodes.getListBtnsVouchers(listFavVouch, category));
//        if (!JKFavouriteSetup.getFavouriteSetupStore().isUseDefaultFavourites()) {
//            int countVoucher = JKFavouriteSetup.getFavouriteSetupStore().getCountVouchers();
//            if (listVouchers.size() > countVoucher) {
//                listVouchers = listVouchers.subList(0, countVoucher);
//            }
//        }
//        return JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listVouchers);
//    }

//    private TilePane getTileBundles() {
//        Collections.sort(listFavTopProvBundles, new Comparator<TopupProvider>() {
//            @Override
//            public int compare(TopupProvider o1, TopupProvider o2) {
//                return o1.getName().compareTo(o2.getName());
//            }
//        });
//        List<Button> listBundles = new ArrayList<>();
//        listBundles.addAll(favNodes.getListBtnsTopData(listFavTopProvBundles));
//        if (listBundles.size() > 4) {
//            listBundles = listBundles.subList(0, 4);
//        }
//        return JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listBundles);
//    }

    private TilePane getTileElectricity() {
        Collections.sort(listFavElecSuppliers, new Comparator<ElectricityProvider>() {
            @Override
            public int compare(ElectricityProvider o1, ElectricityProvider o2) {
                return o1.getDisplayName().compareTo(o2.getDisplayName());
            }
        });
        List<Button> listElectricity = new ArrayList<>();
        listElectricity.addAll(favNodes.getListBtnsElectricity(listFavElecSuppliers));
        if (!JKFavouriteSetup.getFavouriteSetupStore().isUseDefaultFavourites()) {
            int countElect = JKFavouriteSetup.getFavouriteSetupStore().getCountElectricity();
            if (listElectricity.size() > countElect) {
                listElectricity = listElectricity.subList(0, countElect);
            }
        }
        return JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listElectricity);
    }

    private TilePane getTileBillPayments() {
        Collections.sort(listFavBPProds, new Comparator<BillPayProduct>() {
            @Override
            public int compare(BillPayProduct o1, BillPayProduct o2) {
                return o1.getProdName().compareTo(o2.getProdName());
            }
        });
        List<Button> listBillPay = new ArrayList<>();
        listBillPay.addAll(favNodes.getListBtnsBillPayments(listFavBPProds));
        if (!JKFavouriteSetup.getFavouriteSetupStore().isUseDefaultFavourites()) {
            int countBillPay = JKFavouriteSetup.getFavouriteSetupStore().getCountBillPayments();
            if (listBillPay.size() > countBillPay) {
                listBillPay = listBillPay.subList(0, countBillPay);
            }
        }
        return JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listBillPay);
    }

}
