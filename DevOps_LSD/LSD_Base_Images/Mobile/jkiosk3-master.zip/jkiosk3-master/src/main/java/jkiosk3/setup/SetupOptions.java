package jkiosk3.setup;

import javafx.geometry.HPos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.store.JKOptions;
import jkiosk3.users.CurrentUser;

/**
 *
 * @author Val
 */
public class SetupOptions extends Region {

    private RadioButton radKeyboard;
    private RadioButton radTouchscreen;
    private CheckBox chkUserMainMenuItem;
    private CheckBox chkSalesAutoLogout;
    private CheckBox chkSalesPersonLogin;
    private CheckBox chkCanCashierEndShift;
    private RadioButton radReprint10;
    private RadioButton radReprint20;
    private RadioButton radReprint50;
    private RadioButton radReprint100;

    public SetupOptions() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getOptionsEntry());
        vb.getChildren().add(getControls());

        getChildren().add(vb);
    }

    private GridPane getOptionsEntry() {

        GridPane grid = JKLayout.getGridContent2Col(0.35, 0.65, HPos.LEFT);

        VBox vbHead = JKNode.getPageHeadVB("Options");

        Label lblEntry = JKText.getLblDk("Entry Method", JKText.FONT_B_XSM);
        lblEntry.setMinWidth(JKLayout.btnSmW);

        Label lblUserMan = JKText.getLblContentHead("User Management Options");

        Label lblReportOptions = JKText.getLblContentHead("Report Options");

        ToggleGroup toggle = new ToggleGroup();

        radKeyboard = new RadioButton("Keyboard");
        radKeyboard.setToggleGroup(toggle);
        radKeyboard.setSelected(JKOptions.getOptions().isKeyboard());

        radTouchscreen = new RadioButton("Touchscreen");
        radTouchscreen.setToggleGroup(toggle);
        radTouchscreen.setSelected(!(JKOptions.getOptions().isKeyboard()));

        HBox hbEntry = JKLayout.getHBox(0, JKLayout.sp);
        hbEntry.getChildren().addAll(radKeyboard, JKNode.getHSpacer(), radTouchscreen);

        if (SceneSetup.userPin.equals("2596")) {
            chkUserMainMenuItem = new CheckBox("User Login Required for Each Main Menu Item");
            chkUserMainMenuItem.setSelected(JKOptions.getOptions().isMultipleMenuLogin());
            chkUserMainMenuItem.setDisable(false);

        } else if (CurrentUser.getUser().getUserLevel() == 1) {
            chkUserMainMenuItem = new CheckBox("User Login Required for Each Main Menu Item");
            chkUserMainMenuItem.setSelected(JKOptions.getOptions().isMultipleMenuLogin());
            chkUserMainMenuItem.setDisable(true);
            chkUserMainMenuItem.setVisible(false);
        }

        chkSalesAutoLogout = new CheckBox("Sales Person AutoLogout After Each Sale");
        chkSalesAutoLogout.setSelected(JKOptions.getOptions().isAutoLogout());

        chkSalesPersonLogin = new CheckBox("Sales Person Login at Start of Each Sale");
        chkSalesPersonLogin.setSelected(JKOptions.getOptions().isSalesPersonLogin());

        chkCanCashierEndShift = new CheckBox("Allow Cashiers to End Shift");
        chkCanCashierEndShift.setSelected(JKOptions.getOptions().isCashierEndShift());

        Label lblReprints = JKText.getLblDk("Number of Reprints to view", JKText.FONT_B_XSM);

        ToggleGroup tgReprints = new ToggleGroup();

        radReprint10 = new RadioButton("10");
        radReprint10.setToggleGroup(tgReprints);
        radReprint10.setSelected(JKOptions.getOptions().getReprintNumber() == 10);

        radReprint20 = new RadioButton("20");
        radReprint20.setToggleGroup(tgReprints);
        radReprint20.setSelected(JKOptions.getOptions().getReprintNumber() == 20);

        radReprint50 = new RadioButton("50");
        radReprint50.setToggleGroup(tgReprints);
        radReprint50.setSelected(JKOptions.getOptions().getReprintNumber() == 50);

        radReprint100 = new RadioButton("100");
        radReprint100.setToggleGroup(tgReprints);
        radReprint100.setSelected(JKOptions.getOptions().getReprintNumber() == 100);

        HBox hbReprints = JKLayout.getHBoxLeft(0, (4 * JKLayout.sp));
        hbReprints.getChildren().addAll(radReprint10, radReprint20, radReprint50, radReprint100);

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblEntry, hbEntry);

        grid.add(JKNode.createGridSpanSep(2), 0, 2);
        grid.add(lblUserMan, 0, 3, 2, 1);
        grid.add(chkUserMainMenuItem, 0, 4, 2, 1);
        grid.add(chkSalesAutoLogout, 0, 5, 2, 1);
        grid.add(chkSalesPersonLogin, 0, 6, 2, 1);
        grid.add(chkCanCashierEndShift, 0, 7, 2, 1);
        grid.add(JKNode.createGridSpanSep(2), 0, 8);
        grid.add(lblReportOptions, 0, 9, 2, 1);
        grid.add(lblReprints, 0, 10, 2, 1);
        grid.add(hbReprints, 0, 11, 2, 1);

        return grid;
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("", false) {
            @Override
            public void onClickTest() {
                System.out.println("we clicked the Test button");
            }

            @Override
            public void onClickSave() {
                saveOptions();
            }
        };
    }

    private void saveOptions() {
        if (radKeyboard.isSelected()) {
            JKOptions.getOptions().setKeyTouch("Keyboard");
            JKOptions.getOptions().setKeyboard(true);
        } else if (radTouchscreen.isSelected()) {
            JKOptions.getOptions().setKeyTouch("Touchscreen");
            JKOptions.getOptions().setKeyboard(false);
        }

        if (chkUserMainMenuItem.isSelected()) {
            JKOptions.getOptions().setMultipleMenuLogin(true);
        } else {
            JKOptions.getOptions().setMultipleMenuLogin(false);
        }

        if (chkSalesAutoLogout.isSelected()) {
            JKOptions.getOptions().setAutoLogout(true);
        } else {
            JKOptions.getOptions().setAutoLogout(false);
        }

        if (chkSalesPersonLogin.isSelected()) {
            JKOptions.getOptions().setSalesPersonLogin(true);
        } else {
            JKOptions.getOptions().setSalesPersonLogin(false);
        }

        if (chkCanCashierEndShift.isSelected()) {
            JKOptions.getOptions().setCashierEndShift(true);
        } else {
            JKOptions.getOptions().setCashierEndShift(false);
        }

        if (radReprint10.isSelected()) {
            JKOptions.getOptions().setReprintNumber(10);
        } else if (radReprint20.isSelected()) {
            JKOptions.getOptions().setReprintNumber(20);
        } else if (radReprint50.isSelected()) {
            JKOptions.getOptions().setReprintNumber(50);
        } else if (radReprint100.isSelected()) {
            JKOptions.getOptions().setReprintNumber(100);
        }

        if (JKOptions.saveSystemSetup()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Setup options saved successfully", null);
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Setup options not saved", null);
        }
    }
}
