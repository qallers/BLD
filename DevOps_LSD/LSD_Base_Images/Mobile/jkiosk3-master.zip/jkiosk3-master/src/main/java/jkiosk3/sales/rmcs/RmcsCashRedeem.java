package jkiosk3.sales.rmcs;

import aeonmoneytransfer.MoneyTransferResponse;
import aeonprinting.AeonPrintJob;

import java.util.Date;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.print_layouts.PrintAssorted;
import jkiosk3.sales.MerchantCopy;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._tender.TenderAmounts;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.UserUtil;

/**
 * @author val
 */
public class RmcsCashRedeem extends Region {

    private String recipientMobileNum;
    private String voucherNum;
    private String voucherPin;
    private double amount;

    public RmcsCashRedeem() {
        VBox vbRedeem = JKLayout.getVBox (0, JKLayout.spNum);
        vbRedeem.getChildren ().add (getRedeemVoucherEntry ());
        vbRedeem.getChildren ().add (getControlButtons ());
        getChildren ().add (vbRedeem);
    }

    private GridPane getRedeemVoucherEntry() {
        double inset = 2 * JKLayout.sp;
        Label lblRedeem = JKText.getLblContentHead ("Money Transfer - " + RmcsUtil.MONEY_TRF_REDEEM);

        Label lblRecipient = JKText.getLblContentSubHead ("Recipient Details: ");
        Label lblVoucher = JKText.getLblContentSubHead ("Voucher Details: ");

        // Recipient components
        Label lblRecMobileNum = JKText.getLblDk ("Mobile Number", JKText.FONT_B_XSM);
        lblRecMobileNum.setTranslateX (inset);
        final TextField txtRecMobileNum = new TextField ();
        txtRecMobileNum.getStyleClass ().add ("txtfld-right");
        txtRecMobileNum.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad ().showNumPad (txtRecMobileNum, "Mobile Number", "",
                        new NumberPadResult () {
                            @Override
                            public void onDone(String value) {
                                if (validateMobileNum (value)) {
                                    recipientMobileNum = value;
                                    txtRecMobileNum.setText (JKText.getCellNumFormatted (recipientMobileNum));
                                } else {
                                    txtRecMobileNum.clear ();
                                }
                            }
                        });
            }
        });

        // Voucher components
        Label lblVoucherNum = JKText.getLblDk ("Voucher Number", JKText.FONT_B_XSM);
        lblVoucherNum.setTranslateX (inset);
        Label lblPinNum = JKText.getLblDk ("PIN Number", JKText.FONT_B_XSM);
        lblPinNum.setTranslateX (inset);

        final TextField txtVoucherNum = new TextField ();
        txtVoucherNum.getStyleClass ().add ("txtfld-right");
        txtVoucherNum.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (txtVoucherNum, "Voucher Number", "", false, true, new KeyboardResult () {
                    @Override
                    public void onDone(String value) {
                        System.out.println ("value = " + value);
                        value = value.replaceAll ("\\s+", "");
                        System.out.println ("value = " + value);
                        if (validateVoucherNum (value)) {
                            voucherNum = value;
                            txtVoucherNum.setText (RmcsUtil.getVoucherDisplayFormat (voucherNum));
                        } else {
                            txtVoucherNum.clear ();
                        }
                    }
                });
            }
        });
        final PasswordField pwdPinNum = new PasswordField ();
        pwdPinNum.getStyleClass ().add ("txtfld-right");
        pwdPinNum.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (pwdPinNum, "PIN Number", "", false, true, new KeyboardResult () {
                    @Override
                    public void onDone(String value) {
                        if (validatePinNum (value)) {
                            voucherPin = value;
                            pwdPinNum.setText (voucherPin);
                        } else {
                            pwdPinNum.clear ();
                        }
                    }
                });
            }
        });

        GridPane grid = JKLayout.getGridContent2Col (0.5, 0.5);

        grid.add (lblRedeem, 0, 0, 2, 1);
        grid.add (JKNode.createGridSpanSep (2), 0, 1);

        grid.addRow (2, lblRecipient);
        grid.addRow (3, lblRecMobileNum, txtRecMobileNum);
        grid.addRow (5, lblVoucher);
        grid.addRow (6, lblVoucherNum, txtVoucherNum);
        grid.addRow (7, lblPinNum, pwdPinNum);

        return grid;
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons ();

        ctrlBtns.getBtnAccept ().setDisable (false);
        ctrlBtns.getBtnAccept ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                if (validateContinue ()) {
                    processRmcsRedeem ();
                }
            }
        });
        ctrlBtns.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new MoneyTransferMenu ());
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
            }
        });

        return ctrlBtns;
    }

    private void processRmcsRedeem() {
        String ref = SalesUtil.getUniqueRef ();

        RmcsRedeem.getInstance ().getRedeemReq ().setReference (ref);
        RmcsRedeem.getInstance ().getRedeemReq ().setRecipMSISDN (recipientMobileNum);
        RmcsRedeem.getInstance ().getRedeemReq ().setVoucherNum (voucherNum);
        RmcsRedeem.getInstance ().getRedeemReq ().setPIN (voucherPin);

        RmcsUtil.getMoneyTrfRedeemResp (RmcsRedeem.getInstance ().getRedeemReq (), new RmcsUtil.MoneyTransferRedeemResponseResult () {

            @Override
            public void moneyTrfRedRespResult(final MoneyTransferResponse moneyTrfRedResp) {
                if (moneyTrfRedResp.isSuccess ()) {
                    final String transRef = moneyTrfRedResp.getTrxId ();
                    RmcsRedeem.getInstance ().setRedeemResp (moneyTrfRedResp);
                    RmcsRedeem.getInstance ().setDate (new Date ());
                    amount = -moneyTrfRedResp.getAmount ();

                    JKiosk3.getMsgBox ().showMsgBox (RmcsUtil.MONEY_TRF_REDEEM + " Successful", "", new RmcsCashRedeemSummary (),
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    // Money Transfer is ALWAYS a CASH-ONLY transaction!
                                    TenderAmounts.addTenderAmount (TenderAmounts.TENDER_CASH, amount);

                                    AeonPrintJob apj = moneyTrfRedResp.getPrintLines ();

                                    if (JKPrintOptions.getPrintOptions ().isPrintMerchantCopy ()) {
                                        MerchantCopy.getInstance ().setTransType (SaleType.MONEY_TRANSFER.getDisplay ());
                                        MerchantCopy.getInstance ().setDetails (moneyTrfRedResp.getShiftId (), moneyTrfRedResp.getTransSeq (),
                                                SaleType.MONEY_TRANSFER_REDEEM.getDisplay (), amount, null, 0,
                                                transRef, RmcsRedeem.getInstance ().getDate (), CurrentUser.getSalesUser ().getUserName ());

                                        AeonPrintJob apjMC = PrintAssorted.getMerchantCopyPrint (MerchantCopy.getInstance ());
                                        apj.setMerchantCopy (apjMC);
                                    }

                                    SalesUtil.processSoldItem (transRef,
                                            SaleType.MONEY_TRANSFER.getDisplay (),
                                            SaleType.MONEY_TRANSFER_REDEEM.getDisplay () + " - R " + amount,
                                            apj, amount, false, "online",
                                            moneyTrfRedResp.getVoucherNum (), RmcsRedeem.getInstance ().getDate (), "", null);

                                    PrintHandler.handlePrintRequestSale (SaleType.MONEY_TRANSFER_REDEEM.getDisplay (),
                                            apj, transRef);
                                    SceneSales.clearAndChangeContent (new MoneyTransferMenu ());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Voucher Redeem Error", !moneyTrfRedResp.getAeonErrorText ().isEmpty () ?
                            "A" + moneyTrfRedResp.getAeonErrorCode () + " - " + moneyTrfRedResp.getAeonErrorText () :
                            "B" + moneyTrfRedResp.getErrorCode () + " - " + moneyTrfRedResp.getErrorText ()
                                    + "\n\nPlease confirm that all details are entered correctly.", null);
                }
            }
        });
    }

    private boolean validateMobileNum(String mobileNum) {
        if (!mobileNum.matches ("(^0[678][01234689]((\\d{7})|( |-)((\\d{3}))( |-)(\\d{4})|( |-)(\\d{7})))")) {
            JKiosk3.getMsgBox ().showMsgBox ("Mobile Number", "Please enter a valid Mobile Number", null);
            return false;
        }
        return true;
    }

    private boolean validateVoucherNum(String vouchNum) {
        if (!vouchNum.matches ("(\\w{16,20})")) {
            JKiosk3.getMsgBox ().showMsgBox ("Voucher Number", "Please enter a valid Voucher Number", null);
            return false;
        }
        return true;
    }

    private boolean validatePinNum(String pinNum) {
        if (!pinNum.matches ("(\\w{5})")) {
            JKiosk3.getMsgBox ().showMsgBox ("PIN Number", "Please enter a valid PIN Number", null);
            return false;
        }
        return true;
    }

    private boolean validateContinue() {
        if (recipientMobileNum == null || voucherNum == null || voucherPin == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Incomplete Details", "Please provide all details", null);
            return false;
        }
        return true;
    }
}
