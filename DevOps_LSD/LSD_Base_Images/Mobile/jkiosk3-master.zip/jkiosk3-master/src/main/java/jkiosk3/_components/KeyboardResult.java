package jkiosk3._components;

/**
 *
 * @author Val
 */
public abstract class KeyboardResult {

    public abstract void onDone(String value);
}
