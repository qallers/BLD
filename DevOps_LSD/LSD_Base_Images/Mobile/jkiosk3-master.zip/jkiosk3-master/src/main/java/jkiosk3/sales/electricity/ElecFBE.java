package jkiosk3.sales.electricity;

import aeonelectricity.ElectricityConfirmation;
import aeonelectricity.ElectricityConnection;
import aeonelectricity.ElectricityMeter;
import aeonelectricity.ElectricityVoucher;
import aeonprinting.AeonPrintJob;

import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.MagCardData;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.PrintQueue;
import jkiosk3.printing.PrintUtil;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.electricity.ElectricityUtil.ElectricityConfirm;
import jkiosk3.sales.electricity.ElectricityUtil.ElectricityResult;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.users.UserUtil;

/**
 * @author Val
 */
public class ElecFBE extends Region {

    private ElectricityConnection connection;
    private ElectricityConfirmation confirmation;
    private final ElectricityProvider provider;
    private String meterNum;
    private int amount;
    private String sgc;
    private String tt;
    private String ti;
    private String krn;
    private String alg;
    private final VBox vbFBE;
    private ElecEnterMeter gMeter;
    private ElecShareBtnsLessMore btnsLessMore;
    private final ElecShareGridLessMore gridLessMore;
    private boolean isMore = false;

    public ElecFBE(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;
        vbFBE = JKLayout.getVBox (0, JKLayout.spNum);
        gridLessMore = new ElecShareGridLessMore (ElectricityUtil.ELEC_FBE);
        getChildren ().add (getMeterNumberEntry ());
    }

    private VBox getMeterNumberEntry() {
        gMeter = new ElecEnterMeter (provider, ElectricityUtil.ELEC_FBE, new ElecEnterMeterResult () {
            @Override
            public void onDone() {
                if (gMeter.isMagEntry ()) {
                    if (vbFBE.getChildren ().contains (gridLessMore)) {
                        vbFBE.getChildren ().remove (gridLessMore);
                    }
                    btnsLessMore.getBtnLess ().setDisable (true);
                    btnsLessMore.getBtnMore ().setDisable (true);
                    btnsLessMore.getBtnAccept ().setDisable (false);
                    isMore = false;
                }
            }
        });
        System.out.println ("reading mag card for meter num = : " + gMeter.isMagEntry ());

        vbFBE.getChildren ().addAll (gMeter, getElecSaleCtrls ());
        return vbFBE;
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        btnsLessMore = new ElecShareBtnsLessMore ();

        if (provider.getDisplayName ().contains ("Eskom")
                || provider.getDisplayName ().contains ("Universal")) {
            btnsLessMore.getBtnLess ().setVisible (true);
            btnsLessMore.getBtnLess ().setOnMouseReleased (new EventHandler () {
                @Override
                public void handle(Event arg0) {
                    getLessMoreAction (btnsLessMore.getBtnLess ());
                }
            });
            btnsLessMore.getBtnMore ().setVisible (true);
            btnsLessMore.getBtnMore ().setOnMouseReleased (new EventHandler () {
                @Override
                public void handle(Event arg0) {
                    getLessMoreAction (btnsLessMore.getBtnMore ());
                }
            });
        }

        btnsLessMore.getBtnAccept ().setDisable (false);
        btnsLessMore.getBtnAccept ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                requestConfirmation ();
            }
        });
        btnsLessMore.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });

        return btnsLessMore;
    }

    private void getLessMoreAction(Button b) {
        switch (b.getText ()) {
            case "Less...":
                vbFBE.getChildren ().remove (gridLessMore);
                btnsLessMore.getBtnLess ().setDisable (true);
                btnsLessMore.getBtnMore ().setDisable (false);
                isMore = false;
                break;
            case "More...":
                vbFBE.getChildren ().add (1, gridLessMore);
                btnsLessMore.getBtnLess ().setDisable (false);
                btnsLessMore.getBtnMore ().setDisable (true);
                isMore = true;
                break;
            default:
                vbFBE.getChildren ().remove (gridLessMore);
                break;
        }
    }

    private boolean inputValidation() {
        boolean validated = false;
        try {
            meterNum = gMeter.getMeterNum ().trim ();
            sgc = gridLessMore.getTxtSGC ().getText ();
            tt = gridLessMore.getTxtTT ().getText ();
            ti = gridLessMore.getTxtTi ().getText ();
            krn = gridLessMore.getTxtKrn ().getText ();
            alg = gridLessMore.getTxtAlg ().getText ();
            //
            if (meterNum.equals ("") || meterNum == null) {
                JKiosk3.getMsgBox ().showMsgBox ("Meter Number", "Meter Number cannot be blank.\n"
                        + "Please enter Meter Number.", null);
                validated = false;
            } else {
                if (isMore) {
                    amount = 0;

                    if ((gridLessMore.getTxtSGC ().getText ().equals ("") || gridLessMore.getTxtSGC ().getText () == null)
                            || (gridLessMore.getTxtTT ().getText ().equals ("") || gridLessMore.getTxtTT ().getText () == null)
                            || (gridLessMore.getTxtTi ().getText ().equals ("") || gridLessMore.getTxtTi ().getText () == null)
                            || (gridLessMore.getTxtKrn ().getText ().equals ("") || gridLessMore.getTxtKrn ().getText () == null)
                            || (gridLessMore.getTxtAlg ().getText ().equals ("") || gridLessMore.getTxtAlg ().getText () == null)) {
                        JKiosk3.getMsgBox ().showMsgBox ("Empty Field(s)", "All fields must be completed", null);
                        validated = false;
                    } else {
                        if ((!sgc.matches ("\\d{6}")) || (!tt.matches ("\\d{2}")) || (!ti.matches ("\\d{2}"))
                                || (!krn.matches ("\\d{1}")) || (!alg.matches ("\\d{2}"))) {
                            JKiosk3.getMsgBox ().showMsgBox ("Incorrect value entered",
                                    "Fields must be numeric only: - \n"
                                            + "SGC - 6 digits\n"
                                            + "TT - 2 digits\n"
                                            + "TI - 2 digits\n"
                                            + "KRN - 1 digit\n"
                                            + "ALG - 2 digits", null);
                        } else {
                            validated = true;
                        }
                    }
                } else {
                    validated = true;
                }
            }
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox ().showMsgBox ("Amount", "Amount for FBE will be R 0", null);
            validated = false;
        } catch (Exception e) {
            e.printStackTrace ();
        }

        return validated;
    }

    private void requestConfirmation() {
        if (inputValidation ()) {
            makeElectricityConnection ();
        }
    }

    private void makeElectricityConnection() {
        final ElectricityMeter meter = new ElectricityMeter ();
        if (gMeter.isMagEntry ()) {
            meter.setTrack2data (meterNum);
            meter.setMeterSgc ("");
            meter.setMeterTt ("");
            meter.setMeterTi ("");
            meter.setMeterKrn ("");
            meter.setMeterAlg ("");
        } else {
            meter.setMeterNum (meterNum);
            meter.setMeterSgc (sgc);
            meter.setMeterTt (tt);
            meter.setMeterTi (ti);
            meter.setMeterKrn (krn);
            meter.setMeterAlg (alg);
        }

        String transType = provider.getTransactionType ();

        ElectricityUtil.getElectricityConfirmation (transType, "FBE", meter, 0, new ElectricityConfirm () {
            @Override
            public void electricityConfirm(ElectricityConnection connect, final ElectricityConfirmation confirm) {
                if (confirm.isSuccess ()) {
                    connection = connect;
                    confirmation = confirm;

                    ElecConfirm confirmGrid = new ElecConfirm (confirmation, meter, amount, ElectricityUtil.ELEC_FBE);

                    JKiosk3.getMsgBox ().showMsgBox ("Electricity Meter Confirmation", "FBE", confirmGrid,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    buyElectricity (confirm.getTransRef ());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Unable to Confirm", !confirm.getAeonErrorText ().isEmpty () ?
                                    "A" +confirm.getAeonErrorCode () + " - " + confirm.getAeonErrorText () :
                                    "B" +confirm.getErrorCode () + " - " + confirm.getErrorText (),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    //
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                    ElectricityUtil.resetElectricity ();
                }
            }
        });
    }

    private void buyElectricity(String transRef) {
        String ref = SalesUtil.getUniqueRef ();

        ElectricityUtil.getElectricityVoucher (connection, "FBE", transRef, ref, new ElectricityResult () {
            @Override
            public void electricityResult(ElectricityVoucher voucher) {
                if (voucher.isSuccess ()) {
                    SalesUtil.processElectricity (ElectricityUtil.ELEC_FBE, voucher, amount);

//                    int transRef = voucher.getTransRef();
////                    AeonPrintJob printjob = voucher.getPrintLines();
////                    AeonPrintJob apjm = voucher.getMerchantPrintLines();
//                    String descript = ElectricityUtil.ELEC_FBE + " " + voucher.getMeter().getMeterNum();
//
////                    SalesUtil.processSoldItem(transRef, SaleType.ELECTRICITY.getDisplay(), descript, printjob,
////                            amount, false, "online", null);
//                    SalesUtil.processSoldItem(transRef, SaleType.ELECTRICITY.getDisplay(), descript, 
//                            voucher.getPrintLines(), voucher.getMerchantPrintLines(), amount, false, "online", null);
//////                    ElectricityUtil.printMerchantCopy(confirmation, voucher, amount);
////                    PrintHandler.handleMerchantCopyPrint(apjm);
//                    final List<MagCardData> magList = ElectricityUtil.getMagCardTokens(voucher);
//
//                    if (JKPrintOptions.getPrintOptions().isPrintImmediately()) {
//                        if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
//                            JKiosk3.getPrintPreview().showPrintPreview("Electricity FBE", voucher.getPrintLines(), Integer.toString(transRef), 
//                                    PrintPreview.PRN_OK, new PrintPreviewResult() {
//                                        @Override
//                                        public void onOk() {
//                                            PrintUtil.writeMagCardTokens(magList, null);
//                                        }
//
//                                        @Override
//                                        public void onCancel() {
//                                            //
//                                        }
//                                    });
//                        } else {
//                            PrintUtil.sendToPrinter(voucher.getPrintLines(), transRef);
//                            PrintUtil.writeMagCardTokens(magList, null);
//                        }
//                    } else {
//                        PrintQueue.addItem(Integer.toString(voucher.getTransRef()), voucher.getPrintLines());
//                        PrintQueue.addMagCards(magList);
//                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Electricity FBE Failed", !voucher.getAeonErrorText ().isEmpty () ?
                            voucher.getAeonErrorCode () + " - " + voucher.getAeonErrorText () :
                            voucher.getErrorText (), null);
                }
                ElectricityUtil.resetElectricity ();
            }
        });
    }
}
