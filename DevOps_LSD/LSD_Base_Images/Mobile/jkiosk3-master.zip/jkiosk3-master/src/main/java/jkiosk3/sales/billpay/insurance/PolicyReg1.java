package jkiosk3.sales.billpay.insurance;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.users.UserUtil;

public class PolicyReg1 extends Region {

    //    private ToggleGroup togGrpPolType;
    private TextField txtPolNum;

    public PolicyReg1() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().add(polRegStep1());
        vb.getChildren().add(getNav());
        getChildren().add(vb);
        setContent();
    }

    private void setContent() {
        if (PolicyRegistration.getInstance().isNav1()) {
//            String togSelected = PolicyRegistration.getInstance().getPolicyType();
//            for (int i = 0; i < PolicyRegUtil.getListPolTypes().size(); i++) {
//                if (togSelected.equals(PolicyRegUtil.getListPolTypes().get(i))) {
//                    togGrpPolType.getToggles().get(i).setSelected(true);
//                    break;
//                }
//            }
            txtPolNum.setText(PolicyRegistration.getInstance().getPolicyNumber());
        }
    }

    private Group polRegStep1() {

        Label lblHead = JKText.getLblDk("Policy Registration", JKText.FONT_B_SM);
        Label lblStep = JKText.getLblDk("Step 1", JKText.FONT_B_XSM);

        VBox vbHead = JKNode.getPageDblHeadVB(0, lblHead, lblStep);

        Label lblPolNum = JKText.getLblDk("Policy Number", JKText.FONT_B_XXSM);

//        List<String> btnLabels = PolicyRegUtil.getListPolTypes();
//        togGrpPolType = new ToggleGroup();
//
//        HBox hbPolType = JKLayout.getHBox(0, JKLayout.sp);
//        for (final String s : btnLabels) {
//            final ToggleButton tog = JKNode.getToggleSm(s);
//            tog.setMinWidth((JKLayout.contentW - (4 * JKLayout.sp)) / 3);
//            tog.getStyleClass().add("prov_VAS");
//            tog.setFont(JKText.FONT_B_XXSM);
//            tog.setToggleGroup(togGrpPolType);
//            tog.setOnMouseReleased(new EventHandler() {
//                @Override
//                public void handle(Event e) {
//                    if (tog.isSelected()) {
//                        PolicyRegistration.getInstance().setPolicyType(s);
//                    }
//                }
//            });
//            hbPolType.getChildren().add(tog);
//        }
        txtPolNum = new TextField();
        txtPolNum.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getKeyboard().showKeyboard(txtPolNum, "Enter Policy Number", "", false, true);
//                }
            }
        });

        GridPane grid = JKLayout.getContentGrid2Col(0.25, 0.75);

        grid.add(vbHead, 0, 0, 2, 1);

//        grid.addRow(2, hbPolType);
        grid.addRow(4, lblPolNum, txtPolNum);
        grid.addRow(5, new Label());

        Group grp = JKNode.getContentGroup(grid);

        return grp;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav();

        nav.getBtnBack().setDisable(true);

        nav.getBtnCancel().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent(new BillPaymentMenu());
            }
        });

        nav.getBtnNext().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                if (isValidReg1()) {
                    PolicyRegistration.getInstance().setNav1(true);
                    PolicyRegistration.getInstance().setPolicyNumber(txtPolNum.getText());
                    SceneSales.clearAndChangeContent(new PolicyReg2());
                }
            }
        });
        return nav;
    }

    private boolean isValidReg1() {
//        if (togGrpPolType.getSelectedToggle() == null) {
//            JKiosk3.getMsgBox().showMsgBox("Policy Type", "Please select one of the Policy Types", null);
//            return false;
//        }
        if (txtPolNum.getText() == null || txtPolNum.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Policy Number", "Please enter a Policy Number", null);
            return false;
        }
        return true;
    }
}
