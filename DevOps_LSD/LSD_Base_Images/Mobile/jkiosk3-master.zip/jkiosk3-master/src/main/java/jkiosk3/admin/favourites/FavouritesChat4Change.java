package jkiosk3.admin.favourites;

import aeonfavourites.FavouriteItem;
import aeonvarivouchers.Supplier;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Pagination;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.admin.favourites.fav_cache.CacheFavouriteCustomStore;
import jkiosk3.sales.chat4change.Chat4ChangeUtil;

import java.util.ArrayList;
import java.util.List;

public class FavouritesChat4Change extends Region {

    private List<FavouriteItem> listFavouriteCache;
    private List<FavouriteItem> listFavouriteTemp;
    private List<Supplier> suppliers;
    private List<Node> listChkNodes;
    private StackPane stackPane;
    private final static double PG_HT = 525;
    private final static int PG_SIZE = 10;

    public FavouritesChat4Change() {
        this.suppliers = new ArrayList<>();
        this.stackPane = JKLayout.getStackFavouriteSelect(PG_HT);

        this.listFavouriteCache = CacheFavouriteCustomStore.getListFavouriteItems();
        this.listFavouriteTemp = new ArrayList<>();
        for (FavouriteItem f : listFavouriteCache) {
            listFavouriteTemp.add(f);
        }

        Chat4ChangeUtil.getC4CSupplierList(new Chat4ChangeUtil.C4CListSuppliersResult() {

            @Override
            public void c4cListSuppliersResult(List<Supplier> listSuppliers) {
                if (listSuppliers != null && !listSuppliers.isEmpty()) {
                    suppliers = listSuppliers;

                    getChildren().addAll(getFavouriteChat4ChangeLayout());
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Chat 4 Change Supplier Error", "No Chat 4 Change Suppliers found", null);
                    JKiosk3.changeScene(new SceneFavourites());
                }
            }
        });
    }

    private VBox getFavouriteChat4ChangeLayout() {
        getProductCheckBoxes();

        VBox vbContent = JKLayout.getVBoxContent(JKLayout.spNum);
        VBox vbHead = JKNode.getPageHeadVB("Select Chat 4 Change Favourites");

        vbContent.getChildren().addAll(vbHead, stackPane);

        VBox vbPage = JKLayout.getVBox(0, JKLayout.spNum);
        vbPage.getChildren().addAll(vbContent, getBtnControls());
        return vbPage;
    }

    private ControlButtonsFav getBtnControls() {
        ControlButtonsFav ctrl = new ControlButtonsFav();
        ctrl.getBtnSave().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                saveUpdatedFavourites();
            }
        });
        return ctrl;
    }

    private void getProductCheckBoxes() {
        listChkNodes = getListC4CSupplierFavs();

        createPagedItems();
    }

    private List<Node> getListC4CSupplierFavs() {
        List<Node> listChkProvs = new ArrayList<>();
        for (final Supplier s : suppliers) {
            final CheckBox chk = new CheckBox(s.getName());
            for (FavouriteItem i : listFavouriteCache) {
                if (i.getTrxType().equalsIgnoreCase("C4C_Voucher")
                        && i.getProductId().equals(Integer.toString(s.getCode()))) {
                    chk.setSelected(true);
                    break;
                }
            }
            chk.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    if (chk.isSelected()) {
                        addProduct(s);
                    } else if (!chk.isSelected()) {
                        removeProduct(s);
                    }
                }
            });
            listChkProvs.add(chk);
        }

        return listChkProvs;
    }

    private void createPagedItems() {

        int numPgs = 0;
        if (listChkNodes.isEmpty()) {
            numPgs = 1;
        } else if (listChkNodes.size() % PG_SIZE == 0) {
            numPgs = listChkNodes.size() / PG_SIZE;
        } else {
            numPgs = (listChkNodes.size() / PG_SIZE) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedVBox(pg, listChkNodes, PG_SIZE, PG_HT);
            }
        });

        stackPane.getChildren().add(pages);
    }

    private void addProduct(Supplier supplier) {
        if (!isProductInList(supplier)) {
            FavouriteItem favouriteItem = new FavouriteItem();
            favouriteItem.setTrxGroup("Vouchers");
            favouriteItem.setTrxType("C4C_Voucher");
            favouriteItem.setProductId(Integer.toString(supplier.getCode()));
            listFavouriteTemp.add(favouriteItem);
        }
    }

    private void removeProduct(Supplier supplier) {
        if (isProductInList(supplier)) {
            for (FavouriteItem f : listFavouriteTemp) {
                if (f.getTrxType().equalsIgnoreCase("C4C_Voucher")
                        && f.getProductId().equals(Integer.toString(supplier.getCode()))) {
                    listFavouriteTemp.remove(f);
                    break;
                }
            }
        }
    }

    private boolean isProductInList(Supplier supplier) {
        FavouriteItem favItem = null;
        for (FavouriteItem f : listFavouriteTemp) {
            if (f.getTrxType().equalsIgnoreCase("C4C_Voucher")
                    && f.getProductId().equals(Integer.toString(supplier.getCode()))) {
                favItem = f;
                break;
            }
        }
        if (favItem != null) {
            return true;
        } else {
            return false;
        }
    }

    private void saveUpdatedFavourites() {
        if (!listFavouriteTemp.isEmpty()) {
            listFavouriteCache = listFavouriteTemp;
            if (CacheFavouriteCustomStore.saveFavouriteStore(listFavouriteCache)) {
                SceneFavourites.clearAndChangeContent(new FavouritesChat4Change());
            }
        } else {
            JKiosk3.getMsgBox().showMsgBox("Custom Favourites", "Please add at least 1 product to the list", null);
        }
    }
}
