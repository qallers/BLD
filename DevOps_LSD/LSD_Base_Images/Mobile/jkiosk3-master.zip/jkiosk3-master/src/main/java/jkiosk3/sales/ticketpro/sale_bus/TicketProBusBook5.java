package jkiosk3.sales.ticketpro.sale_bus;

import aeonprinting.AeonPrintJob;
import aeonticketpros.TicketProsCheckoutResp;
import aeonticketpros.TicketProsPaymentReq;
import aeonticketpros.TicketProsPaymentResp;
import aeonticketpros.TicketProsPrintReq;
import aeonticketpros.TicketProsPrintResp;

import java.io.File;
import java.util.Date;
import java.util.logging.Logger;

import aeonticketpros.bus.TicketProBusAutoCancelReq;
import aeonticketpros.bus.TicketProBusAutoCancelResp;
import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.tickets.JKPutcoCancel;
import jkiosk3.sales.MerchantCopy;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales._tender.TenderAmounts;
import jkiosk3.sales.ticketpro.TicketProBusSale;
import jkiosk3.sales.ticketpro.TicketProUtilBus;
import jkiosk3.sales.ticketpro.TicketProUtilBus.TicketProBusPaymentResult;
import jkiosk3.sales.ticketpro.TicketProUtilBus.TicketProBusTicketPrintResult;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.UserUtil;
import jkiosk3.utilities.DownloadUtil;

public class TicketProBusBook5 extends Region {

    /*
     * Payment for TicketPro Bus Tickets
     */
    private final static Logger logger = Logger.getLogger (TicketProBusBook5.class.getName ());
    //
    private final TicketProsCheckoutResp checkoutResponse;
    private TicketProsPaymentResp paymentResponse;
    private TicketProsPrintResp printResponse;
    private JKTenderToggles tenderTypes;
    private String tenderSelected;

    public TicketProBusBook5() {
        checkoutResponse = TicketProBusSale.getInstance ().getCheckoutResponse ();

        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (getSaleReferenceGroup ());
        vb.getChildren ().add (getNav ());

        getChildren ().add (vb);
    }

    private GridPane getSaleReferenceGroup() {

        VBox vbHead = JKNode.getPutcoHeader ("Bus Ticket Booking - Step 5");

        Label lblConfirm = JKText.getLblContentSubHead ("Booking Confirmation and Payment");

        Label lblRef = JKText.getLblDk ("Booking Reference", JKText.FONT_B_XSM);
        Label lblAmtDue = JKText.getLblDk ("Balance Due", JKText.FONT_B_XSM);

        Text txtRef = JKText.getTxtDk (checkoutResponse.getReference (), JKText.FONT_B_XSM);
        Text txtAmtDue = JKText.getTxtDk (JKText.getDeciFormat (checkoutResponse.getBalance ()), JKText.FONT_B_XSM);

        GridPane grid = JKLayout.getGridContent2Col (0.5, 0.5);

        grid.add (vbHead, 0, 0, 2, 1);
        grid.add (lblConfirm, 0, 1, 2, 1);
        grid.addRow (3, lblRef, txtRef);
        grid.addRow (4, lblAmtDue, txtAmtDue);
        grid.addRow (6, getTenderTypes ());

        return grid;
    }

    private JKTenderToggles getTenderTypes() {
        tenderTypes = new JKTenderToggles (SaleType.TICKETPRO.getDisplay ());
        for (ToggleButton b : tenderTypes.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler () {
                @Override
                public void handle(Event e) {
                    tenderSelected = tenderTypes.getTenderTypeSelected ();
                    makePayment ();
                }
            });
        }
        return tenderTypes;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();

        nav.getBtnBack ().setDisable (true);

        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                TicketProBusSale.resetTicketProBusSale ();
                SceneSales.clearAndShowFavourites ();
            }
        });

        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private void makePayment() {
        TicketProsPaymentReq req = new TicketProsPaymentReq ();
        req.setTransactionId (checkoutResponse.getTransactionId ());
        req.setAmount (checkoutResponse.getBalance ());
        req.setPaymentMethod (tenderSelected);

        TicketProUtilBus.getTicketProBusPaymentResp (req, new TicketProBusPaymentResult () {

            @Override
            public void tpBusPaymentResult(TicketProsPaymentResp tpBusPaymentResp) {
                if (tpBusPaymentResp.isSuccess ()) {
                    paymentResponse = tpBusPaymentResp;
                    GridPane gridSumm = showPaymentResponseGrid ();
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Booking Success", "", gridSumm, MessageBox.CONTROLS_SHOW,
                            MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    requestTicketProBusTickets ();
                                    SceneSales.clearAndChangeContent (null);
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }

                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Payment Error",
                            !tpBusPaymentResp.getAeonErrorText ().isEmpty () ?
                                    "A" + tpBusPaymentResp.getAeonErrorCode () + " - " + tpBusPaymentResp.getAeonErrorText () :
                                    "B" + tpBusPaymentResp.getErrorCode () + " - " + tpBusPaymentResp.getErrorText (), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    SceneSales.clearAndShowFavourites ();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private GridPane showPaymentResponseGrid() {
        GridPane grid = JKLayout.getSummaryGrid2Col (0.5, 0.5);
        Label lblRef = JKText.getLblDk ("Booking Reference", JKText.FONT_B_XSM);

        Text txtRef = JKText.getTxtDk (paymentResponse.getReference (), JKText.FONT_B_XSM);

        grid.addRow (0, lblRef, txtRef);

        return grid;
    }

    private void requestTicketProBusTickets() {
        final TicketProsPrintReq printRequest = new TicketProsPrintReq ();
        printRequest.setTransactionId (paymentResponse.getTransactionId ());
        // always print to ticket printer
        printRequest.setFormat ("ezpl");
        printRequest.setCardId ("");
        printRequest.setReprint (false);

        TicketProUtilBus.getTicketProBusPrint (printRequest, new TicketProBusTicketPrintResult () {

            @Override
            public void tpBusTicketPrintResult(TicketProsPrintResp tpBusTicketPrintResp) {
                if (tpBusTicketPrintResp.isSuccess ()) {
                    printResponse = tpBusTicketPrintResp;
                    final File printFile = DownloadUtil.downloadRemoteFile (tpBusTicketPrintResp.getTickets (), JK3Config.getTicketPrint ());
                    if (printFile != null) {
                        // sale should only go into basket if tickets are received from TicketPro AND PRINTED
//                        processSale();
                        printTickets (printFile);

                    } else {
                        // cancel ticket sale - file was not received
                        cancelTicketSale ();
                        // original - showTicketPrintError();
//                        showTicketPrintError();
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Print Error", !tpBusTicketPrintResp.getAeonErrorText ().isEmpty () ?
                                    "A" + tpBusTicketPrintResp.getAeonErrorCode () + " - " + tpBusTicketPrintResp.getAeonErrorText () :
                                    "B" + tpBusTicketPrintResp.getErrorCode () + " - " + tpBusTicketPrintResp.getErrorText (), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    // cancel ticket sale - response was unsuccessful, did not receive URL for tickets
                                    cancelTicketSale ();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private void processSale() {
        boolean canCancel = false;
        String transRef = paymentResponse.getTransRef ();
        String desc = TicketProBusSale.getInstance ().getTicketProBusRouteBooking ().getListSeats ().get (0).getVenue ();
        String bookingRef = paymentResponse.getReference ();
        double amtPaid = checkoutResponse.getBalance ();

        TenderAmounts.addTenderAmount (tenderTypes.getTenderText (), amtPaid);

        SalesUtil.processSoldItem (transRef, SaleType.TICKETPRO.getDisplay (), desc + " " + bookingRef,
                null, amtPaid, canCancel, "online", bookingRef, new Date (), null, tenderSelected);

        PrintHandler.handleMerchantCopyPrint (printResponse.getMerchantCopyPrint ());

//        MerchantCopy.getInstance().setDetails(paymentResponse.getShiftId(), paymentResponse.getTransSeq(),
//                desc + " " + paymentResponse.getReference(),
//                checkoutResponse.getBalance(), null, 0, paymentResponse.getTransRef(),
//                new Date(), CurrentUser.getSalesUser().getUserName(), tenderTypes.getTenderText());
//
//        PrintHandler.handleMerchantCopyPrint(MerchantCopy.getInstance());
    }

    private void printTickets(final File printFile) {
        // This is a 'working' ticket received from TicketPro, use only for testing!!!
//        String branchPath = "C:\\_projects\\BLT\\SouthAfrica\\Roodepoort\\AEON\\Clients\\Applications\\JKiosk3\\branches\\";
//        final File testFile = new File(branchPath + "JK3-SlipOpt-4\\media\\printFiles\\test-x4.ezpl");
        Platform.runLater (new Runnable () {
            @Override
            public void run() {
                String printAdvice = "Tickets will be printed on Ticket Printer.";
                JKiosk3.getMsgBox ().showMsgBox ("Ticket Received From TicketPro", printAdvice, null, MessageBox.CONTROLS_SHOW,
                        MessageBox.MSG_OK, new MessageBoxResult () {

                            @Override
                            public void onOk() {
                                PrintHandler.writeFileContentToPrinterPort (printFile, new ResultCallback () {
                                    @Override
                                    public void onResult(boolean result) {
                                        if (result) {
                                            processSale ();
                                        } else {
                                            // cancel ticket sale
                                            cancelTicketSale ();
                                        }
                                    }
                                });
                            }

                            @Override
                            public void onCancel() {
                                //
                            }
                        });
            }
        });
    }

    private void cancelTicketSale() {
        final TicketProBusAutoCancelReq cancelReq = new TicketProBusAutoCancelReq ();
        cancelReq.setDeviceId (JKSystem.getSystemConfig ().getDeviceId ());
        cancelReq.setDeviceSerial (JKSystem.getSystemConfig ().getSerial ());
        cancelReq.setUserPin (CurrentUser.getSalesUser ().getUserPin ());
        cancelReq.setTicketReference (paymentResponse.getReference ());
        cancelReq.setTransactionRef (paymentResponse.getTransRef ());

        JKPutcoCancel.savePutcoCancelItem (cancelReq);

        TicketProUtilBus.getTicketProBusAutoCancel (cancelReq, new TicketProUtilBus.TicketProPutcoAutoCancelResult () {
            @Override
            public void tpBusTicketAutoCancelResult(TicketProBusAutoCancelResp tpAutoCancelResp) {
                if (tpAutoCancelResp.isSuccess ()) {
                    JKiosk3.getMsgBox ().showMsgBox ("Ticket Cancelled", "Ticket Cancelled for Reference\n\n" + paymentResponse.getReference (),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    JKPutcoCancel.removePutcoCancelItem (cancelReq.getTransactionRef ());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });

                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Ticket Not Cancelled", "", null);
                    SceneSales.clearAndShowFavourites ();
                }
            }
        });
    }
}
