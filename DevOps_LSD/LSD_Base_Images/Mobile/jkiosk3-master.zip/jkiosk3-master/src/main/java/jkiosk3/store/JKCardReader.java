package jkiosk3.store;

/**
 *
 * @author Val
 */
public class JKCardReader {

    private static StoreJKCardReader cardReaderConfig;

    public static StoreJKCardReader getCardReaderConfig() {
        if (cardReaderConfig == null) {
            cardReaderConfig = ((StoreJKCardReader) Store.loadObject(JKCardReader.class.getSimpleName()));
        }
        if (cardReaderConfig == null) {
            cardReaderConfig = new StoreJKCardReader();
        }
        return cardReaderConfig;
    }

    public static boolean saveCardReaderConfig() {
        getCardReaderConfig();
        return Store.saveObject(JKCardReader.class.getSimpleName(), cardReaderConfig);
    }
}
