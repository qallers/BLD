package jkiosk3.store;

/**
 *
 * @author Val
 */
public class JKDialup {

    private static StoreJKDialup dialupConnect;

    public static StoreJKDialup getDialupConnect() {
        if (dialupConnect == null) {
            dialupConnect = ((StoreJKDialup) Store.loadObject(JKDialup.class.getSimpleName()));
        }
        if (dialupConnect == null) {
            dialupConnect = new StoreJKDialup();
        }
        return dialupConnect;
    }

    public static boolean saveDialupConnect() {
        getDialupConnect();
        return Store.saveObject(JKDialup.class.getSimpleName(), dialupConnect);
    }
}
