package jkiosk3.store;

import java.io.Serializable;

/**
 *
 * @author Val
 */
public class StoreJKPrinter implements Serializable {

    private String printWinOth = "";
    private boolean printWin = true;
    private String printPort = "COM1";
    private String printDriver = "Star";
    private int printBaud = 9600;
    private boolean printFlowControl = false;

    public int getPrintBaud() {
        return printBaud;
    }

    public void setPrintBaud(int printBaud) {
        this.printBaud = printBaud;
    }

    public String getPrintDriver() {
        return printDriver;
    }

    public void setPrintDriver(String printDriver) {
        this.printDriver = printDriver;
    }

    public boolean isPrintFlowControl() {
        return printFlowControl;
    }

    public void setPrintFlowControl(boolean printFlowControl) {
        this.printFlowControl = printFlowControl;
    }

    public String getPrintPort() {
        return printPort;
    }

    public void setPrintPort(String printPort) {
        this.printPort = printPort;
    }

    public boolean isPrintWin() {
        return printWin;
    }

    public void setPrintWin(boolean printWin) {
        this.printWin = printWin;
    }

    public String getPrintWinOth() {
        return printWinOth;
    }

    public void setPrintWinOth(String printWinOth) {
        this.printWinOth = printWinOth;
    }
}
