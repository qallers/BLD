package jkiosk3.store;

public class JKDevLocation {

    private static StoreJKDevLocation deviceLocation;

    public static StoreJKDevLocation getDeviceLocation() {
        if (deviceLocation == null) {
            deviceLocation = ((StoreJKDevLocation) Store.loadObject(JKDevLocation.class.getSimpleName()));
        }
        if (deviceLocation == null) {
            deviceLocation = new StoreJKDevLocation();
        }
        return deviceLocation;
    }

    public static boolean saveDeviceLocation() {
        getDeviceLocation();
        return Store.saveObject(JKDevLocation.class.getSimpleName(), deviceLocation);
    }
}
