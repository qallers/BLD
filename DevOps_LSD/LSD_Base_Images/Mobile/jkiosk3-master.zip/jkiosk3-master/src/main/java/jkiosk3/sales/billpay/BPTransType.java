package jkiosk3.sales.billpay;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum BPTransType {

    BILLPAY_BLU_ACCOUNT("Payments", "BluBillPayment", "Blu Bill Payment"),
    BILLPAY_BLU_M2M("Payments", "MerchantTransfer", "MerchantTransfer"),
    BILLPAY_PAYAT_ACCOUNT("Payments", "VASPayAtAccountPayment", "Pay@ Account Payment"),
    BILLPAY_PAYAT_TRAFFIC("Payments", "VASPayAtFinePayment", "Pay@ Fine Payment"),
    BILLPAY_PAYAT_INSURANCE("Payments", "VASPayAtInsurance", "Pay@ Insurance Payment"),
    BILLPAY_SAPO_ACCOUNT("Payments", "VASSAPOAccountPayment", "SAPO Account Payment"),
    BILLPAY_SYNTELL_ACCOUNT("Payments", "VASSyntellAccountPayment", "Syntell Account Payment"),
    BILLPAY_SYNTELL_TRAFFIC("Payments", "VASSyntellFinePayment", "Syntell Traffic Fines"),

    MTN_SMS("MTN", "MTN Topup", "Blu Bill Payment"),
    CELLC_SMS("Cell C", "Cell C Topup SMS", "Blu Bill Payment"),

    AIRTIME_VOUCHER("Airtime", "Voucher", "Blu Bill Payment"),
    ELECTRICITY_VOUCHER("MTN", "MTN Topup", "Blu Bill Payment"),
    DATA_VOUCHER("MTN", "MTN Topup", "Blu Bill Payment"),
    OTHER_VOUCHER("MTN", "MTN Topup", "Blu Bill Payment"),
    CHAT4CHANGE("MTN", "MTN Topup", "Blu Bill Payment"),
    AIRTIME_TOPUP("Topup", "Airtime Topup", "Blu Bill Payment"),
    DATA_TOPUP("Topup", "Airtime Topup", "Blu Bill Payment"),
    ELECTRICITY("MTN", "MTN Topup", "Blu Bill Payment"),
    TOPUP_WALLET("Wallet", "Wallet Topup", "Blu Bill Payment"),
    ;

    private final String trxGroup;
    private final String trxType;
    private final String displayName;

    private BPTransType(String trxGroup, String trxType, String displayName) {
        this.trxGroup = trxGroup;
        this.trxType = trxType;
        this.displayName = displayName;
    }

    @Override
    public String toString() {
        return getDisplayName();
    }

    public String getTrxGroup() {
        return trxGroup;
    }

    public String getTrxType() {
        return trxType;
    }

    public String getDisplayName() {
        return displayName;
    }

    public static List<BPTransType> getListBPTransTypes() {
        List<BPTransType> listBPTransTypes = Arrays.asList(BPTransType.values());
        return listBPTransTypes;
    }

    public static List<String> getListBPTrxTypes() {
        List<String> listTrxTypes = new ArrayList<>();
        listTrxTypes.add(BILLPAY_BLU_ACCOUNT.getTrxType());
        listTrxTypes.add(BILLPAY_PAYAT_ACCOUNT.getTrxType());
        listTrxTypes.add(BILLPAY_PAYAT_TRAFFIC.getTrxType());
        listTrxTypes.add(BILLPAY_PAYAT_INSURANCE.getTrxType());
        listTrxTypes.add(BILLPAY_SAPO_ACCOUNT.getTrxType());
        listTrxTypes.add(BILLPAY_SYNTELL_ACCOUNT.getTrxType());
        listTrxTypes.add(BILLPAY_SYNTELL_TRAFFIC.getTrxType());

        return listTrxTypes;
    }
}
