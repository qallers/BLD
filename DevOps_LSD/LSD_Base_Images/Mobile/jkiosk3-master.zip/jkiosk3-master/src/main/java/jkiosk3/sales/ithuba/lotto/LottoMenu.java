package jkiosk3.sales.ithuba.lotto;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.SceneSales;
import jkiosk3.users.SalesUserLoginResult;

/**
 *
 * @author valeriew
 */
public class LottoMenu extends Region {

    private static final String QP_LOTTO = "QP Lotto";
    private static final String QP_POWERBALL = "QP PowerBall";
    private static final String PLAYER_LOTTO = "Player Selection";
    private static final String PLAYER_POWERBALL = "Player Selection";
    private final static int btnId = 1;

    public LottoMenu() {
        getChildren().add(getMenuGroup());
    }

    private VBox getMenuGroup() {

        VBox vbHead = JKNode.getPageHeadVB("Ithuba National Lottery");

        ImageView imgLotto = JKNode.getJKImageViewProvider("prov_IthubaLotto.png");
        HBox hbLotto = JKLayout.getHBoxLeft(0, 0);
        hbLotto.getChildren().add(imgLotto);

        TilePane tileLotto = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getLottoButtons());

        ImageView imgPowerBall = JKNode.getJKImageViewProvider("prov_IthubaPowerBall.png");
        HBox hbPowerBall = JKLayout.getHBoxLeft(0, 0);
        hbPowerBall.getChildren().add(imgPowerBall);

        TilePane tilePowerBall = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getPowerBallButtons());

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, hbLotto, tileLotto, JKNode.createContentSep(), hbPowerBall, tilePowerBall);

        return vb;
    }

    private List<Button> getLottoButtons() {
        List<Button> btnList = new ArrayList<>();

        String[] btnLabels = {QP_LOTTO, PLAYER_LOTTO};

        for (String s : btnLabels) {
            String btnText = "";
            if (s.startsWith("QP")) {
                btnText = "Quick Pick";
            } else {
                btnText = "Choose Numbers";
            }
//            final Button btn = JKNode.getBtnVAS(s, "prov_Ithuba.png", 52, JKLayout.sp / 2, "prov_VAS");
//            final Button btn = JKNode.getBtnVAS(btnText, "prov_Ithuba.png", 52, JKLayout.sp / 2, "prov_VAS");
//            final Button btn = JKNode.getBtnVAS(btnText, "prov_Ithuba.png", 52, JKLayout.sp / 2, "prov_ithuba_lotto");
            final Button btn = JKNode.getBtnIthuba(btnText, "prov_Ithuba.png", 54, "prov_ithuba_lotto");
            btn.setId(s);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }
        return btnList;
    }

    private List<Button> getPowerBallButtons() {
        List<Button> btnList = new ArrayList<>();

        String[] btnLabels = {QP_POWERBALL, PLAYER_POWERBALL};

        for (String s : btnLabels) {
            String btnText = "";
            if (s.startsWith("QP")) {
                btnText = "Quick Pick";
            } else {
                btnText = "Choose Numbers";
            }
//            final Button btn = JKNode.getBtnVAS(s, "prov_Ithuba.png", 52, JKLayout.sp / 2, "prov_VAS");
//            final Button btn = JKNode.getBtnVAS(btnText, "prov_Ithuba.png", 52, JKLayout.sp / 2, "prov_VAS");
            final Button btn = JKNode.getBtnIthuba(btnText, "prov_Ithuba.png", 54, "prov_ithuba_powerball");

            if (s.equals(QP_POWERBALL)) {
                btn.setId(s);
            } else if (!s.equals(QP_POWERBALL) && PLAYER_POWERBALL.equals(PLAYER_LOTTO)) {
                btn.setId(s += String.valueOf(btnId));
            }

            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);

        }
        return btnList;
    }

    private void getMenuAction(final Button b) {

//        JKiosk3.getSalesUserLogin().showUserLogin(new PasswordField(), new SalesUserLoginResult() {
        JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
            @Override
            public void onDone() {
                switch (b.getId()) {
                    case QP_LOTTO:
                        SceneSales.clearAndChangeContent(new QuickPickLotto());
                        break;
                    case QP_POWERBALL:
                        SceneSales.clearAndChangeContent(new QuickPickPowerBall());
                        break;
                    case PLAYER_LOTTO:
                        SceneSales.clearAndChangeContent(new PlayerLotto());
                        break;
                    case PLAYER_POWERBALL + "1":
                        SceneSales.clearAndChangeContent(new PlayerPowerBall());
                        break;
                    default:
                        JKiosk3.getMsgBox().showMsgBox("Error", "Invalid selection", null);
                }
            }
        });
    }

}
