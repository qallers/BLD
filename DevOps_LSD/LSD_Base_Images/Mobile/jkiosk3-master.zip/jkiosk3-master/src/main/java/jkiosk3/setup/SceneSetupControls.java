package jkiosk3.setup;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

/**
 *
 * @author Val
 */
public abstract class SceneSetupControls extends Region {

    private final String btnTestLabel;
    private final boolean isShowTest;
    private static Button btnTest;

    public SceneSetupControls(String testBtnText, boolean showTestBtn) {
        this.btnTestLabel = testBtnText;
        this.isShowTest = showTestBtn;
        HBox group = getCtrlButtons();
        getChildren().add(group);
    }

    public abstract void onClickTest();

    public abstract void onClickSave();

    private HBox getCtrlButtons() {

        btnTest = JKNode.getBtnSm("Test");
        btnTest.setText(btnTestLabel);
        btnTest.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickTest();
            }
        });
        btnTest.setVisible(isShowTest);

        Button btnSave = JKNode.getBtnSm("Save");
        btnSave.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickSave();
            }
        });

        Button btnCancel = JKNode.getBtnSm("Cancel");
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneSetup.getVbSetupContent().getChildren().clear();
            }
        });

        HBox hb = JKLayout.getControlsHBox();

        hb.getChildren().addAll(btnTest, JKNode.getHSpacer(), btnSave, btnCancel);

        return hb;
    }
    
    public static Button getBtnTest() {
        return btnTest;
    }
}
