package jkiosk3.branding;

import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Valerie
 */
public class MerchantGroups {

    //public final static String FILENAME_MERCHANT_GROUPS = "MerchantGroupBranding.xml";

    private static List<MerchantGroup> listMerchantGroups;

    public static List<MerchantGroup> makeListMerchantGroups() {
        listMerchantGroups = new ArrayList<>();

        Element root;
        SAXBuilder builder = new SAXBuilder();
        File file = new File(JK3Config.getMediaBrandingGroups());
        try {
            root = builder.build(file).getRootElement();
            for (Object group : root.getChildren("merchantGroup")) {
                Element grp = (Element) group;

                MerchantGroup merchGrp = new MerchantGroup();
                merchGrp.setCode(grp.getChildTextTrim("code"));
                merchGrp.setName(grp.getChildTextTrim("name"));
                merchGrp.setPrimaryColourHex(grp.getChildTextTrim("primaryColourHex"));
                merchGrp.setSecondaryColourHex(grp.getChildTextTrim("secondaryColourHex"));

                listMerchantGroups.add(merchGrp);
            }
        } catch (JDOMException | IOException e) {
            JKiosk3.getMsgBox().showMsgBox("Merchant Groups", e.getMessage(), null);
        }

        return listMerchantGroups;
    }
}
