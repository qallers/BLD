package jkiosk3.sales.rica;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.SceneSales;

/**
 *
 * @author Val
 */
public class RICAMenu extends Region {

    public RICAMenu() {
        getChildren().add(getMenuGroup());
    }

    private TilePane getMenuGroup() {

        String[] btnLabels = {"Query", "Subscriber"};

        List<Button> btnList = new ArrayList<>();

        for (final String s : btnLabels) {
            final Button btn = JKNode.getBtnSmDbl(s);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        TilePane tile = JKLayout.getTileContent(JKLayout.sp, JKLayout.sp, 2);
        tile.getChildren().addAll(btnList);

        return tile;
    }

    private void getMenuAction(Button b) {
        switch (b.getText()) {
            case "Query":
                SceneSales.clearAndChangeContent(new RICAQuery());
                break;
            case "Subscriber":
                SceneSales.clearAndChangeContent(new SubscriberMenu());
        }
    }
}
