package jkiosk3.sales.ticketpro;

import aeonticketpros.TicketProsCart;
import aeonticketpros.TicketProsCheckoutResp;
import aeonticketpros.bus.TicketProBusRouteBookResp;
import aeonticketpros.bus.TicketProBusRouteCode;
import aeonticketpros.bus.TicketProBusRouteListResp;
import aeonticketpros.bus.TicketProBusSeat;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author valeriew
 */
public class TicketProBusSale {

    private TicketProBusRouteListResp listRoutes;
    private TicketProBusRouteCode selectedRouteCode;
    private TicketProBusRouteBookResp ticketProBusRouteBooking;
    private TicketProsCart busSaleCart;
    private List<TicketProBusSeat> selectedBusSeats;
    private TicketProsCheckoutResp checkoutResponse;
    private String customerName;
    private String customerSurname;
    private String customerMobilePhone;
    private final List<String> listRouteSoldOut = new ArrayList<>();
    //
    private static TicketProBusSale instance;

    public static TicketProBusSale getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    private static TicketProBusSale newInstance() {
        instance = new TicketProBusSale();
        return instance;
    }

    public static void resetTicketProBusSale() {
        instance = null;
    }

    public TicketProBusRouteListResp getListRoutes() {
        return listRoutes;
    }

    public void setListRoutes(TicketProBusRouteListResp listRoutes) {
        this.listRoutes = listRoutes;
    }

    public TicketProBusRouteCode getSelectedRouteCode() {
        return selectedRouteCode;
    }

    public void setSelectedRouteCode(TicketProBusRouteCode selectedRouteCode) {
        this.selectedRouteCode = selectedRouteCode;
    }
    
    public TicketProBusRouteBookResp getTicketProBusRouteBooking() {
        return ticketProBusRouteBooking;
    }

    public void setTicketProBusRouteBooking(TicketProBusRouteBookResp ticketProBusRouteBooking) {
        this.ticketProBusRouteBooking = ticketProBusRouteBooking;
    }

    public TicketProsCart getBusSaleCart() {
        return busSaleCart;
    }

    public void setBusSaleCart(TicketProsCart busSaleCart) {
        this.busSaleCart = busSaleCart;
    }

    public TicketProsCheckoutResp getCheckoutResponse() {
        return checkoutResponse;
    }

    public void setCheckoutResponse(TicketProsCheckoutResp checkoutResponse) {
        this.checkoutResponse = checkoutResponse;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerSurname() {
        return customerSurname;
    }

    public void setCustomerSurname(String customerSurname) {
        this.customerSurname = customerSurname;
    }

    public String getCustomerMobilePhone() {
        return customerMobilePhone;
    }

    public void setCustomerMobilePhone(String customerMobilePhone) {
        this.customerMobilePhone = customerMobilePhone;
    }
    
    public List<TicketProBusSeat> getSelectedBusSeats() {
        return selectedBusSeats;
    }

    public void setSelectedBusSeats(List<TicketProBusSeat> selectedBusSeats) {
        this.selectedBusSeats = selectedBusSeats;
    }

    public List<String> getListRouteSoldOut() {
        return listRouteSoldOut;
    }
}
