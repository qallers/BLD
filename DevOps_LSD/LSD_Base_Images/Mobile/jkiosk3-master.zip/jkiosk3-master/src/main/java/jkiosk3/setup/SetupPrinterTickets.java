package jkiosk3.setup;

import gnu.io.CommPortIdentifier;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.UnsupportedCommOperationException;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.PrintUtil;
import jkiosk3.printing.print_layouts.PrintAssorted;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.store.JKPrinterTickets;
import jkiosk3.utilities.DownloadUtil;

public class SetupPrinterTickets extends Region {

    private final static Logger logger = Logger.getLogger(SetupPrinterTickets.class.getName());
    double w = JKLayout.contentW;
    private RadioButton radDef;
    private RadioButton radSec;
    private RadioButton radComm;
    private ComboBox cbName;
    private ComboBox cbPort;
    private ComboBox cbBaudCurrent;
    private ComboBox cbBaudRequired;
    private GridPane gridEnable;
    private GridPane gridComm;

    public SetupPrinterTickets() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getTicketPrinterEntry());
        vb.getChildren().add(getControls());

        setPrintEnableView();
        setPrinterTypeView();

        getChildren().add(vb);
    }

    private GridPane getTicketPrinterEntry() {

        VBox vbHead = JKNode.getPageHeadVB("Ticket Printing");

        Label lblPrinter = JKText.getLblDk("Use Printer", JKText.FONT_B_XSM);

        ToggleGroup togglePrinter = new ToggleGroup();

        radDef = new RadioButton("Default Printer");
        radDef.setToggleGroup(togglePrinter);
        radDef.setSelected(true);
        radDef.setSelected(JKPrinterTickets.getPrinterTickets().isUseDefaultPrinter());
        radDef.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                setPrintEnableView();
                setPrinterTypeView();
            }
        });

        radSec = new RadioButton("Ticket Printer");
        radSec.setToggleGroup(togglePrinter);
        radSec.setSelected(!(JKPrinterTickets.getPrinterTickets().isUseDefaultPrinter()));
        radSec.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                setPrintEnableView();
                setPrinterTypeView();
            }
        });

        HBox hbSelectPrinter = JKLayout.getHBox(0, JKLayout.sp);
        hbSelectPrinter.getChildren().addAll(radDef, JKNode.getHSpacer(), radSec, JKNode.getHSpacer());

        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75, HPos.LEFT);

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblPrinter, hbSelectPrinter);
        grid.add(JKNode.createGridSpanSep(2), 0, 2);
        grid.add(getGridEnablePrint(), 0, 3);

        return grid;
    }

    private GridPane getGridEnablePrint() {

        Label lblConnectBy = JKText.getLblDk("Connect By", JKText.FONT_B_XSM);

        ToggleGroup toggle = new ToggleGroup();

        radComm = new RadioButton("COM Port");
        radComm.setToggleGroup(toggle);
        radComm.setSelected(JKPrinterTickets.getPrinterTickets().isUseSerialPrinter());
        radComm.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                setPrinterTypeView();
            }
        });

        Label lblName = JKText.getLblDk("Name", JKText.FONT_B_XSM);

        cbName = new ComboBox();
        cbName.setPrefSize(((w - (2 * JKLayout.sp)) * 0.75), 35);
        cbName.getSelectionModel().select(JKPrinterTickets.getPrinterTickets().getPrinterName());
        cbName.getItems().addAll("Inani iDT2");

        gridEnable = JKLayout.getContentGridInner2Col(0.25, 0.75);

        gridEnable.addRow(0, lblConnectBy, radComm);
        gridEnable.addRow(1, lblName, cbName);
        gridEnable.add(JKNode.createGridSpanSep(2), 0, 2);
        gridEnable.add(getGridCommConnection(), 0, 3);

        return gridEnable;
    }

    private GridPane getGridCommConnection() {

        Label lblPort = JKText.getLblDk("Port", JKText.FONT_B_XSM);
        Label lblBaud = JKText.getLblDk("Baud Rate", JKText.FONT_B_SM);
        Label lblBaudCurrent = JKText.getLblDk("Current", JKText.FONT_B_XSM);
        lblBaudCurrent.setTranslateX(JKLayout.sp);
        Label lblBaudRequired = JKText.getLblDk("Required", JKText.FONT_B_XSM);
        lblBaudRequired.setTranslateX(JKLayout.sp);

        cbPort = new ComboBox();
        cbPort.setPrefSize(((w - (2 * JKLayout.sp)) * 0.75), 35);
        cbPort.getSelectionModel().select(JKPrinterTickets.getPrinterTickets().getSerialPrinterPort());
        cbPort.getItems().addAll("COM1", "COM2", "COM3", "COM4", "COM5", "COM6");

        String[] baudrates = {"4800", "9600", "19200", "38400", "57600", "115200"};
        List<String> listBaud = Arrays.asList(baudrates);

        cbBaudCurrent = new ComboBox();
        cbBaudCurrent.setPrefSize(((w - (2 * JKLayout.sp)) * 0.75), 35);
        cbBaudCurrent.getItems().addAll(listBaud);
        cbBaudCurrent.getSelectionModel().select(Integer.toString(JKPrinterTickets.getPrinterTickets().getSerialPrinterBaud()));

        cbBaudRequired = new ComboBox();
        cbBaudRequired.setPrefSize(((w - (2 * JKLayout.sp)) * 0.75), 35);
        cbBaudRequired.getItems().addAll(listBaud);
        cbBaudRequired.getSelectionModel().select(Integer.toString(JKPrinterTickets.getPrinterTickets().getSerialPrinterBaud()));

        gridComm = JKLayout.getContentGridInner2Col(0.25, 0.75);
        gridComm.setDisable(true);

        gridComm.addRow(0, lblPort, cbPort);
        gridComm.addRow(2, lblBaud);
        gridComm.addRow(3, lblBaudCurrent, cbBaudCurrent);
        gridComm.addRow(4, lblBaudRequired, cbBaudRequired);
        return gridComm;
    }

    private void setPrintEnableView() {
        if (radDef.isSelected()) {
            gridEnable.setDisable(true);
        } else if (radSec.isSelected()) {
            gridEnable.setDisable(false);
            setPrinterTypeView();
        }
    }

    private void setPrinterTypeView() {
        if (radComm.isSelected()) {
            gridComm.setDisable(false);
        } else {
            gridComm.setDisable(true);
        }
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("Test Print", true) {
            @Override
            public void onClickTest() {
                if (radDef.isSelected()) {
                    if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
                        JKiosk3.getPrintPreview().showPrintPreview("Test Print", PrintAssorted.getTestPrint(),
                                PrintPreview.PRN_OK, new PrintPreviewResult() {
                                    @Override
                                    public void onOk() {
                                        //
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    } else {
                        PrintUtil.sendToPrinter(PrintAssorted.getTestPrint());
                    }
                } else if (radSec.isSelected()) {

                    testPrintToPrinterPort();
                }
            }

            @Override
            public void onClickSave() {
                saveTicketPrinter();
            }
        };
    }

    private void saveTicketPrinter() {
        if (radDef.isSelected()) {
            JKPrinterTickets.getPrinterTickets().setUseDefaultPrinter(true);
        } else if (radSec.isSelected()) {
            JKPrinterTickets.getPrinterTickets().setUseDefaultPrinter(false);
            JKPrinterTickets.getPrinterTickets().setUseSerialPrinter(true);
            if (cbName.getSelectionModel().getSelectedItem() == null
                    || cbPort.getSelectionModel().getSelectedItem() == null
                    || cbBaudRequired.getSelectionModel().getSelectedItem() == null) {
                JKiosk3.getMsgBox().showMsgBox("Name, Port or Baud Rate",
                        "Name, Port or Baud Rate cannot be empty", null);
            } else {
                JKPrinterTickets.getPrinterTickets().setPrinterName(cbName.getSelectionModel().getSelectedItem().toString());
                JKPrinterTickets.getPrinterTickets().setSerialPrinterPort(cbPort.getSelectionModel().getSelectedItem().toString());
                JKPrinterTickets.getPrinterTickets().setSerialPrinterBaud(Integer.parseInt(cbBaudRequired.getSelectionModel().getSelectedItem().toString()));
            }
        }
        if (JKPrinterTickets.savePrinterTickets()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Ticket Printer settings saved successfully", null,
                    MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                        @Override
                        public void onOk() {
                            // Open COM port, send command for required Baud rate, then instruct User to restart printer
                            if (JKPrinterTickets.getPrinterTickets().isUseSerialPrinter()) {
                                if (!cbBaudRequired.getSelectionModel().getSelectedItem().toString()
                                        .equals(cbBaudCurrent.getSelectionModel().getSelectedItem().toString())) {
                                    JKiosk3.getMsgBox().showMsgBox("Printer Setup Changed", "Please make sure that the printer is switched"
                                                    + "\n\n"
                                                    + "ON"
                                                    + "\n\n before continuing", null,
                                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                                @Override
                                                public void onOk() {
                                                    resetPrinterBaudRate();
                                                }

                                                @Override
                                                public void onCancel() {
                                                    //
                                                }
                                            });
                                }
                            }
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Ticket Printer settings not saved", null);
        }
    }

    private void resetPrinterBaudRate() {
        int currentBaud = Integer.parseInt(cbBaudCurrent.getSelectionModel().getSelectedItem().toString());

        String ticketPrinterPort = JKPrinterTickets.getPrinterTickets().getSerialPrinterPort();
        String ticketPrinterBaud = Integer.toString(JKPrinterTickets.getPrinterTickets().getSerialPrinterBaud());

        System.out.println("SAVED VALUES : ticketPrinterPort : " + ticketPrinterPort + " ::: ticketPrinterBaud : " + ticketPrinterBaud);

        Enumeration portList = CommPortIdentifier.getPortIdentifiers();
        CommPortIdentifier portId = null;
        while (portList.hasMoreElements()) {
            final CommPortIdentifier pid = (CommPortIdentifier) portList.nextElement();
            if (pid.getPortType() == CommPortIdentifier.PORT_SERIAL
                    && pid.getName().equals(ticketPrinterPort)) {
                portId = pid;
                break;
            }
        }
        if (portId != null) {
            try {
                // open the serial port
                final SerialPort port = (SerialPort) portId.open("PortListOpen", 10000);
                port.setSerialPortParams(currentBaud, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);

                String serialPortSet = "";
                switch (ticketPrinterBaud) {
                    case "4800":
                        serialPortSet = "^Y48,N,8,1\n";
                        break;
                    case "9600":
                        serialPortSet = "^Y96,N,8,1\n";
                        break;
                    case "19200":
                        serialPortSet = "^Y19,N,8,1\n";
                        break;
                    case "38400":
                        serialPortSet = "^Y38,N,8,1\n";
                        break;
                    case "57600":
                        serialPortSet = "^Y57,N,8,1\n";
                        break;
                    case "115200":
                        serialPortSet = "^Y11,N,8,1\n";
                        break;
                    default:
                        serialPortSet = "^Y96,N,8,1\n";
                        break;
                }

                try (OutputStream printerOutput = port.getOutputStream()) {
                    /* This command should reset the printer before changing any values */
//                    printerOutput.write("\n".getBytes());
//                    printerOutput.write("^Z\n".getBytes());
                    printerOutput.write("\n".getBytes(Charset.defaultCharset()));
                    /* This command sets the Printer Baud rate to the User's choice */
                    printerOutput.write(serialPortSet.getBytes(Charset.defaultCharset()));
                    printerOutput.write(serialPortSet.getBytes(Charset.defaultCharset()));

                    logger.info("END OF PRINTER RESET");
                    JKiosk3.getMsgBox().showMsgBox("Printer Reset", "\nPlease print a Test Print"
                                    + "\n\nto ensure that changes are successful", null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    SceneSetup.getVbSetupContent().getChildren().remove(1);
                                    SceneSetup.getVbSetupContent().getChildren().add(1, new SetupPrinterTickets());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } catch (IOException e) {
                    logger.log(Level.SEVERE, e.getMessage(), e);
                } finally {
                    port.close();
                }
            } catch (PortInUseException | UnsupportedCommOperationException ex) {
                logger.log(Level.SEVERE, ex.getMessage(), ex);
            }
        }
    }

    private static void testPrintToPrinterPort() {
        String branchPath = "C:\\_projects\\BLT\\SouthAfrica\\Roodepoort\\AEON\\Clients\\Applications\\JKiosk3\\trunk\\";
        // get test file from server, to ensure that we can download as well as print
        final File testFile = DownloadUtil.downloadRemoteFile(JK3Config.getTicketProPrintTest(), JK3Config.getTicketPrint());
//        final File testFile = new File(branchPath + "media\\printFiles\\test-1.ezpl");
//
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                if (testFile != null) {
                    System.out.println("test file for ticketpro : " + testFile.getAbsolutePath());
                    JKiosk3.getMsgBox().showMsgBox("Test Printer", "Press OK to continue", null, MessageBox.CONTROLS_SHOW,
                            MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    PrintHandler.writeFileContentToPrinterPort(testFile, new ResultCallback() {
                                        @Override
                                        public void onResult(boolean result) {
                                            if (result) {
                                                System.out.println("PRINTER ALL OK!");
                                            } else {
                                                System.out.println("OOPS, SOMETHING WRONG!");
                                            }
                                        }
                                    });
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Test Printer",
                            "Unable to retrieve Test Print file\n\nCheck connection", null);
                }
            }
        });
    }
}
