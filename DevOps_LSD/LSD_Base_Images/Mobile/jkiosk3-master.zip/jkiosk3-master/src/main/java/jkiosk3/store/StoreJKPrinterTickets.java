package jkiosk3.store;

import java.io.Serializable;

/**
 *
 * @author valerie
 */
public class StoreJKPrinterTickets implements Serializable {

    private boolean useDefaultPrinter = true;
    private boolean useSerialPrinter = true;
    private String printerName = "Inani iDT2";
    private String serialPrinterPort = "COM2";
    private int serialPrinterBaud = 9600;

    public boolean isUseDefaultPrinter() {
        return useDefaultPrinter;
    }

    public void setUseDefaultPrinter(boolean useDefaultPrinter) {
        this.useDefaultPrinter = useDefaultPrinter;
    }

    public boolean isUseSerialPrinter() {
        return useSerialPrinter;
    }

    public void setUseSerialPrinter(boolean useSerialPrinter) {
        this.useSerialPrinter = useSerialPrinter;
    }

    public String getPrinterName() {
        return printerName;
    }

    public void setPrinterName(String printerName) {
        this.printerName = printerName;
    }

    public String getSerialPrinterPort() {
        return serialPrinterPort;
    }

    public void setSerialPrinterPort(String serialPrinterPort) {
        this.serialPrinterPort = serialPrinterPort;
    }

    public int getSerialPrinterBaud() {
        return serialPrinterBaud;
    }

    public void setSerialPrinterBaud(int serialPrinterBaud) {
        this.serialPrinterBaud = serialPrinterBaud;
    }
}
