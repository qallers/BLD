package jkiosk3.store.cache;

import aeonusers.UserTransactionType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author valeriew
 */
public class ListTransTypes implements Serializable {
    
    // L(ist)  = 12 (1 + 2 = 3)
    // T(rans) = 20 (2 + 0 = 2)
    // T(ypes) = 20 (2 + 0 = 2)
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 999322L;
    private final List<UserTransactionType> listTransTypes = new ArrayList<>();

    public List<UserTransactionType> getListTransTypes() {
        return listTransTypes;
    }    
}
