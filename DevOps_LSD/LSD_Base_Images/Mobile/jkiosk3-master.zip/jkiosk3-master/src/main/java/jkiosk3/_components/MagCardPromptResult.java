package jkiosk3._components;

/**
 *
 * @author Val
 */
public abstract class MagCardPromptResult {
    
    public abstract void onDone();
}
