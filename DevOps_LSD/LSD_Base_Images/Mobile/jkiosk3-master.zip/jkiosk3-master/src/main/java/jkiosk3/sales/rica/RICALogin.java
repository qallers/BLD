package jkiosk3.sales.rica;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.rica.RICAUtil.LoggedInResult;
import jkiosk3.users.CurrentUser;

/**
 *
 * @author Val
 */
public class RICALogin extends Region {

    private TextField txtAgentName;
    private PasswordField pwdAgentPwd;
    private String agentCode;
    private String agentPwd;
    private String userPin;

    public RICALogin() {
        getChildren().add(getRICALogin());
    }

    private VBox getRICALogin() {

        double w = JKLayout.contentW;

        ImageView imgRica = JKNode.getJKImageViewProvider("prov_rica_173x150.png");

        Button btnRicaLogin = JKNode.getBtnSm("Login");
        btnRicaLogin.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickLoginButton();
            }
        });

        VBox vb = JKLayout.getVBoxContent(2 * JKLayout.sp);
        vb.setStyle("-fx-padding: 30px 15px 30px 15px;");
        vb.setMaxWidth(w);
        vb.setMinWidth(w);

        vb.getChildren().addAll(imgRica, getLoginGrid(), btnRicaLogin);

        return vb;
    }

    private GridPane getLoginGrid() {
        GridPane grid = new GridPane();

        grid.setHgap(JKLayout.sp);
        grid.setVgap(JKLayout.sp);

        double gridW = 495;

        grid.setMaxWidth(gridW);
        grid.setMinWidth(gridW);

        ColumnConstraints col0 = new ColumnConstraints();
        col0.setPrefWidth(gridW * 0.5);
        col0.setFillWidth(true);
        col0.setHalignment(HPos.RIGHT);
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPrefWidth(gridW * 0.5);
        col1.setFillWidth(true);
        col1.setHalignment(HPos.LEFT);

        grid.getColumnConstraints().addAll(col0, col1);

        Label lblAgentName = JKText.getLblDk("RICA Agent Username", JKText.FONT_B_XSM);
        Label lblAgentPwd = JKText.getLblDk("Password", JKText.FONT_B_XSM);

        txtAgentName = new TextField();
        txtAgentName.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtAgentName, "RICA Agent Username", "", false);
            }
        });

        pwdAgentPwd = new PasswordField();
        pwdAgentPwd.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(pwdAgentPwd, "RICA Agent Password", "", false);
            }
        });

        grid.add(lblAgentName, 0, 0);
        grid.add(lblAgentPwd, 0, 1);

        grid.add(txtAgentName, 1, 0);
        grid.add(pwdAgentPwd, 1, 1);

        return grid;
    }

    private void onClickLoginButton() {
        userPin = CurrentUser.getUser().getUserPin();
        agentCode = txtAgentName.getText();
        agentPwd = pwdAgentPwd.getText();
        RICAUtil.setUserPin(userPin);
        RICAUtil.setAgentCode(agentCode);
        RICAUtil.setAgentPwd(agentPwd);
        agentLogin();
    }

    private void agentLogin() {
        RICAUtil.isAgentLoggedIn(userPin, agentCode, agentPwd, new LoggedInResult() {
            @Override
            public void isLoggedInResult(boolean isLoggedIn) {
                if (isLoggedIn) {
                    SceneSales.clearAndChangeContent(new RICAMenu());
                } else {
                    JKiosk3.getMsgBox().showMsgBox("RICA Login Failed", "Invalid Agent Code or Password", null);
                }
            }
        });
    }
}
