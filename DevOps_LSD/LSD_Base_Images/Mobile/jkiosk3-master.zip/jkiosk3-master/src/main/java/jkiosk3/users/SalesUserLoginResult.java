package jkiosk3.users;

/**
 *
 * @author Val
 */
public abstract class SalesUserLoginResult {
    
    public abstract void onDone();    
}
