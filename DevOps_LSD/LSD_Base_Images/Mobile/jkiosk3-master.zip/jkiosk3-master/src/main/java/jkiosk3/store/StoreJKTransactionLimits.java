package jkiosk3.store;

import java.io.Serializable;

/**
 *
 * @author valeriew
 */
public class StoreJKTransactionLimits implements Serializable {
    
    // S(tore) = 19 : (1 + 9 = 10) (1 + 0 = 1)
    // J(K)  = 10 : (1 + 0 = 1)
    // T(ransaction) = 20 : (2 + 0 = 2)
    // L(imits) = 13 : (1 + 3 = 4)
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 991124L;
    //
    private double transLimitBillPay = 9999.00D;

    public double getTransLimitBillPay() {
        return transLimitBillPay;
    }

    public void setTransLimitBillPay(double transLimitBillPay) {
        this.transLimitBillPay = transLimitBillPay;
    }
}
