package jkiosk3.sales.coaches;

import aeoncoach.CoachCarrier;
import aeoncoach.CoachListItem;
import aeoncoach.CoachRoute;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.TicketingMenu;
import jkiosk3.sales._bus_carriers.CoachCarrierLayouts;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.users.UserUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CoachBook2a extends Region {

    private final static Logger logger = Logger.getLogger(CoachBook2a.class.getName());

    private CoachListItem locationFrom;
    private CoachListItem locationTo;
    private CoachRoute routeSelectedDepart;
    private CoachRoute routeSelectedReturn;
    private final String departOrReturn;
    private final StackPane stack;
    private List<Node> listGrids;
    private GridPane gridCost;
    private String tripDepartId;
    private String tripReturnId;

    public CoachBook2a(String departOrReturn) {
        this.departOrReturn = departOrReturn;

        tripDepartId = null;
        tripReturnId = null;

        stack = CoachCarrierLayouts.getStackCoachCarriers();

        initialiseItems();

        createPagedCarriers();

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(showCoachTicketBookStep2a(), getNav());
        getChildren().add(vb);
    }

    private void initialiseItems() {

        listGrids = new ArrayList<>();

        CoachCarrier coachCarrier = null;

        switch (departOrReturn) {
            case CoachUtil.TRIP_DEPART:
                locationFrom = CoachTicketSale.getInstance().getDepartureLoc();
                locationTo = CoachTicketSale.getInstance().getDestinationLoc();
                List<CoachRoute> listRoutes = CoachTicketSale.getInstance().getCoachAvailabilityResp().getRoutes();
                //
                // if return trip is selected, check for return carriers before showing view
                // only carriers who have return trips should be shown
                //
                if (CoachTicketSale.getInstance().isReturnTrip()) {
                    List<CoachRoute> listRoutesDepart = new ArrayList<>();
                    List<CoachRoute> listReturnAvailable = CoachTicketSale.getInstance().getCoachAvailabilityResp().getReturnRoutes();
                    List<String> listReturnCarriers = new ArrayList<>();
                    for (CoachRoute r : listReturnAvailable) {
                        listReturnCarriers.add(r.getCarrier());
                    }
                    if (!listReturnCarriers.isEmpty()) {
                        for (CoachRoute cr : listRoutes) {
                            if (listReturnCarriers.contains(cr.getCarrier())) {
                                // add to list of routes to show
                                listRoutesDepart.add(cr);
                            }
                        }
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("No Routes Available", "No Return Routes found for selected criteria." +
                                        "\n\nPlease select different Departure or Return dates, " +
                                        "\n\nor 'One Way' (non-Return) trip.", null,
                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                    @Override
                                    public void onOk() {
                                        SceneSales.clearAndChangeContent(new CoachBook1());
                                    }

                                    @Override
                                    public void onCancel() {
                                    }
                                });
                    }
                    for (CoachRoute c : listRoutesDepart) {
                        for (CoachCarrier cc : CoachTicketSale.getInstance().getListCarriers()) {
                            if (cc.getCarrierCode().equalsIgnoreCase(c.getCarrier())) {
                                coachCarrier = cc;
                                break;
                            }
                        }
                        listGrids.add(getGridRouteSingleClass(coachCarrier, c));
                    }

                } else {
                    for (CoachRoute c : listRoutes) {
                        for (CoachCarrier cc : CoachTicketSale.getInstance().getListCarriers()) {
                            if (cc.getCarrierCode().equalsIgnoreCase(c.getCarrier())) {
                                coachCarrier = cc;
                                break;
                            }
                        }
                        listGrids.add(getGridRouteSingleClass(coachCarrier, c));
                    }
                }
                break;
            case CoachUtil.TRIP_RETURN:
                CoachCarrier carrierDepart = CoachTicketSale.getInstance().getCoachCarrierDepart();
                locationFrom = CoachTicketSale.getInstance().getDestinationLoc();
                locationTo = CoachTicketSale.getInstance().getDepartureLoc();
                List<CoachRoute> listReturnAvailable = CoachTicketSale.getInstance().getCoachAvailabilityResp().getReturnRoutes();
                List<CoachRoute> listReturnRoutes = new ArrayList<>();
                for (CoachRoute r : listReturnAvailable) {
                    if (r.getCarrier().equals(carrierDepart.getCarrierCode())) {
                        listReturnRoutes.add(r);
                    }
                }
                if (!listReturnRoutes.isEmpty()) {
                    for (CoachRoute c : listReturnRoutes) {
                        for (CoachCarrier cc : CoachTicketSale.getInstance().getListCarriers()) {
                            if (cc.getCarrierCode().equalsIgnoreCase(c.getCarrier())) {
                                coachCarrier = cc;
                                break;
                            }
                        }
                        listGrids.add(getGridRouteSingleClass(coachCarrier, c));
                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Return Routes", "No Return Routes found for selected criteria",
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                @Override
                                public void onOk() {
                                    SceneSales.clearAndChangeContent(new CoachBook2a(CoachUtil.TRIP_DEPART));
                                }

                                @Override
                                public void onCancel() {
                                }
                            });
                }

                break;
            default:
                break;
        }
    }

    private VBox showCoachTicketBookStep2a() {

        Label lblHead1 = JKText.getLblDk(CoachUtil.COACH_PG_HEAD, JKText.FONT_B_24);
        Label lblHead2 = JKText.getLblDk("Select " + departOrReturn.toUpperCase(Locale.ENGLISH) + " Trip", JKText.FONT_B_22);

        VBox vbHead = JKNode.getPageDblHeadVB(0, lblHead1, lblHead2);

        GridPane gridTrip = CoachCarrierLayouts.getGridTripsRequested(locationFrom, locationTo,
                CoachTicketSale.getInstance().getDateDepart(), CoachTicketSale.getInstance().getDateReturn());

        VBox vb = CoachCarrierLayouts.getVBoxCoach();

        vb.getChildren().addAll(vbHead, gridTrip, JKNode.createContentSep());
        vb.getChildren().add(stack);

        return vb;
    }

    private void createPagedCarriers() {
        int numPgs = 0;
        if (listGrids.isEmpty()) {
            numPgs = 1;
        } else if ((listGrids.size() % CoachCarrierLayouts.pageSize) == 0) {
            numPgs = listGrids.size() / CoachCarrierLayouts.pageSize;
        } else {
            numPgs = (listGrids.size() / CoachCarrierLayouts.pageSize) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedVBox(pg, listGrids, CoachCarrierLayouts.pageSize, CoachCarrierLayouts.pageHt);
            }
        });
        stack.getChildren().clear();
        stack.getChildren().add(pages);
    }

    private GridPane getGridRouteSingleClass(CoachCarrier coachCarrier, CoachRoute route) {

        StackPane stackImg = CoachCarrierLayouts.getStackCoachCarrierImage(coachCarrier, JKLayout.btnSmW, JKLayout.btnSmH);

        String carrierName = coachCarrier.getCarrierDescription();
        if (carrierName == null || carrierName.equals("")) {
            carrierName = coachCarrier.getCarrierName();
        }
        Label lblCarrier = JKText.getLblDk(carrierName, JKText.FONT_B_22);

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy  HH:mm");
        Text txtTime = JKText.getTxtDk(sdf.format(route.getBoardingTime()), JKText.FONT_B_XXSM);

        Label lblTravelClass = JKText.getLblDk("Travel Class Here", JKText.FONT_B_20);
        if (route.getTravelClassDescription() != null && !route.getTravelClassDescription().isEmpty()) {
            lblTravelClass.setText(route.getTravelClassDescription());
        } else if (route.getTravelClass() != null && !route.getTravelClass().isEmpty()) {
            lblTravelClass.setText(route.getTravelClass());
        }

        VBox vbTrip = JKLayout.getVBoxLeft(0, (1 * JKLayout.spNum));
        vbTrip.getChildren().addAll(lblCarrier, lblTravelClass, txtTime);

        gridCost = getTicketCostsForRoute(route);

        GridPane grid = CoachCarrierLayouts.getGridCoachCarrierTrip();
        grid.setId(route.getRouteCode());

        VBox vbBtns = getVBBtns(coachCarrier, route, grid);

        grid.addRow(0, stackImg, vbTrip, gridCost, vbBtns);

        return grid;
    }

    private GridPane getTicketCostsForRoute(CoachRoute coachRoute) {

        GridPane grid = CoachCarrierLayouts.getGridTicketCosts();

        Label lbl0 = JKText.getLblDk("Adult : ", JKText.FONT_B_15);
        Label lbl1 = JKText.getLblDk("Child : ", JKText.FONT_B_15);
        Label lbl2 = JKText.getLblDk("Infant : ", JKText.FONT_B_15);

        Text txt0 = JKText.getTxtDk("n/a", JKText.FONT_B_XXSM);
        Text txt1 = JKText.getTxtDk("n/a", JKText.FONT_B_XXSM);
        Text txt2 = JKText.getTxtDk("n/a", JKText.FONT_B_XXSM);

        try {
            if (coachRoute.getPriceAdult() != null) {
                double priceAdult = Double.parseDouble(coachRoute.getPriceAdult());
                txt0.setText(JKText.getDeciFormat(priceAdult));
            }
            if (coachRoute.getPriceChild() != null) {
                double priceChild = Double.parseDouble(coachRoute.getPriceChild());
                txt1.setText(JKText.getDeciFormat(priceChild));
            }
            if (coachRoute.getPriceInfant() != null) {
                double priceInfant = Double.parseDouble(coachRoute.getPriceInfant());
                txt2.setText(JKText.getDeciFormat(priceInfant));
            }
        } catch (NumberFormatException nfe) {
            logger.log(Level.SEVERE, nfe.getMessage(), nfe);
        }

        grid.addRow(0, lbl0, txt0);
        grid.addRow(1, lbl1, txt1);
        grid.addRow(2, lbl2, txt2);

        return grid;
    }

    private VBox getVBBtns(final CoachCarrier coachCarrier, final CoachRoute route, final GridPane gridSelected) {

        Button btnSelect = JKNode.getBtnPopup("select");
        btnSelect.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                for (Node n : listGrids) {
                    GridPane gp = (GridPane) n;

                    gp.getStyleClass().clear();
                    gp.getStyleClass().add("gridCoach");
                    if (gp == gridSelected) {
                        gridSelected.getStyleClass().add("gridCoachSelected");
                        if (departOrReturn.equalsIgnoreCase(CoachUtil.TRIP_DEPART)) {
                            CoachTicketSale.getInstance().setCoachCarrierDepart(coachCarrier);
                            routeSelectedDepart = route;
                            tripDepartId = gp.getId();
                            CoachTicketSale.getInstance().setRouteDepart(routeSelectedDepart);
                        } else {
                            CoachTicketSale.getInstance().setCoachCarrierReturn(coachCarrier);
                            routeSelectedReturn = route;
                            tripReturnId = gp.getId();
                            CoachTicketSale.getInstance().setRouteReturn(routeSelectedReturn);
                        }
                    }
                }
            }
        });

//        Button btnInfo = JKNode.getBtnPopup("info");
//        btnInfo.setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                ScrollPane scrollInfo = new CoachCarrierInfo(coachCarrier);
//                JKiosk3.getMsgBox().showMsgBox(coachCarrier.getCarrierDescription(), null, scrollInfo);
//            }
//        });

        VBox vbBtns = CoachCarrierLayouts.getVBoxButtons();
//        vbBtns.getChildren().addAll(btnSelect, JKNode.getVSpacer(), btnInfo);
        vbBtns.getChildren().addAll(btnSelect, JKNode.getVSpacer());
        return vbBtns;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav();

        nav.getBtnBack().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                switch (departOrReturn) {
                    case CoachUtil.TRIP_DEPART:
                        SceneSales.clearAndChangeContent(new CoachBook1());
                        break;
                    case CoachUtil.TRIP_RETURN:
                        SceneSales.clearAndChangeContent(new CoachBook2a(CoachUtil.TRIP_DEPART));
                        break;
                    default:
                        break;
                }
            }
        });

        nav.getBtnCancel().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent(new TicketingMenu());
            }
        });

        nav.getBtnNext().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                if (validateTripSelected()) {
                    logSelections();
                    if (departOrReturn.equalsIgnoreCase(CoachUtil.TRIP_DEPART)) {
                        if (CoachTicketSale.getInstance().isReturnTrip()) {
                            SceneSales.clearAndChangeContent(new CoachBook2a(CoachUtil.TRIP_RETURN));
                        } else {
                            SceneSales.clearAndChangeContent(new CoachBook4());
                        }
                    } else {
                        SceneSales.clearAndChangeContent(new CoachBook4());
                    }
                }
            }
        });
        return nav;
    }

    private void logSelections() {
        StringBuilder sb = new StringBuilder("\r\n");
        if (departOrReturn.equalsIgnoreCase(CoachUtil.TRIP_DEPART)) {
            sb.append("Departure Trip ID    : ").append(CoachTicketSale.getInstance().getRouteDepart().getRouteCode()).append("\r\n");
        } else {
            sb.append("Return Trip ID    : ").append(CoachTicketSale.getInstance().getRouteReturn().getRouteCode()).append("\r\n");
        }

        logger.info(sb.toString());
    }

    private boolean validateTripSelected() {
        switch (departOrReturn) {
            case CoachUtil.TRIP_DEPART:
                if (tripDepartId == null || tripDepartId.equals("")) {
                    JKiosk3.getMsgBox().showMsgBox("No Trip Selected", "\nA Trip must be selected before continuing.", null);
                    return false;
                }
                break;
            case CoachUtil.TRIP_RETURN:
                if (tripReturnId == null || tripReturnId.equals("")) {
                    JKiosk3.getMsgBox().showMsgBox("No Trip Selected", "\nA Trip must be selected before continuing.", null);
                    return false;
                }
                break;
            default:
                break;
        }
        return true;
    }
}
//
// =======================================================

//        ImageView imgView = JKNode.getImageViewCoachCarrier(coachCarrier.getCarrierCode());
////        ImageView imgView = JKNode.getJKImageViewProvider("prov_" + coachCarrier.getCarrierTransType() + ".png");
//        StackPane stackImg = CoachCarrierLayouts.getStackImage(imgView);

// **********************************************************
// Just in case we are required to use drop-downs again.
// The data we receive does NOT SUPPORT this functionality!!!
// **********************************************************
//    private GridPane getGridRouteSelectClass(CoachCarrier coachCarrier, CoachRoute route) {
//        System.out.println("details for Route : " + route.getRouteCode());
//
//        ImageView imgView = JKNode.getJKImageViewProvider("prov_" + coachCarrier.getCarrierTransType() + ".png");
//        StackPane stackImg = CoachCarrierLayouts.getStackImage(imgView);
//
//        Label lblCarrier = JKText.getLblDk(coachCarrier.getCarrierName(), JKText.FONT_B_22);
//
//        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
//        Text txtTime = JKText.getTxtDk(sdf.format(route.getBoardingTime()), JKText.FONT_B_15);
//        txtTime.setTranslateX(JKLayout.sp);
//
//        VBox vbTrip = JKLayout.getVBoxLeft(0, (1 * JKLayout.spNum));
//
//        ObservableList<CoachTravelClass> list = FXCollections.observableArrayList(route.getListTravelClass());
//        for (CoachTravelClass t : list) {
//            System.out.println("price adult  = " + t.getPriceAdult());
//        }
//
//        ComboBox<CoachTravelClass> comClass = CoachCarrierLayouts.getComboBoxTravelClass();
//        comClass.setStyle("-fx-font-size: 20px;");
//        comClass.setItems(list);
//        comClass.getSelectionModel().select(0);
//
////        selectedTravelClass = comClass.getSelectionModel().getSelectedItem();
////
////        gridCost = getTicketCosts(selectedTravelClass);
//
//        vbTrip.getChildren().addAll(lblCarrier, comClass, txtTime);
//
//        GridPane grid = CoachCarrierLayouts.getGridCoachCarrierTrip();
//        grid.setId(route.getRouteCode());
//
////        VBox vbBtns = getVBBtns(coachCarrier, route, selectedTravelClass, grid);
//
////        grid.addRow(0, stackImg, vbTrip, gridCost, vbBtns);
//
////        comClass.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<CoachTravelClass>() {
//        comClass.valueProperty().addListener(new ChangeListener<CoachTravelClass>() {
//            @Override
//            public void changed(ObservableValue observable, CoachTravelClass oldValue, CoachTravelClass newValue) {
////                selectedTravelClass = newValue;
////
////                gridCost = getTicketCosts(selectedTravelClass);
////
////                grid.getChildren().clear();
////                grid.addRow(0, stackImg, vbTrip, gridCost, vbBtns);
//            }
//        });
//
//        return grid;
//    }
//
//    private GridPane getTicketCosts(CoachTravelClass travelClass) {
//
//        GridPane grid = CoachCarrierLayouts.getGridTicketCosts();
//
//        Label lbl0 = JKText.getLblDk("Adult : ", JKText.FONT_B_15);
//        Label lbl1 = JKText.getLblDk("Child : ", JKText.FONT_B_15);
//        Label lbl2 = JKText.getLblDk("Infant : ", JKText.FONT_B_15);
//
//        Text txt0 = JKText.getTxtDk(JKText.getDeciFormat(travelClass.getPriceAdult()), JKText.FONT_B_XXSM);
//        Text txt1 = JKText.getTxtDk(JKText.getDeciFormat(travelClass.getPriceChild()), JKText.FONT_B_XXSM);
//        if (travelClass.getPriceChild() == 0.0) {
//            txt1.setText("");
//        }
//        Text txt2 = JKText.getTxtDk(JKText.getDeciFormat(travelClass.getPriceInfant()), JKText.FONT_B_XXSM);
//        if (travelClass.getPriceInfant() == 0.0) {
//            txt2.setText("");
//        }
//
//        grid.addRow(0, lbl0, txt0);
//        grid.addRow(1, lbl1, txt1);
//        grid.addRow(2, lbl2, txt2);
//
//        return grid;
//    }