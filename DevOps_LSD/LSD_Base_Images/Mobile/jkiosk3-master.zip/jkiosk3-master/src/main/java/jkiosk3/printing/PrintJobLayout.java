package jkiosk3.printing;

import aeonprinting.AeonPrintFormat;
import aeonprinting.AeonPrintJob;
import aeonprinting.AeonPrintLine;
import jkiosk3.JK3Config;
import jkiosk3.store.JKPrintOptions;

import javax.xml.bind.DatatypeConverter;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class PrintJobLayout {

    private PrintJob printJobSer;
    private String printLinesWin;

    private BarcodeHandler bh;
    private boolean isForceBarcode;

    private static final int fontSizeDisplay = 14;
    private static final int fontSizeBigDisplay = 16;
    private static final int FONT_LARGE = 46;
    //    private static final int fontSizeBarDisplay = 12;
    //
    private static final int fontSizePrint = 9;
    private static final int fontSizeBigPrint = 12;
    private static final int fontSizeBarPrint = 10;

    private final String styleDisplay = "<style><!--"
            + "body {"
            + "   font-family: Consolas, 'Courier New';"
            + "   font-size: " + fontSizeDisplay + "pt;"
            + "   line-spacing: 2px; "
            + "}"
            + "div {"
            + "    padding: 0px; "
            + "    margin: 0px; "
            + "}"
            + "hr {"
            + "   height: 1px;"
            + "   margin: 5px;"
            + "   padding: 0px;"
            + "}"
            + ".centre {"
            + "   text-align: center;"
            + "}"
            + ".centreBold {"
            + "   font-weight: bold;"
            + "   text-align: center;"
            + "}"
            + ".centreBoldLarge {"
            + "   font-weight: bold;"
            + "   text-align: center;"
            + "   -webkit-transform: scaleY(20);"
            + "   -moz-transform: scaleY(20);"
            + "    font-size: " + fontSizeBigDisplay + "pt;"
            + "}"
            + ".bigBold {"
            + "   font-size: " + fontSizeBigDisplay + "pt;"
            + "}"
            + ".centreUnderline {"
            + "   text-decoration: underline;"
            + "   text-align: center;"
            + "}"
            + ".highlight {"
            + "   background-color: black;"
            + "   color: white;"
            + "}"
            + ".hide {"
            + "   display: none;"
            + "}"
            + "--></style>";
    //
    private final String stylePrint = "<style><!--"
            + "body {"
            + "   font-family: Consolas;"
            + "   font-size: " + fontSizePrint + "pt;"
            + "   line-spacing: 2px; "
            + "}"
            + "div {"
            + "    padding: 0px; "
            + "    margin: 0px; "
            + "}"
            + "hr {"
            + "   height: 1px;"
            + "   margin: 5px;"
            + "   padding: 0px;"
            + "}"
            + "pre {"
            + "   margin: 0px;"
            + "   padding: 0px;"
            + "}"
            + ".centre {"
            + "   text-align: center;"
            + "}"
            + ".logo {"
            + "   text-align: center;"
            + "}"
            + ".bold {"
            + "   font-weight: bold;"
            + "}"
            + ".centreBold {"
            + "   text-align: center;"
            + "   font-weight: bold;"
            + "}"
            + ".centreBoldLarge {"
            + "   font-weight: bold;"
            + "   text-align: center;"
            + "   -webkit-transform: scaleY(10);"
            + "   -moz-transform: scaleY(10);"
            + "   font-size: " + fontSizeBigPrint + "pt;"
            + "}"
            + ".bigBold {"
            + "   text-align: center;"
            + "   font-size: " + fontSizeBigPrint + "pt;"
            + "   font-weight: bold;"
            + "}"
            + ".centreUnderline {"
            + "   text-align: center;"
            + "   text-decoration: underline;"
            + "}"
            + ".highlight {"
            + "   background-color: black;"
            + "   color: white;"
            + "}"
            + ".barcode {"
            + "   font-family: Consolas; "
            + "   text-align: center;"
            + "   font-size: " + fontSizeBarPrint + "pt;"
            + "   padding: 10px 10px 0px 10px;"
            + "}"
            + ".barcode_text {"
            + "   text-align: center;"
            + "   font-size: " + fontSizePrint + "pt;"
            + "   padding: 0px;"
            + "}"
            + "--></style>";

    public PrintJobLayout() {
        this.bh = new BarcodeHandler ();
    }

    public PrintJobLayout(boolean isForceBarcode) {
        this.bh = new BarcodeHandler ();
        this.isForceBarcode = isForceBarcode;
    }

    private void getPrintLines(AeonPrintJob printJob) {

//        bh = new BarcodeHandler();

        PrintJob pj = new PrintJob (32);

        StringBuilder printout = new StringBuilder ();
        printout.append ("<html>");
        printout.append ("<head><style /></head>");
        printout.append ("<body>");

        for (AeonPrintLine l : printJob.getLines ()) {
            if (l.getLine () != null) {
                String lineS = l.getLine ();                                         // line for Serial prints
                String lineW = lineS.replaceAll (" ", "&nbsp;");   // line for Windows prints

                switch (l.getFormat ()) {
                    case "A":       // NORMAL("A")
                        if (lineS.length () > 0) {
                            if (lineS.length () < 32 && lineS.contains (":")) {
                                String[] split = {lineS.substring (0, lineS.indexOf (":") + 1), lineS.substring (lineS.indexOf (":") + 1)};
                                String s = String.format ("%-" + split[0].length () + "s" + "%" + (32 - split[0].length ()) + "s", split[0], split[1]);
                                pj.addLine (s, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BOLD);
                                printout.append ("<div class='centre'>").append (s.replaceAll (" ", "&nbsp;")).append ("</div>");
                            } else if (lineS.length () < 32 && !lineS.contains (":")) {
                                String s = String.format ("%-" + (32 - lineS.length ()) + "s" + "%" + (lineS.length ()) + "s", " ", lineS);
                                pj.addLine (s, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BOLD);
                                printout.append ("<div class='centre'>").append (s.replaceAll (" ", "&nbsp;")).append ("</div>");
                            } else {
                                pj.addLine (lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BOLD);
                                printout.append ("<div class='centre'>").append (lineW).append ("</div>");
                            }
                        }
                        break;
                    case "B":       // BOLD("B")
                        pj.addLine (lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BOLD);
                        printout.append ("<div class='centreBold'>").append (lineW).append ("</div>");
                        break;
                    case "C":       //
                    case "D":
                        break;
                    case "E":       // CENTER_BOLD("E")D);
                        pj.addLine (lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.CENTER_BOLD);
                        if (PrintUtil.isPinFormat (lineS)) {
                            printout.append ("<div class='centreBoldLarge'>").append (lineS).append ("</div>");
                        } else {
                            printout.append ("<div class='centreBold'>").append (lineS).append ("</div>");
                        }
                        break;
                    case "F":       //
                        break;
                    case "G":       //
                        break;
                    case "H":       // CENTER("H")
                        pj.addLine (lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BOLD);
                        printout.append ("<div class='centre'>").append (lineW).append ("</div>");
                        break;
                    case "I":       //
                        break;
                    case "J":       // HEADER_IMAGE("J")    - used for things like TicketPro events, different logo for each Event
                        String[] logoURLSplit = lineS.split ("\\\\");
                        String fileNameHeader = logoURLSplit[logoURLSplit.length - 1];
                        if (PrintUtil.PRINT_POS) {      // Serial print
                            File imgFile = new File (JK3Config.getImagesTemp () + fileNameHeader);
                            String path = imgFile.getAbsolutePath ().replaceAll ("\\\\", "\\\\\\\\");
                            pj.addLine (path, PrintJob.PrintAlign.CENTER, AeonPrintFormat.HEADER_IMAGE);
                        }
                        if (PrintUtil.PRINT_WIN) {      // Windows print
                            String imgFileSrc = ("file:" + JK3Config.getImagesTemp () + fileNameHeader).replaceAll ("\\\\", "/");
                            printout.append ("<div class='logo'><img src='").append (imgFileSrc).append ("' border='0' /></div>");
                        }
                        break;
                    case "K":       // CENTER_UNDERLINE("K")
                        pj.addLine (lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BOLD);
                        printout.append ("<div class='centreUnderline'>").append (lineW).append ("</div>");
                        break;
                    case "L":       // LOGO("L")    - used for pre-defined logo items, such as BLT, bus carriers and MVNOs
                        String filePathLogo = checkLogoPathExists (lineS);
                        if (PrintUtil.PRINT_POS) {      // Serial print
                            File logoFile = new File (filePathLogo);
                            String path = logoFile.getAbsolutePath ().replaceAll ("\\\\", "\\\\\\\\");
                            pj.addLine (path, PrintJob.PrintAlign.CENTER, AeonPrintFormat.LOGO);
                            pj.addLine (" ", PrintJob.PrintAlign.CENTER, AeonPrintFormat.BOLD);
                        }
                        if (PrintUtil.PRINT_WIN) {      // Windows print
                            String imgFileSrc = ("file:" + filePathLogo).replaceAll ("\\\\", "/");
                            printout.append ("<div class='logo'><img src='").append (imgFileSrc).append ("' border='0' /></div>");
                        }
                        break;
                    case "M":       // INVERT("M")
                        pj.addLine (lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BOLD);
                        printout.append ("<div class='highlight'>").append (lineW).append ("</div>");
                        break;
                    case "N":       // BREAK("N")
                        pj.addBreak ();
                        printout.append ("<hr />");
                        break;
                    case "O":       // BLANK("O")
                        pj.addLine ("", PrintJob.PrintAlign.LEFT, AeonPrintFormat.BOLD);
                        printout.append ("<br />");
                        break;
                    case "P":       // BAR_EAN("P")     (Vouchers)
                        if (!lineS.isEmpty () || !lineW.isEmpty ()) {
                            if (isForceBarcode) {
                                // If true, force barcode to print regardless of setting.
                                addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_EAN);
                                addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_EAN13);
                            } else {
                                // If false, check whether Merchant wants barcode to print or not.
                                if (JKPrintOptions.getPrintOptions ().isPrintBarcode ()) {
                                    addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_EAN);
//                            String subLine = line.substring(0, 12);
//                            String subLine = lineW.substring(0, 13);
                                    addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_EAN13);
                                }
                            }
                        }
                        break;
                    case "Q":       // BAR_39("Q")      (C4C)
                        if (!lineS.isEmpty () || !lineW.isEmpty ()) {
                            if (isForceBarcode) {
                                // If true, force barcode to print regardless of setting.
                                addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_39);
                                addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_CODE39);
                            } else {
                                // If false, check whether Merchant wants barcode to print or not.
                                if (JKPrintOptions.getPrintOptions ().isPrintBarcode ()) {
                                    addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_39);
                                    addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_CODE39);
                                }
                            }
                        }
                        break;
                    case "R":       // BAR_INT2OF5("R")
                        if (!lineS.isEmpty () || !lineW.isEmpty ()) {
                            if (isForceBarcode) {
                                // If true, force barcode to print regardless of setting.
                                addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_INT2OF5);
                                addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_ITF);
                            } else {
                                // If false, check whether Merchant wants barcode to print or not.
                                if (JKPrintOptions.getPrintOptions ().isPrintBarcode ()) {
                                    addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_INT2OF5);
                                    addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_ITF);
                                }
                            }
                        }
                        break;
                    case "S":       // BAR_128B("S")
                        if (!lineS.isEmpty () || !lineW.isEmpty ()) {
                            // THIS ONE IS HANDLED SLIGHTLY DIFFERENTLY!
                            if (isForceBarcode) {
                                // If true, force barcode to print regardless of setting.
                                pj.addLine (DatatypeConverter.printHexBinary (lineS.getBytes ()), PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_128B);
                                // if barcode has characters '<' or '>' then we need to convert them to HTML encoded
                                StringBuilder sb = bh.processBarcodeTextToPrint (lineS);
                                String filename = bh.createBarcode (lineW, BarcodeHandler.BARCODE_128B);
                                if (filename != null) {
                                    printout.append ("<div class='centre'><img src='").append (getBarcodePath (filename)).append ("' width='180' /></div>");
                                    printout.append ("<div class='barcode_text'>*").append (sb.toString ()).append ("*</div>");
                                } else {
                                    printout.append ("<div class='barcode_text'>*").append (sb.toString ()).append ("*</div>");
                                }
                            } else {
                                // If false, check whether Merchant wants barcode to print or not.
                                if (JKPrintOptions.getPrintOptions ().isPrintBarcode ()) {
                                    pj.addLine (DatatypeConverter.printHexBinary (lineS.getBytes ()), PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_128B);
                                    // if barcode has characters '<' or '>' then we need to convert them to HTML encoded
                                    StringBuilder sb = bh.processBarcodeTextToPrint (lineS);
                                    String filename = bh.createBarcode (lineW, BarcodeHandler.BARCODE_128B);
                                    if (filename != null) {
                                        printout.append ("<div class='centre'><img src='").append (getBarcodePath (filename)).append ("' width='180' /></div>");
                                        printout.append ("<div class='barcode_text'>*").append (sb.toString ()).append ("*</div>");
                                    } else {
                                        printout.append ("<div class='barcode_text'>*").append (sb.toString ()).append ("*</div>");
                                    }
                                }
                            }
                        }
                        break;
                    case "T":       // BAR_128C("T")
                        if (!lineS.isEmpty () || !lineW.isEmpty ()) {
                            if (isForceBarcode) {
                                // If true, force barcode to print regardless of setting.
                                addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_128C);
                                addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_128C);
                            } else {
                                // If false, check whether Merchant wants barcode to print or not.
                                if (JKPrintOptions.getPrintOptions ().isPrintBarcode ()) {
                                    addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_128C);
                                    addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_128C);
                                }
                            }
                        }
                        break;
                    case "U":       // BAR_INT2OF5L("U") - 2 extra digits on end for lotto - print even if PRINT BARCODES is OFF
                        if (!lineS.isEmpty () || !lineW.isEmpty ()) {
                            // Does not need the check for 'isForceBarcode'.  Unique case.
                            /* Do NOT check if barcode print setting is ON or OFF.  Ithuba barcodes MUST print regardless of setting */
                            char ch = ';';
                            String linesub = lineS.substring (0, lineS.indexOf (ch));
                            pj.addLine (linesub, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_INT2OF5L);
                            String filenameIthuba = bh.createBarcode (linesub, BarcodeHandler.BARCODE_ITF);
                            if (filenameIthuba != null) {
                                printout.append ("<div class='centre'><img src='").append (getBarcodePath (filenameIthuba)).append ("' width='180' /></div>");
                            } else {
                                printout.append ("<div class='barcode_text'>*").append (linesub).append ("*</div>");
                            }
                        }
                        break;
                    case "V":       // BAR_PDF417("V")
                        if (!lineS.isEmpty () || !lineW.isEmpty ()) {
                            if (isForceBarcode) {
                                // If true, force barcode to print regardless of setting.
                                addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_PDF417);
                                addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_PDF417);
                            } else {
                                // If false, check whether Merchant wants barcode to print or not.
                                if (JKPrintOptions.getPrintOptions ().isPrintBarcode ()) {
                                    addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_PDF417);
                                    addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_PDF417);
                                }
                            }
                        }
                        break;
                    case "W":       // WIDE("W")
                        break;
                    case "X":       // BAR_128A("X")
                        if (!lineS.isEmpty () || !lineW.isEmpty ()) {
                            if (isForceBarcode) {
                                // If true, force barcode to print regardless of setting.
                                addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_128A);
                                addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_128A);
                            } else {
                                // If false, check whether Merchant wants barcode to print or not.
                                if (JKPrintOptions.getPrintOptions ().isPrintBarcode ()) {
                                    addBarcodeLinesSer (pj, lineS, PrintJob.PrintAlign.CENTER, AeonPrintFormat.BAR_128A);
                                    addBarcodeLinesWin (printout, lineW, BarcodeHandler.BARCODE_128A);
                                }
                            }
                        }
                        break;
                    case "Y":
                        break;
                    case "Z":
                        break;
                    default:
                        pj.addLine (lineS, PrintJob.PrintAlign.LEFT, AeonPrintFormat.NORMAL);
                        printout.append ("<div>").append (lineW).append ("</div>");
                        break;
                }
            } else {
                System.out.println ("PrintLine is NULL : we do not have a printLine!");
            }
        }

        printout.append ("</body></html>");

        printJobSer = pj;
        printLinesWin = printout.toString ().

                replace ("<style />", stylePrint);

    }

    private String checkLogoPathExists(String logoID) {
        String fileName = logoID + ".gif";
        String imgUrl = JK3Config.getMediaLogos () + fileName;
        try {
            new BufferedInputStream (new FileInputStream (imgUrl));
            return imgUrl;
        } catch (IllegalArgumentException | IOException e) {    // will catch exception if the image does not exist
            return JK3Config.getMediaLogos () + "0.gif";
        }
    }

    private void addBarcodeLinesSer(PrintJob pj, String line, PrintJob.PrintAlign printAlign, AeonPrintFormat barcodeFormat) {
        pj.addLine (line, printAlign, barcodeFormat);
        pj.addLine (line, printAlign, AeonPrintFormat.NORMAL);
    }

    private void addBarcodeLinesWin(StringBuilder printout, String line, String barcodeFormat) {
        String filename = bh.createBarcode (line, barcodeFormat);
        if (filename != null) {
            printout.append ("<div class='centre'><img src='").append (getBarcodePath (filename)).append ("' width='180' /></div>");
            printout.append ("<div class='barcode_text'>*").append (line).append ("*</div>");
        } else {
            printout.append ("<div class='barcode_text'>*").append (line).append ("*</div>");
        }
    }

    private String getBarcodePath(String filename) {
        String barcodeFilePath = "file:" + JK3Config.getBarcodes ();
        return (barcodeFilePath + filename).replaceAll ("\\\\", "/");
    }

    private String getPreviewLines(AeonPrintJob printJob) {

        StringBuilder preview = new StringBuilder ();

        preview.append ("<html>");
        preview.append ("<head><style /></head>");
        preview.append ("<body>");
        for (AeonPrintLine l : printJob.getLines ()) {
            if (l.getLine () != null) {
                String lineP = l.getLine ();
                String line = lineP.replaceAll (" ", "&nbsp;");
                switch (l.getFormat ()) {
                    case "A":
//                        System.out.println("lineP = " + lineP);
                        if (lineP.length () > 0) {
                            if (lineP.length () < 32 && lineP.contains (":")) {
                                String[] split = {lineP.substring (0, lineP.indexOf (":") + 1), lineP.substring (lineP.indexOf (":") + 1)};
                                String s = String.format ("%-" + split[0].length () + "s" + "%" + (32 - split[0].length ()) + "s", split[0], split[1]);
                                preview.append ("<div class='centre'>").append (s.replaceAll (" ", "&nbsp;")).append ("</div>");
                            } else if (lineP.length () < 32 && !lineP.contains (":")) {
                                String s = String.format ("%-" + (32 - lineP.length ()) + "s" + "%" + (lineP.length ()) + "s", " ", lineP);
                                preview.append ("<div class='centre'>").append (s.replaceAll (" ", "&nbsp;")).append ("</div>");
                            } else {
                                preview.append ("<div class='centre'>").append (line).append ("</div>");
                            }
                        }
                        break;
                    case "B":
                        preview.append ("<div class='centreBold'>").append (line).append ("</div>");
                        break;
                    case "C":
//                        preview.append("<div class='bigBold centreBold'>").append(line).append("</div>");
                        preview.append ("<div class='centreBold'>").append (line).append ("</div>");
                        break;
                    case "E":
//                        preview.append("<div class='bigBold centreBold'>").append(line).append("</div>");
                        preview.append ("<div class='centreBold'>").append (line).append ("</div>");
                        break;
                    case "H":
                        preview.append ("<div class='centre'>").append (line).append ("</div>");
                        break;
                    case "K":
                        preview.append ("<div class='centreUnderline'>").append (line).append ("</div>");
                        break;
                    case "L":
                        preview.append ("<div class='centre'>").append ("").append ("</div>");
                        break;
                    case "M":
                        preview.append ("<div class='highlight'>").append (line).append ("</div>");
                        break;
                    case "N":
                        preview.append ("<hr />");
                        break;
                    case "O":
                        preview.append ("<br />");
                        break;
                    default:
                        preview.append ("<div class='hide'>").append ("").append ("</div>");
                        break;
                }
            } else {
                System.out.println ("PrintUtil : we do not have a printLine!");
            }
        }

        preview.append ("</body></html>");
        return preview.toString ().replace ("<style />", styleDisplay);
    }

    public String getPrintLinesPreview(AeonPrintJob printJob) {
        return getPreviewLines (printJob);
    }

    public PrintJob getPrintJobSer(AeonPrintJob printJob) {
        getPrintLines (printJob);
        return printJobSer;
    }

    public String getPrintLinesWin(AeonPrintJob printJob) {
        getPrintLines (printJob);
        return printLinesWin;
    }
}
