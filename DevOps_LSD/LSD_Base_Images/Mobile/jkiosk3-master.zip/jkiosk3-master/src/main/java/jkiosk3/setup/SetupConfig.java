package jkiosk3.setup;

import java.util.UUID;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKOptions;
import jkiosk3.store.JKSystem;

/**
 *
 * @author Val
 */
public class SetupConfig extends Region {

    private Label lblConnect;
    private TextField txtServer;
    private TextField txtPort;
    private TextField txtServerNonSSL;
    private TextField txtPortNonSSL;
    private TextField txtDevId;
    private TextField txtConnect;
    // private CheckBox chkSecConn;
    private CheckBox chkAutoConn;
    private CheckBox chkAutoDisconn;
    private static boolean deviceChanged = false;

    public SetupConfig() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getConfigEntry());
        vb.getChildren().add(getControls());

        getChildren().add(vb);
    }

    private GridPane getConfigEntry() {
        GridPane grid = JKLayout.getGridContent2Col(0.3, 0.65, HPos.LEFT);

        // VBox vbHead = JKNode.getPageHeadVB("Secure Config");

        Label header = JKText.getLblDk("Device Config", JKText.FONT_B_XSM);
        Label lblServer = JKText.getLblDk("SSL Server", JKText.FONT_B_XSM);
        header.setMinWidth(JKLayout.btnLgW);
        lblServer.setMinWidth(JKLayout.btnLgW);
        Label lblPort = JKText.getLblDk("SSL Port", JKText.FONT_B_XSM);

        // VBox vbHeadNonSSL = JKNode.getPageHeadVB("Non-Secure Config");

        Label lblServerNonSSL = JKText.getLblDk("Non-SSL Server", JKText.FONT_B_XSM);
        lblServerNonSSL.setMinWidth(JKLayout.btnLgW);
        Label lblPortNonSSL = JKText.getLblDk("Non-SSL Port", JKText.FONT_B_XSM);
        Label lblDevId = JKText.getLblDk("Device ID", JKText.FONT_B_XSM);
        lblConnect = JKText.getLblDk("Connection", JKText.FONT_B_XSM);

        txtServer = new TextField();
        txtServer.setText(JK3Config.getAeonSSL());
        txtServer.setDisable(true);

        txtServerNonSSL = new TextField();
        txtServerNonSSL.setText(JK3Config.getNonAeonSSL());
        txtServerNonSSL.setDisable(true);

/*        txtServer.setOnMouseReleased(   new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtServer, "Server IP Address", txtServer.getText(), false);
                }
            }
        });*/

        txtPort = new TextField();
        txtPort.setText(JK3Config.getAeonSSLPort());
        txtPort.setDisable(true);

        txtPortNonSSL = new TextField();
        txtPortNonSSL.setText(JK3Config.getNonAeonSSLPort());
        txtPortNonSSL.setDisable(true);
/*        txtPort.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtPort, "Server Port", txtPort.getText());
                }
            }
        });*/

        txtDevId = new TextField();
        txtDevId.setText(Integer.toString(JKSystem.getSystemConfig().getDeviceId()));
        txtDevId.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtDevId, "Device ID", txtDevId.getText());
                }
            }
        });

        txtConnect = new TextField();
        txtConnect.setText(JKDialup.getDialupConnect().getAutoConnName());
        txtConnect.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtConnect, "Connection Name", txtConnect.getText(), false);
                }
            }
        });

        // chkSecConn = new CheckBox("Use Secure Connection");
        // chkSecConn.setSelected(JKSystem.getSystemConfig().isSecureConn());

        chkAutoConn = new CheckBox("Auto-Connect (if not connected)");
        chkAutoConn.setSelected(JKDialup.getDialupConnect().isAutoConn());
        chkAutoConn.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event arg0) {
                setAutoConnectView();
            }
        });

        chkAutoDisconn = new CheckBox("Auto-Disconnect (if connected)");
        chkAutoDisconn.setSelected(JKDialup.getDialupConnect().isAutoDisconn());

        setAutoConnectView();

/*        grid.add(vbHead, 0, 0, 2, 1);
        grid.add(vbHeadNonSSL, 0, 3, 2, 1);*/
        grid.addRow(1, header);
        grid.addRow(2, lblServer, txtServer);
        grid.addRow(3, lblPort, txtPort);
        grid.add(JKNode.createGridSpanSep(2), 0, 4);
        grid.addRow(5, lblServerNonSSL, txtServerNonSSL);
        grid.addRow(6, lblPortNonSSL, txtPortNonSSL);
        grid.addRow(7, lblDevId, txtDevId);

        // grid.add(chkSecConn, 1, 4);
        //grid.add(JKNode.createGridSpanSep(2), 0, 7);

        grid.add(chkAutoConn, 1, 8);
        grid.add(chkAutoDisconn, 1, 9);

        grid.addRow(10, lblConnect, txtConnect);

        return grid;
    }

    private void setAutoConnectView() {
        if (chkAutoConn.isSelected()) {
            chkAutoDisconn.setDisable(false);
            lblConnect.setDisable(false);
            txtConnect.setDisable(false);
        } else {
            chkAutoDisconn.setDisable(true);
            lblConnect.setDisable(true);
            txtConnect.setDisable(true);
        }
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("", false) {
            @Override
            public void onClickTest() {
                //
            }

            @Override
            public void onClickSave() {
                if (JKSystem.getSystemConfig().getDeviceId() != 0) {
                    if (JKSystem.getSystemConfig().getDeviceId() == Integer.parseInt(txtDevId.getText())) {
                        deviceChanged = false;
                        saveSystemConfig();
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Configuration Update", "Application restart will be required", null,
                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult() {
                                    @Override
                                    public void onOk() {
                                        deviceChanged = true;
                                        saveSystemConfig();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    }
                } else if (JKSystem.getSystemConfig().getDeviceId() == 0) {
                    deviceChanged = false;
                    saveSystemConfig();
                }
            }
        };
    }

    private void saveSystemConfig() {
        JKSystem.getSystemConfig().setServer(txtServer.getText());
        JKSystem.getSystemConfig().setPort(Integer.parseInt(txtPort.getText()));
        JKSystem.getSystemConfig().setDeviceId(Integer.parseInt(txtDevId.getText()));
        // JKSystem.getSystemConfig().setSecureConn(chkSecConn.isSelected());
//        JKSystem.getSystemConfig().setSerial(getSerial());
        //
        JKDialup.getDialupConnect().setAutoConn(chkAutoConn.isSelected());
        JKDialup.getDialupConnect().setAutoDisconn(chkAutoDisconn.isSelected());
        JKDialup.getDialupConnect().setAutoConnName(txtConnect.getText());

        //
        if (JKSystem.saveSystemConfig() && JKDialup.saveDialupConnect()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Config settings saved successfully", null);
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Config settings not saved", null);
        }
    }

    public static String getSerial() {
        String serial = JKSystem.getSystemConfig().getSerial();
        if (serial.equals("")) {
            serial = createSerial();
        }
        return serial;
    }

    public static String createSerial() {
        return UUID.randomUUID().toString();
    }

    public static boolean isDeviceChanged() {
        return deviceChanged;
    }
}
