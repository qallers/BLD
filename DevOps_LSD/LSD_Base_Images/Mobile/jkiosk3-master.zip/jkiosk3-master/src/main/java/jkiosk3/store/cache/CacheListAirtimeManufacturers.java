package jkiosk3.store.cache;

import aeonairtime.AirtimeManufacturer;
import java.util.Collections;
import java.util.List;
import jkiosk3.store.Store;

/**
 *
 * @author valeriew
 */
public class CacheListAirtimeManufacturers {
    
    private static volatile ListAirtimeManufacturers listAirtimeManufacturers;

    private static ListAirtimeManufacturers getListAirtimeMan() {
        if (listAirtimeManufacturers == null) {
            listAirtimeManufacturers = ((ListAirtimeManufacturers) Store.loadObject(CacheListAirtimeManufacturers.class.getSimpleName()));
        }
        if (listAirtimeManufacturers == null) {
            listAirtimeManufacturers = new ListAirtimeManufacturers();
        }
        return listAirtimeManufacturers;
    }

    private static void saveListAirtimeManufacturers(ListAirtimeManufacturers listAirtimeMan) {
        Store.saveObject(CacheListAirtimeManufacturers.class.getSimpleName(), listAirtimeMan);
    }

    public static void saveAirtimeManufacturers(List<AirtimeManufacturer> listAirtimeMan) {
        getListAirtimeMan();

        listAirtimeManufacturers.getListAirtimeManufacturers().clear();
        listAirtimeManufacturers.getListAirtimeManufacturers().addAll(listAirtimeMan);
        saveListAirtimeManufacturers(listAirtimeManufacturers);
    }

    public static boolean hasItems() {
        getListAirtimeMan();
        return !listAirtimeManufacturers.getListAirtimeManufacturers().isEmpty();
    }

    public static List<AirtimeManufacturer> getListAirtimeManufacturers() {
        getListAirtimeMan();
        return Collections.unmodifiableList(listAirtimeManufacturers.getListAirtimeManufacturers());
    }
    
    public static void deleteCacheAirtimeManufacturers() {
        Store.deleteObject(CacheListAirtimeManufacturers.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheListAirtimeManufacturers.class.getSimpleName());
    }    
}
