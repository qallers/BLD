package jkiosk3.sales.search;

import jkiosk3.sales.SalesItems;
import jkiosk3.sales.topups.TopupProvider;

import java.util.ArrayList;
import java.util.List;

public class CreateWalletTopupProduct {

    public static List<SearchProduct> createWalletTopupProducts() {
        final String WALLET_TOP_UP = "Wallet Topup";

        List<SearchProduct> products = new ArrayList<>();
        for (TopupProvider topupProvider : SalesItems.getListTopupProvidersOther()) {
            SearchProduct networkProvider = new SearchProduct();

            String airtimeName = topupProvider.getDisplayName();

            networkProvider.setProvName(airtimeName);
            networkProvider.setProdName(String.format("%s %s", airtimeName.startsWith("x") ? airtimeName.substring(1) : airtimeName, WALLET_TOP_UP));
            networkProvider.setSearchTransType(SearchTransType.TOPUP_WALLET);

            products.add(networkProvider);
        }

        return products;
    }
}
