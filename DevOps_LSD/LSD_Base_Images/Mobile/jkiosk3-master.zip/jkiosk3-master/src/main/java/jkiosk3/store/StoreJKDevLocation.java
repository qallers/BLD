package jkiosk3.store;

import java.io.Serializable;

public class StoreJKDevLocation implements Serializable {

    // S(tore) = 19 : (1 + 9 = 10) (1 + 0 = 1)
    // J(K)  = 10 : (1 + 0 = 1)
    // D(ev) = 4
    // L(ocation) = 12 : (1 + 2 = 3)
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 991146L;

    private String deviceAddress;
    private String deviceLatLng;
    private String deviceLatitude;
    private String deviceLongitude;
    private long dateAndTimeSet;

    public String getDeviceAddress() {
        return deviceAddress;
    }

    public void setDeviceAddress(String deviceAddress) {
        this.deviceAddress = deviceAddress;
    }

    public String getDeviceLatLng() {
        return deviceLatLng;
    }

    public void setDeviceLatLng(String deviceLatLng) {
        this.deviceLatLng = deviceLatLng;
    }

    public String getDeviceLatitude() {
        return deviceLatitude;
    }

    public void setDeviceLatitude(String deviceLatitude) {
        this.deviceLatitude = deviceLatitude;
    }

    public String getDeviceLongitude() {
        return deviceLongitude;
    }

    public void setDeviceLongitude(String deviceLongitude) {
        this.deviceLongitude = deviceLongitude;
    }

    public long getDateAndTimeSet() {
        return dateAndTimeSet;
    }

    public void setDateAndTimeSet(long dateAndTimeSet) {
        this.dateAndTimeSet = dateAndTimeSet;
    }

    // Laurie's requirement
    // <location>jkiosk,lon=1234,lat=5678</location>
    public String getFormattedLocation() {
        StringBuilder sb = new StringBuilder();
        sb.append("jkiosk,").append("lon=").append(getDeviceLongitude()).append(",lat=").append(getDeviceLatitude());

        return sb.toString();
    }
}
