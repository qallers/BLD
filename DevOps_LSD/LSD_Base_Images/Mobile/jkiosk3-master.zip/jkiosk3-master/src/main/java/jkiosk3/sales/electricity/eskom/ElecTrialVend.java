package jkiosk3.sales.electricity.eskom;

import aeonelectricity.ElectricityConfirmation;
import aeonelectricity.ElectricityConnection;
import aeonelectricity.ElectricityMeter;
import aeonelectricity.ElectricityVoucher;

import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.PrintQueue;
import jkiosk3.printing.PrintUtil;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales._common.QuickAmounts;
import jkiosk3.sales._common.QuickAmountsResult;
import jkiosk3.sales.electricity.ElecConfirm;
import jkiosk3.sales.electricity.ElecEnterMeter;
import jkiosk3.sales.electricity.ElecEnterMeterResult;
import jkiosk3.sales.electricity.ElecShareBtnsLessMore;
import jkiosk3.sales.electricity.ElecShareGridLessMore;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.store.JKBranding;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.users.UserUtil;

/**
 * @author valerie
 */
public class ElecTrialVend extends Region {

    private final static Logger logger = Logger.getLogger(ElecTrialVend.class.getName());
    private ElectricityConnection connection;
    private final ElectricityProvider provider;
    private String meterNum;
    private int amount;
    private String sgc;
    private String tt;
    private String ti;
    private String krn;
    private String alg;
    private QuickAmounts qAmts;
    private final VBox vbToken;
    private ElecEnterMeter gMeter;
    private ElecShareBtnsLessMore btnsLessMore;
    private final ElecShareGridLessMore gridLessMore;
    private boolean isMore = false;

    public ElecTrialVend(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;

        vbToken = JKLayout.getVBox(0, JKLayout.spNum);
        gridLessMore = new ElecShareGridLessMore(ElectricityUtil.ELEC_TRIAL_VEND);

        getChildren().add(getMeterNumberEntry());
    }

    private VBox getMeterNumberEntry() {
        gMeter = new ElecEnterMeter(provider, ElectricityUtil.ELEC_TRIAL_VEND, new ElecEnterMeterResult() {
            @Override
            public void onDone() {
                if (gMeter.isMagEntry()) {
                    if (vbToken.getChildren().contains(gridLessMore)) {
                        vbToken.getChildren().remove(gridLessMore);
                        vbToken.getChildren().add(1, qAmts);
                    }
                    btnsLessMore.getBtnLess().setDisable(true);
                    btnsLessMore.getBtnMore().setDisable(true);
                    btnsLessMore.getBtnAccept().setDisable(false);
                    isMore = false;
                }
            }
        });

//        String merchantGroup = JKBranding.getBranding().getMerchantGroup().getCode();
//        qAmts = new QuickAmounts(merchantGroup, new QuickAmountsResult() {
//        qAmts = new QuickAmounts(SaleType.ELECTRICITY, null, new QuickAmountsResult() {
//            @Override
//            public void amountSelected(double value) {
//                amount = (int) value;
//                requestConfirmation();
//            }
//        });
//        qAmts.setVisible(true);
        qAmts = getQuickAmts();

        vbToken.getChildren().addAll(gMeter, qAmts, getElecSaleCtrls());
        return vbToken;
    }

    private QuickAmounts getQuickAmts() {
        QuickAmounts quick = new QuickAmounts(SaleType.ELECTRICITY, null, new QuickAmountsResult() {
            @Override
            public void amountSelected(double value) {
                amount = (int) value;
                requestConfirmation();
            }
        });
        quick.setVisible(true);
        return quick;
    }

    private void resetQuickAmounts() {
        vbToken.getChildren().remove(qAmts);
        qAmts = getQuickAmts();
        vbToken.getChildren().add(1, qAmts);
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        btnsLessMore = new ElecShareBtnsLessMore();

        if (provider.getDisplayName().contains("Eskom")
                || provider.getDisplayName().contains("Universal")) {
            btnsLessMore.getBtnLess().setVisible(true);
            btnsLessMore.getBtnLess().setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event arg0) {
                    getLessMoreAction(btnsLessMore.getBtnLess());
                }
            });
            btnsLessMore.getBtnMore().setVisible(true);
            btnsLessMore.getBtnMore().setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event arg0) {
                    getLessMoreAction(btnsLessMore.getBtnMore());
                }
            });
        }

        btnsLessMore.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event arg0) {
                requestConfirmation();
            }
        });
        btnsLessMore.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity();
            }
        });

        return btnsLessMore;
    }

    private void getLessMoreAction(Button b) {
        switch (b.getText()) {
            case "Less...":
                vbToken.getChildren().add(1, qAmts);
                vbToken.getChildren().remove(gridLessMore);
                btnsLessMore.getBtnLess().setDisable(true);
                btnsLessMore.getBtnMore().setDisable(false);
                btnsLessMore.getBtnAccept().setDisable(true);
                isMore = false;
                break;
            case "More...":
                vbToken.getChildren().remove(qAmts);
                vbToken.getChildren().add(1, gridLessMore);
                btnsLessMore.getBtnLess().setDisable(false);
                btnsLessMore.getBtnMore().setDisable(true);
                btnsLessMore.getBtnAccept().setDisable(false);
                isMore = true;
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Selected Action", "Nothing selected", null);
                break;
        }
    }

    private boolean inputValidation() {
        boolean validated = false;
        try {
            meterNum = gMeter.getMeterNum().trim();
            sgc = gridLessMore.getTxtSGC().getText();
            tt = gridLessMore.getTxtTT().getText();
            ti = gridLessMore.getTxtTi().getText();
            krn = gridLessMore.getTxtKrn().getText();
            alg = gridLessMore.getTxtAlg().getText();
            //
            if (meterNum.equals("") || meterNum == null) {
                JKiosk3.getMsgBox().showMsgBox("Meter Number", "Meter Number cannot be blank.\n\n"
                        + "Please enter Meter Number \n\nand choose or enter an amount.", null);
//                JKiosk3.getMsgBox().showMsgBox("Meter Number", "Meter Number cannot be blank.\n"
//                        + "Please enter Meter Number and choose an amount.", null);
                amount = 0;
                resetQuickAmounts();
                validated = false;
            } else {
                if (isMore) {
                    amount = Integer.parseInt(gridLessMore.getTxtAmt().getText());

                    if ((gridLessMore.getTxtSGC().getText().equals("") || gridLessMore.getTxtSGC().getText() == null)
                            || (gridLessMore.getTxtTT().getText().equals("") || gridLessMore.getTxtTT().getText() == null)
                            || (gridLessMore.getTxtTi().getText().equals("") || gridLessMore.getTxtTi().getText() == null)
                            || (gridLessMore.getTxtKrn().getText().equals("") || gridLessMore.getTxtKrn().getText() == null)
                            || (gridLessMore.getTxtAlg().getText().equals("") || gridLessMore.getTxtAlg().getText() == null)) {
                        JKiosk3.getMsgBox().showMsgBox("Empty Field(s)", "All fields must be completed", null);
                        validated = false;
                    } else {
                        if ((!sgc.matches("\\d{6}")) || (!tt.matches("\\d{2}")) || (!ti.matches("\\d{2}"))
                                || (!krn.matches("\\d{1}")) || (!alg.matches("\\d{2}"))) {
                            JKiosk3.getMsgBox().showMsgBox("Incorrect value entered",
                                    "Fields must be numeric only: - \n"
                                            + "SGC - 6 digits\n"
                                            + "TT - 2 digits\n"
                                            + "TI - 2 digits\n"
                                            + "KRN - 1 digit\n"
                                            + "ALG - 2 digits", null);
                        } else {
                            validated = true;
                        }
                    }
                } else {
                    validated = true;
                }
            }
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox().showMsgBox("Amount", "Amount cannot be empty, and\n must be in rands only, no cents", null);
            logger.log(Level.SEVERE, nfe.getMessage(), nfe);
            validated = false;
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }

        return validated;
    }

    private void requestConfirmation() {
        if (inputValidation()) {
            makeElectricityConnection();
        }
    }

    private void makeElectricityConnection() {
        final ElectricityMeter meter = new ElectricityMeter();
        if (gMeter.isMagEntry()) {
            meter.setTrack2data(meterNum);
            meter.setMeterSgc("");
            meter.setMeterTt("");
            meter.setMeterTi("");
            meter.setMeterKrn("");
            meter.setMeterAlg("");
        } else {
            meter.setMeterNum(meterNum);
            meter.setMeterSgc(sgc);
            meter.setMeterTt(tt);
            meter.setMeterTi(ti);
            meter.setMeterKrn(krn);
            meter.setMeterAlg(alg);
        }

        String transType = provider.getTransactionType();

        ElectricityUtil.getElectricityConfirmation(transType, "Trial", meter, amount, new ElectricityUtil.ElectricityConfirm() {
            @Override
            public void electricityConfirm(ElectricityConnection connect, final ElectricityConfirmation confirm) {
                if (confirm.isSuccess()) {
                    connection = connect;
                    ElecConfirm confirmGrid = new ElecConfirm(confirm, meter, amount, ElectricityUtil.ELEC_TRIAL_VEND);
                    JKiosk3.getMsgBox().showMsgBox("Electricity Meter Confirmation", "Trial Vend", confirmGrid,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult() {
                                @Override
                                public void onOk() {
                                    buyElectricity(confirm.getTransRef());
                                }

                                @Override
                                public void onCancel() {
                                    resetQuickAmounts();
                                }
                            });
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Unable to Confirm", !confirm.getAeonErrorText ().isEmpty () ?
                                    confirm.getAeonErrorCode() + " - " + confirm.getAeonErrorText() :
                                    confirm.getErrorCode() + " - " + confirm.getErrorText(),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                @Override
                                public void onOk() {
                                    ElectricityUtil.resetElectricity();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                    logger.info(("Unable to Confirm :").concat(Integer.toString(confirm.getErrorCode()))
                            .concat(" - ").concat(confirm.getErrorText()));
                }
            }
        });
    }

    private void buyElectricity(String confirmRef) {
        String ref = SalesUtil.getUniqueRef();

        ElectricityUtil.getElectricityVoucher(connection, "Trial", confirmRef, ref, new ElectricityUtil.ElectricityResult() {
            @Override
            public void electricityResult(ElectricityVoucher voucher) {
                if (voucher.isSuccess()) {
                    // 2019-11-07  -  PRODDEFECT-868
                    // Print immediately or later is now handled in PrintHandler
//                    if (JKPrintOptions.getPrintOptions().isPrintImmediately()) {
                        if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
                            JKiosk3.getPrintPreview().showPrintPreview("Electricity Trial Vend", voucher.getPrintLines(), voucher.getTransRef(),
                                    PrintPreview.PRN_OK, new PrintPreviewResult() {
                                        @Override
                                        public void onOk() {
                                            //
                                        }

                                        @Override
                                        public void onCancel() {
                                            //
                                        }
                                    });
                        } else {
//                            PrintUtil.sendToPrinter(voucher.getPrintLines(), voucher.getTransRef());
                            PrintHandler.handlePrintRequestSale(SaleType.ELECTRICITY.getDisplay(), voucher.getPrintLines(), voucher.getTransRef());
                        }
//                    } else {
//                        PrintQueue.addItem(voucher.getTransRef(), voucher.getPrintLines());
//                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Electricity Trial Vend Failed", !voucher.getAeonErrorText ().isEmpty () ? voucher.getAeonErrorCode () +" - "+ voucher.getAeonErrorText (): voucher.getErrorText(), null);
                }
                ElectricityUtil.resetElectricity();
            }
        });
    }
}
