package jkiosk3.sales.chat4change;

import aeonvarivouchers.Supplier;
import aeonvarivouchers.VDVoucherReq;
import aeonvarivouchers.VDVoucherResp;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.store.JKSalesOptions;
import jkiosk3.users.SalesUserLoginResult;
import jkiosk3.users.UserUtil;

public class Chat4Change extends Region {

    private final static Logger logger = Logger.getLogger (Chat4Change.class.getName ());
    private List<Supplier> suppliers;
    private VBox vbSuppliers;
    private VBox vbPageLayout;
    private VBox vbHeader;
    private VBox vbAmount;
    private double amount;
    private double amtMin;
    private double amtMax;
    private boolean showFavourite;

    public Chat4Change(boolean isFavourite) {
        suppliers = new ArrayList<> ();
        this.showFavourite = isFavourite;

        Chat4ChangeUtil.getC4CSupplierList (new Chat4ChangeUtil.C4CListSuppliersResult () {

            @Override
            public void c4cListSuppliersResult(List<Supplier> listSuppliers) {
                if (!listSuppliers.isEmpty ()) {
                    suppliers = listSuppliers;
                    getChildren ().add (getChat4ChangeLayout ());
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Chat-4-Change Voucher Suppliers",
                            "No Chat-4-Change Suppliers found.", null);
                }
            }
        });
    }

    private VBox getC4CPageHeader() {
        Label lblC4C = JKText.getLblDk (SaleType.CHAT4CHANGE.getDisplay (), JKText.FONT_B_24);
        if (Chat4ChangeSale.getInstance ().getSupplier () != null) {
            String provName = Chat4ChangeSale.getInstance ().getSupplier ().getName ();
            Button btnProvFav = JKNode.getAirtimeProviderButton (provName, "");
            return JKNode.getPageDblHeadVB (0, lblC4C, btnProvFav);
        } else {
            Label lblspace = JKText.getLblDk ("", JKText.FONT_B_24);
            return JKNode.getPageDblHeadVB (0, lblC4C, lblspace);
        }
    }

    private VBox getChat4ChangeLayout() {

        vbHeader = getC4CPageHeader ();

        vbPageLayout = JKLayout.getVBox (0, JKLayout.spNum);
        TilePane tile = JKLayout.getTile (0, JKLayout.sp, JKLayout.sp, 4);

        tile.getChildren ().addAll (getSupplierButtons ());

        vbSuppliers = JKLayout.getVBoxContent (JKLayout.sp);
        vbSuppliers.getChildren ().addAll (vbHeader, tile);

        vbPageLayout.getChildren ().add (vbSuppliers);
        if (showFavourite) {
            onSelectProviderButton ();
        }

        return vbPageLayout;
    }

    private List<Button> getSupplierButtons() {
        List<Button> listBtns = new ArrayList<> ();

        if (!suppliers.isEmpty ()) {
            for (final Supplier supp : suppliers) {
                Button btn = JKNode.getBtnSm ("");
                btn.getStyleClass ().add ("prov_" + supp.getName ().replaceAll (" ", "").replaceAll ("\n", "") + "_fix");
                ImageView imgView = JKNode.getImageViewC4CProvider (
                        "prov_" + supp.getName ().replaceAll (" ", "").replaceAll ("\n", "") + ".png");
                if (imgView != null) {
                    btn.setGraphic (imgView);
                } else {
                    btn.setText (supp.getName ());
                }
                btn.setOnMouseReleased (new EventHandler<Event> () {
                    @Override
                    public void handle(Event e) {
                        Chat4ChangeSale.getInstance ().setSupplier (supp);
                        onSelectProviderButton ();
                    }
                });
                listBtns.add (btn);
            }
            return listBtns;
        } else {
            JKiosk3.getMsgBox ().showMsgBox ("Chat 4 Change", "No Chat 4 Change Providers found", null);
            return null;
        }
    }

    private void onSelectProviderButton() {
        JKiosk3.getSalesUserLogin ().showUserLogin (new SalesUserLoginResult () {
            @Override
            public void onDone() {
                vbSuppliers.getChildren ().remove (vbHeader);
                vbHeader = getC4CPageHeader ();
                vbSuppliers.getChildren ().add (0, vbHeader);
                if (vbPageLayout.getChildren ().contains (vbAmount)) {
                    vbPageLayout.getChildren ().remove (vbAmount);
                    vbPageLayout.getChildren ().add (getAmountEntry ());
                } else {
                    vbPageLayout.getChildren ().add (getAmountEntry ());
                }
            }
        });
    }

    private VBox getAmountEntry() {

        String provName = Chat4ChangeSale.getInstance ().getSupplier ().getName ();

        amtMin = 2.0;
        amtMax = 500.0;

        if (Chat4ChangeSale.getInstance ().getSupplier ().getAmtMin () != 0) {
            amtMin = Chat4ChangeSale.getInstance ().getSupplier ().getAmtMin ();
        }
        if (Chat4ChangeSale.getInstance ().getSupplier ().getAmtMax () != 0) {
            amtMax = Chat4ChangeSale.getInstance ().getSupplier ().getAmtMax ();
        }

        Label lblAmt = JKText.getLblDk ("Sell any amount of Airtime in Rand and Cents "
                + "\n\nbetween R " + JKText.getDeciFormat (amtMin)
                + " and R " + JKText.getDeciFormat (amtMax) + " \n\n", JKText.FONT_B_20);
        Button btnAmt = JKNode.getBtnSmDbl ("Enter Amount");
        btnAmt.getStyleClass ().add ("prov_" + provName.replaceAll (" ", "").replaceAll ("\n", ""));
        btnAmt.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad ().showNumPad (new TextField (), "Amount", "", new NumberPadResult () {
                    @Override
                    public void onDone(String value) {
                        if (validateAmount (value)) {
                            Chat4ChangeSale.getInstance ().setAmount (amount);
                            if (JKSalesOptions.getSalesOptions ().isConfirmSale ()) {
                                showSummary ();
                            } else {
                                buyChat4ChangeVoucher ();
                            }
                        }
                    }
                });
            }
        });
        vbAmount = JKLayout.getVBoxContent (JKLayout.sp);
        vbAmount.setAlignment (Pos.CENTER_LEFT);
        vbAmount.getChildren ().addAll (lblAmt, btnAmt);
        return vbAmount;
    }

    private void showSummary() {
        GridPane grid = JKLayout.getSummaryGrid2Col (0.4, 0.6);

        Label lblProv = JKText.getLblDk ("Provider", JKText.FONT_B_20);
        Label lblAmt = JKText.getLblDk ("Amount", JKText.FONT_B_20);

        Text txtProv = JKText.getTxtDk (Chat4ChangeSale.getInstance ().getSupplier ().getName (), JKText.FONT_B_24);

        Text txtAmt = JKText.getTxtDk (JKText.getDeciFormat (Chat4ChangeSale.getInstance ().getAmount ()), JKText.FONT_B_24);

        grid.addRow (0, lblProv, txtProv);
        grid.addRow (1, lblAmt, txtAmt);

        JKiosk3.getMsgBox ().showMsgBox ("Chat 4 Change Voucher Sale", "Are you sure you want to purchase this Voucher?", grid,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        buyChat4ChangeVoucher ();
                    }

                    @Override
                    public void onCancel() {
                        UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                        SceneSales.clearAndShowFavourites ();
                    }
                });
    }

    private void buyChat4ChangeVoucher() {
        VDVoucherReq req = new VDVoucherReq ();
        req.setReference (SalesUtil.getUniqueRef ());
        req.setSupplierCode (Chat4ChangeSale.getInstance ().getSupplier ().getCode ());
        req.setSupplierName (Chat4ChangeSale.getInstance ().getSupplier ().getName ());
        req.setAmount (Chat4ChangeSale.getInstance ().getAmount ());

        Chat4ChangeUtil.getC4CVoucher (req, new Chat4ChangeUtil.C4CVoucherResult () {
            @Override
            public void c4cVoucherResult(VDVoucherResp c4cVoucher) {
                if (c4cVoucher.isSuccess ()) {
                    SalesUtil.processChat4Change (c4cVoucher);
                    if (vbPageLayout.getChildren ().contains (vbAmount)) {
                        vbPageLayout.getChildren ().remove (vbAmount);
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Transaction Failed",!c4cVoucher.getAeonErrorText ().isEmpty () ?
                            "A" + c4cVoucher.getAeonErrorCode () + " - " + c4cVoucher.getAeonErrorText () : "B" + c4cVoucher.getErrorCode () + " - " + c4cVoucher.getErrorText (), null);
                }
                SceneSales.clearAndShowFavourites ();
            }
        });
    }

    private boolean validateAmount(String amt) {
        try {
            amount = Double.parseDouble (amt);
            if (amount < amtMin || amount > amtMax) {
                JKiosk3.getMsgBox ().showMsgBox ("Amount",
                        "Please enter an Amount between R "
                                + JKText.getDeciFormat (amtMin) + " and R "
                                + JKText.getDeciFormat (amtMax), null);
                return false;
            }
        } catch (NumberFormatException nfe) {
            logger.log (Level.SEVERE, nfe.getMessage (), nfe);
            JKiosk3.getMsgBox ().showMsgBox ("Amount", "Please enter a valid Amount", null);
            return false;
        }
        return true;
    }
}
