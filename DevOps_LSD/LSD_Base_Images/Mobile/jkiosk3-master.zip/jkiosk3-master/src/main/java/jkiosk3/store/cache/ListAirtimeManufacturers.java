package jkiosk3.store.cache;

import aeonairtime.AirtimeManufacturer;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author valeriew
 */
public class ListAirtimeManufacturers implements Serializable {
    
    // L(ist)  = 12 (1 + 2 = 3)
    // A(irtime) = 1
    // M(anufacturers) = 13 (1 + 3 = 4)
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 999314L;
    private final List<AirtimeManufacturer> listAirtimeManufacturers = new ArrayList<>();

    public List<AirtimeManufacturer> getListAirtimeManufacturers() {
        return listAirtimeManufacturers;
    }
    
}
