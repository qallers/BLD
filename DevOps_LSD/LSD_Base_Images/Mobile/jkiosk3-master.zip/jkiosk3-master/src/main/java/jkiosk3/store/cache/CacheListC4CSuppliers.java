package jkiosk3.store.cache;

import aeonvarivouchers.Supplier;
import java.util.List;
import jkiosk3.store.Store;

/**
 *
 * @author valeriew
 */
public class CacheListC4CSuppliers {

    private static volatile ListC4CSuppliers listC4CSupp;

    private static ListC4CSuppliers getListC4CSupp() {
        if (listC4CSupp == null) {
            listC4CSupp = ((ListC4CSuppliers) Store.loadObject(CacheListC4CSuppliers.class.getSimpleName()));
        }
        if (listC4CSupp == null) {
            listC4CSupp = new ListC4CSuppliers();
        }
        return listC4CSupp;
    }

    private static void saveListC4CSuppliers(ListC4CSuppliers listC4CSuppliers) {
        Store.saveObject(CacheListC4CSuppliers.class.getSimpleName(), listC4CSuppliers);
    }

    public static void saveC4CSuppliers(List<Supplier> listC4CSuppliers) {
        if (getListC4CSuppliers().size() > 0) {
            listC4CSupp.getListC4CSuppliers().clear();
            listC4CSupp.getListC4CSuppliers().addAll(listC4CSuppliers);
            saveListC4CSuppliers(listC4CSupp);
        } else {
            listC4CSupp.getListC4CSuppliers().addAll(listC4CSuppliers);
            saveListC4CSuppliers(listC4CSupp);
        }
    }

    public static boolean hasItems() {
        getListC4CSupp();
        return listC4CSupp.getListC4CSuppliers().size() > 0;
    }

    public static List<Supplier> getListC4CSuppliers() {
        getListC4CSupp();
        return listC4CSupp.getListC4CSuppliers();
    }
    
    public static void deleteCacheC4CSuppliers() {
        Store.deleteObject(CacheListC4CSuppliers.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheListC4CSuppliers.class.getSimpleName());
    }
}
