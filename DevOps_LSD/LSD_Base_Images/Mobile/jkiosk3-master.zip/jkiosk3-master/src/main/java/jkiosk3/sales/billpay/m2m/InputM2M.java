package jkiosk3.sales.billpay.m2m;

import aeonmerchanttransfer.MerchantAccountInfoReq;
import aeonmerchanttransfer.MerchantAccountInfoResp;
import aeonmerchanttransfer.MerchantTransferConfirmReq;
import aeonmerchanttransfer.MerchantTransferConfirmResp;
import aeonmerchanttransfer.MerchantTransferConnection;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;

import static jkiosk3._common.JKLayout.contentW;
import static jkiosk3._common.JKLayout.sp;

import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayUtilMerchantTransfer;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.users.UserUtil;

public class InputM2M extends Region {

    private final static Logger logger = Logger.getLogger (InputM2M.class.getName ());

    private VBox vbContent;
    private GridPane gridEntry;
    private GridPane gridConfirm;
    private TextField txtNumber;
    private TextField txtNumber2;
    private TextField txtAmt;
    private Button btnDetail;
    private JKTenderToggles tenders;

    private String entry1;
    private String entry2;
    private String accountNumberConfirmed;
    private double amtPaid;
    private String tendered;
    private MerchantTransferConnection connect;
    private MerchantAccountInfoResp merchInfo;

    public InputM2M() {

        VBox vbLayout = JKLayout.getVBox (0, JKLayout.spNum);
        vbLayout.getChildren ().add (getAccountNumberEntry ());
        vbLayout.getChildren ().add (getNav ());

        getChildren ().add (vbLayout);
    }

    private VBox getAccountNumberEntry() {

        vbContent = JKLayout.getVBoxContent (JKLayout.spNum);
        vbContent.getChildren ().add (getHeaderLayout ());
        vbContent.getChildren ().add (getPaymentEntry ());

        return vbContent;
    }

    private GridPane getPaymentEntry() {
        gridEntry = getNumberEntry ();
        return gridEntry;
    }

    // new gridpane for entry - different for this product!!!
    private GridPane getHeaderLayout() {
        ImageView img = BillPayUtilMisc.getImageViewBillPay ("prov_Blu.png");
        img.setFitHeight (55);

        Label lblAccountPayment = JKText.getLblContentHead ("Merchant To Merchant Transfer");

        Label lblProdName = JKText.getLblDk ("Merchant To Merchant Transfer", JKText.FONT_B_XSM);

        HBox hbProv = JKLayout.getHBoxLeft (0, JKLayout.sp);
        hbProv.setPrefWidth (JKLayout.contentW - (2 * JKLayout.sideW));
        hbProv.getChildren ().addAll (img, lblProdName);

        GridPane gridHead = JKLayout.getContentGridInner2Col (0.5, 0.5);
        gridHead.add (lblAccountPayment, 0, 0, 2, 1);
        gridHead.add (hbProv, 0, 1, 2, 1);
        gridHead.addRow (2, JKNode.createGridSpanSep (2));

        return gridHead;
    }

    private GridPane getNumberEntry() {

        final String strPrompt = "Enter Account Number";
        final String strPrompt2 = "Re-enter Account Number";

        Label lblPaymentType = JKText.getLblDk ("Account Number", JKText.FONT_B_XSM);
        Label lblAmount = JKText.getLblDk ("Amount", JKText.FONT_B_XSM);

        txtNumber = new TextField ();
        txtNumber.setPromptText (strPrompt);
        txtNumber.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getKeyboard ().showKeyboard (txtNumber, strPrompt, "", false, false, new KeyboardResult () {

                    @Override
                    public void onDone(String value) {
                        txtNumber.setText (value.toUpperCase (Locale.ENGLISH));
                        // set value of first entry
                        if (!value.trim ().equals ("")) {
                            entry1 = value.trim ();
                            txtNumber2.setDisable (false);
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("Account Number", "Account Number" + " cannot be empty", null);
                            txtNumber2.setDisable (true);
                        }
                    }
                });
//                }
            }
        });

        txtNumber2 = new TextField ();
        txtNumber2.setPromptText (strPrompt2);
        txtNumber2.setDisable (true);
        txtNumber2.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                txtNumber.setVisible (false);
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getKeyboard ().showKeyboard (txtNumber2, strPrompt2, "", false, false, new KeyboardResult () {

                    @Override
                    public void onDone(String value) {
                        txtNumber2.setText (value.toUpperCase (Locale.ENGLISH));
                        if (!value.trim ().equals ("")) {
                            entry2 = value.trim ();
                            checkEnteredDetails ();
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("Account Number", "Account Number" + " cannot be empty", null);
                            txtNumber2.setDisable (false);
                            btnDetail.setDisable (true);
                        }
                    }
                });
//                }
            }
        });

        txtAmt = JKNode.getTextFieldRight ();
        txtAmt.setText ("");
        txtAmt.setDisable (false);
        txtAmt.setPromptText ("Enter Amount to Pay");
        txtAmt.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad ().showNumPad (true, txtAmt, "Enter Amount", "", new NumberPadResult () {

                    @Override
                    public void onDone(String value) {
                        amtPaid = SalesUtil.getAmountAsDouble (value, txtAmt);
                    }
                });
//                }
            }
        });

        btnDetail = JKNode.getBtnMsgBox ("show detail");
        btnDetail.setDisable (true);
        btnDetail.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (inputValidAmount ()) {
                    txtAmt.setDisable (true);
                    btnDetail.setDisable (true);
                    if (vbContent.getChildren ().contains (gridConfirm)) {
                        vbContent.getChildren ().remove (gridConfirm);
                        getAccountInfo ();
                    } else {
                        getAccountInfo ();
                    }
                }
            }
        });

        GridPane gridEnter = JKLayout.getContentGridInner2Col (0.5, 0.5, HPos.RIGHT);

        gridEnter.addRow (0, lblPaymentType, txtNumber);
        gridEnter.addRow (1, new Label (""), txtNumber2);
        gridEnter.addRow (2, lblAmount, txtAmt);
        gridEnter.add (btnDetail, 1, 3);
        gridEnter.addRow (4, JKNode.createGridSpanSep (2));

        return gridEnter;
    }

    private GridPane getViewAccountAndPaymentDetail() {

        final double amtConv = merchInfo.getConvenienceFee ();

        Label lblAccountNumber = JKText.getLblDk ("Merchant Account Number", JKText.FONT_B_XSM);
        Label lblAccountHolder = JKText.getLblDk ("Merchant Name", JKText.FONT_B_XSM);
        GridPane.setValignment (lblAccountHolder, VPos.TOP);
        Label lblAmount = JKText.getLblDk ("Amount", JKText.FONT_B_XSM);
        Label lblConvFee = JKText.getLblDk ("Convenience Fee", JKText.FONT_B_XSM);
        Label lblTotal = JKText.getLblDk ("Total Payable", JKText.FONT_B_XSM);

        Text txtAccountNumber = JKText.getTxtDk (merchInfo.getTransfereeAccount (), JKText.FONT_B_XSM);
        Text txtAccountHolder = JKText.getTxtDk (merchInfo.getTransfereeName (), JKText.FONT_B_XSM);
        txtAccountHolder.setTextAlignment (TextAlignment.RIGHT);
        txtAccountHolder.setWrappingWidth ((contentW - (2 * sp)) / 2);
        Text txtAmountPaid = JKText.getTxtDk ("R " + JKText.getDeciFormat (amtPaid), JKText.FONT_B_XSM);
        Text txtConvFee = JKText.getTxtDk ("R " + JKText.getDeciFormat (amtConv), JKText.FONT_B_XSM);
        final Text txtTotal = JKText.getTxtDk ("R " + JKText.getDeciFormat (merchInfo.getTotalAmount ()), JKText.FONT_B_SM);

        gridConfirm = JKLayout.getContentGridInner2Col (0.5, 0.5, HPos.RIGHT);

        gridConfirm.addRow (0, lblAccountNumber, txtAccountNumber);
        gridConfirm.addRow (1, lblAccountHolder, txtAccountHolder);
        gridConfirm.addRow (2, lblAmount, txtAmountPaid);
        gridConfirm.addRow (3, lblConvFee, txtConvFee);
        gridConfirm.addRow (5, lblTotal, txtTotal);
        gridConfirm.addRow (7, getTenderTypes ());

        return gridConfirm;
    }

    private JKTenderToggles getTenderTypes() {
        List<String> listTenders = new ArrayList<> ();

        List<String> listTendTmp = merchInfo.getTenderTypes ();
        if (!listTendTmp.isEmpty ()) {
            for (String s : listTendTmp) {
                listTenders.add (s.toLowerCase ().replaceAll (" ", ""));
            }
        }
        if (!listTenders.isEmpty ()) {
            tenders = new JKTenderToggles (SaleType.BILLPAYMENTS.getDisplay (), listTenders);
        } else {
            tenders = new JKTenderToggles (SaleType.BILLPAYMENTS.getDisplay ());
        }

        for (ToggleButton b : tenders.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event e) {

                    if (inputValidAmount ()) {
                        tendered = tenders.getTenderTypeSelected ();
                        showConfirmationSummary ();
                    } else {
                        tenders.resetTenderType ();
                    }
                }
            });
        }
        return tenders;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (vbContent.getChildren ().contains (gridEntry)) {
                    UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                    SceneSales.clearAndChangeContent (new BillPaymentMenu ());
                } else {
                    SceneSales.clearAndChangeContent (new InputM2M ());
                }
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                BillPayUtilMisc.resetBillPayView ();
            }
        });
        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private void showConfirmationSummary() {
        SummaryM2M summary = new SummaryM2M (merchInfo, amtPaid, tendered);

        JKiosk3.getMsgBox ().showMsgBox (BillPayUtilMisc.TYPE_M2M_TRANSFER, "Confirm all details before proceeding", summary,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {

                    @Override
                    public void onOk() {
                        getTransferConfirm ();
                    }

                    @Override
                    public void onCancel() {
                        UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                        BillPayUtilMisc.resetBillPayView ();
                    }
                });
    }

    //====================================
    // above - mostly view
    // below - mostly process
    //====================================
    private void getAccountInfo() {
        MerchantAccountInfoReq req = new MerchantAccountInfoReq ();
        req.setAccountNo (accountNumberConfirmed);
        req.setAmount (amtPaid);

        BillPayUtilMerchantTransfer.getAccountInfo (req, new BillPayUtilMerchantTransfer.MerchantAccountInfoResult () {
            @Override
            public void merchantAccountInfoResult(MerchantTransferConnection mtc, MerchantAccountInfoResp merchantInfoResult) {
                if (merchantInfoResult.isSuccess ()) {
                    connect = mtc;
                    merchInfo = merchantInfoResult;
                    if (amtPaid >= merchInfo.getMinAmount () && amtPaid <= merchInfo.getMaxAmount ()) {
                        gridConfirm = getViewAccountAndPaymentDetail ();
                        if (vbContent.getChildren ().contains (gridEntry)) {
                            vbContent.getChildren ().remove (gridEntry);
                            vbContent.getChildren ().add (1, gridConfirm);
                        } else {
                            vbContent.getChildren ().add (1, gridConfirm);
                        }
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("Amount to Pay", "Amount must be between\n\nR "
                                + JKText.getDeciFormat (merchInfo.getMinAmount ()) + "\n\nand\n\nR "
                                + JKText.getDeciFormat (merchInfo.getMaxAmount ()), null);
                        txtAmt.clear ();
                        txtAmt.setDisable (false);
                        btnDetail.setDisable (false);
                    }
                } else {
                    showFailedResult ("Unable to Confirm Account Details", (!merchantInfoResult.getAeonErrorText ().isEmpty () ?
                            "A" + merchantInfoResult.getAeonErrorCode () + " - " + merchantInfoResult.getAeonErrorText () :
                            "B" + merchantInfoResult.getErrorCode () + " - " + merchantInfoResult.getErrorText ()));

                    if (vbContent.getChildren ().contains (gridEntry)) {
                        vbContent.getChildren ().remove (gridEntry);
                        vbContent.getChildren ().add (1, getPaymentEntry ());
                    }
                }
            }
        });
    }

    private void getTransferConfirm() {
        final MerchantTransferConfirmReq reqConf = new MerchantTransferConfirmReq ();
        reqConf.setTrxId (merchInfo.getTransRef ());
        reqConf.setAccountNumber (merchInfo.getTransfereeAccount ());
        reqConf.setAmountDue (amtPaid);
        reqConf.setWantPrintJob (true);
        reqConf.setConfirmType ("commit");
        reqConf.setTenderType (tendered.toLowerCase (Locale.ENGLISH));

        BillPayUtilMerchantTransfer.getTransferConfirm (connect, reqConf, new BillPayUtilMerchantTransfer.MerchantTransferConfirmResult () {
            @Override
            public void merchantTransferConfirmResult(MerchantTransferConfirmResp transferConfirmResult) {
                if (transferConfirmResult.isSuccess ()) {
                    /* Handle this like a Bill Payment.  We need to record the tender type, etc. */
//                    SalesUtil.processMerchantTransfer(BillPayUtilMisc.BLU_M2M_TRANSFER, transferConfirmResult.getTransRef(),
                    SalesUtil.processMerchantTransfer (BPTransType.BILLPAY_BLU_M2M.getDisplayName (), transferConfirmResult.getTransRef (),
                            reqConf.getAccountNumber (), merchInfo.getTotalAmount (), tendered,
                            transferConfirmResult.getMerchantMessage () + "\n\n" + "Transfer submitted",
                            transferConfirmResult.getPrintLines (), transferConfirmResult.getMerchantPrintLines ());
                } else {
                    showFailedResult ("Payment Confirmation Failed",
                            (!transferConfirmResult.getAeonErrorText ().isEmpty () ?
                                    "A" + transferConfirmResult.getAeonErrorCode () + " - " + transferConfirmResult.getAeonErrorText () :
                                    "B" + transferConfirmResult.getErrorCode () + " - " + transferConfirmResult.getErrorText ()));
                }
                BillPayUtilMisc.resetBillPayView ();
            }
        });
    }

    private void showFailedResult(String head, String msg) {
        JKiosk3.getMsgBox ().showMsgBox (head, msg, null);
        String errorlog = head + "\n\t" + msg;
        logger.info (errorlog);
    }

    private boolean inputValidAmount() {
        if (txtAmt.getText ().trim ().equals ("") || txtAmt.getText ().trim ().equals ("0")) {
            JKiosk3.getMsgBox ().showMsgBox ("Amount to Pay", "Please enter a valid Amount", null);
            return false;
        }
        return true;
    }

    private void checkEnteredDetails() {
        if (entry2.equals (entry1)) {
            accountNumberConfirmed = entry1.toUpperCase (Locale.ENGLISH);
            if (inputValidAccount ()) {
                txtNumber.setVisible (true);
                txtNumber.setDisable (true);
                txtNumber2.setDisable (true);
                btnDetail.setDisable (false);
            }
        } else {
            accountNumberConfirmed = null;
            JKiosk3.getMsgBox ().showMsgBox ("Account Numbers entered do not match", entry1 + " - " + entry2, null);
            if (vbContent.getChildren ().contains (gridEntry)) {
                vbContent.getChildren ().remove (gridEntry);
                vbContent.getChildren ().add (1, getPaymentEntry ());
            }
        }
    }

    private boolean inputValidAccount() {
        if (accountNumberConfirmed.equals ("") || accountNumberConfirmed.isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Merchant To Merchant Transfer", "Account Number cannot be empty", null);
            return false;
        }
        return true;
    }
}
