package jkiosk3.sales.ticketpro.sale;

import aeonticketpros.TicketProsCart;
import aeonticketpros.TicketProsPriceCategory;
import aeonticketpros.TicketProsReserveSeatsReq;
import aeonticketpros.TicketProsReserveSeatsResp;
import aeonticketpros.TicketProsSeat;
import aeonticketpros.TicketProsSeatCategory;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;

import static jkiosk3._common.JKLayout.contentW;
import static jkiosk3._common.JKLayout.sp;

import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.ticketpro.TicketProMenu;
import jkiosk3.sales.ticketpro.TicketProSale;
import jkiosk3.sales.ticketpro.TicketProUtil;
import jkiosk3.store.JKOptions;
import jkiosk3.users.UserUtil;

public class TicketProTickets extends Region {

    private JKioskNav nav;
    private TicketProsCart cart;
    private List<TicketProsPriceCategory> listPriceCats;
    private Text txtTicketCount;
    private RadioButton radioYes;
    private RadioButton radioNo;
    private ComboBox comboSeatsPrices;
    private GridPane gridTicketTypes;
    private VBox vbTickets;
    private int ticketCount;
    private int tmpCount = 0;

    public TicketProTickets() {
        if (TicketProSale.getInstance ().getSaleCart () == null) {
            TicketProUtil.createTicketProCart (new TicketProUtil.TicketProCreateCartResult () {
                @Override
                public void tpCreateCartResult(TicketProsCart tpCreateCart) {
                    cart = tpCreateCart;
                    TicketProSale.getInstance ().setSaleCart (cart);
                }
            });
        } else {
            cart = TicketProSale.getInstance ().getSaleCart ();
        }
        if (TicketProSale.getInstance ().getSelectedSeats () == null
                || TicketProSale.getInstance ().getSelectedSeats ().isEmpty ()) {
            ticketCount = 0;
        } else {
            ticketCount = TicketProSale.getInstance ().getSelectedSeats ().size ();
        }
        getChildren ().add (getTicketsLayout ());
    }

    private VBox getTicketsLayout() {
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (getTicketsGroup ());
        vb.getChildren ().add (getNav ());
        return vb;
    }

    private JKioskNav getNav() {
        nav = new JKioskNav ();

        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(javafx.event.Event e) {
                TicketProSale.getInstance ().setSaleCart (null);
                SceneSales.clearAndChangeContent (new TicketProEvents (TicketProSale.getInstance ().getListEvents ()));
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(javafx.event.Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndShowFavourites ();
            }
        });
        nav.getBtnNext ().setText ("view\ncart");
        nav.getBtnNext ().setFont (JKText.FONT_B_14);
        nav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(javafx.event.Event e) {
                if (ticketCount > 0) {
                    SceneSales.clearAndChangeContent (new TicketProViewCart ());
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("View Cart", "No Tickets in Cart yet, please add Tickets", null);
                }
            }
        });
        return nav;
    }

    private VBox getTicketsGroup() {
        final List<TicketProsSeatCategory> listSeatCats = TicketProSale.getInstance ().getSelectedEventDetail ().getListSeatCategories ();

        vbTickets = JKLayout.getVBoxContent (JKLayout.sp);

        Label lblShowSeatCats = JKText.getLblDk ("Show Seat Categories for Event, if available", JKText.FONT_B_XXSM);
        Button btnShowSeatCats = JKNode.getBtnPopup ("show");
        btnShowSeatCats.setDisable (true);
        btnShowSeatCats.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                TicketProSeating seatDisplay = new TicketProSeating (listSeatCats);
                JKiosk3.getMsgBox ().showMsgBox (TicketProSale.getInstance ().getSelectedEvent ().getName (),
                        TicketProSale.getInstance ().getSelectedEventDetail ().getVenueName (), seatDisplay,
                        MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, null);
            }
        });
        HBox hbShow = JKLayout.getHBox (0, 0);
        hbShow.getChildren ().addAll (lblShowSeatCats, JKNode.getHSpacer (), btnShowSeatCats);

        Label lblScattered = JKText.getLblDk ("If seats cannot be found together, would you accept scattered seating?",
                JKText.FONT_B_XXSM);
        ToggleGroup togScattered = new ToggleGroup ();
        radioYes = new RadioButton ("Yes");
        radioYes.setToggleGroup (togScattered);
        radioNo = new RadioButton ("No");
        radioNo.setSelected (true);
        radioNo.setToggleGroup (togScattered);
        HBox hbScattered = JKLayout.getHBox (0, 0);
        hbScattered.getChildren ().addAll (JKNode.getHSpacer (), radioYes, JKNode.getHSpacer (), radioNo);

        ObservableList seatsAndPricing = FXCollections.observableArrayList (listSeatCats);

        Label lblSeatsPrices = JKText.getLblDk ("Seats/Pricing", JKText.FONT_B_XSM);
        comboSeatsPrices = new ComboBox (seatsAndPricing);
        comboSeatsPrices.setPrefWidth ((JKLayout.contentW - 2 * JKLayout.sp) * 0.75);
        comboSeatsPrices.getSelectionModel ().selectedItemProperty ().addListener (new ChangeListener () {
            @Override
            public void changed(ObservableValue ov, Object t, Object selected) {
                tmpCount = 0;
                if (selected != null) {
                    if (vbTickets.getChildren ().contains (gridTicketTypes)) {
                        vbTickets.getChildren ().remove (gridTicketTypes);
                        vbTickets.getChildren ().add (getPriceCategoriesForSelectedSeats ((TicketProsSeatCategory) selected));
                    } else {
                        vbTickets.getChildren ().add (getPriceCategoriesForSelectedSeats ((TicketProsSeatCategory) selected));
                    }
                }
            }
        });

        Label lblEvt = JKText.getLblContentHead ("Event - " + TicketProSale.getInstance ().getSelectedEvent ().getName ());
        Label lblTicket = JKText.getLblDk ("Choose Seating and Tickets", JKText.FONT_B_XSM);
        HBox hbChoose = JKLayout.getHBox (0, 0);
        hbChoose.getChildren ().addAll (lblTicket, JKNode.getHSpacer (), showTicketCount ());

        GridPane grid1 = JKLayout.getContentGridInner2Col (0.25, 0.75);
        grid1.add (lblScattered, 0, 0, 2, 1);
        grid1.addRow (1, new Label (""), hbScattered);
        grid1.addRow (2, lblSeatsPrices, comboSeatsPrices);

        vbTickets.getChildren ().addAll (lblEvt, hbChoose, JKNode.createContentSep ());
        vbTickets.getChildren ().add (grid1);

        return vbTickets;
    }

    private HBox showTicketCount() {
        txtTicketCount = JKText.getTxtDk (Integer.toString (ticketCount), JKText.FONT_B_XSM);
        Label lblTicketCount = JKText.getLblDk ("tickets currently in cart: ", JKText.FONT_B_XXSM);
        HBox hbViewCart = JKLayout.getHBox (0, 0);
        hbViewCart.getChildren ().addAll (lblTicketCount, txtTicketCount);
        return hbViewCart;
    }

    private GridPane getPriceCategoriesForSelectedSeats(TicketProsSeatCategory seatCategory) {
        List<TicketProsPriceCategory> displayPriceCats = seatCategory.getListPriceCategories ();
        listPriceCats = new ArrayList<> ();
        gridTicketTypes = getTicketPriceGrid ();
        int rowNum = 0;
        Label lblAdding = JKText.getLblDk ("Tickets to be added to cart: ", JKText.FONT_B_XXSM);
        final Text txtTotalTickets = JKText.getTxtDk (Integer.toString (tmpCount), JKText.FONT_B_XSM);
        final Button btnAdd = JKNode.getBtnPopup ("add");
        btnAdd.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (validateEntry ()) {
                    showScatteredSeatWarning ();
                }
            }
        });

        for (final TicketProsPriceCategory pc : displayPriceCats) {
            pc.setQuantity (0);
            // make a grid of ticket pricing
            Label lblPriceLabel = JKText.getLblDk (pc.getPriceLabel (), JKText.FONT_B_XSM);
            Label lblPrice = JKText.getLblDk (JKText.getDeciFormat (pc.getPrice ()), JKText.FONT_B_XSM);
            final TextField txtQty = new TextField ();
            txtQty.setAlignment (Pos.CENTER_RIGHT);
            txtQty.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event e) {
                    if (!txtQty.getText ().equals ("")) {
                        tmpCount -= Integer.parseInt (txtQty.getText ());
                        txtQty.setText ("");
                    }
                    if (!(JKOptions.getOptions ().isKeyboard ())) {
                        JKiosk3.getNumPad ().showNumPad (txtQty, "No. of Tickets", "", new NumberPadResult () {
                            @Override
                            public void onDone(String value) {
                                int addNum = getTicketCountEntered (txtQty, value);
                                pc.setQuantity (addNum);
                                txtTotalTickets.setText (Integer.toString (tmpCount += addNum));
                            }
                        });
                    } else {
                        txtQty.setOnAction (new EventHandler<ActionEvent> () {
                            @Override
                            public void handle(ActionEvent t) {
                                int addKey = getTicketCountEntered (txtQty, txtQty.getText ());
                                pc.setQuantity (addKey);
                                txtTotalTickets.setText (Integer.toString (tmpCount += addKey));
                                btnAdd.requestFocus ();
                            }
                        });
                    }
                }
            });
            listPriceCats.add (pc);

            gridTicketTypes.addRow (rowNum, lblPriceLabel, lblPrice, txtQty);
            rowNum++;
        }

        gridTicketTypes.add (JKNode.createGridSpanSep (4), 0, rowNum);
        gridTicketTypes.addRow (rowNum + 1, lblAdding, new Label (), txtTotalTickets, btnAdd);
        return gridTicketTypes;
    }

    private int getTicketCountEntered(TextField txtfld, String value) {
        int count = 0;
        try {
            count = Integer.parseInt (value);
            if (count > 0) {
                txtfld.setText (Integer.toString (count));
            } else {
                txtfld.setText ("");
            }
        } catch (NumberFormatException nfe) {
            txtfld.setText ("");
            JKiosk3.getMsgBox ().showMsgBox ("Number of Tickets", "Please enter a valid number of tickets", null);
        }
        return count;
    }

    private void showScatteredSeatWarning() {
        JKiosk3.getMsgBox ().showMsgBox ("ATTENTION", "Are you sure that you have booked the correct number of seats?"
                        + "\n\nPLEASE NOTE"
                        + "\n\nIf you need to book additional seats later, they may not be adjacent to the seats you are booking now!"
                        + "\n\nTo confirm current selection, click OK."
                        + "\n\nTo change selected seat counts, click Cancel.",
                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {

                    @Override
                    public void onOk() {
                        reserveSeats ();
                    }

                    @Override
                    public void onCancel() {
                        //
                    }
                });
    }

    private GridPane getTicketPriceGrid() {
        GridPane grid = new GridPane ();
        double width = (contentW - (4 * sp));
        double colCalcWidth = width - (3 * JKLayout.sp);
        grid.setMaxWidth (width);
        grid.setMinWidth (width);
        grid.getStyleClass ().add ("gridInner");
        grid.setStyle ("-fx-hgap: 15px;");

        ColumnConstraints col0 = new ColumnConstraints ();
        col0.setMaxWidth (colCalcWidth * 0.45);
        col0.setMinWidth (colCalcWidth * 0.45);
        col0.setHalignment (HPos.LEFT);
        ColumnConstraints col1 = new ColumnConstraints ();
        col1.setMaxWidth (colCalcWidth * 0.25);
        col1.setMinWidth (colCalcWidth * 0.25);
        col1.setHalignment (HPos.RIGHT);
        ColumnConstraints col2 = new ColumnConstraints ();
        col2.setMaxWidth (colCalcWidth * 0.15);
        col2.setMinWidth (colCalcWidth * 0.15);
        col2.setHalignment (HPos.RIGHT);
        ColumnConstraints col3 = new ColumnConstraints ();
        col3.setMaxWidth (colCalcWidth * 0.15);
        col3.setMinWidth (colCalcWidth * 0.15);
        col3.setHalignment (HPos.RIGHT);

        grid.getColumnConstraints ().addAll (col0, col1, col2, col3);

        return grid;
    }

    private boolean validateEntry() {

        if (radioYes.isSelected ()) {
            TicketProSale.getInstance ().setScatteredSeats (true);
        } else if (radioNo.isSelected ()) {
            TicketProSale.getInstance ().setScatteredSeats (false);
        }

        if (comboSeatsPrices.getSelectionModel ().getSelectedItem () == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Seats/Pricing", "Please select a Seat category", null);
            return false;
        } else {
            TicketProSale.getInstance ().setSelectedSeatCategory (
                    (TicketProsSeatCategory) comboSeatsPrices.getSelectionModel ().getSelectedItem ());
        }

        // check number entry and add to 'listPriceCats' here
        List<TicketProsPriceCategory> selectedPriceCats = new ArrayList<> ();
        for (TicketProsPriceCategory p : listPriceCats) {
            if (p.getQuantity () > 0) {
                selectedPriceCats.add (p);
            }
        }
        if (selectedPriceCats.isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Tickets", "Please enter number of Tickets required", null);
            return false;
        } else {
            TicketProSale.getInstance ().setSelectedPriceCategories (selectedPriceCats);
        }

        return true;
    }

    private void reserveSeats() {

        TicketProSale.getInstance ().setSelectedSeats (new ArrayList<TicketProsSeat> ());

        TicketProsReserveSeatsReq req = new TicketProsReserveSeatsReq ();

        req.setCartId (cart.getCartId ());
        req.setEventId (TicketProSale.getInstance ().getSelectedEvent ().getEventId ());
        req.setSeatCategoryId (TicketProSale.getInstance ().getSelectedSeatCategory ().getSeatCategoryId ());
        req.setScattered (TicketProSale.getInstance ().isScatteredSeats ());
        req.setListPriceCategories (TicketProSale.getInstance ().getSelectedPriceCategories ());

        TicketProUtil.reserveTicketProSeats (req, new TicketProUtil.TicketProReserveSeatsResult () {
            @Override
            public void tpReserveSeatsResult(TicketProsReserveSeatsResp tpReserveSeats) {
                if (tpReserveSeats.isSuccess ()) {
                    nav.getBtnBack ().setDisable (true);
                    TicketProSale.getInstance ().setReservedSeats (tpReserveSeats);
                    TicketProSale.getInstance ().getSelectedSeats ().addAll (tpReserveSeats.getListSeats ());
                    resetAndUpdateView ();
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Reserve Seats Error",
                            !tpReserveSeats.getAeonErrorText ().isEmpty () ?
                                    "A" + tpReserveSeats.getAeonErrorCode () + " - " + tpReserveSeats.getAeonErrorText () :
                                    "B" + tpReserveSeats.getErrorCode () + " - " + tpReserveSeats.getErrorText (), null);
                }
            }
        });
    }

    private void resetAndUpdateView() {
        comboSeatsPrices.getSelectionModel ().clearSelection ();
        vbTickets.getChildren ().remove (gridTicketTypes);
        ticketCount = TicketProSale.getInstance ().getReservedSeats ().getListSeats ().size ();
        txtTicketCount.setText (Integer.toString (ticketCount));
//        lblSeatsAvailable.setText("/ 00");
    }
}
