package jkiosk3.printing.print_layouts;

import aeoncoach.CoachCarrier;
import aeoncoach.CoachReserveResp;
import aeoncoach.CoachTicket;
import aeonprinting.AeonPrintJob;
import jkiosk3._common.JKText;
import jkiosk3.printing.BarcodeHandler;
import jkiosk3.sales._bus_carriers.CoachCarrierLayouts;
import jkiosk3.store.cache.CacheListCoachCarriers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

public class PrintCoachTicket {

    private final static Logger logger = Logger.getLogger(PrintCoachTicket.class.getName());

    /**
     * Private Constructor created to hide implicit public one.
     */
    private PrintCoachTicket() {
    }

    public static AeonPrintJob getCoachTicketPrint(CoachReserveResp response, CoachTicket ticket) {
        final String PRINT_LAYOUT = "%-15s" + "%-1s" + "%19s";
        final String PRINT_LAYOUT_CONTENT = "%-14s" + "%-1s" + "%20s";

        String logoCode = "0";
        String webSite = "";
        String callCentre = "";
        String barcodeType = "";

        CoachCarrier selected = null;
        List<CoachCarrier> listCarrierData = CacheListCoachCarriers.getListCoachCarriers().getListCarriers();
        if (!listCarrierData.isEmpty()) {
            for (CoachCarrier c : listCarrierData) {
                if (ticket.getCarrier().equalsIgnoreCase(c.getCarrierName()) || ticket.getCarrier().equalsIgnoreCase(c.getCarrierCode())) {
                    selected = c;
                    break;
                }
            }
        }

        // image to print on ticket
//        String localFile = getTicketLogoPath(selected);
        String localFile = CoachCarrierLayouts.getCarrierLogoPath(selected, true);

        if (selected != null) {
            logoCode = selected.getCarrierCode();
            webSite = selected.getCarrierWebsite();
            callCentre = selected.getCarrierCallCentre();
            barcodeType = selected.getCarrierBarcodeType();
        } else {
            logoCode = "0";
            webSite = "not available";
            callCentre = "not available";
            barcodeType = "128B";
        }

        AeonPrintJob apj = new AeonPrintJob();
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy HH:mm");

        if (localFile == null) {
            apj.addLogo(logoCode);
        } else {
            apj.addHeaderImage(localFile);
        }

        apj.addBreak();
        apj.addCentreBold("Coach Ticket");
        apj.addCentre("");

        if (ticket.getTicketHeader() != null) {
            List<String> wrapTicketHead = apj.wordWrap(ticket.getTicketHeader(), 36);
            for (int i = 0; i < wrapTicketHead.size(); i++) {
                apj.addCentre(wrapTicketHead.get(i));
            }
            apj.addCentre("");
        }

        apj.addCentre(String.format(PRINT_LAYOUT, "Carrier", ":", selected.getCarrierDescription()));

        if (!ticket.getServiceNumber().isEmpty()) {
            apj.addCentre(String.format(PRINT_LAYOUT, "Service Number", ":", ticket.getServiceNumber()));
        }

        apj.addCentre(String.format(PRINT_LAYOUT, "Passenger Class", ":", ticket.getTravelClass()));
        apj.addCentre(String.format(PRINT_LAYOUT, "Ticket Amount", ":", JKText.getDeciFormat(ticket.getAmount())));
        apj.addCentre(String.format(PRINT_LAYOUT, "Issue Date", ":", sdf.format(new Date())));
        apj.addBreak();

        apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, "Ticket Number", ":", ticket.getTicketNumber()));
        apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, "Transaction ID", ":", response.getReference()));
        //
        String boardText = ticket.getBoardLocation();
        if (ticket.getBoardLocation().isEmpty()) {
            boardText = ticket.getBoardCity();
        }
        if (boardText.length() > 19) {
            List<String> wrapBoardLoc = apj.wordWrap(boardText, 19);
            for (int i = 0; i < wrapBoardLoc.size(); i++) {
                if (i == 0) {
                    apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, "Boarding At", ":", wrapBoardLoc.get(i)));
                } else {
                    apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, " ", ":", wrapBoardLoc.get(i)));
                }
            }
        } else {
            apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, "Boarding At", ":", boardText));
        }
        //
        String destText = ticket.getDestLocation();
        if (ticket.getDestLocation().isEmpty()) {
            destText = ticket.getDestCity();
        }
        if (destText.length() > 19) {
            List<String> wrapDestLoc = apj.wordWrap(destText, 19);
            for (int i = 0; i < wrapDestLoc.size(); i++) {
                if (i == 0) {
                    apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, "Destination", ":", wrapDestLoc.get(i)));
                } else {
                    apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, " ", ":", wrapDestLoc.get(i)));
                }
            }
        } else {
            apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, "Destination", ":", destText));
        }

        apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, "Boarding Time", ":", sdf.format(ticket.getBoardTime())));

        apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, "Arrival Time", ":", sdf.format(ticket.getArrivalTime())));

        if (!ticket.getPassenger().getTitle().isEmpty()) {
            apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, "Title", ":", ticket.getPassenger().getTitle()));
        }
        String fullname = ticket.getPassenger().getInitials() + " " + ticket.getPassenger().getLastName();
        apj.addCentre(String.format(PRINT_LAYOUT_CONTENT, "Name", ":", fullname.trim()));

        apj.addBreak();

        BarcodeHandler bh = new BarcodeHandler();
        switch (barcodeType) {
            case "128A":
            case "128B":
                apj.addBarcode128B(ticket.getBarcode());
                break;
            case "128B-special":
                String barcodePreProcess = bh.processBarcode128B(ticket.getBarcode());
                apj.addBarcode128B(barcodePreProcess);
                break;
            default:
                break;
        }

        apj.addCentre("");

        apj.addCentre("KEEP YOUR TICKET SAFE");
        apj.addCentre("");

        if (ticket.getTicketFooter() != null) {
            List<String> wrapTicketFoot = apj.wordWrap(ticket.getTicketFooter(), 36);
            for (int i = 0; i < wrapTicketFoot.size(); i++) {
                apj.addCentre(wrapTicketFoot.get(i));
            }
            apj.addCentre("");
        }

        apj.addCentre("For enquiries and cancellations");
        apj.addCentre("please contact");
        apj.addCentre(callCentre);

        apj.addCentre("");

        apj.addCentre("For Terms and Conditions, visit");
        apj.addCentre(webSite);
        apj.addBreak();

        apj.addCentre("");
        apj.addCentreBold("- Print Done -");

        return apj;
    }

    // MOVED to CoachCarrierLayouts, consolidated with method to get Carrier image for Routes.
    //
//    private static String getTicketLogoPath(CoachCarrier selectedCarrier) {
//        String localImgPath = null;
//
//        try {
//            File imgFile = new File(JK3Config.getImagesTemp() + selectedCarrier.getCarrierCode() + ".gif");
//
//            if (imgFile != null) {
//
//                long timeFile = imgFile.lastModified();
//                long timeNow = System.currentTimeMillis();
//                long timeExp = timeNow - timeFile;
//                long timeDiff = 1000L * 60L * 60L * 24L;   // millis/sec * sec/min * min/hr * hr/day;
//                //        long timeDiff = 1000L * 60L * 5L;   // testing - 5min
//                if (imgFile.exists() && (timeExp < timeDiff)) {
//                    localImgPath = imgFile.getName();
//                } else {
//                    localImgPath = getDownloadedTicketLogo(selectedCarrier);
//                }
//            } else {
//                localImgPath = getDownloadedTicketLogo(selectedCarrier);
//            }
//
//        } catch (IllegalArgumentException e) {
//            localImgPath = getDownloadedTicketLogo(selectedCarrier);
//        }
//        return localImgPath;
//    }
//
//    private static String getDownloadedTicketLogo(CoachCarrier carrier) {
//        String updatedImg = null;
//
//        ImageHandler ih = new ImageHandler();
//        String imgUrl = CacheListCoachCarriers.getListCoachCarriers().getMediaUrl() + carrier.getCarrierCode() + ".gif";
//        updatedImg = ih.getHeaderImagePathCoach(imgUrl);
//
//        return updatedImg;
//    }
}
