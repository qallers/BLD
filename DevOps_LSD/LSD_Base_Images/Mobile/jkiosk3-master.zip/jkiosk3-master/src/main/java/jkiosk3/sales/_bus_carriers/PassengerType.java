package jkiosk3.sales._bus_carriers;

import aeoncoach.CoachCarrier;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum  PassengerType {

//    ADULT("A", "Adult"),
//    CHILD("C", "Child"),
//    INFANT("I", "Infant");
//
//    private final String code;
//    private final String name;
//    private List<PassengerType> listPassengerTypes = new ArrayList<>();
//
//    private PassengerType(String code, String name) {
//        this.code = code;
//        this.name = name;
//    }
//
//    public static PassengerType byName(String name) {
//        for (PassengerType value : values()) {
//            if (value.name().equalsIgnoreCase(name)) return value;
//        }
//        throw new IllegalArgumentException(String.format("Name %s not found", name));
//    }
//
//    public static PassengerType byCode(String code) {
//        for (PassengerType value : values()) {
//            if (value.code.equalsIgnoreCase(code)) return value;
//        }
//        throw new IllegalArgumentException(String.format("Code %s not found", code));
//    }
//
//    @Override
//    public String toString() {
//        return getName();
//    }
//
//    public String getCode() {
//        return code;
//    }
//
//    public String getCode(CoachCarrier carrier) {
//        if (carrier.getCarrierCode().equalsIgnoreCase("IM")) {
//            return name(); // INFANT, CHILD, etc
//        }
//        return code;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public static List<PassengerType> getListPassengerTypes() {
//        List<PassengerType> listPassengerTypes = Arrays.asList(PassengerType.values());
//        return listPassengerTypes;
//    }
}
