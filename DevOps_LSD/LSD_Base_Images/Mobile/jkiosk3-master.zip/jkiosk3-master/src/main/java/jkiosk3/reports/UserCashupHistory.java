package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.Shift;
import aeonreports.ShiftUsers;
import aeonusers.User;
import java.util.List;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.PrintHandler;

/**
 *
 * @author valeriew
 */
public class UserCashupHistory extends Region {

    private final static Logger LOG = Logger.getLogger(ShiftView.class.getName());
    private ComboBox comShift;
    private ComboBox comUsers;
    private List<Shift> listShifts;
    private int shiftId;
    private int userId;

    public UserCashupHistory() {
        ReportUtil.getShiftListUserHistory(new ReportUtil.ShiftListHistoryResult() {

            @Override
            public void shiftListHistoryResult(List<Shift> shiftListHistoryResult) {
                if (!shiftListHistoryResult.isEmpty()) {
                    listShifts = shiftListHistoryResult;
                    VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

                    vb.getChildren().add(getCashupHistory());
                    vb.getChildren().add(getPrintControl());

                    getChildren().addAll(vb);
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Shift List", "No Shift Details Available", null);
                }
            }
        });
    }

    private VBox getCashupHistory() {

        VBox vbHead = JKNode.getPageHeadVB("View Cashup History");

        Label lblShift = JKText.getLblDk("Select Shift", JKText.FONT_B_XSM);

        Label lblUsers = JKText.getLblDk("Select User", JKText.FONT_B_XSM);

        comShift = new ComboBox();
        comShift.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.75), 35);
        ObservableList<Shift> observeShifts = FXCollections.observableArrayList(listShifts);
        comShift.setItems(observeShifts);
        comShift.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object oldShift, Object newShift) {
                if (newShift != null) {
                    shiftId = ((Shift) newShift).getShiftId();
                    getUsersForSelectedShift(shiftId);
                }
            }
        });

        comUsers = new ComboBox();
        comUsers.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.75), 35);
        comUsers.setDisable(true);
        comUsers.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue v1, Object user1, Object user2) {
                if (user2 != null) {
                    userId = ((User) user2).getUserId();
                }
            }
        });

        GridPane grid = JKLayout.getContentGridInner2Col(0.25, 0.75);

        grid.addRow(0, lblShift, comShift);
        grid.addRow(1, lblUsers, comUsers);

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, grid);

        return vb;
    }

    private void getUsersForSelectedShift(int shiftId) {
        ReportUtil.getUsersOnShift(shiftId, new ReportUtil.ShiftUsersResult() {

            @Override
            public void shiftUsersResult(ShiftUsers shiftUsersResult) {
                if (shiftUsersResult.isSuccess()) {
                    if (!shiftUsersResult.getListUsers().isEmpty()) {
                        ObservableList<User> observeUsers = FXCollections.observableArrayList(shiftUsersResult.getListUsers());
                        comUsers.setDisable(false);
                        comUsers.setItems(observeUsers);
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Users for Selected Shift", "No Users found for selected Shift.\n"
                                + "Please select a different Shift", null);
                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Shift Users", "Failed to Retrieve Users for Selected Shift\n\n"
                            + shiftUsersResult.getErrorCode() + " - " + shiftUsersResult.getErrorText(), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    SceneReports.clearAndChangeContent(new ShiftMenu());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                LOG.info(("HISTORY : Selected Shift - ").concat(Integer.toString(shiftId))
                        .concat(" ; Selected User ID - ").concat(Integer.toString(userId)));
                ReportUtil.getCashupReportHistory(shiftId, userId, new ReportUtil.AeonPrintJobResult() {

                    @Override
                    public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                        PrintHandler.handlePrintRequestReport("Print Cashup History", aeonPrintJob);
                        int n = SceneReports.getVbReportContent().getChildren().size();
                        if (n > 2) {
                            SceneReports.getVbReportContent().getChildren().remove(2, n);
                        }
                    }
                });
            }
        };
    }
}
