package jkiosk3.utilities;

import com.jmethod.jdlite.JDException;
import com.jmethod.jdlite.JDial;

/**
 *
 * @author Val
 */
public class DialupConnection {

    private JDial jDial;
    private static DialupConnection singletonObject;

    private DialupConnection() {
        try {
            jDial = new JDial();
        } catch (JDException e) {
            e.printStackTrace();
        }
    }

    public static synchronized DialupConnection getInstance() {
        if (singletonObject == null) {
            singletonObject = new DialupConnection();
        }

        return singletonObject;
    }

    public synchronized boolean isConnected(final String connectionName) {
        return jDial.entryIsActive(connectionName);
    }

    public synchronized boolean startConnection(final String connectionName) {
        boolean result = false;

        if (jDial != null) {
            int resultCode = jDial.dialAsync(connectionName);

            switch (resultCode) {
                case JDial.EST_CONNECTION:
                    System.out.println("Connection established.");
                    result = true;
                    break;
                case JDial.BAD_CONNECTION:
                    System.out.println("Bad connection.");
                    break;
                case JDial.ENTRY_IS_ACTIVE:
                    System.out.println("Already activated.");
                    result = true;
                    break;
                case JDial.ENTRY_IS_DIALING:
                    System.out.println("Is dialing");
                    break;
                case JDial.NO_SUCH_ENTRY:
                    System.out.println("No such entry");
                    break;
                default:
                    System.out.println("Unknown result");
            }
        }

        return result;
    }

    public synchronized boolean closeConnection(final String connectionName) {
        return jDial.hangUp(connectionName);
    }
}
