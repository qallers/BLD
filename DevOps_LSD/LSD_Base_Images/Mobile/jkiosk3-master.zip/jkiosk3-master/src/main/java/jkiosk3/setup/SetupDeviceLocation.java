package jkiosk3.setup;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.StageComponents;
import jkiosk3.store.JKDevLocation;
import jkiosk3.store.JKSystem;

import java.text.SimpleDateFormat;
import java.util.logging.Logger;


public class SetupDeviceLocation extends Region {

    private final static Logger logger = Logger.getLogger(SetupDeviceLocation.class.getSimpleName());

    private final static String ADD_ADVICE = "address will be filled in here";
    private final static String LATLNG_ADVICE = "[lat, lng]";
    private Text txtAddressSelected;
    private Text txtDeviceLatitude;
    private Text txtDeviceLongitude;
    private Text txtLatLng;
    private String deviceAddress;
    private String deviceLatLng;
    private String deviceLatitude;
    private String deviceLongitude;
    private long dateSaved;

    public SetupDeviceLocation() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getLocationLayout());
        vb.getChildren().add(getControls());

        getChildren().add(vb);
    }

    private GridPane getLocationLayout() {

        VBox vbHead = JKNode.getPageHeadVB("Device Location");

        Label lblShowMap = JKText.getLblDk("Click to show map", JKText.FONT_B_XSM);

        Label lblAddressSelected = JKText.getLblDk("Address Selected", JKText.FONT_B_XSM);
        GridPane.setValignment(lblAddressSelected, VPos.TOP);

        Label lblConfirm = JKText.getLblDk("'Save' if the address shown is correct, or open the map to retry.  Zoom in closer if necessary.", JKText.FONT_B_18);
        lblConfirm.setWrapText(true);
        Label lblNote = JKText.getLblDk("Please note that Google Maps might not be able to determine the EXACT address.", JKText.FONT_B_XXSM);
        lblNote.setWrapText(true);

        Button btnShowMap = JKNode.getBtnPopup("show");

        txtAddressSelected = JKText.getTxtDk(ADD_ADVICE, JKText.FONT_B_18);
        txtAddressSelected.setTextAlignment(TextAlignment.RIGHT);
        txtAddressSelected.setWrappingWidth((JKLayout.contentW - (3 * JKLayout.sp)) * 0.65);

        txtDeviceLatitude = JKText.getTxtDk("", JKText.FONT_B_15);
        txtDeviceLongitude = JKText.getTxtDk("", JKText.FONT_B_15);

        txtLatLng = JKText.getTxtDk(LATLNG_ADVICE, JKText.FONT_B_15);

        if (JKDevLocation.getDeviceLocation().getDeviceAddress() != null) {
            txtAddressSelected.setText(JKDevLocation.getDeviceLocation().getDeviceAddress());
            txtLatLng.setText(JKDevLocation.getDeviceLocation().getDeviceLatLng());
        }

        btnShowMap.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StageComponents.showMapSelectStage(txtAddressSelected, txtLatLng, txtDeviceLatitude, txtDeviceLongitude);
            }
        });

        GridPane grid = JKLayout.getGridContent2Col(0.33, 0.67, HPos.RIGHT);

        grid.add(vbHead, 0, 0, 2, 1);
        grid.addRow(1, lblShowMap, btnShowMap);
        grid.addRow(3, lblAddressSelected, txtAddressSelected);
        grid.add(txtLatLng, 1, 4);
        grid.add(lblConfirm, 0, 7, 2, 1);
        grid.add(lblNote, 0, 9, 2, 1);
        return grid;
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("", false) {
            @Override
            public void onClickTest() {
                //
            }

            @Override
            public void onClickSave() {
                if (isValidEntry()) {
                    dateSaved = System.currentTimeMillis();
                    saveDeviceLocation();
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Location Error", "All details have not been set.  Please try again.", null);
                }
            }
        };
    }

    private void saveDeviceLocation() {
        JKDevLocation.getDeviceLocation().setDeviceAddress(deviceAddress);
        JKDevLocation.getDeviceLocation().setDeviceLatLng(deviceLatLng);
        JKDevLocation.getDeviceLocation().setDeviceLatitude(deviceLatitude);
        JKDevLocation.getDeviceLocation().setDeviceLongitude(deviceLongitude);
        JKDevLocation.getDeviceLocation().setDateAndTimeSet(dateSaved);

        if (JKDevLocation.saveDeviceLocation()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Device Location saved successfully", null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK,
                    new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            logDeviceLocation();
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Device Location not saved", null);
        }
    }

    private void logDeviceLocation() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        StringBuilder sb = new StringBuilder("\r\n");
        sb.append("Device ID        : ").append(JKSystem.getSystemConfig().getDeviceId()).append("\r\n");
        sb.append("Device Address   : ").append(JKDevLocation.getDeviceLocation().getDeviceAddress()).append("\r\n");
        sb.append("Device Lat-Lng   : ").append(JKDevLocation.getDeviceLocation().getDeviceLatLng()).append("\r\n");
        sb.append("Device Latitude  : ").append(JKDevLocation.getDeviceLocation().getDeviceLatitude()).append("\r\n");
        sb.append("Device Longitude : ").append(JKDevLocation.getDeviceLocation().getDeviceLongitude()).append("\r\n");
        sb.append("Date saved       : ").append(sdf.format(JKDevLocation.getDeviceLocation().getDateAndTimeSet())).append("\r\n");
        sb.append("XML tag content  : ").append(JKDevLocation.getDeviceLocation().getFormattedLocation()).append("\r\n");
        sb.append("----------------------------------");
        logger.info(sb.toString());
    }

    private boolean isValidEntry() {
        if (!txtAddressSelected.getText().isEmpty() && !txtAddressSelected.getText().equalsIgnoreCase(ADD_ADVICE)) {
            deviceAddress = txtAddressSelected.getText();
        } else {
            return false;
        }
        if (!txtLatLng.getText().isEmpty() && !txtLatLng.getText().equalsIgnoreCase(LATLNG_ADVICE)) {
            deviceLatLng = txtLatLng.getText();
        } else {
            return false;
        }
        if (!txtDeviceLatitude.getText().isEmpty() && !txtDeviceLatitude.getText().equals("")) {
            deviceLatitude = txtDeviceLatitude.getText();
        } else {
            return false;
        }
        if (!txtDeviceLongitude.getText().isEmpty() && !txtDeviceLongitude.getText().equals("")) {
            deviceLongitude = txtDeviceLongitude.getText();
        } else {
            return false;
        }
        return true;
    }
}
