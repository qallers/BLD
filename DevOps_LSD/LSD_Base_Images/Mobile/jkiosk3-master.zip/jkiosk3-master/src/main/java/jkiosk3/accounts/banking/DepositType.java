package jkiosk3.accounts.banking;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Valerie
 */
public class DepositType {

    private String type;
    private List<Bank> listBanks = new ArrayList<>();

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Bank> getListBanks() {
        return listBanks;
    }

    public void setListBanks(List<Bank> listBanks) {
        this.listBanks = listBanks;
    }
}
