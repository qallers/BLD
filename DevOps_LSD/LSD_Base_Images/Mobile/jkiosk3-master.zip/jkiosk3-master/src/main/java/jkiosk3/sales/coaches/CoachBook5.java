package jkiosk3.sales.coaches;

import aeoncoach.CoachPassenger;
import aeoncoach.CoachReserveReq;
import aeoncoach.CoachReserveResp;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.TicketingMenu;
import jkiosk3.sales._bus_carriers.CoachCarrierLayouts;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.users.UserUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import static jkiosk3.sales._bus_carriers.CoachCarrierLayouts.getGridTripsSelected;
import static jkiosk3.sales._bus_carriers.CoachCarrierLayouts.gridCoach;

public class CoachBook5 extends Region {

    private final static Logger logger = Logger.getLogger (CoachBook5.class.getName ());

    private double costDepartAdult = 0.0D;
    private double costDepartChild = 0.0D;
    private double costDepartInfant = 0.0D;
    private double costDepartTotal = 0.0D;
    private double costReturnAdult = 0.0D;
    private double costReturnChild = 0.0D;
    private double costReturnInfant = 0.0D;
    private double costReturnTotal = 0.0D;

    public CoachBook5() {

        try {
            if (CoachTicketSale.getInstance ().getRouteDepart ().getPriceAdult () != null) {
                costDepartAdult = Double.parseDouble (CoachTicketSale.getInstance ().getRouteDepart ().getPriceAdult ());
            }
            if (CoachTicketSale.getInstance ().getRouteDepart ().getPriceChild () != null) {
                costDepartChild = Double.parseDouble (CoachTicketSale.getInstance ().getRouteDepart ().getPriceChild ());
            } else {
                costDepartChild = costDepartAdult;
            }
            if (CoachTicketSale.getInstance ().getRouteDepart ().getPriceInfant () != null) {
                costDepartInfant = Double.parseDouble (CoachTicketSale.getInstance ().getRouteDepart ().getPriceInfant ());
            } else {
                costDepartInfant = costDepartAdult;
            }
            costDepartTotal = (CoachTicketSale.getInstance ().getSeats () * costDepartAdult);

            if (CoachTicketSale.getInstance ().isReturnTrip ()) {
                if (CoachTicketSale.getInstance ().getRouteReturn ().getPriceAdult () != null) {
                    costReturnAdult = Double.parseDouble (CoachTicketSale.getInstance ().getRouteReturn ().getPriceAdult ());
                }
                if (CoachTicketSale.getInstance ().getRouteReturn ().getPriceChild () != null) {
                    costReturnChild = Double.parseDouble (CoachTicketSale.getInstance ().getRouteReturn ().getPriceChild ());
                } else {
                    costReturnChild = costReturnAdult;
                }
                if (CoachTicketSale.getInstance ().getRouteReturn ().getPriceInfant () != null) {
                    costReturnInfant = Double.parseDouble (CoachTicketSale.getInstance ().getRouteReturn ().getPriceInfant ());
                } else {
                    costReturnInfant = costReturnAdult;
                }
                costReturnTotal = (CoachTicketSale.getInstance ().getSeats () * costReturnAdult);
            }
        } catch (NumberFormatException nfe) {
            logger.log (Level.SEVERE, nfe.getMessage (), nfe);
        }

        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().addAll (showCoachTicketBookStep5 (), getNav ());
        getChildren ().add (vb);
    }

    private GridPane showCoachTicketBookStep5() {

        double transX = (JKLayout.sp + (JKLayout.sp / 2));

        Label lblHead1 = JKText.getLblDk (CoachUtil.COACH_PG_HEAD, JKText.FONT_B_24);
        Label lblHead2 = JKText.getLblDk ("Travel Summary", JKText.FONT_B_22);

        VBox vbHead = JKNode.getPageDblHeadVB (0, lblHead1, lblHead2);

        GridPane gridTrip = getGridTripsSelected ();

        Label lblPriceInfo = JKText.getLblDk ("If costs for 'Child' and 'Infant' are not available, 'Adult' cost will be shown. "
                + "Please note that 'Total' may be different at Checkout to that shown below.", JKText.FONT_B_15);
        lblPriceInfo.setWrapText (true);
        lblPriceInfo.setStyle ("-fx-padding: 0px;");

        Label lblDepart = JKText.getLblDk ("Departure", JKText.FONT_B_22);

        Label lblTotal = JKText.getLblDk ("Estimated Total", JKText.FONT_B_22);
        GridPane.setHalignment (lblTotal, HPos.RIGHT);

        double costTotal = 0;
        if (CoachTicketSale.getInstance ().isReturnTrip ()) {
            costTotal = costDepartTotal + costReturnTotal;
        } else {
            costTotal = costDepartTotal;
        }

        Text txtTotal = JKText.getTxtDk ("R " + JKText.getDeciFormat (costTotal), JKText.FONT_B_22);
        GridPane.setHalignment (txtTotal, HPos.RIGHT);

        GridPane grid = JKLayout.getGridContent2ColFixedHt (0.50, 0.50, CoachCarrierLayouts.COACH_PG_HT);
        grid.setStyle ("-fx-vgap: 5px;");

        grid.add (vbHead, 0, 0, 2, 1);
        grid.add (gridTrip, 0, 1, 2, 1);
        grid.add (lblPriceInfo, 0, 2, 2, 1);
        grid.add (lblDepart, 0, 3, 2, 1);
        grid.addRow (4, getGridPassengers (CoachUtil.TRIP_DEPART));
        grid.addRow (5, JKNode.createGridSpanSep (2));
        if (CoachTicketSale.getInstance ().isReturnTrip ()) {
            Label lblReturn = JKText.getLblDk ("Return", JKText.FONT_B_22);
            grid.add (lblReturn, 0, 6, 2, 1);
            grid.addRow (7, getGridPassengers (CoachUtil.TRIP_RETURN));
            grid.addRow (8, JKNode.createGridSpanSep (2));
            grid.addRow (9, lblTotal, txtTotal);
        } else {
            grid.addRow (6, lblTotal, txtTotal);
        }

        return grid;
    }

    private GridPane getGridPassengers(String departOrReturn) {
        List<CoachPassenger> listPassengers = CoachTicketSale.getInstance ().getListPassengers ();
        Collections.sort (listPassengers, new Comparator<CoachPassenger> () {
            @Override
            public int compare(CoachPassenger o1, CoachPassenger o2) {
                return o1.getPassengerType ().getName ().compareTo (o2.getPassengerType ().getName ());
            }
        });
        GridPane gridPass = JKLayout.getGridPane4Col (gridCoach, 0.10, 0.40, 0.20, 0.30, 2, HPos.LEFT);
        gridPass.setVgap (JKLayout.spNum);

        int rowCount = 0;
        for (CoachPassenger b : listPassengers) {
            Label lblPassName = JKText.getLblDk (b.toString (), JKText.FONT_B_18);
            lblPassName.setTranslateX (2 * JKLayout.sp);
            gridPass.add (lblPassName, 0, rowCount, 2, 1);

            Text txtType = JKText.getTxtDk (b.getPassengerTypeCode (), JKText.FONT_B_XXSM);
            if (b.isInfant ()) {
                txtType.setText (b.getPassengerTypeCode () + " + " + "I");
            }

            gridPass.add (txtType, 2, rowCount);
            Text txtCost = JKText.getTxtDk ("n/a", JKText.FONT_B_18);

            switch (departOrReturn) {
                case CoachUtil.TRIP_DEPART:
                    if (b.getPassengerType ().getName ().equals ("ADULT")) {
                        txtCost.setText (JKText.getDeciFormat (costDepartAdult));
                    }
                    if (b.getPassengerType ().getName ().equals ("CHILD")) {
                        txtCost.setText (JKText.getDeciFormat (costDepartChild));
                    }
                    if (b.getPassengerType ().getName ().equals ("INFANT")) {
                        txtCost.setText (JKText.getDeciFormat (costDepartInfant));
                    }
                    break;
                case CoachUtil.TRIP_RETURN:
                    if (b.getPassengerType ().getName ().equals ("ADULT")) {
                        txtCost.setText (JKText.getDeciFormat (costReturnAdult));
                    }
                    if (b.getPassengerType ().getName ().equals ("CHILD")) {
                        txtCost.setText (JKText.getDeciFormat (costReturnChild));
                    }
                    if (b.getPassengerType ().getName ().equals ("INFANT")) {
                        txtCost.setText (JKText.getDeciFormat (costReturnInfant));
                    }
                    break;
                default:
                    break;
            }

            GridPane.setHalignment (txtCost, HPos.RIGHT);
            gridPass.add (txtCost, 3, rowCount);
            rowCount++;
        }

        return gridPass;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();

        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new CoachBook4 ());
            }
        });

        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent (new TicketingMenu ());
            }
        });

        nav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                makeReservation ();
            }
        });
        return nav;
    }

    private void makeReservation() {
        CoachReserveReq req = new CoachReserveReq ();
        req.setSeats (CoachTicketSale.getInstance ().getListPassengers ().size ());
        req.setBoardRoute (CoachTicketSale.getInstance ().getRouteDepart ().getRouteCode ());
        if (CoachTicketSale.getInstance ().getRouteReturn () != null) {
            req.setReturnRoute (CoachTicketSale.getInstance ().getRouteReturn ().getRouteCode ());
        }
        List<CoachPassenger> listPassengers = new ArrayList<> ();
        for (CoachPassenger p : CoachTicketSale.getInstance ().getListPassengers ()) {
            listPassengers.add (p);
            if ((p.getPassengerType ().getName ().equals ("ADULT"))
                    && p.isInfant () && p.getPassengerInfantOnLap () != null) {
                listPassengers.add (p.getPassengerInfantOnLap ());
            }
        }
        req.getPassengers ().addAll (listPassengers);

        CoachUtil.reserveCoachSeats (req, new CoachUtil.CoachReserveRespResult () {
            @Override
            public void coachReserveRespResult(CoachReserveResp coachReserveResp) {
                if (coachReserveResp.isSuccess ()) {
                    // continue to print and payment
                    CoachTicketSale.getInstance ().setCoachReserveResp (coachReserveResp);
                    SceneSales.clearAndChangeContent (new CoachBook6 ());
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Reservation Failure", !coachReserveResp.getAeonErrorMessage ().isEmpty () ?
                            "A" + coachReserveResp.getAeonErrorCode () + " - " + coachReserveResp.getAeonErrorMessage () :
                            "B" + coachReserveResp.getErrorCode () + " - " + coachReserveResp.getErrorMessage (), null);
                    SceneSales.clearAndChangeContent (new TicketingMenu ());
                }
            }
        });
    }

}
//
// =======================================================

//            costDepartTotal = (CoachTicketSale.getInstance().getSeatsAdult() * costDepartAdult)
//                    + (CoachTicketSale.getInstance().getSeatsChild() * costDepartChild)
//                    + (CoachTicketSale.getInstance().getSeatsInfant() * costDepartInfant);

//                costReturnTotal = (CoachTicketSale.getInstance().getSeatsAdult() * costReturnAdult)
//                        + (CoachTicketSale.getInstance().getSeatsChild() * costReturnChild)
//                        + (CoachTicketSale.getInstance().getSeatsInfant() * costReturnInfant);

//            Text txtType = JKText.getTxtDk(b.getPassengerType(), JKText.FONT_B_18);

//                    if (b.getPassengerType().getName().equals("ADULT")) {
//                        txtCost.setText(JKText.getDeciFormat(costDepartAdult));
//                    }
//                    if (b.getPassengerType().getName().equals("CHILD")) {
//                        txtCost.setText(JKText.getDeciFormat(costDepartChild));
//                    }
//                    if (b.getPassengerType().getName().equals("INFANT")) {
//                        txtCost.setText(JKText.getDeciFormat(costDepartInfant));
//                    }

//                    if (b.getPassengerType().getName().equals("ADULT")) {
//                        txtCost.setText(JKText.getDeciFormat(costReturnAdult));
//                    }
//                    if (b.getPassengerType().getName().equals("CHILD")) {
//                        txtCost.setText(JKText.getDeciFormat(costReturnChild));
//                    }
//                    if (b.getPassengerType().getName().equals("INFANT")) {
//                        txtCost.setText(JKText.getDeciFormat(costReturnInfant));
//                    }

