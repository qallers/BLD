package jkiosk3._common;

import aeonusers.User;

import java.util.List;
import java.util.concurrent.ScheduledExecutorService;

import javafx.collections.ListChangeListener;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import jkiosk3.JKiosk3;
import jkiosk3.SceneMenu;
import jkiosk3.StageJKiosk;
import jkiosk3._components.MessageBox;
import jkiosk3._components.SceneBackground;
import jkiosk3.reports.Reprints;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.store.JKBranding;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.UserUtil;

public class JKLayout {

    public final static double sp = 15;
    public final static double spNum = 5;
    public final static double btnLgW = 175;
    public final static double btnLgH = 75;
    public final static double btnSmW = 135;
    public final static double btnSmH = 65;
    public final static double btnNumW = 60;
    public final static double btnNumH = 55;
    public final static double btnToggleH = 45;
    public final static double menuH = ((8 * JKLayout.btnSmH) + (9 * JKLayout.sp));
    public final static double sideW = JKLayout.btnSmW + (2 * JKLayout.sp);
    public final static double contentW = 615;
    public final static double contentH = StageJKiosk.getSceneHeight() - btnLgH;

//Bind the max height property to the calculated height property. As:
//
//arrangement.maxHeightProperty().bind( arrangement.heightProperty());
    // ('arrangement' is a VBox in this case)

    /**
     * Creates a VBox with the specified padding and spacing, which aligns the inner components in the <b>center</b>.
     *
     * @param padding A double value to be used for the padding between the edge of the VBox and the inner components.
     * @param spacing A double value to be used for the vertical spacing between components inside the VBox.
     * @return A ready-to-use VBox component.
     */
    public static VBox getVBox(double padding, double spacing) {
        VBox vb = new VBox();
        vb.setPadding(new Insets(padding));
        vb.setSpacing(spacing);
        vb.setAlignment(Pos.CENTER);
        return vb;
    }

    /**
     * Creates a VBox with the specified padding and spacing, which aligns the inner components on the <b>left</b> of
     * the box.
     *
     * @param padding A double value to be used for the padding between the edge of the VBox and the inner components.
     * @param spacing A double value to be used for the vertical spacing between components inside the VBox.
     * @return A ready-to-use VBox component.
     */
    public static VBox getVBoxLeft(double padding, double spacing) {
        VBox vb = getVBox(padding, spacing);
        vb.setAlignment(Pos.TOP_LEFT);
        return vb;
    }

    /**
     * <p>
     * Creates a VBox with the specified spacing between child components, and is styled with rounded corners and
     * borders, and a background fill, to create a visually distinct unit to hold screen contents.</p>
     * <p>
     * It has fixed padding of 15px.</p>
     *
     * @param spacing A double value to be used for the vertical spacing between components inside the VBox.
     * @return A ready-to-use VBox component.
     */
    public static VBox getVBoxContent(double spacing) {
        VBox vb = getVBox(0, spacing);
//        if (ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile() == null) {
//            vb.getStyleClass().clear();
//            vb.getStyleClass().add("vbContent");
//        } else {
//            vb.getStyleClass().clear();
//            vb.getStyleClass().add("vbContentNFC");
//        }
        vb.getStyleClass().add("vbContent");
        return vb;
    }

    /**
     * Creates an HBox with the specified padding and spacing, which aligns the inner components in the <b>center</b>.
     *
     * @param padding A double value to be used for the padding between the edge of the HBox and the inner components.
     * @param spacing A double value to be used for the horizontal spacing between components inside the HBox.
     * @return A ready-to-use HBox component.
     */
    public static HBox getHBox(double padding, double spacing) {
        HBox hb = new HBox();
        hb.setPadding(new Insets(padding));
        hb.setSpacing(spacing);
        hb.setAlignment(Pos.CENTER);
        return hb;
    }

    /**
     * <p>
     * Creates an HBox with the specified spacing between child components, and is styled with rounded corners and
     * borders, and a background fill, to create a visually distinct unit to hold screen contents.</p>
     * <p>
     * It has fixed padding of 15px.</p>
     *
     * @param spacing A double value to be used for the horizontal spacing between components inside the HBox.
     * @return A ready-to-use HBox component.
     */
    public static HBox getHBoxContent(double spacing) {
        HBox hb = getHBox(0, spacing);
        hb.getStyleClass().add("hbContent");
        return hb;
    }

    /**
     * Creates an HBox with the specified padding and spacing, which aligns the inner components on the <b>left</b> of
     * the box.
     *
     * @param padding A double value to be used for the padding between the edge of the HBox and the inner components.
     * @param spacing A double value to be used for the horizontal spacing between components inside the HBox.
     * @return A ready-to-use HBox component.
     */
    public static HBox getHBoxLeft(double padding, double spacing) {
        HBox hb = getHBox(padding, spacing);
        hb.setAlignment(Pos.CENTER_LEFT);
        return hb;
    }

    /**
     * Creates an HBox to be used for Control Buttons, with standard 15px padding and 15px spacing, which aligns the
     * inner components on the
     * <b>right</b> of the box.
     *
     * @return A ready-to-use HBox component.
     */
    public static HBox getControlsHBox() {
        HBox hb = getHBoxContent(sp);
        hb.setMinWidth(contentW);
        hb.setAlignment(Pos.CENTER_RIGHT);
        return hb;
    }

    /**
     * Creates a GridPane with two columns, sized as fixed percentages of the total width of the GridPane, using the
     * values specified.<br />
     * This GridPane has fixed padding of 15px, an HGap value between columns of 0px, and a VGap value between rows of
     * 15px.
     *
     * @param column0 A double value between 0 and 1, used for calculating the width of the first column of the grid.
     * @param column1 A double value between 0 and 1, used for calculating the width of the second column of the grid.
     * @return A ready-to-use GridPane component with column widths set at fixed percentages.
     */
    public static GridPane getContentGrid2Col(double column0, double column1) {
        return getGridContent((contentW - (2 * sp)), column0, column1, HPos.LEFT, "gridContent");
    }

    /**
     * <p>
     * Creates a GridPane with styling that can be used as a standalone component to hold content. Has a border and
     * background fill that separates it from the rest of the page content.</p>
     * <p>
     * This GridPane has padding of 15px, HGap of 0px and VGap of 15px.</p>
     * <p>
     * The first column is left-aligned, and the second column is right-aligned.</p>
     *
     * @param column0 A double value between 0 and 1, used for calculating the width of the first column of the grid.
     * @param column1 A double value between 0 and 1, used for calculating the width of the second column of the grid.
     * @return A ready-to-use styled GridPane component with column widths set at fixed percentages.
     */
    public static GridPane getGridContent2Col(double column0, double column1) {
        GridPane grid = getGridContent2Col(column0, column1, HPos.RIGHT);
        return grid;
    }

    public static GridPane getGridContent2ColFixedHt(double column0, double column1, double ht) {
        GridPane grid = getGridContent2Col(column0, column1, HPos.RIGHT);
        grid.setMaxHeight(ht);
        grid.setMinHeight(ht);
        return grid;
    }

    /**
     * <p>
     * Creates a GridPane with styling that can be used as a standalone component to hold content. Has a border and
     * background fill that separates it from the rest of the page content.</p>
     * <p>
     * This GridPane has padding of 15px, HGap of 0px and VGap of 15px.</p>
     * <p>
     * The first column is left-aligned, and the second column alignment is set by the 'col1Align' parameter.</p>
     *
     * @param column0   A double value between 0 and 1, used for calculating the width of the first column of the grid.
     * @param column1   A double value between 0 and 1, used for calculating the width of the second column of the grid.
     * @param col1Align An HPos alignment value specifying the horizontal alignment of the content of the second column.
     * @return A ready-to-use styled GridPane component with column widths set at fixed percentages.
     */
    public static GridPane getGridContent2Col(double column0, double column1, HPos col1Align) {
        GridPane grid = new GridPane();
        grid.setMaxWidth(contentW);
        grid.setMinWidth(contentW);
//        if (ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile() == null) {
//            grid.getStyleClass().add("gridContent2");
//        } else {
//            grid.getStyleClass().add("gridContent2NFC");
//        }
        grid.getStyleClass().add("gridContent2");

        ColumnConstraints col0 = new ColumnConstraints((contentW - (2 * sp)) * column0);
        col0.setHalignment(HPos.LEFT);
        ColumnConstraints col1 = new ColumnConstraints((contentW - (2 * sp)) * column1);
        col1.setHalignment(col1Align);

        grid.getColumnConstraints().addAll(col0, col1);
        return grid;
    }

    /**
     * Creates a GridPane with two columns, sized as fixed percentages of the total width of the GridPane, using the
     * values specified.<br />
     * This GridPane has fixed padding of 0px, an HGap value between columns of 0px, and a VGap value between rows of
     * 15px.<br />
     * This GridPane aligns the contents of each column to the <b>left</b>.
     *
     * @param column0 A double value between 0 and 1, used for calculating the width of the first column of the grid.
     * @param column1 A double value between 0 and 1, used for calculating the width of the second column of the grid.
     * @return A ready-to-use GridPane component with column widths set at fixed percentages.
     */
    public static GridPane getContentGridInner2Col(double column0, double column1) {
        return getGridContent((contentW - (2 * sp)), column0, column1, HPos.LEFT, "gridInner");
    }

    public static GridPane getContentGridInner2ColNFC(double column0, double column1) {
        return getGridContent((contentW - (3 * sp)), column0, column1, HPos.LEFT, "gridInnerNfc");
    }

    /**
     * Creates a GridPane with two columns, sized as fixed percentages of the total width of the GridPane, using the
     * values specified.<br />
     * This GridPane has fixed padding of 0px, an HGap value between columns of 0px, and a VGap value between rows of
     * 15px.<br />
     * This GridPane aligns the contents of the first column to the <b>left</b>, and the second column to the alignment
     * specified by <code>col1Align</code>.
     *
     * @param column0   A double value between 0 and 1, used for calculating the width of the first column of the grid.
     * @param column1   A double value between 0 and 1, used for calculating the width of the second column of the grid.
     * @param col1Align An HPos alignment value specifying the horizontal alignment of the content of the second column.
     * @return A ready-to-use GridPane component with column widths set at fixed percentages.
     */
    public static GridPane getContentGridInner2Col(double column0, double column1, HPos col1Align) {
        return getGridContent((contentW - (2 * sp)), column0, column1, col1Align, "gridInner");
    }

    public static GridPane getContentGridInner2ColInScroll(double column0, double column1, HPos col1Align) {
        return getGridContent((contentW - (4 * sp)), column0, column1, col1Align, "gridInner");
    }

    private static GridPane getGridContent(double gridWidth, double column0, double column1, HPos col1Align, String styleClass) {
        GridPane grid = new GridPane();
        grid.setMaxWidth(gridWidth);
        grid.setMinWidth(gridWidth);
        grid.getStyleClass().add(styleClass);

        ColumnConstraints col0 = new ColumnConstraints(gridWidth * column0);
        col0.setHalignment(HPos.LEFT);
        ColumnConstraints col1 = new ColumnConstraints(gridWidth * column1);
        col1.setHalignment(col1Align);

        grid.getColumnConstraints().addAll(col0, col1);
        return grid;
    }

    public static GridPane getContentGridInScroll() {
        GridPane grid = new GridPane();

        double gridWidth = (contentW - (4 * sp));
        grid.setMaxWidth(gridWidth);
        grid.setMinWidth(gridWidth);
        grid.setStyle("-fx-padding: 0;");
        grid.setHgap(JKLayout.spNum);
        grid.setVgap(2 * JKLayout.spNum);

        return grid;
    }

    public static GridPane getSummaryGrid2Col(double column0, double column1) {
        return getGridSummary2ColVariWidth(column0, column1, (MessageBox.getMsgWidth() - (2 * sp)));
    }

    public static GridPane getGridSummary2Col(double column0, double column1) {
        return getGridSummary2ColVariWidth(column0, column1, (MessageBox.getMsgWidth() - (4 * sp)));
    }

    public static GridPane getGridSummary2ColVariWidth(double column0, double column1, double gridwidth) {
        GridPane grid = new GridPane();
        grid.setMaxWidth(gridwidth);
        grid.setMinWidth(gridwidth);
        grid.setVgap(sp);

        ColumnConstraints col0 = new ColumnConstraints(gridwidth * column0);
        col0.setHalignment(HPos.LEFT);
        ColumnConstraints col1 = new ColumnConstraints(gridwidth * column1);
        col1.setHalignment(HPos.RIGHT);

        grid.getColumnConstraints().addAll(col0, col1);

        return grid;
    }

    public static GridPane getSummaryGridInScroll2Col(double column0, double column1) {
        GridPane grid = new GridPane();
        double w = MessageBox.getMsgWidth() - (6 * sp);
        grid.setMaxWidth(w);
        grid.setMinWidth(w);
        grid.setVgap(sp);

        ColumnConstraints col0 = new ColumnConstraints((w - (2 * sp)) * column0);
        col0.setHalignment(HPos.LEFT);
        ColumnConstraints col1 = new ColumnConstraints((w - (2 * sp)) * column1);
        col1.setHalignment(HPos.RIGHT);

        grid.getColumnConstraints().addAll(col0, col1);

        return grid;
    }

    public static GridPane getGridPane3Col(double column0, double column1, double column2) {
        GridPane grid = new GridPane();
        grid.setMaxWidth(contentW);
        grid.setMinWidth(contentW);
        grid.setStyle("-fx-padding: 0px; -fx-hgap: 15px; -fx-vgap: 15px;");

        double divWidth = (contentW - (4 * sp));
        ColumnConstraints col0 = new ColumnConstraints(divWidth * column0);
        ColumnConstraints col1 = new ColumnConstraints(divWidth * column1);
        ColumnConstraints col2 = new ColumnConstraints(divWidth * column2);
        grid.getColumnConstraints().addAll(col0, col1, col2);
        return grid;
    }

    public static GridPane getGridPane3Col(double width, double column0, double column1, double column2, int gridspan, HPos col2Align) {
        GridPane grid = new GridPane();
        grid.setMaxWidth(width);
        grid.setMinWidth(width);
//        grid.setStyle("-fx-padding: 0px; -fx-hgap: 15px; -fx-vgap: 15px;");

//        double divWidth = (contentW - (4 * sp));
        ColumnConstraints col0 = new ColumnConstraints(width * column0);
        ColumnConstraints col1 = new ColumnConstraints(width * column1);
        ColumnConstraints col2 = new ColumnConstraints(width * column2);
        col2.setHalignment(col2Align);

        grid.getColumnConstraints().addAll(col0, col1, col2);

        if (gridspan != 0) {
            GridPane.setColumnSpan(grid, gridspan);
        }

        return grid;
    }

    public static GridPane getGridPane4Col(double width, double column0, double column1, double column2, double column3, int gridspan, HPos col3Align) {
        GridPane grid = new GridPane();
        grid.setMaxWidth(width);
        grid.setMinWidth(width);
        grid.setHgap(JKLayout.sp);
//        grid.setGridLinesVisible(true);

        ColumnConstraints col0 = new ColumnConstraints(width * column0);
        ColumnConstraints col1 = new ColumnConstraints(width * column1);
        ColumnConstraints col2 = new ColumnConstraints(width * column2);
        ColumnConstraints col3 = new ColumnConstraints(width * column3);
        col3.setHalignment(col3Align);

        grid.getColumnConstraints().addAll(col0, col1, col2, col3);
        if (gridspan != 0) {
            GridPane.setColumnSpan(grid, gridspan);
        }

        return grid;
    }

    public static AnchorPane getSceneAnchor(Node menu, final VBox content, VBox vbPageRight) {
        AnchorPane ap = new AnchorPane();
        ap.setPrefWidth(StageJKiosk.getSceneWidth());
        ap.setMaxHeight(JKLayout.contentH);
        double contentOffset = (StageJKiosk.getSceneWidth() / 2) - (JKLayout.contentW / 2);
        content.getChildren().addListener(new ListChangeListener() {

            @Override
            public void onChanged(ListChangeListener.Change change) {
                if (content.getChildren().size() > 0) {
                    SceneBackground.fadeSceneBackgroundImage();
                } else {
                    SceneBackground.showSceneBackgroundImage();
                }
            }
        });

        AnchorPane.setLeftAnchor(menu, sp);
        AnchorPane.setTopAnchor(menu, sp);
        AnchorPane.setLeftAnchor(content, contentOffset);
        AnchorPane.setTopAnchor(content, sp);
        AnchorPane.setTopAnchor(vbPageRight, sp);
        AnchorPane.setRightAnchor(vbPageRight, sp);

        return ap;
    }

    public static StackPane getSceneStack(AnchorPane anchor, Region scene) {
        StackPane stackScene = new StackPane();
        SceneBackground sb = new SceneBackground(JKBranding.getBranding().getMerchantGroup(), scene);
        StackPane.setAlignment(anchor, Pos.TOP_CENTER);

        stackScene.getChildren().addAll(JKiosk3.getComponentStack());
        stackScene.getChildren().addAll(sb, anchor);

        return stackScene;
    }

    public static VBox getMainMenuBtn(final Region newRegion) {
        Button btn = JKNode.getBtnSm("Main Menu");
        btn.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onSelectMainMenu(CurrentUser.getUser().getUserPin());
                if (Reprints.getListSched() != null && !Reprints.getListSched().isEmpty()) {
                    for (ScheduledExecutorService s : Reprints.getListSched()) {
                        s.shutdown();
                        System.out.println("shutting down ScheduledExecutorService : " + s.isShutdown());
                    }
                    Reprints.getListSched().clear();
                }
            }
        });
        VBox vb = getVBoxContent(sp);
        vb.getStyleClass().clear();
        vb.getStyleClass().add("vbContent");
        vb.setMaxSize(sideW, (btnSmH + (2 * sp)));
        vb.setMinSize(sideW, (btnSmH + (2 * sp)));
        vb.getChildren().add(btn);
        return vb;
    }

    private static void onSelectMainMenu(final String userPin) {
        UserUtil.getLoggedInUser(userPin, new UserUtil.LoggedInUserResult() {

            @Override
            public void loggedInUserResult(User loggedInUser) {
                if (loggedInUser.isSuccess()) {
                    int userLevel = loggedInUser.getUserLevel();
                    if (userLevel == 0) {
                        JKiosk3.getMsgBox().showMsgBox("Access Denied",
                                "Main Menu not available for this Access Level", null);
                    } else if (userLevel == 1 || userLevel == 2) {
                        JKiosk3.changeScene(new SceneMenu());
                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Login Failed",
                            loggedInUser.getErrorCode() + " - " + loggedInUser.getErrorText(), null);
                }
            }
        });
    }

    public static VBox getSceneMenuBtnGroup(String sceneType, List<Button> listMenuBtns) {
        VBox vb = getVBoxContent(sp);
        vb.getStyleClass().clear();
        vb.getStyleClass().add("vbContent");
        vb.setAlignment(Pos.TOP_CENTER);
//        double menuHt = ((9 * JKLayout.btnSmH) + (10 * JKLayout.sp));
        double menuHt = ((9 * JKLayout.btnSmH) + (1 * JKLayout.sp) + (9 * 10));
        if (sceneType.equalsIgnoreCase("sales")) {
            if (listMenuBtns.size() == 9) {
                vb.setMaxSize(sideW, menuHt);
                vb.setMinSize(sideW, menuHt);
                vb.setSpacing(10);
            } else {
                vb.setMaxSize(sideW, menuH);
                vb.setMinSize(sideW, menuH);
            }
        } else {
            vb.setMaxSize(sideW, menuH);
            vb.setMinSize(sideW, menuH);
        }
        vb.getChildren().addAll(listMenuBtns);
        return vb;
    }

//    public static Group getSceneInfoGroup(double infoHt, Node infoNode) {
//        Group grp = new Group();
//
//        Rectangle rec = new Rectangle(sideW, infoHt);
//
//        if (infoNode != null) {
//            grp.getChildren().addAll(rec, infoNode);
//        } else {
//            grp.getChildren().add(rec);
//        }
//        return grp;
//    }

    public static VBox getSceneInfoBox(double infoHt, Node infoNode) {
        VBox vb = getVBoxContent(sp);
        vb.setMaxSize(sideW, infoHt);
        vb.setMinSize(sideW, infoHt);
        vb.getStyleClass().clear();
        vb.getStyleClass().add("vbContent");
        vb.setStyle("-fx-padding: 0px 0px 3px 0px;");

        if (infoNode != null) {
            vb.getChildren().addAll(infoNode);
        }
        return vb;
    }

    public static StackPane getComponentStackPane() {
        StackPane stack = new StackPane();
        stack.setMaxSize(StageJKiosk.getSceneWidth(), StageJKiosk.getSceneHeight());
        stack.setMinSize(StageJKiosk.getSceneWidth(), StageJKiosk.getSceneHeight());
        Rectangle recBlock = new Rectangle(StageJKiosk.getSceneWidth(), StageJKiosk.getSceneHeight());
        recBlock.getStyleClass().clear();
        recBlock.getStyleClass().add("rec-blockout");
        stack.getChildren().add(recBlock);
        return stack;
    }

    public static StackPane getStackFavouriteSelect(double pgHt) {
        double innerWidth = (JKLayout.contentW - (2 * JKLayout.sp));    // 615 - 30 = 585

        StackPane stackPane = new StackPane();
        stackPane.setMaxSize(innerWidth, pgHt);
        stackPane.setMinSize(innerWidth, pgHt);
        stackPane.setPadding(new Insets(0, 0, 0, 30));

        return stackPane;
    }

    public static FlowPane getFlowPane(List<Node> listNodes) {
        double w = JKLayout.contentW - (2 * JKLayout.sp);
        FlowPane flowPane = new FlowPane(JKLayout.sp, JKLayout.sp);
        flowPane.setAlignment(Pos.CENTER);
        flowPane.setMaxWidth(w);
        flowPane.setMinWidth(w);
        flowPane.setPrefWrapLength(w);
        flowPane.setStyle("-fx-padding: 0;");
        flowPane.getChildren().addAll(listNodes);

        return flowPane;
    }

    public static TilePane getTiledBtns(double padding, double hgap, double vgap, int cols, List<Button> btnList) {
        TilePane tile = getTile(padding, hgap, vgap, cols);
        tile.getChildren().addAll(btnList);
        return tile;
    }

    public static TilePane getTiledRadioBtn(double padding, double hgap, double vgap, int cols, List<RadioButton> btnList) {
        TilePane tile = getTile(padding, hgap, vgap, cols);
        tile.getChildren().addAll(btnList);
        return tile;
    }

    public static TilePane getTile(double padding, double hgap, double vgap, int cols) {
        TilePane tile = new TilePane();
        tile.setPadding(new Insets(padding));
        tile.setHgap(hgap);
        tile.setVgap(vgap);
        tile.setPrefColumns(cols);
        tile.setAlignment(Pos.CENTER_LEFT);
        return tile;
    }

    public static TilePane getTileContent(double hgap, double vgap, int cols) {
        TilePane tile = getTile(0, hgap, vgap, cols);
        tile.getStyleClass().add("tileContent");
        return tile;
    }
}
