package jkiosk3.sales._favourites.nfc;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SceneSales;
import za.co.blt.consumer.loyalty.api.service.model.response.CompleteConsumerProfile;

public class ActiveNFCDisplay extends Region {

    private final static double ACTIVE_W = 325;
    private final static double ACTIVE_H = 59;

    private CompleteConsumerProfile completeConsumerProfile;

    public ActiveNFCDisplay(CompleteConsumerProfile completeConsumerProfile) {
        this.completeConsumerProfile = completeConsumerProfile;

        getChildren().add(getPaneActiveSubscriber());
    }

    private HBox getPaneActiveSubscriber() {

        Label lblActive = JKText.getLblDk("Return to Favourites for", JKText.FONT_B_18);
        lblActive.setStyle("-fx-text-fill: #00539E;");
        Label lblCard = JKText.getLblDk("Card Number", JKText.FONT_B_XXSM);
        lblCard.setStyle("-fx-text-fill: #00539E;");
        Label lblSp = JKText.getLblDk(" : ", JKText.FONT_B_XXSM);
        lblSp.setStyle("-fx-text-fill: #00539E;");
        Text txtCard = JKText.getTxtDk(ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getConsumer().getLoyaltyCard(), JKText.FONT_B_XXSM);
        txtCard.setFill(Color.valueOf("#00539E"));

        HBox hb = JKLayout.getHBox(0, JKLayout.spNum);
        hb.getChildren().addAll(lblCard, lblSp, txtCard);

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getStyleClass().add("vbNFCbtn");
        vb.setStyle("-fx-border-color: #FFDA00; -fx-border-width: 3px; -fx-border-insets: -3;");
        vb.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new NFCSubscriberFavourites(completeConsumerProfile));
            }
        });
        vb.getChildren().addAll(lblActive, hb);

        Image imgX = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/cross.png"));
        ImageView imgCancel = new ImageView(imgX);

        Button btnCancel = JKNode.getBtnNum("");
        btnCancel.setMaxSize(JKLayout.btnNumW, JKLayout.btnNumW);
        btnCancel.setMinSize(JKLayout.btnNumW, JKLayout.btnNumW);
        btnCancel.setGraphic(imgCancel);
        btnCancel.getStyleClass().add("btnNFC");
        btnCancel.setStyle("-fx-border-color: #FFDA00; -fx-border-width: 3px; -fx-border-insets: -3;");
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                NFCUtil.resetNFCActiveSubscriber();
            }
        });

        HBox hBox = JKLayout.getHBox(0, (JKLayout.spNum) + 3);
        hBox.setMaxSize(ACTIVE_W, ACTIVE_H);
        hBox.setMinSize(ACTIVE_W, ACTIVE_H);
        hBox.getChildren().addAll(vb, btnCancel);

        hBox.setTranslateY(-JKLayout.sp);

        return hBox;
    }
}
