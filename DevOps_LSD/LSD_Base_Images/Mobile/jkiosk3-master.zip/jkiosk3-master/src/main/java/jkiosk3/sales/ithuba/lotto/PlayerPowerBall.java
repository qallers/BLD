package jkiosk3.sales.ithuba.lotto;

import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales._favourites.Favourites;
import jkiosk3.sales.ithuba.LottoUtil;

/**
 *
 * @author valeriew
 */
public class PlayerPowerBall extends Region {

    private final static Logger logger = Logger.getLogger(PlayerPowerBall.class.getName());

    private final int maxBoards = LottoUtil.MAX_BOARDS;
    private final int maxDraws = LottoUtil.MAX_DRAWS;

    private TextField txtNumOfBoards;
    private TextField txtNumOfDraws;

    public PlayerPowerBall() {
        logger.info("Starting sale - Powerball Player Select");
        LottoSale.resetLottoSale();
        getChildren().add(getLayoutGroup());
    }

    private VBox getLayoutGroup() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().add(getContentGroup());
        vb.getChildren().add(getNav());
        return vb;
    }

    private VBox getContentGroup() {
        ImageView img = JKNode.getJKImageViewProvider("prov_IthubaPowerBall.png");
        Label lblPowerBall = JKText.getLblDk("Player Selection PowerBall", JKText.FONT_B_SM);

        VBox vbHead = JKNode.getPageDblHeadVB(0, lblPowerBall, img);

        VBox vb = JKLayout.getVBoxContent(2 * JKLayout.sp);
        vb.getChildren().addAll(vbHead, getContentGrid());

        return vb;
    }

    private GridPane getContentGrid() {

        final String rangeBoards = "Boards (1 - " + maxBoards + ")";
        final String rangeDraws = "Draws (1 - " + maxDraws + ")";
        
//        Label numOfBoardsText = JKText.getLblDk("No. of Boards (1 - " + maxBoards + ")", JKText.FONT_B_XSM);
//        Label numOfDrawsText = JKText.getLblDk("No. of Draws (1 - " + maxDraws + ")", JKText.FONT_B_XSM);
        Label numOfBoardsText = JKText.getLblDk("No. of " + rangeBoards, JKText.FONT_B_XSM);
        Label numOfDrawsText = JKText.getLblDk("No. of " + rangeDraws, JKText.FONT_B_XSM);

        txtNumOfBoards = JKNode.getTextFieldSmRight();
        txtNumOfBoards.setText("1");
        txtNumOfBoards.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
//                JKiosk3.getNumPad().showNumPad(txtNumOfBoards, "Boards (1-" + maxBoards + ")", "", new NumberPadResult() {
                JKiosk3.getNumPad().showNumPad(txtNumOfBoards, rangeBoards, "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        validateNumber(txtNumOfBoards, value, 1, maxBoards);
                    }
                });
            }
        });

        txtNumOfDraws = JKNode.getTextFieldSmRight();
        txtNumOfDraws.setText("1");
        txtNumOfDraws.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
//                JKiosk3.getNumPad().showNumPad(txtNumOfDraws, "Draws (1-" + maxDraws + ")", "", new NumberPadResult() {
                JKiosk3.getNumPad().showNumPad(txtNumOfDraws, rangeDraws, "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        validateNumber(txtNumOfDraws, value, 1, maxDraws);
                    }
                });
            }
        });

        Button btnSelNum = JKNode.getBtnMsgBox("Select Numbers");
        btnSelNum.setMaxWidth((JKLayout.btnSmW * 2) + JKLayout.sp);
        btnSelNum.setMinWidth((JKLayout.btnSmW * 2) + JKLayout.sp);
        btnSelNum.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (canContinue()) {
                    LottoSale.getInstance().setBoards(Integer.parseInt(txtNumOfBoards.getText()));
                    LottoSale.getInstance().setDraws(Integer.parseInt(txtNumOfDraws.getText()));
                    SceneSales.clearAndChangeContent(new PlayerPowerBallSelNum());
                }
            }
        });

        GridPane grid = JKLayout.getContentGridInner2ColInScroll(0.5, 0.5, HPos.RIGHT);

        grid.addRow(0, numOfBoardsText, txtNumOfBoards);
        grid.addRow(1, numOfDrawsText, txtNumOfDraws);

        grid.add(btnSelNum, 1, 3);

        return grid;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav();
        nav.getBtnBack().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new LottoMenu());
            }
        });
//        nav.setBtnCancelAction(new LottoMenu());
        nav.setBtnCancelAction(new Favourites());

        nav.getBtnNext().setDisable(true);
        return nav;
    }

    private void validateNumber(final TextField txt, String value, int minNum, int maxNum) {
        try {
            int numSelected = Integer.parseInt(value);
            if (numSelected < minNum || numSelected > maxNum) {
                JKiosk3.getMsgBox().showMsgBox("Incorrect Number Selected",
                        "ONLY numbers in the range " + minNum + " - " + maxNum + " allowed", null);
                txt.setText("1");
            }
        } catch (NumberFormatException nfe) {
            logger.log(Level.SEVERE, nfe.getMessage(), nfe);
            JKiosk3.getMsgBox().showMsgBox("Invalid Number Selection", "Please review the selected numbers and try again", null);
        }
    }

    private boolean canContinue() {
        if (txtNumOfBoards.getText().equals("") || txtNumOfBoards.getText().equals("0")) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Input", "Please select a valid number of Boards", null);
            return false;
        }
        if (txtNumOfDraws.getText().equals("") || txtNumOfDraws.getText().equals("0")) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Input", "Please select a valid number of Draws", null);
            return false;
        }
        return true;
    }
}
