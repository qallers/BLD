package jkiosk3.sales.search;

import aeonairtime.AirtimeManufacturer;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.vouchers.VoucherUtil;

import java.util.ArrayList;
import java.util.List;

public class CreateDataVoucherProduct {

    public static List<SearchProduct> createDataVoucherProducts() {
        // populate vouchers
        VoucherUtil.getVoucherProvidersList();

        final String VOUCHER_DATA = "Data Voucher";

        List<SearchProduct> products = new ArrayList<>();
        for (AirtimeManufacturer airtimeManufacturer : VoucherUtil.getProvidersShow(SaleType.VOUCHER_DATA)) {
            SearchProduct networkProvider = new SearchProduct();

            networkProvider.setProvName(airtimeManufacturer.getId());
            String dataName = airtimeManufacturer.getName();

            networkProvider.setProdName(String.format("%s %s", dataName, VOUCHER_DATA));
            networkProvider.setSearchTransType(SearchTransType.DATA_VOUCHER);

            products.add(networkProvider);
        }
        return products;
    }

}
