package jkiosk3.sales.billpay.syntell;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.syntell.SyntellFinePayConfReq;
import aeonbillpayments.syntell.SyntellFinePayConfResp;
import aeonbillpayments.syntell.SyntellFinePayReq;
import aeonbillpayments.syntell.SyntellFinePayResp;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.BillPayUtilSyntell;
import jkiosk3.sales.billpay._common.BillPayEntry;
import jkiosk3.sales.billpay._common.BillPaymentSelect;
import jkiosk3.users.UserUtil;

public class InputSyntellTrafficFine extends Region {

    private BillPaymentConnection connection;
    private final BillPayProduct product;
    private final VBox vbContent;
    private BillPayEntry gridAcc;
    private GridPane gridAmtDetail;
    private JKioskNav nav;
    private String noticeNum;
    private double amountPaid;
    private JKTenderToggles tenders;
    private String tendered;
    private SyntellFinePayReq request1;
    private SyntellFinePayResp response1;
    private SyntellFinePayReq request2;
    private SyntellFinePayResp response2;
    private boolean showFavourites;
    private boolean showProductFavourite;

    public InputSyntellTrafficFine(BillPayProduct p, boolean isNFCFavourite, boolean isProductFavourite) {
        this.product = p;
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;

        vbContent = JKLayout.getVBoxContent (JKLayout.spNum);

        VBox vbLayout = JKLayout.getVBox (0, 5);
        vbLayout.getChildren ().add (getFineNumberEntry ());
        vbLayout.getChildren ().add (getNav ());

        getChildren ().add (vbLayout);
    }

    private VBox getFineNumberEntry() {

        ImageView img = BillPayUtilMisc.getImageViewBillPay ("prov_Syntell.png");

        gridAcc = new BillPayEntry ("Traffic Fine Payment", img, product, BillPayEntry.TYPE_TRAFFIC_FINE, showFavourites, showProductFavourite);
        gridAcc.getBtnDetail ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (vbContent.getChildren ().contains (gridAmtDetail)) {
                    vbContent.getChildren ().remove (gridAmtDetail);
                    getFineRequestQuery ();
                } else {
                    getFineRequestQuery ();
                }
            }
        });

        vbContent.getChildren ().add (gridAcc);

        return vbContent;
    }

    private GridPane getDetailAndAmountEntry() {

        GridPane gridDetail = BillPayUtilMisc.getGridBillPayDetail (response1.getFines ().get (0).getAmountDue (),
                response1.getConvenienceFee (), null, BPTransType.BILLPAY_SYNTELL_TRAFFIC.getDisplayName ());
//                response1.getConvenienceFee(), null, BillPayUtilMisc.SYNTELL_TRAFFIC_FINES);

        gridAmtDetail = JKLayout.getContentGridInner2Col (0.5, 0.5);

        gridAmtDetail.add (gridDetail, 0, 1, 2, 1);
        gridAmtDetail.addRow (3, getTenderTypes ());

        return gridAmtDetail;
    }

    private JKTenderToggles getTenderTypes() {
        tenders = new JKTenderToggles (SaleType.BILLPAYMENTS.getDisplay ());
        for (ToggleButton b : tenders.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(javafx.event.Event e) {
                    amountPaid = response1.getFines ().get (0).getAmountDue ();
                    tendered = tenders.getTenderTypeSelected ();
                    submitSyntellFinePaymentRollback (request1, BillPayUtilMisc.CALL_BY_TENDER);
                }
            });
        }
        return tenders;
    }

    private JKioskNav getNav() {
        nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (gridAcc.getVbHead ().getChildren ().contains (gridAcc.getGridEnter ())) {
                    SceneSales.clearAndChangeContent (new BillPaymentSelect (
                            BillPayUtilMisc.TYPE_TRAFFIC_FINE + " Providers", BillPayUtilMisc.TYPE_TRAFFIC_FINE));
                } else {
                    SceneSales.clearAndChangeContent (new InputSyntellTrafficFine (product, showFavourites, showProductFavourite));
                }
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                BillPayUtilMisc.resetBillPayView ();
                if (request1 != null) {
                    submitSyntellFinePaymentRollback (request1, BillPayUtilMisc.CALL_BY_CANCEL);
                }
            }
        });
        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private void showConfirmationSummary() {
        SummarySyntellTrafficFine summary = new SummarySyntellTrafficFine (response2, tendered);

        JKiosk3.getMsgBox ().showMsgBox (BPTransType.BILLPAY_SYNTELL_TRAFFIC.getDisplayName (), "Confirm all details before proceeding",
                summary, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        submitSyntellFinePaymentCommit (request2);
                    }

                    @Override
                    public void onCancel() {
                        UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                        BillPayUtilMisc.resetBillPayView ();
                        submitSyntellFinePaymentRollback (request2, BillPayUtilMisc.CALL_BY_CANCEL);
                    }
                });
    }

    //====================================
    // above - mostly view
    // below - mostly process
    //====================================
    private void getFineRequestQuery() {
        noticeNum = gridAcc.getAccountNumberConfirmed ();

        request1 = new SyntellFinePayReq ();
        request1.setProviderId (product.getProvId ());
        request1.setProductId (product.getProdId ());
        request1.setNoticeNo (noticeNum);

        BillPayUtilSyntell.getSyntellTrafficPaymentResponse (request1, new BillPayUtilSyntell.SyntellFinePaymentResponse () {
            @Override
            public void syntellFinePayResp(BillPaymentConnection connect, SyntellFinePayResp resp) {
                connection = connect;

                if (resp.isSuccess ()) {
                    response1 = resp;
                    if (resp.getFines ().get (0).isPaymentAllowed ()) {
                        gridAcc.getVbHead ().getChildren ().remove (gridAcc.getGridEnter ());
                        gridAcc.getVbHead ().getChildren ().add (gridAcc.getGridDetail (resp.getFines ().get (0).getNoticeNumber (),
                                resp.getFines ().get (0).getVehicleRegNumber ()));
                        gridAmtDetail = getDetailAndAmountEntry ();
                        vbContent.getChildren ().add (1, gridAmtDetail);
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Payment",
                                resp.getFines ().get (0).getPaymentNotAllowedReason (), null,
                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                    @Override
                                    public void onOk() {
                                        submitSyntellFinePaymentRollback (request1, BillPayUtilMisc.CALL_BY_MSG);
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Detail Error",
                            !resp.getAeonErrorText ().isEmpty () ?
                                    "A" + resp.getAeonErrorCode () + " - " + resp.getAeonErrorText () :
                                    "B" + resp.getErrorCode () + " - " + resp.getErrorText (), null);
                    BillPayUtilMisc.resetBillPayView ();
                }
            }
        });
    }

    private void getFineRequestPay() {
        request2 = new SyntellFinePayReq ();
        request2.setProviderId (product.getProvId ());
        request2.setProductId (product.getProdId ());
        request2.setNoticeNo (noticeNum);
        request2.setAmount (amountPaid);

        BillPayUtilSyntell.getSyntellTrafficPaymentResponse (request2, new BillPayUtilSyntell.SyntellFinePaymentResponse () {

            @Override
            public void syntellFinePayResp(BillPaymentConnection connect, SyntellFinePayResp resp) {
                connection = connect;

                if (resp.isSuccess ()) {
                    response2 = resp;
                    showConfirmationSummary ();
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Detail Error",
                            !resp.getAeonErrorText ().isEmpty () ?
                                    "A" + resp.getAeonErrorCode () + " - " + resp.getAeonErrorText () :
                                    "B" + resp.getErrorCode () + " - " + resp.getErrorText (), null);
                    BillPayUtilMisc.resetBillPayView ();
                }
            }
        });
    }

    private void submitSyntellFinePaymentCommit(SyntellFinePayReq reqCommit) {
        SyntellFinePayConfReq confCommit = new SyntellFinePayConfReq ();

        confCommit.setProviderId (reqCommit.getProviderId ());
        confCommit.setProductId (reqCommit.getProductId ());
        confCommit.setNoticeNo (noticeNum);
        confCommit.setAmount (reqCommit.getAmount ());
        confCommit.setConfirmType ("commit");
        confCommit.setTenderType (tendered);
        confCommit.setWantPrintJob (true);

        BillPayUtilSyntell.getSyntellFinePaymentConfirm (connection, confCommit,
                new BillPayUtilSyntell.SyntellFinePaymentConfirm () {
                    @Override
                    public void syntellFinePayConf(final SyntellFinePayConfResp confResp) {
                        if (confResp.isSuccess ()) {
                            double amtTotal = amountPaid + response2.getConvenienceFee ();
                            String descript = product.getProdName () + " - " + request2.getNoticeNo ();

//                    SalesUtil.processBillPayment(BillPayUtilMisc.SYNTELL_TRAFFIC_FINES, response2.getTransRef(), descript, amtTotal,
                            SalesUtil.processBillPayment (BPTransType.BILLPAY_SYNTELL_TRAFFIC.getDisplayName (), response2.getTransRef (), descript, amtTotal,
                                    tendered, confResp.getResultDescription (), confResp.getPrintLines (), confResp.getMerchantPrintLines ());

                        } else if (!confResp.getAeonErrorCode ().isEmpty ()) {
                            JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Payment Error", "A" + confResp.getAeonErrorCode () + " - " + confResp.getAeonErrorText (), null);
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Payment Error", "B" + confResp.getErrorCode () + " - " + confResp.getErrorText (), null);
                        }
                        BillPayUtilMisc.resetBillPayView ();
                    }
                });
    }

    private void submitSyntellFinePaymentRollback(SyntellFinePayReq reqRollback, final String calledBy) {
        SyntellFinePayConfReq confRollback = new SyntellFinePayConfReq ();

        confRollback.setProviderId (reqRollback.getProviderId ());
        confRollback.setProductId (reqRollback.getProductId ());
        confRollback.setNoticeNo (noticeNum);
        confRollback.setAmount (reqRollback.getAmount ());
        confRollback.setConfirmType ("rollback");
        if (tendered != null) {
            confRollback.setTenderType (tendered);
        } else {
            confRollback.setTenderType ("cash");
        }

        BillPayUtilSyntell.getSyntellFinePaymentConfirm (connection, confRollback,
                new BillPayUtilSyntell.SyntellFinePaymentConfirm () {
                    @Override
                    public void syntellFinePayConf(SyntellFinePayConfResp bpConfResp) {
                        if (bpConfResp.isSuccess ()) {
                            switch (calledBy) {
                                case BillPayUtilMisc.CALL_BY_CANCEL:
                                    JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Payment", "Transaction cancelled by User", null);
                                    BillPayUtilMisc.resetBillPayView ();
                                    break;
                                case BillPayUtilMisc.CALL_BY_MSG:
                                    BillPayUtilMisc.resetBillPayView ();
                                    break;
                                case BillPayUtilMisc.CALL_BY_TENDER:
                                    getFineRequestPay ();
                                    break;
                                default:
                                    JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Payment",
                                            "Unable to determine Rollback requestor", null);
                            }
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Payment Rollback Error", !bpConfResp.getAeonErrorText ().isEmpty () ?
                                    "A" + bpConfResp.getAeonErrorCode () + " - " + bpConfResp.getAeonErrorText () :
                                    "B" + bpConfResp.getErrorCode () + " - " + bpConfResp.getErrorText (), null);
                        }
                    }
                });
    }

//    private BillPaymentConnection connection;
//    private final BillPayProduct product;
//    private final VBox vbContent;
//    private BillPayEntry gridAcc;
//    private GridPane gridAmtDetail;
//    private JKioskNav nav;
//    private String noticeNum;
//    private double amountPaid;
//    private JKTenderToggles tenders;
//    private String tendered;
//    private SyntellFinePayReq request1;
//    private SyntellFinePayResp response1;
//    private SyntellFinePayReq request2;
//    private SyntellFinePayResp response2;
//    private boolean showFavourites;
//
//    public InputSyntellTrafficFine(BillPayProduct p, boolean isFavourite) {
//        this.product = p;
//        this.showFavourites = isFavourite;
//
//        vbContent = JKLayout.getVBoxContent(JKLayout.spNum);
//
//        VBox vbLayout = JKLayout.getVBox(0, 5);
//        vbLayout.getChildren().add(getFineNumberEntry());
//        vbLayout.getChildren().add(getNav());
//
//        getChildren().add(vbLayout);
//    }
//
//    private VBox getFineNumberEntry() {
//
//        ImageView img = BillPayUtilMisc.getImageViewBillPay("prov_Syntell.png");
//
//        gridAcc = new BillPayEntry("Traffic Fine Payment", img, product, BillPayEntry.TYPE_TRAFFIC_FINE, showFavourites);
//        gridAcc.getBtnDetail().setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                if (vbContent.getChildren().contains(gridAmtDetail)) {
//                    vbContent.getChildren().remove(gridAmtDetail);
//                    getFineRequestQuery();
//                } else {
//                    getFineRequestQuery();
//                }
//            }
//        });
//
//        vbContent.getChildren().add(gridAcc);
//
//        return vbContent;
//    }
//
//    private GridPane getDetailAndAmountEntry() {
//
//        GridPane gridDetail = BillPayUtilMisc.getGridBillPayDetail(response1.getFines().get(0).getAmountDue(),
//                response1.getConvenienceFee(), null, BPTransType.BILLPAY_SYNTELL_TRAFFIC.getDisplayName());
////                response1.getConvenienceFee(), null, BillPayUtilMisc.SYNTELL_TRAFFIC_FINES);
//
//        gridAmtDetail = JKLayout.getContentGridInner2Col(0.5, 0.5);
//
//        gridAmtDetail.add(gridDetail, 0, 1, 2, 1);
//        gridAmtDetail.addRow(3, getTenderTypes());
//
//        return gridAmtDetail;
//    }
//
//    private JKTenderToggles getTenderTypes() {
//        tenders = new JKTenderToggles(SaleType.BILLPAYMENTS.getDisplay());
//        for (ToggleButton b : tenders.getTenderToggleList()) {
//            b.setOnMouseReleased(new EventHandler() {
//                @Override
//                public void handle(javafx.event.Event e) {
//                    amountPaid = response1.getFines().get(0).getAmountDue();
//                    tendered = tenders.getTenderTypeSelected();
//                    submitSyntellFinePaymentRollback(request1, BillPayUtilMisc.CALL_BY_TENDER);
//                }
//            });
//        }
//        return tenders;
//    }
//
//    private JKioskNav getNav() {
//        nav = new JKioskNav();
//        nav.getBtnBack().setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                if (gridAcc.getVbHead().getChildren().contains(gridAcc.getGridEnter())) {
//                    SceneSales.clearAndChangeContent(new BillPaymentSelect(
//                            BillPayUtilMisc.TYPE_TRAFFIC_FINE + " Providers", BillPayUtilMisc.TYPE_TRAFFIC_FINE));
//                } else {
//                    SceneSales.clearAndChangeContent(new InputSyntellTrafficFine(product, showFavourites));
//                }
//            }
//        });
//        nav.getBtnCancel().setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
//                BillPayUtilMisc.resetBillPayView();
//                if (request1 != null) {
//                    submitSyntellFinePaymentRollback(request1, BillPayUtilMisc.CALL_BY_CANCEL);
//                }
//            }
//        });
//        nav.getBtnNext().setDisable(true);
//        return nav;
//    }
//
//    private void showConfirmationSummary() {
//        SummarySyntellTrafficFine summary = new SummarySyntellTrafficFine(response2, tendered);
//
////        JKiosk3.getMsgBox().showMsgBox(BillPayUtilMisc.SYNTELL_TRAFFIC_FINES, "Confirm all details before proceeding",
//        JKiosk3.getMsgBox().showMsgBox(BPTransType.BILLPAY_SYNTELL_TRAFFIC.getDisplayName(), "Confirm all details before proceeding",
//                summary, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult() {
//                    @Override
//                    public void onOk() {
//                        submitSyntellFinePaymentCommit(request2);
//                    }
//
//                    @Override
//                    public void onCancel() {
//                        UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
//                        BillPayUtilMisc.resetBillPayView();
//                        submitSyntellFinePaymentRollback(request2, BillPayUtilMisc.CALL_BY_CANCEL);
//                    }
//                });
//    }
//
//    //====================================
//    // above - mostly view
//    // below - mostly process
//    //====================================
//    private void getFineRequestQuery() {
//        noticeNum = gridAcc.getAccountNumberConfirmed();
//
//        request1 = new SyntellFinePayReq();
//        request1.setProviderId(product.getProvId());
//        request1.setProductId(product.getProdId());
//        request1.setNoticeNo(noticeNum);
//
//        BillPayUtilSyntell.getSyntellTrafficPaymentResponse(request1, new BillPayUtilSyntell.SyntellFinePaymentResponse() {
//            @Override
//            public void syntellFinePayResp(BillPaymentConnection connect, SyntellFinePayResp resp) {
//                connection = connect;
//
//                if (resp.isSuccess()) {
//                    response1 = resp;
//                    if (resp.getFines().get(0).isPaymentAllowed()) {
//                        gridAcc.getVbHead().getChildren().remove(gridAcc.getGridEnter());
//                        gridAcc.getVbHead().getChildren().add(gridAcc.getGridDetail(resp.getFines().get(0).getNoticeNumber(),
//                                resp.getFines().get(0).getVehicleRegNumber()));
//                        gridAmtDetail = getDetailAndAmountEntry();
//                        vbContent.getChildren().add(1, gridAmtDetail);
//                    } else {
//                        JKiosk3.getMsgBox().showMsgBox("Traffic Fine Payment",
//                                resp.getFines().get(0).getPaymentNotAllowedReason(), null,
//                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
//
//                                    @Override
//                                    public void onOk() {
//                                        submitSyntellFinePaymentRollback(request1, BillPayUtilMisc.CALL_BY_MSG);
//                                    }
//
//                                    @Override
//                                    public void onCancel() {
//                                        //
//                                    }
//                                });
//                    }
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Traffic Fine Detail Error",
//                            resp.getErrorCode() + " - " + resp.getErrorText(), null);
//                    BillPayUtilMisc.resetBillPayView();
//                }
//            }
//        });
////        }
//    }
//
//    private void getFineRequestPay() {
//        request2 = new SyntellFinePayReq();
//        request2.setProviderId(product.getProvId());
//        request2.setProductId(product.getProdId());
//        request2.setNoticeNo(noticeNum);
//        request2.setAmount(amountPaid);
//
//        BillPayUtilSyntell.getSyntellTrafficPaymentResponse(request2, new BillPayUtilSyntell.SyntellFinePaymentResponse() {
//
//            @Override
//            public void syntellFinePayResp(BillPaymentConnection connect, SyntellFinePayResp resp) {
//                connection = connect;
//
//                if (resp.isSuccess()) {
//                    response2 = resp;
//                    showConfirmationSummary();
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Traffic Fine Detail Error",
//                            resp.getErrorCode() + " - " + resp.getErrorText(), null);
//                    BillPayUtilMisc.resetBillPayView();
//                }
//            }
//        });
//    }
//
//    private void submitSyntellFinePaymentCommit(SyntellFinePayReq reqCommit) {
//        SyntellFinePayConfReq confCommit = new SyntellFinePayConfReq();
//
//        confCommit.setProviderId(reqCommit.getProviderId());
//        confCommit.setProductId(reqCommit.getProductId());
//        confCommit.setNoticeNo(noticeNum);
//        confCommit.setAmount(reqCommit.getAmount());
//        confCommit.setConfirmType("commit");
//        confCommit.setTenderType(tendered);
//        confCommit.setWantPrintJob(true);
//
//        BillPayUtilSyntell.getSyntellFinePaymentConfirm(connection, confCommit,
//                new BillPayUtilSyntell.SyntellFinePaymentConfirm() {
//                    @Override
//                    public void syntellFinePayConf(final SyntellFinePayConfResp confResp) {
//                        if (confResp.isSuccess()) {
//                            double amtTotal = amountPaid + response2.getConvenienceFee();
//                            String descript = product.getProdName() + " - " + request2.getNoticeNo();
//
////                    SalesUtil.processBillPayment(BillPayUtilMisc.SYNTELL_TRAFFIC_FINES, response2.getTransRef(), descript, amtTotal,
//                            SalesUtil.processBillPayment(BPTransType.BILLPAY_SYNTELL_TRAFFIC.getDisplayName(), response2.getTransRef(), descript, amtTotal,
//                                    tendered, confResp.getResultDescription(), confResp.getPrintLines(), confResp.getMerchantPrintLines());
//
//                        } else if (confResp.getErrorCode().equals("1995")) {
//                            JKiosk3.getMsgBox().showMsgBox("Traffic Fine Payment Error", confResp.getErrorText(), null);
//                        } else {
//                            JKiosk3.getMsgBox().showMsgBox("Traffic Fine Payment", confResp.getErrorText(), null);
//                        }
//                        BillPayUtilMisc.resetBillPayView();
//                    }
//                });
//    }
//
//    private void submitSyntellFinePaymentRollback(SyntellFinePayReq reqRollback, final String calledBy) {
//        SyntellFinePayConfReq confRollback = new SyntellFinePayConfReq();
//
//        confRollback.setProviderId(reqRollback.getProviderId());
//        confRollback.setProductId(reqRollback.getProductId());
//        confRollback.setNoticeNo(noticeNum);
//        confRollback.setAmount(reqRollback.getAmount());
//        confRollback.setConfirmType("rollback");
//        if (tendered != null) {
//            confRollback.setTenderType(tendered);
//        } else {
//            confRollback.setTenderType("cash");
//        }
//
//        BillPayUtilSyntell.getSyntellFinePaymentConfirm(connection, confRollback,
//                new BillPayUtilSyntell.SyntellFinePaymentConfirm() {
//                    @Override
//                    public void syntellFinePayConf(SyntellFinePayConfResp bpConfResp) {
//                        if (bpConfResp.isSuccess()) {
//                            switch (calledBy) {
//                                case BillPayUtilMisc.CALL_BY_CANCEL:
//                                    JKiosk3.getMsgBox().showMsgBox("Traffic Fine Payment", "Transaction cancelled by User", null);
//                                    BillPayUtilMisc.resetBillPayView();
//                                    break;
//                                case BillPayUtilMisc.CALL_BY_MSG:
//                                    BillPayUtilMisc.resetBillPayView();
//                                    break;
//                                case BillPayUtilMisc.CALL_BY_TENDER:
//                                    getFineRequestPay();
//                                    break;
//                                default:
//                                    JKiosk3.getMsgBox().showMsgBox("Traffic Fine Payment",
//                                            "Unable to determine Rollback requestor", null);
//                            }
//                        } else {
//                            JKiosk3.getMsgBox().showMsgBox("Traffic Fine Payment Rollback Error", bpConfResp.getErrorText(), null);
//                        }
//                    }
//                });
//    }
}
