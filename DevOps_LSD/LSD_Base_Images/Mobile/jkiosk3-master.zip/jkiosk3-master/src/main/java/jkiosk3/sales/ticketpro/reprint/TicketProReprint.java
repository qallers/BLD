package jkiosk3.sales.ticketpro.reprint;

import aeonprinting.AeonPrintJob;
import aeonticketpros.TicketProsPrintReq;
import aeonticketpros.TicketProsPrintResp;
import aeonticketpros.TicketProsTicket;

import java.io.File;
import java.util.List;
import java.util.Locale;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.PrintUtil;
//import jkiosk3.printing.print_layouts.PrintTicketPro;
import jkiosk3.printing.print_layouts.PrintTicketPro;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.ticketpro.TicketProUtil;
import jkiosk3.store.JKOptions;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.store.JKPrinterTickets;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DownloadUtil;

public class TicketProReprint extends Region {

    private TextField txtBookingRef;
    private String bookingRef;
    private TicketProsPrintResp printResp;
    private List<TicketProsTicket> listPrintTickets;
    private int currentPrintJob;

    public TicketProReprint() {
        CurrentUser.setSalesUser (CurrentUser.getUser ());
        VBox vbReprint = JKLayout.getVBox (0, JKLayout.spNum);
        vbReprint.getChildren ().add (getReprintRefEntry ());
        vbReprint.getChildren ().add (getControlButtons ());
        getChildren ().add (vbReprint);
    }

    private GridPane getReprintRefEntry() {
        Label lblTicketReprint = JKText.getLblContentHead ("TicketPro - Reprint");

        Label lblReference = JKText.getLblDk ("Booking Reference", JKText.FONT_B_XSM);

        txtBookingRef = new TextField ();
        txtBookingRef.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getKeyboard ().showKeyboard (txtBookingRef, "Enter Booking Reference", "",
                            false, false, new KeyboardResult () {
                                @Override
                                public void onDone(String value) {
                                    txtBookingRef.setText (value.toUpperCase (Locale.ENGLISH));
                                }
                            });
                }
            }
        });

        GridPane grid = JKLayout.getGridContent2Col (0.5, 0.5);

        grid.add (lblTicketReprint, 0, 0, 2, 1);
        grid.add (JKNode.createGridSpanSep (2), 0, 1);

        grid.addRow (3, lblReference, txtBookingRef);

        return grid;
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons ();

        ctrlBtns.getBtnAccept ().setDisable (false);
        ctrlBtns.getBtnAccept ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (txtBookingRef.getText () != null) {
                    bookingRef = txtBookingRef.getText ();
                    getReprint ();
                }
            }
        });
        ctrlBtns.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndShowFavourites ();
            }
        });

        return ctrlBtns;
    }

    private void getReprint() {
        final TicketProsPrintReq printRequest = new TicketProsPrintReq ();
        printRequest.setTransactionId (bookingRef);
        if (JKPrinterTickets.getPrinterTickets ().isUseDefaultPrinter ()) {
            printRequest.setFormat ("xml");
        } else if (JKPrinterTickets.getPrinterTickets ().isUseSerialPrinter ()) {
            printRequest.setFormat ("ezpl");
        }
        printRequest.setCardId (bookingRef);
        printRequest.setReprint (true);

        TicketProUtil.getTicketProPrint (1, printRequest, new TicketProUtil.TicketProPrintResult () {
            @Override
            public void tpPrintResult(TicketProsPrintResp tpPrintResp) {
                if (tpPrintResp.isSuccess ()) {

                    if (printRequest.getFormat ().equalsIgnoreCase ("xml")) {
                        if (!tpPrintResp.getListTickets ().isEmpty ()) {
                            printResp = tpPrintResp;
                            listPrintTickets = printResp.getListTickets ();
                            printTickets ();
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("TicketPro - Tickets Not Printed",
                                    "\nPlease refer the Customer to\n\nTicketPro Customer Services\n\n" +
                                            JK3Config.getInfoTicketProCustomerServicesTelNum ()
                                            + "\n\nMon - Fri : 08h00 - 16h00"
                                            + "\n\nand quote Reference number printed on Sales Receipt",
                                    null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK,
                                    new MessageBoxResult () {

                                        @Override
                                        public void onOk() {
                                            SceneSales.clearAndShowFavourites ();
                                        }

                                        @Override
                                        public void onCancel() {
                                            //
                                        }
                                    });
                        }
                    } else if (printRequest.getFormat ().equalsIgnoreCase ("ezpl")) {
                        final File printFile = DownloadUtil.downloadRemoteFile (tpPrintResp.getTickets (), JK3Config.getTicketPrint ());
                        if (printFile != null) {
                            JKiosk3.getMsgBox ().showMsgBox ("TicketPro Reprint", "Tickets will be printed on TicketPrinter",
                                    null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                        @Override
                                        public void onOk() {
                                            PrintHandler.writeFileContentToPrinterPort (printFile);
                                        }

                                        @Override
                                        public void onCancel() {
                                            //
                                        }
                                    });
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("TicketPro - Tickets Not Received from TicketPro",
                                    "\nPlease refer the Customer to\n\nTicketPro Customer Services\n\n" +
                                            JK3Config.getInfoTicketProCustomerServicesTelNum ()
                                            + "\n\nMon - Fri : 08h00 - 16h00"
                                            + "\n\nand quote Reference number printed on Sales Receipt", null);
                        }
                    }
                    SceneSales.clearAndShowFavourites ();
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Print Error", !tpPrintResp.getAeonErrorText ().isEmpty () ?
                            "A" + tpPrintResp.getAeonErrorCode () + " - " + tpPrintResp.getAeonErrorText () :
                            "B" + tpPrintResp.getErrorCode () + " - " + tpPrintResp.getErrorText (), null);
                }
            }
        });
    }

    private void printTickets() {
        /* Reprint must always print immediately. */
        /* This is essential to stop from trying to 'Set Printed' with a ticket Serial Number, which will of course fail. */
        if (JKPrintOptions.getPrintOptions ().isPrintPreview ()) {
            currentPrintJob = 0;
            printTicketsPreviewed ();
        } else {
            for (TicketProsTicket t : listPrintTickets) {
                AeonPrintJob apj = PrintTicketPro.getTicketProTicketPrint (printResp, t);
//                AeonPrintJob apj = t.getAeonPrintJob();
                PrintUtil.sendToPrinter (apj);
            }
        }
    }

    private void printTicketsPreviewed() {
        AeonPrintJob apj = PrintTicketPro.getTicketProTicketPrint (printResp, listPrintTickets.get (currentPrintJob));
//        AeonPrintJob apj = listPrintTickets.get(currentPrintJob).getAeonPrintJob();
        JKiosk3.getPrintPreview ().showPrintPreview ("TicketPro", apj, PrintPreview.PRN_OK, new PrintPreviewResult () {
            @Override
            public void onOk() {
                currentPrintJob++;
                if (currentPrintJob < listPrintTickets.size ()) {
                    printTicketsPreviewed ();
                }
            }

            @Override
            public void onCancel() {
                //
            }
        });
    }
}
