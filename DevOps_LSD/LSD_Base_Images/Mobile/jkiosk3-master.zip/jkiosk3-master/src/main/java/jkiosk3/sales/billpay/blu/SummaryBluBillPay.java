package jkiosk3.sales.billpay.blu;

import aeonbillpayments.blubillpay.BluAccSubscriberInfoReq;
import aeonbillpayments.blubillpay.BluAccSubscriberInfoResp;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3.sales._common.JKTenderToggles;

/**
 *
 * @author Valerie
 */
public class SummaryBluBillPay extends Region {

//    private final BluAccSubscriberInfoReq req;
    private final BluAccSubscriberInfoResp resp;
    private final double amountPayable;
    private final String tendered;

//    public SummaryBluBillPay(BluAccSubscriberInfoReq rq, BluAccSubscriberInfoResp rs, double amountPay, String tenderType) {
    public SummaryBluBillPay(BluAccSubscriberInfoResp rs, double amountPay, String tenderType) {

//        this.req = rq;
        this.resp = rs;
        this.amountPayable = amountPay;
        this.tendered = tenderType;
        getChildren().add(getSummaryGrid());
    }

    private GridPane getSummaryGrid() {

        Label lblPaying = JKText.getLblDk("Account Number", JKText.FONT_B_XSM);
        Label lblClientName = JKText.getLblDk("Client Name", JKText.FONT_B_XSM);
        Label lblTenderType = JKText.getLblDk("Tender Type", JKText.FONT_B_XSM);
        Label lblFullAmountDue = JKText.getLblDk("Full Amount Due", JKText.FONT_B_XSM);
        Label lblAmount = JKText.getLblDk("Amount Paid", JKText.FONT_B_XSM);
        Label lblConvenienceFee = JKText.getLblDk("Convenience Fee", JKText.FONT_B_XSM);
        Label lblTotalPayable = JKText.getLblDk("Total Payable", JKText.FONT_B_XSM);
        Label lblBalance = JKText.getLblDk("Balance after payment", JKText.FONT_B_XSM);

        // filled-in fields
        Text txtAccNum = JKText.getTxtDk(resp.getSubscriberID(), JKText.FONT_B_XSM);

        String txtClientNameDisplay = resp.getSubscriberName();
        Text txtClientName = JKText.getTxtDk(txtClientNameDisplay, JKText.FONT_B_XSM);
        txtClientName.setWrappingWidth((MessageBox.getMsgWidth() - (6 * JKLayout.sp)) * 0.6);
        txtClientName.setTextAlignment(TextAlignment.RIGHT);

        String txtTender = JKTenderToggles.getTxtForTender(tendered);
        Text txtTenderType = JKText.getTxtDk(txtTender, JKText.FONT_B_XSM);

        Text txtFullAmountDue = JKText.getTxtDk(JKText.getDeciFormat(resp.getAmount()), JKText.FONT_B_XSM);
        Text txtAmount = JKText.getTxtDk(JKText.getDeciFormat(amountPayable), JKText.FONT_B_XSM);
        Text txtConvenienceFee = JKText.getTxtDk(JKText.getDeciFormat(resp.getConvenienceFee()), JKText.FONT_B_XSM);
//        double totalPayable = resp.getAmount() + resp.getConvenienceFee();
        double totalPayable = amountPayable + resp.getConvenienceFee();
        Text txtTotalPayable = JKText.getTxtDk(JKText.getDeciFormat(totalPayable), JKText.FONT_B_SM);
        double balance = resp.getAmount() - amountPayable;
        Text txtBalance = JKText.getTxtDk(JKText.getDeciFormat(balance), JKText.FONT_B_XSM);

        GridPane grid = JKLayout.getSummaryGrid2Col(0.4, 0.6);
        grid.setTranslateX(-JKLayout.sp);

        grid.addRow(0, lblPaying, txtAccNum);
        grid.addRow(1, lblClientName, txtClientName);
        grid.addRow(2, lblTenderType, txtTenderType);
        grid.addRow(3, lblFullAmountDue, txtFullAmountDue);
        grid.addRow(4, lblAmount, txtAmount);
        grid.addRow(5, lblConvenienceFee, txtConvenienceFee);
        grid.addRow(6, lblTotalPayable, txtTotalPayable);
        grid.addRow(7, lblBalance, txtBalance);

        return grid;
    }
}
