package jkiosk3.store;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Val
 */
public class JKPending {

    private static List<StoreJKPending> pendingList;

    public static void loadPendingList() {
        try {
            if ((pendingList == null) || (pendingList.isEmpty())) {
                pendingList = (ArrayList<StoreJKPending>) Store.loadObject(JKPending.class.getSimpleName());
            }
        } catch (Exception e) {
            pendingList = null;
        }
        if (pendingList == null) {
            pendingList = new ArrayList<>();
        }
    }

    public static boolean hasPendingItems() {
        loadPendingList();
        return pendingList.size() > 0;
    }

    public static void savePendingItem(StoreJKPending saleItem) {
        loadPendingList();
        pendingList.add(saleItem);
        Store.saveObject(JKPending.class.getSimpleName(), pendingList);
    }

    public static void removePendingItem(StoreJKPending item) {
        loadPendingList();
        pendingList.remove(item);
        Store.saveObject(JKPending.class.getSimpleName(), pendingList);
        checkForEmptyList();
    }

    private static void checkForEmptyList() {
        loadPendingList();
        if (pendingList.isEmpty()) {
            clearPending();
        } else {
            Store.saveObject(JKPending.class.getSimpleName(), pendingList);
        }
    }

    public static void clearPending() {
        if (pendingList != null) {
            pendingList.clear();
        }
        Store.deleteObject(JKPending.class.getSimpleName());
    }

    // getters and setters
    public static List<StoreJKPending> getPendingList() {
        return pendingList;
    }
}
