package jkiosk3.sales.billpay.insurance;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.insurance_policy_reg.InsPolRegisterReq;
import aeonbillpayments.insurance_policy_reg.InsPolRegisterResp;
import aeonbillpayments.insurance_policy_reg.PolicyRegisterConnection;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import jkiosk3.JKiosk3;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

/**
 *
 * @author Valerie
 */
public class PolicyRegUtil {

    private final static Logger logger = Logger.getLogger(PolicyRegUtil.class.getName());
    private static PolicyRegisterConnection conn;
    private static String userPin;
    private final static int deviceID = JKSystem.getSystemConfig().getDeviceId();
    private final static String deviceSerial = JKSystem.getSystemConfig().getSerial();
    //
    public final static String POL_TYPE_ACCIDENT = "Personal Accident";
    public final static String POL_TYPE_FUNERAL = "Funeral Policy";
    public final static String POL_TYPE_PROVIDER = "Monthly Provider";
    //
    public final static String POL_PMNT_CASH = "Cash";
    public final static String POL_PMNT_DEBIT = "Debit Order";
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdown = 60;

    private static PolicyRegisterConnection getPolicyRegisterConnect() {
        PolicyRegisterConnection prc = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = (JKSystem.getSystemConfig().getPort());
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            prc = new PolicyRegisterConnection(server, port, secureConnect);
            prc.setTimeout(countdown);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (NoRouteToHostException nre) {
            errorMsg = nre.getClass().getSimpleName() + " : " + nre.getMessage();
            logger.log(Level.SEVERE, nre.getMessage(), nre);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return prc;
    }

    public static List<String> getListPolTypes() {
        List<String> listPolTypes = new ArrayList<>();
        listPolTypes.add(POL_TYPE_ACCIDENT);
        listPolTypes.add(POL_TYPE_FUNERAL);
        listPolTypes.add(POL_TYPE_PROVIDER);

        return listPolTypes;
    }

    private static InsPolRegisterResp getInsurancePolicyRegistration(InsPolRegisterReq req) throws RuntimeException {
        InsPolRegisterResp resp = new InsPolRegisterResp();
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            conn = getPolicyRegisterConnect();
            if (conn != null) {
                if (conn.login(userPin, deviceID, deviceSerial, BillPaymentConnection.BILLPAY_PAYAT_INSURANCE)) {
                    resp = conn.getInsurancePolicyRegistration(req);
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Insurance Policy Registration Error", t);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return resp;
    }

    public static void getInsurancePolicyRegistration(final InsPolRegisterReq req, final InsPolRegisterResult result) {

        JKiosk3.getBusy().showBusy("Registering Insurance Policy");

        final Task<InsPolRegisterResp> taskInsPolReg = new Task() {
            @Override
            protected InsPolRegisterResp call() throws Exception {
                return getInsurancePolicyRegistration(req);
            }
        };

        taskInsPolReg.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    JKiosk3.getBusy().hideBusy();
                    result.insPolRegisterResult(taskInsPolReg.getValue());
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
                    taskutil.taskSaleCancelFail("Policy Registration Error",
                            "Unable to Register Policy", newState, errorMsg, new BillPaymentMenu());
                }
            }
        });
        new Thread(taskInsPolReg).start();
        JKiosk3.getBusy().startCountdown(taskInsPolReg, countdown);
    }

    public static abstract class InsPolRegisterResult {

        public abstract void insPolRegisterResult(InsPolRegisterResp result);
    }

//    public static List<BankDetail> getBankList() {
//        List<BankDetail> listBanks = BankList.getBankList();
//        if (!listBanks.isEmpty()) {
//            Collections.sort(listBanks, new Comparator<BankDetail>() {
//                    @Override
//                    public int compare(BankDetail b1, BankDetail b2) {
//                        return Integer.valueOf(b1.getBankName().compareToIgnoreCase(b2.getBankName()));
//                    }
//                });
//        }
//        return listBanks;
//    }
}
