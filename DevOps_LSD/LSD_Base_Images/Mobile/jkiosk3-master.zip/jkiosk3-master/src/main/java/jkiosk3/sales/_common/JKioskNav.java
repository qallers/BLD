package jkiosk3.sales._common;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.sales._favourites.nfc.NFCSubscriberFavourites;
import jkiosk3.users.UserUtil;

/**
 *
 * @author Val
 */
public class JKioskNav extends Region {

    private Button btnBack;
    private Button btnCancel;
    private Button btnNext;

    public JKioskNav() {
        getChildren().add(getNavGroup());
    }

    private HBox getNavGroup() {

        btnBack = JKNode.getBtnPopup("back");

        btnCancel = JKNode.getBtnPopup("cancel");

        btnNext = JKNode.getBtnPopup("next");

        HBox hbCtrl = JKLayout.getHBoxContent(JKLayout.sp);
        hbCtrl.setMaxWidth(JKLayout.contentW);
        hbCtrl.setMinWidth(JKLayout.contentW);
        hbCtrl.getChildren().addAll(btnBack, JKNode.getHSpacer(), btnCancel, JKNode.getHSpacer(), btnNext);

        return hbCtrl;
    }

    /**
     * This will reset the Sales User, if necessary, and load the designated
     * 'Region' in the Sales Scene content area.
     *
     * @param loadRegion the Region to be loaded on click of the 'cancel' button
     */
    public void setBtnCancelAction(final Region loadRegion) {
        btnCancel.setOnMouseReleased(new EventHandler<Event>() {

            @Override
            public void handle(Event t) {
//                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
//                SceneSales.clearAndChangeContent(loadRegion);
                if (ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile() != null) {
                    SceneSales.clearAndChangeContent(new NFCSubscriberFavourites(ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile()));
                } else {
                    UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
                    SceneSales.clearAndChangeContent(loadRegion);
                }
            }
        });
    }

    public Button getBtnBack() {
        return btnBack;
    }

    public Button getBtnCancel() {
        return btnCancel;
    }

    public Button getBtnNext() {
        return btnNext;
    }
}
