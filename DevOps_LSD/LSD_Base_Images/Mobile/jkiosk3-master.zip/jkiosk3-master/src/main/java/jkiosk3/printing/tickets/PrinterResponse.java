package jkiosk3.printing.tickets;

/**
 *
 *
 */
public enum PrinterResponse {

    PRINTER_RESPONSE_00("00", "00 - Ready"),
    PRINTER_RESPONSE_01("01", "01 - Paper out"),
    PRINTER_RESPONSE_02("02", "02 - Paper jam or missing gap"),
    PRINTER_RESPONSE_03("03", "03 - Ribbon out"),
    PRINTER_RESPONSE_04("04", "04 - Print head is up"),
    PRINTER_RESPONSE_05("05", "05 - Rewinder full"),
    PRINTER_RESPONSE_06("06", "06 - Memory is full"),
    PRINTER_RESPONSE_07("07", "07 - Filename can not be found"),
    PRINTER_RESPONSE_08("08", "08 - Filename duplicate"),
    PRINTER_RESPONSE_09("09", "09 - Syntax error"),
    PRINTER_RESPONSE_10("10", "10 - Cutter jam"),
    PRINTER_RESPONSE_11("11", "11 - CF Card not found"),
    PRINTER_RESPONSE_20("20", "20 - Pause"),
    PRINTER_RESPONSE_21("21", "21 - In Setting Mode"),
    PRINTER_RESPONSE_22("22", "22 - In Keyboard Mode"),
    PRINTER_RESPONSE_50("50", "50 - Printer is printing"),
    PRINTER_RESPONSE_60("60", "60 - Data in process"),
    PRINTER_MSG_Y("Y", "Print complete");

    private final String code;
    private final String description;

    private PrinterResponse(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
