package jkiosk3.sales.electricity.eskom;

import aeonelectricity.ElectricityConfirmation;
import java.util.Collections;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import static jkiosk3._common.JKLayout.sp;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.electricity.ElecShareBtnsLessMore;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.electricity.ElectricitySupplierSelect;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.store.JKOptions;
import jkiosk3.users.UserUtil;

/**
 *
 * @author Valerie
 */
public class ElecConfirmCustomer extends Region {

    private final ElectricityProvider provider;
    private TextField txtId;
    private String idType;
    private String customerId;
    private String idTypeField;
    private boolean useMagReader;
    private boolean magEntry;

    public ElecConfirmCustomer(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;
        getChildren().add(getConfirmCustomerLayout());
    }

    private VBox getConfirmCustomerLayout() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(getCustomerEntry(), getElecSaleCtrls());
        return vb;
    }

    private Group getCustomerEntry() {

        GridPane grid = JKLayout.getContentGrid2Col(0.5, 0.5);

        Label lblHead = JKText.getLblDk("Electricity Confirm Customer Details - " + provider.getDisplayName(), JKText.FONT_B_XSM);

        Label lblIdType = JKText.getLblDk("Confirm By", JKText.FONT_B_XSM);
        final Label lblId = JKText.getLblDk("", JKText.FONT_B_XSM);

        final ObservableMap<String, String> mapIdTypes = FXCollections.observableHashMap();
        mapIdTypes.put("Account", "Account Number");
        mapIdTypes.put("Name", "Customer Name");
        mapIdTypes.put("ID", "Customer ID Number");
        mapIdTypes.put("Address", "Customer Address");
        mapIdTypes.put("Meter", "Meter Number");

        ObservableList<String> listIdTypes = FXCollections.observableArrayList();
        for (String v : mapIdTypes.values()) {
            listIdTypes.add(v);
        }
        Collections.sort(listIdTypes);

        ComboBox cmbIdType = new ComboBox();
        cmbIdType.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.5), 35);
        cmbIdType.setItems(listIdTypes);
        cmbIdType.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue ov, Object oldValue, Object newValue) {
                if (newValue != null) {
                    idTypeField = newValue.toString();
                    lblId.setText(idTypeField);
                    txtId.setDisable(false);
                    txtId.clear();
                    for (String k : mapIdTypes.keySet()) {
                        if (newValue.equals(mapIdTypes.get(k))) {
                            idType = k;
                            break;
                        }
                    }
                }
            }
        });

        txtId = new TextField();
        txtId.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (idTypeField.equalsIgnoreCase(mapIdTypes.get("Meter"))) {
                    useMagReader = true;
                    magEntry = false;
                } else {
                    useMagReader = false;
                    magEntry = false;
                }
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtId, "Enter " + idTypeField, "", useMagReader, false, new KeyboardResult() {

                        @Override
                        public void onDone(String value) {
                            magEntry = JKiosk3.getKeyboard().isMagEntry();
                            if (magEntry && useMagReader) {
                                txtId.setText("TrackData");
                                txtId.setDisable(true);
                            } else {
                                txtId.setText(value);
                                txtId.setDisable(false);
                            }
                        }
                    });
                }
            }
        });

        grid.add(lblHead, 0, 0, 2, 1);
        grid.add(JKNode.createGridSpanSep(2), 0, 1);

        grid.addRow(3, lblIdType, cmbIdType);
        grid.addRow(4, lblId, txtId);

        return JKNode.getContentGroup(grid);
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        ElecShareBtnsLessMore btnsLessMore = new ElecShareBtnsLessMore();

        btnsLessMore.getBtnAccept().setDisable(false);
        btnsLessMore.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event arg0) {
                if (validateInput()) {
                    showCustomerConfirmation();
                }
            }
        });
        btnsLessMore.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity();
            }
        });

        return btnsLessMore;
    }

    private void showCustomerConfirmation() {
        String transType = "EskomDirect";
        ElectricityUtil.getCustomerConfirm(transType, customerId, idType, new ElectricityUtil.EskomCustomerConfirmationResult() {

            @Override
            public void eskomCustomerConfirmationResult(ElectricityConfirmation confirmation) {
                if (confirmation.isSuccess()) {
                    JKiosk3.getMsgBox().showMsgBox("Customer Confirmation", "", getCustomerConfirmationGrid(confirmation),
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    ElectricityUtil.resetElectricity();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Confirm Customer Error",!confirmation.getAeonErrorText ().isEmpty () ?
                                    confirmation.getAeonErrorText():confirmation.getErrorText(),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    SceneSales.clearAndChangeContent(new ElectricitySupplierSelect());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private GridPane getCustomerConfirmationGrid(ElectricityConfirmation conf) {
        GridPane grid = JKLayout.getSummaryGrid2Col(0.5, 0.5);

        Label lblName = JKText.getLblDk("Customer Name", JKText.FONT_B_XSM);
        Label lblAddr = JKText.getLblDk("Customer Address", JKText.FONT_B_XSM);
        Label lblAcc = JKText.getLblDk("Account Number", JKText.FONT_B_XSM);
        Label lblDays = JKText.getLblDk("Days Since Last Purchase", JKText.FONT_B_XSM);
        Label lblFbe = JKText.getLblDk("FBE Due", JKText.FONT_B_XSM);
        Label lblVend = JKText.getLblDk("Can Vend", JKText.FONT_B_XSM);
        Label lblUtil = JKText.getLblDk("Utility Name", JKText.FONT_B_XSM);
        Label lblMeter = JKText.getLblDk("Meter Number", JKText.FONT_B_XSM);
        lblMeter.setTranslateX(sp);
        Label lblSgc = JKText.getLblDk("SGC", JKText.FONT_B_XSM);
        lblSgc.setTranslateX(sp);
        Label lblTt = JKText.getLblDk("TT", JKText.FONT_B_XSM);
        lblTt.setTranslateX(sp);
        Label lblTi = JKText.getLblDk("TI", JKText.FONT_B_XSM);
        lblTi.setTranslateX(sp);
        Label lblKrn = JKText.getLblDk("KRN", JKText.FONT_B_XSM);
        lblKrn.setTranslateX(sp);
        Label lblAlg = JKText.getLblDk("ALG", JKText.FONT_B_XSM);
        lblAlg.setTranslateX(sp);

        Text txtName = JKText.getTxtDk(conf.getCustomerName(), JKText.FONT_B_XSM);
        Text txtAddr = JKText.getTxtDk(conf.getCustomerAddress(), JKText.FONT_B_XSM);
        txtAddr.setWrappingWidth((MessageBox.getMsgWidth() - (2 * sp)) * 0.5);
        txtAddr.setTextAlignment(TextAlignment.RIGHT);
        Text txtAcc = JKText.getTxtDk(conf.getAccountNumber(), JKText.FONT_B_XSM);
        Text txtDays = JKText.getTxtDk(Integer.toString(conf.getDaysLastPurchase()), JKText.FONT_B_XSM);
        String strFbe = "";
        if (conf.isFbeDue()) {
            strFbe = "Yes";
        } else {
            strFbe = "No";
        }
        Text txtFbe = JKText.getTxtDk(strFbe, JKText.FONT_B_XSM);
        String strVend = "";
        if (conf.canVend()) {
            strVend = "Yes";
        } else {
            strVend = "No";
        }
        Text txtVend = JKText.getTxtDk(strVend, JKText.FONT_B_XSM);
        Text txtUtil = JKText.getTxtDk(conf.getUtility(), JKText.FONT_B_XSM);
        Text txtMeter = JKText.getTxtDk(conf.getMeterNumber(), JKText.FONT_B_XSM);
        txtMeter.setTranslateX(-sp);
        Text txtSgc = JKText.getTxtDk(conf.getSgc(), JKText.FONT_B_XSM);
        txtSgc.setTranslateX(-sp);
        Text txtTt = JKText.getTxtDk(conf.getTt(), JKText.FONT_B_XSM);
        txtTt.setTranslateX(-sp);
        Text txtTi = JKText.getTxtDk(conf.getTi(), JKText.FONT_B_XSM);
        txtTi.setTranslateX(-sp);
        Text txtKrn = JKText.getTxtDk(conf.getKrn(), JKText.FONT_B_XSM);
        txtKrn.setTranslateX(-sp);
        Text txtAlg = JKText.getTxtDk(conf.getAt(), JKText.FONT_B_XSM);
        txtAlg.setTranslateX(-sp);

        grid.addRow(0, lblName, txtName);
        grid.addRow(1, lblAddr, txtAddr);
        grid.addRow(2, lblAcc, txtAcc);
        grid.addRow(3, lblDays, txtDays);
        grid.addRow(4, lblFbe, txtFbe);
        grid.addRow(5, lblVend, txtVend);
        grid.addRow(6, lblUtil, txtUtil);
        grid.addRow(7, lblMeter, txtMeter);
        grid.addRow(8, lblSgc, txtSgc);
        grid.addRow(9, lblTt, txtTt);
        grid.addRow(10, lblTi, txtTi);
        grid.addRow(11, lblKrn, txtKrn);
        grid.addRow(12, lblAlg, txtAlg);

        return grid;
    }

    private boolean validateInput() {
        if (idType == null || idType.isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Confirm By", "Please select an item from the 'Confirm By' list", null);
            return false;
        }
        if (txtId.getText() == null || txtId.getText().trim().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox(idTypeField, "Please enter details required in the " + idTypeField + " field", null);
            return false;
        } else {
            customerId = txtId.getText().trim().replaceAll(";(.+)\\?", "$1");
        }
        return true;
    }
}
