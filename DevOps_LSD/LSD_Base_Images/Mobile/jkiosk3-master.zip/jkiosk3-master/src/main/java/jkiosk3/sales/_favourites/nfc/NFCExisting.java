package jkiosk3.sales._favourites.nfc;

import aeonusers.User;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._components.NumberPadResult;
import jkiosk3._components.SceneBackground;
import jkiosk3.sales.SceneSales;
import jkiosk3.users.SalesUserLoginResult;
import jkiosk3.users.UserUtil;
import za.co.blt.consumer.loyalty.api.service.model.response.CompleteConsumerProfile;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfile;
import za.co.blt.consumer.loyalty.api.service.model.response.Favourite;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

public class NFCExisting extends Region {

    private final static Logger logger = Logger.getLogger(NFCExisting.class.getName());

    private NFCSubscriberInput nfcSubscriberInput;
    private ConsumerProfile consumerProfile;
    private CompleteConsumerProfile completeConsumerProfile;

    private String cardNum;
    private String cellNum;
    private String queryBy;
    private String queryNum;

    public NFCExisting() {
        nfcSubscriberInput = new NFCSubscriberInput(true, true);
        getChildren().add(getExistingEntry());
    }

    private VBox getExistingEntry() {
        VBox vBox = JKLayout.getVBox(0, JKLayout.sp);
        vBox.setStyle("-fx-padding: 30px 0px 0px 0px;");
        vBox.getChildren().addAll(nfcSubscriberInput, JKNode.createContentSep(),
                getBtnFavourites(), JKNode.createContentSep(), getMenuButtons());

        return vBox;
    }

    private Button getBtnFavourites() {
        final Integer[] allowAll = {UserUtil.LEVEL_CASHIER, UserUtil.LEVEL_SUPERVISOR, UserUtil.LEVEL_CASHIER_PLUS};

        final Button btnFav = JKNode.getBtnNFC(NFCUtil.NFC_FAVOURITES);
        btnFav.setId(NFCUtil.NFC_FAVOURITES);
        btnFav.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event evt) {
                if (isValidEntry()) {
                    getMenuAction(btnFav, allowAll);
                }
            }
        });
        return btnFav;
    }

    private FlowPane getMenuButtons() {
        List<Node> listBtns = new ArrayList<>();
        String[] btnLabels = {NFCUtil.NFC_EDIT, NFCUtil.NFC_LOST_CARD, NFCUtil.NFC_CANCEL};
        final Integer[] levelRestrict = {UserUtil.LEVEL_SUPERVISOR, UserUtil.LEVEL_CASHIER_PLUS};

        for (String s : btnLabels) {
            final Button btn = JKNode.getBtnNFC(s);
            btn.setMaxWidth((JKLayout.contentW - (4 * JKLayout.sp)) / 3);
            btn.setMinWidth((JKLayout.contentW - (4 * JKLayout.sp)) / 3);
            btn.setId(s);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    if (isValidEntry()) {
                        getMenuAction(btn, levelRestrict);
                    }
                }
            });
            listBtns.add(btn);
        }

        FlowPane flowPaneAccessRestrict = JKLayout.getFlowPane(listBtns);

        return flowPaneAccessRestrict;
    }

    private void getMenuAction(final Button b, Integer[] levelsAllowed) {
        logger.info(("NFC button selected : ").concat(b.getId()).concat(" :: User levels allowed : ").concat(Arrays.toString(levelsAllowed)));
        List<Integer> listAllowed = Arrays.asList(levelsAllowed);

//      If list contains 'Cashier (0)', then anyone, Cashier and above, can access this item
        if (listAllowed.contains(UserUtil.LEVEL_CASHIER)) {

            JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
                @Override
                public void onDone() {
                    switch (b.getId()) {
                        case NFCUtil.NFC_FAVOURITES:                    // Cashier access (0, 1, 2)
                            setQueryParams();
                            NFCUtil.readConsumerProfileComplete(queryBy, queryNum, new NFCUtil.CompleteConsumerProfileResult() {
                                @Override
                                public void completeConsumerProfileResult(CompleteConsumerProfile completeConsumerProf) {
                                    if (completeConsumerProf != null) {
                                        completeConsumerProfile = completeConsumerProf;
                                        consumerProfile = completeConsumerProfile.getConsumer();
                                        ActiveNFCSubscriber.getInstance().setCompleteConsumerProfile(completeConsumerProfile);
                                        ActiveNFCSubscriber.getInstance().setConsumerProfile(completeConsumerProfile.getConsumer());
                                        if (completeConsumerProfile.getFavourites() == null) {
                                            System.out.println("NO FAVOURITES YET FOR THIS CONSUMER!");
                                            List<Favourite> listFavs = new ArrayList<>();
                                            completeConsumerProfile.setFavourites(listFavs);
                                        }
                                        SceneSales.clearAndChangeContent(new NFCSubscriberFavourites(completeConsumerProfile));
                                        SceneBackground.updateSupportView(new ActiveNFCDisplay(completeConsumerProfile));
                                        SceneBackground.setAnchorBackground(true);
                                    } else {
                                        NFCUtil.resetNFCView();
                                    }
                                }
                            });
                            break;
                        default:
                            NFCUtil.resetNFCView();
                            break;
                    }
                }
            });
//      If list does NOT contain 'Cashier (0)', then request login for Cashier Plus or Supervisor
        } else {
            JKiosk3.getNumPad().showNumPad(new PasswordField(), "Enter User Pin", "", new NumberPadResult() {
                @Override
                public void onDone(String value) {
                    UserUtil.getLoggedInUser(value, new UserUtil.LoggedInUserResult() {
                        @Override
                        public void loggedInUserResult(final User loggedInUser) {
                            if (loggedInUser.isSuccess()) {
                                int userLevel = loggedInUser.getUserLevel();
                                if (userLevel == UserUtil.LEVEL_CASHIER) {
                                    JKiosk3.getMsgBox().showMsgBox("Access Denied",
                                            "Menu Item not available for this Access Level", null);
                                } else if (userLevel == UserUtil.LEVEL_SUPERVISOR || userLevel == UserUtil.LEVEL_CASHIER_PLUS) {

                                    setQueryParams();
                                    NFCUtil.readConsumerProfile(queryBy, queryNum, new NFCUtil.ConsumerProfileResult() {
                                        @Override
                                        public void consumerProfileResult(ConsumerProfile consumerProf) {
                                            if (consumerProf != null) {
                                                consumerProfile = consumerProf;
                                                switch (b.getId()) {
                                                    case NFCUtil.NFC_EDIT:                          // Supervisor and Cashier Plus access (1, 2)
                                                        SceneSales.clearAndChangeContent(new NFCSubscriberEdit(loggedInUser, consumerProfile));
                                                        break;
                                                    case NFCUtil.NFC_LOST_CARD:                     // Supervisor and Cashier Plus access (1, 2)
                                                        SceneSales.clearAndChangeContent(new NFCSubscriberReplaceCard(loggedInUser, consumerProfile));
                                                        break;
                                                    case NFCUtil.NFC_CANCEL:                        // Supervisor and Cashier Plus access (1, 2)
                                                        SceneSales.clearAndChangeContent(new NFCSubscriberCancel(loggedInUser, consumerProfile));
                                                        break;
                                                    default:
                                                        NFCUtil.resetNFCView();
                                                        break;
                                                }
                                            } else {
                                                NFCUtil.resetNFCView();
                                            }
                                        }
                                    });
                                }
                            } else {
                                JKiosk3.getMsgBox().showMsgBox("Login Failed",
                                        loggedInUser.getErrorCode() + " - " + loggedInUser.getErrorText(), null);
                            }
                        }
                    });
                }
            });
        }
    }

    private void setQueryParams() {
        if (!cardNum.isEmpty() || !cardNum.equals("")) {
            queryBy = NFCUtil.QUERY_BY_CARD;
            queryNum = cardNum;
        } else if (!cellNum.isEmpty() || !cellNum.equals("")) {
            queryBy = NFCUtil.QUERY_BY_CELL;
            queryNum = cellNum;
        }
    }

    private boolean isValidEntry() {
        cardNum = nfcSubscriberInput.getCardNumber();
        cellNum = nfcSubscriberInput.getCellNumber();

        if ((cardNum.isEmpty() || cardNum.equals(""))
                && (cellNum.isEmpty() || cellNum.equals(""))) {
            JKiosk3.getMsgBox().showMsgBox("Card or Cell Number", "Please enter either a Card Number or a Cell Number", null);
            return false;
        }
        if ((!cardNum.isEmpty() || !cardNum.equals(""))
                && (!cellNum.isEmpty() || !cellNum.equals(""))) {
            JKiosk3.getMsgBox().showMsgBox("Card or Cell Number", "Please enter EITHER" +
                    "\na Card Number OR a Cell Number, \nnot both", null);
            return false;
        }

        return true;
    }
}
