package jkiosk3._components;

import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

/**
 *
 * @author Val
 */
public class ControlSearch extends Region {

    private Button btnSearch;
    private Button btnClear;

    public ControlSearch() {
        getChildren().add(getSearchControlButtons());
    }

    private HBox getSearchControlButtons() {
        HBox hb = JKLayout.getHBox(0, JKLayout.sp);

        btnSearch = JKNode.getBtnPopup("search");

        btnClear = JKNode.getBtnPopup("clear");

        hb.getChildren().addAll(btnSearch, btnClear);

        return hb;
    }

    public Button getBtnSearch() {
        return btnSearch;
    }

    public Button getBtnClear() {
        return btnClear;
    }
}
