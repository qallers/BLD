package jkiosk3.store.cache;

import aeoncoach.CoachCarriersList;

import java.io.Serializable;

public class ListCoachCarriers implements Serializable {

    // L(ist)  = 12 (1 + 2 = 3)
    // C(oach) = 3
    // C(arriers) = 3
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 99033L;

    private CoachCarriersList coachCarriersList = new CoachCarriersList();

    public CoachCarriersList getCoachCarriersList() {
        return coachCarriersList;
    }

    public void setCoachCarriersList(CoachCarriersList coachCarriersList) {
        this.coachCarriersList = coachCarriersList;
    }

}
