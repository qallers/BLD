package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.PrintClient;
import jkiosk3.printing.PrintHandler;
import jkiosk3.store.JKSalesOptions;

/**
 *
 * @author Val
 */
public class ShiftEnd extends Region {

    private final static Logger logger = Logger.getLogger(ShiftEnd.class.getName());

    public ShiftEnd() {
        VBox vbShiftEnd = JKLayout.getVBox(0, JKLayout.spNum);

        vbShiftEnd.getChildren().addAll(getShiftEndGroup(), getPrintControl());

        getChildren().addAll(vbShiftEnd);
    }

    private VBox getShiftEndGroup() {

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);

        Label lblHead = JKText.getLblContentHead("End Shift - "
                + new SimpleDateFormat("dd MMMM yyyy - HH:mm").format(new java.util.Date()));

        vb.getChildren().addAll(lblHead, JKNode.createContentSep());

        return vb;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls("End Shift") {
            @Override
            public void onClickPrint() {
                doEndShift();
            }
        };
    }

    public static void doEndShift() {
        JKiosk3.getMsgBox().showMsgBox("End Shift", "Are you sure you wish to end this shift?", null,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult() {
                    @Override
                    public void onOk() {
                        showShiftViewReport();
                    }

                    @Override
                    public void onCancel() {
                        JKiosk3.getMsgBox().showMsgBox("Shift Not Ended!", "The shift will not be ended at this time", null);
                    }
                });
    }

    private static void showShiftViewReport() {
        try {
            ReportUtil.getPrintShiftEndReport(new ReportUtil.AeonPrintJobResult() {
                @Override
                public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                    if (!aeonPrintJob.getLines().isEmpty()) {
                        PrintHandler.handlePrintRequestReport("End of Shift Report", aeonPrintJob);
                        if (JKSalesOptions.getSalesOptions().isUseCashDrawer()) {
                            if (JKSalesOptions.getSalesOptions().isCashDrawerOpenOnEndShift()) {
                                // pop cash drawer open...
                                new PrintClient().cashDraw();
                            }
                        }
                    }
                }
            });
        } catch (Exception e) {
            JKiosk3.getMsgBox().showMsgBox("End Shift Error", "Please try again later", null);
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
    }
}
