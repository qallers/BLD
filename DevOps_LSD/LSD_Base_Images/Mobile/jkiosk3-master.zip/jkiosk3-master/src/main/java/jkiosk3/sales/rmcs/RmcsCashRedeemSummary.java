package jkiosk3.sales.rmcs;

import javafx.geometry.HPos;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;

/**
 *
 *
 */
public class RmcsCashRedeemSummary extends Region {

    public RmcsCashRedeemSummary() {
        getChildren().add(getRedeemSuccess());
    }

    private VBox getRedeemSuccess() {
        double sp = JKLayout.sp;
        VBox vb = JKLayout.getVBox(0, (4 * sp));
        vb.setMaxWidth(MessageBox.getMsgWidth() - (6 * sp));
        vb.setMinWidth(MessageBox.getMsgWidth() - (6 * sp));

        String success = "Voucher Number\n\n" + RmcsUtil.getVoucherDisplayFormat(RmcsRedeem.getInstance().getRedeemReq().getVoucherNum())
                + "\n\nhas been successfully redeemed";
        Label lblSuccess = JKText.getLblDk(success, JKText.FONT_B_XSM);
        lblSuccess.setTextAlignment(TextAlignment.CENTER);

        Label lblVoucherValue = JKText.getLblDk("Pay to Customer", JKText.FONT_B_XSM);

        Text txtVoucherValue = JKText.getTxtDk("R " + JKText.getDeciFormat(RmcsRedeem.getInstance().getRedeemResp().getAmount()),
                JKText.FONT_B_XSM);

        GridPane grid = new GridPane();
        grid.setMaxWidth((MessageBox.getMsgWidth() / 2) + (2 * sp));
        grid.setMinWidth((MessageBox.getMsgWidth() / 2) + (2 * sp));
        ColumnConstraints col0 = new ColumnConstraints();
        col0.setPercentWidth(60);
        col0.setHalignment(HPos.LEFT);
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPercentWidth(40);
        col1.setHalignment(HPos.RIGHT);
        grid.getColumnConstraints().addAll(col0, col1);

        grid.addRow(2, lblVoucherValue, txtVoucherValue);

        vb.getChildren().addAll(lblSuccess, grid);

        return vb;
    }
}
