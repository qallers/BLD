package jkiosk3.sales._favourites.nfc;

import aeonairtime.AirtimeManufacturer;
import aeonairtime.AirtimeProduct;
import aeonbillpayments.Product;
import aeonbillpayments.Provider;
import aeontopup.TopupBundleCategory;
import aeontopup.TopupBundleProduct;
import aeontopup.TopupBundleProductList;
import aeonusers.UserTransactionType;
import aeonvarivouchers.Supplier;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.ProviderType;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.topups.TopupProvider;
import jkiosk3.sales.topups.TopupSale;
import jkiosk3.store.cache.*;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerHistory;
import za.co.blt.consumer.loyalty.api.service.model.response.Favourite;

import java.util.*;

public class NFCUtilFav {

    public static List<String> getDeviceTransactionTypes() {
        List<UserTransactionType> listUtt = CacheListTransTypes.getListTransactionTypes();
        List<String> listTransTypes = new ArrayList<>();
        for (UserTransactionType u : listUtt) {
            listTransTypes.add(u.getTransactionType());
        }
        return listTransTypes;
    }

    public static List<String> getElectricityMeterNumsFav(ElectricityProvider provider) {
        List<String> listMeterNums = new ArrayList<>();
        if (ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile() != null
                && !ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites().isEmpty()) {
            for (Favourite fav : ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites()) {
                if ((fav.getTrxType() != null) && fav.getTrxType().equalsIgnoreCase(provider.getTransactionType())) {
                    if (!fav.getHistory().isEmpty()) {
                        for (ConsumerHistory h : fav.getHistory()) {
                            if (!h.getAccount().isEmpty()) {
                                listMeterNums.add(h.getAccount());
                            }
                        }
                    }
                }
            }
        }
        return listMeterNums;
    }

    public static List<String> getTopAirMobileNumsFav() {
        List<String> listMobileNums = new ArrayList<>();
        if (ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile() != null
                && !ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites().isEmpty()) {
            if (TopupSale.getInstance().getProvider() != null) {
                for (Favourite fav : ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites()) {
                    if (fav.getTrxType().equalsIgnoreCase(TopupSale.getInstance().getProvider().getName())) {
                        if (!fav.getHistory().isEmpty()) {
                            for (ConsumerHistory h : fav.getHistory()) {
                                String mobileHist = h.getAccount();
                                String mobileNum = "";
                                if (mobileHist.startsWith("27")) {
                                    String mtmp = mobileHist.substring(2);
                                    mobileNum = "0" + mtmp;
                                } else {
                                    mobileNum = mobileHist;
                                }
                                listMobileNums.add(mobileNum);
                            }
                        }
                    }
                }
            }
        }
        return listMobileNums;
    }

    public static List<String> getBillPayAccNumsFav(BillPayProduct product) {
        List<String> listAccNums = new ArrayList<>();
        if (ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile() != null
                && !ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites().isEmpty()) {
            for (Favourite fav : ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites()) {
                if (fav.getTrxGroup().equalsIgnoreCase("Payments") && fav.getProductId().equals(Integer.toString(product.getProdId()))) {
                    if (fav.getHistory() != null) {
                        if (!fav.getHistory().isEmpty()) {
                            for (ConsumerHistory h : fav.getHistory()) {
                                String accNum = h.getAccount();
//                                if (product.getAdditionalFields() == 2 && accNum.length() == 10) {
//                                    String barcode = String.format("%013d", 0);
//                                    String accountStr = h.getAccount();
//                                    String amountStr = String.format("%012d", 0);
//                                    String checkDigit = "0";
//                                    accNum = barcode + accountStr + amountStr + checkDigit;
//                                }
                                if (product.getAdditionalFields() == 2 && accNum.length() == 36) {
                                    accNum = h.getAccount().substring(13, 23);
                                }
                                listAccNums.add(accNum);
                            }
                        }
                    }
                }
            }
        }

        return listAccNums;
    }

    // delete from here once all works...

//    public static List<String> getDeviceTransactionTypes() {
//        List<UserTransactionType> listUtt = CacheListTransTypes.getListTransactionTypes();
//        List<String> listTransTypes = new ArrayList<>();
//        for (UserTransactionType u : listUtt) {
//            listTransTypes.add(u.getTransactionType());
//        }
//        return listTransTypes;
//    }
//
//    public static List<AirtimeManufacturer> getFavouriteVoucherList(List<Favourite> listFavourites) {
//        List<AirtimeManufacturer> listFavVouchers = new ArrayList<>();
//        List<String> listprodids = new ArrayList<>();
//        for (Favourite fav : listFavourites) {
//            if (fav.getTrxType().equalsIgnoreCase("Voucher")) {
//                for (AirtimeManufacturer m : CacheListAirtimeManufacturers.getListAirtimeManufacturers()) {
//                    AirtimeManufacturer favMan = new AirtimeManufacturer();
//                    favMan.setName(m.getName());
//                    favMan.setRechargePlus(m.isRechargePlus());
//                    for (AirtimeProduct p : m.getProducts()) {
//                        if (fav.getProductId().equals(Integer.toString(p.getProductID()))) {
//                            listprodids.add(fav.getProductId());
//                            favMan.getProducts().add(p);
//                        }
//                    }
//                    if (!favMan.getProducts().isEmpty()) {
//                        Collections.sort(favMan.getProducts(), new Comparator<AirtimeProduct>() {
//                            @Override
//                            public int compare(AirtimeProduct o1, AirtimeProduct o2) {
//                                return Integer.valueOf(o1.getCategoryId()).compareTo(o2.getCategoryId());
//                            }
//                        });
//                        listFavVouchers.add(favMan);
//                    }
//                }
//            }
//        }
//        return listFavVouchers;
//    }
//
//    public static List<Supplier> getFavouriteC4C(List<Favourite> listFavourites) {
//        List<Supplier> listC4C = new ArrayList<>();
//        List<Supplier> listSuppliers = CacheListC4CSuppliers.getListC4CSuppliers();
//        for (Favourite fav : listFavourites) {
//            if (fav.getTrxType().equalsIgnoreCase("C4C_Voucher")) {
//                for (Supplier s : listSuppliers) {
//                    if (fav.getProductId().equals(Integer.toString(s.getCode()))) {
//                        listC4C.add(s);
//                    }
//                }
//            }
//        }
//        return listC4C;
//    }
//
//    public static List<TopupProvider> getFavouriteTopupAirtime(List<Favourite> listFavourites) {
//        List<TopupProvider> listTopupAirtime = new ArrayList<>();
//        for (Favourite fav : listFavourites) {
//            if (fav.getTrxGroup().equalsIgnoreCase("Topup")) {
//                for (UserTransactionType utt : CacheListTransTypes.getListTransactionTypes()) {
//                    if (fav.getTrxType().equalsIgnoreCase(utt.getTransactionType())) {
//                        TopupProvider topAir = new TopupProvider(utt.getTransactionType(), utt.getDisplayName(), 0);
//                        listTopupAirtime.add(topAir);
//                    }
//                }
//            }
//        }
//        return listTopupAirtime;
//    }
//
//    public static List<TopupProvider> getFavouriteTopupBundles(List<Favourite> listFavourites) {
//        List<TopupProvider> listTopupBundle = new ArrayList<>();
//        for (Favourite fav : listFavourites) {
//            if (fav.getTrxGroup().equalsIgnoreCase("Bundles")) {
//                for (UserTransactionType utt : CacheListTransTypes.getListTransactionTypes()) {
//                    if (fav.getTrxType().equalsIgnoreCase(utt.getTransactionType())) {
//                        TopupProvider topBundle = new TopupProvider(utt.getTransactionType(), utt.getDisplayName(), 0);
//                        topBundle.setListBundles(new TopupBundleProductList());
//                        for (TopupProvider p : CacheListTopupBundles.getListTopupProviders()) {
//                            for (TopupBundleCategory c : p.getListBundles().getlistCategories()) {
//                                TopupBundleCategory cat = new TopupBundleCategory();
//                                cat.setName(c.getName());
//                                cat.setType(c.getType());
//                                for (TopupBundleProduct prod : c.getListProducts()) {
//                                    if (fav.getProductId().equals(Integer.toString(prod.getProductCode()))) {
//                                        cat.getListProducts().add(prod);
//                                    }
//                                }
//                                if (!cat.getListProducts().isEmpty()) {
//                                    topBundle.getListBundles().getlistCategories().add(cat);
//                                }
//                            }
//                        }
//                        if (!topBundle.getListBundles().getlistCategories().isEmpty()) {
//                            listTopupBundle.add(topBundle);
//                        }
//                    }
//                }
//            }
//        }
//        return listTopupBundle;
//    }
//
//    public static List<ElectricityProvider> getFavouriteElectricity(List<Favourite> listFavourites) {
//        List<ElectricityProvider> listElecProv = new ArrayList<>();
//        for (Favourite fav : listFavourites) {
//            if (fav.getTrxGroup().equalsIgnoreCase("Electricity")) {
//                for (UserTransactionType utt : CacheListTransTypes.getListTransactionTypes()) {
//                    if (fav.getTrxType().equalsIgnoreCase(utt.getTransactionType())) {
//                        ElectricityProvider ep = new ElectricityProvider();
//                        ep.setTransactionType(utt.getTransactionType());
//                        ep.setType(utt.getType());
//                        ep.setDisplayName(utt.getDisplayName());
//                        listElecProv.add(ep);
//                    }
//                }
//            }
//        }
//        return listElecProv;
//    }
//
//    public static List<BillPayProduct> getFavouriteBillPayProducts(List<Favourite> listFavourites) {
//        List<Provider> listFavBPProv = getListBPProviders(listFavourites);
//        List<BillPayProduct> listBillPayments = new ArrayList<>();
//
//        for (Provider p : listFavBPProv) {
//            for (Product pp : p.getProvProducts()) {
//                BillPayProduct bpProd = new BillPayProduct();
//                switch (p.getProvName()) {
//                    case BillPayUtilMisc.PAYAT_BILL_PAY:
////                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.PAYAT_BILL_PAYMENT, BPTransType.BILLPAY_PAYAT_ACCOUNT);
//                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_PAYAT_ACCOUNT);
//                        listBillPayments.add(bpProd);
//                        break;
//                    case BillPayUtilMisc.PAYAT_INSURANCE:
////                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.PAYAT_INSURANCE_POLICY, BPTransType.BILLPAY_PAYAT_INSURANCE);
//                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_PAYAT_INSURANCE);
//                        listBillPayments.add(bpProd);
//                        break;
//                    case BillPayUtilMisc.PAYAT_TRAFFIC_FINES:
////                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.PAYAT_TRAFFIC_FINE, BPTransType.BILLPAY_PAYAT_TRAFFIC);
//                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_PAYAT_TRAFFIC);
//                        listBillPayments.add(bpProd);
//                        break;
//                    case BillPayUtilMisc.SYNTELL_BILL_PAY:
////                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.SYNTELL_BILL_PAYMENT, BPTransType.BILLPAY_SYNTELL_ACCOUNT);
//                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_SYNTELL_ACCOUNT);
//                        listBillPayments.add(bpProd);
//                        break;
//                    case BillPayUtilMisc.SYNTELL_TRAFFIC_FINES:
////                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.SYNTELL_TRAFFIC_FINE, BPTransType.BILLPAY_SYNTELL_TRAFFIC);
//                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_SYNTELL_TRAFFIC);
//                        listBillPayments.add(bpProd);
//                        break;
//                    case BillPayUtilMisc.SAPO_BILL_PAY:
////                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.SAPO_BILL_PAYMENT, BPTransType.BILLPAY_SAPO_ACCOUNT);
//                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_SAPO_ACCOUNT);
//                        listBillPayments.add(bpProd);
//                        break;
//                    case BillPayUtilMisc.BLU_BILL_PAY:
////                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.BLU_BILL_PAYMENT, BPTransType.BILLPAY_BLU_ACCOUNT);
//                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_BLU_ACCOUNT);
//                        listBillPayments.add(bpProd);
//                        break;
//                    case BillPayUtilMisc.BLU_M2M_TRANSFER:
////                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.BLU_M2M_TRANSFER, BPTransType.BILLPAY_BLU_M2M);
//                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_BLU_M2M);
//                        listBillPayments.add(bpProd);
//                        break;
//                    default:
//                        break;
//                }
//            }
//        }
//
//        Collections.sort(listBillPayments, new Comparator<BillPayProduct>() {
//            @Override
//            public int compare(BillPayProduct p1, BillPayProduct p2) {
//                return p1.getProdName().compareToIgnoreCase(p2.getProdName());
//            }
//        });
//
//        return listBillPayments;
//    }
//
//    private static List<Provider> getListBPProviders(List<Favourite> listFavourites) {
//        List<Provider> listBPProviders = new ArrayList<>();
//        List<Provider> listCached = CacheListBillPaymentProviders.getListBillPaymentProviders();
//        for (Favourite fav : listFavourites) {
//            if (fav.getTrxGroup().equalsIgnoreCase("Payments")) {
//                for (Provider p : listCached) {
//                    Provider prov = new Provider();
//                    prov.setProvId(p.getProvId());
//                    prov.setProvName(p.getProvName());
//                    for (Product prod : p.getProvProducts()) {
//                        if (fav.getProductId().equalsIgnoreCase(Integer.toString(prod.getProdId()))) {
//                            prov.getProvProducts().add(prod);
//                        }
//                    }
//                    if (!prov.getProvProducts().isEmpty()) {
//                        Collections.sort(prov.getProvProducts(), new Comparator<Product>() {
//                            @Override
//                            public int compare(Product o1, Product o2) {
//                                return o1.getProdName().compareTo(o2.getProdName());
//                            }
//                        });
//                        listBPProviders.add(prov);
//                    }
//                }
//            }
//        }
//        return listBPProviders;
//    }
//
//    // SHOULD NOT NEED THIS - the BillPayProduct should let us sort by "ProviderType"
////    public static List<BillPayProduct> getFavouriteBillPayTrafFines(List<Favourite> listFavourites) {
////        List<Provider> listFavBPProv = getListBPTrafFines(listFavourites);
////        List<BillPayProduct> listBillPayTrafFines = new ArrayList<>();
////
////        return listBillPayTrafFines;
////    }
//
////    private static List<Provider> getListBPTrafFines(List<Favourite> listFavourites) {
////        List<Provider> listBPProviders = new ArrayList<>();
////        List<Provider> listCached = CacheListBillPaymentProviders.getListBillPaymentProviders();
////        for (Favourite fav : listFavourites) {
////            if (fav.getTrxGroup().equalsIgnoreCase("Payments")
////                    && ((fav.getTrxType().equalsIgnoreCase("VASPayAtFinePayment"))
////                    || (fav.getTrxType().equalsIgnoreCase("VASSyntellFinePayment")))) {
////                for (Provider p : listCached) {
////                    Provider prov = new Provider();
////                    prov.setProvId(p.getProvId());
////                    prov.setProvName(p.getProvName());
////                    for (Product prod : p.getProvProducts()) {
////                        if (fav.getProductId().equalsIgnoreCase(Integer.toString(prod.getProdId()))) {
////                            prov.getProvProducts().add(prod);
////                        }
////                    }
////                    if (!prov.getProvProducts().isEmpty()) {
////                        Collections.sort(prov.getProvProducts(), new Comparator<Product>() {
////                            @Override
////                            public int compare(Product o1, Product o2) {
////                                return o1.getProdName().compareTo(o2.getProdName());
////                            }
////                        });
////                        listBPProviders.add(prov);
////                    }
////                }
////            }
////        }
////        return listBPProviders;
////    }
//
////    private static BillPayProduct makeCopyBillPayProduct(Provider prov, Product prod, ProviderType provType, BPTransType bpTransType) {
//    private static BillPayProduct makeCopyBillPayProduct(Provider prov, Product prod, BPTransType bpTransType) {
//        BillPayProduct prodPay = new BillPayProduct();
//        prodPay.setProvId(prov.getProvId());
//        prodPay.setProvName(prov.getProvName());
//        prodPay.setProdId(prod.getProdId());
//        prodPay.setProdName(prod.getProdName());
//        prodPay.setVerify(prod.isVerify());
//        prodPay.setFullAmount(prod.isFullAmount());
//        prodPay.setAdditionalFields(prod.getAdditionalFields());
//        prodPay.setProdMaxAmount(prod.getProdMaxAmount());
//        prodPay.setProdMinAmount(prod.getProdMinAmount());
//        prodPay.setEnforceFullPayment(prod.isEnforceFullPayment());
//
//        List<String> listTenders = new ArrayList<>();
//        for (String s : prod.getPaymentType()) {
//            String str = s.replaceAll(" ", "").toLowerCase(Locale.ENGLISH);
//            listTenders.add(str);
//        }
//        prodPay.setTendersAllowed(listTenders);
//        prodPay.setReversalSupported(false);
////        prodPay.setProvType(provType);
//        prodPay.setBpTransType(bpTransType);
//
//        return prodPay;
//    }
//
////    public static List<String> getFavouriteTicketEvents(List<Favourite> listFavourites) {
////        List<String> listTicketEvents = new ArrayList<>();
////        for (Favourite fav : listFavourites) {
////            if (fav.getTrxType().equalsIgnoreCase("TKP_TICKET")) {
////                listTicketEvents.add(fav.getTrxType());
////            }
////        }
////        return listTicketEvents;
////    }
//
//    public static List<String> getFavouriteTicketing(List<Favourite> listFavourites) {
//        List<String> listTicketing = new ArrayList<>();
//        for (Favourite fav : listFavourites) {
//            if (fav.getTrxGroup().equalsIgnoreCase("Tickets")) {
//                listTicketing.add(fav.getTrxType());
//            }
//        }
//        return listTicketing;
//    }
//
//    public static List<String> getFavouriteIthuba(List<Favourite> listFavourites) {
//        List<String> listIthuba = new ArrayList<>();
//        for (Favourite fav : listFavourites) {
//            if (fav.getTrxType().equalsIgnoreCase("Ithuba")) {
//                listIthuba.add(fav.getTrxType());
//            }
//        }
//        return listIthuba;
//    }
//
//    public static List<String> getElectricityMeterNumsFav(ElectricityProvider provider) {
//        List<String> listMeterNums = new ArrayList<>();
//        if (ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile() != null
//                && !ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites().isEmpty()) {
//            for (Favourite fav : ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites()) {
//                if ((fav.getTrxType() != null) && fav.getTrxType().equalsIgnoreCase(provider.getTransactionType())) {
//                    if (!fav.getHistory().isEmpty()) {
//                        for (ConsumerHistory h : fav.getHistory()) {
//                            if (!h.getAccount().isEmpty()) {
//                                listMeterNums.add(h.getAccount());
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        return listMeterNums;
//    }
//
//    public static List<String> getTopAirMobileNumsFav() {
//        List<String> listMobileNums = new ArrayList<>();
//        if (ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile() != null
//                && !ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites().isEmpty()) {
//            if (TopupSale.getInstance().getProvider() != null) {
//                for (Favourite fav : ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites()) {
//                    if (fav.getTrxType().equalsIgnoreCase(TopupSale.getInstance().getProvider().getName())) {
//                        if (!fav.getHistory().isEmpty()) {
//                            for (ConsumerHistory h : fav.getHistory()) {
//                                String mobileHist = h.getAccount();
//                                String mobileNum = "";
//                                if (mobileHist.startsWith("27")) {
//                                    String mtmp = mobileHist.substring(2);
//                                    mobileNum = "0" + mtmp;
//                                }
//                                listMobileNums.add(mobileNum);
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        return listMobileNums;
//    }
//
//    public static List<String> getBillPayAccNumsFav(BillPayProduct product) {
//        List<String> listAccNums = new ArrayList<>();
//        if (ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile() != null
//                && !ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites().isEmpty()) {
//            for (Favourite fav : ActiveNFCSubscriber.getInstance().getCompleteConsumerProfile().getFavourites()) {
//                if (fav.getTrxGroup().equalsIgnoreCase("Payments") && fav.getProductId().equals(Integer.toString(product.getProdId()))) {
//                    if (fav.getHistory() != null) {
//                        if (!fav.getHistory().isEmpty()) {
//                            for (ConsumerHistory h : fav.getHistory()) {
//                                String accNum = h.getAccount();
////                                if (product.getAdditionalFields() == 2 && accNum.length() == 10) {
////                                    String barcode = String.format("%013d", 0);
////                                    String accountStr = h.getAccount();
////                                    String amountStr = String.format("%012d", 0);
////                                    String checkDigit = "0";
////                                    accNum = barcode + accountStr + amountStr + checkDigit;
////                                }
//                                if (product.getAdditionalFields() == 2 && accNum.length() == 36) {
//                                    accNum = h.getAccount().substring(13, 23);
//                                }
//                                listAccNums.add(accNum);
//                            }
//                        }
//                    }
//                }
//            }
//        }
//
//        return listAccNums;
//    }

}
