package jkiosk3.sales.billpay._common;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlSearch;
import jkiosk3._components.KeyboardResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilConnect;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.blu.InputBluBillPay;
import jkiosk3.sales.billpay.payat.InputPayAtBillPay;
import jkiosk3.sales.billpay.payat.InputPayAtInsurance;
import jkiosk3.sales.billpay.payat.InputPayAtTrafficFine;
import jkiosk3.sales.billpay.sapo.InputSAPOBillPay;
import jkiosk3.sales.billpay.syntell.InputSyntellBillPay;
import jkiosk3.sales.billpay.syntell.InputSyntellTrafficFine;
import jkiosk3.users.SalesUserLoginResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

public class BillPaymentSelect extends Region {

    private final static Logger logger = Logger.getLogger(BillPaymentSelect.class.getName());
    //
    private final String lblText;
    private final String prodType;
    private ControlSearch searchCtrl;
    private List<BillPayProduct> listBillPay;
    private List<BillPayProduct> listInsure;
    private List<BillPayProduct> listTrafFine;
    private StackPane stack;
    private final static int btnPageSize = 12;

    public BillPaymentSelect(String header, String productType) {
        this.lblText = header;
        this.prodType = productType;

        logger.info(("Bill Payment product type selected : ").concat(productType));

        setSearchControlActions();

        getChildren().add(getBillPaymentGroup());
    }

    private void setSearchControlActions() {
        searchCtrl = new ControlSearch();
        searchCtrl.getBtnSearch().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(new TextField(), "Enter search text", "", false, false, new KeyboardResult() {
                    @Override
                    public void onDone(String value) {
                        getProviders(value.toLowerCase(Locale.ENGLISH));
                    }
                });
            }
        });
        searchCtrl.getBtnClear().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                stack.getChildren().clear();
                getProviders();
            }
        });
    }

    private VBox getBillPaymentGroup() {

        Label lblBillPayments = JKText.getLblDk(lblText, JKText.FONT_B_SM);

        VBox vbHead = JKNode.getPageDblHeadVB(JKLayout.sp, lblBillPayments, searchCtrl);

        stack = new StackPane();
        stack.setPrefHeight(575);

        getProviders();

        VBox vb = JKLayout.getVBoxContent(0);
        vb.setStyle("-fx-padding: 0px 0px 15px 0px;");
        vb.getChildren().addAll(vbHead, stack);

        return vb;
    }

    private void getProviders() {
        BillPayUtilConnect.getProviderProductLists(new BillPayUtilConnect.ListBillPayments() {
            @Override
            public void listBillPayments(Void list) {
                listBillPay = BillPayUtilConnect.getBillPayList();
                listInsure = BillPayUtilConnect.getInsurePayList();
                listTrafFine = BillPayUtilConnect.getTrafFineList();
                getPageContents();
            }
        });
    }

    private void getProviders(String searchTerm) {
        stack.getChildren().clear();
        listBillPay = BillPayUtilConnect.getBillPayList();
        listInsure = BillPayUtilConnect.getInsurePayList();
        listTrafFine = BillPayUtilConnect.getTrafFineList();
        if (!searchTerm.equals("")) {
            switch (prodType) {
                case BillPayUtilMisc.TYPE_BILL_PAY:
                    List<BillPayProduct> srchListBillPay = listBillPay;
                    List<BillPayProduct> srchListBillPayTmp = new ArrayList<>();
                    for (BillPayProduct billPay : srchListBillPay) {
                        if (billPay.getProdName().toLowerCase(Locale.ENGLISH).contains(searchTerm)) {
                            srchListBillPayTmp.add(billPay);
                        }
                    }
                    listBillPay = srchListBillPayTmp;
                    break;
                case BillPayUtilMisc.TYPE_INSURE_PAY:
                    List<BillPayProduct> srchListInsure = listInsure;
                    List<BillPayProduct> srchListInsureTmp = new ArrayList<>();
                    for (BillPayProduct billPay : srchListInsure) {
                        if (billPay.getProdName().toLowerCase(Locale.ENGLISH).contains(searchTerm)) {
                            srchListInsureTmp.add(billPay);
                        }
                    }
                    listInsure = srchListInsureTmp;
                    break;
                case BillPayUtilMisc.TYPE_TRAFFIC_FINE:
                    List<BillPayProduct> srchListTrafFine = listTrafFine;
                    List<BillPayProduct> srchListTrafFineTmp = new ArrayList<>();
                    for (BillPayProduct billPay : srchListTrafFine) {
                        if (billPay.getProdName().toLowerCase(Locale.ENGLISH).contains(searchTerm)) {
                            srchListTrafFineTmp.add(billPay);
                        }
                    }
                    listTrafFine = srchListTrafFineTmp;
                    break;
                default:
                    JKiosk3.getMsgBox().showMsgBox("Bill Payment Selection", "No Bill Payment type selected", null);
            }

            getPageContents();
        }
    }

    private void getPageContents() {
        List<BillPayProduct> bpProducts = new ArrayList<>();
        switch (prodType) {
            case BillPayUtilMisc.TYPE_BILL_PAY:
                bpProducts = listBillPay;
                break;
            case BillPayUtilMisc.TYPE_INSURE_PAY:
                bpProducts = listInsure;
                break;
            case BillPayUtilMisc.TYPE_TRAFFIC_FINE:
                bpProducts = listTrafFine;
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox(SaleType.BILLPAYMENTS.getDisplay(), "No Bill Payment Type Selected", null);
        }
        createPagedItems(bpProducts);
    }

    private void createPagedItems(List<BillPayProduct> bpProducts) {
        final List<Button> btnList = getProductButtons(bpProducts);

        int numPgs = 0;
        if (btnList.isEmpty()) {
            numPgs = 1;
        } else if (btnList.size() % btnPageSize == 0) {
            numPgs = btnList.size() / btnPageSize;
        } else {
            numPgs = (btnList.size() / btnPageSize) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedTile(pg, 500, 2, btnPageSize, btnList);
            }
        });

        stack.getChildren().add(pages);
    }

    private List<Button> getProductButtons(List<BillPayProduct> products) {
        List<Button> buttons = new ArrayList<>();


        for (final BillPayProduct p : products) {
            final Button btn = JKNode.getBtnSmDbl("");
            ImageView img = new ImageView();

            btn.setText(p.getProdName());
            btn.setId(p.getBpTransType().name());

            if (!p.getLogoId().isEmpty()) {
//

                img = BillPayUtilMisc.getImageViewBillPay ("prov_" + p.getLogoId () + ".png");
            } else {

                if (p.getProvName().contains("Blu Bill Payment")) {
                    img = BillPayUtilMisc.getImageViewBillPay("prov_Blu.png");
                }

                if (p.getProvName().contains("Pay@")) {
                    img = BillPayUtilMisc.getImageViewBillPay("prov_PayAt.png");
                } else if (p.getProvName().contains("Syntell")) {
                    img = BillPayUtilMisc.getImageViewBillPay("prov_Syntell.png");
                } else if (p.getProvName().contains("SAPO")) {
                    img = BillPayUtilMisc.getImageViewBillPay("prov_SAPO.png");
                }
            }

            // System.out.println ("logo id: " + p.getLogoId ());

            btn.setGraphic(img);
            btn.setGraphicTextGap(JKLayout.sp / 4);
            btn.getStyleClass().add("prov_VASSmTxt");
            btn.setStyle(JKNode.getBrandButton());
            btn.setFont(JKText.FONT_B_XXSM);
            btn.setAlignment(Pos.CENTER_LEFT);
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event arg0) {
                    logger.info(("Bill Payment product selected : ")
                            .concat(Integer.toString(p.getProdId())).concat((" - ")).concat(p.getProdName()));
                    setSalesPerson(p);
                }
            });
            buttons.add(btn);
        }
        return buttons;
    }

    private void setSalesPerson(final BillPayProduct selectedProduct) {
        JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
            @Override
            public void onDone() {
                getMenuAction(selectedProduct);
            }
        });
    }

    private void getMenuAction(BillPayProduct p) {

        switch (p.getBpTransType()) {
            case BILLPAY_PAYAT_ACCOUNT:
                SceneSales.clearAndChangeContent(new InputPayAtBillPay(p, false, false));
                break;
            case BILLPAY_PAYAT_INSURANCE:
                SceneSales.clearAndChangeContent(new InputPayAtInsurance(p, BillPayUtilMisc.INSURE_PAYMENT, false, false));
                break;
            case BILLPAY_PAYAT_TRAFFIC:
                SceneSales.clearAndChangeContent(new InputPayAtTrafficFine(p, false, false));
                break;
            case BILLPAY_SYNTELL_ACCOUNT:
                SceneSales.clearAndChangeContent(new InputSyntellBillPay(p, false, false));
                break;
            case BILLPAY_SYNTELL_TRAFFIC:
                SceneSales.clearAndChangeContent(new InputSyntellTrafficFine(p, false, false));
                break;
            case BILLPAY_SAPO_ACCOUNT:
                SceneSales.clearAndChangeContent(new InputSAPOBillPay(p, false, false));
                break;
            case BILLPAY_BLU_ACCOUNT:
                SceneSales.clearAndChangeContent(new InputBluBillPay(p, false, false));
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox(SaleType.BILLPAYMENTS.getDisplay(), "Please select a Product to pay", null);
        }
    }

    // delete from here once all works...

//    private final static Logger logger = Logger.getLogger(BillPaymentSelect.class.getName());
//    //
//    private final String lblText;
//    private final String prodType;
//    private ControlSearch searchCtrl;
//    private List<BillPayProduct> listBillPay;
//    private List<BillPayProduct> listInsure;
//    private List<BillPayProduct> listTrafFine;
//    private StackPane stack;
//    private final static int btnPageSize = 12;
//
//    public BillPaymentSelect(String header, String productType) {
//        this.lblText = header;
//        this.prodType = productType;
//
//        logger.info(("Bill Payment product type selected : ").concat(productType));
//
//        setSearchControlActions();
//
//        getChildren().add(getBillPaymentGroup());
//    }
//
//    private void setSearchControlActions() {
//        searchCtrl = new ControlSearch();
//        searchCtrl.getBtnSearch().setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getKeyboard().showKeyboard(new TextField(), "Enter search text", "", false, false, new KeyboardResult() {
//                    @Override
//                    public void onDone(String value) {
//                        getProviders(value.toLowerCase(Locale.ENGLISH));
//                    }
//                });
//            }
//        });
//        searchCtrl.getBtnClear().setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                stack.getChildren().clear();
//                getProviders();
//            }
//        });
//    }
//
//    private VBox getBillPaymentGroup() {
//
//        Label lblBillPayments = JKText.getLblDk(lblText, JKText.FONT_B_SM);
//
//        VBox vbHead = JKNode.getPageDblHeadVB(JKLayout.sp, lblBillPayments, searchCtrl);
//
//        stack = new StackPane();
//        stack.setPrefHeight(575);
//
//        getProviders();
//
//        VBox vb = JKLayout.getVBoxContent(0);
//        vb.setStyle("-fx-padding: 0px 0px 15px 0px;");
//        vb.getChildren().addAll(vbHead, stack);
//
//        return vb;
//    }
//
//    private void getProviders() {
//        BillPayUtilConnect.getProviderProductLists(new BillPayUtilConnect.ListBillPayments() {
//            @Override
//            public void listBillPayments(Void list) {
//                listBillPay = BillPayUtilConnect.getBillPayList();
//                listInsure = BillPayUtilConnect.getInsurePayList();
//                listTrafFine = BillPayUtilConnect.getTrafFineList();
//                getPageContents();
//            }
//        });
//    }
//
//    private void getProviders(String searchTerm) {
//        stack.getChildren().clear();
//        listBillPay = BillPayUtilConnect.getBillPayList();
//        listInsure = BillPayUtilConnect.getInsurePayList();
//        listTrafFine = BillPayUtilConnect.getTrafFineList();
//        if (!searchTerm.equals("")) {
//            switch (prodType) {
//                case BillPayUtilMisc.TYPE_BILL_PAY:
//                    List<BillPayProduct> srchListBillPay = listBillPay;
//                    List<BillPayProduct> srchListBillPayTmp = new ArrayList<>();
//                    for (BillPayProduct billPay : srchListBillPay) {
//                        if (billPay.getProdName().toLowerCase(Locale.ENGLISH).contains(searchTerm)) {
//                            srchListBillPayTmp.add(billPay);
//                        }
//                    }
//                    listBillPay = srchListBillPayTmp;
//                    break;
//                case BillPayUtilMisc.TYPE_INSURE_PAY:
//                    List<BillPayProduct> srchListInsure = listInsure;
//                    List<BillPayProduct> srchListInsureTmp = new ArrayList<>();
//                    for (BillPayProduct billPay : srchListInsure) {
//                        if (billPay.getProdName().toLowerCase(Locale.ENGLISH).contains(searchTerm)) {
//                            srchListInsureTmp.add(billPay);
//                        }
//                    }
//                    listInsure = srchListInsureTmp;
//                    break;
//                case BillPayUtilMisc.TYPE_TRAFFIC_FINE:
//                    List<BillPayProduct> srchListTrafFine = listTrafFine;
//                    List<BillPayProduct> srchListTrafFineTmp = new ArrayList<>();
//                    for (BillPayProduct billPay : srchListTrafFine) {
//                        if (billPay.getProdName().toLowerCase(Locale.ENGLISH).contains(searchTerm)) {
//                            srchListTrafFineTmp.add(billPay);
//                        }
//                    }
//                    listTrafFine = srchListTrafFineTmp;
//                    break;
//                default:
//                    JKiosk3.getMsgBox().showMsgBox("Bill Payment Selection", "No Bill Payment type selected", null);
//            }
//
//            getPageContents();
//        }
//    }
//
//    private void getPageContents() {
//        List<BillPayProduct> bpProducts = new ArrayList<>();
//        switch (prodType) {
//            case BillPayUtilMisc.TYPE_BILL_PAY:
//                bpProducts = listBillPay;
//                break;
//            case BillPayUtilMisc.TYPE_INSURE_PAY:
//                bpProducts = listInsure;
//                break;
//            case BillPayUtilMisc.TYPE_TRAFFIC_FINE:
//                bpProducts = listTrafFine;
//                break;
//            default:
//                JKiosk3.getMsgBox().showMsgBox(SaleType.BILLPAYMENTS.getDisplay(), "No Bill Payment Type Selected", null);
//        }
//        createPagedItems(bpProducts);
//    }
//
//    private void createPagedItems(List<BillPayProduct> bpProducts) {
//        final List<Button> btnList = getProductButtons(bpProducts);
//
//        int numPgs = 0;
//        if (btnList.isEmpty()) {
//            numPgs = 1;
//        } else if (btnList.size() % btnPageSize == 0) {
//            numPgs = btnList.size() / btnPageSize;
//        } else {
//            numPgs = (btnList.size() / btnPageSize) + 1;
//        }
//        Pagination pages = new Pagination(numPgs);
//        pages.setPageFactory(new Callback<Integer, Node>() {
//            @Override
//            public Node call(Integer pg) {
//                return JKNode.createPagedTile(pg, 500, 2, btnPageSize, btnList);
//            }
//        });
//
//        stack.getChildren().add(pages);
//    }
//
//    private List<Button> getProductButtons(List<BillPayProduct> products) {
//        List<Button> buttons = new ArrayList<>();
//
//        for (final BillPayProduct p : products) {
//            final Button btn = JKNode.getBtnSmDbl("");
//
//            btn.setText(p.getProdName());
////            btn.setId(p.getProvType().name());
//            btn.setId(p.getBpTransType().name());
//
//            ImageView img = new ImageView();
//            if (p.getProvName().contains("Blu Bill Payment")) {
//                img = BillPayUtilMisc.getImageViewBillPay("prov_Blu.png");
//            } else if (p.getProvName().contains("Pay@")) {
//                img = BillPayUtilMisc.getImageViewBillPay("prov_PayAt.png");
//            } else if (p.getProvName().contains("Syntell")) {
//                img = BillPayUtilMisc.getImageViewBillPay("prov_Syntell.png");
//            } else if (p.getProvName().contains("SAPO")) {
//                img = BillPayUtilMisc.getImageViewBillPay("prov_SAPO.png");
//            }
//            btn.setGraphic(img);
//            btn.setGraphicTextGap(JKLayout.sp / 4);
//            btn.getStyleClass().add("prov_VASSmTxt");
//            btn.setStyle(JKNode.getBrandButton());
//            btn.setFont(JKText.FONT_B_XXSM);
//            btn.setAlignment(Pos.CENTER_LEFT);
//            btn.setWrapText(true);
//            btn.setOnMouseReleased(new EventHandler<Event>() {
//                @Override
//                public void handle(Event arg0) {
//                    logger.info(("Bill Payment product selected : ")
//                            .concat(Integer.toString(p.getProdId())).concat((" - ")).concat(p.getProdName()));
//                    setSalesPerson(p);
//                }
//            });
//            buttons.add(btn);
//        }
//        return buttons;
//    }
//
//    private void setSalesPerson(final BillPayProduct selectedProduct) {
//        JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
//            @Override
//            public void onDone() {
//                getMenuAction(selectedProduct);
//            }
//        });
//    }
//
//    private void getMenuAction(BillPayProduct p) {
//
//        switch (p.getBpTransType()) {
//            case BILLPAY_PAYAT_ACCOUNT:
//                SceneSales.clearAndChangeContent(new InputPayAtBillPay(p, false));
//                break;
//            case BILLPAY_PAYAT_INSURANCE:
//                SceneSales.clearAndChangeContent(new InputPayAtInsurance(p, BillPayUtilMisc.INSURE_PAYMENT, false));
//                break;
//            case BILLPAY_PAYAT_TRAFFIC:
//                SceneSales.clearAndChangeContent(new InputPayAtTrafficFine(p, false));
//                break;
//            case BILLPAY_SYNTELL_ACCOUNT:
//                SceneSales.clearAndChangeContent(new InputSyntellBillPay(p, false));
//                break;
//            case BILLPAY_SYNTELL_TRAFFIC:
//                SceneSales.clearAndChangeContent(new InputSyntellTrafficFine(p, false));
//                break;
//            case BILLPAY_SAPO_ACCOUNT:
//                SceneSales.clearAndChangeContent(new InputSAPOBillPay(p, false));
//                break;
//            case BILLPAY_BLU_ACCOUNT:
//                SceneSales.clearAndChangeContent(new InputBluBillPay(p, false));
//                break;
//            default:
//                JKiosk3.getMsgBox().showMsgBox(SaleType.BILLPAYMENTS.getDisplay(), "Please select a Product to pay", null);
//        }
//
////        switch (p.getProvType()) {
////
////            case PAYAT_BILL_PAYMENT:
////                SceneSales.clearAndChangeContent(new InputPayAtBillPay(p, false));
////                break;
////            case PAYAT_INSURANCE_POLICY:
////                SceneSales.clearAndChangeContent(new InputPayAtInsurance(p, BillPayUtilMisc.INSURE_PAYMENT, false));
////                break;
////            case PAYAT_TRAFFIC_FINE:
////                SceneSales.clearAndChangeContent(new InputPayAtTrafficFine(p, false));
////                break;
////            case SYNTELL_BILL_PAYMENT:
////                SceneSales.clearAndChangeContent(new InputSyntellBillPay(p, false));
////                break;
////            case SYNTELL_TRAFFIC_FINE:
////                SceneSales.clearAndChangeContent(new InputSyntellTrafficFine(p, false));
////                break;
////            case SAPO_BILL_PAYMENT:
////                SceneSales.clearAndChangeContent(new InputSAPOBillPay(p, false));
////                break;
////            case BLU_BILL_PAYMENT:
////                SceneSales.clearAndChangeContent(new InputBluBillPay(p, false));
////                break;
////            default:
////                JKiosk3.getMsgBox().showMsgBox(SaleType.BILLPAYMENTS.getDisplay(), "Please select a Product to pay", null);
////        }
//    }
}
