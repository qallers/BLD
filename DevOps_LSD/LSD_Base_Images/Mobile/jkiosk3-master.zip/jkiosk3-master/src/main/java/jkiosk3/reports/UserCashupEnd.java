package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.ShiftList;
import aeonreports.ShiftUsers;
import aeonusers.User;
import java.util.List;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.reports.ReportUtil.AeonPrintJobResult;
import jkiosk3.reports.ReportUtil.ShiftListResult;
import jkiosk3.reports.ReportUtil.ShiftUsersResult;

/**
 *
 * @author valeriew
 */
public class UserCashupEnd extends Region {

    private final static Logger LOG = Logger.getLogger(ShiftView.class.getName());
    private List<User> listUsers;
    private int currentShiftId;
    private int userId;

    public UserCashupEnd() {
        ReportUtil.getOpenShiftDetails(new ShiftListResult() {

            @Override
            public void shiftListResult(ShiftList shiftList) {
                if (shiftList.isSuccess()) {
                    currentShiftId = shiftList.getShifts().get(0).getShiftId();
                    getUsersAndShowView();
                }
            }
        });
    }

    private void getUsersAndShowView() {
        ReportUtil.getUsersOnShift(currentShiftId, new ShiftUsersResult() {

            @Override
            public void shiftUsersResult(ShiftUsers shiftUsersResult) {
                if (shiftUsersResult.isSuccess()) {
                    listUsers = shiftUsersResult.getListUsers();

                    VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

                    vb.getChildren().add(getCashupEndView());
                    vb.getChildren().add(getPrintControl());

                    getChildren().addAll(vb);
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Shift Users", "Failed to Retrieve Users for Selected Shift\n\n"
                            + shiftUsersResult.getErrorCode() + " - " + shiftUsersResult.getErrorText(), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    SceneReports.clearAndChangeContent(new ShiftMenu());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private VBox getCashupEndView() {

        VBox vbHead = JKNode.getPageHeadVB("End User Cashup");

        Label lblUsers = JKText.getLblDk("Select User", JKText.FONT_B_XSM);

        ComboBox comUsers = new ComboBox();
        comUsers.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.75), 35);
        ObservableList<User> observeUsers = FXCollections.observableArrayList(listUsers);
        comUsers.setItems(observeUsers);
        comUsers.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue v1, Object user1, Object user2) {
                if (user2 != null) {
                    userId = ((User) user2).getUserId();
                }
            }
        });

        GridPane grid = JKLayout.getContentGridInner2Col(0.25, 0.75);

        grid.addRow(0, lblUsers, comUsers);

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, grid);

        return vb;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls("End Cashup") {
            @Override
            public void onClickPrint() {
                LOG.info(("END CASHUP : Selected User - ").concat(Integer.toString(userId)));
                ReportUtil.getCashupReport(currentShiftId, userId, new AeonPrintJobResult() {

                    @Override
                    public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                        PrintHandler.handlePrintRequestReport("Print Cashup Report", aeonPrintJob);
                        int n = SceneReports.getVbReportContent().getChildren().size();
                        if (n > 2) {
                            SceneReports.getVbReportContent().getChildren().remove(2, n);
                        }
                    }
                });
            }
        };
    }
}
