package jkiosk3.sales.electricity;

import aeonelectricity.ElectricityConfirmation;
import aeonelectricity.ElectricityMeter;
import javafx.geometry.VPos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SceneSales;

/**
 *
 * @author Val
 */
public class ElecConfirm extends Region {

    private final ElectricityConfirmation confirmed;
    private final ElectricityMeter meter;
    private String meterNum;
    private final int amount;
    private final String transType;

    public ElecConfirm(ElectricityConfirmation confirm, ElectricityMeter meter, int amt, String transType) {
        this.confirmed = confirm;
        this.meter = meter;
        this.amount = amt;
        this.transType = transType;

        if (meter.getTrack2data() != null) {
//            meterNum = meter.getTrack2data();
            meterNum = "TrackData";
        } else if (meter.getMeterNum() != null) {
            meterNum = meter.getMeterNum();
        } else {
            JKiosk3.getMsgBox().showMsgBox("Unspecified Meter Number", "Meter Number not specified", null,
                    MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            SceneSales.clearAndChangeContent(new ElectricitySupplierSelect());
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        }

        getChildren().add(makeSummaryGrid());
    }

    private GridPane makeSummaryGrid() {
        GridPane grid = JKLayout.getSummaryGrid2Col(0.35, 0.65);
        grid.setTranslateX(-JKLayout.sp);

//        String meterNum1 = "";
//        String meterNum2 = "";
//        if (meterNum.contains("=")) {
//            int index = meterNum.indexOf("=");
//            meterNum1 = meterNum.substring(0, index - 1);
//            meterNum2 = meterNum.substring(index);
//        } else {
//            meterNum1 = meterNum;
//        }
        
        boolean showMin = false;
        if (confirmed.getMin() > 0.0) {
            showMin = true;
        }

        Label lblMeterNumS = JKText.getLblDk("Meter Number", JKText.FONT_B_SM);
        Label lblCustomerS = JKText.getLblDk("Customer Name", JKText.FONT_B_XSM);
        Label lblAddressS = JKText.getLblDk("Customer Address", JKText.FONT_B_XSM);
        GridPane.setValignment(lblAddressS, VPos.TOP);
        Label lblUtilityS = JKText.getLblDk("Utility", JKText.FONT_B_XSM);
        Label lblMinS = JKText.getLblDk("Min / Arrears", JKText.FONT_B_XSM);
//        Label lblMaxS = JKText.getLblDk("Max", JKText.FONT_B_XSM);        
        Label lblAmountS = JKText.getLblDk("Amount", JKText.FONT_B_XSM);

        Text txtMeterNum = JKText.getTxtDk(meterNum, JKText.FONT_B_SM);
//        Text txtMeterNum1 = JKText.getTxtDk(meterNum1, JKText.FONT_B_SM);
//        Text txtMeterNum2 = JKText.getTxtDk(meterNum2, JKText.FONT_B_SM);
        Text txtCustomerS = JKText.getTxtDk(confirmed.getCustomerName(), JKText.FONT_B_XSM);
        Text txtAddressS = JKText.getTxtDk(confirmed.getCustomerAddress(), JKText.FONT_B_XSM);
        txtAddressS.setWrappingWidth(375);
        txtAddressS.setTextAlignment(TextAlignment.RIGHT);
        Text txtUtilityS = JKText.getTxtDk(confirmed.getUtility(), JKText.FONT_B_XSM);
        Text txtMinS = JKText.getTxtDk(JKText.getDeciFormat(confirmed.getMin()), JKText.FONT_B_XSM);
//        Text txtMaxS = JKText.getTxtDk(JKText.getDeciFormat(confirmed.getMax()), JKText.FONT_B_XSM);        
        Text txtAmountS = JKText.getTxtDk(JKText.getDeciFormat(amount), JKText.FONT_B_XSM);

        grid.addRow(0, lblMeterNumS, txtMeterNum);
//        grid.addRow(0, lblMeterNumS, txtMeterNum1);
//        grid.addRow(1, new Label(""), txtMeterNum2);

        switch (transType) {
            case ElectricityUtil.ELEC_UPDATE_M_CARD:
                grid.add(getMeterDetail(), 0, 1, 2, 1);
                grid.addRow(2, JKNode.createGridSpanSep(2));
                grid.addRow(3, lblCustomerS, txtCustomerS);
                grid.addRow(4, lblAddressS, txtAddressS);
                grid.addRow(5, lblUtilityS, txtUtilityS);
                break;
            case ElectricityUtil.ELEC_TOKEN:
            case ElectricityUtil.ELEC_FBE:
                if (!meter.getMeterSgc().equals("")) {
                    grid.add(getMeterDetail(), 0, 1, 2, 1);
                }
                grid.addRow(2, JKNode.createGridSpanSep(2));
                grid.addRow(3, lblCustomerS, txtCustomerS);
                grid.addRow(4, lblAddressS, txtAddressS);
                grid.addRow(5, lblUtilityS, txtUtilityS);
                if (showMin) {
                    grid.addRow(6, lblMinS, txtMinS);
//                    grid.addRow(7, lblMaxS, txtMaxS);
                    grid.addRow(7, lblAmountS, txtAmountS);
                } else {
                    grid.addRow(6, lblAmountS, txtAmountS);
                }
                break;
            case ElectricityUtil.ELEC_REPRINT:
            case ElectricityUtil.ELEC_REPRINT_LIST:
                break;
            case ElectricityUtil.ELEC_UPDATE_M_KEY:
                grid.addRow(1, JKNode.createGridSpanSep(2));
                grid.addRow(2, lblCustomerS, txtCustomerS);
                grid.addRow(3, lblAddressS, txtAddressS);
                grid.addRow(4, lblUtilityS, txtUtilityS);
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox(transType, "No details available", null);
                break;
        }

        return grid;
    }

    private GridPane getMeterDetail() {
        Label lblMeterSGC = JKText.getLblDk("SGC", JKText.FONT_B_XSM);
        Label lblMeterTT = JKText.getLblDk("TT", JKText.FONT_B_XSM);
        Label lblMeterTI = JKText.getLblDk("TI", JKText.FONT_B_XSM);
        Label lblMeterKRN = JKText.getLblDk("KRN", JKText.FONT_B_XSM);
        Label lblMeterALG = JKText.getLblDk("ALG", JKText.FONT_B_XSM);

        Text txtMeterSGC = new Text();
        Text txtMeterTT = new Text();
        Text txtMeterTI = new Text();
        Text txtMeterKRN = new Text();
        Text txtMeterALG = new Text();

        switch (transType) {
            case ElectricityUtil.ELEC_UPDATE_M_CARD:
                txtMeterSGC = JKText.getTxtDk(confirmed.getSgc(), JKText.FONT_B_XSM);
                txtMeterTT = JKText.getTxtDk(confirmed.getTt(), JKText.FONT_B_XSM);
                txtMeterTI = JKText.getTxtDk(confirmed.getTi(), JKText.FONT_B_XSM);
                txtMeterKRN = JKText.getTxtDk(confirmed.getKrn(), JKText.FONT_B_XSM);
                txtMeterALG = JKText.getTxtDk(confirmed.getAt(), JKText.FONT_B_XSM);
                break;
            case ElectricityUtil.ELEC_TOKEN:
            case ElectricityUtil.ELEC_FBE:
                if (!meter.getMeterSgc().equals("")) {
                    txtMeterSGC = JKText.getTxtDk(meter.getMeterSgc(), JKText.FONT_B_XSM);
                    txtMeterTT = JKText.getTxtDk(meter.getMeterTt(), JKText.FONT_B_XSM);
                    txtMeterTI = JKText.getTxtDk(meter.getMeterTi(), JKText.FONT_B_XSM);
                    txtMeterKRN = JKText.getTxtDk(meter.getMeterKrn(), JKText.FONT_B_XSM);
                    txtMeterALG = JKText.getTxtDk(meter.getMeterAlg(), JKText.FONT_B_XSM);
                }
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox(transType, "No details available", null);
        }

        GridPane gridDetail = JKLayout.getSummaryGrid2Col(0.30, 0.60);
        gridDetail.setTranslateX(2 * JKLayout.sp);
        gridDetail.addRow(0, lblMeterSGC, txtMeterSGC);
        gridDetail.addRow(1, lblMeterTT, txtMeterTT);
        gridDetail.addRow(2, lblMeterTI, txtMeterTI);
        gridDetail.addRow(3, lblMeterKRN, txtMeterKRN);
        gridDetail.addRow(4, lblMeterALG, txtMeterALG);

        return gridDetail;
    }
}
