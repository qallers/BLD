package jkiosk3.sales.search;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlSearch;
import jkiosk3._components.KeyboardResult;
import jkiosk3.sales.MerchantCopy;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilConnect;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.blu.InputBluBillPay;
import jkiosk3.sales.billpay.m2m.InputM2M;
import jkiosk3.sales.billpay.payat.InputPayAtBillPay;
import jkiosk3.sales.billpay.payat.InputPayAtInsurance;
import jkiosk3.sales.billpay.payat.InputPayAtTrafficFine;
import jkiosk3.sales.billpay.sapo.InputSAPOBillPay;
import jkiosk3.sales.billpay.syntell.InputSyntellBillPay;
import jkiosk3.sales.billpay.syntell.InputSyntellTrafficFine;
import jkiosk3.sales.chat4change.Chat4Change;
import jkiosk3.sales.chat4change.Chat4ChangeSale;
import jkiosk3.sales.electricity.ElectricityMenu;
import jkiosk3.sales.topups.TopupSale;
import jkiosk3.sales.topups.airtime.Airtime;
import jkiosk3.sales.topups.bundles.BundleProvidersDataOrSMS;
import jkiosk3.sales.topups.wallets.WalletProviders;
import jkiosk3.sales.vouchers.VoucherSale;
import jkiosk3.sales.vouchers.Vouchers;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.SalesUserLoginResult;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

// search all products available on JKiosk
public class SearchMenu extends Region {
    private final static String SEARCH_HEADER = "Search";
    private final static int btnPageSize = 12;
    private final static Logger logger = Logger.getLogger(SearchMenu.class.getName());
    private final String lblText;
    private final String prodType;
    private ControlSearch searchCtrl;
    private List<SearchProduct> listSearchProducts;
    private StackPane stack;

    public SearchMenu() {
        this.lblText = SEARCH_HEADER;
        this.prodType = BillPayUtilMisc.TYPE_BILL_PAY;

        logger.info(("Bill Payment product type selected : ").concat(prodType));

        setSearchControlActions();

        getChildren().add(getBillPaymentGroup());

    }

    private void setSearchControlActions() {
        searchCtrl = new ControlSearch();
        searchCtrl.getBtnSearch().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(new TextField(), "Enter search text", "", false, false, new KeyboardResult() {
                    @Override
                    public void onDone(String value) {
                        getProviders(value.toLowerCase(Locale.ENGLISH));
                    }
                });
            }
        });
        searchCtrl.getBtnClear().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                stack.getChildren().clear();
                getProviders();
            }
        });
    }

    private VBox getBillPaymentGroup() {

        Label lblBillPayments = JKText.getLblDk(lblText, JKText.FONT_B_SM);

        VBox vbHead = JKNode.getPageDblHeadVB(JKLayout.sp, lblBillPayments, searchCtrl);

        stack = new StackPane();
        stack.setPrefHeight(575);

        getProviders();

        VBox vb = JKLayout.getVBoxContent(0);
        vb.setStyle("-fx-padding: 0px 0px 15px 0px;");
        vb.getChildren().addAll(vbHead, stack);

        return vb;
    }

    private void getProviders(String searchTerm) {
        stack.getChildren().clear();

        List<SearchProduct> combinedList = new ArrayList<>();

        if (CurrentUser.getUser().getTransTypes().contains(BillPayUtilMisc.BLU_M2M_TRANSFER)) {
            combinedList.add(getMerchant());
        }

        combinedList.addAll(CreateBillPaymentProduct.createBillPayProducts());
        combinedList.addAll(CreateBillPaymentProduct.createInsurePayProducts());
        combinedList.addAll(CreateBillPaymentProduct.createTrafficFineProducts());
        combinedList.addAll(CreateAirtimeTopupProduct.createAirtimeTopupProducts());
        combinedList.addAll(CreateDataTopupProduct.createDataTopupProducts());
        combinedList.addAll(CreateSMSTopupProduct.createSMSTopupProducts());
        combinedList.addAll(CreateWalletTopupProduct.createWalletTopupProducts());
        combinedList.addAll(CreateAirtimeVoucherProduct.createAirtimeVoucherProducts());
        combinedList.addAll(CreateDataVoucherProduct.createDataVoucherProducts());
        combinedList.addAll(CreateElectricityVoucherProduct.createElectricityVoucherProducts());
        combinedList.addAll(CreateOtherVoucherProduct.createOtherVoucherProducts());
        combinedList.addAll(CreateElectricityProduct.createElectricityProducts());
        combinedList.addAll(CreateC4CProduct.createC4CProducts());

        if (!searchTerm.equals("")) {
            List<SearchProduct> srchListBillPayTmp = new ArrayList<>();

            for (SearchProduct searchProduct : combinedList) {
                if (searchProduct.getProdName().toLowerCase(Locale.ENGLISH).contains(searchTerm)) {
                    srchListBillPayTmp.add(searchProduct);
                }
            }
            listSearchProducts = srchListBillPayTmp;

        } else {
            listSearchProducts = combinedList;
        }
        Collections.sort(listSearchProducts);
        createPagedItems(listSearchProducts);
    }

    private void getProviders() {
        BillPayUtilConnect.getProviderProductLists(new BillPayUtilConnect.ListBillPayments() {
            @Override
            public void listBillPayments(Void list) {
                getProviders("");
            }
        });
    }

    public SearchProduct getMerchant() {
        SearchProduct merchant = new SearchProduct();

        merchant.setProdName(BillPayUtilMisc.TYPE_M2M_TRANSFER);
        merchant.setProvName("Blu Bill Payment");
        merchant.setBpTransType(BPTransType.BILLPAY_BLU_M2M);
        merchant.setSearchTransType(SearchTransType.BILL_PAYMENT);

        return merchant;
    }

    private void createPagedItems(List<SearchProduct> searchProducts) {
        final List<Button> btnList = getProductButtons(searchProducts);

        int numPgs = 0;
        if (btnList.isEmpty()) {
            numPgs = 1;
        } else if (btnList.size() % btnPageSize == 0) {
            numPgs = btnList.size() / btnPageSize;
        } else {
            numPgs = (btnList.size() / btnPageSize) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedTile(pg, 500, 2, btnPageSize, btnList);
            }
        });

        stack.getChildren().add(pages);
    }

    private List<Button> getProductButtons(List<SearchProduct> products) {
        List<Button> buttons = new ArrayList<>();

        for (final SearchProduct p : products) {
            final Button btn = JKNode.getBtnSmDbl("");
            final SearchProduct product = p;

            btn.setText(product.getProdName());
//            btn.setId(product.getBpTransType().name());

            ImageView img = BillPayUtilMisc.getImageViewBillPay(String.format("prov_%s.png", product.getProvName()));

            if (product.getProvName().contains("Blu Bill Payment")) {
                if (product.getLogoId() != null && !product.getLogoId().isEmpty()) {
                    img = BillPayUtilMisc.getImageViewBillPay("prov_" + product.getLogoId() + ".png");
                } else {
                    img = BillPayUtilMisc.getImageViewBillPay("prov_Blu.png");
                }
            } else if (product.getProvName().contains("Pay@")) {
                img = BillPayUtilMisc.getImageViewBillPay("prov_PayAt.png");
            } else if (product.getProvName().contains("Syntell")) {
                img = BillPayUtilMisc.getImageViewBillPay("prov_Syntell.png");
            } else if (product.getProvName().contains("SAPO")) {
                img = BillPayUtilMisc.getImageViewBillPay("prov_SAPO.png");
            } else if (product.getProvName().contains("Vodacom")) {
                img = BillPayUtilMisc.getImageViewBillPay("prov_Vodacom.png");
            } else if (product.getProvName().contains("MTN")) {
                img = BillPayUtilMisc.getImageViewBillPay("prov_MTN.png");
            } else if (product.getProvName().contains("CellC")) {
                img = BillPayUtilMisc.getImageViewBillPay("prov_CellC.png");
            } else if (product.getProvName().contains("TelkomMobile")) {
                img = BillPayUtilMisc.getImageViewBillPay("prov_TelkomMobile.png");
            }

            if (product.getProdName().endsWith("Electricity")) {
                img = BillPayUtilMisc.getImageViewBillPay("");
            }

            btn.setGraphic(img);

            btn.setGraphicTextGap(JKLayout.sp / 4);
            btn.getStyleClass().add("prov_VASSmTxt");
            btn.setStyle(JKNode.getBrandButton());
            btn.setFont(JKText.FONT_B_XXSM);
            btn.setAlignment(Pos.CENTER_LEFT);
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event arg0) {
                    setSalesPerson(product);
                }
            });
            buttons.add(btn);
        }
        return buttons;
    }

    private void setSalesPerson(final SearchProduct selectedProduct) {
        JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
            @Override
            public void onDone() {
                getMenuAction(selectedProduct);
            }
        });
    }

    private BillPayProduct searchProductToBillPayProduct(SearchProduct product) {
        BillPayProduct billPayProduct = new BillPayProduct();
        billPayProduct.setProvId(product.getProvId());
        billPayProduct.setProvName(product.getProvName());
        billPayProduct.setProdId(product.getProdId());
        billPayProduct.setProdName(product.getProdName());
        billPayProduct.setBpTransType(product.getBpTransType());
        billPayProduct.setVerify(product.isVerify());
        billPayProduct.setFullAmount(product.isFullAmount());
        billPayProduct.setAdditionalFields(product.getAdditionalFields());
        billPayProduct.setProdMaxAmount(product.getProdMaxAmount());
        billPayProduct.setProdMinAmount(product.getProdMinAmount());
        billPayProduct.setEnforceFullPayment(product.isEnforceFullPayment());
        billPayProduct.setTendersAllowed(product.getTendersAllowed());
        billPayProduct.setReversalSupported(product.isReversalSupported());
        billPayProduct.setLogoId(product.getLogoId());
        return billPayProduct;
    }

    private void getMenuAction(SearchProduct p) {
        switch (p.getSearchTransType()) {

            case BILL_PAYMENT:
                switch (p.getBpTransType()) {
                    case BILLPAY_PAYAT_ACCOUNT:
                        SceneSales.clearAndChangeContent(new InputPayAtBillPay(searchProductToBillPayProduct(p), false, false));
                        break;
                    case BILLPAY_PAYAT_INSURANCE:
                        SceneSales.clearAndChangeContent(new InputPayAtInsurance(searchProductToBillPayProduct(p), BillPayUtilMisc.INSURE_PAYMENT, false, false));
                        break;
                    case BILLPAY_PAYAT_TRAFFIC:
                        SceneSales.clearAndChangeContent(new InputPayAtTrafficFine(searchProductToBillPayProduct(p), false, false));
                        break;
                    case BILLPAY_SYNTELL_ACCOUNT:
                        SceneSales.clearAndChangeContent(new InputSyntellBillPay(searchProductToBillPayProduct(p), false, false));
                        break;
                    case BILLPAY_SYNTELL_TRAFFIC:
                        SceneSales.clearAndChangeContent(new InputSyntellTrafficFine(searchProductToBillPayProduct(p), false, false));
                        break;
                    case BILLPAY_SAPO_ACCOUNT:
                        SceneSales.clearAndChangeContent(new InputSAPOBillPay(searchProductToBillPayProduct(p), false, false));
                        break;
                    case BILLPAY_BLU_ACCOUNT:
                        SceneSales.clearAndChangeContent(new InputBluBillPay(searchProductToBillPayProduct(p), false, false));
                        break;
                    case BILLPAY_BLU_M2M:
                        SceneSales.clearAndChangeContent(new InputM2M());
                        break;
                }
                break;

            case AIRTIME_TOPUP:
                refreshTopup(SaleType.TOPUP_AIRTIME);
                SceneSales.clearAndChangeContent(new Airtime());
                break;

            case DATA_TOPUP:
                refreshTopup(SaleType.TOPUP_BUNDLE_DATA);
                SceneSales.clearAndChangeContent(new BundleProvidersDataOrSMS());
                break;

            case SMS_BUNDLE:
                refreshTopup(SaleType.TOPUP_BUNDLE_SMS);
                SceneSales.clearAndChangeContent(new BundleProvidersDataOrSMS());
                break;

            case AIRTIME_VOUCHER:
                getVoucherMenuAction(SaleType.VOUCHER_AIRTIME);
                break;

            case DATA_VOUCHER:
                getVoucherMenuAction(SaleType.VOUCHER_DATA);
                break;

            case ELECTRICITY_VOUCHER:
                getVoucherMenuAction(SaleType.VOUCHER_ELEC);
                break;

            case OTHER_VOUCHER:
                getVoucherMenuAction(SaleType.VOUCHER_OTHER);
                break;

            case TOPUP_WALLET:
                refreshTopup(SaleType.TOPUP_WALLET);
                SceneSales.clearAndChangeContent(new WalletProviders());
                break;

            case ELECTRICITY:
                for (SearchProduct billPayProduct : CreateElectricityProduct.createElectricityProducts()) {
//                    if (p.getProvName().equals(billPayProduct.getElectricityProvider().getTransactionType())) {
                    if (p.getProvName().equals(billPayProduct.getProvName())) {
                        SceneSales.clearAndChangeContent(new ElectricityMenu(billPayProduct.getElectricityProvider()));

                        break;
                    }
                }

                break;

            case CHAT4CHANGE:
                MerchantCopy.resetMerchantCopy();
                MerchantCopy.getInstance().setTransType("btnMenuSelection.getText()");
                Chat4ChangeSale.resetChat4ChangeSale();
                SceneSales.clearAndChangeContent(new Chat4Change(false));
                break;

            default:
                JKiosk3.getMsgBox().showMsgBox(SaleType.BILLPAYMENTS.getDisplay(), "Please select a Product to pay", null);
        }
    }

    private void refreshTopup(SaleType saleType) {
        TopupSale.resetTopupSale();
        TopupSale.getInstance().setSaleType(saleType);
    }

    private void getVoucherMenuAction(SaleType voucherType) {
        VoucherSale.resetVoucherSale();
        VoucherSale.getInstance().setSaleType(voucherType);
        SceneSales.clearAndChangeContent(new Vouchers());
    }

}