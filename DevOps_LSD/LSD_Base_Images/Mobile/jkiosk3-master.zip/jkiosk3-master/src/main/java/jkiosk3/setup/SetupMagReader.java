package jkiosk3.setup;

import MagCard.MagEncoders;
import java.util.List;
import javafx.geometry.HPos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MagCardPrompt;
import jkiosk3.printing.MagCardData;
import jkiosk3.store.JKCardReader;

/**
 *
 * @author Val
 */
public class SetupMagReader extends Region {

    private CheckBox chkRead;
    private CheckBox chkWrite;
    private ComboBox chcPort;
    private ComboBox chcBaud;
    private ComboBox chcType;

    public SetupMagReader() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getMagReaderEntry());
        vb.getChildren().add(getControls());
        
        updateTestBtnState();

        getChildren().add(vb);
    }

    private GridPane getMagReaderEntry() {
        double w = JKLayout.contentW;

        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75, HPos.LEFT);

        VBox vbHead = JKNode.getPageHeadVB("Mag Card Reader / Writer");

        Label lblPort = JKText.getLblDk("Port", JKText.FONT_B_XSM);
        lblPort.setMinWidth(JKLayout.btnSmW);
        Label lblBaud = JKText.getLblDk("Baud Rate", JKText.FONT_B_XSM);
        Label lblType = JKText.getLblDk("Type", JKText.FONT_B_XSM);

        chkRead = new CheckBox("Enable Reading");
        chkRead.setSelected(JKCardReader.getCardReaderConfig().isMagCardRead());

        chkWrite = new CheckBox("Enable Writing");
        chkWrite.setSelected(JKCardReader.getCardReaderConfig().isMagCardWrite());

        chcPort = new ComboBox();
        chcPort.setPrefSize(((w - (2 * JKLayout.sp)) * 0.75), 35);
        chcPort.getSelectionModel().select(JKCardReader.getCardReaderConfig().getMagCardPort());
        chcPort.getItems().addAll("COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9");

        chcBaud = new ComboBox();
        chcBaud.setPrefSize(((w - (2 * JKLayout.sp)) * 0.75), 35);
        chcBaud.getSelectionModel().select(Integer.toString(JKCardReader.getCardReaderConfig().getMagCardBaud()));
        chcBaud.getItems().addAll("2400", "4800", "9600", "14400", "19200", "38400", "57600", "115200");

        chcType = new ComboBox();
        chcType.setPrefSize(((w - (2 * JKLayout.sp)) * 0.75), 35);
        chcType.getSelectionModel().select(JKCardReader.getCardReaderConfig().getMagCardType());
        chcType.getItems().addAll(MagEncoders.getListMagEncoders());

        grid.add(vbHead, 0, 0, 2, 1);

        grid.add(chkRead, 1, 1);
        grid.add(chkWrite, 1, 2);
        grid.addRow(3, lblPort, chcPort);
        grid.addRow(4, lblBaud, chcBaud);
        grid.addRow(5, lblType, chcType);

        return grid;
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("Test Mag\nReader", true) {
            @Override
            public void onClickTest() {
                System.out.println("we clicked the Test button");
                List<MagCardData> cardTestData = MagCardPrompt.getTestList();
                try {
                    JKiosk3.getMagCardPrompt().showMagCodePromptBox("Test", cardTestData, null, true);
//                    JKiosk3.getMagCardPrompt().showMagCodePromptBox("Test", cardTestData, null, false);
                } catch (Exception ex) {
                    JKiosk3.getMsgBox().showMsgBox("Error", ex.toString(), null);
                }
            }

            @Override
            public void onClickSave() {
                saveSystemMagReader();
            }
        };
    }
    
    private void updateTestBtnState() {
        if (JKCardReader.getCardReaderConfig().isMagCardRead() || JKCardReader.getCardReaderConfig().isMagCardWrite()) {
            SceneSetupControls.getBtnTest().setDisable(false);
        } else {
            SceneSetupControls.getBtnTest().setDisable(true);
        }
    }

    private void saveSystemMagReader() {

        JKCardReader.getCardReaderConfig().setMagCardRead(chkRead.isSelected());
        JKCardReader.getCardReaderConfig().setMagCardWrite(chkWrite.isSelected());
        JKCardReader.getCardReaderConfig().setMagCardPort(chcPort.getSelectionModel().getSelectedItem().toString());
        JKCardReader.getCardReaderConfig().setMagCardBaud(Integer.parseInt(chcBaud.getSelectionModel().getSelectedItem().toString()));
        JKCardReader.getCardReaderConfig().setMagCardType((MagEncoders) chcType.getSelectionModel().getSelectedItem());
        //
        if (JKCardReader.saveCardReaderConfig()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Mag Reader settings saved successfully", null);
            updateTestBtnState();
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Mag Reader settings not saved", null);
        }
        System.out.println("mag encoder type : " + JKCardReader.getCardReaderConfig().getMagCardType());
        System.out.println("mag encoder name : " + JKCardReader.getCardReaderConfig().getMagCardType().getDisplayName());
    }
}
