package jkiosk3.sales._favourites.nfc;

import za.co.blt.consumer.loyalty.api.service.model.response.CompleteConsumerProfile;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfile;

public class ActiveNFCSubscriber {

    private ConsumerProfile consumerProfile;
    private CompleteConsumerProfile completeConsumerProfile;
    //
    private static ActiveNFCSubscriber instance;

    public static ActiveNFCSubscriber getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    private static ActiveNFCSubscriber newInstance() {
        instance = new ActiveNFCSubscriber();
        return instance;
    }

    public static void resetActiveNFCSubscriber() {
        instance = null;
    }

    public ConsumerProfile getConsumerProfile() {
        return consumerProfile;
    }

    public void setConsumerProfile(ConsumerProfile consumerProfile) {
        this.consumerProfile = consumerProfile;
    }

    public CompleteConsumerProfile getCompleteConsumerProfile() {
        return completeConsumerProfile;
    }

    public void setCompleteConsumerProfile(CompleteConsumerProfile completeConsumerProfile) {
        this.completeConsumerProfile = completeConsumerProfile;
    }
}
