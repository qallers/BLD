package jkiosk3.sales.billpay.insurance;

/**
 *
 * @author Valerie
 */
public class PolicyRegistration {

    private boolean nav1 = false;
    private boolean nav2 = false;
    private boolean nav3 = false;
    private int policyProviderId;
    private int policyProductId;
    private String policyType;
    private String policyNumber;
    private String mainLifeID;
    private String mainLifeName;
    private String mainLifeSurname;
    private String mainLifeAddress;
    private String mainLifeContact1;
    private String mainLifeContact2;
    private String beneficiaryName;
    private String beneficiarySurname;
    private String paymentType;
//    private String bankAccHolder;
//    private String bankName;
//    private String bankBranchName;
//    private String bankBranchCode;
//    private String bankAccType;
//    private String bankAccNumber;
//    private String bankDebitDate;

    private static PolicyRegistration instance;

    private static PolicyRegistration newInstance() {
        instance = new PolicyRegistration();
        return instance;
    }

    public static PolicyRegistration getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    public static void resetPolicyRegistration() {
        instance = null;
    }

    // getters and setters    
    public boolean isNav1() {
        return nav1;
    }

    public void setNav1(boolean nav1) {
        this.nav1 = nav1;
    }

    public boolean isNav2() {
        return nav2;
    }

    public void setNav2(boolean nav2) {
        this.nav2 = nav2;
    }

    public boolean isNav3() {
        return nav3;
    }

    public void setNav3(boolean nav3) {
        this.nav3 = nav3;
    }

    public int getPolicyProviderId() {
        return policyProviderId;
    }

    public void setPolicyProviderId(int policyProviderId) {
        this.policyProviderId = policyProviderId;
    }

    public int getPolicyProductId() {
        return policyProductId;
    }

    public void setPolicyProductId(int policyProductId) {
        this.policyProductId = policyProductId;
    }

    public String getPolicyType() {
        return policyType;
    }

    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getMainLifeID() {
        return mainLifeID;
    }

    public void setMainLifeID(String mainLifeID) {
        this.mainLifeID = mainLifeID;
    }

    public String getMainLifeName() {
        return mainLifeName;
    }

    public void setMainLifeName(String mainLifeName) {
        this.mainLifeName = mainLifeName;
    }

    public String getMainLifeSurname() {
        return mainLifeSurname;
    }

    public void setMainLifeSurname(String mainLifeSurname) {
        this.mainLifeSurname = mainLifeSurname;
    }

    public String getMainLifeAddress() {
        return mainLifeAddress;
    }

    public void setMainLifeAddress(String mainLifeAddress) {
        this.mainLifeAddress = mainLifeAddress;
    }

    public String getMainLifeContact1() {
        return mainLifeContact1;
    }

    public void setMainLifeContact1(String mainLifeContact1) {
        this.mainLifeContact1 = mainLifeContact1;
    }

    public String getMainLifeContact2() {
        return mainLifeContact2;
    }

    public void setMainLifeContact2(String mainLifeContact2) {
        this.mainLifeContact2 = mainLifeContact2;
    }

    public String getBeneficiaryName() {
        return beneficiaryName;
    }

    public void setBeneficiaryName(String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }

    public String getBeneficiarySurname() {
        return beneficiarySurname;
    }

    public void setBeneficiarySurname(String beneficiarySurname) {
        this.beneficiarySurname = beneficiarySurname;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

//    public String getBankAccHolder() {
//        return bankAccHolder;
//    }
//
//    public void setBankAccHolder(String bankAccHolder) {
//        this.bankAccHolder = bankAccHolder;
//    }
//
//    public String getBankName() {
//        return bankName;
//    }
//
//    public void setBankName(String bankName) {
//        this.bankName = bankName;
//    }
//
//    public String getBankBranchName() {
//        return bankBranchName;
//    }
//
//    public void setBankBranchName(String bankBranchName) {
//        this.bankBranchName = bankBranchName;
//    }
//
//    public String getBankBranchCode() {
//        return bankBranchCode;
//    }
//
//    public void setBankBranchCode(String bankBranchCode) {
//        this.bankBranchCode = bankBranchCode;
//    }
//
//    public String getBankAccType() {
//        return bankAccType;
//    }
//
//    public void setBankAccType(String bankAccType) {
//        this.bankAccType = bankAccType;
//    }
//
//    public String getBankAccNumber() {
//        return bankAccNumber;
//    }
//
//    public void setBankAccNumber(String bankAccNumber) {
//        this.bankAccNumber = bankAccNumber;
//    }
//
//    public String getBankDebitDate() {
//        return bankDebitDate;
//    }
//
//    public void setBankDebitDate(String bankDebitDate) {
//        this.bankDebitDate = bankDebitDate;
//    }
}
