package jkiosk3.sales.billpay.insurance;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.users.UserUtil;

public class PolicyReg2 extends Region {

    private TextField txtMainLifeID;
    private TextField txtMainLifeName;
    private TextField txtMainLifeSurname;
    private TextField txtMainLifeContact1;
    private TextField txtMainLifeContact2;
    private TextField txtBeneficiaryName;
    private TextField txtBeneficiarySurname;

    public PolicyReg2() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().add(polRegStep2());
        vb.getChildren().add(getNav());
        getChildren().add(vb);
        setContent();
    }

    private void setContent() {
        if (PolicyRegistration.getInstance().isNav2()) {
            txtMainLifeID.setText(PolicyRegistration.getInstance().getMainLifeID());
            txtMainLifeName.setText(PolicyRegistration.getInstance().getMainLifeName());
            txtMainLifeSurname.setText(PolicyRegistration.getInstance().getMainLifeSurname());
            txtMainLifeContact1.setText(PolicyRegistration.getInstance().getMainLifeContact1());
            txtMainLifeContact2.setText(PolicyRegistration.getInstance().getMainLifeContact2());
            txtBeneficiaryName.setText(PolicyRegistration.getInstance().getBeneficiaryName());
            txtBeneficiarySurname.setText(PolicyRegistration.getInstance().getBeneficiarySurname());
        }
    }

    private Group polRegStep2() {

        Label lblHead = JKText.getLblDk("Policy Registration", JKText.FONT_B_SM);
        Label lblStep = JKText.getLblDk("Step 2", JKText.FONT_B_XSM);

        VBox vbHead = JKNode.getPageDblHeadVB(0, lblHead, lblStep);

        Label lblMainLife = JKText.getLblDk("Main Life Assured", JKText.FONT_B_SM);
        Label lblMainLifeID = JKText.getLblDk("ID Number", JKText.FONT_B_XXSM);
        Label lblMainLifeName = JKText.getLblDk("Full First Names", JKText.FONT_B_XXSM);
        Label lblMainLifeSurname = JKText.getLblDk("Surname", JKText.FONT_B_XXSM);
        Label lblMainLifeContact1 = JKText.getLblDk("Contact No. 1", JKText.FONT_B_XXSM);
        Label lblMainLifeContact2 = JKText.getLblDk("Contact No. 2", JKText.FONT_B_XXSM);

        Label lblBeneficiary = JKText.getLblDk("Beneficiary", JKText.FONT_B_SM);
        Label lblBeneficiaryName = JKText.getLblDk("Full First Names", JKText.FONT_B_XXSM);
        Label lblBeneficiarySurname = JKText.getLblDk("Surname", JKText.FONT_B_XXSM);
        txtMainLifeID = new TextField();
        txtMainLifeID.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getNumPad().showNumPad(txtMainLifeID, "Main Life ID", "", new NumberPadResult() {
                    @Override
                    public void onDone(String result) {
                        checkAgeAllowed(result);
                    }
                });
//                }
            }
        });

        txtMainLifeName = new TextField();
        txtMainLifeName.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getKeyboard().showKeyboard(txtMainLifeName, "Enter Main Life Full First Names", "", false, true);
//                }
            }
        });

        txtMainLifeSurname = new TextField();
        txtMainLifeSurname.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getKeyboard().showKeyboard(txtMainLifeSurname, "Enter Main Life Surname", "", false, true);
//                }
            }
        });

        txtMainLifeContact1 = new TextField();
        txtMainLifeContact1.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getNumPad().showNumPad(txtMainLifeContact1, "Contact Number 1", "");
//                }
            }
        });

        txtMainLifeContact2 = new TextField();
        txtMainLifeContact2.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getNumPad().showNumPad(txtMainLifeContact2, "Contact Number 2", "");
//                }
            }
        });

        txtBeneficiaryName = new TextField();
        txtBeneficiaryName.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getKeyboard().showKeyboard(txtBeneficiaryName, "Enter Beneficiary First Names", "", false, true);
//                }
            }
        });

        txtBeneficiarySurname = new TextField();
        txtBeneficiarySurname.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
//                if (!JKOptions.getOptions().isKeyboard()) {
                JKiosk3.getKeyboard().showKeyboard(txtBeneficiarySurname, "Enter Beneficiary Surname", "", false, true);
//                }
            }
        });
        GridPane grid = JKLayout.getContentGrid2Col(0.25, 0.75);

        grid.add(vbHead, 0, 0, 2, 1);

        grid.add(lblMainLife, 0, 1, 2, 1);
        grid.addRow(2, lblMainLifeID, txtMainLifeID);
        grid.addRow(3, lblMainLifeName, txtMainLifeName);
        grid.addRow(4, lblMainLifeSurname, txtMainLifeSurname);
        grid.addRow(5, lblMainLifeContact1, txtMainLifeContact1);
        grid.addRow(6, lblMainLifeContact2, txtMainLifeContact2);
        grid.addRow(8, JKNode.createGridSpanSep(2));
        grid.add(lblBeneficiary, 0, 9, 2, 1);
        grid.addRow(10, lblBeneficiaryName, txtBeneficiaryName);
        grid.addRow(11, lblBeneficiarySurname, txtBeneficiarySurname);

        Group grp = JKNode.getContentGroup(grid);

        return grp;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav();

        nav.getBtnBack().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new PolicyReg1());
            }
        });

        nav.getBtnCancel().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent(new BillPaymentMenu());
            }
        });

        nav.getBtnNext().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                if (isValidReg2()) {
                    PolicyRegistration.getInstance().setNav2(true);
                    PolicyRegistration.getInstance().setMainLifeID(txtMainLifeID.getText());
                    PolicyRegistration.getInstance().setMainLifeName(txtMainLifeName.getText());
                    PolicyRegistration.getInstance().setMainLifeSurname(txtMainLifeSurname.getText());
                    PolicyRegistration.getInstance().setMainLifeContact1(txtMainLifeContact1.getText());
                    PolicyRegistration.getInstance().setMainLifeContact2(txtMainLifeContact2.getText());
                    PolicyRegistration.getInstance().setBeneficiaryName(txtBeneficiaryName.getText());
                    PolicyRegistration.getInstance().setBeneficiarySurname(txtBeneficiarySurname.getText());
                    SceneSales.clearAndChangeContent(new PolicyReg4());
                }
            }
        });
        return nav;
    }

    private void checkAgeAllowed(String mainID) {
        String mainDOB = mainID.substring(0, 6);
        try {
            Date dob = new SimpleDateFormat("yyMMdd").parse(mainDOB);
            Date now = new Date();
            long dobLong = dob.getTime();
            long nowLong = now.getTime();
            long ageMillis = nowLong - dobLong;
            double ageDays = (double) TimeUnit.MILLISECONDS.toDays(ageMillis);
            double age18 = 18 * 365.25;
            double age64 = 64 * 365.25;
            if (ageDays < age18 || ageDays > age64) {
                System.out.println("person's age in years = " + ageDays / 365.25);
                JKiosk3.getMsgBox().showMsgBox("Not Eligible", "Only Persons between the ages of 18 and 64 years "
                        + "\nqualify for this policy", null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                    @Override
                    public void onOk() {
                        txtMainLifeID.setText("");
                    }

                    @Override
                    public void onCancel() {
                        //
                    }

                });
            } else {
                System.out.println("person's age in years = " + ageDays / 365.25);
            }
        } catch (ParseException pe) {
            pe.printStackTrace();
        }
    }

    private boolean isValidReg2() {
        if (txtMainLifeID.getText() == null || txtMainLifeID.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Main Life Assured ID", "Please enter ID number of Main Life Assured", null);
            return false;
        }
        if (!txtMainLifeID.getText().matches("(\\d{13})")) {
            JKiosk3.getMsgBox().showMsgBox("Main Life Assured ID", "Please enter a valid RSA ID number", null);
            return false;
        }
        if (txtMainLifeName.getText() == null || txtMainLifeName.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Main Life Assured Name", "Please enter First Names of Main Life Assured", null);
            return false;
        }
        if (txtMainLifeSurname.getText() == null || txtMainLifeSurname.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Main Life Assured Surname", "Please enter Surname of Main Life Assured", null);
            return false;
        }
        if (txtMainLifeContact1.getText() == null || txtMainLifeContact1.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Main Life Assured Contact Number", "Please enter Primary Contact Number of Main Life Assured", null);
            return false;
        }
        if (!txtMainLifeContact1.getText().matches("^0(\\d{9})")) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Contact No. 1", "Please enter valid Contact No. 1", null);
            return false;
        }
        if (txtMainLifeContact2.getText() == null || txtMainLifeContact2.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Main Life Assured Contact Number", "Please enter Alternate Contact Number of Main Life Assured", null);
            return false;
        }
        if (!txtMainLifeContact2.getText().matches("^0(\\d{9})")) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Contact No. 2", "Please enter valid Contact No. 2", null);
            return false;
        }
        if (txtMainLifeContact1.getText().equals(txtMainLifeContact2.getText())) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Contact Numbers", "Contact No. 1 and Contact No. 2 cannot be the same", null);
            return false;
        }
        if (txtBeneficiaryName.getText() == null || txtBeneficiaryName.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Beneficiary Name", "Please enter First Names of Beneficiary", null);
            return false;
        }
        if (txtBeneficiarySurname.getText() == null || txtBeneficiarySurname.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Beneficiary Surname", "Please enter Surname of Beneficiary", null);
            return false;
        }
        return true;
    }
}
