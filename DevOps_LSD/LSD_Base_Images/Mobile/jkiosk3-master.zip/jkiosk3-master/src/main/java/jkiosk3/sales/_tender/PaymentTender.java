package jkiosk3.sales._tender;

import aeontender.Item;
import aeontender.TenderType;
import aeontender.TenderTypeResponse;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SaleSummary;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales._common.SummaryTableView;
import jkiosk3.store.JKSalesOptions;
import jkiosk3.store.JKTenders;

public class PaymentTender extends Region {

    private final static Logger logger = Logger.getLogger(PaymentTender.class.getName());
    //
    private Double amountDue;
    private Text txtDue;
    private Text txtPaid;
    private Text txtOutstanding;
    private Text txtChange;
    private TextField txtfldCash;
    private TextField txtfldCheque;
    private TextField txtfldCredCard;
    private TextField txtfldDebCard;
    private Button btnOK;
    private static Double pdCash = 0.0;
    private static Double pdCheque = 0.0;
    private static Double pdCredCard = 0.0;
    private static Double pdDebCard = 0.0;
    private Double pdTotalPaid;
    private Double pdOutstanding;
    private static Double change;
    private PaymentTenderResult result;
    private TenderType tender;
    //
    private String defaultCash;
    private String defaultCheque;
    private String defaultCredCard;
    private String defaultDebCard;

    public PaymentTender() {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getPayTenderGrp());
        getChildren().add(stack);
    }

    private VBox getPayTenderGrp() {

        double w = 450;

        Label lblHead = JKText.getLblDk("Payment Due", JKText.FONT_B_XSM);
        Label lblCash = JKText.getLblDk("Cash:", JKText.FONT_B_XSM);
        lblCash.setDisable(!JKSalesOptions.getSalesOptions().isAcceptCash());
        Label lblCheque = JKText.getLblDk("Cheque:", JKText.FONT_B_XSM);
        lblCheque.setDisable(!JKSalesOptions.getSalesOptions().isAcceptCheque());
        Label lblCreditCard = JKText.getLblDk("Credit Card:", JKText.FONT_B_XSM);
        lblCreditCard.setDisable(!JKSalesOptions.getSalesOptions().isAcceptCreditCard());
        Label lblDebitCard = JKText.getLblDk("Debit Card:", JKText.FONT_B_XSM);
        lblDebitCard.setDisable(!JKSalesOptions.getSalesOptions().isAcceptDebitCard());
        Label lblTotalPaid = JKText.getLblDk("Total Paid:", JKText.FONT_B_XSM);
        Label lblOutstanding = JKText.getLblDk("Outstanding:", JKText.FONT_B_XSM);
        Label lblChange = JKText.getLblDk("Change:", JKText.FONT_B_XSM);

        // amounts in text boxes
        txtDue = JKText.getTxtDk("", JKText.FONT_B_SM);

        txtPaid = JKText.getTxtDk("", JKText.FONT_B_SM);

        txtOutstanding = JKText.getTxtDk("", JKText.FONT_B_SM);
        txtOutstanding.setStyle("-fx-fill: #FF0000;");

        txtChange = JKText.getTxtDk("", JKText.FONT_B_SM);

        txtfldCash = new TextField();
        txtfldCash.getStyleClass().add("txtfld-numeric");
        txtfldCash.setAlignment(Pos.CENTER_RIGHT);
        txtfldCash.setText(getTxtfldFormat(pdCash));
        txtfldCash.setDisable(!JKSalesOptions.getSalesOptions().isAcceptCash());
        txtfldCash.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (pdCash > 0.0) {
                    defaultCash = Double.toString(pdCash);
                } else {
                    defaultCash = "0";
                }
                JKiosk3.getNumPad().showNumPad(txtfldCash, "Cash", defaultCash, new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        double tenderRequired = TenderAmounts.getTenderCash();
                        if (validateInputField(txtfldCash, value, pdCash, tenderRequired)) {
                            pdCash = Double.parseDouble(value);
                            txtfldCash.setText(getTxtfldFormat(pdCash));
                            updateValues();
                        }
                    }
                });
            }
        });

        txtfldCheque = new TextField();
        txtfldCheque.getStyleClass().add("txtfld-numeric");
        txtfldCheque.setAlignment(Pos.CENTER_RIGHT);
        txtfldCheque.setText(getTxtfldFormat(0));
        txtfldCheque.setDisable(!JKSalesOptions.getSalesOptions().isAcceptCheque());
        txtfldCheque.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (pdCheque > 0.0) {
                    defaultCheque = Double.toString(pdCheque);
                } else {
                    defaultCheque = "0";
                }
                JKiosk3.getNumPad().showNumPad(txtfldCheque, "Cheque", defaultCheque, new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        double tenderRequired = TenderAmounts.getTenderCheque();
                        if (validateInputField(txtfldCheque, value, pdCheque, tenderRequired)) {
                            pdCheque = Double.parseDouble(value);
                            txtfldCheque.setText(getTxtfldFormat(pdCheque));
                            updateValues();
                        }
                    }
                });
            }
        });

        txtfldCredCard = new TextField();
        txtfldCredCard.getStyleClass().add("txtfld-numeric");
        txtfldCredCard.setAlignment(Pos.CENTER_RIGHT);
        txtfldCredCard.setText(getTxtfldFormat(0));
        txtfldCredCard.setDisable(!JKSalesOptions.getSalesOptions().isAcceptCreditCard());
        txtfldCredCard.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (pdCredCard > 0.0) {
                    defaultCredCard = Double.toString(pdCredCard);
                } else {
                    defaultCredCard = "0";
                }
                JKiosk3.getNumPad().showNumPad(txtfldCredCard, "Credit Card", defaultCredCard, new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        double tenderRequired = TenderAmounts.getTenderCreditCard();
                        if (validateInputField(txtfldCredCard, value, pdCredCard, tenderRequired)) {
                            pdCredCard = Double.parseDouble(value);
                            txtfldCredCard.setText(getTxtfldFormat(pdCredCard));
                            updateValues();
                        }
                    }
                });
            }
        });

        txtfldDebCard = new TextField();
        txtfldDebCard.getStyleClass().add("txtfld-numeric");
        txtfldDebCard.setAlignment(Pos.CENTER_RIGHT);
        txtfldDebCard.setText(getTxtfldFormat(0));
        txtfldDebCard.setDisable(!JKSalesOptions.getSalesOptions().isAcceptDebitCard());
        txtfldDebCard.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (pdDebCard > 0.0) {
                    defaultDebCard = Double.toString(pdDebCard);
                } else {
                    defaultDebCard = "0";
                }
                JKiosk3.getNumPad().showNumPad(txtfldDebCard, "Debit Card", defaultDebCard, new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        double tenderRequired = TenderAmounts.getTenderDebitCard();
                        if (validateInputField(txtfldDebCard, value, pdDebCard, tenderRequired)) {
                            pdDebCard = Double.parseDouble(value);
                            txtfldDebCard.setText(getTxtfldFormat(pdDebCard));
                            updateValues();
                        }
                    }
                });
            }
        });

        btnOK = JKNode.getBtnMsgBox("OK");
        btnOK.setDisable(true);
        btnOK.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onOkBtnEvent();
            }
        });

        Button btnCancel = JKNode.getBtnMsgBox("Cancel");
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onCancelBtnEvent();
            }
        });

        double sp = JKLayout.sp;

        HBox hbBtns = JKLayout.getHBox(sp, sp);
        hbBtns.setPrefWidth(w - (2 * sp));
        hbBtns.setSpacing(2 * sp);
        hbBtns.setStyle("-fx-alignment: center;");
        hbBtns.getChildren().addAll(btnOK, btnCancel);

        GridPane grid = new GridPane();
        grid.setMaxWidth(w - (2 * sp));
        grid.getStyleClass().add("gridContent");

        ColumnConstraints col0 = new ColumnConstraints();
        col0.setMaxWidth((w - (4 * sp)) * 0.5);
        col0.setMinWidth((w - (4 * sp)) * 0.5);
        col0.setFillWidth(true);
        col0.setHalignment(HPos.LEFT);
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setMaxWidth((w - (4 * sp)) * 0.5);
        col1.setMinWidth((w - (4 * sp)) * 0.5);
        col1.setFillWidth(true);
        col1.setHalignment(HPos.RIGHT);

        grid.getColumnConstraints().addAll(col0, col1);

        grid.add(lblHead, 0, 0);
        grid.add(JKNode.createGridSpanSep(2), 0, 1);
        grid.add(lblCash, 0, 2);
        grid.add(lblCheque, 0, 3);
        grid.add(lblCreditCard, 0, 4);
        grid.add(lblDebitCard, 0, 5);
        grid.add(JKNode.createGridSpanSep(2), 0, 6);
        grid.add(lblTotalPaid, 0, 7);
        grid.add(lblOutstanding, 0, 8);
        grid.add(lblChange, 0, 9);

        grid.add(txtDue, 1, 0);
        grid.add(txtfldCash, 1, 2);
        grid.add(txtfldCheque, 1, 3);
        grid.add(txtfldCredCard, 1, 4);
        grid.add(txtfldDebCard, 1, 5);
        grid.add(txtPaid, 1, 7);
        grid.add(txtOutstanding, 1, 8);
        grid.add(txtChange, 1, 9);

        VBox vbox = JKLayout.getVBoxContent(5);
        vbox.setStyle("-fx-padding: 0px 15px 0px 15px;");
        vbox.setMaxSize(w, 525);
        vbox.setMinSize(w, 525);
        vbox.setAlignment(Pos.TOP_CENTER);
        vbox.setTranslateY(-JKLayout.sp);

        vbox.getChildren().addAll(grid, new Separator(), hbBtns);

        return vbox;
    }

    private String getTxtfldFormat(double number) {
        String strFormat = String.format(JKText.getDeciFormat(number));
        return strFormat;
    }

    private boolean validateInputField(final TextField field, String value,
                                       final double currentAmount, final double tenderRequired) {
        if ((value == null) || (value.equals("")) || (value.isEmpty())) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Amount", "Amount entered cannot be empty", null);
            field.setText(getTxtfldFormat(currentAmount));
            return false;
        }
        try {
            double tmpvalue = Double.parseDouble(value);
            if (tmpvalue < tenderRequired) {
                JKiosk3.getMsgBox().showMsgBox("Invalid Amount", "Amount entered cannot be less than " + JKText.getDeciFormat(tenderRequired), null);
                field.setText(getTxtfldFormat(tenderRequired));
                return false;
            }
        } catch (NumberFormatException nfe) {
            System.out.println("amount entered error : " + nfe.getMessage());
            JKiosk3.getMsgBox().showMsgBox("Invalid Amount Entered", "Amount must be a valid rand value", null);
            field.setText(getTxtfldFormat(currentAmount));
            return false;
        }
        return true;
    }

    private void updateValues() {
        pdTotalPaid = pdCash + pdCheque + pdCredCard + pdDebCard;

        amountDue = Double.valueOf(new DecimalFormat("#.##").format(amountDue));

        if (pdTotalPaid >= amountDue) {
            pdOutstanding = 0.0;
            txtOutstanding.setStyle(JKText.getBrandText());
            change = pdTotalPaid - amountDue;
            btnOK.setDisable(false);
        } else {
            pdOutstanding = amountDue - pdTotalPaid;
            txtOutstanding.setStyle("-fx-fill: #FF0000;");
            change = 0.0;
            btnOK.setDisable(true);
        }

        txtPaid.setText(JKText.getDeciFormat(pdTotalPaid));
        txtOutstanding.setText(JKText.getDeciFormat(pdOutstanding));
        txtChange.setText(JKText.getDeciFormat(change));
    }

    private void onOkBtnEvent() {

        SummaryTableView.setPrintTendered(pdTotalPaid);
        SummaryTableView.setPrintChange(change);

        tender = getPaymentReceivedDetail();

        submitTender(true);
    }

    private void onCancelBtnEvent() {
        clearContents();
        setVisible(false);
        toBack();
        if (result != null) {
            result.onCancel();
        }
    }

    public void clearAndHidePaymentTender() {
        onCancelBtnEvent();
    }

    private void clearContents() {
        txtDue.setText(JKText.getDeciFormat(0));
        txtfldCash.setText(getTxtfldFormat(0));
        txtfldCheque.setText(getTxtfldFormat(0));
        txtfldCredCard.setText(getTxtfldFormat(0));
        txtfldDebCard.setText(getTxtfldFormat(0));
        amountDue = 0.0;
        pdCash = 0.0;
        pdCheque = 0.0;
        pdCredCard = 0.0;
        pdDebCard = 0.0;
        pdTotalPaid = 0.0;
        pdOutstanding = 0.0;
        change = 0.0;
        txtOutstanding.setStyle("-fx-fill: #FF0000;");
        btnOK.setDisable(true);
    }

    private void showInitialTenders() {
        pdCash = pdCash + TenderAmounts.getTenderCash();
        pdCheque = pdCheque + TenderAmounts.getTenderCheque();
        pdCredCard = pdCredCard + TenderAmounts.getTenderCreditCard();
        pdDebCard = pdDebCard + TenderAmounts.getTenderDebitCard();

        txtfldCash.setText(getTxtfldFormat(pdCash));
        txtfldCheque.setText(getTxtfldFormat(pdCheque));
        txtfldCredCard.setText(getTxtfldFormat(pdCredCard));
        txtfldDebCard.setText(getTxtfldFormat(pdDebCard));

        updateValues();
    }

    public void showPaymentTender(double amount, PaymentTenderResult res) {
        this.amountDue = amount;
        this.result = res;

        showInitialTenders();

        txtDue.setText(JKText.getDeciFormat(amountDue));
        txtDue.setStyle(JKText.getBrandText());

        txtPaid.setText(JKText.getDeciFormat(0.0));
        txtPaid.setStyle(JKText.getBrandText());
        txtOutstanding.setText(JKText.getDeciFormat(amountDue - pdTotalPaid));
        txtChange.setText(JKText.getDeciFormat(0.0));
        txtChange.setStyle(JKText.getBrandText());

        this.setVisible(true);
        this.toFront();
    }

    public void calculatePaymentTender(double amount, PaymentTenderResult res) {
        this.amountDue = amount;
        this.result = res;

        pdCash = pdCash + TenderAmounts.getTenderCash();
        pdCheque = pdCheque + TenderAmounts.getTenderCheque();
        pdCredCard = pdCredCard + TenderAmounts.getTenderCreditCard();
        pdDebCard = pdDebCard + TenderAmounts.getTenderDebitCard();

        pdTotalPaid = pdCash + pdCheque + pdCredCard + pdDebCard;

        amountDue = Double.valueOf(new DecimalFormat("#.##").format(amountDue));

        if (pdTotalPaid >= amountDue) {
            pdOutstanding = 0.0;
            change = pdTotalPaid - amountDue;
        } else {
            pdOutstanding = amountDue - pdTotalPaid;
            change = 0.0;
            // add outstanding amount to pdCash
            pdCash = pdCash + pdOutstanding;
        }

        pdTotalPaid = pdCash + pdCheque + pdCredCard + pdDebCard;

        SummaryTableView.setPrintTendered(pdTotalPaid);
        SummaryTableView.setPrintChange(change);

        tender = getPaymentReceivedDetail();

        submitTender(false);
    }

    private TenderType getPaymentReceivedDetail() {
        TenderType tendered = new TenderType();
        tendered.setReference(SalesUtil.getUniqueRef());
        tendered.setTotal(amountDue);
        tendered.setCash(pdCash);
        tendered.setCheque(pdCheque);
        tendered.setCreditcard(pdCredCard);
        tendered.setDebitcard(pdDebCard);
        tendered.setOther(0.0);
        tendered.setChange(change);

        List<Item> itemList = new ArrayList<>();
        for (SaleSummary s : SummaryTableView.getSummaryRows()) {
            Item item = new Item();
            item.setTransRef(s.getReference());
            itemList.add(item);
        }
        tendered.setItemList(itemList);

        return tendered;
    }

    private void submitTender(final boolean showChange) {
        JKTenders.saveTender(tender);
        TenderUtil.submitTenderSummary(tender, showChange, new TenderUtil.TenderSubmitResult() {

            @Override
            public void tenderSubmitResult(TenderTypeResponse tenderResponse) {
                if (tenderResponse != null && tenderResponse.isSuccess()) {
                    onSubmitComplete(showChange);
                    if (JKTenders.hasItems() && JKTenders.getJkTenders().getListTenderTypes().contains(tender)) {
                        JKTenders.removeTender(tender);
                    } else {
                        System.out.println("oops, this TenderType is not in our saved list");
                    }
                } else {
                    logger.info(("*** TENDER SUBMIT FAILED *** - Shift will not balance by the value of this Sale - R ").concat(Double.toString(tender.getTotal())));
                    JKiosk3.getMsgBox().showMsgBox("Submit Tender", "\nSubmit Tender Failed"
                            + "\n\nSystem will attempt to re-submit on next Login,"
                            + "\nor before viewing Reports.", null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                        @Override
                        public void onOk() {
                            onSubmitComplete(showChange);
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
                }
            }
        });
    }

    private void onSubmitComplete(boolean showChange) {
        if (showChange) {
            SalesUtil.showChange(change);
        }
        resetAndClear();
        setVisible(false);
        toBack();
        if (result != null) {
            result.onOk();
        }
    }

    private void resetAndClear() {
        TenderAmounts.resetTenderAmounts();
        clearContents();
    }

    // getters and setters as required
    public static double getPdCash() {
        return pdCash;
    }

    public static double getPdCheque() {
        return pdCheque;
    }

    public static double getPdCredCard() {
        return pdCredCard;
    }

    public static double getPdDebCard() {
        return pdDebCard;
    }

    public static double getChange() {
        return change;
    }
}
