package jkiosk3.sales.topups;

import aeontopup.TopupAirtimeReq;
import aeontopup.TopupBundleProduct;
import aeontopup.TopupBundleReq;
import aeontopup.TopupWalletReq;
import jkiosk3.sales.SaleType;

public class TopupSale {

    private SaleType saleType;
    private TopupProvider provider;
    private String providerStyleName;
    private String category;
    private TopupAirtimeReq airtimeReq;
    private TopupBundleProduct product;
    private TopupBundleReq bundleReq;
    private TopupWalletReq walletReq;
    private String cellNum;
    private double amount;
    private String ref;
    private boolean rechargePlus;
    //
    private static TopupSale instance;

    private static TopupSale newInstance() {
        instance = new TopupSale();
        return instance;
    }

    public static TopupSale getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    public static void resetTopupSale() {
        instance = null;
    }

    // getters and setters

    public SaleType getSaleType() {
        return saleType;
    }

    public void setSaleType(SaleType saleType) {
        this.saleType = saleType;
    }

    public TopupProvider getProvider() {
        return provider;
    }

    public void setProvider(TopupProvider provider) {
        this.provider = provider;
    }

    public String getProviderStyleName() {
        return providerStyleName;
    }

    public void setProviderStyleName(String providerStyleName) {
        this.providerStyleName = providerStyleName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public TopupAirtimeReq getAirtimeReq() {
        return airtimeReq;
    }

    public void setAirtimeReq(TopupAirtimeReq airtimeReq) {
        this.airtimeReq = airtimeReq;
    }

    public TopupBundleProduct getProduct() {
        return product;
    }

    public void setProduct(TopupBundleProduct product) {
        this.product = product;
    }

    public TopupBundleReq getBundleReq() {
        return bundleReq;
    }

    public void setBundleReq(TopupBundleReq bundleReq) {
        this.bundleReq = bundleReq;
    }

    public TopupWalletReq getWalletReq() {
        return walletReq;
    }

    public void setWalletReq(TopupWalletReq walletReq) {
        this.walletReq = walletReq;
    }

    public String getCellNum() {
        return cellNum;
    }

    public void setCellNum(String cellNum) {
        this.cellNum = cellNum;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public boolean isRechargePlus() {
        return rechargePlus;
    }

    public void setRechargePlus(boolean rechargePlus) {
        this.rechargePlus = rechargePlus;
    }
}
