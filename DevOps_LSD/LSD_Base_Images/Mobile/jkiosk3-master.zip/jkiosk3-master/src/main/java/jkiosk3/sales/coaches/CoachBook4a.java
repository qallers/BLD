package jkiosk3.sales.coaches;

import aeoncoach.CoachPassenger;
import aeoncoach.CoachPassengerType;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.NumberPadResult;
import jkiosk3.store.JKOptions;

import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CoachBook4a extends Region {

    private final static Logger logger = Logger.getLogger(CoachBook4a.class.getName());

    private final double popupWidth = (MessageBox.getMsgWidth() - (4 * JKLayout.sp));
    //
    private CoachPassengerType infantType;
    private RadioButton radMale;
    private RadioButton radFemale;
    private TextField txtInfInitial;
    private TextField txtInfSurname;
    private TextField txtInfAge;
    private double infantAge;

    public CoachBook4a(CoachPassengerType infantType) {
        this.infantType = infantType;

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(getInfantEntryLayout());
        getChildren().add(vb);
    }

    private VBox getInfantEntryLayout() {
        Label lblClear = JKText.getLblDk("Clear all", JKText.FONT_B_XXSM);
        Label lblInstruct = JKText.getLblDk("'Save' details, then click 'OK' to continue, \nor 'Cancel' to close this popup without saving",
                JKText.FONT_B_18);

        final Button btnClear = JKNode.getBtnPopup("clear");
        btnClear.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                radMale.setSelected(false);
                radFemale.setSelected(false);
                txtInfInitial.clear();
                txtInfSurname.clear();
                txtInfAge.clear();
                JKiosk3.getInputPopup().btnsDisable(false, true, false);
            }
        });
        HBox hbBtns = JKLayout.getHBox(0, JKLayout.sp);
        hbBtns.getChildren().addAll(JKNode.getHSpacer(), btnClear);

        GridPane gridInf2 = JKLayout.getGridSummary2ColVariWidth(0.75, 0.25, popupWidth);
        gridInf2.addRow(4, lblClear, hbBtns);
        gridInf2.add(lblInstruct, 0, 5, 2, 1);

        VBox vbInfGrids = JKLayout.getVBox(0, JKLayout.spNum);
        vbInfGrids.setMaxWidth(popupWidth);
        vbInfGrids.setMinWidth(popupWidth);
        vbInfGrids.getChildren().addAll(getInfantEntry(), gridInf2);

        return vbInfGrids;
    }

    private GridPane getInfantEntry() {

        Label lblInfGender = JKText.getLblDk("Gender", JKText.FONT_B_XSM);
        Label lblInfInitial = JKText.getLblDk("Initials", JKText.FONT_B_XSM);
        Label lblInfSurname = JKText.getLblDk("Surname", JKText.FONT_B_XSM);
        Label lblAge = JKText.getLblDk("Age (in Months)", JKText.FONT_B_XSM);

        ToggleGroup toggleGroup = new ToggleGroup();

        radMale = new RadioButton("Male");
        radMale.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");
        radMale.setToggleGroup(toggleGroup);

        radFemale = new RadioButton("Female");
        radFemale.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");
        radFemale.setToggleGroup(toggleGroup);

        HBox hbGender = JKLayout.getHBox(0, 0);
        hbGender.getChildren().addAll(radMale, JKNode.getHSpacer(), radFemale, JKNode.getHSpacer());

        txtInfInitial = new TextField();
        txtInfInitial.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event arg0) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtInfInitial, "Enter Initials (3 characters max)", "",
                            false, false, new KeyboardResult() {
                                @Override
                                public void onDone(String value) {
                                    if (!value.matches("[a-zA-Z ]{1,3}")) {
                                        JKiosk3.getMsgBox().showMsgBox("Infant Initials", "Please enter Initials,"
                                                + "\nnot more than 3 characters", null);
                                        txtInfInitial.clear();
                                    } else {
                                        txtInfInitial.setText(value);
                                    }
                                }
                            });
                }
            }
        });

        txtInfSurname = new TextField();
        txtInfSurname.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event arg0) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtInfSurname, "Enter Surname (20 characters max)", "",
                            false, false, new KeyboardResult() {
                                @Override
                                public void onDone(String value) {
                                    if (!value.matches("[a-zA-Z ]{1,20}")) {
                                        JKiosk3.getMsgBox().showMsgBox("Infant Surname", "Please enter Infant Surname, "
                                                + "\nnot more than 20 characters", null);
                                        txtInfSurname.clear();
                                    } else {
                                        txtInfSurname.setText(value);
                                    }
                                }
                            });
                }
            }
        });

        txtInfAge = new TextField();
        txtInfAge.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event arg0) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtInfAge, "Age in Months", "", new NumberPadResult() {
                        @Override
                        public void onDone(String value) {
                            if (isValidAgeEntry(value)) {
                                txtInfAge.setText(value);
                            } else {
                                txtInfAge.clear();
                            }
                        }
                    });
                }
            }
        });

        GridPane gridInf = JKLayout.getGridSummary2ColVariWidth(0.5, 0.5, popupWidth);

        gridInf.addRow(0, lblInfGender, hbGender);
        gridInf.addRow(1, lblInfInitial, txtInfInitial);
        gridInf.addRow(2, lblInfSurname, txtInfSurname);
        gridInf.addRow(3, lblAge, txtInfAge);

        return gridInf;
    }

    public CoachPassenger getCoachPassengerInfant() {
        if (isValidateInfantDetails()) {
            CoachPassenger passInfantOnLap = new CoachPassenger();

            if (radMale.isSelected()) {
                passInfantOnLap.setTitle("Mr");
            } else if (radFemale.isSelected()) {
                passInfantOnLap.setTitle("Ms");
            }
            passInfantOnLap.setInitials(txtInfInitial.getText());
            passInfantOnLap.setLastName(txtInfSurname.getText());
            DecimalFormat df = new DecimalFormat("#,##0");
            passInfantOnLap.setIdNumber(df.format(infantAge));

            passInfantOnLap.setCellNum("0000000000");
            passInfantOnLap.setEmail("");

            passInfantOnLap.setPassengerTypeCode(infantType.getCode());
            passInfantOnLap.setDiscount("");
            passInfantOnLap.setInfant(false);
            return passInfantOnLap;
        } else {
            return null;
        }
    }

    private boolean isValidAgeEntry(String value) {
        try {
            double infantAgeInMonths = Double.parseDouble(value);
            double infAge = infantAgeInMonths / 12;
            infantAge = Math.floor(infAge);
            System.out.println("infant age entered as a Double and FLOORED = " + infantAge);
            int carrierAgeLimit = infantType.getMaxAge();
            String carrierName = CoachTicketSale.getInstance().getCoachCarrierDepart().getCarrierDescription();
            if (infantAgeInMonths < 0) {
                JKiosk3.getMsgBox().showMsgBox("Invalid Infant Age", "Negative values are not allowed", null);
                return false;
            }
            if (infantAgeInMonths > carrierAgeLimit) {
                JKiosk3.getMsgBox().showMsgBox("Invalid Infant Age", "Selected Carrier : " + carrierName
                        + "\n\nallows Infant On Lap up to the age of \n\n"
                        + carrierAgeLimit + " months", null);
                return false;
            }
        } catch (NumberFormatException nfe) {
            logger.log(Level.SEVERE, nfe.getMessage(), nfe);
            return false;
        }
        return true;
    }

    public boolean isValidateInfantDetails() {
        if (!radMale.isSelected() && !radFemale.isSelected()) {
            JKiosk3.getMsgBox().showMsgBox("Infant Gender", "Please select either 'Male' or 'Female'", null);
            return false;
        }
        if (txtInfInitial.getText() == null || txtInfInitial.getText().equals("")
                || txtInfSurname.getText() == null || txtInfSurname.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Infant Initials and Surname", "Please enter Infant Initials and Surname", null);
            return false;
        }
        if (txtInfAge.getText() == null || txtInfAge.getText().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Infant Age", "Please enter Infant Age", null);
            return false;
        }
        return true;
    }
}
//
// =======================================================

//        Label lblInfTitle = JKText.getLblDk("Title", JKText.FONT_B_XSM);

//        ObservableList titles = FXCollections.observableArrayList();
// for male infant
//        for (BusListItem b : titleList) {
//            String tc = b.getCode();
//            if (tc.equalsIgnoreCase("MAST")
//                    || tc.equalsIgnoreCase("MASTER")
//                    || tc.equalsIgnoreCase("MR")) {
//                titles.add(tc);
//                break;
//            }
//        }
//        // for female infant
//        for (BusListItem b : titleList) {
//            String tc = b.getCode();
//            if (tc.equalsIgnoreCase("MISS")
//                    || tc.equalsIgnoreCase("MS")) {
//                titles.add(tc);
//                break;
//            }
//        }

//        ComboBox comInfTitle = new ComboBox();
//        comInfTitle.setPrefSize((JKLayout.btnSmW + JKLayout.sp), 35);
//        comInfTitle.setVisibleRowCount(15);
//        comInfTitle.setItems(titles);

//            passInfantOnLap.setTitle(infTitle);

//            switch (CoachTicketSale.getInstance().getRouteDepart().getCarrier()) {
//                case CarmaUtil.CARRIER_CODE_ELDOCOACHES:
//                    passInfantOnLap.setPassengerType("C");
//                    break;
//                case CarmaUtil.CARRIER_CODE_CITYTOCITY:
//                case CarmaUtil.CARRIER_CODE_TRANSLUX:
//                    passInfantOnLap.setPassengerType("I");
//                    break;
//                case CarmaUtil.CARRIER_CODE_INTERCAPE:
//                    passInfantOnLap.setPassengerType("INFANT");
//                    break;
//                default:
//                    break;
//            }

//            for (CoachListItem i : CoachUtil.getListCoachPassengerTypes()) {
//                if (i.getCarrierId().equals(CoachTicketSale.getInstance().getCoachCarrierDepart().getCarrierCode())) {
//                    passInfantOnLap.setPassengerType(i);
//                }
//            }


//        if (title == null || title.equals("")) {
//            JKiosk3.getMsgBox().showMsgBox("Infant Title", "Please select a Title", null);
//            return false;
//        }

//                            try {
//                                int age = Integer.parseInt(value);
//                            } catch (NumberFormatException nfe) {
//                                logger.log(Level.SEVERE, nfe.getMessage(), nfe);
//                                JKiosk3.getMsgBox().showMsgBox("Infant Age", "Please enter a valid age", null);
//                                txtInfAge.clear();
//                            }
//                            if (isValidAgeEntry(value)) {
//
//                            } else {
//                                JKiosk3.getMsgBox().showMsgBox("Infant Age", "Please enter a valid age", null);
//                                txtInfAge.clear();
//                            }

//                            switch (BusTicketSale.getInstance().getBusCarrier().getCarrierCode()) {
//                                case CarmaUtil.CARRIER_CODE_CITYTOCITY:
//                                case CarmaUtil.CARRIER_CODE_TRANSLUX:
//                                case CarmaUtil.CARRIER_CODE_INTERCAPE:
//                                    if (Integer.parseInt(value) > 2) {
//                                        correctInfantAge(txtInfAge, "2");
//                                    }
//                                    break;
//                                case CarmaUtil.CARRIER_CODE_ELDOCOACHES:
//                                case CarmaUtil.CARRIER_CODE_SAROADLINK:
//                                    if (Integer.parseInt(value) > 3) {
//                                        correctInfantAge(txtInfAge, "3");
//                                    }
//                                    break;
//                                default:
//                                    break;
//                            }

//        if (infantToEdit != null) {
//            comInfTitle.getSelectionModel().select(infantToEdit.getTitle());
//            txtInfInitial.setText(infantToEdit.getInitials());
//            txtInfSurname.setText(infantToEdit.getLastName());
//            txtInfAge.setText(infantToEdit.getIdNumber());
//        }

