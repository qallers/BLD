package jkiosk3.sales.coaches;

import aeoncoach.CoachCarrier;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._components.MessageBox;

public class CoachCarrierInfo extends ScrollPane {

    public CoachCarrierInfo(CoachCarrier coachCarrier) {
        String info = "";
        double w = MessageBox.getMsgWidth() - (4 * JKLayout.sp);

        this.setMaxSize(w, 520);
        this.setMinSize(w, 520);
        this.getStyleClass().add("scrollWhite");
        this.setStyle("-fx-padding: 15px;");
        this.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        this.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);

        switch (coachCarrier.getCarrierTransType()) {
            case "CityToCity":
            case "TransLux":
            case "Translux":
                info = getInfoAutoPax();
                break;
            case "EldoCoaches":
            case "Eldo":
                info = getInfoEldoCoaches();
                break;
            case "Greyhound":
                info = getInfoGreyhound();
                break;
            case "Intercape":
                info = getInfoIntercape();
                break;
            default:
                info = getCarrierNotFound();
                break;
        }
        VBox vb = JKLayout.getVBox(0, 0);
        ImageView imgView = JKNode.getJKImageViewProvider("prov_" + coachCarrier.getCarrierTransType() + ".png");

        WebView webView = new WebView();
        webView.setMaxWidth(w - (4 * JKLayout.sp));
        webView.getEngine().loadContent(info);

        vb.getChildren().addAll(imgView, webView);

        this.setContent(vb);
    }

    private String getCarrierNotFound() {
        String sb = "";
        sb += ("<!DOCTYPE html><html lang='en'>");
        sb += ("<head><title></title><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></head>");
        sb += ("<body>");
        sb += ("<span style='font-family: Tahoma; color: #002349; font-size: 14pt; line-height: 1.5em; text-align: center;'>");
        sb += ("<br />");
        sb += ("<h3>No Information Found</h3>");
        sb += ("<h3>for this Carrier</h3>");
        sb += ("</span></body></html>");
        return sb;
    }

    private String getInfoAutoPax() {
        String sb = "";
        sb += ("<!DOCTYPE html><html lang='en'>");
        sb += ("<head><title></title><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></head>");
        sb += ("<body>");
        sb += ("<span style='font-family: Tahoma; color: #002349; font-size: 14pt; line-height: 1.5em;'>");
        sb += ("<h3>Seating Guide</h3>");
        sb += ("<ul>");
        sb += ("<li>No children under the age of 12 years will be conveyed without being accompanied by an adult.</li>");
        sb += ("<li>Children 12 years and older pay full fare.</li>");
        sb += ("<li>Children 3 - 11 years pay a discounted fare (limit of 3 (three) children per 1 (one) fare paying adult).</li>");
        sb += ("<li>Children younger than 3 years travel free if not occupying a seat (i.e. seated on adult's lap). Should "
                + "more than one child under three years old accompany the same adult, all successive children will pay the "
                + "rates for 3 - 11 years category.</li>");
        sb += ("<li>Positive identification will be required when the ticket is collected.</li>");
        sb += ("</ul>");
        sb += ("</span></body></html>");
        return sb;
    }

    private String getInfoEldoCoaches() {
        String sb = "";
        sb += ("<!DOCTYPE html><html lang='en'>");
        sb += ("<head><title></title><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></head>");
        sb += ("<body>");
        sb += ("<span style='font-family: Tahoma; color: #002349; font-size: 14pt; line-height: 1.5em;'>");
        sb += ("<h3>Seating Guide</h3>");
        sb += ("<ul>");
        sb += ("<li>No unaccompanied children under the age of 12 years will be transported.</li>");
        sb += ("<li>Children under 3 years will be transported for free provided that they sit on the mother’s lap.</li>");
        sb += ("<li>Not more than 3 children may accompany one fare paying adult.</li>");
        sb += ("<li>Eldo Coaches reserves the right to refuse the transport of sick passengers and/or pregnant females in "
                + "excess of 7 months.</li>");
        sb += ("</ul>");
        sb += ("</span></body></html>");
        return sb;
    }

    private String getInfoGreyhound() {
        String sb = "";
        sb += ("<!DOCTYPE html><html lang='en'>");
        sb += ("<head><title></title><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></head>");
        sb += ("<body>");
        sb += ("<span style='font-family: Tahoma; color: #002349; font-size: 14pt; line-height: 1.5em;'>");
        sb += ("<h3>Seating Guide</h3>");
        sb += ("<ul>");
        sb += ("<li>No unaccompanied children under the age of 12 will be conveyed.</li>");
        sb += ("<li>Proof of identity will be required when the ticket is purchased and on boarding the coach.</li>");
        sb += ("<li>Children over the age of two will be required to purchase a ticket and the child fare will apply.</li>");
        sb += ("<li>Infants under the age of two travel free of charge, provided they sit on an adults lap.</li>");
        sb += ("</ul>");
        sb += ("</span></body></html>");
        return sb;
    }
    
    private String getInfoIntercape() {
        String sb = "";
        sb += ("<!DOCTYPE html><html lang='en'>");
        sb += ("<head><title></title><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></head>");
        sb += ("<body>");
        sb += ("<span style='font-family: Tahoma; color: #002349; font-size: 14pt; line-height: 1.5em;'>");
        sb += ("<h3>Seating Guide</h3>");
        sb += ("<ul>");
        sb += ("<li>Children under 12 years will not be allowed to travel alone and must be accompanied by a parent or guardian older than 18 years.</li>");
        sb += ("<li>Children between 12 and 18 years will be allowed to travel alone, provided that a prescribed INTERCAPE "
                + "indemnity form was completed by the legal guardian or parent in respect of each unaccompanied child. "
                + "Please enquire with the consultant or agent upon purchase of the ticket.</li>");
        sb += ("<li>Children younger than 18 months may travel free of charge on the lap of a parent or legal guardian, "
                + "provided that only one child per parent or legal guardian is allowed.</li>");
        sb += ("<li>Positive identification will be required when the ticket is collected.</li>");
        sb += ("</ul>");
        sb += ("</span></body></html>");
        return sb;
    }

}
