package jkiosk3.sales.rica;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;

/**
 *
 * @author Val
 */
public class SubReg0 extends Region {

    private double sp = JKLayout.sp;
    private double w = JKLayout.contentW;
    private TextField txtIdentification;
    private TextField txtNationality;
    private ToggleButton toggleIdNumber;
    private ToggleButton togglePassport;

    public SubReg0() {
        setId(SubAll.REG_PG_0);

        getChildren().add(getSubPg0());
    }

    private VBox getSubPg0() {
        VBox vb = JKLayout.getVBoxLeft(0, sp);
        vb.setPrefWidth(w - (2 * sp));

        Label lblCurrOwner = JKText.getLblDk("Current Owner", JKText.FONT_B_SM);

        vb.getChildren().addAll(lblCurrOwner, getOwnerIdGrid());

        return vb;
    }

    private GridPane getOwnerIdGrid() {
        GridPane grid = JKLayout.getContentGridInner2Col(0.33, 0.67);

        Label lblIdentification = JKText.getLblDk("Identification", JKText.FONT_B_XSM);
        Label lblNationality = JKText.getLblDk("Nationality", JKText.FONT_B_XSM);

        txtNationality = new TextField();
        HBox.setHgrow(txtNationality, Priority.ALWAYS);
        txtNationality.setText("ZA - South Africa");
        txtNationality.setDisable(true);

        Button btnCodes = JKNode.getBtnPopup("code");
        btnCodes.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                Region codes = new CountryCodeList(txtNationality, CountryCodes.COUNTRY_NAME);
                JKiosk3.getMsgBox().showMsgBox("select country code", "", codes, MessageBox.CONTROLS_HIDE,
                        MessageBox.MSG_OK, null);
            }
        });

        HBox hbNationality = JKLayout.getHBox(0, 5);
        hbNationality.setPrefWidth(((w - (3 * sp)) * 0.67));
        hbNationality.getChildren().addAll(txtNationality, btnCodes);

        grid.add(lblIdentification, 0, 1);
        grid.add(lblNationality, 0, 3);

        grid.add(JKNode.createGridSpanSep(2), 1, 0);
        grid.add(getIdBox(), 1, 1);
        grid.add(JKNode.createGridSpanSep(2), 1, 2);
        grid.add(hbNationality, 1, 3);

        return grid;
    }

    private VBox getIdBox() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        ToggleGroup toggleIdPassport = new ToggleGroup();

        toggleIdNumber = JKNode.getToggleSmDbl("ID Number");
        toggleIdNumber.setToggleGroup(toggleIdPassport);

        togglePassport = JKNode.getToggleSmDbl("Passport Number");
        togglePassport.setToggleGroup(toggleIdPassport);

        HBox hb = JKLayout.getHBox(0, JKLayout.sp);
        hb.getChildren().addAll(toggleIdNumber, togglePassport);

        txtIdentification = new TextField();
        txtIdentification.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtIdentification, "Subscriber ID / Passport Number",
                        txtIdentification.getText(), false);
            }
        });

        vb.getChildren().addAll(hb, txtIdentification);

        return vb;
    }

    public ToggleButton getToggleIdNumber() {
        return toggleIdNumber;
    }

    public ToggleButton getTogglePassport() {
        return togglePassport;
    }

    public TextField getTxtIdentification() {
        return txtIdentification;
    }

    public TextField getTxtNationality() {
        return txtNationality;
    }

    //
    public boolean validatePg0() {
        boolean validPg0 = false;
        if (!toggleIdNumber.isSelected() && !togglePassport.isSelected()) {
            validPg0 = false;
            JKiosk3.getMsgBox().showMsgBox("Registration error", "Either 'ID Number' or 'Passport Number' "
                    + "button must be selected", null);
        } else if (txtIdentification.getText().equals("") || txtNationality.getText().equals("")) {
            validPg0 = false;
            JKiosk3.getMsgBox().showMsgBox("Registration error", "Current Owner Identification and Nationality required", null);
        } else {
            validPg0 = true;
        }
        return validPg0;
    }
}
