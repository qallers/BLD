package jkiosk3.reports;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.users.CurrentUser;

/**
 *
 * @author valeriew
 */
public class UserCashupMenu extends Region {

    private final List<String> userCashupMenusAllowed;

    public UserCashupMenu() {
        userCashupMenusAllowed = ReportUtilMenus.getUserCashupReportMenu(CurrentUser.getUser().getUserPin());
        getChildren().add(getMenuGroup());
    }

    private VBox getMenuGroup() {

        VBox vbCashupMenu = JKNode.getPageHeadVB("User Cashup Menu");

        List<Button> btnList = new ArrayList<>();

        for (String s : userCashupMenusAllowed) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 4, btnList);

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbCashupMenu, tile);

        return vb;
    }

    private void getMenuAction(Button b) {
        int n = SceneReports.getVbReportContent().getChildren().size();
        if (n > 2) {
            SceneReports.getVbReportContent().getChildren().remove(2, n);
        }

        switch (b.getText()) {
            case ReportUtilMenus.REP_BTN_USER_CASHUP_CURRENT:
                SceneReports.getVbReportContent().getChildren().add(2, new UserCashupEnd());
                break;
            case ReportUtilMenus.REP_BTN_USER_CASHUP_HISTORY:
                SceneReports.getVbReportContent().getChildren().add(2, new UserCashupHistory());
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Cashup Reports", "No Report Selected", null);
        }
    }
}
