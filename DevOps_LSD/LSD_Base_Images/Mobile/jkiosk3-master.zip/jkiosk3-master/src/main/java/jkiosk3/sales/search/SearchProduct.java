package jkiosk3.sales.search;

import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.electricity.ElectricityProvider;

import java.util.List;

/**
 * @author Val
 */
public class SearchProduct implements Comparable {

    private SearchTransType searchTransType;
    private int provId;
    private String provName;
    private int prodId;
    private String prodName;
    //    private ProviderType provType;
    private BPTransType bpTransType;
    private boolean verify;
    private boolean fullAmount;
    private int additionalFields;
    private double prodMaxAmount;
    private double prodMinAmount;
    private boolean enforceFullPayment;
    private List<String> tendersAllowed;
    private boolean reversalSupported;
    private ElectricityProvider electricityProvider;
    private String logoId;

    public SearchTransType getSearchTransType() {
        return searchTransType;
    }

    public void setSearchTransType(SearchTransType searchTransType) {
        this.searchTransType = searchTransType;
    }

    public int getProdId() {
        return prodId;
    }

    public void setProdId(int prodId) {
        this.prodId = prodId;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public int getProvId() {
        return provId;
    }

    public void setProvId(int provId) {
        this.provId = provId;
    }

    public String getProvName() {
        return provName;
    }

    public void setProvName(String provName) {
        this.provName = provName;
    }

    public BPTransType getBpTransType() {
        return bpTransType;
    }

    public void setBpTransType(BPTransType bpTransType) {
        this.bpTransType = bpTransType;
    }

    public int getAdditionalFields() {
        return additionalFields;
    }

    public void setAdditionalFields(int additionalFields) {
        this.additionalFields = additionalFields;
    }

    public boolean isFullAmount() {
        return fullAmount;
    }

    public void setFullAmount(boolean fullAmount) {
        this.fullAmount = fullAmount;
    }

    public boolean isVerify() {
        return verify;
    }

    public void setVerify(boolean verify) {
        this.verify = verify;
    }

    public double getProdMaxAmount() {
        return prodMaxAmount;
    }

    public void setProdMaxAmount(double prodMaxAmount) {
        this.prodMaxAmount = prodMaxAmount;
    }

    public double getProdMinAmount() {
        return prodMinAmount;
    }

    public void setProdMinAmount(double prodMinAmount) {
        this.prodMinAmount = prodMinAmount;
    }

    public boolean isEnforceFullPayment() {
        return enforceFullPayment;
    }

    public void setEnforceFullPayment(boolean enforceFullPayment) {
        this.enforceFullPayment = enforceFullPayment;
    }

    public List<String> getTendersAllowed() {
        return tendersAllowed;
    }

    public void setTendersAllowed(List<String> tendersAllowed) {
        this.tendersAllowed = tendersAllowed;
    }

    public boolean isReversalSupported() {
        return reversalSupported;
    }

    public void setReversalSupported(boolean reversalSupported) {
        this.reversalSupported = reversalSupported;
    }

    public ElectricityProvider getElectricityProvider() {
        return electricityProvider;
    }

    public void setElectricityProvider(ElectricityProvider electricityProvider) {
        this.electricityProvider = electricityProvider;
    }

    public String getLogoId() {
        return logoId;
    }

    public void setLogoId(String logoId) {
        this.logoId = logoId;
    }

    @Override
    public String toString() {
        return "SearchProduct [provId=" + provId + ", provName=" + provName + ", prodId=" + prodId + ", prodName="
                + prodName + ", bpTransType=" + bpTransType + ", verify=" + verify + ", fullAmount=" + fullAmount
                + ", additionalFields=" + additionalFields + ", prodMaxAmount=" + prodMaxAmount + ", prodMinAmount="
                + prodMinAmount + ", enforceFullPayment=" + enforceFullPayment + ", tendersAllowed=" + tendersAllowed
                + ", reversalSupported=" + reversalSupported + ", searchTransType=" + searchTransType + "]";
    }

    @Override
    public int compareTo(Object that) {
        if (that instanceof SearchProduct) {
            return this.getProdName().compareTo(((SearchProduct) that).getProdName());
        }
        return 0;
    }
}
