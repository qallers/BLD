package jkiosk3.sales._favourites.nfc;

import aeonusers.User;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfile;

public class NFCSubscriberCancel extends Region {

    private User nfcUser;
    private ConsumerProfile consumerProfile;

    public NFCSubscriberCancel(User nfcUser, ConsumerProfile consumerProfile) {
        this.nfcUser = nfcUser;
        this.consumerProfile = consumerProfile;

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(getCancelLayout(), getControlButtons());

        getChildren().add(vb);
    }

    private VBox getCancelLayout() {

        VBox nfcHead = JKNode.getNFCpgHead("Subscriber Cancellation");

        VBox vBox = JKLayout.getVBoxContent(JKLayout.sp);

        vBox.getChildren().addAll(nfcHead, getInput());

        return vBox;
    }

    private GridPane getInput() {

        Label lblCardNum = JKText.getLblDk("Card Number", JKText.FONT_B_20);

        Label lblSubName = JKText.getLblDk("Name", JKText.FONT_B_20);
        Label lblSubSurname = JKText.getLblDk("Surname", JKText.FONT_B_20);
        Label lblSubCellNum = JKText.getLblDk("Cellphone Number", JKText.FONT_B_20);

        Text txtCardNum = JKText.getTxtDk(consumerProfile.getLoyaltyCard(), JKText.FONT_B_24);

        Text txtSubName = JKText.getTxtDk(consumerProfile.getName(), JKText.FONT_B_20);
        Text txtSubSurname = JKText.getTxtDk(consumerProfile.getSurname(), JKText.FONT_B_20);
        Text txtSubCellNum = JKText.getTxtDk(consumerProfile.getMobile(), JKText.FONT_B_20);

        GridPane gridPane = JKLayout.getContentGridInner2Col(0.50, 0.50);

        gridPane.addRow(1, lblCardNum, txtCardNum);
        gridPane.addRow(2, lblSubName, txtSubName);
        gridPane.addRow(3, lblSubSurname, txtSubSurname);
        gridPane.addRow(4, lblSubCellNum, txtSubCellNum);

        return gridPane;
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons();

        ctrlBtns.getBtnAccept().setText("Confirm Cancellation");
        ctrlBtns.getBtnAccept().getStyleClass().add("btnNFC");
        ctrlBtns.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getMsgBox().showMsgBox("Subscriber Cancel", "\nAre you SURE that you want to cancel this Subscriber?\n",
                        null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL,
                        new MessageBoxResult() {
                            @Override
                            public void onOk() {
                                deleteSubscriber();
                            }

                            @Override
                            public void onCancel() {
                                NFCUtil.resetNFCView();
                            }
                        });
            }
        });
        ctrlBtns.getBtnCancel().getStyleClass().add("btnNFC");
        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                NFCUtil.resetNFCView();
            }
        });

        return ctrlBtns;
    }

    private void deleteSubscriber() {
        NFCUtil.deleteConsumerProfile(nfcUser, consumerProfile.getProfileId(), new NFCUtil.ConsumerProfileDeleteResult() {
            @Override
            public void consumerProfileDeleteResult(Boolean consumerProfileDeleted) {
                if (consumerProfileDeleted) {
                    JKiosk3.getMsgBox().showMsgBox("Subscriber Cancel", "Successfully Cancelled Subscriber", null);
                    NFCUtil.resetNFCView();
                } else {
                    NFCUtil.resetNFCView();
                }
            }
        });
    }
}
