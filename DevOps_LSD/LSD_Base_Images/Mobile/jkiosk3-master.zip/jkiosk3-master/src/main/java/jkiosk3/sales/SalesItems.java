package jkiosk3.sales;

import aeonusers.UserTransactionType;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.topups.TopupProvider;

public class SalesItems {

    private final static Logger logger = Logger.getLogger(SalesItems.class.getName());
    // lists for transaction types
    private static List<UserTransactionType> userTransTypes;
    private static List<String> listUserTransAllowed;
    private static List<ElectricityProvider> listElecSuppliers;
    private static List<TopupProvider> listTopupProvidersAirtime;
    private static List<TopupProvider> listTopupProvidersBundles;
    private static List<TopupProvider> listTopupProvidersOther;

    public static void setupTransTypeList(List<UserTransactionType> loggedInUserTransTypes) {
        /* Don't use Cached list for this.  Use list passed in from User Login, 
         so that the most current Allowed Transaction Types are used. */
        SalesItems.userTransTypes = loggedInUserTransTypes;
        makeTransactionLists();
        logTransTypesAvailable();
    }

    private static void makeTransactionLists() {
        listUserTransAllowed = new ArrayList<>();
        listElecSuppliers = new ArrayList<>();
        listTopupProvidersAirtime = new ArrayList<>();
        listTopupProvidersBundles = new ArrayList<>();
        listTopupProvidersOther = new ArrayList<>();
        for (UserTransactionType utt : userTransTypes) {
            listUserTransAllowed.add(utt.getTransactionType());
            if (utt.getGroup().equalsIgnoreCase("XML Interface")) {
                if (utt.getType() != null) {
                    if (utt.getType().equalsIgnoreCase("Electricity")) {
                        ElectricityProvider ep = new ElectricityProvider();
                        ep.setTransactionType(utt.getTransactionType());
                        ep.setType(utt.getType());
                        ep.setDisplayName(utt.getDisplayName());
                        listElecSuppliers.add(ep);
                    }
                    if (utt.getType().equalsIgnoreCase("Topup") && (!utt.getTransactionType().contains("Bundles"))) {
                        TopupProvider topAir = new TopupProvider(utt.getTransactionType(), utt.getDisplayName(), 0, utt.isRechargePlus());
                        listTopupProvidersAirtime.add(topAir);
                    }
                    if (utt.getType().equalsIgnoreCase("Bundles") && (utt.getTransactionType().contains("Bundles"))) {
                        TopupProvider topBundle = new TopupProvider(utt.getTransactionType(), utt.getDisplayName(), 0, utt.isRechargePlus());
                        listTopupProvidersBundles.add(topBundle);
                    }
                    if (utt.getType().equalsIgnoreCase("Bundles") && (!utt.getTransactionType().contains("Bundles"))) {
                        // 2019-03-18  -  this should give us a list of 1  -  Lucky365
                        TopupProvider topBundle = new TopupProvider(utt.getTransactionType(), utt.getDisplayName(), 0, utt.isRechargePlus());
                        listTopupProvidersOther.add(topBundle);
                    }
                }
            }
        }
    }

    private static void logTransTypesAvailable() {
        StringBuilder sb = new StringBuilder();
        sb.append("\r\n").append("  > > > Electricity Providers : ");
        for (ElectricityProvider e : listElecSuppliers) {
            sb.append("\r\n  -  ").append(e.getTransactionType());
        }
        sb.append("\r\n").append(" ---------------------------------");
        sb.append("\r\n").append("  > > > Topup Providers Airtime : ");
        for (TopupProvider p : listTopupProvidersAirtime) {
            sb.append("\r\n  -  ").append(p.getName());
        }
        sb.append("\r\n").append(" ---------------------------------");
        sb.append("\r\n").append("  > > > Topup Providers Bundles : ");
        for (TopupProvider p : listTopupProvidersBundles) {
            sb.append("\r\n  -  ").append(p.getName());
        }
        sb.append("\r\n").append(" ---------------------------------");
        for (TopupProvider p : listTopupProvidersOther) {
            sb.append("\r\n  -  ").append(p.getName());
        }
        sb.append("\r\n").append(" ---------------------------------");
        sb.append("\r\n");
        logger.info(sb.toString());
    }

    public static List<String> getListUserTransAllowed() {
        makeTransactionLists();
        return listUserTransAllowed;
    }

    public static List<ElectricityProvider> getElecSuppliers() {
        makeTransactionLists();
        return listElecSuppliers;
    }

    public static List<TopupProvider> getListTopupProvidersAirtime() {
        makeTransactionLists();
//        addTestProvider();
        return listTopupProvidersAirtime;
    }

    public static List<TopupProvider> getListTopupProvidersBundles() {
        /* Will always get THIS list when creating or updating Product Cache.
         * Needed for looping through Topup Providers for Bundle Products.
         */
        makeTransactionLists();
        return listTopupProvidersBundles;
    }

    public static List<TopupProvider> getListTopupProvidersOther() {
        makeTransactionLists();
//        addTestProvider();
        return listTopupProvidersOther;
    }

    private static void addTestProvider() {
        TopupProvider topAirTest = new TopupProvider("Connect", "Connect", 0, true);
        listTopupProvidersAirtime.add(topAirTest);
//        TopupProvider topOtherTest = new TopupProvider("DiskiMillions", "DiskiMillions", 0, true);
//        listTopupProvidersOther.add(topOtherTest);
    }
}
