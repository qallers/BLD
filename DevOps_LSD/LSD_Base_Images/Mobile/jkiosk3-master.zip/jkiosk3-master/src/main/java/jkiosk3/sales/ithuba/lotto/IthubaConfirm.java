package jkiosk3.sales.ithuba.lotto;

import aeonithuba.IthubaConfirmRes;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3.sales.ithuba.LottoUtil;

/**
 *
 * @author valeriew
 */
public class IthubaConfirm extends Region {
    
    private final IthubaConfirmRes ithubaConfirm;
    private final String gametype;
    private final String gametypePlus1;
    private final String gametypePlus2;

    public IthubaConfirm(IthubaConfirmRes ithubaConfirm, String gametype, String gametypePlus1, String gametypePlus2) {

        this.ithubaConfirm = ithubaConfirm;
        this.gametype = gametype;
        this.gametypePlus1 = gametypePlus1;
        this.gametypePlus2 = gametypePlus2;

        VBox vbConfirm = JKLayout.getVBox(0, 0);
        vbConfirm.setPrefWidth(MessageBox.getMsgWidth() - (2 * JKLayout.sp));
        vbConfirm.setAlignment(Pos.TOP_CENTER);
        vbConfirm.getChildren().add(getSummaryGrid());

        getChildren().add(vbConfirm);
    }

    private GridPane getSummaryGrid() {

        Label lblConfirm = JKText.getLblDk("Please confirm all details before continuing."
                + "\nClicking on 'OK' button will buy ticket.", JKText.FONT_B_XSM);
        lblConfirm.setTextAlignment(TextAlignment.CENTER);
        GridPane.setHalignment(lblConfirm, HPos.CENTER);

        Label lblNoReverse = JKText.getLblDk("THIS CANNOT BE REVERSED", JKText.FONT_B_SM);
        lblNoReverse.setTextAlignment(TextAlignment.CENTER);
        GridPane.setHalignment(lblNoReverse, HPos.CENTER);

        Label lblBoards = JKText.getLblDk("Number of Boards", JKText.FONT_B_XSM);
        Label lblDraws = JKText.getLblDk("Number of Draws", JKText.FONT_B_XSM);
        Label lblPlus = JKText.getLblDk(gametype + " Plus?", JKText.FONT_B_XSM);
        Label lblPlus1 = JKText.getLblDk(gametype + " Plus 1?", JKText.FONT_B_XSM);
        Label lblPlus2 = JKText.getLblDk(gametype + " Plus 2?", JKText.FONT_B_XSM);
        Label lblCost = JKText.getLblDk("Cost", JKText.FONT_B_XSM);

        // filled-in fields
        Text txtBoards = JKText.getTxtDk(Integer.toString(ithubaConfirm.getNumBoards()), JKText.FONT_B_XSM);

        Text txtDraws = JKText.getTxtDk(Integer.toString(ithubaConfirm.getNumDraws()), JKText.FONT_B_XSM);

        Text txtPlus = JKText.getTxtDk(gametypePlus1, JKText.FONT_B_XSM);
        Text txtPlus2 = JKText.getTxtDk(gametypePlus2, JKText.FONT_B_XSM);
        Text txtCost = JKText.getTxtDk("R " + JKText.getDeciFormat((double) ithubaConfirm.getAmt() / 100), JKText.FONT_B_SM);

        GridPane grid = JKLayout.getGridSummary2ColVariWidth(0.65, 0.35, 450);
        grid.setTranslateX(-JKLayout.sp);

        grid.add(lblConfirm, 0, 0, 2, 1);
        grid.add(lblNoReverse, 0, 1, 2, 1);
        grid.add(JKNode.createGridSpanSep(2), 0, 2);
        grid.addRow(3, lblBoards, txtBoards);
        grid.addRow(4, lblDraws, txtDraws);
        switch (gametype) {
            case LottoUtil.GAMETYPE_LOTTO_QUICK:
            case LottoUtil.GAMETYPE_LOTTO_SELECT:
                grid.addRow(5, lblPlus1, txtPlus);
                grid.addRow(6, lblPlus2, txtPlus2);
                /* Blank GridRow to leave breathing-space before displaying cost */
                grid.addRow(8, lblCost, txtCost);
                break;
            case LottoUtil.GAMETYPE_PBALL_QUICK:
            case LottoUtil.GAMETYPE_PBALL_SELECT:
//                grid.addRow(4, lblDraws, txtDraws);
                grid.addRow(5, lblPlus, txtPlus);
                /* Blank GridRow to leave breathing-space before displaying cost */
                grid.addRow(7, lblCost, txtCost);
                break;
            default:
                break;
        }
//        grid.addRow(5, lblPlus, txtPlus);
        /* Blank GridRow to leave breathing-space before displaying cost */
//        grid.addRow(7, lblCost, txtCost);

        return grid;
    }    
}
