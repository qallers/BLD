package jkiosk3.sales.coaches;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.*;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.coaches.cancel.CancelTicketMenu;
import jkiosk3.store.*;
import jkiosk3.users.CurrentUser;

import java.util.Locale;

public class CancelCoachTicket extends Region {

    private TextField txtBookingRef;
    private ControlSearchAndCancel ctrlBtns;
    private static final long EXIRY_LIMIT = 30 * 60 * 1000;   //thirty minutes

    public CancelCoachTicket() {
        CurrentUser.setSalesUser(CurrentUser.getUser());
        VBox vbReprint = JKLayout.getVBox(0, JKLayout.spNum);
        vbReprint.getChildren().add(getCancelCoachEntry());
        ctrlBtns = new ControlSearchAndCancel();
        ctrlBtns.getBtnSearch().setDisable(true);
        vbReprint.getChildren().add(getControlButtons());
        getChildren().add(vbReprint);
    }

    private GridPane getCancelCoachEntry() {
        Label lblTransaction = JKText.getLblContentHead("Cancel Coach Transaction");

        Label lblReference = JKText.getLblDk("Enter Transaction ID or Trx Ref", JKText.FONT_B_XXSM);

        txtBookingRef = new TextField();
        txtBookingRef.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtBookingRef, "Enter Transaction ID or Trx Ref", "",
                            false, false, new KeyboardResult() {
                                @Override
                                public void onDone(String value) {
                                    txtBookingRef.setText(value.toUpperCase(Locale.ENGLISH));
                                    ctrlBtns.getBtnSearch().setDisable(value.isEmpty() ? true : false);
                                }
                            });
                }
            }
        });

        GridPane grid = JKLayout.getGridContent2Col(0.5, 0.5);

        grid.add(lblTransaction, 0, 0, 2, 1);
        grid.add(JKNode.createGridSpanSep(2), 0, 1);

        grid.addRow(3, lblReference, txtBookingRef);

        return grid;
    }

    private ControlSearchAndCancel getControlButtons() {

        ctrlBtns.getBtnSearch().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                if (txtBookingRef.getText() != null) {
                    JKCancelTicket.loadCancelList();
                    StoreJKCancelTicket storeJKCancelTicket = JKCancelTicket.searchForCancelTicket(txtBookingRef.getText().toLowerCase());

                    if (storeJKCancelTicket != null && isAddScheduler(storeJKCancelTicket)) {
                        SceneSales.clearAndChangeContent(new CancelTicketMenu(storeJKCancelTicket));
                    } else {
                        JKiosk3.getMsgBox().showMsgBox(String.format("Transaction %s not found", txtBookingRef.getText()), "Please contact Support to cancel this transaction", null);
                    }


                }
            }
        });

        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndShowFavourites();
            }
        });

        return ctrlBtns;
    }

    private boolean isAddScheduler(StoreJKCancelTicket storeJKCancelTicket) {
        long timeSale = storeJKCancelTicket.getTransactionDate().getTime();
        long timeList = System.currentTimeMillis();

        return (timeList - timeSale) > EXIRY_LIMIT ? false : true;
    }
}
