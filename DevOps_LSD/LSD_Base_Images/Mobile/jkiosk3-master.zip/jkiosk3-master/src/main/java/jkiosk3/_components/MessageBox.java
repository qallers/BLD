package jkiosk3._components;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.TextAlignment;
import jkiosk3.StageJKiosk;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;

/**
 *
 * @author Val
 */
public class MessageBox extends Region {

    private final static double msgWidth = 650;
    private Rectangle rec;
    private Label lblHead;
    private Label lblContent;
    private Button btnOK;
    private Button btnCancel;
    private HBox hbBtns;
    private VBox vboxContent;
    private StackPane paneContent;
    private Group grpContent;
    private Separator sep;
    private MessageBoxResult result;
    public final static byte MSG_OK = 1;
    public final static byte MSG_OK_CANCEL = 2;
    public final static byte MSG_CANCEL = 3;
    public final static byte MSG_YES_NO = 4;
    public final static byte CONTROLS_SHOW = 1;
    public final static byte CONTROLS_HIDE = 2;

    public MessageBox() {
        getChildren().add(getMsgBoxStack());
    }

    private StackPane getMsgBoxStack() {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getMsgBoxGrp());

        return stack;
    }

    private Group getMsgBoxGrp() {
        grpContent = new Group();

        rec = new Rectangle();
//        rec.setWidth(msgWidth);

        vboxContent = JKLayout.getVBox(JKLayout.sp, (JKLayout.sp / 2));
//        vboxContent.setPrefWidth(msgWidth);

        lblHead = JKText.getLblDk("A Message Box", JKText.FONT_B_SM);
//        lblHead.setMaxWidth(msgWidth - (2 * JKLayout.sp));
        lblHead.setAlignment(Pos.CENTER);
        lblHead.setTextAlignment(TextAlignment.CENTER);
        lblHead.setWrapText(true);

        lblContent = JKText.getLblDk("Put a message in here", JKText.FONT_B_XSM);
//        lblContent.setMaxWidth(msgWidth - (2 * JKLayout.sp));
        lblContent.setAlignment(Pos.CENTER);
        lblContent.setTextAlignment(TextAlignment.CENTER);
        lblContent.setWrapText(true);

        paneContent = new StackPane();
//        paneContent.setMaxWidth(msgWidth - (2 * JKLayout.sp));
//        paneContent.setMinWidth(msgWidth - (2 * JKLayout.sp));
        paneContent.setPadding(new Insets(JKLayout.sp));

        btnOK = JKNode.getBtnMsgBox("OK");
        btnOK.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onOkBtnEvent();
            }
        });

        btnCancel = JKNode.getBtnMsgBox("Cancel");
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onCancelBtnEvent();
            }
        });

        hbBtns = JKLayout.getHBox(0, (2 * JKLayout.sp));
//        hbBtns.setMaxWidth(msgWidth - (2 * JKLayout.sp));
//        hbBtns.setMinWidth(msgWidth - (2 * JKLayout.sp));
        hbBtns.getChildren().addAll(btnOK, btnCancel);

        vboxContent.getChildren().addAll(lblHead, getSep(),
                lblContent, paneContent, getSep(), hbBtns);

        rec.heightProperty().bind(vboxContent.heightProperty());

        grpContent.getChildren().addAll(rec, vboxContent);
//        double grpOffset = (StageJKiosk.getSceneWidth() / 2) - (msgWidth / 2);
//        StackPane.setAlignment(grpContent, Pos.CENTER_LEFT);
//        grpContent.setTranslateX(grpOffset);

        return grpContent;
    }

    private Separator getSep() {
        sep = new Separator();
//        sep.setMaxWidth(msgWidth - (2 * JKLayout.sp));
//        sep.setMinWidth(msgWidth - (2 * JKLayout.sp));
        return sep;
    }
    
    private void setMsgBoxWidth(double msgW) {
        rec.setWidth(msgW);
        lblHead.setMaxWidth(msgW - (2 * JKLayout.sp));
        lblContent.setMaxWidth(msgW - (2 * JKLayout.sp));
        vboxContent.setPrefWidth(msgW);
        paneContent.setMaxWidth(msgW - (2 * JKLayout.sp));
        paneContent.setMinWidth(msgW - (2 * JKLayout.sp));
        hbBtns.setMaxWidth(msgW - (2 * JKLayout.sp));
        hbBtns.setMinWidth(msgW - (2 * JKLayout.sp));
        sep.setMaxWidth(msgW - (2 * JKLayout.sp));
        sep.setMinWidth(msgW - (2 * JKLayout.sp));
        double grpOffset = (StageJKiosk.getSceneWidth() / 2) - (msgW / 2);
        StackPane.setAlignment(grpContent, Pos.CENTER_LEFT);
        grpContent.setTranslateX(grpOffset);
    }

    private void onOkBtnEvent() {
        clearContents();
        setVisible(false);
        toBack();
        if (result != null) {
            result.onOk();
        }
    }

    private void onCancelBtnEvent() {
        clearContents();
        setVisible(false);
        toBack();
        if (result != null) {
            result.onCancel();
        }
    }

    private void clearContents() {
        lblHead.setText("");
        lblContent.setText("");
        paneContent.getChildren().clear();
    }

    public void hideMsgBox() {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                clearContents();
                setVisible(false);
                toBack();
            }
        });
    }

    public Button showMsgBox(String head, String content, Node node) {
        return showMsgBox(head, content, node, CONTROLS_SHOW, MSG_OK, null);
    }

//    public void showMsgBox(String head, String content, Node node, byte showControls) {
//        showMsgBox(head, content, node, showControls, MSG_OK, null);
//    }
    public Button showMsgBox(String head, String content, Node node, byte showControls, byte msgType, MessageBoxResult res) {
//        vboxContent.setPrefWidth(width);
//        hbBtns.setPrefWidth(width);
//        hbBtns.setStyle("-fx-background-color: pink;");
        return showMsgBox(head, content, node, msgWidth, showControls, msgType, res);
    }

    public Button showMsgBox(String head, String content, Node node, double width, byte showControls, byte msgType, MessageBoxResult res) {
        setMsgBoxWidth(width);
        // colour the panels to show spacing - for testing only
//        if (width != msgWidth) {
//            paneContent.setStyle("-fx-background-color: lightpink;");
//            hbBtns.setStyle("-fx-background-color: lightpink;");
//        } else {
//            paneContent.setStyle("-fx-background-color: lightgreen;");
//            hbBtns.setStyle("-fx-background-color: lightgreen;");
//        }
        
        lblHead.setText(head);
        lblContent.setText(content);
        this.result = res;

        hbBtns.getChildren().clear();
        switch (msgType) {
            case MSG_OK:
                btnOK.setText("OK");
                hbBtns.getChildren().add(btnOK);
                break;
            case MSG_OK_CANCEL:
                btnOK.setText("OK");
                btnCancel.setText("Cancel");
                hbBtns.getChildren().addAll(btnOK, btnCancel);
                break;
            case MSG_CANCEL:
                btnCancel.setText("Cancel");
                hbBtns.getChildren().addAll(btnCancel);
                break;
            case MSG_YES_NO:
                btnOK.setText("Yes");
                btnCancel.setText("No");
                hbBtns.getChildren().addAll(btnOK, btnCancel);
                break;
            default:
                hbBtns.getChildren().add(btnOK);
        }

        vboxContent.getChildren().clear();
        switch (showControls) {
            case CONTROLS_SHOW:
                vboxContent.getChildren().addAll(lblHead, new Separator(),
                        lblContent, paneContent, new Separator(), hbBtns);
                break;
            case CONTROLS_HIDE:
                vboxContent.getChildren().addAll(lblHead, new Separator(),
                        lblContent, paneContent, new Separator());
                break;
            default:
                vboxContent.getChildren().addAll(lblHead, new Separator(),
                        lblContent, null, new Separator(), hbBtns);
        }

        if (node != null) {
            paneContent.getChildren().clear();
            paneContent.getChildren().add(node);
        } else {
            paneContent.getChildren().clear();
        }

        this.setVisible(true);
        this.toFront();

        return btnOK;
    }

    public static double getMsgWidth() {
        return msgWidth;
    }

    public Button getBtnCancel() {
        return btnCancel;
    }

    public Button getBtnOK() {
        return btnOK;
    }
}
