package jkiosk3._components;

/**
 *
 * @author Val
 */
public abstract class MessageBoxResult {

    public abstract void onOk();

    public abstract void onCancel();
}
