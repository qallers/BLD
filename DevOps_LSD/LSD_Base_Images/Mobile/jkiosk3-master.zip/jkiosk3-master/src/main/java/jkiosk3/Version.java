package jkiosk3;

public class Version {

    private final static String versionNum = "3.21.05.10";          // 10 May 2021
    private final static String version;
    private final static String softwareVersion;
//    private static String rssUrl;

    static {
        // 'MONTH' must be one less than actual month number, eg April = 03 i.e. (4-1) in second parameter
        // keep time on "00" to ensure that this is less than news item dates   -   this variable is used for NEWS
//        versionDate.set(2016, (12 - 1), 19, 00, 00, 00);          // year, month, day, hour, min, seconds
        version = "JKiosk - version " + versionNum;
        softwareVersion = "JK-3.";
//            rssUrl = "http://196.38.158.102/AEON/RSS/rss.ashx?AspxAutoDetectCookieSupport=1";
//            rssUrl = "http://10.22.7.15/AEON/AEON_QA/RSS/rss.ashx?AspxAutoDetectCookieSupport=1";
    }

    public static String getVersion() {
        return version;
    }

    public static String getVersionNum() {
        return versionNum;
    }

    public static String getSoftwareVersion() {
        return softwareVersion;
    }

//    public static String getRssUrl() {
//        return rssUrl;
//    }
}
