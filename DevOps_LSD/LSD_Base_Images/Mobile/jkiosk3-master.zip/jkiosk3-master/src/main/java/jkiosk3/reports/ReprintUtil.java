package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.ReprintConnection;
import aeonreports.ReprintList;
import aeonreports.UnprintedItem;
import aeonreports.UnprintedList;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.concurrent.Task;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.TaskUtil;

/**
 *
 * @author Val
 */
public class ReprintUtil {

    private final static Logger LOG = Logger.getLogger(ReprintUtil.class.getName());
    private final static String userPin = CurrentUser.getUser().getUserPin();
    private final static int deviceId = JKSystem.getSystemConfig().getDeviceId();
    private final static String serial = JKSystem.getSystemConfig().getSerial();
    private static ReprintConnection reprintConnect;
    //
    public static final String REPRINT_VOUCHER = "reprintVoucher";
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 60;

    /**
     * Private Constructor to hide implicit public one.
     */
    private ReprintUtil() {
    }

    private static ReprintConnection getReprintConnect() {
        ReprintConnection reprintConn = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        try {
            reprintConn = new ReprintConnection(server, port, secureConnect);
            reprintConn.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            LOG.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            LOG.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            LOG.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            LOG.log(Level.SEVERE, e.getMessage(), e);
        }
        return reprintConn;
    }

    private static boolean isLoggedInReprint() throws RuntimeException {
        boolean loggedInReprint = false;

        reprintConnect = getReprintConnect();

        try {
            if (reprintConnect != null) {
                loggedInReprint = reprintConnect.login(userPin, deviceId, serial);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }

        return loggedInReprint;
    }

    private static AeonPrintJob getUnprintedVoucher() throws RuntimeException {
        AeonPrintJob apj = new AeonPrintJob();
        try {
            if (isLoggedInReprint()) {
                apj = reprintConnect.getUnprintedReprint();
                if (reprintConnect.setUnprintedSold()) {
                    reprintConnect.disconnect();
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Unprinted Voucher Error", t);
        } finally {
            if (reprintConnect != null) {
                reprintConnect.disconnect();
            }
        }
        return apj;
    }

    private static ReprintList getReprintListByDate(long dateFrom, long dateTo) throws RuntimeException {
        ReprintList reprintList = new ReprintList();
        try {
            if (isLoggedInReprint()) {
                reprintList = reprintConnect.getReprintListByDate(dateFrom, dateTo);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Reprint List Error", t);
        } finally {
            if (reprintConnect != null) {
                reprintConnect.disconnect();
            }
        }

        return reprintList;
    }

    private static AeonPrintJob getReprintSelected(String transRef) throws RuntimeException {
        AeonPrintJob reprintSelected = new AeonPrintJob();
        boolean userReprint = JKPrintOptions.getPrintOptions().isHideReprintPin();
        int ur = userReprint ? 1 : 0;
        try {
            if (isLoggedInReprint()) {
                /* Second input parameter is <userReprint> - 0 = false, 1 = true*/
                reprintSelected = reprintConnect.getReprint(transRef, ur);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Reprint Error", t);
        } finally {
            if (reprintConnect != null) {
                reprintConnect.disconnect();
            }
        }

        return reprintSelected;
    }

    private static UnprintedList getUnprintedList() throws RuntimeException {
        UnprintedList unprinted = new UnprintedList();
        try {
            if (isLoggedInReprint()) {
                unprinted = reprintConnect.getUnprintedList();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Unprinted List Error", t);
        } finally {
            if (reprintConnect != null) {
                reprintConnect.disconnect();
            }
        }

        return unprinted;
    }
    
    private static UnprintedItem getUnprintedItem(String transRef) throws RuntimeException {
        UnprintedItem unprintedItem = new UnprintedItem();
        try {
            if (isLoggedInReprint()) {
                unprintedItem = reprintConnect.getUnprintedTrxByTrxId(transRef);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Unprinted Item Error", t);
        } finally {
            if (reprintConnect != null) {
                reprintConnect.disconnect();
            }
        }
        return unprintedItem;
    }
//
//    private static ReprintList getReprintVoucherList() {
//        ReprintList reprintList = new ReprintList();
//
//        try {
//            if (isLoggedInReprint()) {
//                reprintList = reprintConnect.getReprintList();
//                reprintConnect.disconnect();
//            }
//        } catch (Exception e) {
//            JKiosk3.getMsgBox().showMsgBox("Reprint List", "Reprint List Error\n\n" + e.getMessage(), null);
//        }
//
//        return reprintList;
//    }
//
    /*
     * JKiosk3 stores Reprint items on the local machine.  No server connections are made 
     * to retrieve a Reprint.
     * Keep this method in case this functionality changes in the future.
     */
//    private static AeonPrintJob getPrintReport(String type, int accId, int ref) {
//        AeonPrintJob apj = new AeonPrintJob();
//
//        try {
//            if (isLoggedInReprint()) {
//                if (type.equals(REPRINT_VOUCHER)) {
//                    apj = reprintConnect.getReprint(ref);
//                }
//                reprintConnect.disconnect();
//            }
//        } catch (Exception e) {
//            JKiosk3.getMsgBox().showMsgBox("Reprint List", "Reprint List Error\n\n" + e.getMessage(), null);
//        }
//        return apj;
//    }
//
    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
//    public static void getReprintVoucherList(final ReprintListResult result) {
//        JKiosk3.getBusy().showBusy("");
//
//        final Task<ReprintList> task = new Task() {
//            @Override
//            protected ReprintList call() throws Exception {
//                return getReprintVoucherList();
//            }
//        };
//
//        task.stateProperty().addListener(new ChangeListener<Worker.State>() {
//            @Override
//            public void changed(ObservableValue<? extends Worker.State> observable,
//                    Worker.State oldValue, Worker.State newState) {
//                if (newState == Worker.State.SUCCEEDED) {
//                    Platform.runLater(new Runnable() {
//                        @Override
//                        public void run() {
//                            JKiosk3.getBusy().hideBusy();
//                            result.reprintListResult(task.getValue());
//                        }
//                    });
//                }
//            }
//        });
//        new Thread(task).start();
//    }
//

    public static void getUnprintedVoucher(final AeonPrintJobResult result) {
        JKiosk3.getBusy().showBusy("Checking for Unprinted Vouchers");

        final Task<AeonPrintJob> taskUnprinted = new Task() {
            @Override
            protected AeonPrintJob call() throws Exception {
                return getUnprintedVoucher();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.aeonPrintJobResult((AeonPrintJob) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Unprinted Voucher Error",
                        "Error Retrieving Unprinted Voucher", State.CANCELLED, errorMsg, new JKioskLogin());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Unprinted Voucher Error",
                        "Error Retrieving Unprinted Voucher", State.FAILED, errorMsg, new JKioskLogin());
            }
        };

        new Thread(taskUnprinted).start();
        JKiosk3.getBusy().startCountdown(taskUnprinted, countdownTime);
    }

    public static void getReprintListByDate(final long dateFrom, final long dateTo, final ReprintListResult result) {
        JKiosk3.getBusy().showBusy("Getting Reprint List");

        Task<ReprintList> taskReprintByDate = new Task<ReprintList>() {

            @Override
            protected ReprintList call() throws Exception {
                return getReprintListByDate(dateFrom, dateTo);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.reprintListResult((ReprintList) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Reprint List Error",
                        "Error Retrieving Reprint List", State.CANCELLED, errorMsg, new JKioskLogin());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Reprint List Error",
                        "Error Retrieving Reprint List", State.FAILED, errorMsg, new JKioskLogin());
            }
        };
        new Thread(taskReprintByDate).start();
        JKiosk3.getBusy().startCountdown(taskReprintByDate, countdownTime);
    }

    public static void getReprintSelected(final String transRef, final AeonPrintJobResult result) {
        JKiosk3.getBusy().showBusy("Getting Selected Reprint");

        Task<AeonPrintJob> taskReprintSelected = new Task<AeonPrintJob>() {

            @Override
            protected AeonPrintJob call() throws Exception {
                return getReprintSelected(transRef);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.aeonPrintJobResult((AeonPrintJob) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Reprint Error",
                        "Error Retrieving Selected Reprint", State.CANCELLED, errorMsg, new JKioskLogin());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Reprint Error",
                        "Error Retrieving Selected Reprint", State.FAILED, errorMsg, new JKioskLogin());
            }
        };
        new Thread(taskReprintSelected).start();
        JKiosk3.getBusy().startCountdown(taskReprintSelected, countdownTime);
    }

    public static void getUnprintedList(final UnprintedListResult result) {
        JKiosk3.getBusy().showBusy("Checking for Unprinted Transactions");
        Task<UnprintedList> taskUnprintedList = new Task<UnprintedList>() {
            @Override
            protected UnprintedList call() throws Exception {
                return getUnprintedList();
            }
            
            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.unprintedListResult((UnprintedList) getValue());
            }
            
            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Unprinted List Error", 
                        "Error Retrieving List of Unprinted Items", State.CANCELLED, errorMsg, new JKioskLogin());
            }
            
            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Unprinted List Error", 
                        "Error Retrieving List of Unprinted Items", State.FAILED, errorMsg, new JKioskLogin());
            }
        };
        new Thread(taskUnprintedList).start();
        JKiosk3.getBusy().startCountdown(taskUnprintedList, countdownTime);
    }
    
    public static void getUnprintedItem(final String transRef, final UnprintedItemResult result) {
        JKiosk3.getBusy().showBusy("Getting Unprinted Transaction Details");
        Task<UnprintedItem> taskUnprintedItem = new Task<UnprintedItem>() {
            @Override
            protected UnprintedItem call() throws Exception {
                return getUnprintedItem(transRef);
            }
            
            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.unprintedItemResult((UnprintedItem) getValue());
            }
            
            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Unprinted Item Error", 
                        "Error Retrieving Unprinted Item", State.CANCELLED, errorMsg, new JKioskLogin());
            }
            
            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Unprinted Item Error", 
                        "Error Retrieving Unprinted Item", State.CANCELLED, errorMsg, new JKioskLogin());
            }
        };
        new Thread(taskUnprintedItem).start();
        JKiosk3.getBusy().startCountdown(taskUnprintedItem, countdownTime);
    }

    public abstract static class ReprintListResult {

        public abstract void reprintListResult(ReprintList reprintList);
    }

    public abstract static class AeonPrintJobResult {

        public abstract void aeonPrintJobResult(AeonPrintJob aeonPrintJob);
    }

    public abstract static class UnprintedListResult {

        public abstract void unprintedListResult(UnprintedList unprintedList);
    }
    
    public abstract static class UnprintedItemResult {
        public abstract void unprintedItemResult(UnprintedItem unprintedItem);
    }
}
