package jkiosk3.sales.topups.bundles;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.topups.AirtimeUtil;
import jkiosk3.sales.topups.MenuTopups;
import jkiosk3.sales.topups.TopupProvider;
import jkiosk3.sales.topups.TopupSale;

import java.util.ArrayList;
import java.util.List;

public class BundleProvidersDataOrSMS extends Region {

    private SaleType saleTypeSelected;
    private List<TopupProvider> listTopupProviders;

    public BundleProvidersDataOrSMS() {
        this.saleTypeSelected = TopupSale.getInstance().getSaleType();
        System.out.println("\n\n " + saleTypeSelected );
        AirtimeUtil.getListTopupProvidersToShow(saleTypeSelected, new AirtimeUtil.TopupBundleProviderListResult() {
            @Override
            public void topupBundleProviderListResult(List<TopupProvider> providerList) {
                if (!providerList.isEmpty()) {
                    listTopupProviders = providerList;
                    getChildren().add(getBundleProviderButtons());
                }
            }
        });
    }

    public BundleProvidersDataOrSMS(SaleType saleTypeSelected, List<TopupProvider> listTopupProviders) {
        this.saleTypeSelected = saleTypeSelected;
        // this.listTopupProviders = AirtimeUtil.getListTopupProvidersToShow(saleTypeSelected);
        this.listTopupProviders = listTopupProviders;

/*        AirtimeUtil.getListTopupProvidersToShow(saleTypeSelected, new AirtimeUtil.TopupBundleProviderListResult() {
            @Override
            public void topupBundleProviderListResult(List<TopupProvider> providerList) {
                if (!providerList.isEmpty()) {
                    listTopupProviders = providerList;
                    // getChildren().add(getBundleProviderButtons());
                }
            }
        });*/

        System.out.println(listTopupProviders);

        for (final TopupProvider p : listTopupProviders) {
            final String provStyle = AirtimeUtil.getProviderStyleName(p);

            final Button btn = JKNode.getBtnSm("");
            ImageView imgView = JKNode.getJKImageViewProvider("prov_" + provStyle + ".png");

            btn.setGraphic(imgView);
            btn.getStyleClass().add("prov_" + provStyle + "_fix");

            TopupSale.getInstance().setProviderStyleName(provStyle);
            TopupSale.getInstance().setProvider(p);

            System.out.println(p);
        }
            /*btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    TopupSale.getInstance().setProviderStyleName(provStyle);
                    TopupSale.getInstance().setProvider(p);

                    System.out.println(TopupSale.getInstance().getProviderStyleName() + "-------- control");
                    System.out.println(TopupSale.getInstance().getProvider() + "-------- control");

                    showBundleCategories();
                }
            });*/

        showBundleCategories();
    }

/*    public BundleProvidersDataOrSMS(SaleType saleTypeSelected) {
        this.saleTypeSelected = TopupSale.getInstance().getSaleType();
        this.saleTypeSelected = saleTypeSelected;
        AirtimeUtil.getListTopupProvidersToShow(saleTypeSelected, new AirtimeUtil.TopupBundleProviderListResult() {
            @Override
            public void topupBundleProviderListResult(List<TopupProvider> providerList) {
                if (!providerList.isEmpty()) {
                    listTopupProviders = providerList;
                    getChildren().add(getBundleProviderButtons());
                }
            }
        });
    }*/

    private VBox getBundleProviderButtons() {

        Button btnBack = JKNode.getBtnPopup("back");
        btnBack.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new MenuTopups());
            }
        });

        Label lblTopupType = JKText.getLblDk(saleTypeSelected.getDisplay(), JKText.FONT_B_SM);

        VBox vbHead = JKNode.getPageDblHeadVB(0, btnBack, lblTopupType);

        List<Button> btnList = new ArrayList<>();

        for (final TopupProvider p : listTopupProviders) {
            final String provStyle = AirtimeUtil.getProviderStyleName(p);

            final Button btn = JKNode.getBtnSm("");
            ImageView imgView = JKNode.getJKImageViewProvider("prov_" + provStyle + ".png");

            btn.setGraphic(imgView);
            btn.getStyleClass().add("prov_" + provStyle + "_fix");
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    TopupSale.getInstance().setProviderStyleName(provStyle);
                    TopupSale.getInstance().setProvider(p);

                    System.out.println(TopupSale.getInstance().getProviderStyleName() + "-------- control");
                    System.out.println(TopupSale.getInstance().getProvider() + "-------- control");

                    showBundleCategories();
                }
            });

            btnList.add(btn);
        }

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 4, btnList);

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    public void getBundleProviderButtons(SaleType saleTypeSelected, List<TopupProvider> listTopupProviders) {
        this.saleTypeSelected = saleTypeSelected;
        this.listTopupProviders = listTopupProviders;

        getBundleProviderButtons();
    }

    private void showBundleCategories() {
        SceneSales.clearAndChangeContent(new BundleSelectDataOrSMS());
    }
}
