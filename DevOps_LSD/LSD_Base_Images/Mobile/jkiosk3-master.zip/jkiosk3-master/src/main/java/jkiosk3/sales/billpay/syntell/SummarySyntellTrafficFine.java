package jkiosk3.sales.billpay.syntell;

import aeonbillpayments.TrafficFine;
import aeonbillpayments.syntell.SyntellFinePayResp;
import java.util.List;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3.sales._common.JKTenderToggles;

/**
 *
 * @author Val
 */
public class SummarySyntellTrafficFine extends Region {

    private final SyntellFinePayResp response;
    private final List<TrafficFine> fines;
    private final String tendered;

    public SummarySyntellTrafficFine(SyntellFinePayResp resp, String tenderType) {
        this.response = resp;
        this.tendered = tenderType;

        fines = resp.getFines();
        getChildren().add(getSummaryGrid());
    }

    private GridPane getSummaryGrid() {
        GridPane grid = JKLayout.getSummaryGrid2Col(0.4, 0.6);
        grid.setTranslateX(-JKLayout.sp);

        TrafficFine trafficFine = fines.get(0);

        Label lblLocalAuthority = JKText.getLblDk("Local Authority", JKText.FONT_B_XSM);
        Label lblNoticeNo = JKText.getLblDk("Notice Number", JKText.FONT_B_XSM);
        Label lblVehicleReg = JKText.getLblDk("Vehicle Registration", JKText.FONT_B_XSM);
        Label lblOwnerId = JKText.getLblDk("Owner ID", JKText.FONT_B_XSM);
        Label lblLocation = JKText.getLblDk("Location", JKText.FONT_B_XSM);
        Label lblDescription = JKText.getLblDk("Description", JKText.FONT_B_XSM);
        Label lblDateAndTime = JKText.getLblDk("Offence Date", JKText.FONT_B_XSM);
        Label lblTenderType = JKText.getLblDk("Tender Type", JKText.FONT_B_XSM);
        Label lblAmount = JKText.getLblDk("Amount", JKText.FONT_B_XSM);
        Label lblConvenienceFee = JKText.getLblDk("Convenience Fee", JKText.FONT_B_XSM);
        Label lblTotalPayable = JKText.getLblDk("Total Payable", JKText.FONT_B_XSM);

        // filled-in fields
        Text txtLocalAuthority = JKText.getTxtDk(trafficFine.getLocalAuthorityName(), JKText.FONT_B_XSM);
        Text txtNoticeNo = JKText.getTxtDk(trafficFine.getNoticeNumber(), JKText.FONT_B_XSM);
        Text txtVehicleReg = JKText.getTxtDk(trafficFine.getVehicleRegNumber(), JKText.FONT_B_XSM);
        Text txtID = JKText.getTxtDk(trafficFine.getOwnerIdNumber(), JKText.FONT_B_XSM);

        Text txtLocation = JKText.getTxtDk("", JKText.FONT_B_XSM);
        txtLocation.setWrappingWidth((MessageBox.getMsgWidth() - (6 * JKLayout.sp)) * 0.6);
        txtLocation.setTextAlignment(TextAlignment.RIGHT);
        if (trafficFine.getOffenceLocation() == null || trafficFine.getOffenceLocation().equals("")) {
            txtLocation.setText("not available");
        } else {
            txtLocation.setText(trafficFine.getOffenceLocation());
        }

        Text txtDescription = JKText.getTxtDk("", JKText.FONT_B_XSM);
        txtDescription.setWrappingWidth((MessageBox.getMsgWidth() - (6 * JKLayout.sp)) * 0.6);
        txtDescription.setTextAlignment(TextAlignment.RIGHT);
        if (trafficFine.getOffenceDescription() == null || trafficFine.getOffenceDescription().equals("")) {
            txtDescription.setText("not available");
        } else {
            txtDescription.setText(trafficFine.getOffenceDescription());
        }

        String offenceDate = JKText.getDateDisplay(trafficFine.getOffenceDateTime());
        Text txtDateAndTime = JKText.getTxtDk(offenceDate, JKText.FONT_B_XSM);

        String tenderDisplay = JKTenderToggles.getTxtForTender(tendered);
        Text txtTenderType = JKText.getTxtDk(tenderDisplay, JKText.FONT_B_XSM);

        Text txtAmount = JKText.getTxtDk(JKText.getDeciFormat(trafficFine.getAmountDue()), JKText.FONT_B_XSM);
        Text txtConvenienceFee = JKText.getTxtDk(JKText.getDeciFormat(response.getConvenienceFee()), JKText.FONT_B_XSM);
        double totalPayable = trafficFine.getAmountDue() + response.getConvenienceFee();
        Text txtTotalPayable = JKText.getTxtDk(JKText.getDeciFormat(totalPayable), JKText.FONT_B_SM);

        grid.addRow(0, lblLocalAuthority, txtLocalAuthority);
        grid.addRow(1, lblNoticeNo, txtNoticeNo);
        grid.addRow(2, lblVehicleReg, txtVehicleReg);
        grid.addRow(3, lblOwnerId, txtID);
        grid.addRow(4, lblLocation, txtLocation);
        grid.addRow(5, lblDescription, txtDescription);
        grid.addRow(6, lblDateAndTime, txtDateAndTime);
        grid.addRow(7, lblTenderType, txtTenderType);
        grid.addRow(8, lblAmount, txtAmount);
        grid.addRow(9, lblConvenienceFee, txtConvenienceFee);
        grid.addRow(10, lblTotalPayable, txtTotalPayable);

        return grid;
    }
}
