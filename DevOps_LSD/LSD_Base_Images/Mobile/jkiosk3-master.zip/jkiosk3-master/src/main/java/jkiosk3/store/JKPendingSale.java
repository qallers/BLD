package jkiosk3.store;

import javafx.collections.ObservableList;
import jkiosk3.sales.SaleSummary;

import java.util.List;

public class JKPendingSale {

    private static StoreJKPendingSale pendingSale;

    private static void loadPendingSale() {
        if ((pendingSale == null) || (pendingSale.getListSaleSummary().isEmpty())) {
            pendingSale = (StoreJKPendingSale) Store.loadObject(JKPendingSale.class.getSimpleName());
        }
        if (pendingSale == null) {
            pendingSale = new StoreJKPendingSale();
        }
    }

    public static boolean hasPendingItems() {
        loadPendingSale();
        return pendingSale.getListSaleSummary().size() > 0;
    }

    public static void savePendingSale(ObservableList<SaleSummary> listPendingSales) {
//        loadPendingList();
//        pendingList.add(saleItem);
        // No need to load existing, just save object with new FULL list...?
        StoreJKPendingSale storeJKPendingSale = new StoreJKPendingSale();
        storeJKPendingSale.getListSaleSummary().addAll(listPendingSales);
        Store.saveObject(JKPendingSale.class.getSimpleName(), storeJKPendingSale);
    }

//    public static ObservableList<SaleSummary> getPendingSaleItems() {
//        loadPendingSale();
//        return pendingSale.getListSaleSummary();
//    }

    public static List<SaleSummary> getPendingSaleItemsList() {
        loadPendingSale();
        return pendingSale.getListSaleSummary();
    }
}
