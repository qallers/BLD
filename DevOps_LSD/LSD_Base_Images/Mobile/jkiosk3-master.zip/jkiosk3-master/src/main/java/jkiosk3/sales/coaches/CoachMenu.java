package jkiosk3.sales.coaches;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._components.NumberPadResult;
import jkiosk3.reports.Reprints;
import jkiosk3.sales.MerchantCopy;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._favourites.Favourites;
import jkiosk3.users.SalesUserLoginResult;

import java.util.ArrayList;
import java.util.List;

public class CoachMenu extends Region {

    public CoachMenu() {
        getChildren().add(getTicketingProviders());
    }

    private VBox getTicketingProviders() {
        VBox vbHead = JKNode.getPageHeadVB("Coach Ticket Menu");

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getMenuButtons());

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private List<Button> getMenuButtons() {
        List<Button> btnList = new ArrayList<>();

        for (String category : getCategory()) {
            btnList.add(createButton(category));
        }

        return btnList;
    }

    private List<String> getCategory() {
        List<String> coachCategory = new ArrayList<>();
        coachCategory.add("Buy Ticket");
        coachCategory.add("Cancel Ticket");
        coachCategory.add("Reprint Ticket");

        return coachCategory;
    }

    private Button createButton(final String buttonName) {
        final Button btn = JKNode.getBtnSmDbl("");

        btn.setText(buttonName);
        btn.getStyleClass().add("prov_VAS_fix");
        btn.setStyle(JKNode.getBrandButton());
        btn.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event evt) {
                if (buttonName.equals("Buy Ticket")) {
                    CoachTicketSale.resetCoachTicketSale();

                    JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
                        @Override
                        public void onDone() {
                            SceneSales.clearAndChangeContent(new CoachBook1());
                        }
                    });
                } else {
                    final PasswordField pwd = new PasswordField();
                    JKiosk3.getNumPad().showNumPad(pwd, "Enter User Pin", "", new NumberPadResult() {
                        @Override
                        public void onDone(String value) {
                            String userPin = pwd.getText();

                            Region theRegion = getMenuAction(btn);

                            SalesUtil.onSelectCoachMenu(userPin, buttonName, theRegion);
                        }
                    });
                }
            }
        });

        return btn;
    }

    private Region getMenuAction(final Button button) {
        MerchantCopy.resetMerchantCopy();
        Region region = null;

        switch (button.getText()) {
            case "Reprint Ticket":
                region = new Reprints();
                break;

            case "Cancel Ticket":
                region = new CancelCoachTicket();
                break;
            default:
                region = new Favourites();
        }

        return region;
    }
}
