package jkiosk3.sales.rmcs;

import aeonmoneytransfer.MoneyTransferConnection;
import aeonmoneytransfer.MoneyTransferDepositReq;
import aeonmoneytransfer.MoneyTransferPreAuthReq;
import aeonmoneytransfer.MoneyTransferRedeemReq;
import aeonmoneytransfer.MoneyTransferResponse;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import static javafx.concurrent.Worker.State.CANCELLED;
import static javafx.concurrent.Worker.State.FAILED;
import jkiosk3.JKiosk3;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SceneSales;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

/**
 *
 *
 */
public class RmcsUtil {

    private final static Logger logger = Logger.getLogger(RmcsUtil.class.getName());
    public static final String MONEY_TRF_DEPOSIT = "Cash-In";
    public static final String MONEY_TRF_REDEEM = "Cash-Out";
    private static MoneyTransferConnection conn;
    private static String userPin;
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 60;

    /**
     * Creates a MoneyTransferConnection object, to be used for any request/response communications. Retrieves the
     * Server (IP address) and Port that has been entered and saved in the setup process. Socket timeout is also set in
     * this method.
     *
     * @return a MoneyTransferConnection object.
     */
    private static MoneyTransferConnection getMoneyTransferConnection() {
        MoneyTransferConnection mTrfConn = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            mTrfConn = new MoneyTransferConnection(server, port, secureConnect);
            mTrfConn.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return mTrfConn;
    }

    /**
     * Allows for a User (Cashier) to be authenticated for a specific Transaction Type prior to the Transaction being
     * processed.
     *
     * @param pin the PIN number of the User requesting the authentication.
     * @return <ul><li>'true' - User (Cashier) is authenticated, or</li>
     * <li>'false' - User (Cashier) is not authenticated.</li></ul>
     * @throws RuntimeException
     */
    private static boolean isLoggedIn(String pin) throws RuntimeException {
        boolean loggedIn = false;
        int deviceId = JKSystem.getSystemConfig().getDeviceId();
        String serial = JKSystem.getSystemConfig().getSerial();

        try {
            loggedIn = conn.login(pin, deviceId, serial);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    /**
     * Checks the RMCS records to determine whether the Customer is registered as FICA-compliant, and brings back the
     * response together with the amount of the Convenience Fee to be charged for a Money Transfer Deposit transaction.
     *
     * @param req the MoneyTransferPreAuthReq object built with the information provided by the Customer.
     * @return a MoneyTransferResponse object.
     * @throws RuntimeException
     */
    private static MoneyTransferResponse getMoneyTrfPreAuthResp(final MoneyTransferPreAuthReq req) throws RuntimeException {
        MoneyTransferResponse moneyTrfPreAuthResp = new MoneyTransferResponse();
        userPin = CurrentUser.getSalesUser().getUserPin();
        conn = getMoneyTransferConnection();
        try {
            if (isLoggedIn(userPin)) {
                moneyTrfPreAuthResp = conn.depoPreAuth(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("RMCS Error", t);
        } finally {
            // DO NOT DISCONNECT!  KEEP CONNECTION OPEN!
//            if (conn != null) {
//                conn.disconnect();
//            }
        }
        return moneyTrfPreAuthResp;
    }

    /**
     * Sends the Money Transfer Deposit information provided by the Customer to RMCS to be processed.
     *
     * @param req the MoneyTransferPreAuthReq object built with the information provided by the Customer.
     * @return a MoneyTransferResponse object.
     * @throws RuntimeException
     */
    private static MoneyTransferResponse getMoneyTrfDepositResp(final MoneyTransferDepositReq req) throws RuntimeException {
        MoneyTransferResponse moneyTrfDepositResp = new MoneyTransferResponse();
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            moneyTrfDepositResp = conn.deposit(req);
            if (moneyTrfDepositResp.isSuccess()) {
                conn.printed(true);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("RMCS Error", t);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return moneyTrfDepositResp;
    }

    /**
     * If the Customer does not wish to proceed with the Money Transfer Deposit, this will mark the transaction in the
     * database with the appropriate Status.
     *
     * @param isDecline
     * @return a MoneyTransferResponse object.
     * @throws RuntimeException
     */
    private static MoneyTransferResponse getMoneyTrfDepositDecline(boolean isDecline) throws RuntimeException {
        MoneyTransferResponse moneyTrfDeclineResp = new MoneyTransferResponse();
        try {
            moneyTrfDeclineResp = conn.decline(isDecline);
            if (!moneyTrfDeclineResp.isSuccess()) {
                logger.info(Integer.toString(moneyTrfDeclineResp.getErrorCode()).concat(" - ")
                        .concat(moneyTrfDeclineResp.getErrorText()));
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("RMCS Error", t);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return moneyTrfDeclineResp;
    }

    /**
     * Sends the Money Transfer Redeem information provided by the Customer to RMCS to be processed.
     *
     * @param req the MoneyTransferRedeemReq object built with the information provided by the Customer.
     * @return a MoneyTransferResponse object.
     * @throws RuntimeException
     */
    private static MoneyTransferResponse getMoneyTrfRedeemResp(MoneyTransferRedeemReq req) throws RuntimeException {
        MoneyTransferResponse moneyTrfRedeemResp = new MoneyTransferResponse();
        userPin = CurrentUser.getSalesUser().getUserPin();
        conn = getMoneyTransferConnection();
        try {
            if (isLoggedIn(userPin)) {
                moneyTrfRedeemResp = conn.redeem(req);
                if (moneyTrfRedeemResp.isSuccess()) {
                    conn.printed(true);
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("RMCS Error", t);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return moneyTrfRedeemResp;
    }

//    /*----------------*/
//    /* Busy Indicator */
//    /*----------------*/
    public static void getMoneyTrfPreAuthResp(final MoneyTransferPreAuthReq req, final MoneyTransferPreAuthResponseResult result) {
        JKiosk3.getBusy().showBusy("Processing Money Transfer Authorisation");

        final Task<MoneyTransferResponse> taskMoneyTrfPreAuth = new Task() {
            @Override
            protected MoneyTransferResponse call() throws Exception {
                return getMoneyTrfPreAuthResp(req);
            }
        };

        taskMoneyTrfPreAuth.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    JKiosk3.getBusy().hideBusy();
                    result.moneyTrfPreAuthRespResult(taskMoneyTrfPreAuth.getValue());
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
//                    taskutil.taskSaleCancelFail("RMCS Money Transfer Pre-Auth Error",
//                            "Error Processing RMCS Money Transfer Pre-Auth", newState, errorMsg, new SceneSales());
                    JKiosk3.getBusy().hideBusy();
                    String msgadd = "\n\nPlease check your network connection";
                    if (newState.equals(CANCELLED)) {
                        JKiosk3.getMsgBox().showMsgBox("RMCS Money Transfer Pre-Auth Error",
                                "Error Processing RMCS Money Transfer Pre-Auth" + "\n\n" + newState + "\n\n" + "Operation timed out" + msgadd,
                                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                    @Override
                                    public void onOk() {
                                        JKiosk3.returnToLogin();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    } else if (newState.equals(FAILED)) {
                        JKiosk3.getMsgBox().showMsgBox("RMCS Money Transfer Pre-Auth Error", "Error Processing RMCS Money Transfer Pre-Auth" + "\n\n"
                                + newState + "\n\n" + errorMsg + msgadd, null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                    @Override
                                    public void onOk() {
                                        JKiosk3.returnToLogin();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    }
                }
            }
        });
        new Thread(taskMoneyTrfPreAuth).start();
        JKiosk3.getBusy().startCountdown(taskMoneyTrfPreAuth, countdownTime);
    }

    public static void getMoneyTrfDepositResp(final MoneyTransferDepositReq req, final MoneyTransferDepositResponseResult result) {
        JKiosk3.getBusy().showBusy("Processing Money Transfer Deposit");

        final Task<MoneyTransferResponse> taskMoneyTrfDeposit = new Task() {
            @Override
            protected MoneyTransferResponse call() throws Exception {
                return getMoneyTrfDepositResp(req);
            }
        };

        taskMoneyTrfDeposit.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    JKiosk3.getBusy().hideBusy();
                    result.moneyTrfDepRespResult(taskMoneyTrfDeposit.getValue());
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
//                    taskutil.taskSaleCancelFail("RMCS Money Transfer Deposit Error",
//                            "Error Processing RMCS Money Transfer Deposit", newState, errorMsg, new SceneSales());
                    JKiosk3.getBusy().hideBusy();
                    String msgadd = "\n\nPlease check your network connection";
                    if (newState.equals(CANCELLED)) {
                        JKiosk3.getMsgBox().showMsgBox("RMCS Money Transfer Deposit Error",
                                "Error Processing RMCS Money Transfer Deposit" + "\n\n" + newState + "\n\n" + "Operation timed out" + msgadd,
                                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                    @Override
                                    public void onOk() {
                                        JKiosk3.returnToLogin();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    } else if (newState.equals(FAILED)) {
                        JKiosk3.getMsgBox().showMsgBox("RMCS Money Transfer Deposit Error", "Error Processing RMCS Money Transfer Deposit" + "\n\n"
                                + newState + "\n\n" + errorMsg + msgadd, null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                    @Override
                                    public void onOk() {
                                        JKiosk3.returnToLogin();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    }
                }
            }
        });
        new Thread(taskMoneyTrfDeposit).start();
        JKiosk3.getBusy().startCountdown(taskMoneyTrfDeposit, countdownTime);
    }

    public static void getMoneyTrfDepositDecline(final boolean isDecline, final MoneyTransferDepositDeclineResult result) {
        JKiosk3.getBusy().showBusy("Processing Money Transfer Deposit Decline");

        final Task<MoneyTransferResponse> taskMoneyTrfDepDecline = new Task() {
            @Override
            protected MoneyTransferResponse call() throws Exception {
                return getMoneyTrfDepositDecline(isDecline);
            }
        };

        taskMoneyTrfDepDecline.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    JKiosk3.getBusy().hideBusy();
                    result.moneyTrfDepDeclineResult(taskMoneyTrfDepDecline.getValue());
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
                    taskutil.taskSaleCancelFail("RMCS Money Transfer Deposit Decline Error",
                            "Error Processing RMCS Money Transfer Deposit Decline", newState, errorMsg, new SceneSales(true));
                }
            }
        });
        new Thread(taskMoneyTrfDepDecline).start();
        JKiosk3.getBusy().startCountdown(taskMoneyTrfDepDecline, countdownTime);
    }

    public static void getMoneyTrfRedeemResp(final MoneyTransferRedeemReq req, final MoneyTransferRedeemResponseResult result) {
        JKiosk3.getBusy().showBusy("Processing Money Transfer Redeem");

        final Task<MoneyTransferResponse> taskMoneyTrfRedeem = new Task() {
            @Override
            protected MoneyTransferResponse call() throws Exception {
                return getMoneyTrfRedeemResp(req);
            }
        };
        taskMoneyTrfRedeem.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    JKiosk3.getBusy().hideBusy();
                    result.moneyTrfRedRespResult(taskMoneyTrfRedeem.getValue());
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
//                    taskutil.taskSaleCancelFail("RMCS Money Transfer Redeem Error",
//                            "Error Processing RMCS Money Transfer Redeem", newState, errorMsg, new SceneSales());
                    JKiosk3.getBusy().hideBusy();
                    String msgadd = "\n\nPlease check your network connection";
                    if (newState.equals(CANCELLED)) {
                        JKiosk3.getMsgBox().showMsgBox("RMCS Money Transfer Redeem Error",
                                "Error Processing RMCS Money Transfer Redeem" + "\n\n" + newState + "\n\n" + "Operation timed out" + msgadd,
                                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                    @Override
                                    public void onOk() {
                                        JKiosk3.returnToLogin();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    } else if (newState.equals(FAILED)) {
                        JKiosk3.getMsgBox().showMsgBox("RMCS Money Transfer Redeem Error", "Error Processing RMCS Money Transfer Redeem" + "\n\n"
                                + newState + "\n\n" + errorMsg + msgadd, null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                    @Override
                                    public void onOk() {
                                        JKiosk3.returnToLogin();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    }
                }
            }
        });
        new Thread(taskMoneyTrfRedeem).start();
        JKiosk3.getBusy().startCountdown(taskMoneyTrfRedeem, countdownTime);
    }

    public static abstract class MoneyTransferPreAuthResponseResult {

        public abstract void moneyTrfPreAuthRespResult(MoneyTransferResponse moneyTrfPreAuthResp);
    }

    public static abstract class MoneyTransferDepositResponseResult {

        public abstract void moneyTrfDepRespResult(MoneyTransferResponse moneyTrfDepResp);
    }

    public static abstract class MoneyTransferDepositDeclineResult {

        public abstract void moneyTrfDepDeclineResult(MoneyTransferResponse moneyTrfDepDeclineResult);
    }

    public static abstract class MoneyTransferRedeemResponseResult {

        public abstract void moneyTrfRedRespResult(MoneyTransferResponse moneyTrfRedResp);
    }
    //
    //
    //

    public static String getVoucherDisplayFormat(String voucherNum) {
        if (voucherNum.length() > 16) {
            return voucherNum.substring(0, 4)
                    + " " + voucherNum.substring(4, 8)
                    + " " + voucherNum.substring(8, 12)
                    + " " + voucherNum.substring(12, 16)
                    + " " + voucherNum.substring(16);
        } else {
            return voucherNum.substring(0, 4)
                    + " " + voucherNum.substring(4, 8)
                    + " " + voucherNum.substring(8, 12)
                    + " " + voucherNum.substring(12, 16);
        }
    }
}
