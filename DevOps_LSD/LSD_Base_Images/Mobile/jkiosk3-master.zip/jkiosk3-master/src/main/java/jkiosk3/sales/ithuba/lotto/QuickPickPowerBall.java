package jkiosk3.sales.ithuba.lotto;

import aeonithuba.IthubaConfirmRes;
import aeonithuba.IthubaLottoReq;
import aeonithuba.IthubaLottoRes;

import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales._favourites.Favourites;
import jkiosk3.sales._tender.TenderAmounts;
import jkiosk3.sales.ithuba.LottoUtil;

public class QuickPickPowerBall extends Region {

    private final static Logger logger = Logger.getLogger (QuickPickPowerBall.class.getName ());

    private final int maxBoards = LottoUtil.MAX_BOARDS;
    private final int maxDraws = LottoUtil.MAX_DRAWS;

    private CheckBox cbPlayPowerBallPlus;
    private TextField txtNumOfBoards;
    private TextField txtNumOfDraws;
    private IthubaLottoReq req;
    private String lottoPlus;

    public QuickPickPowerBall() {
        logger.info ("Starting sale - Powerball Quick Pick");
        LottoSale.resetLottoSale ();
        getChildren ().add (getLayoutGroup ());
    }

    private VBox getLayoutGroup() {
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (getContentGroup ());
        vb.getChildren ().add (getNav ());
        return vb;
    }

    private VBox getContentGroup() {
        ImageView img = JKNode.getJKImageViewProvider ("prov_IthubaPowerBall.png");
        Label lblPowerBall = JKText.getLblDk ("Quick Pick PowerBall", JKText.FONT_B_SM);

        VBox vbHead = JKNode.getPageDblHeadVB (0, lblPowerBall, img);

        VBox vb = JKLayout.getVBoxContent (2 * JKLayout.sp);
        vb.getChildren ().addAll (vbHead, getContentGrid ());

        return vb;
    }

    private GridPane getContentGrid() {

        final String rangeBoards = "Boards (1 - " + maxBoards + ")";
        final String rangeDraws = "Draws (1 - " + maxDraws + ")";

//        Label numOfBoardsText = JKText.getLblDk("No. of Boards (1 - " + maxBoards + ")", JKText.FONT_B_XSM);
//        Label numOfDrawsText = JKText.getLblDk("No. of Draws (1 - " + maxDraws + ")", JKText.FONT_B_XSM);
        Label numOfBoardsText = JKText.getLblDk ("No. of " + rangeBoards, JKText.FONT_B_XSM);
        Label numOfDrawsText = JKText.getLblDk ("No. of " + rangeDraws, JKText.FONT_B_XSM);
        Label playPowerBallPlus = JKText.getLblDk ("Play PowerBall Plus ", JKText.FONT_B_XSM);

        txtNumOfBoards = JKNode.getTextFieldSmRight ();
        txtNumOfBoards.setText ("1");
        txtNumOfBoards.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                JKiosk3.getNumPad().showNumPad(txtNumOfBoards, "Boards (1-" + maxBoards + ")", "", new NumberPadResult() {
                JKiosk3.getNumPad ().showNumPad (txtNumOfBoards, rangeBoards, "", new NumberPadResult () {
                    @Override
                    public void onDone(String value) {
                        validateNumber (txtNumOfBoards, value, 1, maxBoards);
                    }
                });
            }
        });

        txtNumOfDraws = JKNode.getTextFieldSmRight ();
        txtNumOfDraws.setText ("1");
        txtNumOfDraws.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                JKiosk3.getNumPad().showNumPad(txtNumOfDraws, "Draws (1-" + maxDraws + ")", "", new NumberPadResult() {
                JKiosk3.getNumPad ().showNumPad (txtNumOfDraws, rangeDraws, "", new NumberPadResult () {
                    @Override
                    public void onDone(String value) {
                        validateNumber (txtNumOfDraws, value, 1, maxDraws);
                    }
                });
            }
        });

        cbPlayPowerBallPlus = new CheckBox ();

        GridPane grid = JKLayout.getContentGridInner2ColInScroll (0.5, 0.5, HPos.RIGHT);

        grid.addRow (0, numOfBoardsText, txtNumOfBoards);
        grid.addRow (1, numOfDrawsText, txtNumOfDraws);
        grid.addRow (3, playPowerBallPlus, cbPlayPowerBallPlus);

        return grid;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new LottoMenu ());
            }
        });
//        nav.setBtnCancelAction(new LottoMenu());
        nav.setBtnCancelAction (new Favourites ());

        nav.getBtnNext ().setText ("play!");
        nav.getBtnNext ().setFont (LottoUtil.FONT_PLAY);
        nav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event t) {
                if (canContinue ()) {
                    LottoSale.getInstance ().setBoards (Integer.parseInt (txtNumOfBoards.getText ()));
                    LottoSale.getInstance ().setDraws (Integer.parseInt (txtNumOfDraws.getText ()));

                    if (cbPlayPowerBallPlus.isSelected ()) {
                        LottoSale.getInstance ().setLottoPlus1 (true);
                        lottoPlus = "Yes";
                    } else {
                        LottoSale.getInstance ().setLottoPlus1 (false);
                        lottoPlus = "No";
                    }

                    LottoSale.getInstance ().setLottoPlus2 (false);
                    confirmLotto ();
                }
            }
        });
        return nav;
    }

    private void confirmLotto() {
        StringBuilder sb = new StringBuilder ("\r\n");
        sb.append ("Powerball Quick Pick").append ("\r\n");
        sb.append ("Boards selected         : ").append (LottoSale.getInstance ().getBoards ()).append ("\r\n");
        sb.append ("Draws selected          : ").append (LottoSale.getInstance ().getDraws ()).append ("\r\n");
        sb.append ("Powerball Plus 1 selected : ").append (LottoSale.getInstance ().isLottoPlus1 ()).append ("\r\n");
        sb.append ("Powerball Plus 2 selected : ").append (LottoSale.getInstance ().isLottoPlus2 ()).append ("\r\n");
        logger.info (sb.toString ());

        req = new IthubaLottoReq ();

        req.setRef (SalesUtil.getUniqueRef ());
        req.getStructData ().put (LottoUtil.DATA_GAME, "Powerball");
        req.getStructData ().put (LottoUtil.DATA_TYPE, "Quickpick");
        req.getStructData ().put (LottoUtil.DATA_NUM_BOARDS, Integer.toString (LottoSale.getInstance ().getBoards ()));
        req.getStructData ().put (LottoUtil.DATA_NUM_DRAWS, Integer.toString (LottoSale.getInstance ().getDraws ()));
        req.getStructData ().put (LottoUtil.DATA_PLUS1, Boolean.toString (LottoSale.getInstance ().isLottoPlus1 ()));
        req.getStructData ().put (LottoUtil.DATA_PLUS2, Boolean.toString (LottoSale.getInstance ().isLottoPlus2 ()));

        LottoUtil.getLottoConfirm (req, new LottoUtil.IthubaConfirmResult () {
            @Override
            public void ithubaLottoResult(IthubaConfirmRes ithubaConfirmRes) {

                if (ithubaConfirmRes.isSuccess ()) {
                    logger.info (("Powerball Confirm success - amount due = ").concat (JKText.getDeciFormat ((double) ithubaConfirmRes.getAmt () / 100)));

                    IthubaConfirm confirm = new IthubaConfirm (ithubaConfirmRes, LottoUtil.GAMETYPE_PBALL_QUICK, lottoPlus, "");

                    JKiosk3.getMsgBox ().showMsgBox ("PowerBall Confirmation", "", confirm,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    logger.info ("Customer confirmed - OK button clicked");
                                    buyLottoTicket ();
                                }

                                @Override
                                public void onCancel() {
                                    logger.info ("Customer declined - Cancel button clicked");
                                }
                            });

                } else {
                    resetOnError (!ithubaConfirmRes.getAeonErrorCode ().isEmpty () ? "A" + ithubaConfirmRes.getAeonErrorCode () : "B" + ithubaConfirmRes.getErrorCode (),
                            !ithubaConfirmRes.getAeonErrorText ().isEmpty () ? ithubaConfirmRes.getAeonErrorText () : ithubaConfirmRes.getErrorText ());
                }
            }
        });
    }

    private void buyLottoTicket() {

        LottoUtil.getFinalLottoResp (req, new LottoUtil.IthubaResult () {
            @Override
            public void ithubaLottoFinalRes(IthubaLottoRes ithubaLottoRes) {

                if (ithubaLottoRes.isSuccess ()) {
                    logger.info (("Powerball QuickPick Sale success - amount due = ").concat (JKText.getDeciFormat ((double) ithubaLottoRes.getAmt () / 100)));

                    SalesUtil.processIthuba (ithubaLottoRes, LottoUtil.GAMETYPE_PBALL_QUICK);

                    SceneSales.clearAndShowFavourites ();

                } else {
                    resetOnError (!ithubaLottoRes.getAeonErrorCode ().isEmpty () ? "A" + ithubaLottoRes.getAeonErrorCode () : "B" + ithubaLottoRes.getErrorCode (),
                            !ithubaLottoRes.getAeonErrorText ().isEmpty () ? ithubaLottoRes.getAeonErrorText () : ithubaLottoRes.getErrorText ());
                }
            }
        });
    }

    private void validateNumber(final TextField txt, String value, int minNum, int maxNum) {
        try {
            if (Integer.parseInt (value) < minNum || Integer.parseInt (value) > maxNum) {
                JKiosk3.getMsgBox ().showMsgBox ("Incorrect Number Selected", "ONLY numbers in the range " + minNum + "-" + maxNum + " allowed", null);
                txt.setText ("1");
            }
        } catch (NumberFormatException nfe) {
            logger.log (Level.SEVERE, nfe.getMessage (), nfe);
            JKiosk3.getMsgBox ().showMsgBox ("Invalid Number Selection", "Please review the selected numbers and try again", null);
        }
    }

    private boolean canContinue() {
        if (txtNumOfBoards.getText ().equals ("") || txtNumOfBoards.getText ().equals ("0")) {
            JKiosk3.getMsgBox ().showMsgBox ("Invalid Input", "Please select a valid number of Boards", null);
            return false;
        }
        if (txtNumOfDraws.getText ().equals ("") || txtNumOfDraws.getText ().equals ("0")) {
            JKiosk3.getMsgBox ().showMsgBox ("Invalid Input", "Please select a valid number of Draws", null);
            return false;
        }
        return true;
    }

    private void resetOnError(String errorCode, String errorText) {
        logger.info (("Powerball Quick Pick failure ").concat (errorCode).concat (" - ").concat (errorText));
        JKiosk3.getMsgBox ().showMsgBox ("Lotto Error", errorCode + " - " + errorText, null);
        SceneSales.clearAndShowFavourites ();
    }
}
