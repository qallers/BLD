package jkiosk3.sales.ticketpro;

import aeonticketpros.TicketProsCart;
import aeonticketpros.TicketProsCategory;
import aeonticketpros.TicketProsCheckoutResp;
import aeonticketpros.TicketProsEvent;
import aeonticketpros.TicketProsEventDetail;
import aeonticketpros.TicketProsPriceCategory;
import aeonticketpros.TicketProsReserveSeatsResp;
import aeonticketpros.TicketProsSeat;
import aeonticketpros.TicketProsSeatCategory;

import java.util.ArrayList;
import java.util.List;

public class TicketProSale {

    private List<TicketProsCategory> listCategories = new ArrayList<>();
    private TicketProsCategory selectedCategory;
    private List<TicketProsEvent> listEvents = new ArrayList<>();
    private TicketProsEvent selectedEvent;
    private TicketProsEventDetail selectedEventDetail;
    private TicketProsCart saleCart;
    private TicketProsSeatCategory selectedSeatCategory;
    private List<TicketProsPriceCategory> selectedPriceCategories;
    private TicketProsReserveSeatsResp reservedSeats;
    private List<TicketProsSeat> selectedSeats;
    private TicketProsCheckoutResp checkoutResponse;
    private boolean scatteredSeats;
    private String customerName;
    private String customerSurname;
    private String customerMobilePhone;
    private String tenderType;
    private String tenderText;
    //
    private static TicketProSale instance;

    public static TicketProSale getInstance() {
        return instance;
    }

    public static TicketProSale newInstance() {
        instance = new TicketProSale();
        return instance;
    }

    public static void resetTicketProSale() {
        instance = null;
    }

    public List<TicketProsCategory> getListCategories() {
        return listCategories;
    }

    public TicketProsCategory getSelectedCategory() {
        return selectedCategory;
    }

    public void setSelectedCategory(TicketProsCategory selectedCategory) {
        this.selectedCategory = selectedCategory;
    }

    public List<TicketProsEvent> getListEvents() {
        return listEvents;
    }

    public TicketProsEvent getSelectedEvent() {
        return selectedEvent;
    }

    public void setSelectedEvent(TicketProsEvent selectedEvent) {
        this.selectedEvent = selectedEvent;
    }

    public TicketProsEventDetail getSelectedEventDetail() {
        return selectedEventDetail;
    }

    public void setSelectedEventDetail(TicketProsEventDetail selectedEventDetail) {
        this.selectedEventDetail = selectedEventDetail;
    }

    public TicketProsCart getSaleCart() {
        return saleCart;
    }

    public void setSaleCart(TicketProsCart saleCart) {
        this.saleCart = saleCart;
    }

    public TicketProsSeatCategory getSelectedSeatCategory() {
        return selectedSeatCategory;
    }

    public void setSelectedSeatCategory(TicketProsSeatCategory selectedSeatCategory) {
        this.selectedSeatCategory = selectedSeatCategory;
    }

    public List<TicketProsPriceCategory> getSelectedPriceCategories() {
        return selectedPriceCategories;
    }

    public void setSelectedPriceCategories(List<TicketProsPriceCategory> selectedPriceCategories) {
        this.selectedPriceCategories = selectedPriceCategories;
    }

    public TicketProsReserveSeatsResp getReservedSeats() {
        return reservedSeats;
    }

    public void setReservedSeats(TicketProsReserveSeatsResp reservedSeats) {
        this.reservedSeats = reservedSeats;
    }

    public List<TicketProsSeat> getSelectedSeats() {
        return selectedSeats;
    }

    public void setSelectedSeats(List<TicketProsSeat> selectedSeats) {
        this.selectedSeats = selectedSeats;
    }

    public TicketProsCheckoutResp getCheckoutResponse() {
        return checkoutResponse;
    }

    public void setCheckoutResponse(TicketProsCheckoutResp checkoutResponse) {
        this.checkoutResponse = checkoutResponse;
    }

    public boolean isScatteredSeats() {
        return scatteredSeats;
    }

    public void setScatteredSeats(boolean scatteredSeats) {
        this.scatteredSeats = scatteredSeats;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerSurname() {
        return customerSurname;
    }

    public void setCustomerSurname(String customerSurname) {
        this.customerSurname = customerSurname;
    }

    public String getCustomerMobilePhone() {
        return customerMobilePhone;
    }

    public void setCustomerMobilePhone(String customerMobilePhone) {
        this.customerMobilePhone = customerMobilePhone;
    }

    public String getTenderType() {
        return tenderType;
    }

    public void setTenderType(String tenderType) {
        this.tenderType = tenderType;
    }

    public String getTenderText() {
        return tenderText;
    }

    public void setTenderText(String tenderText) {
        this.tenderText = tenderText;
    }
}
