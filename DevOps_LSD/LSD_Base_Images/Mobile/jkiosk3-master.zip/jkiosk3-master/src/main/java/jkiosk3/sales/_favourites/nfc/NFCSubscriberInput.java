package jkiosk3.sales._favourites.nfc;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.NumberPadResult;
import za.co.blt.ACRReader;

import javax.smartcardio.CardException;

public class NFCSubscriberInput extends Region {

    private boolean showSearch;
    private boolean allowKeyboardInput;
    private String cardNumber;
    private String cellNumber;
    private TextField txtTapCard;
    private TextField txtCellNumber;

    public NFCSubscriberInput(boolean showSearch, boolean allowKeyboardInput) {
        this.showSearch = showSearch;
        this.allowKeyboardInput = allowKeyboardInput;

        getChildren().add(getNFCReadBox());
        onClickReset();
    }

    private GridPane getNFCReadBox() {

        String instructions = "";
        if (allowKeyboardInput) {
            instructions = "Tap, Scan or Enter Card";
        } else {
            instructions = "Tap Card";
        }

//        Label lblTapCard = JKText.getLblDk("Tap, Scan or Enter Card", JKText.FONT_B_20);
        Label lblTapCard = JKText.getLblDk(instructions, JKText.FONT_B_20);

        Label lblSearch = JKText.getLblDk("OR Search by Cell Number", JKText.FONT_B_XXSM);
        lblSearch.setTranslateX(1 * JKLayout.sp);

        Label lblCellNum = JKText.getLblDk("Enter Cell Number", JKText.FONT_B_20);

        txtTapCard = getTextFieldNFC();
        if (allowKeyboardInput) {
            txtTapCard.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    JKiosk3.getKeyboard().showKeyboard(txtTapCard, "Scan Barcode, or enter Cell Number", "",
                            false, false, new KeyboardResult() {
                                @Override
                                public void onDone(String value) {
                                    txtTapCard.clear();
                                    txtTapCard.setText(value);
                                    cardNumber = value;
                                }
                            });
                }
            });
        } else {
            txtTapCard.setDisable(true);
        }
        txtTapCard.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent e) {
                if (e.getCode() == KeyCode.ENTER) {
                    cardNumber = txtTapCard.getText();
                    txtTapCard.clear();
                    txtTapCard.setText(cardNumber);
                }
            }
        });

        Button btnReset = JKNode.getBtnPopup("clear");
        btnReset.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickReset();
            }
        });

        HBox hbTapCard = JKLayout.getHBox(0, JKLayout.sp);
        hbTapCard.setTranslateX(3);
        hbTapCard.getChildren().addAll(txtTapCard, btnReset);

        txtCellNumber = getTextFieldNFC();
        txtCellNumber.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickReset();
                JKiosk3.getNumPad().showNumPad(txtCellNumber, "Cell Number", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        if (isValidCellNumber(value)) {
                            cellNumber = value;
                        } else {
                            txtCellNumber.clear();
                        }
                    }
                });
            }
        });

        Button btnClear = JKNode.getBtnPopup("clear");
        btnClear.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickReset();
            }
        });

        HBox hbClearCell = JKLayout.getHBox(0, JKLayout.sp);
        hbClearCell.setTranslateX(3);
        hbClearCell.getChildren().addAll(txtCellNumber, btnClear);

        GridPane gridPane = JKLayout.getContentGridInner2Col(0.50, 0.50, HPos.RIGHT);
        GridPane.setColumnSpan(gridPane, 2);

        gridPane.addRow(0, lblTapCard, hbTapCard);
        if (showSearch) {
            gridPane.addRow(1, lblSearch);
            gridPane.addRow(2, lblCellNum, hbClearCell);
        }

        return gridPane;
    }

    private void onClickCardRead(final TextField textField) {
        textField.clear();
        textField.requestFocus();
        try {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    ACRReader acr = new ACRReader();
                    try {
                        if (acr.isACRReaderReady()) {
                            String cardUid = acr.getCardUid();
                            if (cardUid != null) {
                                textField.setText(cardUid);
                                cardNumber = cardUid;
                            } else {
                                showCardReaderError("Unable to determine Card Number");
                            }
                        }
                    } catch (CardException ce) {
                        showCardReaderError(ce.getClass().getSimpleName());
                    } catch (Exception e) {
                        showCardReaderError(e.getClass().getSimpleName());
                    }
                }
            }).start();
        } catch (NullPointerException | IllegalArgumentException e) {
            showCardReaderError(e.getClass().getSimpleName());
        }
    }

    private void onClickReset() {
        cardNumber = "";
        cellNumber = "";
        txtTapCard.clear();
        txtCellNumber.clear();
        txtTapCard.requestFocus();
        onClickCardRead(txtTapCard);
    }

    private TextField getTextFieldNFC() {
        final TextField textField = new TextField();
        double txtW = ((JKLayout.contentW - (3 * JKLayout.sp)) / 2) - (JKLayout.btnNumW + JKLayout.sp);
        textField.setMaxSize(txtW, 37);
        textField.setMinSize(txtW, 37);
        textField.setStyle("-fx-font-size: 18pt;");
        return textField;
    }

    private void showCardReaderError(final String errorMsg) {
        onClickReset();
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                String msg = errorMsg + ("\n\nPlease click 'clear' and try again");
                JKiosk3.getMsgBox().showMsgBox("Card Reader Error", msg, null);
            }
        });
    }

    private boolean isValidCellNumber(String value) {
//        if (!txtCellNumber.getText().matches("\\d{10}")) {
//        if (!txtCellNumber.getText().matches("(^0[678][01234689]((\\d{7})|( |-)((\\d{3}))( |-)(\\d{4})|( |-)(\\d{7})))")) {
        if (!value.matches("(^0[678][01234689]((\\d{7})|( |-)((\\d{3}))( |-)(\\d{4})|( |-)(\\d{7})))")) {
            JKiosk3.getMsgBox().showMsgBox("Subscriber Cell Number", "Please enter a valid Cell Number", null);
            return false;
        }
        return true;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public String getCellNumber() {
        return cellNumber;
    }
}
