package jkiosk3.store;

public class JKCacheOptions {

    private static StoreJKCacheOptions jkCacheOptions;

    public static StoreJKCacheOptions getCachePreferences() {
        if (jkCacheOptions == null) {
            jkCacheOptions = ((StoreJKCacheOptions) Store.loadObject(JKCacheOptions.class.getSimpleName()));
        }
        if (jkCacheOptions == null) {
            jkCacheOptions = new StoreJKCacheOptions();
        }
        return jkCacheOptions;
    }

    public static boolean saveCachePreferences(StoreJKCacheOptions cachePrefs) {
        getCachePreferences();
        return Store.saveObject(JKCacheOptions.class.getSimpleName(), cachePrefs);
    }
}
