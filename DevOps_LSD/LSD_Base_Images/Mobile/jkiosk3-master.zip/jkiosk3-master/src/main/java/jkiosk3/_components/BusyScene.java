package jkiosk3._components;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;

public class BusyScene extends Region {

    private final static Logger logger = Logger.getLogger(BusyScene.class.getName());
    private volatile int countdownSeconds = 0;
    private String msg = "";
    private Label lblMsg;
    private Label lblCount;
    private ScheduledExecutorService schedCountdown;

    public BusyScene() {
        getChildren().add(getBusyStack());
    }

    private StackPane getBusyStack() {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().get(0).setStyle("-fx-opacity: 0.75;");

        stack.getChildren().addAll(getBusyPane());

        return stack;
    }

    private StackPane getBusyPane() {

        double w = 370;
        double h = 370;

        VBox vb = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
        vb.setPrefSize(w, h);

        ProgressIndicator wait = new ProgressIndicator();
        wait.setMaxSize((w / 2), (h / 2));
        wait.setMinSize((w / 2), (h / 2));

        Label lblWait = JKText.getLblDk("Please be patient", JKText.FONT_B_XSM);
        lblMsg = JKText.getLblDk(msg, JKText.FONT_B_XXSM);
        lblMsg.setTextAlignment(TextAlignment.CENTER);
        lblMsg.setWrapText(true);

        vb.getChildren().addAll(wait, lblWait, lblMsg);

        StackPane stack = new StackPane();
        stack.setMaxSize(w, h);
        stack.setMinSize(w, h);
        lblCount = JKText.getLblDk(Integer.toString(countdownSeconds), JKText.FONT_N_XXSM);
        stack.getChildren().addAll(lblCount);

        StackPane stbusy = new StackPane();
        stbusy.getStyleClass().add("stackContent");
        stbusy.setMaxSize(w, h);
        stbusy.setMinSize(w, h);
        stbusy.getChildren().addAll(vb, stack);

        return stbusy;
    }

    public void showBusy(String message) {
        this.msg = message;
        countdownSeconds = 0;
        lblMsg.setText(msg);
        this.setVisible(true);
        this.toFront();
    }

    public void hideBusy() {
//        countdownSeconds = 0;
        schedCountdown.shutdown();
        lblMsg.setText("");
        this.setVisible(false);
        this.toBack();
    }

    /**
     * Starts a <code>ScheduledExecutorService</code> which reduces the countdown by 1 in 1-second intervals. If the
     * <code>Task</code> is successfully completed, the <code>ScheduledExecutorService</code> is stopped. If the
     * <code>Task</code> is cancelled by another process, the ProgressIndicator is hidden and a message is logged. If
     * the countdown reaches zero and the <code>Task</code> is still running, the <code>Task</code> is cancelled, the
     * ProgressIndicator is hidden, and a message is logged.
     *
     * @param task      the Task that must be cancelled if the countdown reaches zero
     * @param countdown the number of seconds to be counted down - may be different for various processes
     */
    public void startCountdown(final Task task, final int countdown) {
        if (schedCountdown != null) {
            schedCountdown.shutdown();
        }
        this.countdownSeconds = (countdown);
        schedCountdown = Executors.newSingleThreadScheduledExecutor();
        schedCountdown.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        // try-catch was causing counter to show 57 seconds for full cycle.
//                        try {
                        countdownSeconds--;
                        lblCount.setText(Integer.toString(countdownSeconds));
                        if (task.isDone()) {
                            System.out.println("TASK IS DONE : " + task.titleProperty());
                            schedCountdown.shutdown();
                        } else if (task.isCancelled()) {
                            hideBusy();
                            schedCountdown.shutdown();
                            logger.info(" > > >  task is CANCELLED, hiding busy  < < <");
                        } else if (countdownSeconds <= 0) {
                            if (task.isRunning()) {
                                task.cancel();
//                                hideBusy();
//                                schedCountdown.shutdown();
                            }
                            hideBusy();
                            schedCountdown.shutdown();
                            logger.info(" > > >  countdown is ZERO, hiding busy  < < <");
                        }
//                        } catch (Throwable t) {
//                            logger.log(Level.SEVERE, " >>> Failed to process countdown <<< ", t);
//                        } finally {
////                            System.out.println("shutting down schedCountdown");
//                            schedCountdown.shutdown();
//                        }
                    }
                });
            }
        }, 0, 1, TimeUnit.SECONDS);
    }
}
