package jkiosk3.sales.search;

import aeonairtime.AirtimeManufacturer;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.vouchers.VoucherUtil;

import java.util.ArrayList;
import java.util.List;

public class CreateOtherVoucherProduct {

    public static List<SearchProduct> createOtherVoucherProducts() {
        // populate vouchers
        VoucherUtil.getVoucherProvidersList();

        final String OTHER_VOUCHER = "Voucher";

        List<SearchProduct> products = new ArrayList<>();
        for (AirtimeManufacturer airtimeManufacturer : VoucherUtil.getProvidersShow(SaleType.VOUCHER_OTHER)) {
            SearchProduct networkProvider = new SearchProduct();

            networkProvider.setProvName(airtimeManufacturer.getId());
            String airtimeName = airtimeManufacturer.getName();

            networkProvider.setProdName(String.format("%s %s", airtimeName.startsWith("x") ? airtimeName.substring(1) : airtimeName, OTHER_VOUCHER));
            networkProvider.setSearchTransType(SearchTransType.OTHER_VOUCHER);

            products.add(networkProvider);
        }
        return products;
    }
}
