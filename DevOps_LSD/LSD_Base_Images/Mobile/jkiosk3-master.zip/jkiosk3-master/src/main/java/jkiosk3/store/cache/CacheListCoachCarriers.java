package jkiosk3.store.cache;

import aeoncoach.CoachCarriersList;
import jkiosk3.store.Store;

public class CacheListCoachCarriers {

    private static volatile ListCoachCarriers listCoachCarriers;

    private static ListCoachCarriers getCachedListCoachCarriers() {
        if (listCoachCarriers == null) {
            listCoachCarriers = ((ListCoachCarriers) Store.loadObject(CacheListCoachCarriers.class.getSimpleName()));
        }
        if (listCoachCarriers == null) {
            listCoachCarriers = new ListCoachCarriers();
        }
        return listCoachCarriers;
    }

    private static void saveListCoachCarriers(ListCoachCarriers listCoachCarrier) {
        Store.saveObject(CacheListCoachCarriers.class.getSimpleName(), listCoachCarrier);
    }

    public static void saveListCoachCarriers(CoachCarriersList coachCarriersList) {
        getCachedListCoachCarriers();
        listCoachCarriers.setCoachCarriersList(coachCarriersList);

        saveListCoachCarriers(listCoachCarriers);
    }

    public static boolean hasItems() {
        getCachedListCoachCarriers();
        return !listCoachCarriers.getCoachCarriersList().getListCarriers().isEmpty();
    }

    public static CoachCarriersList getListCoachCarriers() {
        getCachedListCoachCarriers();
        return listCoachCarriers.getCoachCarriersList();
    }

    public static void deleteCacheListCoachCarriers() {
        Store.deleteObject(CacheListCoachCarriers.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheListCoachCarriers.class.getSimpleName());
    }
}
