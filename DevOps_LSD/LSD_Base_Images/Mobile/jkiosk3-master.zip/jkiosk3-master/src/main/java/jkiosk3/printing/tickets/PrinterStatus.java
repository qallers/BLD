package jkiosk3.printing.tickets;

import gnu.io.SerialPort;
import javafx.application.Platform;
import jkiosk3.JKiosk3;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;

import java.io.*;
import java.nio.charset.Charset;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PrinterStatus {

    private final static Logger logger = Logger.getLogger(PrinterStatus.class.getSimpleName());

    private SerialPort serialPort;
    private String printerResp;
    private String printerStatus;
    private String msgDescription;
    //    private Timer timer;
    private ResultCallback finalResult;

    public PrinterStatus(SerialPort serialPort) {
        this.serialPort = serialPort;
    }

    public void isPrinterReady(ResultCallback resultCallback) {
        this.finalResult = resultCallback;
        if (isPrinterStatusReady()) {
            System.out.println("Printer status is READY TO PRINT... " + printerStatus);
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    finalResult.onResult(true);
                }
            });
        }
    }

    private boolean isPrinterStatusReady() {
        printerStatus = getPrinterResponse();

        if (printerStatus.equalsIgnoreCase(PrinterResponse.PRINTER_RESPONSE_00.getCode())) {
//            if (timer != null) {
//                timer.cancel();
//            }
            return true;
        } else {
            return false;
        }
    }

    private String getPrinterResponse() {

        String statusRequest = "\n^XSET,IMMEDIATE,1\n~S,STATUS\n";
        byte[] bytes = (statusRequest).getBytes(Charset.defaultCharset());

        printerResp = null;
        String printerStatusStr = "";

        // DO NOT use 'try-with-resources', as we do not want the port closed yet
        try {
            OutputStream printerOutput = serialPort.getOutputStream();
            printerOutput.write(bytes);

            InputStream inputStream = serialPort.getInputStream();

            BufferedReader printerResponse = new BufferedReader(new InputStreamReader(inputStream));

            printerResp = printerResponse.readLine();

            if (printerResp != null && printerResp.length() >= 2) {
                printerStatusStr = printerResp.substring(0, 2);
            }

        } catch (IOException ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
            showPrinterError(ex.getMessage());
        }
        return printerStatusStr;
    }

    private void showPrinterError(final String msg) {
//        if (timer != null) {
//            timer.cancel();
//        }
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                if (printerResp != null) {
                    String msgCode = printerResp.substring(0, 2);
                    msgDescription = "";
                    for (PrinterResponse r : PrinterResponse.values()) {
                        if (msgCode.equalsIgnoreCase(r.getCode())) {
                            msgDescription = r.getDescription();
                            break;
                        }
                    }
                    JKiosk3.getMsgBox().showMsgBox("Ticket Printer Error", msgDescription, null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                @Override
                                public void onOk() {
                                    finalResult.onResult(false);
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Ticket Printer Error",
                            "Unable to connect to Ticket Printer\n\n" + msg, null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                                @Override
                                public void onOk() {
                                    finalResult.onResult(false);
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }
}

//    public void isPrintCompleteAndReset(ResultCallback resultCallback) {
//        this.finalResult = resultCallback;
//        timer = new Timer();
//        timer.scheduleAtFixedRate(new TimerTask() {
//            @Override
//            public void run() {
//                if (isPrinting()) {
//                    // do nothing, continue looping...
//                    System.out.println("Printer is still busy... " + printerStatus);
//                } else {
//                    if (isPrinterStatusReady()) {
//                        System.out.println("Printer is finished, and status is READY... " + printerStatus);
//                        timer.cancel();
//                        Platform.runLater(new Runnable() {
//                            @Override
//                            public void run() {
//                                finalResult.onResult(true);
//                            }
//                        });
//                    }
//                }
//            }
//        }, 3500, 750);
//    }


//    private boolean isPrinting() {
//        printerStatus = getPrinterResponse();
//
//        if (printerStatus.equalsIgnoreCase(PrinterResponse.PRINTER_RESPONSE_50.getCode())) {
//            return true;
//        } else {
//            return false;
//        }
//    }

// HISTORY
//    public PrinterStatus(SerialPort serialPort, ResultCallback result) {
//        this.serialPort = serialPort;
//        this.finalResult = result;
//        isPrinterReady();
//    }

// HISTORY
//    private void isPrinterReady() {
//
//        if (getPrinterStatus()) {
//            // printerRest must be reset to null before next status check
////            printerResp = null;
//////            isPaperReady();
////            Timer timer = new Timer();
////            timer.schedule(new TimerTask() {
////                @Override
////                public void run() {
////                    if (getPrinterStatus()) {
//                        Platform.runLater(new Runnable() {
//                            @Override
//                            public void run() {
//                                finalResult.onResult(true);
//                            }
//                        });
////                    } else {
////                        showPrinterError();
////                    }
////                }
////            }, 1000);
//            // original delay, when doing paper check
////            }, 4250);
////        } else {
////            showPrinterError("");
//        }
//    }

// HISTORY...
//    private void isPaperReady() {
//        logger.info("in isPaperReady()...");
//        String readyMsg = "\n^S7\n^H12\n^R0\n^W54\n^Q200,5,0\n^O0\n^AD\n^D0\n^E13\n^XSET,SENSING,0\n~S,FEED\n^B203\n";
//        byte[] bytes = (readyMsg).getBytes(Charset.defaultCharset());
//
//        // DO NOT use 'try-with-resources', as we do not want the port closed yet
//        try {
//            OutputStream printerOutput = serialPort.getOutputStream();
//            printerOutput.write(bytes);
//
//            // No response for this, returns zero bytes.  Just feeds paper forward, and back.
//
//        } catch (IOException ex) {
//            logger.log(Level.SEVERE, ex.getMessage(), ex);
//        }
//    }


//            readyMsg = "^S7\n^H12\n^R0\n^W54\n^Q200,5,0\n^O0\n^AD\n^D0\n^E13\n^XSET,SENSING,0\n~S,FEED\n^B203\n";
// ^S7\n                - speed setting         - S7 = 177.8 mm/s
// ^H12\n               - print darkness        - 00 - 19
// ^R0\n                - row column adjustment - 0 - 399 dots
// ^W54\n               - label width setting   - unit: mm
// ^Q200,5,0\n          - label length          - x = label length, y = black mark width, z = black line to top of form position
// ^O0\n                - label dispenser (peel)    - 0 = disable, 1 = enable dispenser, 2 = enable applicator
// ^AD\n                - printing mode         - D = direct thermal, T = thermal transfer
// ^D0\n                - number of labels per cut  - 0 = disable cutting, 1 - 32767 = number of labels
// ^E13\n               - stop position setting - 0 - 40 mm
// ^XSET,SENSING,0\n    - assign reflect or see-through sensor mode be a detector while using continuous label  - 0 = reflect, 1 = see-through, 2 = none
// ~S,FEED\n            - FEED = same as push Feed key once, PAUSE = same as pause key... etc.
// ^B203\n";            - set backward length   - 1 - 1000 mm


//     This one is to check if the printer is connected,basically if the device can communicate with it
//    public boolean checkUSBReadyStatus() {
//
//        try {
//            byte[] printerStatus = getUSBPrinterStatus(false);
//            // We just check for a "00" response in the first 2 characters,
//            // 48 or 0x30 = "0", ie 00,00000 = OK
//            return printerStatus != null && ((printerStatus[0] == 48) && (printerStatus[1] == 48));
//        } catch (Exception exception) {
////            Log.d(TAG, "Unable to checkUSBReadyStatus: " + exception);
//            logger.log(Level.SEVERE, exception.getMessage(), exception);
//        }
//
//        return false;
//    }
//
//    /*
//        Gets the USB status information, we can probably make an abstract class for usb printers,
//        of which you subclass the different printers and their specific commands, but someone needs
//        to stick their hands in the air...  (waiting...)
//        This applies to the Inani DT2 EZPL Printer at the moment - probably needs to make this more
//        generic so that it can do other printers as well, just saying
//        ~S,STATUS - return format: "aa,nnnnn<CR><LF>" = 10 bytes
//     */
//    public byte[] getUSBPrinterStatus(Boolean quietMode) {
//        byte[] printerResponse;
////        Log.d(TAG, "trying to getUSBPrinterStatus");
//        try {
//            String readyMsg;
//            if (quietMode) {
//                readyMsg = "~S,STATUS\n";
//            } else {
//                readyMsg = "^XSET,IMMEDIATE,1\n~S,STATUS\n";
//            }
//            return callUSBPrinterCommand(readyMsg, 10);
//        } catch (Exception exception) {
////            activity.logger.error("can't get printer status " + exception);
////            Log.d(TAG, "can't get printer status " + exception);
//            logger.log(Level.SEVERE, exception.getMessage(), exception);
//        }
//        return new byte [] {57,57};		// 57 = "9"
//    }
//
////    /*
////        Call the USB Printer with the specified `command`, returns a byte[] with the response
////        for the command.  You need to specify the size of the response that will be received for
////        the command that will be executed
////     */
////    private byte[] callUSBPrinterCommand(String command, Integer cmdResponseSize) {
////        UsbRequest outRequest = null;
////        UsbRequest inRequest = null;
////        try {
////            ByteBuffer requestMsg = ByteBuffer.wrap(command.getBytes());
////            ByteBuffer responseMsg = ByteBuffer.allocate(cmdResponseSize);
////            byte[] response = null;
////            if (checkUSBConnectivity()) {
////                outRequest = getOutRequest();
////                inRequest = getInRequest();
////                if (outRequest.queue(requestMsg, requestMsg.remaining())) {
////                    if (connection.requestWait() == outRequest) {
////                        Log.d(TAG, "USB STATUS CHECK - wrote: " + requestMsg.position());
////                        if (cmdResponseSize > 0) {						// Check if this command needs a response message
////                            if (inRequest.queue(responseMsg, responseMsg.limit())) {
////                                if (connection.requestWait() == inRequest) {
////                                    Log.d(TAG, "USB STATUS CHECK - received: " + responseMsg.position() + " = " + new String(responseMsg.array()));
////                                    if (responseMsg.position() > 0) {
////                                        response = responseMsg.array();
////                                    }
////                                }
////                            } else {
////                                Log.d(TAG, "USB STATUS CHECK (IN) request queue failed !!");
////                                connection.close();
////                                connection = null;        // Reset the connection status just in case
////                                securePrinter = null;
////                            }
////                        }
////                    }
////                } else {
////                    Log.d(TAG, "USB STATUS CHECK (OUT) request queue failed !!");
////                    connection.close();
////                    connection = null;        // Reset the connection status just in case
////                    securePrinter = null;
////                }
////            }
////            return response;
////        } catch (Exception exception) {
////            if ( activity != null && activity.logger != null )
////                activity.logger.error("can't get printer status " + exception);
////            return null;
////        } finally {
////            if ( outRequest != null )
////                outRequest.close();
////            if ( inRequest != null )
////                inRequest.close();
////        }
////    }
//
//    // And this one checks if there is paper
//    public boolean checkUSBPrinterPaperAvailable() {
//
//        try {
//            String readyMsg;
//            byte[] cmdResponse;
//
//            // so this is not a very good solution, but solves our current requirement of proving that a ticket
//            // has been printed for putco but for different label sizes this will break things (^Q Setting)
//            readyMsg = "^S7\n^H12\n^R0\n^W54\n^Q200,5,0\n^O0\n^AD\n^D0\n^E13\n^XSET,SENSING,0\n~S,FEED\n^B203\n";
////                            readyMsg = "^S7\n~S,FEED\n^B203\n";
////            Log.d(TAG, "Checking for out of paper on printer - top of form command");
//
//            callUSBPrinterCommand(readyMsg, 0);
//
//            // We need to wait for the top of form printer command to finish before we try for a status, this is not
//            // really the best way of waiting for this to happen...
//            //Thread.sleep(Integer.parseInt(activity.getResources().getString(R.string.putcoPaperCheckSleepTime)));
//            Thread.sleep(Integer.parseInt(activity.getPreference(activity.PREF_PUTCO_PAPER_CHECK_SLEEP_TIME)));
//            readyMsg = "~S,STATUS\n";                           // Speed (max), Feed to top of form, backup 203mm
////            Log.d(TAG, "Checking status after top of form command");;
//
//            cmdResponse = callUSBPrinterCommand(readyMsg, 10);
//
//            return ((cmdResponse[0] == 48) && (cmdResponse[1] == 48));
//
//        } catch (Exception exception) {
//            activity.logger.error("checkUSBPrinterPaperAvailable exception: " + exception);
////            Log.d(TAG, "checkUSBPrinterPaperAvailable exception: " + exception);
//            logger.log(Level.SEVERE, exception.getMessage(), exception);
//
//            return false;
//        }
//    }
//
//    // This one gets the error message from the printer
//    public String getUSBPrinterErrorString() {
//
//        byte[] printerResponse = getUSBPrinterStatus(true);
//
//        String printerErrorString = new String(printerResponse);
//
//        // Check if the error is in our hashmap
//        if ( hmPrinterErrorStrings.containsKey(printerErrorString.substring(0,2)) ) {
//            return hmPrinterErrorStrings.get(printerErrorString.substring(0,2));
//        } else {
//            return "Unknown Error";
//        }
//    }
//
//    // And the full implimanation
//    protected boolean checkUSBPrinter(boolean checkPaperAvailable) {
//        BluDroidUSBPrint usbPrint = null;
//        if (isRunningInEmulator()) {
////             usbPrint = new USBMockPrinter(this, ticket);
//            usbPrint = new BluDroidUSBPrint(this, ticket);
//        } else {
//            usbPrint = new BluDroidUSBPrint(this, ticket);
//        }
//
//        try {
//            if (!usbPrint.checkUSBReadyStatus()) {
//                createAlertDialog("USB Printer Error",
//                        "Unable to communicate with the USB printer: " + usbPrint.getUSBPrinterErrorString());
//                return false;
//            }
//
//            if (checkPaperAvailable) {
//                if (!usbPrint.checkUSBPrinterPaperAvailable()) {
//                    createAlertDialog("USB Printer Paper check failed",
//                            "USB Printer Error: " + usbPrint.getUSBPrinterErrorString());
//                    return false;
//                }
//            }
//
//        } catch (Exception exception) {
////            Log.d(TAG, "checkUSBPrinter Exception " + exception);
//            logger.log(Level.SEVERE, exception.getMessage(), exception);
//            createAlertDialog("USB Printer Error",
//                    "Unable to communicate with the USB printer, please restore communication before continuing");
//            return false;
//        } finally {
//            usbPrint.unregisterReceiver();
//        }
//
//        return true;
//    }
