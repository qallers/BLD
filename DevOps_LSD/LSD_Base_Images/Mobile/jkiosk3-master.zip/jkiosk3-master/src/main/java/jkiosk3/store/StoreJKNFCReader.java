package jkiosk3.store;

import za.co.blt.NFCReaders;

import java.io.Serializable;

public class StoreJKNFCReader implements Serializable {

    // S(tore) = 19 : (1 + 9 = 10) (1 + 0 = 1)
    // J(K)  = 10 : (1 + 0 = 1)
    // N(FC) = 14  :  (1 + 4 = 5)
    // R(eader) = 18 : (1 + 8 = 9)
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 991159L;

    private boolean nfcCardRead = false;
    private NFCReaders nfcReaderModel = NFCReaders.ACR122U;

    public boolean isNfcCardRead() {
        return nfcCardRead;
    }

    public void setNfcCardRead(boolean nfcCardRead) {
        this.nfcCardRead = nfcCardRead;
    }

    public NFCReaders getNfcReaderModel() {
        return nfcReaderModel;
    }

    public void setNfcReaderModel(NFCReaders nfcReaderModel) {
        this.nfcReaderModel = nfcReaderModel;
    }
}
