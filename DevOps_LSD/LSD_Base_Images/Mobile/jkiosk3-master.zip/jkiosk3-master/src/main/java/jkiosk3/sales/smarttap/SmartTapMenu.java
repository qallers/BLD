package jkiosk3.sales.smarttap;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class SmartTapMenu extends Region {

    private final static Logger logger = Logger.getLogger(SmartTapMenu.class.getName());

    public SmartTapMenu() {
        getChildren().add(getMenuGroup());
    }

    private VBox getMenuGroup() {

        VBox vbHead = JKNode.getPageHeadVB("SmartTap Menu");

        List<Button> listBtns = getMenuButtons();

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listBtns);

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private List<Button> getMenuButtons() {
        List<Button> btnList = new ArrayList<>();

        List<String> btnLabels = new ArrayList<>();
        btnLabels.add("SmartTap Bus");
        btnLabels.add("SmartTap Wallet");

        for (String s : btnLabels) {
            final Button btn = JKNode.getBtnSmDbl(s);
            btn.setId(s);
            btn.getStyleClass().add("prov_VAS_fix");
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        return btnList;
    }

    private void getMenuAction(Button b) {

        logger.info(("SmartTap menu option selected : ").concat(b.getId()));

        switch (b.getText()) {
            case "SmartTap Bus":
                break;
            case "SmartTap Wallet":
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Error", "Invalid selection", null);
        }
    }
}
