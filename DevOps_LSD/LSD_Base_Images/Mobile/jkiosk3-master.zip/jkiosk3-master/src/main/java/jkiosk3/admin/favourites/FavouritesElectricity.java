package jkiosk3.admin.favourites;

import aeonfavourites.FavouriteItem;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.layout.*;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.admin.favourites.fav_cache.CacheFavouriteCustomStore;
import jkiosk3.admin.favourites.fav_cache.JKFavouriteSetup;
import jkiosk3.sales.SalesItems;
import jkiosk3.sales.electricity.ElectricityProvider;

import java.util.ArrayList;
import java.util.List;

public class FavouritesElectricity extends Region {

    private List<FavouriteItem> listFavouriteCache;
    private List<FavouriteItem> listFavouriteUpdate;
    private List<FavouriteItem> listFavouriteTemp;
    private List<ElectricityProvider> listProvidersForUser;
    private List<Node> listChkNodes;
    private Label lblListSize;
    private StackPane stackPane;
//    private final static double PG_HT = 525;
    private final static double PG_HT = 535;
    private final static int PG_SIZE = 10;
    private int maxCount;

    public FavouritesElectricity() {
        this.listFavouriteCache = CacheFavouriteCustomStore.getListFavouriteItems();
        this.listFavouriteUpdate = new ArrayList<>();
        this.listFavouriteTemp = new ArrayList<>();
        this.maxCount = JKFavouriteSetup.getFavouriteSetupStore().getCountElectricity();

        for (FavouriteItem f : listFavouriteCache) {
            if (f.getTrxGroup().equalsIgnoreCase("Electricity")) {
                listFavouriteTemp.add(f);
            } else {
                listFavouriteUpdate.add(f);
            }
        }

        this.listProvidersForUser = SalesItems.getElecSuppliers();
        this.stackPane = JKLayout.getStackFavouriteSelect(PG_HT);

//        if (listFavouriteTemp.size() > maxCount) {
//            listFavouriteTemp = listFavouriteTemp.subList(0, maxCount);
//        }

        if (listProvidersForUser != null && !listProvidersForUser.isEmpty()) {
            SceneFavourites.checkMenuButtonsDisable(SceneFavourites.SELECT_ELECTRICITY, true);
            getChildren().addAll(getFavouriteElectricityLayout());
        } else {
            JKiosk3.getMsgBox().showMsgBox("Electricity Provider Error", "No Electricity Providers found", null,
                    MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            JKiosk3.changeScene(new SceneFavourites());
                        }

                        @Override
                        public void onCancel() {

                        }
                    });
        }
    }

    private VBox getFavouriteElectricityLayout() {
        getProductCheckBoxes();

        Label lblHead1 = JKText.getLblDk("Select Electricity Favourites", JKText.FONT_B_24);
        lblListSize = JKText.getLblDk(Integer.toString(listFavouriteTemp.size()), JKText.FONT_B_20);
        if (listFavouriteTemp.size() > maxCount) {
            lblListSize.setStyle("-fx-text-fill: #ff0000;");
        } else {
            lblListSize.setStyle("-fx-text-fill: #0F224E;");
        }
        Label lblHead2 = JKText.getLblDk(" of " + maxCount, JKText.FONT_B_20);
        HBox hbCount = JKLayout.getHBox(0, JKLayout.spNum);
        hbCount.getChildren().addAll(lblListSize, lblHead2);
        VBox vbHeader = JKNode.getPageDblHeadVB(0, lblHead1, hbCount);

        VBox vbContent = JKLayout.getVBoxContent(JKLayout.spNum);
        VBox vbHead = JKNode.getPageHeadVB("Select Electricity Favourites");

        vbContent.getChildren().addAll(vbHeader, stackPane, getBtnControls());

//        VBox vbPage = JKLayout.getVBox(0, JKLayout.spNum);
//        vbPage.getChildren().addAll(vbContent, getBtnControls());

        return vbContent;
    }

    private ControlButtonsFavList getBtnControls() {
        ControlButtonsFavList ctrl = new ControlButtonsFavList();
        ctrl.getBtnSave().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                saveUpdatedFavourites();
            }
        });
        ctrl.getBtnCancel().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneFavourites.checkMenuButtonsDisable(SceneFavourites.SELECT_ELECTRICITY, false);
                SceneFavourites.clearAndChangeContent(null);
            }
        });
        return ctrl;
    }

//    private ControlButtonsFav getBtnControls() {
//        ControlButtonsFav ctrl = new ControlButtonsFav();
//        ctrl.getBtnSave().setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                saveUpdatedFavourites();
//            }
//        });
//        return ctrl;
//    }

    private void getProductCheckBoxes() {
        listChkNodes = getListElectricityFavs();

        createPagedItems();
    }

    private List<Node> getListElectricityFavs() {
        List<Node> listChkProvs = new ArrayList<>();
        for (final ElectricityProvider p : listProvidersForUser) {
            final CheckBox chk = new CheckBox(p.getDisplayName());
            for (FavouriteItem i : listFavouriteCache) {
                if (i.getTrxGroup().equalsIgnoreCase("Electricity")
                        && i.getTrxType().equals(p.getTransactionType())) {
                    chk.setSelected(true);
                    break;
                }
            }
            chk.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    if (chk.isSelected()) {
                        addProduct(chk, p);
                    } else if (!chk.isSelected()) {
                        removeProduct(p);
                    }
                }
            });
            listChkProvs.add(chk);
        }

        return listChkProvs;
    }

    private void createPagedItems() {

        int numPgs = 0;
        if (listChkNodes.isEmpty()) {
            numPgs = 1;
        } else if (listChkNodes.size() % PG_SIZE == 0) {
            numPgs = listChkNodes.size() / PG_SIZE;
        } else {
            numPgs = (listChkNodes.size() / PG_SIZE) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedVBox(pg, listChkNodes, PG_SIZE, PG_HT);
            }
        });

        stackPane.getChildren().add(pages);
    }

    private void addProduct(CheckBox checkBox, ElectricityProvider prov) {
        if (!isProductInList(prov)) {
            FavouriteItem favouriteItem = new FavouriteItem();
            favouriteItem.setTrxGroup(SceneFavourites.TRX_GROUP_ELECTRICITY);
            favouriteItem.setTrxType(prov.getTransactionType());
            if (listFavouriteTemp.size() < maxCount) {
                listFavouriteTemp.add(favouriteItem);
            } else {
                JKiosk3.getMsgBox().showMsgBox("Maximum Count Exceeded",
                        "\nA total of " + maxCount + " Electricity Providers can be selected."
                                + "\n\nRemove another Electricity Provider and click 'Save' first,"
                                + "\nor change settings in 'Favourites Preferences'", null);
                checkBox.setSelected(false);
            }
            lblListSize.setText(Integer.toString(listFavouriteTemp.size()));
            if (listFavouriteTemp.size() > maxCount) {
                lblListSize.setStyle("-fx-text-fill: #ff0000;");
            } else {
                lblListSize.setStyle("-fx-text-fill: #0F224E;");
            }
        }
    }

    private void removeProduct(ElectricityProvider prov) {
        if (isProductInList(prov)) {
            for (FavouriteItem f : listFavouriteTemp) {
                if (f.getTrxGroup().equalsIgnoreCase("Electricity")
                        && f.getTrxType().equals(prov.getTransactionType())) {
                    listFavouriteTemp.remove(f);
                    break;
                }
            }
            lblListSize.setText(Integer.toString(listFavouriteTemp.size()));
            if (listFavouriteTemp.size() > maxCount) {
                lblListSize.setStyle("-fx-text-fill: #ff0000;");
            } else {
                lblListSize.setStyle("-fx-text-fill: #0F224E;");
            }
        }
    }

    private boolean isProductInList(ElectricityProvider prov) {
        FavouriteItem favItem = null;
        for (FavouriteItem f : listFavouriteTemp) {
            if (f.getTrxGroup().equalsIgnoreCase("Electricity")
                    && f.getTrxType().equals(prov.getTransactionType())) {
                favItem = f;
                break;
            }
        }
        if (favItem != null) {
            return true;
        } else {
            return false;
        }
    }

    private void saveUpdatedFavourites() {
        if (!listFavouriteTemp.isEmpty()) {
            listFavouriteUpdate.addAll(listFavouriteTemp);
            listFavouriteCache = listFavouriteUpdate;
            if (CacheFavouriteCustomStore.saveFavouriteStore(listFavouriteCache)) {
//                SceneFavourites.clearAndChangeContent(new FavouritesElectricity());
                SceneFavourites.checkMenuButtonsDisable(SceneFavourites.SELECT_ELECTRICITY, false);
                SceneFavourites.clearAndChangeContent(null);
            }
        } else {
            JKiosk3.getMsgBox().showMsgBox("Custom Favourites", "Please add at least 1 product to the list", null);
        }
    }
}
