package jkiosk3.sales.electricity.eskom;

import aeonelectricity.ElectricityConfirmation;
import aeonelectricity.ElectricityConnection;
import aeonelectricity.ElectricityMeter;
import aeonelectricity.ElectricityVoucher;

import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.MagCardData;
import jkiosk3.printing.PrintUtil;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.electricity.ElecConfirm;
import jkiosk3.sales.electricity.ElecEnterMeter;
import jkiosk3.sales.electricity.ElecEnterMeterResult;
import jkiosk3.sales.electricity.ElecShareBtnsLessMore;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.users.UserUtil;

public class ElecReprint extends Region {

    private ElectricityConnection connection;
    private ElectricityConfirmation confirmation;
    private final ElectricityProvider provider;
    private String meterNum;
    private ElecEnterMeter gMeter;
    private String reprintEvent;

    public ElecReprint(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;
        if (provider.getTransactionType ().contains ("Eskom")) {
            this.reprintEvent = "OnlineReprint";
        } else {
            this.reprintEvent = "Reprint";
        }
        System.out.println ("Provider = " + provider.getTransactionType () + " :: Reprint event = " + reprintEvent);
        getChildren ().add (getReprintLayout ());
    }

    private VBox getReprintLayout() {
        gMeter = new ElecEnterMeter (provider, ElectricityUtil.ELEC_REPRINT, new ElecEnterMeterResult () {
            @Override
            public void onDone() {
                if (gMeter.isMagEntry ()) {
                    System.out.println ("onDone : meter number entered : " + gMeter.getMeterNum ());
                    System.out.println ("onDone : did we read mag card? : " + gMeter.isMagEntry ());
                }
            }
        });
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().addAll (gMeter, getElecSaleCtrls ());
        return vb;
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        ElecShareBtnsLessMore btnsLessMore = new ElecShareBtnsLessMore ();

        btnsLessMore.getBtnAccept ().setDisable (false);
        btnsLessMore.getBtnAccept ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                getMeterConfirmation ();
            }
        });
        btnsLessMore.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });
        return btnsLessMore;
    }

    private void getMeterConfirmation() {
        if (validateInput ()) {
            final ElectricityMeter meter = new ElectricityMeter ();
            if (gMeter.isMagEntry ()) {
                meter.setTrack2data (meterNum);
            } else {
                meter.setMeterNum (meterNum);
            }

            String transType = provider.getTransactionType ();
            System.out.println ("electricity reprint - transType = " + transType);

//            ElectricityUtil.getElectricityConfirmation(transType, "OnlineReprint", meter, 0, new ElectricityUtil.ElectricityConfirm() {
            ElectricityUtil.getElectricityConfirmation (transType, reprintEvent, meter, 0, new ElectricityUtil.ElectricityConfirm () {
                @Override
                public void electricityConfirm(ElectricityConnection connect, final ElectricityConfirmation confirm) {
                    if (confirm.isSuccess ()) {
                        connection = connect;
                        confirmation = confirm;

                        ElecConfirm confirmGrid = new ElecConfirm (confirmation, meter, 0, ElectricityUtil.ELEC_REPRINT);

                        JKiosk3.getMsgBox ().showMsgBox ("Electricity Meter Confirmation", "Reprint", confirmGrid,
                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                                    @Override
                                    public void onOk() {
                                        requestReprint ();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("Unable to Confirm", !confirm.getAeonErrorText ().isEmpty () ?
                                        "A" + confirm.getAeonErrorCode () + " - " + confirm.getAeonErrorText () :
                                        "B" + confirm.getErrorCode () + " - " + confirm.getErrorText (),
                                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                    @Override
                                    public void onOk() {
                                        ElectricityUtil.resetElectricity ();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    }
                    ElectricityUtil.resetElectricity ();
                }
            });
        }
    }

    private void requestReprint() {
//        ElectricityUtil.getElectricityVoucherReprint(connection, "OnlineReprint", meterNum, null,
        ElectricityUtil.getElectricityVoucherReprint (connection, reprintEvent, meterNum, null,
                new ElectricityUtil.ElectricityResult () {
                    @Override
                    public void electricityResult(ElectricityVoucher voucher) {
                        if (voucher.isSuccess ()) {
                            final List<MagCardData> magList = ElectricityUtil.getMagCardTokens (voucher);
                            if (JKPrintOptions.getPrintOptions ().isPrintPreview ()) {
                                JKiosk3.getPrintPreview ().showPrintPreview ("Electricity Voucher Reprint", voucher.getPrintLines (),
                                        PrintPreview.PRN_OK_CANCEL, new PrintPreviewResult () {
                                            @Override
                                            public void onOk() {
                                                PrintUtil.writeMagCardTokens (magList, null);
                                            }

                                            @Override
                                            public void onCancel() {
                                                //
                                            }
                                        });
                            } else {
                                PrintUtil.sendToPrinter (voucher.getPrintLines ());
                                PrintUtil.writeMagCardTokens (magList, null);
                            }
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("Electricity Voucher Reprint", !voucher.getAeonErrorText ().isEmpty () ?
                                    "A" + voucher.getAeonErrorCode () + " - " + voucher.getAeonErrorText () :
                                    "B" + voucher.getErrorCode () + " - " + voucher.getErrorText (), null);
                        }
                        ElectricityUtil.resetElectricity ();
                    }
                });
    }

    private boolean validateInput() {
        meterNum = gMeter.getMeterNum ().trim ();
        if (meterNum.equals ("") || meterNum == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Meter Number", "Meter Number cannot be blank.\n"
                    + "Please enter Meter Number.", null);
            return false;
        }
        return true;
    }
}
