package jkiosk3._components;

import MagCard.LomaMR3;
import MagCard.MSRE206;
import MagCard.MagCard;
import MagCard.MagEncoders;
import static MagCard.MagEncoders.MSRE206;
import MagCard.MagReadListener;
import MagCard.MagWriteListener;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.printing.MagCardData;
import jkiosk3.store.JKCardReader;

/**
 *
 * @author Val
 */
public class MagCardPrompt extends Region implements MagWriteListener, MagReadListener {

    private final static Logger logger = Logger.getLogger(MagCardPrompt.class.getName());
    private boolean isTest;
    //
    public final static String CARD_METER = "Meter Card (plastic)";
    public final static String CARD_TOKEN = "Token Card(s) (paper)";
    //
    private MagEncoders selectedEncoder;
    //
    private Label lblContent;
    private int cardNum;
    private int cardTotal;
    private List<MagCardData> cardList;
    private MagCardPromptResult result;
    private MagCard magEncoder;
    private VBox vbox;
    private Label lblHead;
    private Label lblCardType;
    private TextField txtMagRead;
    private Button btnOK;
    private Button btnTestRead;
    private Button btnTestWrite;
    private Button btnClose;
    private HBox hbBtns;

    public MagCardPrompt() {
        getChildren().add(getMagCardStack());
    }

    private StackPane getMagCardStack() {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getMagCardGrp());

        return stack;
    }

    private Group getMagCardGrp() {
        double w = 600;

        Group grp = new Group();

        Rectangle rec = new Rectangle();
        rec.setWidth(w);

        vbox = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
        vbox.setPrefWidth(w);

        lblHead = JKText.getLblDk("Mag Card Encoding", JKText.FONT_B_SM);
        lblCardType = JKText.getLblDk("", JKText.FONT_B_SM);

        lblContent = JKText.getLblDk("Please swipe Card " + cardNum + " of " + cardTotal, JKText.FONT_B_XSM);
        lblContent.setTextAlignment(TextAlignment.CENTER);

        txtMagRead = new TextField();
        txtMagRead.setMaxWidth(450);
        txtMagRead.setMinWidth(450);

        btnOK = JKNode.getBtnMsgBox("OK");
        btnOK.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onOkBtnEvent();
            }
        });

        btnTestRead = JKNode.getBtnMsgBox("Test Read");
        btnTestRead.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickedTestRead();
            }
        });

        btnTestWrite = JKNode.getBtnMsgBox("Test Write");
        btnTestWrite.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                writeCards();
            }
        });

        btnClose = JKNode.getBtnMsgBox("Done");
        btnClose.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onCloseBtnEvent();
            }
        });

        hbBtns = JKLayout.getHBox(0, JKLayout.sp);
        hbBtns.setPrefWidth(w);
        hbBtns.getChildren().addAll(btnOK, btnTestRead, btnTestWrite, btnClose);

        vbox.getChildren().addAll(lblHead, new Separator(), lblContent, new Separator(), hbBtns);

        rec.heightProperty().bind(vbox.heightProperty());

        grp.getChildren().addAll(rec, vbox);

        return grp;
    }

    private void onOkBtnEvent() {
        cardNum++;
        if (cardNum <= cardTotal) {
            System.out.println("==============================================");
            System.out.println("card " + cardNum + " : track1 to write : " + cardList.get(cardNum - 1).getTrack1());
            System.out.println("card " + cardNum + " : track2 to write : " + cardList.get(cardNum - 1).getTrack2());
            System.out.println("card " + cardNum + " : track3 to write : " + cardList.get(cardNum - 1).getTrack3());
            System.out.println("==============================================");
            lblContent.setText("Writing : Please swipe Card " + cardNum + " of " + cardTotal);
            magEncoder.writeCard(
                    cardList.get(cardNum - 1).getTrack1(),
                    cardList.get(cardNum - 1).getTrack2(),
                    cardList.get(cardNum - 1).getTrack3());
        } else {
            stopMagEncoder();
            logger.info(" > > > NON-TEST  -  ALL CARDS WRITTEN  -  MOVING TO onCloseBtnEvent() < < < ");
            btnOK.setDisable(true);
            onCloseBtnEvent();
        }
    }

    private void onCloseBtnEvent() {
        btnOK.setDisable(false);
        logger.info(" > > >  onCloseBtnEvent() < < <");
        setVisible(false);
        toBack();
        stopMagEncoder();
        if (result != null) {
            result.onDone();
        }
    }

    public void onCloseWithoutResult() {
        setVisible(false);
        toBack();
        stopMagEncoder();
    }

    private void onClickedTestRead() {
        btnTestWrite.setDisable(true);
        txtMagRead.setText("");
        lblHead.setText("Mag Card Encoding : " + selectedEncoder.getDisplayName());
        lblContent.setText("Please swipe test card to be read.\n"
                + "Click 'Test Read' again to test more cards.");

        vbox.getChildren().clear();
        vbox.getChildren().addAll(lblHead, lblCardType, new Separator(), lblContent, txtMagRead, new Separator(), hbBtns);

        magEncoder = getMagCardWriter();
        magEncoder.readCard();
    }

    private void writeCards() {
        if (isTest) {
            btnTestRead.setDisable(true);
            lblHead.setText("Mag Card Encoding : " + selectedEncoder.getDisplayName());
        } else {
            hbBtns.getChildren().clear();
            hbBtns.getChildren().addAll(btnOK, btnClose);
        }

        vbox.getChildren().clear();
        vbox.getChildren().addAll(lblHead, lblCardType, new Separator(), lblContent, new Separator(), hbBtns);

        magEncoder = getMagCardWriter();
        cardNum = 0;
        cardTotal = cardList.size();

        onOkBtnEvent();
    }

    private MagCard getMagCardWriter() {
        try {
            if (magEncoder == null) {
                logger.info(" > > > START OF getMagCardWriter() - MAG ENCODER IS NULL");
                switch (selectedEncoder) {
                    case LOMAMR3:
                        magEncoder = new LomaMR3();
                        break;
                    case MSRE206:
                        magEncoder = new MSRE206();
                        break;
                    default:
                        JKiosk3.getMsgBox().showMsgBox("Mag Card Encoder", "Unable to initialise Mag Card Encoder\n\n"
                                + "Check settings in 'Setup'", null);
                }
                if (magEncoder != null) {
                    magEncoder.connect(JKCardReader.getCardReaderConfig().getMagCardPort(),
                            JKCardReader.getCardReaderConfig().getMagCardBaud());
                    magEncoder.setReadListener(this);
                    magEncoder.setWriteListener(this);
                }
            } else {
                logger.info(" > > > INSIDE getMagCardWriter() - MAG ENCODER IS NOT NULL");
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
            JKiosk3.getMsgBox().showMsgBox("Mag Card Encoder", "Unable to initialise Mag Card Encoder\n\n"
                    + e.getMessage(), null);
        }
        return magEncoder;
    }

    public void showMagCodePromptBox(String cardType, List<MagCardData> cardList, MagCardPromptResult res, boolean isTestRW) {
        this.cardList = cardList;
        this.result = res;
        this.isTest = isTestRW;

        selectedEncoder = JKCardReader.getCardReaderConfig().getMagCardType();

        lblCardType.setText(cardType);
        hbBtns.getChildren().clear();

        if (isTest) {
            btnTestRead.setDisable(false);
            btnTestWrite.setDisable(false);
            lblContent.setText("Please select 'Test Read' or 'Test Write'.\n\n"
                    + "For 'Test Read' please have \n a pre-written readable card available.\n\n"
                    + "For 'Test Write' please have \n 2 writable cards available.\n");
            hbBtns.getChildren().addAll(btnTestRead, btnTestWrite, btnClose);
            vbox.getChildren().clear();
            vbox.getChildren().addAll(lblHead, lblCardType, new Separator(), lblContent, new Separator(), hbBtns);
        } else {
            writeCards();
        }

        this.setVisible(true);
        this.toFront();
    }

    public void stopMagEncoder() {
        if (magEncoder != null) {
            magEncoder.stop();
            magEncoder = null;
            logger.info("STOPPED MAG ENCODER");
        }
    }

    @Override
    public void wroteMagCard(boolean success) {
        if (success) {
            logger.info(("wroteMagCard() is TRUE? : ").concat(Boolean.toString(success)));
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    onOkBtnEvent();
                }
            });
        } else {
            logger.info(("wroteMagCard() is FALSE? : ").concat(Boolean.toString(success)));
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getMsgBox().showMsgBox("Error Writing Card", "Writing Failed", null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    writeCards();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            });
        }
    }

    @Override
    public void readMagCard(boolean success, final String string, final String string1, final String string2) {
        if (success) {
            logger.info(">>> MAG CARD READ SUCCESS <<<");
            if (string != null || string1 != null || string2 != null) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        // set content of text field to Track 2 data
                        txtMagRead.setText(string1);
                        logger.info(string.concat(" : ").concat(string1).concat(" : ").concat(string2));
                    }
                });
            }
        } else {
            logger.info(">>> MAG CARD READ FAILURE <<<");
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getMsgBox().showMsgBox("Error Reading Card", "Reading Failed", null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    if (isTest) {
                                        onClickedTestRead();
                                    } else {
                                        //
                                    }
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            });
        }
    }

    public static List<MagCardData> getTestList() {
        List<MagCardData> testDataList = new ArrayList<>();
        System.out.println("cards in testList BEFORE adding fake stuff = " + testDataList.size());
        if (testDataList.isEmpty()) {
//            track2.append("600727");
//            track2.append(meter.getMeterNum());
//            track2.append(luhnEnc(track2.toString()));
//            track2.append("===");
//            track2.append(meter.getMeterTt() == null ? "01"
//                    : meter.getMeterTt());
//            track2.append(meter.getMeterAlg() == null ? "07"
//                    : meter.getMeterAlg());
//            track2.append(meter.getMeterSgc() == null ? "000000"
//                    : meter.getMeterSgc());
//            track2.append(meter.getMeterTi() == null ? "07"
//                    : meter.getMeterTi());
//            track2.append(meter.getMeterKrn() == null ? "1"
//                    : meter.getMeterKrn());
            // make some test 'cards', add to list for checking...
            MagCardData card1 = new MagCardData();
            card1.setTrack1("011");
            card1.setTrack2("0111111111111===11110001");
//            card1.setTrack2("60072711111111111===0107000000071");     // as per 'real' values above
            card1.setTrack3("1111222233334444");        // 16 digit token number
            testDataList.add(card1);
            MagCardData card2 = new MagCardData();
            card2.setTrack1("");
            card2.setTrack2("0222222222222===22220002");
            card2.setTrack3("11112222333344445555");    // 20 digit token number
            testDataList.add(card2);
            System.out.println("card1 added to list: " + card1.getTrack1() + card1.getTrack2() + card1.getTrack3());
            System.out.println("card2 added to list: " + card2.getTrack1() + card2.getTrack2() + card2.getTrack3());
        }
        return testDataList;
    }

    public Button getBtnOK() {
        return btnOK;
    }

    public Button getBtnClose() {
        return btnClose;
    }
}
