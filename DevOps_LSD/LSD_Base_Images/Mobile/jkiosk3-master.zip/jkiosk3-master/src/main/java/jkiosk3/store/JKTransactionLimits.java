package jkiosk3.store;

/**
 *
 * @author valeriew
 */
public class JKTransactionLimits {
    
    private static StoreJKTransactionLimits jkTransactionLimits;

    public static StoreJKTransactionLimits getTransactionLimits() {
        if (jkTransactionLimits == null) {
            jkTransactionLimits = ((StoreJKTransactionLimits) Store.loadObject(JKTransactionLimits.class.getSimpleName()));
        }
        if (jkTransactionLimits == null) {
            jkTransactionLimits = new StoreJKTransactionLimits();
        }
        return jkTransactionLimits;
    }

    public static boolean saveTransactionLimits(StoreJKTransactionLimits transactionLimits) {
        getTransactionLimits();
        return Store.saveObject(JKTransactionLimits.class.getSimpleName(), transactionLimits);
    }    
}
