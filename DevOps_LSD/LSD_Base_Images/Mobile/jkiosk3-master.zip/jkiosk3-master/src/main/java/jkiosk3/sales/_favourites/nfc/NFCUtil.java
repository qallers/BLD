package jkiosk3.sales._favourites.nfc;

import aeonusers.User;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3._components.SceneBackground;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.UserUtil;
import jkiosk3.utilities.TaskUtil;
import za.co.blt.consumer.loyalty.api.service.constants.UrlPaths;
import za.co.blt.consumer.loyalty.api.service.model.request.ConsumerProfileRequest;
import za.co.blt.consumer.loyalty.api.service.model.response.CompleteConsumerProfile;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfile;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfileIdentifier;
import za.co.blt.consumer.loyalty.api.service.model.response.Error;

import javax.ws.rs.core.MediaType;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NFCUtil {

    private final static Logger logger = Logger.getLogger(NFCUtil.class.getName());

    public final static String NFC_EXISTING = "Existing Subscriber";
    public final static String NFC_NEW = "New Subscriber";
    public final static String NFC_FAVOURITES = "View Subscriber Favourites";
    public final static String NFC_REGISTER = "Register New Subscriber";
    public final static String NFC_EDIT = "Edit Subscriber";
    public final static String NFC_LOST_CARD = "Replace Lost Card";
    public final static String NFC_CANCEL = "Cancel Subscriber";
    public final static String QUERY_BY_CARD = "loyaltycard";
    public final static String QUERY_BY_CELL = "mobilenumber";

    private final static TaskUtil TASK_UTIL = new TaskUtil();
    private final static int COUNTDOWN_TIME = 30;
    private final static int COUNTDOWN_WS = 10000;

    private final static String USERNAME = "jkiosk";
    private final static String PASSWORD_QA = "kvvedhp5u76jeksa0d7c8649mk";          // Dev and QA
    private final static String PASSWORD_LIVE = "ul3ljsh5tq8tnkmd0hoa4hf4bv";        // LIVE
    private static String password;

    static final Client REST_CLIENT;

    static {
        REST_CLIENT = Client.create();

        if (JK3Config.getServerPath().contains("aeonbld")) {
            password = PASSWORD_LIVE;
        } else {
            password = PASSWORD_QA;
        }

        REST_CLIENT.addFilter(new LoggingFilter());
        REST_CLIENT.addFilter(new HTTPBasicAuthFilter(USERNAME, password));
    }

//    private static String getPath() {
//        return JK3Config.getLoyaltyPath();
//    }

    private static ConsumerProfileIdentifier createConsumerProfile(ConsumerProfileRequest request) {
        request.setDeviceId(JKSystem.getSystemConfig().getDeviceId());
        request.setDeviceUserId(CurrentUser.getSalesUser().getUserId());

        ConsumerProfileIdentifier consumerProfileIdentifier = null;

        try {
            WebResource webResource = REST_CLIENT.resource(getPath() + UrlPaths.CREATE_CONSUMER_PROFILE);

            webResource.setProperty(ClientConfig.PROPERTY_CONNECT_TIMEOUT, 2000);
            webResource.setProperty(ClientConfig.PROPERTY_READ_TIMEOUT, COUNTDOWN_WS);

            consumerProfileIdentifier = webResource
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE)
                    .post(ConsumerProfileIdentifier.class, request);
            logger.info(("Consumer Profile created with ID : ").concat(consumerProfileIdentifier.toString()));
        } catch (UniformInterfaceException e) {
            // HTTP 400 & 500 errors.  Status code 404 will not have an Error object in the message body!
            if (e.getResponse().getStatus() == 400 || e.getResponse().getStatus() == 500) {
                showNFCError("Register Subscriber", e.getResponse().getEntity(Error.class));
                logger.log(Level.SEVERE, Integer.toString(e.getResponse().getStatus()), e);
            } else {
                showNFCError("Register Subscriber", null);
            }
        } catch (ClientHandlerException e) {
            // Connection & Timeout
            showNFCException("Register Subscriber", e);
            logger.log(Level.SEVERE, e.getMessage(), e);
        }

        return consumerProfileIdentifier;
    }

    private static ConsumerProfile readConsumerProfile(String queryBy, String queryNumber) {
        ConsumerProfile consumerProfile = null;

        String urlPath = "";
        if (queryBy.equals(QUERY_BY_CARD)) {
            urlPath = UrlPaths.GET_CONSUMER_PROFILE_BY_LOYALTY_CARD;
        } else if (queryBy.equals(QUERY_BY_CELL)) {
            urlPath = UrlPaths.GET_CONSUMER_PROFILE_BY_MOBILE_NUMBER;
        }
        try {
            WebResource webResource = REST_CLIENT.resource(getPath() + urlPath);

            webResource.setProperty(ClientConfig.PROPERTY_CONNECT_TIMEOUT, 2000);
            webResource.setProperty(ClientConfig.PROPERTY_READ_TIMEOUT, COUNTDOWN_WS);

            consumerProfile = webResource.queryParam(queryBy, queryNumber)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE)
                    .get(ConsumerProfile.class);
            System.out.println(consumerProfile);
        } catch (UniformInterfaceException e) {
            // HTTP 400 & 500 errors.  Status code 404 will not have an Error object in the message body!
            if (e.getResponse().getStatus() == 400 || e.getResponse().getStatus() == 500) {
                showNFCError("Subscriber Profile", e.getResponse().getEntity(Error.class));
                logger.log(Level.SEVERE, Integer.toString(e.getResponse().getStatus()), e);
                //
            } else if (e.getResponse().getStatus() == 404) {
                showNFCNotFound("Subscriber Profile", "\nSubscriber not found");
            } else {
                showNFCError("Subscriber Profile", null);
            }
        } catch (ClientHandlerException e) {
            // Connection & Timeout
            showNFCException("Subscriber Profile", e);
            logger.log(Level.SEVERE, e.getMessage(), e);
        }

        return consumerProfile;
    }

    private static CompleteConsumerProfile readConsumerProfileComplete(String queryBy, String queryNumber) {
        CompleteConsumerProfile consumerProfile = null;

        String urlPath = "";
        if (queryBy.equals(QUERY_BY_CARD)) {
            urlPath = UrlPaths.GET_CONSUMER_FAVOURITES_BY_LOYALTY_CARD;
        } else if (queryBy.equals(QUERY_BY_CELL)) {
            urlPath = UrlPaths.GET_CONSUMER_FAVOURITES_BY_MOBILE_NUMBER;
        }
        try {
            WebResource webResource = REST_CLIENT.resource(getPath() + urlPath);

            webResource.setProperty(ClientConfig.PROPERTY_CONNECT_TIMEOUT, 2000);
            webResource.setProperty(ClientConfig.PROPERTY_READ_TIMEOUT, COUNTDOWN_WS);

            consumerProfile = webResource.queryParam(queryBy, queryNumber)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE)
                    .get(CompleteConsumerProfile.class);
            System.out.println(consumerProfile);
        } catch (UniformInterfaceException e) {
            // HTTP 400 & 500 errors.  Status code 404 will not have an Error object in the message body!
            if (e.getResponse().getStatus() == 400 || e.getResponse().getStatus() == 500) {
                showNFCError("Subscriber Profile", e.getResponse().getEntity(Error.class));
                logger.log(Level.SEVERE, Integer.toString(e.getResponse().getStatus()), e);
                //
            } else if (e.getResponse().getStatus() == 404) {
                showNFCNotFound("Subscriber Profile", "\nSubscriber not found");
            } else {
                showNFCError("Subscriber Profile", null);
            }
        } catch (ClientHandlerException e) {
            // Connection & Timeout
            showNFCException("Subscriber Profile", e);
            logger.log(Level.SEVERE, e.getMessage(), e);
        }

        return consumerProfile;
    }

    private static boolean updateConsumerProfile(ConsumerProfile consumerProfile, ConsumerProfileRequest consumerProfileRequest) {

        try {
            WebResource webResource = REST_CLIENT.resource(getPath() + UrlPaths.UPDATE_CONSUMER_PROFILE.replace("{profileId}", consumerProfile.getProfileId()));

            webResource.setProperty(ClientConfig.PROPERTY_CONNECT_TIMEOUT, 2000);
            webResource.setProperty(ClientConfig.PROPERTY_READ_TIMEOUT, COUNTDOWN_WS);
            webResource
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE)
                    .put(consumerProfileRequest);
        } catch (UniformInterfaceException e) {
            // HTTP 400 & 500 errors.  Status code 404 will not have an Error object in the message body!
            if (e.getResponse().getStatus() == 400 || e.getResponse().getStatus() == 500) {
                showNFCError("Update Subscriber Profile", e.getResponse().getEntity(Error.class));
                logger.log(Level.SEVERE, Integer.toString(e.getResponse().getStatus()), e);
            } else {
                showNFCError("Update Subscriber Profile", null);
            }
            return false;
        } catch (ClientHandlerException e) {
            // Connection & Timeout
            showNFCException("Update Subscriber Profile", e);
            logger.log(Level.SEVERE, e.getMessage(), e);
            return false;
        }
        return true;
    }

    private static boolean deleteConsumerProfile(User nfcUser, String profileId) {
        try {
            WebResource webResource = REST_CLIENT.resource(getPath() + UrlPaths.DELETE_CONSUMER_PROFILE.replace("{profileId}", profileId));

            webResource.setProperty(ClientConfig.PROPERTY_CONNECT_TIMEOUT, 2000);
            webResource.setProperty(ClientConfig.PROPERTY_READ_TIMEOUT, COUNTDOWN_WS);
            webResource
                    .queryParam("deviceid", Integer.toString(JKSystem.getSystemConfig().getDeviceId()))
                    .queryParam("deviceuserid", Integer.toString(nfcUser.getUserId()))
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .accept(MediaType.APPLICATION_JSON_TYPE)
                    .delete();
        } catch (UniformInterfaceException e) {
            // HTTP 400 & 500 errors.  Status code 404 will not have an Error object in the message body!
            if (e.getResponse().getStatus() == 400 || e.getResponse().getStatus() == 500) {
                showNFCError("Cancel Subscriber", e.getResponse().getEntity(Error.class));
                logger.log(Level.SEVERE, Integer.toString(e.getResponse().getStatus()), e);
            } else {
                showNFCError("Cancel Subscriber", null);
            }
            return false;
        } catch (ClientHandlerException e) {
            // Connection & Timeout
            showNFCException("Cancel Subscriber", e);
            logger.log(Level.SEVERE, e.getMessage(), e);
            return false;
        }
        return true;
    }

    private static void showNFCError(final String errorMsg, final Error error) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                if (error != null) {
                    JKiosk3.getMsgBox().showMsgBox(errorMsg, error.getError() + "\n\n" + error.getMessage(), null);
                } else {
                    JKiosk3.getMsgBox().showMsgBox(errorMsg, "An unknown error occurred", null);
                }
                resetNFCView();
            }
        });
    }

    private static void showNFCException(final String errorMsg, final ClientHandlerException except) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                JKiosk3.getMsgBox().showMsgBox(errorMsg, except.getMessage(), null);
                resetNFCView();
            }
        });
    }

    private static void showNFCNotFound(final String head, final String errorMsg) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                JKiosk3.getMsgBox().showMsgBox(head, errorMsg, null);
                resetNFCView();
            }
        });
    }

    private static void showTaskCancelFail(final String head, final String msg, Worker.State state) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                JKiosk3.getMsgBox().showMsgBox(head, msg, null);
                resetNFCView();
            }
        });
    }

    public static void resetNFCView() {
        SceneSales.clearAndChangeContent(new NFCMenu());
    }

    public static void resetNFCActiveSubscriber() {
        UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            ActiveNFCSubscriber.resetActiveNFCSubscriber();
            SceneBackground.updateSupportView(SceneBackground.getvBoxSupport());
            SceneBackground.setAnchorBackground(false);
            SceneSales.clearAndShowFavourites();
        }
    }

    /*********************/
    /*  Busy indicators  */

    /*********************/

    public static void createConsumerProfile(final ConsumerProfileRequest request, final ConsumerProfileIdentifierResult result) {
        JKiosk3.getBusy().showBusy("Creating Subscriber Registration");

        final Task<ConsumerProfileIdentifier> taskConsumerCreate = new Task<ConsumerProfileIdentifier>() {
            @Override
            protected ConsumerProfileIdentifier call() throws Exception {
                return createConsumerProfile(request);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.consumerProfileIdentifierResult(getValue());
            }

            @Override
            protected void cancelled() {
                showTaskCancelFail("Subscriber Registration",
                        "Subscriber Registration Error", State.CANCELLED);
            }

            @Override
            protected void failed() {
                showTaskCancelFail("Subscriber Registration",
                        "Subscriber Registration Error", State.FAILED);
            }
        };
        new Thread(taskConsumerCreate).start();
        JKiosk3.getBusy().startCountdown(taskConsumerCreate, COUNTDOWN_TIME);
    }

    public static void readConsumerProfile(final String queryBy, final String queryNumber, final ConsumerProfileResult result) {
        JKiosk3.getBusy().showBusy("Reading Subscriber Profile");

        final Task<ConsumerProfile> taskConsumerRead = new Task<ConsumerProfile>() {
            @Override
            protected ConsumerProfile call() throws Exception {
                return readConsumerProfile(queryBy, queryNumber);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.consumerProfileResult(getValue());
            }

            @Override
            protected void cancelled() {
                showTaskCancelFail("Subscriber Profile",
                        "Subscriber Profile Error", State.CANCELLED);
            }

            @Override
            protected void failed() {
                showTaskCancelFail("Subscriber Profile",
                        "Subscriber Profile Error", State.FAILED);
            }
        };
        new Thread(taskConsumerRead).start();
        JKiosk3.getBusy().startCountdown(taskConsumerRead, COUNTDOWN_TIME);
    }

    public static void readConsumerProfileComplete(final String queryBy, final String queryNumber, final CompleteConsumerProfileResult result) {
        JKiosk3.getBusy().showBusy("Reading Subscriber Favourites");

        final Task<CompleteConsumerProfile> taskConsumerRead = new Task<CompleteConsumerProfile>() {
            @Override
            protected CompleteConsumerProfile call() throws Exception {
                return readConsumerProfileComplete(queryBy, queryNumber);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.completeConsumerProfileResult(getValue());
            }

            @Override
            protected void cancelled() {
                showTaskCancelFail("Subscriber Profile",
                        "Subscriber Profile Error", State.CANCELLED);
            }

            @Override
            protected void failed() {
                showTaskCancelFail("Subscriber Profile",
                        "Subscriber Profile Error", State.FAILED);
            }
        };
        new Thread(taskConsumerRead).start();
        JKiosk3.getBusy().startCountdown(taskConsumerRead, COUNTDOWN_TIME);
    }

    public static void updateConsumerProfile(final ConsumerProfile consumerProfile,
                                             final ConsumerProfileRequest consumerProfileRequest, final ConsumerProfileUpdateResult result) {
        JKiosk3.getBusy().showBusy("Updating Subscriber Profile");

        final Task<Boolean> taskConsumerUpdate = new Task<Boolean>() {
            @Override
            protected Boolean call() throws Exception {
                return updateConsumerProfile(consumerProfile, consumerProfileRequest);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.consumerProfileUpdateResult(getValue());
            }

            @Override
            protected void cancelled() {
                showTaskCancelFail("Subscriber Profile Update",
                        "Subscriber Profile Update Error", State.CANCELLED);
            }

            @Override
            protected void failed() {
                showTaskCancelFail("Subscriber Profile Update",
                        "Subscriber Profile Update Error", State.FAILED);
            }
        };
        new Thread(taskConsumerUpdate).start();
        JKiosk3.getBusy().startCountdown(taskConsumerUpdate, COUNTDOWN_TIME);
    }

    public static void deleteConsumerProfile(final User nfcUser, final String profileId, final ConsumerProfileDeleteResult result) {
        JKiosk3.getBusy().showBusy("Deleting Subscriber Profile");

        final Task<Boolean> taskConsumerDelete = new Task<Boolean>() {
            @Override
            protected Boolean call() throws Exception {
                return deleteConsumerProfile(nfcUser, profileId);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.consumerProfileDeleteResult(getValue());
            }

            @Override
            protected void cancelled() {
                showTaskCancelFail("Subscriber Cancel",
                        "Subscriber Cancel Error", State.CANCELLED);
            }

            @Override
            protected void failed() {
                showTaskCancelFail("Subscriber Cancel",
                        "Subscriber Cancel Error", State.FAILED);
            }
        };
        new Thread(taskConsumerDelete).start();
        JKiosk3.getBusy().startCountdown(taskConsumerDelete, COUNTDOWN_TIME);
    }

    /* Abstract classes for results */
    // Create
    public abstract static class ConsumerProfileIdentifierResult {
        public abstract void consumerProfileIdentifierResult(ConsumerProfileIdentifier consumerProfileId);
    }

    // Read
    public abstract static class ConsumerProfileResult {
        public abstract void consumerProfileResult(ConsumerProfile consumerProfile);
    }

    public abstract static class CompleteConsumerProfileResult {
        public abstract void completeConsumerProfileResult(CompleteConsumerProfile completeConsumerProfile);
    }

    // Update
    public abstract static class ConsumerProfileUpdateResult {
        public abstract void consumerProfileUpdateResult(Boolean consumerProfileUpdated);
    }

    // Delete
    public abstract static class ConsumerProfileDeleteResult {
        public abstract void consumerProfileDeleteResult(Boolean consumerProfileDeleted);
    }

    // delete from here once all works...

    //    private final static Logger logger = Logger.getLogger(NFCUtil.class.getName());
//
//    public final static String NFC_EXISTING = "Existing Subscriber";
//    public final static String NFC_NEW = "New Subscriber";
//    public final static String NFC_FAVOURITES = "View Subscriber Favourites";
//    public final static String NFC_REGISTER = "Register New Subscriber";
//    public final static String NFC_EDIT = "Edit Subscriber";
//    public final static String NFC_LOST_CARD = "Replace Lost Card";
//    public final static String NFC_CANCEL = "Cancel Subscriber";
//    public final static String QUERY_BY_CARD = "loyaltycard";
//    public final static String QUERY_BY_CELL = "mobilenumber";
//
//    private final static TaskUtil TASK_UTIL = new TaskUtil();
//    private final static int COUNTDOWN_TIME = 30;
//    private final static int COUNTDOWN_WS = 10000;
//
//    private final static String USERNAME = "jkiosk";
//    private final static String PASSWORD_QA = "kvvedhp5u76jeksa0d7c8649mk";        // Dev and QA
//    private final static String PASSWORD_LIVE = "ul3ljsh5tq8tnkmd0hoa4hf4bv";        // LIVE
//    private static String versionPassword;
//
//    static final Client REST_CLIENT;
//
//    static {
//        REST_CLIENT = Client.create();
//        REST_CLIENT.addFilter(new LoggingFilter());
//        versionPassword = getPwdVersion();
//        REST_CLIENT.addFilter(new HTTPBasicAuthFilter(USERNAME, versionPassword));
//    }
//
//    private static String getPwdVersion() {
//        String pwd = "";
//        if (JK3Config.getServerPath().contains("aeonbld")) {
//            pwd = PASSWORD_LIVE;
//        } else {
//            pwd = PASSWORD_QA;
//        }
//        return pwd;
//    }
//
    private static String getPath() {
        return JK3Config.getLoyaltyPath();
    }
//
//    private static ConsumerProfileIdentifier createConsumerProfile(ConsumerProfileRequest request) {
//        request.setDeviceId(JKSystem.getSystemConfig().getDeviceId());
//        request.setDeviceUserId(CurrentUser.getSalesUser().getUserId());
//
//        ConsumerProfileIdentifier consumerProfileIdentifier = null;
//
//        try {
//            WebResource webResource = REST_CLIENT.resource(getPath() + UrlPaths.CREATE_CONSUMER_PROFILE);
//
//            webResource.setProperty(ClientConfig.PROPERTY_CONNECT_TIMEOUT, 2000);
//            webResource.setProperty(ClientConfig.PROPERTY_READ_TIMEOUT, COUNTDOWN_WS);
//
//            consumerProfileIdentifier = webResource
//                    .type(MediaType.APPLICATION_JSON_TYPE)
//                    .accept(MediaType.APPLICATION_JSON_TYPE)
//                    .post(ConsumerProfileIdentifier.class, request);
//            logger.info(("Consumer Profile created with ID : ").concat(consumerProfileIdentifier.toString()));
//        } catch (UniformInterfaceException e) {
//            // HTTP 400 & 500 errors.  Status code 404 will not have an Error object in the message body!
//            if (e.getResponse().getStatus() == 400 || e.getResponse().getStatus() == 500) {
//                showNFCError("Register Subscriber", e.getResponse().getEntity(Error.class));
//                logger.log(Level.SEVERE, Integer.toString(e.getResponse().getStatus()), e);
//            } else {
//                showNFCError("Register Subscriber", null);
//            }
//        } catch (ClientHandlerException e) {
//            // Connection & Timeout
//            showNFCException("Register Subscriber", e);
//            logger.log(Level.SEVERE, e.getMessage(), e);
//        }
//
//        return consumerProfileIdentifier;
//    }
//
//    private static ConsumerProfile readConsumerProfile(String queryBy, String queryNumber) {
//        ConsumerProfile consumerProfile = null;
//
//        String urlPath = "";
//        if (queryBy.equals(QUERY_BY_CARD)) {
//            urlPath = UrlPaths.GET_CONSUMER_PROFILE_BY_LOYALTY_CARD;
//        } else if (queryBy.equals(QUERY_BY_CELL)) {
//            urlPath = UrlPaths.GET_CONSUMER_PROFILE_BY_MOBILE_NUMBER;
//        }
//        try {
//            WebResource webResource = REST_CLIENT.resource(getPath() + urlPath);
//
//            webResource.setProperty(ClientConfig.PROPERTY_CONNECT_TIMEOUT, 2000);
//            webResource.setProperty(ClientConfig.PROPERTY_READ_TIMEOUT, COUNTDOWN_WS);
//
//            consumerProfile = webResource.queryParam(queryBy, queryNumber)
//                    .type(MediaType.APPLICATION_JSON_TYPE)
//                    .accept(MediaType.APPLICATION_JSON_TYPE)
//                    .get(ConsumerProfile.class);
//            System.out.println(consumerProfile);
//        } catch (UniformInterfaceException e) {
//            // HTTP 400 & 500 errors.  Status code 404 will not have an Error object in the message body!
//            if (e.getResponse().getStatus() == 400 || e.getResponse().getStatus() == 500) {
//                showNFCError("Subscriber Profile", e.getResponse().getEntity(Error.class));
//                logger.log(Level.SEVERE, Integer.toString(e.getResponse().getStatus()), e);
//                //
//            } else if (e.getResponse().getStatus() == 404) {
//                showNFCNotFound("Subscriber Profile", "\nSubscriber not found");
//            } else {
//                showNFCError("Subscriber Profile", null);
//            }
//        } catch (ClientHandlerException e) {
//            // Connection & Timeout
//            showNFCException("Subscriber Profile", e);
//            logger.log(Level.SEVERE, e.getMessage(), e);
//        }
//
//        return consumerProfile;
//    }
//
//    private static CompleteConsumerProfile readConsumerProfileComplete(String queryBy, String queryNumber) {
//        CompleteConsumerProfile consumerProfile = null;
//
//        String urlPath = "";
//        if (queryBy.equals(QUERY_BY_CARD)) {
//            urlPath = UrlPaths.GET_CONSUMER_FAVOURITES_BY_LOYALTY_CARD;
//        } else if (queryBy.equals(QUERY_BY_CELL)) {
//            urlPath = UrlPaths.GET_CONSUMER_FAVOURITES_BY_MOBILE_NUMBER;
//        }
//        try {
//            WebResource webResource = REST_CLIENT.resource(getPath() + urlPath);
//
//            webResource.setProperty(ClientConfig.PROPERTY_CONNECT_TIMEOUT, 2000);
//            webResource.setProperty(ClientConfig.PROPERTY_READ_TIMEOUT, COUNTDOWN_WS);
//
//            consumerProfile = webResource.queryParam(queryBy, queryNumber)
//                    .type(MediaType.APPLICATION_JSON_TYPE)
//                    .accept(MediaType.APPLICATION_JSON_TYPE)
//                    .get(CompleteConsumerProfile.class);
//            System.out.println(consumerProfile);
//        } catch (UniformInterfaceException e) {
//            // HTTP 400 & 500 errors.  Status code 404 will not have an Error object in the message body!
//            if (e.getResponse().getStatus() == 400 || e.getResponse().getStatus() == 500) {
//                showNFCError("Subscriber Profile", e.getResponse().getEntity(Error.class));
//                logger.log(Level.SEVERE, Integer.toString(e.getResponse().getStatus()), e);
//                //
//            } else if (e.getResponse().getStatus() == 404) {
//                showNFCNotFound("Subscriber Profile", "\nSubscriber not found");
//            } else {
//                showNFCError("Subscriber Profile", null);
//            }
//        } catch (ClientHandlerException e) {
//            // Connection & Timeout
//            showNFCException("Subscriber Profile", e);
//            logger.log(Level.SEVERE, e.getMessage(), e);
//        }
//
//        return consumerProfile;
//    }
//
//    private static boolean updateConsumerProfile(ConsumerProfile consumerProfile, ConsumerProfileRequest consumerProfileRequest) {
//
//        try {
//            WebResource webResource = REST_CLIENT.resource(getPath() + UrlPaths.UPDATE_CONSUMER_PROFILE.replace("{profileId}", consumerProfile.getProfileId()));
//
//            webResource.setProperty(ClientConfig.PROPERTY_CONNECT_TIMEOUT, 2000);
//            webResource.setProperty(ClientConfig.PROPERTY_READ_TIMEOUT, COUNTDOWN_WS);
//            webResource
//                    .type(MediaType.APPLICATION_JSON_TYPE)
//                    .accept(MediaType.APPLICATION_JSON_TYPE)
//                    .put(consumerProfileRequest);
//        } catch (UniformInterfaceException e) {
//            // HTTP 400 & 500 errors.  Status code 404 will not have an Error object in the message body!
//            if (e.getResponse().getStatus() == 400 || e.getResponse().getStatus() == 500) {
//                showNFCError("Update Subscriber Profile", e.getResponse().getEntity(Error.class));
//                logger.log(Level.SEVERE, Integer.toString(e.getResponse().getStatus()), e);
//            } else {
//                showNFCError("Update Subscriber Profile", null);
//            }
//            return false;
//        } catch (ClientHandlerException e) {
//            // Connection & Timeout
//            showNFCException("Update Subscriber Profile", e);
//            logger.log(Level.SEVERE, e.getMessage(), e);
//            return false;
//        }
//        return true;
//    }
//
//    private static boolean deleteConsumerProfile(User nfcUser, String profileId) {
//        try {
//            WebResource webResource = REST_CLIENT.resource(getPath() + UrlPaths.DELETE_CONSUMER_PROFILE.replace("{profileId}", profileId));
//
//            webResource.setProperty(ClientConfig.PROPERTY_CONNECT_TIMEOUT, 2000);
//            webResource.setProperty(ClientConfig.PROPERTY_READ_TIMEOUT, COUNTDOWN_WS);
//            webResource
//                    .queryParam("deviceid", Integer.toString(JKSystem.getSystemConfig().getDeviceId()))
//                    .queryParam("deviceuserid", Integer.toString(nfcUser.getUserId()))
//                    .type(MediaType.APPLICATION_JSON_TYPE)
//                    .accept(MediaType.APPLICATION_JSON_TYPE)
//                    .delete();
//        } catch (UniformInterfaceException e) {
//            // HTTP 400 & 500 errors.  Status code 404 will not have an Error object in the message body!
//            if (e.getResponse().getStatus() == 400 || e.getResponse().getStatus() == 500) {
//                showNFCError("Cancel Subscriber", e.getResponse().getEntity(Error.class));
//                logger.log(Level.SEVERE, Integer.toString(e.getResponse().getStatus()), e);
//            } else {
//                showNFCError("Cancel Subscriber", null);
//            }
//            return false;
//        } catch (ClientHandlerException e) {
//            // Connection & Timeout
//            showNFCException("Cancel Subscriber", e);
//            logger.log(Level.SEVERE, e.getMessage(), e);
//            return false;
//        }
//        return true;
//    }
//
//    private static void showNFCError(String errorMsg, Error error) {
//        Platform.runLater(new Runnable() {
//            @Override
//            public void run() {
//                if (error != null) {
//                    JKiosk3.getMsgBox().showMsgBox(errorMsg, error.getError() + "\n\n" + error.getMessage(), null);
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox(errorMsg, "An unknown error occurred", null);
//                }
//                resetNFCView();
//            }
//        });
//    }
//
//    private static void showNFCException(String errorMsg, ClientHandlerException except) {
//        Platform.runLater(new Runnable() {
//            @Override
//            public void run() {
//                JKiosk3.getMsgBox().showMsgBox(errorMsg, except.getMessage(), null);
//                resetNFCView();
//            }
//        });
//    }
//
//    private static void showNFCNotFound(String head, String errorMsg) {
//        Platform.runLater(new Runnable() {
//            @Override
//            public void run() {
//                JKiosk3.getMsgBox().showMsgBox(head, errorMsg, null);
//                resetNFCView();
//            }
//        });
//    }
//
//    private static void showTaskCancelFail(String head, String msg, Worker.State state) {
//        Platform.runLater(new Runnable() {
//            @Override
//            public void run() {
//                JKiosk3.getMsgBox().showMsgBox(head, msg, null);
//                resetNFCView();
//            }
//        });
//    }
//
//    public static void resetNFCView() {
//        SceneSales.clearAndChangeContent(new NFCMenu());
//    }
//
//    public static void resetNFCActiveSubscriber() {
//        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
//            ActiveNFCSubscriber.resetActiveNFCSubscriber();
//            SceneBackground.updateSupportView(SceneBackground.getvBoxSupport());
//            SceneBackground.setAnchorBackground(false);
//            SceneSales.clearAndChangeContent(null);
//        }
//    }
//
//    /*********************/
//    /*  Busy indicators  */
//
//    /*********************/
//
//    public static void createConsumerProfile(ConsumerProfileRequest request, ConsumerProfileIdentifierResult result) {
//        JKiosk3.getBusy().showBusy("Creating Subscriber Registration");
//
//        final Task<ConsumerProfileIdentifier> taskConsumerCreate = new Task<ConsumerProfileIdentifier>() {
//            @Override
//            protected ConsumerProfileIdentifier call() throws Exception {
//                return createConsumerProfile(request);
//            }
//
//            @Override
//            protected void succeeded() {
//                JKiosk3.getBusy().hideBusy();
//                result.consumerProfileIdentifierResult(getValue());
//            }
//
//            @Override
//            protected void cancelled() {
//                showTaskCancelFail("Subscriber Registration",
//                        "Subscriber Registration Error", State.CANCELLED);
//            }
//
//            @Override
//            protected void failed() {
//                showTaskCancelFail("Subscriber Registration",
//                        "Subscriber Registration Error", State.FAILED);
//            }
//        };
//        new Thread(taskConsumerCreate).start();
//        JKiosk3.getBusy().startCountdown(taskConsumerCreate, COUNTDOWN_TIME);
//    }
//
//    public static void readConsumerProfile(String queryBy, String queryNumber, ConsumerProfileResult result) {
//        JKiosk3.getBusy().showBusy("Reading Subscriber Profile");
//
//        final Task<ConsumerProfile> taskConsumerRead = new Task<ConsumerProfile>() {
//            @Override
//            protected ConsumerProfile call() throws Exception {
//                return readConsumerProfile(queryBy, queryNumber);
//            }
//
//            @Override
//            protected void succeeded() {
//                JKiosk3.getBusy().hideBusy();
//                result.consumerProfileResult(getValue());
//            }
//
//            @Override
//            protected void cancelled() {
//                showTaskCancelFail("Subscriber Profile",
//                        "Subscriber Profile Error", State.CANCELLED);
//            }
//
//            @Override
//            protected void failed() {
//                showTaskCancelFail("Subscriber Profile",
//                        "Subscriber Profile Error", State.FAILED);
//            }
//        };
//        new Thread(taskConsumerRead).start();
//        JKiosk3.getBusy().startCountdown(taskConsumerRead, COUNTDOWN_TIME);
//    }
//
//    public static void readConsumerProfileComplete(String queryBy, String queryNumber, CompleteConsumerProfileResult result) {
//        JKiosk3.getBusy().showBusy("Reading Subscriber Favourites");
//
//        final Task<CompleteConsumerProfile> taskConsumerRead = new Task<CompleteConsumerProfile>() {
//            @Override
//            protected CompleteConsumerProfile call() throws Exception {
//                return readConsumerProfileComplete(queryBy, queryNumber);
//            }
//
//            @Override
//            protected void succeeded() {
//                JKiosk3.getBusy().hideBusy();
//                result.completeConsumerProfileResult(getValue());
//            }
//
//            @Override
//            protected void cancelled() {
//                showTaskCancelFail("Subscriber Profile",
//                        "Subscriber Profile Error", State.CANCELLED);
//            }
//
//            @Override
//            protected void failed() {
//                showTaskCancelFail("Subscriber Profile",
//                        "Subscriber Profile Error", State.FAILED);
//            }
//        };
//        new Thread(taskConsumerRead).start();
//        JKiosk3.getBusy().startCountdown(taskConsumerRead, COUNTDOWN_TIME);
//    }
//
//    public static void updateConsumerProfile(ConsumerProfile consumerProfile,
//                                             ConsumerProfileRequest consumerProfileRequest, ConsumerProfileUpdateResult result) {
//        JKiosk3.getBusy().showBusy("Updating Subscriber Profile");
//
//        final Task<Boolean> taskConsumerUpdate = new Task<Boolean>() {
//            @Override
//            protected Boolean call() throws Exception {
//                return updateConsumerProfile(consumerProfile, consumerProfileRequest);
//            }
//
//            @Override
//            protected void succeeded() {
//                JKiosk3.getBusy().hideBusy();
//                result.consumerProfileUpdateResult(getValue());
//            }
//
//            @Override
//            protected void cancelled() {
//                showTaskCancelFail("Subscriber Profile Update",
//                        "Subscriber Profile Update Error", State.CANCELLED);
//            }
//
//            @Override
//            protected void failed() {
//                showTaskCancelFail("Subscriber Profile Update",
//                        "Subscriber Profile Update Error", State.FAILED);
//            }
//        };
//        new Thread(taskConsumerUpdate).start();
//        JKiosk3.getBusy().startCountdown(taskConsumerUpdate, COUNTDOWN_TIME);
//    }
//
//    public static void deleteConsumerProfile(User nfcUser, String profileId, ConsumerProfileDeleteResult result) {
//        JKiosk3.getBusy().showBusy("Deleting Subscriber Profile");
//
//        final Task<Boolean> taskConsumerDelete = new Task<Boolean>() {
//            @Override
//            protected Boolean call() throws Exception {
//                return deleteConsumerProfile(nfcUser, profileId);
//            }
//
//            @Override
//            protected void succeeded() {
//                JKiosk3.getBusy().hideBusy();
//                result.consumerProfileDeleteResult(getValue());
//            }
//
//            @Override
//            protected void cancelled() {
//                showTaskCancelFail("Subscriber Cancel",
//                        "Subscriber Cancel Error", State.CANCELLED);
//            }
//
//            @Override
//            protected void failed() {
//                showTaskCancelFail("Subscriber Cancel",
//                        "Subscriber Cancel Error", State.FAILED);
//            }
//        };
//        new Thread(taskConsumerDelete).start();
//        JKiosk3.getBusy().startCountdown(taskConsumerDelete, COUNTDOWN_TIME);
//    }
//
//    /* Abstract classes for results */
//    // Create
//    public abstract static class ConsumerProfileIdentifierResult {
//        public abstract void consumerProfileIdentifierResult(ConsumerProfileIdentifier consumerProfileId);
//    }
//
//    // Read
//    public abstract static class ConsumerProfileResult {
//        public abstract void consumerProfileResult(ConsumerProfile consumerProfile);
//    }
//
//    public abstract static class CompleteConsumerProfileResult {
//        public abstract void completeConsumerProfileResult(CompleteConsumerProfile completeConsumerProfile);
//    }
//
//    // Update
//    public abstract static class ConsumerProfileUpdateResult {
//        public abstract void consumerProfileUpdateResult(Boolean consumerProfileUpdated);
//    }
//
//    // Delete
//    public abstract static class ConsumerProfileDeleteResult {
//        public abstract void consumerProfileDeleteResult(Boolean consumerProfileDeleted);
//    }
}
