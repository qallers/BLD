package jkiosk3.sales.billpay.sapo;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.sapo.SapoPayConfReq;
import aeonbillpayments.sapo.SapoPayConfResp;
import aeonbillpayments.sapo.SapoPayReq;
import aeonbillpayments.sapo.SapoPayResp;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales._favourites.nfc.NFCUtilFav;
import jkiosk3.sales.billpay.*;
import jkiosk3.sales.billpay.BillPayUtilSAPO.SapoBillPaymentConfirm;
import jkiosk3.sales.billpay.BillPayUtilSAPO.SapoBillPaymentResponse;
import jkiosk3.sales.billpay._common.BillPaymentSelect;
import jkiosk3.store.JKTransactionLimits;
import jkiosk3.users.UserUtil;

public class InputSAPOBillPay extends Region {

    private final static Logger logger = Logger.getLogger (InputSAPOBillPay.class.getName ());
    // input components
    private TextField txtAccNum;
    private TextField txtAccNum2;
    private ComboBox cbNumber;
    private TextField txtAmount;
    private TextField txtAmountDue;
    // JKiosk components
    private JKTenderToggles tenders;
    private InputSAPOEskom inputEskom;
    private InputSAPOTelkom inputTelkom;
    // collected info
    private final int addFields;
    private String accountNum;
    private double amount;
    private double amountDue;
    private String tenderType;
    private String additionalString;
    private String accountStr;
    //
    private String entry1;
    private String entry2;
    private String accountNumberConfirmed;
    // AeonLib objects
    private BillPaymentConnection connection;
    private final BillPayProduct product;
    private SapoPayReq req;
    private SapoPayResp response;
    private BillPaySAPOAddFields addFieldObject;
    private boolean showFavourites;
    private boolean showProductFavourite;
    private double inputW;

    public InputSAPOBillPay(BillPayProduct p, boolean isNFCFavourite, boolean isProductFavourite) {
        this.product = p;
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;
        this.inputW = ((JKLayout.contentW - (3 * JKLayout.sp)) / 2);

        addFields = product.getAdditionalFields ();

        logger.info (("additionalFields value for the selected product : ").concat (Integer.toString (addFields)));

        VBox vb = JKLayout.getVBox (0, 5);

        vb.getChildren ().add (getAccountPaymentEntryGroup ());
        vb.getChildren ().add (getNav ());

        getChildren ().add (vb);
    }

    private void checkAccNumFav() {
        if (!NFCUtilFav.getBillPayAccNumsFav (product).isEmpty ()) {
            List<String> listAccNums = NFCUtilFav.getBillPayAccNumsFav (product);
            cbNumber = new ComboBox ();
            cbNumber.setMaxWidth (inputW);
            cbNumber.setMinWidth (inputW);
            cbNumber.setEditable (true);
            cbNumber.setItems (FXCollections.observableArrayList (listAccNums));
            cbNumber.getEditor ().setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event event) {
                    JKiosk3.getNumPad ().showNumPad (cbNumber.getEditor (), "Account Number", "", new NumberPadResult () {
                        @Override
                        public void onDone(String value) {
                            accountNumberConfirmed = value;
                        }
                    });
                }
            });
            cbNumber.getSelectionModel ().selectedItemProperty ().addListener (new ChangeListener<String> () {
                @Override
                public void changed(ObservableValue observable, String oldValue, String newValue) {
                    accountNumberConfirmed = newValue;
                    txtAccNum.setText (accountNumberConfirmed);
                    txtAccNum2.setText (accountNumberConfirmed);
                    System.out.println ("accountNumberConfirmed = " + accountNumberConfirmed);
                }
            });
        }
    }

    private GridPane getAccountPaymentEntryGroup() {

        Label lblAccountPayment = JKText.getLblContentHead ("Account Payment");

        ImageView img = BillPayUtilMisc.getImageViewBillPay ("prov_SAPO.png");
        Label lblProdName = JKText.getLblDk (product.getProdName (), JKText.FONT_B_XSM);

        HBox hb = JKLayout.getHBoxLeft (0, JKLayout.sp);
        hb.setPrefWidth (JKLayout.contentW - (2 * JKLayout.sideW));
        hb.getChildren ().addAll (img, lblProdName);

        Label lblAccountNum = JKText.getLblDk ("Account Number", JKText.FONT_B_XSM);

        Label lblAmount = JKText.getLblDk ("Amount", JKText.FONT_B_XSM);

        // additional field Labels
        Label lblAmountDue = JKText.getLblDk ("Amount Due", JKText.FONT_B_XSM);

        txtAccNum = new TextField ();
        txtAccNum.setPromptText ("Enter Account Number");
        txtAccNum.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getKeyboard ().showKeyboard (txtAccNum, "Enter Account Number", "", false, false, new KeyboardResult () {

                    @Override
                    public void onDone(String value) {
                        if (!value.trim ().equals ("")) {
                            if (accountNumberConfirmed != null) {
                                if (!value.trim ().equals (entry2)) {
                                    JKiosk3.getMsgBox ().showMsgBox ("Account Number", "Account Numbers do not match", null);
                                    resetInputs ();
                                }
                            } else // City of Joburg    - prod ID 49
                            // HomeChoice Lay By - prod ID 67
                            {
                                if ((product.getProdId () == 49) || (product.getProdId () == 67)) {
                                    if (value.trim ().length () == 9) {
                                        entry1 = value.trim ();
                                        txtAccNum2.setDisable (false);
                                    } else {
                                        JKiosk3.getMsgBox ().showMsgBox (product.getProdName (), "\nPlease enter a valid 9 digit Account Number", null);
                                        txtAccNum.setText ("");
                                        txtAccNum2.setDisable (true);
                                    }
                                } else {
                                    entry1 = value.trim ();
                                    txtAccNum2.setDisable (false);
                                }
                            }
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("Account Number", "Account Number cannot be empty", null);
                        }
                    }
                });
//                }
            }
        });

        txtAccNum2 = new TextField ();
        txtAccNum2.setPromptText ("Re-enter Account Number");
        txtAccNum2.setDisable (true);
        txtAccNum2.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                txtAccNum.setVisible (false);
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getKeyboard ().showKeyboard (txtAccNum2, "Re-enter Account Number", "", false, false, new KeyboardResult () {

                    @Override
                    public void onDone(String value) {
                        entry2 = value.trim ();
                        checkEnteredDetails ();
                    }
                });
//                }
            }
        });

        txtAmount = JKNode.getTextFieldRight ();

        txtAmount.setPromptText ("Enter Amount to pay");
        txtAmount.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad ().showNumPad (txtAmount, "Enter Amount Due", "", new NumberPadResult () {
                    @Override
                    public void onDone(String value) {
                        amount = SalesUtil.getAmountAsDouble (value, txtAmount);
                    }
                });
//                }
            }
        });

        // additional field TextFields
//        inputTelkom = new InputSAPOTelkom();
//        inputEskom = new InputSAPOEskom(showFavourites);
//
        txtAmountDue = JKNode.getTextFieldRight ();

        txtAmountDue.setPromptText ("Enter Amount Due");
        txtAmountDue.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad ().showNumPad (txtAmountDue, "Enter Amount Due", "", new NumberPadResult () {
                    @Override
                    public void onDone(String value) {
                        amountDue = SalesUtil.getAmountAsDouble (value, txtAmountDue);
                    }
                });
//                }
            }
        });

        // need all components created before adding to grid
        checkAccNumFav ();

        GridPane grid = JKLayout.getGridContent2Col (0.5, 0.5);

        grid.add (lblAccountPayment, 0, 0, 2, 1);
        grid.add (hb, 0, 1, 2, 1);
        grid.add (JKNode.createGridSpanSep (2), 0, 2);

        switch (addFields) {
            case 1:                     // Telkom
                inputTelkom = new InputSAPOTelkom (product, showFavourites, showProductFavourite);
                grid.add (inputTelkom, 0, 4, 2, 1);
                grid.add (getTenderTypes (), 0, 6);
                break;
            case 2:                     // Eskom
                inputEskom = new InputSAPOEskom (product, showFavourites, showProductFavourite);
                grid.add (inputEskom, 0, 4, 2, 1);
                grid.add (getTenderTypes (), 0, 6);
                break;
            case 3:                     // Generic addinal Amount
                if (showFavourites) {
                    grid.addRow (4, lblAccountNum, cbNumber);
                } else {
                    grid.addRow (4, lblAccountNum, txtAccNum);
                }
//                grid.addRow(4, lblAccountNum, txtAccNum);
                grid.addRow (5, new Label (""), txtAccNum2);
                grid.addRow (6, lblAmount, txtAmount);
                grid.add (getTenderTypes (), 0, 8);
                break;
            case 4:                     // Generic addional AmountDue
                if (showFavourites) {
                    grid.addRow (4, lblAccountNum, cbNumber);
                } else {
                    grid.addRow (4, lblAccountNum, txtAccNum);
                }
//                grid.addRow(4, lblAccountNum, txtAccNum);
                grid.addRow (5, new Label (""), txtAccNum2);
                grid.addRow (6, lblAmountDue, txtAmountDue);
                grid.add (getTenderTypes (), 0, 8);
                break;
            default:                    // All other just get the account number as additional field data.
                if (showFavourites) {
                    grid.addRow (4, lblAccountNum, cbNumber);
                } else {
                    grid.addRow (4, lblAccountNum, txtAccNum);
                }
//                grid.addRow(4, lblAccountNum, txtAccNum);
                grid.addRow (5, new Label (""), txtAccNum2);
                grid.addRow (6, lblAmount, txtAmount);
                grid.add (getTenderTypes (), 0, 8);
                break;
        }

//        if (addFields == 1) {               // Telkom
//            grid.add(inputTelkom, 0, 4, 2, 1);
//            grid.add(getTenderTypes(), 0, 6);
//        } else if (addFields == 2) {        // Eskom
//            grid.add(inputEskom, 0, 4, 2, 1);
//            grid.add(getTenderTypes(), 0, 6);
//        } else if (addFields == 3) {        // Generic addinal Amount
//            grid.addRow(4, lblAccountNum, txtAccNum);
//            grid.addRow(5, new Label(""), txtAccNum2);
//            grid.addRow(6, lblAmount, txtAmount);
//            grid.add(getTenderTypes(), 0, 8);
//        } else if (addFields == 4) {        // Generic addional AmountDue
//            grid.addRow(4, lblAccountNum, txtAccNum);
//            grid.addRow(5, new Label(""), txtAccNum2);
//            grid.addRow(6, lblAmountDue, txtAmountDue);
//            grid.add(getTenderTypes(), 0, 8);
//        } else {                            // All other just get the account number as additional field data.
//            grid.addRow(4, lblAccountNum, txtAccNum);
//            grid.addRow(5, new Label(""), txtAccNum2);
//            grid.addRow(6, lblAmount, txtAmount);
//            grid.add(getTenderTypes(), 0, 8);
//        }
        return grid;
    }

    private void checkEnteredDetails() {
        if (entry2.equals (entry1)) {
            accountNumberConfirmed = entry1;
            //
            txtAccNum.setVisible (true);
            txtAccNum.setDisable (true);
            txtAccNum2.setDisable (true);
        } else {
            accountNumberConfirmed = null;
            JKiosk3.getMsgBox ().showMsgBox ("Account Numbers entered do not match", entry1 + " - " + entry2, null);
            resetInputs ();
        }
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new BillPaymentSelect (
                        BillPayUtilMisc.TYPE_BILL_PAY + " Providers", BillPayUtilMisc.TYPE_BILL_PAY));
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                BillPayUtilMisc.resetBillPayView ();
            }
        });
        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private JKTenderToggles getTenderTypes() {
        tenders = new JKTenderToggles (SaleType.BILLPAYMENTS.getDisplay ());
        for (ToggleButton b : tenders.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(javafx.event.Event e) {
                    if (addFields != 1 && addFields != 2) {
                        if (inputValidAccount ()) {
                            tenderType = tenders.getTenderTypeSelected ();
                            makePaymentRequest ();
                        }
                    } else {
                        tenderType = tenders.getTenderTypeSelected ();
                        makePaymentRequest ();
                    }
                }
            });
        }
        return tenders;
    }

    private void makePaymentRequest() {
        req = new SapoPayReq ();
        req.setProviderId (product.getProvId ());
        req.setProductId (product.getProdId ());

        switch (addFields) {
            case 1:                     // Telkom
                if (inputTelkom.isValidInputTelkom ()) {
                    inputTelkom.setAdditionalValues ();
                    amountDue = inputTelkom.getAmountTel ();
                    accountStr = inputTelkom.getAccountStr ();
                    additionalString = inputTelkom.getAdditionalString ();
                    addFieldObject = new BillPaySAPOAddFields ();
                    addFieldObject.setGroupNo (inputTelkom.getGroupNum ());
                    addFieldObject.setSystemNo (inputTelkom.getSystemNum ());
                    addFieldObject.setPaymentCode (inputTelkom.getPaymentCode ());
                    addFieldObject.setControlCode (inputTelkom.getControlCode ());
                    addFieldObject.setAmountDue (amountDue);
                    req.setRefNo (inputTelkom.getAccountNum ());
                    req.setAmount (amountDue);
                    req.setAdditionalFields (additionalString);
                    req.setTenderType (tenderType);
//                getAccountPaymentConfirmation(req);
                    checkAndAuthoriseAmount (req);
                } else {
                    tenders.resetTenderType ();
                }
                break;
            case 2:                     // Eskom
                if (inputEskom.isValidInputEskom ()) {
                    inputEskom.setAdditionalValues ();
                    amountDue = inputEskom.getAmountEsk ();
                    accountStr = inputEskom.getAccountStr ();
                    additionalString = inputEskom.getAdditionalString ();
                    addFieldObject = new BillPaySAPOAddFields ();
                    addFieldObject.setBarcode (inputEskom.getBarcode ());
                    addFieldObject.setAccountNum (inputEskom.getAccountNum ());
                    addFieldObject.setAccountStr (accountStr);
                    addFieldObject.setCheckDigit (inputEskom.getCheckDigit ());
                    addFieldObject.setAmountDue (amountDue);
                    req.setRefNo (inputEskom.getAccountNum ());
                    req.setAmount (amountDue);
                    req.setAdditionalFields (additionalString);
                    req.setTenderType (tenderType);
                    checkAndAuthoriseAmount (req);
                } else {
                    tenders.resetTenderType ();
                }
                break;
            case 3:
                if (isInputValid3 ()) {
                    addFieldObject = new BillPaySAPOAddFields ();
                    addFieldObject.setAccountNum (accountNum);
                    addFieldObject.setAmount (amount);
                    req.setRefNo (accountNum);
                    req.setAmount (amount);
                    req.setTenderType (tenderType);
                    req.setAdditionalFields (additionalString);
                    checkAndAuthoriseAmount (req);
                } else {
                    tenders.resetTenderType ();
                }
                break;
            case 4:
                if (isInputValid4 ()) {
                    addFieldObject = new BillPaySAPOAddFields ();
                    addFieldObject.setAccountNum (accountNum);
                    addFieldObject.setAmountDue (amountDue);
                    req.setRefNo (accountNum);
                    req.setAmount (amountDue);
                    req.setTenderType (tenderType);
                    req.setAdditionalFields (additionalString);
                    checkAndAuthoriseAmount (req);
                } else {
                    tenders.resetTenderType ();
                }
                break;
            default:
                if (isInputValid5 ()) {
                    addFieldObject = new BillPaySAPOAddFields ();
                    addFieldObject.setAccountNum (accountNum);
                    addFieldObject.setAmount (amount);
                    req.setRefNo (accountNum);
                    req.setAmount (amount);
                    req.setTenderType (tenderType);
                    req.setAdditionalFields (additionalString);
                    checkAndAuthoriseAmount (req);
                } else {
                    tenders.resetTenderType ();
                }
                break;
        }


    }

    private void checkAndAuthoriseAmount(final SapoPayReq request) {
        if (request.getAmount () > JKTransactionLimits.getTransactionLimits ().getTransLimitBillPay ()) {
            BillPayUtilMisc.getSupervisorOverride (request.getAmount (), new UserUtil.SupervisorOverride () {

                @Override
                public void supervisorOverrideResult(Boolean isSupervisor) {
                    if (isSupervisor) {
                        System.out.println ("supervisor has authorised, show summary and continue...");
                        getAccountPaymentConfirmation (request);
                    } else {
                        System.out.println ("no authorisation yet, try again...");
                    }
                }
            }, txtAmount, txtAmountDue);
            tenders.resetTenderType ();
        } else {
            getAccountPaymentConfirmation (request);
        }
    }

    private void getAccountPaymentConfirmation(final SapoPayReq request) {

        SummarySAPOBillPay summary = new SummarySAPOBillPay (addFields, addFieldObject, request);

        JKiosk3.getMsgBox ().showMsgBox ("Bill Payment", "Confirm all details before proceeding",
                summary, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {

                        BillPayUtilSAPO.getSapoAccPaymentResponse (request, new SapoBillPaymentResponse () {
                            @Override
                            public void sapoBillPayResp(BillPaymentConnection connect, SapoPayResp resp) {
                                connection = connect;
                                response = resp;

                                if (response.isSuccess ()) {
                                    submitSAPOBillPaymentConfirm ();
                                } else {
                                    JKiosk3.getMsgBox ().showMsgBox ("Bill Payment Error", !response.getAeonErrorText ().isEmpty () ?
                                            "A" + response.getAeonErrorCode () + " - " + response.getAeonErrorText () :
                                            "B" + response.getErrorCode () + " -  " + response.getErrorText (), null);
                                }
                            }
                        });
                    }

                    @Override
                    public void onCancel() {
                        SceneSales.clearAndChangeContent (new InputSAPOBillPay (product, showFavourites, showProductFavourite));
                    }
                });
    }

    private void submitSAPOBillPaymentConfirm() {
        final SapoPayConfReq conf = new SapoPayConfReq ();

        conf.setTransRef (response.getTransRef ());
        conf.setWantPrintJob (true);

        BillPayUtilSAPO.getSAPOPaymentConfirm (connection, conf, new SapoBillPaymentConfirm () {
            @Override
            public void sapoBillPayConf(final SapoPayConfResp confResp) {
                if (confResp.isSuccess ()) {
                    double amt;
                    if (addFields == 1 || addFields == 2 || addFields == 4) {
                        amt = amountDue;
                    } else {
                        amt = amount;
                    }
                    String descript = product.getProdName () + " - " + accountStr;

//                    SalesUtil.processBillPayment(BillPayUtilMisc.SAPO_BILL_PAY, response.getTransRef(), descript, amt, tenderType,
                    SalesUtil.processBillPayment (BPTransType.BILLPAY_SAPO_ACCOUNT.getDisplayName (), response.getTransRef (), descript, amt, tenderType,
                            "Transaction Successful", confResp.getPrintLines (), confResp.getMerchantPrintLines ());

                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Bill Payment Error", !confResp.getAeonErrorText ().isEmpty () ?
                            "A" + confResp.getAeonErrorCode () + " - " + confResp.getAeonErrorText () :
                            "B" + confResp.getErrorCode () + " - " + confResp.getErrorText (), null);
                }
                BillPayUtilMisc.resetBillPayView ();
            }
        });
    }

    private boolean inputValidAccount() {
        if (accountNumberConfirmed == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Account Number", "Please enter and confirm Account Number before continuing", null);
            resetInputs ();
            return false;
        }
        if (accountNumberConfirmed.equals ("") || accountNumberConfirmed.isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Account Number", "Account Number fields cannot be empty", null);
            resetInputs ();
            return false;
        }
        return true;
    }

    private void resetInputs() {
        accountNumberConfirmed = null;
        //
        txtAccNum.setVisible (true);
        txtAccNum.setText ("");
        txtAccNum.setPromptText ("Enter Account Number");
        txtAccNum2.setText ("");
        txtAccNum2.setPromptText ("Re-enter Account Number");
        txtAccNum2.setDisable (true);
    }

    private boolean isInputValid3() {   // Generic additional Amount
        if (txtAmount.getText ().equals ("") || txtAmount.getText ().isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Amount", "Amount cannot be empty", null);
            return false;
        }
        try {
            accountNum = accountNumberConfirmed;
//            amount = Double.parseDouble(txtAmount.getText());
            additionalString = "1=" + accountNum + " "
                    + "2=" + Double.toString (amount);
            accountStr = accountNum;
            return true;
//        } catch (NumberFormatException nfe) {
//            logger.log(Level.SEVERE, nfe.getMessage(), nfe);
//            JKiosk3.getMsgBox().showMsgBox("Number format",
//                    "Please ensure that all numbers are in the correct format", null);
//            return false;
        } catch (Exception e) {
            logger.log (Level.SEVERE, e.getMessage (), e);
            return false;
        }
    }

    private boolean isInputValid4() {   // Generic additional AmountDue
        if (txtAmountDue.getText ().equals ("") || txtAmountDue.getText ().isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Amount Due", "Amount Due cannot be empty", null);
            return false;
        }
        try {
            accountNum = accountNumberConfirmed;
//            amountDue = Double.parseDouble(txtAmountDue.getText());
            additionalString = "1=" + accountNum + " "
                    + "2=" + Double.toString (amountDue);
            accountStr = accountNum;
            return true;
//        } catch (NumberFormatException nfe) {
//            logger.log(Level.SEVERE, nfe.getMessage(), nfe);
//            JKiosk3.getMsgBox().showMsgBox("Number format",
//                    "Please ensure that all numbers are in the correct format", null);
//            return false;
        } catch (Exception e) {
            logger.log (Level.SEVERE, e.getMessage (), e);
            return false;
        }
    }

    private boolean isInputValid5() {   // All other just get the account number as additional field data.
        if (txtAmount.getText ().equals ("") || txtAmount.getText ().isEmpty ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Amount Due", "Amount Due cannot be empty", null);
            return false;
        }
        try {
            accountNum = accountNumberConfirmed;
//            amount = Double.parseDouble(txtAmount.getText());
            additionalString = "1=" + accountNum;
            accountStr = accountNum;
            return true;
//        } catch (NumberFormatException nfe) {
//            logger.log(Level.SEVERE, nfe.getMessage(), nfe);
//            JKiosk3.getMsgBox().showMsgBox("Number format",
//                    "Please ensure that all numbers are in the correct format", null);
//            return false;
        } catch (Exception e) {
            logger.log (Level.SEVERE, e.getMessage (), e);
            return false;
        }
    }

    public JKTenderToggles getTenders() {
        return tenders;
    }
}
