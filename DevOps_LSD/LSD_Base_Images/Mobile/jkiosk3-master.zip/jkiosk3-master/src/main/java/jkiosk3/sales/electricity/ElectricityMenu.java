package jkiosk3.sales.electricity;

import jkiosk3.Version;
import jkiosk3.sales.electricity.eskom.ElecUpdateMeterKey;
import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.MerchantCopy;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.electricity.eskom.ElecConfirmCustomer;
import jkiosk3.sales.electricity.eskom.ElecLogFault;
import jkiosk3.sales.electricity.eskom.ElecEngKeyChange;
import jkiosk3.sales.electricity.eskom.ElecPayAccount;
import jkiosk3.sales.electricity.eskom.ElecRedeemVoucher;
import jkiosk3.sales.electricity.eskom.ElecReprint;
import jkiosk3.sales.electricity.eskom.ElecReprintList;
import jkiosk3.sales.electricity.eskom.ElecTrialVend;
import jkiosk3.sales.electricity.eskom.ElecUpdateMeterCard;
import jkiosk3.store.JKCardReader;
import jkiosk3.users.SalesUserLoginResult;

public class ElectricityMenu extends Region {

    private final ElectricityProvider provider;

    public ElectricityMenu(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;
        getChildren().add(getMenuGroup());
    }

    private VBox getMenuGroup() {
        VBox vbHead = JKNode.getPageHeadVB("Electricity - " + provider.getDisplayName());

        List<String> listBtnLabels = new ArrayList<>();
        if (provider.getDisplayName().contains("Eskom")
                || provider.getDisplayName().contains("Universal")) {
            listBtnLabels.add(ElectricityUtil.ELEC_TOKEN);
            listBtnLabels.add(ElectricityUtil.ELEC_FBE);
            listBtnLabels.add(ElectricityUtil.ELEC_REPRINT);
            listBtnLabels.add(ElectricityUtil.ELEC_REPRINT_LIST);
            listBtnLabels.add(ElectricityUtil.ELEC_UPDATE_M_KEY);
//            if (!Version.isLive()) {
//                listBtnLabels.add(ElectricityUtil.ELEC_UPDATE_M_CARD);
//                listBtnLabels.add(ElectricityUtil.ELEC_FAULT_REPORT);
//                listBtnLabels.add(ElectricityUtil.ELEC_TRIAL_VEND);
////                listBtnLabels.add(ElectricityUtil.ELEC_PAY_ACCOUNT);
//                listBtnLabels.add(ElectricityUtil.ELEC_CONFIRM_CUSTOMER);
//                listBtnLabels.add(ElectricityUtil.ELEC_ENG_KEY_CHANGE);
//                if (JKCardReader.getCardReaderConfig().isMagCardWrite()) {
//                    listBtnLabels.add(ElectricityUtil.ELEC_REDEEM_VOUCHER);
//                }
//            }
        } else {
            listBtnLabels.add(ElectricityUtil.ELEC_TOKEN);
            listBtnLabels.add(ElectricityUtil.ELEC_FBE);
            listBtnLabels.add(ElectricityUtil.ELEC_REPRINT);
        }

        List<Button> btnList = new ArrayList<>();

        for (final String s : listBtnLabels) {
            final Button btn = JKNode.getBtnSmDbl(s);
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, btnList);

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private void getMenuAction(final Button b) {
        MerchantCopy.resetMerchantCopy();
        MerchantCopy.getInstance().setTransType(b.getText());
        JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
            @Override
            public void onDone() {
                switch (b.getText()) {
                    case ElectricityUtil.ELEC_TOKEN:
                        SceneSales.clearAndChangeContent(new ElecToken(provider));
                        break;
                    case ElectricityUtil.ELEC_FBE:
                        SceneSales.clearAndChangeContent(new ElecFBE(provider));
                        break;
                    case ElectricityUtil.ELEC_UPDATE_M_KEY:
                        SceneSales.clearAndChangeContent(new ElecUpdateMeterKey(provider));
                        break;
                    case ElectricityUtil.ELEC_UPDATE_M_CARD:
                        SceneSales.clearAndChangeContent(new ElecUpdateMeterCard(provider));
                        break;
                    case ElectricityUtil.ELEC_FAULT_REPORT:
                        SceneSales.clearAndChangeContent(new ElecLogFault(provider));
                        break;
                    case ElectricityUtil.ELEC_TRIAL_VEND:
                        SceneSales.clearAndChangeContent(new ElecTrialVend(provider));
                        break;
                    case ElectricityUtil.ELEC_REPRINT:
                        SceneSales.clearAndChangeContent(new ElecReprint(provider));
                        break;
                    case ElectricityUtil.ELEC_REPRINT_LIST:
                        SceneSales.clearAndChangeContent(new ElecReprintList(provider));
                        break;
                    case ElectricityUtil.ELEC_PAY_ACCOUNT:
                        SceneSales.clearAndChangeContent(new ElecPayAccount(provider));
                        break;
                    case ElectricityUtil.ELEC_CONFIRM_CUSTOMER:
                        SceneSales.clearAndChangeContent(new ElecConfirmCustomer(provider));
                        break;
                    case ElectricityUtil.ELEC_ENG_KEY_CHANGE:
                        SceneSales.clearAndChangeContent(new ElecEngKeyChange(provider));
                        break;
                    case ElectricityUtil.ELEC_REDEEM_VOUCHER:
                        SceneSales.clearAndChangeContent(new ElecRedeemVoucher(provider));
                        break;
                    default:
                        JKiosk3.getMsgBox().showMsgBox("Electricity", "No Transaction Type Selected", null);
                        break;
                }
            }
        });
    }
}
