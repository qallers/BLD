package jkiosk3.sales.ithuba.lotto;

import aeonithuba.IthubaConfirmRes;
import aeonithuba.IthubaLottoReq;
import aeonithuba.IthubaLottoRes;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.StageComponents;
import jkiosk3.printing.PrintUtil;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales._favourites.Favourites;
import jkiosk3.sales._tender.TenderAmounts;
import jkiosk3.sales.ithuba.LottoUtil;
import za.co.blt.jfxnumberselector.JFXNumberSelectorResult;
import za.co.blt.jfxnumberselector.JFXNumbersRequired;

public class PlayerPowerBallSelNum extends Region {

    private final static Logger logger = Logger.getLogger (PlayerPowerBallSelNum.class.getName ());

    private final double innerWidth = (JKLayout.contentW - (2 * JKLayout.sp));
    private final static double PG_HT = 410;
    private final static int PAGE_SIZE = 5;
    private final int numMax = LottoUtil.NUM_MAX_POWERBALL_BOARD;
    private final int numRequired = LottoUtil.NUM_REQ_POWERBALL;
    private final int numMaxPB = LottoUtil.NUM_MAX_POWERBALL_BOARD_PB;
    private final int numRequiredPB = LottoUtil.NUM_REQ_POWERBALL_PB;

    private List<Node> listboards;

    private IthubaLottoReq req;

    private AnchorPane anchor;
    private CheckBox cbPlayPowerBallPlus;

    private final int numberOfBoards;
    private final int draws;
    private char board;
    private String lottoPlus;

    public PlayerPowerBallSelNum() {
        this.numberOfBoards = LottoSale.getInstance ().getBoards ();
        this.draws = LottoSale.getInstance ().getDraws ();

        VBox vbcontent = JKLayout.getVBox (0, JKLayout.spNum);
        vbcontent.getChildren ().add (getContentGroup ());
        vbcontent.getChildren ().add (getNav ());
        getChildren ().add (vbcontent);
    }

    private VBox getContentGroup() {
        Label lblLotto = JKText.getLblDk ("Player Selection PowerBall", JKText.FONT_B_SM);
        ImageView img = JKNode.getJKImageViewProvider ("prov_IthubaPowerBall.png");

        VBox vbHead = JKNode.getPageDblHeadVB (0, lblLotto, img);

        anchor = new AnchorPane ();
        anchor.setMaxSize (innerWidth, PG_HT);
        anchor.setMinSize (innerWidth, PG_HT);
        anchor.setTranslateX (JKLayout.spNum);

        listboards = makeListBoards ();

        createPagedItems ();

        VBox vb = JKLayout.getVBoxContent (0);
        vb.getChildren ().addAll (vbHead, anchor, getAdditionalSection ());

        return vb;
    }

    private List<Node> makeListBoards() {
        double vbW = (innerWidth / 5) - JKLayout.sp;

        final List<Node> nodes = new ArrayList<> ();

        /*For PowerBall Player Selection, we need to select 5 numbers in the range 1 - 45, 
         and 1 PowerBall number in the range 1 - 20 */
        for (board = 'A'; board < 'A' + numberOfBoards; board++) {

            final VBox vbBoard = JKLayout.getVBox (JKLayout.spNum, JKLayout.sp);
            vbBoard.setId ("Board " + board);
            vbBoard.setMaxSize (vbW, PG_HT - 75 - 15);
            vbBoard.setMinSize (vbW, PG_HT - 75 - 15);
            vbBoard.getStyleClass ().add ("vbLotto");
            if (board == 'A') {
                vbBoard.setDisable (false);
            } else {
                vbBoard.setDisable (true);
            }
            double btnWidth = (JKLayout.contentW / 5) - (3 * JKLayout.sp);
            final Button btn = JKNode.getBtnSm ("Board " + board);
            btn.setFont (JKText.FONT_B_XXSM);
            btn.setMaxSize (btnWidth, JKLayout.btnToggleH);
            btn.setMinSize (btnWidth, JKLayout.btnToggleH);

            vbBoard.getChildren ().add (btn);

            final List<Text> listTxts = new ArrayList<> ();
            Text txt;
            for (int j = 0; j < numRequired; j++) {
                txt = JKText.getTxtDk ("-", JKText.FONT_B_XSM);
                listTxts.add (txt);
            }
            vbBoard.getChildren ().addAll (listTxts);

            final StackPane stackPower = new StackPane ();
            stackPower.setId ("Board " + board);
            stackPower.setMaxSize (btnWidth, JKLayout.btnToggleH);
            stackPower.setMinSize (btnWidth, JKLayout.btnToggleH);
            stackPower.getStyleClass ().add ("stackPowerBall");
            stackPower.setDisable (true);
            stackPower.setOpacity (0.25);
            final Text txtPowerBall = JKText.getTxtDk ("Power\nBall", JKText.FONT_B_18);
            txtPowerBall.getStyleClass ().add ("txtPowerBall");
            stackPower.getChildren ().add (txtPowerBall);

            btn.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event e) {
                    onClickBoard (btn, listTxts, stackPower);
                }
            });

            stackPower.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event e) {
                    onClickPowerBall (txtPowerBall, nodes, vbBoard, stackPower);
                }
            });
            vbBoard.getChildren ().add (stackPower);

            nodes.add (vbBoard);
        }

        return nodes;
    }

    private void onClickBoard(final Button btn, final List<Text> listTxts, final StackPane stackPower) {
        JFXNumbersRequired required = new JFXNumbersRequired (numMax, numRequired, 8, btn.getText (), true, 1.0);
        StageComponents.showStageNumberSelector (required, LottoUtil.DIM_LG, new JFXNumberSelectorResult () {
            @Override
            public void onDone(List<String> list) {
                if (!list.isEmpty ()) {
                    if (LottoSale.getInstance ().getBoardNumbers ().containsKey (btn.getText ())
                            && LottoSale.getInstance ().getBoardNumbers ().get (btn.getText ()).size () == 6) {

                        String powrball = LottoSale.getInstance ().getBoardNumbers ().get (btn.getText ()).get (LottoSale.getInstance ().getBoardNumbers ().get (btn.getText ()).size () - 1);
                        LottoSale.getInstance ().getBoardNumbers ().put (btn.getText (), list);
                        LottoSale.getInstance ().getBoardNumbers ().get (btn.getText ()).add (powrball);

                    } else {
                        LottoSale.getInstance ().getBoardNumbers ().put (btn.getText (), list);
                    }

                    for (int k = 0; k < numRequired; k++) {
                        listTxts.get (k).setText (list.get (k));
                    }

                    stackPower.setDisable (false);
                    stackPower.setOpacity (1.0);
                }
            }
        });
    }

    private void onClickPowerBall(final Text txtPowerBall, final List<Node> nodes, final VBox vbBoard, final StackPane sp) {
        JFXNumbersRequired required = new JFXNumbersRequired (numMaxPB, numRequiredPB, 5,
                txtPowerBall.getText ().replaceAll ("\n", " "), true, 1.0);
        StageComponents.showStageNumberSelector (required, LottoUtil.DIM_SM, new JFXNumberSelectorResult () {
            @Override
            public void onDone(List<String> list) {
                if (!list.isEmpty ()) {
                    /* For PowerBall, we can only select ONE number, so our list will only have ONE number, at index 0 */

                    if (LottoSale.getInstance ().getBoardNumbers ().get (sp.getId ()).size () == 6) {
                        LottoSale.getInstance ().getBoardNumbers ().get (sp.getId ()).remove (LottoSale.getInstance ().getBoardNumbers ().get (sp.getId ()).size () - 1);
                        LottoSale.getInstance ().getBoardNumbers ().get (sp.getId ()).add (list.get (0));
                    } else {
                        LottoSale.getInstance ().getBoardNumbers ().get (sp.getId ()).add (list.get (0));
                    }

                    txtPowerBall.setText (list.get (0));
                    txtPowerBall.setFont (JKText.FONT_B_XSM);

                    if (nodes.size () > 1) {
                        int index = 0;
                        for (Node n : nodes) {
                            if (n.getId ().equals (vbBoard.getId ())) {
                                index = nodes.indexOf (n);
                            }
                        }
                        if ((index + 1) < nodes.size ()) {
                            nodes.get (index + 1).setDisable (false);
                        }
                    }
                }
            }
        });
    }

    private void createPagedItems() {

        int numPgs = 0;
        if (listboards.isEmpty ()) {
            numPgs = 1;
        } else if (listboards.size () % PAGE_SIZE == 0) {
            numPgs = listboards.size () / PAGE_SIZE;
        } else {
            numPgs = (listboards.size () / PAGE_SIZE) + 1;
        }
        Pagination pages = new Pagination (numPgs);
        pages.setPageFactory (new Callback<Integer, Node> () {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedHBox (pg, listboards, PAGE_SIZE, PG_HT);
            }
        });

        anchor.getChildren ().add (pages);
    }

    private GridPane getAdditionalSection() {

        Label playLottoPlus = JKText.getLblDk ("Play PowerBall Plus", JKText.FONT_B_XSM);
        cbPlayPowerBallPlus = new CheckBox ();

        GridPane grid = JKLayout.getContentGridInner2ColInScroll (0.5, 0.5, HPos.RIGHT);

        grid.add (playLottoPlus, 0, 0);
        grid.add (cbPlayPowerBallPlus, 1, 0);

        return grid;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new PlayerPowerBall ());
            }
        });
//        nav.setBtnCancelAction(new LottoMenu());
        nav.setBtnCancelAction (new Favourites ());

        nav.getBtnNext ().setText ("play!");
        nav.getBtnNext ().setFont (LottoUtil.FONT_PLAY);
        nav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event t) {
                if (isValidEntry ()) {
                    if (cbPlayPowerBallPlus.isSelected ()) {
                        LottoSale.getInstance ().setLottoPlus1 (true);
                        lottoPlus = "Yes";
                    } else {
                        LottoSale.getInstance ().setLottoPlus1 (false);
                        lottoPlus = "No";
                    }

                    LottoSale.getInstance ().setLottoPlus2 (false);
                    confirmLotto ();
                }
            }
        });
        return nav;
    }

    private void confirmLotto() {
        StringBuilder sb = new StringBuilder ("\r\n");
        sb.append ("Powerball Player Select").append ("\r\n");
        sb.append ("Boards selected         : ").append (numberOfBoards).append ("\r\n");
        sb.append ("Draws selected          : ").append (draws).append ("\r\n");
        sb.append ("Powerball Plus 1 selected : ").append (LottoSale.getInstance ().isLottoPlus1 ()).append ("\r\n");
        sb.append ("Powerball Plus 2 selected : ").append (LottoSale.getInstance ().isLottoPlus2 ()).append ("\r\n");
        logger.info (sb.toString ());

        req = new IthubaLottoReq ();

        StringBuilder numbers = new StringBuilder ();
        String delim = "";
        for (String key : LottoSale.getInstance ().getBoardNumbers ().keySet ()) {
            if (numbers.length () > 0) {
                numbers.append ("|");
            }
            for (String value : LottoSale.getInstance ().getBoardNumbers ().get (key)) {
                numbers.append (delim).append (value);
                delim = ",";
            }
            delim = "";
        }

        req.setRef (SalesUtil.getUniqueRef ());
        req.getStructData ().put (LottoUtil.DATA_GAME, "Powerball");
        req.getStructData ().put (LottoUtil.DATA_TYPE, "PlayerSelected");
        req.getStructData ().put (LottoUtil.DATA_NUM_BOARDS, Integer.toString (numberOfBoards));
        req.getStructData ().put (LottoUtil.DATA_NUM_DRAWS, Integer.toString (draws));
        req.getStructData ().put (LottoUtil.DATA_NUMBERS, numbers.toString ());
        req.getStructData ().put (LottoUtil.DATA_PLUS1, Boolean.toString (LottoSale.getInstance ().isLottoPlus1 ()));
        req.getStructData ().put (LottoUtil.DATA_PLUS2, Boolean.toString (LottoSale.getInstance ().isLottoPlus2 ()));

        LottoUtil.getLottoConfirm (req, new LottoUtil.IthubaConfirmResult () {
            @Override
            public void ithubaLottoResult(IthubaConfirmRes ithubaConfirmRes) {
                if (ithubaConfirmRes.isSuccess ()) {
                    logger.info (("Powerball Player Select Confirm success - amount due = ").concat (JKText.getDeciFormat ((double) ithubaConfirmRes.getAmt () / 100)));

                    PrintUtil.sendToPrinter (ithubaConfirmRes.getConfirmPrint ());

                    IthubaConfirm confirm = new IthubaConfirm (ithubaConfirmRes, LottoUtil.GAMETYPE_PBALL_SELECT, lottoPlus, "");

                    JKiosk3.getMsgBox ().showMsgBox ("PowerBall Confirmation", "", confirm,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    logger.info ("Customer confirmed - OK button clicked");
                                    buyLottoTicket ();
                                }

                                @Override
                                public void onCancel() {
                                    logger.info ("Customer declined - Cancel button clicked");
                                }
                            });
                } else {
                    resetOnError (!ithubaConfirmRes.getAeonErrorCode ().isEmpty () ? "A" + ithubaConfirmRes.getAeonErrorCode () : "B" + ithubaConfirmRes.getErrorCode (),
                            !ithubaConfirmRes.getAeonErrorText ().isEmpty () ? ithubaConfirmRes.getAeonErrorText () : ithubaConfirmRes.getErrorText ());
                }
            }
        });
    }

    private void buyLottoTicket() {
        LottoUtil.getFinalLottoResp (req, new LottoUtil.IthubaResult () {
            @Override
            public void ithubaLottoFinalRes(IthubaLottoRes ithubaLottoRes) {
                if (ithubaLottoRes.isSuccess ()) {
                    logger.info (("Powerball Player Select Sale success - amount due = ").concat (JKText.getDeciFormat ((double) ithubaLottoRes.getAmt () / 100)));

                    SalesUtil.processIthuba (ithubaLottoRes, LottoUtil.GAMETYPE_PBALL_SELECT);

                    SceneSales.clearAndShowFavourites ();

                } else {
                    resetOnError (!ithubaLottoRes.getAeonErrorCode ().isEmpty () ? "A" + ithubaLottoRes.getAeonErrorCode () : "B" + ithubaLottoRes.getErrorCode (),
                            !ithubaLottoRes.getAeonErrorText ().isEmpty () ? ithubaLottoRes.getAeonErrorText () : ithubaLottoRes.getErrorText ());
                }
            }
        });
    }

    private boolean isValidEntry() {
        if (!LottoSale.getInstance ().getBoardNumbers ().isEmpty ()) {
            if (LottoSale.getInstance ().getBoardNumbers ().size () != LottoSale.getInstance ().getBoards ()) {
                JKiosk3.getMsgBox ().showMsgBox ("Number Selection", "Please select numbers for each Board", null);
                return false;
            }
            for (List<String> list : LottoSale.getInstance ().getBoardNumbers ().values ()) {
                if (list.size () < 6) {
                    JKiosk3.getMsgBox ().showMsgBox ("Number Selection", "Please select ALL numbers for each Board", null);
                    return false;
                }
            }
        } else {
            JKiosk3.getMsgBox ().showMsgBox ("No Numbers Selected", "Please select numbers before continuing", null);
            return false;
        }
        return true;
    }

    private void resetOnError(String errorCode, String errorText) {
        logger.info (("Powerball Player Select failure ").concat (errorCode).concat (" - ").concat (errorText));
        JKiosk3.getMsgBox ().showMsgBox ("Lotto Error", errorCode + " - " + errorText, null);
        SceneSales.clearAndShowFavourites ();
    }
}
