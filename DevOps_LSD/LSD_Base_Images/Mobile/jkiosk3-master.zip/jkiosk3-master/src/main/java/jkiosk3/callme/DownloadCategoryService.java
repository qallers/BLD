package jkiosk3.callme;

import com.google.gson.*;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Logger;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.Base64;
import jkiosk3.JK3Config;
import jkiosk3.store.JKSystem;
import org.json.JSONArray;
import org.json.JSONObject;
import sun.misc.BASE64Encoder;

public class DownloadCategoryService {
    private final static Logger logger = Logger.getLogger(DownloadCategoryService.class.getName());
    private String username;
    private String password;
    private String url;

    public DownloadCategoryService() {
        username = "bludroid";
        password = "7m2hu88qgpeb01ir89576rbq9o";
        url = JK3Config.getLoyaltyPath() + "/customer/support/help/v1/callme/area";

        if (url.contains(".live.")) {
            logger.info("using PROD credentials");
            password = "437s5j5o6ac67qkjvamfiqo3hq";
        }
    }

    public String postData(){
        String authString = username + ":" + password;
        String authStringEnc = new BASE64Encoder().encode(authString.getBytes());
        Client restClient = Client.create();
        WebResource webResource = restClient.resource(url);
        int currentDeviceId = JKSystem.getSystemConfig().getDeviceId();

        String input = "{\"deviceId\":\""+ currentDeviceId +"\"}";

        ClientResponse resp = webResource/*.accept("Content-Type", "text/plain", "application/json; charset=utf8")*/
                .type( "application/json; charset=utf8")
                .header("Authorization", "Basic " + authStringEnc)
                .post(ClientResponse.class, input);

        String response = "";

        if(resp.getStatus() == 200){
            response = resp.getEntity(String.class);
        } else {
            logger.info("Unable to connect to the server........" + DownloadCategoryService.class.getName());
        }

        return response;
    }

}
