package jkiosk3._common;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Val
 */
public class JKNews {

    private String releaseVersion;
    private String releaseDate;
    private List<JKNewsItem> listItems = new ArrayList<>();

    public String getReleaseVersion() {
        return releaseVersion;
    }

    public void setReleaseVersion(String releaseVersion) {
        this.releaseVersion = releaseVersion;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public List<JKNewsItem> getListItems() {
        return listItems;
    }

    public void setListItems(List<JKNewsItem> listItems) {
        this.listItems = listItems;
    }
}
