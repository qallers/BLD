package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.*;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.concurrent.Task;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3.SceneMenu;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.TaskUtil;

/**
 *
 * @author Val
 */
public class ReportUtil {

    /*
     * Please note - although the Emergency Topup Reprints appear on the Report page, the 
     * functionality for these reprints can be found in: -
     * jkiosk3.accounts.emerg_topup.EmergencyTopupUtil.java
     */
    private final static Logger logger = Logger.getLogger(ReportUtil.class.getName());
    private static String userPin = CurrentUser.getUser().getUserPin();
    private final static int deviceId = JKSystem.getSystemConfig().getDeviceId();
    private final static String serial = JKSystem.getSystemConfig().getSerial();
    private static ReportConnection rc;
    //
    public static final String REP_INVOICE = "invoice";
    public static final String REP_STATEMENT = "statement";
    public static final String REP_PROFIT = "profit";
    public static final String REP_PROFIT_SHIFT = "profitByShift";
    public static final String REP_SHIFT = "shift";
    public static final String REP_SHIFT_END = "shiftEnd";
    public final static String REP_DAILY_BATCH = "dailyBatch";
//    public static final String REP_TRANS_LIST = "transactionList";
    public static final String REP_TRANS_LIST = "Transaction List";
    public static final String REP_EMERG_TOP_TRANS_LIST = "Emergency Topup Transaction List";
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 60;

    /**
     * Private Constructor to hide implicit public one.
     */
    private ReportUtil() {
    }

    private static ReportConnection getReportConnect() {
        ReportConnection reportConn = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        try {
            reportConn = new ReportConnection(server, port, secureConnect);
            reportConn.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return reportConn;
    }

    private static boolean isLoggedIn(String transType) throws RuntimeException {
        boolean loggedIn = false;

        rc = getReportConnect();

        try {
            if (rc != null) {
                loggedIn = rc.login(userPin, deviceId, serial, transType);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    private static boolean isLoggedIn() {
        return isLoggedIn("Reports");
    }

    private static AccountList getAccountList() throws RuntimeException {
        AccountList accList = new AccountList();

        try {
            if (isLoggedIn()) {
                accList = rc.getAccountList();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Account List Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return accList;
    }

    private static AccountInfo getAccountDetail() throws RuntimeException {
        AccountInfo accInfo = new AccountInfo();

        try {
            if (isLoggedIn()) {
                accInfo = rc.getAccInfo(userPin, deviceId, serial);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Account Detail Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return accInfo;
    }

    private static InvoiceList getInvoiceList(int accId) throws RuntimeException {
        InvoiceList invList = new InvoiceList();

        try {
            if (isLoggedIn()) {
                invList = rc.getInvoiceList(accId);

                Collections.sort(invList.getInvoices(), new Comparator<Invoice>() {
                    @Override
                    public int compare(Invoice o1, Invoice o2) {
                        return Integer.valueOf(o1.getInvoiceId()).compareTo(o2.getInvoiceId());
                    }
                });
                Collections.reverse(invList.getInvoices());
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Invoice List Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return invList;
    }

    private static ShiftList getShiftList() throws RuntimeException {
        ShiftList shiftList = new ShiftList();

        try {
            if (isLoggedIn()) {
                shiftList = rc.getShiftList();

                Collections.sort(shiftList.getShifts(), new Comparator<Shift>() {
                    @Override
                    public int compare(Shift s1, Shift s2) {
                        return Integer.valueOf(s1.getShiftId()).compareTo(s2.getShiftId());
                    }
                });
                Collections.reverse(shiftList.getShifts());

                Shift currentShift = new Shift();
                currentShift.setShiftId(0);
                shiftList.getShifts().add(0, currentShift);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Shift List Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return shiftList;
    }

    private static ShiftList getOpenShiftDetails() throws RuntimeException {
        ShiftList openShiftList = new ShiftList();

        try {
            if (isLoggedIn()) {
                openShiftList = rc.getOpenShiftDetails();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Shift List Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return openShiftList;
    }

    private static List<Shift> getShiftListUserHistory() throws RuntimeException {
        ShiftList openShiftList;
        ShiftList shiftList;
        List<Shift> listShifts = new ArrayList<>();

        try {
            if (isLoggedIn()) {
                openShiftList = rc.getOpenShiftDetails();
                shiftList = rc.getShiftList();
                openShiftList.getShifts().get(0).setShiftName("Current Shift");
                listShifts.add(openShiftList.getShifts().get(0));
                listShifts.addAll(shiftList.getShifts());

                Collections.sort(listShifts, new Comparator<Shift>() {
                    @Override
                    public int compare(Shift s1, Shift s2) {
                        return Integer.valueOf(s1.getShiftId()).compareTo(s2.getShiftId());
                    }
                });
                Collections.reverse(listShifts);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Shift List Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return listShifts;
    }

    private static AeonPrintJob getPrintReport(String type, int accId, int ref) throws RuntimeException {
        AeonPrintJob apj = new AeonPrintJob();

        try {
            if (isLoggedIn()) {
                switch (type) {
                    case REP_INVOICE:
                        apj = rc.getPrintInvoice(accId, ref);
                        break;
                    case REP_STATEMENT:
                        apj = rc.getStatementMini(accId, ref);
                        break;
                    case REP_PROFIT:
                        apj = rc.getProfitReport(accId, ref);
                        break;
                    case REP_PROFIT_SHIFT:
                        apj = rc.getProfitShiftReport(accId, ref);
                        break;
                    case REP_SHIFT:
                        apj = rc.getPrintShift(ref);
                        break;
//                    case REP_TRANS_LIST:      // CR-2062  -  Transaction List now has its own method, different parameter requirements
//                        apj = rc.getTransList(ref);
//                        break;
                    case REP_EMERG_TOP_TRANS_LIST:
                        apj = rc.getEmergencyTopupTransactions(accId, ref);
                        break;
                    default:
                        JKiosk3.getMsgBox().showMsgBox("Print Report", "No report type requested", null);
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Print Report Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return apj;
    }

    private static AeonPrintJob getPrintShiftEndReport() throws RuntimeException {
        AeonPrintJob apj = new AeonPrintJob();
        if (CurrentUser.getSalesUser() != null) {
            userPin = CurrentUser.getSalesUser().getUserPin();
        } else {
            userPin = CurrentUser.getUser().getUserPin();
        }
        rc = getReportConnect();

        try {
            if (rc != null) {
                if (rc.login(userPin, deviceId, serial, "Reports")) {
                    apj = rc.getEndShift(new HashMap<Integer, Integer>(), new HashMap<Integer, Integer>(),
                            new HashMap<Integer, Integer>());
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Shift End Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return apj;
    }

    private static DailyBatchReport getDailyBatchReport(long dateRequested) throws RuntimeException {
        DailyBatchReport dailyBatch = new DailyBatchReport();
        userPin = CurrentUser.getUser().getUserPin();
        
        rc = getReportConnect();
        try {
            if (rc != null) {

                if (rc.login(userPin, deviceId, serial, "Reports")) {
                    dailyBatch = rc.getDailyBatchReport(dateRequested);
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Daily Batch Report Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return dailyBatch;
    }

    private static ShiftUsers getUsersOnShift(int shiftId) throws RuntimeException {
        ShiftUsers shiftUsers = new ShiftUsers();
        if (CurrentUser.getSalesUser() != null) {
            userPin = CurrentUser.getSalesUser().getUserPin();
        } else {
            userPin = CurrentUser.getUser().getUserPin();
        }
        rc = getReportConnect();

        try {
            if (rc != null) {
                if (rc.login(userPin, deviceId, serial, "Reports")) {
                    shiftUsers = rc.getShiftUsers(shiftId);
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Users for Selected Shift Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }

        return shiftUsers;
    }

    private static AeonPrintJob getCashupReport(int shiftId, int userId) throws RuntimeException {
        AeonPrintJob apj = new AeonPrintJob();
        if (CurrentUser.getSalesUser() != null) {
            userPin = CurrentUser.getSalesUser().getUserPin();
        } else {
            userPin = CurrentUser.getUser().getUserPin();
        }
        rc = getReportConnect();

        try {
            if (rc != null) {
                if (rc.login(userPin, deviceId, serial, "Reports")) {
                    apj = rc.getCashUpReport(userId, shiftId);
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Cashup Report Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return apj;
    }

    private static AeonPrintJob getCashupReportHistory(int shiftId, int userId) throws RuntimeException {
        AeonPrintJob apj = new AeonPrintJob();
        if (CurrentUser.getSalesUser() != null) {
            userPin = CurrentUser.getSalesUser().getUserPin();
        } else {
            userPin = CurrentUser.getUser().getUserPin();
        }
        rc = getReportConnect();

        try {
            if (rc != null) {
                if (rc.login(userPin, deviceId, serial, "Reports")) {
                    apj = rc.getCashUpReportHistory(userId, shiftId);
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Cashup History Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return apj;
    }

    private static TransListResp getTransactionListByDate(final TransListReq req) throws RuntimeException {
        TransListResp transListResp = new TransListResp();
        if (CurrentUser.getSalesUser() != null) {
            userPin = CurrentUser.getSalesUser().getUserPin();
        } else {
            userPin = CurrentUser.getUser().getUserPin();
        }

        try {
            if (isLoggedIn("Reports")) {
                transListResp = rc.getTransListByDate(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Transaction List Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }

        return transListResp;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getAccountList(final AccountListResult result) {
        JKiosk3.getBusy().showBusy("Getting List of Accounts");

        final Task<AccountList> taskAccList = new Task() {
            @Override
            protected AccountList call() throws Exception {
                return getAccountList();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.accountListResult((AccountList) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Account List",
                        "Unable to Retrieve Account List", State.CANCELLED, errorMsg, new SceneMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Account List",
                        "Unable to Retrieve Account List", State.FAILED, errorMsg, new SceneMenu());
            }
        };
        new Thread(taskAccList).start();
        JKiosk3.getBusy().startCountdown(taskAccList, countdownTime);
    }

    public static void getAccountDetail(final AccountDetailResult result) {
        JKiosk3.getBusy().showBusy("Getting Account Detail");

        final Task<AccountInfo> taskAccInfo = new Task() {
            @Override
            protected AccountInfo call() throws Exception {
                return getAccountDetail();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.accountDetailResult((AccountInfo) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Account Detail",
                        "Unable to Retrieve Account Detail", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Account Detail",
                        "Unable to Retrieve Account Detail", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskAccInfo).start();
        JKiosk3.getBusy().startCountdown(taskAccInfo, countdownTime);
    }

    public static void getInvoiceList(final int accId, final InvoiceListResult result) {
        JKiosk3.getBusy().showBusy("Getting List of Invoices");

        final Task<InvoiceList> taskInvList = new Task() {
            @Override
            protected InvoiceList call() throws Exception {
                return getInvoiceList(accId);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.invoiceListResult((InvoiceList) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Invoice List",
                        "Unable to Retrieve Invoice List", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Invoice List",
                        "Unable to Retrieve Invoice List", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskInvList).start();
        JKiosk3.getBusy().startCountdown(taskInvList, countdownTime);
    }

    public static void getShiftList(final ShiftListResult result) {
        JKiosk3.getBusy().showBusy("Getting List of Shifts");

        final Task<ShiftList> taskShiftList = new Task() {
            @Override
            protected ShiftList call() throws Exception {
                return getShiftList();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.shiftListResult((ShiftList) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Shift List",
                        "Unable to Retrieve Shift List", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Shift List",
                        "Unable to Retrieve Shift List", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskShiftList).start();
        JKiosk3.getBusy().startCountdown(taskShiftList, countdownTime);
    }

    public static void getOpenShiftDetails(final ShiftListResult result) {
        JKiosk3.getBusy().showBusy("Getting Current Shift Detail");

        final Task<ShiftList> taskOpenShift = new Task() {
            @Override
            protected ShiftList call() throws Exception {
                return getOpenShiftDetails();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.shiftListResult((ShiftList) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Shift List",
                        "Unable to Retrieve Shift List", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Shift List",
                        "Unable to Retrieve Shift List", State.FAILED, errorMsg, new SceneReports());
            }
        };

        new Thread(taskOpenShift).start();
        JKiosk3.getBusy().startCountdown(taskOpenShift, countdownTime);
    }

    public static void getShiftListUserHistory(final ShiftListHistoryResult result) {
        JKiosk3.getBusy().showBusy("Getting Current Shift Detail");

        final Task<List<Shift>> taskListShifts = new Task() {
            @Override
            protected List<Shift> call() throws Exception {
                return getShiftListUserHistory();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.shiftListHistoryResult((List<Shift>) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Shift List",
                        "Unable to Retrieve Shift List", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Shift List",
                        "Unable to Retrieve Shift List", State.FAILED, errorMsg, new SceneReports());
            }
        };

        new Thread(taskListShifts).start();
        JKiosk3.getBusy().startCountdown(taskListShifts, countdownTime);
    }

    public static void getPrintReport(final String type, final int accId, final int ref, final AeonPrintJobResult result) {
        JKiosk3.getBusy().showBusy("Getting Report PrintJob");

        final Task<AeonPrintJob> taskPrintReport = new Task() {
            @Override
            protected AeonPrintJob call() throws Exception {
                return getPrintReport(type, accId, ref);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.aeonPrintJobResult((AeonPrintJob) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Print Report",
                        "Unable to Retrieve Report Print", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Print Report",
                        "Unable to Retrieve Report Print", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskPrintReport).start();
        JKiosk3.getBusy().startCountdown(taskPrintReport, countdownTime);
    }

    public static void getPrintShiftEndReport(final AeonPrintJobResult result) {
        JKiosk3.getBusy().showBusy("Getting Shift End PrintJob");

        final Task<AeonPrintJob> taskShiftEnd = new Task() {
            @Override
            protected AeonPrintJob call() throws Exception {
                return getPrintShiftEndReport();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.aeonPrintJobResult((AeonPrintJob) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Shift End",
                        "Unable to Process Shift End", State.CANCELLED, errorMsg, new JKioskLogin());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Shift End",
                        "Unable to Process Shift End", State.FAILED, errorMsg, new JKioskLogin());
            }
        };
        new Thread(taskShiftEnd).start();
        JKiosk3.getBusy().startCountdown(taskShiftEnd, countdownTime);
    }

    public static void getDailyBatchReport(final long date, final DailyBatchReportResult result) {
        JKiosk3.getBusy().showBusy("Getting Daily Batch Report");

        final Task<DailyBatchReport> taskDailyBatch = new Task() {
            @Override
            protected DailyBatchReport call() throws Exception {
                return getDailyBatchReport(date);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.dailyBatchReportResult((DailyBatchReport) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Daily Batch Report",
                        "Unable to Retrieve Daily Batch Report", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Daily Batch Report",
                        "Unable to Retrieve Daily Batch Report", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskDailyBatch).start();
        JKiosk3.getBusy().startCountdown(taskDailyBatch, countdownTime);
    }

    public static void getUsersOnShift(final int shiftId, final ShiftUsersResult result) {
        JKiosk3.getBusy().showBusy("Getting Users for Selected Shift");

        final Task<ShiftUsers> taskShiftUsers = new Task<ShiftUsers>() {
            @Override
            protected ShiftUsers call() throws Exception {
                return getUsersOnShift(shiftId);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.shiftUsersResult((ShiftUsers) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Shift Users",
                        "Unable to Retrieve Shift Users", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Shift Users",
                        "Unable to Retrieve Shift Users", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskShiftUsers).start();
        JKiosk3.getBusy().startCountdown(taskShiftUsers, countdownTime);
    }

    public static void getCashupReport(final int shiftId, final int userId, final AeonPrintJobResult result) {
        JKiosk3.getBusy().showBusy("Getting Cashup Report for\nSelected User");

        final Task<AeonPrintJob> taskHistory = new Task<AeonPrintJob>() {
            @Override
            protected AeonPrintJob call() throws Exception {
                return getCashupReport(shiftId, userId);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.aeonPrintJobResult((AeonPrintJob) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Cashup Report",
                        "Unable to Retrieve Cashup Report", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Cashup Report",
                        "Unable to Retrieve Cashup Report", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskHistory).start();
        JKiosk3.getBusy().startCountdown(taskHistory, countdownTime);
    }

    public static void getCashupReportHistory(final int shiftId, final int userId, final AeonPrintJobResult result) {
        JKiosk3.getBusy().showBusy("Getting History for\nSelected Shift and User");

        final Task<AeonPrintJob> taskHistory = new Task<AeonPrintJob>() {
            @Override
            protected AeonPrintJob call() throws Exception {
                return getCashupReportHistory(shiftId, userId);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.aeonPrintJobResult((AeonPrintJob) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Cashup History",
                        "Unable to Retrieve Cashup History", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Cashup History",
                        "Unable to Retrieve Cashup History", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskHistory).start();
        JKiosk3.getBusy().startCountdown(taskHistory, countdownTime);
    }

    public static void getTransactionListByDate(final TransListReq req, final TransactListResult result) {
        JKiosk3.getBusy().showBusy("Getting Transaction List");

        final Task<TransListResp> taskTransact = new Task<TransListResp>() {
            @Override
            protected TransListResp call() throws Exception {
                return getTransactionListByDate(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.transactListResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskEmTopPromoReportCancelFail("Transaction List",
                        "Unable to Retrieve Transaction List", State.CANCELLED, errorMsg, new SceneReports());
            }

            @Override
            protected void failed() {
                taskutil.taskEmTopPromoReportCancelFail("Transaction List",
                        "Unable to Retrieve Transaction List", State.FAILED, errorMsg, new SceneReports());
            }
        };
        new Thread(taskTransact).start();
        JKiosk3.getBusy().startCountdown(taskTransact, countdownTime);
    }

    public abstract static class AccountListResult {

        public abstract void accountListResult(AccountList accountList);
    }

    public abstract static class AccountDetailResult {

        public abstract void accountDetailResult(AccountInfo accountInfo);
    }

    public abstract static class InvoiceListResult {

        public abstract void invoiceListResult(InvoiceList invoiceList);
    }

    public abstract static class ShiftListResult {

        public abstract void shiftListResult(ShiftList shiftList);
    }

    public abstract static class AeonPrintJobResult {

        public abstract void aeonPrintJobResult(AeonPrintJob aeonPrintJob);
    }

    public abstract static class DailyBatchReportResult {

        public abstract void dailyBatchReportResult(DailyBatchReport dailyBatchReport);
    }

    public abstract static class ShiftUsersResult {

        public abstract void shiftUsersResult(ShiftUsers shiftUsersResult);
    }

    public abstract static class ShiftListHistoryResult {

        public abstract void shiftListHistoryResult(List<Shift> shiftListHistoryResult);
    }

    public abstract static class TransactListResult {
        public abstract void transactListResult(TransListResp transListResp);
    }

    // getters
    public static ReportConnection getRc() {
        return getReportConnect();
    }
}
