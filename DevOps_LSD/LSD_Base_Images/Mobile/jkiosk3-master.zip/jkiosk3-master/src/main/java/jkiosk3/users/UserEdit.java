package jkiosk3.users;

import aeonusers.User;
import java.util.ArrayList;
import java.util.List;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.store.JKOptions;

/**
 *
 * @author Val
 */
public class UserEdit extends Region {

    private TextField txtName;
    private TextField txtPin;
    private RadioButton radCash;
    private RadioButton radCashPlus;
    private RadioButton radSup;
    private Button btnPermissions;
    private final SimpleStringProperty strUser = new SimpleStringProperty();
    private User currentUser;
    private User selectedUser;
    private int selectedUserID;
    private String editUserName;
    private ControlButtons ctrlBtns;
    private List<User> userList;

    public UserEdit() {
        currentUser = CurrentUser.getUser();
//        System.out.println("in UserEdit...");
//        System.out.println("cu name = " + currentUser.getUserName() + "  ::  cu pin = " + currentUser.getUserPin() + "  ::  cu id = " + currentUser.getUserId());
        JKUserAddEdit.resetJKUserAddEdit();
        JKUserAddEdit.getInstance().setNewOrEdit(UserUtil.USER_EDIT);
        userList = new ArrayList<>();

        UserUtil.getOnlineUsersList(CurrentUser.getUser().getUserPin(), new UserUtil.ListUsersResult() {
            @Override
            public void listUsersResult(List<User> listUsers) {
                if (!listUsers.isEmpty()) {
                    userList = listUsers;
                    VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
                    vb.getChildren().addAll(getEditUserEntry(), getControlButtons());
                    getChildren().add(vb);
                } else {
                    JKiosk3.changeScene(new SceneUsers());
                }
            }
        });
    }

    private GridPane getEditUserEntry() {

        double w = JKLayout.contentW;

        VBox vbHead = JKNode.getPageHeadVB("Edit User");

        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);

        Label lblSelect = JKText.getLblDk("Select User", JKText.FONT_B_XSM);
        lblSelect.setMinWidth(JKLayout.btnSmW);

        Label lblName = JKText.getLblDk("User Name", JKText.FONT_B_XSM);
        Label lblPin = JKText.getLblDk("User PIN", JKText.FONT_B_XSM);
        Label lblLevel = JKText.getLblDk("User Level", JKText.FONT_B_XSM);

        final ComboBox comUserSelect = new ComboBox();
        comUserSelect.setPrefSize(((w - (2 * JKLayout.sp)) * 0.75), 35);
        final ObservableList<User> observeUsers = FXCollections.observableArrayList(userList);
        strUser.bind(comUserSelect.getSelectionModel().selectedItemProperty());
        strUser.addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                System.out.println(newValue);
                comUserSelect.getSelectionModel().select(newValue);
                for (User u : observeUsers) {
                    if (u.getUserName().equalsIgnoreCase(newValue)) {
                        selectedUser = u;
                        onSelectUser();
                        break;
                    }
                }
            }
        });
        for (User u : observeUsers) {
            comUserSelect.getItems().add(u.getUserName());
        }

        ToggleGroup toggle = new ToggleGroup();

        radCash = new RadioButton("Cashier");
        radCash.setToggleGroup(toggle);
        radCash.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setButtonsEnableDisable();
            }
        });

        radCashPlus = new RadioButton("Cashier Plus");
        radCashPlus.setToggleGroup(toggle);
        radCashPlus.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setButtonsEnableDisable();
            }
        });

        radSup = new RadioButton("Supervisor");
        radSup.setToggleGroup(toggle);
        radSup.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setButtonsEnableDisable();
            }
        });

        HBox hbUserLvl = JKLayout.getHBox(0, JKLayout.sp);
        hbUserLvl.setMaxWidth(w * 0.75);
        hbUserLvl.getChildren().addAll(radCash, JKNode.getHSpacer(), radCashPlus, JKNode.getHSpacer(), radSup);

        txtName = new TextField();
        txtName.setPromptText("Click, enter User Name");
        txtName.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtName, "Enter User Name", txtName.getText(), false, true);
                }
            }
        });

        txtPin = new TextField();
        txtPin.setPromptText("Change if required, leave to keep current PIN");
        txtPin.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtPin, "Enter User PIN", txtPin.getText());
                }
            }
        });

        btnPermissions = JKNode.getBtnMsgBox("permissions");
        btnPermissions.setDisable(true);
        btnPermissions.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (validateUser()) {
                    setUserDetails();
                }
            }
        });

        HBox hbPermissions = JKLayout.getHBox(0, 0);
        hbPermissions.getChildren().addAll(JKNode.getHSpacer(), btnPermissions, JKNode.getHSpacer());

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblSelect, comUserSelect);

        grid.add(JKNode.createGridSpanSep(2), 0, 2);

        grid.addRow(3, lblName, txtName);
        grid.addRow(4, lblPin, txtPin);
        grid.addRow(5, lblLevel, hbUserLvl);
        grid.addRow(6, new Label(), hbPermissions);

        return grid;
    }

    private ControlButtons getControlButtons() {
        ctrlBtns = new ControlButtons();

        ctrlBtns.getBtnAccept().setText("Save");
        ctrlBtns.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (validateUser()) {
                    setUserDetails();
                }
            }
        });
        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneUsers.getVbUsersContent().getChildren().clear();
            }
        });

        return ctrlBtns;
    }

    private void setButtonsEnableDisable() {
        if (radCashPlus.isSelected()) {
            btnPermissions.setDisable(false);
            ctrlBtns.getBtnAccept().setDisable(true);
        } else if (!radCashPlus.isSelected()) {
            btnPermissions.setDisable(true);
            ctrlBtns.getBtnAccept().setDisable(false);
        }
    }

    private void onSelectUser() {
        selectedUserID = selectedUser.getUserId();
        txtName.setText(selectedUser.getUserName());
        if (selectedUser.getUserLevel() == 0) {         // Cashier
            radCash.setSelected(true);
        } else if (selectedUser.getUserLevel() == 1) {  // Supervisor
            radSup.setSelected(true);            
        } else if (selectedUser.getUserLevel() == 2) {  // Cashier Plus
            radCashPlus.setSelected(true);
            btnPermissions.setDisable(false);
        }
        if (currentUser.getUserId() == selectedUser.getUserId()) {
            radCash.setDisable(true);
            radSup.setDisable(true);
            radCashPlus.setDisable(true);
        } else {
            radCash.setDisable(false);
            radSup.setDisable(false);
            radCashPlus.setDisable(false);
        }
    }

    private boolean validateUser() {
        boolean validUser = false;
        editUserName = txtName.getText().trim();

        if (editUserName.length() > 20) {
            validUser = false;
            JKiosk3.getMsgBox().showMsgBox("User Name", "Name cannot be more than 20 characters", null);
        } else {
            for (User u : userList) {
                if ((editUserName.equalsIgnoreCase(u.getUserName())) && (!(selectedUserID == u.getUserId()))) {
                    validUser = false;
                    JKiosk3.getMsgBox().showMsgBox("User Already Exists", "Please enter a unique user name", null);
                    break;
                } else {
                    validUser = true;
                }
            }
        }

        return validUser;
    }

    private void setUserDetails() {
        String userPin = selectedUser.getUserPin();
        if (txtPin.getText().trim().equals("")) {
            userPin = "";
        } else {
            userPin = txtPin.getText().trim();
        }

        int userLevel = 0;
        if (radCash.isSelected()) {
            userLevel = 0;
        } else if (radSup.isSelected()) {
            userLevel = 1;
        } else if (radCashPlus.isSelected()) {
            userLevel = 2;
        }
        JKUserAddEdit.getInstance().setAeonUser(selectedUser);
        JKUserAddEdit.getInstance().getAeonUser().setUserId(selectedUser.getUserId());
        JKUserAddEdit.getInstance().getAeonUser().setUserName(editUserName);
        JKUserAddEdit.getInstance().getAeonUser().setUserPin(userPin);
        JKUserAddEdit.getInstance().getAeonUser().setUserLevel(userLevel);
        saveOrContinue();
    }

    private void saveOrContinue() {
        if (JKUserAddEdit.getInstance().getAeonUser().getUserLevel() == 2) {
            SceneUsers.clearAndChangeContent(new UserPermissions());
        } else {
            if (currentUser.getUserId() == selectedUser.getUserId()) {
                System.out.println("changing own User details");
                JKiosk3.getMsgBox().showMsgBox("Edit User", "You are changing your OWN details.\n\nYou will be returned to the Login screen."
                        + "\n\nAre you sure you want to continue?",
                        null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_YES_NO, new MessageBoxResult() {

                            @Override
                            public void onOk() {
                                JKUserAddEdit.getInstance().getAeonUser().setUserPermissions(null);
                                UserUtil.saveEditUser(JKUserAddEdit.getInstance().getAeonUser(), true);
//                                JKiosk3.changeScene(new JKioskLogin());
                            }

                            @Override
                            public void onCancel() {
                                //
                            }
                        });
            } else {
                JKUserAddEdit.getInstance().getAeonUser().setUserPermissions(null);
                UserUtil.saveEditUser(JKUserAddEdit.getInstance().getAeonUser(), false);
                SceneUsers.clearAndChangeContent(new UserEdit());
            }
            // // //
//            JKUserAddEdit.getInstance().getAeonUser().setUserPermissions(null);
//            UserUtil.saveEditUser(JKUserAddEdit.getInstance().getAeonUser());
//            SceneUsers.clearAndChangeContent(new UserEdit());
        }
    }
}
