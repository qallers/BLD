package jkiosk3.admin.favourites;

import aeonfavourites.FavouriteItem;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.admin.favourites.fav_cache.CacheFavouriteCustomStore;
import jkiosk3.admin.favourites.fav_cache.JKFavouriteSetup;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilConnect;
import jkiosk3.sales.billpay.BillPayUtilMisc;

import java.util.ArrayList;
import java.util.List;

public class FavouritesBillPayments extends Region {

    private List<FavouriteItem> listFavouriteCache;
    private List<FavouriteItem> listFavouriteUpdate;
    private List<FavouriteItem> listFavouriteTemp;
    private List<BillPayProduct> listBillPay;
    private List<BillPayProduct> listInsure;
    private List<BillPayProduct> listTrafFine;
    private Label lblListSize;
    private StackPane stackPane;
    private final double innerWidth = (JKLayout.contentW - (2 * JKLayout.sp));
//    private final static double PG_HT = 485;
    private final static double PG_HT = 490;
    private final static int PG_SIZE = 9;
    private int maxCount;

    public FavouritesBillPayments() {
        this.listFavouriteCache = CacheFavouriteCustomStore.getListFavouriteItems();
        this.listFavouriteUpdate = new ArrayList<>();
        this.listFavouriteTemp = new ArrayList<>();
        this.maxCount = JKFavouriteSetup.getFavouriteSetupStore().getCountBillPayments();

        for (FavouriteItem f : listFavouriteCache) {
            if (f.getTrxGroup().equalsIgnoreCase("Payments")) {
                listFavouriteTemp.add(f);
            } else {
                listFavouriteUpdate.add(f);
            }
        }

        this.stackPane = JKLayout.getStackFavouriteSelect(PG_HT);

//        if (listFavouriteTemp.size() > maxCount) {
//            listFavouriteTemp = listFavouriteTemp.subList(0, maxCount);
//        }

        SceneFavourites.checkMenuButtonsDisable(SceneFavourites.SELECT_BILL_PAYMENTS, true);
        getChildren().addAll(getFavouriteBillPayLayout());
    }

    private void getProviders() {
        BillPayUtilConnect.getProviderProductLists(new BillPayUtilConnect.ListBillPayments() {
            @Override
            public void listBillPayments(Void list) {
                listBillPay = BillPayUtilConnect.getBillPayList();
                listInsure = BillPayUtilConnect.getInsurePayList();
                listTrafFine = BillPayUtilConnect.getTrafFineList();
            }
        });
    }

    private VBox getFavouriteBillPayLayout() {
        getProviders();

        Label lblHead1 = JKText.getLblDk("Select Bill Payment Favourites", JKText.FONT_B_24);
        lblListSize = JKText.getLblDk(Integer.toString(listFavouriteTemp.size()), JKText.FONT_B_20);
        if (listFavouriteTemp.size() > maxCount) {
            lblListSize.setStyle("-fx-text-fill: #ff0000;");
        } else {
            lblListSize.setStyle("-fx-text-fill: #0F224E;");
        }
        Label lblHead2 = JKText.getLblDk(" of " + maxCount, JKText.FONT_B_20);
        HBox hbCount = JKLayout.getHBox(0, JKLayout.spNum);
        hbCount.getChildren().addAll(lblListSize, lblHead2);
        VBox vbHeader = JKNode.getPageDblHeadVB(0, lblHead1, hbCount);

        VBox vbContent = JKLayout.getVBoxContent(JKLayout.spNum);
        VBox vbHead = JKNode.getPageHeadVB("Select Bill Payment Favourites");
        vbContent.getChildren().addAll(vbHeader, getSelectBPFavs(), getBtnControls());

//        VBox vbPage = JKLayout.getVBox(0, JKLayout.spNum);
//        vbPage.getChildren().addAll(vbContent, getBtnControls());

        return vbContent;
    }

    private ControlButtonsFavList getBtnControls() {
        ControlButtonsFavList ctrl = new ControlButtonsFavList();
        ctrl.getBtnSave().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                saveUpdatedFavourites();
            }
        });
        ctrl.getBtnCancel().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneFavourites.checkMenuButtonsDisable(SceneFavourites.SELECT_BILL_PAYMENTS, false);
                SceneFavourites.clearAndChangeContent(null);
            }
        });
        return ctrl;
    }

//    private ControlButtonsFav getBtnControls() {
//        ControlButtonsFav ctrl = new ControlButtonsFav();
//        ctrl.getBtnSave().setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                saveUpdatedFavourites();
//            }
//        });
//        return ctrl;
//    }

    private VBox getSelectBPFavs() {

        Label lblSelect = JKText.getLblDk("Select Bill Payment Type", JKText.FONT_B_XSM);
        lblSelect.setMinWidth(JKLayout.btnSmW);

        List<String> listBPTypes = new ArrayList<>();
        listBPTypes.add(BillPayUtilMisc.TYPE_BILL_PAY);

        final ObservableList<String> listBPType = FXCollections.observableArrayList(listBPTypes);

        final ComboBox comBPSelect = new ComboBox();
        comBPSelect.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.5), 35);
        comBPSelect.setItems(listBPType);
        comBPSelect.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                stackPane.getChildren().clear();
                getPageContents((String) newValue);
            }
        });

        HBox hb = JKLayout.getHBox(0, 0);
        hb.setMaxWidth(innerWidth);
        hb.setMinWidth(innerWidth);
        hb.getChildren().addAll(lblSelect, JKNode.getHSpacer(), comBPSelect);

        VBox vbContent = JKLayout.getVBoxLeft(0, JKLayout.spNum);
        vbContent.getChildren().addAll(hb, JKNode.createContentSep(), stackPane);

        return vbContent;
    }

    private void getPageContents(String productType) {
        List<BillPayProduct> bpProducts = new ArrayList<>();
        switch (productType) {
            case BillPayUtilMisc.TYPE_BILL_PAY:
                bpProducts = listBillPay;
                break;
            case BillPayUtilMisc.TYPE_INSURE_PAY:
                bpProducts = listInsure;
                break;
            case BillPayUtilMisc.TYPE_TRAFFIC_FINE:
                bpProducts = listTrafFine;
                break;
            default:
                break;
        }
        createPagedItems(bpProducts);
    }

    private void createPagedItems(List<BillPayProduct> bpProducts) {
        final List<Node> listNodes = getBPProductSelectionList(bpProducts);

        int numPgs = 0;
        if (listNodes.isEmpty()) {
            numPgs = 1;
        } else if (listNodes.size() % PG_SIZE == 0) {
            numPgs = listNodes.size() / PG_SIZE;
        } else {
            numPgs = (listNodes.size() / PG_SIZE) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedVBox(pg, listNodes, PG_SIZE, PG_HT);
            }
        });

        stackPane.getChildren().add(pages);
    }

    private List<Node> getBPProductSelectionList(List<BillPayProduct> bpProducts) {
        String stringLayout = "%-8s" + "%-2s" + "%-40s";
        List<Node> listChks = new ArrayList<>();
        for (final BillPayProduct p : bpProducts) {
            int index = p.getProvName().indexOf(' ');
            String provName = p.getProvName().substring(0, index);
            String prodName = String.format(stringLayout, provName, ":", p.getProdName());
            final CheckBox chk = new CheckBox(prodName);
            for (FavouriteItem i : listFavouriteCache) {
                if (i.getTrxGroup().equalsIgnoreCase("Payments")
                        && i.getProductId().equals(Integer.toString(p.getProdId()))) {
                    chk.setSelected(true);
                    break;
                }
            }
            chk.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    if (chk.isSelected()) {
                        addProduct(chk, p);
                    } else if (!chk.isSelected()) {
                        removeProduct(p);
                    }
                }
            });
            listChks.add(chk);
        }
        return listChks;
    }

    private void addProduct(CheckBox checkBox, BillPayProduct prod) {
        if (!isProductInList(prod)) {
            FavouriteItem favouriteItem = new FavouriteItem();
            favouriteItem.setTrxGroup(SceneFavourites.TRX_GROUP_BILL_PAYMENTS);
            String bpTrxType = "";
            switch (prod.getBpTransType()) {
                case BILLPAY_PAYAT_ACCOUNT:
                    bpTrxType = BPTransType.BILLPAY_PAYAT_ACCOUNT.getTrxType();
                    break;
                case BILLPAY_PAYAT_INSURANCE:
                    bpTrxType = BPTransType.BILLPAY_PAYAT_INSURANCE.getTrxType();
                    break;
                case BILLPAY_PAYAT_TRAFFIC:
                    bpTrxType = BPTransType.BILLPAY_PAYAT_TRAFFIC.getTrxType();
                    break;
                case BILLPAY_SYNTELL_ACCOUNT:
                    bpTrxType = BPTransType.BILLPAY_SYNTELL_ACCOUNT.getTrxType();
                    break;
                case BILLPAY_SYNTELL_TRAFFIC:
                    bpTrxType = BPTransType.BILLPAY_SYNTELL_TRAFFIC.getTrxType();
                    break;
                case BILLPAY_SAPO_ACCOUNT:
                    bpTrxType = BPTransType.BILLPAY_SAPO_ACCOUNT.getTrxType();
                    break;
                case BILLPAY_BLU_ACCOUNT:
                    bpTrxType = BPTransType.BILLPAY_BLU_ACCOUNT.getTrxType();
                    break;
                default:
                    break;
            }
            favouriteItem.setTrxType(bpTrxType);
            favouriteItem.setProductId(Integer.toString(prod.getProdId()));
            if (listFavouriteTemp.size() < maxCount) {
                listFavouriteTemp.add(favouriteItem);
            } else {
                JKiosk3.getMsgBox().showMsgBox("Maximum Count Exceeded",
                        "\nA total of " + maxCount + " Bill Issuers can be selected."
                                + "\n\nRemove another Bill Issuer and click 'Save' first,"
                                + "\nor change settings in 'Favourites Preferences'", null);
                checkBox.setSelected(false);
            }
            lblListSize.setText(Integer.toString(listFavouriteTemp.size()));
            if (listFavouriteTemp.size() > maxCount) {
                lblListSize.setStyle("-fx-text-fill: #ff0000;");
            } else {
                lblListSize.setStyle("-fx-text-fill: #0F224E;");
            }
        }
    }

    private void removeProduct(BillPayProduct prod) {
        if (isProductInList(prod)) {
            for (FavouriteItem f : listFavouriteTemp) {
                if (f.getTrxGroup().equalsIgnoreCase("Payments")
                        && f.getProductId().equals(Integer.toString(prod.getProdId()))) {
                    listFavouriteTemp.remove(f);
                    break;
                }
            }
            lblListSize.setText(Integer.toString(listFavouriteTemp.size()));
            if (listFavouriteTemp.size() > maxCount) {
                lblListSize.setStyle("-fx-text-fill: #ff0000;");
            } else {
                lblListSize.setStyle("-fx-text-fill: #0F224E;");
            }
        }
    }

    private boolean isProductInList(BillPayProduct prod) {
        FavouriteItem favItem = null;
        for (FavouriteItem f : listFavouriteTemp) {
            if (f.getTrxGroup().equalsIgnoreCase("Payments")
                    && f.getProductId().equals(Integer.toString(prod.getProdId()))) {
                favItem = f;
                break;
            }
        }
        if (favItem != null) {
            return true;
        } else {
            return false;
        }
    }

    private void saveUpdatedFavourites() {
        if (!listFavouriteTemp.isEmpty()) {
            listFavouriteUpdate.addAll(listFavouriteTemp);
            listFavouriteCache = listFavouriteUpdate;
            if (CacheFavouriteCustomStore.saveFavouriteStore(listFavouriteCache)) {
//                SceneFavourites.clearAndChangeContent(new FavouritesBillPayments());
                SceneFavourites.checkMenuButtonsDisable(SceneFavourites.SELECT_BILL_PAYMENTS, false);
                SceneFavourites.clearAndChangeContent(null);
            }
        } else {
            JKiosk3.getMsgBox().showMsgBox("Custom Favourites", "Please add at least 1 product to the list", null);
        }
    }
}
