package jkiosk3.accounts.emerg_topup;

import aeonemergencytopup.Account;
import aeonemergencytopup.AccountsList;

import java.util.ArrayList;
import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3.SceneMenu;
import jkiosk3._common.JKLayout;

import static jkiosk3._common.JKLayout.menuH;
import static jkiosk3._common.JKLayout.sideW;
import static jkiosk3._common.JKLayout.sp;

import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;

public class SceneEmergencyTopup extends Region {

    private static VBox vbEmergTopContent;
    private VBox vbBtns;
    private AccountsList listElligibleAccounts;
    private final static double infoHeight = 265;

    public SceneEmergencyTopup() {
        StackPane stack = JKLayout.getSceneStack(getEmergTopSceneLayout(), this);
        getChildren().add(stack);
        getElligibleAccounts();
    }

    private AnchorPane getEmergTopSceneLayout() {
        Group menu = getMenuGroup();
        vbEmergTopContent = JKLayout.getVBox(0, JKLayout.spNum);
        VBox grpInfo = JKLayout.getSceneInfoBox(infoHeight, getSceneInfo());
        VBox grpClose = JKLayout.getMainMenuBtn(new SceneMenu());

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(grpInfo, grpClose);

        AnchorPane ap = JKLayout.getSceneAnchor(menu, vbEmergTopContent, vb);
        ap.getChildren().addAll(menu, vbEmergTopContent, vb);

        return ap;
    }

    private Group getMenuGroup() {
        Group grp = new Group();
        Rectangle rec = new Rectangle(sideW, menuH);
        vbBtns = JKLayout.getVBox(sp, sp);

        grp.getChildren().addAll(rec, vbBtns);

        return grp;
    }

    private void getElligibleAccounts() {
        EmergencyTopupUtil.getListAccounts(new EmergencyTopupUtil.AccountsListResult() {
            @Override
            public void accountListResult(AccountsList listAccounts) {
                if (listAccounts.isSuccess()) {
                    if (!listAccounts.getListAccounts().isEmpty()) {
                        listElligibleAccounts = listAccounts;
                        getAccountsMenu();
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Accounts", "No Accounts were found that are eligible for"
                                        + "\nEmergency Topup",
                                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                    @Override
                                    public void onOk() {
                                        JKiosk3.changeScene(new SceneMenu());
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Accounts", "Unable to retrieve list of Accounts\n\n" + listAccounts.getErrorText(),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    JKiosk3.changeScene(new SceneMenu());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private void getAccountsMenu() {

        List<Button> btnList = new ArrayList<>();

        if (listElligibleAccounts != null) {
            for (final Account a : listElligibleAccounts.getListAccounts()) {
                final Button btn = JKNode.getBtnSm(a.getAccountNumber());
                btn.setOnMouseReleased(new EventHandler<Event>() {
                    @Override
                    public void handle(Event e) {
                        onSelectAccount(a);
                    }
                });
                btnList.add(btn);
            }
        }

        vbBtns.getChildren().addAll(btnList);
    }

    private VBox getSceneInfo() {

        VBox vb = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
        vb.setMaxSize(JKLayout.sideW, infoHeight);
        vb.setMinSize(JKLayout.sideW, infoHeight);

        Label lblSupport = JKText.getLblDk("Support", JKText.FONT_B_XXSM);

        Label lblNumber = JKText.getLblDk(JK3Config.getInfoHelpDeskTelNum(), JKText.FONT_B_XXSM);

        vb.getChildren().addAll(lblSupport, lblNumber);

        return vb;
    }

    private void onSelectAccount(Account accSelected) {
        EmergencyTopup.resetEmergencyTopup();
        vbEmergTopContent.getChildren().clear();
        vbEmergTopContent.getChildren().add(new EmergencyTopupRequest(accSelected));
    }

    public static VBox getVbEmergTopContent() {
        return vbEmergTopContent;
    }
}
