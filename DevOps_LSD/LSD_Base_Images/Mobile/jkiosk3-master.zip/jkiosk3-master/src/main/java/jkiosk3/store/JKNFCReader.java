package jkiosk3.store;

public class JKNFCReader {

    private static StoreJKNFCReader nfcReaderConfig;

    public static StoreJKNFCReader getNfcReaderConfig() {
        if (nfcReaderConfig == null) {
            nfcReaderConfig = ((StoreJKNFCReader) Store.loadObject(JKNFCReader.class.getSimpleName()));
        }
        if (nfcReaderConfig == null) {
            nfcReaderConfig = new StoreJKNFCReader();
        }
        return nfcReaderConfig;
    }

    public static boolean saveCardReaderConfig() {
        getNfcReaderConfig();
        return Store.saveObject(JKNFCReader.class.getSimpleName(), nfcReaderConfig);
    }
}
