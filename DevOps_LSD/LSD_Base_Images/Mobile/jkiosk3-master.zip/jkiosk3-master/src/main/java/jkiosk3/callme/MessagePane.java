package jkiosk3.callme;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKText;

public class MessagePane {
    public GridPane messageGrid() {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);

        double gridW = 590;
        grid.setMaxWidth(gridW * 6);
        grid.setMinWidth(gridW);

        Label lblMessage1 = JKText.getLblDk("\n We value your loyalty and would like to support you with any problem you  \n maybe experiencing.\n", JKText.FONT_B_15);
        lblMessage1.setTextAlignment(TextAlignment.CENTER);

        Label lblMessage2 = JKText.getLblDk("\nHelp us to identify your problem, we will call you back and find the best \n solution to solve it.\n\n\n", JKText.FONT_B_15);
        lblMessage2.setTextAlignment(TextAlignment.CENTER);

        grid.add(lblMessage1, 0, 0);
        grid.add(lblMessage2, 0, 1);

        return grid;
    }

}
