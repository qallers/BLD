package jkiosk3.store;

import java.io.Serializable;

/**
 *
 * @author Valerie
 */
public class StoreJKSalesOptions implements Serializable {

//    private final static long serialVersionUID = 100033L;
    // Sales Options
    private boolean confirmSale = false;
    private boolean enterTender = false;
    private boolean useCashDrawer = false;
    private boolean cashDrawerOpenOnEndShift = false;
    private boolean acceptCash = true;
    private boolean acceptCheque = false;
    private boolean acceptCreditCard = false;
    private boolean acceptDebitCard = false;

    public boolean isConfirmSale() {
        return confirmSale;
    }

    public void setConfirmSale(boolean confirmSale) {
        this.confirmSale = confirmSale;
    }

    public boolean isEnterTender() {
        return enterTender;
    }

    public void setEnterTender(boolean enterTender) {
        this.enterTender = enterTender;
    }

    public boolean isUseCashDrawer() {
        return useCashDrawer;
    }

    public void setUseCashDrawer(boolean useCashDrawer) {
        this.useCashDrawer = useCashDrawer;
    }

    public boolean isCashDrawerOpenOnEndShift() {
        return cashDrawerOpenOnEndShift;
    }

    public void setCashDrawerOpenOnEndShift(boolean cashDrawerOpenOnEndShift) {
        this.cashDrawerOpenOnEndShift = cashDrawerOpenOnEndShift;
    }

    public boolean isAcceptCash() {
        return acceptCash;
    }

    public void setAcceptCash(boolean acceptCash) {
        this.acceptCash = acceptCash;
    }

    public boolean isAcceptCheque() {
        return acceptCheque;
    }

    public void setAcceptCheque(boolean acceptCheque) {
        this.acceptCheque = acceptCheque;
    }

    public boolean isAcceptCreditCard() {
        return acceptCreditCard;
    }

    public void setAcceptCreditCard(boolean acceptCreditCard) {
        this.acceptCreditCard = acceptCreditCard;
    }

    public boolean isAcceptDebitCard() {
        return acceptDebitCard;
    }

    public void setAcceptDebitCard(boolean acceptDebitCard) {
        this.acceptDebitCard = acceptDebitCard;
    }
}
