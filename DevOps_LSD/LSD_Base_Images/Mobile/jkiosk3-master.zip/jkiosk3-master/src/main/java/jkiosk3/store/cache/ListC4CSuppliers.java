package jkiosk3.store.cache;

import aeonvarivouchers.Supplier;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author valeriew
 */
public class ListC4CSuppliers implements Serializable {

    // L(ist)  = 12 (1 + 2 = 3)
    // C(4C) = 3
    // S(uppliers) = 19 (1 + 9 = 10) (1 + 0 = 1)
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 999331L;
    private final List<Supplier> listC4CSuppliers = new ArrayList<>();

    public List<Supplier> getListC4CSuppliers() {
        return listC4CSuppliers;
    }
}
