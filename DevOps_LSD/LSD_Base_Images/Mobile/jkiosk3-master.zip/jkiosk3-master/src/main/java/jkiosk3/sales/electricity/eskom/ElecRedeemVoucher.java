package jkiosk3.sales.electricity.eskom;

import aeonelectricity.ElectricityConfirmation;
import aeonelectricity.ElectricityConnection;
import aeonelectricity.ElectricityMeter;
import aeonelectricity.ElectricityVoucher;

import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.MagCardData;
import jkiosk3.printing.PrintUtil;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.electricity.ElecConfirm;
import jkiosk3.sales.electricity.ElecEnterMeter;
import jkiosk3.sales.electricity.ElecEnterMeterResult;
import jkiosk3.sales.electricity.ElecShareBtnsLessMore;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.users.UserUtil;

/**
 * @author Valerie
 */
public class ElecRedeemVoucher extends Region {

    private ElectricityConnection connection;
    private ElectricityConfirmation confirmation;
    private final ElectricityProvider provider;
    private String meterNum;
    private ElecEnterMeter gMeter;

    public ElecRedeemVoucher(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;
        getChildren ().add (getRedeemVoucherLayout ());
    }

    private VBox getRedeemVoucherLayout() {
        gMeter = new ElecEnterMeter (provider, ElectricityUtil.ELEC_REDEEM_VOUCHER, new ElecEnterMeterResult () {
            @Override
            public void onDone() {
                if (gMeter.isMagEntry ()) {
                    System.out.println ("onDone : meter number entered : " + gMeter.getMeterNum ());
                    System.out.println ("onDone : did we read mag card? : " + gMeter.isMagEntry ());
                }
            }
        });
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().addAll (gMeter, getElecSaleCtrls ());
        return vb;
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        ElecShareBtnsLessMore btnsLessMore = new ElecShareBtnsLessMore ();

        btnsLessMore.getBtnAccept ().setDisable (false);
        btnsLessMore.getBtnAccept ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                getMeterConfirmation ();
            }
        });
        btnsLessMore.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });
        return btnsLessMore;
    }

    private void getMeterConfirmation() {
        if (validateInput ()) {
            final ElectricityMeter meter = new ElectricityMeter ();
            if (gMeter.isMagEntry ()) {
                meter.setTrack2data (meterNum);
            } else {
                meter.setMeterNum (meterNum);
            }

            String transType = provider.getTransactionType ();

            ElectricityUtil.getElectricityConfirmation (transType, "OnlineReprint", meter, 0, new ElectricityUtil.ElectricityConfirm () {
                @Override
                public void electricityConfirm(ElectricityConnection connect, final ElectricityConfirmation confirm) {
                    if (confirm.isSuccess ()) {
                        connection = connect;
                        confirmation = confirm;

                        ElecConfirm confirmGrid = new ElecConfirm (confirmation, meter, 0, ElectricityUtil.ELEC_REDEEM_VOUCHER);

                        JKiosk3.getMsgBox ().showMsgBox ("Electricity Meter Confirmation", "Redeem Voucher", confirmGrid,
                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                                    @Override
                                    public void onOk() {
                                        requestRedeemVoucher ();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("Unable to Confirm", !confirm.getAeonErrorText ().isEmpty () ?
                                        "A" + confirm.getAeonErrorCode () + " - " + confirm.getAeonErrorText () :
                                        "B" + confirm.getErrorCode () + " - " + confirm.getErrorText (),
                                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                    @Override
                                    public void onOk() {
                                        ElectricityUtil.resetElectricity ();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    }
                    ElectricityUtil.resetElectricity ();
                }
            });
        }
    }

    private void requestRedeemVoucher() {
        String reference = SalesUtil.getUniqueRef ();

        ElectricityUtil.getElectricityVoucherReprint (connection, "OnlineReprint", meterNum, reference,
                new ElectricityUtil.ElectricityResult () {
                    @Override
                    public void electricityResult(ElectricityVoucher voucher) {
                        if (voucher.isSuccess ()) {
                            final List<MagCardData> magList = ElectricityUtil.getMagCardTokens (voucher);
                            if (magList.isEmpty ()) {
                                JKiosk3.getMsgBox ().showMsgBox ("Redeem Voucher", "No Mag Tokens available for this Meter", null);
                            } else {
                                PrintUtil.writeMagCardTokens (magList, null);
                            }
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("Electricity Redeem Voucher", !voucher.getAeonErrorText ().isEmpty () ?
                                    "A" + voucher.getAeonErrorCode () + " - " + voucher.getAeonErrorText () :
                                    "B" + voucher.getErrorCode () + " - " + voucher.getErrorText (), null);
                        }
                        ElectricityUtil.resetElectricity ();
                    }
                });
    }

    private boolean validateInput() {
        meterNum = gMeter.getMeterNum ().trim ();
        if (meterNum.equals ("") || meterNum == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Meter Number", "Meter Number cannot be blank.\n"
                    + "Please enter Meter Number.", null);
            return false;
        }
        return true;
    }
}
