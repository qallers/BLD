package jkiosk3.printing;

import java.io.IOException;
import jkiosk3.printing.cashdrawer.CashDrawerWindows;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import jkiosk3.store.JKCashDrawer;
import jkiosk3.store.JKPrinter;
import org.json.JSONObject;
import za.co.blt.serialprinter.Printer;

/**
 *
 * @author Val
 */
public class PrintClient {

    private final static Logger logger = Logger.getLogger(PrintClient.class.getName());

    private int clientId;

    public void print(PrintJob pj, PrintDevice dev) {
        JSONObject req = new JSONObject();
        try {
            req.put("toFile", false);
            req.put("clientId", clientId);
            req.put("pjId", System.currentTimeMillis());
            req.put("device", dev.printerDetails());
            req.put("printJob", pj.getEncodedPrintLines());
            req.put("fails", "");
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }

        String request = req.toString();

        System.out.println("printDriver() : " + JKPrinter.getPrinterConfig().getPrintDriver());
        System.out.println("printPort()   : " + JKPrinter.getPrinterConfig().getPrintPort());
        System.out.println("printBaud()   : " + JKPrinter.getPrinterConfig().getPrintBaud());
        Printer printer = Printer.getInstance(JKPrinter.getPrinterConfig().getPrintDriver(),
                JKPrinter.getPrinterConfig().getPrintPort(), JKPrinter.getPrinterConfig().getPrintBaud());
        printer.print(request);

        logger.info(("print request sent to printer = ").concat(request));
    }

    public void cashDraw() {

        if (JKPrinter.getPrinterConfig().isPrintWin()) {
            logger.info(("cash drawer pop for Windows on printer : ").concat(JKCashDrawer.getCashDrawerConfig().getCdWindows().getPrinterModel()));
            if (JKCashDrawer.getCashDrawerConfig().getCdWindows().getPrinterModel().equalsIgnoreCase("PartnerTech")) {
                try {
                    ProcessBuilder p = new ProcessBuilder();
                    p.command("PT6910CashDrawerKickA.exe");
                    p.start();
                } catch (IOException ex) {
                    logger.severe("PartnerTech cashdrawer pop failed");
                }
            } else {
                CashDrawerWindows cdWin = JKCashDrawer.getCashDrawerConfig().getCdWindows();
                byte[] cdByte = cdWin.getCashDrawerBytes();

                javax.print.PrintService ps = PrintServiceLookup.lookupDefaultPrintService();
                logger.info(("DEFAULT WINDOWS PRINT SERVICE NAME : ").concat(ps.getName()));
                try {
                    DocPrintJob job = ps.createPrintJob();
                    DocFlavor flav = DocFlavor.BYTE_ARRAY.AUTOSENSE;
                    Doc doc = new SimpleDoc(cdByte, flav, null);
                    job.print(doc, null);
                } catch (Exception e) {
                    logger.log(Level.SEVERE, e.getMessage(), e);
                }
            }
        } else {
            logger.info(("cash drawer pop for Serial on printer : ").concat(JKPrinter.getPrinterConfig().getPrintDriver()));
            if (JKCashDrawer.getCashDrawerConfig().isCashDrawerIo()) {
                logger.info("cash drawer pop for PartnerTech on Serial printer");
                try {
                    ProcessBuilder p = new ProcessBuilder();
                    p.command("PT6910CashDrawerKickA.exe");
                    p.start();
                } catch (IOException ex) {
                    logger.severe("PartnerTech cashdrawer pop failed");
                }
            } else {
                Printer printer = Printer.getInstance(JKPrinter.getPrinterConfig().getPrintDriver(),
                        JKPrinter.getPrinterConfig().getPrintPort(), JKPrinter.getPrinterConfig().getPrintBaud());
                printer.openCashDrawer();
            }
        }
    }
}
// http://keyhut.com/popopen.htm
// http://www.xcontractbridge.com/epos.htm
//
// Citizen CBM-230 	27,112,0,50,250
// Citizen CBM-231 	27,112,0,50,250
// Citizen CBM-232 	27,112,0,50,250
// Citizen CBM-233 	27,112,0,50,250
// Citizen CBM-253 	27,112,0,50,250
// Citizen CBM-262 	27,112,0,50,250
// Citizen CBM-1000 	27,112,0,50,250
// Citizen iDP-3210 	27,112,0,50,250
// Citizen iDP-3240 	27,112,0,50,250
// Citizen iDP-3310 	7
// Citizen CBM-1000 / CBM-1000 II 	27,112,0,50,250
// Epson M51PD          27,112,0,25,250
// Epson TM-T80P 	27,112,0,25,250
// Epson T88iii / TM-U200D 	27,112,0,25,250
// Epson T88iiiP / TM-U200D 	27,112,0,64,240
// Epson TM-88IV 	27,112,48,55,121
// Epson TM-88V 	27,112,48,55,121
// Epson M188D          27,112,48,55,121
// Epson TM-T20 	27,112,48,55,121
// Epson TM-T60 	27,112,32,25
// Epson TM-T70 	27,112,48,55,121
// Epson TM-T90 	27,112,0,25,250
// Epson TM-U200 	27,112,0,25,250
// Epson TM-U200B 	27,112,48,25,250
// Epson TM-U210PD 	27,112,0,25,250
// Epson TM-U220A 	27,112,0,25,250
// Epson TM-U295 	27,112,48,55,121
// Epson ADP 300 	27,112,0,25,250
// Epson TM-U950P 	27,112,0,50,250
// Epson LX-300+ 	27,112,0,25,250
// Epson TM-U300PD 	27,112,0,25,250
// Epson TM-U375 	27,112,0,25,250
// Epson M665A          27,112,48,55,121
// Epson TM-T883P 	27,112,0,50,250
// Epson TM-H6000 	27,112,48,55,121
// IBM 4610             7
// IBM 4610             27,112,0,50,250
// Ithaca PcOS 51 	27,112,0,25,250
// Ithaca PcOS 52 	27,112,0,25,250
// Ithaca 150           27,120,1
// NCR 7167             27,112,0,55
// NCR 7167             27,112,1,55
// Posiflex PP6000 	27,112,0,25,250
// Samsung 220          27,112,48,55,121
// Samsung SRP 270 	27,112,0,25,250
// Samsung SRP 270A 	27,112,0,64,240
// Samsung SRP 270AP 	27,112,48,55,121
// Samsung SRP 350 	27,110,0,25,250
// Star                 27,7,11,55,7
// Star TSP-100 	7
// Star TSP-600 	7
// Star TSP-700 	27,07,11,55,07
// TEC RKP300           27,112,0,100,250
// Toshiba SX2100 	27,112,32,55,255
// Toshiba TEC DRJST-51 27,112,0,100,250
// Wasp WPT-100 	27,112,49,48,48
