package jkiosk3.sales._favourites.nfc;

import aeonusers.User;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3.sales.SceneSales;
import jkiosk3.store.JKSystem;
import za.co.blt.consumer.loyalty.api.service.model.request.ConsumerProfileRequest;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfile;

public class NFCSubscriberEdit extends Region {

    private User nfcUser;
    private ConsumerProfile consumerProfile;
    private String subName;
    private String subSurname;
    private String subCellNum;
    private TextField txtSubName;
    private TextField txtSubSurname;
    private TextField txtSubCellNum;

    public NFCSubscriberEdit(User nfcUser, ConsumerProfile consumerProfile) {
        this.nfcUser = nfcUser;
        this.consumerProfile = consumerProfile;

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(getEditLayout(), getControlButtons());

        getChildren().add(vb);
    }

    private VBox getEditLayout() {

        VBox nfcHead = JKNode.getNFCpgHead("Subscriber Edit");

        VBox vBox = JKLayout.getVBoxContent(JKLayout.sp);

        vBox.getChildren().addAll(nfcHead, getInput());

        return vBox;
    }

    private GridPane getInput() {

        Label lblCardNum = JKText.getLblDk("Card Number", JKText.FONT_B_20);
        Label lblSubName = JKText.getLblDk("Name", JKText.FONT_B_20);
        Label lblSubSurname = JKText.getLblDk("Surname", JKText.FONT_B_20);
        Label lblSubCellNum = JKText.getLblDk("Cellphone Number", JKText.FONT_B_20);

        Text txtCardNum = JKText.getTxtDk(consumerProfile.getLoyaltyCard(), JKText.FONT_B_24);

        txtSubName = new TextField();
        txtSubName.setText(consumerProfile.getName());
        txtSubName.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtSubName, "Enter Subscriber First Name", "", false);
            }
        });
        txtSubSurname = new TextField();
        txtSubSurname.setText(consumerProfile.getSurname());
        txtSubSurname.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtSubSurname, "Enter Subscriber Surname", "", false);
            }
        });
        txtSubCellNum = new TextField();
        txtSubCellNum.setText(consumerProfile.getMobile());
        txtSubCellNum.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtSubCellNum, "Enter Cell Number", "");
            }
        });

        GridPane gridEdit = JKLayout.getContentGridInner2Col(0.50, 0.50);

        gridEdit.addRow(1, lblCardNum, txtCardNum);
        gridEdit.addRow(2, lblSubName, txtSubName);
        gridEdit.addRow(3, lblSubSurname, txtSubSurname);
        gridEdit.addRow(4, lblSubCellNum, txtSubCellNum);

        return gridEdit;
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons();

        ctrlBtns.getBtnAccept().setText("Update Details");
        ctrlBtns.getBtnAccept().getStyleClass().add("btnNFC");
        ctrlBtns.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (isValidEntry()) {
                    updateConsumerProfile();
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Subscriber Edit", "Please enter all required details", null);
                }
            }
        });
        ctrlBtns.getBtnCancel().getStyleClass().add("btnNFC");
        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new NFCMenu());
            }
        });

        return ctrlBtns;
    }

    private void updateConsumerProfile() {
        ConsumerProfileRequest consumerProfileRequest = new ConsumerProfileRequest();
        consumerProfileRequest.setLoyaltyCard(consumerProfile.getLoyaltyCard());
        consumerProfileRequest.setName(subName);
        consumerProfileRequest.setSurname(subSurname);
        consumerProfileRequest.setMobile(subCellNum);
        consumerProfileRequest.setDeviceId(JKSystem.getSystemConfig().getDeviceId());
        consumerProfileRequest.setDeviceUserId(nfcUser.getUserId());

        NFCUtil.updateConsumerProfile(consumerProfile, consumerProfileRequest, new NFCUtil.ConsumerProfileUpdateResult() {
            @Override
            public void consumerProfileUpdateResult(Boolean consumerProfileUpdated) {
                if (consumerProfileUpdated) {
                    JKiosk3.getMsgBox().showMsgBox("Subscriber Update", "Subscriber successfully updated", null);
                    NFCUtil.resetNFCView();
                } else {
                    NFCUtil.resetNFCView();
                }
            }
        });
    }

    private boolean isValidEntry() {
        if (txtSubName.getText().isEmpty()) {
            return false;
        } else {
            subName = txtSubName.getText();
        }
        if (txtSubSurname.getText().isEmpty()) {
            return false;
        } else {
            subSurname = txtSubSurname.getText();
        }
        if (txtSubCellNum.getText().isEmpty()) {
            return false;
        } else {
            subCellNum = txtSubCellNum.getText();
        }

        return true;
    }
}
