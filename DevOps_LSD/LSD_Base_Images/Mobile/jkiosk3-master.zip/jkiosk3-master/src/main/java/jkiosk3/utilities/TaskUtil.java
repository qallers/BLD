package jkiosk3.utilities;

import java.util.logging.Logger;
import javafx.concurrent.Worker;
import static javafx.concurrent.Worker.State.CANCELLED;
import static javafx.concurrent.Worker.State.FAILED;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SceneSales;

/**
 *
 *
 */
public class TaskUtil {

    private final static Logger logger = Logger.getLogger(TaskUtil.class.getName());

    /**
     * Instantiates a TaskUtil object which will be used to determine what happens when a Task State is
     * <code>CANCELLED</code> or <code>FAILED</code>
     */
    public TaskUtil() {
        //
    }

    /**
     * Determines what happens when a <code>Task</code> is <code>CANCELLED</code> or <code>FAILED</code> when trying to
     * establish a Connection.
     *
     * @param state the state of the <code>Task</code> when the error occurred
     * @param error an error message indicating why the error occurred
     * @param dest the <code>Region</code> (view) to which the User should be returned
     */
    public void taskConnectCancelFail(Worker.State state, String error, Region dest) {
        logger.info(("connect task cancelled or failed : ").concat(state.name()).concat(" : ").concat(error));
        taskCancelFail("Connection Error", "Connection Failed", state, error);
        if (dest != null) {
            SceneSales.clearAndChangeContent(dest);
        } else {
            SceneSales.clearAndChangeContent(null);
        }
    }

    /**
     * Determines what happens when a <code>Task</code> returns <code>null</code> when trying to establish a Connection.
     *
     * @param error an error message indicating why the error occurred
     * @param dest the <code>Region</code> (view) to which the User should be returned
     */
    public void taskConnectNull(String error, Region dest) {
        logger.info(("connect task returned null : ").concat(error));
        JKiosk3.getBusy().hideBusy();
        JKiosk3.getNumPad().hideNumPad();
//        JKiosk3.getMsgBox().hideMsgBox();
        String msgadd = "\n\nPlease check your network connection";
        JKiosk3.getMsgBox().showMsgBox("Connection Error", "\n\n" + error + msgadd, null);
        SceneSales.clearAndChangeContent(dest);
    }

    /**
     * Determines what happens when a <code>Task</code> is <code>CANCELLED</code> or <code>FAILED</code> when processing
     * a Sale item.
     *
     * @param header the header to show on the popup message box
     * @param msg the message to show on the popup message box
     * @param state the state of the <code>Task</code> when the error occurred
     * @param error an error message indicating why the error occurred
     * @param dest the <code>Region</code> (view) to which the User should be returned
     */
    public void taskSaleCancelFail(String header, String msg, Worker.State state, String error, Region dest) {
        logger.info(("sales task cancelled or failed : ").concat(state.name()).concat(" : ").concat(error));
        taskCancelFail(header, msg, state, error);
        if (dest != null) {
            SceneSales.clearAndChangeContent(dest);
        } else {
            SceneSales.clearAndChangeContent(null);
        }
    }
    
    /**
     * When a <code>Task</code> is <code>CANCELLED</code> or <code>FAILED</code> when processing
     * a Sale item, the <code>User</code> is returned to the logout screen.  On login, a Forced Reprint 
     * will be provided with which the basket may be re-populated.
     *
     * @param header the header to show on the popup message box
     * @param msg the message to show on the popup message box
     * @param state the state of the <code>Task</code> when the error occurred
     * @param error an error message indicating why the error occurred
     */
    public void taskSaleCancelFailLogout(String header, String msg, Worker.State state, String error) {
        JKiosk3.getBusy().hideBusy();
        JKiosk3.getNumPad().hideNumPad();
//        JKiosk3.getMsgBox().hideMsgBox();
        logger.info(("sales task cancelled or failed : ").concat(state.name()).concat(" : ").concat(error));
        JKiosk3.getMsgBox().showMsgBox(header, msg + "\n\n" + state.name() + "\n\n" + error, null, MessageBox.CONTROLS_SHOW, 
                MessageBox.MSG_OK, new MessageBoxResult() {

            @Override
            public void onOk() {
                JKiosk3.changeScene(new JKioskLogin());
            }

            @Override
            public void onCancel() {
                //
            }
        
        });
    }

    /**
     * Determines what happens when a <code>Task</code> is <code>CANCELLED</code> or <code>FAILED</code> when processing
     * an Emergency Topup, a Promotion or a Report or Reprint item.
     *
     * @param header the header to show on the popup message box
     * @param msg the message to show on the popup message box
     * @param state the state of the <code>Task</code> when the error occurred
     * @param error an error message indicating why the error occurred
     * @param dest the <code>Region</code> (view) to which the User should be returned
     */
    public void taskEmTopPromoReportCancelFail(String header, String msg, Worker.State state, String error, Region dest) {
        logger.info(("emergencytopup, promo, report task cancelled or failed : ").concat(state.name()).concat(" : ").concat(error));
        taskCancelFail(header, msg, state, error);
        JKiosk3.changeScene(dest);
    }

    /**
     * Determines what happens when a <code>Task</code> is <code>CANCELLED</code> or <code>FAILED</code> when processing
     * an User Login or Authentication.
     *
     * @param header the header to show on the popup message box
     * @param msg the message to show on the popup message box
     * @param state the state of the <code>Task</code> when the error occurred
     * @param error an error message indicating why the error occurred
     * @param dest the <code>Region</code> (view) to which the User should be returned
     */
    public void taskUserCancelFail(String header, String msg, Worker.State state, String error, Region dest) {
        logger.info(("users task cancelled or failed : ").concat(state.name()).concat(" : ").concat(error));
        taskCancelFail(header, msg, state, error);
        JKiosk3.changeScene(dest);
    }

    /**
     * Hides the Progress Indicator and builds the message to be shown to the User on the popup message box.
     *
     * @param header the header to show on the popup message box
     * @param msg the message to show on the popup message box
     * @param caller the <code>Class</code> from which the error originated
     * @param state the state of the <code>Task</code> when the error occurred
     * @param error an error message indicating why the error occurred
     */
    public void taskAdminCancelFail(String header, String msg, Class caller, Worker.State state, String error) {
        StringBuilder sb = new StringBuilder("\r\n");
        sb.append("----------------------------------------------------------------------------------------").append("\r\n");
        sb.append("Admin task cancelled or failed : ").append(state.name()).append("\r\n");
        sb.append("From calling class             : ").append(caller.getSimpleName()).append("\r\n");
        sb.append("Header                         : ").append(header).append("\r\n");
        sb.append("Message                        : ").append(msg).append("\r\n");
        sb.append("Error                          : ").append(error).append("\r\n");
        sb.append("----------------------------------------------------------------------------------------").append("\r\n");
        logger.info(sb.toString());
        taskCancelFail(header, msg, state, error);
    }

    /**
     * Hides the Progress Indicator and builds the message to be shown to the User on the popup message box.
     *
     * @param header the header to show on the popup message box
     * @param msg the message to show on the popup message box
     * @param state the state of the <code>Task</code> when the error occurred
     * @param error an error message indicating why the error occurred
     */
    private void taskCancelFail(String header, String msg, Worker.State state, String error) {
        JKiosk3.getBusy().hideBusy();
        JKiosk3.getNumPad().hideNumPad();
//        JKiosk3.getMsgBox().hideMsgBox();
        String msgadd = "\n\nPlease check your network connection";
        if (state.equals(CANCELLED)) {
            JKiosk3.getMsgBox().showMsgBox(header,
                    msg + "\n\n" + state + "\n\n" + "Operation timed out" + msgadd, null);
        } else if (state.equals(FAILED)) {
            JKiosk3.getMsgBox().showMsgBox(header, msg + "\n\n" + state + "\n\n" + error + msgadd, null);
        }
    }
}
