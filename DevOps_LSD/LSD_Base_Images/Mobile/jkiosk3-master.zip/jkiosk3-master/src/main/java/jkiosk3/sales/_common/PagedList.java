package jkiosk3.sales._common;

import java.util.List;
import javafx.scene.Node;
import javafx.scene.control.Pagination;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._components.MessageBox;

/**
 *
 * @author Val
 */
public class PagedList extends Region {

    private List<Node> listNodes;
    private int pageSize;

    public PagedList(List<Node> itemList, int pageCount) {
        this.listNodes = itemList;
        this.pageSize = pageCount;

        int numPgs = 0;
        if ((listNodes.size() % pageSize) == 0) {
            numPgs = listNodes.size() / pageSize;
        } else {
            numPgs = (listNodes.size() / pageSize) + 1;
        }
        //
        for (int i = 0; i < listNodes.size(); i++) {
            if ((i % 2) == 0) {
                listNodes.get(i).getStyleClass().add("altRowBackground");
            }
        }
        //
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return createPage(pg, MessageBox.getMsgWidth());
            }
        });
        getChildren().add(pages);
    }
    
    public PagedList(List<Node> itemList, int pageCount, final double pgWidth) {
        this.listNodes = itemList;
        this.pageSize = pageCount;

        int numPgs = 0;
        if ((listNodes.size() % pageSize) == 0) {
            numPgs = listNodes.size() / pageSize;
        } else {
            numPgs = (listNodes.size() / pageSize) + 1;
        }
        //
        for (int i = 0; i < listNodes.size(); i++) {
            if ((i % 2) == 0) {
                listNodes.get(i).getStyleClass().add("altRowBackground");
            }
        }
        //
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return createPage(pg, pgWidth);
            }
        });
        getChildren().add(pages);
    }

    private VBox createPage(int pageIndex, double pgW) {
        VBox vbPaged = JKLayout.getVBox(0, 0);
        vbPaged.setMaxWidth(pgW - (4 * JKLayout.sp));
        vbPaged.setMinWidth(pgW - (4 * JKLayout.sp));
        vbPaged.setMaxHeight(475);
        vbPaged.setMinHeight(475);

        int page = pageIndex * pageSize;

        int pageCount = 0;
        if (pageIndex > ((listNodes.size() / pageSize) - 1)) {
            pageCount = listNodes.size() % pageSize;
        } else {
            pageCount = pageSize;
        }
        for (int i = page; i < page + pageCount; i++) {
            vbPaged.getChildren().add(listNodes.get(i));
        }
        vbPaged.getChildren().add(JKNode.getVSpacer());

        return vbPaged;
    }
}
