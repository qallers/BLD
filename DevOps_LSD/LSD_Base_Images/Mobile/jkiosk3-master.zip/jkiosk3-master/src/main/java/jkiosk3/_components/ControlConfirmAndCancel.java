package jkiosk3._components;

import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

/**
 *
 * @author Val
 */
public class ControlConfirmAndCancel extends Region {

    private Button btnBack;
    private Button btnConfirm;
    private Button btnCancel;

    public ControlConfirmAndCancel() {
        getChildren().add(getBtnControls());
    }

    private HBox getBtnControls() {

        btnBack = JKNode.getBtnSm("Back");
        btnBack.setWrapText(true);

        btnCancel = JKNode.getBtnSm("Cancel");
        btnCancel.setWrapText(true);

        btnConfirm = JKNode.getBtnSm("Confirm");
        btnConfirm.setWrapText(true);

        HBox hb = JKLayout.getControlsHBox();

        hb.getChildren().addAll(btnBack, JKNode.getHSpacer(), btnCancel, JKNode.getHSpacer(), btnConfirm);

        return hb;
    }

    public Button getBtnCancel() {
        return btnCancel;
    }

    public Button getBtnBack() {
        return btnBack;
    }

    public Button getBtnConfirm() {
        return btnConfirm;
    }
}
