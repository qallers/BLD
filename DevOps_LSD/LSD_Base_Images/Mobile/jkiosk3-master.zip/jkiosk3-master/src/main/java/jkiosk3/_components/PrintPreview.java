package jkiosk3._components;

import aeonprinting.AeonPrintJob;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.web.WebView;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.PrintJobLayout;
import jkiosk3.printing.PrintUtil;
import jkiosk3.reports.ReportUtil;

public class PrintPreview extends Region {

    private final static double SP = JKLayout.sp;
    private final static double W = 575;
    private final static double H = 515;
    private Label lblPPHead;
    private Button btnOK;
    private Button btnCancel;
    private HBox hbBtns;
    private StackPane paneContent;
    private WebView htmlLines;
    private final PrintJobLayout pl;
    private AeonPrintJob aeonPrintJob;
    private String transRef;
    private boolean isForceBarcode;
    private PrintPreviewResult result;
    public final static byte PRN_OK = 1;
    public final static byte PRN_OK_CANCEL = 2;

    public PrintPreview() {
        pl = new PrintJobLayout();
        getChildren().add(getPrintPreviewStack());
    }

    private StackPane getPrintPreviewStack() {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getPrintPreviewGrp());

        return stack;
    }

    private Group getPrintPreviewGrp() {

        Group grp = new Group();

        Rectangle rec = new Rectangle();
        rec.setWidth(W);

        VBox vbox = JKLayout.getVBox(SP, SP);
        vbox.setPrefWidth(W);

        lblPPHead = JKText.getLblDk("A PrintPreview Box", JKText.FONT_B_SM);

        btnOK = JKNode.getBtnMsgBox("OK");
        btnOK.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onOkBtnEvent();
            }
        });

        btnCancel = JKNode.getBtnMsgBox("Cancel");
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onCancelBtnEvent();
            }
        });

        hbBtns = JKLayout.getHBox(0, SP);
        hbBtns.setPrefWidth(W);
        hbBtns.getChildren().addAll(btnOK, btnCancel);

        vbox.getChildren().addAll(lblPPHead, new Separator(), getContentPane(), new Separator(), hbBtns);

        rec.heightProperty().bind(vbox.heightProperty());

        grp.getChildren().addAll(rec, vbox);

        return grp;
    }

    private StackPane getContentPane() {
        paneContent = new StackPane();
        paneContent.setMaxWidth(W - (2 * SP));
        paneContent.setMinWidth(W - (2 * SP));
        paneContent.setPadding(new Insets(SP));

        htmlLines = new WebView();
        htmlLines.setMaxSize((W - (2 * SP)), H);

        paneContent.getChildren().add(htmlLines);

        return paneContent;
    }

    private void onOkBtnEvent() {
        if (transRef.equals("0")) {
            // This will be a non-sale item print
            PrintUtil.sendToPrinter(aeonPrintJob);
        } else {
            // Anything with a transRef will be a sale item print
            if (isForceBarcode) {
                PrintUtil.sendToPrinter(aeonPrintJob, transRef, true, true);
            } else {
                PrintUtil.sendToPrinter(aeonPrintJob, transRef, true, false);
            }
            // Anything with a transRef will be a sale item print
//            PrintUtil.sendToPrinter(aeonPrintJob, transRef, true);
        }
        clearContents();
        setVisible(false);
        toBack();
        if (result != null) {
            result.onOk();
        }
    }

    private void onCancelBtnEvent() {
        clearContents();
        setVisible(false);
        toBack();
        if (result != null) {
            result.onCancel();
        }
    }

    private void clearContents() {
        lblPPHead.setText("");
        paneContent.getChildren().clear();
    }

    public void showPrintPreview(String head, AeonPrintJob apj, byte prnType, PrintPreviewResult res) {
        showPrintPreview(head, apj, "0", prnType, res);
    }

    public void showPrintPreview(String head, AeonPrintJob apj, String transRef, byte prnType, PrintPreviewResult res) {
        this.result = res;
        lblPPHead.setText(head);

        hbBtns.getChildren().clear();
        switch (head) {
            case ReportUtil.REP_TRANS_LIST:
                btnOK.setText("Print");
                break;
            default:
                btnOK.setText("OK");
                break;
        }
        switch (prnType) {
            case PRN_OK:
            default:
                hbBtns.getChildren().add(btnOK);
                break;
            case PRN_OK_CANCEL:
                hbBtns.getChildren().addAll(btnOK, btnCancel);
                break;
        }

        if (apj != null) {
            this.aeonPrintJob = apj;
            this.transRef = transRef;
            paneContent.getChildren().clear();
            htmlLines.getEngine().loadContent(pl.getPrintLinesPreview(aeonPrintJob));
            paneContent.getChildren().add(htmlLines);
            this.setVisible(true);
            this.toFront();
        }
    }

    public void showPrintPreview(String head, AeonPrintJob apj, String transRef, byte prnType, boolean isForceBarcode, PrintPreviewResult res) {
        this.isForceBarcode = isForceBarcode;
        showPrintPreview(head, apj, transRef, prnType, res);
    }
}
