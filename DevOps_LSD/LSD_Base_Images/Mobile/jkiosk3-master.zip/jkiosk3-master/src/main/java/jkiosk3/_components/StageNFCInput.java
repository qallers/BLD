package jkiosk3._components;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales._favourites.nfc.NFCUtil;
import za.co.blt.ACRReader;

import javax.smartcardio.CardException;
import java.awt.*;

public class StageNFCInput extends Region {

    private Stage stageParent;
    private String nfcTransType;
    private String cardNumber;
    private boolean newCard;
    private boolean showSearch;
    private double inputHeight;
    private TextField txtTapCard;
    private Keyboard keyboard;
    private MessageBox messageBox;
    private StageNFCInputResult result;

    public StageNFCInput(Stage stageParent, Dimension dim, String nfcTrans, boolean newCard, boolean showSearch, StageNFCInputResult result) {
        this.stageParent = stageParent;
        this.nfcTransType = nfcTrans;
        this.newCard = newCard;
        this.showSearch = showSearch;
        this.result = result;

        if (showSearch) {
            inputHeight = 325;
        } else {
            inputHeight = 225;
        }

        keyboard = new Keyboard();
        keyboard.setVisible(false);

        messageBox = new MessageBox();
        messageBox.setVisible(false);

        StackPane stackPane = new StackPane();
        stackPane.setPrefSize(dim.getWidth(), dim.getHeight());
        stackPane.getChildren().addAll(keyboard, messageBox, getInputLayout());

        getChildren().add(stackPane);

        txtTapCard.requestFocus();
        onClickReset();
        onClickCardRead(txtTapCard);
    }

    private VBox getInputLayout() {
        double popupWidth = JKLayout.contentW;

        Label label = JKText.getLblDk(nfcTransType, JKText.FONT_B_24);

        Button btnOK = JKNode.getBtnMsgBox("OK");
        btnOK.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (isValidRead()) {
                    onClickOK();
                } else {
                    cardNumber = txtTapCard.getText();
                    if (isValidScan()) {
                        onClickOK();
                    }
                }
            }
        });

        Button btnCancel = JKNode.getBtnMsgBox("Cancel");
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickCancel();
            }
        });

        HBox hBox = JKLayout.getHBox(0, JKLayout.sp);
        hBox.setPrefWidth(popupWidth - (2 * JKLayout.sp));
        hBox.getChildren().addAll(btnOK, btnCancel);

        VBox vBox = JKLayout.getVBoxContent(JKLayout.sp);
        vBox.setMaxSize(popupWidth, inputHeight);
        vBox.setMinSize(popupWidth, inputHeight);
        vBox.getChildren().addAll(label, new Separator(), getNFCReadBox(), new Separator(), hBox);

        return vBox;
    }

    private GridPane getNFCReadBox() {

        Label lblTapCard = JKText.getLblDk("Tap or Scan Card", JKText.FONT_B_20);
        Label lblEnterSearch = JKText.getLblDk("Search", JKText.FONT_B_20);

        txtTapCard = getTextFieldNFC("Click here, then tap or scan card");
        txtTapCard.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                txtTapCard.clear();
                txtTapCard.setStyle("-fx-font-size: 20pt;");
                onClickCardRead(txtTapCard);
            }
        });

        Button btnReset = JKNode.getBtnPopup("reset");
        btnReset.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickReset();
            }
        });

        HBox hbTapCard = JKLayout.getHBox(0, JKLayout.sp);
        hbTapCard.getChildren().addAll(txtTapCard, btnReset);

        if (nfcTransType.equalsIgnoreCase(NFCUtil.NFC_LOST_CARD) && !newCard) {
            hbTapCard.setDisable(true);
        }

        Label lblOr = JKText.getLblDk("OR", JKText.FONT_B_20);
        lblOr.setTranslateX(2 * JKLayout.sp);

        final TextField txtSearch = getTextFieldNFC("Card or Cell Number");
        txtSearch.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                txtSearch.setStyle("-fx-font-size: 18pt;");
                keyboard.showKeyboard(txtSearch, "Enter Card or Cell Number", "", false, false,
                        new KeyboardResult() {
                            @Override
                            public void onDone(String value) {
                                cardNumber = value;
                            }
                        });
            }
        });

        Button btnSearch = JKNode.getBtnPopup("search");
        btnSearch.setDisable(true);
        btnSearch.setVisible(false);

        HBox hbSearch = JKLayout.getHBox(0, JKLayout.sp);
        hbSearch.getChildren().addAll(txtSearch, btnSearch);

        GridPane gridPane = JKLayout.getContentGridInner2ColInScroll(0.40, 0.60, HPos.RIGHT);
        GridPane.setColumnSpan(gridPane, 2);

        gridPane.addRow(0, lblTapCard, hbTapCard);
        if (showSearch) {
            gridPane.addRow(2, lblOr);
            gridPane.addRow(3, lblEnterSearch, hbSearch);
        }

        return gridPane;
    }

    private TextField getTextFieldNFC(String promptText) {
        final TextField textField = new TextField();
        textField.setMaxHeight(37);
        textField.setMinHeight(37);
        HBox.setHgrow(textField, Priority.ALWAYS);
        textField.setStyle("-fx-font-size: 12pt;");
        textField.setPromptText(promptText);
        textField.setFocusTraversable(false);
        return textField;
    }

    private void onClickCardRead(final TextField textField) {
        try {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    ACRReader acr = new ACRReader();
                    try {
                        if (acr.isACRReaderReady()) {
                            String cardUid = acr.getCardUid();
                            if (cardUid != null) {
                                textField.setText(cardUid);
                                cardNumber = cardUid;
                            } else {
                                showCardReaderError("Unable to determine Card Number");
                            }
                        }
                    } catch (CardException ce) {
                        showCardReaderError(ce.getClass().getSimpleName());
                    } catch (Exception e) {
                        showCardReaderError(e.getClass().getSimpleName());
                    }
                }
            }).start();
        } catch (NullPointerException | IllegalArgumentException e) {
            showCardReaderError(e.getClass().getSimpleName());
        }
    }

    private void onClickOK() {
        try {
            result.onDone(cardNumber);
            stageParent.close();
        } catch (NullPointerException npe) {
            stageParent.close();
            showCardReaderError(npe.getClass().getSimpleName());
        }
    }

    private void onClickCancel() {
        stageParent.close();
    }

    private void onClickReset() {
        cardNumber = "";
        txtTapCard.clear();
        txtTapCard.setStyle("-fx-font-size: 12pt;");
    }

    private void showCardReaderError(final String errorMsg) {
        onClickReset();
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                String msg = errorMsg + ("\n\nPlease click 'reset' and try again");
                messageBox.showMsgBox("Card Reader Error", msg, null);
            }
        });
    }

    private boolean isValidRead() {
        if (cardNumber == null || cardNumber.isEmpty()) {
            return false;
        }
        return true;
    }

    private boolean isValidScan() {
        if (cardNumber == null || cardNumber.isEmpty()) {
            messageBox.showMsgBox("Card Number", "Please tap, scan or enter a Card Number", null);
            return false;
        }
        return true;
    }
}
