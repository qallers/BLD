package jkiosk3.sales.ticketpro.cache;

import aeonticketpros.TicketProsCategoryList;
import aeonticketpros.TicketProsEventList;
import javafx.application.Platform;
import jkiosk3._common.ResultCallback;
import jkiosk3.sales.ticketpro.TicketProUtil;

import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Logger;

public class CacheControllerTicketPro {

    private final static Logger logger = Logger.getLogger(CacheControllerTicketPro.class.getName());

    public CacheControllerTicketPro() {
        // variables will be initialised as required
    }

    public void updateTPCache(boolean checkFileTime, final ResultCallback resultCallback) {
        if (checkFileTime) {
            long timecurrent = System.currentTimeMillis();
            long timeupdate = 1000L * 60L * 60L;    // 1 hour
//            long timeoutdated = 1000L * 60L * 3L;    // 3 mins - testing
            long timepassed = CacheTPCatAndEvent.checkFileTime() + timeupdate;
            logger.info("From menu - update only if necessary");
            if (!CacheTPCatAndEvent.hasCategoryItems() || !CacheTPCatAndEvent.hasEventItems() || timecurrent >= timepassed) {
                getOnlineTPCache(resultCallback);
            } else {
                Timer t = new Timer();
                t.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        resultCallback.onResult(true);
                    }
                }, 350);
            }
        } else {
            logger.info("User requested cache update NOW");
            getOnlineTPCache(resultCallback);
        }
    }

    private void getOnlineTPCache(final ResultCallback resultCallback) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                getOnlineTPCategoryAndEventsCache(resultCallback);
            }
        }).start();
    }

    private void getOnlineTPCategoryAndEventsCache(final ResultCallback resultCallback) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                TicketProUtil.getTicketProCategoryList(true, new TicketProUtil.TicketProCategoryListResult() {
                    @Override
                    public void tpCategoryListResult(final TicketProsCategoryList tpCategoryList) {
                        if (tpCategoryList.isSuccess()) {
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    TicketProUtil.getTicketProEventsAllList(true, new TicketProUtil.TicketProEventListAllResult() {
                                        @Override
                                        public void tpEventListAllResult(TicketProsEventList tpEventListAllResult) {
                                            if (tpEventListAllResult.isSuccess() && !tpEventListAllResult.getListEvents().isEmpty()) {
                                                CacheTPCatAndEvent.saveTPCategoriesAndEvents(tpCategoryList, tpEventListAllResult);
                                                logger.info(" * * * TicketPro Categories and Events Cache successfully updated * * * ");
                                                // allow mini-time (1 sec) to write file to HDD before continuing next operation
                                                Timer t = new Timer();
                                                t.schedule(new TimerTask() {
                                                    @Override
                                                    public void run() {
                                                        resultCallback.onResult(true);
                                                    }
                                                }, 1000);
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    }
                });
            }
        });
    }
}
