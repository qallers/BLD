package jkiosk3.sales.billpay.payat;

import aeonbillpayments.TrafficFine;
import aeonbillpayments.payat.PayAtAccPayReq;
import aeonbillpayments.payat.PayAtFinePayResp;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3.sales._common.JKTenderToggles;

/**
 *
 * @author Val
 */
public class SummaryPayAtTrafficFine extends Region {

    private final TrafficFine trafficFine;
    private final PayAtFinePayResp response;
    private final String tendered;

    public SummaryPayAtTrafficFine(PayAtAccPayReq rq, PayAtFinePayResp resp, String tenderType) {
        this.tendered = tenderType;
        this.response = resp;

        trafficFine = resp.getFine();
        getChildren().add(getSummaryGrid());
    }

    private GridPane getSummaryGrid() {
        String txtTender = JKTenderToggles.getTxtForTender(tendered);

        Label lblLocalAuthority = JKText.getLblDk("Local Authority", JKText.FONT_B_XSM);
        Label lblNoticeNo = JKText.getLblDk("Notice Number", JKText.FONT_B_XSM);
        Label lblVehicleReg = JKText.getLblDk("Vehicle Registration", JKText.FONT_B_XSM);
        Label lblDateAndTime = JKText.getLblDk("Offence Date", JKText.FONT_B_XSM);
        Label lblTenderType = JKText.getLblDk("Tender Type", JKText.FONT_B_XSM);
        Label lblAmount = JKText.getLblDk("Amount", JKText.FONT_B_XSM);
        Label lblConvenienceFee = JKText.getLblDk("Convenience Fee", JKText.FONT_B_XSM);
        Label lblTotalPayable = JKText.getLblDk("Total Payable", JKText.FONT_B_XSM);

        // filled-in fields
        Text txtLocalAuthority = new Text();
        if (trafficFine.getLocalAuthorityName() != null) {
            txtLocalAuthority = JKText.getTxtDk(trafficFine.getLocalAuthorityName(), JKText.FONT_B_XSM);
        } else {
            txtLocalAuthority = JKText.getTxtDk("Not Available", JKText.FONT_B_XSM);
        }

        Text txtNoticeNo = JKText.getTxtDk(trafficFine.getNoticeNumber(), JKText.FONT_B_XSM);

        Text txtVehicleReg = new Text();
        if (trafficFine.getVehicleRegNumber() != null) {
            txtVehicleReg = JKText.getTxtDk(trafficFine.getVehicleRegNumber(), JKText.FONT_B_XSM);
        } else {
            txtVehicleReg = JKText.getTxtDk("Not Available", JKText.FONT_B_XSM);
        }

        Text txtDateAndTime = new Text();
        if (trafficFine.getOffenceDateTime() != null) {
            String offenceDate = JKText.getDateDisplay(trafficFine.getOffenceDateTime());
            txtDateAndTime = JKText.getTxtDk(offenceDate, JKText.FONT_B_XSM);
        } else {
            txtDateAndTime = JKText.getTxtDk("Not Available", JKText.FONT_B_XSM);
        }
        
        Text txtTenderType = JKText.getTxtDk(txtTender, JKText.FONT_B_XSM);
        Text txtAmount = JKText.getTxtDk(JKText.getDeciFormat(trafficFine.getAmountDue()), JKText.FONT_B_XSM);
        Text txtConvenienceFee = JKText.getTxtDk(JKText.getDeciFormat(response.getConvenienceFee()), JKText.FONT_B_XSM);
        double totalPayable = trafficFine.getAmountDue() + response.getConvenienceFee();
        Text txtTotalPayable = JKText.getTxtDk(JKText.getDeciFormat(totalPayable), JKText.FONT_B_SM);

        GridPane grid = JKLayout.getSummaryGrid2Col(0.4, 0.6);
        grid.setTranslateX(-JKLayout.sp);

        grid.addRow(0, lblLocalAuthority, txtLocalAuthority);
        grid.addRow(1, lblNoticeNo, txtNoticeNo);
        grid.addRow(2, lblVehicleReg, txtVehicleReg);
        grid.addRow(3, lblDateAndTime, txtDateAndTime);
        grid.addRow(4, lblTenderType, txtTenderType);
        grid.addRow(5, lblAmount, txtAmount);
        grid.addRow(6, lblConvenienceFee, txtConvenienceFee);
        grid.addRow(7, lblTotalPayable, txtTotalPayable);

        return grid;
    }
}
