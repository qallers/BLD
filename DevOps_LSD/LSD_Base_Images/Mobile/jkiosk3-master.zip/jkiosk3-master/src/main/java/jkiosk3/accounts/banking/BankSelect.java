package jkiosk3.accounts.banking;

import aeonreports.Account;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

import java.util.*;

/**
 * @author Valerie
 */
public class BankSelect extends Region {

    private final Account selectedAccount;
    Bank bnks = new Bank(); // create banks object

    public BankSelect(Account selectedAccount) {
        this.selectedAccount = selectedAccount;
        getChildren().add(getBankNames());
    }

    private VBox getBankNames() {

        VBox vbHead = JKNode.getPageHeadVB("Bank");

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getMenuButtons());

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private List<Button> getMenuButtons() {
        List<Button> btnList = new ArrayList<>();

//        List<String> btnLabels = new ArrayList<String> ();
//        if (bnks.getBankName ().contains ("ABSA") && bnks.getAccountNumber () != null) {
//            btnLabels.add (SceneBanking.BANK_ABSA);
//        }

        for (final String s : getButtonLabels()) {
            final Button btn = JKNode.getBtnSmDbl(s);

            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(s);
                }
            });
            btnList.add(btn);
        }

        return btnList;
    }

    private void getMenuAction(String bankName) {

        SceneBanking.getVbBankAccContent().getChildren().clear();
        SceneBanking.getVbBankAccContent().getChildren().add(new BankAccSelect(selectedAccount, bankName));
    }

    private List<String> getButtonLabels() {
        Set<String> bankSet = new HashSet<>();
        List<AccountType> accountTypes = AccountDepositDetail.getAccountTypeList();
        for (AccountType accountType : accountTypes) {
            for (DepositType depositType : accountType.getListDepositTypes()) {
                for (Bank bank : depositType.getListBanks()) {
                    bankSet.add(bank.getBankName());
                }
            }
        }
        List<String> list = new ArrayList<>(bankSet);
        Collections.sort(list);
        return list;
    }

}
