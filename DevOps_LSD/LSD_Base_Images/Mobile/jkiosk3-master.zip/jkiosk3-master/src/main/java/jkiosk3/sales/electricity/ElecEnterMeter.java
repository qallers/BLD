package jkiosk3.sales.electricity;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.KeyboardResult;
import jkiosk3.sales._favourites.nfc.NFCUtilFav;
import jkiosk3.store.JKOptions;

import java.util.List;

/**
 *
 * @author Valerie
 */
public class ElecEnterMeter extends Group {

    private final ElecEnterMeterResult result;
    private final ElectricityProvider provider;
    private final String transaction;
    private ComboBox cbMeter;
    private TextField txtMeterNum;
    private String meterNum = "";
    private boolean magEntry;
    private boolean showFavourites;

    public ElecEnterMeter(ElectricityProvider selectedProvider, String transaction, ElecEnterMeterResult res) {
        this.provider = selectedProvider;
        this.transaction = transaction;
        this.result = res;
        this.showFavourites = false;

        checkMeterNumFav();

        getChildren().add(getMeterEntryGrid());
    }

    private void checkMeterNumFav() {
        if (transaction.equalsIgnoreCase(ElectricityUtil.ELEC_TOKEN)) {
            System.out.println("transaction is token");
            if (!NFCUtilFav.getElectricityMeterNumsFav(provider).isEmpty()) {
                showFavourites = true;
                List<String> listMeterNums = NFCUtilFav.getElectricityMeterNumsFav(provider);
                cbMeter = new ComboBox();
                cbMeter.setMaxWidth((JKLayout.contentW - (3 * JKLayout.sp)) / 2);
                cbMeter.setMinWidth((JKLayout.contentW - (3 * JKLayout.sp)) / 2);
                cbMeter.setEditable(true);
                cbMeter.setItems(FXCollections.observableArrayList(listMeterNums));
                cbMeter.getEditor().setOnMouseReleased(new EventHandler() {
                    @Override
                    public void handle(Event event) {
                        JKiosk3.getKeyboard().showKeyboard(cbMeter.getEditor(), "Enter Meter Number", "", true, false,
                                new KeyboardResult() {
                                    @Override
                                    public void onDone(String value) {
                                        magEntry = JKiosk3.getKeyboard().isMagEntry();
                                        meterNum = value;
                                        if (magEntry) {
                                            cbMeter.getEditor().setText("TrackData");
                                            cbMeter.getEditor().setDisable(true);
                                        } else {
                                            cbMeter.getEditor().setText(value);
                                            cbMeter.getEditor().setDisable(false);
                                        }
                                        onDoneAction();
                                    }
                                });
                    }
                });
                cbMeter.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue observable, String oldValue, String newValue) {
                        System.out.println("oldValue = " + oldValue + " - newValue = " + newValue);
                        meterNum = newValue;
                        System.out.println("meterNum = " + meterNum);
                    }
                });
//                cbMeter.getSelectionModel().select(0);

//                meterNum = NFCUtilFav.getElectricityMeterNumsFav(provider).get(0);
//                txtMeterNum.setText(meterNum);
//                txtMeterNum.setDisable(true);
            }
        }
    }

    private GridPane getMeterEntryGrid() {
        Label lblUpdate = JKText.getLblDk("Electricity " + transaction + " - " + provider.getDisplayName(), JKText.FONT_B_XSM);

        Label lblMeter = JKText.getLblDk("Meter Number", JKText.FONT_B_XSM);

        txtMeterNum = new TextField();
        txtMeterNum.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtMeterNum, "Enter Meter Number", "", true, false,
                            new KeyboardResult() {
                                @Override
                                public void onDone(String value) {
                                    magEntry = JKiosk3.getKeyboard().isMagEntry();
                                    meterNum = value;
                                    if (magEntry) {
                                        txtMeterNum.setText("TrackData");
                                        txtMeterNum.setDisable(true);
                                    } else {
                                        txtMeterNum.setText(value);
                                        txtMeterNum.setDisable(false);
                                    }
                                    onDoneAction();
                                }
                            });
                }
            }
        });

        GridPane grid = JKLayout.getGridContent2Col(0.5, 0.5);

        grid.add(lblUpdate, 0, 0, 2, 1);
        grid.add(JKNode.createGridSpanSep(2), 0, 1);

        if (showFavourites) {
            grid.addRow(3, lblMeter, cbMeter);
        } else {
            grid.addRow(3, lblMeter, txtMeterNum);
        }

        return grid;
    }

    private void onDoneAction() {
        if (result != null) {
            result.onDone();
        }
    }

    public TextField getTxtMeterNum() {
        return txtMeterNum;
    }

    public String getMeterNum() {
        return meterNum;
    }

//    public void setMeterNum(String meterNum) {
//        this.meterNum = meterNum;
//    }

    public boolean isMagEntry() {
        return magEntry;
    }
}
