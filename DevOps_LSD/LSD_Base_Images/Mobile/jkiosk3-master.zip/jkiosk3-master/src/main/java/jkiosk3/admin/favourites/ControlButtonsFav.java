package jkiosk3.admin.favourites;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;

public class ControlButtonsFav extends Region {

    private Button btnSave;

    public ControlButtonsFav() {
        getChildren().add(getBtnControls());
    }

    private HBox getBtnControls() {

        btnSave = JKNode.getBtnPopupDbl("Save");
        btnSave.setFont(JKText.FONT_B_20);

        Button btnCancel = JKNode.getBtnPopupDbl("Cancel");
        btnCancel.setFont(JKText.FONT_B_20);
        btnCancel.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneFavourites.clearAndChangeContent(null);
            }
        });

        HBox hb = JKLayout.getControlsHBox();

        hb.getChildren().addAll(JKNode.getHSpacer(), btnSave, btnCancel);

        return hb;
    }

    public Button getBtnSave() {
        return btnSave;
    }
}
