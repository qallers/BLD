package jkiosk3.store;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import jkiosk3.JK3Config;

/**
 *
 * @author Val
 */
public class Store {

    //private static String basePath = "store\\";
    public static boolean saveObject(String name, Object obj) {
        boolean res = false;
        try {
            new File(JK3Config.getStore()).mkdirs();
            FileOutputStream fout = new FileOutputStream(JK3Config.getStore() + name);
            ObjectOutputStream oos = new ObjectOutputStream(fout);
            oos.writeObject(obj);
            oos.close();
            res = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    public static Object loadObject(String name) {
        Object res = null;
        try {
            new File(JK3Config.getStore()).mkdirs();
            File objFile = new File(JK3Config.getStore() + name);
            if (objFile.exists()) {
                FileInputStream fin = new FileInputStream(objFile);
                ObjectInputStream ois = new ObjectInputStream(fin);
                res = ois.readObject();
                ois.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    public static void deleteObject(String name) {
        try {
            File objFile = new File(JK3Config.getStore() + name);
            if (objFile.exists()) {
                objFile.delete();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static long getFileTimestamp(String name) {
        long timestamp = 0;
        File filename = new File(JK3Config.getStore() + name);
        if (filename.exists()) {
            timestamp = filename.lastModified();
        }
        return timestamp;
    }
}
