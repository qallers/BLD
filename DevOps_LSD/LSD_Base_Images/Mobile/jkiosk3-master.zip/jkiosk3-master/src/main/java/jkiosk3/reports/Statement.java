package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.Account;
import aeonreports.AccountList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.reports.ReportUtil.AeonPrintJobResult;

/**
 *
 * @author Val
 */
public class Statement extends Region {

    private final static Logger logger = Logger.getLogger(Statement.class.getName());
    private ObservableList listAccObserv;
    private Account selectedAcc;
    private TextField txtDays;
    private int statementDays;

    public Statement() {
        ReportUtil.getAccountList(new ReportUtil.AccountListResult() {
            @Override
            public void accountListResult(final AccountList accountList) {
                if (accountList.isSuccess()) {
                    listAccObserv = FXCollections.observableArrayList();
                    for (Account acc : accountList.getAccounts()) {
                        listAccObserv.add(acc);
                    }

                    VBox vb = JKLayout.getVBox(0, 5);

                    vb.getChildren().add(getStatementGroup());
                    vb.getChildren().add(getPrintControl());

                    getChildren().addAll(vb);

                } else {
                    JKiosk3.getMsgBox().showMsgBox("Statement",
                            "Error retrieving list of Accounts\n\n" + accountList.getErrorText(),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    SceneReports.getVbReportContent().getChildren().clear();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private GridPane getStatementGroup() {
        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);

        VBox vbHead = JKNode.getReportHeadVB("Statements");

        Label lblAccNo = JKText.getLblDk("Account", JKText.FONT_B_XSM);

        Label lblDays = JKText.getLblDk("No of Days", JKText.FONT_B_XSM);

        ComboBox comAcc = new ComboBox();
        comAcc.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.75), 35);
        comAcc.setItems(listAccObserv);
        comAcc.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue ov, Object oldValue, Object newValue) {
                if (newValue != null) {
                    selectedAcc = (Account) newValue;
                }
            }
        });

        txtDays = new TextField();
        txtDays.setPromptText("days");
        txtDays.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event arg0) {
                JKiosk3.getNumPad().showNumPad(txtDays, "Enter Days", "");
            }
        });

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblAccNo, comAcc);
        grid.addRow(2, lblDays, txtDays);

        return grid;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                showStatementReport();
            }
        };
    }

    private void showStatementReport() {
        if (inputValidation()) {
            try {
                if (isUseDays()) {
                    ReportUtil.getPrintReport(ReportUtil.REP_STATEMENT, selectedAcc.getAccountId(), statementDays,
                            new AeonPrintJobResult() {
                                @Override
                                public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                                    PrintHandler.handlePrintRequestReport("Statement Report for " + statementDays + " days",
                                            aeonPrintJob);
                                }
                            });
                }
            } catch (Exception e) {
                logger.log(Level.SEVERE, e.getMessage(), e);
            }
            resetForm();
        }
    }

    private boolean inputValidation() {
        boolean validated = false;

        if (isAccountValid()) {
            if (txtDays.getText().equals("")) {
                JKiosk3.getMsgBox().showMsgBox("Days", "Days cannot be empty", null);
                validated = false;
            } else if (isUseDays()) {
                validated = true;
            }
        }

        return validated;
    }

    private boolean isAccountValid() {
        if (selectedAcc == null) {
            JKiosk3.getMsgBox().showMsgBox("Account Selection", "Please select an Account from the list", null);
            return false;
        }
        return true;
    }

    private boolean isUseDays() {
        boolean useDays = false;

        if ((!txtDays.getText().equals(""))) {
            try {
                statementDays = Integer.parseInt(txtDays.getText());
                useDays = true;
            } catch (NumberFormatException nfe) {
                JKiosk3.getMsgBox().showMsgBox("Days", "Number of days must be entered correctly", null);
                logger.log(Level.SEVERE, nfe.getMessage(), nfe);
            }
        }

        return useDays;
    }

    private void resetForm() {
        int n = SceneReports.getVbReportContent().getChildren().size();
        if (n > 1) {
            SceneReports.getVbReportContent().getChildren().remove(1, n);
        }
    }
}
