package jkiosk3.admin.favourites.fav_cache;

import aeonfavourites.FavouriteItem;
import jkiosk3.store.Store;

import java.util.List;

public class CacheFavouriteCustomStore {

    private static volatile FavouriteCustomStore favouriteCustomStore;

    private static FavouriteCustomStore getFavouriteCustomStore() {
        if (favouriteCustomStore == null) {
            favouriteCustomStore = ((FavouriteCustomStore) Store.loadObject(CacheFavouriteCustomStore.class.getSimpleName()));
        }
        if (favouriteCustomStore == null) {
            favouriteCustomStore = new FavouriteCustomStore();
        }
        return favouriteCustomStore;
    }

    public static boolean saveFavouriteStore(List<FavouriteItem> listFavouritesUpdate) {
        deleteCacheFavouriteStore();
        // should now be null, need to make a new one before adding list
        getFavouriteCustomStore();
        favouriteCustomStore.setListFavouriteItem(listFavouritesUpdate);
        return Store.saveObject(CacheFavouriteCustomStore.class.getSimpleName(), favouriteCustomStore);
    }

    public static boolean hasFavouriteStoreItems() {
        getFavouriteCustomStore();
        return !favouriteCustomStore.getListFavouriteItem().isEmpty();
    }

    public static List<FavouriteItem> getListFavouriteItems() {
        getFavouriteCustomStore();
        return favouriteCustomStore.getListFavouriteItem();
    }

    public static void deleteCacheFavouriteStore() {
        Store.deleteObject(CacheFavouriteCustomStore.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheFavouriteCustomStore.class.getSimpleName());
    }
}
