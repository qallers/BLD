package jkiosk3.sales.rica;

import aeonrica.Registration;
import aeonrica.RicaConnection;
import aeonrica.RicaResponse;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3.store.JKDialup;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Val
 */
public class RICAUtil {

    private final static Logger logger = Logger.getLogger(RICAUtil.class.getName());
    public final static String NEW_REG = "New Registration";
    public final static String CHANGE_CELL_NUM = "Change Owner\nCell Phone Number";
    public final static String CHANGE_SIM_SP = "Change Owner\nSIM or SP Number";
    //
    private static String registrationType;
    //
    private static String userPin;
    private static String agentCode;
    private static String agentPwd;
    private final static int ricaDeviceId = 45;
    private final static String ricaDeviceSer = "93n367fvk393";
    private static RicaConnection rc;
    private static RicaResponse ricaResp;
    //
    private static boolean chOwnCell = false;
    private static boolean chOwnSimSp = false;
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 60;

    public RICAUtil(){
        rc = null;
    }

    private static RicaConnection getRicaConnect() {

//        String ricaServer = "196.38.158.103";
//        int ricaPort = 7894;
        rc = null;

        String ricaServer = JK3Config.getSSLRicaServer();
        int ricaPort = Integer.parseInt(JK3Config.getSSLRicaPort());
        final boolean SSL = true;

        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            rc = new RicaConnection(ricaServer, ricaPort, SSL);
            rc.setTimeout(countdownTime);

            logger.log(Level.INFO, String.format("Rica Server Connected: %s, Port: %s",
                    ricaServer, ricaPort));
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);

            rc = ricaConnectNonSecureServer();
        } catch (NoRouteToHostException nre) {
            errorMsg = nre.getClass().getSimpleName() + " : " + nre.getMessage();
            logger.log(Level.SEVERE, nre.getMessage(), nre);

            rc = ricaConnectNonSecureServer();
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);

            rc = ricaConnectNonSecureServer();
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);

            rc = ricaConnectNonSecureServer();
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);

            rc = ricaConnectNonSecureServer();
        }


        return rc;
    }

    public static RicaConnection ricaConnectNonSecureServer(){
        RicaConnection ricaConnection = null;
        String ricaServer = JK3Config.getNonSSLRicaServer();
        int ricaPort = Integer.parseInt(JK3Config.getNonSSLRicaPort());;
        final boolean SSL = false;

        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }

        try {
            ricaConnection = new RicaConnection(ricaServer, ricaPort, SSL);
            ricaConnection.setTimeout(countdownTime);

            logger.log(Level.INFO, " ", ricaServer);

            logger.log(Level.INFO, String.format("Rica Server Connected: %s, Port: %s",
                    ricaServer, ricaPort));
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (NoRouteToHostException nre) {
            errorMsg = nre.getClass().getSimpleName() + " : " + nre.getMessage();
            logger.log(Level.SEVERE, nre.getMessage(), nre);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }

        return ricaConnection;
    }

    private static boolean isAgentLoggedIn(String pin, String code, String pwd) {
        boolean loggedIn = false;

        rc = getRicaConnect();
        try {
            if (rc.login(pin, ricaDeviceId, ricaDeviceSer)) {
                if (rc.checkUser(code, pwd, ricaDeviceId, ricaDeviceSer)) {
                    loggedIn = true;
                }
            }
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }

        return loggedIn;
    }

    private static RicaResponse queryCellNumber(String cellNum) throws RuntimeException {
        RicaResponse response = null;
        try {
            if (isAgentLoggedIn(userPin, agentCode, agentPwd)) {
                response = rc.queryMsisdn(agentCode, agentPwd, ricaDeviceId, "testing", cellNum);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("RICA Query Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }

        return response;
    }

    private static RicaResponse submitRicaRegistration(Registration reg) throws RuntimeException {
        try {
            if (isAgentLoggedIn(userPin, agentCode, agentPwd)) {
                if (!isChOwnCell() && !isChOwnSimSp()) {
                    ricaResp = rc.doRegistration(agentCode, agentPwd, ricaDeviceId, "testReg", reg);
                } else {
                    ricaResp = rc.doChangeOwner(agentCode, agentPwd, ricaDeviceId, "testChOwn", reg);
                }
            } else {
                JKiosk3.getMsgBox().showMsgBox("RICA Login Failed", "Invalid Agent Code or Password", null);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("RICA Registration Error", t);
        } finally {
            if (rc != null) {
                rc.disconnect();
            }
        }
        return ricaResp;
    }

    // getters and setters
    public static String getUserPin() {
        return userPin;
    }

    public static void setUserPin(String userPin) {
        RICAUtil.userPin = userPin;
    }

    public static String getAgentCode() {
        return agentCode;
    }

    public static void setAgentCode(String agentCode) {
        RICAUtil.agentCode = agentCode;
    }

    public static String getAgentPwd() {
        return agentPwd;
    }

    public static void setAgentPwd(String agentPwd) {
        RICAUtil.agentPwd = agentPwd;
    }

    public static boolean isChOwnCell() {
        return chOwnCell;
    }

    public static void setChOwnCell(boolean chOwnCell) {
        RICAUtil.chOwnCell = chOwnCell;
    }

    public static boolean isChOwnSimSp() {
        return chOwnSimSp;
    }

    public static void setChOwnSimSp(boolean chOwnSimSp) {
        RICAUtil.chOwnSimSp = chOwnSimSp;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void isAgentLoggedIn(final String pin, final String code, final String pwd, final LoggedInResult result) {
        JKiosk3.getBusy().showBusy("RICA Agent Login");

        final Task<Boolean> task = new Task() {
            @Override
            protected Boolean call() throws Exception {
                return isAgentLoggedIn(pin, code, pwd);
            }
        };

        task.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    if (task.getValue() != null) {
                        JKiosk3.getBusy().hideBusy();
                        result.isLoggedInResult(task.getValue());
                    } else {
                        errorMsg = "Unable to establish connection";
                        taskutil.taskConnectNull(errorMsg, new RICALogin());
                    }
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
                    taskutil.taskSaleCancelFail("Agent Login",
                            "Agent Login Error", newState, errorMsg, new RICALogin());
                }
            }
        });
        new Thread(task).start();
        JKiosk3.getBusy().startCountdown(task, countdownTime);
    }

    public static void queryCellNumber(final String cellNum, final RicaResponseResult result) {
        JKiosk3.getBusy().showBusy("RICA Query");

        final Task<RicaResponse> task = new Task() {
            @Override
            protected RicaResponse call() throws Exception {
                return queryCellNumber(cellNum);
            }
        };

        task.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    if (task.getValue() != null) {
                        JKiosk3.getBusy().hideBusy();
                        result.ricaResponseResult(task.getValue());
                    } else {
                        errorMsg = "Unable to establish connection";
                        taskutil.taskConnectNull(errorMsg, new RICAMenu());
                    }
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
                    taskutil.taskSaleCancelFail("RICA Query",
                            "RICA Query Error", newState, errorMsg, new RICAMenu());
                }
            }
        });
        new Thread(task).start();
        JKiosk3.getBusy().startCountdown(task, countdownTime);
    }

    public static void submitRicaRegistration(final Registration reg, final RicaResponseResult result) {
        JKiosk3.getBusy().showBusy("RICA Registration");

        final Task<RicaResponse> task = new Task() {
            @Override
            protected RicaResponse call() throws Exception {
                return submitRicaRegistration(reg);
            }
        };

        task.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    if (task.getValue() != null) {
                        JKiosk3.getBusy().hideBusy();
                        result.ricaResponseResult(task.getValue());
                    } else {
                        errorMsg = "Unable to establish connection";
                        taskutil.taskConnectNull(errorMsg, new RICAMenu());
                    }
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
                    taskutil.taskSaleCancelFail("RICA Registration",
                            "RICA Registration Error", newState, errorMsg, new RICAMenu());
                }
            }
        });
        new Thread(task).start();
        JKiosk3.getBusy().startCountdown(task, countdownTime);
    }

    public static abstract class LoggedInResult {

        public abstract void isLoggedInResult(boolean isLoggedIn);
    }

    public static abstract class RicaResponseResult {

        public abstract void ricaResponseResult(RicaResponse ricaResponse);
    }

    //
    public static String getRegistrationType() {
        return registrationType;
    }

    public static void setRegistrationType(String registrationType) {
        RICAUtil.registrationType = registrationType;
    }
}
