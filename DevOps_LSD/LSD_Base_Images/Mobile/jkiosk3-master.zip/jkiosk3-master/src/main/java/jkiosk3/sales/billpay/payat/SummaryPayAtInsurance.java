package jkiosk3.sales.billpay.payat;

import aeonbillpayments.payat.PayAtIPPayReq;
import aeonbillpayments.payat.PayAtIPPayResp;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales.billpay._common.BillPaymentMenu;

/**
 *
 * @author Val
 */
public class SummaryPayAtInsurance extends Region {

    private final PayAtIPPayReq req;
    private final PayAtIPPayResp resp;
    private final int months;
    private final double premium;
    private final String tendered;

    public SummaryPayAtInsurance(PayAtIPPayReq rq, PayAtIPPayResp rs, int mths, double prem, String tenderType) {
        this.req = rq;
        this.resp = rs;
        this.months = mths;
        this.premium = prem;
        this.tendered = tenderType;

        if (resp.getFirstName() == null && resp.getLastName() == null) {
            JKiosk3.getMsgBox().showMsgBox("Insurance Policy Payment", "Unable to verify Client Details.", null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                @Override
                public void onOk() {
                    SceneSales.clearAndChangeContent(new BillPaymentMenu());
                }

                @Override
                public void onCancel() {
                    //
                }
            });
        } else {
            getChildren().add(getSummaryGrid());
        }
    }

    private GridPane getSummaryGrid() {

        Label lblPaying = JKText.getLblDk("Policy Number", JKText.FONT_B_XSM);
        Label lblClientName = JKText.getLblDk("Client Name", JKText.FONT_B_XSM);
        Label lblContactNum = JKText.getLblDk("Contact Number", JKText.FONT_B_XSM);
        Label lblClientAddress = JKText.getLblDk("Client Address", JKText.FONT_B_XSM);
        Label lblTenderType = JKText.getLblDk("Tender Type", JKText.FONT_B_XSM);
        Label lblPremium = JKText.getLblDk("Premium", JKText.FONT_B_XSM);
        Label lblMonths = JKText.getLblDk("Months", JKText.FONT_B_XSM);
        Label lblAmountDue = JKText.getLblDk("Amount Due", JKText.FONT_B_XSM);
        Label lblConvenienceFee = JKText.getLblDk("Convenience Fee", JKText.FONT_B_XSM);
        Label lblTotalPayable = JKText.getLblDk("Total Payable", JKText.FONT_B_XSM);

        // filled-in fields
        Text txtPolNum = JKText.getTxtDk(req.getPolicyNumber(), JKText.FONT_B_SM);

        Text txtClientName = JKText.getTxtDk(resp.getFirstName() + " " + resp.getLastName(), JKText.FONT_B_SM);
        txtClientName.setWrappingWidth((MessageBox.getMsgWidth() - (6 * JKLayout.sp)) * 0.6);
        txtClientName.setTextAlignment(TextAlignment.RIGHT);

        String contactNum = "";
        if (resp.getContactNumber() != null) {
            if (resp.getContactNumber().matches("^0(\\d{9})")) {
                contactNum = JKText.getCellNumFormatted(resp.getContactNumber());
            } else {
                contactNum = resp.getContactNumber();
            }
        } else {
            contactNum = "Not Available";
        }
        Text txtContactNum = JKText.getTxtDk(contactNum, JKText.FONT_B_XSM);

        String address = "";
        if (resp.getAddress() != null) {
            address = resp.getAddress();
        } else {
            address = "Not Available";
        }
        Text txtClientAddress = JKText.getTxtDk(address, JKText.FONT_B_XSM);
        txtClientAddress.setWrappingWidth((MessageBox.getMsgWidth() - (6 * JKLayout.sp)) * 0.6);
        txtClientAddress.setTextAlignment(TextAlignment.RIGHT);

        String txtTender = JKTenderToggles.getTxtForTender(tendered);
        Text txtTenderType = JKText.getTxtDk(txtTender, JKText.FONT_B_XSM);
        Text txtPremium = JKText.getTxtDk(JKText.getDeciFormat(premium), JKText.FONT_B_XSM);
        Text txtMonths = JKText.getTxtDk(Integer.toString(months), JKText.FONT_B_XSM);
        Text txtAmountDue = JKText.getTxtDk(JKText.getDeciFormat(req.getAmount()), JKText.FONT_B_XSM);

        Text txtConvenienceFee = JKText.getTxtDk(JKText.getDeciFormat(resp.getConvenienceFee()), JKText.FONT_B_XSM);
        double totalPayable = req.getAmount() + resp.getConvenienceFee();
        Text txtTotalPayable = JKText.getTxtDk(JKText.getDeciFormat(totalPayable), JKText.FONT_B_SM);

        GridPane grid = JKLayout.getSummaryGrid2Col(0.4, 0.6);
        grid.setTranslateX(-JKLayout.sp);

        grid.addRow(0, lblPaying, txtPolNum);
        grid.addRow(1, lblClientName, txtClientName);
        grid.addRow(2, lblContactNum, txtContactNum);
        grid.addRow(3, lblClientAddress, txtClientAddress);
        grid.addRow(4, lblTenderType, txtTenderType);
        grid.addRow(5, lblPremium, txtPremium);
        grid.addRow(6, lblMonths, txtMonths);
        grid.addRow(7, lblAmountDue, txtAmountDue);
        grid.addRow(8, lblConvenienceFee, txtConvenienceFee);
        grid.addRow(9, lblTotalPayable, txtTotalPayable);

        return grid;
    }
}
