package jkiosk3.sales.rica;

import aeonrica.RicaResponse;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3.sales.SceneSales;

/**
 *
 * @author Val
 */
public class RICAQuery extends Region {

    private TextField txtCellNum;

    public RICAQuery() {
        VBox vb = JKLayout.getVBox(0, 5);

        vb.getChildren().addAll(getQueryEntry(), getControlButtons());

        getChildren().add(vb);
    }

    private GridPane getQueryEntry() {

        Label lblHead = JKText.getLblContentHead("Query by...");

        Label lblCellNum = JKText.getLblDk("Cell Number", JKText.FONT_B_XSM);
        lblCellNum.setMinWidth(JKLayout.btnSmW);

        txtCellNum = new TextField();
        txtCellNum.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtCellNum, "Cell Number", "");
            }
        }); 

        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);

        grid.add(lblHead, 0, 0, 2, 1);
        grid.add(JKNode.createGridSpanSep(2), 0, 1);

        grid.add(lblCellNum, 0, 2);

        grid.add(txtCellNum, 1, 2);

        return grid;
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons();

        ctrlBtns.getBtnAccept().setText("Query");
        ctrlBtns.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                submitQuery();
            }
        });
        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new RICAMenu());
            }
        });

        return ctrlBtns;
    }

    private void submitQuery() {
        String cellNum = txtCellNum.getText();
        final String cellDisplay = JKText.getCellNumFormatted(cellNum);

        RICAUtil.queryCellNumber(cellNum, new RICAUtil.RicaResponseResult() {
            @Override
            public void ricaResponseResult(RicaResponse ricaResponse) {
                JKiosk3.getMsgBox().showMsgBox(ricaResponse.getMessage(), cellDisplay + "\n\n" + ricaResponse.getMessageDetails(), null);
            }
        });
    }
}
