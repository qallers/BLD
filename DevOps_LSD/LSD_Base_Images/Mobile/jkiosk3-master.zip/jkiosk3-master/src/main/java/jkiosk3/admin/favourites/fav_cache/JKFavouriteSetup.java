package jkiosk3.admin.favourites.fav_cache;

import jkiosk3.store.Store;

public class JKFavouriteSetup {

    private static volatile StoreJKFavouriteSetup favouriteSetup;

    public static StoreJKFavouriteSetup getFavouriteSetupStore() {
        if (favouriteSetup == null) {
            favouriteSetup = ((StoreJKFavouriteSetup) Store.loadObject(JKFavouriteSetup.class.getSimpleName()));
        }
        if (favouriteSetup == null) {
            favouriteSetup = new StoreJKFavouriteSetup();
        }
        return favouriteSetup;
    }

    public static boolean saveFavouriteSetup() {
        getFavouriteSetupStore();
        return Store.saveObject(JKFavouriteSetup.class.getSimpleName(), favouriteSetup);
    }

    public static void deleteFavouriteSetup() {
        Store.deleteObject(JKFavouriteSetup.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(JKFavouriteSetup.class.getSimpleName());
    }
}
