package jkiosk3.sales.billpay;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.Product;
import aeonbillpayments.Provider;
import javafx.concurrent.Task;
import jkiosk3.JKiosk3;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.store.cache.CacheListBillPaymentProviders;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Val
 */
public class BillPayUtilConnect {

    private final static Logger logger = Logger.getLogger(BillPayUtilConnect.class.getName());
    private static BillPaymentConnection bpc;
    //
    private static List<BillPayProduct> billPayList;
    private static List<BillPayProduct> trafFineList;
    private static List<BillPayProduct> insurePayList;
    private static List<BillPayProduct> m2mTransferList;
    //
    private final static TaskUtil TASK_UTIL = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    public final static int COUNTDOWN_TIME = 60;

    public static BillPaymentConnection getBillPaymentConnect() {
        bpc = null;
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            bpc = new BillPaymentConnection(JKSystem.getSystemConfig().getServer(), JKSystem.getSystemConfig().getPort(), JKSystem.getSystemConfig().isSecureConn());
            bpc.setTimeout(COUNTDOWN_TIME);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (NoRouteToHostException nre) {
            errorMsg = nre.getClass().getSimpleName() + " : " + nre.getMessage();
            logger.log(Level.SEVERE, nre.getMessage(), nre);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return bpc;
    }

    private static boolean isLoggedIn(String pin, String transType) throws RuntimeException {
        String loyaltyProfileId = "";
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            loyaltyProfileId = ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId();
        } else {
            System.out.println("no active nfc subscriber profile");
        }

        boolean loggedIn = false;

        try {
            if (bpc != null) {
                loggedIn = bpc.login(pin, JKSystem.getSystemConfig().getDeviceId(), JKSystem.getSystemConfig().getSerial(), transType, loyaltyProfileId);
//                loggedIn = bpc.login(pin, JKSystem.getSystemConfig().getDeviceId(), JKSystem.getSystemConfig().getSerial(), transType);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    /* ----- TEST THIS BEFORE FINALISING RETRIEVAL OF LISTS!!! ----- */
    private static Void getBillPayProvidersAndProducts() throws RuntimeException {
        List<Provider> listProviders = new ArrayList<>();

        if (CacheListBillPaymentProviders.hasItems()) {
            listProviders = CacheListBillPaymentProviders.getListBillPaymentProviders();
            makeBillPayProductLists(listProviders);
        } else {
            listProviders = getOnlineBillPaymentProviderList();
            makeBillPayProductLists(listProviders);
        }
        return null;
    }

    private static List<Provider> getOnlineBillPaymentProviderList() throws RuntimeException {
        List<Provider> listProviders = new ArrayList<>();

        try {
            bpc = getBillPaymentConnect();

            if (isLoggedIn(CurrentUser.getUser().getUserPin(), BillPaymentConnection.BILLPAY_VAS_PRODUCTS)) {
                listProviders = bpc.getProductList();
            }

        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Product List Error", t);
        } finally {
            if (bpc != null) {
                bpc.disconnect();
            }
        }
        return listProviders;
    }

    private static void makeBillPayProductLists(List<Provider> listProviders) {
        int count = 0;
        for (Provider p : listProviders) {
            count += p.getProvProducts().size();
        }
        System.out.println("Bill Payment Product count : " + count);

        billPayList = new ArrayList<>();
        trafFineList = new ArrayList<>();
        insurePayList = new ArrayList<>();
        m2mTransferList = new ArrayList<>();
        for (Provider p : listProviders) {
            for (Product pp : p.getProvProducts()) {
                BillPayProduct bpProd = new BillPayProduct();
                switch (p.getProvName()) {
                    case BillPayUtilMisc.PAYAT_BILL_PAY:
//                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.PAYAT_BILL_PAYMENT, BPTransType.BILLPAY_PAYAT_ACCOUNT);
                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_PAYAT_ACCOUNT);
                        billPayList.add(bpProd);
                        break;
                    case BillPayUtilMisc.PAYAT_INSURANCE:
//                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.PAYAT_INSURANCE_POLICY, BPTransType.BILLPAY_PAYAT_INSURANCE);
                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_PAYAT_INSURANCE);
                        insurePayList.add(bpProd);
                        break;
                    case BillPayUtilMisc.PAYAT_TRAFFIC_FINES:
//                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.PAYAT_TRAFFIC_FINE, BPTransType.BILLPAY_PAYAT_TRAFFIC);
                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_PAYAT_TRAFFIC);
                        trafFineList.add(bpProd);
                        break;
                    case BillPayUtilMisc.SYNTELL_BILL_PAY:
//                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.SYNTELL_BILL_PAYMENT, BPTransType.BILLPAY_SYNTELL_ACCOUNT);
                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_SYNTELL_ACCOUNT);
                        billPayList.add(bpProd);
                        break;
                    case BillPayUtilMisc.SYNTELL_TRAFFIC_FINES:
//                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.SYNTELL_TRAFFIC_FINE, BPTransType.BILLPAY_SYNTELL_TRAFFIC);
                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_SYNTELL_TRAFFIC);
                        trafFineList.add(bpProd);
                        break;
                    case BillPayUtilMisc.SAPO_BILL_PAY:
//                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.SAPO_BILL_PAYMENT, BPTransType.BILLPAY_SAPO_ACCOUNT);
                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_SAPO_ACCOUNT);
                        billPayList.add(bpProd);
                        break;
                    case BillPayUtilMisc.BLU_BILL_PAY:
//                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.BLU_BILL_PAYMENT, BPTransType.BILLPAY_BLU_ACCOUNT);
                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_BLU_ACCOUNT);
                        billPayList.add(bpProd);
                        break;
                    case BillPayUtilMisc.BLU_M2M_TRANSFER:
//                        bpProd = makeCopyBillPayProduct(p, pp, ProviderType.BLU_M2M_TRANSFER, BPTransType.BILLPAY_BLU_M2M);
                        bpProd = makeCopyBillPayProduct(p, pp, BPTransType.BILLPAY_BLU_M2M);
                        m2mTransferList.add(bpProd);
                        break;
                    default:
                        break;
                }
            }
        }

        Collections.sort(billPayList, new Comparator<BillPayProduct>() {
            @Override
            public int compare(BillPayProduct p1, BillPayProduct p2) {
                return p1.getProdName().compareToIgnoreCase(p2.getProdName());
            }
        });

        Collections.sort(insurePayList, new Comparator<BillPayProduct>() {
            @Override
            public int compare(BillPayProduct p1, BillPayProduct p2) {
                return p1.getProdName().compareToIgnoreCase(p2.getProdName());
            }
        });

        Collections.sort(trafFineList, new Comparator<BillPayProduct>() {
            @Override
            public int compare(BillPayProduct p1, BillPayProduct p2) {
                return p1.getProdName().compareToIgnoreCase(p2.getProdName());
            }
        });

        Collections.sort(m2mTransferList, new Comparator<BillPayProduct>() {
            @Override
            public int compare(BillPayProduct p1, BillPayProduct p2) {
                return p1.getProdName().compareToIgnoreCase(p2.getProdName());
            }
        });

    }

//    private static BillPayProduct makeCopyBillPayProduct(Provider prov, Product prod, ProviderType provType, BPTransType bpTransType) {
    private static BillPayProduct makeCopyBillPayProduct(Provider prov, Product prod, BPTransType bpTransType) {
        BillPayProduct prodPay = new BillPayProduct();
        prodPay.setProvId(prov.getProvId());
        prodPay.setProvName(prov.getProvName());
        prodPay.setProdId(prod.getProdId());
        prodPay.setProdName(prod.getProdName());
        prodPay.setVerify(prod.isVerify());
        prodPay.setFullAmount(prod.isFullAmount());
        prodPay.setAdditionalFields(prod.getAdditionalFields());
        prodPay.setProdMaxAmount(prod.getProdMaxAmount());
        prodPay.setProdMinAmount(prod.getProdMinAmount());
        prodPay.setEnforceFullPayment(prod.isEnforceFullPayment());
        prodPay.setLogoId(prod.getLogoId());

        List<String> listTenders = new ArrayList<>();
        for (String s : prod.getPaymentType()) {
            String str = s.replaceAll(" ", "").toLowerCase(Locale.ENGLISH);
            listTenders.add(str);
        }
        prodPay.setTendersAllowed(listTenders);
        prodPay.setReversalSupported(false);
//        prodPay.setProvType(provType);
        prodPay.setBpTransType(bpTransType);

        return prodPay;
    }

    /*----------------*/
 /* Busy Indicator */
 /*----------------*/
    public static void getProviderProductLists(final ListBillPayments bpList) {
        JKiosk3.getBusy().showBusy("Getting Product List");

        final Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                return getBillPayProvidersAndProducts();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                bpList.listBillPayments(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("Error",
                        "Error Retrieving Product List", State.CANCELLED, errorMsg, new BillPaymentMenu());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("Error",
                        "Error Retrieving Product List", State.FAILED, errorMsg, new BillPaymentMenu());
            }
        };

        new Thread(task).start();
        JKiosk3.getBusy().startCountdown(task, COUNTDOWN_TIME);
    }

    public abstract static class ListBillPayments {

        public abstract void listBillPayments(Void list);
    }

    public abstract static class ListBillPaymentProvidersResult {

        public abstract void listBillPayProviderResult(List<Provider> listProviderResult);
    }
//
    // getters and setters

    public static List<BillPayProduct> getBillPayList() {
        return billPayList;
    }

    public static List<BillPayProduct> getInsurePayList() {
        return insurePayList;
    }

    public static List<BillPayProduct> getTrafFineList() {
        return trafFineList;
    }

    public static List<BillPayProduct> getM2MTransferList() {
        return m2mTransferList;
    }

    public static BillPaymentConnection getBpc() {
        bpc = getBillPaymentConnect();
        return bpc;
    }

    public static boolean isLoggedIn(String transactType) {
        return isLoggedIn(CurrentUser.getSalesUser().getUserPin(), transactType);
    }

    public static String getErrorMsg() {
        return errorMsg;
    }
}
