package jkiosk3.reports;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

/**
 *
 * @author Val
 */
public abstract class SceneReportControls extends Region {
    
    public SceneReportControls() {
        getChildren().add(getPrintControls("Print"));
    }

    public SceneReportControls(String strBtnText) {
        getChildren().add(getPrintControls(strBtnText));
    }

    public abstract void onClickPrint();

    private HBox getPrintControls(String strText) {

        Button btnPrint = JKNode.getBtnSm(strText);
        btnPrint.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickPrint();
            }
        });

        HBox hb = JKLayout.getControlsHBox();
        hb.getStyleClass().add("hbContent");

        hb.getChildren().addAll(JKNode.getHSpacer(), btnPrint);

        return hb;
    }
}
