package jkiosk3._common;

import Download.HttpUtils;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import jkiosk3.JK3Config;
//import jkiosk3.utilities.HttpUtils;

/**
 *
 * @author Val
 */
public class JKMedia {

    private final static Logger logger = Logger.getLogger(JKMedia.class.getName());

    public static boolean isStylesheetDownload() {

        new File(JK3Config.getBasePath()).mkdirs();

//        if (HttpUtils.httpDownload(JK3Config.getProviderStyle(), JK3Config.getMediaProviderStyle(), true, "got file")) {
        if (HttpUtils.httpDownload(JK3Config.getProviderStyle(), JK3Config.getMediaProviderStyle(), true, null)) {
            System.out.println("we got the style file!");
            System.out.println("Input file  = " + JK3Config.getProviderStyle());
            System.out.println("Output File = " + JK3Config.getMediaProviderStyle());
            return true;
        } else {
            System.out.println("oops, not got style file");
            return false;
        }
    }

//    public static List<JKNews> downloadNews() {
//        new File(INSTALL_PATH_NEWS).mkdirs();
//
//        List<JKNews> listNews = new ArrayList<>();
//        if (fetchNewsList()) {
//            listNews = makeNewsItems();
//        }
//
//        List<JKNews> listNewsTemp = new ArrayList<>();
//        for (JKNews jkrn : listNews) {
//            if (jkrn.getReleaseVersion().equals(Version.getVersionNum())) {
//                jkNews = jkrn;
//            }
//        }
//        return listNewsTemp;
//    }
//
//    private static boolean fetchNewsList() {
//        if (Version.isLive()) {
//            return HttpUtils.httpDownload(SERVER_PATH + SERVER_FOLDER_NEWS + FILENAME_NEWS_LIVE,
//                    INSTALL_PATH_NEWS + FILENAME_NEWS_LIVE, true, "message");
//        } else {
//            return HttpUtils.httpDownload(SERVER_PATH + SERVER_FOLDER_NEWS + FILENAME_NEWS_DEMO,
//                    INSTALL_PATH_NEWS + FILENAME_NEWS_DEMO, true, "message");
//        }
//    }
//
//    private static List<JKNews> makeNewsItems() {
//        List<JKNews> listNewsItems = new ArrayList<>();
//        Element notes;
//        SAXBuilder builder = new SAXBuilder();
//        File file;
//        if (Version.isLive()) {
//            file = new File(INSTALL_PATH_NEWS + FILENAME_NEWS_LIVE);
//        } else {
//            file = new File(INSTALL_PATH_NEWS + FILENAME_NEWS_DEMO);
//        }
//        try {
//            notes = builder.build(file).getRootElement().getChild("Notes");
//            for (Object upd : notes.getChildren("Update")) {
//                Element update = (Element) upd;
//                JKNews jkr = new JKNews();
//                jkr.setReleaseVersion(update.getChildTextTrim("Version"));
//                jkr.setReleaseDate(update.getChildTextTrim("Date"));
//
//                List<JKNewsItem> listItems = new ArrayList<>();
//                for (Object itm : update.getChild("Items").getChildren("Item")) {
//                    Element item = (Element) itm;
//                    JKNewsItem newItem = new JKNewsItem();
//                    newItem.setTitle(item.getChildTextTrim("Title"));
//                    newItem.setDescription(item.getChildTextTrim("Description"));
//                    listItems.add(newItem);
//                }
//                jkr.setListItems(listItems);
//
//                listNewsItems.add(jkr);
//            }
//        } catch (JDOMException | IOException e) {
//            e.printStackTrace();
//        }
//
//        return listNewsItems;
//    }
//
//    // getter
//    public static JKNews getJkNews() {
//        return jkNews;
//    }
    public static void createMediaFolder(String folderPath) {
        File f = new File(folderPath);
//        int fileCount = 15;
        try {
//            if (f.exists() && f.listFiles().length > fileCount) {
//                for (File file : f.listFiles()) {
//                    file.delete();
//                }
//                f.delete();
//                f.mkdirs();
//            } else if (!f.exists()) {
//                f.mkdirs();
//            }
            if (!f.exists()) {
                f.mkdirs();
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
    }

    public static void checkFolderSize(List<File> listFiles, String folderPath, int fileCount) {
        Collections.sort(listFiles, new Comparator<File>() {
            @Override
            public int compare(File f1, File f2) {
                return Long.compare(f1.lastModified(), f2.lastModified()) * -1;
            }
        });
        int listSize = listFiles.size();
        if (listSize > fileCount) {
            ListIterator<File> li = listFiles.listIterator(fileCount);
            while (li.hasNext()) {
                File fileNext = li.next();
                fileNext.delete();
            }
//        } else {
//            logger.info(("No files to be removed from : ").concat(folderPath));
        }
    }
}
