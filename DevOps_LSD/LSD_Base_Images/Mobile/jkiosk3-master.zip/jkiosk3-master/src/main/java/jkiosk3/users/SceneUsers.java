package jkiosk3.users;

import aeonusers.User;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3.SceneMenu;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

/**
 *
 * @author Val
 */
public class SceneUsers extends Region {

    private List<User> listUsers = new ArrayList<>();
    private static VBox vbUsersContent;
    private static ListView listViewUsers;
    private final static double infoHt = 300;

    public SceneUsers() {
        if (UserUtil.getUserList() != null) {
            listUsers = UserUtil.getUserList();
        } else {
            System.out.println("user list is null here - have to contact server");
            UserUtil.getOnlineUsersList(CurrentUser.getUser().getUserPin(), new UserUtil.ListUsersResult() {

                @Override
                public void listUsersResult(List<User> userList) {
                    if (listUsers != null) {
                        listUsers = userList;
                    }
                }
            });
        }
        getChildren().add(JKLayout.getSceneStack(getUsersLayout(), this));
    }

    private AnchorPane getUsersLayout() {
        VBox menu = getUserMenu();
        vbUsersContent = JKLayout.getVBox(0, JKLayout.spNum);
        ListView listUsersView = getUserListView();
//        Group grpInfo = JKLayout.getSceneInfoGroup(infoHt, listUsersView);
        VBox grpInfo = JKLayout.getSceneInfoBox(infoHt, listUsersView);
        VBox grpClose = JKLayout.getMainMenuBtn(new SceneMenu());

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(grpInfo, grpClose);

        AnchorPane ap = JKLayout.getSceneAnchor(menu, vbUsersContent, vb);

        ap.getChildren().addAll(menu, vbUsersContent, vb);

        return ap;
    }

    private VBox getUserMenu() {
        String[] btnLabels = {"Add User", "Edit User", "Print User List"};

        List<Button> btnList = new ArrayList<>();

        for (String s : btnLabels) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuSelection(btn);
                }
            });
            btnList.add(btn);
        }

        return JKLayout.getSceneMenuBtnGroup("", btnList);
    }

    private ListView getUserListView() {
        listViewUsers = new ListView();
//        listViewUsers.setMaxSize((JKLayout.sideW - (2 * JKLayout.spNum)), (infoHt - (2 * JKLayout.spNum)));
        listViewUsers.setMaxSize((JKLayout.sideW - (1 * JKLayout.spNum)), (infoHt - (1 * JKLayout.spNum)));
//        listViewUsers.setTranslateX(JKLayout.spNum);
//        listViewUsers.setTranslateY(JKLayout.spNum);
        listViewUsers.getStyleClass().add("small-table");

        ObservableList<String> users = UserUtil.getUsersByPin(listUsers);
        listViewUsers.setItems(users);

        return listViewUsers;
    }

    private void getMenuSelection(Button b) {
        switch (b.getText()) {
            case "Add User":
                clearAndChangeContent(new UserAdd());
                break;
            case "Edit User":
                clearAndChangeContent(new UserEdit());
                break;
            case "Print User List":
                clearAndChangeContent(new UserListPrint());
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("User Error", "Unspecified selection.", null);
        }
    }

    public static void clearAndChangeContent(Region newRegion) {
        vbUsersContent.getChildren().clear();
        vbUsersContent.getChildren().add(newRegion);
    }

    public static VBox getVbUsersContent() {
        return vbUsersContent;
    }

    public static ListView getListViewUsers() {
        return listViewUsers;
    }
}
