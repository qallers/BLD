package jkiosk3.sales.search;

import jkiosk3.sales.SalesItems;
import jkiosk3.sales.electricity.ElectricityProvider;

import java.util.ArrayList;
import java.util.List;

public class CreateElectricityProduct {

    public static List<SearchProduct> createElectricityProducts() {
        final String ELECTRICITY = "Electricity";

        List<SearchProduct> products = new ArrayList<>();
        for (ElectricityProvider electricityProvider : SalesItems.getElecSuppliers()) {
            SearchProduct networkProvider = new SearchProduct();

            String airtimeName = electricityProvider.getDisplayName();

            networkProvider.setProvName(airtimeName);
            networkProvider.setProdName(String.format("%s %s", airtimeName.startsWith("x") ? airtimeName.substring(1) : airtimeName, ELECTRICITY));
            networkProvider.setSearchTransType(SearchTransType.ELECTRICITY);
            networkProvider.setElectricityProvider(electricityProvider);

            products.add(networkProvider);
        }

        return products;
    }

}
