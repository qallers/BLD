package jkiosk3.store;

import aeonusers.UserTransactionType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author
 */
public class StoreJKTransTypes implements Serializable {

    private static final long serialVersionUID = 13333L;
    private final List<UserTransactionType> listUtTypes = new ArrayList<>();

    public List<UserTransactionType> getListUtTypes() {
        return listUtTypes;
    }
}
