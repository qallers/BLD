package jkiosk3.sales.rica;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;

/**
 *
 * @author Val
 */
public class SubReg3 extends Region {

    private TextField txtAddr1;
    private TextField txtAddr2;
    private TextField txtAddrSuburb;
    private TextField txtAddrCity;
    private ComboBox comAddrProvince;
    private TextField txtAddrPostCode;
    private TextField txtCountry;
    private CheckBox chkAddrVerified;

    public SubReg3() {
        setId(SubAll.REG_PG_3);

        getChildren().add(getSubPg3());
    }

    private GridPane getSubPg3() {
        GridPane grid = JKLayout.getContentGridInner2Col(0.33, 0.67);

        double w = JKLayout.contentW;

        Label lblPhysAddr = JKText.getLblDk("Physical Address", JKText.FONT_B_SM);

        Label lblAddr1 = JKText.getLblDk("Address 1", JKText.FONT_B_XSM);
        lblAddr1.setPrefWidth(JKLayout.btnSmW);
        Label lblAddr2 = JKText.getLblDk("Address 2", JKText.FONT_B_XSM);
        Label lblAddrSuburb = JKText.getLblDk("Suburb", JKText.FONT_B_XSM);
        Label lblAddrCity = JKText.getLblDk("City / Town", JKText.FONT_B_XSM);
        Label lblAddrProvince = JKText.getLblDk("Province", JKText.FONT_B_XSM);
        Label lblAddrPostCode = JKText.getLblDk("Post Code", JKText.FONT_B_XSM);
        Label lblAddrCountry = JKText.getLblDk("Country", JKText.FONT_B_XSM);

        txtAddr1 = new TextField();
        txtAddr1.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtAddr1, "Subscriber Address 1", txtAddr1.getText(), false);
            }
        });

        txtAddr2 = new TextField();
        txtAddr2.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtAddr2, "Subscriber Address 2", txtAddr2.getText(), false);
            }
        });

        txtAddrSuburb = new TextField();
        txtAddrSuburb.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtAddrSuburb, "Subscriber Address - Suburb", txtAddrSuburb.getText(), false);
            }
        });

        txtAddrCity = new TextField();
        txtAddrCity.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtAddrCity, "Subscriber Address - City / Town", txtAddrCity.getText(), false);
            }
        });

        comAddrProvince = new ComboBox();
        comAddrProvince.setPrefWidth(((w - (2 * JKLayout.sp)) * 0.67));
        comAddrProvince.getItems().addAll("Eastern Cape",
                "Free State",
                "Gauteng",
                "KwaZulu-Natal",
                "Limpopo",
                "Mpumalanga",
                "North West Province",
                "Northern Cape",
                "Western Cape");

        txtAddrPostCode = new TextField();
        txtAddrPostCode.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtAddrPostCode, "Post Code", txtAddrPostCode.getText());
            }
        });

        txtCountry = new TextField();
        txtCountry.setText("ZA - South Africa");
        txtCountry.setDisable(true);
        HBox.setHgrow(txtCountry, Priority.ALWAYS);

        Button btnCodes = JKNode.getBtnPopup("code");
        btnCodes.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                Region codes = new CountryCodeList(txtCountry, CountryCodes.COUNTRY_NAME);
                JKiosk3.getMsgBox().showMsgBox("select country code", "", codes, MessageBox.CONTROLS_HIDE,
                        MessageBox.MSG_OK, null);
            }
        });

        HBox hbNationality = JKLayout.getHBox(0, 5);
        hbNationality.setPrefWidth(((w - (3 * JKLayout.sp)) * 0.67));
        hbNationality.getChildren().addAll(txtCountry, btnCodes);

        chkAddrVerified = new CheckBox("Applicant Address Visually Verified");

        grid.add(lblPhysAddr, 0, 0, 2, 1);
        grid.add(lblAddr1, 0, 1);
        grid.add(lblAddr2, 0, 2);
        grid.add(lblAddrSuburb, 0, 3);
        grid.add(lblAddrCity, 0, 4);
        grid.add(lblAddrProvince, 0, 5);
        grid.add(lblAddrPostCode, 0, 6);
        grid.add(lblAddrCountry, 0, 7);

        grid.add(txtAddr1, 1, 1);
        grid.add(txtAddr2, 1, 2);
        grid.add(txtAddrSuburb, 1, 3);
        grid.add(txtAddrCity, 1, 4);
        grid.add(comAddrProvince, 1, 5);
        grid.add(txtAddrPostCode, 1, 6);
        grid.add(hbNationality, 1, 7);
        grid.add(chkAddrVerified, 1, 8);

        return grid;
    }

    public ComboBox getComAddrProvince() {
        return comAddrProvince;
    }

    public CheckBox getChkAddrVerified() {
        return chkAddrVerified;
    }

    public TextField getTxtAddr1() {
        return txtAddr1;
    }

    public TextField getTxtAddr2() {
        return txtAddr2;
    }

    public TextField getTxtAddrCity() {
        return txtAddrCity;
    }

    public TextField getTxtAddrPostCode() {
        return txtAddrPostCode;
    }

    public TextField getTxtAddrSuburb() {
        return txtAddrSuburb;
    }

    public TextField getTxtCountry() {
        return txtCountry;
    }

    //
    public boolean validatePg3() {
        boolean validPg3 = false;
        if (txtAddrSuburb.getText().equals("") || txtAddrCity.getText().equals("")) {
            validPg3 = false;
            JKiosk3.getMsgBox().showMsgBox("Registration error", "City and Suburb required", null);
        } else if (comAddrProvince.getSelectionModel().getSelectedItem() == null) {
            validPg3 = false;
            JKiosk3.getMsgBox().showMsgBox("Registration error", "Province required", null);
        } else if (txtCountry.getText().equals("")) {
            validPg3 = false;
            JKiosk3.getMsgBox().showMsgBox("Registration error", "New Owner/Subscriber Country required", null);
        } else {
            validPg3 = true;
        }
        return validPg3;
    }
}
