package jkiosk3.sales.rica;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales._common.PagedList;
import jkiosk3.sales.rica.CountryCodes.CountryCode;

/**
 *
 * @author Val
 */
public class CountryCodeList extends Region {

    private List<CountryCode> countryList;
    private TextField txtDestination;
    private String fieldType;
    private CountryCode selectedCountry;

    public CountryCodeList(TextField txtField, String inputType) {
        countryList = CountryCodes.getCodeList();
        this.txtDestination = txtField;
        this.fieldType = inputType;

        getChildren().add(getCountryPaging());
    }

    private PagedList getCountryPaging() {
        List<Node> countryItems = new ArrayList<>();

        for (final CountryCode country : countryList) {
            Label lblCountry = JKText.getLblDk(country.getName(), JKText.FONT_B_XXSM);
            lblCountry.setMaxWidth(375);
            lblCountry.setMinWidth(375);
            Label lblCode = JKText.getLblDk(country.getCode(), JKText.FONT_B_XXSM);
            lblCode.setMaxWidth(55);
            lblCode.setMinWidth(55);
            Label lblDial = JKText.getLblDk(country.getDial(), JKText.FONT_B_XXSM);
            lblDial.setMaxWidth(70);
            lblDial.setMinWidth(70);

            Button btnSelect = JKNode.getBtnPopup("select");
            btnSelect.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    selectedCountry = country;
                    fillTextField(selectedCountry);
                }
            });
            HBox hbCodeItem = JKLayout.getHBox(JKLayout.spNum, JKLayout.spNum);
            hbCodeItem.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    selectedCountry = country;
                    fillTextField(selectedCountry);
                }
            });
            hbCodeItem.getChildren().addAll(lblCountry, lblCode, lblDial, btnSelect);
            countryItems.add(hbCodeItem);
        }
        PagedList paging = new PagedList(countryItems, 10);
        return paging;
    }

    private void fillTextField(CountryCode code) {
        switch (fieldType) {
            case CountryCodes.COUNTRY_NAME:
                txtDestination.setText(code.toString());
                break;
            case CountryCodes.COUNTRY_CODE:
                txtDestination.setText(code.getCode());
                break;
            case CountryCodes.COUNTRY_DIAL:
                txtDestination.setText(code.getDial());
        }
        JKiosk3.getMsgBox().setVisible(false);
        JKiosk3.getMsgBox().toBack();
    }
}
