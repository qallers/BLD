package jkiosk3.callme;

import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3.sales.ithuba.LottoUtil;

public class DisplayCategoryDesc extends Region {

    public DisplayCategoryDesc (String description){
        VBox vbConfirm = JKLayout.getVBox(0, 0);
        vbConfirm.setPrefWidth(MessageBox.getMsgWidth() - (2 * JKLayout.sp));
        vbConfirm.setAlignment(Pos.TOP_CENTER);
        vbConfirm.getChildren().add(getSummaryGrid(description));

        getChildren().add(vbConfirm);
    }

    public DisplayCategoryDesc (){}

    private GridPane getSummaryGrid(String desc) {
        desc = JKNode.popupTextFormat(desc, 42) + "\n\n";
        Label lblConfirm = JKText.getLblDk(desc, JKText.FONT_B_XSM);
        lblConfirm.setTextAlignment(TextAlignment.CENTER);
        GridPane.setHalignment(lblConfirm, HPos.CENTER);

        GridPane grid = JKLayout.getGridSummary2ColVariWidth(0.65, 0.35, 450);
        grid.add(lblConfirm, 0, 0, 2, 1);

        return grid;
    }
}
