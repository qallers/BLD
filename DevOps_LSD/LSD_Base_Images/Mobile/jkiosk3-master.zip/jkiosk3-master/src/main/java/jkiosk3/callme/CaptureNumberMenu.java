package jkiosk3.callme;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.NumberPad;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales._favourites.Favourites;

import java.util.logging.Level;
import java.util.logging.Logger;

public class CaptureNumberMenu extends Region {
    private final static Logger logger = Logger.getLogger(CaptureNumberMenu.class.getName());
    private TextField txtConfirmContactNumber;
    private String number;
    private Button btnSelNum;
    private String category;

    public CaptureNumberMenu(String category, String description){
        this.category = category;
        logger.info("Start capturing contact numbers");
        getChildren().add(getLayoutGroup(description));
    }

    private StackPane getLayoutGroup(String description) {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getContentGroup(description)/*, getNav()*/);

        return stack;
    }

    private VBox getContentGroup(String desc) {
        HBox hbCallMeMessage = JKLayout.getHBoxLeft(0, 0);
        hbCallMeMessage.setAlignment(Pos.CENTER);
        hbCallMeMessage.setMaxWidth(0.2);

        hbCallMeMessage.getChildren().add(descriptionGrid(desc));

        Image imgC = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/callme.png"));
        ImageView imgCallMe = new ImageView(imgC);
        imgCallMe.setFitHeight(50);
        imgCallMe.setPreserveRatio(true);

        final Button btnCallMe = JKNode.getBtnNum("");
        btnCallMe.setGraphic(imgCallMe);
        btnCallMe.getStyleClass().add("prov_mtn_fix");
        btnCallMe.setMaxHeight(100);

        VBox vbHead = JKNode.getPageCallMeHeadVB("Please Call Me");
        vbHead.getChildren().addAll(btnCallMe);

        VBox vb = JKLayout.getVBoxContent(/*2 * */JKLayout.sp);
        vb.getChildren().addAll(vbHead, hbCallMeMessage, getContentGrid());

        return vb;
    }

    private GridPane descriptionGrid(String desc) {
        double gridW = 590;
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setMaxWidth(gridW * 6);
        grid.setMinWidth(gridW);

        Label lblMessage1 = JKText.getLblDk(String.format("%s\n", JKNode.popupTextFormat(desc, 42)), JKText.FONT_B_15);
        lblMessage1.setTextAlignment(TextAlignment.CENTER);

        grid.add(lblMessage1, 0, 0);

        return grid;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav();
        nav.getBtnBack().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.changeScene(new CallMeMainMenu());
            }
        });

        nav.setBtnCancelAction(new Favourites());

        nav.getBtnNext().setDisable(true);
        return nav;
    }

    private GridPane getContentGrid() {
        final String ENTER_CONTACT_NUMBER_TEXT = "Enter number";

        Label numOfBoardsText = JKText.getLblDk("Number: ", JKText.FONT_B_XSM);
        Label numOfDrawsText = JKText.getLblDk("Confirm number: " , JKText.FONT_B_XSM);

        final TextField txtContactNumber = JKNode.getTextFieldRight();

        txtContactNumber.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                NumberPad numberPad = new NumberPad();
                getChildren().add(numberPad);

                numberPad.showNumPad(txtContactNumber, ENTER_CONTACT_NUMBER_TEXT, "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        number = value;
                    }
                });
            }
        });

        txtConfirmContactNumber = JKNode.getTextFieldRight();
        txtConfirmContactNumber.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                NumberPad numberPad = new NumberPad();
                getChildren().add(numberPad);
                numberPad.showNumPad(txtConfirmContactNumber, ENTER_CONTACT_NUMBER_TEXT, "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        validateContactNumber(txtConfirmContactNumber, number, value, btnSelNum);

                    }
                });
            }
        });

        btnSelNum = JKNode.getBtnMsgBox("Submit");
        btnSelNum.setDisable(true);
        btnSelNum.setMaxWidth((JKLayout.btnSmW * 1.7) + JKLayout.sp);
        btnSelNum.setMinWidth(/*(JKLayout.btnSmW * 2) + */JKLayout.sp);
        btnSelNum.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SendCallMeService sendCallMe = new SendCallMeService();
                String successMessage = sendCallMe.sendCallmeMessage(number, category);

                if(successMessage.isEmpty()){
                    MessageBox messageBox = new MessageBox();
                    getChildren().add(messageBox);
                    messageBox.showMsgBox("Oops! something went wrong",
                            "System is unable to send please call me. \n Please try again later.", null);
                } else {
                    MessageBox messageBox = new MessageBox();
                    getChildren().add(messageBox);
                    Button btn = messageBox.showMsgBox("Thank you for contacting us!",
                            successMessage, null);

                    btn.setOnMouseReleased(new EventHandler() {
                        @Override
                        public void handle(Event e) {
                            JKiosk3.changeScene(new JKioskLogin());
                        }
                    });
                }

            }
        });

        final Button btnBack = JKNode.getBtnMsgBox("Back");
        btnBack.setDisable(false);
        btnBack.setMaxWidth((JKLayout.btnSmW * 1.7) + JKLayout.sp);
        btnBack.setMinWidth(/*(JKLayout.btnSmW * 2) +*/ JKLayout.sp);
        btnBack.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.changeScene(new CallMeMainMenu());
            }
        });

        GridPane grid = JKLayout.getContentGridInner2ColInScroll(0.5, 0.5, HPos.RIGHT);

        grid.addRow(0, numOfBoardsText, txtContactNumber);
        grid.addRow(1, numOfDrawsText, txtConfirmContactNumber);
        grid.add(btnSelNum, 1, 3);
        grid.add(btnBack, 0, 3);

        return grid;
    }

    private void validateContactNumber(final TextField txt, String number, String confirmNumber, Button callMeBtn) {
        try {
            if (!confirmNumber.equalsIgnoreCase(number)) {
                MessageBox messageBox = new MessageBox();
                getChildren().add(messageBox);
                messageBox.showMsgBox("Mismatch Number Entered",
                        "\nThe two numbers do not match. Please try again.", null);
                txt.setText(confirmNumber);
            } else {
                callMeBtn.setDisable(false);
            }
        } catch (NumberFormatException nfe) {
            logger.log(Level.SEVERE, nfe.getMessage(), nfe);
            MessageBox messageBox = new MessageBox();
            getChildren().add(messageBox);
            messageBox.showMsgBox("Invalid Number Selection", "Please review the selected numbers and try again", null);
        }
    }
}


