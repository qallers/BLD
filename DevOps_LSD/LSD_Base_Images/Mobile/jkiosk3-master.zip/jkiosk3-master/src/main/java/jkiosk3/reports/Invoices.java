package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.Account;
import aeonreports.AccountList;
import aeonreports.Invoice;
import aeonreports.InvoiceList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.printing.PrintHandler;
import jkiosk3.reports.ReportUtil.AccountListResult;
import jkiosk3.reports.ReportUtil.AeonPrintJobResult;
import jkiosk3.reports.ReportUtil.InvoiceListResult;

/**
 *
 * @author Val
 */
public class Invoices extends Region {

    private final static Logger logger = Logger.getLogger(Invoices.class.getName());
    private ComboBox comAcc;
    private ComboBox comInv;
    private List<Invoice> invList;
    private int accountId;
    private int invoiceId;

    public Invoices() {
        VBox vb = JKLayout.getVBox(0, 5);

        vb.getChildren().add(getInvoiceGrid());
        vb.getChildren().add(getPrintControl());

        getChildren().addAll(vb);
    }

    private GridPane getInvoiceGrid() {
        double sp = JKLayout.sp;
        double w = JKLayout.contentW;

        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);

        VBox vbHead = JKNode.getReportHeadVB("Invoices");

        Label lblAccNo = JKText.getLblDk("Account", JKText.FONT_B_XSM);
        lblAccNo.setMinWidth(JKLayout.btnSmW);

        Label lblInvoice = JKText.getLblDk("Invoice", JKText.FONT_B_XSM);

        comAcc = new ComboBox();
        comAcc.setPrefSize(((w - (2 * sp)) * 0.75), 35);

        ReportUtil.getAccountList(new AccountListResult() {
            @Override
            public void accountListResult(final AccountList accountList) {
                for (Account a : accountList.getAccounts()) {
                    comAcc.getItems().add(a.getAccountNo());
                }
                comAcc.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
                    @Override
                    public void changed(ObservableValue arg0, Object oldAcc, Object newAcc) {
                        if (comInv.getSelectionModel().getSelectedItem() != null) {
                            comInv.getSelectionModel().clearSelection();
                        }
                        for (Account selected : accountList.getAccounts()) {
                            if (selected.getAccountNo().equals(newAcc)) {
                                accountId = selected.getAccountId();
                                makeInvoiceList(accountId);
                            }
                        }
                    }
                });
            }
        });

        comInv = new ComboBox();
        comInv.setPrefSize(((w - (2 * sp)) * 0.75), 35);
        if (invList == null) {
            comInv.getItems().add("");
        }
        comInv.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object oldInv, Object newInv) {
                if (newInv != null) {
                    invoiceId = ((Invoice) newInv).getInvoiceId();
                }
            }
        });

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblAccNo, comAcc);
        grid.addRow(2, lblInvoice, comInv);

        return grid;
    }

    private List<Invoice> makeInvoiceList(int accId) {
        ReportUtil.getInvoiceList(accId, new InvoiceListResult() {
            @Override
            public void invoiceListResult(InvoiceList invoiceList) {
                if (invoiceList == null || invoiceList.getInvoices().isEmpty()) {
                    JKiosk3.getMsgBox().showMsgBox("Invoices", "No Invoices to display", null);
                } else {
                    invList = invoiceList.getInvoices();
                    comInv.getItems().clear();
                    for (Invoice i : invoiceList.getInvoices()) {
                        comInv.getItems().add(i);
                    }
                }
            }
        });
        return invList;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                if (inputValidation()) {
                    showInvoiceReport();
                }
            }
        };
    }

    private void showInvoiceReport() {
        try {
            ReportUtil.getPrintReport(ReportUtil.REP_INVOICE, accountId, invoiceId, new AeonPrintJobResult() {
                @Override
                public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                    PrintHandler.handlePrintRequestReport("Print Invoice", aeonPrintJob);
                }
            });
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        resetForm();
    }

    private void resetForm() {
        int n = SceneReports.getVbReportContent().getChildren().size();
        if (n > 1) {
            SceneReports.getVbReportContent().getChildren().remove(1, n);
        }
    }

    private boolean inputValidation() {
        boolean validated = false;

        if (isAccountValid()) {
            if (comInv.getSelectionModel().selectedItemProperty().getValue() == null) {
                JKiosk3.getMsgBox().showMsgBox("Invoice Selection", "Please select an Invoice from the list", null);
                validated = false;
            } else {
                validated = true;
            }
        }

        return validated;
    }

    private boolean isAccountValid() {
        if (comAcc.getSelectionModel().selectedItemProperty().getValue() == null) {
            JKiosk3.getMsgBox().showMsgBox("Account Selection", "Please select an Account from the list", null);
            return false;
        } else {
            return true;
        }
    }
}
