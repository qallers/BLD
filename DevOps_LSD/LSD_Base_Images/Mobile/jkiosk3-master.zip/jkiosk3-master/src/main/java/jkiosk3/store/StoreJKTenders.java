package jkiosk3.store;

import aeontender.TenderType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author valeriew
 */
public class StoreJKTenders implements Serializable {
    
    private static final long serialVersionUID = 15555L;
    private final List<TenderType> listTenderTypes = new ArrayList<>();

    public List<TenderType> getListTenderTypes() {
        return listTenderTypes;
    }

    /* Should not need a setter. */
    /* Will 'get' list of items and 'add' to it. */
//    public void setListTenderTypes(List<TenderType> listTenderTypes) {
//        this.listTenderTypes = listTenderTypes;
//    }    
}
