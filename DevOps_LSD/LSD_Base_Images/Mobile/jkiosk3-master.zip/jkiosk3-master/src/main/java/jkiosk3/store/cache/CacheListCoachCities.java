package jkiosk3.store.cache;

import aeoncoach.CoachListItemResp;
import jkiosk3.store.Store;

public class CacheListCoachCities {

    private static volatile ListCoachCities listCoachCities;

    private static ListCoachCities getCachedListCoachCities() {
        if (listCoachCities == null) {
            listCoachCities = ((ListCoachCities) Store.loadObject(CacheListCoachCities.class.getSimpleName()));
        }
        if (listCoachCities == null) {
            listCoachCities = new ListCoachCities();
        }
        return listCoachCities;
    }

    private static void saveListCoachCities(ListCoachCities listCoachCity) {
        Store.saveObject(CacheListCoachCities.class.getSimpleName(), listCoachCity);
    }

    public static void saveListCoachCities(CoachListItemResp coachListCities) {
        getCachedListCoachCities();
        listCoachCities.setCoachCitiesList(coachListCities);

        saveListCoachCities(listCoachCities);
    }

    public static boolean hasItems() {
        getCachedListCoachCities();
        return !listCoachCities.getCoachCitiesList().getListItems().isEmpty();
    }

    public static CoachListItemResp getListCoachCities() {
        getCachedListCoachCities();
        return listCoachCities.getCoachCitiesList();
    }

    public static void deleteCacheListCoachCities() {
        Store.deleteObject(CacheListCoachCities.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheListCoachCities.class.getSimpleName());
    }
}
