package jkiosk3.sales.ticketpro;

import aeonticketpros.TicketProsCheckoutReq;
import aeonticketpros.TicketProsCheckoutResp;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3._components.ControlSearch;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.ticketpro.sale.TicketProViewCart;
import jkiosk3.sales.ticketpro.sale.TicketProPayment;
import jkiosk3.store.JKOptions;
import jkiosk3.users.UserUtil;

public class TicketProCustomerReg extends Region {

    private ControlSearch searchCtrl;
    private TextField txtCustomerFirstName;
    private TextField txtCustomerLastName;
    private TextField txtCustomerCellNum;

    public TicketProCustomerReg() {
        setSearchControlActions ();

        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (getCustomerRegLayout ());
        vb.getChildren ().add (getNav ());

        getChildren ().add (vb);
    }

    private void setSearchControlActions() {
        searchCtrl = new ControlSearch ();
        searchCtrl.setVisible (false);
        searchCtrl.getBtnSearch ().setDisable (true);
        searchCtrl.getBtnClear ().setDisable (true);
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(javafx.event.Event e) {
                SceneSales.clearAndChangeContent (new TicketProViewCart ());
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(javafx.event.Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndShowFavourites ();
            }
        });
        nav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(javafx.event.Event e) {
                if (validateInput ()) {
                    TicketProSale.getInstance ().setCustomerName (txtCustomerFirstName.getText ().trim ());
                    TicketProSale.getInstance ().setCustomerSurname (txtCustomerLastName.getText ().trim ());
                    TicketProSale.getInstance ().setCustomerMobilePhone (txtCustomerCellNum.getText ().trim ());
                    checkoutTickets ();
                }
            }
        });
        return nav;
    }

    private GridPane getCustomerRegLayout() {
        Label lblCustomerReg = JKText.getLblDk ("Customer Registration", JKText.FONT_B_SM);
        Label lblCustomerDetail = JKText.getLblContentSubHead ("Search for existing Customer, or enter new");
        lblCustomerDetail.setVisible (false);

        HBox hbHead = JKLayout.getHBox (0, 0);
        hbHead.setPrefWidth (JKLayout.contentW - (2 * JKLayout.sp));
        hbHead.getChildren ().addAll (lblCustomerReg, JKNode.getHSpacer (), searchCtrl);

        Label lblCustomerFirstName = JKText.getLblDk ("First Name", JKText.FONT_B_XSM);
        Label lblCustomerLastName = JKText.getLblDk ("Last Name", JKText.FONT_B_XSM);
        Label lblCustomerCellNum = JKText.getLblDk ("Cell Number", JKText.FONT_B_XSM);

        txtCustomerFirstName = new TextField ();
        txtCustomerFirstName.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (!JKOptions.getOptions ().isKeyboard ()) {
                    JKiosk3.getKeyboard ().showKeyboard (txtCustomerFirstName, "Enter Customer First Name", "", false);
                }
            }
        });
        txtCustomerLastName = new TextField ();
        txtCustomerLastName.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (!JKOptions.getOptions ().isKeyboard ()) {
                    JKiosk3.getKeyboard ().showKeyboard (txtCustomerLastName, "Enter Customer Last Name", "", false);
                }
            }
        });
        txtCustomerCellNum = new TextField ();
        txtCustomerCellNum.setPromptText ("do not use spaces, dashes, etc.");
        txtCustomerCellNum.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (!JKOptions.getOptions ().isKeyboard ()) {
                    JKiosk3.getNumPad ().showNumPad (txtCustomerCellNum, "Enter Cell Number", "");
                }
            }
        });

        GridPane grid = JKLayout.getGridContent2Col (0.25, 0.75);

        grid.add (hbHead, 0, 0, 2, 1);
        grid.add (lblCustomerDetail, 0, 1, 2, 1);
        grid.add (JKNode.createGridSpanSep (2), 0, 2);
        grid.addRow (3, lblCustomerFirstName, txtCustomerFirstName);
        grid.addRow (4, lblCustomerLastName, txtCustomerLastName);
        grid.addRow (5, lblCustomerCellNum, txtCustomerCellNum);

        return grid;
    }

    private boolean validateInput() {
        if (txtCustomerCellNum.getText () == null || txtCustomerCellNum.getText ().equals ("")) {
            JKiosk3.getMsgBox ().showMsgBox ("Customer Cell Number", "Please enter a Cell Number for the Customer", null);
            return false;
        }
        if (!txtCustomerCellNum.getText ().matches ("(^0[678][01234689]((\\d{7})|( |-)((\\d{3}))( |-)(\\d{4})|( |-)(\\d{7})))")) {
            JKiosk3.getMsgBox ().showMsgBox ("Customer Cell Number", "Please enter a valid Cell Number", null);
            return false;
        }
        return true;
    }

    private void checkoutTickets() {

        TicketProsCheckoutReq req = new TicketProsCheckoutReq ();

        req.setCartId (TicketProSale.getInstance ().getSaleCart ().getCartId ());
        req.setMobilePhone (TicketProSale.getInstance ().getCustomerMobilePhone ());
        req.setName (TicketProSale.getInstance ().getCustomerName ());
        req.setSurname (TicketProSale.getInstance ().getCustomerSurname ());

        TicketProUtil.checkoutTicketPro (req, new TicketProUtil.TicketProCheckoutResult () {
            @Override
            public void tpCheckoutResult(TicketProsCheckoutResp tpCheckoutResp) {
                if (tpCheckoutResp.isSuccess ()) {
                    TicketProSale.getInstance ().setCheckoutResponse (tpCheckoutResp);
                    SceneSales.clearAndChangeContent (new TicketProPayment ());
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Checkout Error",
                            !tpCheckoutResp.getAeonErrorText ().isEmpty () ?
                                    "A" + tpCheckoutResp.getAeonErrorCode () + " - " + tpCheckoutResp.getAeonErrorText () :
                                    "B" + tpCheckoutResp.getErrorCode () + " - " + tpCheckoutResp.getErrorText (), null);
                }

            }
        });
    }
}
//
//Bus Rules doc pg 10
//
//•	Phase 1, Functionality must be built so that the customer can register at the end of the purchase. This function 
//        must take place post sale and acceptance of payment before the ticket is printed.
//•	Customer Registration Info to Include:
//•	A mobile number that must validated as 10 digits and not all O’s
//•	Free text first name and last name.
//•	Must be enabled at the Spar Kiosk (Payzone)
//•	Must be enabled on the BLD Spectra Devices and BLD Touchscreens
//
//
//Bus Rules doc pg 12
//
// Once customer is happy with their allocated seats the cashier will check out, after check out, the API will give a 
// transaction ID, and then give the balance due.
//
// Customer will then be prompted to register, if a first time customer or be requested to enter unique identifier to 
// populate registration details.
//	
// Once done customer will be prompted to pay balance due, a message appears reflecting that the payment has been accepted 
// and your balance is zero.  Only once payment has been accepted will the tickets be able to print.
