package jkiosk3.printing.print_layouts;

import aeonemergencytopup.LoanConfirmResp;
import aeonprinting.AeonPrintJob;
import aeonprinting.AeonPrintLine;
import jkiosk3._common.JKText;

/**
 *
 * @author Valerie
 */
public class PrintEmergTop {

    /**
     * Private Constructor created to hide implicit public one.
     */
    private PrintEmergTop() {
    }

    public static AeonPrintJob getEmergencyTopupConfirmationReceipt(String accNum, LoanConfirmResp confResp, boolean isReprint) {
        final String PRINT_LAYOUT = "%-14s" + "%-2s" + "%20s";

        AeonPrintJob apj = new AeonPrintJob();

        if (isReprint) {
            apj.addBreak();
            apj.addCentre("* REPRINT *");
            apj.addBreak();
        }

        apj.addLogo("0");

        for (AeonPrintLine line : PrintAssorted.addMerchantHeader().getLines()) {
            apj.getLines().add(line);
        }

        apj.addBreak();

        apj.addCentreBold("Emergency Topup Confirmation");
        apj.addBreak();

        apj.addCentre(String.format(PRINT_LAYOUT, "Requested by", ":", confResp.getUserName()));
        apj.addCentre(String.format(PRINT_LAYOUT, "Date", ":", JKText.getDateDisplaySec(confResp.getTransDate())));
        apj.addCentre(String.format(PRINT_LAYOUT, "Trans Ref", ":", confResp.getTransRef()));

        apj.addBreak();

        apj.addCentre(String.format(PRINT_LAYOUT, "Account ID", ":", confResp.getAccountId()));
        apj.addCentre(String.format(PRINT_LAYOUT, "Account Number", ":", accNum));
        apj.addCentre(String.format(PRINT_LAYOUT, "Available", ":", JKText.getDeciFormat(confResp.getAmountAvailable())));
        apj.addCentre(String.format(PRINT_LAYOUT, "Requested", ":", JKText.getDeciFormat(confResp.getAmountRequested())));
        apj.addCentre(String.format(PRINT_LAYOUT, "Allocated", ":", JKText.getDeciFormat(confResp.getAmountAllocated())));
        apj.addCentreBold(String.format(PRINT_LAYOUT, "Balance", ":", JKText.getDeciFormat(confResp.getBalance())));

        apj.addBreak();
        apj.addCentre("");
        apj.addCentreBold("- Print Done -");
        apj.addCentre("");

        if (isReprint) {
            apj.addBreak();
            apj.addCentre("* REPRINT *");
            apj.addBreak();
        }

        return apj;
    }
}
