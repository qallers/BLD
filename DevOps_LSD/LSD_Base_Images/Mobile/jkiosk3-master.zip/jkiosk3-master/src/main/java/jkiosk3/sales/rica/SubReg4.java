package jkiosk3.sales.rica;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;

/**
 *
 * @author Val
 */
public class SubReg4 extends Region {

    private Label lblRefNum;
    private TextField txtCountryCode;
    private TextField txtAreaCode;
    private TextField txtAltNumber;
//    private ComboBox comRegisterBy;
    private ObservableList<RadioButton> listRadios;
    private TextField txtRefNum;
    private TextField txtL4SimNum;

    public SubReg4() {
        setId(SubAll.REG_PG_4);

        getChildren().add(getSubPg4());
    }

    private GridPane getSubPg4() {

        double w = JKLayout.contentW;

        GridPane grid = new GridPane();

        grid.setPrefWidth(w - (2 * JKLayout.sp));
        grid.getStyleClass().add("gridInner");
        grid.setStyle("-fx-hgap: 15px;");

        ColumnConstraints col0 = new ColumnConstraints();
        col0.setPrefWidth((w - (2 * JKLayout.sp)) * 0.35);
        col0.setHalignment(HPos.LEFT);
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPrefWidth((w - (2 * JKLayout.sp)) * 0.30);
        col1.setHalignment(HPos.LEFT);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setPrefWidth((w - (2 * JKLayout.sp)) * 0.35);
        col2.setHalignment(HPos.LEFT);
        grid.getColumnConstraints().addAll(col0, col1, col2);

        Label lblContact = JKText.getLblDk("Contact Details", JKText.FONT_B_SM);

        Label lblAlternateContact = JKText.getLblDk("Alternative Contact Number", JKText.FONT_B_XSM);
        Label lblCountryCode = JKText.getLblDk("Country Code", JKText.FONT_B_XSM);
        Label lblCountryEg = JKText.getLblDk("e.g. ZA = '27'", JKText.FONT_B_12);
        Label lblAreaCode = JKText.getLblDk("Area Code", JKText.FONT_B_XSM);
        Label lblAreaEg = JKText.getLblDk("e.g. Jhb = '11'", JKText.FONT_B_12);
        Label lblAltNumber = JKText.getLblDk("Number", JKText.FONT_B_XSM);
        Label lblRegisterBy = JKText.getLblDk("Register By", JKText.FONT_B_XSM);
        lblRefNum = JKText.getLblDk("Reference Number", JKText.FONT_B_XSM);
        final Label lblSimNumber = JKText.getLblDk("Last 4 Digits of SIM Serial Number", JKText.FONT_B_XSM);

        txtCountryCode = new TextField();
        txtCountryCode.setText("27");
        txtCountryCode.setMaxWidth(120);
        txtCountryCode.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtCountryCode, "Country Code", txtCountryCode.getText());
            }
        });

        Button btnCodes = JKNode.getBtnPopup("code");
        btnCodes.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                Region codes = new CountryCodeList(txtCountryCode, CountryCodes.COUNTRY_DIAL);
                JKiosk3.getMsgBox().showMsgBox("select country code", "", codes, MessageBox.CONTROLS_HIDE,
                        MessageBox.MSG_OK, null);
            }
        });

        HBox hbCountryCode = JKLayout.getHBoxLeft(0, 5);
        hbCountryCode.setPrefWidth((w - (2 * JKLayout.sp)) * 0.33);
        hbCountryCode.getChildren().addAll(txtCountryCode, btnCodes);

        txtAreaCode = new TextField();
        txtAreaCode.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtAreaCode, "Area Code", txtAreaCode.getText());
            }
        });

        txtAltNumber = new TextField();
        txtAltNumber.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtAltNumber, "Phone Number", txtAltNumber.getText());
            }
        });

//        comRegisterBy = new ComboBox();
//        comRegisterBy.setPrefWidth(((w - (2 * JKLayout.sp)) * 0.67));
////        comRegisterBy.getItems().addAll(SubAll.REG_TYPE_CELL, SubAll.REG_TYPE_SP, SubAll.REG_TYPE_SIM);
//        comRegisterBy.getItems().addAll(SubAll.REG_TYPE_SP, SubAll.REG_TYPE_SIM);
//        comRegisterBy.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
//            @Override
//            public void changed(ObservableValue observe, Object oldValue, Object newValue) {
//                txtRefNum.clear();
//                txtL4SimNum.clear();
//                switch (newValue.toString()) {
////                    case SubAll.REG_TYPE_CELL:
////                        lblRefNum.setText(SubAll.REG_TYPE_CELL);
////                        lblSimNumber.setDisable(false);
////                        txtL4SimNum.setDisable(false);
////                        break;
//                    case SubAll.REG_TYPE_SP:
//                        lblRefNum.setText("SP Serial Number");
////                        lblSimNumber.setDisable(true);
////                        txtL4SimNum.setDisable(true);
//                        lblSimNumber.setDisable(false);
//                        txtL4SimNum.setDisable(false);
//                        break;
//                    case SubAll.REG_TYPE_SIM:
//                        lblRefNum.setText(SubAll.REG_TYPE_SIM);
//                        lblSimNumber.setDisable(true);
//                        txtL4SimNum.setDisable(true);
//                }
//            }
//        });
        ToggleGroup togRegType = new ToggleGroup();

        String[] listStr = {SubAll.REG_TYPE_CELL, SubAll.REG_TYPE_SP, SubAll.REG_TYPE_SIM};

        listRadios = FXCollections.observableArrayList();

        for (String s : listStr) {
            final RadioButton rad = new RadioButton(s);
            rad.setToggleGroup(togRegType);
            rad.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");
            GridPane.setColumnSpan(rad, 2);
            rad.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    txtRefNum.clear();
                    txtL4SimNum.clear();
                    if (rad.isSelected()) {
                        switch (rad.getText()) {
                            case SubAll.REG_TYPE_CELL:
                                lblRefNum.setText(SubAll.REG_TYPE_CELL);
                                lblSimNumber.setDisable(false);
                                txtL4SimNum.setDisable(false);
                                break;
                            case SubAll.REG_TYPE_SP:
                                lblRefNum.setText("SP Serial Number");
                                lblSimNumber.setDisable(false);
                                txtL4SimNum.setDisable(false);
                                break;
                            case SubAll.REG_TYPE_SIM:
                                lblRefNum.setText(SubAll.REG_TYPE_SIM);
                                lblSimNumber.setDisable(true);
                                txtL4SimNum.setDisable(true);
                                break;
                            default:
                                break;
                        }
                    }
                }
            });
            listRadios.add(rad);
        }

        txtRefNum = new TextField();
        GridPane.setColumnSpan(txtRefNum, 2);
        txtRefNum.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtRefNum, "Reference Number", txtRefNum.getText(), false, false,
                        new KeyboardResult() {
                    @Override
                    public void onDone(String value) {
                        if (value.length() > 4) {
                            for (RadioButton r : listRadios) {
                                if (r.isSelected()) {
                                    switch (r.getText()) {
                                        case SubAll.REG_TYPE_CELL:
                                            System.out.println("reg by cell - number is " + value);
                                            txtL4SimNum.setDisable(false);
                                            break;
                                        case SubAll.REG_TYPE_SP:
                                            System.out.println("reg by starter pack - number is " + value);
                                            txtL4SimNum.setDisable(false);
                                            break;
                                        case SubAll.REG_TYPE_SIM:
                                            System.out.println("reg by sim - number is " + value);
                                            if (!value.equals("")) {
                                                int indexStart = value.length() - 4;
                                                String last4sim = value.substring(indexStart, value.length());
                                                txtL4SimNum.setText(last4sim);
                                            }
                                            break;
                                        default:
                                            break;
                                    }
                                }
                            }
                        } else {
                            JKiosk3.getMsgBox().showMsgBox("Reference Number", "Please enter a valid Cell Phone Number / SP Serial Number / SIM Serial Number", null);
                            txtRefNum.clear();
                        }
                    }
                });
            }
        });

        txtL4SimNum = new TextField();
        txtL4SimNum.setMaxWidth((w - (2 * JKLayout.sp)) * 0.35);
        txtL4SimNum.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtL4SimNum, "SIM Number", txtL4SimNum.getText());
            }
        });

        HBox hbSim = JKLayout.getHBoxLeft(0, 0);
        hbSim.setPrefWidth(((w - (2 * JKLayout.sp)) * 0.35) + ((w - (2 * JKLayout.sp)) * 0.30) - (2 * JKLayout.sp));
        hbSim.getChildren().addAll(lblSimNumber, JKNode.getHSpacer(), txtL4SimNum);
        GridPane.setColumnSpan(hbSim, 3);

        grid.add(lblContact, 0, 0, 3, 1);
        grid.add(lblAlternateContact, 0, 1, 3, 1);
        grid.addRow(2, lblCountryCode, lblAreaCode, lblAltNumber);
        grid.addRow(3, lblCountryEg, lblAreaEg);
        grid.addRow(4, hbCountryCode, txtAreaCode, txtAltNumber);
        grid.add(JKNode.createGridSpanSep(3), 0, 5);
        grid.addRow(6, lblRegisterBy, listRadios.get(0));
        grid.addRow(7, new Label(""), listRadios.get(1));
        grid.addRow(8, new Label(""), listRadios.get(2));
        grid.addRow(10, lblRefNum, txtRefNum);
        grid.add(hbSim, 0, 11);

        return grid;
    }

//    public ComboBox getComRegisterBy() {
//        return comRegisterBy;
//    }
    public ObservableList<RadioButton> getListRadios() {
        return listRadios;
    }

    public Label getLblRefNum() {
        return lblRefNum;
    }

    public TextField getTxtAltNumber() {
        return txtAltNumber;
    }

    public TextField getTxtAreaCode() {
        return txtAreaCode;
    }

    public TextField getTxtCountryCode() {
        return txtCountryCode;
    }

    public TextField getTxtRefNum() {
        return txtRefNum;
    }

    public TextField getTxtL4SimNum() {
        return txtL4SimNum;
    }

    public boolean validatePg4() {
        if (txtCountryCode.getText().trim().equals("") || txtAreaCode.getText().trim().equals("")
                || txtAltNumber.getText().trim().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Registration error", "Country Code, Area Code and Number required", null);
            return false;
        }
        RadioButton radSel = null;
        for (RadioButton r : listRadios) {
            if (r.isSelected()) {
                radSel = r;
                break;
            }
        }
        if (radSel == null) {
            JKiosk3.getMsgBox().showMsgBox("Registration error", "Please select one of the 'Register By' options", null);
            return false;
        }
        if (txtRefNum.getText().trim().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Registration error", "Cell Phone Number / SP Serial Number / "
                    + "SIM Serial Number\ncannot be blank", null);
            return false;
        }
        if (txtL4SimNum.getText().trim().equals("")) {
            JKiosk3.getMsgBox().showMsgBox("Registration error", "Last 4 Digits of SIM Serial Number\ncannot be blank", null);
            return false;
        }
        return true;
    }
}
