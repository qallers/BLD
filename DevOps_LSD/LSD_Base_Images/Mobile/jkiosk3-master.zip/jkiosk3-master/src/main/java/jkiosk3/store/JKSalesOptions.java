package jkiosk3.store;

/**
 *
 * @author Valerie
 */
public class JKSalesOptions {
    
    private static StoreJKSalesOptions salesOptions;

    public static StoreJKSalesOptions getSalesOptions() {
        if (salesOptions == null) {
            salesOptions = ((StoreJKSalesOptions) Store.loadObject(JKSalesOptions.class.getSimpleName()));
        }
        if (salesOptions == null) {
            salesOptions = new StoreJKSalesOptions();
        }
        return salesOptions;
    }

    public static boolean saveSystemSetup() {
        getSalesOptions();
        return Store.saveObject(JKSalesOptions.class.getSimpleName(), salesOptions);
    }
}
