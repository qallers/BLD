package jkiosk3.sales.vouchers;

import aeonairtime.*;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._recharge_plus.RechargePlusUtil;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;

import java.util.List;

public class VoucherQuantity extends Region {

    private final static int MAX_COUNT = 10;
    private final AirtimeManufacturer provider;
    private final AirtimeProduct product;
    private TextField txtQty;
    private int voucherQty;
    private boolean showRechargePlus = false;
    private boolean isRechargePlus = false;
    private boolean showFavourite;

    public VoucherQuantity(boolean isFavourite) {
        this.provider = VoucherSale.getInstance ().getProvider ();
        this.product = VoucherSale.getInstance ().getProduct ();
        this.showFavourite = isFavourite;

        VoucherSale.getInstance ().setRechargePlus (false);

        List<String> onlineTransTypes = CurrentUser.getUser ().getTransTypes ();
        if (onlineTransTypes.contains ("RechargePlus")) {
            if (provider.isRechargePlus ()) {
                showRechargePlus = true;
            } else {
                showRechargePlus = false;
            }
        }

        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (getVoucherQuantityGrid ());
        vb.getChildren ().add (getControlButtons ());
        getChildren ().addAll (vb);
    }

    private GridPane getVoucherQuantityGrid() {

        Button btnBack = JKNode.getBtnPopup ("back");
        btnBack.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new VoucherProducts ());
            }
        });

        Button btnProvider = JKNode.getAirtimeProviderButton (provider.getId (), product.getName ());

        VBox vbHead1 = new VBox ();
        if (showFavourite) {
            Label lblSaleType = JKText.getLblDk (VoucherSale.getInstance ().getSaleType ().getDisplay (), JKText.FONT_B_SM);
            vbHead1 = JKNode.getPageDblHeadVB (0, lblSaleType, btnProvider);
        } else {
            vbHead1 = JKNode.getPageDblHeadVB (0, btnBack, btnProvider);
        }

        Label lblProduct = JKText.getLblDk (product.getName (), JKText.FONT_B_XSM);
        VBox vbHead2 = JKNode.getPageDblHeadVB (0, new Label (""), lblProduct);

        Label lblQty = JKText.getLblDk ("Number of Vouchers (maximum 10)", JKText.FONT_B_XSM);

        Label lblRchgPlus = JKText.getLblDk (RechargePlusUtil.RECHARGE_PLUS_LBL, JKText.FONT_B_XSM);

        CheckBox chkRchgPlus = new CheckBox ();
        GridPane.setHalignment (chkRchgPlus, HPos.RIGHT);
        chkRchgPlus.selectedProperty ().addListener (new ChangeListener<Boolean> () {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean aBoolean, Boolean t1) {
                if (t1) {
                    isRechargePlus = true;
                } else {
                    isRechargePlus = false;
                }
            }
        });

        txtQty = new TextField ();
        txtQty.setText ("1");
        txtQty.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event t) {
                JKiosk3.getNumPad ().showNumPad (txtQty, "Number of Vouchers", "", new NumberPadResult () {
                    @Override
                    public void onDone(String value) {
                        SalesUtil.getAmountAsInt (value, txtQty, MAX_COUNT);
                    }
                });
            }
        });

        GridPane grid = JKLayout.getGridContent2Col (0.75, 0.25, HPos.RIGHT);
        grid.add (vbHead1, 0, 0, 2, 1);
        grid.add (vbHead2, 0, 1, 2, 1);

        grid.addRow (2, lblQty, txtQty);
        if (showRechargePlus) {
            // CR changed specs for RechargePlus, now applicable to ALL Voucher products, not just category 1 and 2
//            if (product.getCategoryId() == 1 || product.getCategoryId() == 2) {     /* NOTE - '1' = SaleType.VOUCHER_AIRTIME, '2' = SaleType.VOUCHER_DATA */
            grid.addRow (4, lblRchgPlus, chkRchgPlus);
//            }
        }

        return grid;
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons ();

        ctrlBtns.getBtnAccept ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (isValidEntry ()) {
                    /* NOTE - With RechargePlus added, we need to show the summary regardless of the setting. */
                    showSummary ();
                }
            }
        });
        ctrlBtns.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                SceneSales.clearAndChangeContent(new MenuVouchers());
                SceneSales.clearAndShowFavourites ();
            }
        });

        return ctrlBtns;
    }

    private void showSummary() {
        GridPane grid = JKLayout.getSummaryGrid2Col (0.45, 0.55);

        double amtRchgPlus = RechargePlusUtil.getRechargePlusValue ();

        Label lblProv = JKText.getLblDk ("Provider", JKText.FONT_B_XSM);
        Label lblVouch = JKText.getLblDk ("Voucher", JKText.FONT_B_XSM);
        Label lblQty = JKText.getLblDk ("Quantity", JKText.FONT_B_XSM);
        Label lblAmtTotal = JKText.getLblDk ("Total Due", JKText.FONT_B_26);

        String displayName = "";
        if (provider.getName ().startsWith ("x")) {
            displayName = provider.getName ().substring (1);
        } else {
            displayName = provider.getName ();
        }
        Text txtProv = JKText.getTxtDk (displayName, JKText.FONT_B_24);

        double wrapwidth = MessageBox.getMsgWidth () - (225 + (1 * JKLayout.sp));
        Text txtVouch = JKText.getTxtDk (product.getName ().trim (), JKText.FONT_B_24);
        txtVouch.setWrappingWidth (wrapwidth);
        txtVouch.setTextAlignment (TextAlignment.RIGHT);

        Text txtSummQty = JKText.getTxtDk (JKText.getDeciFormatNoDecimals (voucherQty), JKText.FONT_B_24);

        double amtDue = product.getValue () * voucherQty;

        Text txtAmtTotal = JKText.getTxtDk ("", JKText.FONT_B_26);

        grid.addRow (0, lblProv, txtProv);
        grid.addRow (1, lblVouch, txtVouch);
        grid.addRow (2, lblQty, txtSummQty);

        if (isRechargePlus) {
            Label lblAmtDue = JKText.getLblDk ("Voucher Total", JKText.FONT_B_XSM);
            Label lblAmtRchgPlus = JKText.getLblDk (RechargePlusUtil.RECHARGE_PLUS_LBL + " (R" + JKText.getDeciFormat (amtRchgPlus) + " x " + voucherQty + ")", JKText.FONT_B_XSM);
            Text txtAmtDue = JKText.getTxtDk ("R " + JKText.getDeciFormat (amtDue), JKText.FONT_B_24);
            double amtRechargePlusTotal = voucherQty * amtRchgPlus;
            Text txtAmtRchgPlus = JKText.getTxtDk ("R " + JKText.getDeciFormat (amtRechargePlusTotal), JKText.FONT_B_24);
            txtAmtTotal.setText ("R " + JKText.getDeciFormat (amtDue + amtRechargePlusTotal));

            grid.addRow (3, lblAmtDue, txtAmtDue);
            grid.addRow (4, lblAmtRchgPlus, txtAmtRchgPlus);
            grid.addRow (6, lblAmtTotal, txtAmtTotal);
        } else {
            txtAmtTotal.setText ("R " + JKText.getDeciFormat (amtDue));
            grid.addRow (5, lblAmtTotal, txtAmtTotal);
        }

        String confirmPurchase = "Are you sure you want to purchase ";
        if (voucherQty == 1) {
            confirmPurchase += "this Voucher?";
        } else if (voucherQty > 1) {
            confirmPurchase += voucherQty + " Vouchers?";
        }
        JKiosk3.getMsgBox ().showMsgBox ("Voucher Sale", confirmPurchase, grid,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        buyVouchers ();
                    }

                    @Override
                    public void onCancel() {
                        //
                    }
                });
    }

    private void buyVouchers() {
        VoucherMultiReq req = new VoucherMultiReq ();
        req.setUserPin (CurrentUser.getSalesUser ().getUserPin ());
        req.setDeviceId (JKSystem.getSystemConfig ().getDeviceId ());
        req.setDeviceSer (JKSystem.getSystemConfig ().getSerial ());
        req.setProductId (product.getProductID ());
        req.setReference (SalesUtil.getUniqueRef ());
        req.setQuantity (voucherQty);
        req.setRechargePlus (isRechargePlus);
        req.setPrint (true);
        /* ******************************************************************************** */
        /* NOTE : JKiosk does NOT YET manage processing of all-in-one prints as per CR-2063 */
        /* ******************************************************************************** */
        req.setPrintIndividualSlips (true);

        VoucherSale.getInstance ().setRechargePlus (isRechargePlus);

        VoucherUtil.getAirtimeVouchers (req, new VoucherUtil.AirtimeVouchersResult () {
            @Override
            public void airtimeVoucherResult(VoucherMultiResp vouchers) {
                if (vouchers.isSuccess ()) {
                    VoucherSale.getInstance ().setResponse (vouchers);
                    if (isRechargePlus) {
                        VoucherSale.getInstance ().setCanCancel (false);
                    } else {
                        VoucherSale.getInstance ().setCanCancel (!JKPrintOptions.getPrintOptions ().isPrintImmediately ());
                    }
//                    VoucherSale.getInstance().setCanCancel(!JKPrintOptions.getPrintOptions().isPrintImmediately());
                    SalesUtil.processSoldVouchers (VoucherSale.getInstance ());
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Voucher Error", !vouchers.getAeonErrorText ().isEmpty () ?
                            vouchers.getAeonErrorCode () + " - " + vouchers.getAeonErrorText () :
                            vouchers.getErrorCode () + " - " + vouchers.getErrorText (), null);
                }
                SceneSales.clearAndShowFavourites ();
            }
        });
    }

    private boolean isValidEntry() {
        final String VOUCH_QTY = "Voucher Quantity";
        try {
            voucherQty = Integer.parseInt (txtQty.getText ());
            if (voucherQty == 0) {
                JKiosk3.getMsgBox ().showMsgBox (VOUCH_QTY, "Zero Vouchers selected,\nplease enter a valid number of Vouchers", null);
                return false;
            }
            if (voucherQty > 10) {
                JKiosk3.getMsgBox ().showMsgBox (VOUCH_QTY, "A Maximum of 10 Vouchers per Voucher Type is allowed", null);
                return false;
            }
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox ().showMsgBox (VOUCH_QTY, "Please enter a valid number of Vouchers", null);
            return false;
        }
        return true;
    }
}
