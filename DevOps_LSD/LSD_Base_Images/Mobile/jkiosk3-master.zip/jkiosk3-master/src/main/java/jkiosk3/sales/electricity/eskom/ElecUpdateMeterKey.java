package jkiosk3.sales.electricity.eskom;

import aeonelectricity.ElectricityConfirmation;
import aeonelectricity.ElectricityConnection;
import aeonelectricity.ElectricityMeter;
import aeonelectricity.ElectricityVoucher;
import aeonprinting.AeonPrintJob;

import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._components.MagCardPromptResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.MagCardData;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.PrintQueue;
import jkiosk3.printing.PrintUtil;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.electricity.ElecConfirm;
import jkiosk3.sales.electricity.ElecEnterMeter;
import jkiosk3.sales.electricity.ElecEnterMeterResult;
import jkiosk3.sales.electricity.ElecShareBtnsLessMore;
import jkiosk3.sales.electricity.ElecShareGridLessMore;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.store.JKCardReader;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.users.UserUtil;

/**
 * @author Val
 */
public class ElecUpdateMeterKey extends Region {

    private ElectricityConnection connection;
    private ElectricityConfirmation confirmation;
    private final ElectricityProvider provider;
    private ElecEnterMeter gMeter;
    private ElecShareBtnsLessMore btnsLessMore;
    private final ElecShareGridLessMore gridLessMore;
    private String meterNum;
    private String sgc;
    private String tt;
    private String ti;
    private String krn;
    private String alg;
    private boolean isMore = true;

    public ElecUpdateMeterKey(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;
        gridLessMore = new ElecShareGridLessMore (ElectricityUtil.ELEC_UPDATE_M_KEY);
        getChildren ().add (getMeterNumberEntry ());
    }

    private VBox getMeterNumberEntry() {
        final VBox vbUpdateKey = JKLayout.getVBox (0, JKLayout.spNum);
        gMeter = new ElecEnterMeter (provider, ElectricityUtil.ELEC_UPDATE_M_KEY, new ElecEnterMeterResult () {
            @Override
            public void onDone() {
                if (gMeter.isMagEntry ()) {
                    gridLessMore.setDisable (true);
//                    gridLessMore.getTxtSGC().setText("");
//                    gridLessMore.getTxtTT().setText("");
//                    gridLessMore.getTxtTi().setText("");
//                    gridLessMore.getTxtKrn().setText("");
//                    gridLessMore.getTxtAlg().setText("");
//                    btnsLessMore.getBtnLess().setDisable(true);
//                    btnsLessMore.getBtnMore().setDisable(true);
                    btnsLessMore.getBtnAccept ().setDisable (false);
                    isMore = false;
                } else {
                    if (vbUpdateKey.getChildren ().contains (gridLessMore)) {
                        gridLessMore.getTxtSGC ().setText ("");
                        gridLessMore.getTxtTT ().setText ("");
                        gridLessMore.getTxtTi ().setText ("");
                        gridLessMore.getTxtKrn ().setText ("");
                        gridLessMore.getTxtAlg ().setText ("");
                        vbUpdateKey.getChildren ().remove (gridLessMore);
                    }
                    vbUpdateKey.getChildren ().add (1, gridLessMore);
                }
            }
        });

//        VBox vbUpdateKey = JKLayout.getVBox(0, JKLayout.spNum);
//        vbUpdateKey.getChildren().addAll(gMeter, gridLessMore, getElecSaleCtrls());
        vbUpdateKey.getChildren ().addAll (gMeter, getElecSaleCtrls ());
        return vbUpdateKey;
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        btnsLessMore = new ElecShareBtnsLessMore ();

        btnsLessMore.getBtnAccept ().setDisable (false);
        btnsLessMore.getBtnAccept ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                if (inputValidation ()) {
                    makeElectricityConnection ();
                }
            }
        });
        btnsLessMore.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });

        return btnsLessMore;
    }

    private boolean inputValidation() {

        meterNum = gMeter.getMeterNum ().trim ();
        sgc = gridLessMore.getTxtSGC ().getText ();
        tt = gridLessMore.getTxtTT ().getText ();
        ti = gridLessMore.getTxtTi ().getText ();
        krn = gridLessMore.getTxtKrn ().getText ();
        alg = gridLessMore.getTxtAlg ().getText ();
        //
        if (meterNum.equals ("") || meterNum == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Meter Number", "Meter Number cannot be blank.\n"
                    + "Please enter Meter Number.", null);
            return false;
        }
        if (isMore) {
            if ((gridLessMore.getTxtSGC ().getText ().equals ("") || gridLessMore.getTxtSGC ().getText () == null)
                    || (gridLessMore.getTxtTT ().getText ().equals ("") || gridLessMore.getTxtTT ().getText () == null)
                    || (gridLessMore.getTxtTi ().getText ().equals ("") || gridLessMore.getTxtTi ().getText () == null)
                    || (gridLessMore.getTxtKrn ().getText ().equals ("") || gridLessMore.getTxtKrn ().getText () == null)
                    || (gridLessMore.getTxtAlg ().getText ().equals ("") || gridLessMore.getTxtAlg ().getText () == null)) {
                JKiosk3.getMsgBox ().showMsgBox ("Empty Field(s)", "All fields must be completed", null);
                return false;
            }
            if ((!sgc.matches ("\\d{6}")) || (!tt.matches ("\\d{2}")) || (!ti.matches ("\\d{2}"))
                    || (!krn.matches ("\\d{1}")) || (!alg.matches ("\\d{2}"))) {
                JKiosk3.getMsgBox ().showMsgBox ("Incorrect value entered",
                        "Fields must be numeric only: - \n"
                                + "SGC - 6 digits\n"
                                + "TT - 2 digits\n"
                                + "TI - 2 digits\n"
                                + "KRN - 1 digit\n"
                                + "ALG - 2 digits", null);
                return false;
            }
        }
        return true;
    }

    private void makeElectricityConnection() {
        final ElectricityMeter meter = new ElectricityMeter ();
        if (gMeter.isMagEntry ()) {
            meter.setTrack2data (meterNum);
            meter.setMeterSgc ("");
            meter.setMeterTt ("");
            meter.setMeterTi ("");
            meter.setMeterKrn ("");
            meter.setMeterAlg ("");
        } else {
            meter.setMeterNum (meterNum);
            meter.setMeterSgc (sgc);
            meter.setMeterTt (tt);
            meter.setMeterTi (ti);
            meter.setMeterKrn (krn);
            meter.setMeterAlg (alg);
        }

        String transType = provider.getTransactionType ();

        ElectricityUtil.getElectricityConfirmation (transType, "Update", meter, 0, new ElectricityUtil.ElectricityConfirm () {
            @Override
            public void electricityConfirm(ElectricityConnection connect, final ElectricityConfirmation confirm) {
                if (confirm.isSuccess ()) {
                    connection = connect;
                    confirmation = confirm;

                    ElecConfirm confirmGrid = new ElecConfirm (confirmation, meter, 0, ElectricityUtil.ELEC_UPDATE_M_KEY);

                    JKiosk3.getMsgBox ().showMsgBox ("Electricity Meter Confirmation", "Update Meter Key", confirmGrid,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    updateMeterKey (confirm.getTransRef ());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Unable to Confirm", !confirm.getAeonErrorText ().isEmpty () ?
                                    "A" + confirm.getErrorCode () + " - " + confirm.getErrorText () :
                                    "B" + confirm.getErrorCode () + " - " + confirm.getErrorText (),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    //
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                    ElectricityUtil.resetElectricity ();
                }
            }
        });
    }

    private void updateMeterKey(String transRef) {
        String ref = SalesUtil.getUniqueRef ();

        ElectricityUtil.getUpdateMeterKeyVoucher (connection, "Update", transRef, ref, new ElectricityUtil.EskomUpdateMeterKeyResult () {

            @Override
            public void eskomUpdateMeterKeyResult(final ElectricityVoucher updateMeterKeyVoucher) {
                if (updateMeterKeyVoucher.isSuccess ()) {
                    SalesUtil.processElectricity (ElectricityUtil.ELEC_UPDATE_M_KEY, updateMeterKeyVoucher, 0);

//                    int transRef = updateMeterKeyVoucher.getTransRef();
//                    String desc = ElectricityUtil.ELEC_UPDATE_M_KEY + " " + updateMeterKeyVoucher.getMeter().getMeterNum();
////                    AeonPrintJob printjob = updateMeterKeyVoucher.getPrintLines();
////                    AeonPrintJob apjm = updateMeterKeyVoucher.getMerchantPrintLines();
//
////                    SalesUtil.processSoldItem(transRef, SaleType.ELECTRICITY.getDisplay(), desc, printjob,
////                            0, false, "online", null);
//                    SalesUtil.processSoldItem(transRef, SaleType.ELECTRICITY.getDisplay(), desc, 
//                            updateMeterKeyVoucher.getPrintLines(), updateMeterKeyVoucher.getMerchantPrintLines(), 0, false, "online", null);
//////                    ElectricityUtil.printMerchantCopy(confirmation, updateMeterKeyVoucher, 0);
////                    PrintHandler.handleMerchantCopyPrint(apjm);
//
//                    final List<MagCardData> magList = ElectricityUtil.getMagCardTokens(updateMeterKeyVoucher);
//                    final List<MagCardData> cardUpdateList = ElectricityUtil.getMagCardUpdateByVoucher(updateMeterKeyVoucher);
//
//                    if (JKPrintOptions.getPrintOptions().isPrintImmediately()) {
//                        if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
//                            JKiosk3.getPrintPreview().showPrintPreview("Electricity Update Meter Key", updateMeterKeyVoucher.getPrintLines(),
//                                    PrintPreview.PRN_OK, new PrintPreviewResult() {
//                                        @Override
//                                        public void onOk() {
//                                            writeMagCards(cardUpdateList, magList, true);
//                                        }
//
//                                        @Override
//                                        public void onCancel() {
//                                            //
//                                        }
//                                    });
//                        } else {
//                            PrintUtil.sendToPrinter(updateMeterKeyVoucher.getPrintLines());
//                            writeMagCards(cardUpdateList, magList, true);
//                        }
//                    } else {
//                        PrintQueue.addItem(Integer.toString(transRef), updateMeterKeyVoucher.getPrintLines());
//                        PrintQueue.addMagCards(magList);
//                        writeMagCards(cardUpdateList, magList, false);
//                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Electricity Update Key Failed", !updateMeterKeyVoucher.getAeonErrorText ().isEmpty () ?
                            "A" + updateMeterKeyVoucher.getAeonErrorCode () + " - " + updateMeterKeyVoucher.getAeonErrorText () :
                            "B" + updateMeterKeyVoucher.getErrorCode () + " - " + updateMeterKeyVoucher.getErrorText (), null);
                }
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });
    }

//    private void writeMagCards(final List<MagCardData> cardUpdates, final List<MagCardData> magTokens, final boolean isWriteAll) {
//        if (JKCardReader.getCardReaderConfig().isMagCardWrite()) {
//            PrintUtil.writeMagCardUpdate(cardUpdates, new MagCardPromptResult() {
//                @Override
//                public void onDone() {
//                    if (isWriteAll) {
//                        PrintUtil.writeMagCardTokens(magTokens, null);
//                    }
//                }
//            });
//        } else {
//            JKiosk3.getMsgBox().showMsgBox("Unable to write Mag Cards", "Mag Card Read/Write not configured in Setup", null);
//        }
//    }
}
