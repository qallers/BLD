package jkiosk3.sales._favourites;

import aeonairtime.AirtimeManufacturer;
import aeonairtime.AirtimeProduct;
import aeontopup.TopupBundleCategory;
import aeontopup.TopupBundleProduct;
import aeonvarivouchers.Supplier;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKNode;
import jkiosk3._common.ResultCallback;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.blu.InputBluBillPay;
import jkiosk3.sales.billpay.payat.InputPayAtBillPay;
import jkiosk3.sales.billpay.payat.InputPayAtInsurance;
import jkiosk3.sales.billpay.payat.InputPayAtTrafficFine;
import jkiosk3.sales.billpay.sapo.InputSAPOBillPay;
import jkiosk3.sales.billpay.syntell.InputSyntellBillPay;
import jkiosk3.sales.billpay.syntell.InputSyntellTrafficFine;
import jkiosk3.sales.chat4change.Chat4Change;
import jkiosk3.sales.chat4change.Chat4ChangeSale;
import jkiosk3.sales.electricity.ElectricityMenu;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.ithuba.lotto.LottoMenu;
import jkiosk3.sales.ticketpro.TicketProMenu;
import jkiosk3.sales.topups.AirtimeUtil;
import jkiosk3.sales.topups.TopupProvider;
import jkiosk3.sales.topups.TopupSale;
import jkiosk3.sales.topups.airtime.AirtimeRecharge;
import jkiosk3.sales.topups.bundles.BundleRecharge;
import jkiosk3.sales.topups.wallets.WalletRecharge;
import jkiosk3.sales.vouchers.VoucherQuantity;
import jkiosk3.sales.vouchers.VoucherSale;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.SalesUserLoginResult;
import za.co.blt.consumer.loyalty.api.service.model.response.Favourite;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class FavNodes {

    private final static Logger logger = Logger.getLogger(FavNodes.class.getName());

    private List<Favourite> listFavourites;
    private SaleType saleType;
    private boolean isNFCFavourite;
    private final static String BTN_STYLE = "-fx-padding: 0px 5px 0px 5px; " +
            "-fx-text-alignment: left; " +
            "-fx-font-weight: bold; " +
            "-fx-font-size: ";
    private final static String STACK_STYLE = "-fx-padding: 0px 1px 0px 1px; " +
            "-fx-background-radius: 7.5px; " +
            "-fx-border-color: transparent;";

    public FavNodes(boolean isNFCFavourite, List<Favourite> listFavourites) {
        this.isNFCFavourite = isNFCFavourite;
        this.listFavourites = listFavourites;
    }

    /* Vouchers */
    public List<Button> getListBtnsVouchers(List<AirtimeManufacturer> listFavVouch) {
        List<Button> listBtns = new ArrayList<>();

        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();
        if ((onlineTransTypes.contains("Voucher"))) {
            for (AirtimeManufacturer m : listFavVouch) {
                for (final AirtimeProduct p : m.getProducts()) {
                    saleType = null;
                    switch (p.getCategoryId()) {
                        case 1:
                            saleType = SaleType.VOUCHER_AIRTIME;
                            break;
                        case 2:
                            saleType = SaleType.VOUCHER_DATA;
                            break;
                        case 3:
                            saleType = SaleType.VOUCHER_ELEC;
                            break;
                        case 4:
                            saleType = SaleType.VOUCHER_OTHER;
                            break;
                        default:
                            break;
                    }
                    Button btn = makeButtonFavouriteVoucherProduct(saleType, m, p);
                    listBtns.add(btn);
                }
            }
        } else {
            if (isNFCFavourite) {
                Button btnBlank = getBtnFavNotAvailable("Voucher Products not available");
                listBtns.add(btnBlank);
            }
        }

        return listBtns;
    }

    private Button makeButtonFavouriteVoucherProduct(final SaleType saleTypeVoucher, final AirtimeManufacturer m, final AirtimeProduct p) {

        String provStyle = m.getId();
        StackPane stackPane = makeAirtimeDataStack(m.getId(), provStyle);

        Button btn = makeFavouriteBtn(p.getName(), "prov_" + m.getId(), stackPane);
        btn.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StringBuilder sb = new StringBuilder("\n");
                sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
                sb.append(("\t\t>>>>> \tStarting sale for Favourite  : \t\t").concat(saleTypeVoucher.name()));
                logger.info(sb.toString());
                getSalesUserLogin(new ResultCallback() {
                    @Override
                    public void onResult(boolean result) {
                        VoucherSale.resetVoucherSale();
                        VoucherSale.getInstance().setSaleType(saleTypeVoucher);
                        VoucherSale.getInstance().setProvider(m);
                        VoucherSale.getInstance().setProduct(p);
                        SceneSales.clearAndChangeContent(new VoucherQuantity(true));
                    }
                });
            }
        });

        return btn;
    }

    /* Chat-4-Change */
    public List<Button> getListBtnsC4C(List<Supplier> listFavC4C) {
        List<Button> listBtns = new ArrayList<>();

        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();
        if (onlineTransTypes.contains("C4C_Voucher")) {
            for (final Supplier supp : listFavC4C) {
                saleType = SaleType.CHAT4CHANGE;
                Button btn = makeButtonFavouriteC4CProduct(SaleType.CHAT4CHANGE, supp, saleType.getDisplay());
                listBtns.add(btn);
            }
        } else {
            if (isNFCFavourite) {
                Button btnBlank = getBtnFavNotAvailable("Chat 4 Change not available");
                listBtns.add(btnBlank);
            }
        }

        return listBtns;
    }

    private Button makeButtonFavouriteC4CProduct(final SaleType saleTypeC4C, final Supplier supp, String strDisplay) {

        String provStyle = supp.getName();
        StackPane stackPane = makeAirtimeDataStack(supp.getName(), provStyle);

        Button btn = makeFavouriteBtn(saleTypeC4C.getDisplay(), "prov_" + supp.getName(), stackPane);
        btn.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StringBuilder sb = new StringBuilder("\n");
                sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
                sb.append(("\t\t>>>>> \tStarting sale for Favourite  : \t\t").concat(saleTypeC4C.name()));
                logger.info(sb.toString());
                getSalesUserLogin(new ResultCallback() {
                    @Override
                    public void onResult(boolean result) {
                        Chat4ChangeSale.resetChat4ChangeSale();
                        Chat4ChangeSale.getInstance().setSupplier(supp);
                        SceneSales.clearAndChangeContent(new Chat4Change(true));
                    }
                });
            }
        });

        return btn;
    }

    /* Topup Airtime */
    public List<Button> getListBtnsTopAir(List<TopupProvider> listFavTopupProvAirtime) {
        List<Button> listBtns = new ArrayList<>();

        for (final TopupProvider p : listFavTopupProvAirtime) {
            saleType = SaleType.TOPUP_AIRTIME;
            Button btn = makeButtonFavouriteTopAirProduct(SaleType.TOPUP_AIRTIME, p);
            listBtns.add(btn);
        }
        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();
        for (Favourite f : listFavourites) {
            if (f.getTrxGroup().equalsIgnoreCase("Topup") && !onlineTransTypes.contains(f.getTrxType())) {
                if (isNFCFavourite) {
                    Button btnBlank = getBtnFavNotAvailable(f.getTrxType() + " Topup not available");
                    listBtns.add(btnBlank);
                }
            }
        }

        return listBtns;
    }

    private Button makeButtonFavouriteTopAirProduct(final SaleType saleTypeTopAir, final TopupProvider prov) {
        final String provStyle = prov.getName();

        StackPane stackPane = makeAirtimeDataStack(prov.getName(), provStyle);

        Button btn = makeFavouriteBtn(saleTypeTopAir.getDisplay(), "prov_" + prov.getName() + "_fix", stackPane);
        btn.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StringBuilder sb = new StringBuilder("\n");
                sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
                sb.append(("\t\t>>>>> \tStarting sale for Favourite  : \t\t").concat(saleTypeTopAir.name()));
                logger.info(sb.toString());
                getSalesUserLogin(new ResultCallback() {
                    @Override
                    public void onResult(boolean result) {
                        TopupSale.resetTopupSale();
                        TopupSale.getInstance().setSaleType(saleTypeTopAir);
                        TopupSale.getInstance().setProvider(prov);
                        TopupSale.getInstance().setProviderStyleName(provStyle);
                        if (isNFCFavourite) {
                            SceneSales.clearAndChangeContent(new AirtimeRecharge(true, false));
                        } else {
                            SceneSales.clearAndChangeContent(new AirtimeRecharge(false, true));
                        }
                    }
                });
            }
        });

        return btn;
    }

    /* Topup Data and SMS */
    public List<Button> getListBtnsTopData(List<TopupProvider> listFavTopupProvBundles) {
        List<Button> listBtns = new ArrayList<>();

        for (TopupProvider prov : listFavTopupProvBundles) {
            for (TopupBundleCategory c : prov.getListBundles().getlistCategories()) {
                for (TopupBundleProduct prod : c.getListProducts()) {
                    saleType = null;
                    switch (c.getName()) {
                        case "SMS":
                            saleType = SaleType.TOPUP_BUNDLE_SMS;
                            break;
                        case "DATA":
                            saleType = SaleType.TOPUP_BUNDLE_DATA;
                            break;
                        default:
                            break;
                    }
                    Button btn = makeButtonFavouriteTopDataProduct(saleType, prov, prod);
                    listBtns.add(btn);
                }
            }
        }
        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();
        for (Favourite f : listFavourites) {
            if (f.getTrxGroup().equalsIgnoreCase("Bundles")
                    && f.getTrxType().contains("Bundles")
                    && !onlineTransTypes.contains(f.getTrxType())) {
                if (isNFCFavourite) {
                    Button btnBlank = getBtnFavNotAvailable(f.getTrxType() + " not available");
                    listBtns.add(btnBlank);
                }
            }
        }

        return listBtns;
    }

    private Button makeButtonFavouriteTopDataProduct(final SaleType saleTypeTopData, final TopupProvider prov, final TopupBundleProduct prod) {
        String img = AirtimeUtil.getProviderStyleName(prov);
        final String provStyle = AirtimeUtil.getProviderStyleName(prov);

        StackPane stackPane = makeAirtimeDataStack(img, provStyle);

        Button btn = makeFavouriteBtn(prod.getDescription(), "prov_" + provStyle + "_fix", stackPane);
        btn.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StringBuilder sb = new StringBuilder("\n");
                sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
                sb.append(("\t\t>>>>> \tStarting sale for Favourite  : \t\t").concat(saleTypeTopData.name()));
                logger.info(sb.toString());
                getSalesUserLogin(new ResultCallback() {
                    @Override
                    public void onResult(boolean result) {
                        TopupSale.resetTopupSale();
                        TopupSale.getInstance().setSaleType(saleTypeTopData);
                        TopupSale.getInstance().setProviderStyleName(provStyle);
                        TopupSale.getInstance().setProvider(prov);
                        TopupSale.getInstance().setProduct(prod);
                        if (isNFCFavourite) {
                            SceneSales.clearAndChangeContent(new BundleRecharge(true));
                        } else {
                            SceneSales.clearAndChangeContent(new BundleRecharge(false));
                        }
                    }
                });
            }
        });

        return btn;
    }

    /* Topup Wallet */
    public List<Button> getListBtnsTopWallet(List<TopupProvider> listFavTopupProvWallet) {
        List<Button> listBtns = new ArrayList<>();

        for (final TopupProvider p : listFavTopupProvWallet) {
            saleType = SaleType.TOPUP_WALLET;
            Button btn = makeButtonFavouriteTopWalletProduct(SaleType.TOPUP_WALLET, p);
            listBtns.add(btn);
        }
        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();
        for (Favourite f : listFavourites) {
            if (f.getTrxGroup().equalsIgnoreCase("Bundles")
                    && !f.getTrxType().contains("Bundles")
                    && !onlineTransTypes.contains(f.getTrxType())) {
                if (isNFCFavourite) {
                    Button btnBlank = getBtnFavNotAvailable(f.getTrxType() + " Topup not available");
                    listBtns.add(btnBlank);
                }
            }
        }

        return listBtns;
    }

    private Button makeButtonFavouriteTopWalletProduct(final SaleType saleTypeTopWallet, final TopupProvider prov) {
        final String provStyle = AirtimeUtil.getProviderStyleName(prov);

        StackPane stackPane = makeAirtimeDataStack(prov.getName(), provStyle);

        Button btn = makeFavouriteBtn(saleTypeTopWallet.getDisplay(), "prov_" + prov.getName() + "_fix", stackPane);
        btn.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StringBuilder sb = new StringBuilder("\n");
                sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
                sb.append(("\t\t>>>>> \tStarting sale for Favourite  : \t\t").concat(saleTypeTopWallet.name()));
                logger.info(sb.toString());
                getSalesUserLogin(new ResultCallback() {
                    @Override
                    public void onResult(boolean result) {
                        TopupSale.resetTopupSale();
                        TopupSale.getInstance().setSaleType(saleTypeTopWallet);
                        TopupSale.getInstance().setProvider(prov);
                        TopupSale.getInstance().setProviderStyleName(provStyle);
                        if (isNFCFavourite) {
                            SceneSales.clearAndChangeContent(new WalletRecharge(true, false));
                        } else {
                            SceneSales.clearAndChangeContent(new WalletRecharge(false, true));
                        }
                    }
                });
            }
        });

        return btn;
    }

    /* Electricity */
    public List<Button> getListBtnsElectricity(List<ElectricityProvider> listFavElecSuppliers) {
        List<Button> listBtns = new ArrayList<>();

        for (Favourite f : listFavourites) {
            for (ElectricityProvider s : listFavElecSuppliers) {
                if (f.getTrxGroup().equalsIgnoreCase("Electricity") && f.getTrxType().equalsIgnoreCase(s.getTransactionType())) {
                    saleType = SaleType.ELECTRICITY;
                    Button btn = makeButtonFavouriteElectricityProvider(s);
                    listBtns.add(btn);
                }
            }
        }
        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();
        for (Favourite f : listFavourites) {
            if (f.getTrxGroup().equalsIgnoreCase("Electricity") && !onlineTransTypes.contains(f.getTrxType())) {
                if (isNFCFavourite) {
                    Button btnBlank = getBtnFavNotAvailable(f.getTrxType() + " Electricity not available");
                    listBtns.add(btnBlank);
                }
            }
        }

        return listBtns;
    }

    private Button makeButtonFavouriteElectricityProvider(final ElectricityProvider prov) {
        double imgW = 65;
        double imgH = 60;

        ImageView iv = makeFavouriteImageView(imgW, imgH, "prov_electricity");

        StackPane stackPane = makeFavouriteStackPane(imgW, imgH, "");
        stackPane.getChildren().add(iv);

        Button btn = makeFavouriteBtn(prov.getDisplayName(), "prov_Electricity_fix", stackPane);
        btn.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StringBuilder sb = new StringBuilder("\n");
                sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
                sb.append(("\t\t>>>>> \tStarting sale for Favourite  : \t\t").concat(SaleType.ELECTRICITY.name()));
                logger.info(sb.toString());
                SceneSales.clearAndChangeContent(new ElectricityMenu(prov));
            }
        });
        return btn;
    }

    /* Bill Payments */
    public List<Button> getListBtnsBillPayments(List<BillPayProduct> listFavBPProds) {
        List<Button> listBtns = new ArrayList<>();

        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();

        for (final BillPayProduct prod : listFavBPProds) {
            if (onlineTransTypes.contains(prod.getBpTransType().getTrxType())) {
                saleType = SaleType.BILLPAYMENTS;
                Button btn = getBtnFavBillPayProduct(prod);
                btn.setOnMouseReleased(new EventHandler<Event>() {
                    @Override
                    public void handle(Event e) {
                        StringBuilder sb = new StringBuilder("\n");
                        sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
                        sb.append(("\t\t>>>>> \tStarting sale for Favourite  : \t\t").concat(saleType.name()));
                        logger.info(sb.toString());
                        getSalesUserLogin(new ResultCallback() {
                            @Override
                            public void onResult(boolean result) {
                                switch (prod.getBpTransType()) {
                                    case BILLPAY_PAYAT_ACCOUNT:
                                        if (isNFCFavourite) {
                                            SceneSales.clearAndChangeContent(new InputPayAtBillPay(prod, true, false));
                                        } else {
                                            SceneSales.clearAndChangeContent(new InputPayAtBillPay(prod, false, true));
                                        }
                                        break;
                                    case BILLPAY_PAYAT_INSURANCE:
                                        if (isNFCFavourite) {
                                            SceneSales.clearAndChangeContent(new InputPayAtInsurance(prod, BillPayUtilMisc.INSURE_PAYMENT, true, false));
                                        } else {
                                            SceneSales.clearAndChangeContent(new InputPayAtInsurance(prod, BillPayUtilMisc.INSURE_PAYMENT, false, true));
                                        }
                                        break;
                                    case BILLPAY_PAYAT_TRAFFIC:
                                        if (isNFCFavourite) {
                                            SceneSales.clearAndChangeContent(new InputPayAtTrafficFine(prod, true, false));
                                        } else {
                                            SceneSales.clearAndChangeContent(new InputPayAtTrafficFine(prod, false, true));
                                        }
                                        break;
                                    case BILLPAY_SYNTELL_ACCOUNT:
                                        if (isNFCFavourite) {
                                            SceneSales.clearAndChangeContent(new InputSyntellBillPay(prod, true, false));
                                        } else {
                                            SceneSales.clearAndChangeContent(new InputSyntellBillPay(prod, false, true));
                                        }
                                        break;
                                    case BILLPAY_SYNTELL_TRAFFIC:
                                        if (isNFCFavourite) {
                                            SceneSales.clearAndChangeContent(new InputSyntellTrafficFine(prod, true, false));
                                        } else {
                                            SceneSales.clearAndChangeContent(new InputSyntellTrafficFine(prod, false, true));
                                        }
                                        break;
                                    case BILLPAY_SAPO_ACCOUNT:
                                        if (isNFCFavourite) {
                                            SceneSales.clearAndChangeContent(new InputSAPOBillPay(prod, true, false));
                                        } else {
                                            SceneSales.clearAndChangeContent(new InputSAPOBillPay(prod, false, true));
                                        }
                                        break;
                                    case BILLPAY_BLU_ACCOUNT:
                                        if (isNFCFavourite) {
                                            SceneSales.clearAndChangeContent(new InputBluBillPay(prod, true, false));
                                        } else {
                                            SceneSales.clearAndChangeContent(new InputBluBillPay(prod, false, true));
                                        }
                                        break;
                                    default:
                                        JKiosk3.getMsgBox().showMsgBox(SaleType.BILLPAYMENTS.getDisplay(), "Please select a Product to pay", null);
                                }
                            }
                        });
                    }
                });
                listBtns.add(btn);
            }
        }

        for (Favourite f : listFavourites) {
            if (f.getTrxGroup().equalsIgnoreCase("Payments") && !onlineTransTypes.contains(f.getTrxType())) {
                if (isNFCFavourite) {
                    String strBillPay = "";
                    switch (f.getTrxType()) {
                        case "BluBillPayment":
                            strBillPay = BPTransType.BILLPAY_BLU_ACCOUNT.getDisplayName();
                            break;
                        case "VASPayAtAccountPayment":
                            strBillPay = BPTransType.BILLPAY_PAYAT_ACCOUNT.getDisplayName();
                            break;
                        case "VASPayAtFinePayment":
                            strBillPay = BPTransType.BILLPAY_PAYAT_TRAFFIC.getDisplayName();
                            break;
                        case "VASPayAtInsurance":
                            strBillPay = BPTransType.BILLPAY_PAYAT_INSURANCE.getDisplayName();
                            break;
                        case "VASSAPOAccountPayment":
                            strBillPay = BPTransType.BILLPAY_SAPO_ACCOUNT.getDisplayName();
                            break;
                        case "VASSyntellAccountPayment":
                            strBillPay = BPTransType.BILLPAY_SYNTELL_ACCOUNT.getDisplayName();
                            break;
                        case "VASSyntellFinePayment":
                            strBillPay = BPTransType.BILLPAY_SYNTELL_TRAFFIC.getDisplayName();
                            break;
                        default:
                            strBillPay = f.getTrxType();
                            break;
                    }
                    Button btnBlank = getBtnFavNotAvailable(strBillPay + " not available");
                    listBtns.add(btnBlank);
                }
            }
        }

        return listBtns;
    }

    private Button getBtnFavBillPayProduct(BillPayProduct product) {
        double imgW = 65;
        double imgH = 32;

        ImageView iv = new ImageView();
        if (product.getProvName().contains("Blu Bill Payment")) {
            iv = BillPayUtilMisc.getImageViewBillPay("prov_Blu.png");
        } else if (product.getProvName().contains("Pay@")) {
            iv = BillPayUtilMisc.getImageViewBillPay("prov_PayAt.png");
        } else if (product.getProvName().contains("Syntell")) {
            iv = BillPayUtilMisc.getImageViewBillPay("prov_Syntell.png");
        } else if (product.getProvName().contains("SAPO")) {
            iv = BillPayUtilMisc.getImageViewBillPay("prov_SAPO.png");
        }
        // first check width, then height
        if (iv.getImage().getWidth() > imgW - 4) {
            iv.setFitWidth(imgW - 4);
        }
        iv.setPreserveRatio(true);
        if (iv.getImage().getHeight() > imgH - 2) {
            iv.setFitHeight(imgH - 2);
        }
        iv.setPreserveRatio(true);

        StackPane stackPane = makeFavouriteStackPane(imgW, imgH, "");
        stackPane.getChildren().add(iv);

        Button btn = makeFavouriteBtn(product.getProdName(), "prov_VASSmTxt_fix", stackPane);

        return btn;
    }

    /* Ticketing */
    public List<Button> getListBtnsTicketing(List<String> listTicketing) {
        List<Button> listBtns = new ArrayList<>();

        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();

        for (Favourite f : listFavourites) {
            for (String s : listTicketing) {
                if (f.getTrxGroup().equalsIgnoreCase("Tickets") && f.getTrxType().equalsIgnoreCase(s)) {
                    if (onlineTransTypes.contains(s)) {
                        String btnlabel = "";
                        Button btn = new Button();
                        switch (s) {
                            case "TKP_TICKET":
                                saleType = SaleType.TICKETPRO;
                                btnlabel = "TicketPro";
                                btn = makeButtonFavouriteTicketProProducts(saleType, btnlabel);
                                break;
                            default:
                                saleType = SaleType.BUSTICKETS;
                                btnlabel = s;
                                btn = makeButtonFavouriteBusTicketProducts(saleType, btnlabel);
                                break;
                        }
                        listBtns.add(btn);
                    }
                }
            }
        }
        for (Favourite f : listFavourites) {
            if (f.getTrxGroup().equalsIgnoreCase("Tickets") && !onlineTransTypes.contains(f.getTrxType())) {
                if (isNFCFavourite) {
                    String strTicket = "";
                    switch (f.getTrxType()) {
                        case "TKP_TICKET":
                            strTicket = "TicketPro";
                            break;
                        default:
                            strTicket = f.getTrxType();
                            break;
                    }
                    Button btnBlank = getBtnFavNotAvailable(strTicket + " Tickets not available");
                    listBtns.add(btnBlank);
                }
            }
        }

        return listBtns;
    }

    private Button makeButtonFavouriteBusTicketProducts(final SaleType saleTypeTicket, String prov) {
        double imgW = 65;
        double imgH = 35;

        ImageView iv = makeFavouriteImageView(imgW, imgH, "prov_" + prov);

        StackPane stackPane = makeFavouriteStackPane(imgW, imgH, "");
        stackPane.getChildren().add(iv);

        Button btn = makeFavouriteBtn(prov, "prov_VASSmTxt_fix", stackPane);
        btn.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StringBuilder sb = new StringBuilder("\n");
                sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
                sb.append(("\t\t>>>>> \tStarting sale for Favourite  : \t\t").concat(saleTypeTicket.name()));
                logger.info(sb.toString());
                getSalesUserLogin(new ResultCallback() {
                    @Override
                    public void onResult(boolean result) {
//                        SceneSales.clearAndChangeContent(new CarmaCarriers());
                        JKiosk3.getMsgBox().showMsgBox("No longer available",
                                "Please purchase tickets from the 'Coach Tickets' menu", null);
                        SceneSales.clearAndShowFavourites();
                    }
                });
            }
        });

        return btn;
    }

    private Button makeButtonFavouriteTicketProProducts(final SaleType saleTypeTicket, String prov) {

        ImageView iv = JKNode.getJKImageViewProvider("TicketPros.png");

        Button btn = makeFavouriteBtn("", "prov_TicketPros_fix", iv);
        btn.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StringBuilder sb = new StringBuilder("\n");
                sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
                sb.append(("\t\t>>>>> \tStarting sale for Favourite  : \t\t").concat(saleTypeTicket.name()));
                logger.info(sb.toString());
                getSalesUserLogin(new ResultCallback() {
                    @Override
                    public void onResult(boolean result) {
                        SceneSales.clearAndChangeContent(new TicketProMenu());
                    }
                });
            }
        });

        return btn;
    }

    /* Ithuba */
    public List<Button> getListBtnsIthuba(List<String> listIthuba) {
        List<Button> listBtns = new ArrayList<>();

        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();
        for (Favourite f : listFavourites) {
            for (String s : listIthuba) {
                if (f.getTrxType().equalsIgnoreCase(s) && onlineTransTypes.contains(s)) {
                    saleType = SaleType.LOTTO;
                    Button btn = makeButtonFavouriteIthubaProvider();
                    listBtns.add(btn);
                }
            }
        }

        for (Favourite f : listFavourites) {
            if (f.getTrxType().equalsIgnoreCase("Ithuba") && !onlineTransTypes.contains(f.getTrxType())) {
                if (isNFCFavourite) {
                    Button btnBlank = getBtnFavNotAvailable(f.getTrxType() + " not available");
                    listBtns.add(btnBlank);
                }
            }
        }

        return listBtns;
    }

    private Button makeButtonFavouriteIthubaProvider() {
        double imgW = 65;
        double imgH = 60;

        ImageView iv = makeFavouriteImageView(imgW, imgH, "prov_Ithuba");

        StackPane stackPane = makeFavouriteStackPane(imgW, imgH, "prov_ithuba", "prov_ithuba_lotto");
        stackPane.getChildren().add(iv);

        Button btn = makeFavouriteBtn("Ithuba", "prov_ithuba", stackPane);
        btn.getStyleClass().add("prov_ithuba_lotto");
        btn.setStyle(BTN_STYLE + "14pt; -fx-graphic-text-gap: 5px;");
        btn.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StringBuilder sb = new StringBuilder("\n");
                sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
                sb.append(("\t\t>>>>> \tStarting sale for Favourite  : \t\t").concat(SaleType.LOTTO.name()));
                logger.info(sb.toString());
                getSalesUserLogin(new ResultCallback() {
                    @Override
                    public void onResult(boolean result) {
                        SceneSales.clearAndChangeContent(new LottoMenu());
                    }
                });
            }
        });
        return btn;
    }

    /* Generic items */
    private StackPane makeAirtimeDataStack(String prov, String provStyle) {
        double imgW = 65;
        double imgH = 32;

        ImageView iv = makeFavouriteImageView(imgW, imgH, "prov_" + prov);

        StackPane stackPane = makeFavouriteStackPane(imgW, imgH, "prov_" + provStyle + "_fix");
        stackPane.getChildren().add(iv);

        return stackPane;
    }

    private StackPane makeFavouriteStackPane(double imgW, double imgH, String... strStyle) {
        StackPane stackPane = new StackPane();
        stackPane.setMaxSize(imgW, imgH);
        stackPane.setMinSize(imgW, imgH);

        if (!strStyle.equals("")) {
            stackPane.getStyleClass().addAll(strStyle);
        }

        stackPane.setStyle(STACK_STYLE);

        return stackPane;
    }

    private ImageView makeFavouriteImageView(double imgW, double imgH, String imgName) {
        ImageView iv = JKNode.getJKImageViewProvider(imgName + ".png");
        // first check width, then height
        if (iv.getImage().getWidth() > imgW - 4) {
            iv.setFitWidth(imgW - 4);
        }
        iv.setPreserveRatio(true);
        if (iv.getImage().getHeight() > imgH - 2) {
            iv.setFitHeight(imgH - 2);
        }
        iv.setPreserveRatio(true);
        return iv;
    }

    private Button makeFavouriteBtn(String btnText, String btnStyle, Node btnGraphic) {
        Button btn = JKNode.getBtnSmDbl(btnText);
        btn.setGraphic(btnGraphic);
        btn.setGraphicTextGap(5);
        btn.setAlignment(Pos.CENTER_LEFT);
        btn.getStyleClass().add(btnStyle);
        if (btnText.length() > 35) {
            btn.setStyle(BTN_STYLE + "12pt;");
        } else {
            btn.setStyle(BTN_STYLE + "14pt;");
        }
        btn.setWrapText(true);
        return btn;
    }

    private Button getBtnFavNotAvailable(String str) {
        Button btn = JKNode.getBtnSmDbl(str);
        btn.getStyleClass().add("btnFavourites");
        btn.setStyle("-fx-font-size: 13pt;");
        if (str.length() > 32) {
            btn.setStyle("-fx-font-size: 12pt;");
        }
        btn.setTextAlignment(TextAlignment.CENTER);
        btn.setWrapText(true);
        btn.setDisable(true);
        return btn;
    }

    private void getSalesUserLogin(final ResultCallback resultCallback) {
        JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
            @Override
            public void onDone() {
                resultCallback.onResult(true);
            }
        });
    }
}
//
// END OF CODE
//
//    private Button makeButtonFavouriteVoucher(SaleType saleTypeVoucher, AirtimeManufacturer m, AirtimeProduct p) {
//        Button btnVoucher = getBtnFav(saleTypeVoucher, m.getId(), p.getName());
//        btnVoucher.setStyle("-fx-border-color: #FF0000; -fx-border-width: 2px;");
//        btnVoucher.setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                getSalesUserLogin(new ResultCallback() {
//                    @Override
//                    public void onResult(boolean result) {
//                        VoucherSale.resetVoucherSale();
//                        VoucherSale.getInstance().setSaleType(saleTypeVoucher);
//                        VoucherSale.getInstance().setProvider(m);
//                        VoucherSale.getInstance().setProduct(p);
//                        SceneSales.clearAndChangeContent(new VoucherQuantity(true));
//                    }
//                });
//            }
//        });
//
//        return btnVoucher;
//    }

//    private Button makeButtonFavouriteC4C(SaleType saleTypeC4C, Supplier supp, String strDisplay) {
//        Button btnC4C = getBtnFav(saleTypeC4C, supp.getName(), strDisplay);
//        btnC4C.setStyle("-fx-border-color: #FF7F2A; -fx-border-width: 2px;");
//        btnC4C.setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                getSalesUserLogin(new ResultCallback() {
//                    @Override
//                    public void onResult(boolean result) {
//                        Chat4ChangeSale.resetChat4ChangeSale();
//                        Chat4ChangeSale.getInstance().setSupplier(supp);
//                        SceneSales.clearAndChangeContent(new Chat4Change(true));
//                    }
//                });
//            }
//        });
//
//        return btnC4C;
//    }

//    private Button makeButtonFavouriteTopAir(SaleType saleTypeTopAir, TopupProvider prov, String strDisplay) {
//        String provStyle = AirtimeUtil.getProviderStyleName(prov);
//        Button btnTopAir = getBtnFav(saleTypeTopAir, prov.getName(), strDisplay);
//        btnTopAir.setStyle("-fx-border-color: #2AAAFF; -fx-border-width: 2px;");
//        btnTopAir.setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                getSalesUserLogin(new ResultCallback() {
//                    @Override
//                    public void onResult(boolean result) {
//                        TopupSale.resetTopupSale();
//                        TopupSale.getInstance().setSaleType(saleTypeTopAir);
//                        TopupSale.getInstance().setProvider(prov);
//                        TopupSale.getInstance().setProviderStyleName(provStyle);
//                        if (isNFCFavourite) {
//                            SceneSales.clearAndChangeContent(new AirtimeRecharge(true, false));
//                        } else {
//                            SceneSales.clearAndChangeContent(new AirtimeRecharge(false, true));
//                        }
//                    }
//                });
//            }
//        });
//
//        return btnTopAir;
//    }

//    private Button makeButtonFavouriteTopData(SaleType saleTypeTopData, TopupProvider prov, TopupBundleProduct prod) {
//        String provStyle = AirtimeUtil.getProviderStyleName(prov);
//        Button btnTopData = getBtnFav(saleTypeTopData, provStyle, prod.getDescription());
//        btnTopData.setStyle("-fx-border-color: #00FFFF; -fx-border-width: 2px;");
//        btnTopData.setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                getSalesUserLogin(new ResultCallback() {
//                    @Override
//                    public void onResult(boolean result) {
//                        TopupSale.resetTopupSale();
//                        TopupSale.getInstance().setSaleType(saleTypeTopData);
//                        TopupSale.getInstance().setProviderStyleName(provStyle);
//                        TopupSale.getInstance().setProvider(prov);
//                        TopupSale.getInstance().setProduct(prod);
//                        if (isNFCFavourite) {
//                            SceneSales.clearAndChangeContent(new BundleRecharge(true));
//                        } else {
//                            SceneSales.clearAndChangeContent(new BundleRecharge(false));
//                        }
//                    }
//                });
//            }
//        });
//
//        return btnTopData;
//    }

//    private Button makeButtonFavouriteElectricity(SaleType saleTypeElect, ElectricityProvider prov) {
//        Button btnElect = getBtnFav(saleTypeElect, prov.getDisplayName(), prov.getDisplayName());
//        btnElect.setStyle("-fx-border-color: #FFFF00; -fx-border-width: 2px;");
//        btnElect.setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                getSalesUserLogin(new ResultCallback() {
//                    @Override
//                    public void onResult(boolean result) {
//                        SceneSales.clearAndChangeContent(new ElecToken(prov));
//                    }
//                });
//            }
//        });
//        List<UserTransactionType> listUserTransTypes = CurrentUser.getUser().getUserTransactionTypes();
//        for (UserTransactionType utt : listUserTransTypes) {
//            if (utt.getType().equalsIgnoreCase("Electricity")) {
//                if (utt.getDisplayName().equalsIgnoreCase(prov.getDisplayName())) {
//                    // found provider, no need to continue
//                    btnElect.setDisable(false);
//                    break;
//                } else {
//                    btnElect.setDisable(true);
//                }
//            }
//        }
//
//        return btnElect;
//    }

//    private Button makeButtonFavouriteTickets(SaleType saleTypeTicket, String prov) {
//        Button btnTicket = getBtnFav(saleTypeTicket, prov, prov);
//        btnTicket.setStyle("-fx-border-width: 2px;");
//        btnTicket.setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                getSalesUserLogin(new ResultCallback() {
//                    @Override
//                    public void onResult(boolean result) {
//                        switch (saleTypeTicket) {
//                            case TICKETPRO:
//                                SceneSales.clearAndChangeContent(new TicketProMenu());
//                                break;
//                            default:
//                                SceneSales.clearAndChangeContent(new CarmaCarriers());
//                                break;
//                        }
//                    }
//                });
//            }
//        });
//
//        return btnTicket;
//    }

// // //
//    private Button getBtnFav(SaleType saleTypeBtn, String prov, String label) {
//        VBox vb = getProductBox(saleTypeBtn, prov);
//        Button btn = getFavouriteButton(vb, label);
//
//        return btn;
//    }

// Bill payments need a BillPayProduct to build view.
//    private Button getBtnFavBillPay(BillPayProduct product) {
//        VBox vb = getProductBoxBillPay(product);
//        Button btn = getFavouriteButton(vb, product.getProdName());
//        btn.setStyle("-fx-border-color: #00FF00; -fx-border-width: 2px;");
//
//        return btn;
//    }

//    private VBox getProductBox(SaleType saleType, String prov) {
//        Label lbl = JKText.getLblDk("", JKText.FONT_B_15);
//
//        ImageView iv = JKNode.getJKImageViewProvider("prov_" + prov + ".png");
//        StackPane stackPane = getProductStack();
//
//        switch (saleType) {
//            case VOUCHER_AIRTIME:
//            case VOUCHER_DATA:
//            case VOUCHER_ELEC:
//            case VOUCHER_OTHER:
//                lbl.setText(saleType.getDisplay().substring(0, saleType.getDisplay().indexOf(" ")));
//                stackPane.getStyleClass().add("prov_" + prov + "_fix");
//                break;
//            case CHAT4CHANGE:
//                lbl.setText(saleType.getType());
//                stackPane.getStyleClass().add("prov_" + prov + "_fix");
//                break;
//            case TOPUP_AIRTIME:
//            case TOPUP_BUNDLE_DATA:
//            case TOPUP_BUNDLE_SMS:
//                lbl.setText(saleType.getType());
//                stackPane.getStyleClass().add("prov_" + prov + "_fix");
//                break;
//            case ELECTRICITY:
//                lbl.setText(saleType.getType());
//                iv = JKNode.getJKImageViewProvider("prov_electricity.png");
//                stackPane.getStyleClass().add("prov_NFC_fix");
//                break;
//            case BUSTICKETS:
//                lbl.setText(saleType.getDisplay());
//                stackPane.getStyleClass().add("prov_NFC_fix");
//                break;
//            case TICKETPRO:
//                lbl.setText(saleType.getType());
//                iv = JKNode.getJKImageViewProvider("TicketPros.png");
//                stackPane.getStyleClass().add("prov_TicketPros_fix");
//                break;
//            case LOTTO:
//                lbl.setText(saleType.getType());
//                iv = JKNode.getJKImageViewProvider("prov_Ithuba.png");
//                stackPane.getStyleClass().add("prov_NFC_fix");
//                break;
//            default:
//                break;
//        }
//        setImageViewSize(iv);
//
//        stackPane.setStyle(getProductStackStyle());
//        stackPane.getChildren().add(iv);
//
//        VBox vb = getProductVBox();
//        vb.getChildren().addAll(lbl, stackPane);
//
//        return vb;
//    }

//    private VBox getProductBoxBillPay(BillPayProduct bpProduct) {
//        Label lbl = JKText.getLblDk("", JKText.FONT_B_15);
//
//        ImageView iv = JKNode.getJKImageViewProvider("prov_" + bpProduct.getProvName() + ".png");
//        StackPane stackPane = getProductStack();
//
//        switch (bpProduct.getBpTransType()) {
//            case BILLPAY_PAYAT_ACCOUNT:
//            case BILLPAY_SYNTELL_ACCOUNT:
//            case BILLPAY_SAPO_ACCOUNT:
//            case BILLPAY_BLU_ACCOUNT:
//            case BILLPAY_BLU_M2M:
//                lbl.setText("Payment");
//                break;
//            case BILLPAY_PAYAT_INSURANCE:
//                lbl.setText("Insurance");
//                break;
//            case BILLPAY_PAYAT_TRAFFIC:
//            case BILLPAY_SYNTELL_TRAFFIC:
//                lbl.setText("Traffic Fine");
//                break;
//            default:
//                break;
//        }
//
//        if (bpProduct.getProvName().contains("Blu Bill Payment")) {
//            iv = BillPayUtilMisc.getImageViewBillPay("prov_Blu.png");
//        } else if (bpProduct.getProvName().contains("Pay@")) {
//            iv = BillPayUtilMisc.getImageViewBillPay("prov_PayAt.png");
//        } else if (bpProduct.getProvName().contains("Syntell")) {
//            iv = BillPayUtilMisc.getImageViewBillPay("prov_Syntell.png");
//        } else if (bpProduct.getProvName().contains("SAPO")) {
//            iv = BillPayUtilMisc.getImageViewBillPay("prov_SAPO.png");
//        }
//        stackPane.getStyleClass().add("prov_NFC_fix");
//
//        setImageViewSize(iv);
//
//        stackPane.setStyle(getProductStackStyle());
//        stackPane.getChildren().add(iv);
//
//        VBox vb = getProductVBox();
//        vb.getChildren().addAll(lbl, stackPane);
//
//        return vb;
//    }

//    private void setImageViewSize(ImageView iv) {
//        // first check width, then height
//        if (iv.getImage().getWidth() > 90) {
//            iv.setFitWidth(90);
//        }
//        iv.setPreserveRatio(true);
//        if (iv.getImage().getHeight() > 35) {
//            iv.setFitHeight(35);
//        }
//        iv.setPreserveRatio(true);
//    }

//    private StackPane getProductStack() {
//        StackPane stackPane = new StackPane();
//        stackPane.setMaxSize(97, 37);
//        stackPane.setMinSize(97, 37);
//        return stackPane;
//    }

//    private String getProductStackStyle() {
//        String stackStyle = "-fx-padding: 1px; -fx-background-radius: 7.5px; -fx-border-radius: 7.5px; -fx-border-style: dotted; -fx-border-width: 0.75px;";
//        return stackStyle;
//    }

//    private VBox getProductVBox() {
//        VBox vBox = JKLayout.getVBox(0, 0);
//        vBox.setMaxWidth(97);
//        vBox.setMinWidth(97);
//        return vBox;
//    }

//    private Button getFavouriteButton(VBox vBox, String btnText) {
//        Button btn = JKNode.getBtnSmDbl(btnText);
//        btn.setGraphic(vBox);
//        btn.setGraphicTextGap(5);
//        btn.getStyleClass().add("btnFavourites");
//        btn.setAlignment(Pos.CENTER_LEFT);
//        if (btnText.length() > 32) {
//            btn.setStyle("-fx-font-size: 12pt;");
//        }
//        btn.setWrapText(true);
//        return btn;
//    }