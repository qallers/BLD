package jkiosk3.store;

import java.io.Serializable;

public class StoreJKCacheOptions implements Serializable {
    
    // S(tore) = 19 : (1 + 9 = 10) (1 + 0 = 1)
    // J(K)  = 10 : (1 + 0 = 1)
    // C(ache) = 3
    // O(ptions) = 15 : (1 + 5 = 6)
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 991136L;
    //
    private boolean daily = true;
    private boolean hourly = false;
    private boolean never = false;

    public boolean isDaily() {
        return daily;
    }

    public void setDaily(boolean daily) {
        this.daily = daily;
    }

    public boolean isHourly() {
        return hourly;
    }

    public void setHourly(boolean hourly) {
        this.hourly = hourly;
    }

    public boolean isNever() {
        return never;
    }

    public void setNever(boolean never) {
        this.never = never;
    }
}
