package jkiosk3.sales.billpay.payat;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.payat.PayAtAccPayConfReq;
import aeonbillpayments.payat.PayAtAccPayConfResp;
import aeonbillpayments.payat.PayAtAccPayReq;
import aeonbillpayments.payat.PayAtAccPayResp;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.BillPayUtilPayAt;
import jkiosk3.sales.billpay.BillPayUtilPayAt.PayAtBillPaymentResponse;
import jkiosk3.sales.billpay._common.BillPayEntry;
import jkiosk3.sales.billpay._common.BillPaymentSelect;
import jkiosk3.store.JKTransactionLimits;
import jkiosk3.users.UserUtil;

public class InputPayAtBillPay extends Region {

    private BillPaymentConnection connection;
    private final BillPayProduct product;
    private final VBox vbContent;
    private BillPayEntry gridAcc;
    private GridPane gridAmtDetail;
    private JKioskNav nav;
    private TextField txtAmt;
    private String accountNum;
    private double amountPaid;
    private String acceptPartPayment;
    private JKTenderToggles tenders;
    private String tendered;
    private PayAtAccPayReq request1;
    private PayAtAccPayResp response1;
    private PayAtAccPayReq request2;
    private PayAtAccPayResp response2;
    private boolean showFavourites;
    private boolean showProductFavourite;

    public InputPayAtBillPay(BillPayProduct p, boolean isNFCFavourite, boolean isProductFavourite) {
        this.product = p;
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;

        vbContent = JKLayout.getVBoxContent (JKLayout.spNum);

        VBox vbLayout = JKLayout.getVBox (0, 5);
        vbLayout.getChildren ().add (getAccountNumberEntry ());
        vbLayout.getChildren ().add (getNav ());

        getChildren ().add (vbLayout);
    }

    private VBox getAccountNumberEntry() {

        ImageView img = BillPayUtilMisc.getImageViewBillPay ("prov_PayAt.png");

        gridAcc = new BillPayEntry ("Account Payment", img, product, BillPayEntry.TYPE_ACCOUNT, showFavourites, showProductFavourite);
        gridAcc.getBtnDetail ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (vbContent.getChildren ().contains (gridAmtDetail)) {
                    vbContent.getChildren ().remove (gridAmtDetail);
                    getAccountRequestQuery ();
                } else {
                    getAccountRequestQuery ();
                }
            }
        });

        vbContent.getChildren ().add (gridAcc);

        return vbContent;
    }

    private GridPane getDetailAndAmountEntry() {

        GridPane gridDetail = BillPayUtilMisc.getGridBillPayDetail (response1.getAmountDue (), response1.getConvenienceFee (),
                acceptPartPayment, BPTransType.BILLPAY_PAYAT_ACCOUNT.getDisplayName ());

        Label lblAmount = JKText.getLblDk ("Amount", JKText.FONT_B_XSM);
        txtAmt = JKNode.getTextFieldRight ();

        if (product.isFullAmount ()) {
            txtAmt.setDisable (true);
            txtAmt.setPromptText ("Pay amount on confirm summary");
        } else if (response1.getAcceptPartPayment ().equalsIgnoreCase ("N")) {
            txtAmt.setText (JKText.getDeciFormat (response1.getAmountDue ()));
            amountPaid = response1.getAmountDue ();
            txtAmt.setDisable (true);
        } else {
            txtAmt.setDisable (false);
            txtAmt.setPromptText ("Enter Amount to Pay");
        }
        txtAmt.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad ().showNumPad (txtAmt,
                        "R " + (JKText.getDeciFormat (response1.getAmountDue () + response1.getConvenienceFee ())),
                        "", new NumberPadResult () {

                            @Override
                            public void onDone(String value) {
                                amountPaid = SalesUtil.getAmountAsDouble (value, txtAmt);
                            }
                        });
//                }
            }
        });

        gridAmtDetail = JKLayout.getContentGridInner2Col (0.5, 0.5);

        gridAmtDetail.add (gridDetail, 0, 1, 2, 1);
        gridAmtDetail.addRow (2, lblAmount, txtAmt);
        gridAmtDetail.addRow (3, getTenderTypes ());

        return gridAmtDetail;
    }

    private JKTenderToggles getTenderTypes() {
        tenders = new JKTenderToggles (SaleType.BILLPAYMENTS.getDisplay ());
        for (ToggleButton b : tenders.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(javafx.event.Event e) {
                    if (!txtAmt.getText ().trim ().equals ("") && amountPaid != 0) {
                        tendered = tenders.getTenderTypeSelected ();
                        System.out.println ("set tendered to type : " + tendered);
                        checkAndAuthoriseAmount ();
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("Amount to Pay", "Please enter an Amount", null);
                        tenders.resetTenderType ();
                    }
                }
            });
        }
        return tenders;
    }

    private JKioskNav getNav() {
        nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (gridAcc.getVbHead ().getChildren ().contains (gridAcc.getGridEnter ())) {
                    SceneSales.clearAndChangeContent (new BillPaymentSelect (
                            BillPayUtilMisc.TYPE_BILL_PAY + " Providers", BillPayUtilMisc.TYPE_BILL_PAY));
                } else {
                    SceneSales.clearAndChangeContent (new InputPayAtBillPay (product, showFavourites, showProductFavourite));
                }
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                BillPayUtilMisc.resetBillPayView ();
                if (request1 != null) {
                    submitPayAtBillPaymentRollback (request1, response1, BillPayUtilMisc.CALL_BY_CANCEL);
                }
            }
        });
        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private void showConfirmationSummary() {
        SummaryPayAtBillPay summary = new SummaryPayAtBillPay (response1, request2, response2, tendered);

        JKiosk3.getMsgBox ().showMsgBox (product.getBpTransType ().getDisplayName (), "Confirm all details before proceeding",
                summary, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        submitPayAtBillPaymentCommit (request2, response2);
                    }

                    @Override
                    public void onCancel() {
                        UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                        BillPayUtilMisc.resetBillPayView ();
                        submitPayAtBillPaymentRollback (request2, response2, BillPayUtilMisc.CALL_BY_CANCEL);
                    }
                });
    }

    //====================================
    // above - mostly view
    // below - mostly process
    //====================================
    private void getAccountRequestQuery() {
        if (inputValidAccount ()) {
            accountNum = gridAcc.getAccountNumberConfirmed ();

            request1 = new PayAtAccPayReq ();
            request1.setProviderId (product.getProvId ());
            request1.setProductId (product.getProdId ());
            request1.setAccountNo (accountNum);
            request1.setAmountDue (10.0);
            request1.setAdditionalAmount (0.0);
            request1.setPaymentRefNumber ("");
            request1.setStoreID ("");
            request1.setTillID ("");
            request1.setPaymentReceiptNo ("");
            request1.setEcho ("");
            request1.setRealTime (1);
            request1.setVerifyOnly (1);

            BillPayUtilPayAt.getPayAtBillPaymentResponse (request1, new PayAtBillPaymentResponse () {
                @Override
                public void payAtBillPayResp(BillPaymentConnection connect, PayAtAccPayResp resp) {
                    connection = connect;

                    if (resp.isSuccess ()) {
                        response1 = resp;
                        switch (resp.getAcceptPartPayment ()) {
                            case "Y":
                                acceptPartPayment = "Yes";
                                break;
                            case "N":
                                acceptPartPayment = "No";
                                break;
                            default:
                                JKiosk3.getMsgBox ().showMsgBox ("Pay@ Account Payment", "No Part Payment Result Received", null);
                        }
                        gridAcc.getVbHead ().getChildren ().remove (gridAcc.getGridEnter ());
                        gridAcc.getVbHead ().getChildren ().add (gridAcc.getGridDetail (resp.getPaymentRefNumber (),
                                resp.getFirstName () + " " + resp.getLastName ()));
                        gridAmtDetail = getDetailAndAmountEntry ();
                        vbContent.getChildren ().add (1, gridAmtDetail);
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("Account Detail Error", (!resp.getAeonErrorText ().isEmpty () ?
                                "A" + resp.getAeonErrorCode () + " - " + resp.getAeonErrorText () : "B" + resp.getErrorCode () + " - " + resp.getErrorText ()), null);
                        BillPayUtilMisc.resetBillPayView ();
                    }
                }
            });
        }
    }

    private void checkAndAuthoriseAmount() {
        if (amountPaid > JKTransactionLimits.getTransactionLimits ().getTransLimitBillPay ()) {
            BillPayUtilMisc.getSupervisorOverride (amountPaid, new UserUtil.SupervisorOverride () {

                @Override
                public void supervisorOverrideResult(Boolean isSupervisor) {
                    if (isSupervisor) {
                        submitPayAtBillPaymentRollback (request1, response1, BillPayUtilMisc.CALL_BY_TENDER);
                        System.out.println ("supervisor has authorised, show summary and continue...");
                    } else {
                        System.out.println ("no authorisation yet, try again...");
                    }
                }
            }, txtAmt);
            tenders.resetTenderType ();
        } else {
            submitPayAtBillPaymentRollback (request1, response1, BillPayUtilMisc.CALL_BY_TENDER);
        }
    }

    private void getAccountRequestPay() {
        request2 = new PayAtAccPayReq ();
        request2.setProviderId (product.getProvId ());
        request2.setProductId (product.getProdId ());
        request2.setAccountNo (accountNum);
        request2.setAmountDue (amountPaid);
        request2.setAdditionalAmount (0.0);
        request2.setPaymentRefNumber ("");
        request2.setStoreID ("");
        request2.setTillID ("");
        request2.setPaymentReceiptNo ("");
        request2.setEcho ("");
        request2.setRealTime (1);
        request2.setVerifyOnly (0);

        BillPayUtilPayAt.getPayAtBillPaymentResponse (request2, new PayAtBillPaymentResponse () {
            @Override
            public void payAtBillPayResp(BillPaymentConnection connect, PayAtAccPayResp resp) {
                connection = connect;

                if (resp.isSuccess ()) {
                    response2 = resp;
                    showConfirmationSummary ();
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Account Detail Error", (!resp.getAeonErrorText ().isEmpty () ?
                            "A" + resp.getAeonErrorCode () + " - " + resp.getAeonErrorText () : "B" + resp.getErrorCode () + " - " + resp.getErrorText ()), null);
                    BillPayUtilMisc.resetBillPayView ();
                }
            }
        });
    }

    private void submitPayAtBillPaymentCommit(PayAtAccPayReq reqCommit, PayAtAccPayResp respCommit) {
        PayAtAccPayConfReq confCommit = new PayAtAccPayConfReq ();

        confCommit.setProviderId (reqCommit.getProviderId ());
        confCommit.setProductId (reqCommit.getProductId ());
        confCommit.setConfirmType ("commit");
        confCommit.setTrxId (respCommit.getTransactionID ());
        confCommit.setAmountDue (reqCommit.getAmountDue ());
        confCommit.setAdditionalAmount (reqCommit.getAdditionalAmount ());
        confCommit.setEcho ("");
        confCommit.setTenderType (tendered);
        confCommit.setWantPrintJob (true);
        System.out.println ("tender type being committed for transaction = " + confCommit.getTenderType ());

        BillPayUtilPayAt.getPayAtBillPaymentConfirm (connection, confCommit, new BillPayUtilPayAt.PayAtBillPaymentConfirm () {
            @Override
            public void payAtBillPayConf(final PayAtAccPayConfResp confResp) {
                if (confResp.isSuccess ()) {
                    double amtTotal = amountPaid + response2.getConvenienceFee ();
                    String descript = product.getProdName () + " - " + request2.getAccountNo ();

                    SalesUtil.processBillPayment (BPTransType.BILLPAY_PAYAT_ACCOUNT.getDisplayName (), response2.getTransRef (), descript, amtTotal,
                            tendered, confResp.getConfEventDescription (), confResp.getPrintLines (), confResp.getMerchantPrintLines ());

                } else if (!confResp.getAeonErrorMessage ().isEmpty ()) {
                    JKiosk3.getMsgBox ().showMsgBox ("Bill Payment Error", "A" + confResp.getAeonErrorCode () + "  -  " + confResp.getAeonErrorMessage (), null);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Bill Payment Error", "B" + confResp.getErrorCode () + "  -  " + confResp.getErrorMessage (), null);
                }

                BillPayUtilMisc.resetBillPayView ();
            }
        });
    }

    private void submitPayAtBillPaymentRollback(PayAtAccPayReq reqRollback, PayAtAccPayResp respRollback, final String calledBy) {
        PayAtAccPayConfReq confRollback = new PayAtAccPayConfReq ();

        confRollback.setProviderId (reqRollback.getProviderId ());
        confRollback.setProductId (reqRollback.getProductId ());
        confRollback.setConfirmType ("rollback");
        confRollback.setTrxId (respRollback.getTransactionID ());
        confRollback.setAmountDue (reqRollback.getAmountDue ());
        confRollback.setAdditionalAmount (reqRollback.getAdditionalAmount ());
        confRollback.setEcho ("");
        if (tendered != null) {
            confRollback.setTenderType (tendered);
        } else {
            confRollback.setTenderType ("cash");
        }

        BillPayUtilPayAt.getPayAtBillPaymentConfirm (connection, confRollback, new BillPayUtilPayAt.PayAtBillPaymentConfirm () {
            @Override
            public void payAtBillPayConf(PayAtAccPayConfResp confResp) {
                if (confResp.isSuccess ()) {
                    switch (calledBy) {
                        case BillPayUtilMisc.CALL_BY_CANCEL:
                            JKiosk3.getMsgBox ().showMsgBox ("Bill Payment", "Transaction cancelled by User", null);
                            BillPayUtilMisc.resetBillPayView ();
                            break;
                        case BillPayUtilMisc.CALL_BY_TENDER:
                            getAccountRequestPay ();
                            break;
                        default:
                            JKiosk3.getMsgBox ().showMsgBox ("Pay@ Account Payment", "Unable to Determine Rollback Requestor", null);
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Bill Payment Rollback Error",
                            !confResp.getAeonErrorMessage ().isEmpty () ?
                                    "A" + confResp.getAeonErrorCode () + " - " + confResp.getAeonErrorMessage () :
                                    "B" + confResp.getErrorCode () + " - " + confResp.getErrorMessage (), null);
                }
            }
        });
    }

    private boolean inputValidAccount() {
        /* This is now checked before allowing the 'show detail' button to be enabled */
//        if (gridAcc.getTxtNumber().getText().trim().equals("") || gridAcc.getTxtNumber().getText().trim().isEmpty()) {
//        if (gridAcc.getAccountNumber().equals("") || gridAcc.getAccountNumber().isEmpty()) {
//            JKiosk3.getMsgBox().showMsgBox("Account Number", "Account Number cannot be empty", null);
//            return false;
//        }
//        if (product.getProdName().contains("Multichoice") && (gridAcc.getTxtNumber().getText().length() > 28)) {
        if (product.getProdName ().contains ("Multichoice") && (gridAcc.getAccountNumberConfirmed ().length () > 28)) {
            JKiosk3.getMsgBox ().showMsgBox ("Multichoice Account Number",
                    "Please enter a valid Multichoice Account number", null);
            return false;
        }
        return true;
    }

}