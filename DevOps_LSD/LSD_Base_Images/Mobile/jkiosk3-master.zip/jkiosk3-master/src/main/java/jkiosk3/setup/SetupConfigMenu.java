package jkiosk3.setup;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

import java.util.ArrayList;
import java.util.List;

public class SetupConfigMenu extends Region {

    private final static String MENU_CONFIG = "Device Config";
    private final static String MENU_LOCATE = "Device Location";
    private final static String RICA_CONFIG = "Rica Config";

    public SetupConfigMenu() {
        getChildren().add(getMenuGroup());
    }

    private HBox getMenuGroup() {

        String[] configMenu = {MENU_CONFIG, MENU_LOCATE, RICA_CONFIG};
        List<Button> btnList = new ArrayList<>();

        for (String s : configMenu) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
            // 2019-11-11  -  The Google API settings have still not been checked, this still does not work.
            // Disable until further notice.
//            if (System.getProperty("java.runtime.version").startsWith("1.7") && btn.getText().equalsIgnoreCase(MENU_LOCATE)) {
//                btn.setDisable(true);
//            }
            if (btn.getText().equalsIgnoreCase(MENU_LOCATE)) {
                btn.setDisable(true);
            }
        }

        HBox hb = JKLayout.getControlsHBox();
        hb.setAlignment(Pos.CENTER_LEFT);
        hb.getChildren().addAll(btnList);
        hb.getChildren().add(JKNode.getHSpacer());

        return hb;
    }

    private void getMenuAction(Button b) {
        if (SceneSetup.getVbSetupContent().getChildren().size() > 1) {
            SceneSetup.getVbSetupContent().getChildren().remove(1);
        }

        switch (b.getText()) {
            case MENU_CONFIG:
                SceneSetup.getVbSetupContent().getChildren().add(1, new SetupConfig());
                break;
            case MENU_LOCATE:
                String jre = System.getProperty("java.runtime.version");
                int majorVer = 0;
                // Java 9 onwards have an easier way to do this, but for now, we need to cater for '1.8' as well
                if (jre.startsWith("1.8.") || jre.startsWith("9.") || jre.startsWith("10.")) {
                    SceneSetup.getVbSetupContent().getChildren().add(1, new SetupDeviceLocation());
//                    majorVer = Integer.parseInt(jre.substring(2, 3));
//                } else if (jre.startsWith("9.") || jre.startsWith("10.")) {
//                    majorVer = Integer.parseInt(jre.substring(0, jre.indexOf('.')));
                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Java Version : " + jre, "Incompatible Java Version found", null);
                    JKiosk3.getMsgBox().showMsgBox("Java Version : " + jre, "Java 8 or over is required for this feature", null);
                }
//                if (majorVer > 7) {
//                    SceneSetup.getVbSetupContent().getChildren().add(1, new SetupDeviceLocation());
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Java Version : " + jre, "Java 8 or over is required for this feature", null);
//                }
                break;
            case RICA_CONFIG:
                SceneSetup.getVbSetupContent().getChildren().add(1, new SetupRicaConfig());
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Config Menu", "Config Option Not Selected!", null);
                break;
        }
    }
}
