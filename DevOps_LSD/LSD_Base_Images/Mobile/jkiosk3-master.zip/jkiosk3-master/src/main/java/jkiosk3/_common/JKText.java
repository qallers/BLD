package jkiosk3._common;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.store.JKBranding;

public class JKText {

    public static Color COLOUR_MAIN = Color.web("#0F224E");
    public final static Color COLOUR_RED = Color.web("#FF0000");
    public final static Color COLOUR_GREEN = Color.web("#00FF00");
    public final static Color COLOUR_MAIN_LIGHT = Color.web("#0056B3");
    //
    public final static String fontConsolas = "file:media/fonts/consola.ttf";
    public final static String fontLucidaUni = "file:media/fonts/luc_uni.ttf";
    public final static String fontTahoma = "file:media/fonts/tahoma.ttf";
    public final static String fontTahomaBold = "file:media/fonts/tahomabd.ttf";
    //
    // 2019-10-31  -  slowly changing to use sizes instead of 'X' formats
    public final static Font FONT_B_10 = Font.loadFont(fontTahomaBold, 10);
    public final static Font FONT_B_12 = Font.loadFont(fontTahomaBold, 12);
//    public final static Font FONT_B_XXXSM = Font.loadFont(fontTahomaBold, 12);
//    public final static Font FONT_B_13 = Font.loadFont(fontTahomaBold, 13);
    public final static Font FONT_B_14 = Font.loadFont(fontTahomaBold, 14);
    public final static Font FONT_B_15 = Font.loadFont(fontTahomaBold, 15);
    public final static Font FONT_B_XXSM = Font.loadFont(fontTahomaBold, 16);
    public final static Font FONT_B_18 = Font.loadFont(fontTahomaBold, 18);
    public final static Font FONT_B_20 = Font.loadFont(fontTahomaBold, 20);
    public final static Font FONT_B_22 = Font.loadFont(fontTahomaBold, 22);
    public final static Font FONT_B_XSM = Font.loadFont(fontTahomaBold, 20);
    public final static Font FONT_B_SM = Font.loadFont(fontTahomaBold, 24);
    public final static Font FONT_B_24 = Font.loadFont(fontTahomaBold, 24);
    public final static Font FONT_B_26 = Font.loadFont(fontTahomaBold, 26);
    public final static Font FONT_B_MID = Font.loadFont(fontTahomaBold, 28);
//    public final static Font FONT_B_LG = Font.loadFont(fontTahomaBold, 30);
    public final static Font FONT_B_XLG = Font.loadFont(fontTahomaBold, 42);
    public final static Font FONT_B_XXLG = Font.loadFont(fontTahomaBold, 54);
    //
    public final static Font FONT_N_XXSM = Font.loadFont(fontTahoma, 16);
    public final static Font FONT_N_22 = Font.loadFont(fontTahoma, 22);
    //
    public final static Font FONT_LUCIDA_UNI_MID = Font.loadFont(fontLucidaUni, 16);
    public final static Font FONT_LUCIDA_UNI_LG = Font.loadFont(fontLucidaUni, 28);
    public final static Font FONT_CONSOLAS_MID = Font.loadFont(fontConsolas, 16);

    public static void setColourMain(String hexColour) {
        COLOUR_MAIN = Color.web(hexColour);
    }

    /**
     * Defines the properties for a Label to be used for a page content header.
     *
     * @param lbl the text to be displayed on the Label.
     * @return a Label with the correct attributes and layout for use as a page content header.
     */
    public static Label getLblContentHead(String lbl) {
        Label label = new Label(lbl);
        label.setFont(FONT_B_SM);
        label.setMaxWidth(JKLayout.contentW - (2 * JKLayout.sp));
        label.setMinWidth(JKLayout.contentW - (2 * JKLayout.sp));
        label.setTextFill(COLOUR_MAIN);
        return label;
    }

    /**
     * Defines the properties for a Label to be used for a page content header.
     *
     * The label defined is center aligned
     *
     * @param lbl the text to be displayed on the Label.
     * @return a Label with the correct attributes and layout for use as a page content header.
     */
    public static Label getLblCenterAlignContentHead(String lbl) {
        Label label = new Label(lbl);
        label.setAlignment(Pos.CENTER);
        label.setFont(FONT_B_SM);
        label.setMaxWidth(JKLayout.contentW - (2 * JKLayout.sp));
        label.setMinWidth(JKLayout.contentW - (2 * JKLayout.sp));
        label.setTextFill(COLOUR_MAIN);
        return label;
    }

    /**
     * Defines the properties for a Label to be used for a page content sub-header.
     *
     * @param lbl the text to be displayed on the Label.
     * @return a Label with the correct attributes and layout for use as a page content sub-header.
     */
    public static Label getLblContentSubHead(String lbl) {
        Label label = new Label(lbl);
        label.setFont(FONT_B_20);
        label.setMaxWidth(JKLayout.contentW - (2 * JKLayout.sp));
        label.setMinWidth(JKLayout.contentW - (2 * JKLayout.sp));
        label.setTextFill(COLOUR_MAIN);
        return label;
    }

    /**
     * Defines the properties for a Label to be used in a page content, e.g. as a Label for an input field.
     *
     * @param lbl the text to be displayed on the Label.
     * @param font the font (including size) to be used.
     * @return a Label with the correct attributes for use as a Label for a page input field or information Label.
     */
    public static Label getLblDk(String lbl, Font font) {
        Label label = new Label(lbl);
        label.setFont(font);
        label.setTextFill(COLOUR_MAIN);
        return label;
    }

    /**
     * Defines the properties for a Text component to be used in a page content, e.g. for display of a retrieved or
     * previously set value.
     *
     * @param txt the value of the text to be displayed.
     * @param font the font (including size) to be used.
     * @return a Text component with the correct attributes for use as a page value field.
     */
    public static Text getTxtMainLight(String txt, Font font) {
        Text text = new Text(txt);
        text.setFont(font);
        text.setFill(COLOUR_MAIN_LIGHT);
        return text;
    }

    /**
     * Defines the properties for a Text component to be used in a page content, e.g. for display of a retrieved or
     * previously set value.
     *
     * @param txt the value of the text to be displayed.
     * @param font the font (including size) to be used.
     * @return a Text component with the correct attributes for use as a page value field.
     */
    public static Text getTxtDk(String txt, Font font) {
        Text text = new Text(txt);
        text.setFont(font);
        text.setFill(COLOUR_MAIN);
        return text;
    }

    /**
     * Defines the properties for a Text component to be used in a page content, e.g. for display of a retrieved or
     * previously set value.
     *
     * @param txt the value of the text to be displayed.
     * @param font the font (including size) to be used.
     * @return a Text component with the correct attributes for use as a page value field.
     */
    public static Text getTxtWh(String txt, Font font) {
        Text text = new Text(txt);
        text.setFont(font);
        text.setFill(Color.web("#FFFFFF"));
        return text;
    }

    /**
     * Defines the properties for a Text component that needs to be wrapped and aligned, to be used in a page content,
     * e.g. for display of a retrieved or previously set value.
     *
     * @param txt the value of the text to be displayed.
     * @param font the font (including size) to be used.
     * @param width the width at which the text should wrap.
     * @param align the alignment of the text within the space allocated to it.
     * @return a Text component with the correct attributes for use as a page value field.
     */
    public static Text getTxtDkWrap(String txt, Font font, double width, TextAlignment align) {
        Text text = getTxtDk(txt, font);
        text.setWrappingWidth(width);
        text.setTextAlignment(align);
        return text;
    }

    /**
     * Defines the properties for a Text component that needs to be wrapped and aligned, to be used in a page content,
     * e.g. for display of a retrieved or previously set value.
     *
     * @param txt the value of the text to be displayed.
     * @param font the font (including size) to be used.
     * @param width the width at which the text should wrap.
     * @param align the alignment of the text within the space allocated to it.
     * @return a Text component with the correct attributes for use as a page value field.
     */
    public static Text getTxtWhWrap(String txt, Font font, double width, TextAlignment align) {
        Text text = getTxtWh(txt, font);
        text.setWrappingWidth(width);
        text.setTextAlignment(align);
        return text;
    }

    /**
     * Defines a String in a format suitable for display on screen, or on a print.
     *
     * @param amount the amount to be formatted.
     * @return String suitable for display of Rand values, with grouping separator and two decimal places.
     */
    public static String getDeciFormat(double amount) {
        DecimalFormatSymbols dfSym = new DecimalFormatSymbols();
        dfSym.setGroupingSeparator(' ');
        DecimalFormat df = new DecimalFormat("#,##0.00", dfSym);
        return df.format(amount);
    }

    public static String getDeciFormat(String input) {
        String formatted = "";
        try {
            double amt = Double.parseDouble(input);
            formatted = getDeciFormat(amt);
        } catch (NumberFormatException nfe) {
            System.out.println("something wrong, not valid");
        }

        return formatted;
    }

    /**
     * Defines a String in a format suitable for display on screen, or on a print.
     *
     * @param amount the amount to be formatted.
     * @return String suitable for display of Rand or other values, with grouping separator and no decimal places.
     */
    public static String getDeciFormatNoDecimals(double amount) {
        DecimalFormatSymbols dfSym = new DecimalFormatSymbols();
        dfSym.setGroupingSeparator(' ');
        DecimalFormat df = new DecimalFormat("#,##0", dfSym);
        return df.format(amount);
    }

    /**
     * Defines a SimpleDateFormat with date only for display or printing and applies it to the Date input parameter.
     *
     * @param date the Date to be formatted.
     * @return String in format 'dd/MM/yyyy' suitable for display on a print.
     *
     */
    public static String getDateDisplay(Date date) {
        return new SimpleDateFormat("dd/MM/yyyy").format(date);
    }

    /**
     * Defines a SimpleDateFormat with minutes for display or printing and applies it to the Date input parameter.
     *
     * @param date the Date to be formatted.
     * @return String in format 'dd/MM/yyyy kk:mm' suitable for display on a print.
     *
     */
    public static String getDateDisplayMin(Date date) {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm").format(date);
    }

    /**
     * Defines a SimpleDateFormat with seconds for display or printing and applies it to the Date input parameter.
     *
     * @param date the Date to be formatted.
     * @return String in format 'dd/MM/yyyy kk:mm:ss' suitable for display on a print.
     *
     */
    public static String getDateDisplaySec(Date date) {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(date);
    }

    /**
     * Returns a formatted mobile number in an easily readable format.
     *
     * @param mobileNum the mobile number to be formatted.
     * @return a String in a format suitable for display or for printing.
     *
     */
    public static String getCellNumFormatted(String mobileNum) {
        if (mobileNum != null) {
            return mobileNum.substring(0, 3) + " " + mobileNum.substring(3, 6) + " " + mobileNum.substring(6, 10);
        } else {
            return "No mobile number provided";
        }
    }

    public static String getSAIDNumFormatted(String idNum) {
        if (idNum != null) {
            return idNum.substring(0, 6) + " " + idNum.substring(6, 10) + " " + idNum.substring(10, 13);
        } else {
            return ("No ID Number provided");
        }
    }

    public static String getBrandText() {
        String brandColour = JKBranding.getBranding().getMerchantGroup().getPrimaryColourHex();
        return "-fx-fill: " + brandColour + ";";
    }
}
