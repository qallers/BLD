package jkiosk3.store;

/**
 *
 * @author valeriew
 */
public class JKSetPrintedQueue {

    private static StoreJKSetPrintedQueue setPrintedQueue;

    private static void loadSetPrintedQueue() {
        if ((setPrintedQueue == null) || (setPrintedQueue.getListTransRefs().isEmpty())) {
            setPrintedQueue = (StoreJKSetPrintedQueue) Store.loadObject(JKSetPrintedQueue.class.getSimpleName());
        }
        if (setPrintedQueue == null) {
            setPrintedQueue = new StoreJKSetPrintedQueue();
        }
    }

    public static boolean hasItems() {
        loadSetPrintedQueue();
        return setPrintedQueue.getListTransRefs().size() > 0;
    }

    public static void saveSetPrintedItem(String transRef) {
        loadSetPrintedQueue();
        setPrintedQueue.getListTransRefs().add(transRef);
        Store.saveObject(JKSetPrintedQueue.class.getSimpleName(), setPrintedQueue);
    }

    public static void removeSetPrintedItem(String transRef) {
        loadSetPrintedQueue();
//        System.out.println("size of queue before remove : " + setPrintedQueue.getListTransRefs().size());
//        System.out.println("transRef = " + transRef);
        for (String i : setPrintedQueue.getListTransRefs()) {
//            System.out.println("       i = " + i);
            if (i.equalsIgnoreCase(transRef)) {
                int index = setPrintedQueue.getListTransRefs().indexOf(i);
//                System.out.println("   index = " + index);
                setPrintedQueue.getListTransRefs().remove(index);
                break;
            }
        }
        Store.saveObject(JKSetPrintedQueue.class.getSimpleName(), setPrintedQueue);
//        System.out.println("size of queue after remove  : " + setPrintedQueue.getListTransRefs().size());
        checkForEmptyList();
    }

    private static void checkForEmptyList() {
        loadSetPrintedQueue();
        if (setPrintedQueue.getListTransRefs().isEmpty()) {
            clearSetPrintedQueue();
        } else {
            Store.saveObject(JKSetPrintedQueue.class.getSimpleName(), setPrintedQueue);
        }
    }

    public static void clearSetPrintedQueue() {
        if (setPrintedQueue != null) {
            setPrintedQueue.getListTransRefs().clear();
        }
        Store.deleteObject(JKSetPrintedQueue.class.getSimpleName());
    }

    public static StoreJKSetPrintedQueue getSetPrintedQueue() {
        loadSetPrintedQueue();
        return setPrintedQueue;
    }
}
