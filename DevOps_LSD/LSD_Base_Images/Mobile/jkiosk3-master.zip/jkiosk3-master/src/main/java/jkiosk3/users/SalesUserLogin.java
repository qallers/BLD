package jkiosk3.users;

import aeonusers.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Separator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.store.JKOptions;

public class SalesUserLogin extends Region {

    private final static Logger logger = Logger.getLogger(SalesUserLogin.class.getName());

    private PasswordField pwdFld;
    private SalesUserLoginResult result;
    private boolean isSupervisorLoginRequired;
//    private boolean isCashierPlusOrSupervisorRequired;
    private boolean saleInProgress;

    public SalesUserLogin() {
        getChildren().add(getLoginStack());
    }

    private StackPane getLoginStack() {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getLoginGrp());

        return stack;
    }

    private Group getLoginGrp() {

        double w = 250;
        double h = 450;

        Rectangle rec = new Rectangle(w, h);

        VBox vbox = JKLayout.getVBox(JKLayout.sp, (2 * JKLayout.spNum));

        Label lbl = JKText.getLblDk("User PIN", JKText.FONT_B_XSM);

        pwdFld = new PasswordField();
        pwdFld.setMaxWidth(w - (4 * JKLayout.sp));
        pwdFld.setMinWidth(w - (4 * JKLayout.sp));
        pwdFld.setPromptText("enter password");
        pwdFld.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent e) {
                if (e.getCode() == KeyCode.ENTER) {
                    getEnterBtnEvent();
                }
            }
        });

        Image imgX = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/cross.png"));
        Image imgTick = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/tick.png"));
        ImageView imgCancel = new ImageView(imgX);
        ImageView imgEnter = new ImageView(imgTick);

        Button btnCancel = JKNode.getBtnNum("");
        btnCancel.setGraphic(imgCancel);
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setVisible(false);
                toBack();
            }
        });

        Button btnEnter = JKNode.getBtnNum("Enter");
        btnEnter.setFont(JKText.FONT_B_XSM);
        btnEnter.setGraphic(imgEnter);
        btnEnter.setMaxSize(((2 * JKLayout.btnNumW) + JKLayout.spNum), JKLayout.btnNumH);
        btnEnter.setMinSize(((2 * JKLayout.btnNumW) + JKLayout.spNum), JKLayout.btnNumH);
        btnEnter.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                getEnterBtnEvent();
            }
        });

        HBox hb = JKLayout.getHBox(0, JKLayout.spNum);
        hb.getChildren().addAll(btnCancel, btnEnter);

        TilePane tile = JKLayout.getTile(15, 5, 5, 3);
        tile.setPrefWidth(w - (2 * JKLayout.sp));
        tile.getChildren().addAll(getNumBtnList());

        Separator sep = new Separator();
        sep.setMaxWidth(w - (4 * JKLayout.sp));

        vbox.getChildren().addAll(lbl, pwdFld, hb, sep, tile);

        Group grp = new Group();
        grp.getChildren().addAll(rec, vbox);

        return grp;
    }

    private List<Button> getNumBtnList() {
        List<Button> btnList = new ArrayList<>();

        String[] nums = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "."};

        for (String s : nums) {
            Button btn = JKNode.getBtnNum(s);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    pwdFld.appendText(((Button) e.getSource()).getText());
                }
            });
            btnList.add(btn);
        }

        Button btnBackSp = JKNode.getBtnNum("←");
        btnBackSp.setFont(JKText.FONT_LUCIDA_UNI_LG);
        btnBackSp.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                int end = pwdFld.getText().length() - 1;
                if (end >= 0) {
                    pwdFld.setText(pwdFld.getText(0, end));
                }
            }
        });
        btnList.add(11, btnBackSp);

        return btnList;
    }

    private void getEnterBtnEvent() {

        UserUtil.getLoggedInUser(pwdFld.getText(), new UserUtil.LoggedInUserResult() {

            @Override
            public void loggedInUserResult(User loggedInUser) {
                if (loggedInUser.isSuccess()) {

                    if (isSupervisorLoginRequired) {
                        int userLevel = loggedInUser.getUserLevel();
                        if (userLevel == 0 || userLevel == 2) {
                            showLoginFailedMessage("Access Denied", "Menu Item not available for this Access Level");
                        } else if (userLevel == 1) {
                            logger.info(("\t\t>>>>> \tSupervisor User logged in : \t").concat(loggedInUser.getUserName()));
                            if (JKOptions.getOptions().isSalesPersonLogin() && CurrentUser.getSalesUser() == null) {
                                CurrentUser.setSalesUser(loggedInUser);
                                SceneSales.getLblSalesPerson().setText(loggedInUser.getUserName());
                            }
                            hideSalesUserLoginAndProcessResult();
                        }
                    } else {
                        logger.info(("\t\t>>>>> \tUser logged in :    \t").concat(loggedInUser.getUserName()));
                        if (JKOptions.getOptions().isSalesPersonLogin()) {
                            CurrentUser.setSalesUser(loggedInUser);
                            SceneSales.getLblSalesPerson().setText(loggedInUser.getUserName());
                        }
                        hideSalesUserLoginAndProcessResult();
                    }
                } else {
                    logger.info(("\t\t>>>>> \tUser login failed : \tpin : ").concat(pwdFld.getText()).concat("\t: ")
                            .concat(Integer.toString(loggedInUser.getErrorCode())).concat("\t").concat(loggedInUser.getErrorText()));
                    showLoginFailedMessage("Login Failed", loggedInUser.getErrorCode() + " - " + loggedInUser.getErrorText());
                }
            }
        });
    }

    public void showUserLogin(SalesUserLoginResult res) {
        showUserLogin(false, res);
    }

//    public void showUserLogin(PasswordField inputFld, SalesUserLoginResult res) {
//        showUserLogin(false, res);
//    }

    private void showUserLogin(boolean isSupervisorRequired, SalesUserLoginResult res) {
        this.isSupervisorLoginRequired = isSupervisorRequired;
        this.result = res;

        if (isSupervisorLoginRequired) {
            requestUserPassword();
        } else if (!isSupervisorLoginRequired) {
            if (JKOptions.getOptions().isSalesPersonLogin()) {
                if (CurrentUser.getSalesUser() == null) {
                    requestUserPassword();
                } else {
                    // This would already be set, if 'getSalesUser' was != null
                    CurrentUser.setSalesUser(CurrentUser.getUser());
                    SceneSales.getLblSalesPerson().setText(CurrentUser.getSalesUser().getUserName());
                    hideSalesUserLoginAndProcessResult();
                }
            } else {
                CurrentUser.setSalesUser(CurrentUser.getUser());
                SceneSales.getLblSalesPerson().setText(CurrentUser.getSalesUser().getUserName());
                hideSalesUserLoginAndProcessResult();
            }
        }
    }

    /*  Maybe look into this in future.  Not useful now. */
//    public void showUserLogin(Integer[] levelsAllowed, SalesUserLoginResult res) {
//        this.result = res;
//        List<Integer> listLevels = Arrays.asList(levelsAllowed);
//        if (listLevels.contains(UserUtil.LEVEL_SUPERVISOR)
//                && !listLevels.contains(UserUtil.LEVEL_CASHIER_PLUS) &&
//                !listLevels.contains(UserUtil.LEVEL_CASHIER)) {
//            isSupervisorLoginRequired = true;
//            showUserLogin(true, res);
//        }
//    }

    private void showLoginFailedMessage(String head, String msg) {
        JKiosk3.getMsgBox().showMsgBox(head, msg, null,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult() {
                    @Override
                    public void onOk() {
                        requestUserPassword();
                    }

                    @Override
                    public void onCancel() {
                        UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
                        result = null;
                        setVisible(false);
                        toBack();
                    }
                });
    }

    private void requestUserPassword() {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                pwdFld.clear();
                pwdFld.requestFocus();
            }
        });
        this.setVisible(true);
        this.toFront();
    }

    private void hideSalesUserLoginAndProcessResult() {
        this.setVisible(false);
        this.toBack();
        if (result != null) {
            result.onDone();
        }
    }
}
