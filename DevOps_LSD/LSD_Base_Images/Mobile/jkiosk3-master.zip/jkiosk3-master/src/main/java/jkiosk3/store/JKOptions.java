package jkiosk3.store;

/**
 *
 * @author Valerie
 */
public class JKOptions {

    private static StoreJKOptions options;

    public static StoreJKOptions getOptions() {
        if (options == null) {
            options = ((StoreJKOptions) Store.loadObject(JKOptions.class.getSimpleName()));
        }
        if (options == null) {
            options = new StoreJKOptions();
        }
        return options;
    }

    public static boolean saveSystemSetup() {
        getOptions();
        return Store.saveObject(JKOptions.class.getSimpleName(), options);
    }
}
