package jkiosk3.store;

import java.io.Serializable;

/**
 *
 * @author Valerie
 */
public class StoreJKPrintOptions implements Serializable {

//    private final static long serialVersionUID = 100011L;
    // Print Options
    private boolean printPreview = false;
    private boolean printImmediately = false;
    private boolean printReceipts = false;
    private boolean printMerchantCopy = false;
    private boolean printBarcode = false;
    private boolean hideReprintPin = false;
    private String storeName = "";
    private String storeAddress = "";
    private String storeVatReg = "";

    public boolean isHideReprintPin() {
        return hideReprintPin;
    }

    public void setHideReprintPin(boolean hideReprintPin) {
        this.hideReprintPin = hideReprintPin;
    }

    public boolean isPrintPreview() {
        //ignore exisiting config, and always disable print preview
        return false;
    }

    public void setPrintPreview(boolean printPreview) {
        this.printPreview = printPreview;
    }

    public boolean isPrintImmediately() {
        return printImmediately;
    }

    public void setPrintImmediately(boolean printImmediately) {
        this.printImmediately = printImmediately;
    }

    public boolean isPrintReceipts() {
        return printReceipts;
    }

    public void setPrintReceipts(boolean printReceipts) {
        this.printReceipts = printReceipts;
    }

    public boolean isPrintMerchantCopy() {
        return printMerchantCopy;
    }

    public void setPrintMerchantCopy(boolean printMerchantCopy) {
        this.printMerchantCopy = printMerchantCopy;
    }

    public boolean isPrintBarcode() {
        return printBarcode;
    }

    public void setPrintBarcode(boolean printBarcode) {
        this.printBarcode = printBarcode;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getStoreAddress() {
        return storeAddress;
    }

    public void setStoreAddress(String storeAddress) {
        this.storeAddress = storeAddress;
    }

    public String getStoreVatReg() {
        return storeVatReg;
    }

    public void setStoreVatReg(String storeVatReg) {
        this.storeVatReg = storeVatReg;
    }
}
