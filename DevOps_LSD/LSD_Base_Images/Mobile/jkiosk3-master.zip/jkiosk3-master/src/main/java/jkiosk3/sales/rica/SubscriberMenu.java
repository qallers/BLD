package jkiosk3.sales.rica;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.SceneSales;

/**
 *
 * @author Val
 */
public class SubscriberMenu extends Region {

    public SubscriberMenu() {
        getChildren().add(getMenuGroup());
    }

    private TilePane getMenuGroup() {

        String[] btnLabels = {RICAUtil.NEW_REG, RICAUtil.CHANGE_CELL_NUM, RICAUtil.CHANGE_SIM_SP};

        List<Button> btnList = new ArrayList<>();

        for (final String s : btnLabels) {
            final Button btn = JKNode.getBtnSmDbl(s);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        TilePane tile = JKLayout.getTileContent(JKLayout.sp, JKLayout.sp, 2);
        tile.getChildren().addAll(btnList);

        return tile;
    }

    private void getMenuAction(Button b) {
        switch (b.getText()) {
            case RICAUtil.NEW_REG:
                RICAUtil.setRegistrationType(RICAUtil.NEW_REG);
                RICAUtil.setChOwnCell(false);
                RICAUtil.setChOwnSimSp(false);
                SceneSales.clearAndChangeContent(new SubNewRegistration());
                break;
            case RICAUtil.CHANGE_CELL_NUM:
                RICAUtil.setRegistrationType(RICAUtil.CHANGE_CELL_NUM);
                RICAUtil.setChOwnCell(true);
                RICAUtil.setChOwnSimSp(false);
                SceneSales.clearAndChangeContent(new SubChOwnCell());
                break;
            case RICAUtil.CHANGE_SIM_SP:
                RICAUtil.setRegistrationType(RICAUtil.CHANGE_SIM_SP);
                RICAUtil.setChOwnCell(false);
                RICAUtil.setChOwnSimSp(true);
                SceneSales.clearAndChangeContent(new SubChOwnSimSp());
        }
    }
}
