package jkiosk3.sales.search;

import aeonairtime.AirtimeManufacturer;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.vouchers.VoucherUtil;

import java.util.ArrayList;
import java.util.List;

public class CreateElectricityVoucherProduct {

    public static List<SearchProduct> createElectricityVoucherProducts() {
        // populate vouchers
        VoucherUtil.getVoucherProvidersList();

        final String VOUCHER_ELECTRICITY = "Electricity Voucher";

        List<SearchProduct> products = new ArrayList<>();
        for (AirtimeManufacturer electricityVoucher : VoucherUtil.getProvidersShow(SaleType.VOUCHER_ELEC)) {
            SearchProduct networkProvider = new SearchProduct();

            networkProvider.setProvName(electricityVoucher.getId());
            String electricityName = electricityVoucher.getName();

            networkProvider.setProdName(String.format("%s %s", electricityName, VOUCHER_ELECTRICITY));
            networkProvider.setSearchTransType(SearchTransType.ELECTRICITY_VOUCHER);

            products.add(networkProvider);

        }
        return products;
    }

}
