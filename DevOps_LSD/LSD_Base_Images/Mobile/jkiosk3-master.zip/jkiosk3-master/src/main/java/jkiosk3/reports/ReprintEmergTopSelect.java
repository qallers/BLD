package jkiosk3.reports;

import aeonemergencytopup.AccountsList;
import aeonemergencytopup.Account;
import aeonemergencytopup.EmergTopHistoryReq;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.accounts.emerg_topup.EmergencyTopupUtil;
import jkiosk3.sales.SalesUtil;
import jkiosk3.store.JKOptions;

/**
 *
 * @author Valerie
 */
public class ReprintEmergTopSelect extends Region {

    private ObservableList listAccObserv;
    private Account selectedAccount;
    private int numDays;
    private TextField txtDays;

    public ReprintEmergTopSelect() {
        EmergencyTopupUtil.getListAccounts(new EmergencyTopupUtil.AccountsListResult() {

            @Override
            public void accountListResult(AccountsList listAccounts) {
                if (listAccounts.isSuccess()) {
                    listAccObserv = FXCollections.observableArrayList();
                    for (aeonemergencytopup.Account acc : listAccounts.getListAccounts()) {
                        listAccObserv.add(acc);
                    }

                    VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

                    vb.getChildren().add(getEmergTopReprintSelect());
                    vb.getChildren().add(getPrintControl());

                    getChildren().addAll(vb);
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Reprint Emergency Topup",
                            "Error retrieving list of Accounts\n\n" + listAccounts.getErrorCode() + " - " + listAccounts.getErrorText(),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    SceneReports.getVbReportContent().getChildren().clear();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private GridPane getEmergTopReprintSelect() {
        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);

        VBox vbHead = JKNode.getReportHeadVB("Reprint Emergency Topup");

        Label lblAccNo = JKText.getLblDk("Account", JKText.FONT_B_XSM);

        Label lblDays = JKText.getLblDk("No of Days", JKText.FONT_B_XSM);

        final ComboBox comAcc = new ComboBox();
        comAcc.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.75), 35);

        comAcc.setItems(listAccObserv);
        comAcc.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue ov, Object oldValue, Object newValue) {
                if (newValue != null) {
                    selectedAccount = (Account) newValue;
                }
            }
        });

        txtDays = new TextField();
        txtDays.setPromptText("days");
        txtDays.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event arg0) {
                if (!JKOptions.getOptions().isKeyboard()) {
                    JKiosk3.getNumPad().showNumPad(txtDays, "Enter Days", "");
                }
            }
        });

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblAccNo, comAcc);
        grid.addRow(2, lblDays, txtDays);

        return grid;
    }

    private Group getPrintControl() {

        Button btnView = JKNode.getBtnSm("View");
        btnView.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (validateInput()) {
                    getReprintListView();
                }
            }
        });

        HBox hb = JKLayout.getControlsHBox();
        hb.getChildren().addAll(JKNode.getHSpacer(), btnView);

        Group grp = JKNode.getContentGroup(hb);

        return grp;
    }

    private void getReprintListView() {
        EmergTopHistoryReq req = new EmergTopHistoryReq();
        req.setReference(SalesUtil.getUniqueRef());
        req.setAccount(selectedAccount);
        req.setDays(numDays);

        SceneReports.clearAndChangeContent(new ReprintEmergTopList(req));
    }

    private boolean validateInput() {
        if (selectedAccount == null) {
            JKiosk3.getMsgBox().showMsgBox("Account", "Please select an Account from the list", null);
            return false;
        }
        if (txtDays.getText() == null || txtDays.getText().trim().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Number of Days", "Please enter a number of days to view", null);
            return false;
        } else {
            try {
                numDays = Integer.parseInt(txtDays.getText().trim());
            } catch (NumberFormatException nfe) {
                JKiosk3.getMsgBox().showMsgBox("Number of Days", "Please enter a valid number of days", null);
                return false;
            }
        }
        return true;
    }
}
