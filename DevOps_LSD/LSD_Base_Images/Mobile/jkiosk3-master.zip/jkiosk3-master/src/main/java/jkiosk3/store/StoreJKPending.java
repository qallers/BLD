package jkiosk3.store;

import aeonprinting.AeonPrintJob;
import aeonusers.User;
import java.io.Serializable;

public class StoreJKPending implements Serializable {

    private String description;
    private double amount;
    private String transReference;
    private boolean canCancel;
    private String onlineOffline;
    private AeonPrintJob aeonPrintJob;
    private User user;
    private long dateTime;
    private String serialNo;
    private String saleType;
    private String tenderType;

    public StoreJKPending(String descript, double amt, String trxRef, boolean cancel, String onOff,
            AeonPrintJob apj, User usrName, String serial, String saleType) {
        this.description = descript;
        this.amount = amt;
        this.transReference = trxRef;
        this.canCancel = cancel;
        this.onlineOffline = onOff;
        this.aeonPrintJob = apj;
        this.user = usrName;
        this.serialNo = serial;
        this.saleType = saleType;
    }

    public AeonPrintJob getAeonPrintJob() {
        return aeonPrintJob;
    }

    public void setAeonPrintJob(AeonPrintJob aeonPrintJob) {
        this.aeonPrintJob = aeonPrintJob;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public boolean isCanCancel() {
        return canCancel;
    }

    public void setCanCancel(boolean canCancel) {
        this.canCancel = canCancel;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOnlineOffline() {
        return onlineOffline;
    }

    public void setOnlineOffline(String onlineOffline) {
        this.onlineOffline = onlineOffline;
    }

    public String getTransReference() {
        return transReference;
    }

    public void setTransReference(String transReference) {
        this.transReference = transReference;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public long getDateTime() {
        return dateTime;
    }

    public void setDateTime(long dateTime) {
        this.dateTime = dateTime;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getSaleType() {
        return saleType;
    }

    public void setSaleType(String saleType) {
        this.saleType = saleType;
    }

    public String getTenderType() {
        return tenderType;
    }

    public void setTenderType(String tenderType) {
        this.tenderType = tenderType;
    }
}
