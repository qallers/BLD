package jkiosk3.admin.favourites.fav_cache;

import aeonfavourites.FavouriteItem;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FavouriteDefaultStore implements Serializable {

    private final static long serialVersionUID = 10122L;

    private List<FavouriteItem> listFavouriteItem = new ArrayList<>();

    public List<FavouriteItem> getListFavouriteItem() {
        return listFavouriteItem;
    }

    public void setListFavouriteItem(List<FavouriteItem> listFavouriteItem) {
        this.listFavouriteItem = listFavouriteItem;
    }

}
