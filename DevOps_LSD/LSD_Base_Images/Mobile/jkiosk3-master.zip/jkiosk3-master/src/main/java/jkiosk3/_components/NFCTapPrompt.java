package jkiosk3._components;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import za.co.blt.ACRReader;

import javax.smartcardio.CardException;

public class NFCTapPrompt extends Region {

    private final static double msgWidth = 620;
    private String infoDefault;
    private Label lblInfo;
    private String head;
    private String info;
    private String btnText;
    private TextField txtFld;
    private TextField txtCardNum;
    private Stage stagePopup;

    public NFCTapPrompt(String head, String info, String btnText, TextField txtCardNum, Stage stagePopup) {
        this.head = head;
        this.info = info;
        this.btnText = btnText;
        this.txtCardNum = txtCardNum;
        this.stagePopup = stagePopup;

        infoDefault = "Please click the '" + btnText + "' button";

        getChildren().add(getInputBoxStack());
    }

    private StackPane getInputBoxStack() {
        Label lblHead = JKText.getLblDk(head, JKText.FONT_B_XSM);
        lblHead.setMaxWidth(msgWidth - (2 * JKLayout.sp));
        lblHead.setAlignment(Pos.CENTER);
        lblHead.setTextAlignment(TextAlignment.CENTER);
        lblHead.setWrapText(true);

        lblInfo = JKText.getLblDk(infoDefault, JKText.FONT_B_XXSM);
        lblInfo.setMaxWidth(msgWidth - (2 * JKLayout.sp));
        lblInfo.setAlignment(Pos.CENTER);
        lblInfo.setTextAlignment(TextAlignment.CENTER);
        lblInfo.setWrapText(true);

        txtFld = new TextField();
        txtFld.setMaxWidth(300);
        txtFld.setMinWidth(300);

        Button btnTap = JKNode.getBtnMsgBox(btnText);
        btnTap.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                lblInfo.setText(info);
                txtFld.clear();
                onTestBtnEvent();
            }
        });

        Button btnReset = JKNode.getBtnMsgBox("Reset");
        btnReset.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onResetBtnEvent();
            }
        });

        Button btnClose = JKNode.getBtnMsgBox("Close");
        btnClose.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onCloseBtnEvent();
            }
        });

        HBox hbBtns = JKLayout.getHBox(0, (2 * JKLayout.sp));
        hbBtns.setMaxWidth(msgWidth - (2 * JKLayout.sp));
        hbBtns.setMinWidth(msgWidth - (2 * JKLayout.sp));
        hbBtns.getChildren().addAll(btnTap, btnReset, btnClose);

        VBox vboxContent = JKLayout.getVBoxContent(JKLayout.sp);
        vboxContent.setMaxSize(msgWidth, 300);
        vboxContent.setMinSize(msgWidth, 300);

        vboxContent.getChildren().addAll(lblHead, JKNode.createContentSep(), lblInfo, txtFld, JKNode.createContentSep(), hbBtns);

        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().add(vboxContent);

        return stack;
    }

    private void onTestBtnEvent() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ACRReader acr = new ACRReader();
                try {
                    if (acr.isACRReaderReady()) {
                        String cardUid = acr.getCardUid();
                        txtFld.setText(cardUid);
                        if (txtCardNum != null) {
                            txtCardNum.setText(cardUid);
                        }
                    }
                } catch (CardException ce) {
                    ce.printStackTrace();
                }
            }
        }).start();
    }

    private void onResetBtnEvent() {
        lblInfo.setText(infoDefault);
        txtFld.clear();
    }

    private void onCloseBtnEvent() {
        stagePopup.close();
    }
}
