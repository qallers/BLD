package jkiosk3.branding;

import java.io.Serializable;

/**
 *
 * @author Valerie
 */
public class MerchantGroup implements Serializable {

    private String code;
    private String name;
    private String primaryColourHex;
    private String secondaryColourHex;
    
    @Override
    public String toString() {
        return code + " - " + name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrimaryColourHex() {
        return primaryColourHex;
    }

    public void setPrimaryColourHex(String primaryColourHex) {
        this.primaryColourHex = primaryColourHex;
    }

    public String getSecondaryColourHex() {
        return secondaryColourHex;
    }

    public void setSecondaryColourHex(String secondaryColourHex) {
        this.secondaryColourHex = secondaryColourHex;
    }
}
