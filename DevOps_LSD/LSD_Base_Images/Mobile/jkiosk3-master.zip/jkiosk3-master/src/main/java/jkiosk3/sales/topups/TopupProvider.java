package jkiosk3.sales.topups;

import aeontopup.TopupBundleProductList;

import java.io.Serializable;

public class TopupProvider implements Serializable {

    public String name;
    public String displayName;
    public int id;
    public boolean rechargePlus;
    private TopupBundleProductList listBundles;

    public TopupProvider() {
    }

    public TopupProvider(String name, String displayName, int id) {
        this.name = name;
        this.displayName = displayName;
        this.id = id;
    }

    public TopupProvider(String name, String displayName, int id, boolean rechargePlus) {
        this.name = name;
        this.displayName = displayName;
        this.id = id;
        this.rechargePlus = rechargePlus;
    }

    @Override
	public String toString() {
		return "TopupProvider [name=" + name + ", displayName=" + displayName + ", id=" + id + ", rechargePlus="
				+ rechargePlus + ", listBundles=" + listBundles + "]";
	}

	public String getName() {
        return name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public boolean isRechargePlus() {
        return rechargePlus;
    }

    public TopupBundleProductList getListBundles() {
        return listBundles;
    }

    public void setListBundles(TopupBundleProductList listBundles) {
        this.listBundles = listBundles;
    }
}
