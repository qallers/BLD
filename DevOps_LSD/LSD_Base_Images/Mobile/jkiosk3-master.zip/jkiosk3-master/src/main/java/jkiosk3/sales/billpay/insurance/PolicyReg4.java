package jkiosk3.sales.billpay.insurance;

import aeonbillpayments.insurance_policy_reg.InsPolRegisterReq;
import aeonbillpayments.insurance_policy_reg.InsPolRegisterResp;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.ProviderType;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.sales.billpay.payat.InputPayAtInsurance;
import jkiosk3.users.UserUtil;

/**
 * @author Valerie
 */
public class PolicyReg4 extends Region {

    public PolicyReg4() {
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (polRegStep4 ());
        vb.getChildren ().add (getNav ());
        getChildren ().add (vb);
    }

    private Group polRegStep4() {

        Label lblHead = JKText.getLblDk ("Policy Registration", JKText.FONT_B_SM);
        Label lblStep = JKText.getLblDk ("Step 3", JKText.FONT_B_XSM);

        VBox vbHead = JKNode.getPageDblHeadVB (0, lblHead, lblStep);

        Label lblConfirm = JKText.getLblDk ("Please Confirm All Details Before Continuing!", JKText.FONT_B_XSM);

        ScrollPane scroll = new ScrollPane ();
        scroll.setPrefSize ((JKLayout.contentW - (2 * JKLayout.sp)), (525 - 65));
        scroll.getStyleClass ().add ("scroll-invisible");
        scroll.setHbarPolicy (ScrollPane.ScrollBarPolicy.NEVER);

        scroll.setContent (getSummaryGrid ());

        GridPane grid = JKLayout.getContentGrid2Col (0.5, 0.5);

        grid.add (vbHead, 0, 0, 2, 1);

        grid.add (lblConfirm, 0, 1, 2, 1);
        grid.addRow (2, JKNode.createGridSpanSep (2));
        grid.add (scroll, 0, 3, 2, 1);

        Group grp = JKNode.getContentGroup (grid);

        return grp;
    }

    private GridPane getSummaryGrid() {

        Label lblPolType = JKText.getLblDk ("Policy Type", JKText.FONT_B_XXSM);
        Label lblPolNum = JKText.getLblDk ("Policy Number", JKText.FONT_B_XXSM);
        Label lblMainID = JKText.getLblDk ("Main Life Assured ID", JKText.FONT_B_XXSM);
        Label lblMainName = JKText.getLblDk ("Main Life Assured First Names", JKText.FONT_B_XXSM);
        Label lblMainSurname = JKText.getLblDk ("Main Life Assured Surname", JKText.FONT_B_XXSM);
        Label lblMainContact1 = JKText.getLblDk ("Main Life Assured Contact 1", JKText.FONT_B_XXSM);
        Label lblMainContact2 = JKText.getLblDk ("Main Life Assured Contact 2", JKText.FONT_B_XXSM);
        Label lblBeneficName = JKText.getLblDk ("Beneficiary First Names", JKText.FONT_B_XXSM);
        Label lblBeneficSurname = JKText.getLblDk ("Beneficiary Surname", JKText.FONT_B_XXSM);
        Label lblPmntType = JKText.getLblDk ("Payment Type", JKText.FONT_B_XXSM);
//        Label lblAccHolder = JKText.getLblDk("Account Holder", JKText.FONT_B_XXSM);
//        Label lblBank = JKText.getLblDk("Bank Name", JKText.FONT_B_XXSM);
//        Label lblBranchName = JKText.getLblDk("Branch Name", JKText.FONT_B_XXSM);
//        Label lblBranchCode = JKText.getLblDk("Branch Code", JKText.FONT_B_XXSM);
//        Label lblAccType = JKText.getLblDk("Account Type", JKText.FONT_B_XXSM);
//        Label lblAccNum = JKText.getLblDk("Account Number", JKText.FONT_B_XXSM);
//        Label lblDebitDate = JKText.getLblDk("Debit Date", JKText.FONT_B_XXSM);

        Text txtPolType = JKText.getTxtDk (PolicyRegistration.getInstance ().getPolicyType (), JKText.FONT_B_SM);
        Text txtPolNum = JKText.getTxtDk (PolicyRegistration.getInstance ().getPolicyNumber (), JKText.FONT_B_XXSM);
        Text txtMainID = JKText.getTxtDk (PolicyRegistration.getInstance ().getMainLifeID (), JKText.FONT_B_XXSM);
        Text txtMainName = JKText.getTxtDk (PolicyRegistration.getInstance ().getMainLifeName (), JKText.FONT_B_XXSM);
        Text txtMainSurname = JKText.getTxtDk (PolicyRegistration.getInstance ().getMainLifeSurname (), JKText.FONT_B_XXSM);
        Text txtMainContact1 = JKText.getTxtDk (PolicyRegistration.getInstance ().getMainLifeContact1 (), JKText.FONT_B_XXSM);
        Text txtMainContact2 = JKText.getTxtDk (PolicyRegistration.getInstance ().getMainLifeContact2 (), JKText.FONT_B_XXSM);
        Text txtBeneficName = JKText.getTxtDk (PolicyRegistration.getInstance ().getBeneficiaryName (), JKText.FONT_B_XXSM);
        Text txtBeneficSurname = JKText.getTxtDk (PolicyRegistration.getInstance ().getBeneficiarySurname (), JKText.FONT_B_XXSM);
//        Text txtPmntType = JKText.getTxtDk(PolicyRegistration.getInstance().getPaymentType(), JKText.FONT_B_XXSM);
//        Text txtAccHolder = JKText.getTxtDk(PolicyRegistration.getInstance().getBankAccHolder(), JKText.FONT_B_XXSM);
//        Text txtBank = JKText.getTxtDk(PolicyRegistration.getInstance().getBankName(), JKText.FONT_B_XXSM);
//        Text txtBranchName = JKText.getTxtDk(PolicyRegistration.getInstance().getBankBranchName(), JKText.FONT_B_XXSM);
//        Text txtBranchCode = JKText.getTxtDk(PolicyRegistration.getInstance().getBankBranchCode(), JKText.FONT_B_XXSM);
//        Text txtAccType = JKText.getTxtDk(PolicyRegistration.getInstance().getBankAccType(), JKText.FONT_B_XXSM);
//        Text txtAccNum = JKText.getTxtDk(PolicyRegistration.getInstance().getBankAccNumber(), JKText.FONT_B_XXSM);
//        Text txtDebitDate = JKText.getTxtDk(PolicyRegistration.getInstance().getBankDebitDate(), JKText.FONT_B_XXSM);

        GridPane gridSummary = JKLayout.getContentGridInner2ColInScroll (0.5, 0.5, HPos.RIGHT);
//        gridSummary.addRow(0, lblPolType, txtPolType);
        gridSummary.addRow (1, lblPolNum, txtPolNum);
        gridSummary.addRow (2, lblMainID, txtMainID);
        gridSummary.addRow (3, lblMainName, txtMainName);
        gridSummary.addRow (4, lblMainSurname, txtMainSurname);
        gridSummary.addRow (5, lblMainContact1, txtMainContact1);
        gridSummary.addRow (6, lblMainContact2, txtMainContact2);
        gridSummary.add (JKNode.createGridSpanSep (2), 0, 7);
        gridSummary.addRow (8, lblBeneficName, txtBeneficName);
        gridSummary.addRow (9, lblBeneficSurname, txtBeneficSurname);
        gridSummary.add (JKNode.createGridSpanSep (2), 0, 10);
//        gridSummary.addRow(11, lblPmntType, txtPmntType);
//        if (PolicyRegistration.getInstance().getPaymentType().equals(PolicyRegUtil.POL_PMNT_DEBIT)) {
//            gridSummary.addRow(12, lblAccHolder, txtAccHolder);
//            gridSummary.addRow(13, lblBank, txtBank);
//            gridSummary.addRow(14, lblBranchName, txtBranchName);
//            gridSummary.addRow(15, lblBranchCode, txtBranchCode);
//            gridSummary.addRow(16, lblAccType, txtAccType);
//            gridSummary.addRow(17, lblAccNum, txtAccNum);
//            gridSummary.addRow(18, lblDebitDate, txtDebitDate);
//        }

        return gridSummary;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();

        nav.getBtnBack ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new PolicyReg2 ());
            }
        });

        nav.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(javafx.event.Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent (new BillPaymentMenu ());
            }
        });

        nav.getBtnNext ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                submitRegistrationRequest ();
//                SceneSales.clearAndChangeContent(new PolicyRegPayment());
            }
        });
        return nav;
    }

    private void submitRegistrationRequest() {
        InsPolRegisterReq req = new InsPolRegisterReq ();
        req.setPolicyNumber (PolicyRegistration.getInstance ().getPolicyNumber ());
        req.setFirstName (PolicyRegistration.getInstance ().getMainLifeName ());
        req.setLastName (PolicyRegistration.getInstance ().getMainLifeSurname ());
        req.setContactNumber (PolicyRegistration.getInstance ().getMainLifeContact1 ());
        req.setIdNumber (PolicyRegistration.getInstance ().getMainLifeID ());
        req.setAddress (PolicyRegistration.getInstance ().getMainLifeContact1 ());
        req.setTextField1 (PolicyRegistration.getInstance ().getBeneficiaryName ());
        req.setTextField2 (PolicyRegistration.getInstance ().getBeneficiarySurname ());
        req.setTextField3 ("");
        req.setAdditionalAmount (0.0);
        req.setPaymentRefNumber ("");
        req.setStoreId ("");
        req.setTillId ("");
        req.setProviderId ("");
        req.setProductId ("");

        PolicyRegUtil.getInsurancePolicyRegistration (req, new PolicyRegUtil.InsPolRegisterResult () {

            @Override
            public void insPolRegisterResult(final InsPolRegisterResp result) {
                if (result.isSuccess ()) {
                    SummaryPolicyReg summary = new SummaryPolicyReg (result);

                    final BillPayProduct product = new BillPayProduct ();
                    product.setProvId (result.getProviderId ());
                    product.setProdName (result.getInstitution ());
                    product.setProdId (result.getProductId ());
//                    product.setProdName(result.getInstitution() + " " + JKText.getDeciFormat(result.getAmountDue()) + " Insurance Policy");
                    product.setProdName (result.getPolicyType ());
//                    product.setProvType(ProviderType.PAYAT_INSURANCE_POLICY);
                    product.setBpTransType (BPTransType.BILLPAY_PAYAT_INSURANCE);

                    JKiosk3.getMsgBox ().showMsgBox ("Policy Registration", result.getMessageDesc (), summary,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    if (result.getPayAfterRegister ()) {
                                        SceneSales.clearAndChangeContent (new InputPayAtInsurance (product, BillPayUtilMisc.INSURE_REGISTER,
                                                false, false));
                                    } else {
                                        UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                                        SceneSales.clearAndChangeContent (new BillPaymentMenu ());
                                    }
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Policy Registration Error", !result.getAeonErrorText ().isEmpty () ?
                                    "A" + result.getAeonErrorCode () + " - " + result.getAeonErrorText () :
                                    "B" + result.getErrorCode () + " - " + result.getErrorText (),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                                    SceneSales.clearAndChangeContent (new BillPaymentMenu ());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }
}
