package jkiosk3.sales.electricity;

/**
 *
 * @author Val
 */
public class ElectricityProvider {

    private String transactionType;
    private String type;
    private String displayName;

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

	@Override
	public String toString() {
		return "ElectricityProvider [transactionType=" + transactionType + ", type=" + type + ", displayName="
				+ displayName + "]";
	}
    
    
}
