package jkiosk3.store;

import java.io.Serializable;

/**
 *
 * @author Val
 */
public class StoreJKDialup implements Serializable {

    private boolean autoConn = false;
    private boolean autoDisconn = false;
    private String autoConnName = "Internet";

    public boolean isAutoConn() {
        return autoConn;
    }

    public void setAutoConn(boolean autoConn) {
        this.autoConn = autoConn;
    }

    public String getAutoConnName() {
        return autoConnName;
    }

    public void setAutoConnName(String autoConnName) {
        this.autoConnName = autoConnName;
    }

    public boolean isAutoDisconn() {
        return autoDisconn;
    }

    public void setAutoDisconn(boolean autoDisconn) {
        this.autoDisconn = autoDisconn;
    }
}
