package jkiosk3.printing.cashdrawer;

import java.io.Serializable;

/**
 *
 *
 */
public class CashDrawerWindows implements Serializable {

    private static final long serialVersionUID = 10001L;
    private String printerModel;
    private String cashDrawerCodes;
    private byte[] cashDrawerBytes;

    @Override
    public String toString() {
        return printerModel;
    }

    public String getPrinterModel() {
        return printerModel;
    }

    public void setPrinterModel(String printerModel) {
        this.printerModel = printerModel;
    }

    public String getCashDrawerCodes() {
        return cashDrawerCodes;
    }

    public void setCashDrawerCodes(String cashDrawerCodes) {
        this.cashDrawerCodes = cashDrawerCodes;
    }

    public byte[] getCashDrawerBytes() {
        String[] strCodes = cashDrawerCodes.split(",");
        cashDrawerBytes = new byte[strCodes.length];
        for (int i = 0; i < strCodes.length; i++) {
            cashDrawerBytes[i] = Byte.parseByte(strCodes[i]);
        }
        return cashDrawerBytes;
    }
}
