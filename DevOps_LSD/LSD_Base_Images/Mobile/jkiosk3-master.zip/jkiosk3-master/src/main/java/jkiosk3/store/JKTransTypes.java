package jkiosk3.store;

import aeonusers.UserTransactionType;
import java.util.List;

/**
 *
 * @author Val
 */
public class JKTransTypes {

    private static StoreJKTransTypes jkTransTypes;

    private static void loadTransTypes() {
        if ((jkTransTypes == null) || jkTransTypes.getListUtTypes().isEmpty()) {
            jkTransTypes = (StoreJKTransTypes) Store.loadObject(JKTransTypes.class.getSimpleName());
        }
        if (jkTransTypes == null) {
            jkTransTypes = new StoreJKTransTypes();
        }
    }

    public static void saveTransTypes(List<UserTransactionType> tt) {
        loadTransTypes();
        if (!jkTransTypes.getListUtTypes().isEmpty()) {
            Store.deleteObject(JKTransTypes.class.getSimpleName());
        } else {
            for (UserTransactionType ut : tt) {
                jkTransTypes.getListUtTypes().add(ut);
            }
        }
        Store.saveObject(JKTransTypes.class.getSimpleName(), jkTransTypes);
    }

    public static List<UserTransactionType> getListUserTransTypes() {
        loadTransTypes();
        return jkTransTypes.getListUtTypes();
    }

    public static void clearTransTypes() {
        loadTransTypes();
        if (jkTransTypes != null) {
            jkTransTypes.getListUtTypes().clear();
        }
        Store.deleteObject(JKTransTypes.class.getSimpleName());
    }

    public static void deleteJKTransTypeFile() {
        Store.deleteObject(JKTransTypes.class.getSimpleName());
    }

//    private static List<String> transTypes;
//    public static void loadTransTypes() {
//        if ((transTypes == null) || (transTypes.isEmpty())) {
//            transTypes = (ArrayList<String>) Store.loadObject(JKTransTypes.class.getSimpleName());
//        }
//        if (transTypes == null) {
//            transTypes = new ArrayList<>();
//        }
//    }
//    public static boolean hasTransTypes() {
//        loadTransTypes();
//        return transTypes.size() > 0;
//    }
//    public static String getTransType(String name) {
//        String res = null;
//        loadTransTypes();
//        for (String s : transTypes) {
//            if (s.equals(name)) {
//                res = s;
//                break;
//            }
//        }
//        return res;
//    }
//    public static List<String> getTransTypesList(String pin) {
//        transTypes = null;
//        loadTransTypes();
//        if (!(JKTransTypes.hasTransTypes())) {
//            transTypes = getOnlineTransTypeList(pin);
//        }
//        return transTypes;
//    }
//    private static List<String> getOnlineTransTypeList(String pin) {
////        List<String> tTypes = new ArrayList<>();
//        transTypes = new ArrayList<>();
//        UserUtil.getLoggedInUser(pin, new LoggedInUserResult() {
//            @Override
//            public void loggedInUserResult(User loggedInUser) {
//                if (loggedInUser.isSuccess()) {
//                    transTypes = loggedInUser.getTransTypes();
//                    for (String tt : transTypes) {
//                        JKTransTypes.saveTransType(tt);
//                    }
////                    for (int i = 0; i < transTypes.size(); i++) {
////                        JKTransTypes.saveTransType(transTypes.get(i));
////                    }
//                }
//            }
//        });
////        User user = UserUtil.getLoggedInUser(pin);
////        if (user != null) {
////            tTypes = user.getTransTypes();
////            for (int i = 0; i < tTypes.size(); i++) {
////                JKTransTypes.saveTransType(tTypes.get(i).toString());
////            }
////        }
////        return tTypes;
//        return transTypes;
//    }
//    public static void saveTransType(String tt) {
//        loadTransTypes();
//        if (getTransType(tt) == null) {
//            transTypes.add(tt);
//            Store.saveObject(JKTransTypes.class.getSimpleName(), transTypes);
//        }
//    }
//    public static void saveTransTypes(List<String> tt) {
//        if (transTypes != null) {
//            transTypes.clear();
//        } else {
//            transTypes = new ArrayList<>();
//        }
//
//        transTypes.addAll(tt);
//        Store.saveObject(JKTransTypes.class.getSimpleName(), transTypes);
//    }
//    public static void clearTransTypes() {
//        if (transTypes != null) {
//            transTypes.clear();
//        }
//        Store.deleteObject(JKTransTypes.class.getSimpleName());
//    }
}
