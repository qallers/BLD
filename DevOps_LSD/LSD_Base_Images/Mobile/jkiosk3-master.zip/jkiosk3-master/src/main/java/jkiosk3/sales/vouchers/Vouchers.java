package jkiosk3.sales.vouchers;

import aeonairtime.AirtimeManufacturer;
import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.vouchers.VoucherUtil.AirtimeManufacturerResult;

public class Vouchers extends Region {

    private final SaleType voucherType;
    private TilePane tile;

    public Vouchers() {
        this.voucherType = VoucherSale.getInstance().getSaleType();
        getChildren().add(getVoucherProviders());
    }

    private VBox getVoucherProviders() {

        Button btnBack = JKNode.getBtnPopup("back");
        btnBack.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new MenuVouchers());
            }
        });

        Label lblVoucherType = JKText.getLblDk(voucherType.getDisplay(), JKText.FONT_B_SM);

        VBox vbHead = JKNode.getPageDblHeadVB(0, btnBack, lblVoucherType);

        tile = JKLayout.getTile(0, JKLayout.sp, JKLayout.sp, 4);

        getProviders();

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private void getProviders() {
        VoucherUtil.getVoucherProvidersList(new AirtimeManufacturerResult() {

            @Override
            public void airtimeManufacturerResult(List<AirtimeManufacturer> manufacturerList) {
                if (!manufacturerList.isEmpty()) {
                    List<AirtimeManufacturer> listView = VoucherUtil.getProvidersShow(voucherType);
                    if (!listView.isEmpty()) {
                        tile.getChildren().addAll(getProviderButtons(listView));
                    }
                }
            }
        });
    }

    private List<Button> getProviderButtons(List<AirtimeManufacturer> provList) {
        List<Button> btnList = new ArrayList<>();

        for (final AirtimeManufacturer a : provList) {
            final Button btn = JKNode.getAirtimeProviderButton(a.getId(), null);

            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    VoucherSale.getInstance().setProvider(a);
                    SceneSales.clearAndChangeContent(new VoucherProducts());
                }
            });
            btnList.add(btn);
        }
        return btnList;
    }
}
