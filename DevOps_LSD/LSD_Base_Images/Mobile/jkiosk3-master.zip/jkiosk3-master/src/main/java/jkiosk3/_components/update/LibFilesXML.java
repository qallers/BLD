package jkiosk3._components.update;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LibFilesXML {

//    private static final Logger logger = Logger.getLogger(LibFilesXML.class.getName());
//    private final static String LIBFILES = "libfiles";
//    private final static String LIBFILE = "libfile";
//    private String filename;
//    private List<String> listLibFilenames;
//
//    public LibFilesXML(String filename) {
//        this.filename = filename;
//        this.listLibFilenames = new ArrayList<>();
//
//        getListFiles();
//    }
//
//    private List<String> getListFiles() {
//
//            Document dom;
//            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//            String file = null;
//            try {
//                DocumentBuilder db = dbf.newDocumentBuilder();
//                Document doc = db.parse(filename);
//
//                doc.getDocumentElement().normalize();
//
////                NodeList parent = doc.getElementsByTagName(LIBFILES);
//
//                NodeList files = doc.getElementsByTagName(LIBFILE);
//                for (int i = 0; i < files.getLength(); i++) {
//                    listLibFilenames.add(files.item(i).getTextContent());
//                }
//
//            } catch (ParserConfigurationException | SAXException | IOException e) {
//                logger.log(Level.SEVERE, e.getMessage(), e);
//            }
//        if (!listLibFilenames.isEmpty()) {
//            System.out.println("size of list = " + listLibFilenames.size());
//        }
//
//        return listLibFilenames;
//    }
//
//    public List<String> getListLibFilenames() {
//        return listLibFilenames;
//    }
}
