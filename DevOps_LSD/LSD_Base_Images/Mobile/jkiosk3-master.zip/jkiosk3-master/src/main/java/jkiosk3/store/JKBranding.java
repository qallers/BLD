package jkiosk3.store;

/**
 *
 * @author Valerie
 */
public class JKBranding {
    
    private static StoreJKBranding branding;

    public static StoreJKBranding getBranding() {
        if (branding == null) {
            branding = ((StoreJKBranding) Store.loadObject(JKBranding.class.getSimpleName()));
        }
        if (branding == null) {
            branding = new StoreJKBranding();
        }
        return branding;
    }

    public static boolean saveBranding() {
        getBranding();
        return Store.saveObject(JKBranding.class.getSimpleName(), branding);
    }    
}
