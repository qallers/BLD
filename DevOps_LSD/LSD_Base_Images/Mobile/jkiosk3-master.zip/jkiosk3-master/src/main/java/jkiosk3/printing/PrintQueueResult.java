package jkiosk3.printing;

/**
 *
 * @author valeriew
 */
public abstract class PrintQueueResult {
    
    public abstract void onDone(boolean printQueueComplete);
    
}
