package jkiosk3;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 *
 * @author Val
 */
public class JK3Log {

    private final static int fileLimit = (1024 * 1024);
    private final static int fileCount = 3;

    public static void makeLogHandlers() throws IOException {
        File logs = new File("logs");
        logs.mkdir();

        Handler logHandler = new FileHandler(String.format("logs/log-%s.txt", 
                new SimpleDateFormat("YYYYMMdd").format(new Date())), fileLimit, fileCount, true);
        logHandler.setFormatter(new SimpleFormatter());
        Logger.getLogger("").addHandler(logHandler);
    }
}
