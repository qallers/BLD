package jkiosk3.admin.favourites.fav_cache;

import aeonfavourites.FavouriteItem;
import jkiosk3.store.Store;

import java.util.List;

public class CacheFavouriteDefaultStore {

    private static volatile FavouriteDefaultStore favouriteDefaultStore;

    private static FavouriteDefaultStore getFavouriteDefaultStore() {
        if (favouriteDefaultStore == null) {
            favouriteDefaultStore = ((FavouriteDefaultStore) Store.loadObject(CacheFavouriteDefaultStore.class.getSimpleName()));
        }
        if (favouriteDefaultStore == null) {
            favouriteDefaultStore = new FavouriteDefaultStore();
        }
        return favouriteDefaultStore;
    }

    public static boolean saveFavouriteStore(List<FavouriteItem> listFavouriteItem) {
        getFavouriteDefaultStore();
        favouriteDefaultStore.setListFavouriteItem(listFavouriteItem);
        return Store.saveObject(CacheFavouriteDefaultStore.class.getSimpleName(), favouriteDefaultStore);
    }

    public static boolean hasFavouriteStoreItems() {
        getFavouriteDefaultStore();
        return !favouriteDefaultStore.getListFavouriteItem().isEmpty();
    }

    public static List<FavouriteItem> getListFavouriteItems() {
        getFavouriteDefaultStore();
        return favouriteDefaultStore.getListFavouriteItem();
    }

    public static void deleteCacheFavouriteStore() {
        Store.deleteObject(CacheFavouriteDefaultStore.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheFavouriteDefaultStore.class.getSimpleName());
    }

}
