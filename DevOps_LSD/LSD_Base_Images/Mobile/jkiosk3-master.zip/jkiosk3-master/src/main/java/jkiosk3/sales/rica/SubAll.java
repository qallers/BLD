package jkiosk3.sales.rica;

import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SceneSales;

/**
 * @author Val
 */
public class SubAll extends Region {

    public final static String REG_TYPE_CELL = "Cell Phone Number";
    public final static String REG_TYPE_SP = "Starter Pack Serial Number";
    public final static String REG_TYPE_SIM = "SIM Serial Number";
    //
    public final static String REG_SUBMIT_CELL = "MSISDN";
    public final static String REG_SUBMIT_SP = "STARTER_PACK_REF";
    public final static String REG_SUBMIT_SIM = "SIM";
    //
    public final static String REG_PG_0 = "pg0";
    public final static String REG_PG_1 = "pg1";
    public final static String REG_PG_2 = "pg2";
    public final static String REG_PG_3 = "pg3";
    public final static String REG_PG_4 = "pg4";
    //
    private final double w = JKLayout.contentW;
    private final double h = 665;
    private static Label lblSubAction;
    private static Pane subContent;
    private static Button btnBack;
    private static Button btnNext;
    private ImageView imgViewNext;
    private List<Region> pages;
    private int currentPg;

    public SubAll(List<Region> pgs) {
        this.pages = pgs;

        currentPg = 0;

        getChildren().add(getSubFrame());
    }

    private VBox getSubFrame() {

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.setPrefSize(w, h);

        lblSubAction = JKText.getLblDk("", JKText.FONT_B_SM);
        lblSubAction.setMinWidth(w - (2 * JKLayout.sp));
        lblSubAction.setAlignment(Pos.CENTER_LEFT);

        subContent = new Pane();
        VBox.setVgrow(subContent, Priority.ALWAYS);
        subContent.getChildren().add(pages.get(currentPg));

        vb.getChildren().addAll(lblSubAction, JKNode.createContentSep());
        vb.getChildren().add(subContent);
        vb.getChildren().addAll(JKNode.createContentSep(), getNavButtons());

        return vb;
    }

    private HBox getNavButtons() {
        HBox hb = JKLayout.getHBox(0, 5);
        hb.setMinWidth(w - (2 * JKLayout.sp));

        Image imgBack = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/arrow_left.png"));
        Image imgCancel = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/cross.png"));
        Image imgNext = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/arrow_right.png"));
        ImageView imgViewBack = new ImageView(imgBack);
        ImageView imgViewCancel = new ImageView(imgCancel);
        imgViewNext = new ImageView(imgNext);

        btnBack = JKNode.getBtnSm("Back");
        btnBack.setGraphic(imgViewBack);
        btnBack.setGraphicTextGap(JKLayout.sp);
        btnBack.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onClickBack();
            }
        });

        Button btnCancel = JKNode.getBtnSm("Cancel");
        btnCancel.setGraphic(imgViewCancel);
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new RICAMenu());
            }
        });

        btnNext = JKNode.getBtnSm("Next");
        btnNext.setGraphic(imgViewNext);
        btnNext.setGraphicTextGap(JKLayout.sp);
        btnNext.setContentDisplay(ContentDisplay.RIGHT);
        btnNext.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                validateAndContinue();
            }
        });

        hb.getChildren().addAll(btnBack, JKNode.getHSpacer(), btnCancel, JKNode.getHSpacer(), btnNext);

        return hb;
    }

    private void validateAndContinue() {
        switch (pages.get(currentPg).getId()) {
            case REG_PG_0:
                SubReg0 pg0 = (SubReg0) pages.get(currentPg);
                if (pg0.validatePg0()) {
                    onClickNext();
                }
                break;
            case REG_PG_1:
                SubReg1 pg1 = (SubReg1) pages.get(currentPg);
                if (pg1.validatePg1()) {
                    onClickNext();
                }
                break;
            case REG_PG_2:
                SubReg2 pg2 = (SubReg2) pages.get(currentPg);
                if (pg2.validatePg2()) {
                    onClickNext();
                }
                break;
            case REG_PG_3:
                SubReg3 pg3 = (SubReg3) pages.get(currentPg);
                if (pg3.validatePg3()) {
                    onClickNext();
                }
        }
    }

    public void onClickNext() {

        btnBack.setDisable(false);

        currentPg = Math.min(currentPg + 1, pages.size() - 1);
        if (currentPg == (pages.size() - 1)) {
            btnNext.setText("Submit");
            btnNext.setGraphic(null);
            btnNext.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    if (btnNext.getText().equals("Submit")) {
                        SubReg4 pg4 = (SubReg4) pages.get(currentPg);
                        if (pg4.validatePg4()) {
                            switch (RICAUtil.getRegistrationType()) {
                                case RICAUtil.NEW_REG:
                                    SubNewRegistration.onClickSubmit();
                                    break;
                                case RICAUtil.CHANGE_CELL_NUM:
                                    SubChOwnCell.onClickSubmit();
                                    break;
                                case RICAUtil.CHANGE_SIM_SP:
                                    SubChOwnSimSp.onClickSubmit();
                            }
                        }
                    } else {
                        onClickNext();
                    }
                }
            });
        } else if (currentPg < (pages.size() - 1)) {

            btnNext.setText("Next");
            btnNext.setGraphic(imgViewNext);
        }
        subContent.getChildren().clear();
        subContent.getChildren().add(pages.get(currentPg));
    }

    public void onClickBack() {

        currentPg = Math.max(currentPg - 1, 0);
        if (currentPg > 0) {
            btnNext.setText("Next");
            btnNext.setGraphic(imgViewNext);
        } else if (currentPg == 0) {
            btnBack.setDisable(true);
        } else {
            btnBack.setDisable(false);
        }
        subContent.getChildren().clear();
        subContent.getChildren().add(pages.get(currentPg));
    }

    public static Label getLblSubAction() {
        return lblSubAction;
    }

    public static Button getBtnBack() {
        return btnBack;
    }

    public static Button getBtnNext() {
        return btnNext;
    }
}
