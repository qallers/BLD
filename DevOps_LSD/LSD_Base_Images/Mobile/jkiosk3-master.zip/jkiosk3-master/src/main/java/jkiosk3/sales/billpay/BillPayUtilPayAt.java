package jkiosk3.sales.billpay;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.payat.PayAtAccPayConfReq;
import aeonbillpayments.payat.PayAtAccPayConfResp;
import aeonbillpayments.payat.PayAtAccPayReq;
import aeonbillpayments.payat.PayAtAccPayResp;
import aeonbillpayments.payat.PayAtFinePayConfResp;
import aeonbillpayments.payat.PayAtFinePayResp;
import aeonbillpayments.payat.PayAtIPPayConfReq;
import aeonbillpayments.payat.PayAtIPPayConfResp;
import aeonbillpayments.payat.PayAtIPPayReq;
import aeonbillpayments.payat.PayAtIPPayResp;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.concurrent.Worker.State;
import jkiosk3.JKiosk3;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.utilities.TaskUtil;

/**
 *
 * @author Val
 */
public class BillPayUtilPayAt {

    private final static Logger logger = Logger.getLogger(BillPayUtilPayAt.class.getName());
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private static BillPaymentConnection bpc = null;

    private static PayAtAccPayConfResp getPayAtBillPaymentConfirm(BillPaymentConnection conn, PayAtAccPayConfReq r)
            throws RuntimeException {
        PayAtAccPayConfResp resp = new PayAtAccPayConfResp();

        try {
            resp = conn.getPayAtAccountPaymentConfirmation(r);
        } catch (Throwable t) {
            resp.setErrorCode("1995");
            resp.setErrorMessage("Communication error.  Please try again.");
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Payment Confirm Error", t);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return resp;
    }

    private static PayAtIPPayConfResp getPayAtInsurancePaymentConfirm(BillPaymentConnection conn, PayAtIPPayConfReq r)
            throws RuntimeException {
        PayAtIPPayConfResp resp = new PayAtIPPayConfResp();

        try {
            resp = conn.getPayAtInsurancePaymentConfirmation(r);
        } catch (Throwable t) {
            resp.setErrorCode("1996");
            resp.setErrorText("Communication error.  Please try again.");
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Payment Confirm Error", t);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return resp;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getPayAtBillPaymentResponse(final PayAtAccPayReq r, final PayAtBillPaymentResponse resp) {

        JKiosk3.getBusy().showBusy("Confirming Account Details");

        final Task<BillPaymentConnection> taskConnect = new Task() {
            @Override
            protected BillPaymentConnection call() throws Exception {
                bpc = BillPayUtilConnect.getBpc();
                return bpc;
            }
        };

        final Task<PayAtAccPayResp> taskAccResp = new Task<PayAtAccPayResp>() {
            @Override
            protected PayAtAccPayResp call() throws Exception {
                PayAtAccPayResp res = null;
                if (BillPayUtilConnect.isLoggedIn(BillPaymentConnection.BILLPAY_PAYAT_ACCOUNT)) {
                    res = bpc.getPayAtAccountPayment(r);
                }
                return res;
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                resp.payAtBillPayResp(taskConnect.getValue(), getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Account Details", State.CANCELLED, errorMsg, new BillPaymentMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Account Details", State.FAILED, errorMsg, new BillPaymentMenu());
            }
        };

        taskConnect.stateProperty().addListener(new ChangeListener<State>() {
            @Override
            public void changed(ObservableValue<? extends State> observable, State oldValue, State newState) {
                if (newState == State.SUCCEEDED) {
                    if (taskConnect.getValue() != null) {
                        new Thread(taskAccResp).start();
                        JKiosk3.getBusy().startCountdown(taskAccResp, BillPayUtilConnect.COUNTDOWN_TIME);
                    } else {
                        errorMsg = "Unable to establish connection";
                        taskutil.taskConnectNull(errorMsg, new BillPaymentMenu());
                    }
                } else if (newState == State.CANCELLED || newState == State.FAILED) {
                    taskutil.taskConnectCancelFail(newState, errorMsg, new BillPaymentMenu());
                }
            }
        });

        new Thread(taskConnect).start();
    }

    public static void getPayAtBillPaymentConfirm(final BillPaymentConnection conn, final PayAtAccPayConfReq r, final PayAtBillPaymentConfirm conf) {

        JKiosk3.getBusy().showBusy("Confirming Payment");

        final Task<PayAtAccPayConfResp> taskAccConf = new Task() {
            @Override
            protected PayAtAccPayConfResp call() throws Exception {
                return getPayAtBillPaymentConfirm(conn, r);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                conf.payAtBillPayConf((PayAtAccPayConfResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.FAILED, errorMsg);
            }
        };

        new Thread(taskAccConf).start();
        JKiosk3.getBusy().startCountdown(taskAccConf, BillPayUtilConnect.COUNTDOWN_TIME);
    }

    public static void getPayAtInsurancePaymentResponse(final PayAtIPPayReq r, final PayAtInsurancePayResponse resp) {

        JKiosk3.getBusy().showBusy("Getting Policy Details");

        final Task<BillPaymentConnection> taskConnect = new Task() {
            @Override
            protected BillPaymentConnection call() throws Exception {
                bpc = BillPayUtilConnect.getBpc();
                return bpc;
            }
        };

        final Task<PayAtIPPayResp> taskInsResp = new Task() {
            @Override
            protected PayAtIPPayResp call() throws Exception {
                PayAtIPPayResp res = null;
                if (BillPayUtilConnect.isLoggedIn(BillPaymentConnection.BILLPAY_PAYAT_INSURANCE)) {
                    res = bpc.getPayAtInsurancePayment(r);
                }
                return res;
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                resp.payAtInsurancePayResp(taskConnect.getValue(), (PayAtIPPayResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Policy Details", State.CANCELLED, errorMsg, new BillPaymentMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Policy Details", State.FAILED, errorMsg, new BillPaymentMenu());
            }
        };

        taskConnect.stateProperty().addListener(new ChangeListener<State>() {
            @Override
            public void changed(ObservableValue<? extends State> observable, State oldValue, State newState) {
                if (newState == State.SUCCEEDED) {
                    if (taskConnect.getValue() != null) {
                        new Thread(taskInsResp).start();
                        JKiosk3.getBusy().startCountdown(taskInsResp, BillPayUtilConnect.COUNTDOWN_TIME);
                    } else {
                        errorMsg = "Unable to establish connection";
                        taskutil.taskConnectNull(errorMsg, new BillPaymentMenu());
                    }
                } else if (newState == State.CANCELLED || newState == State.FAILED) {
                    taskutil.taskConnectCancelFail(newState, errorMsg, new BillPaymentMenu());
                }
            }
        });

        new Thread(taskConnect).start();
    }

    public static void getPayAtInsurancePaymentConfirm(final BillPaymentConnection conn, final PayAtIPPayConfReq r,
            final PayAtInsurancePayConfirm conf) {

        JKiosk3.getBusy().showBusy("Confirming Payment");

        final Task<PayAtIPPayConfResp> taskInsConf = new Task() {
            @Override
            protected PayAtIPPayConfResp call() throws Exception {
                return getPayAtInsurancePaymentConfirm(conn, r);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                conf.payAtInsurancePayConf((PayAtIPPayConfResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.FAILED, errorMsg);
            }
        };

        new Thread(taskInsConf).start();
        JKiosk3.getBusy().startCountdown(taskInsConf, BillPayUtilConnect.COUNTDOWN_TIME);
    }

    public static void getPayAtTrafficFinePaymentResponse(final PayAtAccPayReq r, final PayAtTrafficFinePaymentResponse resp) {

        JKiosk3.getBusy().showBusy("Confirming Traffic Fine Details");

        final Task<BillPaymentConnection> taskConnect = new Task() {
            @Override
            protected BillPaymentConnection call() throws Exception {
                bpc = BillPayUtilConnect.getBpc();
                return bpc;
            }
        };

        final Task<PayAtFinePayResp> taskTrafResp = new Task() {
            @Override
            protected PayAtFinePayResp call() throws Exception {
                PayAtFinePayResp res = null;
                if (BillPayUtilConnect.isLoggedIn(BillPaymentConnection.BILLPAY_PAYAT_FINE)) {
                    res = bpc.getPayAtTrafficFinePayment(r);
                }
                return res;
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                resp.payAtTrafficFinePayResp(taskConnect.getValue(), (PayAtFinePayResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Traffic Fine Details", State.CANCELLED, errorMsg, new BillPaymentMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Traffic Fine Details", State.FAILED, errorMsg, new BillPaymentMenu());
            }
        };

        taskConnect.stateProperty().addListener(new ChangeListener<State>() {
            @Override
            public void changed(ObservableValue<? extends State> observable, State oldValue, State newState) {
                if (newState == State.SUCCEEDED) {
                    if (taskConnect.getValue() != null) {
                        new Thread(taskTrafResp).start();
                        JKiosk3.getBusy().startCountdown(taskTrafResp, BillPayUtilConnect.COUNTDOWN_TIME);
                    } else {
                        errorMsg = "Unable to establish connection";
                        taskutil.taskConnectNull(errorMsg, new BillPaymentMenu());
                    }
                } else if (newState == State.CANCELLED || newState == State.FAILED) {
                    taskutil.taskConnectCancelFail(newState, errorMsg, new BillPaymentMenu());
                }
            }
        });

        new Thread(taskConnect).start();
    }

    public abstract static class PayAtBillPaymentResponse {

        public abstract void payAtBillPayResp(BillPaymentConnection connect, PayAtAccPayResp resp);
    }

    public abstract static class PayAtBillPaymentConfirm {

        public abstract void payAtBillPayConf(PayAtAccPayConfResp bpConfResp);
    }

    public abstract static class PayAtInsurancePayResponse {

        public abstract void payAtInsurancePayResp(BillPaymentConnection connect, PayAtIPPayResp resp);
    }

    public abstract static class PayAtInsurancePayConfirm {

        public abstract void payAtInsurancePayConf(PayAtIPPayConfResp insConfResp);
    }

    public abstract static class PayAtTrafficFinePaymentResponse {

        public abstract void payAtTrafficFinePayResp(BillPaymentConnection connect, PayAtFinePayResp resp);
    }

    public abstract static class PayAtTrafficFinePaymentConfirm {

        public abstract void payAtTrafficFinePayConf(PayAtFinePayConfResp bpConfResp);
    }
}
