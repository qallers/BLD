package jkiosk3.sales.rica;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Val
 */
public class CountryCodes {

    public final static String COUNTRY_NAME = "Country Name";
    public final static String COUNTRY_CODE = "Country Code";
    public final static String COUNTRY_DIAL = "Country Dialling Prefix";
    private static final List<CountryCode> codeList;

    static {
        codeList = new ArrayList<>();
        codeList.add(new CountryCode("Afghanistan", "AF", "93"));
        codeList.add(new CountryCode("Aland Islands", "AX", "-"));
        codeList.add(new CountryCode("Albania", "AL", "355"));
        codeList.add(new CountryCode("Algeria", "DZ", "213"));
        codeList.add(new CountryCode("American Samoa", "AS", "684"));
        codeList.add(new CountryCode("Andorra", "AD", "376"));
        codeList.add(new CountryCode("Angola", "AO", "244"));
        codeList.add(new CountryCode("Anguilla", "AI", "264"));
        codeList.add(new CountryCode("Antarctica", "AQ", "672"));
        codeList.add(new CountryCode("Antigua and Barbuda", "AG", "268"));
        codeList.add(new CountryCode("Argentina", "AR", "54"));
        codeList.add(new CountryCode("Armenia", "AM", "374"));
        codeList.add(new CountryCode("Aruba", "AW", "297"));
        codeList.add(new CountryCode("Australia", "AU", "61"));
        codeList.add(new CountryCode("Austria", "AT", "43"));
        codeList.add(new CountryCode("Azerbaijan", "AZ", "994"));
        codeList.add(new CountryCode("Bahamas", "BS", "242"));
        codeList.add(new CountryCode("Bahrain", "BH", "973"));
        codeList.add(new CountryCode("Bangladesh", "BD", "880"));
        codeList.add(new CountryCode("Barbados", "BB", "246"));
        codeList.add(new CountryCode("Belarus", "BY", "375"));
        codeList.add(new CountryCode("Belgium", "BE", "32"));
        codeList.add(new CountryCode("Belize", "BZ", "501"));
        codeList.add(new CountryCode("Benin", "BJ", "229"));
        codeList.add(new CountryCode("Bermuda", "BM", "441"));
        codeList.add(new CountryCode("Bhutan", "BT", "975"));
        codeList.add(new CountryCode("Bolivia", "BO", "591"));
        codeList.add(new CountryCode("Bosnia and Herzegovina", "BA", "387"));
        codeList.add(new CountryCode("Botswana", "BW", "267"));
        codeList.add(new CountryCode("Bouvet Island", "BV", "-"));
        codeList.add(new CountryCode("Brazil", "BR", "55"));
        codeList.add(new CountryCode("British Indian Ocean Territory", "IO", "-"));
        codeList.add(new CountryCode("Brunei Darussalam", "BN", "673"));
        codeList.add(new CountryCode("Bulgaria", "BG", "359"));
        codeList.add(new CountryCode("Burkina Faso", "BF", "226"));
        codeList.add(new CountryCode("Burundi", "BI", "257"));
        codeList.add(new CountryCode("Cambodia", "KH", "855"));
        codeList.add(new CountryCode("Cameroon", "CM", "237"));
        codeList.add(new CountryCode("Canada", "CA", "1"));
        codeList.add(new CountryCode("Cape Verde", "CV", "238"));
        codeList.add(new CountryCode("Cayman Islands", "KY", "345"));
        codeList.add(new CountryCode("Central African Republic", "CF", "236"));
        codeList.add(new CountryCode("Chad", "TD", "235"));
        codeList.add(new CountryCode("Chile", "CL", "56"));
        codeList.add(new CountryCode("China", "CN", "86"));
        codeList.add(new CountryCode("Christmas Island", "CX", "61"));
        codeList.add(new CountryCode("Cocos (Keeling) Islands", "CC", "61"));
        codeList.add(new CountryCode("Colombia", "CO", "57"));
        codeList.add(new CountryCode("Comoros", "KM", "269"));
        codeList.add(new CountryCode("Congo", "CG", "242"));
        codeList.add(new CountryCode("Congo", "CD", "243"));
        codeList.add(new CountryCode("Cook Islands", "CK", "682"));
        codeList.add(new CountryCode("Costa Rica", "CR", "506"));
        codeList.add(new CountryCode("Cote d'Ivoire", "CI", "225"));
        codeList.add(new CountryCode("Croatia", "HR", "385"));
        codeList.add(new CountryCode("Cuba", "CU", "53"));
        codeList.add(new CountryCode("Cyprus", "CY", "357"));
        codeList.add(new CountryCode("Czech Republic", "CZ", "420"));
        codeList.add(new CountryCode("Denmark", "DK", "45"));
        codeList.add(new CountryCode("Djibouti", "DJ", "253"));
        codeList.add(new CountryCode("Dominica", "DM", "767"));
        codeList.add(new CountryCode("Dominican Republic", "DO", "809"));
        codeList.add(new CountryCode("Ecuador", "EC", "593"));
        codeList.add(new CountryCode("Egypt", "EG", "20"));
        codeList.add(new CountryCode("El Salvador", "SV", "503"));
        codeList.add(new CountryCode("Equatorial Guinea", "GQ", "240"));
        codeList.add(new CountryCode("Eritrea", "ER", "291"));
        codeList.add(new CountryCode("Estonia", "EE", "372"));
        codeList.add(new CountryCode("Ethiopia", "ET", "251"));
        codeList.add(new CountryCode("Falkland Islands (Malvinas)", "FK", "500"));
        codeList.add(new CountryCode("Faroe Islands", "FO", "298"));
        codeList.add(new CountryCode("Fiji", "FJ", "679"));
        codeList.add(new CountryCode("Finland", "FI", "358"));
        codeList.add(new CountryCode("France", "FR", "33"));
        codeList.add(new CountryCode("French Guiana", "GF", "594"));
        codeList.add(new CountryCode("French Polynesia", "PF", "689"));
        codeList.add(new CountryCode("French Southern Territories", "TF", "-"));
        codeList.add(new CountryCode("Gabon", "GA", "241"));
        codeList.add(new CountryCode("Gambia", "GM", "220"));
        codeList.add(new CountryCode("Georgia", "GE", "995"));
        codeList.add(new CountryCode("Germany", "DE", "49"));
        codeList.add(new CountryCode("Ghana", "GH", "233"));
        codeList.add(new CountryCode("Gibraltar", "GI", "350"));
        codeList.add(new CountryCode("Greece", "GR", "30"));
        codeList.add(new CountryCode("Greenland", "GL", "299"));
        codeList.add(new CountryCode("Grenada", "GD", "473"));
        codeList.add(new CountryCode("Guadeloupe", "GP", "590"));
        codeList.add(new CountryCode("Guam", "GU", "671"));
        codeList.add(new CountryCode("Guatemala", "GT", "502"));
        codeList.add(new CountryCode("Guernsey", "GG", "-"));
        codeList.add(new CountryCode("Guinea", "GN", "224"));
        codeList.add(new CountryCode("Guinea-Bissa", "GW", "245"));
        codeList.add(new CountryCode("Guyana", "GY", "-"));
        codeList.add(new CountryCode("Haiti", "HT", "509"));
        codeList.add(new CountryCode("Heard Island and McDonald Islands", "HM", "-"));
        codeList.add(new CountryCode("Holy See (Vatican City State)", "VA", "39"));
        codeList.add(new CountryCode("Honduras", "HN", "504"));
        codeList.add(new CountryCode("Hong Kong", "HK", "852"));
        codeList.add(new CountryCode("Hungary", "HU", "36"));
        codeList.add(new CountryCode("Iceland", "IS", "354"));
        codeList.add(new CountryCode("India", "IN", "91"));
        codeList.add(new CountryCode("Indonesia", "ID", "62"));
        codeList.add(new CountryCode("Iran", "IR", "98"));
        codeList.add(new CountryCode("Iraq", "IQ", "964"));
        codeList.add(new CountryCode("Ireland", "IE", "353"));
        codeList.add(new CountryCode("Isle of Man", "IM", "-"));
        codeList.add(new CountryCode("Israel", "IL", "972"));
        codeList.add(new CountryCode("Italy", "IT", "39"));
        codeList.add(new CountryCode("Jamaica", "JM", "876"));
        codeList.add(new CountryCode("Japan", "JP", "81"));
        codeList.add(new CountryCode("Jersey", "JE", "-"));
        codeList.add(new CountryCode("Jordan", "JO", "962"));
        codeList.add(new CountryCode("Kazakhstan", "KZ", "7"));
        codeList.add(new CountryCode("Kenya", "KE", "254"));
        codeList.add(new CountryCode("Kiribati", "KI", "686"));
        codeList.add(new CountryCode("Korea", "KP", "850"));
        codeList.add(new CountryCode("Korea", "KR", "82"));
        codeList.add(new CountryCode("Kuwait", "KW", "965"));
        codeList.add(new CountryCode("Kyrgyzstan", "KG", "7"));
        codeList.add(new CountryCode("Lao People's Democratic Republic", "LA", "856"));
        codeList.add(new CountryCode("Latvia", "LV", "371"));
        codeList.add(new CountryCode("Lebanon", "LB", "961"));
        codeList.add(new CountryCode("Lesotho", "LS", "266"));
        codeList.add(new CountryCode("Liberia", "LR", "231"));
        codeList.add(new CountryCode("Libyan Arab Jamahiriya", "LY", "218"));
        codeList.add(new CountryCode("Liechtenstein", "LI", "423"));
        codeList.add(new CountryCode("Lithuania", "LT", "370"));
        codeList.add(new CountryCode("Luxembourg", "LU", "352"));
        codeList.add(new CountryCode("Macao", "MO", "853"));
        codeList.add(new CountryCode("Macedonia", "MK", "389"));
        codeList.add(new CountryCode("Madagascar", "MG", "261"));
        codeList.add(new CountryCode("Malawi", "MW", "265"));
        codeList.add(new CountryCode("Malaysia", "MY", "60"));
        codeList.add(new CountryCode("Maldives", "MV", "960"));
        codeList.add(new CountryCode("Mali", "ML", "223"));
        codeList.add(new CountryCode("Malta", "MT", "356"));
        codeList.add(new CountryCode("Marshall Islands", "MH", "692"));
        codeList.add(new CountryCode("Martinique", "MQ", "596"));
        codeList.add(new CountryCode("Mauritania", "MR", "222"));
        codeList.add(new CountryCode("Mauritius", "MU", "230"));
        codeList.add(new CountryCode("Mayotte", "YT", "269"));
        codeList.add(new CountryCode("Mexico", "MX", "52"));
        codeList.add(new CountryCode("Micronesia", "FM", "691"));
        codeList.add(new CountryCode("Moldova", "MD", "373"));
        codeList.add(new CountryCode("Monaco", "MC", "377"));
        codeList.add(new CountryCode("Mongolia", "MN", "976"));
        codeList.add(new CountryCode("Montserrat", "MS", "664"));
        codeList.add(new CountryCode("Morocco", "MA", "212"));
        codeList.add(new CountryCode("Mozambique", "MZ", "258"));
        codeList.add(new CountryCode("Myanmar", "MM", "95"));
        codeList.add(new CountryCode("Namibia", "NA", "264"));
        codeList.add(new CountryCode("Nauru", "NR", "674"));
        codeList.add(new CountryCode("Nepal", "NP", "977"));
        codeList.add(new CountryCode("Netherlands", "NL", "31"));
        codeList.add(new CountryCode("Netherlands Antilles", "AN", "599"));
        codeList.add(new CountryCode("New Caledonia", "NC", "687"));
        codeList.add(new CountryCode("New Zealand", "NZ", "64"));
        codeList.add(new CountryCode("Nicaragua", "NI", "505"));
        codeList.add(new CountryCode("Niger", "NE", "227"));
        codeList.add(new CountryCode("Nigeria", "NG", "234"));
        codeList.add(new CountryCode("Niue", "NU", "683"));
        codeList.add(new CountryCode("Norfolk Island", "NF", "672"));
        codeList.add(new CountryCode("Northern Mariana Islands", "MP", "670"));
        codeList.add(new CountryCode("Norway", "NO", "47"));
        codeList.add(new CountryCode("Oman", "OM", "968"));
        codeList.add(new CountryCode("Pakistan", "PK", "92"));
        codeList.add(new CountryCode("Palau", "PW", "680"));
        codeList.add(new CountryCode("Palestinian Territory", "PS", "970"));
        codeList.add(new CountryCode("Panama", "PA", "507"));
        codeList.add(new CountryCode("Papua New Guinea", "PG", "675"));
        codeList.add(new CountryCode("Paraguay", "PY", "595"));
        codeList.add(new CountryCode("Peru", "PE", "51"));
        codeList.add(new CountryCode("Philippines", "PH", "63"));
        codeList.add(new CountryCode("Pitcairn", "PN", "-"));
        codeList.add(new CountryCode("Poland", "PL", "48"));
        codeList.add(new CountryCode("Portugal", "PT", "351"));
        codeList.add(new CountryCode("Puerto Rico", "PR", "787"));
        codeList.add(new CountryCode("Qatar", "QA", "974"));
        codeList.add(new CountryCode("Reunion", "RE", "262"));
        codeList.add(new CountryCode("Romania", "RO", "40"));
        codeList.add(new CountryCode("Russian Federation", "RU", "7"));
        codeList.add(new CountryCode("Rwanda", "RW", "250"));
        codeList.add(new CountryCode("Saint Helena", "SH", "290"));
        codeList.add(new CountryCode("Saint Kitts and Nevis", "KN", "869"));
        codeList.add(new CountryCode("Saint Lucia", "LC", "758"));
        codeList.add(new CountryCode("Saint Pierre and Miquelon", "PM", "508"));
        codeList.add(new CountryCode("Saint Vincent and the Grenadines", "VC", "784"));
        codeList.add(new CountryCode("Samoa", "WS", "7"));
        codeList.add(new CountryCode("San Marino", "SM", "378"));
        codeList.add(new CountryCode("Sao Tome and Principe", "ST", "239"));
        codeList.add(new CountryCode("Saudi Arabia", "SA", "966"));
        codeList.add(new CountryCode("Senegal", "SN", "221"));
        codeList.add(new CountryCode("Serbia ", "RS", "381"));
        codeList.add(new CountryCode("Seychelles", "SC", "248"));
        codeList.add(new CountryCode("Sierra Leone", "SL", "232"));
        codeList.add(new CountryCode("Singapore", "SG", "65"));
        codeList.add(new CountryCode("Slovakia", "SK", "421"));
        codeList.add(new CountryCode("Slovenia", "SI", "386"));
        codeList.add(new CountryCode("Solomon Islands", "SB", "677"));
        codeList.add(new CountryCode("Somalia", "SO", "252"));
        codeList.add(new CountryCode("South Africa", "ZA", "27"));
        codeList.add(new CountryCode("South Georgia and the South Sandwich Islands", "GS", "-"));
        codeList.add(new CountryCode("Spain", "ES", "34"));
        codeList.add(new CountryCode("Sri Lanka", "LK", "94"));
        codeList.add(new CountryCode("Sudan", "SD", "249"));
        codeList.add(new CountryCode("Suriname", "SR", "597"));
        codeList.add(new CountryCode("Svalbard and Jan Mayen", "SJ", "-"));
        codeList.add(new CountryCode("Swaziland", "SZ", "268"));
        codeList.add(new CountryCode("Sweden", "SE", "46"));
        codeList.add(new CountryCode("Switzerland", "CH", "41"));
        codeList.add(new CountryCode("Syrian Arab Republic", "SY", "963"));
        codeList.add(new CountryCode("Taiwan", "TW", "886"));
        codeList.add(new CountryCode("Tajikistan", "TJ", "992"));
        codeList.add(new CountryCode("Tanzania", "TZ", "255"));
        codeList.add(new CountryCode("Thailand", "TH", "66"));
        codeList.add(new CountryCode("Timor-Lest", "TL", "-"));
        codeList.add(new CountryCode("Togo", "TG", "228"));
        codeList.add(new CountryCode("Tokelau", "TK", "690"));
        codeList.add(new CountryCode("Tonga", "TO", "676"));
        codeList.add(new CountryCode("Trinidad and Tobago", "TT", "868"));
        codeList.add(new CountryCode("Tunisia", "TN", "216"));
        codeList.add(new CountryCode("Turkey", "TR", "90"));
        codeList.add(new CountryCode("Turkmenistan", "TM", "993"));
        codeList.add(new CountryCode("Turks and Caicos Islands", "TC", "649"));
        codeList.add(new CountryCode("Tuvalu", "TV", "688"));
        codeList.add(new CountryCode("Uganda", "UG", "256"));
        codeList.add(new CountryCode("Ukraine", "UA", "380"));
        codeList.add(new CountryCode("United Arab Emirates", "AE", "971"));
        codeList.add(new CountryCode("United Kingdom", "GB", "44"));
        codeList.add(new CountryCode("United States", "US", "1"));
        codeList.add(new CountryCode("United States Minor Outlying Islands", "UM", "-"));
        codeList.add(new CountryCode("Uruguay", "UY", "598"));
        codeList.add(new CountryCode("Uzbekistan", "UZ", "998"));
        codeList.add(new CountryCode("Vanuatu", "VU", "678"));
        codeList.add(new CountryCode("Venezuela", "VE", "58"));
        codeList.add(new CountryCode("Viet Nam", "VN", "84"));
        codeList.add(new CountryCode("Virgin Islands", "VG", "284"));
        codeList.add(new CountryCode("Virgin Islands", "VI", "340"));
        codeList.add(new CountryCode("Wallis and Futuna", "WF", "681"));
        codeList.add(new CountryCode("Western Sahara", "EH", "-"));
        codeList.add(new CountryCode("Yemen", "YE", "967"));
        codeList.add(new CountryCode("Zambia", "ZM", "260"));
        codeList.add(new CountryCode("Zimbabwe", "ZW", "263"));
    }

    public static List<CountryCode> getCodeList() {
        return codeList;
    }

    public static class CountryCode {

        private String name;
        private String code;
        private String dial;

        public CountryCode(String name, String code, String dial) {
            this.name = name;
            this.code = code;
            this.dial = dial;
        }

        @Override
        public String toString() {
            return code + " - " + name;
        }

        public String getCode() {
            return code;
        }

        public String getName() {
            return name;
        }

        public String getDial() {
            return dial;
        }
    }
}
