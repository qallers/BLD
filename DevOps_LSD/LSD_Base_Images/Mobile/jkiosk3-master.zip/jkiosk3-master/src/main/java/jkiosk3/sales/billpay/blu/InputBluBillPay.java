package jkiosk3.sales.billpay.blu;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.blubillpay.BluAccPayConfReq;
import aeonbillpayments.blubillpay.BluAccPayConfResp;
import aeonbillpayments.blubillpay.BluAccSubscriberInfoReq;
import aeonbillpayments.blubillpay.BluAccSubscriberInfoResp;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilBlu;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay._common.BillPayEntry;
import jkiosk3.sales.billpay._common.BillPaymentSelect;
import jkiosk3.store.JKTransactionLimits;
import jkiosk3.users.UserUtil;

import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

public class InputBluBillPay extends Region {

    private final static Logger logger = Logger.getLogger (InputBluBillPay.class.getName ());

    private BillPaymentConnection connection;
    private final BillPayProduct product;
    private final VBox vbContent;
    private BillPayEntry gridAcc;
    private GridPane gridAmtDetail;
    private TextField txtAmt;
    private double amountPaid;
    private JKTenderToggles tenders;
    private String tendered;
    private BluAccSubscriberInfoResp subInfoResp;
    private boolean showFavourites;
    private boolean showProductFavourite;

    public InputBluBillPay(BillPayProduct prod, boolean isNFCFavourite, boolean isProductFavourite) {
        this.product = prod;
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;

        vbContent = JKLayout.getVBoxContent (JKLayout.spNum);

        VBox vbLayout = JKLayout.getVBox (0, 5);
        vbLayout.getChildren ().add (getAccountNumberEntry ());
        vbLayout.getChildren ().add (getNav ());

        getChildren ().add (vbLayout);
    }

    private VBox getAccountNumberEntry() {

        ImageView img = new ImageView();

        if (product.getLogoId() != null && !product.getLogoId().isEmpty()) {
//        if (!product.getLogoId ().isEmpty ()) {
            img = BillPayUtilMisc.getImageViewBillPay("prov_" + product.getLogoId() + ".png");
        } else {

            if (product.getProvName().contains("Blu Bill Payment")) {

                img = BillPayUtilMisc.getImageViewBillPay("prov_Blu.png");
            }

            if (product.getProvName().contains("Pay@")) {
                img = BillPayUtilMisc.getImageViewBillPay("prov_PayAt.png");
            } else if (product.getProvName ().contains ("Syntell")) {
                img = BillPayUtilMisc.getImageViewBillPay ("prov_Syntell.png");
            } else if (product.getProvName ().contains ("SAPO")) {
                img = BillPayUtilMisc.getImageViewBillPay ("prov_SAPO.png");
            }
        }
        img.setFitHeight (55);

        gridAcc = new BillPayEntry ("Account Payment", img, product, BillPayEntry.TYPE_ACCOUNT, showFavourites, showProductFavourite);
        gridAcc.getBtnDetail ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (vbContent.getChildren ().contains (gridAmtDetail)) {
                    vbContent.getChildren ().remove (gridAmtDetail);
                    getSubscriberInfo ();
                } else {
                    getSubscriberInfo ();
                }
            }
        });

        vbContent.getChildren ().add (gridAcc);

        return vbContent;
    }

    private GridPane getDetailAndAmountEntry() {

        String strPartPmnt = "";
        if (subInfoResp.isAcceptPartialPayment ()) {
            strPartPmnt = "Yes";
        } else {
            strPartPmnt = "No";
        }

        GridPane gridDetail = BillPayUtilMisc.getGridBillPayDetail (subInfoResp.getAmount (),
                subInfoResp.getConvenienceFee (), strPartPmnt, product.getBpTransType ().getDisplayName ());

        Label lblAmount = JKText.getLblDk ("Amount", JKText.FONT_B_XSM);
        txtAmt = JKNode.getTextFieldRight ();

        if (product.isEnforceFullPayment ()) {
            txtAmt.setText (JKText.getDeciFormat (subInfoResp.getAmount ()));
            txtAmt.setDisable (true);
        } else {
            txtAmt.setText ("");
            txtAmt.setDisable (false);
            txtAmt.setPromptText ("Enter Amount to Pay");
        }

        txtAmt.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
//                if (!(JKOptions.getOptions().isKeyboard())) {
                JKiosk3.getNumPad ().showNumPad (true, txtAmt,
                        "R " + (JKText.getDeciFormat (subInfoResp.getAmount () + subInfoResp.getConvenienceFee ())),
                        "", new NumberPadResult () {

                            @Override
                            public void onDone(String value) {
                                amountPaid = SalesUtil.getAmountAsDouble (value, txtAmt);
                            }
                        });
//                }
            }
        });

        gridAmtDetail = JKLayout.getContentGridInner2Col (0.5, 0.5);

        gridAmtDetail.add (gridDetail, 0, 1, 2, 1);
        gridAmtDetail.addRow (2, lblAmount, txtAmt);
        gridAmtDetail.addRow (3, getTenderTypes ());

        return gridAmtDetail;
    }

    private JKTenderToggles getTenderTypes() {
        List<String> listTenderAllowed = product.getTendersAllowed ();
        tenders = new JKTenderToggles (SaleType.BILLPAYMENTS.getDisplay (), listTenderAllowed);
        for (ToggleButton b : tenders.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(javafx.event.Event e) {

                    if (inputValidAmount ()) {
                        tendered = tenders.getTenderTypeSelected ();
                        checkAndAuthoriseAmount ();
                    } else {
                        tenders.resetTenderType ();
                    }
                }
            });
        }
        return tenders;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (gridAcc.getVbHead ().getChildren ().contains (gridAcc.getGridEnter ())) {
                    SceneSales.clearAndChangeContent (new BillPaymentSelect (
                            BillPayUtilMisc.TYPE_BILL_PAY + " Providers", BillPayUtilMisc.TYPE_BILL_PAY));
                } else {
                    SceneSales.clearAndChangeContent (new InputBluBillPay (product, showFavourites, showProductFavourite));
                }
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                BillPayUtilMisc.resetBillPayView ();
            }
        });
        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private void checkAndAuthoriseAmount() {
        if (amountPaid > JKTransactionLimits.getTransactionLimits ().getTransLimitBillPay ()) {
            BillPayUtilMisc.getSupervisorOverride (amountPaid, new UserUtil.SupervisorOverride () {

                @Override
                public void supervisorOverrideResult(Boolean isSupervisor) {
                    if (isSupervisor) {
                        logger.info ("Supervisor has authorised, show summary and continue...");
                        showConfirmationSummary ();
                    } else {
                        logger.info ("no authorisation yet, try again...");
                    }
                }
            }, txtAmt);
            tenders.resetTenderType ();
        } else {
            showConfirmationSummary ();
        }
    }

    private void showConfirmationSummary() {
        SummaryBluBillPay summary = new SummaryBluBillPay (subInfoResp, amountPaid, tendered);

        JKiosk3.getMsgBox ().showMsgBox (product.getBpTransType ().getDisplayName (), "Confirm all details before proceeding", summary,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {

                    @Override
                    public void onOk() {
                        getAccountPaymentConfirm ("commit");
                    }

                    @Override
                    public void onCancel() {
                        UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                        BillPayUtilMisc.resetBillPayView ();
                    }
                });

    }

    //====================================
    // above - mostly view
    // below - mostly process
    //====================================
    private void getSubscriberInfo() {
        if (inputValidAccount ()) {
            String accountNum = gridAcc.getAccountNumberConfirmed ();

            BluAccSubscriberInfoReq subInfoReq = new BluAccSubscriberInfoReq ();
            subInfoReq.setProviderId (product.getProvId ());
            subInfoReq.setProductId (product.getProdId ());
            subInfoReq.setAccountNo (accountNum);

            BillPayUtilBlu.getBluAccSubInfoResp (subInfoReq, new BillPayUtilBlu.BluAccSubscriberInfoResponse () {
                @Override
                public void bluAccSubscriberInfoResp(BillPaymentConnection connect, BluAccSubscriberInfoResp resp) {
                    connection = connect;

                    if (resp.isSuccess ()) {
                        subInfoResp = resp;

                        gridAcc.getVbHead ().getChildren ().remove (gridAcc.getGridEnter ());
                        gridAcc.getVbHead ().getChildren ().add (gridAcc.getGridDetail (subInfoResp.getSubscriberID (),
                                subInfoResp.getSubscriberName ()));
                        gridAmtDetail = getDetailAndAmountEntry ();
                        vbContent.getChildren ().add (1, gridAmtDetail);
                    } else {
                        if (!resp.getAeonErrorText ().isEmpty ()) {
                            JKiosk3.getMsgBox ().showMsgBox ("Subscriber Info Error", "A" + resp.getAeonErrorCode () + " - " + resp.getAeonErrorText (), null);
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("Subscriber Info Error", "B" + resp.getErrorCode () + " - " + resp.getErrorText (), null);
                        }
                        BillPayUtilMisc.resetBillPayView ();
                    }
                }
            });
        }
    }

    private void getAccountPaymentConfirm(String confirmType) {
        BluAccPayConfReq confRequest = new BluAccPayConfReq ();

        confRequest.setProviderId (product.getProvId ());
        confRequest.setProductId (product.getProdId ());
        confRequest.setConfirmType (confirmType);
        confRequest.setTrxId (subInfoResp.getTransRef ());
        confRequest.setAmountDue (amountPaid);
//        confRequest.setTenderType(tendered);        // 2017-03-06  -  see 201703-blubillpay.xml  -  not working if camel-case, works if all lower case
        confRequest.setTenderType (tendered.toLowerCase (Locale.ENGLISH));
        confRequest.setAccountNumber (subInfoResp.getSubscriberID ());
        confRequest.setWantPrintJob (true);

        BillPayUtilBlu.getBluBillPaymentConfirm (connection, confRequest, new BillPayUtilBlu.BluBillPaymentConfirm () {
            @Override
            public void bluBillPayConf(final BluAccPayConfResp bpConfResp) {
                if (bpConfResp.isSuccess ()) {
                    double amtTotal = amountPaid + subInfoResp.getConvenienceFee ();
                    String transRef = subInfoResp.getTransRef ();
                    String descript = product.getProdName () + " - " + subInfoResp.getSubscriberID ();

                    SalesUtil.processBillPayment (BPTransType.BILLPAY_BLU_ACCOUNT.getDisplayName (), transRef, descript, amtTotal, tendered,
                            bpConfResp.getMerchantMessage (), bpConfResp.getPrintLines (), bpConfResp.getMerchantPrintLines ());

                } else {
                    if (!bpConfResp.getAeonErrorText ().isEmpty ()) {
                        JKiosk3.getMsgBox ().showMsgBox ("", "A" + bpConfResp.getAeonErrorCode () + " - " + bpConfResp.getAeonErrorText (), null);
                    } else {
                        JKiosk3.getMsgBox ().showMsgBox ("", "B" + bpConfResp.getErrorCode () + " - " + bpConfResp.getErrorText (), null);

                    }

                }
                BillPayUtilMisc.resetBillPayView ();
            }
        });
    }

    private boolean inputValidAccount() {
//        if (product.getProdName().contains("Multichoice") && (gridAcc.getTxtNumber().getText().length() > 28)) {
        /* Product ID 298 was Multichoice, name changed to DSTV.
         * To fix that, I am changing this to check the Product ID instead of the Product Name,
         * and then insert the Product Name into the displayed message.
         */
        if ((product.getProdId () == 298) && (gridAcc.getAccountNumberConfirmed ().length () > 28)) {
            JKiosk3.getMsgBox ().showMsgBox (product.getProdName () + " Account Number",
                    "Please enter a valid " + product.getProdName () + " Account number", null);
            return false;
        }

        return true;
    }

    private boolean inputValidAmount() {
        if (txtAmt.getText ().trim ().equals ("") || txtAmt.getText ().trim ().equals ("0")) {
            JKiosk3.getMsgBox ().showMsgBox ("Amount to Pay", "Please enter a valid Amount", null);
            return false;
        }
        try {
            amountPaid = Double.parseDouble (txtAmt.getText ().trim ().replaceAll (" ", ""));

            // No need to validate this.  If 'product.isEnforceFullPayment()' is true,
            // input field is disabled so User is unable to enter an amount.
//            if (!product.isEnforceFullPayment()) {
            if (product.getProdMinAmount () != 0 && product.getProdMaxAmount () != 0) {
                if (amountPaid < product.getProdMinAmount () || amountPaid > product.getProdMaxAmount ()) {
                    String strAmt = "Amount must be between \n\nR " + JKText.getDeciFormat (product.getProdMinAmount ())
                            + "\n\nand\n\nR " + JKText.getDeciFormat (product.getProdMaxAmount ());
                    JKiosk3.getMsgBox ().showMsgBox ("Amount", strAmt, null);
                    txtAmt.setText ("");
                    return false;
                }
            } else if (product.getProdMinAmount () == 0 && product.getProdMaxAmount () == 0) {
                // Payments of less than R 10.00 return an error message.
                if (amountPaid < 10) {
                    JKiosk3.getMsgBox ().showMsgBox ("Amount", "Minimum Payment is \n\nR " + JKText.getDeciFormat (10.0), null);
                    txtAmt.setText ("");
                    return false;
                }
            }
//            }
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox ().showMsgBox ("Amount", "Amount must be a valid number", null);
            txtAmt.setText ("");
            return false;
        }
        return true;
    }

}