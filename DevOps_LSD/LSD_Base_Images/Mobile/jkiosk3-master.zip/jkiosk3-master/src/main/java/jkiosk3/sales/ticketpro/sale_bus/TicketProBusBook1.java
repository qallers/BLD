package jkiosk3.sales.ticketpro.sale_bus;

import aeonticketpros.bus.TicketProBusRoute;
import aeonticketpros.bus.TicketProBusRouteCode;
import aeonticketpros.bus.TicketProBusRouteListReq;
import aeonticketpros.bus.TicketProBusRouteListResp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.OverrunStyle;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales._common.PagedList;
import jkiosk3.sales.ticketpro.TicketProBusSale;
import jkiosk3.sales.ticketpro.TicketProUtilBus;
import jkiosk3.users.UserUtil;

public class TicketProBusBook1 extends Region {

    private final static Logger logger = Logger.getLogger (TicketProBusBook1.class.getName ());
    // statics
    private final static String ROUTE_CODE = "Route Code";
    private final static String DEPARTURE = "Departure";
    private final static String DESTINATION = "Destination";
    private final static String ALL = "All";
    private final static String SEARCHED = "Searched";
    private final static String PROMPT_ROUTE = "Enter Route Code";
    private final static String PROMPT_CITY = "Click for full list";
    private final static double ROUTES_WIDTH = 875;
    private final static double CITIES_WIDTH = 725;
    // AeonLib items
    private List<TicketProBusRouteCode> listRouteCodes = new ArrayList<> ();
    private final List<String> listDepCities = new ArrayList<> ();
    private final List<String> listDestCities = new ArrayList<> ();
    private TicketProBusRouteCode selectedRoute;
    // components for view
    private TextField txtRouteCode;
    private TextField txtDeparture;
    private TextField txtDestination;
    private Button btnSearchRouteCode;
    private Button btnSearchDeparture;
    private Button btnSearchDestination;
    private Button btnClearAll;
    private Text txtRouteSelected;
    private Text txtRouteFrom;
    private Text txtRouteTo;
    //
    private String strDepart = "";
    private String strDest = "";

    public TicketProBusBook1() {
        TicketProBusSale.resetTicketProBusSale ();
        TicketProUtilBus.getTicketProBusRouteCodeList (new TicketProUtilBus.TicketProBusRouteCodeListResult () {
            @Override
            public void tpBusRouteCodeListResult(List<TicketProBusRouteCode> tpBusRouteCodeList) {
                if (!tpBusRouteCodeList.isEmpty ()) {
                    listRouteCodes = tpBusRouteCodeList;

                    getListDepartures ();
                    getListDestinations ();

                    getChildren ().add (getPage1Layout ());

                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Putco Booking", "No Route Codes found", null);
                }
            }
        });
    }

    private VBox getPage1Layout() {
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().addAll (getBoardAndDestinationEntry (), getNav ());
        return vb;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();

        nav.getBtnBack ().setDisable (true);

        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(javafx.event.Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndShowFavourites ();
            }
        });

        nav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (validateInput ()) {
                    getRoutes ();
                }
            }
        });
        return nav;
    }

    private Button getBtnSearch(final String searchType) {
        Button btnSearch = JKNode.getBtnPopup ("search");
        btnSearch.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                onClickSearch (searchType);
            }
        });

        return btnSearch;
    }

    private Button getBtnClear() {
        Button btnClear = JKNode.getBtnPopup ("clear all");
        btnClear.setFont (JKText.FONT_B_18);
        btnClear.setMaxWidth ((2 * JKLayout.btnNumW) + JKLayout.sp);
        btnClear.setMinWidth ((2 * JKLayout.btnNumW) + JKLayout.sp);
        btnClear.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                onClickClear ();
            }
        });
        return btnClear;
    }

    private HBox getHBoxInput(Node node, Button btn) {
        HBox hbInput = JKLayout.getHBox (0, JKLayout.sp);
        hbInput.getChildren ().addAll (node, btn);
        return hbInput;
    }

    private Label getLblSep() {
        return JKText.getLblDk (" : ", JKText.FONT_B_14);
    }

    private GridPane getBoardAndDestinationEntry() {

        VBox vbHead = JKNode.getPutcoHeader ("Bus Ticket Booking - Step 1");

        Label lblRouteSelected = JKText.getLblDk ("Route Selected", JKText.FONT_B_XXSM);
        lblRouteSelected.setTranslateX (JKLayout.sp);
        Label lblRouteFrom = JKText.getLblDk ("From", JKText.FONT_B_XXSM);
        lblRouteFrom.setTranslateX (JKLayout.sp);
        Label lblRouteTo = JKText.getLblDk ("To", JKText.FONT_B_XXSM);
        lblRouteTo.setTranslateX (JKLayout.sp);

        double txtW = (JKLayout.contentW - (2 * JKLayout.sp)) * 0.75;
        txtRouteSelected = JKText.getTxtDkWrap ("...", JKText.FONT_B_15, txtW, TextAlignment.RIGHT);
        txtRouteFrom = JKText.getTxtDkWrap ("...", JKText.FONT_B_15, txtW, TextAlignment.RIGHT);
        txtRouteTo = JKText.getTxtDkWrap ("...", JKText.FONT_B_15, txtW, TextAlignment.RIGHT);

        Label lblOr = JKText.getLblDk ("OR", JKText.FONT_B_SM);
        lblOr.setMinWidth (JKLayout.contentW - (2 * JKLayout.sp));
        lblOr.setAlignment (Pos.CENTER);

        Label lblRoute = JKText.getLblDk (ROUTE_CODE, JKText.FONT_B_XSM);
        Label lblDepart = JKText.getLblDk (DEPARTURE, JKText.FONT_B_XSM);
        Label lblDest = JKText.getLblDk (DESTINATION, JKText.FONT_B_XSM);

        btnClearAll = getBtnClear ();

        GridPane grid = JKLayout.getGridContent2Col (0.25, 0.75, HPos.RIGHT);

        grid.add (vbHead, 0, 0, 2, 1);
        //
        grid.addRow (2, lblRouteSelected, txtRouteSelected);
        grid.addRow (3, lblRouteFrom, txtRouteFrom);
        grid.addRow (4, lblRouteTo, txtRouteTo);
        grid.add (JKNode.createGridSpanSep (2), 0, 5, 2, 1);
        //
        grid.add (getHBoxInput (JKNode.getHSpacer (), btnClearAll), 0, 6, 2, 1);
        grid.addRow (9, lblRoute, getInputRouteCode ());
        grid.add (lblOr, 0, 11, 2, 1);
        grid.addRow (13, lblDepart, getInputDeparture ());
        grid.addRow (14, lblDest, getInputDestination ());

        return grid;
    }

    private HBox getInputRouteCode() {
        txtRouteCode = new TextField ();
        HBox.setHgrow (txtRouteCode, Priority.ALWAYS);
        btnSearchRouteCode = getBtnSearch (ROUTE_CODE);

        txtRouteCode.setPromptText (PROMPT_ROUTE);
        txtRouteCode.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (txtRouteCode, "Enter Route Code", "", false, false, new KeyboardResult () {
                    @Override
                    public void onDone(String value) {
                        onEnterTxtRouteCode (value);
                    }
                });
            }
        });
        return getHBoxInput (txtRouteCode, btnSearchRouteCode);
    }

    private HBox getInputDeparture() {
        txtDeparture = new TextField ();
        HBox.setHgrow (txtDeparture, Priority.ALWAYS);
        btnSearchDeparture = getBtnSearch (DEPARTURE);

        txtDeparture.setPromptText (PROMPT_CITY);
        txtDeparture.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event evt) {
                onSearchCities (txtDeparture, ALL, DEPARTURE, "", listDepCities);
            }
        });
        return getHBoxInput (txtDeparture, btnSearchDeparture);
    }

    private HBox getInputDestination() {
        txtDestination = new TextField ();
        HBox.setHgrow (txtDestination, Priority.ALWAYS);
        btnSearchDestination = getBtnSearch (DESTINATION);

        txtDestination.setPromptText (PROMPT_CITY);
        txtDestination.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event evt) {
                onSearchCities (txtDestination, ALL, DESTINATION, "", listDestCities);
            }
        });
        return getHBoxInput (txtDestination, btnSearchDestination);
    }

    private void onSearchRoutes(TextField txtfld, String allOrSearched, String routeOrDepart,
                                String searchTerm, List<TicketProBusRouteCode> listRoutes) {
        switch (allOrSearched) {
            case ALL:
                showRoutesOrCities (txtfld, routeOrDepart, listRoutes, null);
                break;
            case SEARCHED:
                List<TicketProBusRouteCode> listSearched = searchRouteCodes (searchTerm, listRoutes);
                if (!listSearched.isEmpty ()) {
                    showRoutesOrCities (txtfld, routeOrDepart, listSearched, null);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Bus Route Codes",
                            "Search Term not found.  Please try again.", null);
                }
                break;
            default:
                break;
        }
    }

    private void onSearchCities(TextField txtfld, String allOrSearched, String departOrDest,
                                String searchTerm, List<String> listRoutes) {
        switch (allOrSearched) {
            case ALL:
                showRoutesOrCities (txtfld, departOrDest, null, listRoutes);
                break;
            case SEARCHED:
                List<String> listSearched = searchCities (searchTerm, listRoutes);
                if (!listSearched.isEmpty ()) {
                    showRoutesOrCities (txtfld, departOrDest, null, listSearched);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Bus Route Codes",
                            "Search Term not found.  Please try again.", null);
                }
                break;
            default:
                break;
        }
    }

    private List<TicketProBusRouteCode> searchRouteCodes(String searchTerm, List<TicketProBusRouteCode> listCodes) {
        List<TicketProBusRouteCode> listSearched = new ArrayList<> ();
        if (searchTerm.equals ("") || searchTerm.isEmpty ()) {
            listSearched.addAll (listCodes);
        } else {
            for (TicketProBusRouteCode l : listCodes) {
                if (l.toString ().toLowerCase (Locale.ENGLISH).contains (searchTerm.toLowerCase (Locale.ENGLISH))) {
                    listSearched.add (l);
                }
            }
        }
        return listSearched;
    }

    private List<String> searchCities(String searchTerm, List<String> listCities) {
        List<String> listSearched = new ArrayList<> ();
        if (searchTerm.equals ("") || searchTerm.isEmpty ()) {
            listSearched.addAll (listCities);
        } else {
            for (String l : listCities) {
                if (l.toLowerCase (Locale.ENGLISH).contains (searchTerm.toLowerCase (Locale.ENGLISH))) {
                    listSearched.add (l);
                }
            }
        }
        return listSearched;
    }

    private void showRoutesOrCities(TextField txtfld, String routeOrCity, List<TicketProBusRouteCode> listRoutes, List<String> listCities) {
        switch (routeOrCity) {
            case ROUTE_CODE:
                JKiosk3.getMsgBox ().showMsgBox ("Select " + routeOrCity, "", getPagedRoutes (listRoutes),
                        ROUTES_WIDTH, MessageBox.CONTROLS_SHOW, MessageBox.MSG_CANCEL, null);
                break;
            case DEPARTURE:
            case DESTINATION:
                JKiosk3.getMsgBox ().showMsgBox ("Select " + routeOrCity, "", getPagedCities (txtfld, routeOrCity, listCities),
                        CITIES_WIDTH, MessageBox.CONTROLS_SHOW, MessageBox.MSG_CANCEL, null);
                break;
            default:
                break;
        }
    }

    private PagedList getPagedRoutes(List<TicketProBusRouteCode> listCodes) {
        List<Node> listNodes = new ArrayList<> ();

        for (final TicketProBusRouteCode c : listCodes) {

            double lblBaseW = ROUTES_WIDTH - JKLayout.btnNumW - (4 * JKLayout.sp);

            Label lblCode = JKText.getLblDk (c.getRouteCode (), JKText.FONT_B_15);
            lblCode.setMaxWidth (lblBaseW * 0.06);
            lblCode.setMinWidth (lblBaseW * 0.06);
            lblCode.setTextOverrun (OverrunStyle.ELLIPSIS);

            Label lblDepart = JKText.getLblDk (c.getDeparture (), JKText.FONT_B_14);
            lblDepart.setMaxWidth (lblBaseW * 0.44);
            lblDepart.setMinWidth (lblBaseW * 0.44);
            lblDepart.setTextOverrun (OverrunStyle.ELLIPSIS);

            Label lblDest = JKText.getLblDk (c.getDestination (), JKText.FONT_B_14);
            lblDest.setMaxWidth (lblBaseW * 0.44);
            lblDest.setMinWidth (lblBaseW * 0.44);
            lblDest.setTextOverrun (OverrunStyle.ELLIPSIS);

            Button btn = JKNode.getBtnPopup ("select");
            btn.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event evt) {
                    onSelectRoute (c);
                }
            });

            HBox hb = JKLayout.getHBox (JKLayout.spNum, 0);
            hb.setId (c.getRouteId ());
            hb.setMaxWidth (ROUTES_WIDTH - (2 * JKLayout.sp));
            hb.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event evt) {
                    onSelectRoute (c);
                }
            });
            hb.getChildren ().addAll (lblCode, getLblSep (), lblDepart, getLblSep (), lblDest, btn);
            if (!c.getDeparture ().equals ("")) {
                listNodes.add (hb);
            }
        }
        PagedList paging = new PagedList (listNodes, 10, ROUTES_WIDTH);
        return paging;
    }

    private PagedList getPagedCities(final TextField txtfield, final String departOrDest, List<String> listCodes) {
        List<Node> listNodes = new ArrayList<> ();

        for (final String c : listCodes) {

            double lblBaseW = CITIES_WIDTH - JKLayout.btnNumW - (2 * JKLayout.sp);

            Label lblDepartOrDest = JKText.getLblDk ("", JKText.FONT_B_14);
            lblDepartOrDest.setMaxWidth (lblBaseW * 0.90);
            lblDepartOrDest.setMinWidth (lblBaseW * 0.90);
            lblDepartOrDest.setTextOverrun (OverrunStyle.ELLIPSIS);
            lblDepartOrDest.setText (c);

            Button btn = JKNode.getBtnPopup ("select");
            btn.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event evt) {
                    onSelectCity (txtfield, departOrDest, c);
                }
            });

            HBox hb = JKLayout.getHBox (JKLayout.spNum, 0);
            hb.setId (c);
            hb.setMaxWidth (CITIES_WIDTH - (2 * JKLayout.sp));
            hb.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event evt) {
                    onSelectCity (txtfield, departOrDest, c);
                }
            });
            hb.getChildren ().addAll (lblDepartOrDest, btn);
            if (!c.equals ("")) {
                listNodes.add (hb);
            }
        }
        PagedList paging = new PagedList (listNodes, 10, CITIES_WIDTH);
        return paging;
    }

    private void onSelectRoute(TicketProBusRouteCode route) {
        selectedRoute = route;
        txtRouteSelected.setText (selectedRoute.getRouteCode ());
        txtRouteFrom.setText (selectedRoute.getDeparture ());
        txtRouteTo.setText (selectedRoute.getDestination ());
        TicketProBusSale.getInstance ().setSelectedRouteCode (selectedRoute);
        txtRouteCode.setText (route.toString ());
        txtRouteCode.setDisable (true);
        txtDeparture.setDisable (true);
        txtDestination.setDisable (true);
        btnSearchRouteCode.setDisable (true);
        btnSearchDeparture.setDisable (true);
        btnSearchDestination.setDisable (true);

        JKiosk3.getMsgBox ().toBack ();
        JKiosk3.getMsgBox ().setVisible (false);
    }

    private void onSelectCity(final TextField txtfield, final String departOrDest, String route) {
        txtfield.setText (route);
        txtfield.setDisable (true);
        txtRouteCode.clear ();
        txtRouteCode.setDisable (true);
        btnSearchRouteCode.setDisable (true);
        switch (departOrDest) {
            case DEPARTURE:
                strDepart = route;
                btnSearchDeparture.setDisable (true);
                getListDestinations ();
                break;
            case DESTINATION:
                strDest = route;
                btnSearchDestination.setDisable (true);
                getListDepartures ();
                break;
            default:
                break;
        }
        checkIsRouteComplete ();
        JKiosk3.getMsgBox ().toBack ();
        JKiosk3.getMsgBox ().setVisible (false);
    }

    private void checkIsRouteComplete() {
        if (!strDepart.isEmpty ()) {
            txtRouteFrom.setText (strDepart);
        }
        if (!strDest.isEmpty ()) {
            txtRouteTo.setText (strDest);
        }
        if (!strDepart.isEmpty () && !strDest.isEmpty ()) {
            for (TicketProBusRouteCode c : listRouteCodes) {
                if (c.getDeparture ().equalsIgnoreCase (strDepart) && c.getDestination ().equalsIgnoreCase (strDest)) {
                    selectedRoute = c;
                    txtRouteSelected.setText (selectedRoute.getRouteCode ());
                    TicketProBusSale.getInstance ().setSelectedRouteCode (selectedRoute);
                    break;
                }
            }
        }
    }

    private void getRoutes() {
        TicketProBusRouteListReq req = new TicketProBusRouteListReq ();
        req.setIdDeparture ("");
        req.setIdDestination ("");
        req.setIdRoute (TicketProBusSale.getInstance ().getSelectedRouteCode ().getRouteCode ());

        TicketProUtilBus.getTicketProBusRouteList (req, new TicketProUtilBus.TicketProBusRouteListResult () {

            @Override
            public void tpBusRouteListResult(TicketProBusRouteListResp tpBusRouteListResp) {
                if (tpBusRouteListResp.isSuccess ()) {
                    StringBuilder sb = new StringBuilder ();
                    sb.append ("\r\n").append ("Bus Route items : ").append (tpBusRouteListResp.getListBusRoutes ().size ());
                    for (TicketProBusRoute r : tpBusRouteListResp.getListBusRoutes ()) {
                        sb.append ("\r\n").append ("Bus Route ID   : ").append (r.getRouteId ());
                        sb.append ("\r\n").append ("Bus Route Fare : ").append (r.getFare ());
                        sb.append ("\r\n").append ("- - - - - - - - - - - - - - - - - - - -");
                    }
                    logger.info (sb.toString ());
                    for (TicketProBusRouteCode c : listRouteCodes) {
                        if (tpBusRouteListResp.getListBusRoutes ().get (0).getRouteCode ().equalsIgnoreCase (c.getRouteCode ())) {
                            TicketProBusSale.getInstance ().setSelectedRouteCode (c);
                            break;
                        }
                    }
                    TicketProBusSale.getInstance ().setListRoutes (tpBusRouteListResp);
                    SceneSales.clearAndChangeContent (new TicketProBusBook2 ());
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Bus Routes", !tpBusRouteListResp.getAeonErrorText ().isEmpty () ?
                            "A" + tpBusRouteListResp.getAeonErrorCode () + " - " + tpBusRouteListResp.getAeonErrorText () :
                            "B" + tpBusRouteListResp.getErrorCode () + " - " + tpBusRouteListResp.getErrorText (), null);

                }
            }
        });
    }

    private void getListDepartures() {
        listDepCities.clear ();
        List<TicketProBusRouteCode> listSort = new ArrayList<> ();
        listSort.addAll (listRouteCodes);

        Collections.sort (listSort, new Comparator<TicketProBusRouteCode> () {
            @Override
            public int compare(TicketProBusRouteCode o1, TicketProBusRouteCode o2) {
                return o1.getDeparture ().compareTo (o2.getDeparture ());
            }
        });

        // put them in a LinkedHashMap to ensure that each item only appears once (no duplicates)
        Map<String, TicketProBusRouteCode> mapDepart = new LinkedHashMap<> ();
        for (TicketProBusRouteCode c : listSort) {
            if (!strDest.isEmpty ()) {
                if (c.getDestination ().equalsIgnoreCase (strDest)) {
                    mapDepart.put (c.getDeparture (), c);
                }
            } else {
                mapDepart.put (c.getDeparture (), c);
            }
        }
        for (String s : mapDepart.keySet ()) {
            listDepCities.add (s);
        }
    }

    private void getListDestinations() {
        listDestCities.clear ();
        List<TicketProBusRouteCode> listSort = new ArrayList<> ();
        listSort.addAll (listRouteCodes);

        Collections.sort (listSort, new Comparator<TicketProBusRouteCode> () {
            @Override
            public int compare(TicketProBusRouteCode o1, TicketProBusRouteCode o2) {
                return o1.getDestination ().compareTo (o2.getDestination ());
            }
        });

        // put them in a LinkedHashMap to ensure that each item only appears once (no duplicates)
        Map<String, TicketProBusRouteCode> mapDest = new LinkedHashMap<> ();
        for (TicketProBusRouteCode c : listSort) {
            if (!strDepart.isEmpty ()) {
                if (c.getDeparture ().equalsIgnoreCase (strDepart)) {
                    mapDest.put (c.getDestination (), c);
                }
            } else {
                mapDest.put (c.getDestination (), c);
            }
        }
        for (String r : mapDest.keySet ()) {
            listDestCities.add (r);
        }
    }

    private void onEnterTxtRouteCode(String value) {
        if (!value.equals ("")) {
            String code = value.toUpperCase (Locale.ENGLISH);
            if (isValidRouteCode (code)) {
                for (TicketProBusRouteCode c : listRouteCodes) {
                    if (code.equalsIgnoreCase (c.getRouteCode ())) {
                        onSelectRoute (c);
                        break;
                    }
                }
            } else {
                txtRouteCode.setDisable (false);
                txtRouteCode.clear ();
                txtRouteCode.setPromptText (PROMPT_ROUTE);
            }
        }
    }

    private void onClickSearch(final String searchType) {
        String srchInstruct = "Enter search text";
        if (searchType.equals (ROUTE_CODE)) {
            srchInstruct = "Enter search text  -  OR \nleave empty and press 'Enter' to see all Routes";
        }
        JKiosk3.getKeyboard ().showKeyboard (new TextField (), srchInstruct, "", false, false, new KeyboardResult () {

            @Override
            public void onDone(String value) {
                switch (searchType) {
                    case ROUTE_CODE:
                        onSearchRoutes (txtRouteCode, SEARCHED, ROUTE_CODE, value, listRouteCodes);
                        break;
                    case DEPARTURE:
                        onSearchCities (txtDeparture, SEARCHED, DEPARTURE, value, listDepCities);
                        break;
                    case DESTINATION:
                        onSearchCities (txtDestination, SEARCHED, DESTINATION, value, listDestCities);
                        break;
                    default:
                        break;
                }
            }
        });
    }

    private void onClickClear() {
        selectedRoute = null;
        strDepart = "";
        strDest = "";
        txtRouteSelected.setText ("...");
        txtRouteFrom.setText ("...");
        txtRouteTo.setText ("...");
        txtRouteCode.clear ();
        txtRouteCode.setPromptText (PROMPT_ROUTE);
        txtRouteCode.setDisable (false);
        btnSearchRouteCode.setDisable (false);
        txtDeparture.clear ();
        txtDeparture.setPromptText (PROMPT_CITY);
        txtDeparture.setDisable (false);
        btnSearchDeparture.setDisable (false);
        txtDestination.clear ();
        txtDestination.setPromptText (PROMPT_CITY);
        txtDestination.setDisable (false);
        btnSearchDestination.setDisable (false);
        getListDepartures ();
        getListDestinations ();
    }

    private boolean isValidRouteCode(String value) {
        if (value.matches ("\\D{1}\\d{3}") || value.matches ("\\d{4}")) {
            List<String> list = new ArrayList<> ();
            for (TicketProBusRouteCode c : listRouteCodes) {
                list.add (c.getRouteCode ());
            }
            if (!list.contains (value)) {
                JKiosk3.getMsgBox ().showMsgBox ("Invalid Route Code", value + "\n\nRoute Code not found."
                        + "\nUse 'search' if Code is not known.", null);

                return false;
            }
        } else {
            JKiosk3.getMsgBox ().showMsgBox ("Route ID", value + "\n\nInvalid Route Code entered", null);
            return false;
        }
        return true;
    }

    private boolean validateInput() {
        if (txtRouteCode.getText ().equals ("") && (txtDeparture.getText ().equals ("") || txtDestination.getText ().equals (""))) {
            JKiosk3.getMsgBox ().showMsgBox ("Select Routes", "Please enter a Route Code\n\nor\n\nSelect Departure and Destination", null);
            return false;
        }
        if (selectedRoute == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Select Routes", "Please enter required information", null);
            return false;
        }
        return true;
    }
}
