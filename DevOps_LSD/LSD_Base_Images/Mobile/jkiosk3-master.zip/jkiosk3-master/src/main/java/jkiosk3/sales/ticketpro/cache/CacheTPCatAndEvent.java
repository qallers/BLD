package jkiosk3.sales.ticketpro.cache;

import aeonticketpros.TicketProsCategoryList;
import aeonticketpros.TicketProsEventList;
import jkiosk3.store.Store;

public class CacheTPCatAndEvent {

    private static volatile TPCatAndEvent listTPCatAndEvent;

    private static TPCatAndEvent getListTPCatAndEvent() {
        if (listTPCatAndEvent == null) {
            listTPCatAndEvent = ((TPCatAndEvent) Store.loadObject(CacheTPCatAndEvent.class.getSimpleName()));
        }
        if (listTPCatAndEvent == null) {
            listTPCatAndEvent = new TPCatAndEvent();
        }
        return listTPCatAndEvent;
    }

    private static void saveListTPCatAndEvent(TPCatAndEvent listCatAndEvent) {
        Store.saveObject(CacheTPCatAndEvent.class.getSimpleName(), listCatAndEvent);
    }

    public static void saveTPCategoriesAndEvents(TicketProsCategoryList listTPCategories, TicketProsEventList listTPEvents) {
        getListTPCatAndEvent();
        listTPCatAndEvent.setListTPCategories(listTPCategories);
        listTPCatAndEvent.setListTPEvents(listTPEvents);
        saveListTPCatAndEvent(listTPCatAndEvent);
    }

    public static boolean hasCategoryItems() {
        getListTPCatAndEvent();
        return !listTPCatAndEvent.getListTPCategories().getListCategories().isEmpty();
    }

    public static boolean hasEventItems() {
        getListTPCatAndEvent();
        return !listTPCatAndEvent.getListTPEvents().getListEvents().isEmpty();
    }

    public static TicketProsCategoryList getListTPCategories() {
        getListTPCatAndEvent();
        return listTPCatAndEvent.getListTPCategories();
    }

    public static TicketProsEventList getListTPEvents() {
        getListTPCatAndEvent();
        return listTPCatAndEvent.getListTPEvents();
    }

    public static void deleteCacheTPCatAndEvent() {
        Store.deleteObject(CacheTPCatAndEvent.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheTPCatAndEvent.class.getSimpleName());
    }
}
