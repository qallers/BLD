package jkiosk3.users;

import aeonprinting.AeonPrintJob;
import aeonusers.User;
import aeonusers.UserListResp;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._components.ControlButtons;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.print_layouts.PrintAssorted;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class UserListPrint extends Region {

    private UserListResp userListResp;
//    private List<User> listUsersCurrent;
//    private List<User> listSort;
//    private ToggleGroup toggle;
//    private RadioButton radName;
//    private RadioButton radPin;

    public UserListPrint() {
        UserUtil.getUserListResp(CurrentUser.getUser().getUserPin(), new UserUtil.UserListRespResult() {
            @Override
            public void userListRespResult(UserListResp userListResponse) {
                if (userListResponse.isSuccess()) {
                    userListResp = userListResponse;
                    CurrentUser.setSalesUser(CurrentUser.getUser());

                    VBox vbHead = JKNode.getPageHeadVB("Print User List");

                    VBox vb = JKLayout.getVBoxContent(JKLayout.spNum);
//                    vb.getChildren().addAll(getListPrintSelection(), getControlButtons());
                    vb.getChildren().addAll(vbHead);

                    VBox vbContent = JKLayout.getVBox(0, JKLayout.spNum);
                    vbContent.getChildren().addAll(vb, getControlButtons());

                    getChildren().addAll(vbContent);
                }
            }
        });
//        UserUtil.getOnlineUsersList(CurrentUser.getUser().getUserPin(), new UserUtil.ListUsersResult() {
//
//            @Override
//            public void listUsersResult(List<User> listUsersResult) {
//                if (!listUsersResult.isEmpty()) {
//                    listUsersCurrent = listUsersResult;
//                    CurrentUser.setSalesUser(CurrentUser.getUser());
//
//                    VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
//                    vb.getChildren().addAll(getListPrintSelection(), getControlButtons());
//
//                    listSort = sortUserList();
//
//                    getChildren().add(vb);
//                }
//            }
//        });
    }

//    private GridPane getListPrintSelection() {
//
//        double w = JKLayout.contentW;
//
//        VBox vbHead = JKNode.getPageHeadVB("Print User List");
//
//        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);
//
//        Label lblNoSort = JKText.getLblDk("Please note that sorting is no longer available!", JKText.FONT_B_XSM);
//
//        Label lblSortBy = JKText.getLblDk("Sort By", JKText.FONT_B_XSM);
//        lblSortBy.setMinWidth(JKLayout.btnSmW);
//        lblSortBy.setDisable(true);
//
//        toggle = new ToggleGroup();
//
//        radName = new RadioButton("Name");
//        radName.setDisable(true);
//        radName.setToggleGroup(toggle);
//        radName.setSelected(true);
////        radName.setOnMouseReleased(new EventHandler() {
////            @Override
////            public void handle(Event e) {
////                listSort = sortUserList();
////            }
////        });
//
//        radPin = new RadioButton("PIN Prefix");
//        radPin.setDisable(true);
//        radPin.setToggleGroup(toggle);
////        radPin.setOnMouseReleased(new EventHandler() {
////            @Override
////            public void handle(Event e) {
//////                listSort = sortUserList();
////            }
////        });
//
//        HBox hbSortBy = JKLayout.getHBox(0, JKLayout.sp);
//        hbSortBy.setMaxWidth(w * 0.75);
//        hbSortBy.getChildren().addAll(radName, JKNode.getHSpacer(), radPin, JKNode.getHSpacer());
//
//        grid.add(vbHead, 0, 0, 2, 1);
//
////        grid.add(lblNoSort, 0, 2, 2, 1);
////
////        grid.addRow(4, lblSortBy, hbSortBy);
//
//        return grid;
//    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons();

        ctrlBtns.getBtnAccept().setText("Print");
        ctrlBtns.getBtnAccept().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                AeonPrintJob apj = PrintAssorted.getPrintUserList(sortUserList(userListResp.getListUsers()));
                PrintHandler.handlePrintRequestReport("User List", apj);
//                AeonPrintJob apjUsers = userListResp.getAeonPrintJob();
//                PrintHandler.handlePrintRequestReport("User List", apjUsers);
            }
        });
        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneUsers.getVbUsersContent().getChildren().clear();
            }
        });

        return ctrlBtns;
    }

    private List<User> sortUserList(List<User> listUsersCurrent) {
        List<User> sorted = listUsersCurrent;
        Collections.sort(sorted, new Comparator<User>() {
            @Override
            public int compare(User u1, User u2) {
                return u1.getUserPin().compareTo(u2.getUserPin());
            }
        });
        return sorted;
    }
}
