package jkiosk3.sales.billpay.syntell;

import aeonbillpayments.syntell.SyntellAccPayReq;
import aeonbillpayments.syntell.SyntellAccPayResp;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3.sales._common.JKTenderToggles;

public class SummarySyntellBillPay extends Region {

    private final SyntellAccPayReq req2;
    private final SyntellAccPayResp resp2;

    public SummarySyntellBillPay(SyntellAccPayReq rq2, SyntellAccPayResp rs2) {
        this.req2 = rq2;
        this.resp2 = rs2;
        getChildren().add(getSummaryGrid());
    }

    private GridPane getSummaryGrid() {
        GridPane grid = JKLayout.getSummaryGrid2Col(0.4, 0.6);
        grid.setTranslateX(-JKLayout.sp);

        Label lblPaying = JKText.getLblDk("Account Number", JKText.FONT_B_XSM);
        Label lblReceiptNum = JKText.getLblDk("Receipt Number", JKText.FONT_B_XSM);
        Label lblTenderType = JKText.getLblDk("Tender Type", JKText.FONT_B_XSM);
        Label lblAmount = JKText.getLblDk("Amount", JKText.FONT_B_XSM);
        Label lblConvenienceFee = JKText.getLblDk("ConvenienceFee", JKText.FONT_B_XSM);
        Label lblTotalPayable = JKText.getLblDk("Total Payable", JKText.FONT_B_XSM);

        // filled-in fields
        Text txtAccNum = JKText.getTxtDk(req2.getAccountNo(), JKText.FONT_B_XSM);
        Text txtReceiptNum = JKText.getTxtDk(resp2.getReceiptNo(), JKText.FONT_B_XSM);

        String txtTender = JKTenderToggles.getTxtForTender(req2.getTenderType());
        Text txtTenderType = JKText.getTxtDk(txtTender, JKText.FONT_B_XSM);
        Text txtAmount = JKText.getTxtDk(JKText.getDeciFormat(req2.getAmount()), JKText.FONT_B_XSM);
        Text txtConvenienceFee = JKText.getTxtDk(JKText.getDeciFormat(resp2.getConvenienceFee()), JKText.FONT_B_XSM);
        double totalPayable = resp2.getAmountPaid() + resp2.getConvenienceFee();
        Text txtTotalPayable = JKText.getTxtDk(JKText.getDeciFormat(totalPayable), JKText.FONT_B_SM);

        grid.addRow(0, lblPaying, txtAccNum);
        grid.addRow(1, lblReceiptNum, txtReceiptNum);
        grid.addRow(2, lblTenderType, txtTenderType);
        grid.addRow(3, lblAmount, txtAmount);
        grid.addRow(4, lblConvenienceFee, txtConvenienceFee);
        grid.addRow(5, lblTotalPayable, txtTotalPayable);

        return grid;
    }
}
