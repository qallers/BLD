package jkiosk3.store.cache;

import aeonticketpros.bus.TicketProBusRouteCode;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author valeriew
 */
public class ListPutcoRoutes implements Serializable {

    private final static long serialVersionUID = 10001L;

    private final List<TicketProBusRouteCode> listPutcoRouteCodes = new ArrayList<>();

    public List<TicketProBusRouteCode> getListPutcoRouteCodes() {
        return listPutcoRouteCodes;
    }
}
