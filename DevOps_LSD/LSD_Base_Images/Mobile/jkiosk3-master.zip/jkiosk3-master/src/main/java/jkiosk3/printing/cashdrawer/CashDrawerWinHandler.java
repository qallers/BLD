package jkiosk3.printing.cashdrawer;

import Download.HttpUtils;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

/**
 *
 *
 */
public class CashDrawerWinHandler {

    private final static Logger logger = Logger.getLogger(CashDrawerWinHandler.class.getName());
//    public final static String PRINT_CODES_DEV = "http://196.38.158.113/touchscreen/jkiosk3_demo/jk3printcodes.xml";
//    public final static String PRINT_CODES_LIVE = "http://196.38.158.102/touchscreen/jkiosk3/jk3printcodes.xml";
    private final static String INSTALL_PATH_PRINT = "printer\\";
//    public final static String FILENAME_PRINT = "jk3printcodes.xml";
    private List<CashDrawerWindows> listWinPrinters;
    private static CashDrawerWinHandler instance;

    public static CashDrawerWinHandler getInstance() {
        if (instance == null) {
            System.out.println("cashdrawer instance is NULL");
            instance = new CashDrawerWinHandler();
        } else {
            System.out.println("cashdrawer instance is NOT NULL");
        }
        return instance;
    }

    private CashDrawerWinHandler() {
        createPrinterFolder(INSTALL_PATH_PRINT);
//        if (HttpUtils.httpDownload(JK3Config.getPrintcodesDownloadPath(), INSTALL_PATH_PRINT + JK3Config.getPrintcodesFile(), true, null)) {
            makeCashDrawerWinList();
//        } else {
//            JKiosk3.getMsgBox().showMsgBox("Printers for Cash Drawer Control", "Unable to download updated Cash Drawer config file.\n\n"
//                    + "Your Cash Drawer may not work correctly!", null,
//                    MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
//
//                        @Override
//                        public void onOk() {
//                            makeCashDrawerWinList();
//                        }
//
//                        @Override
//                        public void onCancel() {
//                            //
//                        }
//                    });
//        }
    }

    public static void createPrinterFolder(String folderPath) {
        File f = new File(folderPath);
        try {
            if (!f.exists()) {
                f.mkdirs();
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
    }

    private void makeCashDrawerWinList() {
        listWinPrinters = processPrintCodes();
        if (listWinPrinters != null) {
            if (listWinPrinters.isEmpty()) {
                JKiosk3.getMsgBox().showMsgBox("Cash Drawer", "Cash Drawer list is empty.\n\nYour Cash Drawer may not work.", null);
            }
        } else {
            JKiosk3.getMsgBox().showMsgBox("Cash Drawer", "Unable to load Cash Drawer config file.\n\nPlease check your connection.", null);
        }
    }

    private List<CashDrawerWindows> processPrintCodes() {
        List<CashDrawerWindows> listPrinters = new ArrayList<>();
        try {
            File file = new File(INSTALL_PATH_PRINT + JK3Config.getPrintcodesFile());
            Element printers = new SAXBuilder().build(file).getRootElement().getChild("printers");
            for (Object print : printers.getChildren("printwin")) {
                Element printer = (Element) print;

                CashDrawerWindows printWin = new CashDrawerWindows();
                printWin.setPrinterModel(printer.getChildTextTrim("model"));
                printWin.setCashDrawerCodes(printer.getChildTextTrim("cashdrawercodes"));

                listPrinters.add(printWin);
            }
        } catch (JDOMException | IOException e) {
            JKiosk3.getMsgBox().showMsgBox("Printers", e.getMessage(), null);
        }
        return listPrinters;
    }

    public List<CashDrawerWindows> getListWinPrinters() {
        return listWinPrinters;
    }
}
