package jkiosk3._components.update;

import javafx.scene.layout.Region;

/**
 *
 * @author valeriew
 */
public class DownloadRegion extends Region {

    public void setContent(Region content) {
        getChildren().clear();
        getChildren().add(content);
    }
}
