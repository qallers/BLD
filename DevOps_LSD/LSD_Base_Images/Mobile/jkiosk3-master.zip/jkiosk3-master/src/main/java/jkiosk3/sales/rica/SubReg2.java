package jkiosk3.sales.rica;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;

/**
 *
 * @author Val
 */
public class SubReg2 extends Region {

    private ComboBox comTitle;
    private TextField txtFirstNames;
    private TextField txtSurname;
    private ToggleButton toggleIdNumber;
    private ToggleButton togglePassport;
    private TextField txtIdentification;
    private TextField txtNationality;
    private CheckBox chkIdVerified;

    public SubReg2() {
        setId(SubAll.REG_PG_2);

        getChildren().add(getSubPg2());
    }

    private GridPane getSubPg2() {
        GridPane grid = JKLayout.getContentGridInner2Col(0.33, 0.67);

        double w = JKLayout.contentW;

        Label lblTitle = JKText.getLblDk("Title", JKText.FONT_B_XSM);
        lblTitle.setPrefWidth(JKLayout.btnSmW);
        Label lblFirstNames = JKText.getLblDk("First Names", JKText.FONT_B_XSM);
        Label lblSurname = JKText.getLblDk("Surname", JKText.FONT_B_XSM);
        Label lblIdentification = JKText.getLblDk("Identification", JKText.FONT_B_XSM);
        Label lblNationality = JKText.getLblDk("Nationality", JKText.FONT_B_XSM);

        comTitle = new ComboBox();
        comTitle.setPrefWidth(((w - (2 * JKLayout.sp)) * 0.67));
        comTitle.getItems().addAll("Mr", "Ms", "Miss", "Mrs", "Sir", "Dr", "Prof");

        txtFirstNames = new TextField();
        GridPane.setHgrow(txtFirstNames, Priority.ALWAYS);
        txtFirstNames.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtFirstNames, "Subscriber First Names", txtFirstNames.getText(), false);
            }
        });

        txtSurname = new TextField();
        GridPane.setHgrow(txtSurname, Priority.ALWAYS);
        txtSurname.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtSurname, "Subscriber Surname", txtSurname.getText(), false);
            }
        });

        txtNationality = new TextField();
        txtNationality.setText("ZA - South Africa");
        HBox.setHgrow(txtNationality, Priority.ALWAYS);
        txtNationality.setDisable(true);

        Button btnCodes = JKNode.getBtnPopup("code");
        btnCodes.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                Region codes = new CountryCodeList(txtNationality, CountryCodes.COUNTRY_NAME);
                JKiosk3.getMsgBox().showMsgBox("select country code", "", codes, MessageBox.CONTROLS_HIDE,
                        MessageBox.MSG_OK, null);
            }
        });

        HBox hbNationality = JKLayout.getHBox(0, 5);
        hbNationality.setPrefWidth(((w - (3 * JKLayout.sp)) * 0.67));
        hbNationality.getChildren().addAll(txtNationality, btnCodes);

        chkIdVerified = new CheckBox("Applicant ID Visually Verified");

        grid.add(lblTitle, 0, 0);
        grid.add(lblFirstNames, 0, 1);
        grid.add(lblSurname, 0, 2);
        grid.add(lblIdentification, 0, 4);
        grid.add(lblNationality, 0, 6);

        grid.add(comTitle, 1, 0);
        grid.add(txtFirstNames, 1, 1);
        grid.add(txtSurname, 1, 2);
        grid.add(JKNode.createGridSpanSep(2), 1, 3);
        grid.add(getIdBox(), 1, 4);
        grid.add(JKNode.createGridSpanSep(2), 1, 5);
        grid.add(hbNationality, 1, 6);
        grid.add(chkIdVerified, 1, 7);

        return grid;
    }

    private VBox getIdBox() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        ToggleGroup toggleIdPassport = new ToggleGroup();

        toggleIdNumber = JKNode.getToggleSmDbl("ID Number");
        toggleIdNumber.setToggleGroup(toggleIdPassport);

        togglePassport = JKNode.getToggleSmDbl("Passport Number");
        togglePassport.setToggleGroup(toggleIdPassport);

        HBox hb = JKLayout.getHBox(0, JKLayout.sp);
        hb.getChildren().addAll(toggleIdNumber, togglePassport);

        txtIdentification = new TextField();
        txtIdentification.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtIdentification, "Subscriber ID / Passport Number",
                        txtIdentification.getText(), false);
            }
        });

        vb.getChildren().addAll(hb, txtIdentification);

        return vb;
    }

    public ComboBox getComTitle() {
        return comTitle;
    }

    public CheckBox getChkIdVerified() {
        return chkIdVerified;
    }

    public ToggleButton getToggleIdNumber() {
        return toggleIdNumber;
    }

    public ToggleButton getTogglePassport() {
        return togglePassport;
    }

    public TextField getTxtFirstNames() {
        return txtFirstNames;
    }

    public TextField getTxtIdentification() {
        return txtIdentification;
    }

    public TextField getTxtNationality() {
        return txtNationality;
    }

    public TextField getTxtSurname() {
        return txtSurname;
    }

    public boolean validatePg2() {
        boolean validPg2 = false;
        if (!toggleIdNumber.isSelected() && !togglePassport.isSelected()) {
            validPg2 = false;
            JKiosk3.getMsgBox().showMsgBox("Registration error", "Either 'ID Number' or 'Passport Number' "
                    + "button must be selected", null);
        } else if (txtIdentification.getText().equals("") || txtNationality.getText().equals("")) {
            validPg2 = false;
            JKiosk3.getMsgBox().showMsgBox("Registration error", "New Owner Identification and Nationality required", null);
        } else {
            validPg2 = true;
        }
        return validPg2;
    }
}
