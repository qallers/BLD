package jkiosk3.sales.ticketpro;

import aeonprinting.AeonPrintJob;
import aeonticketpros.TicketProsCart;
import aeonticketpros.TicketProsCartClearReq;
import aeonticketpros.TicketProsCheckoutReq;
import aeonticketpros.TicketProsCheckoutResp;
import aeonticketpros.TicketProsPaymentReq;
import aeonticketpros.TicketProsPaymentResp;
import aeonticketpros.TicketProsPrintReq;
import aeonticketpros.TicketProsPrintResp;
import aeonticketpros.bus.*;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import javafx.concurrent.Worker.State;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.PrintUtil;
import jkiosk3.printing.print_layouts.PrintTicketPro;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.sales.ticketpro.sale_bus.TicketProBusBook1;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.store.cache.CacheListPutcoRoutes;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

public class TicketProUtilBus {

    private final static Logger logger = Logger.getLogger(TicketProUtilBus.class.getName());
    //
    private static TicketProConnectionBus tpConnBus;
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 90;

    public static TicketProConnectionBus getTicketProConnectionBus() {
        TicketProConnectionBus tpConnectBus = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            tpConnectBus = new TicketProConnectionBus(server, port, secureConnect);
            tpConnectBus.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return tpConnectBus;
    }

    public static boolean isLoggedIn(String pin) throws RuntimeException {
        String loyaltyProfileId = "";
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            loyaltyProfileId = ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId();
        }

        boolean loggedIn = false;
        int deviceId = JKSystem.getSystemConfig().getDeviceId();
        String serial = JKSystem.getSystemConfig().getSerial();
        tpConnBus = getTicketProConnectionBus();

        try {
            loggedIn = tpConnBus.login(pin, deviceId, serial, loyaltyProfileId);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    private static List<TicketProBusRouteCode> getTicketProBusRouteCodeList() {
        List<TicketProBusRouteCode> listRouteCodes = new ArrayList<>();
        if (CacheListPutcoRoutes.hasItems()) {
            listRouteCodes = CacheListPutcoRoutes.getListPutcoRouteCodes();
        } else {
            TicketProBusRouteCodeList listRoutes = getOnlineTicketProBusRouteCodeList();
            listRouteCodes = listRoutes.getListBusRouteCodes();
            Collections.sort(listRouteCodes, new Comparator<TicketProBusRouteCode>() {
                @Override
                public int compare(TicketProBusRouteCode o1, TicketProBusRouteCode o2) {
                    return o1.getRouteCode().compareTo(o2.getRouteCode());
                }
            });
        }
        return listRouteCodes;
    }

    private static TicketProBusRouteCodeList getOnlineTicketProBusRouteCodeList() throws RuntimeException {
        TicketProBusRouteCodeList listRouteCode = null;
        try {
            if (isLoggedIn(CurrentUser.getSalesUser().getUserPin())) {
                listRouteCode = tpConnBus.getBusRouteCodesList();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Bus Route Code List Error", t);
        } finally {
            if (tpConnBus != null) {
                tpConnBus.disconnect();
            }
        }
        return listRouteCode;
    }

    private static TicketProBusRouteListResp getTicketProBusRouteList(TicketProBusRouteListReq req) throws RuntimeException {
        TicketProBusRouteListResp resp = new TicketProBusRouteListResp();
        String userPin = CurrentUser.getSalesUser().getUserPin();

        try {
            if (isLoggedIn(userPin)) {
                resp = tpConnBus.getBusRouteList(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Bus Routes List Error", t);
        } finally {
            if (tpConnBus != null) {
                tpConnBus.disconnect();
            }
        }

        return resp;
    }

    private static TicketProsCart createTicketProBusCart() throws RuntimeException {
        TicketProsCart cart = new TicketProsCart();
        String userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                cart = tpConnBus.createTicketProBusCart();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Create Cart Error", t);
        }
        // do not disconnect - keep connection open from here to process end.
        return cart;
    }

    private static TicketProBusRouteBookResp getTicketProBusRouteBooking(TicketProBusRouteBookReq req) throws RuntimeException {
        TicketProBusRouteBookResp resp = new TicketProBusRouteBookResp();
        String userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                resp = tpConnBus.getTicketProBusRouteBook(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Reserve Seats Error", t);
        }

        return resp;
    }

    private static TicketProBusCartClearResp clearBusCart(TicketProsCartClearReq req) throws RuntimeException {
        TicketProBusCartClearResp resp = new TicketProBusCartClearResp();
        String userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                resp = tpConnBus.clearTicketProBusCart(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Clear Cart Error", t);
        }

        return resp;
    }

    private static TicketProsCheckoutResp checkoutTicketProBus(TicketProsCheckoutReq req) throws RuntimeException {
        TicketProsCheckoutResp resp = null;
        String userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                resp = tpConnBus.checkoutBusTickets(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Checkout Error", t);
        }
        return resp;
    }

//    private static TicketProsPaymentResp getTicketProBusPaymentResp(int count, TicketProsPaymentReq req) throws RuntimeException {
//        TicketProsPaymentResp resp = null;
//        try {
//            if (count == 1) {
//                resp = tpConnBus.makePaymentBusTickets(req);
//            } else {
//                String userPin = CurrentUser.getSalesUser().getUserPin();
//                if (isLoggedIn(userPin)) {
//                    resp = tpConnBus.makePaymentBusTickets(req);
//                }
//            }
//        } catch (Throwable t) {
//            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
//            logger.log(Level.SEVERE, t.getMessage(), t);
//            throw new RuntimeException("TicketPro Payment Error", t);
//        }
//        return resp;
//    }

    private static TicketProsPaymentResp getTicketProBusPaymentResp(TicketProsPaymentReq req) throws RuntimeException {
        TicketProsPaymentResp resp = null;
        try {
                resp = tpConnBus.makePaymentBusTickets(req);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Payment Error", t);
        }
        return resp;
    }

//    private static TicketProsPrintResp getTicketProBusPrint(int count, TicketProsPrintReq req) throws RuntimeException {
//        TicketProsPrintResp resp = null;
//        try {
//            if (count == 1) {
//                resp = tpConnBus.getBusTicketPrint(req);
//            } else {
//                String userPin = CurrentUser.getSalesUser().getUserPin();
//                if (isLoggedIn(userPin)) {
//                    resp = tpConnBus.getBusTicketPrint(req);
//                }
//            }
//        } catch (Throwable t) {
//            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
//            logger.log(Level.SEVERE, t.getMessage(), t);
//            throw new RuntimeException("TicketPro Print Error", t);
//        } finally {
//            if (tpConnBus != null) {
//                tpConnBus.disconnect();
//            }
//        }
//        return resp;
//    }

    private static TicketProsPrintResp getTicketProBusPrint(TicketProsPrintReq req) throws RuntimeException {
        TicketProsPrintResp resp = null;
        try {
                resp = tpConnBus.getBusTicketPrint(req);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Print Error", t);
        } finally {
            if (tpConnBus != null) {
                tpConnBus.disconnect();
            }
        }
        return resp;
    }

    private static TicketProBusAutoCancelResp getTicketProBusAutoCancelResp(TicketProBusAutoCancelReq req) throws RuntimeException {
        TicketProBusAutoCancelResp resp = null;
        tpConnBus = getTicketProConnectionBus();
        try {
            resp = tpConnBus.getBusTicketAutoCancel(req);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Auto Cancel Error", t);
        } finally {
            if (tpConnBus != null) {
                tpConnBus.disconnect();
            }
        }
        return resp;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getTicketProBusRouteCodeList(final TicketProBusRouteCodeListResult result) {
        JKiosk3.getBusy().showBusy("Getting TicketPro Bus Route Code List");

        final Task<List<TicketProBusRouteCode>> taskRouteCode = new Task<List<TicketProBusRouteCode>>() {
            @Override
            protected List<TicketProBusRouteCode> call() throws Exception {
                return getTicketProBusRouteCodeList();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpBusRouteCodeListResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Bus Route Code List",
                        "Unable to retrieve Bus Route Code List", State.CANCELLED, errorMsg, new TicketProBusBook1());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Bus Route Code List",
                        "Unable to retrieve Bus Route Code List", State.FAILED, errorMsg, new TicketProBusBook1());
            }
        };
        new Thread(taskRouteCode).start();
        JKiosk3.getBusy().startCountdown(taskRouteCode, countdownTime);
    }

    public static void getTicketProBusRouteList(final TicketProBusRouteListReq req, final TicketProBusRouteListResult result) {
        JKiosk3.getBusy().showBusy("Getting TicketPro Bus Route List");

        final Task<TicketProBusRouteListResp> taskBusRouteList = new Task<TicketProBusRouteListResp>() {
            @Override
            protected TicketProBusRouteListResp call() throws Exception {
                return getTicketProBusRouteList(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpBusRouteListResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Bus Route List",
                        "Unable to retrieve Bus Route List", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Bus Route List",
                        "Unable to retrieve Bus Route List", State.FAILED, errorMsg, new TicketProMenu());
            }
        };
        new Thread(taskBusRouteList).start();
        JKiosk3.getBusy().startCountdown(taskBusRouteList, countdownTime);
    }

    public static void createTicketProBusCart(final TicketProBusCreateCartResult result) {
        JKiosk3.getBusy().showBusy("Creating TicketPro Bus Cart");

        final Task<TicketProsCart> taskBusCart = new Task<TicketProsCart>() {
            @Override
            protected TicketProsCart call() throws Exception {
                return createTicketProBusCart();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpCreateBusCartResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Bus Cart",
                        "Unable to create Cart", Worker.State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Bus Cart",
                        "Unable to create Cart", Worker.State.FAILED, errorMsg, new TicketProMenu());
            }
        };
        new Thread(taskBusCart).start();
        JKiosk3.getBusy().startCountdown(taskBusCart, countdownTime);
    }

    public static void getTicketProBusRouteBooking(final TicketProBusRouteBookReq req, final TicketProBusRouteBookResult result) {
        JKiosk3.getBusy().showBusy("Reserving TicketPro Bus Seats");

        final Task<TicketProBusRouteBookResp> taskBusSeatsReserve = new Task<TicketProBusRouteBookResp>() {
            @Override
            protected TicketProBusRouteBookResp call() throws Exception {
                return getTicketProBusRouteBooking(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpBusRouteBookResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Bus Seats",
                        "Error Reserving Bus Seats", Worker.State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Bus Seats",
                        "Error Reserving Bus Seats", Worker.State.FAILED, errorMsg, new TicketProMenu());
            }
        };
        new Thread(taskBusSeatsReserve).start();
        JKiosk3.getBusy().startCountdown(taskBusSeatsReserve, countdownTime);
    }

    public static void clearBusCart(final TicketProsCartClearReq req, final TicketProBusClearCartResult result) {
        JKiosk3.getBusy().showBusy("Clearing TicketPro Cart");

        final Task<TicketProBusCartClearResp> taskTPCartClear = new Task<TicketProBusCartClearResp>() {
            @Override
            protected TicketProBusCartClearResp call() throws Exception {
                return clearBusCart(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpClearBusCartResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Clear Cart",
                        "Error Clearing Cart", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Clear Cart",
                        "Error Clearing Cart", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPCartClear).start();
        JKiosk3.getBusy().startCountdown(taskTPCartClear, countdownTime);
    }

    public static void checkoutTicketProBus(final TicketProsCheckoutReq req, final TicketProBusCheckoutResult result) {
        JKiosk3.getBusy().showBusy("Checkout TicketPro Cart");

        final Task<TicketProsCheckoutResp> taskTPCheckoutBus = new Task<TicketProsCheckoutResp>() {
            @Override
            protected TicketProsCheckoutResp call() throws Exception {
                return checkoutTicketProBus(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpCheckoutBusResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Checkout",
                        "Error Processing Checkout", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Checkout",
                        "Error Processing Checkout", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPCheckoutBus).start();
        JKiosk3.getBusy().startCountdown(taskTPCheckoutBus, countdownTime);
    }

//    public static void getTicketProBusPaymentResp(final int count, final TicketProsPaymentReq req, final TicketProBusPaymentResult result) {
//        JKiosk3.getBusy().showBusy("Processing TicketPro Payment");
//
//        final Task<TicketProsPaymentResp> taskTPPaymentBus = new Task<TicketProsPaymentResp>() {
//            @Override
//            protected TicketProsPaymentResp call() throws Exception {
//                return getTicketProBusPaymentResp(count, req);
//            }
//
//            @Override
//            protected void succeeded() {
//                JKiosk3.getBusy().hideBusy();
//                result.tpBusPaymentResult(getValue());
//            }
//
//            @Override
//            protected void cancelled() {
//                errorOnPayment(count, req, State.CANCELLED, result);
//            }
//
//            @Override
//            protected void failed() {
//                errorOnPayment(count, req, State.FAILED, result);
//            }
//        };
//
//        new Thread(taskTPPaymentBus).start();
//        JKiosk3.getBusy().startCountdown(taskTPPaymentBus, countdownTime);
//    }

    public static void getTicketProBusPaymentResp(final TicketProsPaymentReq req, final TicketProBusPaymentResult result) {
        JKiosk3.getBusy().showBusy("Processing TicketPro Payment");

        final Task<TicketProsPaymentResp> taskTPPaymentBus = new Task<TicketProsPaymentResp>() {
            @Override
            protected TicketProsPaymentResp call() throws Exception {
                return getTicketProBusPaymentResp(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpBusPaymentResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Payment",
                        "Error Processing Payment", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Payment",
                        "Error Processing Payment", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPPaymentBus).start();
        JKiosk3.getBusy().startCountdown(taskTPPaymentBus, countdownTime);
    }

//    public static void getTicketProBusPrint(final int count, final TicketProsPrintReq req,
//                                            final TicketProBusTicketPrintResult result) {
//        JKiosk3.getBusy().showBusy("Getting TicketPro Print");
//
//        final Task<TicketProsPrintResp> taskTPPrint = new Task<TicketProsPrintResp>() {
//            @Override
//            protected TicketProsPrintResp call() throws Exception {
//                return getTicketProBusPrint(count, req);
//            }
//
//            @Override
//            protected void succeeded() {
//                JKiosk3.getBusy().hideBusy();
//                result.tpBusTicketPrintResult(getValue());
//            }
//
//            @Override
//            protected void cancelled() {
//                errorOnPrint(count, req, State.CANCELLED, result);
//            }
//
//            @Override
//            protected void failed() {
//                errorOnPrint(count, req, State.FAILED, result);
//            }
//        };
//
//        new Thread(taskTPPrint).start();
//        JKiosk3.getBusy().startCountdown(taskTPPrint, countdownTime);
//    }

    public static void getTicketProBusPrint(final TicketProsPrintReq req,
                                            final TicketProBusTicketPrintResult result) {
        JKiosk3.getBusy().showBusy("Getting TicketPro Print");

        final Task<TicketProsPrintResp> taskTPPrint = new Task<TicketProsPrintResp>() {
            @Override
            protected TicketProsPrintResp call() throws Exception {
                return getTicketProBusPrint(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpBusTicketPrintResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("TicketPro Print",
                        "Error Processing Print", State.CANCELLED, errorMsg, new TicketProMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("TicketPro Print",
                        "Error Processing Print", State.FAILED, errorMsg, new TicketProMenu());
            }
        };

        new Thread(taskTPPrint).start();
        JKiosk3.getBusy().startCountdown(taskTPPrint, countdownTime);
    }

    public static void getTicketProBusAutoCancel(final TicketProBusAutoCancelReq cancelRequest, final TicketProPutcoAutoCancelResult result) {

        JKiosk3.getBusy().showBusy("Cancelling Unsuccessful Putco Ticket");

        final Task<TicketProBusAutoCancelResp> taskAutoCancel = new Task<TicketProBusAutoCancelResp>() {
            @Override
            protected TicketProBusAutoCancelResp call() throws Exception {
                return getTicketProBusAutoCancelResp(cancelRequest);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.tpBusTicketAutoCancelResult(getValue());
            }

            @Override
            protected void cancelled() {
                showCancelledFailedAutoCancel("Auto Cancel", State.CANCELLED);
            }

            @Override
            protected void failed() {
                showCancelledFailedAutoCancel("Auto Cancel", State.FAILED);
            }
        };

        new Thread(taskAutoCancel).start();
        JKiosk3.getBusy().startCountdown(taskAutoCancel, countdownTime);
    }

    /*
     * Errors on first submit to server
     */
//    private static void errorOnPayment(int count, final TicketProsPaymentReq req, State newState,
//                                       final TicketProBusPaymentResult result) {
//        String msgReason = "Error Processing Payment" + "\n\n" + newState + "\n\n";
//        if (count == 1) {
//            JKiosk3.getMsgBox().showMsgBox("TicketPro Payment", msgReason + "Click 'OK' to retry",
//                    null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
//                        @Override
//                        public void onOk() {
//                            getTicketProBusPaymentResp(2, req, result);
//                        }
//
//                        @Override
//                        public void onCancel() {
//                            //
//                        }
//                    });
//        } else {
//            showCancelledFailed("Payment", newState);
//        }
//    }

//    private static void errorOnPrint(int count, final TicketProsPrintReq req, State newState,
//                                     final TicketProBusTicketPrintResult result) {
//        String msgReason = "Error Processing Print" + "\n\n" + newState + "\n\n";
//        if (count == 1) {
//            JKiosk3.getMsgBox().showMsgBox("TicketPro Print", msgReason + "Click 'OK' to retry",
//                    null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
//                        @Override
//                        public void onOk() {
//                            getTicketProBusPrint(2, req, result);
//                        }
//
//                        @Override
//                        public void onCancel() {
//                            //
//                        }
//                    });
//        } else {
//            showCancelledFailed("Print", newState);
//        }
//    }

    private static void showCancelledFailed(String trxType, State newState) {
        JKiosk3.getBusy().hideBusy();

        String msgadd = "\n\nPlease check your network connection";
        String msgReason = "Error Processing " + trxType + "\n\n" + newState + "\n\n";
        if (newState == State.CANCELLED) {
            msgReason += "Operation timed out" + msgadd;
        } else if (newState == State.FAILED) {
            msgReason += errorMsg + msgadd;
        }
        msgReason += "\n\nClick 'OK' to print details";
        msgReason += "\n\nPlease phone TicketPro Customer Services to cancel this sale";

        JKiosk3.getMsgBox().showMsgBox("TicketPro " + trxType, msgReason,
                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                    @Override
                    public void onOk() {
                        PrintTicketPro print = new PrintTicketPro();
                        AeonPrintJob apj = print.getTicketProBusCancelRequestPrint();
                        PrintUtil.sendToPrinter(apj);
                        SceneSales.clearAndChangeContent(new TicketProMenu());
                    }

                    @Override
                    public void onCancel() {
                        //
                    }
                });
    }

    private static void showCancelledFailedAutoCancel(String trxType, State newState) {
        JKiosk3.getBusy().hideBusy();

        String msgadd = "\n\nPlease check your network connection";
        String msgReason = "Error Processing " + trxType + "\n\n" + newState + "\n\n";
        if (newState == State.CANCELLED) {
            msgReason += "Operation timed out" + msgadd;
        } else if (newState == State.FAILED) {
            msgReason += errorMsg + msgadd;
        }
        msgReason += "\n\nPlease ensure that you are connected to the network before continuing";
        msgReason += "\n\nYou will be returned to the Login Screen";

        JKiosk3.getMsgBox().showMsgBox("TicketPro " + trxType, msgReason,
                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                    @Override
                    public void onOk() {
                        JKiosk3.changeScene(new JKioskLogin());
                    }

                    @Override
                    public void onCancel() {
                        //
                    }
                });
    }

    /*
     * Abstract inner Result classes
     */
    public static abstract class TicketProBusRouteCodeResult {

        public abstract void tpBusRouteCodeResult(TicketProBusRouteCodeList tpBusRouteCodeResult);
    }

    public static abstract class TicketProBusRouteCodeListResult {

        public abstract void tpBusRouteCodeListResult(List<TicketProBusRouteCode> tpBusRouteCodeList);
    }

    public static abstract class TicketProBusRouteListResult {

        public abstract void tpBusRouteListResult(TicketProBusRouteListResp tpBusRouteListResp);
    }

    public static abstract class TicketProBusCreateCartResult {

        public abstract void tpCreateBusCartResult(TicketProsCart tpCreateCart);
    }

    public static abstract class TicketProBusRouteBookResult {

        public abstract void tpBusRouteBookResult(TicketProBusRouteBookResp tpBooking);
    }

    public static abstract class TicketProBusClearCartResult {

        public abstract void tpClearBusCartResult(TicketProBusCartClearResp tpClearBusCartResp);
    }

    public static abstract class TicketProBusCheckoutResult {

        public abstract void tpCheckoutBusResult(TicketProsCheckoutResp tpCheckoutBusResp);
    }

    public static abstract class TicketProBusPaymentResult {

        public abstract void tpBusPaymentResult(TicketProsPaymentResp tpBusPaymentResp);
    }

    public static abstract class TicketProBusTicketPrintResult {

        public abstract void tpBusTicketPrintResult(TicketProsPrintResp tpBusTicketPrintResp);
    }

    public static abstract class TicketProPutcoAutoCancelResult {
        public abstract void tpBusTicketAutoCancelResult(TicketProBusAutoCancelResp tpAutoCancelResp);
    }
}
