package jkiosk3.store;

/**
 *
 * @author Val
 */
public class JKPrinter {

    private static StoreJKPrinter printerConfig;

    public static StoreJKPrinter getPrinterConfig() {
        if (printerConfig == null) {
            printerConfig = ((StoreJKPrinter) Store.loadObject(JKPrinter.class.getSimpleName()));
        }
        if (printerConfig == null) {
            printerConfig = new StoreJKPrinter();
        }
        return printerConfig;
    }

    public static boolean savePrinterConfig() {
        getPrinterConfig();
        return Store.saveObject(JKPrinter.class.getSimpleName(), printerConfig);
    }
}
