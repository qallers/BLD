package jkiosk3.sales.electricity;

import aeonelectricity.ElectricityConfirmation;
import aeonelectricity.ElectricityConnection;
import aeonelectricity.ElectricityMeter;
import aeonelectricity.ElectricityVoucher;

import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.QuickAmounts;
import jkiosk3.sales._common.QuickAmountsResult;
import jkiosk3.sales.electricity.ElectricityUtil.ElectricityConfirm;
import jkiosk3.sales.electricity.ElectricityUtil.ElectricityResult;
import jkiosk3.users.UserUtil;

public class ElecToken extends Region {

    private final static Logger logger = Logger.getLogger (ElecToken.class.getName ());
    private ElectricityConnection connection;
    private ElectricityConfirmation confirmation;
    private final ElectricityProvider provider;
    private String meterNum;
    private int amount;
    private String sgc;
    private String tt;
    private String ti;
    private String krn;
    private String alg;
    private QuickAmounts qAmts;
    private final VBox vbToken;
    private ElecEnterMeter gMeter;
    private ElecShareBtnsLessMore btnsLessMore;
    private final ElecShareGridLessMore gridLessMore;
    private boolean isMore = false;

    public ElecToken(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;

        vbToken = JKLayout.getVBox (0, JKLayout.spNum);
        gridLessMore = new ElecShareGridLessMore (ElectricityUtil.ELEC_TOKEN);

        getChildren ().add (getMeterNumberEntry ());
    }

    private VBox getMeterNumberEntry() {
        gMeter = new ElecEnterMeter (provider, ElectricityUtil.ELEC_TOKEN, new ElecEnterMeterResult () {
            @Override
            public void onDone() {
                if (gMeter.isMagEntry ()) {
                    if (vbToken.getChildren ().contains (gridLessMore)) {
                        vbToken.getChildren ().remove (gridLessMore);
                        vbToken.getChildren ().add (1, qAmts);
                    }
                    btnsLessMore.getBtnLess ().setDisable (true);
                    btnsLessMore.getBtnMore ().setDisable (true);
                    btnsLessMore.getBtnAccept ().setDisable (false);
                    isMore = false;
                }
            }
        });
        System.out.println ("reading mag card for meter num = : " + gMeter.isMagEntry ());

        qAmts = getQuickAmts ();

        vbToken.getChildren ().addAll (gMeter, qAmts, getElecSaleCtrls ());
        return vbToken;
    }

    private QuickAmounts getQuickAmts() {
        QuickAmounts quick = new QuickAmounts (SaleType.ELECTRICITY, null, new QuickAmountsResult () {
            @Override
            public void amountSelected(double value) {
                amount = (int) value;
                requestConfirmation ();
            }
        });
        quick.setVisible (true);
        return quick;
    }

    private void resetQuickAmounts() {
        vbToken.getChildren ().remove (qAmts);
        qAmts = getQuickAmts ();
        vbToken.getChildren ().add (1, qAmts);
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        btnsLessMore = new ElecShareBtnsLessMore ();

        if (provider.getDisplayName ().contains ("Eskom")
                || provider.getDisplayName ().contains ("Universal")) {
            btnsLessMore.getBtnLess ().setVisible (true);
            btnsLessMore.getBtnLess ().setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event arg0) {
                    getLessMoreAction (btnsLessMore.getBtnLess ());
                }
            });
            btnsLessMore.getBtnMore ().setVisible (true);
            btnsLessMore.getBtnMore ().setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event arg0) {
                    getLessMoreAction (btnsLessMore.getBtnMore ());
                }
            });
        }

        btnsLessMore.getBtnAccept ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event arg0) {
                requestConfirmation ();
            }
        });
        btnsLessMore.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });

        return btnsLessMore;
    }

    private void getLessMoreAction(Button b) {
        switch (b.getText ()) {
            case "Less...":
                vbToken.getChildren ().add (1, qAmts);
                vbToken.getChildren ().remove (gridLessMore);
                btnsLessMore.getBtnLess ().setDisable (true);
                btnsLessMore.getBtnMore ().setDisable (false);
                btnsLessMore.getBtnAccept ().setDisable (true);
                isMore = false;
                break;
            case "More...":
                vbToken.getChildren ().remove (qAmts);
                vbToken.getChildren ().add (1, gridLessMore);
                btnsLessMore.getBtnLess ().setDisable (false);
                btnsLessMore.getBtnMore ().setDisable (true);
                btnsLessMore.getBtnAccept ().setDisable (false);
                isMore = true;
                break;
            default:
                vbToken.getChildren ().remove (gridLessMore);
                break;
        }
    }

    private boolean inputValidation() {
        boolean validated = false;
        try {
            meterNum = gMeter.getMeterNum ().trim ();
            sgc = gridLessMore.getTxtSGC ().getText ();
            tt = gridLessMore.getTxtTT ().getText ();
            ti = gridLessMore.getTxtTi ().getText ();
            krn = gridLessMore.getTxtKrn ().getText ();
            alg = gridLessMore.getTxtAlg ().getText ();
            //
            if (meterNum.equals ("") || meterNum == null) {
                JKiosk3.getMsgBox ().showMsgBox ("Meter Number", "Meter Number cannot be blank.\n\n"
                        + "Please enter Meter Number \n\nand choose or enter an amount.", null);
                amount = 0;
                resetQuickAmounts ();
                validated = false;
            } else if (isMore) {
                amount = Integer.parseInt (gridLessMore.getTxtAmt ().getText ());

                if ((gridLessMore.getTxtSGC ().getText ().equals ("") || gridLessMore.getTxtSGC ().getText () == null)
                        || (gridLessMore.getTxtTT ().getText ().equals ("") || gridLessMore.getTxtTT ().getText () == null)
                        || (gridLessMore.getTxtTi ().getText ().equals ("") || gridLessMore.getTxtTi ().getText () == null)
                        || (gridLessMore.getTxtKrn ().getText ().equals ("") || gridLessMore.getTxtKrn ().getText () == null)
                        || (gridLessMore.getTxtAlg ().getText ().equals ("") || gridLessMore.getTxtAlg ().getText () == null)) {
                    JKiosk3.getMsgBox ().showMsgBox ("Empty Field(s)", "All fields must be completed", null);
                    validated = false;
                } else if ((!sgc.matches ("\\d{6}")) || (!tt.matches ("\\d{2}")) || (!ti.matches ("\\d{2}"))
                        || (!krn.matches ("\\d{1}")) || (!alg.matches ("\\d{2}"))) {
                    JKiosk3.getMsgBox ().showMsgBox ("Incorrect value entered",
                            "Fields must be numeric only: - \n"
                                    + "SGC - 6 digits\n"
                                    + "TT - 2 digits\n"
                                    + "TI - 2 digits\n"
                                    + "KRN - 1 digit\n"
                                    + "ALG - 2 digits", null);
                } else {
                    validated = true;
                }
            } else {
                validated = true;
            }
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox ().showMsgBox ("Amount", "Amount cannot be empty, \nmust be a numeric only value,"
                    + "\nand\n must be in rands only, no cents", null);
            logger.log (Level.SEVERE, nfe.getMessage (), nfe);
            validated = false;
        } catch (Exception e) {
            logger.log (Level.SEVERE, e.getMessage (), e);
        }

        return validated;
    }

    private void requestConfirmation() {
        if (inputValidation ()) {
            makeElectricityConnection ();
        }
    }

    private void makeElectricityConnection() {
        final ElectricityMeter meter = new ElectricityMeter ();
        if (gMeter.isMagEntry ()) {
            meter.setTrack2data (meterNum);
            meter.setMeterSgc ("");
            meter.setMeterTt ("");
            meter.setMeterTi ("");
            meter.setMeterKrn ("");
            meter.setMeterAlg ("");
        } else {
            meter.setMeterNum (meterNum);
            meter.setMeterSgc (sgc);
            meter.setMeterTt (tt);
            meter.setMeterTi (ti);
            meter.setMeterKrn (krn);
            meter.setMeterAlg (alg);
        }

        String transType = provider.getTransactionType ();
        System.out.println ("ELECTRICITY - TRANSTYPE = " + transType);

        ElectricityUtil.getElectricityConfirmation (transType, "Token", meter, amount, new ElectricityConfirm () {
            @Override
            public void electricityConfirm(ElectricityConnection connect, final ElectricityConfirmation confirm) {
                if (confirm.isSuccess ()) {
                    connection = connect;
                    confirmation = confirm;

                    ElecConfirm confirmGrid = new ElecConfirm (confirmation, meter, amount, ElectricityUtil.ELEC_TOKEN);

                    JKiosk3.getMsgBox ().showMsgBox ("Electricity Meter Confirmation", "Token", confirmGrid,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    buyElectricity (confirm.getTransRef ());
                                }

                                @Override
                                public void onCancel() {
                                    resetQuickAmounts ();
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Unable to Confirm",(!confirm.getAeonErrorText ().isEmpty () ? "A" + confirm.getAeonErrorCode () + " - " + confirm.getAeonErrorText () :
                                    "B" + confirm.getErrorCode () + " - " + confirm.getErrorText ()),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    resetQuickAmounts ();
                                    SceneSales.clearAndChangeContent (new ElectricitySupplierSelect ());
                                }

                                @Override
                                public void onCancel() {
                                    // btn not shown here
                                }
                            });
                    ElectricityUtil.resetElectricity ();
                }
            }
        });
    }

    private void buyElectricity(String confirmRef) {
        String ref = SalesUtil.getUniqueRef ();

        ElectricityUtil.getElectricityVoucher (connection, "Token", confirmRef, ref, new ElectricityResult () {
            @Override
            public void electricityResult(ElectricityVoucher voucher) {
                if (voucher.isSuccess ()) {
                    SalesUtil.processElectricity (ElectricityUtil.ELEC_TOKEN, voucher, amount);

                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Electricity Purchase Failed",(!voucher.getAeonErrorText ().isEmpty () ?
                            "A" + voucher.getAeonErrorCode () + " - " + voucher.getAeonErrorText () :
                            "B" + voucher.getErrorCode () + " - " + voucher.getErrorText ()), null);
                }
                ElectricityUtil.resetElectricity ();
            }
        });
    }
}