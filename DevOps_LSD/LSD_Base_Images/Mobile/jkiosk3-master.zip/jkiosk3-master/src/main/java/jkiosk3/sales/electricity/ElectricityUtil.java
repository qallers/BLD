package jkiosk3.sales.electricity;

import aeonelectricity.ElectricityConfirmation;
import aeonelectricity.ElectricityConnection;
import aeonelectricity.ElectricityMeter;
import aeonelectricity.ElectricityToken;
import aeonelectricity.ElectricityVoucher;
import aeonelectricity.EskomFault;
import aeonelectricity.EskomFaultReq;
import aeonelectricity.EskomFaultType;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import jkiosk3.JKiosk3;
import jkiosk3.printing.MagCardData;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.SummaryTableView;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

public class ElectricityUtil {

    private final static Logger logger = Logger.getLogger(ElectricityUtil.class.getName());
    //
    public final static String ELEC_TOKEN = "Token";
    public final static String ELEC_FBE = "FBE";
    public final static String ELEC_UPDATE_M_KEY = "Update Meter Key";
    public final static String ELEC_UPDATE_M_CARD = "Update Meter Card";
    public final static String ELEC_FAULT_REPORT = "Fault Report";
    public final static String ELEC_TRIAL_VEND = "Trial Vend";
    public final static String ELEC_REPRINT = "Reprint";
    public final static String ELEC_REPRINT_LIST = "Reprint List";
    public final static String ELEC_PAY_ACCOUNT = "Pay Account (Debt)";
    public final static String ELEC_CONFIRM_CUSTOMER = "Confirm Customer Details";
    public final static String ELEC_ENG_KEY_CHANGE = "Engineering Key Change";
    public final static String ELEC_REDEEM_VOUCHER = "Redeem Voucher";
    //
    private static String userPin;
    private final static int deviceNo = JKSystem.getSystemConfig().getDeviceId();
    private final static String serialNo = JKSystem.getSystemConfig().getSerial();
    private static ElectricityConnection connection;
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 60;
    private static String loyaltyProfileId = "";

    private static ElectricityConnection getElectricityConnect() {
        ElectricityConnection electConnect = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = (JKSystem.getSystemConfig().getPort());
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            electConnect = new ElectricityConnection(server, port, secureConnect);
            electConnect.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return electConnect;
    }

    private static ElectricityVoucher getElectricityVoucher(ElectricityConnection ec, String type, String transref,
                                                            String ref) throws RuntimeException {


        ElectricityVoucher ev = null;
        try {
            ev = ec.getElectricityVoucher(type, transref, ref);
            if (ev.isSuccess()) {
//                ec.setPrinted(transref, ref);
//                ec.setSold(transref, ref);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Electricity Voucher Error", t);
        } finally {
            if (ec != null) {
                ec.disconnect();
            }
        }
        return ev;
    }

    private static ElectricityVoucher getElectricityVoucherReprint(
            ElectricityConnection ec, String transType, String meterNum, String reference) throws RuntimeException {
        ElectricityVoucher evReprint = new ElectricityVoucher();
        try {
            switch (transType) {
                case "OnlineReprint":
                    evReprint = ec.getOnlineReprint(meterNum, reference);
                    break;
                case "Reprint":
                    evReprint = ec.getReprint(meterNum);
                    break;
                default:
                    break;
            }
//            evReprint = ec.getOnlineReprint(meterNum, reference);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Electricity Voucher Reprint Error", t);
        } finally {
            if (ec != null) {
                ec.disconnect();
            }
        }
        return evReprint;
    }

    private static List<ElectricityVoucher> getElectricityVoucherReprintList(String transType, String meterNum, String ref)
            throws RuntimeException {
        List<ElectricityVoucher> listReprint = new ArrayList<>();
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            connection = getElectricityConnect();
            if (connection.login(userPin, deviceNo, serialNo, transType)) {
                listReprint = connection.getReprintList(meterNum, ref);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Electricity Voucher Reprint List Error", t);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return listReprint;
    }

    public static List<MagCardData> getMagCardTokens(ElectricityVoucher voucher) {
        List<MagCardData> magList = new ArrayList<>();
        System.out.println("do we get Mag Cards for this Voucher? : " + voucher.isPrintMagCard());
        // These 3 checks are now done BEFORE we reach this point!
        // See SalesUtil method 'writeElectricityMagCards(String type, ElectricityVoucher voucher)'
        // NOTE : For paper 'token' cards, only Track 3 is used, therefore we do NOT need to 'formatTrack2' for these!
        for (ElectricityToken t : voucher.getFreeTokens()) {
            MagCardData bsstCard = new MagCardData();
            bsstCard.setTrack1("000");
            bsstCard.setTrack2("0000000000000===00000000");
//                        bsstCard.setTrack2(formatTrack2(voucher.getMeter()));
            bsstCard.setTrack3(t.getBsstTokenNumber());
            magList.add(bsstCard);
        }
        for (ElectricityToken t : voucher.getTokens()) {
            MagCardData paidCard = new MagCardData();
            paidCard.setTrack1("000");
            paidCard.setTrack2("0000000000000===00000000");
//                        paidCard.setTrack2(formatTrack2(voucher.getMeter()));
            paidCard.setTrack3(t.getTokenNumber());
            magList.add(paidCard);
        }
        System.out.println("we have " + magList.size() + " tokens in our list");
        return magList;
    }

    public static List<MagCardData> getMagCardUpdateByConfirmation(ElectricityConfirmation confirmed) {
        // ESKOM only
        List<MagCardData> listCardUpdate = new ArrayList<>();
        if (confirmed.getUtility().equalsIgnoreCase("Eskom")) {
            MagCardData cardUpdate = new MagCardData();
            ElectricityMeter meter = new ElectricityMeter();
            meter.setMeterNum(confirmed.getMeterNumber());
            meter.setMeterSgc(confirmed.getSgc());
            meter.setMeterTt(confirmed.getTt());
            meter.setMeterTi(confirmed.getTi());
            meter.setMeterAlg(confirmed.getAt());
            meter.setMeterKrn(confirmed.getKrn());
            cardUpdate.setTrack2(formatTrack2(meter));
            listCardUpdate.add(cardUpdate);
        }
        return listCardUpdate;
    }

    public static List<MagCardData> getMagCardUpdateByVoucher(ElectricityVoucher voucher) {
        // ESKOM only
        List<MagCardData> listCardUpdate = new ArrayList<>();
        if (voucher.getUtility().equalsIgnoreCase("Eskom")) {
            MagCardData cardUpdate = new MagCardData();
            ElectricityMeter meter = new ElectricityMeter();
            meter.setMeterNum(voucher.getMeter().getMeterNum());
            meter.setMeterSgc(voucher.getMeter().getMeterSgc());
            meter.setMeterTt(voucher.getMeter().getMeterTt());
            meter.setMeterTi(voucher.getMeter().getMeterTi());
            meter.setMeterAlg(voucher.getMeter().getMeterAlg());
            meter.setMeterKrn(voucher.getMeter().getMeterKrn());
            cardUpdate.setTrack2(formatTrack2(meter));
            listCardUpdate.add(cardUpdate);
        }
        return listCardUpdate;
    }

    private static String formatTrack2(ElectricityMeter meter) {
        StringBuilder track2 = new StringBuilder();
        track2.append("600727");
        track2.append(meter.getMeterNum());
        // 2019-03-07  -  this will FAIL if we have an alpha-numeric meter number!
        // Should only be used for Eskom card updates, which should be numeric only meter numbers.
        track2.append(luhnEnc(track2.toString()));
        track2.append("===");
        track2.append(meter.getMeterTt() == null ? "01"
                : meter.getMeterTt());
        track2.append(meter.getMeterAlg() == null ? "07"
                : meter.getMeterAlg());
        track2.append(meter.getMeterSgc() == null ? "000000"
                : meter.getMeterSgc());
        track2.append(meter.getMeterTi() == null ? "07"
                : meter.getMeterTi());
        track2.append(meter.getMeterKrn() == null ? "1"
                : meter.getMeterKrn());

        return track2.toString();
    }

    /**
     * Calculates a LUHN modulus 10 check-digit
     *
     * @param number The Numbers to calculate the check on.
     * @return the check digit
     */
    private static int luhnEnc(String number) {
        int sum = 0;

        boolean alternate = true;
        for (int i = number.length(); i >= 1; i--) {
            int n = Integer.parseInt(number.substring(i - 1, i));

            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n = (n % 10) + 1;
                }
            }
            sum += n;
            alternate = !alternate;
        }

        int mod = (10 - (sum % 10)) % 10;
        return mod;
    }

    private static List<EskomFaultType> getListEskomFaults(String transType) throws RuntimeException {
        List<EskomFaultType> listFaults = new ArrayList<>();
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            connection = getElectricityConnect();
            if (connection.login(userPin, deviceNo, serialNo, transType)) {
                listFaults = connection.getEskomFaults();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Electricity Eskom Fault List Error", t);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return listFaults;
    }

    private static EskomFault logEskomFault(String transType, EskomFaultReq req) throws RuntimeException {
        EskomFault logFault = new EskomFault();
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            connection = getElectricityConnect();
            if (connection.login(userPin, deviceNo, serialNo, transType)) {
                logFault = connection.logEskomFault(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Electricity Eskom Fault Error", t);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return logFault;
    }

    private static ElectricityVoucher getPayAccountVoucher(String transType, String meter, double amount) throws RuntimeException {
        ElectricityVoucher payAccountVoucher = new ElectricityVoucher();
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            connection = getElectricityConnect();
            payAccountVoucher = connection.getPayDebtVoucher(userPin, deviceNo, serialNo, transType, meter, amount);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Electricity Eskom Account Pay Error", t);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        return payAccountVoucher;
    }

    private static ElectricityConfirmation getCustomerConfirm(String transType, String id, String idType) throws RuntimeException {
        ElectricityConfirmation customerConfirm = new ElectricityConfirmation();
        userPin = CurrentUser.getSalesUser().getUserPin();

        try {
            connection = getElectricityConnect();
            customerConfirm = connection.getCustomerConfirm(userPin, deviceNo, serialNo, transType, id, idType);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Electricity Eskom Customer Confirm Error", t);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        return customerConfirm;
    }

    private static ElectricityVoucher getEngKeyChangeVoucher(String transType, String reference, ElectricityMeter meter)
            throws RuntimeException {
        ElectricityVoucher engKeyChangeVoucher = new ElectricityVoucher();
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            connection = getElectricityConnect();
            engKeyChangeVoucher = connection.getEngKeyChangeVoucher(userPin, deviceNo, serialNo, transType, reference, meter);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Electricity Eskom Key Change Error", t);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

        return engKeyChangeVoucher;
    }

    private static ElectricityVoucher getUpdateMeterKeyVoucher(ElectricityConnection ec, String type, String transref,
                                                               String ref) throws RuntimeException {
        ElectricityVoucher updateMeterKeyVoucher = null;
        try {
            updateMeterKeyVoucher = ec.getElectricityVoucher(type, transref, ref);
            if (updateMeterKeyVoucher.isSuccess()) {
//                ec.setPrinted(transref, ref);
//                ec.setSold(transref, ref);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Electricity Eskom Update Meter Key Error", t);
        } finally {
            if (ec != null) {
                ec.disconnect();
            }
        }
        return updateMeterKeyVoucher;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getElectricityConfirmation(final String transType, final String type,
                                                  final ElectricityMeter meterNum, final int amount, final ElectricityConfirm confirm) {
//        String loyaltyProfileId = "";
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            loyaltyProfileId = ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId();
        }

        userPin = CurrentUser.getSalesUser().getUserPin();

        JKiosk3.getBusy().showBusy("Checking for Meter Number");

        final Task<ElectricityConnection> taskConnect = new Task<ElectricityConnection>() {
            @Override
            protected ElectricityConnection call() throws Exception {
                connection = getElectricityConnect();
                return connection;
            }
        };

        final Task<ElectricityConfirmation> taskConfirm = new Task<ElectricityConfirmation>() {
            @Override
            protected ElectricityConfirmation call() throws Exception {
                if (transType.isEmpty()) {
                    return connection.getMeterConfirm(userPin, deviceNo, serialNo, meterNum, amount);
                } else {
                    return connection.getMeterConfirm(transType, userPin, deviceNo, serialNo, meterNum, amount, loyaltyProfileId);
                }
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                confirm.electricityConfirm(taskConnect.getValue(), getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Meter Confirmation",
                        "Confirmation Failed", State.CANCELLED, errorMsg, new ElectricitySupplierSelect());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Meter Confirmation",
                        "Confirmation Failed", State.FAILED, errorMsg, new ElectricitySupplierSelect());
            }
        };

        taskConnect.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    new Thread(taskConfirm).start();
                    JKiosk3.getBusy().startCountdown(taskConfirm, countdownTime);
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
                    taskutil.taskConnectCancelFail(newState, errorMsg, new ElectricitySupplierSelect());
                }
            }
        });

        new Thread(taskConnect).start();
    }

    // use for Update Meter Card
    public static void getElectricityConfirmation(final String transType, final ElectricityMeter meterNum, final int amount,
                                                  final boolean meterDetails, final ElectricityConfirm confirm) {

        userPin = CurrentUser.getSalesUser().getUserPin();

        JKiosk3.getBusy().showBusy("Checking for Meter Number");

        final Task<ElectricityConnection> taskConnect = new Task<ElectricityConnection>() {
            @Override
            protected ElectricityConnection call() throws Exception {
                connection = getElectricityConnect();
                return connection;
            }
        };

        final Task<ElectricityConfirmation> taskConfirmCard = new Task<ElectricityConfirmation>() {
            @Override
            protected ElectricityConfirmation call() throws Exception {
                return connection.getMeterConfirm(transType, userPin, deviceNo, serialNo, meterNum, amount, meterDetails);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                confirm.electricityConfirm(taskConnect.getValue(), getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Meter Confirmation",
                        "Update Meter Card Confirmation Failed", State.CANCELLED, errorMsg, new ElectricitySupplierSelect());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Meter Confirmation",
                        "Update Meter Card Confirmation Failed", State.FAILED, errorMsg, new ElectricitySupplierSelect());
            }
        };

        taskConnect.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    new Thread(taskConfirmCard).start();
                    JKiosk3.getBusy().startCountdown(taskConfirmCard, countdownTime);
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
                    taskutil.taskConnectCancelFail(newState, errorMsg, new ElectricitySupplierSelect());
                }
            }
        });

        new Thread(taskConnect).start();
    }

    public static void getElectricityVoucher(final ElectricityConnection econn, final String type, final String transref,
                                             final String ref, final ElectricityResult result) {

        JKiosk3.getBusy().showBusy("Getting Electricity Voucher");

        final Task<ElectricityVoucher> taskElecVoucher = new Task<ElectricityVoucher>() {
            @Override
            protected ElectricityVoucher call() throws Exception {
                return getElectricityVoucher(econn, type, transref, ref);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.electricityResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Electricity Voucher Error", "Electricity Voucher Failed", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Electricity Voucher Error", "Electricity Voucher Failed", State.FAILED, errorMsg);
            }
        };

        new Thread(taskElecVoucher).start();
        JKiosk3.getBusy().startCountdown(taskElecVoucher, countdownTime);
    }

    public static void getElectricityVoucherReprint(final ElectricityConnection ec, final String transType,
                                                    final String meterNum, final String reference, final ElectricityResult result) {
        JKiosk3.getBusy().showBusy("Getting Reprint");

        final Task<ElectricityVoucher> taskElecVoucherReprint = new Task<ElectricityVoucher>() {
            @Override
            protected ElectricityVoucher call() throws Exception {
                return getElectricityVoucherReprint(ec, transType, meterNum, reference);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.electricityResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Electricity Voucher Reprint",
                        "Electricity Voucher Reprint Failed", State.CANCELLED, errorMsg, new ElectricitySupplierSelect());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Electricity Voucher Reprint",
                        "Electricity Voucher Reprint Failed", State.FAILED, errorMsg, new ElectricitySupplierSelect());
            }
        };

        new Thread(taskElecVoucherReprint).start();
        JKiosk3.getBusy().startCountdown(taskElecVoucherReprint, countdownTime);
    }

    public static void getElectricityVoucherReprintList(final String transType, final String meterNum, final String ref,
                                                        final EskomReprintListResult result) {
        JKiosk3.getBusy().showBusy("Getting Reprint List");
        final Task<List<ElectricityVoucher>> taskReprintList = new Task<List<ElectricityVoucher>>() {
            @Override
            protected List<ElectricityVoucher> call() throws Exception {
                return getElectricityVoucherReprintList(transType, meterNum, ref);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.eskomReprintListResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Electricity Voucher Reprint List",
                        "Electricity Voucher Reprint List Failed", State.CANCELLED, errorMsg, new ElectricitySupplierSelect());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Electricity Voucher Reprint List",
                        "Electricity Voucher Reprint List Failed", State.FAILED, errorMsg, new ElectricitySupplierSelect());
            }
        };

        new Thread(taskReprintList).start();
        JKiosk3.getBusy().startCountdown(taskReprintList, countdownTime);
    }

    public static void getListEskomFaults(final String transType, final EskomFaultListResult result) {
        JKiosk3.getBusy().showBusy("Getting List of Eskom Faults");

        final Task<List<EskomFaultType>> taskEskomListFaults = new Task<List<EskomFaultType>>() {
            @Override
            protected List<EskomFaultType> call() throws Exception {
                return getListEskomFaults(transType);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.eskomFaultList(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Eskom Fault List",
                        "Error Retrieving List of Faults", State.CANCELLED, errorMsg, new ElectricitySupplierSelect());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Eskom Fault List",
                        "Error Retrieving List of Faults", State.FAILED, errorMsg, new ElectricitySupplierSelect());
            }
        };

        new Thread(taskEskomListFaults).start();
        JKiosk3.getBusy().startCountdown(taskEskomListFaults, countdownTime);
    }

    public static void logEskomFault(final String transType, final EskomFaultReq req, final EskomFaultLogged result) {
        JKiosk3.getBusy().showBusy("Logging Fault");

        final Task<EskomFault> taskEskomFault = new Task<EskomFault>() {
            @Override
            protected EskomFault call() throws Exception {
                return logEskomFault(transType, req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.eskomFaultLogged(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Eskom Log Fault Error", "Eskom Log Fault Failed", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Eskom Log Fault Error", "Eskom Log Fault Failed", State.FAILED, errorMsg);
            }
        };

        new Thread(taskEskomFault).start();
        JKiosk3.getBusy().startCountdown(taskEskomFault, countdownTime);
    }

    public static void getPayAccountVoucher(final String transType, final String meter, final double amount, final EskomPayDebtResult result) {
        JKiosk3.getBusy().showBusy("Processing Account Payment");

        final Task<ElectricityVoucher> taskEskomPayDebt = new Task<ElectricityVoucher>() {
            @Override
            protected ElectricityVoucher call() throws Exception {
                return getPayAccountVoucher(transType, meter, amount);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.eskomPayDebtResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Eskom Account Payment Error", "Eskom Account Payment Failed", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Eskom Account Payment Error", "Eskom Account Payment Failed", State.FAILED, errorMsg);
            }
        };

        new Thread(taskEskomPayDebt).start();
        JKiosk3.getBusy().startCountdown(taskEskomPayDebt, countdownTime);
    }

    public static void getCustomerConfirm(final String transType, final String id, final String idType,
                                          final EskomCustomerConfirmationResult result) {
        JKiosk3.getBusy().showBusy("Getting Customer Details");

        final Task<ElectricityConfirmation> taskEskomCustomerConfirm = new Task<ElectricityConfirmation>() {
            @Override
            protected ElectricityConfirmation call() throws Exception {
                return getCustomerConfirm(transType, id, idType);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.eskomCustomerConfirmationResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Confirm Customer Error", "Confirm Customer Failed", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Confirm Customer Error", "Confirm Customer Failed", State.FAILED, errorMsg);
            }

        };

        new Thread(taskEskomCustomerConfirm).start();
        JKiosk3.getBusy().startCountdown(taskEskomCustomerConfirm, countdownTime);
    }

    public static void getEngKeyChangeVoucher(final String transType, final String reference, final ElectricityMeter meter,
                                              final EskomEngKeyChangeResult result) {
        JKiosk3.getBusy().showBusy("Getting Engineering Key Change Result");

        final Task<ElectricityVoucher> taskEskomEngKeyChange = new Task<ElectricityVoucher>() {
            @Override
            protected ElectricityVoucher call() throws Exception {
                return getEngKeyChangeVoucher(transType, reference, meter);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.eskomEngKeyChangeResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Key Change Error", "Key Change Failed", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Key Change Error", "Key Change Failed", State.FAILED, errorMsg);
            }
        };

        new Thread(taskEskomEngKeyChange).start();
        JKiosk3.getBusy().startCountdown(taskEskomEngKeyChange, countdownTime);
    }

    public static void getUpdateMeterKeyVoucher(final ElectricityConnection conn, final String type, final String transRef,
                                                final String reference, final EskomUpdateMeterKeyResult result) {
        JKiosk3.getBusy().showBusy("Getting Update Meter Key Result");

        final Task<ElectricityVoucher> taskEskomUpdateMeterKey = new Task<ElectricityVoucher>() {
            @Override
            protected ElectricityVoucher call() throws Exception {
                return getUpdateMeterKeyVoucher(conn, type, transRef, reference);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.eskomUpdateMeterKeyResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Update Meter Key Error", "Update Meter Key Failed", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Update Meter Key Error", "Update Meter Key Failed", State.FAILED, errorMsg);
            }
        };

        new Thread(taskEskomUpdateMeterKey).start();
        JKiosk3.getBusy().startCountdown(taskEskomUpdateMeterKey, countdownTime);
    }

    public abstract static class ElectricityResult {

        public abstract void electricityResult(ElectricityVoucher voucher);
    }

    public abstract static class ElectricityConfirm {

        public abstract void electricityConfirm(ElectricityConnection connect, ElectricityConfirmation confirm);
    }

    public abstract static class EskomFaultListResult {

        public abstract void eskomFaultList(List<EskomFaultType> eskomFaultTypes);
    }

    public abstract static class EskomFaultLogged {

        public abstract void eskomFaultLogged(EskomFault eskomFault);
    }

    public abstract static class EskomPayDebtResult {

        public abstract void eskomPayDebtResult(ElectricityVoucher payDebtVoucher);
    }

    public abstract static class EskomCustomerConfirmationResult {

        public abstract void eskomCustomerConfirmationResult(ElectricityConfirmation confirmation);
    }

    public abstract static class EskomEngKeyChangeResult {

        public abstract void eskomEngKeyChangeResult(ElectricityVoucher engKeyChangeVoucher);
    }

    public abstract static class EskomUpdateMeterKeyResult {

        public abstract void eskomUpdateMeterKeyResult(ElectricityVoucher updateMeterKeyVoucher);
    }

    public abstract static class EskomReprintListResult {

        public abstract void eskomReprintListResult(List<ElectricityVoucher> listReprints);
    }

    //
    public static void resetElectricity() {
//        SceneSales.clearAndChangeContent(new ElectricitySupplierSelect());
        SceneSales.clearAndShowFavourites();
        if (SummaryTableView.getSummaryRows().isEmpty()) {
            SceneSales.getLblSalesPerson().setText("");
            CurrentUser.setSalesUser(null);
        }
    }
}
