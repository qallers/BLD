package jkiosk3.sales.ticketpro.sale;

import aeonticketpros.TicketProsSeatCategory;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3._common.JKLayout;
import static jkiosk3._common.JKLayout.sp;
import jkiosk3._common.JKNode;
import static jkiosk3._common.JKNode.getImageBlank;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;

/**
 *
 * @author Val
 */
public class TicketProSeating extends Region {

    private List<TicketProsSeatCategory> listSeatCats;

    public TicketProSeating(List<TicketProsSeatCategory> seatCats) {
        this.listSeatCats = seatCats;
        getChildren().add(getSeatCategoryDisplay());
    }

    private VBox getSeatCategoryDisplay() {
        String imageUrl = "C:\\Users\\Val\\Documents\\Projects\\AeonSA_Clients\\Trunk\\JKiosk3\\media\\newlands.png";
        Image img;
        try {
            BufferedInputStream imgIn = new BufferedInputStream(new FileInputStream(imageUrl));
            img = new Image(imgIn);
            try {
                imgIn.close();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        } catch (FileNotFoundException | IllegalArgumentException e) {
            img = getImageBlank();
        }
        ImageView imgView = new ImageView(img);
        imgView.setFitHeight(300);
        imgView.setPreserveRatio(true);

        VBox vbSeatCats = JKLayout.getVBox(0, JKLayout.spNum);
        for (TicketProsSeatCategory cat : listSeatCats) {
            Label lblSeatCat = JKText.getLblDk(cat.toString(), JKText.FONT_B_XXSM);
            Label lblAvailable = JKText.getLblDk("0 available", JKText.FONT_B_XXSM);
            HBox hb = JKLayout.getHBox(0, 0);
            hb.setMaxWidth(450);
            hb.setMinWidth(450);
            if (cat.getSeatLabel().contains("Cat 6")) {
                hb.setStyle("-fx-background-color: #EDBA6E;");
//                lblAvailable.setText((int) (Math.random() * 100) + " available");
                lblAvailable.setText(new Random().nextInt(100) + " available");
            }
            hb.getChildren().addAll(lblSeatCat, JKNode.getHSpacer(), lblAvailable);
            vbSeatCats.getChildren().add(hb);
        }

        VBox vbSeating = JKLayout.getVBox(0, sp);
        vbSeating.setMinWidth(MessageBox.getMsgWidth() - (4 * JKLayout.sp));
        vbSeating.getChildren().addAll(imgView, vbSeatCats);

        return vbSeating;
    }
}
