package jkiosk3.sales.ticketpro.sale;

import aeonticketpros.TicketProsCategory;
import aeonticketpros.TicketProsCategoryList;

import java.util.ArrayList;
import java.util.List;

import aeonticketpros.TicketProsEvent;
import aeonticketpros.TicketProsEventList;
import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.ControlSearch;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.ticketpro.TicketProMenu;
import jkiosk3.sales.ticketpro.TicketProSale;
import jkiosk3.sales.ticketpro.TicketProUtil;
import jkiosk3.sales.ticketpro.TicketProUtil.TicketProCategoryListResult;
import jkiosk3.sales.ticketpro.cache.CacheControllerTicketPro;
import jkiosk3.users.UserUtil;

public class TicketProCategories extends Region {

    private List<TicketProsCategory> listCategories;
    private List<TicketProsEvent> listEventsAll;
    private List<Button> listCategoryButtons;
    private AnchorPane anchorPane;
    private ControlSearch searchCtrl;
    private final static int pageSize = 10;

    public TicketProCategories() {
        listCategories = new ArrayList<> ();
        listEventsAll = new ArrayList<> ();

        TicketProUtil.getTicketProCategoryList (false, new TicketProCategoryListResult () {
            @Override
            public void tpCategoryListResult(TicketProsCategoryList tpCategoryList) {
                if (tpCategoryList.isSuccess ()) {
                    listCategories = tpCategoryList.getListCategories ();
                    TicketProSale.getInstance ().getListCategories ().addAll (listCategories);
                    TicketProUtil.getTicketProEventsAllList (false, new TicketProUtil.TicketProEventListAllResult () {
                        @Override
                        public void tpEventListAllResult(TicketProsEventList tpEventListAllResult) {
                            if (tpEventListAllResult.isSuccess () && !tpEventListAllResult.getListEvents ().isEmpty ()) {
                                listEventsAll = tpEventListAllResult.getListEvents ();
                                setSearchControlActions ();
                                getChildren ().add (getCategoryLayout ());
                            } else {
                                JKiosk3.getMsgBox ().showMsgBox ("TicketPro Events Cache",
                                        "No Events cached.\n\nEvents might not be searchable.", null);
                            }
                        }
                    });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Categories",!tpCategoryList.getAeonErrorText ().isEmpty () ?
                                    "A" + tpCategoryList.getAeonErrorCode () + " - " + tpCategoryList.getAeonErrorText () :
                                    "B" + tpCategoryList.getErrorCode () + " - " + tpCategoryList.getErrorText (), null);
                }
            }
        });
    }

    private void setSearchControlActions() {

        searchCtrl = new ControlSearch ();
        searchCtrl.getBtnSearch ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (new TextField (), "Enter search text", "",
                        false, false, new KeyboardResult () {
                            @Override
                            public void onDone(String value) {
                                TicketProUtil.getTicketProEventsSearchedList (value, listEventsAll,
                                        new TicketProUtil.TicketProEventListResult () {
                                            @Override
                                            public void tpEventListResult(List<TicketProsEvent> tpEventListSearchedResult) {
                                                TicketProSale.getInstance ().setSelectedCategory (null);
                                                TicketProSale.getInstance ().getListEvents ().clear ();
                                                TicketProSale.getInstance ().getListEvents ().addAll (tpEventListSearchedResult);
                                                SceneSales.clearAndChangeContent (new TicketProEvents (tpEventListSearchedResult));
                                            }
                                        });
                            }
                        });
            }
        });
        searchCtrl.getBtnClear ().setDisable (true);
        searchCtrl.getBtnClear ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                //
            }
        });
    }

    private VBox getCategoryLayout() {
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (getCategoryPane ());
        vb.getChildren ().add (getNav ());
        return vb;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(javafx.event.Event e) {
                SceneSales.clearAndChangeContent (new TicketProMenu ());
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(javafx.event.Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndChangeContent (new TicketProMenu ());
            }
        });
        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private VBox getCategoryPane() {

        Label lblCategories = JKText.getLblDk ("TicketPro Categories", JKText.FONT_B_SM);

        Button btnUpdate = JKNode.getBtnPopupDbl ("update cache");
        btnUpdate.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                CacheControllerTicketPro cacheControllerTicketPro = TicketProUtil.getCacheControllerTicketPro ();
                cacheControllerTicketPro.updateTPCache (false, new ResultCallback () {
                    @Override
                    public void onResult(boolean result) {
                        Platform.runLater (new Runnable () {
                            @Override
                            public void run() {
                                SceneSales.clearAndChangeContent (new TicketProCategories ());
                            }
                        });
                    }
                });
            }
        });

        HBox hbSearch = JKLayout.getHBox (0, JKLayout.sp);
        hbSearch.getChildren ().addAll (btnUpdate, searchCtrl);

        VBox vbHead = JKNode.getPageDblHeadVB (0, lblCategories, hbSearch);
        vbHead.setMaxWidth (JKLayout.contentW - (2 * JKLayout.sp));

        anchorPane = new AnchorPane ();

        getListCategoryButtons ();

//        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getCategoryButtons());

        VBox vb = JKLayout.getVBoxContent (JKLayout.sp);
        vb.setStyle ("-fx-padding: 15px 0px 15px 0px;");
//        vb.getChildren().addAll(vbHead, tile);
        vb.getChildren ().addAll (vbHead, anchorPane);

        return vb;
    }

    private void getListCategoryButtons() {
        listCategoryButtons = getCategoryButtons ();
        createPagedCategories ();
    }

    private void createPagedCategories() {
        anchorPane.getChildren ().clear ();
        int numPgs = 0;
        if (listCategoryButtons.isEmpty ()) {
            numPgs = 1;
        } else if ((listCategoryButtons.size () % pageSize) == 0) {
            numPgs = listCategoryButtons.size () / pageSize;
        } else {
            numPgs = (listCategoryButtons.size () / pageSize) + 1;
        }
        Pagination pages = new Pagination (numPgs);
        pages.setPageFactory (new Callback<Integer, Node> () {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedTile (pg, 435, 2, pageSize, listCategoryButtons);
            }
        });
        anchorPane.getChildren ().add (pages);
    }

    private List<Button> getCategoryButtons() {
        List<Button> btnList = new ArrayList<> ();

        for (final TicketProsCategory c : listCategories) {
            final Button btn = JKNode.getBtnSmDbl (c.getName ());
            btn.setId (c.getId ());
            btn.setFont (JKText.FONT_B_SM);
            btn.getStyleClass ().add ("btnTicketPros");
            btn.setOnMouseReleased (new EventHandler () {
                @Override
                public void handle(Event evt) {
                    TicketProSale.getInstance ().setSelectedCategory (c);
                    getMenuAction (c);
                }
            });
            if (!c.getId ().equalsIgnoreCase ("bus")) {
                btnList.add (btn);
            }
        }

        return btnList;
    }

    private void getMenuAction(TicketProsCategory cat) {
        TicketProUtil.getTicketProEventList (cat.getId (), new TicketProUtil.TicketProEventListResult () {

            @Override
            public void tpEventListResult(List<TicketProsEvent> tpEventListResult) {
                if (!tpEventListResult.isEmpty ()) {
                    TicketProSale.getInstance ().getListEvents ().clear ();
                    TicketProSale.getInstance ().getListEvents ().addAll (tpEventListResult);
                    SceneSales.clearAndChangeContent (new TicketProEvents (tpEventListResult));
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Events",
                            "No Events Found for Selected Category", null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK,
                            new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    SceneSales.clearAndChangeContent (new TicketProCategories ());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }
}
