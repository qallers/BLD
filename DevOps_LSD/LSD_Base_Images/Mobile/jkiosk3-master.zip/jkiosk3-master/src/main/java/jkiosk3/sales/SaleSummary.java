package jkiosk3.sales;

import java.io.Serializable;
import java.util.Date;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class SaleSummary implements Serializable {

    private SimpleStringProperty itemName;
    private SimpleDoubleProperty amount;
    private SimpleStringProperty reference;
    private SimpleBooleanProperty canCancel;
    private SimpleStringProperty offOn;
    private SimpleStringProperty addRef;
    private Date dateTime;
    private SimpleStringProperty serialNo;
    private SimpleStringProperty saleType;

    public SaleSummary(String item, double amt, String ref, boolean cancel, String offline, String addRef,
            Date date, String serial, String saleTypeAdded) {
        this.itemName = new SimpleStringProperty(item);
        this.amount = new SimpleDoubleProperty(amt);
        this.reference = new SimpleStringProperty(ref);
        this.canCancel = new SimpleBooleanProperty(cancel);
        this.offOn = new SimpleStringProperty(offline);
        this.addRef = new SimpleStringProperty(addRef);
        this.dateTime = date;
        this.serialNo = new SimpleStringProperty(serial);
        this.saleType = new SimpleStringProperty(saleTypeAdded);
    }

    public String getAddRef() {
        return addRef.get();
    }

    public void setAddRef(String addReference) {
        addRef.set(addReference);
    }

    public String getItemName() {
        return itemName.get();
    }

    public void setItemName(String value) {
        itemName.set(value);
    }

    public Double getAmount() {
        return amount.get();
    }

    public void setAmount(double amt) {
        amount.set(amt);
    }

    public String getReference() {
        return reference.get();
    }

    public void setReference(String ref) {
        reference.set(ref);
    }

    public Boolean getCanCancel() {
        return canCancel.get();
    }

    public void setCanCancel(Boolean cancel) {
        canCancel.set(cancel);
    }

    public String getOffOn() {
        return offOn.get();
    }

    public void setOffOn(String offline) {
        offOn.set(offline);
    }

    public Date getDateTime() {
        return dateTime;
    }

    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }

    public String getSerialNo() {
        return serialNo.get();
    }

    public void setSerialNo(String serial) {
        serialNo.set(serial);
    }
    
    public String getSaleType() {
        return saleType.get();
    }
    
    public void setSaleType(String saleTypeAdded) {
        saleType.set(saleTypeAdded);
    }
}
