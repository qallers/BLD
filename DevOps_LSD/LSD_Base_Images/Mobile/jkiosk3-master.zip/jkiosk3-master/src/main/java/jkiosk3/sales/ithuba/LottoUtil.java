package jkiosk3.sales.ithuba;

import aeonithuba.IthubaConfirmRes;
import aeonithuba.IthubaConnection;
import aeonithuba.IthubaLottoReq;
import aeonithuba.IthubaLottoRes;
import java.awt.Dimension;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.concurrent.Task;
import javafx.scene.text.Font;
import jkiosk3.JKiosk3;
import jkiosk3.StageJKiosk;
import jkiosk3._common.JKText;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

public class LottoUtil {

    private final static Logger logger = Logger.getLogger(LottoUtil.class.getName());

    public final static int MAX_BOARDS = 20;
    public final static int MAX_DRAWS = 10;
    public final static int NUM_MAX_LOTTO_BOARD = 52;
//    public final static int NUM_MAX_POWERBALL_BOARD = 45;
    public final static int NUM_MAX_POWERBALL_BOARD = 50;
    public final static int NUM_MAX_POWERBALL_BOARD_PB = 20;
    public final static int NUM_REQ_LOTTO = 6;
    public final static int NUM_REQ_POWERBALL = 5;
    public final static int NUM_REQ_POWERBALL_PB = 1;
    public final static String GAMETYPE_LOTTO_QUICK = "Lotto QuickPick";
    public final static String GAMETYPE_LOTTO_SELECT = "Lotto";
    public final static String GAMETYPE_PBALL_QUICK = "PowerBall QuickPick";
    public final static String GAMETYPE_PBALL_SELECT = "PowerBall";
//    public final static Dimension DIM_LG = new Dimension(((int) (StageJKiosk.getSceneWidth() * 0.75)), ((int) (StageJKiosk.getSceneHeight() * 0.65)));
    public final static Dimension DIM_LG = new Dimension(((int) (StageJKiosk.getSceneWidth() * 0.85)), ((int) (StageJKiosk.getSceneHeight() * 0.75)));
//    public final static Dimension DIM_SM = new Dimension(((int) (StageJKiosk.getSceneWidth() * 0.65)), ((int) (StageJKiosk.getSceneHeight() * 0.55)));
    public final static Dimension DIM_SM = new Dimension(((int) (StageJKiosk.getSceneWidth() * 0.60)), ((int) (StageJKiosk.getSceneHeight() * 0.45)));
    public final static Font FONT_PLAY = JKText.FONT_B_18;

    public final static String DATA_GAME = "Game";
    public final static String DATA_TYPE = "Type";
    public final static String DATA_NUM_BOARDS = "NumBoards";
    public final static String DATA_NUM_DRAWS = "NumberOfDraws";
    public final static String DATA_NUMBERS = "Numbers";
    public final static String DATA_PLUS1 = "Plus1";
    public final static String DATA_PLUS2 = "Plus2";

    private static String userPin;
    private static IthubaConnection connection;
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 60;

    private static IthubaConnection getIthubaConnect() {
        IthubaConnection ithubaConnect = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = (JKSystem.getSystemConfig().getPort());
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            ithubaConnect = new IthubaConnection(server, port, secureConnect);
            ithubaConnect.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return ithubaConnect;
    }

    private static boolean isLoggedIn(String pin) throws RuntimeException {
        String loyaltyProfileId = "";
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            loyaltyProfileId = ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId();
        }

        boolean loggedIn = false;
        connection = getIthubaConnect();
        int deviceId = JKSystem.getSystemConfig().getDeviceId();
        String serial = JKSystem.getSystemConfig().getSerial();
        try {
            if (connection != null) {
                loggedIn = connection.login(pin, deviceId, serial, loyaltyProfileId);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    private static IthubaConfirmRes getLottoConfirm(IthubaLottoReq req) throws RuntimeException {
        IthubaConfirmRes ithubaConfirmRes = new IthubaConfirmRes();
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                ithubaConfirmRes = connection.confirm(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Lotto Error", t);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return ithubaConfirmRes;
    }

    public static void getLottoConfirm(final IthubaLottoReq req, final IthubaConfirmResult result) {
        JKiosk3.getBusy().showBusy("Getting Ithuba Confirm Response");

        final Task<IthubaConfirmRes> taskIthubaConfirm = new Task<IthubaConfirmRes>() {
            @Override
            protected IthubaConfirmRes call() throws Exception {
                return getLottoConfirm(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.ithubaLottoResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Ithuba Response Error",
                        "Unable to retrieve Response", State.CANCELLED, errorMsg, null);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Ithuba Response Error",
                        "Unable to retrieve Response", State.FAILED, errorMsg, null);
            }
        };

        new Thread(taskIthubaConfirm).start();
        JKiosk3.getBusy().startCountdown(taskIthubaConfirm, countdownTime);
    }

    private static IthubaLottoRes getFinalLottoResp(IthubaLottoReq req) throws RuntimeException {
        IthubaLottoRes ithubaLottoRes = new IthubaLottoRes();
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {

                if (req.getStructData().get("Game").equalsIgnoreCase("Powerball")) {
                    ithubaLottoRes = connection.powerball(req);
                } else {
                    ithubaLottoRes = connection.lotto(req);
                }

                if (ithubaLottoRes.isSuccess()) {
                    connection.printed(true);
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Lotto Error", t);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return ithubaLottoRes;
    }

    public static void getFinalLottoResp(final IthubaLottoReq req, final IthubaResult result) {
        JKiosk3.getBusy().showBusy("Getting Ithuba Final Response");

        final Task<IthubaLottoRes> taskIthubaResponse = new Task<IthubaLottoRes>() {
            @Override
            protected IthubaLottoRes call() throws Exception {
                return getFinalLottoResp(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.ithubaLottoFinalRes(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Ithuba Response Error",
                        "Unable to retrieve Response", State.CANCELLED, errorMsg, null);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Ithuba Response Error",
                        "Unable to retrieve Response", State.FAILED, errorMsg, null);
            }
        };

        new Thread(taskIthubaResponse).start();
        JKiosk3.getBusy().startCountdown(taskIthubaResponse, countdownTime);

    }

    public static abstract class IthubaResult {

        public abstract void ithubaLottoFinalRes(IthubaLottoRes ithubaLottoRes);
    }

    public static abstract class IthubaConfirmResult {

        public abstract void ithubaLottoResult(IthubaConfirmRes ithubaConfirmRes);
    }
}
