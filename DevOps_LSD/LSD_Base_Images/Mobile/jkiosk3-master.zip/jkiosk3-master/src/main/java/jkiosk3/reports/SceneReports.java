package jkiosk3.reports;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3.SceneMenu;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._common.ResultCallback;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.ResubmitUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;

public class SceneReports extends Region {

    private static VBox vbReportContent;
    private static VBox vbInfo;
    private List<String> reportMenusAllowed;

    public SceneReports() {
        ResubmitUtil.resubmitUnprocessedItems(new ResultCallback() {
            @Override
            public void onResult(boolean result) {
                if (result) {
                    reportMenusAllowed = ReportUtilMenus.getUserMainReportMenu(CurrentUser.getUser().getUserPin());
                    createReportScene();
                }
            }
        });
    }

    private void createReportScene() {
        getChildren().add(JKLayout.getSceneStack(getReportLayout(), this));
    }

    private AnchorPane getReportLayout() {
        VBox menu = getReportMenu();
        vbReportContent = JKLayout.getVBox(0, JKLayout.spNum);
        VBox grpInfo = JKLayout.getSceneInfoBox(265, getSceneInfo());
        VBox grpClose = JKLayout.getMainMenuBtn(new SceneMenu());

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(grpInfo, grpClose);

        AnchorPane ap = JKLayout.getSceneAnchor(menu, vbReportContent, vb);
        ap.getChildren().addAll(menu, vbReportContent, vb);

        return ap;
    }

    private VBox getReportMenu() {

        List<Button> btnList = new ArrayList<>();

        for (String s : reportMenusAllowed) {
            final Button btn = JKNode.getBtnSm(s);
            if (s.equalsIgnoreCase(ReportUtilMenus.REP_BTN_EMERG_TOP_TRANS)
                    || s.equalsIgnoreCase(ReportUtilMenus.REP_BTN_EMERG_TOP_REPRINT)) {
                btn.setFont(JKText.FONT_B_XXSM);
            }
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    getMenuSelection(btn);
                }
            });
            btnList.add(btn);
        }

        return JKLayout.getSceneMenuBtnGroup("", btnList);
    }

    private VBox getSceneInfo() {
        double infoH = 265;

        vbInfo = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
        vbInfo.setMinSize(JKLayout.sideW, infoH);
        vbInfo.setAlignment(Pos.CENTER);

        vbInfo.getChildren().addAll(getSceneInfoContent(false));

        return vbInfo;
    }

    private List<Node> getSceneInfoContent(boolean isReprintView) {
        List<Node> listContent = new ArrayList<>();

        Label lblSupport = JKText.getLblDk("Support", JKText.FONT_B_XXSM);
        Label lblNumber = JKText.getLblDk(JK3Config.getInfoHelpDeskTelNum(), JKText.FONT_B_XXSM);
        Label lblReprint = JKText.getLblDk("Expired Reprints\n\nare shown\n\nDisabled", JKText.FONT_B_XXSM);
        lblReprint.setWrapText(true);
        lblReprint.setPrefWidth(JKLayout.sideW - (2 * JKLayout.sp));
        lblReprint.setTextAlignment(TextAlignment.CENTER);
        if (isReprintView) {
            listContent.add(lblSupport);
            listContent.add(lblNumber);
            listContent.add(new Separator());
            listContent.add(new Label(""));
            listContent.add(lblReprint);
        } else {
            listContent.add(lblSupport);
            listContent.add(lblNumber);
        }

        return listContent;
    }

    private void updateInfo(boolean isReprintView) {
        vbInfo.getChildren().clear();
        if (isReprintView) {
            vbInfo.getChildren().addAll(getSceneInfoContent(true));
        } else {
            vbInfo.getChildren().addAll(getSceneInfoContent(false));
        }
    }

    private void getMenuSelection(Button b) {

        switch (b.getText()) {
            case ReportUtilMenus.REP_BTN_SHIFTS:
                updateInfo(false);
                clearAndChangeContent(new ShiftMenu());
                break;
            case ReportUtilMenus.REP_BTN_ACCS:
                updateInfo(false);
                clearAndChangeContent(new AccountsMenu());
                break;
            case ReportUtilMenus.REP_BTN_TRANS:
                updateInfo(false);
//                clearAndChangeContent(new Transactions());
                clearAndChangeContent(new TransactByDate());
                break;
            case ReportUtilMenus.REP_BTN_REPRINT:
                if (Reprints.getListSched() != null && !Reprints.getListSched().isEmpty()) {
                    for (ScheduledExecutorService s : Reprints.getListSched()) {
                        s.shutdown();
                        System.out.println("shutting down ScheduledExecutorService : " + s.isShutdown());
                    }
                    Reprints.getListSched().clear();
                }
                updateInfo(true);
                clearAndChangeContent(new Reprints());
                break;
            case ReportUtilMenus.REP_BTN_REPRINT_ONLINE:
                updateInfo(false);
                clearAndChangeContent(new ReprintsOnlineSelect());
                break;
            case ReportUtilMenus.REP_BTN_EMERG_TOP_TRANS:
                updateInfo(false);
                clearAndChangeContent(new EmergTopTransactions());
                break;
            case ReportUtilMenus.REP_BTN_EMERG_TOP_REPRINT:
                updateInfo(false);
                clearAndChangeContent(new ReprintEmergTopSelect());
                break;
            default:
                updateInfo(false);
                JKiosk3.getMsgBox().showMsgBox("Reports", "No Report Selected", null);
        }
    }

    public static void clearAndChangeContent(Region newRegion) {
        if (newRegion != null) {
            vbReportContent.getChildren().clear();
            vbReportContent.getChildren().add(newRegion);
        } else {
            vbReportContent.getChildren().clear();
        }
    }

    public static VBox getVbReportContent() {
        return vbReportContent;
    }
}
