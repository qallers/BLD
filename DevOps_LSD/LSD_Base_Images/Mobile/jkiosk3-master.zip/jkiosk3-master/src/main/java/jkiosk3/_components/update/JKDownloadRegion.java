package jkiosk3._components.update;

import Download.HttpUtils;
import Download.ThreadedDownload;
import Install.Installer;
import Install.InstallerProgress;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.ResultCallback;

/**
 *
 * @author valeriew
 */
public class JKDownloadRegion extends Region {

    private final static Logger logger = Logger.getLogger(JKDownloadRegion.class.getName());
    //
    private final DownloadProperties dlProp;
    //
    private ProgressIndicator prog;
    private Label lblCurrent;
    private Label lblPatience;
    private Label lblInfo;
    private String infoPatience;
    //
    private ThreadedDownload threadedDownload;
    private Timer t;

    public JKDownloadRegion(DownloadProperties dlProp, final ResultCallback result) {
        this.dlProp = dlProp;

        if (dlProp.getTitle().equals(StageUpdates.DOWNLOAD_LIB_FILES)) {
            infoPatience = "Please be patient while JKiosk downloads required items" +
                    "\n\nSome large files may cause Progress Indicator" +
                    "\nto appear to freeze" +
                    "\n\nPlease wait until downloads are complete";
        } else {
            infoPatience = "Please be patient while JKiosk downloads required items";
        }

        getChildren().add(showDownloadContent());
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                getZipDownload(result);
            }
        });
    }

    private void getZipDownload(final ResultCallback callback) {
        logger.info(("url of remote file  : ").concat(dlProp.getUrl()));
//        logger.info(("date of remote file : ").concat(new SimpleDateFormat("yyyy-MM-dd HH:mm").format(HttpUtils.getDateFileRemote())));
        //
        threadedDownload = new ThreadedDownload(dlProp.getUrl(), dlProp.getFileDestination(), true);
        t = new Timer();
        t.schedule(new TimerTask() {
            @Override
            public void run() {
                showProgress(callback);
            }
        }, 500);
    }

    private void showProgress(final ResultCallback callback) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {

                boolean done = false;
                if (threadedDownload.isNotNew()) {
                    done = true;
                    lblCurrent.setText("No updates found.");
                    lblPatience.setText("");
                    lblInfo.setText("");
                    callback.onResult(true);
                } else {
                    double percent = threadedDownload.getProgress();
                    prog.setProgress(percent / 100);
                    if (threadedDownload.isDone()) {
//                        if (HttpUtils.isLocalFileComplete(dlProp.getUrl(), dlProp.getFileDestination())) {
//                            logger.info("file retrieved successfully");
//                        } else {
//                            logger.info("file not downloaded");
//                        }
                        logger.info(("   DOWNLOAD IS COMPLETE : ").concat(dlProp.getTitle()));
                        done = true;
                        if (dlProp.getInstallDestination() != null) {
                            doUnpackZip();
                        }
                        callback.onResult(true);
                    } else if (threadedDownload.isFailed()) {
                        logger.info(("   DOWNLOAD FAILED : ").concat(dlProp.getTitle()));
                        done = true;
                        callback.onResult(false);
                    }
                }

                if (!done) {
                    t.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            showProgress(callback);
                        }
                    }, 500);
                } else {
                    t.cancel();
                }
            }
        });
    }

    private void doUnpackZip() {
        /* We need to exclude the 'AutoUpdater.jar' file, or else the system attempts to unzip the jar. */
        if (!dlProp.getTitle().equals(StageUpdates.DOWNLOAD_AUTO_UPDATER)) {
            new Installer(dlProp.getFileDestination(), dlProp.getInstallDestination()).install(new InstallerProgress());
            logger.info(("   unpacked files for : ").concat(dlProp.getTitle()));
        }
    }

    private VBox showDownloadContent() {

        VBox vbDL = new VBox(45);
        vbDL.setPadding(new Insets(30));
        vbDL.getStyleClass().add("vbDownload");
        vbDL.setPrefSize(StageDownload.STAGE_WIDTH, StageDownload.STAGE_HEIGHT);
        prog = new ProgressIndicator();
        prog.setPrefSize(50, 50);

        Label lblDownloading = new Label("Downloading");
        lblDownloading.getStyleClass().add("lblLg");
        lblCurrent = new Label(dlProp.getTitle());
        lblCurrent.getStyleClass().add("lblXLg");
//        lblPatience = new Label("Please be patient while JKiosk downloads required items" +
//                "\n\nSome large files may cause Progress Indicator to appear to freeze" +
//                "\nPlease wait until downloads are complete");
        lblPatience = new Label(infoPatience);
        lblPatience.getStyleClass().add("lblMed");
        lblPatience.setWrapText(true);
        lblPatience.setTextAlignment(TextAlignment.CENTER);
        lblInfo = new Label("This will only happen on first run, or if items are updated.");
        lblInfo.getStyleClass().add("lblSm");
        lblInfo.setWrapText(true);
        lblInfo.setTextAlignment(TextAlignment.CENTER);

        vbDL.getChildren().addAll(prog, lblDownloading, lblCurrent, lblPatience, lblInfo);

        return vbDL;
    }
}
