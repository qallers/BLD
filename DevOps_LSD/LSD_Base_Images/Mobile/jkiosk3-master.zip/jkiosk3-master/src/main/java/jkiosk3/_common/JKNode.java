package jkiosk3._common;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.scene.text.Font;
import jkiosk3.JK3Config;
import jkiosk3._components.ControlSearch;
import jkiosk3.store.JKBranding;
import jkiosk3.store.cache.CacheListCoachCarriers;

public class JKNode {

    public final static String DECREASE = "decrease";
    public final static String INCREASE = "increase";

    /**
     * Creates a VBox containing a list of paged <code>Node</code> items for the specified <code>pageIndex</code>, and
     * containing the specified <code>pageSize</code> number of items.
     *
     * @param pageIndex The page number in the series of pages to be shown.
     * @param nodeList  The full list of <code>Node</code> items that will be displayed.
     * @param pageSize  The number of items to be displayed in a single page view.
     * @return A VBox populated with page <i>x</i> of a list of items.
     */
    public static VBox createPagedVBox(int pageIndex, List<Node> nodeList, int pageSize) {
        return createPagedVBox(pageIndex, nodeList, pageSize, 0);
    }

    /**
     * Creates a VBox containing a list of paged <code>Node</code> items for the specified <code>pageIndex</code>, and
     * containing the specified <code>pageSize</code> number of items.
     *
     * @param pageIndex The page number in the series of pages to be shown.
     * @param nodeList  The full list of <code>Node</code> items that will be displayed.
     * @param pageSize  The number of items to be displayed in a single page view.
     * @param pageHt    The height of the page that this paginated list will be displayed on.
     * @return A VBox populated with page <i>x</i> of a list of items.
     */
    public static VBox createPagedVBox(int pageIndex, List<Node> nodeList, int pageSize, double pageHt) {
        VBox vbPaged = JKLayout.getVBoxLeft(0, JKLayout.sp);
        vbPaged.setPadding(new Insets(JKLayout.sp, JKLayout.sp, 0, 0));
        vbPaged.setMaxWidth(JKLayout.contentW - (2 * JKLayout.sp));
        vbPaged.setMinWidth(JKLayout.contentW - (2 * JKLayout.sp));
        if (pageHt != 0) {
            vbPaged.setMaxHeight(pageHt - 75);
            vbPaged.setMinHeight(pageHt - 75);
        }
        StackPane.setAlignment(vbPaged, Pos.TOP_CENTER);

        int page = pageIndex * pageSize;

        int pageCount = 0;
        if (pageIndex > ((nodeList.size() / pageSize) - 1)) {
            pageCount = nodeList.size() % pageSize;
        } else {
            pageCount = pageSize;
        }
        List<Node> listNodes = new ArrayList<>();
        for (int i = page; i < page + pageCount; i++) {
            listNodes.add(nodeList.get(i));
        }
        vbPaged.getChildren().addAll(listNodes);
        vbPaged.getChildren().add(JKNode.getVSpacer());

        return vbPaged;
    }

    public static HBox createPagedHBox(int pageIndex, List<Node> nodeList, int pageSize, double pgHt) {
        HBox hbPaged = JKLayout.getHBoxLeft(0, JKLayout.sp);
        hbPaged.setMaxWidth(JKLayout.contentW - (2 * JKLayout.sp));
        hbPaged.setMinWidth(JKLayout.contentW - (2 * JKLayout.sp));
        hbPaged.setMaxHeight(pgHt - 75);
        hbPaged.setMinHeight(pgHt - 75);
        StackPane.setAlignment(hbPaged, Pos.TOP_CENTER);

        int page = pageIndex * pageSize;

        int pageCount = 0;
        if (pageIndex > ((nodeList.size() / pageSize) - 1)) {
            pageCount = nodeList.size() % pageSize;
        } else {
            pageCount = pageSize;
        }
        List<Node> listNodes = new ArrayList<>();
        for (int i = page; i < page + pageCount; i++) {
            listNodes.add(nodeList.get(i));
        }
        hbPaged.getChildren().addAll(listNodes);

        return hbPaged;
    }

    public static TilePane createPagedTile(int pageIndex, double height, int columns, int pageSize, List<Button> listToPage) {
        TilePane tile = JKLayout.getTile(0, JKLayout.sp, JKLayout.sp, columns);
        tile.setPadding(new Insets(0, JKLayout.sp, JKLayout.sp, JKLayout.sp));
        tile.setMaxHeight(height);
        tile.setMinHeight(height);
        tile.setAlignment(Pos.TOP_LEFT);

        int page = pageIndex * pageSize;

        int pageCount = 0;
        if (pageIndex > (listToPage.size() / pageSize - 1)) {
            pageCount = listToPage.size() % pageSize;
        } else {
            pageCount = pageSize;
        }
        List<Button> listBtnsPerPage = new ArrayList<>();
        for (int i = page; i < page + pageCount; i++) {
            listBtnsPerPage.add(listToPage.get(i));
        }
        tile.getChildren().addAll(listBtnsPerPage);

        return tile;
    }

    public static VBox getPageDblHeadVB(double padding, Node nodeLeft, Node nodeRight) {
        VBox vb = JKLayout.getVBoxLeft(padding, JKLayout.sp);

        HBox hbHead = JKLayout.getHBox(0, 0);
        if (nodeLeft != null) {
            hbHead.getChildren().addAll(nodeLeft, JKNode.getHSpacer(), nodeRight);
        } else {
            hbHead.getChildren().addAll(JKNode.getHSpacer(), nodeRight);
        }
//        hbHead.getChildren().addAll(nodeLeft, JKNode.getHSpacer(), nodeRight);

        vb.getChildren().addAll(hbHead, JKNode.createContentSep());

        return vb;
    }

    public static VBox getPageHeadVB(String pageTitle) {
        VBox vb = JKLayout.getVBoxLeft(0, JKLayout.sp);

        Label lblHead = JKText.getLblContentHead(pageTitle);

        vb.getChildren().addAll(lblHead, JKNode.createContentSep());

        return vb;
    }

    public static VBox getPageCallMeHeadVB(String pageTitle) {
        VBox vb = JKLayout.getVBoxLeft(0, JKLayout.sp);
        vb.setAlignment(Pos.CENTER);

        Label lblHead = JKText.getLblCenterAlignContentHead(pageTitle);

        vb.getChildren().addAll(lblHead, JKNode.createContentSep());

        return vb;
    }

    public static VBox getReportHeadVB(String reportName) {
        VBox vb = JKLayout.getVBoxLeft(0, JKLayout.sp);

        Label lblHead = JKText.getLblContentHead(reportName + " - "
                + new SimpleDateFormat("dd MMMM yyyy").format(new java.util.Date()));
        if (reportName.contains("Emergency Topup")) {
            lblHead.setFont(JKText.FONT_B_XSM);
        } else {
            lblHead.setFont(JKText.FONT_B_SM);
        }

        vb.getChildren().addAll(lblHead, JKNode.createContentSep());

        return vb;
    }

    public static Button getBtnLg(String lbl) {
        return getBtnAll(lbl, JKText.FONT_B_SM, JKLayout.btnLgW, JKLayout.btnLgH);
    }

    public static Button getBtnMsgBox(String lbl) {
        return getBtnAll(lbl, JKText.FONT_B_XSM, JKLayout.btnSmW, JKLayout.btnToggleH);
    }

    public static Button getBtnNum(String lbl) {
        return getBtnAll(lbl, JKText.FONT_B_MID, JKLayout.btnNumW, JKLayout.btnNumH);
    }

    public static Button getBtnPopup(String lbl) {
        return getBtnAll(lbl, JKText.FONT_B_14, JKLayout.btnNumW, 35);
    }

    public static Button getBtnPopupDbl(String lbl) {
        return getBtnAll(lbl, JKText.FONT_B_14, ((2 * JKLayout.btnNumW) + JKLayout.sp), 35);
    }

    public static Button getBtnSm(String lbl) {
        return getBtnAll(lbl, JKText.FONT_B_XSM, JKLayout.btnSmW, JKLayout.btnSmH);
    }

    public static Button getBtnSmDbl(String lbl) {
        return getBtnAll(lbl, JKText.FONT_B_XSM, ((2 * JKLayout.btnSmW) + JKLayout.sp), JKLayout.btnSmH);
    }

    private static Button getBtnAll(String lbl, Font font, double width, double height) {
        Button btn = new Button(lbl);
        btn.setFont(font);
        btn.setMaxSize(width, height);
        btn.setMinSize(width, height);
        return btn;
    }

    public static Button getBtnIthuba(String lbl, String imgName, double imgWidth, String styleClassName) {
        Button btnIthuba = getBtnSmDbl(lbl);
        ImageView img = getJKImageViewVAS(imgName, imgWidth);
        btnIthuba.setGraphic(img);
        btnIthuba.getStyleClass().addAll("prov_ithuba", styleClassName);
        return btnIthuba;
    }

    public static Button getBtnNFC(String btnText) {
        Button btn = JKNode.getBtnPopupDbl(btnText);
        btn.setFont(JKText.FONT_B_18);
        btn.setMaxSize(((2 * JKLayout.btnSmW) + JKLayout.sp), JKLayout.btnToggleH);
        btn.setMinSize(((2 * JKLayout.btnSmW) + JKLayout.sp), JKLayout.btnToggleH);
        btn.getStyleClass().add("btnNFC");
        return btn;
    }

    public static Button getBtnNfcImg() {
        Image img = new Image(JKNode.class.getClassLoader().getResourceAsStream("jkiosk3/images/nfc.png"));
        ImageView imgNFC = new ImageView(img);
        imgNFC.setFitHeight(55);
        imgNFC.setPreserveRatio(true);

        Button btnNfc = JKNode.getBtnSm("");
        btnNfc.setGraphic(imgNFC);
        btnNfc.getStyleClass().add("btnNFC");

        return btnNfc;
    }

    public static VBox getNFCpgHead(String pgTitle) {
        Label lblHead = JKText.getLblDk(pgTitle, JKText.FONT_B_SM);

        Button btnNfc = JKNode.getBtnNfcImg();

        VBox vbHead = JKNode.getPageDblHeadVB(0, lblHead, btnNfc);
        return vbHead;
    }

    public static String getBrandButton() {
        String brandColour = JKBranding.getBranding().getMerchantGroup().getPrimaryColourHex();
        return "-fx-text-fill: " + brandColour + "; -fx-border-color: " + brandColour + ";";
    }

    public static ToggleButton getToggleSm(String lbl) {
        return getToggleAll(lbl, null, JKLayout.btnSmW, JKLayout.btnToggleH);
    }

    public static ToggleButton getToggleSmDbl(String lbl) {
        return getToggleAll(lbl, JKText.FONT_B_XXSM, (2 * JKLayout.btnSmW), 35);
    }

    private static ToggleButton getToggleAll(String lbl, Font font, double width, double height) {
        ToggleButton toggle = new ToggleButton(lbl);
        if (font != null) {
            toggle.setFont(font);
        }
        toggle.setPrefSize(width, height);
        toggle.getStyleClass().add("toggle-button");
        return toggle;
    }

    public static TextField getTextField35H() {
        TextField txmfld = new TextField();
        txmfld.setMaxHeight(35);
        txmfld.setMinHeight(35);
        return txmfld;
    }

    public static TextField getTextFieldSmRight() {
        TextField txmSmRight = new TextField();
        txmSmRight.setMinWidth(JKLayout.btnNumW);
        txmSmRight.setMaxWidth(JKLayout.btnNumW);
        txmSmRight.getStyleClass().add("txtfld-right");
        return txmSmRight;
    }

    public static TextField getTextFieldRight() {
        TextField txmRight = new TextField();
        txmRight.getStyleClass().add("txtfld-right");
        return txmRight;
    }

    public static ImageView getJKImageView(String imgName, double width, double height) {
        Image img = new Image("file:media/branding/BLD/lg_BLD.png");
        if (JKBranding.getBranding().getMerchantGroup() == null) {
            img = new Image("file:media/branding/BLD/lg_BLD.png");
        } else {
            img = new Image("file:media/branding/" + JKBranding.getBranding().getMerchantGroup().getCode() + "/" + imgName);
        }
        ImageView imgV = new ImageView(img);
        if (width > 0 && height == 0) {
            imgV.setFitWidth(width);
        } else if (width == 0 && height > 0) {
            imgV.setFitHeight(height);
        } else if (width > 0 && height > 0) {
            imgV.setFitWidth(width);
            imgV.setFitHeight(height);
        }
        imgV.setPreserveRatio(true);
        return imgV;
    }

    public static ImageView getJKImageViewBlank() {
        Image img = new Image("file:media/images/prov_blank.png");
        return new ImageView(img);
    }

    public static ImageView getImageViewC4CProvider(String imgName) {
        String imgUrl = JK3Config.getMediaImages() + imgName;
        try (BufferedInputStream imgIn = new BufferedInputStream(new FileInputStream(imgUrl))) {
            Image img = new Image(imgIn);
            ImageView imgView = new ImageView(img);
            return imgView;
        } catch (IllegalArgumentException | IOException e) {    // will return null if the image does not exist
            return null;
        }
    }

    public static ImageView getImageViewCarmaCarrier(String imgName) {
        ImageView imgViewCarma = JKNode.getJKImageViewProvider(imgName);
        imgViewCarma.setFitWidth(115.0D);
        imgViewCarma.setPreserveRatio(true);
        return imgViewCarma;
    }

    public static ImageView getImageViewCoachCarrier(String carrierCode) {
        Image img = null;
//        String imgUrl = CacheListCoachCarriers.getListCoachCarriers().getMediaUrl() + "/" + carrierCode + "/" + carrierCode + ".png";
        String imgUrl = CacheListCoachCarriers.getListCoachCarriers().getMediaUrl() + "/" + carrierCode + ".png";
        try (BufferedInputStream imgIn = new BufferedInputStream(new FileInputStream(imgUrl))) {
            img = new Image(imgIn);
        } catch (IllegalArgumentException | IOException e) {
            img = getImageBlank();
        }
        ImageView imgView = new ImageView(img);
        return imgView;
    }

    public static ImageView getJKImageViewProvider(String imgName) {
        Image img = null;
        String imgUrl = JK3Config.getMediaImages() + imgName;
        try (BufferedInputStream imgIn = new BufferedInputStream(new FileInputStream(imgUrl))) {
            img = new Image(imgIn);
        } catch (IllegalArgumentException | IOException e) {
            img = getImageBlank();
        }
        ImageView imgView = new ImageView(img);
        return imgView;
    }

    public static ImageView getJKImageViewVAS(String imgName, double imgWidth) {
        ImageView img = JKNode.getJKImageViewProvider(imgName);
        img.setFitWidth(imgWidth);
        img.setPreserveRatio(true);
        return img;
    }

    public static Node getHSpacer() {
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        return spacer;
    }

    public static Node getVSpacer() {
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        return spacer;
    }

    public static Group getContentGroup(Region regionContent) {
        Group grp = new Group();
        Rectangle rec = new Rectangle();
        rec.setWidth(JKLayout.contentW);
        rec.heightProperty().bind(regionContent.heightProperty());
        grp.getChildren().addAll(rec, regionContent);
        return grp;
    }

    public static Separator createContentSep() {
        Separator sep = new Separator();
        sep.setMaxWidth(JKLayout.contentW - (2 * JKLayout.sp));
        sep.setMinWidth(JKLayout.contentW - (2 * JKLayout.sp));
        return sep;
    }

    public static Separator createGridSpanSep(int cols) {
        Separator sep = new Separator();
        GridPane.setColumnSpan(sep, cols);
        return sep;
    }

    /* Button for each AirtimeManufacturer (Provider) */
    public static Button getAirtimeProviderButton(String providerId, String voucherName) {
        Button btnProv = JKNode.getBtnSm("");

        String imgUrl = "";
        if (providerId != null) {
            imgUrl = "prov_" + providerId + ".png";
            btnProv.getStyleClass().add("prov_" + providerId + "_fix");
        } else {
            imgUrl = "prov_blank.png";
        }

        ImageView imgViewAM = getJKImageViewProvider(imgUrl);

        btnProv.setGraphic(imgViewAM);
        return btnProv;
    }

    /* Blank button for when images cannot be found, or do not exist */
    public static Image getImageBlank() {
        Image img = null;
        String imgUrl = JK3Config.getMediaImages() + "prov_blank.png";
        try (BufferedInputStream imgIn = new BufferedInputStream(new FileInputStream(imgUrl))) {
            img = new Image(imgIn);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return img;
    }

    /* Default TicketPro image for Event buttons, for when images cannot be retrieved, or do not exist */
    public static Image getImageTicketPro() {
        Image img = null;
        String imgUrl = JK3Config.getMediaImages() + "TicketPros.png";
        try (BufferedInputStream imgIn = new BufferedInputStream(new FileInputStream(imgUrl))) {
            img = new Image(imgIn);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return img;
    }

    public static VBox getPutcoHeader(String headertxt) {
        Label lblHead = JKText.getLblDk(headertxt, JKText.FONT_B_SM);
        ImageView img = getJKImageViewProvider("prov_Putco.png");

        VBox vbHead = getPageDblHeadVB(0, lblHead, img);

        return vbHead;
    }

    public static ControlSearch getSearchPlaceHolderInactive() {
        ControlSearch ctrl = new ControlSearch();
        ctrl.getBtnSearch().setDisable(true);
        ctrl.getBtnClear().setDisable(true);
        ctrl.setVisible(false);
        return ctrl;
    }

    public static StackPane createArrowStack(String direction, double rotate) {
        double w = 35;
        double h = 35;
        double x1 = w - 5;
        double y1 = 3;
        double x2 = 3;
        double y2 = h * 0.5;
        double x3 = 5;
        double y3 = h - 3;
        double x4 = w - 3;
        double x5 = w * 0.65;
        double x6 = w * 0.35;
        StackPane stackArrow = new StackPane();
        stackArrow.setMaxSize(w, h);
        stackArrow.setMinSize(w, h);
        stackArrow.getStyleClass().add("stackArrow");

        SVGPath svg = new SVGPath();
        switch (direction) {
            case DECREASE:
                svg.setContent("M" + x1 + "," + y1 + " L" + x2 + "," + y2 + " L" + x1 + "," + y3 + " L" + x5 + "," + y2 + " Z");
                svg.setRotate(rotate);
                break;
            case INCREASE:
                svg.setContent("M" + x3 + "," + y1 + " L" + x4 + "," + y2 + " L" + x3 + "," + y3 + " L" + x6 + "," + y2 + " Z");
                svg.setRotate(rotate);
                break;
            default:
                break;
        }

        svg.getStyleClass().add("svgArrow");
        svg.setScaleX(0.8);
        svg.setScaleY(0.7);
        stackArrow.getChildren().add(svg);
        stackArrow.setScaleY(0.95);
        return stackArrow;
    }

    public static String popupTextFormat(String text, int size){
        char[] ch = text.toCharArray();
        StringBuilder builder = new StringBuilder();

        int count = 0;
        for (char c : ch) {
            if(count == size) {
                builder.append(c).append("\n");
                count = 0;
            } else {
                builder.append(c);
            }

            count++;
        }

        return builder.toString();
    }
}
