package jkiosk3.sales.ticketpro;

import aeonticketpros.TicketProAllowedProduct;
import aeonusers.User;
import javafx.application.Platform;
import jkiosk3.JK3Config;
import jkiosk3._common.ResultCallback;
import jkiosk3.sales.ticketpro.cache.CacheControllerTicketPro;
import jkiosk3.sales.ticketpro.sale.TicketProCategories;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.print_layouts.PrintTicketPro;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.TicketingMenu;
import jkiosk3.sales.ticketpro.collect.TicketProCollect;
import jkiosk3.sales.ticketpro.reprint.TicketProReprint;
import jkiosk3.sales.ticketpro.sale_bus.TicketProBusBook1;
import jkiosk3.store.JKPrinterTickets;
import jkiosk3.users.SalesUserLoginResult;
import jkiosk3.users.UserUtil;

public class TicketProMenu extends Region {

    private final static Logger logger = Logger.getLogger (TicketProMenu.class.getName ());
    private static List<TicketProAllowedProduct> listAllowed;

    public TicketProMenu() {
        TicketProUtil.getAllowedProducts (new TicketProUtil.TicketProAllowedProductsListResult () {
            @Override
            public void tpAllowedProductsListResult(List<TicketProAllowedProduct> tpAllowedList) {
                if (!tpAllowedList.isEmpty ()) {
                    listAllowed = tpAllowedList;
                    getChildren ().add (getMenuGroup ());
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Menu", "No Allowed Products Found", null);
                    SceneSales.clearAndChangeContent (new TicketingMenu ());
                }
            }
        });
    }

    private VBox getMenuGroup() {

        VBox vbHead = JKNode.getPageHeadVB ("TicketPro Menu");

        List<Button> listBtns = getMenuButtons ();

        TilePane tile = JKLayout.getTiledBtns (0, JKLayout.sp, JKLayout.sp, 2, listBtns);

        VBox vb = JKLayout.getVBoxContent (JKLayout.sp);
        vb.getChildren ().addAll (vbHead, tile);

        return vb;
    }
//                <vasproduct id="682">Ticket Pro - Collection </vasproduct>
//                <vasproduct id="188">Ticket Pro - Events</vasproduct>
//                <vasproduct id="688">Ticket Pro - Putco</vasproduct>

    private List<Button> getMenuButtons() {
        List<Button> btnList = new ArrayList<> ();

        List<String> btnLabels = new ArrayList<> ();
        btnLabels.add (TicketProUtil.TICKETPRO_CANCELLATIONS);
        btnLabels.add (TicketProUtil.TICKETPRO_REPRINT);

        for (TicketProAllowedProduct prod : listAllowed) {
            final Button btnProd = JKNode.getBtnSmDbl ("");
            btnProd.setId (Integer.toString (prod.getProductId ()));
            if (prod.getProductId () == 188) {
                btnProd.setText (TicketProUtil.TICKETPRO_SALES);
            }
            if (prod.getProductId () == 688) {
                btnProd.setText (TicketProUtil.TICKETPRO_SALES_BUS);
            }
            if (prod.getProductId () == 682) {
                btnProd.setText (TicketProUtil.TICKETPRO_COLLECT);
            }
            btnProd.getStyleClass ().add ("btnTicketPros");
            btnProd.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event evt) {
                    getMenuAction (btnProd);
                }
            });
            btnList.add (btnProd);
        }

        for (String s : btnLabels) {
            final Button btn = JKNode.getBtnSmDbl (s);
            btn.setId (s);
            btn.getStyleClass ().add ("btnTicketPros");
            btn.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event evt) {
                    getMenuAction (btn);
                }
            });
            btnList.add (btn);
        }

        return btnList;
    }

    private void getMenuAction(Button b) {

        logger.info (("TicketPro menu option selected : ").concat (b.getId ()));

        switch (b.getText ()) {
            case TicketProUtil.TICKETPRO_SALES:
                CacheControllerTicketPro cacheControllerTicketPro = TicketProUtil.getCacheControllerTicketPro ();
                cacheControllerTicketPro.updateTPCache (true, new ResultCallback () {
                    @Override
                    public void onResult(boolean result) {
                        Platform.runLater (new Runnable () {
                            @Override
                            public void run() {
                                TicketProSale.newInstance ();
                                SceneSales.clearAndChangeContent (new TicketProCategories ());
                            }
                        });
                    }
                });
                break;
            case TicketProUtil.TICKETPRO_SALES_BUS:
                if (!JKPrinterTickets.getPrinterTickets ().isUseDefaultPrinter ()) {
                    TicketProBusSale.resetTicketProBusSale ();
                    JKiosk3.getSalesUserLogin ().showUserLogin (new SalesUserLoginResult () {
                        @Override
                        public void onDone() {
                            SceneSales.clearAndChangeContent (new TicketProBusBook1 ());
                        }
                    });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Ticket Printer", "Bus Tickets Not Available\n\n"
                            + "This option requires a Ticket Printer", null);
                }

                break;
            case TicketProUtil.TICKETPRO_CANCELLATIONS:
                String message = "\nPlease refer the Customer to\n\nTicketPro Customer Services\n\n" +
                        JK3Config.getInfoTicketProCustomerServicesTelNum ()
                        + "\n\nMon - Fri : 08h00 - 16h00\n\n" + JK3Config.getInfoTicketProCustomerServicesEmail () + "\n\n";
                Label lblPrintOrCancel = JKText.getLblDk ("Click 'OK' to print, 'Cancel' for no print", JKText.FONT_B_XXSM);
                JKiosk3.getMsgBox ().showMsgBox ("TicketPro Cancellations / Refunds", message, lblPrintOrCancel,
                        MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {

                            @Override
                            public void onOk() {
                                PrintHandler.handlePrintRefund ("TicketPro Customer Services",
                                        PrintTicketPro.getTicketProCustomerServicePrint (null));
                            }

                            @Override
                            public void onCancel() {
                                //
                            }
                        });
                break;
            case TicketProUtil.TICKETPRO_COLLECT:
                JKiosk3.getSalesUserLogin ().showUserLogin (new SalesUserLoginResult () {
                    @Override
                    public void onDone() {
                        SceneSales.clearAndChangeContent (new TicketProCollect ());
                    }
                });
                break;
            case TicketProUtil.TICKETPRO_REPRINT:
                final PasswordField pwd = new PasswordField ();
                JKiosk3.getNumPad ().showNumPad (pwd, "Enter User Pin", "", new NumberPadResult () {
                    @Override
                    public void onDone(String value) {
                        String userPin = pwd.getText ();
                        onSelectReprint (userPin);
                    }
                });
                break;
            default:
                JKiosk3.getMsgBox ().showMsgBox ("Error", "Invalid selection", null);
        }
    }

    public static void onSelectReprint(final String userPin) {
        UserUtil.getLoggedInUser (userPin, new UserUtil.LoggedInUserResult () {

            @Override
            public void loggedInUserResult(User loggedInUser) {
                if (loggedInUser.isSuccess ()) {
                    int userLevel = loggedInUser.getUserLevel ();
                    if (userLevel == 0 || userLevel == 2) {
                        JKiosk3.getMsgBox ().showMsgBox ("Access Denied",
                                "Menu Item not available for this Access Level", null);
                    } else if (userLevel == 1) {
                        SceneSales.clearAndChangeContent (new TicketProReprint ());
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Login Failed",
                            !loggedInUser.getAeonErrorText ().isEmpty () ?
                                    "A" + loggedInUser.getAeonErrorCode () + " - " + loggedInUser.getAeonErrorText () :
                                    "B" + loggedInUser.getErrorCode () + " - " + loggedInUser.getErrorText (), null);
                }
            }
        });
    }
}
