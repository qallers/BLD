package jkiosk3.sales.search;

public enum SearchTransType {

    BILL_PAYMENT,
    SMS_BUNDLE,
    AIRTIME_VOUCHER,
    ELECTRICITY_VOUCHER,
    DATA_VOUCHER,
    OTHER_VOUCHER,
    CHAT4CHANGE,
    AIRTIME_TOPUP,
    DATA_TOPUP,
    ELECTRICITY,
    TOPUP_WALLET,
    ;

}
