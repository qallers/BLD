package jkiosk3.sales.billpay.payat;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.payat.PayAtIPPayConfReq;
import aeonbillpayments.payat.PayAtIPPayConfResp;
import aeonbillpayments.payat.PayAtIPPayReq;
import aeonbillpayments.payat.PayAtIPPayResp;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.BillPayUtilPayAt;
import jkiosk3.sales.billpay.BillPayUtilPayAt.PayAtInsurancePayConfirm;
import jkiosk3.sales.billpay.BillPayUtilPayAt.PayAtInsurancePayResponse;
import jkiosk3.sales.billpay._common.BillPayEntry;
import jkiosk3.sales.billpay._common.BillPayInsuranceMenu;
import jkiosk3.sales.billpay._common.BillPaymentSelect;
import jkiosk3.sales.billpay.insurance.PolicyRegistration;
import jkiosk3.users.UserUtil;

public class InputPayAtInsurance extends Region {

    private BillPaymentConnection connection;
    private final BillPayProduct product;
    private final String caller;
    private final VBox vbContent;
    private BillPayEntry gridPol;
    private GridPane gridAmtDetail;
    private JKioskNav nav;
    private String policyNum;
    private int monthsSelected;
    private double amtPremium;
    private double amtPayable;
    private double amtTotal;
    private String acceptPartPayment;
    private JKTenderToggles tenders;
    private String tendered;
    private PayAtIPPayReq request1;
    private PayAtIPPayResp response1;
    private PayAtIPPayReq request2;
    private PayAtIPPayResp response2;
    private boolean showFavourites;
    private boolean showProductFavourite;

    public InputPayAtInsurance(BillPayProduct p, String caller, boolean isNFCFavourite, boolean isProductFavourite) {
        this.product = p;
        this.caller = caller;
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;

        vbContent = JKLayout.getVBoxContent (JKLayout.spNum);

        VBox vbLayout = JKLayout.getVBox (0, 5);
        vbLayout.getChildren ().add (getPolicyNumberEntry ());
        vbLayout.getChildren ().add (getNav ());

        getChildren ().add (vbLayout);
    }

    private VBox getPolicyNumberEntry() {

        ImageView img = BillPayUtilMisc.getImageViewBillPay ("prov_PayAt.png");

        gridPol = new BillPayEntry ("Insurance Policy Payment", img, product, BillPayEntry.TYPE_INS_POLICY, showFavourites, showProductFavourite);
        if (caller.equalsIgnoreCase (BillPayUtilMisc.INSURE_REGISTER)) {
            gridPol.getTxtNumber ().setText (PolicyRegistration.getInstance ().getPolicyNumber ());
        }
        gridPol.getBtnDetail ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (vbContent.getChildren ().contains (gridAmtDetail)) {
                    vbContent.getChildren ().remove (gridAmtDetail);
                    getPolicyRequestQuery ();
                } else {
                    System.out.println ("about to get policy holder detail...");
                    getPolicyRequestQuery ();
                }
            }
        });

        vbContent.getChildren ().add (gridPol);

        return vbContent;
    }

    private GridPane getDetailAndAmountEntry() {

        GridPane gridDetail = BillPayUtilMisc.getGridBillPayDetail (response1.getAmountDue (), response1.getConvenienceFee (),
                acceptPartPayment, BPTransType.BILLPAY_PAYAT_INSURANCE.getDisplayName ());

        Label lblMonths = JKText.getLblDk ("Months", JKText.FONT_B_XSM);
        Label lblTotal = JKText.getLblDk ("New Total", JKText.FONT_B_XSM);

        monthsSelected = 1;
        amtPayable = (monthsSelected * amtPremium);
        amtTotal = (monthsSelected * amtPremium) + response1.getConvenienceFee ();
        final Text txtTotal = JKText.getTxtDk (JKText.getDeciFormat (amtTotal), JKText.FONT_B_SM);

        ComboBox comMonths = new ComboBox ();
        comMonths.setPrefWidth (100);
        if (caller.equalsIgnoreCase (BillPayUtilMisc.INSURE_REGISTER)
                || response1.getAcceptPartPayment ().equalsIgnoreCase ("N")) {
            comMonths.setDisable (true);
        } else {
            comMonths.setDisable (false);
            comMonths.setVisibleRowCount (12);
        }

        Object[] strMonths = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"};
        comMonths.getItems ().addAll (strMonths);
        comMonths.getSelectionModel ().select (0);
        comMonths.getSelectionModel ().selectedItemProperty ().addListener (new ChangeListener () {
            @Override
            public void changed(ObservableValue arg0, Object oldMths, Object newMths) {
                if (newMths != null) {
                    monthsSelected = Integer.parseInt (newMths.toString ());
                    amtPayable = (monthsSelected * amtPremium);
                    amtTotal = (monthsSelected * amtPremium) + response1.getConvenienceFee ();
                    txtTotal.setText (JKText.getDeciFormat (amtTotal));
                }
            }
        });

        HBox hbMonths = JKLayout.getHBox (0, JKLayout.sp);
        hbMonths.getChildren ().addAll (lblMonths, JKNode.getHSpacer (), comMonths);

        HBox hbTotal = JKLayout.getHBox (0, JKLayout.sp);
        hbTotal.getChildren ().addAll (JKNode.getHSpacer (), lblTotal, JKNode.getHSpacer (), txtTotal);

        gridAmtDetail = JKLayout.getContentGridInner2Col (0.5, 0.5);

        gridAmtDetail.add (gridDetail, 0, 1, 2, 1);
        gridAmtDetail.addRow (2, hbMonths, hbTotal);
        gridAmtDetail.addRow (3, getTenderTypes ());

        return gridAmtDetail;
    }

    private JKTenderToggles getTenderTypes() {
        tenders = new JKTenderToggles (SaleType.BILLPAYMENTS.getDisplay ());
        for (ToggleButton b : tenders.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(javafx.event.Event e) {
                    tendered = tenders.getTenderTypeSelected ();
                    submitPayAtPolicyPaymentRollback (request1, response1, BillPayUtilMisc.CALL_BY_TENDER);
                }
            });
        }
        return tenders;
    }

    private JKioskNav getNav() {
        nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (gridPol.getVbHead ().getChildren ().contains (gridPol.getGridEnter ())) {
                    SceneSales.clearAndChangeContent (new BillPaymentSelect (
                            BillPayUtilMisc.TYPE_INSURE_PAY + " Providers", BillPayUtilMisc.TYPE_INSURE_PAY));
                } else {
                    SceneSales.clearAndChangeContent (new InputPayAtInsurance (product, caller, showFavourites, showProductFavourite));
                }
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                BillPayUtilMisc.resetBillPayView ();
                if (request1 != null) {
                    submitPayAtPolicyPaymentRollback (request1, response1, BillPayUtilMisc.CALL_BY_CANCEL);
                }
            }
        });
        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private void showConfirmationSummary() {
        SummaryPayAtInsurance summary = new SummaryPayAtInsurance (request2, response2, monthsSelected, amtPremium, tendered);

        JKiosk3.getMsgBox ().showMsgBox (BPTransType.BILLPAY_PAYAT_INSURANCE.getDisplayName (), "Confirm all details before proceeding",
                summary, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        submitPayAtPolicyPaymentCommit (request2, response2);
                    }

                    @Override
                    public void onCancel() {
                        UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                        BillPayUtilMisc.resetBillPayView ();
                        submitPayAtPolicyPaymentRollback (request2, response2, BillPayUtilMisc.CALL_BY_CANCEL);
                    }
                });
    }

    //====================================
    // above - mostly view
    // below - mostly process
    //====================================
    private void getPolicyRequestQuery() {
        policyNum = gridPol.getAccountNumberConfirmed ();

        request1 = new PayAtIPPayReq ();
        request1.setProviderId (product.getProvId ());
        request1.setProductId (product.getProdId ());
        request1.setPolicyNumber (policyNum);
        request1.setAmount (0.0);
        request1.setPaymentRefNumber ("");
        request1.setStoreId ("");
        request1.setTillId ("");
        request1.setPaymentReceiptNo ("");
        request1.setEcho ("");
        request1.setRealTime (1);
//        request1.setVerifyOnly(0);
        request1.setVerifyOnly (1);

        System.out.println ("PayAtIPPayReq created, off to request detail...");

        BillPayUtilPayAt.getPayAtInsurancePaymentResponse (request1, new PayAtInsurancePayResponse () {
            @Override
            public void payAtInsurancePayResp(BillPaymentConnection connect, PayAtIPPayResp resp) {
                connection = connect;

                if (resp.isSuccess () && resp.getMessageCode () == 0) {
                    response1 = resp;
                    switch (resp.getAcceptPartPayment ()) {
                        case "Y":
                            acceptPartPayment = "Yes";
                            break;
                        case "N":
                            acceptPartPayment = "No";
                            break;
                        default:
                            JKiosk3.getMsgBox ().showMsgBox ("Pay@ Insurance Payment", "No Part Payment Result Received", null);
                    }
                    amtPremium = resp.getAmountDue ();
                    gridPol.getVbHead ().getChildren ().remove (gridPol.getGridEnter ());
                    gridPol.getVbHead ().getChildren ().add (gridPol.getGridDetail (resp.getPaymentRefNumber (),
                            resp.getFirstName () + " " + resp.getLastName ()));
                    gridAmtDetail = getDetailAndAmountEntry ();
                    vbContent.getChildren ().add (1, gridAmtDetail);
                } else if (resp.isSuccess () && resp.getMessageCode () != 0) {
                    JKiosk3.getMsgBox ().showMsgBox ("Policy Detail Error", resp.getMessageCode () + " - " + resp.getMessageDescription ()
                                    + "\n\nHas the correct Policy type been selected?", null, MessageBox.CONTROLS_SHOW,
                            MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    SceneSales.clearAndChangeContent (new BillPayInsuranceMenu ());
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Policy Detail Error", (!resp.getAeonErrorText ().isEmpty () ?
                            "A" + resp.getAeonErrorCode () + " - " + resp.getAeonErrorText () :
                            "B" + resp.getErrorCode () + " - " + resp.getErrorText ()), null);
                    BillPayUtilMisc.resetBillPayView ();
                }
            }
        });
    }

    private void getPolicyRequestPay() {
        request2 = new PayAtIPPayReq ();
        request2.setProviderId (product.getProvId ());
        request2.setProductId (product.getProdId ());
        request2.setPolicyNumber (policyNum);
        request2.setAmount (amtPayable);
        request2.setPaymentRefNumber ("");
        request2.setStoreId ("");
        request2.setTillId ("");
        request2.setPaymentReceiptNo ("");
        request2.setEcho ("");
        request2.setRealTime (1);
        request2.setVerifyOnly (0);

        BillPayUtilPayAt.getPayAtInsurancePaymentResponse (request2, new PayAtInsurancePayResponse () {
            @Override
            public void payAtInsurancePayResp(BillPaymentConnection connect, PayAtIPPayResp resp) {
                connection = connect;

                if (resp.isSuccess ()) {
                    response2 = resp;
                    showConfirmationSummary ();
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Policy Detail Error",
                            !resp.getAeonErrorText ().isEmpty () ?
                                    "A" + resp.getAeonErrorCode () + " - " + resp.getAeonErrorText () :
                                    "B" + resp.getErrorCode () + " - " + resp.getErrorText (), null);
                    BillPayUtilMisc.resetBillPayView ();
                }
            }
        });
    }

    private void submitPayAtPolicyPaymentCommit(PayAtIPPayReq reqCommit, PayAtIPPayResp respCommit) {
        final PayAtIPPayConfReq confCommit = new PayAtIPPayConfReq ();

        confCommit.setProviderId (reqCommit.getProviderId ());
        confCommit.setProductId (reqCommit.getProductId ());
        confCommit.setConfirmType ("commit");
        confCommit.setTransactionId (respCommit.getTransactionID ());
        confCommit.setTenderType (tendered);
        confCommit.setWantPrintJob (true);

        BillPayUtilPayAt.getPayAtInsurancePaymentConfirm (connection, confCommit, new PayAtInsurancePayConfirm () {
            @Override
            public void payAtInsurancePayConf(final PayAtIPPayConfResp insConfResp) {
                if (insConfResp.isSuccess ()) {
                    String descript = product.getProdName () + " - " + request2.getPolicyNumber ();
                    if (insConfResp.getResponseCode ().equals ("0")) {

                        SalesUtil.processBillPayment (BPTransType.BILLPAY_PAYAT_INSURANCE.getDisplayName (), response2.getTransRef (), descript, amtTotal,
                                tendered, "Payment Success", insConfResp.getPrintLines (), insConfResp.getMerchantPrintLines ());
                    }
                } else if (!insConfResp.getAeonErrorText ().isEmpty ()) {
                    JKiosk3.getMsgBox ().showMsgBox ("Policy Payment Error", "A" + insConfResp.getAeonErrorCode () + "  -  " + insConfResp.getErrorText (), null);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Policy Payment Error", "B" + insConfResp.getErrorCode () + " - " + insConfResp.getErrorText (), null);
                }
                BillPayUtilMisc.resetBillPayView ();
            }
        });
    }

    private void submitPayAtPolicyPaymentRollback(PayAtIPPayReq reqRollback, PayAtIPPayResp respRollback, final String calledBy) {
        PayAtIPPayConfReq confRollback = new PayAtIPPayConfReq ();

        confRollback.setProviderId (reqRollback.getProviderId ());
        confRollback.setProductId (reqRollback.getProductId ());
        confRollback.setConfirmType ("rollback");
        confRollback.setTransactionId (respRollback.getTransactionID ());
        if (tendered != null) {
            confRollback.setTenderType (tendered);
        } else {
            confRollback.setTenderType ("cash");
        }

        BillPayUtilPayAt.getPayAtInsurancePaymentConfirm (connection, confRollback, new PayAtInsurancePayConfirm () {
            @Override
            public void payAtInsurancePayConf(PayAtIPPayConfResp insConfResp) {
                if (insConfResp.isSuccess ()) {
                    switch (calledBy) {
                        case BillPayUtilMisc.CALL_BY_CANCEL:
                            JKiosk3.getMsgBox ().showMsgBox ("Insurance Policy Payment", "Transaction cancelled by User", null);
                            BillPayUtilMisc.resetBillPayView ();
                            break;
                        case BillPayUtilMisc.CALL_BY_TENDER:
                            getPolicyRequestPay ();
                            break;
                        default:
                            JKiosk3.getMsgBox ().showMsgBox ("Pay@ Insurance Payment", "Unable to Determine Rollback Requestor", null);
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Policy Payment Rollback Error",
                            (!insConfResp.getAeonErrorText ().isEmpty () ?
                                    "A" +insConfResp.getAeonErrorCode () + " - " + insConfResp.getAeonErrorText () :
                                    "B" +insConfResp.getErrorCode () + " - " + insConfResp.getErrorText ()), null);
                }
            }
        });
    }

//    private BillPaymentConnection connection;
//    private final BillPayProduct product;
//    private final String caller;
//    private final VBox vbContent;
//    private BillPayEntry gridPol;
//    private GridPane gridAmtDetail;
//    private JKioskNav nav;
//    private String policyNum;
//    private int monthsSelected;
//    private double amtPremium;
//    private double amtPayable;
//    private double amtTotal;
//    private String acceptPartPayment;
//    private JKTenderToggles tenders;
//    private String tendered;
//    private PayAtIPPayReq request1;
//    private PayAtIPPayResp response1;
//    private PayAtIPPayReq request2;
//    private PayAtIPPayResp response2;
//    private boolean showFavourites;
//
//    public InputPayAtInsurance(BillPayProduct p, String caller, boolean isFavourite) {
//        this.product = p;
//        this.caller = caller;
//        this.showFavourites = isFavourite;
//
//        vbContent = JKLayout.getVBoxContent(JKLayout.spNum);
//
//        VBox vbLayout = JKLayout.getVBox(0, 5);
//        vbLayout.getChildren().add(getPolicyNumberEntry());
//        vbLayout.getChildren().add(getNav());
//
//        getChildren().add(vbLayout);
//    }
//
//    private VBox getPolicyNumberEntry() {
//
//        ImageView img = BillPayUtilMisc.getImageViewBillPay("prov_PayAt.png");
//
//        gridPol = new BillPayEntry("Insurance Policy Payment", img, product, BillPayEntry.TYPE_INS_POLICY, showFavourites);
//        if (caller.equalsIgnoreCase(BillPayUtilMisc.INSURE_REGISTER)) {
//            gridPol.getTxtNumber().setText(PolicyRegistration.getInstance().getPolicyNumber());
//        }
//        gridPol.getBtnDetail().setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
//                if (vbContent.getChildren().contains(gridAmtDetail)) {
//                    vbContent.getChildren().remove(gridAmtDetail);
//                    getPolicyRequestQuery();
//                } else {
//                    System.out.println("about to get policy holder detail...");
//                    getPolicyRequestQuery();
//                }
//            }
//        });
//
//        vbContent.getChildren().add(gridPol);
//
//        return vbContent;
//    }
//
//    private GridPane getDetailAndAmountEntry() {
//
//        GridPane gridDetail = BillPayUtilMisc.getGridBillPayDetail(response1.getAmountDue(), response1.getConvenienceFee(),
//                acceptPartPayment, BPTransType.BILLPAY_PAYAT_INSURANCE.getDisplayName());
//
//        Label lblMonths = JKText.getLblDk("Months", JKText.FONT_B_XSM);
//        Label lblTotal = JKText.getLblDk("New Total", JKText.FONT_B_XSM);
//
//        monthsSelected = 1;
//        amtPayable = (monthsSelected * amtPremium);
//        amtTotal = (monthsSelected * amtPremium) + response1.getConvenienceFee();
//        final Text txtTotal = JKText.getTxtDk(JKText.getDeciFormat(amtTotal), JKText.FONT_B_SM);
//
//        ComboBox comMonths = new ComboBox();
//        comMonths.setPrefWidth(100);
//        if (caller.equalsIgnoreCase(BillPayUtilMisc.INSURE_REGISTER)
//                || response1.getAcceptPartPayment().equalsIgnoreCase("N")) {
//            comMonths.setDisable(true);
//        } else {
//            comMonths.setDisable(false);
//            comMonths.setVisibleRowCount(12);
//        }
//
//        Object[] strMonths = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"};
//        comMonths.getItems().addAll(strMonths);
//        comMonths.getSelectionModel().select(0);
//        comMonths.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
//            @Override
//            public void changed(ObservableValue arg0, Object oldMths, Object newMths) {
//                if (newMths != null) {
//                    monthsSelected = Integer.parseInt(newMths.toString());
//                    amtPayable = (monthsSelected * amtPremium);
//                    amtTotal = (monthsSelected * amtPremium) + response1.getConvenienceFee();
//                    txtTotal.setText(JKText.getDeciFormat(amtTotal));
//                }
//            }
//        });
//
//        HBox hbMonths = JKLayout.getHBox(0, JKLayout.sp);
//        hbMonths.getChildren().addAll(lblMonths, JKNode.getHSpacer(), comMonths);
//
//        HBox hbTotal = JKLayout.getHBox(0, JKLayout.sp);
//        hbTotal.getChildren().addAll(JKNode.getHSpacer(), lblTotal, JKNode.getHSpacer(), txtTotal);
//
//        gridAmtDetail = JKLayout.getContentGridInner2Col(0.5, 0.5);
//
//        gridAmtDetail.add(gridDetail, 0, 1, 2, 1);
//        gridAmtDetail.addRow(2, hbMonths, hbTotal);
//        gridAmtDetail.addRow(3, getTenderTypes());
//
//        return gridAmtDetail;
//    }
//
//    private JKTenderToggles getTenderTypes() {
//        tenders = new JKTenderToggles(SaleType.BILLPAYMENTS.getDisplay());
//        for (ToggleButton b : tenders.getTenderToggleList()) {
//            b.setOnMouseReleased(new EventHandler() {
//                @Override
//                public void handle(javafx.event.Event e) {
//                    tendered = tenders.getTenderTypeSelected();
//                    submitPayAtPolicyPaymentRollback(request1, response1, BillPayUtilMisc.CALL_BY_TENDER);
//                }
//            });
//        }
//        return tenders;
//    }
//
//    private JKioskNav getNav() {
//        nav = new JKioskNav();
//        nav.getBtnBack().setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                if (gridPol.getVbHead().getChildren().contains(gridPol.getGridEnter())) {
//                    SceneSales.clearAndChangeContent(new BillPaymentSelect(
//                            BillPayUtilMisc.TYPE_INSURE_PAY + " Providers", BillPayUtilMisc.TYPE_INSURE_PAY));
//                } else {
//                    SceneSales.clearAndChangeContent(new InputPayAtInsurance(product, caller, showFavourites));
//                }
//            }
//        });
//        nav.getBtnCancel().setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
//                BillPayUtilMisc.resetBillPayView();
//                if (request1 != null) {
//                    submitPayAtPolicyPaymentRollback(request1, response1, BillPayUtilMisc.CALL_BY_CANCEL);
//                }
//            }
//        });
//        nav.getBtnNext().setDisable(true);
//        return nav;
//    }
//
//    private void showConfirmationSummary() {
//        SummaryPayAtInsurance summary = new SummaryPayAtInsurance(request2, response2, monthsSelected, amtPremium, tendered);
//
////        JKiosk3.getMsgBox().showMsgBox(BillPayUtilMisc.PAYAT_INSURANCE, "Confirm all details before proceeding",
//        JKiosk3.getMsgBox().showMsgBox(BPTransType.BILLPAY_PAYAT_INSURANCE.getDisplayName(), "Confirm all details before proceeding",
//                summary, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult() {
//                    @Override
//                    public void onOk() {
//                        submitPayAtPolicyPaymentCommit(request2, response2);
//                    }
//
//                    @Override
//                    public void onCancel() {
//                        UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
//                        BillPayUtilMisc.resetBillPayView();
//                        submitPayAtPolicyPaymentRollback(request2, response2, BillPayUtilMisc.CALL_BY_CANCEL);
//                    }
//                });
//    }
//
//    //====================================
//    // above - mostly view
//    // below - mostly process
//    //====================================
//    private void getPolicyRequestQuery() {
//        policyNum = gridPol.getAccountNumberConfirmed();
//
//        request1 = new PayAtIPPayReq();
//        request1.setProviderId(product.getProvId());
//        request1.setProductId(product.getProdId());
//        request1.setPolicyNumber(policyNum);
//        request1.setAmount(0.0);
//        request1.setPaymentRefNumber("");
//        request1.setStoreId("");
//        request1.setTillId("");
//        request1.setPaymentReceiptNo("");
//        request1.setEcho("");
//        request1.setRealTime(1);
////        request1.setVerifyOnly(0);
//        request1.setVerifyOnly(1);
//
//        System.out.println("PayAtIPPayReq created, off to request detail...");
//
//        BillPayUtilPayAt.getPayAtInsurancePaymentResponse(request1, new PayAtInsurancePayResponse() {
//            @Override
//            public void payAtInsurancePayResp(BillPaymentConnection connect, PayAtIPPayResp resp) {
//                connection = connect;
//
//                if (resp.isSuccess() && resp.getMessageCode() == 0) {
//                    response1 = resp;
//                    switch (resp.getAcceptPartPayment()) {
//                        case "Y":
//                            acceptPartPayment = "Yes";
//                            break;
//                        case "N":
//                            acceptPartPayment = "No";
//                            break;
//                        default:
//                            JKiosk3.getMsgBox().showMsgBox("Pay@ Insurance Payment", "No Part Payment Result Received", null);
//                    }
//                    amtPremium = resp.getAmountDue();
//                    gridPol.getVbHead().getChildren().remove(gridPol.getGridEnter());
//                    gridPol.getVbHead().getChildren().add(gridPol.getGridDetail(resp.getPaymentRefNumber(),
//                            resp.getFirstName() + " " + resp.getLastName()));
//                    gridAmtDetail = getDetailAndAmountEntry();
//                    vbContent.getChildren().add(1, gridAmtDetail);
//                } else if (resp.isSuccess() && resp.getMessageCode() != 0) {
//                    JKiosk3.getMsgBox().showMsgBox("Policy Detail Error",
//                            resp.getMessageCode() + " - " + resp.getMessageDescription()
//                                    + "\n\nHas the correct Policy type been selected?", null, MessageBox.CONTROLS_SHOW,
//                            MessageBox.MSG_OK, new MessageBoxResult() {
//
//                                @Override
//                                public void onOk() {
//                                    SceneSales.clearAndChangeContent(new BillPayInsuranceMenu());
//                                }
//
//                                @Override
//                                public void onCancel() {
//                                    //
//                                }
//                            });
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Policy Detail Error",
//                            resp.getErrorCode() + " - " + resp.getErrorText(), null);
//                    BillPayUtilMisc.resetBillPayView();
//                }
//            }
//        });
//    }
//
//    private void getPolicyRequestPay() {
//        request2 = new PayAtIPPayReq();
//        request2.setProviderId(product.getProvId());
//        request2.setProductId(product.getProdId());
//        request2.setPolicyNumber(policyNum);
//        request2.setAmount(amtPayable);
//        request2.setPaymentRefNumber("");
//        request2.setStoreId("");
//        request2.setTillId("");
//        request2.setPaymentReceiptNo("");
//        request2.setEcho("");
//        request2.setRealTime(1);
//        request2.setVerifyOnly(0);
//
//        BillPayUtilPayAt.getPayAtInsurancePaymentResponse(request2, new PayAtInsurancePayResponse() {
//            @Override
//            public void payAtInsurancePayResp(BillPaymentConnection connect, PayAtIPPayResp resp) {
//                connection = connect;
//
//                if (resp.isSuccess()) {
//                    response2 = resp;
//                    showConfirmationSummary();
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Policy Detail Error",
//                            resp.getErrorCode() + " - " + resp.getErrorText(), null);
//                    BillPayUtilMisc.resetBillPayView();
//                }
//            }
//        });
//    }
//
//    private void submitPayAtPolicyPaymentCommit(PayAtIPPayReq reqCommit, PayAtIPPayResp respCommit) {
//        final PayAtIPPayConfReq confCommit = new PayAtIPPayConfReq();
//
//        confCommit.setProviderId(reqCommit.getProviderId());
//        confCommit.setProductId(reqCommit.getProductId());
//        confCommit.setConfirmType("commit");
//        confCommit.setTransactionId(respCommit.getTransactionID());
//        confCommit.setTenderType(tendered);
//        confCommit.setWantPrintJob(true);
//
//        BillPayUtilPayAt.getPayAtInsurancePaymentConfirm(connection, confCommit, new PayAtInsurancePayConfirm() {
//            @Override
//            public void payAtInsurancePayConf(final PayAtIPPayConfResp insConfResp) {
//                if (insConfResp.isSuccess()) {
//                    String descript = product.getProdName() + " - " + request2.getPolicyNumber();
//                    if (insConfResp.getResponseCode().equals("0")) {
//
////                        SalesUtil.processBillPayment(BillPayUtilMisc.PAYAT_INSURANCE, response2.getTransRef(), descript, amtTotal,
//                        SalesUtil.processBillPayment(BPTransType.BILLPAY_PAYAT_INSURANCE.getDisplayName(), response2.getTransRef(), descript, amtTotal,
//                                tendered, "Payment Success", insConfResp.getPrintLines(), insConfResp.getMerchantPrintLines());
//                    }
//                } else if (insConfResp.getErrorCode().equals("1995")) {
//                    JKiosk3.getMsgBox().showMsgBox("Policy Payment Error", insConfResp.getErrorText(), null);
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Policy Payment", insConfResp.getErrorText(), null);
//                }
//                BillPayUtilMisc.resetBillPayView();
//            }
//        });
//    }
//
//    private void submitPayAtPolicyPaymentRollback(PayAtIPPayReq reqRollback, PayAtIPPayResp respRollback, final String calledBy) {
//        PayAtIPPayConfReq confRollback = new PayAtIPPayConfReq();
//
//        confRollback.setProviderId(reqRollback.getProviderId());
//        confRollback.setProductId(reqRollback.getProductId());
//        confRollback.setConfirmType("rollback");
//        confRollback.setTransactionId(respRollback.getTransactionID());
//        if (tendered != null) {
//            confRollback.setTenderType(tendered);
//        } else {
//            confRollback.setTenderType("cash");
//        }
//
//        BillPayUtilPayAt.getPayAtInsurancePaymentConfirm(connection, confRollback, new PayAtInsurancePayConfirm() {
//            @Override
//            public void payAtInsurancePayConf(PayAtIPPayConfResp insConfResp) {
//                if (insConfResp.isSuccess()) {
//                    switch (calledBy) {
//                        case BillPayUtilMisc.CALL_BY_CANCEL:
//                            JKiosk3.getMsgBox().showMsgBox("Insurance Policy Payment", "Transaction cancelled by User", null);
//                            BillPayUtilMisc.resetBillPayView();
//                            break;
//                        case BillPayUtilMisc.CALL_BY_TENDER:
//                            getPolicyRequestPay();
//                            break;
//                        default:
//                            JKiosk3.getMsgBox().showMsgBox("Pay@ Insurance Payment", "Unable to Determine Rollback Requestor", null);
//                    }
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Policy Payment Rollback Error",
//                            insConfResp.getErrorCode() + insConfResp.getErrorText(), null);
//                }
//            }
//        });
//    }
}
