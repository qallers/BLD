package jkiosk3.sales._favourites;

import aeonairtime.AirtimeManufacturer;
import aeonfavourites.FavouriteItem;
import aeonvarivouchers.Supplier;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.*;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.topups.TopupProvider;
import za.co.blt.consumer.loyalty.api.service.model.response.Favourite;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FavouriteTabs extends Region {

    private List<Favourite> listFavourite;
    //
    private List<AirtimeManufacturer> listFavVouch = new ArrayList<>();
    private List<Supplier> listFavC4C = new ArrayList<>();
    private List<TopupProvider> listFavTopProvAir = new ArrayList<>();
    private List<TopupProvider> listFavTopProvBundles = new ArrayList<>();
    private List<ElectricityProvider> listFavElecSuppliers = new ArrayList<>();
    private List<BillPayProduct> listFavBPProds = new ArrayList<>();
    private List<String> listTicketing = new ArrayList<>();
    private List<String> listIthuba = new ArrayList<>();

    public FavouriteTabs() {

        FavouriteUtil.getListFavouriteProducts(false, new FavouriteUtil.FavouriteProductsResult() {
            @Override
            public void favouriteProductsResult(List<FavouriteItem> favListResp) {
                if (!favListResp.isEmpty()) {
                    FavouriteUtilLists favUtilList = new FavouriteUtilLists();
//                        listFavouriteItem = favListResp.getListFavouriteItems();
                    listFavourite = favUtilList.convertFavouriteItemsToFavourites(favListResp);
                    Collections.sort(listFavourite, new Comparator<Favourite>() {
                        @Override
                        public int compare(Favourite o1, Favourite o2) {
                            return o1.getTrxType().compareTo(o2.getTrxType());
                        }
                    });
//                    if (listFavourite.size() > 14) {
//                        listFavourite = listFavourite.subList(0, 14);
//                    }
                    if (!listFavourite.isEmpty()) {
                        // sort into lists for each product type, make buttons, add to view
                        listFavVouch = favUtilList.getFavouriteVoucherList(listFavourite);
                        Collections.sort(listFavVouch, new Comparator<AirtimeManufacturer>() {
                            @Override
                            public int compare(AirtimeManufacturer o1, AirtimeManufacturer o2) {
                                return o1.getName().compareTo(o2.getName());
                            }
                        });
                        listFavC4C = favUtilList.getFavouriteC4C(listFavourite);
                        listFavTopProvAir = favUtilList.getFavouriteTopupAirtime(listFavourite);
                        listFavTopProvBundles = favUtilList.getFavouriteTopupBundles(listFavourite);
                        listFavElecSuppliers = favUtilList.getFavouriteElectricity(listFavourite);
                        listFavBPProds = favUtilList.getFavouriteBillPayProducts(listFavourite);
                        listTicketing = favUtilList.getFavouriteTicketing(listFavourite);
                        listIthuba = favUtilList.getFavouriteIthuba(listFavourite);

//                        getChildren().addAll(getFavouriteTabsView());

                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Favourites",
                                "\nNo Favourites for this Device", null);
                    }
                }
            }
        });
    }

//    private VBox getFavouriteTabsView() {
////        FavNodes favNodes = new FavNodes(false);
//
//        VBox vbHead = JKNode.getPageHeadVB("Favourites");
//
//        TabPane tabPane =  new TabPane();
//        tabPane.setTabMinWidth((JKLayout.contentW - (5 * JKLayout.sp)) / 3);
////        tabPane.getStyleClass().add("tabPaneFavourite");
//        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
//
//        Label lbl1 = JKText.getLblDk("Vouchers", JKText.FONT_B_20);
//        Label lbl2 = JKText.getLblDk("Bill Payments", JKText.FONT_B_20);
//        Label lbl3 = JKText.getLblDk("Other", JKText.FONT_B_20);
//        Tab tab1 = new Tab();
//        tab1.getStyleClass().add("tabFavourite");
//        tab1.setGraphic(lbl1);
//        Tab tab2 = new Tab();
//        tab2.getStyleClass().add("tabFavourite");
//        tab2.setGraphic(lbl2);
//        Tab tab3 = new Tab();
//        tab3.getStyleClass().add("tabFavourite");
//        tab3.setGraphic(lbl3);
//        tabPane.getTabs().addAll(tab1, tab2, tab3);
//
//        List<Button> listfavs1 = new ArrayList<>();
//        List<Button> listfavs2 = new ArrayList<>();
//        List<Button> listfavs3 = new ArrayList<>();
//
////        listfavs1.addAll(favNodes.getListBtnsVouchers(listFavVouch));
////        listfavs1.addAll(favNodes.getListBtnsC4C(listFavC4C));
////        listfavs1.addAll(favNodes.getListBtnsTopAir(listFavTopProvAir));
////        listfavs1.addAll(favNodes.getListBtnsTopData(listFavTopProvBundles));
////        listfavs2.addAll(favNodes.getListBtnsBillPayments(listFavBPProds));
////        listfavs3.addAll(favNodes.getListBtnsElectricity(listFavElecSuppliers));
////        listfavs3.addAll(favNodes.getListBtnsTicketing(listTicketing));
////        listfavs3.addAll(favNodes.getListBtnsIthuba(listIthuba));
//
//        TilePane tile1 = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listfavs1);
//        tile1.setStyle("-fx-padding: 20px 0px 0px 0px;");
//        TilePane tile2 = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listfavs2);
//        tile2.setStyle("-fx-padding: 20px 0px 0px 0px;");
//        TilePane tile3 = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listfavs3);
//        tile3.setStyle("-fx-padding: 20px 0px 0px 0px;");
//
//        double paneHt = (6 * JKLayout.btnSmH) + (7 * JKLayout.sp);
//        Pane pane1 = new Pane(tile1);
//        pane1.setMinHeight(paneHt);
//        Pane pane2 = new Pane(tile2);
//        pane2.setMinHeight(paneHt);
//        Pane pane3 = new Pane(tile3);
//        pane3.setMinHeight(paneHt);
//
//        tab1.setContent(pane1);
//        tab2.setContent(pane2);
//        tab3.setContent(pane3);
//
//        VBox vBox = JKLayout.getVBoxContent(JKLayout.sp);
//        vBox.getChildren().addAll(vbHead, tabPane);
//
//        return vBox;
//    }
}
