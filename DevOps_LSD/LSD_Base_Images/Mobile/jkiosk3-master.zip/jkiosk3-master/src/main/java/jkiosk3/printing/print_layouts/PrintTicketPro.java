package jkiosk3.printing.print_layouts;

import aeonprinting.AeonPrintJob;
import aeonticketpros.TicketProsCheckoutResp;
import aeonticketpros.TicketProsPrintElement;
import aeonticketpros.TicketProsPrintResp;
import aeonticketpros.TicketProsReserveSeatsResp;
import aeonticketpros.TicketProsTicket;
import aeonticketpros.bus.TicketProBusRouteBookResp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKText;
import jkiosk3.printing.BarcodeHandler;
import jkiosk3.printing.ImageHandler;
import jkiosk3.sales.ticketpro.TicketProBusSale;
import jkiosk3.sales.ticketpro.TicketProSale;
import jkiosk3.users.CurrentUser;

public class PrintTicketPro {

    private static final String PRINT_LAYOUT_EVT = "%-10s" + "%-1s" + "%24s";
    private static final String TICKETPRO_BARCODE_128C = "code128c";
    private static final String TICKETPRO_BARCODE_PDF417 = "pdf417";
    private static final String TICKETPRO_WEBSITE = "www.ticketpro.co.za";
    private static final String TICKETPRO_T_AND_C = "For terms and conditions refer to " + TICKETPRO_WEBSITE;
    private static final String TICKETPRO_NO_REFUND = "Tickets are not refundable";
    private static final ImageHandler ih = new ImageHandler();

    public static AeonPrintJob getTicketProTicketPrint(TicketProsPrintResp printResp, TicketProsTicket ticket) {

        String logoCode = "9";

        AeonPrintJob apj = new AeonPrintJob();
        // image to print on ticket
        String logoGIFTP = ticket.getElementByName("logo_gif").getValue();
        String localFile = null;
        if (ih.getHeaderImagePathCoach(logoGIFTP) != null) {
            localFile = ih.getHeaderImagePathCoach(logoGIFTP);
            System.out.println(" >>> path to TicketPro ticket header image : " + localFile);
        }

        // barcode to print on ticket
        String barcode1 = ticket.getElementByName("Barcode1").getValue();
        String barcodeEncoding = ticket.getElementByName("Barcode1").getEncoding();

        if (localFile == null) {
            apj.addLogo(logoCode);
        } else {
            apj.addHeaderImage(localFile);
        }
        apj.addCentre("");
        apj.addCentreBold("TicketPro");

        apj.addBreak();

        // LinkedHashMap keeps order of insertion, does not store duplicate keys (XML element name).
        Map<String, TicketProsPrintElement> map = new LinkedHashMap<>();
        for (TicketProsPrintElement p : ticket.getListPrintElements()) {
            map.put(p.getName(), p);
        }
        for (Map.Entry<String, TicketProsPrintElement> entry : map.entrySet()) {
            String key = entry.getKey();
            TicketProsPrintElement elem = entry.getValue();
            // exclude elements for logo images and barcodes
            if (!key.equalsIgnoreCase("Logo") && !key.equalsIgnoreCase("logo_gif")
                    && !key.equalsIgnoreCase("Barcode1") && !key.equalsIgnoreCase("Barcode2")
                    && !key.equalsIgnoreCase("PrintLines")) {
                String content = elem.getValue().trim();
                if (!content.equals("")) {
                    System.out.println(String.format("%-16s" + "%-7s" + "%35s", key, elem.getSize(), content));

                    List<String> contentWrap = new ArrayList<>();
                    if (content.length() > 35) {
                        contentWrap = apj.wordWrap(content, 35);
                    }
                    int fontsize = Integer.parseInt(elem.getSize());

                    if (fontsize >= 15) {
                        if (!contentWrap.isEmpty()) {
                            for (String s : contentWrap) {
                                apj.addCentreBold(s);
                            }
                        } else {
                            apj.addCentreBold(content);
                        }
                    } else {
                        if (!contentWrap.isEmpty()) {
                            for (String s : contentWrap) {
                                apj.addCentre(s);
                            }
                        } else {
                            apj.addCentre(content);
                        }
                    }
                }
            }
        }

        apj.addCentre("");

        apj.addBreak();

        List<String> wrapAdvert = apj.wordWrap(TICKETPRO_T_AND_C, 35);
        for (String line : wrapAdvert) {
            apj.addCentre(line);
        }

        List<String> wrapFoot = apj.wordWrap(TICKETPRO_NO_REFUND, 35);
        for (String line : wrapFoot) {
            apj.addCentre(line);
        }

        apj.addCentre("");

        BarcodeHandler bh = new BarcodeHandler();
        String barcodeProcessed = bh.processBarcode128cPDF417(barcode1);
        switch (barcodeEncoding) {
            case TICKETPRO_BARCODE_128C:
                apj.addBarcode128C(barcodeProcessed);
                break;
            case TICKETPRO_BARCODE_PDF417:
                apj.addBarcodePDF417(barcodeProcessed);
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("TicketPro Print", "Unable to determine Barcode Encoding", null);
        }

        apj.addBreak();

        apj.addCentre("");

        apj.addCentreBold("- Print Done -");

        return apj;
    }

    public static AeonPrintJob getTicketProCustomerServicePrint(TicketProsCheckoutResp checkout) {
        AeonPrintJob apj = new AeonPrintJob();

        apj.addLogo("9");
        apj.addCentreBold("TicketPro");
        apj.addBreak();

        String message2 = "\nPlease refer the Customer to\n\nTicketPro Customer Services\n\n" +
                JK3Config.getInfoTicketProCustomerServicesTelNum()
                + "\n\nMon - Fri : 08h00 - 16h00\n\n" + JK3Config.getInfoTicketProCustomerServicesEmail();
        // details
        apj.addCentre("");
        apj.addCentreBold("TicketPro Customer Services");
        apj.addCentre("");
        apj.addCentre(JK3Config.getInfoTicketProCustomerServicesTelNum());
        apj.addCentre("Mon - Fri : 08h00 - 16h00");
        apj.addCentre("");
        apj.addCentre(JK3Config.getInfoTicketProCustomerServicesEmail());
        apj.addCentre("");
        apj.addCentre("Please make sure that you have your");
        apj.addCentre("");
        apj.addCentreBold("Booking Reference");
        apj.addCentre("");
        apj.addCentre("if requesting a");
        apj.addCentre("Cancellation or Refund");
        apj.addCentre("");

        if (checkout != null) {
            apj.addCentre(String.format(PRINT_LAYOUT_EVT, "Booking Ref", ":", checkout.getReference()));
        }

        apj.addBreak();
        apj.addCentre("For terms and conditions refer to");
        apj.addCentre("www.ticketpro.co.za");
        apj.addBreak();

        apj.addCentre("");

        apj.addCentreBold("- Print Done -");

        return apj;
    }

    public AeonPrintJob getTicketProCancelRequestPrint() {
        String printLayout = "%-12s" + "%-1s" + "%23s";
        AeonPrintJob apj = new AeonPrintJob();

        TicketProsReserveSeatsResp reserved = TicketProSale.getInstance().getReservedSeats();
        TicketProsCheckoutResp checkout = TicketProSale.getInstance().getCheckoutResponse();
        String eventName = reserved.getListSeats().get(0).getEventName();
        Date startDate = reserved.getListSeats().get(0).getStartDate();
        int ticketCount = reserved.getListSeats().size();

        apj.addCentre("");
        apj.addCentreBold("TicketPro");
        apj.addCentre("Cancellation Request Detail");
        apj.addCentre("");
        apj.addCentreBold("TicketPro Customer Services");
        apj.addCentre("");
        apj.addCentre(JK3Config.getInfoTicketProCustomerServicesTelNum());
        apj.addCentre("Mon - Fri : 08h00 - 16h00");
        apj.addCentre("");

        apj.addCentre(String.format(printLayout, "Date", ":", new SimpleDateFormat("yyyy/MM/dd HH:mm").format(new Date())));
        apj.addCentre(String.format(printLayout, "Cashier", ":", CurrentUser.getSalesUser().getUserName()));
        apj.addBreak();

        if (eventName.length() > 23) {
            List<String> wrapEvt = apj.wordWrap(eventName, 23);
            for (int i = 0; i < wrapEvt.size(); i++) {
                if (i == 0) {
                    apj.addCentre(String.format(printLayout, "Event Name", ":", wrapEvt.get(i)));
                } else {
                    apj.addCentre(String.format(printLayout, " ", ":", wrapEvt.get(i)));
                }
            }
        } else {
            apj.addCentre(String.format(printLayout, "Event Name", ":", eventName));
        }
        // <startDate>2016/03/14 01:03:00</startDate>
        apj.addCentre(String.format(printLayout, "Event Date", ":", new SimpleDateFormat("yyyy/MM/dd").format(startDate)));
        apj.addCentre(String.format(printLayout, "Num Tickets", ":", ticketCount));
        apj.addCentre(String.format(printLayout, "Booking Ref", ":", checkout.getReference()));
        apj.addCentre(String.format(printLayout, "Amt Due", ":", JKText.getDeciFormat(checkout.getBalance())));

        apj.addBreak();
        apj.addCentreBold("- Print Done -");

        return apj;
    }

    public AeonPrintJob getTicketProBusCancelRequestPrint() {
        String printLayout = "%-12s" + "%-1s" + "%23s";
        AeonPrintJob apj = new AeonPrintJob();

        TicketProBusRouteBookResp reserved = TicketProBusSale.getInstance().getTicketProBusRouteBooking();
        TicketProsCheckoutResp checkout = TicketProBusSale.getInstance().getCheckoutResponse();
        String eventName = reserved.getListSeats().get(0).getEventName();
        Date startDate = reserved.getListSeats().get(0).getStartDate();
        int ticketCount = reserved.getListSeats().size();

        apj.addCentre("");
        apj.addCentreBold("TicketPro");
        apj.addCentre("Cancellation Request Detail");
        apj.addCentre("");
        apj.addCentreBold("TicketPro Customer Services");
        apj.addCentre("");
        apj.addCentre(JK3Config.getInfoTicketProCustomerServicesTelNum());
        apj.addCentre("Mon - Fri : 08h00 - 16h00");
        apj.addCentre("");

        apj.addCentre(String.format(printLayout, "Date", ":", new SimpleDateFormat("yyyy/MM/dd HH:mm").format(new Date())));
        apj.addCentre(String.format(printLayout, "Cashier", ":", CurrentUser.getSalesUser().getUserName()));
        apj.addBreak();

        if (eventName.length() > 23) {
            List<String> wrapEvt = apj.wordWrap(eventName, 23);
            for (int i = 0; i < wrapEvt.size(); i++) {
                if (i == 0) {
                    apj.addCentre(String.format(printLayout, "Event Name", ":", wrapEvt.get(i)));
                } else {
                    apj.addCentre(String.format(printLayout, " ", ":", wrapEvt.get(i)));
                }
            }
        } else {
            apj.addCentre(String.format(printLayout, "Event Name", ":", eventName));
        }
        // <startDate>2016/03/14 01:03:00</startDate>
        apj.addCentre(String.format(printLayout, "Event Date", ":", new SimpleDateFormat("yyyy/MM/dd").format(startDate)));
        apj.addCentre(String.format(printLayout, "Num Tickets", ":", ticketCount));
        apj.addCentre(String.format(printLayout, "Booking Ref", ":", checkout.getReference()));
        apj.addCentre(String.format(printLayout, "Amt Due", ":", JKText.getDeciFormat(checkout.getBalance())));

        apj.addBreak();
        apj.addCentreBold("- Print Done -");

        return apj;
    }
}
