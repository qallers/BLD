package jkiosk3.branding;

import jkiosk3.store.JKBranding;

public class BrandStyles {

    public static String getBrandButton() {
        String brandColour = JKBranding.getBranding().getMerchantGroup().getPrimaryColourHex();
        return "-fx-text-fill: " + brandColour + "; -fx-border-color: " + brandColour + ";";
    }

    public static String getBrandText() {
        String brandColour = JKBranding.getBranding().getMerchantGroup().getPrimaryColourHex();
        return "-fx-fill: " + brandColour + ";";
    }
}
