package jkiosk3.store.cache;

import aeonairtime.AirtimeManufacturer;
import aeonbillpayments.Provider;
import aeoncoach.CoachCarrier;
import aeoncoach.CoachCarriersList;
import aeoncoach.CoachListItemResp;
import aeonticketpros.TicketProAllowedProdListResp;
import aeonticketpros.bus.TicketProBusRouteCodeList;
import aeontopup.TopupBundleProductList;
import aeonusers.User;
import aeonusers.UserTransactionType;
import aeonvarivouchers.VDVSupplierListResp;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._favourites.Favourites;
import jkiosk3.sales.billpay.BillPayUtilConnect;
import jkiosk3.sales.chat4change.Chat4ChangeUtil;
import jkiosk3.sales.coaches.CoachUtil;
import jkiosk3.sales.ticketpro.TicketProUtil;
import jkiosk3.sales.ticketpro.TicketProUtilBus;
import jkiosk3.sales.topups.AirtimeUtil;
import jkiosk3.sales.topups.TopupProvider;
import jkiosk3.sales.vouchers.VoucherUtil;
import jkiosk3.store.JKCacheOptions;
import jkiosk3.users.UserUtil;

public class CacheController {

    private final static Logger logger = Logger.getLogger(CacheController.class.getName());
    //
    private static boolean firstLogin;
    //
    private boolean updateNow;
    private long timenow;
    private long timeplus;
    //
    private ScheduledExecutorService scheduledCacheExecutor;
    private long timeStartDelay;
    private long timeInterval;
    private long timePause;
    //
    private User cacheUser;
    private List<String> listUserAllowed;
    private List<UserTransactionType> userTransTypes;
    private List<TopupProvider> listTopupProvBundles;
    private int provCount;
    private String changeRegion;
    private ResultCallback finalResult;

    public CacheController() {
        // variables will be initialised as required
    }

    public void setUpdateCacheNow(String parentRegion, ResultCallback result) {
        this.changeRegion = parentRegion;
        this.finalResult = result;
        logger.info("User requested cache update NOW");
//        if (!JKCacheOptions.getCachePreferences().isNever()) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    updateNow = true;
                    CacheUtil.setUpdateNow(true);
                    checkCacheTransTypeList();
                }
            }).start();

            long delaySchedule = 1000L * 60L * 2L * 1L;     // 2 minutes
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    setUpdateCacheScheduler();
                }
            }, delaySchedule);
//        } else {
//            Platform.runLater(new Runnable() {
//                @Override
//                public void run() {
//                    JKiosk3.getMsgBox().showMsgBox("Product Caching",
//                            "'Never cache products'\n\nis selected.\n\nNo products will be cached on this Device", null);
//                }
//            });
//        }
    }

    public void setUpdateCacheScheduler() {
//        if (!JKCacheOptions.getCachePreferences().isNever()) {
            if (scheduledCacheExecutor != null) {
                /* If a scheduler is currently running, stop it. */
                scheduledCacheExecutor.shutdown();
                logger.info("Update not set to Never - Shutdown cache update scheduler");
            }
            /* Start a NEW scheduler. */
            startCacheUpdateScheduler();
//        } else {
//            /* If option is set to 'Never', scheduler must be stopped. */
//            if (scheduledCacheExecutor != null) {
//                scheduledCacheExecutor.shutdown();
//            }
//            logger.info("Update is set to Never - Shutdown cache update scheduler");
//        }
    }

//    public void deleteCachedItems() {
//        if (JKCacheOptions.getCachePreferences().isNever()) {
//            CacheListTransTypes.deleteCacheTransTypes();
//            CacheListAirtimeManufacturers.deleteCacheAirtimeManufacturers();
//            CacheListTopupBundles.deleteCacheTopupProviders();
//            CacheListC4CSuppliers.deleteCacheC4CSuppliers();
//            CacheListBillPaymentProviders.deleteCacheBillPaymentProviders();
//            CacheListTicketProAllowed.deleteCacheTicketProAllowed();
//            CacheListPutcoRoutes.deleteCachePutcoRoutes();
//        }
//    }

    private void startCacheUpdateScheduler() {
        logger.info("Starting Cache Update Scheduler...");
        setCacheDelayAndInterval();
        /* Need to schedule this to check at startup if 'Hourly', 
         * or at specified time if 'Daily', and then on preferred setup frequency 
         * to see whether a product cache update is required. 
         */
//        if (!JKCacheOptions.getCachePreferences().isNever()) {
            scheduledCacheExecutor = Executors.newSingleThreadScheduledExecutor();
            scheduledCacheExecutor.scheduleAtFixedRate(new Runnable() {
                @Override
                public void run() {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            /* We need to set this 'false' each time it loops.
                             * If 'Update Now' is used without 'Save', 
                             * the value of 'updateNow' becomes 'true'. */
                            updateNow = false;
                            CacheUtil.setUpdateNow(false);
                            checkCacheTransTypeList();
                        }
                    }).start();
                }
            }, timeStartDelay, timeInterval, TimeUnit.MILLISECONDS);
//        }
    }

    private void setCacheDelayAndInterval() {
//        timeStartDelay = 0L;
        timeStartDelay = 1000L * 30L;   // allow 1/2 min delay before start
        timeInterval = 1000L * 60L * 60L;   // will retry cache every hour
        timePause = 1000L * 60L;    // allow 1 min for processing
        if (JKCacheOptions.getCachePreferences().isDaily()) {
            logger.info("Cache is set to update DAILY");
            timeInterval = 1000L * 60L * 60L * 24L;
        } else if (JKCacheOptions.getCachePreferences().isHourly()) {
            logger.info("Cache is set to update HOURLY");
//            timeInterval = 1000L * 60L * 5L * 1L;     // 5 minutes
            timeInterval = 1000L * 60L * 60L * 1L;    // 1 hour
//        } else {
//            logger.info("Cache is set OFF - no Products will be cached");
        }
    }

    //
    private void checkCacheTransTypeList() {
        getUserTransTypes(new ResultCallback() {
            @Override
            public void onResult(boolean result) {
                if (result) {
                    timenow = System.currentTimeMillis();
                    timeplus = CacheListTransTypes.checkFileTime() + timeInterval - timePause;
                    if (!userTransTypes.isEmpty()) {    // this should ensure that lists have been made
                        if (updateNow) {
                            logger.info("Cache update requested for Transaction Types");
                            getOnlineTransTypeList();
                        } else if (!CacheListTransTypes.hasItems() || (timenow >= timeplus)) {
                            logger.info("Cache out of date for Transaction Types");
                            getOnlineTransTypeList();
                        } else {
                            checkCacheVoucherProvider();
                        }
                    } else {
                        logger.info("no user transaction types found");
                    }
                } else {
                    logger.info("Failed to initialise product lists.  Cache cannot be updated at this time");
                }
            }
        });
    }

    private void checkCacheVoucherProvider() {
        if (listUserAllowed.contains("Voucher")) {
            timenow = System.currentTimeMillis();
            timeplus = CacheListAirtimeManufacturers.checkFileTime() + timeInterval - timePause;
            if (updateNow) {
                logger.info("Cache update requested for Voucher Products");
                getOnlineVoucherProviderCache();
            } else if (!CacheListAirtimeManufacturers.hasItems() || (timenow >= timeplus)) {
                logger.info("Cache out of date for Voucher Products");
                getOnlineVoucherProviderCache();
            } else {
                checkCacheTopupProviderBundles();
            }
        } else {
            if (CacheListAirtimeManufacturers.hasItems()) {
                CacheListAirtimeManufacturers.deleteCacheAirtimeManufacturers();
            }
            checkCacheTopupProviderBundles();
        }
    }

    private void checkCacheTopupProviderBundles() {
        /* 'listTopupProvBundles' should already have been initialised while getting User Transaction Types. */
        if (listTopupProvBundles != null && !listTopupProvBundles.isEmpty()) {
            provCount = 0;
            timenow = System.currentTimeMillis();
            timeplus = CacheListTopupBundles.checkFileTime() + timeInterval - timePause;
            if (updateNow) {
                logger.info("Cache update requested for Topup Bundle Products");
                getOnlineTopupProviderBundles(provCount);
            } else if (!CacheListTopupBundles.hasItems() || (timenow >= timeplus)) {
                logger.info("Cache out of date for Topup Bundle Products");
                getOnlineTopupProviderBundles(provCount);
            } else {
                checkCacheC4CSuppliersList();
            }
        } else {
            if (listTopupProvBundles.isEmpty()) {
                CacheListTopupBundles.deleteCacheTopupProviders();
            }
            checkCacheC4CSuppliersList();
        }
    }

    private void checkCacheC4CSuppliersList() {
        if (listUserAllowed.contains("C4C_Voucher")) {
            timenow = System.currentTimeMillis();
            timeplus = CacheListC4CSuppliers.checkFileTime() + timeInterval - timePause;
            if (updateNow) {
                logger.info("Cache update requested for Chat-4-Change Providers");
                getOnlineC4CSuppliersList();
            } else if (!CacheListC4CSuppliers.hasItems() || (timenow >= timeplus)) {
                logger.info("Cache out of date for Chat-4-Change Providers");
                getOnlineC4CSuppliersList();
            } else {
                checkCacheBillPaymentProvidersList();
            }
        } else {
            if (CacheListC4CSuppliers.hasItems()) {
                CacheListC4CSuppliers.deleteCacheC4CSuppliers();
            }
            checkCacheBillPaymentProvidersList();
        }
    }

    private void checkCacheBillPaymentProvidersList() {
        if (listUserAllowed.contains("BluBillPayment")
                || listUserAllowed.contains("VASPayAtAccountPayment")
                || listUserAllowed.contains("VASPayAtFinePayment")
                || listUserAllowed.contains("VASPayAtInsurance")
                || listUserAllowed.contains("VASSAPOAccountPayment")
                || listUserAllowed.contains("VASSyntellAccountPayment")
                || listUserAllowed.contains("VASSyntellFinePayment")) {
            timenow = System.currentTimeMillis();
            timeplus = CacheListBillPaymentProviders.checkFileTime() + timeInterval - timePause;
            if (updateNow) {
                logger.info("Cache update requested for Bill Payment Providers");
                getOnlineBillPaymentProvidersList();
            } else if (!CacheListBillPaymentProviders.hasItems() || (timenow >= timeplus)) {
                logger.info("Cache out of date for Bill Payment Providers");
                getOnlineBillPaymentProvidersList();
            } else {
                checkCacheTicketProAllowed();
            }
        } else {
            if (CacheListBillPaymentProviders.hasItems()) {
                CacheListBillPaymentProviders.deleteCacheBillPaymentProviders();
            }
            checkCacheTicketProAllowed();
        }
    }

    private void checkCacheTicketProAllowed() {
        if (listUserAllowed.contains("TKP_TICKET")) {
            timenow = System.currentTimeMillis();
            timeplus = CacheListTicketProAllowed.checkFileTime() + timeInterval - timePause;
            if (updateNow) {
                logger.info("Cache update requested for TicketPro Allowed");
                getOnlineTicketProAllowed();
            } else if (!CacheListTicketProAllowed.hasItems() || (timenow >= timeplus)) {
                logger.info("Cache out of date for TicketPro Allowed");
                getOnlineTicketProAllowed();
            } else {
                checkCachePutcoRouteCodeList();
            }
        } else {
            if (CacheListTicketProAllowed.hasItems()) {
                CacheListTicketProAllowed.deleteCacheTicketProAllowed();
            }
            checkCachePutcoRouteCodeList();
        }
    }

    private void checkCachePutcoRouteCodeList() {
        if (listUserAllowed.contains("TKP_TICKET")) {
            timenow = System.currentTimeMillis();
            timeplus = CacheListPutcoRoutes.checkFileTime() + timeInterval - timePause;
            if (updateNow) {
                logger.info("Cache update requested for Putco Route Codes");
                getOnlinePutcoRouteCodeList();
            } else if (!CacheListPutcoRoutes.hasItems() || (timenow >= timeplus)) {
                logger.info("Cache out of date for Putco Route Codes");
                getOnlinePutcoRouteCodeList();
            } else {
                checkCacheCoachCarrierList();
            }
        } else  {
            if (CacheListPutcoRoutes.hasItems()) {
                CacheListPutcoRoutes.deleteCachePutcoRoutes();
            }
            checkCacheCoachCarrierList();
        }
    }

    private void checkCacheCoachCarrierList() {
        if (listUserAllowed.contains("Carma")) {
            timenow = System.currentTimeMillis();
            timeplus = CacheListCoachCarriers.checkFileTime() + timeInterval - timePause;
            if (updateNow) {
                logger.info("Cache update requested for Coach Carriers List");
                getOnlineCoachCarriersList();
            } else if (!CacheListCoachCarriers.hasItems() || (timenow >= timeplus)) {
                logger.info("Cache out of date for Coach Carriers List");
                getOnlineCoachCarriersList();
            } else {
//                checkCacheCoachCitiesList();
                // any more lists to cache?
            }
        } else {
            if (CacheListCoachCarriers.hasItems()) {
                CacheListCoachCarriers.deleteCacheListCoachCarriers();
            }
//            checkCacheCoachCitiesList();
            // any more lists to cache?
        }
    }

//    private void checkCacheCoachCitiesList() {
//        if (listUserAllowed.contains("Carma")) {
//            timenow = System.currentTimeMillis();
//            timeplus = CacheListCoachCities.checkFileTime() + timeInterval - timePause;
//            if (updateNow) {
//                logger.info("Cache update requested for Coach Cities List");
//                getOnlineCoachCitiesList();
//            } else if (!CacheListCoachCities.hasItems() || (timenow >= timeplus)) {
//                logger.info("Cache out of date for Coach Cities List");
//                getOnlineCoachCitiesList();
//            } else {
//                // any more lists to cache?
//            }
//        } else {
//            if (CacheListCoachCities.hasItems()) {
//                CacheListCoachCities.deleteCacheListCoachCities();
//            }
//            // any more lists to cache?
//        }
//    }

    /* From here onwards, these methods get the cache items, if necessary. */
    private void getUserTransTypes(final ResultCallback result) {
        if (cacheUser != null) {
            CacheUtil.getLoggedInUserCache(cacheUser, new UserUtil.LoggedInUserResult() {

                @Override
                public void loggedInUserResult(User loggedInUser) {
                    if (loggedInUser.isSuccess()) {
                        userTransTypes = loggedInUser.getUserTransactionTypes();
                        listUserAllowed = new ArrayList<>();
                        listTopupProvBundles = new ArrayList<>();
                        for (UserTransactionType utt : userTransTypes) {
                            listUserAllowed.add(utt.getTransactionType());
                            if (utt.getType().equalsIgnoreCase("Bundles") && (utt.getTransactionType().contains("Bundles"))) {
                                TopupProvider topBundle = new TopupProvider(utt.getTransactionType(), utt.getDisplayName(), 0, utt.isRechargePlus());
                                listTopupProvBundles.add(topBundle);
                            }
                        }
                        result.onResult(true);
                    } else {
                        result.onResult(false);
                        logger.info("User login unsuccessful.  Cache cannot be updated at this time");
                    }
                }
            });
        } else {
            logger.info("No User is logged in.  Cache cannot be updated at this time");
        }
    }

    private void getOnlineTransTypeList() {
        CacheListTransTypes.saveUserTransactionTypes(userTransTypes);
        logger.info(" * * * Transaction Type Cache successfully updated * * * ");
        /* Trans Types complete, continue */
        checkCacheVoucherProvider();
    }

    private void getOnlineVoucherProviderCache() {
        CacheUtil.getVoucherProvidersListCache(cacheUser, new VoucherUtil.AirtimeManufacturerResult() {
            @Override
            public void airtimeManufacturerResult(List<AirtimeManufacturer> manufacturerList) {
                if (!manufacturerList.isEmpty()) {
                    CacheListAirtimeManufacturers.saveAirtimeManufacturers(manufacturerList);
                    logger.info(" * * * Voucher Cache successfully updated * * * ");
                    /* Voucher cache complete, continue */
                    checkCacheTopupProviderBundles();
                } else {
                    logger.info("Voucher List Cache failed");
                    /* Voucher cache failed, continue anyway */
                    checkCacheTopupProviderBundles();
                }
            }
        });
    }

    private void getOnlineTopupProviderBundles(int provIndex) {
        final TopupProvider currentProv = listTopupProvBundles.get(provIndex);
        final int provListSize = listTopupProvBundles.size();
        provCount++;
        CacheUtil.getTopupBundleProductCache(cacheUser, currentProv, new AirtimeUtil.TopupBundleProductListResult() {
            @Override
            public void topupBundleProductListResult(TopupBundleProductList topupBundleProductList) {
                if (topupBundleProductList.isSuccess()) {
                    currentProv.setListBundles(topupBundleProductList);
                    if (provCount < provListSize) {
                        getOnlineTopupProviderBundles(provCount);
                    } else {
                        CacheListTopupBundles.saveListTopupBundleProviders(listTopupProvBundles);
                        logger.info(" * * * Topup Bundles Cache successfully updated * * * ");
                        /* Topup Bundle cache complete, continue */
                        checkCacheC4CSuppliersList();
                    }
                } else {
                    logger.info(("Topup Provider Cache failed : ").concat(topupBundleProductList.getErrorText()));
                    /* If Topup Bundle cache fails, check count and continue */
//                    if (provCount < provListSize) {
//                        checkCacheC4CSuppliersList();
//                    }
                    // never mind others, can't save anyway, just continue...
                    checkCacheC4CSuppliersList();
                }
            }
        });
    }

    private void getOnlineC4CSuppliersList() {
        CacheUtil.getC4CSupplierListCache(cacheUser, new Chat4ChangeUtil.C4CSupplierResult() {
            @Override
            public void c4cSupplierListResult(VDVSupplierListResp c4cSupplierList) {
                if (c4cSupplierList.isSuccess() && !c4cSupplierList.getSupplierList().isEmpty()) {
                    CacheListC4CSuppliers.saveC4CSuppliers(c4cSupplierList.getSupplierList());
                    logger.info(" * * * Chat-4-Change Suppliers Cache successfully updated * * * ");
                    /* Chat-4-Change Supplier cache complete, continue */
                    checkCacheBillPaymentProvidersList();
                } else {
                    logger.info(("Chat-4-Change Suppliers Cache failed : ").concat(c4cSupplierList.getErrorText()));
                    /* Chat-4-Change Supplier cache failed, continue anyway */
                    checkCacheBillPaymentProvidersList();
                }
            }
        });
    }

    private void getOnlineBillPaymentProvidersList() {
        CacheUtil.getBillPaymentProviderListCache(cacheUser, new BillPayUtilConnect.ListBillPaymentProvidersResult() {
            @Override
            public void listBillPayProviderResult(List<Provider> listProviderResult) {
                if (!listProviderResult.isEmpty()) {
                    CacheListBillPaymentProviders.saveBillPaymentProviders(listProviderResult);
                    logger.info(" * * * Bill Payment Providers Cache successfully updated * * * ");
                    /* Bill Payment Providers cache complete, continue */
                    checkCacheTicketProAllowed();
                } else {
                    logger.info("Bill Payment Providers Cache failed : ");
                    /* Bill Payment Providers cache failed, continue anyway */
                    checkCacheTicketProAllowed();
                }
            }
        });
    }

    private void getOnlineTicketProAllowed() {
        CacheUtil.getTicketProAllowedProdList(cacheUser, new TicketProUtil.TicketProAllowedProdListResult() {
            @Override
            public void tpAllowedProdListResult(TicketProAllowedProdListResp tpAllowedProdList) {
                if (tpAllowedProdList.isSuccess()) {
                    CacheListTicketProAllowed.saveListTicketProAllowed(tpAllowedProdList);
                    logger.info(" * * * TicketPro Allowed Product List Cache successfully updated * * * ");
                    /* TicketPro Allowed Product List cache complete, continue */
                    checkCachePutcoRouteCodeList();
                } else {
                    logger.info("TicketPro Allowed Product List Cache failed : ");
                    /* TicketPro Allowed Product List cache failed, continue anyway */
                    checkCachePutcoRouteCodeList();
                }
            }
        });
    }

    private void getOnlinePutcoRouteCodeList() {
        CacheUtil.getPutcoRouteCodeListCache(cacheUser, new TicketProUtilBus.TicketProBusRouteCodeResult() {
            @Override
            public void tpBusRouteCodeResult(TicketProBusRouteCodeList tpBusRouteCodeResult) {
                if (tpBusRouteCodeResult.isSuccess()) {
                    CacheListPutcoRoutes.saveListPutcoRouteCodes(tpBusRouteCodeResult);
                    logger.info(" * * * Putco Route Code Cache successfully updated * * * ");
                    // any more lists to cache?
                    checkCacheCoachCarrierList();
                } else {
                    logger.info("Putco Route Code Cache failed : ");
                    // any more lists to cache?
                    checkCacheCoachCarrierList();
                }
            }
        });
    }

    private void getOnlineCoachCarriersList() {
        CacheUtil.getCoachCarriersListCache(cacheUser, new CoachUtil.CoachCarriersListResult() {
            @Override
            public void coachCarriersListResult(CoachCarriersList coachCarriersListResult) {
                if (coachCarriersListResult.isSuccess()) {
                    CacheListCoachCarriers.saveListCoachCarriers(coachCarriersListResult);
                    logger.info(" * * * Coach Carriers List Cache successfully updated * * * ");
                    logger.info(" * * * Cache updates complete * * * ");
                    // any more lists to cache?
//                    checkCacheCoachCitiesList();
                    showCacheComplete();
                } else {
                    logger.info("Coach Carriers List Cache failed : ");
                    logger.info(" * * * Cache updates complete * * * ");
                    // any more lists to cache?
//                    checkCacheCoachCitiesList();
                    showCacheComplete();
                }
            }
        });
    }

//    private void getOnlineCoachCitiesList() {
//        CacheUtil.getCoachCitiesListCache(cacheUser, new CoachUtil.CoachCityListResult() {
//            @Override
//            public void coachCityListResult(CoachListItemResp coachCityListResult) {
//                if (coachCityListResult.isSuccess()) {
//                    CacheListCoachCities.saveListCoachCities(coachCityListResult);
//                    logger.info(" * * * Coach Cities List Cache successfully updated * * * ");
//                    logger.info(" * * * Cache updates complete * * * ");
//                    // any more lists to cache?
//                    showCacheComplete();
//                } else {
//                    logger.info("Coach Cities List Cache failed : ");
//                    logger.info(" * * * Cache updates complete * * * ");
//                    // any more lists to cache?
//                    showCacheComplete();
//                }
//            }
//        });
//    }

    private void showCacheComplete() {
        if (updateNow) {
            JKiosk3.getMsgBox().showMsgBox("Cache Complete", "\nClick OK to continue", null,
                    MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            finalResult.onResult(true);
                            System.out.println("set finalResult in CacheController");
                            switch (changeRegion) {
                                case CacheUtil.SCENE_SALES:
                                    logger.info("Cache Complete");
//                                    SceneSales.clearAndChangeContent(new Favourites());
                                    break;
                                case CacheUtil.SCENE_SETUP:
                                    logger.info("Cache Complete");
                                    break;
                                default:
                                    break;
                            }
                        }

                        @Override
                        public void onCancel() {

                        }
                    });
        }
    }

    public ScheduledExecutorService getScheduledCacheExecutor() {
        return scheduledCacheExecutor;
    }

    public void setCacheUser(User cacheUser) {
        this.cacheUser = cacheUser;
    }

    public static boolean isFirstLogin() {
        return firstLogin;
    }

    public static void setFirstLogin(boolean firstLogin) {
        CacheController.firstLogin = firstLogin;
    }
}
