package jkiosk3.sales._favourites.nfc;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import za.co.blt.consumer.loyalty.api.service.model.request.ConsumerProfileRequest;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfileIdentifier;

public class NFCNewRegistration extends Region {

    NFCSubscriberInput nfcSubscriberInput;
    private String cardNum;
    private String subName;
    private String subSurname;
    private String subCellNum;
    private TextField txtSubName;
    private TextField txtSubSurname;
    private TextField txtSubCellNum;

    public NFCNewRegistration() {
        nfcSubscriberInput = new NFCSubscriberInput(false, false);
        getChildren().add(getNewRegEntry());
    }

    public VBox getNewRegEntry() {

        VBox vBox = JKLayout.getVBox(0, JKLayout.sp);
        vBox.setStyle("-fx-padding: 30px 0px 0px 0px;");

        vBox.getChildren().addAll(nfcSubscriberInput, getInput(), JKNode.createContentSep(), getBtnControls());

        return vBox;
    }

    private GridPane getInput() {

        Label lblSubName = JKText.getLblDk("Name", JKText.FONT_B_20);
        Label lblSubSurname = JKText.getLblDk("Surname", JKText.FONT_B_20);
        Label lblSubCellNum = JKText.getLblDk("Cellphone Number", JKText.FONT_B_20);

        txtSubName = new TextField();
        txtSubName.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtSubName, "Enter Subscriber First Name", "", false);
            }
        });

        txtSubSurname = new TextField();
        txtSubSurname.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(txtSubSurname, "Enter Subscriber Surname", "", false);
            }
        });

        txtSubCellNum = new TextField();
        txtSubCellNum.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtSubCellNum, "Enter Cell Number", "");
            }
        });

        GridPane gridPane = JKLayout.getContentGridInner2Col(0.50, 0.50);

        gridPane.addRow(1, lblSubName, txtSubName);
        gridPane.addRow(2, lblSubSurname, txtSubSurname);
        gridPane.addRow(3, lblSubCellNum, txtSubCellNum);

        return gridPane;
    }

    private HBox getBtnControls() {
        Button btnAccept = JKNode.getBtnSm("Register Subscriber");
        btnAccept.setWrapText(true);
        btnAccept.getStyleClass().add("btnNFC");
        btnAccept.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (isValidEntry()) {
                    createConsumerProfile();
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Subscriber Registration", "Please enter all required details", null);
                }
            }
        });

        Button btnCancel = JKNode.getBtnSm("Cancel");
        btnCancel.getStyleClass().add("btnNFC");
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                NFCUtil.resetNFCView();
            }
        });

        HBox hb = JKLayout.getHBox(0, JKLayout.sp);

        hb.getChildren().addAll(JKNode.getHSpacer(), btnAccept, btnCancel);

        return hb;
    }

    private void createConsumerProfile() {
        ConsumerProfileRequest consumerProfileRequest = new ConsumerProfileRequest();
        consumerProfileRequest.setLoyaltyCard(cardNum);
        consumerProfileRequest.setName(subName);
        consumerProfileRequest.setSurname(subSurname);
        consumerProfileRequest.setMobile(subCellNum);

        NFCUtil.createConsumerProfile(consumerProfileRequest, new NFCUtil.ConsumerProfileIdentifierResult() {
            @Override
            public void consumerProfileIdentifierResult(ConsumerProfileIdentifier consumerProfileId) {
                if (!consumerProfileId.getProfileId().isEmpty()) {
                    JKiosk3.getMsgBox().showMsgBox("Subscriber Registration", "Subscriber successfully registered", null);
                    NFCUtil.resetNFCView();
                } else {
                    NFCUtil.resetNFCView();
                }
            }
        });
    }

    private boolean isValidEntry() {
        if (nfcSubscriberInput.getCardNumber().isEmpty() || nfcSubscriberInput.getCardNumber().equals("")) {
            return false;
        } else {
            cardNum = nfcSubscriberInput.getCardNumber();
        }
        if (txtSubName.getText().isEmpty()) {
            return false;
        } else {
            subName = txtSubName.getText();
        }
        if (txtSubSurname.getText().isEmpty()) {
            return false;
        } else {
            subSurname = txtSubSurname.getText();
        }
        if (txtSubCellNum.getText().isEmpty()) {
            return false;
        } else {
            subCellNum = txtSubCellNum.getText();
        }

        return true;
    }
}
