package jkiosk3._components.update;

import Download.HttpUtils;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3.StageJKiosk;
import jkiosk3._common.ResultCallback;

import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StageLibUpdate extends Stage {

//    private final static Logger logger = Logger.getLogger(StageLibUpdate.class.getName());
//
//    private final double stageWidth = StageJKiosk.getSceneWidth();
//    private final double stageHeight = StageJKiosk.getSceneHeight();
//
//    private ResultCallback finalResult;

//    public StageLibUpdate(ResultCallback finalResult) {
//        this.finalResult = finalResult;
//        loadLibUpdateStage();
//
//        Timer t = new Timer();
//        t.schedule(new TimerTask() {
//            @Override
//            public void run() {
//                getLibFileList();
//            }
//        }, 350);
//    }

//    private void loadLibUpdateStage() {
//
//        Stage stageLibUpdate = new Stage();
//        stageLibUpdate.initOwner(JKiosk3.getMainStage());
//        stageLibUpdate.setTitle("Updating Application");
//        stageLibUpdate.initStyle(StageStyle.TRANSPARENT);
//        stageLibUpdate.initModality(Modality.APPLICATION_MODAL);
//        stageLibUpdate.setWidth(stageWidth);
//        stageLibUpdate.setHeight(stageHeight);
//
//        StackPane root = new StackPane();
//
//        VBox vb = showUpdateProcessing();
//
//        root.getChildren().add(vb);
//
//        Scene scene = new Scene(root, stageWidth, stageHeight);
//
//        scene.getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/default.css").toExternalForm());
//        scene.getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/stageupdate.css").toExternalForm());
//
//        stageLibUpdate.setScene(scene);
//        stageLibUpdate.show();
//    }

//    private VBox showUpdateProcessing() {
//        ProgressIndicator prog = new ProgressIndicator();
//        prog.setMaxSize(55, 55);
//        prog.setMinSize(55, 55);
//
//        Label lblUpdate = new Label("Updating Essential Files");
//        lblUpdate.getStyleClass().add("lblLg");
//
//        Label lblInfo = new Label("Please Wait");
//        lblInfo.getStyleClass().add("lblMed");
//
//        VBox vb = new VBox(45);
//        vb.setPrefSize(stageWidth, stageHeight);
//        vb.getStyleClass().add("vbDownload");
//        vb.getChildren().addAll(prog, lblUpdate, lblInfo);
//
//        return vb;
//    }

//    private void getLibFileList() {
//        String fileRem = JK3Config.getFileUpdatePath() + JK3Config.LIST_LIB_FILES;
//        String fileLocal = JK3Config.getAppInstallPath() + JK3Config.LIST_LIB_FILES;
//        if (HttpUtils.httpDownload(fileRem, fileLocal, true, null)) {
//            if (HttpUtils.isLocalFileComplete(fileRem, fileLocal)) {
////                checkLibFolderExists();
//                LibFilesUpdate libFilesUpdate = new LibFilesUpdate(new ResultCallback() {
//                    @Override
//                    public void onResult(boolean result) {
//                        finalResult.onResult(result);
//                    }
//                });
//            }
//        } else {
//            // if lib files cannot be updated, app might not work
//            if (JOptionPane.showConfirmDialog(null,
//                    "\nUnable to find essential files.\n\nApplication will close.\n\nPlease contact Technical Support.\n",
//                    "JKiosk file(s) not found",
//                    JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE) == 0) {
//                System.exit(0);
//            }
//        }
//    }

//    private void checkLibFolderExists() {
//        File libFolder = new File(JK3Config.getAppInstallPath() + "lib");
//        if (!libFolder.exists()) {
//            if (libFolder.mkdir()) {
//                checkLibFilesUpdate();
//            }
//        } else {
//            checkLibFilesUpdate();
//        }
//    }

//    private void checkLibFilesUpdate() {
//        // download all updated lib files BEFORE application update
//        String dirRem = JK3Config.getFileUpdatePath() + "lib";
//        String dirLocal = JK3Config.getAppInstallPath() + "lib";
//
//        LibFilesXML libFilesXML = new LibFilesXML(JK3Config.LIST_LIB_FILES);
//        List<String> listLibsNew = libFilesXML.getListLibFilenames();
//
//        boolean isLibFileNewer = false;
//        int filecount = 0;
//        for (String s : listLibsNew) {
//            String remoteFile = dirRem + "/" + s;
//            String localFile = dirLocal + File.separator + s;
//
//            isLibFileNewer = HttpUtils.isRemoteFileNewer(remoteFile, localFile);
//            if (isLibFileNewer) {
//                try {
//                    logger.info(("lib file is newer :  ").concat(s));
//                    getLibDownload(remoteFile, localFile, new ResultCallback() {
//                        @Override
//                        public void onResult(boolean result) {
//                            if (result) {
//                                logger.info(("LIB RESULT - download success : ").concat(remoteFile));
//                            } else {
//                                logger.info(("LIB RESULT - download failure : ").concat(remoteFile));
//                            }
//                        }
//                    });
//                } catch (FileNotFoundException nfe) {
//                    logger.log(Level.SEVERE, nfe.getMessage(), nfe);
//                }
//            }
//            filecount++;
//            if (filecount == listLibsNew.size()) {
//                // all lib files done, continue to application update...
//                deleteUnusedLibs(listLibsNew);
//                finalResult.onResult(true);
//            } else {
//                finalResult.onResult(false);
//            }
//        }
//    }

//    private void getLibDownload(String remote, String local, ResultCallback libDLResult) throws FileNotFoundException {
//        if (HttpUtils.httpDownload(remote, local, true, null)) {
//            if (HttpUtils.isLocalFileComplete(remote, local)) {
//                libDLResult.onResult(true);
//            }
//        } else {
//            libDLResult.onResult(false);
//        }
//    }

//    private void deleteUnusedLibs(List<String> listNew) {
//        String dirLocal = JK3Config.getAppInstallPath() + "lib";
//        File dir = new File(dirLocal);
//
//        if (dir.isDirectory()) {
//            File[] files = dir.listFiles();
//            for (File f : Arrays.asList(files)) {
//                if (!listNew.contains(f.getName())) {
//                    logger.info(("file abs path = ").concat(f.getAbsolutePath()));
//                    if (f.delete()) {
//                        logger.info("FILE DELETED");
//                    } else {
//                        logger.info("FILE NOT DELETED");
//                    }
//                }
//            }
//        }
//    }
}
