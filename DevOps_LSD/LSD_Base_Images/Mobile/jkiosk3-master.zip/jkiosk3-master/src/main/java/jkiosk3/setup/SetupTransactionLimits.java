package jkiosk3.setup;

import java.util.logging.Logger;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.NumberPadResult;
import jkiosk3.store.JKTransactionLimits;
import jkiosk3.store.StoreJKTransactionLimits;

/**
 *
 * @author valeriew
 */
public class SetupTransactionLimits extends Region {

    private final static Logger logger = Logger.getLogger(SetupTransactionLimits.class.getName());
    private double amount;

    public SetupTransactionLimits() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getTransactionLimitsEntry());
        vb.getChildren().add(getControls());

        getChildren().add(vb);
    }

    private GridPane getTransactionLimitsEntry() {

        VBox vbHead = JKNode.getPageHeadVB("Transaction Limits");

        Label lblBillPayLimit = JKText.getLblDk("Bill Payment Limit", JKText.FONT_B_SM);

        double amtSaved = JKTransactionLimits.getTransactionLimits().getTransLimitBillPay();

        final TextField txtBillPayLimit = new TextField();
        txtBillPayLimit.setText(String.format(JKText.getDeciFormat(amtSaved)));
        txtBillPayLimit.getStyleClass().add("txtfld-right");
        txtBillPayLimit.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtBillPayLimit, "Enter Amount", "", new NumberPadResult() {

                    @Override
                    public void onDone(String value) {
                        if (isValidAmount(value)) {
                            JKTransactionLimits.getTransactionLimits().setTransLimitBillPay(amount);
                            txtBillPayLimit.setText(String.format(JKText.getDeciFormat(amount)));
                        }
                    }
                });
            }
        });

        GridPane grid = JKLayout.getGridContent2Col(0.5, 0.5, HPos.RIGHT);

        grid.addRow(0, vbHead);
        grid.addRow(2, lblBillPayLimit, txtBillPayLimit);
        grid.addRow(3, new Label(""));

        return grid;
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("", false) {
            @Override
            public void onClickTest() {
            }

            @Override
            public void onClickSave() {
                saveTransLimits();
            }
        };
    }

    private boolean isValidAmount(String amt) {
        boolean isValid = false;
        try {
            amount = Double.parseDouble(amt);
            isValid = true;
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox().showMsgBox("Amount", "Please enter a valid Amount", null);
        }
        return isValid;
    }

    private void saveTransLimits() {
        StoreJKTransactionLimits storeLimits = new StoreJKTransactionLimits();
        storeLimits.setTransLimitBillPay(JKTransactionLimits.getTransactionLimits().getTransLimitBillPay());

        if (JKTransactionLimits.saveTransactionLimits(storeLimits)) {
            logger.info(("Amount Saved for Bill Payment Limit : ").concat(Double.toString(JKTransactionLimits.getTransactionLimits().getTransLimitBillPay())));
            JKiosk3.getMsgBox().showMsgBox("Saved", "Transaction Limits saved successfully", null);
        }
    }
}
