package jkiosk3.store.cache;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import jkiosk3.sales.topups.TopupProvider;

/**
 *
 * @author valeriew
 */
public class ListTopupBundles implements Serializable {
    
    // L(ist)  = 12 (1 + 2 = 3)
    // T(opup) = 20 (2 + 0 = 2)
    // (b)U(ndles) = 21 (2 + 1 = 3)
    // b would resolve to 2 - 322 already used
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 999323L;

    private final List<TopupProvider> listTopupProviders = new ArrayList<>();

    public List<TopupProvider> getListTopupProviders() {
        return listTopupProviders;
    }
}
