package jkiosk3._components.update;

import Download.HttpUtils;
import jkiosk3.JK3Config;
import jkiosk3._common.ResultCallback;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LibFilesUpdate {

//    private final static Logger logger = Logger.getLogger(LibFilesUpdate.class.getName());

//    private ResultCallback finalResult;
//
//    public LibFilesUpdate() {
////        this.finalResult = resultCallback;
////        checkLibFolderExists();
//    }

//    public LibFilesUpdate(ResultCallback resultCallback) {
//        this.finalResult = resultCallback;
//        checkLibFolderExists();
//    }

//    public boolean doesLibFolderExist() {
//        File libFolder = new File(JK3Config.getAppInstallPath() + "lib");
//        if (!libFolder.exists()) {
//            if (libFolder.mkdir()) {
//                return true;
//            }
//        } else {
//            return true;
//        }
//        return false;
//    }

//    public boolean updateLibFiles() {
//        boolean filesComplete = false;
//        // download all updated lib files BEFORE application update
//        String dirRem = JK3Config.getFileUpdatePath() + "lib";
//        String dirLocal = JK3Config.getAppInstallPath() + "lib";
//
//        LibFilesXML libFilesXML = new LibFilesXML(JK3Config.LIST_LIB_FILES);
//        List<String> listLibsNew = libFilesXML.getListLibFilenames();
//
//        boolean isLibFileNewer = false;
//        int filecount = 0;
//        for (String s : listLibsNew) {
//            String remoteFile = dirRem + "/" + s;
//            String localFile = dirLocal + File.separator + s;
//
//            isLibFileNewer = HttpUtils.isRemoteFileNewer(remoteFile, localFile);
//            if (isLibFileNewer) {
//                try {
//                    logger.info(("lib file is newer :  ").concat(s));
//                    getLibDownload(remoteFile, localFile, new ResultCallback() {
//                        @Override
//                        public void onResult(boolean result) {
//                            if (result) {
//                                logger.info(("LIB RESULT - download success : ").concat(remoteFile));
//                            } else {
//                                logger.info(("LIB RESULT - download failure : ").concat(remoteFile));
//                            }
//                        }
//                    });
//                } catch (FileNotFoundException nfe) {
//                    logger.log(Level.SEVERE, nfe.getMessage(), nfe);
//                }
//            }
//            filecount++;
//            if (filecount == listLibsNew.size()) {
//                // all lib files done, continue to application update...
//                deleteUnusedLibs(listLibsNew);
////                finalResult.onResult(true);
//                System.out.println("all files downloaded");
//                filesComplete = true;
////            } else {
////                System.out.println("filecount = " + filecount);
////                finalResult.onResult(false);
//            }
//        }
//        System.out.println("filesComplete = " + filesComplete);
//        return filesComplete;
//    }

//    private void checkLibFolderExists() {
//        File libFolder = new File(JK3Config.getAppInstallPath() + "lib");
//        if (!libFolder.exists()) {
//            if (libFolder.mkdir()) {
//                checkLibFilesUpdate();
//            }
//        } else {
//            checkLibFilesUpdate();
//        }
//    }

//    private void checkLibFilesUpdate() {
//        // download all updated lib files BEFORE application update
//        String dirRem = JK3Config.getFileUpdatePath() + "lib";
//        String dirLocal = JK3Config.getAppInstallPath() + "lib";
//
//        LibFilesXML libFilesXML = new LibFilesXML(JK3Config.LIST_LIB_FILES);
//        List<String> listLibsNew = libFilesXML.getListLibFilenames();
//
//        boolean isLibFileNewer = false;
//        int filecount = 0;
//        for (String s : listLibsNew) {
//            String remoteFile = dirRem + "/" + s;
//            String localFile = dirLocal + File.separator + s;
//
//            isLibFileNewer = HttpUtils.isRemoteFileNewer(remoteFile, localFile);
//            if (isLibFileNewer) {
//                try {
//                    logger.info(("lib file is newer :  ").concat(s));
//                    getLibDownload(remoteFile, localFile, new ResultCallback() {
//                        @Override
//                        public void onResult(boolean result) {
//                            if (result) {
//                                logger.info(("LIB RESULT - download success : ").concat(remoteFile));
//                            } else {
//                                logger.info(("LIB RESULT - download failure : ").concat(remoteFile));
//                            }
//                        }
//                    });
//                } catch (FileNotFoundException nfe) {
//                    logger.log(Level.SEVERE, nfe.getMessage(), nfe);
//                }
//            }
//            filecount++;
//            if (filecount == listLibsNew.size()) {
//                // all lib files done, continue to application update...
//                deleteUnusedLibs(listLibsNew);
//                finalResult.onResult(true);
//                System.out.println("all files downloaded");
//            } else {
//                finalResult.onResult(false);
//            }
//        }
//    }

//    private void getLibDownload(String remote, String local, ResultCallback libDLResult) throws FileNotFoundException {
//        if (HttpUtils.httpDownload(remote, local, true, null)) {
//            if (HttpUtils.isLocalFileComplete(remote, local)) {
//                libDLResult.onResult(true);
//            }
//        } else {
//            libDLResult.onResult(false);
//        }
//    }

//    private void deleteUnusedLibs(List<String> listNew) {
//        String dirLocal = JK3Config.getAppInstallPath() + "lib";
//        File dir = new File(dirLocal);
//
//        if (dir.isDirectory()) {
//            File[] files = dir.listFiles();
//            for (File f : Arrays.asList(files)) {
//                if (!listNew.contains(f.getName())) {
//                    logger.info(("file abs path = ").concat(f.getAbsolutePath()));
//                    if (f.delete()) {
//                        logger.info("FILE DELETED");
//                    } else {
//                        logger.info("FILE NOT DELETED");
//                    }
//                }
//            }
//        }
//    }
}
