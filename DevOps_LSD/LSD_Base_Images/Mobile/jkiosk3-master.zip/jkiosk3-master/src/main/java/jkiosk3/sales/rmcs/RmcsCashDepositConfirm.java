package jkiosk3.sales.rmcs;

import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;

/**
 *
 * @author valeriew
 */
public class RmcsCashDepositConfirm extends Region {
    
    public RmcsCashDepositConfirm() {
        getChildren().add(getDepositConfirm());
    }
    
    
    private GridPane getDepositConfirm() {
        double inset = 2 * JKLayout.sp;

        Label lblDepositor = JKText.getLblContentSubHead("Depositor Details: ");
        Label lblRecipient = JKText.getLblContentSubHead("Recipient Details: ");
        Label lblDeposit = JKText.getLblContentSubHead("Deposit Details: ");

        // Depositor components
        Label lblDepMobileNum = JKText.getLblDk("Mobile Number", JKText.FONT_B_XSM);
        lblDepMobileNum.setTranslateX(inset);
        Label lblDepIDNum = JKText.getLblDk("ID Number", JKText.FONT_B_XSM);
        lblDepIDNum.setTranslateX(inset);
        Label lblDepIDConfirm = JKText.getLblDk("ID Book present and ID Number confirmed", JKText.FONT_B_XSM);
        lblDepIDConfirm.setTranslateX(inset);
        
        Text txtDepMobileNum = JKText.getTxtDk(JKText.getCellNumFormatted(RmcsDeposit.getInstance().getPreAuthReq().getDepoMSISDN()), JKText.FONT_B_XSM);
        Text txtDepIDNum = JKText.getTxtDk(JKText.getSAIDNumFormatted(RmcsDeposit.getInstance().getPreAuthReq().getDepoID()), JKText.FONT_B_XSM);
        String confirmId = "";
        if (RmcsDeposit.getInstance().isIdConfirmed()) {
            confirmId = "Yes";
        } else {
            confirmId = "No";
        }
        Text chkDepIDConfirm = JKText.getTxtDk(confirmId, JKText.FONT_B_XSM);
        
        HBox hbIDConf = JKLayout.getHBox(0, 0);
        hbIDConf.getChildren().addAll(lblDepIDConfirm, JKNode.getHSpacer(), chkDepIDConfirm);
        
        // Recipient components
        Label lblRecMobileNum = JKText.getLblDk("Mobile Number", JKText.FONT_B_XSM);
        lblRecMobileNum.setTranslateX(inset);
        
        Text txtRecMobileNum = JKText.getTxtDk(JKText.getCellNumFormatted(RmcsDeposit.getInstance().getPreAuthReq().getRecipMSISDN()), JKText.FONT_B_XSM);

        // Deposit components
        Label lblDepAmount = JKText.getLblDk("Amount", JKText.FONT_B_XSM);
        lblDepAmount.setTranslateX(inset);
        Label lblDepFee = JKText.getLblDk("Fee", JKText.FONT_B_XSM);
        lblDepFee.setTranslateX(inset);
        Label lblDepTotal = JKText.getLblDk("Total", JKText.FONT_B_XSM);
        lblDepTotal.setTranslateX(inset);

        Text txtDepAmount = JKText.getTxtDk(JKText.getDeciFormat(RmcsDeposit.getInstance().getPreAuthReq().getAmount()), JKText.FONT_B_XSM);
        Text txtDepFee = JKText.getTxtDk(JKText.getDeciFormat(RmcsDeposit.getInstance().getPreAuthResp().getConvFees()), JKText.FONT_B_XSM);
        
        double amtTotal = RmcsDeposit.getInstance().getPreAuthReq().getAmount() + RmcsDeposit.getInstance().getPreAuthResp().getConvFees();
        Text txtDepTotal = JKText.getTxtDk(JKText.getDeciFormat(amtTotal), JKText.FONT_B_SM);        

        GridPane gridConfirm = JKLayout.getGridSummary2Col(0.5, 0.5);

        gridConfirm.add(JKNode.createGridSpanSep(2), 0, 0);
        gridConfirm.addRow(1, lblDepositor);
        gridConfirm.addRow(2, lblDepMobileNum, txtDepMobileNum);
        gridConfirm.addRow(3, lblDepIDNum, txtDepIDNum);
        gridConfirm.add(hbIDConf, 0, 4, 2, 1);
        gridConfirm.addRow(6, lblRecipient);
        gridConfirm.addRow(7, lblRecMobileNum, txtRecMobileNum);
        gridConfirm.addRow(9, lblDeposit);
        gridConfirm.addRow(10, lblDepAmount, txtDepAmount);
        gridConfirm.addRow(11, lblDepFee, txtDepFee);
        gridConfirm.addRow(12, lblDepTotal, txtDepTotal);

        return gridConfirm;
    }    
}
