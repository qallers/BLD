package jkiosk3.sales.ithuba.lotto;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author valeriew
 */
public class LottoSale {

    private Map<String, List<String>> boardNumbers = new LinkedHashMap<>();
    private boolean lottoPlus1;
    private boolean lottoPlus2;
    private double amount;
    private int boards;
    private int draws;

    private static volatile LottoSale instance;

    private static LottoSale newInstance() {
        instance = new LottoSale();
        return instance;
    }

    public static LottoSale getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    public static void resetLottoSale() {
        System.out.println("  > > >  RESETTING LOTTO SALE TO NULL...");
        instance = null;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getBoards() {
        return boards;
    }

    public void setBoards(int boards) {
        this.boards = boards;
    }

    public int getDraws() {
        return draws;
    }

    public void setDraws(int draws) {
        this.draws = draws;
    }

    public boolean isLottoPlus1() {
        return lottoPlus1;
    }

    public void setLottoPlus1(boolean lottoPlus1) {
        this.lottoPlus1 = lottoPlus1;
    }

    public boolean isLottoPlus2() {
        return lottoPlus2;
    }

    public void setLottoPlus2(boolean lottoPlus2) {
        this.lottoPlus2 = lottoPlus2;
    }

    public Map<String, List<String>> getBoardNumbers() {
        return boardNumbers;
    }

    public void setBoardNumbers(Map<String, List<String>> boardNumbers) {
        this.boardNumbers = boardNumbers;
    }
}
