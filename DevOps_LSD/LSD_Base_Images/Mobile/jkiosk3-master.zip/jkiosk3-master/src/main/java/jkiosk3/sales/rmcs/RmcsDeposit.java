package jkiosk3.sales.rmcs;

import aeonmoneytransfer.MoneyTransferDepositReq;
import aeonmoneytransfer.MoneyTransferPreAuthReq;
import aeonmoneytransfer.MoneyTransferResponse;
import java.util.Date;

/**
 *
 *
 */
public class RmcsDeposit {

    private final MoneyTransferPreAuthReq preAuthReq = new MoneyTransferPreAuthReq();
    private MoneyTransferResponse preAuthResp = new MoneyTransferResponse();
    private final MoneyTransferDepositReq depositReq = new MoneyTransferDepositReq();
    private MoneyTransferResponse depositResp = new MoneyTransferResponse();
    private MoneyTransferResponse declineResp = new MoneyTransferResponse();
    private boolean idConfirmed;
    private double amtTotal;
    private Date date;

    private static volatile RmcsDeposit instance;

    public static RmcsDeposit getInstance() {
        return instance;
    }

    public static RmcsDeposit newInstance() {
        instance = new RmcsDeposit();
        return instance;
    }

    public static void resetRmcsCashDeposit() {
        instance = null;
    }

    // getters and setters
    public MoneyTransferPreAuthReq getPreAuthReq() {
        return preAuthReq;
    }

    public void setPreAuthResp(MoneyTransferResponse preAuthResp) {
        this.preAuthResp = preAuthResp;
    }

    public MoneyTransferResponse getPreAuthResp() {
        return preAuthResp;
    }

    public MoneyTransferDepositReq getDepositReq() {
        return depositReq;
    }

    public void setDepositResp(MoneyTransferResponse depositResp) {
        this.depositResp = depositResp;
    }

    public MoneyTransferResponse getDepositResp() {
        return depositResp;
    }

    public MoneyTransferResponse getDeclineResp() {
        return declineResp;
    }

    public void setDeclineResp(MoneyTransferResponse declineResp) {
        this.declineResp = declineResp;
    }

    public double getAmtTotal() {
        return amtTotal;
    }

    public void setAmtTotal(double amtTotal) {
        this.amtTotal = amtTotal;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean isIdConfirmed() {
        return idConfirmed;
    }

    public void setIdConfirmed(boolean idConfirmed) {
        this.idConfirmed = idConfirmed;
    }
}
