package jkiosk3.sales._recharge_plus;

import aeonusers.UserTransactionType;
import jkiosk3.store.cache.CacheListTransTypes;

import java.util.List;
import java.util.logging.Logger;

public class RechargePlusUtil {

    private final static Logger logger = Logger.getLogger(RechargePlusUtil.class.getName());

    public final static String RECHARGE_PLUS_LBL = "Recharge Plus";

    public static double getRechargePlusValue() {
        double rechargePlusValue = 0.0;
        List<UserTransactionType> listTransTypes = CacheListTransTypes.getListTransactionTypes();
        for (UserTransactionType t : listTransTypes) {
            if (t.getTransactionType().equalsIgnoreCase("RechargePlus")) {
                rechargePlusValue = (double) t.getValueInCents() / 100;
                break;
            }
        }
        return rechargePlusValue;
    }
}
