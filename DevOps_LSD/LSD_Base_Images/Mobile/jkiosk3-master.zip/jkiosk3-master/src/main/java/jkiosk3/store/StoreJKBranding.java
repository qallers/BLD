package jkiosk3.store;

import java.io.Serializable;
import jkiosk3.branding.MerchantGroup;

/**
 *
 * @author Valerie
 */
public class StoreJKBranding implements Serializable {

    private MerchantGroup merchantGroup;

    public MerchantGroup getMerchantGroup() {
        return merchantGroup;
    }

    public void setMerchantGroup(MerchantGroup merchantGroup) {
        this.merchantGroup = merchantGroup;
    }
}
