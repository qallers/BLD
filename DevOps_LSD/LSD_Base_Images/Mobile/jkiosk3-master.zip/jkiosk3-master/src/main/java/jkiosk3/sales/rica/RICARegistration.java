package jkiosk3.sales.rica;

import aeonrica.Registration;
import javafx.scene.control.RadioButton;

/**
 *
 * @author Val
 */
public class RICARegistration {

    private static Registration ricaReg;
    //
    private static SubReg0 pg0;
    private static SubReg1 pg1;
    private static SubReg2 pg2;
    private static SubReg3 pg3;
    private static SubReg4 pg4;
    //
    private final static String ID_DOC = "ID Document";
    private final static String ID_PASSPORT = "Passport";
    //
    private static String currIdType;
    private static String currIdNumber;
    private static String currNationality;
    private static String network;
    private static String title;
    private static String firstNames;
    private static String lastName;
    private static String idType;
    private static String idNumber;
    private static String nationality;
    private static boolean isIdVerified;
    private static String addr1;
    private static String addr2;
    private static String addrSuburb;
    private static String addrCity;
    private static String addrRegion;
    private static String addrPostcode;
    private static String addrCountry;
    private static boolean isAddrVerified;
    private static String telCountryCode;
    private static String telAreaCode;
    private static String telDiallingNo;
    private static String refType;
    private static String refNumber;
    private static String l4SimNum;

    public static Registration getRicaRegistration(SubReg0 reg0, SubReg1 reg1, SubReg2 reg2, SubReg3 reg3, SubReg4 reg4) {
        pg0 = reg0;
        pg1 = reg1;
        pg2 = reg2;
        pg3 = reg3;
        pg4 = reg4;

        ricaReg = createRicaRegistration();

        return ricaReg;
    }

    private static void getRegistrationValues() {

        // pg0
        if (pg0 != null) {
            if (pg0.getToggleIdNumber().isSelected()) {
                currIdType = ID_DOC;
            } else if (pg0.getTogglePassport().isSelected()) {
                currIdType = ID_PASSPORT;
            }

            if (RICAUtil.isChOwnSimSp()) {
                currNationality = "ZA";
                currIdNumber = "1111111111112";
                currIdType = "N";
            } else if (RICAUtil.isChOwnCell()) {
                currIdNumber = pg0.getTxtIdentification().getText();
                for (CountryCodes.CountryCode c : CountryCodes.getCodeList()) {
                    if (pg0.getTxtNationality().getText().equals(c.toString())) {
                        currNationality = c.getCode();
                    }
                }
            } else {
                currNationality = "";
                currIdNumber = "";
                currIdType = "";
            }
        } else {
            currNationality = "";
            currIdNumber = "";
            currIdType = "";
        }

        // pg1
        network = pg1.getToggleNetwork().getId();

        // pg2
        title = pg2.getComTitle().getSelectionModel().getSelectedItem().toString();
        firstNames = pg2.getTxtFirstNames().getText();
        lastName = pg2.getTxtSurname().getText();

        if (pg2.getToggleIdNumber().isSelected()) {
            idType = ID_DOC;
        } else if (pg2.getTogglePassport().isSelected()) {
            idType = ID_PASSPORT;
        }

        idNumber = pg2.getTxtIdentification().getText();
        for (CountryCodes.CountryCode c : CountryCodes.getCodeList()) {
            if (pg2.getTxtNationality().getText().equals(c.toString())) {
                nationality = c.getCode();
            }
        }
        isIdVerified = pg2.getChkIdVerified().isSelected();
//
//        // pg3
        addr1 = pg3.getTxtAddr1().getText();
        addr2 = pg3.getTxtAddr2().getText();
        addrSuburb = pg3.getTxtAddrSuburb().getText();
        addrCity = pg3.getTxtAddrCity().getText();
        addrRegion = pg3.getComAddrProvince().getSelectionModel().getSelectedItem().toString();
        addrPostcode = pg3.getTxtAddrPostCode().getText();
        for (CountryCodes.CountryCode c : CountryCodes.getCodeList()) {
            if (pg3.getTxtCountry().getText().equals(c.toString())) {
                addrCountry = c.getCode();
            }
        }
        isAddrVerified = pg3.getChkAddrVerified().isSelected();
//
//        // pg4
        for (CountryCodes.CountryCode c : CountryCodes.getCodeList()) {
            if (pg4.getTxtCountryCode().getText().equals(c.getDial())) {
                telCountryCode = c.getDial();
            }
        }
        telAreaCode = pg4.getTxtAreaCode().getText();
        telDiallingNo = pg4.getTxtAltNumber().getText();
//        refType = pg4.getComRegisterBy().getSelectionModel().getSelectedItem().toString();
        for (RadioButton r : pg4.getListRadios()) {
            if (r.isSelected()) {
                refType = r.getText();
                break;
            }
        }
        refNumber = pg4.getTxtRefNum().getText();
        l4SimNum = pg4.getTxtL4SimNum().getText();
    }

    private static Registration createRicaRegistration() {

        getRegistrationValues();

        Registration reg = new Registration();

        switch (RICAUtil.getRegistrationType()) {
            case RICAUtil.NEW_REG:
                reg.setChangeOwner(false);
                reg.setExisting(false);
                break;
            case RICAUtil.CHANGE_CELL_NUM:
                reg.setChangeOwner(true);
                reg.setExisting(true);
                break;
            case RICAUtil.CHANGE_SIM_SP:
                reg.setChangeOwner(true);
                reg.setExisting(true);
        }

        // pg0
        if (pg0 != null) {
            switch (currIdType) {
                case ID_DOC:
                    reg.setCurrOwnIdtype("N");
                    break;
                case ID_PASSPORT:
                    reg.setCurrOwnIdtype("P");
                    break;
            }
            reg.setCurrOwnIdnumber(currIdNumber);
            reg.setCurrOwnNationality(currNationality);
        }

        // pg1
        reg.setNetwork(network);

        // pg2
        reg.setTitle(title);
        reg.setFirstname(firstNames);
        reg.setLastname(lastName);

        switch (idType) {
            case ID_DOC:
                reg.setIdtype("N");
                break;
            case ID_PASSPORT:
                reg.setIdtype("P");
                break;
        }

        reg.setIdnumber(idNumber);
        reg.setNationality(nationality);
        reg.setIdverify(isIdVerified);

        // pg3
        reg.setAddr1(addr1);
        reg.setAddr2(addr2);
        reg.setAddrsuburb(addrSuburb);
        reg.setAddrcity(addrCity);
        reg.setAddrregion(addrRegion);
        reg.setAddrpostcode(addrPostcode);
        reg.setAddrcountry(addrCountry);
        reg.setProofaddr(isAddrVerified);

        // pg4
        reg.setTelCountryCode(telCountryCode);
        reg.setTelAreaCode(telAreaCode);
        reg.setTelDialingNo(telDiallingNo);
        switch (refType) {
            case SubAll.REG_TYPE_CELL:
                reg.setReftype(SubAll.REG_SUBMIT_CELL);
                break;
            case SubAll.REG_TYPE_SP:
                reg.setReftype(SubAll.REG_SUBMIT_SP);
                break;
            case SubAll.REG_TYPE_SIM:
                reg.setReftype(SubAll.REG_SUBMIT_SIM);
        }
        reg.setRefnumber(refNumber);
        reg.setLast4simdigs(l4SimNum);

        return reg;
    }
}
