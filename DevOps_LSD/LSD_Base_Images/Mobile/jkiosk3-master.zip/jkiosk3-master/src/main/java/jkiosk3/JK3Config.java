package jkiosk3;

import xmlproperties.XMLProperties;

import javax.swing.*;
import java.util.Properties;

public class JK3Config {

    //    private final static String DOWNLOAD_PATH_LIVE = "http://196.38.158.102/touchscreen/jkiosk3/app/";
//    private final static String DOWNLOAD_PATH_DEMO = "http://196.38.158.113/touchscreen/jkiosk3_demo/app/";
    //
//    public final static String DEMO_CONFIG_URL = "http://196.38.158.113/touchscreen/jkiosk3_demo/jk3config.xml";
//    public final static String LIVE_CONFIG_URL = "http://196.38.158.102/touchscreen/jkiosk3/jk3config.xml";
    public final static String CONFIG_FILENAME = "jk3config.xml";
    public final static String LIST_LIB_FILES = "libfiles.xml";

    private static Properties configuration;
    private static Properties mediaConfig;
    private static Properties infoConfig;
    private static Properties brandingConfig;

    public static boolean buildFilePaths() {
        try {
            configuration = new XMLProperties(CONFIG_FILENAME).getProperties("Files", "DirectoryPaths");
            mediaConfig = new XMLProperties(CONFIG_FILENAME).getProperties("Files", "Media");
            infoConfig = new XMLProperties(CONFIG_FILENAME).getProperties("Info", "Contacts");
            brandingConfig = new XMLProperties(CONFIG_FILENAME).getProperties("Info", "Branding");
            return true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Unable to find config file\n" + e.getMessage(), "Config",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public static String getFileUpdatePath() {
        buildFilePaths();
        return getServerPath() + configuration.getProperty("filePath");
    }

    public static String getServerPath() {
        return configuration.getProperty("serverPath");
    }

    public static String getLoyaltyPath() {
        return configuration.getProperty("loyaltyPath");
    }

    public static String getAppUpdatePath() {
        return getFileUpdatePath() + configuration.getProperty("jkioskAppUpdate");
    }

    public static String getAppInstallPath() {
        return configuration.getProperty("jkioskInstallPath", "c:\\jkiosk3\\");
    }

    public static String getAppInstallFile() {
        return configuration.getProperty("jkioskAppUpdate");
    }

    public static String getDownloadsFolder() {
        return getServerPath() + configuration.getProperty("downloadsFolder");
    }

    public static String getAutoUpdaterPath() {
        return getDownloadsFolder() + configuration.getProperty("jkioskUpdater");
    }

    public static String getAutoUpdater() {
        return getAppInstallPath() + configuration.getProperty("jkioskUpdater");
    }

    public static String getNonSSLRicaServer() { return configuration.getProperty("nonRicaSSL"); }

    public static String getSSLRicaServer() { return configuration.getProperty("ricaSSL"); }

    public static String getNonSSLRicaPort() {
        return configuration.getProperty("nonRicaSSLPort");
    }

    public static String getSSLRicaPort() { return configuration.getProperty("ricaSSLPort"); }

    public static String getHelpUrl() {
        return getServerPath() + configuration.getProperty("helpUrl");
    }

    public static String getRssUrl() {
        return configuration.getProperty("rssUrl");
    }

    public static String getBankAccounts() {
        return getDownloadsFolder() + configuration.getProperty("bankAccounts");
    }

    public static String getBranding() {
        return getDownloadsFolder() + configuration.getProperty("branding");
    }

    public static String getAeonSSL() {return configuration.getProperty("aeonSSL");}

    public static String getAeonSSLPort() {return configuration.getProperty("aeonSSLPort");}

    public static String getNonAeonSSL() {return configuration.getProperty("nonAeonSSL");}

    public static String getNonAeonSSLPort() {return configuration.getProperty("nonAeonSSLPort");}
    
    public static String getBusCarrierData() {
        return getDownloadsFolder() + configuration.getProperty("busCarrierData");
    }

    public static String getFonts() {
        return getDownloadsFolder() + configuration.getProperty("fonts");
    }

    public static String getImages() {
        return getDownloadsFolder() + configuration.getProperty("images");
    }

    public static String getLogos() {
        return getDownloadsFolder() + configuration.getProperty("logos");
    }

    public static String getProviderStyle() {
        return getDownloadsFolder() + configuration.getProperty("providerStyle");
    }

    public static String getTicketProPrintTest() {
        return getDownloadsFolder() + configuration.getProperty("ticketProPrintTest");
    }

    public static String getPrintcodesDownloadPath() {
        return getDownloadsFolder() + configuration.getProperty("printcodesFile");
    }

    public static String getPrintcodesFile() {
        return configuration.getProperty("printcodesFile");
    }

    //Media Directory on local device
    public static String getBasePath() {
        return mediaConfig.getProperty("basePath");
    }

    public static String getStore() {

        return mediaConfig.getProperty("store");
    }

    public static String getBarcodes() {
        return getBasePath() + mediaConfig.getProperty("barcodes");
    }

    public static String getImagesTemp() {
        return getBasePath() + mediaConfig.getProperty("imagesTemp");
    }

    public static String getTicketPrint() {
        return getBasePath() + mediaConfig.getProperty("ticketsPrint");
    }

    public static String getMediaFonts() {
        return getBasePath() + mediaConfig.getProperty("fonts");
    }

    public static String getMediaFontsZip() {
        return configuration.getProperty("fonts");
    }

    public static String getMediaImages() {
        return getBasePath() + mediaConfig.getProperty("images");
    }

    public static String getMediaImagesZip() {
        return configuration.getProperty("images");
    }

    public static String getMediaLogos() {
        return getBasePath() + mediaConfig.getProperty("logos");
    }

    public static String getMediaLogosZip() {
        return configuration.getProperty("logos");
    }

    public static String getMediaBranding() {
        return getBasePath() + mediaConfig.getProperty("branding");
    }

    public static String getMediaBrandingZip() {
        return configuration.getProperty("branding");
    }

    public static String getMediaBrandingGroups() {
        return getBasePath() + mediaConfig.getProperty("brandingGroups");
    }

    public static String getMediaBankingFile() {
        return getBasePath() + mediaConfig.getProperty("bankingFile");
    }

    public static String getMediaProviderStyle() {
        return getBasePath() + mediaConfig.getProperty("providerStyle");
    }
    
    public static String getMediaBusCarrierData() {
        return getBasePath() + mediaConfig.getProperty("busCarrierData");
    }

    public static String getInfoHelpDeskTelNum() {
        return infoConfig.getProperty("helpDeskTelNum");
    }

    public static String getInfoHelpDeskEmail() {
        return infoConfig.getProperty("helpDeskEmail");
    }

    public static String getInfoTicketProCustomerServicesTelNum() {
        return infoConfig.getProperty("ticketProCustomerServicesTelNum");
    }

    public static String getInfoTicketProCustomerServicesEmail() {
        return infoConfig.getProperty("ticketProCustomerServicesEmail");
    }

    public static String getDefaultBranding() {
        return brandingConfig.getProperty("defaultBranding", "BLD");
    }
}
