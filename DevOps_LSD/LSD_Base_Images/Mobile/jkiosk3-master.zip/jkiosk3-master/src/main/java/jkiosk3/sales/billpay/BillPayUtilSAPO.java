package jkiosk3.sales.billpay;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.sapo.SapoPayConfReq;
import aeonbillpayments.sapo.SapoPayConfResp;
import aeonbillpayments.sapo.SapoPayReq;
import aeonbillpayments.sapo.SapoPayResp;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.concurrent.Worker.State;
import jkiosk3.JKiosk3;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.utilities.TaskUtil;

/**
 *
 * @author Val
 */
public class BillPayUtilSAPO {

    private final static Logger logger = Logger.getLogger(BillPayUtilSAPO.class.getName());
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private static BillPaymentConnection bpc = null;

    private static SapoPayConfResp getSapoAccPaymentConfirm(BillPaymentConnection conn, SapoPayConfReq r) throws RuntimeException {
        SapoPayConfResp resp = new SapoPayConfResp();

        try {
            resp = conn.getSapoAccountPaymentConfirmation(r);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Payment Confirm Error", t);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return resp;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getSapoAccPaymentResponse(final SapoPayReq r, final SapoBillPaymentResponse resp) {
        JKiosk3.getBusy().showBusy("Confirming Account Details");

        final Task<BillPaymentConnection> taskConnect = new Task() {
            @Override
            protected BillPaymentConnection call() throws Exception {
                bpc = BillPayUtilConnect.getBpc();
                return bpc;
            }
        };

        final Task<SapoPayResp> taskAccResp = new Task() {
            @Override
            protected SapoPayResp call() throws Exception {
                SapoPayResp res = null;
                if (BillPayUtilConnect.isLoggedIn(BillPaymentConnection.BILLPAY_SAPO_ACCOUNT)) {
                    res = bpc.getSapoAccountPayment(r);
                }
                return res;
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                resp.sapoBillPayResp(taskConnect.getValue(), (SapoPayResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Account Details", State.CANCELLED, errorMsg, new BillPaymentMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Account Details", State.FAILED, errorMsg, new BillPaymentMenu());
            }
        };

        taskConnect.stateProperty().addListener(new ChangeListener<State>() {
            @Override
            public void changed(ObservableValue<? extends State> observable, State oldValue, State newState) {
                if (newState == State.SUCCEEDED) {
                    if (taskConnect.getValue() != null) {
                        new Thread(taskAccResp).start();
                        JKiosk3.getBusy().startCountdown(taskAccResp, BillPayUtilConnect.COUNTDOWN_TIME);
                    } else {
                        errorMsg = "Unable to establish connection";
                        taskutil.taskConnectNull(errorMsg, new BillPaymentMenu());
                    }
                } else if (newState == State.CANCELLED || newState == State.FAILED) {
                    taskutil.taskConnectCancelFail(newState, errorMsg, new BillPaymentMenu());
                }
            }
        });

        new Thread(taskConnect).start();
    }

    public static void getSAPOPaymentConfirm(final BillPaymentConnection conn, final SapoPayConfReq r,
            final SapoBillPaymentConfirm conf) {

        JKiosk3.getBusy().showBusy("Confirming Payment");

        final Task<SapoPayConfResp> taskAccConf = new Task() {
            @Override
            protected SapoPayConfResp call() throws Exception {
                return getSapoAccPaymentConfirm(conn, r);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                conf.sapoBillPayConf((SapoPayConfResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.FAILED, errorMsg);
            }
        };

        new Thread(taskAccConf).start();
        JKiosk3.getBusy().startCountdown(taskAccConf, BillPayUtilConnect.COUNTDOWN_TIME);
    }

    public abstract static class SapoBillPaymentResponse {

        public abstract void sapoBillPayResp(BillPaymentConnection connect, SapoPayResp resp);
    }

    public abstract static class SapoBillPaymentConfirm {

        public abstract void sapoBillPayConf(SapoPayConfResp conf);
    }
}
