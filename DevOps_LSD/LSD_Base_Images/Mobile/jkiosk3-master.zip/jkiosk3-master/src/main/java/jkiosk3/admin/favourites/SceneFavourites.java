package jkiosk3.admin.favourites;

import aeonfavourites.FavouriteItem;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import jkiosk3.SceneMenu;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.admin.favourites.fav_cache.JKFavouriteSetup;
import jkiosk3.sales.SaleType;
import jkiosk3.sales._favourites.FavouriteUtil;
import jkiosk3.sales._favourites.FavouriteUtilLists;
import jkiosk3.users.CurrentUser;

import java.util.ArrayList;
import java.util.List;

public class SceneFavourites extends Region {

    public final static String SELECT_PREFS = "Favourites Preferences";
    public final static String SELECT_CLEAR_ALL = "Clear All";
    //
    public final static String SELECT_VOUCHERS = "Select Vouchers";
    public final static String SELECT_CHAT_4_CHANGE = "Select Chat 4 Change";
    public final static String SELECT_TOPUP = "Select Bundles";
    public final static String SELECT_ELECTRICITY = "Select Electricity";
    public final static String SELECT_BILL_PAYMENTS = "Select Bill Payments";

    public final static String TRX_GROUP_VOUCHER = "Vouchers";
    public final static String TRX_GROUP_ELECTRICITY = "Electricity";
    public final static String TRX_GROUP_BILL_PAYMENTS = "Payments";

    private static VBox vboxMenu;
    private static List<Button> btnListFavMenu;
    private ListView listViewFavs;
    private Label lblListHead;
    private final static double infoHt = 455;
    private static VBox vbFavouritesContent;

    public SceneFavourites() {

        StackPane stackPane = JKLayout.getSceneStack(getFavouritesLayout(), this);

        getChildren().add(stackPane);

        loadFavouriteListView();
    }

    private AnchorPane getFavouritesLayout() {
        VBox menu = getFavouriteMenu();
        vbFavouritesContent = JKLayout.getVBox(0, JKLayout.spNum);
        ListView listViewFavs = getFavouriteListView();
        VBox vbList = JKLayout.getSceneInfoBox(infoHt, listViewFavs);
        vbList.setStyle("-fx-padding: 5px 0px 2px 0px;");
        VBox grpClose = JKLayout.getMainMenuBtn(new SceneMenu());

        lblListHead = JKText.getLblDk("Default or custom", JKText.FONT_B_15);
        lblListHead.setTranslateY(3);
        vbList.getChildren().add(0, lblListHead);

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(vbList, getListViewRefresh(), grpClose);

        AnchorPane ap = JKLayout.getSceneAnchor(menu, vbFavouritesContent, vb);

        ap.getChildren().addAll(menu, vbFavouritesContent, vb);

        return ap;
    }

    private VBox getListViewRefresh() {

        Button btnRefresh = JKNode.getBtnMsgBox("Refresh List");
        btnRefresh.setFont(JKText.FONT_B_15);
        btnRefresh.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                loadFavouriteListView();
            }
        });
        VBox vBox = JKLayout.getVBoxContent(JKLayout.sp);
        vBox.setAlignment(Pos.CENTER_LEFT);
        vBox.getChildren().addAll(btnRefresh);
        return vBox;
    }

    private void loadFavouriteListView() {
        listViewFavs.getItems().clear();
        FavouriteUtil.getListFavouriteProducts(false, new FavouriteUtil.FavouriteProductsResult() {
            @Override
            public void favouriteProductsResult(List<FavouriteItem> favListResp) {
                if (favListResp != null && !favListResp.isEmpty()) {

                    FavouriteUtilLists favUtilList = new FavouriteUtilLists();

                    List<String> listDisplay = favUtilList.getListFavouriteDisplayByName(favListResp);
                    if (listDisplay.size() > 14) {
                        listDisplay = listDisplay.subList(0, 14);
                    }

                    ObservableList<String> favs = FXCollections.observableArrayList(listDisplay);

                    String favShow = JKFavouriteSetup.getFavouriteSetupStore().toString();
                    lblListHead.setText(favShow + " List");
                    listViewFavs.setItems(favs);
                }
            }
        });
    }

    private VBox getFavouriteMenu() {

        String[] btnLabels1 = {SELECT_PREFS};
        List<Button> btnList1 = new ArrayList<>();
        for (String s : btnLabels1) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setStyle("-fx-padding: 0px 5px 0px 5px;");
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    getMenuSelection(btn);
                }
            });
            btnList1.add(btn);
        }
        VBox vb1 = getSceneMenuBtnGroup(btnList1, btnList1.size());

        List<String> listFavItems = new ArrayList<>();
        // Add all possible Trans Types
        listFavItems.add(SELECT_VOUCHERS);
        listFavItems.add(SELECT_ELECTRICITY);
        listFavItems.add(SELECT_BILL_PAYMENTS);
        btnListFavMenu = new ArrayList<>();
        for (String s : listFavItems) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setStyle("-fx-padding: 0px 5px 0px 5px;");
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    getMenuSelection(btn);
                }
            });
            btnListFavMenu.add(btn);
        }
        vboxMenu = getSceneMenuBtnGroup(btnListFavMenu, btnListFavMenu.size());
        if (JKFavouriteSetup.getFavouriteSetupStore().isUseDefaultFavourites()) {
            vboxMenu.setDisable(true);
        }

        VBox vBox = JKLayout.getVBox(0, JKLayout.sp);
        vBox.getChildren().addAll(vb1, vboxMenu);

        return vBox;
    }

    public static VBox getSceneMenuBtnGroup(List<Button> listMenuBtns, int btnCount) {
        double menuHt = ((btnCount * JKLayout.btnSmH) + ((btnCount + 1) * JKLayout.sp));
        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.setMaxSize(JKLayout.sideW, menuHt);
        vb.setMinSize(JKLayout.sideW, menuHt);
        vb.getStyleClass().clear();
        vb.getStyleClass().add("vbContent");
        vb.setAlignment(Pos.TOP_CENTER);

        vb.getChildren().addAll(listMenuBtns);
        return vb;
    }

    private ListView getFavouriteListView() {
        listViewFavs = new ListView();
        listViewFavs.setMinHeight(infoHt - 30);
        listViewFavs.getStyleClass().add("small-table");
        listViewFavs.setTranslateY(-7);

        return listViewFavs;
    }

    private void getMenuSelection(Button btn) {
        switch (btn.getText()) {
            case SELECT_PREFS:
                clearAndChangeContent(new FavouritesPrefs());
                break;
            case SELECT_CLEAR_ALL:
                clearAndChangeContent(null);
                lblListHead.setText("Default or custom");
                listViewFavs.getItems().clear();
                break;
            case SELECT_VOUCHERS:
                clearAndChangeContent(new FavouritesVouchers());
                break;
            case SELECT_CHAT_4_CHANGE:
                clearAndChangeContent(new FavouritesChat4Change());
                break;
            case SELECT_TOPUP:
                clearAndChangeContent(new FavouritesTopup());
                break;
            case SELECT_ELECTRICITY:
                clearAndChangeContent(new FavouritesElectricity());
                break;
            case SELECT_BILL_PAYMENTS:
                clearAndChangeContent(new FavouritesBillPayments());
                break;

            default:
                break;
        }
    }

    public static void clearAndChangeContent(Region newRegion) {
        vbFavouritesContent.getChildren().clear();
        if (newRegion != null) {
            vbFavouritesContent.getChildren().add(newRegion);
        }
    }

    public static void checkMenuButtonsDisable(String src, boolean isBtnsDisable) {
        boolean showVouchers = JKFavouriteSetup.getFavouriteSetupStore().isShowVouchers();
        boolean showElectricity = JKFavouriteSetup.getFavouriteSetupStore().isShowElectricity();
        boolean showBillPayments = JKFavouriteSetup.getFavouriteSetupStore().isShowBillPayments();
        for (Button b : btnListFavMenu) {
            switch (b.getText()) {
                case SceneFavourites.SELECT_VOUCHERS:
                    if (isBtnsDisable) {
                        if (src.equalsIgnoreCase(b.getText())) {
                            b.setDisable(false);
                        } else {
                            b.setDisable(isBtnsDisable);
                        }
                    } else {
                        b.setDisable(!showVouchers);
                    }
                    break;
                case SceneFavourites.SELECT_ELECTRICITY:
                    if (isBtnsDisable) {
                        if (src.equalsIgnoreCase(b.getText())) {
                            b.setDisable(false);
                        } else {
                            b.setDisable(isBtnsDisable);
                        }
                    } else {
                        b.setDisable(!showElectricity);
                    }
                    break;
                case SceneFavourites.SELECT_BILL_PAYMENTS:
                    if (isBtnsDisable) {
                        if (src.equalsIgnoreCase(b.getText())) {
                            b.setDisable(false);
                        } else {
                            b.setDisable(isBtnsDisable);
                        }
                    } else {
                        b.setDisable(!showBillPayments);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    public static VBox getVboxMenu() {
        return vboxMenu;
    }

    public static List<Button> getBtnListFavMenu() {
        return btnListFavMenu;
    }
}
