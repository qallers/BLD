package jkiosk3.callme;

import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SloganPane {

    public GridPane sloganGrid() {
        GridPane grid = new GridPane();

        grid.setHgap(JKLayout.sp);
        grid.setVgap(JKLayout.sp);
        grid.setAlignment(Pos.CENTER);
        double gridW = 580;
        grid.setMaxWidth(gridW);
        grid.setMinWidth(gridW);

        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPrefWidth(gridW * 0.5);
        col1.setFillWidth(true);
        col1.setHalignment(HPos.CENTER);

        grid.getColumnConstraints().addAll( col1);

        Label lblAgentName = JKText.getLblDk("\n Helping you to Get more, Do more! \n\n\n", JKText.FONT_B_15);
        lblAgentName.setTextAlignment(TextAlignment.CENTER);

        grid.add(lblAgentName, 0, 0);

        return grid;
    }
}
