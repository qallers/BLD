package jkiosk3.sales;

import aeonbustickets.BusConnection;

import java.util.ArrayList;
import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.coaches.CoachMenu;
import jkiosk3.sales.coaches.CoachTicketSale;
import jkiosk3.sales.ticketpro.TicketProMenu;
import jkiosk3.store.JKCancelTicket;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.SalesUserLoginResult;

public class TicketingMenu extends Region {

    public TicketingMenu() {
        getChildren().add(getTicketingProviders());
    }

    private VBox getTicketingProviders() {

        VBox vbHead = JKNode.getPageHeadVB("Ticketing Providers");

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getMenuButtons());

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private List<Button> getMenuButtons() {
        List<Button> btnList = new ArrayList<>();
        List<SaleType> listSaleTypes = new ArrayList<>();
        List<String> listTransTypes = CurrentUser.getUser().getTransTypes();
        if (listTransTypes.contains("Carma")
                && (listTransTypes.contains("CityToCity") || listTransTypes.contains("Eldo")
                || listTransTypes.contains("Intercape") || listTransTypes.contains("Translux"))) {
//            listSaleTypes.add(SaleType.BUSTICKETS);
            listSaleTypes.add(SaleType.COACHTICKETS);
        }
        if (listTransTypes.contains("TKP_TICKET")) {
            listSaleTypes.add(SaleType.TICKETPRO);
        }

        for (SaleType s : listSaleTypes) {
            final Button btn = JKNode.getBtnSmDbl("");
            btn.setId(s.name());
            switch (s) {
                case TICKETPRO:
                    ImageView imgTP = JKNode.getJKImageViewProvider(SaleType.TICKETPRO.getDisplay() + ".png");
                    btn.setGraphic(imgTP);
                    btn.getStyleClass().add("prov_TicketPros_fix");
                    break;
                default:
                    btn.setText(s.getDisplay());
                    btn.getStyleClass().add("prov_VAS_fix");
                    break;
            }
            btn.setStyle(JKNode.getBrandButton());
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

//        Button btnTest = JKNode.getBtnSmDbl("");
//        ImageView imgTest = JKNode.getJKImageViewProvider("SmartTap.png");
//        btnTest.setGraphic(imgTest);
//        btnTest.getStyleClass().add("prov_VAS_fix");
//        btnTest.setOnMouseReleased(new EventHandler<Event>() {
//            @Override
//            public void handle(Event e) {
////                JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
////                    @Override
////                    public void onDone() {
////                        MerchantCopy.resetMerchantCopy();
////                        MerchantCopy.getInstance().setTransType(SaleType.COACHTICKETS.name());
//                        SceneSales.clearAndChangeContent(new SmartTapMenu());
////                    }
////                });
//            }
//        });
//        btnList.add(btnTest);

        return btnList;
    }

    private void getMenuAction(Button b) {
        MerchantCopy.resetMerchantCopy();
        MerchantCopy.getInstance().setTransType(b.getId());

        switch (SaleType.valueOf(b.getId())) {
            case BUSTICKETS:
                BusConnection.setCurrentTransType("Carma");
//                SceneSales.clearAndChangeContent(new CarmaCarriers());
                break;
            case COACHTICKETS:
                CoachTicketSale.resetCoachTicketSale();
                JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
                    @Override
                    public void onDone() {
                        JKCancelTicket.removeExpiredCancelTickets();
                        SceneSales.clearAndChangeContent(new CoachMenu());
                    }
                });
                break;
            case TICKETPRO:
                SceneSales.clearAndChangeContent(new TicketProMenu());
                break;
            default:
                SceneSales.clearAndShowFavourites();
        }
    }
}
