package jkiosk3.sales._favourites.nfc;

import aeonusers.User;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3.store.JKSystem;
import za.co.blt.consumer.loyalty.api.service.model.request.ConsumerProfileRequest;
import za.co.blt.consumer.loyalty.api.service.model.response.ConsumerProfile;

public class NFCSubscriberReplaceCard extends Region {

    private User nfcUser;
    private ConsumerProfile consumerProfile;
    private NFCSubscriberInput newCardInput;
    private String cardNumNew;

    public NFCSubscriberReplaceCard(User nfcUser, ConsumerProfile consumerProfile) {
        this.nfcUser = nfcUser;
        this.consumerProfile = consumerProfile;

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(getRegLayout(), getControlButtons());

        getChildren().add(vb);
    }

    private VBox getRegLayout() {

        VBox nfcHead = JKNode.getNFCpgHead("Subscriber Replace Lost Card");

        VBox vBox = JKLayout.getVBoxContent(JKLayout.sp);

        vBox.getChildren().addAll(nfcHead, getInput());

        return vBox;
    }

    private GridPane getInput() {

        Label lblCardNum = JKText.getLblDk("Old Card Number", JKText.FONT_B_20);
        Label lblSubName = JKText.getLblDk("Name", JKText.FONT_B_20);
        Label lblSubSurname = JKText.getLblDk("Surname", JKText.FONT_B_20);
        Label lblSubCellNum = JKText.getLblDk("Cellphone Number", JKText.FONT_B_20);

        Text txtCardNum = JKText.getTxtDk(consumerProfile.getLoyaltyCard(), JKText.FONT_B_24);

        Text txtSubName = JKText.getTxtDk(consumerProfile.getName(), JKText.FONT_B_20);
        Text txtSubSurname = JKText.getTxtDk(consumerProfile.getSurname(), JKText.FONT_B_20);
        Text txtSubCellNum = JKText.getTxtDk(consumerProfile.getMobile(), JKText.FONT_B_20);

        Label lblNewCardReg = JKText.getLblDk("Register New Card", JKText.FONT_B_24);

        newCardInput = new NFCSubscriberInput(false, false);

        GridPane gridPane = JKLayout.getContentGridInner2Col(0.50, 0.50);

        gridPane.addRow(1, lblCardNum, txtCardNum);
        gridPane.addRow(2, lblSubName, txtSubName);
        gridPane.addRow(3, lblSubSurname, txtSubSurname);
        gridPane.addRow(4, lblSubCellNum, txtSubCellNum);
        gridPane.addRow(5, JKNode.createGridSpanSep(2));
        gridPane.addRow(6, lblNewCardReg);
        gridPane.addRow(7, newCardInput);

        return gridPane;
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons();

        ctrlBtns.getBtnAccept().setText("Register New Card");
        ctrlBtns.getBtnAccept().getStyleClass().add("btnNFC");
        ctrlBtns.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                cardNumNew = newCardInput.getCardNumber();
                if (isValidEntry()) {
                    replaceLostCard();
                }
            }
        });
        ctrlBtns.getBtnCancel().getStyleClass().add("btnNFC");
        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                NFCUtil.resetNFCView();
            }
        });

        return ctrlBtns;
    }

    private void replaceLostCard() {
        ConsumerProfileRequest consumerProfileRequest = new ConsumerProfileRequest();
        consumerProfileRequest.setLoyaltyCard(cardNumNew);
        consumerProfileRequest.setName(consumerProfile.getName());
        consumerProfileRequest.setSurname(consumerProfile.getSurname());
        consumerProfileRequest.setMobile(consumerProfile.getMobile());
        consumerProfileRequest.setDeviceId(JKSystem.getSystemConfig().getDeviceId());
        consumerProfileRequest.setDeviceUserId(nfcUser.getUserId());

        NFCUtil.updateConsumerProfile(consumerProfile, consumerProfileRequest, new NFCUtil.ConsumerProfileUpdateResult() {
            @Override
            public void consumerProfileUpdateResult(Boolean consumerProfileUpdated) {
                if (consumerProfileUpdated) {
                    JKiosk3.getMsgBox().showMsgBox("Subscriber Card Replace", "Subscriber card replacement successful", null);
                    NFCUtil.resetNFCView();
                } else {
                    NFCUtil.resetNFCView();
                }
            }
        });
    }

    private boolean isValidEntry() {
        if (cardNumNew.isEmpty() || cardNumNew.equals("")) {
            JKiosk3.getMsgBox().showMsgBox("New Card Number", "Please scan or enter a new card number", null);
            return false;
        }
        return true;
    }
}
