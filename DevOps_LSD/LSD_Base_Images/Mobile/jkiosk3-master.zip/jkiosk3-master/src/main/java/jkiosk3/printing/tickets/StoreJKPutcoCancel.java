package jkiosk3.printing.tickets;

import aeonticketpros.bus.TicketProBusAutoCancelReq;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class StoreJKPutcoCancel implements Serializable {

    private final List<TicketProBusAutoCancelReq> listAutoCancelReq = new ArrayList<>();

    public List<TicketProBusAutoCancelReq> getListAutoCancelReq() {
        return listAutoCancelReq;
    }
}
