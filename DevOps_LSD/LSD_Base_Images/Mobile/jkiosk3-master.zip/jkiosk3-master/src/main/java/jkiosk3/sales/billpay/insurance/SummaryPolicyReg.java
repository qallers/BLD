package jkiosk3.sales.billpay.insurance;

import aeonbillpayments.insurance_policy_reg.InsPolRegisterResp;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;

/**
 *
 * @author Valerie
 */
public class SummaryPolicyReg extends Region {

    private final InsPolRegisterResp result;

    public SummaryPolicyReg(InsPolRegisterResp result) {
        this.result = result;
        getChildren().add(getSummaryGrid());
    }

    private GridPane getSummaryGrid() {
        double wrapW = (MessageBox.getMsgWidth() * 0.65) - (2 * JKLayout.sp);
        Label lblPolNum = JKText.getLblDk("Policy Number", JKText.FONT_B_XXSM);
        Label lblPolType = JKText.getLblDk("Policy Type", JKText.FONT_B_XXSM);
        GridPane.setValignment(lblPolType, VPos.TOP);
        Label lblPolHolder = JKText.getLblDk("Policy Holder", JKText.FONT_B_XXSM);
        GridPane.setValignment(lblPolHolder, VPos.TOP);
        Label lblPolBeneficiary = JKText.getLblDk("Policy Beneficiary", JKText.FONT_B_XXSM);
        GridPane.setValignment(lblPolBeneficiary, VPos.TOP);
        Label lblPolAmount = JKText.getLblDk("Policy Premium Amount", JKText.FONT_B_XXSM);

        Text txtPolNum = JKText.getTxtDk(result.getPolicyNumber(), JKText.FONT_B_XSM);
        Text txtPolType = JKText.getTxtDkWrap(result.getPolicyType(), JKText.FONT_B_XSM, wrapW, TextAlignment.RIGHT);
        Text txtPolHolder = JKText.getTxtDkWrap(PolicyRegistration.getInstance().getMainLifeName() + " "
                + PolicyRegistration.getInstance().getMainLifeSurname(), JKText.FONT_B_XSM, wrapW, TextAlignment.RIGHT);
        Text txtPolBeneficiary = JKText.getTxtDkWrap(PolicyRegistration.getInstance().getBeneficiaryName() + " "
                + PolicyRegistration.getInstance().getBeneficiarySurname(), JKText.FONT_B_XSM, wrapW, TextAlignment.RIGHT);
        Text txtPolAmount = JKText.getTxtDk(JKText.getDeciFormat(result.getAmountDue()), JKText.FONT_B_XSM);

        GridPane grid = JKLayout.getSummaryGrid2Col(0.35, 0.65);
        grid.setTranslateX(-JKLayout.sp);
        grid.addRow(0, lblPolNum, txtPolNum);
        grid.addRow(1, lblPolType, txtPolType);
        grid.addRow(2, lblPolHolder, txtPolHolder);
        grid.addRow(3, lblPolBeneficiary, txtPolBeneficiary);
        grid.addRow(4, lblPolAmount, txtPolAmount);

        return grid;
    }
}
