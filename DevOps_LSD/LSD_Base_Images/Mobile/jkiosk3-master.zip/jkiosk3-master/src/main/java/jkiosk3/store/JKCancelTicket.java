package jkiosk3.store;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Val
 */
public class JKCancelTicket implements Serializable {

	private static final long serialVersionUID = 99138L;
	private static final long EXIRY_LIMIT = 30 * 60 * 1000; //thirty minutes
    private static List<StoreJKCancelTicket> cancelTickets;

    public static void loadCancelList() {
        try {
            if ((cancelTickets == null) || (cancelTickets.isEmpty())) {
                cancelTickets = (ArrayList<StoreJKCancelTicket>) Store.loadObject(JKCancelTicket.class.getSimpleName());
            }
        } catch (Exception e) {
            cancelTickets = null;
        }
        if (cancelTickets == null) {
            cancelTickets = new ArrayList<>();
        }
    }

    public static boolean hasCancelTickets() {
        loadCancelList();
        return cancelTickets.size() > 0;
    }

    public static void saveCancelTicket(StoreJKCancelTicket cancelTicket) {
        loadCancelList();
        cancelTickets.add(cancelTicket);
        Store.saveObject(JKCancelTicket.class.getSimpleName(), cancelTickets);
    }

    public static void removeCancelTicket(StoreJKCancelTicket cancelTicket) {
        loadCancelList();
        cancelTickets.remove(cancelTicket);
        if (cancelTickets.isEmpty()) {
            clearCancelTickets();
        } else {
            Store.saveObject(JKCancelTicket.class.getSimpleName(), cancelTickets);
        }
    }

    public static void clearCancelTickets() {
        if (cancelTickets != null) {
            cancelTickets.clear();
        }
        Store.deleteObject(JKCancelTicket.class.getSimpleName());
    }

    public static StoreJKCancelTicket searchForCancelTicket(String ref) {
        if (hasCancelTickets()) {
            for (StoreJKCancelTicket ticket : cancelTickets) {
                if (ticket.getTransId().equalsIgnoreCase(ref) || ticket.getTransRef().equalsIgnoreCase(ref)) {
                    return ticket;
                }
            }
        }
        return null;
    }

    public static void removeExpiredCancelTickets() {
        List<StoreJKCancelTicket> validCancelTickets = new ArrayList<>();
        if (hasCancelTickets()) {
            long now = System.currentTimeMillis();
            for (StoreJKCancelTicket ticket : cancelTickets) {
                if (now - ticket.getTransactionDate().getTime() < EXIRY_LIMIT) {
                    validCancelTickets.add(ticket);
                }
            }
        }
        if (validCancelTickets.isEmpty()) {
            clearCancelTickets();
        } else {
            cancelTickets.clear();
            cancelTickets.addAll(validCancelTickets);
            Store.saveObject(JKCancelTicket.class.getSimpleName(), cancelTickets);
        }
    }

    public static List<StoreJKCancelTicket> getCancelTickets() {
        return cancelTickets;
    }
}
