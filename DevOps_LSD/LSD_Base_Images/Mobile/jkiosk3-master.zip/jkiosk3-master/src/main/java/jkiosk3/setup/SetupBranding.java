package jkiosk3.setup;

import java.util.List;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.branding.MerchantGroup;
import jkiosk3.branding.MerchantGroups;
import jkiosk3.store.JKBranding;

/**
 *
 * @author Valerie
 */
public class SetupBranding extends Region {

    private ObservableList listMerchantGroups;
    private final List<MerchantGroup> merchantGroups;
    private MerchantGroup defaultMerchantGroup;
    private MerchantGroup selectedMerchantGroup;

    public SetupBranding() {
        merchantGroups = MerchantGroups.makeListMerchantGroups();
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getMerchantGroupEntry());
        vb.getChildren().add(getControls());

        getChildren().add(vb);
    }

    private GridPane getMerchantGroupEntry() {

        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75, HPos.LEFT);

        VBox vbHead = JKNode.getPageHeadVB("Branding");

        Label lblMerchantGroup = JKText.getLblDk("Merchant Group", JKText.FONT_B_XXSM);

        listMerchantGroups = FXCollections.observableList(merchantGroups);
        for (Object g : listMerchantGroups) {
            MerchantGroup m = (MerchantGroup) g;
            if (m.getCode().equals("BLD")) {
                defaultMerchantGroup = m;
            }
        }
        ComboBox comMerchantGroup = new ComboBox(listMerchantGroups);
        comMerchantGroup.setPrefWidth((3 * JKLayout.btnSmW) + (2 * JKLayout.sp));
        if (JKBranding.getBranding().getMerchantGroup() != null) {
            selectedMerchantGroup = JKBranding.getBranding().getMerchantGroup();
            comMerchantGroup.getSelectionModel().select(selectedMerchantGroup);
        }
        comMerchantGroup.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

            @Override
            public void changed(ObservableValue ov, Object t, Object t1) {
                selectedMerchantGroup = (MerchantGroup) t1;
            }
        });

        grid.add(vbHead, 0, 0, 2, 1);
        grid.addRow(1, lblMerchantGroup, comMerchantGroup);

        return grid;
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("", false) {
            @Override
            public void onClickTest() {
                //
            }

            @Override
            public void onClickSave() {
                saveSetupBranding();
            }
        };
    }

    private void saveSetupBranding() {
        if (selectedMerchantGroup != null) {
            JKBranding.getBranding().setMerchantGroup(selectedMerchantGroup);
        } else {
            JKBranding.getBranding().setMerchantGroup(defaultMerchantGroup);
        }
        if (JKBranding.saveBranding()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Merchant Group saved successfully", null);
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Merchant Group not saved", null);
        }
    }
}
