package jkiosk3;

import jkiosk3.printing.cashdrawer.CashDrawerWinHandler;
import jkiosk3.store.JKDialup;
import jkiosk3.utilities.DialupConnection;

/**
 *
 * @author Val
 */
public class JKioskStartup {

    public static void start() {
//        startPrintService();
        startAutoConnection();
        initialiseCashDrawer();
    }

//    private static void startPrintService() {
//        if (!(PrintService.isRunning())) {
//            PrintService.startService();
//        }
//    }
    private static void startAutoConnection() {
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
    }
    
    private static void initialiseCashDrawer() {
        System.out.println("in JKioskStartup, about to initialise cash drawer...");
        CashDrawerWinHandler.getInstance();
    }
}
