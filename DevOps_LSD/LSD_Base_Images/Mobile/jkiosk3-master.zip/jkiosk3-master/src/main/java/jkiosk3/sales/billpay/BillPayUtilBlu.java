package jkiosk3.sales.billpay;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.blubillpay.BluAccPayConfReq;
import aeonbillpayments.blubillpay.BluAccPayConfResp;
import aeonbillpayments.blubillpay.BluAccSubscriberInfoReq;
import aeonbillpayments.blubillpay.BluAccSubscriberInfoResp;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.concurrent.Worker.State;
import jkiosk3.JKiosk3;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.utilities.TaskUtil;

/**
 *
 * @author Valerie
 */
public class BillPayUtilBlu {

    private final static Logger logger = Logger.getLogger(BillPayUtilBlu.class.getName());
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private static BillPaymentConnection bpc = null;

    private static BluAccPayConfResp getBluBillPaymentConfirm(BillPaymentConnection conn, BluAccPayConfReq r) throws RuntimeException {
        BluAccPayConfResp resp = new BluAccPayConfResp();
        try {
            resp = conn.getBluAccountPaymentConfirmation(r);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Bill Payment Error", t);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return resp;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getBluAccSubInfoResp(final BluAccSubscriberInfoReq r, final BluAccSubscriberInfoResponse resp) {

        JKiosk3.getBusy().showBusy("Getting Subscriber Info");

        final Task<BillPaymentConnection> taskConnect = new Task() {
            @Override
            protected BillPaymentConnection call() throws Exception {
                bpc = BillPayUtilConnect.getBpc();
                return bpc;
            }
        };

        final Task<BluAccSubscriberInfoResp> taskInfoResp = new Task<BluAccSubscriberInfoResp>() {
            @Override
            protected BluAccSubscriberInfoResp call() throws Exception {
                BluAccSubscriberInfoResp res = null;
                if (BillPayUtilConnect.isLoggedIn(BillPaymentConnection.BILLPAY_BLU_ACCOUNT)) {
                    res = bpc.getBluSubscriberInfo(r);
                }
                return res;
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                resp.bluAccSubscriberInfoResp(taskConnect.getValue(), getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Account Details", State.CANCELLED, errorMsg, new BillPaymentMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Details", State.FAILED, errorMsg, new BillPaymentMenu());
            }
        };

        taskConnect.stateProperty().addListener(new ChangeListener<State>() {
            @Override
            public void changed(ObservableValue<? extends State> observable, State oldValue, State newState) {
                if (newState == State.SUCCEEDED) {
                    if (taskConnect.getValue() != null) {
                        new Thread(taskInfoResp).start();
                        JKiosk3.getBusy().startCountdown(taskInfoResp, BillPayUtilConnect.COUNTDOWN_TIME);
                    } else {
                        errorMsg = "Unable to establish connection";
                        taskutil.taskConnectNull(errorMsg, new BillPaymentMenu());
                    }
                } else if (newState == State.CANCELLED || newState == State.FAILED) {
                    taskutil.taskConnectCancelFail(newState, errorMsg, new BillPaymentMenu());
                }
            }
        });

        new Thread(taskConnect).start();
    }

    public static void getBluBillPaymentConfirm(final BillPaymentConnection conn, final BluAccPayConfReq r, final BluBillPaymentConfirm resp) {
        JKiosk3.getBusy().showBusy("Confirming Payment");

        final Task<BluAccPayConfResp> taskPayConfirm = new Task() {
            @Override
            protected BluAccPayConfResp call() throws Exception {
                return getBluBillPaymentConfirm(conn, r);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                resp.bluBillPayConf((BluAccPayConfResp) getValue());
                if (conn != null) {
                    conn.disconnect();
                }
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.CANCELLED, errorMsg);
                if (conn != null) {
                    conn.disconnect();
                }
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.FAILED, errorMsg);
                if (conn != null) {
                    conn.disconnect();
                }
            }
        };

        new Thread(taskPayConfirm).start();
        JKiosk3.getBusy().startCountdown(taskPayConfirm, BillPayUtilConnect.COUNTDOWN_TIME);
    }

    public abstract static class BluAccSubscriberInfoResponse {

        public abstract void bluAccSubscriberInfoResp(BillPaymentConnection connect, BluAccSubscriberInfoResp resp);
    }

    public abstract static class BluBillPaymentConfirm {

        public abstract void bluBillPayConf(BluAccPayConfResp bpConfResp);
    }
}
