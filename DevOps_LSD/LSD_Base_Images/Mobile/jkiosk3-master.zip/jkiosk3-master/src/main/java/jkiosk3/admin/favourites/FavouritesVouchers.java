package jkiosk3.admin.favourites;

import aeonairtime.AirtimeManufacturer;
import aeonairtime.AirtimeProduct;
import aeonfavourites.FavouriteItem;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.admin.favourites.fav_cache.CacheFavouriteCustomStore;
import jkiosk3.admin.favourites.fav_cache.JKFavouriteSetup;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.vouchers.VoucherUtil;

import java.util.ArrayList;
import java.util.List;

public class FavouritesVouchers extends Region {

    private List<FavouriteItem> listFavouriteCache;
    private List<FavouriteItem> listFavouriteUpdate;
    private List<FavouriteItem> listFavouriteTemp;
    private List<AirtimeManufacturer> listView;
    private List<AirtimeProduct> listProducts;
    private List<Node> listChkNodes;
    private Label lblListSize;
    private SaleType saleTypeSelected;
    private final SimpleStringProperty strManuf = new SimpleStringProperty();
    private AirtimeManufacturer selectedManuf;
    private StackPane stackPane;
    private final double innerWidth = (JKLayout.contentW - (2 * JKLayout.sp));
    //    private final static double PG_HT = 430;
    private final static double PG_HT = 440;
    private final static int PG_SIZE = 8;
    private int maxCount;
//    private int startCount;

    public FavouritesVouchers() {
        this.listFavouriteCache = CacheFavouriteCustomStore.getListFavouriteItems();
        this.listFavouriteUpdate = new ArrayList<>();
        this.listFavouriteTemp = new ArrayList<>();
        this.maxCount = JKFavouriteSetup.getFavouriteSetupStore().getCountVouchers();

        for (FavouriteItem f : listFavouriteCache) {
            if (f.getTrxType().equalsIgnoreCase("Voucher")) {
                listFavouriteTemp.add(f);
            } else {
                listFavouriteUpdate.add(f);
            }
        }

        this.stackPane = JKLayout.getStackFavouriteSelect(PG_HT);

//        if (listFavouriteTemp.size() > maxCount) {
//            listFavouriteTemp = listFavouriteTemp.subList(0, maxCount);
//        }
//        this.startCount = listFavouriteTemp.size();

        SceneFavourites.checkMenuButtonsDisable(SceneFavourites.SELECT_VOUCHERS, true);
        getChildren().addAll(getVoucherSelectLayout());
    }

    private VBox getVoucherSelectLayout() {
        VBox vbContent = JKLayout.getVBoxContent(JKLayout.spNum);

        Label lblHead1 = JKText.getLblDk("Select Voucher Favourites", JKText.FONT_B_24);
        lblListSize = JKText.getLblDk(Integer.toString(listFavouriteTemp.size()), JKText.FONT_B_20);
        if (listFavouriteTemp.size() > maxCount) {
            lblListSize.setStyle("-fx-text-fill: #ff0000;");
        } else {
            lblListSize.setStyle("-fx-text-fill: #0F224E;");
        }
        Label lblHead2 = JKText.getLblDk(" of " + maxCount, JKText.FONT_B_20);
        HBox hbCount = JKLayout.getHBox(0, JKLayout.spNum);
        hbCount.getChildren().addAll(lblListSize, lblHead2);
        VBox vbHeader = JKNode.getPageDblHeadVB(0, lblHead1, hbCount);

        VBox vbHead = JKNode.getPageHeadVB("Select Voucher Favourites");
        vbContent.getChildren().addAll(vbHeader, getSelectVoucherFavs(), getBtnControls());

//        VBox vbPage = JKLayout.getVBox(0, JKLayout.spNum);
//        vbPage.getChildren().addAll(vbContent, getBtnControls());

        return vbContent;
    }

    private ControlButtonsFavList getBtnControls() {
        ControlButtonsFavList ctrl = new ControlButtonsFavList();
        ctrl.getBtnSave().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                saveUpdatedFavourites();
            }
        });
        ctrl.getBtnCancel().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneFavourites.checkMenuButtonsDisable(SceneFavourites.SELECT_VOUCHERS, false);
                SceneFavourites.clearAndChangeContent(null);
            }
        });
        return ctrl;
    }

    private VBox getSelectVoucherFavs() {
        List<SaleType> listSaleType = new ArrayList<>();
        listSaleType.add(SaleType.VOUCHER_AIRTIME);
        listSaleType.add(SaleType.VOUCHER_DATA);
        listSaleType.add(SaleType.VOUCHER_ELEC);
        listSaleType.add(SaleType.VOUCHER_OTHER);

        ObservableList<SaleType> listObserveSaleType = FXCollections.observableArrayList(listSaleType);

        Label lblSaleTypeSelect = JKText.getLblDk("Select Voucher Category", JKText.FONT_B_XSM);
        lblSaleTypeSelect.setMinWidth(JKLayout.btnSmW);

        Label lblProvSelect = JKText.getLblDk("Select Provider", JKText.FONT_B_XSM);
        lblProvSelect.setMinWidth(JKLayout.btnSmW);

        ComboBox comSaleTypeSelect = new ComboBox(listObserveSaleType);
        comSaleTypeSelect.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.5), 35);

        final ComboBox comProvSelect = new ComboBox();
        comProvSelect.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.5), 35);

        HBox hbSaleType = JKLayout.getHBox(0, 0);
        hbSaleType.setMaxWidth(innerWidth);
        hbSaleType.setMinWidth(innerWidth);
        hbSaleType.getChildren().addAll(lblSaleTypeSelect, JKNode.getHSpacer(), comSaleTypeSelect);

        HBox hb = JKLayout.getHBox(0, 0);
        hb.setMaxWidth(innerWidth);
        hb.setMinWidth(innerWidth);
        hb.getChildren().addAll(lblProvSelect, JKNode.getHSpacer(), comProvSelect);

        comSaleTypeSelect.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                if (newValue != null) {
                    saleTypeSelected = (SaleType) newValue;

                    stackPane.getChildren().clear();
                    comProvSelect.getItems().clear();

                    VoucherUtil.getVoucherProvidersList(new VoucherUtil.AirtimeManufacturerResult() {

                        @Override
                        public void airtimeManufacturerResult(List<AirtimeManufacturer> manufacturerList) {
                            if (!manufacturerList.isEmpty()) {
                                listView = VoucherUtil.getProvidersShow(saleTypeSelected);
                                ObservableList<AirtimeManufacturer> listProvidersShow = FXCollections.observableArrayList(listView);
                                for (AirtimeManufacturer am : listView) {
                                    comProvSelect.getItems().add(am.getName());
                                }
                            }
                        }
                    });
                }
            }
        });

        strManuf.bind(comProvSelect.getSelectionModel().selectedItemProperty());
        strManuf.addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                listProducts = new ArrayList<>();

                comProvSelect.getSelectionModel().select(newValue);
                for (AirtimeManufacturer am : listView) {
                    if (am.getName().equalsIgnoreCase(newValue)) {
                        selectedManuf = am;

                        stackPane.getChildren().clear();

                        listProducts.addAll(VoucherUtil.getProviderProducts(saleTypeSelected.name(), selectedManuf.getId()));

                        getProductCheckBoxes();
                        break;
                    }
                }
            }
        });

        VBox vbContent = JKLayout.getVBoxLeft(0, JKLayout.spNum);
        vbContent.getChildren().addAll(hbSaleType, JKNode.createContentSep(), hb, JKNode.createContentSep(), stackPane);

        return vbContent;
    }

    private void getProductCheckBoxes() {
        listChkNodes = getProductSelectionList();

        createPagedItems();
    }

    private List<Node> getProductSelectionList() {
        List<Node> listChks = new ArrayList<>();
        for (final AirtimeProduct ap : listProducts) {
            final CheckBox chk = new CheckBox(ap.getName());
            for (FavouriteItem i : listFavouriteCache) {
                if (i.getTrxType().equals("Voucher")
                        && i.getProductId().equals(Integer.toString(ap.getProductID()))) {
                    chk.setSelected(true);
                    break;
                }
            }
            chk.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    if (chk.isSelected()) {
                        addProduct(chk, ap);
                    } else if (!chk.isSelected()) {
                        removeProduct(ap);
                    }
                }
            });
            listChks.add(chk);
        }
        return listChks;
    }

    private void createPagedItems() {
        int numPgs = 0;
        if (listChkNodes.isEmpty()) {
            numPgs = 1;
        } else if (listChkNodes.size() % PG_SIZE == 0) {
            numPgs = listChkNodes.size() / PG_SIZE;
        } else {
            numPgs = (listChkNodes.size() / PG_SIZE) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedVBox(pg, listChkNodes, PG_SIZE, PG_HT);
            }
        });

        stackPane.getChildren().add(pages);
    }

    private void addProduct(CheckBox checkBox, AirtimeProduct airtimeProduct) {
        if (!isProductInList(airtimeProduct)) {
            FavouriteItem favouriteItem = new FavouriteItem();
            favouriteItem.setTrxGroup(SceneFavourites.TRX_GROUP_VOUCHER);
            favouriteItem.setTrxType("Voucher");
            favouriteItem.setProductId(Integer.toString(airtimeProduct.getProductID()));
            if (listFavouriteTemp.size() < maxCount) {
                listFavouriteTemp.add(favouriteItem);
            } else {
                JKiosk3.getMsgBox().showMsgBox("Maximum Count Exceeded",
                        "\nA total of " + maxCount + " Vouchers can be selected."
                                + "\n\nRemove another Voucher and click 'Save' first,"
                                + "\nor change settings in 'Favourites Preferences'", null);
                checkBox.setSelected(false);
            }
            lblListSize.setText(Integer.toString(listFavouriteTemp.size()));
            if (listFavouriteTemp.size() > maxCount) {
                lblListSize.setStyle("-fx-text-fill: #ff0000;");
            } else {
                lblListSize.setStyle("-fx-text-fill: #0F224E;");
            }
        }
    }

    private void removeProduct(AirtimeProduct airtimeProduct) {
        if (isProductInList(airtimeProduct)) {
            for (FavouriteItem f : listFavouriteTemp) {
                if (f.getTrxType().equals("Voucher")
                        && f.getProductId().equals(Integer.toString(airtimeProduct.getProductID()))) {
                    listFavouriteTemp.remove(f);
                    break;
                }
            }
            lblListSize.setText(Integer.toString(listFavouriteTemp.size()));
            if (listFavouriteTemp.size() > maxCount) {
                lblListSize.setStyle("-fx-text-fill: #ff0000;");
            } else {
                lblListSize.setStyle("-fx-text-fill: #0F224E;");
            }
        }
    }

    private boolean isProductInList(AirtimeProduct airtimeProduct) {
        FavouriteItem favItem = null;
        for (FavouriteItem f : listFavouriteTemp) {
            if (f.getTrxType().equals("Voucher")
                    && f.getProductId().equals(Integer.toString(airtimeProduct.getProductID()))) {
                favItem = f;
                break;
            }
        }
        if (favItem != null) {
            return true;
        } else {
            return false;
        }
    }

    private void saveUpdatedFavourites() {
        if (!listFavouriteTemp.isEmpty()) {
            listFavouriteUpdate.addAll(listFavouriteTemp);
            listFavouriteCache = listFavouriteUpdate;
            if (CacheFavouriteCustomStore.saveFavouriteStore(listFavouriteCache)) {
//                SceneFavourites.clearAndChangeContent(new FavouritesVouchers());
                SceneFavourites.checkMenuButtonsDisable(SceneFavourites.SELECT_VOUCHERS, false);
                SceneFavourites.clearAndChangeContent(null);
            }
        } else {
            JKiosk3.getMsgBox().showMsgBox("Custom Favourites", "Please add at least 1 product to the list", null);
        }
    }
}
