package jkiosk3.printing;

import aeonairtime.AirtimeVoucher;
import aeonprinting.AeonPrintJob;
import gnu.io.CommPortIdentifier;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.UnsupportedCommOperationException;

import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import jkiosk3.JKiosk3;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.print_layouts.PrintAssorted;
import jkiosk3.printing.tickets.PrinterStatus;
import jkiosk3.sales.MerchantCopy;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.vouchers.VoucherSale;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.store.JKPrinterTickets;

public class PrintHandler {

    private final static Logger logger = Logger.getLogger(PrintHandler.class.getName());
    private static int itemCount;
    private static int currentPrintJob;
    private static SerialPort serialPort;

    /**
     * Handles the printing of a Report print type.
     *
     * @param reportType the type of Report being printed.
     * @param apj        the AeonPrintJob for the requested report.
     */
    public static void handlePrintRequestReport(String reportType, AeonPrintJob apj) {
        JKiosk3.getPrintPreview().showPrintPreview(reportType, apj, PrintPreview.PRN_OK_CANCEL,
                new PrintPreviewResult() {
                    @Override
                    public void onOk() {
                        //
                    }

                    @Override
                    public void onCancel() {
                        //
                    }
                });
    }

    /**
     * Handles the printing of a Sale item (could be a Voucher, or Ticket,
     * etc.).
     *
     * @param saleType the type of Sale being printed.
     * @param apj      the AeonPrintJob for the Sale item.
     * @param transRef the Transaction Reference that identifies the Sale item.
     */
    public static void handlePrintRequestSale(String saleType, AeonPrintJob apj, String transRef) {
        // This will create a Map with a SINGLE item in it, which we can then handle the same as the Map for multi-vouchers
        List<String> listTransRefs = new ArrayList<>();
        Map<String, AeonPrintJob> mapPrintJobs = new HashMap<>();
        listTransRefs.add(transRef);
        mapPrintJobs.put(transRef, apj);
        handlePrintRequestSaleFromMaps(saleType, listTransRefs, mapPrintJobs,
                JKPrintOptions.getPrintOptions().isPrintImmediately(), false);
    }

    public static void handlePrintRequestSaleMultiVoucher(VoucherSale saleMulti) {
        AeonPrintJob apjm = saleMulti.getResponse().getMerchantPrintLines();
        handleMerchantCopyPrint(apjm);

        List<String> listTransRefs = new ArrayList<>();
        Map<String, AeonPrintJob> mapPrintJobs = new HashMap<>();
        for (AirtimeVoucher v : saleMulti.getResponse().getListVouchers()) {
            String transRef = v.getTransRef();
            AeonPrintJob apj = v.getPrintLines();
            listTransRefs.add(transRef);
            mapPrintJobs.put(transRef, apj);
        }
        handlePrintRequestSaleFromMaps(SaleType.VOUCHERS.getDisplay(), listTransRefs, mapPrintJobs,
                JKPrintOptions.getPrintOptions().isPrintImmediately(), false);
    }

    // Used for Coach and TicketPro tickets, as well as Maps created here.
    public static void handlePrintRequestSaleFromMaps(String saleType, final List<String> listTransRefs, final Map<String, AeonPrintJob> mapApj,
                                                      boolean isForcePrintImmediate, boolean isForceBarcode) {
        itemCount = 0;
        if (isForcePrintImmediate) {
            printItemsFromMultiList(saleType, listTransRefs, mapApj, isForceBarcode);
        } else {
            currentPrintJob = 0;
            addSaleItemsToPrintQueue(listTransRefs, mapApj);
        }
    }

    public static void handlePrintRequestFromQueue(Map<String, AeonPrintJob> printQueue, PrintQueueResult queueResult) {
        List<String> listTransRefs = new ArrayList<>();

        for (Map.Entry<String, AeonPrintJob> entry : printQueue.entrySet()) {
            String transRef = entry.getKey();
            listTransRefs.add(transRef);
        }
        printItemsFromQueue("Print from Queue", listTransRefs, printQueue, queueResult);
    }

    // // //
    // private methods
    // // //

    private static void printItemsFromMultiList(String saleType, final List<String> listTransRefs, final Map<String, AeonPrintJob> mapApj, boolean isForceBarcode) {
        if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
            currentPrintJob = 0;
            printItemsPreviewed(saleType, listTransRefs, mapApj, isForceBarcode);

        } else {
            String currentTransRef = listTransRefs.get(itemCount);
            AeonPrintJob currentApj = null;

            for (Map.Entry<String, AeonPrintJob> entry : mapApj.entrySet()) {
                if (entry.getKey().equalsIgnoreCase(currentTransRef)) {
                    currentApj = entry.getValue();
                    break;
                }
            }

            handlePrintRequestSaleItem(currentApj, currentTransRef, isForceBarcode);
            // Next item in list?
            itemCount++;
            if (itemCount < mapApj.size()) {
                printItemsFromMultiList(saleType, listTransRefs, mapApj, isForceBarcode);
            } else {
                // Once all done, process set printeds...
                PrintUtil.processSetPrintedItems();
            }
        }
    }

    private static void handlePrintRequestSaleItem(AeonPrintJob apj, String transRef) {
        PrintUtil.sendToPrinter(apj, transRef, false, false);
    }

    private static void handlePrintRequestSaleItem(AeonPrintJob apj, String transRef, boolean isForceBarcode) {
        PrintUtil.sendToPrinter(apj, transRef, false, isForceBarcode);
    }

    private static void printItemsPreviewed(final String saleType, final List<String> listTransRefs,
                                            final Map<String, AeonPrintJob> mapApj, final boolean isForceBarcode) {
        String currentTransRef = listTransRefs.get(currentPrintJob);
        AeonPrintJob currentApj = null;

        for (Map.Entry<String, AeonPrintJob> entry : mapApj.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(currentTransRef)) {
                currentApj = entry.getValue();
                break;
            }
        }
        JKiosk3.getPrintPreview().showPrintPreview(saleType + " : " + (currentPrintJob + 1) + " of " + mapApj.size(),
                currentApj, currentTransRef, PrintPreview.PRN_OK, isForceBarcode, new PrintPreviewResult() {
                    @Override
                    public void onOk() {
                        // PrintPreview automatically does "PrintUtil.sendToPrinter(apj, transRef)" on click of "OK" button
                        currentPrintJob++;
                        if (currentPrintJob < mapApj.size()) {
                            printItemsPreviewed(saleType, listTransRefs, mapApj, isForceBarcode);
                        } else {
                            PrintUtil.processSetPrintedItems();
                        }
                    }

                    @Override
                    public void onCancel() {
                    }
                });
    }

    private static void printItemsFromQueue(String saleType, final List<String> listTransRefs, final Map<String, AeonPrintJob> mapApj,
                                            PrintQueueResult result) {
        if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
            currentPrintJob = 0;
            printItemsPreviewedFromQueue(saleType, listTransRefs, mapApj, result);

        } else {
            String currentTransRef = listTransRefs.get(itemCount);
            AeonPrintJob currentApj = null;

            for (Map.Entry<String, AeonPrintJob> entry : mapApj.entrySet()) {
                if (entry.getKey().equalsIgnoreCase(currentTransRef)) {
                    currentApj = entry.getValue();
                    break;
                }
            }

            handlePrintRequestSaleItem(currentApj, currentTransRef);
            // Next item in list?
            itemCount++;
            if (itemCount < mapApj.size()) {
                printItemsFromQueue(saleType, listTransRefs, mapApj, result);
            } else {
                result.onDone(true);
            }
        }
    }

    private static void printItemsPreviewedFromQueue(final String saleType, final List<String> listTransRefs, final Map<String, AeonPrintJob> mapApj, final PrintQueueResult result) {
        String currentTransRef = listTransRefs.get(currentPrintJob);
        AeonPrintJob currentApj = null;

        for (Map.Entry<String, AeonPrintJob> entry : mapApj.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(currentTransRef)) {
                currentApj = entry.getValue();
                break;
            }
        }
        JKiosk3.getPrintPreview().showPrintPreview(saleType + " : " + (currentPrintJob + 1) + " of " + mapApj.size(),
                currentApj, currentTransRef, PrintPreview.PRN_OK, new PrintPreviewResult() {
                    @Override
                    public void onOk() {
                        // PrintPreview automatically does "PrintUtil.sendToPrinter(apj, transRef)" on click of "OK" button
                        currentPrintJob++;
                        if (currentPrintJob < mapApj.size()) {
                            printItemsPreviewedFromQueue(saleType, listTransRefs, mapApj, result);
                        } else {
                            PrintUtil.processSetPrintedItems();
                            PrintQueue.clearQueue();
                            result.onDone(true);
                        }
                    }

                    @Override
                    public void onCancel() {
                    }
                });
    }

    private static void addSaleItemsToPrintQueue(final List<String> listTransRefs, final Map<String, AeonPrintJob> mapApj) {
        String currentTransRef = listTransRefs.get(currentPrintJob);
        AeonPrintJob currentApj = null;

        for (Map.Entry<String, AeonPrintJob> entry : mapApj.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(currentTransRef)) {
                currentApj = entry.getValue();
                break;
            }
        }
        PrintQueue.addItem(currentTransRef, currentApj);

        currentPrintJob++;
        if (currentPrintJob < mapApj.size()) {
            addSaleItemsToPrintQueue(listTransRefs, mapApj);
        }
    }

    /**
     * Handles the printing of a Merchant Copy of a Sale item, when the
     * AeonPrintJob has not yet been constructed.
     *
     * @param merchantCopy the MerchantCopy constructed during the Sale of an
     *                     item.
     */
    public static void handleMerchantCopyPrint(MerchantCopy merchantCopy) {
        if (JKPrintOptions.getPrintOptions().isPrintMerchantCopy()) {
            AeonPrintJob apj = PrintAssorted.getMerchantCopyPrint(merchantCopy);
            PrintUtil.sendToPrinter(apj);
        }
    }

    /**
     * Handles the printing of a Merchant Copy of a Sale item, when the
     * AeonPrintJob has already been constructed or received, for example in a
     * response from the Aeon server.
     *
     * @param apj an AeonPrintJob built from a server response or other source.
     */
    public static void handleMerchantCopyPrint(AeonPrintJob apj) {
        if (JKPrintOptions.getPrintOptions().isPrintMerchantCopy()) {
            PrintUtil.sendToPrinter(apj);
        }
    }

    /**
     * This does NOT print a refund slip. It prints instructions of who to
     * contact (currently TicketPro only) should a Customer want to request a
     * refund.
     *
     * @param header the Header text to display on the Print Preview.
     * @param apj    the AeonPrintJob showing contact details for the Customer's
     *               reference.
     */
    public static void handlePrintRefund(String header, AeonPrintJob apj) {
        if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
            JKiosk3.getPrintPreview().showPrintPreview(header, apj, PrintPreview.PRN_OK, new PrintPreviewResult() {
                @Override
                public void onOk() {
                    //
                }

                @Override
                public void onCancel() {
                    //
                }
            });
        } else {
            PrintUtil.sendToPrinter(apj);
        }
    }

    /**
     * This method simply prints the content of the file to the console. It is
     * only here to help with debugging, to enable the contents of the file to
     * be seen during development.
     *
     * @param fileIn the file to be printed
     */
    private static void sendTicketProToOutput(File fileIn) {

        ByteArrayOutputStream os = null;

        try (FileInputStream is = new FileInputStream(fileIn)) {
            long filesize = fileIn.length();
            System.out.println("when sending file to output - filesize of input file = " + filesize);
            byte[] buffer = new byte[2048];
            os = new ByteArrayOutputStream();
            int read = 0;
            StringBuilder sb = new StringBuilder();
            sb.append("\r\n").append("file name : ").append(fileIn.getName());
            while ((read = is.read(buffer)) != -1) {
                os.write(buffer, 0, read);
            }
            long outputsize = os.toByteArray().length;
            System.out.println("when sending file to output - filesize of output data = " + outputsize);
            sb.append("\r\n").append(os);
            logger.info(sb.toString());

        } catch (IOException ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
    }

    /**
     * Sends the contents of the file to a Serial Printer connected on the
     * Serial Port saved in Setup, after confirming that the port is correct.
     * <br /><br />
     * After printing the contents of the file, printer response is sent back to
     * the printer to enable handling of any potential print errors.
     *
     * @param fileIn the file to be printed.
     */
    public static void writeFileContentToPrinterPort(File fileIn) {
        // just to show output in console, should be removed once all works correctly...
//        sendTicketProToOutput(fileIn);
        String ticketPrinterPort = JKPrinterTickets.getPrinterTickets().getSerialPrinterPort();
        Enumeration portList = CommPortIdentifier.getPortIdentifiers();
        CommPortIdentifier portId = null;
        while (portList.hasMoreElements()) {
            final CommPortIdentifier pid = (CommPortIdentifier) portList.nextElement();
            if (pid.getPortType() == CommPortIdentifier.PORT_SERIAL
                    && pid.getName().equals(ticketPrinterPort)) {
                portId = pid;
                break;
            }
        }
        if (portId != null) {
            try (FileInputStream fileStream = new FileInputStream(fileIn)) {

                // open the serial port
                final SerialPort port = (SerialPort) portId.open("PortListOpen", 10000);
                port.setSerialPortParams(JKPrinterTickets.getPrinterTickets().getSerialPrinterBaud(),
                        SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);

                try (OutputStream printerOutput = port.getOutputStream()) {
                    // initialise a byte buffer into which to read the file contents
                    byte[] buffer = new byte[2048];
                    int read = 0;

                    StringBuilder sb = new StringBuilder();
                    sb.append("\r\n").append("file name : ").append(fileIn.getName());
                    while ((read = fileStream.read(buffer)) != -1) {
                        // write contents of buffer to the printer/serial port
                        printerOutput.write(buffer, 0, read);
                        sb.append("\r\n").append(new String(buffer));
                    }
                    logger.info(sb.toString());
                    logger.info("END OF PRINT");
                } catch (IOException e) {
                    logger.log(Level.SEVERE, e.getMessage(), e);
                } finally {
                    port.close();
                }
            } catch (PortInUseException | UnsupportedCommOperationException | IOException ex) {
                logger.log(Level.SEVERE, ex.getMessage(), ex);
            }
        }
    }

    public static void writeFileContentToPrinterPort(final File fileIn, final ResultCallback resultCallback) {
        if (serialPort != null) {
            serialPort.close();
            serialPort = null;
        }
        serialPort = getSerialPort();
        if (serialPort != null) {
            PrinterStatus printerStatus = new PrinterStatus(serialPort);
            printerStatus.isPrinterReady(new ResultCallback() {
                @Override
                public void onResult(boolean result) {
                    // First check, before sending print to printer
                    if (result) {
                        // Read stream in from file
                        try (FileInputStream fileStream = new FileInputStream(fileIn)) {
                            // Send stream out to printer
                            // If we use try-with-resources for both input and output, the streams will both be closed
                            // without us needing to have try-catch when closing each stream.
                            try (OutputStream printerOutput = serialPort.getOutputStream()) {
//                                OutputStream printerOutput = serialPort.getOutputStream();
                                // initialise a byte buffer into which to read the file contents
                                byte[] buffer = new byte[2048];
                                int read = 0;

                                StringBuilder sb = new StringBuilder();
                                sb.append("\r\n").append("file name : ").append(fileIn.getName());
                                while ((read = fileStream.read(buffer)) != -1) {
                                    // write contents of buffer to the printer/serial port
                                    printerOutput.write(buffer, 0, read);
                                    sb.append("\r\n").append(new String(buffer));
                                }
                                // 2019-04-04  -  Wentzel stated at meeting for NFC Bus and Wallet
                                // that we must do NOTHING but a single check BEFORE sending print job to printer.
                                // After printing, check again for printer status
//                                printerStatus.isPrintCompleteAndReset(new ResultCallback() {
//                                    @Override
//                                    public void onResult(boolean result2) {
//                                        // Second check, after print has been sent
//                                        if (result2) {
//                                            // If still okay, chances are no error happened during print
//                                            resultCallback.onResult(true);
//                                            logger.info(sb.toString());
//                                            logger.info("END OF PRINT");
//                                            if (serialPort != null) {
//                                                serialPort.close();
//                                            }
//                                        }
//                                    }
//                                });
                                resultCallback.onResult(true);
                                logger.info(sb.toString());
                                logger.info("END OF PRINT");
                                if (serialPort != null) {
                                    serialPort.close();
                                }

                            } catch (IOException e) {
                                // catch for OutputStream
                                logger.log(Level.SEVERE, e.getMessage(), e);
                                resultCallback.onResult(false);
                            }
                        } catch (IOException ex) {
                            // catch for FileInputStream
                            logger.log(Level.SEVERE, ex.getMessage(), ex);
                            resultCallback.onResult(false);
                        }
                    } else {
                        resultCallback.onResult(false);
                    }
                }
            });
        }
    }

    private static SerialPort getSerialPort() {
        SerialPort port = null;

        String ticketPrinterPort = JKPrinterTickets.getPrinterTickets().getSerialPrinterPort();

        Enumeration portList = CommPortIdentifier.getPortIdentifiers();
        CommPortIdentifier portId = null;
        while (portList.hasMoreElements()) {
            final CommPortIdentifier pid = (CommPortIdentifier) portList.nextElement();
            logger.info(("CommPortIdentifier name = ").concat(pid.getName())
                    .concat(" :: CommPortIdentifier type = ").concat(Integer.toString(pid.getPortType())));
            // 1 = PORT_SERIAL
            // 2 = PORT_PARALLEL
            // 3 = PORT_I2C
            // 4 = PORT_RS485
            // 5 = PORT_RAW
            if (pid.isCurrentlyOwned()) {
                logger.info(("CommPortIdentifier owner = ").concat(pid.getCurrentOwner()));
            } else {
                // 2019-04-01  -  Even if not owned, no error is encountered, continue.
                logger.info("CommPortIdentifier has no owner");
            }
            if (pid.getPortType() == CommPortIdentifier.PORT_SERIAL
                    && pid.getName().equals(ticketPrinterPort)) {
                portId = pid;
                break;
            }
        }
        if (portId != null) {
            try {
                port = (SerialPort) portId.open("PortListOpen", 10000);
                port.setSerialPortParams(JKPrinterTickets.getPrinterTickets().getSerialPrinterBaud(),
                        SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
                return port;
            } catch (PortInUseException | UnsupportedCommOperationException ex) {
                logger.log(Level.SEVERE, ex.getMessage(), ex);
            }
        }
        return null;
    }
}
