package jkiosk3.users;

import aeonusers.User;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3.store.JKOptions;

/**
 *
 * @author Val
 */
public class UserAdd extends Region {

    private TextField txtName;
    private TextField txtPin;
    private RadioButton radCash;
    private RadioButton radCashPlus;
    private RadioButton radSup;
    private Button btnPermissions;
    private final User newUser;
    private String newUserName;
    private ControlButtons ctrlBtns;
    private boolean validUser;

    public UserAdd() {
        JKUserAddEdit.resetJKUserAddEdit();
        JKUserAddEdit.getInstance().setNewOrEdit(UserUtil.USER_NEW);
        newUser = new User();

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().addAll(getNewUserEntry(), getControlButtons());

        getChildren().add(vb);
    }

    private GridPane getNewUserEntry() {

        double w = JKLayout.contentW;

        VBox vbHead = JKNode.getPageHeadVB("Add User");

        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);

        Label lblName = JKText.getLblDk("User Name", JKText.FONT_B_XSM);
        lblName.setMinWidth(JKLayout.btnSmW);

        Label lblPin = JKText.getLblDk("User PIN", JKText.FONT_B_XSM);

        Label lblLevel = JKText.getLblDk("User Level", JKText.FONT_B_XSM);

        ToggleGroup toggle = new ToggleGroup();

        radCash = new RadioButton("Cashier");
        radCash.setToggleGroup(toggle);
        radCash.setSelected(true);
        radCash.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setButtonsEnableDisable();
            }
        });

        radCashPlus = new RadioButton("Cashier Plus");
        radCashPlus.setToggleGroup(toggle);
        radCashPlus.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setButtonsEnableDisable();
            }
        });

        radSup = new RadioButton("Supervisor");
        radSup.setToggleGroup(toggle);
        radSup.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setButtonsEnableDisable();
            }
        });

        HBox hbUserLvl = JKLayout.getHBox(0, JKLayout.sp);
        hbUserLvl.setMaxWidth(w * 0.75);
        hbUserLvl.getChildren().addAll(radCash, JKNode.getHSpacer(), radCashPlus, JKNode.getHSpacer(), radSup);

        txtName = new TextField();
        txtName.setPromptText("Click, enter User Name");
        txtName.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtName, "Enter User Name", txtName.getText(), false, true);
                }
            }
        });

        txtPin = new TextField();
        txtPin.setPromptText("Click, enter User PIN");
        txtPin.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtPin, "Enter User PIN", txtPin.getText());
                }
            }
        });

        btnPermissions = JKNode.getBtnMsgBox("permissions");
        btnPermissions.setDisable(true);
        btnPermissions.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (isValidEntry()) {
                    setUserDetails();
                }
            }
        });

        HBox hbPermissions = JKLayout.getHBox(0, 0);
        hbPermissions.getChildren().addAll(JKNode.getHSpacer(), btnPermissions, JKNode.getHSpacer());

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblName, txtName);
        grid.addRow(2, lblPin, txtPin);
        grid.addRow(3, lblLevel, hbUserLvl);
        grid.addRow(4, new Label(), hbPermissions);

        return grid;
    }

    private ControlButtons getControlButtons() {
        ctrlBtns = new ControlButtons();

        ctrlBtns.getBtnAccept().setText("Save");
        ctrlBtns.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (isValidEntry()) {
                    setUserDetails();
                }
            }
        });
        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneUsers.getVbUsersContent().getChildren().clear();
            }
        });

        return ctrlBtns;
    }

    private void setButtonsEnableDisable() {
        if (radCashPlus.isSelected()) {
            btnPermissions.setDisable(false);
            ctrlBtns.getBtnAccept().setDisable(true);
        } else if (!radCashPlus.isSelected()) {
            btnPermissions.setDisable(true);
            ctrlBtns.getBtnAccept().setDisable(false);
        }
    }

    private boolean isValidEntry() {
        validUser = true;

        if (txtName.getText().trim() == null || txtName.getText().trim().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("User Name", "Please enter a User Name", null);
            validUser = false;
        } else {
            newUserName = txtName.getText().trim();
        }

        if (newUserName != null) {
            List<User> userList = UserUtil.getOnlineUsersList(CurrentUser.getUser().getUserPin());
            for (User u : userList) {
                if (newUserName.equalsIgnoreCase(u.getUserName())) {
                    validUser = false;
                    JKiosk3.getMsgBox().showMsgBox("User Already Exists", "Please enter a unique user name", null);
                    break;
                } else {
                    validUser = true;
                }
            }
        }
        return validUser;
    }

    private void setUserDetails() {
        int userLevel = 0;
        if (radCash.isSelected()) {
            userLevel = 0;
        } else if (radSup.isSelected()) {
            userLevel = 1;
        } else if (radCashPlus.isSelected()) {
            userLevel = 2;
        }
        newUser.setUserName(newUserName);
        newUser.setUserPin(txtPin.getText().trim());
        newUser.setUserLevel(userLevel);
        JKUserAddEdit.getInstance().setAeonUser(newUser);
        saveOrContinue();
    }

    private void saveOrContinue() {
        if (JKUserAddEdit.getInstance().getAeonUser().getUserLevel() == 2) {
            SceneUsers.clearAndChangeContent(new UserPermissions());
        } else {
            JKUserAddEdit.getInstance().getAeonUser().setUserPermissions(null);
            UserUtil.saveNewUser(JKUserAddEdit.getInstance().getAeonUser());
            resetInputFields();
        }
    }

    private void resetInputFields() {
        txtName.setText("");
        txtPin.setText("");
        radCash.setSelected(true);
    }
}
