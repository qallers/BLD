package jkiosk3.sales.topups.airtime;

import javafx.scene.layout.HBox;
import jkiosk3.sales.topups.TopupProvider;
import jkiosk3.sales.topups.AirtimeUtil;

import java.util.ArrayList;
import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.topups.MenuTopups;
import jkiosk3.sales.topups.TopupSale;
import jkiosk3.users.SalesUserLoginResult;

public class Airtime extends Region {

    private VBox vbPage;

    public Airtime() {
        vbPage = JKLayout.getVBox(0, JKLayout.spNum);
        vbPage.getChildren().add(getAirtimeProviders());
        getChildren().add(vbPage);
    }

    private VBox getAirtimeProviders() {

        Button btnBack = JKNode.getBtnPopup("back");
        btnBack.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new MenuTopups());
            }
        });

        Label lblTopupType = JKText.getLblDk(TopupSale.getInstance().getSaleType().getDisplay(), JKText.FONT_B_SM);

        final HBox hbHead = JKLayout.getHBox(0, JKLayout.sp);
        hbHead.getChildren().addAll(lblTopupType);

        VBox vbHead = JKNode.getPageDblHeadVB(0, btnBack, hbHead);

        List<TopupProvider> btnLabels = AirtimeUtil.getTopupProviderAirtimeList();

        List<Button> btnList = new ArrayList<>();

        for (final TopupProvider p : btnLabels) {
            final String s = p.getName();
            Button btn = JKNode.getBtnSm("");
            ImageView imgView = JKNode.getJKImageViewProvider("prov_" + s.replaceAll(" ", "").replaceAll("\n", "") + ".png");

            btn.setGraphic(imgView);
            btn.getStyleClass().add("prov_" + s.replaceAll(" ", "").replaceAll("\n", "") + "_fix");
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    TopupSale.getInstance().setProvider(p);

                    Button btnProvider = getHeaderBtn(s);

                    if (hbHead.getChildren().size() == 1) {
                        hbHead.getChildren().add(1, btnProvider);
                    } else if (hbHead.getChildren().size() > 1) {
                        hbHead.getChildren().remove(1);
                        hbHead.getChildren().add(1, btnProvider);
                    }

                    showRechargeView();
                }
            });
            btnList.add(btn);
        }

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 4, btnList);

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private Button getHeaderBtn(String provName) {
        Button btnHead = JKNode.getBtnSm("");
        ImageView imgView = JKNode.getJKImageViewProvider("prov_" + provName.replaceAll(" ", "").replaceAll("\n", "") + ".png");

        btnHead.setGraphic(imgView);
        btnHead.getStyleClass().add("prov_" + provName.replaceAll(" ", "").replaceAll("\n", "") + "_fix");
        return btnHead;
    }


    private void showRechargeView() {
        int n = vbPage.getChildren().size();
        if (n > 1) {
            vbPage.getChildren().remove(1, n);
        }
        JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
            @Override
            public void onDone() {
                vbPage.getChildren().add(1, new AirtimeRecharge(false, false));
            }
        });
    }
}
