package jkiosk3.sales.billpay;

/**
 *
 * @author Val
 */
public enum ProviderType {

//    SANRAL_E_TOLL,
    PAYAT_BILL_PAYMENT,
    PAYAT_INSURANCE_POLICY,
    PAYAT_TRAFFIC_FINE,
    PAYAT_BUS_TICKET,
    SYNTELL_BILL_PAYMENT,
    SYNTELL_TRAFFIC_FINE,
    SAPO_BILL_PAYMENT,
    BLU_BILL_PAYMENT, 
    BLU_M2M_TRANSFER
}
