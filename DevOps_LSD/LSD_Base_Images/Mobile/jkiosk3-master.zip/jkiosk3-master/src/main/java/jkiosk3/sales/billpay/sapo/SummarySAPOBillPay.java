package jkiosk3.sales.billpay.sapo;

import aeonbillpayments.sapo.SapoPayReq;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPaySAPOAddFields;
import jkiosk3.sales.billpay.BillPayUtilMisc;

/**
 *
 * @author Val
 */
public class SummarySAPOBillPay extends Region {

    private final int addFieldCode;
    private final BillPaySAPOAddFields additionalFields;
    private final SapoPayReq req;

    public SummarySAPOBillPay(int addField, BillPaySAPOAddFields additional, SapoPayReq request) {
        this.addFieldCode = addField;
        this.additionalFields = additional;
        this.req = request;

        getChildren().add(getSummaryGrid());
    }

    private GridPane getSummaryGrid() {
        GridPane grid = JKLayout.getSummaryGrid2Col(0.4, 0.6);
        grid.setTranslateX(-JKLayout.sp);

//        Label lblPaying = JKText.getLblDk(BillPayUtilMisc.SAPO_BILL_PAY, JKText.FONT_B_SM);
        Label lblPaying = JKText.getLblDk(BPTransType.BILLPAY_SAPO_ACCOUNT.getDisplayName(), JKText.FONT_B_SM);

        Label lblAccountNum = JKText.getLblDk("Account Number", JKText.FONT_B_XSM);
        Label lblAmount = JKText.getLblDk("Amount", JKText.FONT_B_XSM);
        Label lblAmountDue = JKText.getLblDk("Amount Due", JKText.FONT_B_XSM);
        Label lblTenderType = JKText.getLblDk("Tender Type", JKText.FONT_B_XSM);
        Label lblGroupNum = JKText.getLblDk("Group Number", JKText.FONT_B_XSM);
        Label lblSystemNum = JKText.getLblDk("System Number", JKText.FONT_B_XSM);
        Label lblPaymentCode = JKText.getLblDk("Payment Code", JKText.FONT_B_XSM);
        Label lblControlCode = JKText.getLblDk("Control Code", JKText.FONT_B_XSM);
        Label lblBarcode = JKText.getLblDk("Barcode", JKText.FONT_B_XSM);
        Label lblCheckDigit = JKText.getLblDk("Check Digit", JKText.FONT_B_XSM);

        // filled-in fields
        Text txtAccNum = JKText.getTxtDk(req.getRefNo(), JKText.FONT_B_XSM);
        Text txtAccStr = JKText.getTxtDk(additionalFields.getAccountStr(), JKText.FONT_B_XSM);
        Text txtAmount = JKText.getTxtDk(JKText.getDeciFormat(additionalFields.getAmount()), JKText.FONT_B_XSM);
        Text txtAmountDue = JKText.getTxtDk(JKText.getDeciFormat(additionalFields.getAmountDue()), JKText.FONT_B_XSM);

        String txtTender = JKTenderToggles.getTxtForTender(req.getTenderType());
        Text txtTenderType = JKText.getTxtDk(txtTender, JKText.FONT_B_XSM);
        Text txtGroupNum = JKText.getTxtDk(additionalFields.getGroupNo(), JKText.FONT_B_XSM);
        Text txtSystemNum = JKText.getTxtDk(additionalFields.getSystemNo(), JKText.FONT_B_XSM);
        Text txtPaymentCode = JKText.getTxtDk(additionalFields.getPaymentCode(), JKText.FONT_B_XSM);
        Text txtControlCode = JKText.getTxtDk(additionalFields.getControlCode(), JKText.FONT_B_XSM);
        Text txtBarcode = JKText.getTxtDk(additionalFields.getBarcode(), JKText.FONT_B_XSM);
        Text txtCheckDigit = JKText.getTxtDk(additionalFields.getCheckDigit(), JKText.FONT_B_XSM);

        grid.add(lblPaying, 0, 0, 2, 1);

        if (addFieldCode == 1) {
            grid.addRow(1, lblGroupNum, txtGroupNum);
            grid.addRow(2, lblSystemNum, txtSystemNum);
            grid.addRow(3, lblPaymentCode, txtPaymentCode);
            grid.addRow(4, lblControlCode, txtControlCode);
            grid.addRow(5, lblAmountDue, txtAmountDue);
            grid.addRow(6, lblTenderType, txtTenderType);
        } else if (addFieldCode == 2) {
            grid.addRow(1, lblBarcode, txtBarcode);
            grid.addRow(2, lblAccountNum, txtAccStr);
            grid.addRow(3, lblAmountDue, txtAmountDue);
            grid.addRow(4, lblCheckDigit, txtCheckDigit);
            grid.addRow(5, lblTenderType, txtTenderType);
        } else if (addFieldCode == 3) {
            grid.addRow(1, lblAccountNum, txtAccNum);
            grid.addRow(2, lblAmount, txtAmount);
            grid.addRow(3, lblTenderType, txtTenderType);
        } else if (addFieldCode == 4) {
            grid.addRow(1, lblAccountNum, txtAccNum);
            grid.addRow(2, lblAmountDue, txtAmountDue);
            grid.addRow(3, lblTenderType, txtTenderType);
        } else {
            grid.addRow(1, lblAccountNum, txtAccNum);
            grid.addRow(2, lblAmount, txtAmount);
            grid.addRow(3, lblTenderType, txtTenderType);
        }

        return grid;
    }
}
