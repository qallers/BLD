package jkiosk3.store.cache;

import aeonticketpros.bus.TicketProBusRouteCodeList;
import aeonticketpros.bus.TicketProBusRouteCode;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import jkiosk3.store.Store;

/**
 *
 * @author valeriew
 */
public class CacheListPutcoRoutes {

    private static volatile ListPutcoRoutes listPutcoRoutes;

    private static ListPutcoRoutes getListPutcoRoutes() {
        if (listPutcoRoutes == null) {
            listPutcoRoutes = ((ListPutcoRoutes) Store.loadObject(CacheListPutcoRoutes.class.getSimpleName()));
        }
        if (listPutcoRoutes == null) {
            listPutcoRoutes = new ListPutcoRoutes();
        }
        return listPutcoRoutes;
    }

    private static void saveListPutcoDepart(ListPutcoRoutes listPutRoutes) {
        Store.saveObject(CacheListPutcoRoutes.class.getSimpleName(), listPutRoutes);
    }

    public static void saveListPutcoRouteCodes(TicketProBusRouteCodeList listRoutes) {
        getListPutcoRoutes();
        listPutcoRoutes.getListPutcoRouteCodes().clear();
        listPutcoRoutes.getListPutcoRouteCodes().addAll(listRoutes.getListBusRouteCodes());
        saveListPutcoDepart(listPutcoRoutes);
    }

    public static boolean hasItems() {
        getListPutcoRoutes();
        return !listPutcoRoutes.getListPutcoRouteCodes().isEmpty();
    }

    public static List<TicketProBusRouteCode> getListPutcoRouteCodes() {
        getListPutcoRoutes();
        List<TicketProBusRouteCode> listCodes = listPutcoRoutes.getListPutcoRouteCodes();
        Collections.sort(listCodes, new Comparator<TicketProBusRouteCode>() {
            @Override
            public int compare(TicketProBusRouteCode o1, TicketProBusRouteCode o2) {
                return o1.getRouteCode().compareTo(o2.getRouteCode());
            }
        });
        return Collections.unmodifiableList(listCodes);
    }

    public static void deleteCachePutcoRoutes() {
        Store.deleteObject(CacheListPutcoRoutes.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheListPutcoRoutes.class.getSimpleName());
    }
}
