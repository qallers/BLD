package jkiosk3._components;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import jkiosk3.StageJKiosk;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

public class WebPage extends Region {

    private final double pageW = StageJKiosk.getSceneWidth();
    private StackPane paneContent;
    private WebView htmlContent;

    public WebPage() {
        getChildren().add(getWebPageStack());
    }

    private StackPane getWebPageStack() {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getWebPageGrp());

        return stack;
    }

    private VBox getWebPageGrp() {
        VBox vbox = JKLayout.getVBoxContent(JKLayout.spNum);
        vbox.setStyle("-fx-padding: 15px;");
        vbox.setPrefWidth(pageW - (2 * JKLayout.spNum));

        Button btnOK = JKNode.getBtnMsgBox("OK");
        btnOK.setMaxHeight(JKLayout.btnToggleH);
        btnOK.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onOkBtnEvent();
            }
        });

        vbox.getChildren().addAll(getContentPane(), new Separator(), btnOK);

        return vbox;
    }

    private StackPane getContentPane() {
        double h = StageJKiosk.getSceneHeight() - (6 * JKLayout.sp);

        paneContent = new StackPane();
        paneContent.setPrefWidth(pageW - (2 * JKLayout.spNum));

        htmlContent = new WebView();
        htmlContent.setPrefSize((pageW - (2 * JKLayout.spNum)), h);

        paneContent.getChildren().add(htmlContent);

        return paneContent;
    }

    private void onOkBtnEvent() {
        setVisible(false);
        toBack();
    }

    public void showWebPage(String url) {
        paneContent.getChildren().clear();
        htmlContent.getEngine().load(url);
        paneContent.getChildren().add(htmlContent);

        this.setVisible(true);
        this.toFront();
    }
}
