package jkiosk3.sales._common;

/**
 *
 * @author Val
 */
public abstract class QuickAmountsResult {

    public abstract void amountSelected(double value);
}
