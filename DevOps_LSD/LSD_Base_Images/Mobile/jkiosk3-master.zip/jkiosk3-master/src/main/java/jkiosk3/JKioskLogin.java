package jkiosk3;

import Download.HttpUtils;
import aeonfavourites.FavouriteItem;
import aeonreports.UnprintedItem;
import aeonreports.UnprintedList;
import aeonusers.User;
import aeonusers.UserTransactionType;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.util.Duration;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NewsScroll;
import jkiosk3._components.NumberPadResult;
import jkiosk3._components.update.StageApplicationUpdate;
import jkiosk3.admin.favourites.fav_cache.CacheFavouriteDefaultStore;
import jkiosk3.branding.MerchantGroup;
import jkiosk3.callme.CallMeMainMenu;
import jkiosk3.callme.DownloadCategoryService;
import jkiosk3.printing.PrintHandler;
import jkiosk3.reports.ReprintUtil;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesItems;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._favourites.FavouriteUtil;
import jkiosk3.setup.SceneSetup;
import jkiosk3.setup.SetupConfig;
import jkiosk3.store.*;
import jkiosk3.store.cache.CacheController;
import jkiosk3.store.cache.CacheListTransTypes;
import jkiosk3.store.cache.CacheUtil;
import jkiosk3.users.UserUtil;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.ResubmitUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JKioskLogin extends Region {

    private final static Logger logger = Logger.getLogger(JKioskLogin.class.getName());
    //
    private final double sp = JKLayout.sp;
    private double newsW = (StageJKiosk.getSceneWidth() - (2 * sp));
    //    private final double newsH = 110;
    private final double newsH = 100;       // (6 * SP) + (2 * spNum)
    private HBox hbNews;
    private double calculatedMsgWidth;
    private static TranslateTransition trans;
    private static PasswordField pwd;
    private MerchantGroup merchantGroup;
    private int transCount;
    private String unprintedTypeDisplay;
    private String productDescription;

    public JKioskLogin() {

        if (JKiosk3.getCacheController().getScheduledCacheExecutor() != null) {
            JKiosk3.getCacheController().getScheduledCacheExecutor().shutdown();
            logger.info("Shutdown ScheduledExecutorService for Product Caching on load Login page.");
        }

        /* CR-2014 - caching must ALWAYS be on in future.  If 'never' is selected, this must be changed. */
        if (!JKCacheOptions.getCachePreferences().isDaily() && !JKCacheOptions.getCachePreferences().isHourly()) {
            JKCacheOptions.getCachePreferences().setDaily(true);
            JKCacheOptions.getCachePreferences().setHourly(false);
            JKCacheOptions.getCachePreferences().setNever(false);
            StoreJKCacheOptions jkCache = new StoreJKCacheOptions();
            jkCache.setDaily(JKCacheOptions.getCachePreferences().isDaily());
            jkCache.setHourly(JKCacheOptions.getCachePreferences().isHourly());
            jkCache.setNever(JKCacheOptions.getCachePreferences().isNever());
            StringBuilder sb = new StringBuilder("\r\n");

            if (JKCacheOptions.saveCachePreferences(jkCache)) {
                sb.append("Cache default saved successfully on login");
            } else {
                sb.append("Cache default not saved successfully on login");
            }
            logger.info(sb.toString());
            makeJKioskLogin();
        } else {
            makeJKioskLogin();
        }

    }

    private void makeJKioskLogin() {
        merchantGroup = JKBranding.getBranding().getMerchantGroup();

        if (merchantGroup == null) {
            String defaultBranding = JK3Config.getDefaultBranding();
            System.out.println(">>>>>>>>>>>>>>>>>>defaultBranding = " + defaultBranding);
            if (defaultBranding.equalsIgnoreCase("gcrs")) {
                merchantGroup = new MerchantGroup();
                merchantGroup.setCode("GLOCELL");
                merchantGroup.setName("Glocell Retail Solutions");
                merchantGroup.setPrimaryColourHex("#019549");
                merchantGroup.setSecondaryColourHex("#022F66");
            } else {
                merchantGroup = new MerchantGroup();
                merchantGroup.setCode("BLD");
                merchantGroup.setName("Blue Label Distribution");
                merchantGroup.setPrimaryColourHex("#0F224E");
                merchantGroup.setSecondaryColourHex("#FFDC0D");
            }
            JKBranding.getBranding().setMerchantGroup(merchantGroup);
            JKBranding.saveBranding();
        }

        ImageView imgScreen = getBranding();

//        makeNewsBoxes();
        hbNews = new NewsScroll();

        StackPane stack = new StackPane();

        stack.getChildren().add(imgScreen);
        stack.getChildren().add(getLoginLayout());

        JKioskStartup.start();

        getChildren().add(stack);

        final Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                calculateMsgWidth();
                timer.cancel();
            }
        }, 750);
    }

    private ImageView getBranding() {
        Image img = new Image("file:media/branding/BLD/screen_BLD.png");
        ImageView imgScreen = new ImageView(img);
        JKiosk3.getScene().getStylesheets().clear();
        JKiosk3.getScene().getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/default.css").toExternalForm());
        String merchantCode = merchantGroup.getCode();
        if (merchantCode.equalsIgnoreCase("BLD")) {
            JKText.setColourMain("#0F224E");
            img = new Image("file:media/branding/BLD/screen_BLD.png");
        } else if (!merchantCode.equals("BLD")) {
            JKText.setColourMain(merchantGroup.getPrimaryColourHex());
            JKiosk3.getScene().getStylesheets().add("file:media/branding/" + merchantCode + "/style_" + merchantCode + ".css");
            img = new Image("file:media/branding/" + merchantCode + "/screen_" + merchantCode + ".png");
        }

        // 2019-11-12  -  This is not right. Should NOT be added from here unless the external stylesheet load fails.
//        JKiosk3.getScene().getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/providerStyle.css").toExternalForm());
        //
        /* If the external stylesheet exists, it should be added AFTER the local one, to override any internal styles. */
        try {
            /*
             * stylesheets must be added in correct order - this one must always be added LAST.
             */
//            logger.info("loading external provider stylesheet... ");
            String filepath = "file:media/providerStyle.css";
            JKiosk3.getScene().getStylesheets().add(filepath);
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
            /* If an exception is caught, add the internal stylesheet. */
            JKiosk3.getScene().getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/providerStyle.css").toExternalForm());
        }
        imgScreen.setImage(img);
        return imgScreen;
    }

    private void calculateMsgWidth() {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                calculatedMsgWidth = hbNews.widthProperty().getValue();
//                System.out.println("calculatedMsgWidth is " + calculatedMsgWidth + " wide");
                makeTranslateTransition();
                hbNews.setOpacity(1.0);
            }
        });
    }

    private void makeTranslateTransition() {
        double newsOffset = (StageJKiosk.getSceneWidth() / 2) - (newsW / 2);
        int scrollSpeed = 0;
        /* Higher number scrolls slower.  Speed used to be problematic on some machines. */
        if (calculatedMsgWidth < 2000) {
            scrollSpeed = 27500;
        } else {
            scrollSpeed = 40000;
        }
        trans = new TranslateTransition(Duration.millis(scrollSpeed), hbNews);
        trans.setFromX(newsOffset + newsW);
        trans.setToX(newsOffset - (calculatedMsgWidth + (4 * JKLayout.sp)));
        trans.setCycleCount(Timeline.INDEFINITE);
        trans.setAutoReverse(false);
        trans.play();
    }

    private StackPane getLoginLayout() {
        StackPane stack = new StackPane();
        VBox connect = getConnectStatus();
        HBox setup = getSetupGrp();
        ScrollPane news = getNewsGrp();
        VBox login = getLoginBox();

        StackPane.setAlignment(connect, Pos.TOP_LEFT);
        StackPane.setMargin(connect, new Insets(sp));
        StackPane.setAlignment(setup, Pos.TOP_RIGHT);
        StackPane.setMargin(setup, new Insets(sp));
        StackPane.setAlignment(news, Pos.BOTTOM_CENTER);
        StackPane.setMargin(news, new Insets(0, 0, (2 * sp), 0));

        stack.getChildren().addAll(JKiosk3.getComponentStack());
        stack.getChildren().addAll(connect, login, setup, news);

        return stack;
    }

    private VBox getLoginBox() {
        double w = (JKLayout.btnLgW + (2 * sp));

        VBox vbox = JKLayout.getVBox(sp, sp);
        vbox.getStyleClass().add("vbContent");
        vbox.setMaxSize(w, USE_PREF_SIZE);
        vbox.setMinSize(w, USE_PREF_SIZE);

        Label lbl = JKText.getLblDk("Sign In", JKText.FONT_B_SM);

        pwd = new PasswordField();
        pwd.setPrefWidth(w);
        pwd.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent e) {
                if (e.getCode() == KeyCode.ENTER) {
                    checkAppUpdate();
                }
            }
        });
        pwd.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(pwd, "Enter password", "", new NumberPadResult() {
                        @Override
                        public void onDone(String value) {
                            pwd.requestFocus();
                        }
                    });
                }
            }
        });

        Button btnLogin = JKNode.getBtnLg("Login");
        btnLogin.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                checkAppUpdate();
            }
        });

        if (SetupConfig.isDeviceChanged()) {
            pwd.setDisable(true);
            btnLogin.setDisable(true);
        }

        vbox.getChildren().addAll(lbl, pwd, btnLogin);
        vbox.setTranslateY(5 * sp);

        return vbox;
    }

    private VBox getConnectStatus() {
        VBox vb = JKLayout.getVBoxLeft(0, (sp / 2));
        vb.setPrefWidth(300);

        HBox hbConnect = JKLayout.getHBoxLeft(0, sp);
        hbConnect.setPrefWidth(300);

        String version = "JKiosk - version " + Version.getVersionNum();

        Label lblVersion = JKText.getLblDk(version, JKText.FONT_B_XXSM);
        lblVersion.setMinWidth(300);

        Circle circ = new Circle(10);
        circ.setFill(Color.RED);
        circ.setStroke(Color.web("#002349"));

        Label lblConnect = JKText.getLblDk("Connection Status", JKText.FONT_B_XXSM);

        hbConnect.getChildren().addAll(circ, lblConnect);

        if (JKDialup.getDialupConnect().isAutoConn()) {
            if (DialupConnection.getInstance().isConnected(JKDialup.getDialupConnect().getAutoConnName())) {
                circ.setFill(Color.GREEN);
            } else {
                circ.setFill(Color.RED);
            }
            hbConnect.setVisible(true);
        } else {
            hbConnect.setVisible(false);
        }

        vb.getChildren().addAll(lblVersion, hbConnect, getVBSupport());

        return vb;
    }

    private VBox getVBSupport() {
        Label lblSupport = JKText.getLblDk("Support", JKText.FONT_B_18);
        Text txtTel;
        Text txtEmail;
        txtTel = JKText.getTxtDk(JK3Config.getInfoHelpDeskTelNum(), JKText.FONT_B_15);
        txtEmail = JKText.getTxtDk(JK3Config.getInfoHelpDeskEmail(), JKText.FONT_B_15);

        VBox vbSupport = JKLayout.getVBox(0, JKLayout.spNum);
        vbSupport.setAlignment(Pos.TOP_LEFT);
        vbSupport.getChildren().addAll(lblSupport, txtTel, txtEmail);
        return vbSupport;
    }

    private HBox getSetupGrp() {

        HBox hboxSet = JKLayout.getHBox(sp, sp);
        hboxSet.getStyleClass().add("hbContent");
        hboxSet.setMaxSize(((3 * JKLayout.btnNumW) + (4 * sp)), JKLayout.btnNumH + (2 * sp));

        Image imgC = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/callme.png"));
        ImageView imgCallMe = new ImageView(imgC);
        imgCallMe.setFitHeight(40);
        imgCallMe.setPreserveRatio(true);

        Image imgH = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/help.png"));
        final ImageView imgHelp = new ImageView(imgH);
        Image imgS = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/tools.png"));
        ImageView imgSet = new ImageView(imgS);
        Image imgX = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/cross.png"));
        ImageView imgExit = new ImageView(imgX);

        final Button btnCallMe = JKNode.getBtnNum("");
        btnCallMe.setGraphic(imgCallMe);

        /*btnCallMe.setVisible(JK3Config.getDefaultBranding().equalsIgnoreCase("gcrs") ? false : true);*/

        btnCallMe.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {

                DownloadCategoryService pleaseCallMeUtil = new DownloadCategoryService();
                String restResp = pleaseCallMeUtil.postData();

                if(restResp.isEmpty()){
                    JKiosk3.getMsgBox().showMsgBox("Oops! something went wrong",
                            "Unable to connect to server. \nPlease try again later.", null);
                } else {
                    JKiosk3.changeScene(new CallMeMainMenu());

                    // this is another way of navigating to preferable screen on JKiosk
                    /*getChildren().add(new CallMeMainMenu());*/
                }
            }
        });

        final Button btnHelp = JKNode.getBtnNum("");
        btnHelp.setGraphic(imgHelp);
        btnHelp.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                trans.stop();
                JKiosk3.getWebPage().showWebPage(JK3Config.getHelpUrl());
            }
        });

        Button btnSet = JKNode.getBtnNum("");
        btnSet.setGraphic(imgSet);
        btnSet.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                trans.stop();
                final PasswordField pwdPin = new PasswordField();
                JKiosk3.getNumPad().showNumPad(pwdPin, "Enter PIN Number", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        if (pwdPin.getText().equals("2596")) {
                            JKiosk3.changeScene(new SceneSetup("2596"));
                        } else {
                            JKiosk3.getMsgBox().showMsgBox("Invalid PIN", "Please enter a valid PIN number", null);
                        }
                    }
                });
            }
        });

        Button btnExit = JKNode.getBtnNum("");
        btnExit.setGraphic(imgExit);
        btnExit.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.closeJKiosk();
            }
        });

        if (JKBranding.getBranding().getMerchantGroup().getCode().equals("GLOCELL")) {
            hboxSet.getChildren().addAll(btnHelp, btnSet, btnExit);
        } else {
            hboxSet.getChildren().addAll(btnCallMe, btnHelp, btnSet, btnExit);
        }

        return hboxSet;
    }

    private ScrollPane getNewsGrp() {

        ScrollPane pane = new ScrollPane();
        pane.getStyleClass().add("scrollNewsContent");
        pane.setMaxSize(newsW, newsH);
        pane.setMinSize(newsW, newsH);
        pane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        pane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        pane.setContent(hbNews);

        pane.setOnMouseEntered(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                if (trans != null) {
                    trans.pause();
                }
            }
        });

        pane.setOnMouseExited(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                if (trans != null) {
                    trans.play();
                }
            }
        });

        return pane;
    }

    private void userLogin() {
        trans.stop();
        logSettings();

        final String userPin = pwd.getText();
        UserUtil.getLoggedInUser(userPin, new UserUtil.LoggedInUserResult() {

            @Override
            public void loggedInUserResult(final User loggedInUser) {
                if (loggedInUser != null && loggedInUser.isSuccess()) {
                    logger.info(("User logged in successfully : ").concat(loggedInUser.getUserName()));

                    // 2019-11-05  -  moved to ResubmitUtil, where it belongs!
//                    // check unprinted queue here
//                    if (JKSetPrintedQueue.hasItems()) {
//                        logger.info(("JKioskLogin : items in JKSetPrintedQueue = ").concat(Integer.toString(JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs().size())));
//                        setTransactionPrinted(JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs().get(0));
//                    }

                    /* Make lists needed for Menu, based on User Transaction Types. */
                    List<UserTransactionType> listTransType = loggedInUser.getUserTransactionTypes();
                    SalesItems.setupTransTypeList(listTransType);

                    logger.info(("Items in loggedInUser.getPrintQueue() : ").concat(Integer.toString(loggedInUser.getPrintQueue())));

                    if (loggedInUser.getPrintQueue() > 0) {
                        // make user print vouchers
                        printUnprintedVoucher();
                    } else {
                        System.out.println("No items in User Print Queue, continue...");

                        // wrap these next 2 items in a "busy" and wait for result
                        ResubmitUtil.resubmitUnprocessedItems(new ResultCallback() {
                            @Override
                            public void onResult(boolean result) {
                                // done - result should always be 'true' even if lists still exist
                                if (result) {
                                    continueLogin(loggedInUser);
                                }
                            }
                        });
                    }
                } else if (loggedInUser != null) {
                    JKiosk3.getMsgBox().showMsgBox("Login Failed",
                            loggedInUser.getErrorCode() + " - " + loggedInUser.getErrorText(), null);
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Login Failed",
                            "Unable to validate User", null);
                }
            }
        });
    }

    private void continueLogin(User loggedInUser) {
        /* Start scheduler for Product Cache updating. */
        if (JKiosk3.getCacheController() != null) {
            JKiosk3.getCacheController().setCacheUser(loggedInUser);
            logger.info(("value of CacheController.isFirstLogin = ").concat(Boolean.toString(CacheController.isFirstLogin())));
            if (CacheController.isFirstLogin()) {
                // check if more than an hour ago
                long timecurrent = System.currentTimeMillis();
//                long timetillupdate = 1000L * 60L * 60L;    // 1 hour
                long timetillupdate = 1000L * 60L * 60L * 6L;    // 6 hours - surely 4 times a day is enough?
//                long timetillupdate = 1000L * 60L * 10L;    // 10 minutes
                long timeexpire = CacheListTransTypes.checkFileTime() + timetillupdate;
                long timegone = timecurrent - CacheListTransTypes.checkFileTime();
                System.out.println("time gone by for product cache = " + TimeUnit.MILLISECONDS.toMinutes(timegone) + " minutes");

                if (timecurrent >= timeexpire) {
                    JKiosk3.getCacheController().setUpdateCacheNow(CacheUtil.SCENE_SALES, new ResultCallback() {
                        @Override
                        public void onResult(boolean result) {
                            CacheController.setFirstLogin(false);
                            System.out.println("In Login, cache controller result = " + result);
                            checkFavouritesCache();
                        }
                    });
                } else {
                    checkFavouritesCache();
                }
            } else {
                JKiosk3.getCacheController().setUpdateCacheScheduler();
                checkFavouritesCache();
            }
        } else {
            checkFavouritesCache();
        }
    }

    private void checkFavouritesCache() {
        if (isFavouriteCacheUpdate()) {
            JKiosk3.getMsgBox().showMsgBox("Favourite Products List",
                    "\nFavourites list is out of date.\n\nDo you want to update it now?",
                    null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_YES_NO, new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            FavouriteUtil.getListFavouriteProducts(true, new FavouriteUtil.FavouriteProductsResult() {
                                @Override
                                public void favouriteProductsResult(List<FavouriteItem> favListResp) {
                                    JKiosk3.changeScene(new SceneSales(true));
                                }
                            });
                        }

                        @Override
                        public void onCancel() {
                            JKiosk3.changeScene(new SceneSales(true));
                        }
                    });
        } else {
            JKiosk3.changeScene(new SceneSales(true));
        }
    }

    private boolean isFavouriteCacheUpdate() {
        long timecurrent = System.currentTimeMillis();
        long timetillupdate = 1000L * 60L * 60L * 24L * 7L;    // 1 week
//        long timetillupdate = 1000L * 60L * 3L;    // 3 minutes
        long timeexpire = CacheFavouriteDefaultStore.checkFileTime() + timetillupdate;

        if (timecurrent >= timeexpire) {
            return true;
        } else {
            return false;
        }
    }

    private void printUnprintedVoucher() {
        ReprintUtil.getUnprintedList(new ReprintUtil.UnprintedListResult() {

            @Override
            public void unprintedListResult(UnprintedList unprintedList) {
                if (unprintedList.isSuccess()) {
                    if (unprintedList.getListTransRefs().isEmpty()) {
                        System.out.println("nothing in the list");
                    } else {
                        for (String i : unprintedList.getListTransRefs()) {
                            System.out.println("transref : " + i);
                        }
                        transCount = 0;
                        getUnprintedTrx(transCount, unprintedList.getListTransRefs());
                    }
                }
            }
        });
    }

    private void getUnprintedTrx(final int count, final List<String> listTrx) {
        String trx = listTrx.get(count);
        logger.info(("Retrieving details for unprocessed transaction = ").concat(trx));
        ReprintUtil.getUnprintedItem(trx, new ReprintUtil.UnprintedItemResult() {

            @Override
            public void unprintedItemResult(UnprintedItem unprintedItem) {
                if (unprintedItem.isSuccess()) {
                    processUnprintedItem(unprintedItem, listTrx);
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Failed to retrieve Unprinted Item", "TransRef : " + listTrx.get(count), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    System.out.println("did not get anything useful!");
                                    transCount++;
                                    if (transCount < listTrx.size()) {
                                        getUnprintedTrx(transCount, listTrx);
                                    } else {
                                        JKiosk3.changeScene(new JKioskLogin());
                                    }
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private void processUnprintedItem(final UnprintedItem unprintedItem, final List<String> listTrx) {

        final String transType = unprintedItem.getTransType();

        List<UserTransactionType> listUserTT = JKTransTypes.getListUserTransTypes();
        List<SaleType> listSaleTypes = SaleType.getListSaleTypes();

        for (UserTransactionType utt : listUserTT) {
            if (transType.equalsIgnoreCase(utt.getTransactionType())) {
                UserTransactionType selected = utt;
                for (SaleType st : listSaleTypes) {
                    if (st.getType().equalsIgnoreCase(selected.getType())) {
                        unprintedTypeDisplay = st.getDisplay();
                        break;
                    }
                }
            }
        }
        transCount++;
        productDescription = "";
        if (unprintedItem.getProductName() != null) {
            productDescription = unprintedItem.getProductName();
        } else if (unprintedItem.getReference() != null) {
            productDescription = transType + " " + unprintedItem.getReference();
        } else {
            productDescription = transType;
        }
        JKiosk3.getMsgBox().showMsgBox("Pending Item", productDescription + "\n\nwill be added to the Sale", null, MessageBox.CONTROLS_SHOW,
                MessageBox.MSG_OK, new MessageBoxResult() {

                    @Override
                    public void onOk() {
                        List<String> listTrxId = new ArrayList<>();
                        if (JKPending.hasPendingItems()) {
                            for (StoreJKPending s : JKPending.getPendingList()) {
                                listTrxId.add(s.getTransReference());
                            }
                        }
                        List<User> listUsers = UserUtil.getUserList();
                        User cashier = null;
                        if (listUsers != null) {
                            for (User u : listUsers) {
                                if (u.getUserId() == unprintedItem.getCashierId()) {
                                    cashier = u;
                                    break;
                                }
                            }
                        } else {
                            logger.log(Level.WARNING, "Unable to get User List");
                        }
                        if (cashier == null) {
                            logger.log(Level.WARNING, "Unable to determine cashier for Unprinted Item " + unprintedItem.getTransRef());
                            cashier = new User();
                        }
                        if (!listTrxId.contains(unprintedItem.getTransRef())) {
                            StoreJKPending storeItem = new StoreJKPending(productDescription, unprintedItem.getAmount(), unprintedItem.getTransRef(),
                                    false, "online", unprintedItem.getAeonPrintJob(),
                                    cashier, unprintedItem.getSerial(), unprintedTypeDisplay);
                            storeItem.setDateTime(unprintedItem.getDate());
                            storeItem.setTenderType(unprintedItem.getTenderType());
                            JKPending.savePendingItem(storeItem);
                        }

                        // 2019-11-07  -  PRODDEFECT-868
                        // Print immediately or later is now handled in PrintHandler
//                        if (JKPrintOptions.getPrintOptions().isPrintImmediately()) {
                        // 2021-03-17  - PRODDEFECT-1007
/*                        if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
                            JKiosk3.getPrintPreview().showPrintPreview(unprintedTypeDisplay, unprintedItem.getAeonPrintJob(),
                                    unprintedItem.getTransRef(), PrintPreview.PRN_OK_CANCEL, new PrintPreviewResult() {

                                        @Override
                                        public void onOk() {
                                            checkCountAndContinue(transCount, listTrx);
                                        }

                                        @Override
                                        public void onCancel() {
                                            //
                                        }
                                    });
                        } else {*/
                            try {
                                PrintHandler.handlePrintRequestSale("", unprintedItem.getAeonPrintJob(), unprintedItem.getTransRef());
                                logger.info("item sent to printer - size of JKPending is now : " + JKPending.getPendingList().size());
                            } catch (Exception e) {
                                logger.log(Level.SEVERE, "Error sending unprinted item to PrintHandler: " + e);

                                JKiosk3.getMsgBox().showMsgBox("System Error", "An error occurred trying to recover the transaction.", null);
                            }
                            checkCountAndContinue(transCount, listTrx);
/*                        } */
                    }

                    @Override
                    public void onCancel() {
                    }
                });
    }

    private void checkCountAndContinue(int count, List<String> listTrx) {
        if (count < listTrx.size()) {
            getUnprintedTrx(count, listTrx);
        } else {
            JKiosk3.changeScene(new SceneSales(false));
        }
    }

    public static TranslateTransition getTrans() {
        return trans;
    }

//    private void setTransactionPrinted(final String transRef) {
//        UserUtil.setTransactionPrinted(transRef, new UserUtil.SetPrintedResponseResult() {
//            @Override
//            public void setPrintedResponseResult(SetPrintedResponse result) {
//                if (result.isSuccess()) {
//                    JKSetPrintedQueue.removeSetPrintedItem(transRef);
//                    // continue - business as usual
//                    logger.info(("Set printed success : transRef - ").concat(transRef).concat(" - success - ").concat(Boolean.toString(result.isSuccess())));
//                    JKiosk3.changeScene(new JKioskLogin());
//                } else {
//                    logger.info(("Set printed failed : transRef - ").concat(transRef).concat(" - success - ").concat(Boolean.toString(result.isSuccess())));
//                    JKiosk3.changeScene(new JKioskLogin());
//                }
//            }
//        });
//    }

    private void logSettings() {

        StringBuilder sb = new StringBuilder();
        sb.append("\r\n").append(" ------------------------------------------------ ").append("\r\n");
        sb.append("  >>>  Print Options").append("\r\n");
        sb.append("  Show Print Preview before Printing             : ").append(JKPrintOptions.getPrintOptions().isPrintPreview()).append("\r\n");
        sb.append("  Print Vouchers Immediately                     : ").append(JKPrintOptions.getPrintOptions().isPrintImmediately()).append("\r\n");
        sb.append("  Print Receipts                                 : ").append(JKPrintOptions.getPrintOptions().isPrintReceipts()).append("\r\n");
        sb.append("  Print Merchant Copy of Voucher                 : ").append(JKPrintOptions.getPrintOptions().isPrintMerchantCopy()).append("\r\n");
        sb.append("  Print Barcode on Vouchers                      : ").append(JKPrintOptions.getPrintOptions().isPrintBarcode()).append("\r\n");
        sb.append("  Hide Voucher PIN on Reprint                    : ").append(JKPrintOptions.getPrintOptions().isHideReprintPin()).append("\r\n");
        sb.append(" ------------------------------------------------ ").append("\r\n");
        sb.append("  >>>  Options").append("\r\n");
        sb.append("  Entry Method - Keyboard                        : ").append(JKOptions.getOptions().isKeyboard()).append("\r\n");
        sb.append("  User Login Required for Each Main Menu Item    : ").append(JKOptions.getOptions().isMultipleMenuLogin()).append("\r\n");
        sb.append("  Sales Person AutoLogout After Each Sale        : ").append(JKOptions.getOptions().isAutoLogout()).append("\r\n");
        sb.append("  Sales Person Login at Start of Each Sale       : ").append(JKOptions.getOptions().isSalesPersonLogin()).append("\r\n");
        sb.append("  Allow Cashiers to End Shift                    : ").append(JKOptions.getOptions().isCashierEndShift()).append("\r\n");
        sb.append(" ------------------------------------------------ ").append("\r\n");
        sb.append("  >>>  Sales Options").append("\r\n");
        sb.append("  Confirm Sale Details Before Proceeding         : ").append(JKSalesOptions.getSalesOptions().isConfirmSale()).append("\r\n");
        sb.append("  Enter Amount Tendered and Calculate Change Due : ").append(JKSalesOptions.getSalesOptions().isEnterTender()).append("\r\n");
        sb.append("  Use Cash Drawer                                : ").append(JKSalesOptions.getSalesOptions().isUseCashDrawer()).append("\r\n");
        sb.append("  Open Cash Drawer on End Shift                  : ").append(JKSalesOptions.getSalesOptions().isCashDrawerOpenOnEndShift()).append("\r\n");
        sb.append(" ------------------------------------------------ ").append("\r\n");
        sb.append("  >>>  Cache Options").append("\r\n");
        sb.append("  Update Cache 24 Hourly                         : ").append(JKCacheOptions.getCachePreferences().isDaily()).append("\r\n");
        sb.append("  Update Cache Hourly                            : ").append(JKCacheOptions.getCachePreferences().isHourly()).append("\r\n");
//        sb.append("  Update Cache Never                             : ").append(cacheUpdateNever).append("\r\n");
        sb.append(" ------------------------------------------------ ").append("\r\n");
        logger.info(sb.toString());
    }

    public void checkAppUpdate() {

        String appInstallDestination = JK3Config.getAppInstallPath().concat(JK3Config.getAppInstallFile());
        boolean isFileNewer = HttpUtils.isRemoteFileNewer(JK3Config.getAppUpdatePath(), appInstallDestination);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        StringBuilder sb = new StringBuilder();
        sb.append("\r\n").append("----------------------------------------------------------------------------------------").append("\r\n");
        sb.append("app update retrieval path     : ").append(JK3Config.getAppUpdatePath()).append("\r\n");
        sb.append("app update destination path   : ").append(appInstallDestination).append("\r\n");
        sb.append("date of remote file           : ").append(sdf.format(HttpUtils.getDateFileRemote())).append("\r\n");
        sb.append("date of local file            : ").append(sdf.format(HttpUtils.getDateFileLocal())).append("\r\n");
        sb.append("----------------------------------------------------------------------------------------").append("\r\n");
        logger.info(sb.toString());

        if (isFileNewer) {
            logger.info("NEW VERSION FOUND - NEED TO DOWNLOAD UPDATED ZIP FILE AT THIS POINT");
            StageApplicationUpdate stageUpdate = new StageApplicationUpdate(new ResultCallback() {
                //
                @Override
                public void onResult(boolean result) {
                    if (result) {
                        userLogin();
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Application Update", "Download failed.\n\nApplication has not been updated.", null,
                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                    @Override
                                    public void onOk() {
                                        /* Update failed, but continue with User login anyway */
                                        userLogin();
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    }
                }
            });
        } else {
            userLogin();
        }
    }
}

//        final ContextMenu contextMenu = new ContextMenu();
//        MenuItem add = new MenuItem("add");
//        add.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent actionEvent) {
//                System.out.println("add item somewhere...");
//            }
//        });
//        MenuItem remove = new MenuItem("remove");
//        remove.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent actionEvent) {
//                System.out.println("remove item somewhere...");
//            }
//        });
//        contextMenu.getItems().addAll(add, remove);

//        btnHelp.setOnMouseReleased(new EventHandler() {
//@Override
//public void handle(Event e) {
//        trans.stop();
//        System.out.println("primary mouse");
////                if (e.getSource().equals(MouseButton.PRIMARY)) {
//        JKiosk3.getWebPage().showWebPage(JK3Config.getHelpUrl());
////                }
//        }
//        });
////        btnHelp.setOnContextMenuRequested(new EventHandler<ContextMenuEvent>() {
////            @Override
////            public void handle(ContextMenuEvent contextMenuEvent) {
////                System.out.println("secondary mouse");
////                if (contextMenuEvent.getSource().equals(MouseButton.SECONDARY)) {
////                    contextMenu.show(btnHelp, contextMenuEvent.getX(), contextMenuEvent.getY());
////                }
////            }
////        });
