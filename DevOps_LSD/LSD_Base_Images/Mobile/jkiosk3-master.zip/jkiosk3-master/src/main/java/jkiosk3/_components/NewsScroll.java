package jkiosk3._components;

import javafx.geometry.Pos;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.store.JKBranding;

import java.util.ArrayList;
import java.util.List;

public class NewsScroll extends HBox {

    private final double newsH = 100;       // (6 * sp) + (2 * spNum)
    private HBox hbNews;

    public  NewsScroll() {
        HBox hBox = makeNewsBoxes();

        setOpacity(0.0);

        getChildren().add(hBox);
    }

    private HBox makeNewsBoxes() {
        hbNews = JKLayout.getHBox(JKLayout.spNum, (2 * JKLayout.sp));
        hbNews.setMaxHeight(newsH);
        hbNews.setMinHeight(newsH);
        hbNews.setAlignment(Pos.CENTER);

        hbNews.getChildren().addAll(getNewsDemo());

        return hbNews;
    }

    private List<VBox> getNewsDemo() {
        List<VBox> itemsDemo = new ArrayList<>();

        String brandingSelected = JKBranding.getBranding().getMerchantGroup().getName();

        String[] strLogos;
        if (brandingSelected.toLowerCase().contains("glocell")) {
            strLogos = new String[]{"CellC", "CityToCity", "EldoCoaches",
                    "Intercape", "MTN", "Neotel", "PayAt", "Putco", "SAPO", "Syntell", "Telkom",
                    "TelkomMobile", "TransLux", "UniPin", "VirginMobile", "Vodacom", "TicketPros"};
        } else {
            strLogos = new String[]{"Blu", "CellC", "CityToCity", "EldoCoaches",
                    "Intercape", "MTN", "Neotel", "PayAt", "Putco", "SAPO", "xSupabets", "Syntell", "Telkom",
                    "TelkomMobile", "TopTV", "TransLux", "UniPin", "VirginMobile", "Vodacom", "TicketPros"};
        }
        for (String s : strLogos) {
            ImageView img = JKNode.getJKImageViewProvider("prov_" + s + ".png");
            if (s.equalsIgnoreCase("TicketPros")) {
                img = JKNode.getJKImageViewProvider(s + ".png");
            }
            img.setFitHeight(newsH - 60);       // 4 * SP
            img.setPreserveRatio(true);
            VBox vb = new VBox();
            vb.setMaxHeight(newsH - 30);        // 2 * SP
            vb.setMinHeight(newsH - 30);
            vb.setAlignment(Pos.CENTER);
            vb.getStyleClass().add("vbNews");
            vb.getChildren().add(img);
            itemsDemo.add(vb);
        }

        return itemsDemo;
    }
}

//import com.sun.cnpi.rss.elements.Item;
//import com.sun.cnpi.rss.elements.Rss;
//import com.sun.cnpi.rss.parser.RssParser;
//import com.sun.cnpi.rss.parser.RssParserException;
//import com.sun.cnpi.rss.parser.RssParserFactory;


    /*
     Not currently used, but WILL BE REQUIRED when Business designates someone to keep the RSS news
     on the AEON web site updated.
     */
//    private List<VBox> getNewsRSS() {
//        List<VBox> itemsLive = new ArrayList<>();
//        Calendar cal = Version.getVersionDate();
//        Date versionDate = cal.getTime();
//
//        try {
//            RssParser parser = RssParserFactory.createDefault();
//            Rss rss = parser.parse(new URL(Version.getRssUrl()));
//            if (rss != null) {
//                Collection itemList = rss.getChannel().getItems();
//                List<VBox> itemsTemp = new ArrayList<>();
//                for (Object i : itemList) {
//                    Item item = (Item) i;
//                    Date itemDate = new SimpleDateFormat("E, dd MMM yyyy hh:mm:ss Z").parse(item.getPubDate().getText());
//                    Long versionDateInMillis = versionDate.getTime();
//                    Long itemDateInMillis = itemDate.getTime();
//
//                    if (itemDateInMillis > versionDateInMillis) {
//                        Label lblDateTitle = JKText.getLblDk(new SimpleDateFormat("dd MMM yyyy - HH:mm").format(itemDate)
//                                + " - " + item.getTitle().toString(), JKText.FONT_B_XXXSM);
//                        Label lblDescription = JKText.getLblDk(item.getDescription().toString(), JKText.FONT_N_XXSM);
//                        lblDescription.setWrapText(true);
//
//                        VBox vb = getNewsVBox();
//                        vb.getChildren().addAll(lblDateTitle, lblDescription);
//                        itemsTemp.add(0, vb);
//                    }
//                }
//                if (itemsTemp.size() >= 5) {
//                    itemsLive = itemsTemp.subList(0, 5);
//                } else {
//                    itemsLive = itemsTemp;
//                }
//            }
//        } catch (RssParserException rpe) {
//            Logger.getLogger(JKioskLogin.class.getName()).log(Level.SEVERE, null, rpe);
//        } catch (IOException | ParseException ex) {
//            Logger.getLogger(JKioskLogin.class.getName()).log(Level.SEVERE, null, ex);
//        }
//
//        return itemsLive;
//    }
//
//        JKNews news = JKMedia.getJkNews();
//        if (news != null) {
//            List<JKNewsItem> itemList = news.getListItems();
//            for (JKNewsItem item : itemList) {
//                Label dateTitle = JKText.getLblDk(news.getReleaseDate() + " - " + item.getTitle(), JKText.FONT_B_XXXSM);
//                Label itemDescription = JKText.getLblDk(item.getDescription(), JKText.FONT_N_XXSM);
//                itemDescription.setWrapText(true);
//
//                VBox vb = getNewsVBox();
//                vb.getChildren().addAll(dateTitle, itemDescription);
//                itemsDemo.add(0, vb);
//            }
//        }
//    private VBox getNewsVBox() {
//        VBox vb = JKLayout.getVBoxLeft(0, JKLayout.spNum / 2);
//        vb.setMaxHeight(newsH - (JKLayout.spNum));
//        vb.setMinHeight(newsH - (JKLayout.spNum));
//        vb.setMaxWidth(325);
//        return vb;
//    }