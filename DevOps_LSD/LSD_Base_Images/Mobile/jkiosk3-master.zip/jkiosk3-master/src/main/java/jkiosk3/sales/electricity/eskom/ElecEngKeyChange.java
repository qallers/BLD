package jkiosk3.sales.electricity.eskom;

import aeonelectricity.ElectricityMeter;
import aeonelectricity.ElectricityVoucher;
import aeonprinting.AeonPrintJob;

import java.util.List;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MagCardPromptResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.MagCardData;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.PrintQueue;
import jkiosk3.printing.PrintUtil;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.electricity.ElecEnterMeter;
import jkiosk3.sales.electricity.ElecEnterMeterResult;
import jkiosk3.sales.electricity.ElecShareBtnsLessMore;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.sales.electricity.ElectricityUtil.EskomEngKeyChangeResult;
import jkiosk3.store.JKCardReader;
import jkiosk3.store.JKOptions;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.users.UserUtil;

/**
 * @author Valerie
 */
public class ElecEngKeyChange extends Region {

    private final static Logger logger = Logger.getLogger (ElecEngKeyChange.class.getName ());
    private final ElectricityProvider provider;
    private ElecEnterMeter gMeter;
    private String meterNum;
    private String sgcOld;
    private String sgcNew;
    private String krnOld;
    private String krnNew;
    private String tiOld;
    private String tiNew;
    private String ttOld;
    private String algOld;
    private TextField txtSGC;
    private TextField txtSGCNew;
    private TextField txtKRN;
    private TextField txtKRNNew;
    private TextField txtTI;
    private TextField txtTINew;
    private TextField txtTT;
    private TextField txtAlg;
    private boolean useMagData = false;

    public ElecEngKeyChange(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;
        getChildren ().add (getEngKeyChngLayout ());
    }

    private VBox getEngKeyChngLayout() {
        gMeter = new ElecEnterMeter (provider, ElectricityUtil.ELEC_ENG_KEY_CHANGE, new ElecEnterMeterResult () {
            @Override
            public void onDone() {
                if (gMeter.isMagEntry ()) {
                    useMagData = true;
                    txtSGC.setText ("TrackData");
                    txtSGC.setDisable (true);
                    txtKRN.setText ("TrackData");
                    txtKRN.setDisable (true);
                    txtTI.setText ("TrackData");
                    txtTI.setDisable (true);
                    txtTT.setText ("TrackData");
                    txtTT.setDisable (true);
                    txtAlg.setText ("TrackData");
                    txtAlg.setDisable (true);
                    System.out.println ("onDone : meter number entered : " + gMeter.getMeterNum ());
                    System.out.println ("onDone : did we read mag card? : " + gMeter.isMagEntry ());
                }
            }
        });
        VBox vbEngKeyChng = JKLayout.getVBox (0, JKLayout.spNum);
        vbEngKeyChng.getChildren ().addAll (gMeter, getEngKeyChngEntry (), getElecSaleCtrls ());
        return vbEngKeyChng;
    }

    private GridPane getEngKeyChngEntry() {

        Label lblOld = JKText.getLblDk ("Old", JKText.FONT_B_XSM);
        Label lblNew = JKText.getLblDk ("New", JKText.FONT_B_XSM);
        lblNew.setTranslateX (JKLayout.spNum);
        HBox hbHead = JKLayout.getHBoxLeft (0, JKLayout.sp);
        hbHead.getChildren ().addAll (lblOld, JKNode.getHSpacer (), lblNew, JKNode.getHSpacer ());

        Label lblSGC = JKText.getLblDk ("Supply Group Code (SGC)", JKText.FONT_B_XXSM);
        Label lblKRN = JKText.getLblDk ("Key Revision Number (KRN)", JKText.FONT_B_XXSM);
        Label lblTI = JKText.getLblDk ("Tariff Index (TI)", JKText.FONT_B_XXSM);
        Label lblTT = JKText.getLblDk ("Token Tech (TT)", JKText.FONT_B_XXSM);
        Label lblAlg = JKText.getLblDk ("Algorithm (ALG)", JKText.FONT_B_XXSM);

        txtSGC = new TextField ();
        txtSGC.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event t) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtSGC, "Enter Old SGC", "");
                }
            }
        });
        txtSGCNew = new TextField ();
        txtSGCNew.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event t) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtSGCNew, "Enter New SGC", "");
                }
            }
        });
        HBox hbSGC = JKLayout.getHBox (0, JKLayout.sp);
        hbSGC.getChildren ().addAll (txtSGC, txtSGCNew);

        txtKRN = new TextField ();
        txtKRN.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event t) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtKRN, "Enter Old KRN", "");
                }
            }
        });
        txtKRNNew = new TextField ();
        txtKRNNew.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event t) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtKRNNew, "Enter New KRN", "");
                }
            }
        });
        HBox hbKRN = JKLayout.getHBox (0, JKLayout.sp);
        hbKRN.getChildren ().addAll (txtKRN, txtKRNNew);

        txtTI = new TextField ();
        txtTI.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event t) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtTI, "Enter Old TI", "");
                }
            }
        });
        txtTINew = new TextField ();
        txtTINew.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event t) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtTINew, "Enter New TI", "");
                }
            }
        });
        HBox hbTI = JKLayout.getHBox (0, JKLayout.sp);
        hbTI.getChildren ().addAll (txtTI, txtTINew);
        //
        txtTT = new TextField ();
        txtTT.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event t) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtTT, "Enter Old TT", "");
                }
            }
        });
        TextField txtTTNew = new TextField ();
        txtTTNew.setVisible (false);
        HBox hbTT = JKLayout.getHBox (0, JKLayout.sp);
        hbTT.getChildren ().addAll (txtTT, txtTTNew);
        txtAlg = new TextField ();
        txtAlg.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event t) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtAlg, "Enter Old ALG", "");
                }
            }
        });
        TextField txtAlgNew = new TextField ();
        txtAlgNew.setVisible (false);
        HBox hbAlg = JKLayout.getHBox (0, JKLayout.sp);
        hbAlg.getChildren ().addAll (txtAlg, txtAlgNew);

        GridPane grid = JKLayout.getGridContent2Col (0.5, 0.5);

        grid.addRow (0, new Label (), hbHead);
        grid.addRow (1, lblSGC, hbSGC);
        grid.addRow (2, lblKRN, hbKRN);
        grid.addRow (3, lblTI, hbTI);
        grid.addRow (4, lblTT, hbTT);
        grid.addRow (5, lblAlg, hbAlg);

        return grid;
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        ElecShareBtnsLessMore btnsLessMore = new ElecShareBtnsLessMore ();

        btnsLessMore.getBtnAccept ().setDisable (false);
        btnsLessMore.getBtnAccept ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                if (validateInput ()) {
                    getEngKeyChangeResult ();
                }
            }
        });
        btnsLessMore.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });

        return btnsLessMore;
    }

    private void getEngKeyChangeResult() {
        ElectricityMeter meter = new ElectricityMeter ();
        if (gMeter.isMagEntry ()) {
            meter.setTrack2data (meterNum);
        } else {
            meter.setMeterNum (meterNum);
        }
        meter.setMeterSgc (sgcOld);
        meter.setMeterKrn (krnOld);
        meter.setMeterTi (tiOld);
        meter.setMeterTt (ttOld);
        meter.setMeterAlg (algOld);
        meter.setMeterNewSgc (sgcNew);
        meter.setMeterNewKrn (krnNew);
        meter.setMeterNewTi (tiNew);

        String transType = provider.getTransactionType ();
        ElectricityUtil.getEngKeyChangeVoucher (transType, "", meter, new EskomEngKeyChangeResult () {

            @Override
            public void eskomEngKeyChangeResult(ElectricityVoucher engKeyChangeVoucher) {
                if (engKeyChangeVoucher.isSuccess ()) {
                    SalesUtil.processElectricity (ElectricityUtil.ELEC_ENG_KEY_CHANGE, engKeyChangeVoucher, 0);

//                    int transRef = engKeyChangeVoucher.getTransRef();
//                    String desc = ElectricityUtil.ELEC_ENG_KEY_CHANGE + " " + engKeyChangeVoucher.getMeter().getMeterNum();
////                    AeonPrintJob apj = engKeyChangeVoucher.getPrintLines();
////                    AeonPrintJob apjm = engKeyChangeVoucher.getMerchantPrintLines();
//
////                    SalesUtil.processSoldItem(transRef, SaleType.ELECTRICITY.getDisplay(), desc, apj,
////                            0, false, "online", null);
//                    SalesUtil.processSoldItem(transRef, SaleType.ELECTRICITY.getDisplay(), desc,
//                            engKeyChangeVoucher.getPrintLines(), engKeyChangeVoucher.getMerchantPrintLines(), 0, false, "online", null);
////                    ElectricityUtil.printMerchantCopy(null, engKeyChangeVoucher, 0);
//                    // Merchant copy handled in SalesUtil.processSoldItem.
////                    PrintHandler.handleMerchantCopyPrint(apjm);
//
//                    final List<MagCardData> magList = ElectricityUtil.getMagCardTokens(engKeyChangeVoucher);
//                    final List<MagCardData> cardUpdateList = ElectricityUtil.getMagCardUpdateByVoucher(engKeyChangeVoucher);
//
//                    if (JKPrintOptions.getPrintOptions().isPrintImmediately()) {
//                        if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
//                            JKiosk3.getPrintPreview().showPrintPreview("Electricity Engineering Key Change", engKeyChangeVoucher.getPrintLines(),
//                                    PrintPreview.PRN_OK, new PrintPreviewResult() {
//                                @Override
//                                public void onOk() {
//                                    writeMagCards(cardUpdateList, magList, true);
//                                }
//
//                                @Override
//                                public void onCancel() {
//                                    //
//                                }
//                            });
//                        } else {
//                            PrintUtil.sendToPrinter(engKeyChangeVoucher.getPrintLines());
//                            writeMagCards(cardUpdateList, magList, true);
//                        }
//                    } else {
//                        PrintQueue.addItem(Integer.toString(transRef), engKeyChangeVoucher.getPrintLines());
//                        PrintQueue.addMagCards(magList);
//                        writeMagCards(cardUpdateList, magList, false);
//                    }

                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Engineering Key Change Voucher Error",
                            !engKeyChangeVoucher.getAeonErrorText ().isEmpty () ?
                                    "A" + engKeyChangeVoucher.getAeonErrorCode () + " - " + engKeyChangeVoucher.getAeonErrorText () :
                                    "B" + engKeyChangeVoucher.getErrorCode () + " - " + engKeyChangeVoucher.getErrorText (), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    ElectricityUtil.resetElectricity ();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });
    }

//    private void writeMagCards(final List<MagCardData> cardUpdates, final List<MagCardData> magTokens, final boolean isWriteAll) {
//        if (JKCardReader.getCardReaderConfig().isMagCardWrite()) {
//            PrintUtil.writeMagCardUpdate(cardUpdates, new MagCardPromptResult() {
//                @Override
//                public void onDone() {
//                    if (isWriteAll) {
//                        PrintUtil.writeMagCardTokens(magTokens, null);
//                    }
//                }
//            });
//        } else {
//            JKiosk3.getMsgBox().showMsgBox("Unable to write Mag Cards", "Mag Card Read/Write not configured in Setup", null);
//        }
//    }

    private boolean validateInput() {
        meterNum = gMeter.getMeterNum ().trim ();
        if ((meterNum.equals ("") || meterNum == null)
                || (txtSGC.getText () == null || txtSGC.getText ().trim ().isEmpty ())
                || (txtKRN.getText () == null || txtKRN.getText ().trim ().isEmpty ())
                || (txtTI.getText () == null || txtTI.getText ().trim ().isEmpty ())
                || (txtTT.getText () == null || txtTT.getText ().trim ().isEmpty ())
                || (txtAlg.getText () == null || txtAlg.getText ().trim ().isEmpty ())
                || (txtSGCNew.getText () == null || txtSGCNew.getText ().trim ().isEmpty ())
                || (txtKRNNew.getText () == null || txtKRNNew.getText ().trim ().isEmpty ())
                || (txtTINew.getText () == null || txtTINew.getText ().trim ().isEmpty ())) {
            JKiosk3.getMsgBox ().showMsgBox ("Invalid Entry", "All fields must be completed", null);
            return false;
        } else {
            if (useMagData) {
                sgcNew = txtSGCNew.getText ().trim ();
                krnNew = txtKRNNew.getText ().trim ();
                tiNew = txtTINew.getText ().trim ();
            } else {
                sgcOld = txtSGC.getText ().trim ();
                krnOld = txtKRN.getText ().trim ();
                tiOld = txtTI.getText ().trim ();
                ttOld = txtTT.getText ().trim ();
                algOld = txtAlg.getText ().trim ();
                sgcNew = txtSGCNew.getText ().trim ();
                krnNew = txtKRNNew.getText ().trim ();
                tiNew = txtTINew.getText ().trim ();
            }
//            sgcOld = txtSGC.getText().trim();
//            krnOld = txtKRN.getText().trim();
//            tiOld = txtTI.getText().trim();
//            ttOld = txtTT.getText().trim();
//            algOld = txtAlg.getText().trim();
//            sgcNew = txtSGCNew.getText().trim();
//            krnNew = txtKRNNew.getText().trim();
//            tiNew = txtTINew.getText().trim();
        }
        return true;
    }
}
