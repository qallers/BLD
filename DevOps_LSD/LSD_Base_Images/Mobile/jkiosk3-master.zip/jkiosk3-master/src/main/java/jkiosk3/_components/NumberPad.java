package jkiosk3._components;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputControl;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;

/**
 * @author Val
 */
public class NumberPad extends Region {

    private final static Logger logger = Logger.getLogger(NumberPad.class.getName());

    private Label lbl;
    private TextInputControl inputCtrl;
    private TextInputControl destination;
    private TextField txtFld;
    private PasswordField pwdFld;
    private NumberPadResult result;
    private boolean isCurrency;

    public NumberPad() {
        getChildren().add(getNumPadStack());
    }

    private StackPane getNumPadStack() {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getNumPadGrp());

        return stack;
    }

    private Group getNumPadGrp() {
        Group grp = new Group();

        double w = 250;
        double h = 450;

        Rectangle rec = new Rectangle(w, h);

        VBox vbox = JKLayout.getVBox(JKLayout.sp, (2 * JKLayout.spNum));

        lbl = JKText.getLblDk("", JKText.FONT_B_XSM);

        txtFld = new TextField();
        txtFld.setMaxWidth(w - (4 * JKLayout.sp));
        txtFld.setMinWidth(w - (4 * JKLayout.sp));
        txtFld.setPromptText("enter number");
        txtFld.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent e) {
                if (e.getCode() == KeyCode.ENTER) {
                    getEnterBtnEvent();
                }
            }
        });

        pwdFld = new PasswordField();
        pwdFld.setMaxWidth(w - (4 * JKLayout.sp));
        pwdFld.setMinWidth(w - (4 * JKLayout.sp));
        pwdFld.setPromptText("enter password");
        pwdFld.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent e) {
                if (e.getCode() == KeyCode.ENTER) {
                    getEnterBtnEvent();
                }
            }
        });

        StackPane stack = new StackPane();
        stack.getChildren().addAll(txtFld, pwdFld);

        Image imgX = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/cross.png"));
        Image imgTick = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/tick.png"));
        ImageView imgCancel = new ImageView(imgX);
        ImageView imgEnter = new ImageView(imgTick);

        Button btnCancel = JKNode.getBtnNum("");
        btnCancel.setGraphic(imgCancel);
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setVisible(false);
                toBack();
            }
        });

        Button btnEnter = new Button("Enter");
        btnEnter.setFont(JKText.FONT_B_XSM);
        btnEnter.setGraphic(imgEnter);
        btnEnter.setPrefSize(((2 * JKLayout.btnNumW) + JKLayout.spNum), JKLayout.btnNumH);
        btnEnter.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                getEnterBtnEvent();
            }
        });

        HBox hb = JKLayout.getHBox(0, JKLayout.spNum);
        hb.getChildren().addAll(btnCancel, btnEnter);

        TilePane tile = JKLayout.getTile(15, 5, 5, 3);
        tile.setPrefWidth(w - (2 * JKLayout.sp));
        tile.getChildren().addAll(getNumBtnList());

        Separator sep = new Separator();
        sep.setMaxWidth(w - (4 * JKLayout.sp));

        vbox.getChildren().addAll(lbl, stack, hb, sep, tile);

        grp.getChildren().addAll(rec, vbox);

        return grp;
    }

    private List<Button> getNumBtnList() {
        List<Button> btnList = new ArrayList<>();

        String[] nums = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "."};

        for (String s : nums) {
            Button btn = JKNode.getBtnNum(s);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    inputCtrl.appendText(((Button) e.getSource()).getText());
                }
            });
            btnList.add(btn);
        }

        Button btnBackSp = JKNode.getBtnNum("←");
        btnBackSp.setFont(JKText.FONT_LUCIDA_UNI_LG);
        btnBackSp.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                int end = inputCtrl.getText().length() - 1;
                if (end >= 0) {
                    inputCtrl.setText(inputCtrl.getText(0, end));
                }
            }
        });
        btnList.add(11, btnBackSp);

        return btnList;
    }

    private void getEnterBtnEvent() {
        setVisible(false);
        toBack();
        String inputText = inputCtrl.getText();
        if (isCurrency) {
            if (isValidAmount(inputCtrl.getText(), (TextField) inputCtrl)) {
                destination.setText(inputText);
                if (result != null) {
                    result.onDone(inputText);
                }
            }
        } else {
            destination.setText(inputText);
            if (result != null) {
                result.onDone(inputText);
            }
        }
//        // PREVIOUS WORKING CODE
//        destination.setText(inputCtrl.getText());
//        if (result != null) {
//            result.onDone(inputCtrl.getText());
//        }
    }

    private void setInputControl(TextInputControl control) {
        this.inputCtrl = control;
        if (control instanceof PasswordField) {
            inputCtrl = pwdFld;
            pwdFld.setVisible(true);
            txtFld.setVisible(false);
        } else if (control instanceof TextField) {
            inputCtrl = txtFld;
            pwdFld.setVisible(false);
            txtFld.setVisible(true);
        }
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                inputCtrl.requestFocus();
            }
        });
    }

    public void hideNumPad() {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                setVisible(false);
                toBack();
            }
        });
    }

    public void showNumPad(TextInputControl inputFld, String label, String defTxt) {
        showNumPad(inputFld, label, defTxt, null);
    }

    public void showNumPad(TextInputControl inputFld, String label, String defTxt, NumberPadResult res) {
        showNumPad(false, inputFld, label, defTxt, res);
//        // ORIGINAL WORKING CODE
//        this.result = res;
//        destination = inputFld;
//        setInputControl(inputFld);
//        lbl.setText(label);
//        inputCtrl.setText(defTxt);
//        if (defTxt.equals("0")) {
//            inputCtrl.setText("");
//        }
//        this.setVisible(true);
//        this.toFront();
    }

    public void showNumPad(boolean isCurrency, TextInputControl inputFld, String label, String defTxt, NumberPadResult res) {
        this.isCurrency = isCurrency;
        this.result = res;
        destination = inputFld;

        setInputControl(inputFld);
        lbl.setText(label);
        inputCtrl.setText(defTxt);

        if (defTxt.equals("0")) {
            inputCtrl.setText("");
        }
        this.setVisible(true);
        this.toFront();
    }

    private boolean isValidAmount(String value, TextField txtfld) {
        try {
            // ^(0|[1-9]\d*)+(?:\.\d{0,2})?$ - paste this into 
            // https://www.regexpal.com/
            // and enter required values.  Java adds additional 'escape' characters.
            Pattern dec = Pattern.compile("^(0|[1-9]\\d*)+(?:\\.\\d{0,2})?$");
            Matcher matchDec = dec.matcher(value);
            if (matchDec.matches()) {
                // not used - just checks if the value can be successfully parsed to a Double value
                double amountPaid = Double.parseDouble(value);
                return true;
            } else {
                JKiosk3.getMsgBox().showMsgBox("Amount", "Amount must be numeric only,\n\nand not contain more than 2 decimal places", null);
                if (txtfld != null) {
                    txtfld.clear();
                }
                return false;
            }
        } catch (NumberFormatException nfe) {
            logger.log(Level.SEVERE, nfe.getMessage(), nfe);
            JKiosk3.getMsgBox().showMsgBox("Invalid Amount", "Amount must be a valid number", null);
            if (txtfld != null) {
                txtfld.clear();
            }
            return false;
        }
    }


    @Override
    public String toString() {
        return "NumberPad{" +
                "lbl=" + lbl +
                ", inputCtrl=" + inputCtrl +
                ", destination=" + destination +
                ", txtFld=" + txtFld +
                ", pwdFld=" + pwdFld +
                ", result=" + result +
                ", isCurrency=" + isCurrency +
                '}';
    }
}
