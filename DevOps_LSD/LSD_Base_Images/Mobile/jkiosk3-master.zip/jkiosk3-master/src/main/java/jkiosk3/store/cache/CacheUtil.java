package jkiosk3.store.cache;

import aeonairtime.AirtimeConnection;
import aeonairtime.AirtimeManufacturer;
import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.Provider;
import aeoncoach.CoachCarriersList;
import aeoncoach.CoachConnection;
import aeoncoach.CoachListItemResp;
import aeonticketpros.TicketProAllowedProdListResp;
import aeonticketpros.TicketProsConnection;
import aeonticketpros.bus.TicketProBusRouteCodeList;
import aeonticketpros.bus.TicketProConnectionBus;
import aeontopup.TopupBundleProductList;
import aeontopup.TopupConnection;
import aeonusers.User;
import aeonusers.UserConnection;
import aeonvarivouchers.VDVSupplierListResp;
import aeonvarivouchers.VariableVoucherConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.concurrent.Task;
import jkiosk3.JKiosk3;
import jkiosk3.Version;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.billpay.BillPayUtilConnect;
import jkiosk3.sales.billpay.BillPayUtilConnect.ListBillPaymentProvidersResult;
import jkiosk3.sales.chat4change.Chat4ChangeUtil;
import jkiosk3.sales.coaches.CoachUtil;
import jkiosk3.sales.ticketpro.TicketProUtil;
import jkiosk3.sales.ticketpro.TicketProUtil.TicketProAllowedProdListResult;
import jkiosk3.sales.ticketpro.TicketProUtilBus;
import jkiosk3.sales.ticketpro.TicketProUtilBus.TicketProBusRouteCodeResult;
import jkiosk3.sales.topups.AirtimeUtil;
import jkiosk3.sales.topups.TopupProvider;
import jkiosk3.sales.vouchers.VoucherUtil;
import jkiosk3.sales.vouchers.VoucherUtil.AirtimeManufacturerResult;
import jkiosk3.store.JKSystem;
import jkiosk3.users.UserUtil;

public class CacheUtil {

    private final static Logger logger = Logger.getLogger(CacheUtil.class.getName());

    private final static int DEVICE_ID = JKSystem.getSystemConfig().getDeviceId();
    private final static String DEVICE_SERIAL = JKSystem.getSystemConfig().getSerial();
    //
    public final static String SCENE_SALES = "SceneSales";
    public final static String SCENE_SETUP = "SceneSetup";
    //
    private static String errorMsg = "An unknown error occurred";
    private static int countdownSec;
    private static boolean updateNow;

    /* ***************** */
 /* Transaction Types */
 /* ***************** */
    private static User getLoggedInUserCache(User cacheUser) throws RuntimeException {
        UserConnection uc = UserUtil.getUserConnect();
        User user = null;
        String version = Version.getSoftwareVersion() + Version.getVersionNum();

        try {
            user = uc.login(cacheUser.getUserPin(), DEVICE_ID, DEVICE_SERIAL, version);

        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("User Login Error", t);
        } finally {
            if (uc != null) {
                uc.disconnect();
            }
        }
        return user;
    }

    public static void getLoggedInUserCache(final User cacheUser, final UserUtil.LoggedInUserResult result) {

        if (updateNow) {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getBusy().showBusy("Transaction Cache in progress");
                }
            });
            System.out.println("LoggedInUserCache - yes, updateNow is true");
        } else {
            System.out.println("LoggedInUserCache - no, updateNow is NOT true");
        }

        final Task<User> taskLogin = new Task<User>() {
            @Override
            protected User call() throws Exception {
                return getLoggedInUserCache(cacheUser);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.loggedInUserResult(getValue());
            }

            @Override
            protected void cancelled() {
                JKiosk3.getBusy().hideBusy();
            }

            @Override
            protected void failed() {
                JKiosk3.getBusy().hideBusy();
            }
        };
        startCountdown(taskLogin);
    }

    /* **************** */
 /* Voucher Products */
 /* **************** */
    private static List<AirtimeManufacturer> getOnlineVouchersList(User cacheUser) throws RuntimeException {
        AirtimeConnection ac = VoucherUtil.getAirtimeConnect();
        List<AirtimeManufacturer> listProviders = new ArrayList<>();
        boolean isAMS = cacheUser.getTransTypes().contains("VoucherAMS");
        try {
            if (ac.login(cacheUser.getUserPin(), DEVICE_ID, DEVICE_SERIAL, isAMS)) {
                listProviders = ac.getVoucherList();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Product List Error", t);
        } finally {
            if (ac != null) {
                ac.disconnect();
            }
        }
        return listProviders;
    }

    public static void getVoucherProvidersListCache(final User cacheUser, final AirtimeManufacturerResult result) {

//        JKiosk3.getBusy().showBusy("Vouchers List Cache in progress");
        if (updateNow) {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getBusy().showBusy("Vouchers List Cache in progress");
                }
            });
            System.out.println("VoucherProviderListCache - yes, updateNow is true");
        } else {
            System.out.println("VoucherProviderListCache - no, updateNow is NOT true");
        }

        final Task<List<AirtimeManufacturer>> taskVouchList = new Task<List<AirtimeManufacturer>>() {
            @Override
            protected List<AirtimeManufacturer> call() throws Exception {
                return getOnlineVouchersList(cacheUser);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.airtimeManufacturerResult(getValue());
            }

            @Override
            protected void cancelled() {
                JKiosk3.getBusy().hideBusy();
            }

            @Override
            protected void failed() {
                JKiosk3.getBusy().hideBusy();
            }
        };
        startCountdown(taskVouchList);
    }

    /* ************* */
 /* Topup Bundles */
 /* ************* */
    private static TopupBundleProductList getOnlineTopupBundleProductList(User cacheUser, TopupProvider provider) throws RuntimeException {
        TopupConnection tc = AirtimeUtil.getTopupConnect();
        TopupBundleProductList topupBundleList = new TopupBundleProductList();
        try {
            if (tc.login(cacheUser.getUserPin(), DEVICE_ID, DEVICE_SERIAL, provider.getName())) {
                topupBundleList = tc.getTopupBundleProductList(provider.getName());
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Topup Bundle Products Error", t);
        } finally {
            if (tc != null) {
                tc.disconnect();
            }
        }
        return topupBundleList;
    }

    public static void getTopupBundleProductCache(final User cacheUser, final TopupProvider provider,
            final AirtimeUtil.TopupBundleProductListResult result) {

        if (updateNow) {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getBusy().showBusy("Topup Bundles Cache in progress");
                }
            });
            System.out.println("TopupBundleProductCache - yes, updateNow is true");
        } else {
            System.out.println("TopupBundleProductCache - no, updateNow is NOT true");
        }

        final Task<TopupBundleProductList> taskTopBundle = new Task<TopupBundleProductList>() {
            @Override
            protected TopupBundleProductList call() throws Exception {
                return getOnlineTopupBundleProductList(cacheUser, provider);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.topupBundleProductListResult(getValue());
            }

            @Override
            protected void cancelled() {
                JKiosk3.getBusy().hideBusy();
            }

            @Override
            protected void failed() {
                JKiosk3.getBusy().hideBusy();
            }
        };
        startCountdown(taskTopBundle);
    }

    /* *********************** */
 /* Chat-4-Change Suppliers */
 /* *********************** */
    private static VDVSupplierListResp getC4CSupplierList(User cacheUser) throws RuntimeException {
        VariableVoucherConnection c4cConn = Chat4ChangeUtil.getChat4ChangeConnect();
        VDVSupplierListResp suppliers = new VDVSupplierListResp();
        try {
            if (c4cConn.login(cacheUser.getUserPin(), DEVICE_ID, DEVICE_SERIAL)) {
                String ref = SalesUtil.getUniqueRef();
                suppliers = c4cConn.getListSuppliers(ref);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Chat 4 Change Supplier List Error", t);
        } finally {
            if (c4cConn != null) {
                c4cConn.disconnect();
            }
        }
        return suppliers;
    }

    public static void getC4CSupplierListCache(final User cacheUser, final Chat4ChangeUtil.C4CSupplierResult result) {

        if (updateNow) {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getBusy().showBusy("Chat-4-Change Suppliers Cache in progress");
                }
            });
            System.out.println("C4CSupplierListCache - yes, updateNow is true");
        } else {
            System.out.println("C4CSupplierListCache - no, updateNow is NOT true");
        }

        final Task<VDVSupplierListResp> taskC4CSupplier = new Task<VDVSupplierListResp>() {
            @Override
            protected VDVSupplierListResp call() throws Exception {
                return getC4CSupplierList(cacheUser);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.c4cSupplierListResult(getValue());
            }

            @Override
            protected void cancelled() {
                JKiosk3.getBusy().hideBusy();
            }

            @Override
            protected void failed() {
                JKiosk3.getBusy().hideBusy();
            }
        };
        startCountdown(taskC4CSupplier);
    }

    /* ********************* */
 /* Bill Payment Products */
 /* ********************* */
    private static List<Provider> getOnlineBillPaymentProviderList(User cacheUser) throws RuntimeException {
        BillPaymentConnection bpc = BillPayUtilConnect.getBillPaymentConnect();
        List<Provider> listProviders = new ArrayList<>();
        try {
            if (bpc.login(cacheUser.getUserPin(), DEVICE_ID, DEVICE_SERIAL, BillPaymentConnection.BILLPAY_VAS_PRODUCTS)) {
                listProviders = bpc.getProductList();
            }

        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Product List Error", t);
        } finally {
            if (bpc != null) {
                bpc.disconnect();
            }
        }
        return listProviders;
    }

    public static void getBillPaymentProviderListCache(final User cacheUser, final ListBillPaymentProvidersResult bpList) {

        if (updateNow) {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getBusy().showBusy("Bill Payment Providers Cache in progress");
                }
            });
            System.out.println("BillPaymentProviderListCache - yes, updateNow is true");
        } else {
            System.out.println("BillPaymentProviderListCache - no, updateNow is NOT true");
        }

        final Task<List<Provider>> taskBillPayProv = new Task<List<Provider>>() {
            @Override
            protected List<Provider> call() throws Exception {
                return getOnlineBillPaymentProviderList(cacheUser);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                bpList.listBillPayProviderResult(getValue());
            }

            @Override
            protected void cancelled() {
                JKiosk3.getBusy().hideBusy();
            }

            @Override
            protected void failed() {
                JKiosk3.getBusy().hideBusy();
            }
        };
        startCountdown(taskBillPayProv);
    }

    /* ********************* */
    /* Coach Carriers List */
    /* ********************* */
    private static CoachCarriersList getCoachCarriersList(User cacheUser) throws RuntimeException {
        CoachConnection cConn = CoachUtil.getCoachConnection();
        CoachCarriersList listCarriers = null;
        try {
            if (cConn.login(cacheUser.getUserPin(), DEVICE_ID, DEVICE_SERIAL, "")) {
                listCarriers = cConn.getCoachCarrierList();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Coach Carriers List Error", t);
        } finally {
            if (cConn != null) {
                cConn.disconnect();
            }
        }
        return listCarriers;
    }

    public static void getCoachCarriersListCache(final User cacheUser, final CoachUtil.CoachCarriersListResult carriersListResult) {

        if (updateNow) {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getBusy().showBusy("Coach Carriers List Cache in progress");
                }
            });
            System.out.println("CoachCarriersListCache - yes, updateNow is true");
        } else {
            System.out.println("CoachCarriersListCache - no, updateNow is NOT true");
        }

        final Task<CoachCarriersList> taskCoachCarr = new Task<CoachCarriersList>() {
            @Override
            protected CoachCarriersList call() throws Exception {
                return getCoachCarriersList(cacheUser);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                carriersListResult.coachCarriersListResult(getValue());
            }

            @Override
            protected void cancelled() {
                JKiosk3.getBusy().hideBusy();
            }

            @Override
            protected void failed() {
                JKiosk3.getBusy().hideBusy();
            }
        };
        startCountdown(taskCoachCarr);
    }

    /* ********************* */
    /* Coach Carriers List */
    /* ********************* */
    private static CoachListItemResp getCoachCitiesList(User cacheUser) throws RuntimeException {
        CoachConnection cConn = CoachUtil.getCoachConnection();
        CoachListItemResp listCities = null;
        try {
            if (cConn.login(cacheUser.getUserPin(), DEVICE_ID, DEVICE_SERIAL, "")) {
                listCities = cConn.getCoachCityList();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Coach Cities List Error", t);
        } finally {
            if (cConn != null) {
                cConn.disconnect();
            }
        }
        return listCities;
    }

    public static void getCoachCitiesListCache(final User cacheUser, final CoachUtil.CoachCityListResult citiesListResult) {

        if (updateNow) {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getBusy().showBusy("Coach Cities List Cache in progress");
                }
            });
            System.out.println("CoachCitiesListCache - yes, updateNow is true");
        } else {
            System.out.println("CoachCitiesListCache - no, updateNow is NOT true");
        }

        final Task<CoachListItemResp> taskCoachCity = new Task<CoachListItemResp>() {
            @Override
            protected CoachListItemResp call() throws Exception {
                return getCoachCitiesList(cacheUser);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                citiesListResult.coachCityListResult(getValue());
            }

            @Override
            protected void cancelled() {
                JKiosk3.getBusy().hideBusy();
            }

            @Override
            protected void failed() {
                JKiosk3.getBusy().hideBusy();
            }
        };
        startCountdown(taskCoachCity);
    }

    /* ********************* */
 /* TicketPro Allowed Products List */
 /* ********************* */
    private static TicketProAllowedProdListResp getTicketProAllowedProdList(User cacheUser) throws RuntimeException {
        TicketProsConnection tpconn = TicketProUtil.getTpConn();
        TicketProAllowedProdListResp allowedProds = null;
        try {
            if (tpconn.login(cacheUser.getUserPin(), DEVICE_ID, DEVICE_SERIAL)) {
                allowedProds = tpconn.getAllowedProducts();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("TicketPro Allowed Product List Error", t);
        } finally {
            if (tpconn != null) {
                tpconn.disconnect();
            }
        }
        return allowedProds;
    }

    public static void getTicketProAllowedProdList(final User cacheUser, final TicketProAllowedProdListResult prodListRes) {

        if (updateNow) {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getBusy().showBusy("TicketPro Allowed Product List Cache in progress");
                }
            });
            System.out.println("TicketProAllowedProductListCache - yes, updateNow is true");
        } else {
            System.out.println("TicketProAllowedProductListCache - no, updateNow is NOT true");
        }

        final Task<TicketProAllowedProdListResp> taskTPAllowedList = new Task<TicketProAllowedProdListResp>() {
            @Override
            protected TicketProAllowedProdListResp call() throws Exception {
                return getTicketProAllowedProdList(cacheUser);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                prodListRes.tpAllowedProdListResult(getValue());
            }

            @Override
            protected void cancelled() {
                JKiosk3.getBusy().hideBusy();
            }

            @Override
            protected void failed() {
                JKiosk3.getBusy().hideBusy();
            }
        };
        startCountdown(taskTPAllowedList);
    }

    /* ********************* */
 /* Putco Route Codes List */
 /* ********************** */
    private static TicketProBusRouteCodeList getPutcoRouteCodeList(User cacheUser) throws RuntimeException {
        TicketProConnectionBus tpconn = TicketProUtilBus.getTicketProConnectionBus();
        TicketProBusRouteCodeList listRoutes = null;
        try {
            if (tpconn.login(cacheUser.getUserPin(), DEVICE_ID, DEVICE_SERIAL)) {
                listRoutes = tpconn.getBusRouteCodesList();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Route Code List Error", t);
        } finally {
            if (tpconn != null) {
                tpconn.disconnect();
            }
        }
        return listRoutes;
    }

    public static void getPutcoRouteCodeListCache(final User cacheUser, final TicketProBusRouteCodeResult routeCodeRes) {
        if (updateNow) {
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getBusy().showBusy("Putco Route Code List Cache in progress");
                }
            });
            System.out.println("PutcoRouteCodeListCache - yes, updateNow is true");
        } else {
            System.out.println("PutcoRouteCodeListCache - no, updateNow is NOT true");
        }

        final Task<TicketProBusRouteCodeList> taskPutcoRouteList = new Task<TicketProBusRouteCodeList>() {
            @Override
            protected TicketProBusRouteCodeList call() throws Exception {
                return getPutcoRouteCodeList(cacheUser);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                routeCodeRes.tpBusRouteCodeResult(getValue());
            }

            @Override
            protected void cancelled() {
                JKiosk3.getBusy().hideBusy();
            }

            @Override
            protected void failed() {
                JKiosk3.getBusy().hideBusy();
            }
        };
        startCountdown(taskPutcoRouteList);
    }

    /* *********************** */
 /* Countdown for all tasks */
 /* *********************** */
    private static void startCountdown(final Task task) {
        countdownSec = 60;
        final ScheduledExecutorService schedCountdown = Executors.newSingleThreadScheduledExecutor();
        schedCountdown.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                try {
                    new Thread(task).start();
                    countdownSec--;
                    if (task.isDone()) {
                        schedCountdown.shutdown();
                        task.cancel();
                    } else if (task.isCancelled()) {
                        logger.info(" >>> task is cancelled <<<");
                    } else if (countdownSec <= 0) {
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                if (task.isRunning()) {
                                    task.cancel();
                                }
                                logger.info(" >>> countdown is zero <<<");
                            }
                        });
                    }
                } catch (Throwable t) {
                    logger.log(Level.SEVERE, " >>> Failed to process countdown <<< ", t);
                } finally {
                    //
                }
            }
        }, 0, 1, TimeUnit.SECONDS);
    }

    public static void setUpdateNow(boolean updateNow) {
        CacheUtil.updateNow = updateNow;
    }
}
