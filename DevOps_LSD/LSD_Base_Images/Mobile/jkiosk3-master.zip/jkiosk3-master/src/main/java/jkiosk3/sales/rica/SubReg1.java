package jkiosk3.sales.rica;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;

/**
 *
 * @author Val
 */
public class SubReg1 extends Region {

    private final double sp = JKLayout.sp;
    private final double w = JKLayout.contentW;
    private ToggleGroup toggleProviders;
    private ToggleButton toggleNetwork;

    public SubReg1() {
        setId(SubAll.REG_PG_1);

        getChildren().add(getSubPg1());
    }

    private VBox getSubPg1() {
        VBox vb = JKLayout.getVBoxLeft(0, sp);
        vb.setPrefWidth(w - (2 * sp));

        Label lblNewOwner = JKText.getLblDk("New Owner", JKText.FONT_B_SM);

        Label lblNetwork = JKText.getLblDk("Network", JKText.FONT_B_SM);

        vb.getChildren().addAll(lblNewOwner, JKNode.createContentSep(),
                lblNetwork, getNetworkToggles());

        return vb;
    }

    private HBox getNetworkToggles() {
        HBox hbNetwork = JKLayout.getHBox(0, sp);
        
        final Map<String, String> mapNetworks = new LinkedHashMap<>();
        mapNetworks.put("CellC", "CellC");
        mapNetworks.put("MTN", "MTN");
        mapNetworks.put("TelkomMobile", "Telkom");
        mapNetworks.put("VirginMobile", "Virgin");
        mapNetworks.put("Vodacom", "Vodacom");

        toggleProviders = new ToggleGroup();

        List<ToggleButton> toggleList = new ArrayList<>();

        double togW = (((w - (1 * sp)) / 5) - sp);
        double togH = 65;

        for (final String k : mapNetworks.keySet()) {
            toggleNetwork = new ToggleButton();
            toggleNetwork.setMaxSize(togW, togH);
            toggleNetwork.setMinSize(togW, togH);

            ImageView imgNetwork = JKNode.getJKImageViewProvider("prov_" + k + ".png");
            imgNetwork.setFitWidth(togW - 4);
            imgNetwork.setFitHeight(togH - 4);
            imgNetwork.setPreserveRatio(true);

            toggleNetwork.setGraphic(imgNetwork);
            toggleNetwork.getStyleClass().add("prov_" + k + "_fix");
            toggleNetwork.getStyleClass().add("toggle-button");
            toggleNetwork.setToggleGroup(toggleProviders);
            toggleNetwork.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    toggleNetwork.setId(mapNetworks.get(k));
                }
            });
            toggleList.add(toggleNetwork);
        }

        hbNetwork.getChildren().addAll(toggleList);

        return hbNetwork;
    }

    public ToggleGroup getToggleProviders() {
        return toggleProviders;
    }

    public ToggleButton getToggleNetwork() {
        return toggleNetwork;
    }

    //
    public boolean validatePg1() {
        boolean validPg1 = false;
        if (toggleProviders.getSelectedToggle() == null) {
            validPg1 = false;
            JKiosk3.getMsgBox().showMsgBox("Registration error", "Please select a Network provider", null);
        } else {
            validPg1 = true;
        }
        return validPg1;
    }
}
