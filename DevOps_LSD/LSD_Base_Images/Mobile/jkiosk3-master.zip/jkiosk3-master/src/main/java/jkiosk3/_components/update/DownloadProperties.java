package jkiosk3._components.update;

/**
 *
 * @author valeriew
 */
public class DownloadProperties {

    private final String title;
    private final String url;
    private final String fileDestination;
    private final String installDestination;

    /**
     * This method sets the requirements for downloading, saving and unpacking a
     * file from a server.
     *
     * @param title the title to be shown on the download view
     * @param url the URL of the file to be retrieved from the server
     * @param fileDestination the local folder in which to save the downloaded
     * file
     * @param installDestination the local folder in which to install the
     * downloaded file
     */
    public DownloadProperties(String title, String url, String fileDestination, String installDestination) {
        this.title = title;
        this.url = url;
        this.fileDestination = fileDestination;
        this.installDestination = installDestination;
    }

//        public DownloadProperties(String title, String url, String fileDestination) {
//            this(title, url, fileDestination, null);
//        }
    public String getTitle() {
        return title;
    }

    public String getUrl() {
        return url;
    }

    public String getFileDestination() {
        return fileDestination;
    }

    public String getInstallDestination() {
        return installDestination;
    }
}
