package jkiosk3.setup;

import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.printing.cashdrawer.CashDrawerWinHandler;
import jkiosk3.printing.cashdrawer.CashDrawerWindows;
import jkiosk3.printing.PrintClient;
import jkiosk3.store.JKCashDrawer;
import jkiosk3.store.JKOptions;
import jkiosk3.store.JKPrinter;
import jkiosk3.store.JKSalesOptions;

/**
 *
 * @author Val
 */
public class SetupCashDrawer extends Region {

    private final static double CONTENT_WIDTH = JKLayout.contentW;
    private RadioButton radDirect;
    private RadioButton radOpos;
    private RadioButton radIo;
    private Label lblDeviceName;
    private TextField txtDeviceName;
    private ComboBox chcPort;
    private ComboBox chcBaud;
    private CheckBox chkFlowCon;
    private ComboBox comCDWin;
    private GridPane gridSerial;
    private GridPane gridDirect;
    private GridPane gridWindows;

    public SetupCashDrawer() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getCashDrawerEntry());
        vb.getChildren().add(getControls());

        setCashDrawerTypeView();
        
        updateTestBtnState();

        getChildren().add(vb);
    }

    private VBox getCashDrawerEntry() {

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);

        VBox vbHead = JKNode.getPageHeadVB("Cash Drawer");

        gridSerial = getCashDrawerSerial();
        gridDirect = getCashDrawerDirect();
        gridWindows = getCashDrawerEntryWin();

        vb.getChildren().addAll(vbHead, gridSerial, gridDirect, gridWindows);

        return vb;
    }

    private GridPane getCashDrawerSerial() {
        GridPane grid = JKLayout.getContentGridInner2Col(0.25, 0.75);

        Label lblPrintSer = JKText.getLblDk("If Default Printer is set to 'Other Printer'", JKText.FONT_B_XSM);

        lblDeviceName = JKText.getLblDk("Device Name", JKText.FONT_B_XSM);
        lblDeviceName.setMinWidth(JKLayout.btnSmW);

        ToggleGroup toggle = new ToggleGroup();

        radDirect = new RadioButton("Direct");
        radDirect.setToggleGroup(toggle);
        radDirect.setSelected(JKCashDrawer.getCashDrawerConfig().isCashDrawerDirect());
        radDirect.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setCashDrawerTypeView();
            }
        });

        radOpos = new RadioButton("OPOS");
        radOpos.setToggleGroup(toggle);
        radOpos.setSelected(JKCashDrawer.getCashDrawerConfig().isCashDrawerOpos());
        radOpos.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setCashDrawerTypeView();
            }
        });

        radIo = new RadioButton("P-Tech");
        radIo.setToggleGroup(toggle);
        radIo.setSelected(JKCashDrawer.getCashDrawerConfig().isCashDrawerIo());
        radIo.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setCashDrawerTypeView();
            }
        });

        HBox hbCashDrawerType = JKLayout.getHBox(0, JKLayout.sp);
        hbCashDrawerType.getChildren().addAll(radDirect, JKNode.getHSpacer(), radOpos, JKNode.getHSpacer(), radIo);

        txtDeviceName = new TextField();
        txtDeviceName.setText(JKCashDrawer.getCashDrawerConfig().getCashDrawerName());
        txtDeviceName.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtDeviceName, "Cash Drawer Device Name", "", false);
                }
            }
        });

        grid.add(lblPrintSer, 0, 0, 2, 1);
        grid.add(hbCashDrawerType, 1, 1);
        grid.addRow(3, lblDeviceName, txtDeviceName);

        return grid;
    }

    private GridPane getCashDrawerDirect() {

        GridPane grid = JKLayout.getContentGridInner2Col(0.25, 0.75);

        Label lblPort = JKText.getLblDk("Port", JKText.FONT_B_XSM);
        Label lblBaud = JKText.getLblDk("Baud Rate", JKText.FONT_B_XSM);

        chcPort = new ComboBox();
        chcPort.setPrefSize(((CONTENT_WIDTH - (2 * JKLayout.sp)) * 0.75), 35);
        chcPort.getSelectionModel().select(JKCashDrawer.getCashDrawerConfig().getCashDrawerPort());
        chcPort.getItems().addAll("COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "LPT1", "LPT2", "WINDOWS");

        chcBaud = new ComboBox();
        chcBaud.setPrefSize(((CONTENT_WIDTH - (2 * JKLayout.sp)) * 0.75), 35);
        chcBaud.getSelectionModel().select(Integer.toString(JKCashDrawer.getCashDrawerConfig().getCashDrawerBaud()));
        chcBaud.getItems().addAll("2400", "4800", "9600", "14400", "19200", "38400", "57600", "115200");

        chkFlowCon = new CheckBox("Flow Control");
        chkFlowCon.setSelected(JKCashDrawer.getCashDrawerConfig().isCashDrawerFlowControl());

        grid.addRow(0, lblPort, chcPort);
        grid.addRow(1, lblBaud, chcBaud);
        grid.add(chkFlowCon, 1, 2);

        return grid;
    }

    private GridPane getCashDrawerEntryWin() {

        GridPane gridWin = JKLayout.getContentGridInner2Col(0.25, 0.75);

        Label lblPrintWin = JKText.getLblDk("If Default Printer is set to 'Windows Printer'", JKText.FONT_B_XSM);
        String select = "The printer selected here must be set as the default Windows printer";
        Label lblPrinterDefault = JKText.getLblDk(select, JKText.FONT_B_XXSM);
        Label lblPrintSelect = JKText.getLblDk("Select Printer", JKText.FONT_B_XSM);

        List<CashDrawerWindows> listWinPrint = CashDrawerWinHandler.getInstance().getListWinPrinters();
        ObservableList<CashDrawerWindows> list = FXCollections.observableArrayList(listWinPrint);
        comCDWin = new ComboBox();
        comCDWin.setPrefSize(((CONTENT_WIDTH - (2 * JKLayout.sp)) * 0.75), 35);
        comCDWin.getSelectionModel().select(JKCashDrawer.getCashDrawerConfig().getCdWindows());
        comCDWin.getItems().addAll(list);

        gridWin.add(JKNode.createGridSpanSep(2), 0, 1);
        gridWin.add(lblPrintWin, 0, 2, 2, 1);
        gridWin.add(lblPrinterDefault, 0, 3, 2, 1);
        gridWin.addRow(4, lblPrintSelect, comCDWin);

        return gridWin;
    }

    private void setCashDrawerTypeView() {
        if (JKPrinter.getPrinterConfig().isPrintWin()) {
            gridSerial.setDisable(true);
            gridDirect.setDisable(true);
            gridWindows.setDisable(false);
        } else {
            gridSerial.setDisable(false);
            gridDirect.setDisable(false);
            gridWindows.setDisable(true);
            if (radDirect.isSelected()) {
                gridDirect.setDisable(false);
                lblDeviceName.setDisable(true);
                txtDeviceName.setDisable(true);
            } else if (radOpos.isSelected()) {
                gridDirect.setDisable(true);
                lblDeviceName.setDisable(false);
                txtDeviceName.setDisable(false);
            } else if (radIo.isSelected()) {
                gridDirect.setDisable(true);
                lblDeviceName.setDisable(true);
                txtDeviceName.setDisable(true);
            }
        }
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("Test Cash\nDrawer", true) {
            @Override
            public void onClickTest() {
                new PrintClient().cashDraw();
            }

            @Override
            public void onClickSave() {
                if (validateInput()) {
                    saveSystemCashDrawer();
                }
            }
        };
    }
    
    private void updateTestBtnState() {
        if (JKSalesOptions.getSalesOptions().isUseCashDrawer()) {
            SceneSetupControls.getBtnTest().setDisable(false);
        } else {
            SceneSetupControls.getBtnTest().setDisable(true);
        }
    }

    private boolean validateInput() {
        if (JKPrinter.getPrinterConfig().isPrintWin() && comCDWin.getSelectionModel().getSelectedItem() == null) {
            JKiosk3.getMsgBox().showMsgBox("Select Printer", "If Default Printer is set to 'Windows Printer',"
                    + "\nyou must select a printer from this list ", null);
            return false;
        }
        return true;
    }

    private void saveSystemCashDrawer() {
        if (radDirect.isSelected()) {
            JKCashDrawer.getCashDrawerConfig().setCashDrawerDirectOpos("Direct");
            JKCashDrawer.getCashDrawerConfig().setCashDrawerDirect(true);
            JKCashDrawer.getCashDrawerConfig().setCashDrawerOpos(false);
            JKCashDrawer.getCashDrawerConfig().setCashDrawerIo(false);
        } else if (radOpos.isSelected()) {
            JKCashDrawer.getCashDrawerConfig().setCashDrawerDirectOpos("OPOS");
            JKCashDrawer.getCashDrawerConfig().setCashDrawerDirect(false);
            JKCashDrawer.getCashDrawerConfig().setCashDrawerOpos(true);
            JKCashDrawer.getCashDrawerConfig().setCashDrawerIo(false);
        } else if (radIo.isSelected()) {
            JKCashDrawer.getCashDrawerConfig().setCashDrawerDirectOpos("IO");
            JKCashDrawer.getCashDrawerConfig().setCashDrawerDirect(false);
            JKCashDrawer.getCashDrawerConfig().setCashDrawerOpos(false);
            JKCashDrawer.getCashDrawerConfig().setCashDrawerIo(true);
        }

        if (radDirect.isSelected()) {
            if (chcPort.getSelectionModel().getSelectedItem() == null
                    || chcBaud.getSelectionModel().getSelectedItem() == null) {
                JKiosk3.getMsgBox().showMsgBox("Port or Baud Rate", "Port or Baud Rate cannot be empty", null);
            }
        } else if (radOpos.isSelected()) {
            if (txtDeviceName.getText().isEmpty()
                    || txtDeviceName.getText().equals("")) {
                JKiosk3.getMsgBox().showMsgBox("Device Name", "Device Name cannot be empty", null);
            }
        }

        JKCashDrawer.getCashDrawerConfig().setCashDrawerName(txtDeviceName.getText());
        JKCashDrawer.getCashDrawerConfig().setCashDrawerPort(chcPort.getSelectionModel().getSelectedItem().toString());
        JKCashDrawer.getCashDrawerConfig().setCashDrawerBaud(Integer.parseInt(chcBaud.getSelectionModel().getSelectedItem().toString()));
        JKCashDrawer.getCashDrawerConfig().setCashDrawerFlowControl(chkFlowCon.isSelected());
        //
        JKCashDrawer.getCashDrawerConfig().setCdWindows((CashDrawerWindows) comCDWin.getSelectionModel().getSelectedItem());
        //
        if (JKCashDrawer.saveCashDrawerConfig()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Cash Drawer settings saved successfully."
                    + "\n\nThe 'Test Cash Drawer' button will only be enabled if\n'Use Cash Drawer' in 'Sales Options' is selected.", null);
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Cash Drawer settings not saved", null);
        }
    }
}
