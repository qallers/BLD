package jkiosk3.sales.ticketpro;

import java.util.ArrayList;
import java.util.List;

/**
 *
 *
 */
public class TicketProSaleList {

    private final List<TicketProSale> listTPSales = new ArrayList<>();
    
    private static TicketProSaleList instance;
    
    public static TicketProSaleList getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    public static TicketProSaleList newInstance() {
        instance = new TicketProSaleList();
        return instance;
    }

    public static void resetTicketProSaleList() {
        instance = null;
    }

    public List<TicketProSale> getListTPSales() {
        return listTPSales;
    }
}
