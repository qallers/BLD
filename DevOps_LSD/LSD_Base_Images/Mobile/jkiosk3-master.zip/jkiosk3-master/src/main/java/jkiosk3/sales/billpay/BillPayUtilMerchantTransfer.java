package jkiosk3.sales.billpay;

import aeonmerchanttransfer.MerchantAccountInfoReq;
import aeonmerchanttransfer.MerchantAccountInfoResp;
import aeonmerchanttransfer.MerchantTransferConfirmReq;
import aeonmerchanttransfer.MerchantTransferConfirmResp;
import aeonmerchanttransfer.MerchantTransferConnection;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import jkiosk3.JKiosk3;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

/**
 *
 * @author valeriew
 */
public class BillPayUtilMerchantTransfer {

    private final static Logger logger = Logger.getLogger(BillPayUtilMerchantTransfer.class.getName());
    //
    private final static TaskUtil TASK_UTIL = new TaskUtil();
    private final static int COUNTDOWN_TIME = 60;
    //
    private static String errorMsg = "An unknown error occurred";
    private static MerchantTransferConnection mtconnect = null;

    private static MerchantTransferConnection getMerchantTransferConnect() {
        MerchantTransferConnection mtconn = null;

        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            mtconn = new MerchantTransferConnection(JKSystem.getSystemConfig().getServer(),
                    JKSystem.getSystemConfig().getPort(), JKSystem.getSystemConfig().isSecureConn());
            mtconn.setTimeout(COUNTDOWN_TIME);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (NoRouteToHostException nre) {
            errorMsg = nre.getClass().getSimpleName() + " : " + nre.getMessage();
            logger.log(Level.SEVERE, nre.getMessage(), nre);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return mtconn;
    }

    private static MerchantAccountInfoResp getAccountInfo(MerchantTransferConnection mtconn, MerchantAccountInfoReq req) throws RuntimeException {
        MerchantAccountInfoResp resp = new MerchantAccountInfoResp();
        try {
            if (mtconn.login(CurrentUser.getSalesUser().getUserPin(), JKSystem.getSystemConfig().getDeviceId(), JKSystem.getSystemConfig().getSerial())) {
                resp = mtconn.getMerchantAccountInfo(req);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Account Info Error", t);
        } finally {
            // do not disconnect - same session needed for confirmation!
//            if (mtc != null) {
//                mtc.disconnect();
//            }
        }
        return resp;
    }

    private static MerchantTransferConfirmResp getTransferConfirm(MerchantTransferConnection mtconn, MerchantTransferConfirmReq req) throws RuntimeException {
        MerchantTransferConfirmResp resp = new MerchantTransferConfirmResp();
        try {
            resp = mtconn.getMerchantTransferConfirm(req);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Account Info Error", t);
        } finally {
            if (mtconn != null) {
                mtconn.disconnect();
            }
        }
        return resp;
    }

    /*----------------*/
 /* Busy Indicator */
 /*----------------*/
    public static void getAccountInfo(final MerchantAccountInfoReq req, final MerchantAccountInfoResult result) {
        JKiosk3.getBusy().showBusy("Getting Account Info");

        final Task<MerchantTransferConnection> taskConnect = new Task() {
            @Override
            protected MerchantTransferConnection call() throws Exception {
                mtconnect = getMerchantTransferConnect();
                return mtconnect;
            }
        };

        final Task<MerchantAccountInfoResp> taskAccInfo = new Task<MerchantAccountInfoResp>() {
            @Override
            protected MerchantAccountInfoResp call() throws Exception {
                return getAccountInfo(mtconnect, req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.merchantAccountInfoResult(taskConnect.getValue(), getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("Error",
                        "Error Retrieving Merchant Account Info", State.CANCELLED, errorMsg, new BillPaymentMenu());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("Error",
                        "Error Retrieving Merchant Account Info", State.FAILED, errorMsg, new BillPaymentMenu());
            }
        };

        taskConnect.stateProperty().addListener(new ChangeListener<Worker.State>() {
            @Override
            public void changed(ObservableValue<? extends Worker.State> observable, Worker.State oldValue, Worker.State newState) {
                if (newState == Worker.State.SUCCEEDED) {
                    if (taskConnect.getValue() != null) {
                        new Thread(taskAccInfo).start();
                        JKiosk3.getBusy().startCountdown(taskAccInfo, COUNTDOWN_TIME);
                    } else {
                        errorMsg = "Unable to establish connection";
                        TASK_UTIL.taskConnectNull(errorMsg, new BillPaymentMenu());
                    }
                } else if (newState == Worker.State.CANCELLED || newState == Worker.State.FAILED) {
                    TASK_UTIL.taskConnectCancelFail(newState, errorMsg, new BillPaymentMenu());
                }
            }
        });

        new Thread(taskConnect).start();
    }

    public static void getTransferConfirm(final MerchantTransferConnection connect, final MerchantTransferConfirmReq req, final MerchantTransferConfirmResult result) {
        JKiosk3.getBusy().showBusy("Confirming Transfer");

        final Task<MerchantTransferConfirmResp> task = new Task<MerchantTransferConfirmResp>() {
            @Override
            protected MerchantTransferConfirmResp call() throws Exception {
                return getTransferConfirm(connect, req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.merchantTransferConfirmResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFailLogout("Error",
                        "Error Confirming Transfer", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFailLogout("Error",
                        "Error Confirming Transfer", State.FAILED, errorMsg);
            }
        };

        new Thread(task).start();
        JKiosk3.getBusy().startCountdown(task, COUNTDOWN_TIME);
    }

    public abstract static class MerchantAccountInfoResult {

        public abstract void merchantAccountInfoResult(MerchantTransferConnection connectResult, MerchantAccountInfoResp merchantInfoResult);
    }

    public abstract static class MerchantTransferConfirmResult {

        public abstract void merchantTransferConfirmResult(MerchantTransferConfirmResp transferConfirmResult);
    }
}
