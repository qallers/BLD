package jkiosk3.sales.search;

import jkiosk3.sales.SalesItems;
import jkiosk3.sales.topups.TopupProvider;

import java.util.ArrayList;
import java.util.List;

public class CreateSMSTopupProduct {
    public final static String SMS_BUNDLE = "SMS Bundle Topup";

    public static List<SearchProduct> createSMSTopupProducts() {
        //todo this should not be hardcoded for only cellc and mtn
        List<SearchProduct> products = new ArrayList<>();
        for (TopupProvider topupProvider : SalesItems.getListTopupProvidersBundles()) {
            System.out.println(topupProvider);
            SearchProduct networkProvider = new SearchProduct();
            String prodName = topupProvider.getName();

            if (prodName.toLowerCase().contains("cellc")) {
                prodName = "Cell C";
            } else if (prodName.toLowerCase().contains("mtn")) {
                prodName = "MTN";
            } else {
                continue;
            }

//            else if (prodName.toLowerCase().contains("telkommobile")){
//                prodName = "TelkomMobile";
//            } else if (prodName.toLowerCase().contains("virgin")){
//                prodName = "Virgin";
//            } else if (prodName.toLowerCase().contains("vodacom")){
//                prodName = "Vodacom";
//            }

            networkProvider.setProvName(topupProvider.getName());
            networkProvider.setProdName(String.format("%s %s", prodName.startsWith("x") ? prodName.substring(1) : prodName, SMS_BUNDLE));
            networkProvider.setSearchTransType(SearchTransType.SMS_BUNDLE);
            products.add(networkProvider);

        }
        return products;
    }

}
