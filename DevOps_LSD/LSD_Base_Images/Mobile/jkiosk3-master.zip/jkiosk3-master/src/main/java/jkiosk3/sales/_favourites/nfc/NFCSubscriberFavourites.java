package jkiosk3.sales._favourites.nfc;

import aeonairtime.AirtimeManufacturer;
import aeonvarivouchers.Supplier;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales._favourites.FavNodes;
import jkiosk3.sales._favourites.FavouriteUtilLists;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.topups.TopupProvider;
import za.co.blt.consumer.loyalty.api.service.model.response.CompleteConsumerProfile;
import za.co.blt.consumer.loyalty.api.service.model.response.Favourite;

import java.util.ArrayList;
import java.util.List;

public class NFCSubscriberFavourites extends Region {

    private CompleteConsumerProfile completeConsumerProfile;

    private List<Favourite> listFavourites;
    private List<AirtimeManufacturer> listFavVouch;
    private List<Supplier> listFavC4C;
    private List<TopupProvider> listFavTopProvAir;
    private List<TopupProvider> listFavTopProvBundles;
    private List<TopupProvider> listFavTopProvWallet;
    private List<ElectricityProvider> listFavElecSuppliers;
    private List<BillPayProduct> listFavBPProds;
    private List<String> listTicketing;
    private List<String> listIthuba;

    public NFCSubscriberFavourites(CompleteConsumerProfile completeConsumerProfile) {
        this.completeConsumerProfile = completeConsumerProfile;

        listFavourites = new ArrayList<>();

        if (completeConsumerProfile.getFavourites() != null) {
            listFavourites = completeConsumerProfile.getFavourites();
        }
        if (listFavourites.size() > 14) {
            listFavourites = listFavourites.subList(0, 14);
        }

        FavouriteUtilLists favUtilList = new FavouriteUtilLists();

        if (!listFavourites.isEmpty()) {
            // sort into lists for each product type, make buttons, add to view
            listFavVouch = favUtilList.getFavouriteVoucherList(listFavourites);
            listFavC4C = favUtilList.getFavouriteC4C(listFavourites);
            listFavTopProvAir = favUtilList.getFavouriteTopupAirtime(listFavourites);
            listFavTopProvBundles = favUtilList.getFavouriteTopupBundles(listFavourites);
            listFavTopProvWallet = favUtilList.getFavouriteTopupWallet(listFavourites);
            listFavElecSuppliers = favUtilList.getFavouriteElectricity(listFavourites);
            listFavBPProds = favUtilList.getFavouriteBillPayProducts(listFavourites);
            listTicketing = favUtilList.getFavouriteTicketing(listFavourites);
            listIthuba = favUtilList.getFavouriteIthuba(listFavourites);

            getChildren().addAll(getFavouritesView());

        } else {
            JKiosk3.getMsgBox().showMsgBox("Subscriber Favourites",
                    "\nNo Favourites for this Subscriber yet.\n\nPlease purchase products from the main menu.", null);
        }
    }

    private VBox getFavouritesView() {
        FavNodes favNodes = new FavNodes(true, listFavourites);

        Label lblFavourites = JKText.getLblDk("Favourites", JKText.FONT_B_SM);
        Text txtSubCard = JKText.getTxtDk("Card Number : " + completeConsumerProfile.getConsumer().getLoyaltyCard(), JKText.FONT_B_18);

        VBox vbHead = JKNode.getPageDblHeadVB(0, lblFavourites, txtSubCard);

        List<Button> listfavs = new ArrayList<>();

        listfavs.addAll(favNodes.getListBtnsVouchers(listFavVouch));
        listfavs.addAll(favNodes.getListBtnsC4C(listFavC4C));
        listfavs.addAll(favNodes.getListBtnsTopAir(listFavTopProvAir));
        listfavs.addAll(favNodes.getListBtnsTopData(listFavTopProvBundles));
        listfavs.addAll(favNodes.getListBtnsTopWallet(listFavTopProvWallet));
        listfavs.addAll(favNodes.getListBtnsElectricity(listFavElecSuppliers));
        listfavs.addAll(favNodes.getListBtnsBillPayments(listFavBPProds));
        listfavs.addAll(favNodes.getListBtnsTicketing(listTicketing));
        listfavs.addAll(favNodes.getListBtnsIthuba(listIthuba));

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listfavs);

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }
}
