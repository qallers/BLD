package jkiosk3.setup;

import java.util.logging.Logger;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._common.ResultCallback;
import jkiosk3.store.JKCacheOptions;
import jkiosk3.store.StoreJKCacheOptions;
import jkiosk3.store.cache.CacheController;
import jkiosk3.store.cache.CacheUtil;

public class SetupCacheOptions extends Region {

    private final static Logger logger = Logger.getLogger(SetupCacheOptions.class.getName());
//    private Label lblRestart;

    public SetupCacheOptions() {

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getCacheOptionsEntry());
        vb.getChildren().add(getControls());

        getChildren().add(vb);
    }

    private GridPane getCacheOptionsEntry() {

        VBox vbHead = JKNode.getPageHeadVB("Product Cache Options");

//        lblRestart = JKText.getLblDk(" * Application restart required", JKText.FONT_B_XXSM);
//        lblRestart.setDisable(!JKCacheOptions.getCachePreferences().isNever());
//        lblRestart.setTranslateX(2 * JKLayout.sp);
        Label lblUpdateNow = JKText.getLblDk("Update Now", JKText.FONT_B_SM);

        ToggleGroup toggroup = new ToggleGroup();

        final RadioButton radioUpdateDaily = new RadioButton(" Update 24 hourly");
        radioUpdateDaily.setToggleGroup(toggroup);
        radioUpdateDaily.setId("daily");
        radioUpdateDaily.setFont(JKText.FONT_B_SM);
        radioUpdateDaily.setSelected(JKCacheOptions.getCachePreferences().isDaily());
        radioUpdateDaily.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event t) {
                updateSettingsOnChange(radioUpdateDaily);
            }
        });

        final RadioButton radioUpdateHourly = new RadioButton(" Update every hour");
        radioUpdateHourly.setToggleGroup(toggroup);
        radioUpdateHourly.setId("hourly");
        radioUpdateHourly.setFont(JKText.FONT_B_SM);
        radioUpdateHourly.setSelected(JKCacheOptions.getCachePreferences().isHourly());
        radioUpdateHourly.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event t) {
                updateSettingsOnChange(radioUpdateHourly);
            }
        });

//        final RadioButton radioUpdateNever = new RadioButton(" Never cache products *");
//        radioUpdateNever.setToggleGroup(toggroup);
//        radioUpdateNever.setId("never");
//        radioUpdateNever.setFont(JKText.FONT_B_SM);
//        radioUpdateNever.setSelected(JKCacheOptions.getCachePreferences().isNever());
//        radioUpdateNever.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event t) {
//                updateSettingsOnChange(radioUpdateNever);
//            }
//        });

        Button btnUpdateNow = JKNode.getBtnMsgBox("update now");
        btnUpdateNow.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event t) {
                System.out.println("update cache please");
                CacheController cc = JKiosk3.getCacheController();
                cc.setUpdateCacheNow(CacheUtil.SCENE_SETUP, new ResultCallback() {
                    @Override
                    public void onResult(boolean result) {
                        System.out.println("update cache complete in Setup");
                    }
                });
            }
        });

        GridPane grid = JKLayout.getGridContent2Col(0.75, 0.25, HPos.RIGHT);

        grid.addRow(0, vbHead);
        grid.addRow(2, radioUpdateDaily);
        grid.addRow(4, radioUpdateHourly);
//        grid.addRow(6, radioUpdateNever);
//        grid.addRow(7, lblRestart);
        grid.addRow(6, JKNode.createGridSpanSep(2));
        grid.addRow(8, lblUpdateNow, btnUpdateNow);
        grid.addRow(9, new Label(""));

        return grid;
    }

    private void updateSettingsOnChange(RadioButton radio) {
        JKCacheOptions.getCachePreferences().setDaily(false);
        JKCacheOptions.getCachePreferences().setHourly(false);
        JKCacheOptions.getCachePreferences().setNever(false);
//        lblRestart.setDisable(true);
        switch (radio.getId()) {
            case "daily":
                JKCacheOptions.getCachePreferences().setDaily(true);
                break;
            case "hourly":
                JKCacheOptions.getCachePreferences().setHourly(true);
                break;
//            case "never":
//                JKCacheOptions.getCachePreferences().setNever(true);
//                lblRestart.setDisable(false);
//                break;
            default:
                break;
        }
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("", false) {
            @Override
            public void onClickTest() {
            }

            @Override
            public void onClickSave() {
                saveCacheOptions();
            }
        };
    }

    private void saveCacheOptions() {
        StoreJKCacheOptions jkCache = new StoreJKCacheOptions();
        jkCache.setDaily(JKCacheOptions.getCachePreferences().isDaily());
        jkCache.setHourly(JKCacheOptions.getCachePreferences().isHourly());
        jkCache.setNever(JKCacheOptions.getCachePreferences().isNever());
        //
        StringBuilder sb = new StringBuilder("\r\n");
        sb.append("Cache update daily  = ").append(Boolean.toString(JKCacheOptions.getCachePreferences().isDaily())).append("\r\n");
        sb.append("Cache update hourly = ").append(Boolean.toString(JKCacheOptions.getCachePreferences().isHourly())).append("\r\n");
        sb.append("Cache update never  = ").append(Boolean.toString(JKCacheOptions.getCachePreferences().isNever())).append("\r\n");

        if (JKCacheOptions.saveCachePreferences(jkCache)) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Cache preferences saved successfully", null);
            sb.append("Cache preferences updated and saved successfully");
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Cache preferences not saved", null);
            sb.append("Cache preferences updated but not saved successfully");
        }
        logger.info(sb.toString());

        if (JKiosk3.getCacheController() != null) {
            CacheController cacheController = JKiosk3.getCacheController();
//            if (!JKCacheOptions.getCachePreferences().isNever()) {
                cacheController.setUpdateCacheScheduler();
//            } else {
//                if (cacheController.getScheduledCacheExecutor() != null) {
//                    cacheController.getScheduledCacheExecutor().shutdown();
//                }
//                cacheController.deleteCachedItems();
//            }
        }
    }
}
