package jkiosk3.sales.electricity;

import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

/**
 *
 * @author Val
 */
public class ElecShareBtnsLessMore extends Region {

    private Button btnLess;
    private Button btnMore;
    private Button btnAccept;
    private Button btnCancel;

    public ElecShareBtnsLessMore() {
        Group grpLessMore = getBtnsLessMore();

        getChildren().add(grpLessMore);
    }

    private Group getBtnsLessMore() {

        btnLess = JKNode.getBtnSm("Less...");
        btnLess.setDisable(true);
        btnLess.setVisible(false);

        btnMore = JKNode.getBtnSm("More...");
        btnMore.setDisable(false);
        btnMore.setVisible(false);

        btnAccept = JKNode.getBtnSm("Accept");
        btnAccept.setDisable(true);

        btnCancel = JKNode.getBtnSm("Cancel");

        TilePane tile = JKLayout.getTile(JKLayout.sp, JKLayout.sp, JKLayout.sp, 4);
        tile.getChildren().addAll(btnLess, btnMore, btnAccept, btnCancel);

        return JKNode.getContentGroup(tile);
    }

    public Button getBtnAccept() {
        return btnAccept;
    }

    public Button getBtnCancel() {
        return btnCancel;
    }

    public Button getBtnLess() {
        return btnLess;
    }

    public Button getBtnMore() {
        return btnMore;
    }
}
