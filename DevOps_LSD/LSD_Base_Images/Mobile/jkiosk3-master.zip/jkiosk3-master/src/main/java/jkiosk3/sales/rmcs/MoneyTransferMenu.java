package jkiosk3.sales.rmcs;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.SceneSales;
import jkiosk3.users.SalesUserLoginResult;

/**
 *
 * @author val
 */
public class MoneyTransferMenu extends Region {

    public MoneyTransferMenu() {
        getChildren().add(getMenuGroup());
    }

    private VBox getMenuGroup() {

        VBox vbHead = JKNode.getPageHeadVB("Money Transfer Menu");

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getMenuButtons());

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private List<Button> getMenuButtons() {
        List<Button> btnList = new ArrayList<>();

        String[] btnLabels = {RmcsUtil.MONEY_TRF_DEPOSIT, RmcsUtil.MONEY_TRF_REDEEM};

        for (String s : btnLabels) {
            final Button btn = JKNode.getBtnSmDbl(s);
            btn.setId(s);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        return btnList;
    }

    private void getMenuAction(final Button b) {

//        JKiosk3.getSalesUserLogin().showUserLogin(new PasswordField(), new SalesUserLoginResult() {
        JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
            @Override
            public void onDone() {
                switch (b.getId()) {
                    case RmcsUtil.MONEY_TRF_DEPOSIT:
                        RmcsDeposit.newInstance();
                        SceneSales.clearAndChangeContent(new RmcsCashDeposit());
                        break;
                    case RmcsUtil.MONEY_TRF_REDEEM:
                        RmcsRedeem.newInstance();
                        SceneSales.clearAndChangeContent(new RmcsCashRedeem());
                        break;
                    default:
                        JKiosk3.getMsgBox().showMsgBox("Error", "Invalid selection", null);
                }
            }
        });
    }
}
