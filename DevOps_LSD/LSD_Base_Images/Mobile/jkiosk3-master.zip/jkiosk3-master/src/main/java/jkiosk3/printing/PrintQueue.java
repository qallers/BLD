package jkiosk3.printing;

import aeonprinting.AeonPrintJob;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Val
 */
public class PrintQueue {

    private static Map<String, AeonPrintJob> printQueue = new HashMap();
    private static List<MagCardData> magCards = new ArrayList<>();

    public static void clearQueue() {
        printQueue.clear();
    }

    public static void addItem(String transRef, AeonPrintJob item) {
        printQueue.put(transRef, item);
    }

    public static void removeItem(String transRef) {
        printQueue.remove(transRef);
    }

    public static Map<String, AeonPrintJob> getPrintQueue() {
        return printQueue;
    }

    public static void addMagCards(List<MagCardData> cards) {
        magCards.addAll(cards);
    }

    public static List<MagCardData> getMagCards() {
        return magCards;
    }

    public static void clearMagCardQueue() {
        magCards.clear();
    }
}
