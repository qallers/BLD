package jkiosk3.admin.favourites;

import aeonfavourites.FavouriteItem;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.admin.favourites.fav_cache.CacheFavouriteCustomStore;
import jkiosk3.admin.favourites.fav_cache.JKFavouriteSetup;
import jkiosk3.sales._favourites.FavouriteUtil;
import jkiosk3.users.CurrentUser;

import java.util.ArrayList;
import java.util.List;

public class FavouritesPrefs extends Region {

    private final static String VOUCHERS = "Show Vouchers";
    private final static String ELECTRICITY = "Show Electricity";
    private final static String BILL_PAYMENTS = "Show Bill Payments";
    private final static String USE_DEFAULT = "Use Default";
    private final static String USE_CUSTOM = "Use Custom";
    private VBox vboxMenu;
    private List<Button> listBtnsFavMenu;
    private Button btnDefaultUpdate;
    private ToggleGroup toggleGroup;
    private RadioButton radioDefault;
    private RadioButton radioCustom;
    private GridPane gridCustom;
    private CheckBox chkVouch;
    private CheckBox chkElect;
    private CheckBox chkBillPay;
    private TextField txtVouch;
    private TextField txtElect;
    private TextField txtBillPay;
    private Label lblCountTotal;
    private boolean isEnableVouchers = true;
    private boolean isEnableElectricity = true;
    private boolean isEnableBillPayments = true;
    private int countVouch;
    private int countElect;
    private int countBillPay;
    private int countTotal;
    private final int countMax = 14;

    public FavouritesPrefs() {
        this.vboxMenu = SceneFavourites.getVboxMenu();
        this.listBtnsFavMenu = SceneFavourites.getBtnListFavMenu();
        this.countVouch = JKFavouriteSetup.getFavouriteSetupStore().getCountVouchers();
        this.countElect = JKFavouriteSetup.getFavouriteSetupStore().getCountElectricity();
        this.countBillPay = JKFavouriteSetup.getFavouriteSetupStore().getCountBillPayments();
        this.countTotal = countVouch + countElect + countBillPay;

        checkEnableTransTypes();

        getChildren().addAll(getPreferencesLayout());
    }

    private void checkEnableTransTypes() {
        List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();
        // Disable as needed
        if ((!onlineTransTypes.contains("Voucher")) && (!onlineTransTypes.contains("VoucherAMS"))) {
            isEnableVouchers = false;
        }
        if (!onlineTransTypes.contains("Electricity")) {
            isEnableElectricity = false;
        }
        if ((!onlineTransTypes.contains("VASPayAtAccountPayment")) && (!onlineTransTypes.contains("VASPayAtBusTicket"))
                && (!onlineTransTypes.contains("VASPayAtFinePayment")) && (!onlineTransTypes.contains("VASPayAtInsurance"))
                && (!onlineTransTypes.contains("VASSyntellAccountPayment")) && (!onlineTransTypes.contains("VASSyntellFinePayment"))
                && (!onlineTransTypes.contains("VASSAPOAccountPayment")) && (!onlineTransTypes.contains("BluBillPayment"))
                && (!onlineTransTypes.contains("MerchantTransfer"))) {
            isEnableBillPayments = false;
        }
    }

    private VBox getPreferencesLayout() {
        VBox vbContent = JKLayout.getVBoxContent(JKLayout.spNum);
        VBox vbHead = JKNode.getPageHeadVB("Select Favourite Preferences");
        vbContent.getChildren().addAll(vbHead, getPrefsInput());

        VBox vbPage = JKLayout.getVBox(0, JKLayout.spNum);
        vbPage.getChildren().addAll(vbContent, getBtnControls());

        return vbPage;
    }

    private ControlButtonsFav getBtnControls() {
        ControlButtonsFav ctrl = new ControlButtonsFav();
        ctrl.getBtnSave().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                if (isValidSelection()) {
                    savePreferences();
                }
            }
        });

        return ctrl;
    }

    private GridPane getPrefsInput() {
        toggleGroup = new ToggleGroup();

        btnDefaultUpdate = JKNode.getBtnSm("Update Default Favourites");
        btnDefaultUpdate.setWrapText(true);
        btnDefaultUpdate.setFont(JKText.FONT_B_XXSM);
        btnDefaultUpdate.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                FavouriteUtil.getListFavouriteProducts(true, new FavouriteUtil.FavouriteProductsResult() {
                    @Override
                    public void favouriteProductsResult(List<FavouriteItem> favListResp) {
                        if (!favListResp.isEmpty()) {
                            JKiosk3.getMsgBox().showMsgBox("Default Favourites", "Successfully updated Default Favourites list.", null);
                        } else {
                            JKiosk3.getMsgBox().showMsgBox("Default Favourites", "No items in Default Favourites list!", null);
                        }
                    }
                });
            }
        });

        boolean useDefault = JKFavouriteSetup.getFavouriteSetupStore().isUseDefaultFavourites();

        radioDefault = new RadioButton(USE_DEFAULT);
        radioDefault.setFont(JKText.FONT_B_24);
        radioDefault.setToggleGroup(toggleGroup);
        radioDefault.setSelected(useDefault);
        radioDefault.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                enableComponentsView(radioDefault);
//                if (radioDefault.isSelected()) {
//                    gridCustom.setDisable(true);
//                    btnDefaultUpdate.setDisable(false);
//                    enableMenuView(radioDefault, true);
//                } else {
//                    gridCustom.setDisable(false);
//                    btnDefaultUpdate.setDisable(true);
//                    enableMenuView(radioDefault, true);
//                }
            }
        });

        radioCustom = new RadioButton(USE_CUSTOM);
        radioCustom.setFont(JKText.FONT_B_24);
        radioCustom.setToggleGroup(toggleGroup);
        radioCustom.setSelected(!useDefault);
        radioCustom.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                enableComponentsView(radioCustom);
//                if (radioCustom.isSelected()) {
//                    gridCustom.setDisable(false);
//                    btnDefaultUpdate.setDisable(true);
//                    enableMenuView(radioCustom, false);
//                } else {
//                    gridCustom.setDisable(true);
//                    btnDefaultUpdate.setDisable(false);
//                    enableMenuView(radioCustom, false);
//                }
            }
        });

        HBox hBox = JKLayout.getHBox(0, JKLayout.sp);
        hBox.setMinWidth(JKLayout.contentW - (2 * JKLayout.sp));
        hBox.getChildren().addAll(radioDefault, JKNode.getHSpacer(), radioCustom, JKNode.getHSpacer());
        GridPane.setColumnSpan(hBox, 2);

        gridCustom = getGridCustom();

        if (useDefault) {
            gridCustom.setDisable(true);
            btnDefaultUpdate.setDisable(false);
        } else {
            gridCustom.setDisable(false);
            btnDefaultUpdate.setDisable(true);
        }

        GridPane gridPane = JKLayout.getContentGridInner2Col(0.75, 0.25, HPos.RIGHT);
        gridPane.setStyle("-fx-padding: 15px 0px 0px 0px");

        gridPane.addRow(0, hBox);
        gridPane.addRow(1, JKNode.createGridSpanSep(2));
        gridPane.add(btnDefaultUpdate, 1, 2);
        gridPane.addRow(3, JKNode.createGridSpanSep(2));

        gridPane.add(gridCustom, 0, 4, 2, 1);

        return gridPane;
    }

    private GridPane getGridCustom() {

        Label lblCustomPrefs = JKText.getLblDk("Custom Preferences", JKText.FONT_B_SM);
        Label lblExceed = JKText.getLblDk("If any count is shown in RED, remove items " +
                "from that list until count is correct", JKText.FONT_B_14);
        lblExceed.setWrapText(true);

        Label lblTotal = JKText.getLblDk("Maximum of 14 items can be selected", JKText.FONT_B_XSM);
        Label lblQty = JKText.getLblDk("How many?", JKText.FONT_B_XSM);
        Label lblCount = JKText.getLblDk("Total : ", JKText.FONT_B_SM);
        GridPane.setHalignment(lblCount, HPos.RIGHT);

        chkVouch = new CheckBox(VOUCHERS);
        chkVouch.setDisable(!isEnableVouchers);
        chkVouch.setSelected(JKFavouriteSetup.getFavouriteSetupStore().isShowVouchers());

        chkElect = new CheckBox(ELECTRICITY);
        chkElect.setDisable(!isEnableElectricity);
        chkElect.setSelected(JKFavouriteSetup.getFavouriteSetupStore().isShowElectricity());

        chkBillPay = new CheckBox(BILL_PAYMENTS);
        chkBillPay.setDisable(!isEnableBillPayments);
        chkBillPay.setSelected(JKFavouriteSetup.getFavouriteSetupStore().isShowBillPayments());

        txtVouch = makeTextFieldFav();
        txtVouch.setText(Integer.toString(JKFavouriteSetup.getFavouriteSetupStore().getCountVouchers()));

//        Label lblVouch = JKText.getLblDk(getItemCount("Voucher") + "  of ", JKText.FONT_B_18);
        Label lblVouch = getLabelItemCount("Voucher", JKFavouriteSetup.getFavouriteSetupStore().getCountVouchers());
        HBox hbVouch = JKLayout.getHBox(0, JKLayout.sp);
        hbVouch.getChildren().addAll(JKNode.getHSpacer(), lblVouch, txtVouch);

        txtElect = makeTextFieldFav();
        txtElect.setText(Integer.toString(JKFavouriteSetup.getFavouriteSetupStore().getCountElectricity()));

//        Label lblElect = JKText.getLblDk(getItemCount("Electricity") + "  of ", JKText.FONT_B_18);
        Label lblElect = getLabelItemCount("Electricity", JKFavouriteSetup.getFavouriteSetupStore().getCountElectricity());
        HBox hbElect = JKLayout.getHBox(0, JKLayout.sp);
        hbElect.getChildren().addAll(JKNode.getHSpacer(), lblElect, txtElect);

        txtBillPay = makeTextFieldFav();
        txtBillPay.setText(Integer.toString(JKFavouriteSetup.getFavouriteSetupStore().getCountBillPayments()));

//        Label lblBillPay = JKText.getLblDk(getItemCount("Payments") + "  of ", JKText.FONT_B_18);
        Label lblBillPay = getLabelItemCount("Payments", JKFavouriteSetup.getFavouriteSetupStore().getCountBillPayments());
        HBox hbBillPay = JKLayout.getHBox(0, JKLayout.sp);
        hbBillPay.getChildren().addAll(JKNode.getHSpacer(), lblBillPay, txtBillPay);

        lblCountTotal = JKText.getLblDk(Integer.toString(countTotal), JKText.FONT_B_SM);

        updateMenuButtons(chkVouch, SceneFavourites.SELECT_VOUCHERS, isEnableVouchers);
        updateMenuButtons(chkElect, SceneFavourites.SELECT_ELECTRICITY, isEnableElectricity);
        updateMenuButtons(chkBillPay, SceneFavourites.SELECT_BILL_PAYMENTS, isEnableBillPayments);

        chkVouch.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                updateMenuButtons(chkVouch, SceneFavourites.SELECT_VOUCHERS, isEnableVouchers);
            }
        });
        chkElect.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                updateMenuButtons(chkElect, SceneFavourites.SELECT_ELECTRICITY, isEnableElectricity);
            }
        });
        chkBillPay.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                updateMenuButtons(chkBillPay, SceneFavourites.SELECT_BILL_PAYMENTS, isEnableBillPayments);
            }
        });

        txtVouch.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtVouch, "Count", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        countVouch = getValueAsInt(value);
                        checkAndUpdateCount(chkVouch, txtVouch);
                    }
                });
            }
        });
        txtElect.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtElect, "Count", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        countElect = getValueAsInt(value);
                        checkAndUpdateCount(chkElect, txtElect);
                    }
                });
            }
        });
        txtBillPay.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtBillPay, "Count", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        countBillPay = getValueAsInt(value);
                        checkAndUpdateCount(chkBillPay, txtBillPay);
                    }
                });
            }
        });

//        GridPane gridC = JKLayout.getContentGridInner2Col(0.75, 0.25, HPos.RIGHT);
        GridPane gridC = JKLayout.getContentGridInner2Col(0.65, 0.35, HPos.RIGHT);
        gridC.setStyle("-fx-padding: 15px 0px 0px 0px");

        gridC.addRow(0, lblCustomPrefs);
        gridC.add(lblExceed, 0, 1, 2, 1);
        gridC.addRow(2, lblTotal, lblQty);
        gridC.addRow(4, chkVouch, hbVouch);
        gridC.addRow(5, chkElect, hbElect);
        gridC.addRow(6, chkBillPay, hbBillPay);
        gridC.addRow(8, lblCount, lblCountTotal);

        return gridC;
    }

    private Label getLabelItemCount(String trxTypeOrGroup, int countRequired) {
        int countVoucher = 0;
        int countElectricity = 0;
        int countBillPayment = 0;
        for (FavouriteItem f : CacheFavouriteCustomStore.getListFavouriteItems()) {
            if (f.getTrxType().equalsIgnoreCase("Voucher")) {
                countVoucher++;
            } else if (f.getTrxGroup().equalsIgnoreCase("Electricity")) {
                countElectricity++;
            } else if (f.getTrxGroup().equalsIgnoreCase("Payments")) {
                countBillPayment++;
            }
        }
        int countItem = 0;
        switch (trxTypeOrGroup) {
            case "Voucher":
                countItem = countVoucher;
                break;
            case "Electricity":
                countItem = countElectricity;
                break;
            case "Payments":
                countItem = countBillPayment;
                break;
            default:
                break;
        }
        Label lblCurrentCount = JKText.getLblDk(countItem + "  of ", JKText.FONT_B_18);
        if (countItem > countRequired) {
            lblCurrentCount.setStyle("-fx-text-fill: #ff0000;");
        }

        return lblCurrentCount;
    }


    private void enableComponentsView(final RadioButton radioButton) {
        String msg = "";
        if (radioButton.getText().equalsIgnoreCase(USE_CUSTOM)) {
            msg = "\nPlease be sure to SAVE your Preferences \n\nbefore selecting any items \n\nfrom the lists of Transaction Types";
        } else if (radioButton.getText().equalsIgnoreCase(USE_DEFAULT)) {
            msg = "\nPlease be sure to SAVE your Preferences \n\nbefore selecting the 'Update Default Favourites' button";
        }
        JKiosk3.getMsgBox().showMsgBox(radioButton.getText(), msg, null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
            @Override
            public void onOk() {
                switch (radioButton.getText()) {
                    case USE_CUSTOM:
                        if (radioCustom.isSelected()) {
                            gridCustom.setDisable(false);
                            btnDefaultUpdate.setDisable(true);
                            vboxMenu.setDisable(false);
                        } else {
                            gridCustom.setDisable(true);
                            btnDefaultUpdate.setDisable(false);
                            vboxMenu.setDisable(true);
                        }
                        break;
                    case USE_DEFAULT:
                        if (radioDefault.isSelected()) {
                            gridCustom.setDisable(true);
                            btnDefaultUpdate.setDisable(false);
                            vboxMenu.setDisable(true);
                        } else {
                            gridCustom.setDisable(false);
                            btnDefaultUpdate.setDisable(true);
                            vboxMenu.setDisable(false);
                        }
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onCancel() {

            }
        });
    }

    private void updateMenuButtons(CheckBox checkBox, String trxType, boolean enableMenu) {
        for (Button b : listBtnsFavMenu) {
            if (b.getText().equalsIgnoreCase(trxType)) {
                if (!enableMenu) {
                    b.setDisable(true);
                    checkBox.setSelected(false);
                } else {
                    if (!checkBox.isSelected()) {
                        b.setDisable(true);
                    } else {
                        b.setDisable(false);
                    }
                }
            }
        }
        checkAndUpdateItem(checkBox);
    }

    private void checkAndUpdateItem(CheckBox checkBox) {
        if (!checkBox.isSelected()) {
            switch (checkBox.getText()) {
                case VOUCHERS:
                    countVouch = 0;
                    txtVouch.setText(Integer.toString(countVouch));
                    checkAndUpdateCount(checkBox, txtVouch);
                    break;
                case ELECTRICITY:
                    countElect = 0;
                    txtElect.setText(Integer.toString(countElect));
                    checkAndUpdateCount(checkBox, txtElect);
                    break;
                case BILL_PAYMENTS:
                    countBillPay = 0;
                    txtBillPay.setText(Integer.toString(countBillPay));
                    checkAndUpdateCount(checkBox, txtBillPay);
                    break;
                default:
                    break;
            }
        } else {
            switch (checkBox.getText()) {
                case VOUCHERS:
                    countVouch = JKFavouriteSetup.getFavouriteSetupStore().getCountVouchers();
                    if (countVouch == 0) {
                        countVouch = countMax - (countElect + countBillPay);
                    }
                    txtVouch.setText(Integer.toString(countVouch));
                    checkAndUpdateCount(checkBox, txtVouch);
                    break;
                case ELECTRICITY:
                    countElect = JKFavouriteSetup.getFavouriteSetupStore().getCountElectricity();
                    if (countElect == 0) {
                        countElect = countMax - (countVouch + countBillPay);
                    }
                    txtElect.setText(Integer.toString(countElect));
                    checkAndUpdateCount(checkBox, txtElect);
                    break;
                case BILL_PAYMENTS:
                    countBillPay = JKFavouriteSetup.getFavouriteSetupStore().getCountBillPayments();
                    if (countBillPay == 0) {
                        countBillPay = countMax - (countVouch + countElect);
                    }
                    txtBillPay.setText(Integer.toString(countBillPay));
                    checkAndUpdateCount(checkBox, txtBillPay);
                    break;
                default:
                    break;
            }
        }
    }

    private void checkAndUpdateCount(CheckBox checkBox, TextField textField) {
        countTotal = countVouch + countElect + countBillPay;
        if (countTotal > countMax) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Value", "Total number of items cannot exceed " + countMax, null);
            switch (checkBox.getText()) {
                case VOUCHERS:
                    countVouch = countMax - (countElect + countBillPay);
                    txtVouch.setText(Integer.toString(countVouch));
                    checkAndUpdateCount(checkBox, txtVouch);
                    break;
                case ELECTRICITY:
                    countElect = countMax - (countVouch + countBillPay);
                    txtElect.setText(Integer.toString(countElect));
                    checkAndUpdateCount(checkBox, txtElect);
                    break;
                case BILL_PAYMENTS:
                    countBillPay = countMax - (countVouch + countElect);
                    txtBillPay.setText(Integer.toString(countBillPay));
                    checkAndUpdateCount(checkBox, txtBillPay);
                    break;
                default:
                    break;
            }
        } else {
            lblCountTotal.setText(Integer.toString(countTotal));
        }
    }

    private int getValueAsInt(String value) {
        int intValue = 0;
        try {
            intValue = Integer.parseInt(value);
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Value", "Please enter a valid value", null);
        }
        return intValue;
    }

    private boolean isValidSelection() {
        if (radioCustom.isSelected()) {
            if (countTotal > 0) {
                return true;
            } else {
                JKiosk3.getMsgBox().showMsgBox("Custom Favourites Error",
                        "If 'Use Custom' is selected, at least 1 transaction type must have products selected", null);
                return false;
            }
        } else {
            return true;
        }
    }

    private void savePreferences() {
        if (toggleGroup.getSelectedToggle() != null) {
            JKFavouriteSetup.getFavouriteSetupStore().setUseDefaultFavourites(radioDefault.isSelected());
        } else {
            JKiosk3.getMsgBox().showMsgBox("Favourites Setup", "Please select Default or Custom before Save", null);
        }
        JKFavouriteSetup.getFavouriteSetupStore().setShowVouchers(chkVouch.isSelected());
        JKFavouriteSetup.getFavouriteSetupStore().setShowElectricity(chkElect.isSelected());
        JKFavouriteSetup.getFavouriteSetupStore().setShowBillPayments(chkBillPay.isSelected());
        if (chkVouch.isSelected()) {
            JKFavouriteSetup.getFavouriteSetupStore().setCountVouchers(countVouch);
        } else {
            JKFavouriteSetup.getFavouriteSetupStore().setCountVouchers(0);
            updateFavouriteCachedItems(SceneFavourites.TRX_GROUP_VOUCHER);
        }
        if (chkElect.isSelected()) {
            JKFavouriteSetup.getFavouriteSetupStore().setCountElectricity(countElect);
        } else {
            JKFavouriteSetup.getFavouriteSetupStore().setCountElectricity(0);
            updateFavouriteCachedItems(SceneFavourites.TRX_GROUP_ELECTRICITY);
        }
        if (chkBillPay.isSelected()) {
            JKFavouriteSetup.getFavouriteSetupStore().setCountBillPayments(countBillPay);
        } else {
            JKFavouriteSetup.getFavouriteSetupStore().setCountBillPayments(0);
            updateFavouriteCachedItems(SceneFavourites.TRX_GROUP_BILL_PAYMENTS);
        }

        if (JKFavouriteSetup.saveFavouriteSetup()) {
            String favSelected = JKFavouriteSetup.getFavouriteSetupStore().toString();
            JKiosk3.getMsgBox().showMsgBox("Favourites Setup",
                    "Saved successfully.\n\n" + favSelected + "\n\nwill be used", null, MessageBox.CONTROLS_SHOW,
                    MessageBox.MSG_OK, new MessageBoxResult() {
                        @Override
                        public void onOk() {
                            SceneFavourites.clearAndChangeContent(new FavouritesPrefs());
                        }

                        @Override
                        public void onCancel() {

                        }
                    });
        }
    }

    private void updateFavouriteCachedItems(String trxGroupUpdate) {
        List<FavouriteItem> listFavouriteCache = CacheFavouriteCustomStore.getListFavouriteItems();
        // Make an empty temporary list
        List<FavouriteItem> listUpdateFavCache = new ArrayList<>();
        for (FavouriteItem i : listFavouriteCache) {
            // EXCLUDE any items for the relevant Trx Group
            if (!i.getTrxGroup().equalsIgnoreCase(trxGroupUpdate)) {
                listUpdateFavCache.add(i);
            }
        }
        // Save new list without relevant items as Custom Favourite list
        CacheFavouriteCustomStore.saveFavouriteStore(listUpdateFavCache);
    }

    private TextField makeTextFieldFav() {
        TextField textField = JKNode.getTextFieldRight();
        textField.setMaxWidth(85);
        textField.setMinWidth(85);
        return textField;
    }
}