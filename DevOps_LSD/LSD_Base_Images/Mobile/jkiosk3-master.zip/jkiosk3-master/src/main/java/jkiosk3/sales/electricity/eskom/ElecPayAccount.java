package jkiosk3.sales.electricity.eskom;

import aeonelectricity.ElectricityVoucher;
import aeonprinting.AeonPrintJob;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3.printing.PrintHandler;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales._common.QuickAmounts;
import jkiosk3.sales._common.QuickAmountsResult;
import jkiosk3.sales.electricity.ElecEnterMeter;
import jkiosk3.sales.electricity.ElecEnterMeterResult;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.sales.electricity.ElectricityUtil.EskomPayDebtResult;
import jkiosk3.store.JKBranding;

/**
 * @author Valerie
 */
public class ElecPayAccount extends Region {

    private final ElectricityProvider provider;
    private String meterNum;
    private int amount;
    private ElecEnterMeter gMeter;
    private QuickAmounts qAmts;
    private VBox vbPayAcc;

    public ElecPayAccount(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;

        getChildren ().add (getPayAccountLayout ());
    }

    private VBox getPayAccountLayout() {
        gMeter = new ElecEnterMeter (provider, ElectricityUtil.ELEC_PAY_ACCOUNT, new ElecEnterMeterResult () {
            @Override
            public void onDone() {
                if (gMeter.isMagEntry ()) {
                    System.out.println ("onDone : meter number entered : " + gMeter.getMeterNum ());
                    System.out.println ("onDone : did we read mag card? : " + gMeter.isMagEntry ());
                }
            }
        });
//        String merchantGroup = JKBranding.getBranding().getMerchantGroup().getCode();
//        qAmts = new QuickAmounts(merchantGroup, new QuickAmountsResult() {
//        qAmts = new QuickAmounts(SaleType.ELECTRICITY, null, new QuickAmountsResult() {
//            @Override
//            public void amountSelected(double value) {
//                amount = (int) value;
//                requestConfirmation();
//            }
//        });
//        qAmts.setVisible(true);
        qAmts = getQuickAmts ();

        vbPayAcc = JKLayout.getVBox (0, JKLayout.spNum);
        vbPayAcc.getChildren ().addAll (gMeter, qAmts);
        return vbPayAcc;
    }

    private QuickAmounts getQuickAmts() {
        QuickAmounts quick = new QuickAmounts (SaleType.ELECTRICITY, null, new QuickAmountsResult () {
            @Override
            public void amountSelected(double value) {
                amount = (int) value;
                requestConfirmation ();
            }
        });
        quick.setVisible (true);
        return quick;
    }

    private void resetQuickAmounts() {
        vbPayAcc.getChildren ().remove (qAmts);
        qAmts = getQuickAmts ();
        vbPayAcc.getChildren ().add (1, qAmts);
    }

    private void requestConfirmation() {
        if (validateInput ()) {
            makeAccountPayment (amount);
        }
    }

    private void makeAccountPayment(final double amount) {
        System.out.println ("ElecPayAccount - meterNum = " + meterNum);
//        String transType = "EskomDirect";
        String transType = provider.getTransactionType ();
        ElectricityUtil.getPayAccountVoucher (transType, meterNum, amount, new EskomPayDebtResult () {
            @Override
            public void eskomPayDebtResult(ElectricityVoucher payDebtVoucher) {
                if (payDebtVoucher.isSuccess ()) {
                    SalesUtil.processElectricity (ElectricityUtil.ELEC_PAY_ACCOUNT, payDebtVoucher, amount);

                } else {
                    resetQuickAmounts ();
                    JKiosk3.getMsgBox ().showMsgBox ("Account Payment Error", !payDebtVoucher.getAeonErrorText ().isEmpty () ?
                            "A" + payDebtVoucher.getAeonErrorCode () + " - " + payDebtVoucher.getAeonErrorText () :
                            "B" + payDebtVoucher.getErrorCode () + " - " + payDebtVoucher.getErrorText (), null);
                }
                ElectricityUtil.resetElectricity ();
            }
        });
    }

    private boolean validateInput() {
        meterNum = gMeter.getMeterNum ().trim ();
        if (meterNum.equals ("") || meterNum == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Meter Number", "Meter Number cannot be blank.\n\n"
                    + "Please enter Meter Number \n\nand choose or enter an amount.", null);
            amount = 0;
            resetQuickAmounts ();
//            JKiosk3.getMsgBox().showMsgBox("Meter Number", "Meter Number cannot be blank.\n"
//                    + "Please enter Meter Number and choose an amount.", null);
            return false;
        }
        return true;
    }
}