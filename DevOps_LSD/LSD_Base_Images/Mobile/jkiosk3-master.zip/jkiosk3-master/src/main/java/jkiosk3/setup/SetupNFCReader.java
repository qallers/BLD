package jkiosk3.setup;

import javafx.geometry.HPos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.StageComponents;
import jkiosk3.store.JKNFCReader;
import za.co.blt.NFCReaders;

public class SetupNFCReader extends Region {

    private CheckBox chkRead;
    private ComboBox chcType;

    public SetupNFCReader() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getNFCReaderEntry());
        vb.getChildren().add(getControls());

        getChildren().add(vb);
    }

    private GridPane getNFCReaderEntry() {

        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75, HPos.LEFT);

        VBox vbHead = JKNode.getPageHeadVB("NFC Card Reader");

        Label lblInfo = JKText.getLblDk("If no NFC reader is attached, a barcode scanner can be used to read the card number", JKText.FONT_B_XXSM);
        lblInfo.setWrapText(true);

        Label lblType = JKText.getLblDk("Type", JKText.FONT_B_XSM);

        chkRead = new CheckBox("Use NFC Card Reader");
        chkRead.setSelected(JKNFCReader.getNfcReaderConfig().isNfcCardRead());

        chcType = new ComboBox();
        chcType.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.75), 35);
        chcType.getSelectionModel().select(JKNFCReader.getNfcReaderConfig().getNfcReaderModel());
        chcType.getItems().addAll(NFCReaders.getListNFCReaders());

        grid.add(vbHead, 0, 0, 2, 1);

        grid.add(lblInfo, 0, 1, 2, 1);

        grid.add(chkRead, 1, 3);
        grid.addRow(5, lblType, chcType);

        return grid;
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("Test NFC\nReader", true) {
            @Override
            public void onClickTest() {
                StageComponents.showStageTestPopup("Test NFC Reader",
                        "Please tap card, \nand wait for Card Number to appear in text field", "Test", null);
            }

            @Override
            public void onClickSave() {
                saveNFCSettings();
            }
        };
    }

    private void saveNFCSettings() {

        JKNFCReader.getNfcReaderConfig().setNfcCardRead(chkRead.isSelected());
        JKNFCReader.getNfcReaderConfig().setNfcReaderModel((NFCReaders) chcType.getSelectionModel().getSelectedItem());

        if (JKNFCReader.saveCardReaderConfig()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "NFC Card Reader settings saved successfully", null);
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "NFC Card Reader settings not saved", null);
        }
    }

    private void updateTestBtnState() {
//        if (JKCardReader.getCardReaderConfig().isMagCardRead() || JKCardReader.getCardReaderConfig().isMagCardWrite()) {
//            SceneSetupControls.getBtnTest().setDisable(false);
//        } else {
//            SceneSetupControls.getBtnTest().setDisable(true);
//        }
    }
}
