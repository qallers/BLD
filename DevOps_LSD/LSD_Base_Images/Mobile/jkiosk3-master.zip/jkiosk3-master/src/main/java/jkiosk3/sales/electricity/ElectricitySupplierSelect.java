package jkiosk3.sales.electricity;

import java.util.ArrayList;
import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.*;
import jkiosk3.printing.PrintUtil;
import jkiosk3.sales.SalesItems;
import jkiosk3.sales.SceneSales;
import jkiosk3.store.JKCardReader;

public class ElectricitySupplierSelect extends Region {

    private List<ElectricityProvider> listProvidersForUser;
    private String tokenNumber;

    public ElectricitySupplierSelect() {
        listProvidersForUser = SalesItems.getElecSuppliers();

        if (listProvidersForUser.isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Electricity Providers", "No Electricity Providers configured for this Device", null);
            SceneSales.clearAndShowFavourites();
        } else {
            getChildren().add(getElecProviderButtons());
        }
    }

    private VBox getElecProviderButtons() {

        Label lblProviders = JKText.getLblDk("Electricity Providers", JKText.FONT_B_SM);

        Label lblInstruct = JKText.getLblDk("Enter Token Number WITHOUT spaces or dashes", JKText.FONT_B_20);
        final TextField txtTokenNum = new TextField();
        txtTokenNum.setMaxWidth(350);
        txtTokenNum.setMinWidth(350);
        txtTokenNum.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtTokenNum, "Token Number", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        if (!isValidInput(value)) {
                            txtTokenNum.clear();
                        }
                    }
                });
            }
        });

        final VBox vBox = JKLayout.getVBox(JKLayout.sp, (2 * JKLayout.sp));
        vBox.getChildren().addAll(lblInstruct, txtTokenNum);

        Button btnEncode = JKNode.getBtnPopupDbl("Encode Token");
        btnEncode.setFont(JKText.FONT_B_XXSM);
        btnEncode.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                JKiosk3.getInputPopup().showInputBox(InputPopup.MSG_OK_CANCEL, false, "Encode Token", vBox,
                        new InputPopupResult() {
                            @Override
                            public void onSave() {
                                // 'isSaveContents' is false, do nothing
                            }

                            @Override
                            public void onOk() {
                                txtTokenNum.clear();
                                PrintUtil.writeMagCardTokenEncode(tokenNumber);
                            }

                            @Override
                            public void onCancel() {
                                // default action - close popup
                            }
                        });
            }
        });

        Button btnPlaceholder = new Button();
        btnPlaceholder.setVisible(false);

        VBox vbHead = JKNode.getPageDblHeadVB(0, lblProviders, btnPlaceholder);
        if (JKCardReader.getCardReaderConfig().isMagCardWrite()) {
            vbHead = JKNode.getPageDblHeadVB(0, lblProviders, btnEncode);
        }
        vbHead.setMaxWidth(JKLayout.contentW - (2 * JKLayout.sp));

        List<Button> listProvBtns = new ArrayList<>();

        for (final ElectricityProvider provider : listProvidersForUser) {
            Button btn = JKNode.getBtnSmDbl(provider.getDisplayName());
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    SceneSales.clearAndChangeContent(new ElectricityMenu(provider));
                }
            });
            listProvBtns.add(btn);
        }

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, listProvBtns);

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private boolean isValidInput(String tokenNum) {
        System.out.println("length of value entered = " + tokenNum.length());
        if (tokenNum.equalsIgnoreCase("")) {
            JKiosk3.getMsgBox().showMsgBox("Token Number cannot be empty", "Please enter a Token Number", null);
            return false;
        }
        if ((tokenNum.matches("\\d{16}")) || (tokenNum.matches("\\d{20}"))) {
            tokenNumber = tokenNum;
        } else {
            JKiosk3.getMsgBox().showMsgBox("Invalid Number", "Please enter a valid Token Number", null);
            return false;
        }
        return true;
    }
}
