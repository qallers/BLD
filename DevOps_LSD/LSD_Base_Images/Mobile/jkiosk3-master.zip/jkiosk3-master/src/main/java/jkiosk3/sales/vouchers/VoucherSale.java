package jkiosk3.sales.vouchers;

import aeonairtime.AirtimeManufacturer;
import aeonairtime.AirtimeProduct;

import aeonairtime.VoucherMultiResp;
import jkiosk3.sales.SaleType;

public class VoucherSale {

    private SaleType saleType;
    private AirtimeManufacturer provider = null;
    private AirtimeProduct product = null;
    private boolean canCancel;
    private VoucherMultiResp response;
    private boolean rechargePlus;

    private static VoucherSale instance;

    private static VoucherSale newInstance() {
        instance = new VoucherSale();
        return instance;
    }

    public static VoucherSale getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    public static void resetVoucherSale() {
        instance = null;
    }

    // getters and setters
    public SaleType getSaleType() {
        return saleType;
    }

    public void setSaleType(SaleType saleType) {
        this.saleType = saleType;
    }

    public AirtimeManufacturer getProvider() {
        return provider;
    }

    public void setProvider(AirtimeManufacturer provider) {
        this.provider = provider;
    }

    public AirtimeProduct getProduct() {
        return product;
    }

    public void setProduct(AirtimeProduct product) {
        this.product = product;
    }

    public boolean isCanCancel() {
        return canCancel;
    }

    public void setCanCancel(boolean canCancel) {
        this.canCancel = canCancel;
    }

    public VoucherMultiResp getResponse() {
        return response;
    }

    public void setResponse(VoucherMultiResp response) {
        this.response = response;
    }

    public boolean isRechargePlus() {
        return rechargePlus;
    }

    public void setRechargePlus(boolean rechargePlus) {
        this.rechargePlus = rechargePlus;
    }
}
