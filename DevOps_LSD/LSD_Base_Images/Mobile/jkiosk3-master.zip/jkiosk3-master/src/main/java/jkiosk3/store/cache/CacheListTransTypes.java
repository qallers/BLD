package jkiosk3.store.cache;

import aeonusers.UserTransactionType;
import java.util.List;
import jkiosk3.store.Store;

/**
 *
 * @author valeriew
 */
public class CacheListTransTypes {
    
    private static volatile ListTransTypes listTransTypes;

    private static ListTransTypes getListTransTypes() {
        if (listTransTypes == null) {
            listTransTypes = ((ListTransTypes) Store.loadObject(CacheListTransTypes.class.getSimpleName()));
        }
        if (listTransTypes == null) {
            listTransTypes = new ListTransTypes();
        }
        return listTransTypes;
    }

    private static void saveListTransTypes(ListTransTypes listTransTypes) {
        Store.saveObject(CacheListTransTypes.class.getSimpleName(), listTransTypes);
    }
    
    public static void saveUserTransactionTypes(List<UserTransactionType> listUserTransTypes) {
        if (getListTransactionTypes().size() > 0) {
            listTransTypes.getListTransTypes().clear();
            listTransTypes.getListTransTypes().addAll(listUserTransTypes);
            saveListTransTypes(listTransTypes);
        } else {
            listTransTypes.getListTransTypes().addAll(listUserTransTypes);
            saveListTransTypes(listTransTypes);
        }
    }
    
    public static boolean hasItems() {
        getListTransTypes();
        return listTransTypes.getListTransTypes().size() > 0;
    }

    public static List<UserTransactionType> getListTransactionTypes() {
        getListTransTypes();
        return listTransTypes.getListTransTypes();
    }
    
    public static void deleteCacheTransTypes() {
        Store.deleteObject(CacheListTransTypes.class.getSimpleName());
    }
    
    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheListTransTypes.class.getSimpleName());
    }    
}
