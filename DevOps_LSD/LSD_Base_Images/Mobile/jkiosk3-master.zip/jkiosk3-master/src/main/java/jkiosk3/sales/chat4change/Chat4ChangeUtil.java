package jkiosk3.sales.chat4change;

import aeonvarivouchers.Supplier;
import aeonvarivouchers.VDVSupplierListResp;
import aeonvarivouchers.VDVoucherReq;
import aeonvarivouchers.VDVoucherResp;
import aeonvarivouchers.VariableVoucherConnection;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.concurrent.Task;
import jkiosk3.JKiosk3;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.store.cache.CacheListC4CSuppliers;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

public class Chat4ChangeUtil {

    private final static Logger LOG = Logger.getLogger(Chat4ChangeUtil.class.getName());
    private static VariableVoucherConnection c4cConn;
    private static String userPin;
    private static boolean isAuthenticated = false;
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 60;

    public static VariableVoucherConnection getChat4ChangeConnect() {
        VariableVoucherConnection c4cConnect = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            c4cConnect = new VariableVoucherConnection(server, port, secureConnect);
            c4cConnect.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            LOG.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            LOG.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            LOG.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            LOG.log(Level.SEVERE, e.getMessage(), e);
        }
        return c4cConnect;
    }

    private static boolean isLoggedIn(String pin) throws RuntimeException {
        String loyaltyProfileId = "";
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            loyaltyProfileId = ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId();
        }

        boolean loggedIn = false;
        c4cConn = getChat4ChangeConnect();
        int deviceId = JKSystem.getSystemConfig().getDeviceId();
        String serial = JKSystem.getSystemConfig().getSerial();
        try {
            if (c4cConn != null) {
                loggedIn = c4cConn.login(pin, deviceId, serial, loyaltyProfileId);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    private static VDVSupplierListResp getC4CSupplierList() throws RuntimeException {
        VDVSupplierListResp suppliers = new VDVSupplierListResp();
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                String ref = SalesUtil.getUniqueRef();
                suppliers = c4cConn.getListSuppliers(ref);

                Collections.sort(suppliers.getSupplierList(), new Comparator<Supplier>() {
                    @Override
                    public int compare(Supplier s1, Supplier s2) {
                        return s1.getName().compareToIgnoreCase(s2.getName());
                    }
                });
//                suppliers.getSupplierList().sort(new Comparator<Supplier>() {
//                    @Override
//                    public int compare(Supplier s1, Supplier s2) {
//                        return s1.getName().compareToIgnoreCase(s2.getName());
//                    }
//                });
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Chat 4 Change Supplier List Error", t);
        } finally {
            if (c4cConn != null) {
                c4cConn.disconnect();
            }
        }
        return suppliers;
    }

    public static List<Supplier> getC4CSuppliersList() throws RuntimeException {
        List<Supplier> listC4CSuppliers = new ArrayList<>();

        if (CacheListC4CSuppliers.hasItems()) {
            LOG.info("getting C4C supplier list from cache");
            listC4CSuppliers = CacheListC4CSuppliers.getListC4CSuppliers();
        } else {
            LOG.info("getting C4C supplier list from server");
            VDVSupplierListResp supplierResp = getC4CSupplierList();
            listC4CSuppliers = supplierResp.getSupplierList();
        }

        Collections.sort(listC4CSuppliers, new Comparator<Supplier>() {
            @Override
            public int compare(Supplier s1, Supplier s2) {
                return s1.getName().compareToIgnoreCase(s2.getName());
            }
        });
//        listC4CSuppliers.sort(new Comparator<Supplier>() {
//            @Override
//            public int compare(Supplier s1, Supplier s2) {
//                return s1.getName().compareToIgnoreCase(s2.getName());
//            }
//        });

        return listC4CSuppliers;
    }

    private static VDVoucherResp getC4CVoucher(VDVoucherReq req) throws RuntimeException {
        VDVoucherResp c4cVoucher = new VDVoucherResp();
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                isAuthenticated = true;
                c4cVoucher = c4cConn.getChat4ChangeVoucher(req);
            } else {
                isAuthenticated = false;
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Chat 4 Change Voucher Error", t);
        } finally {
            if (c4cConn != null) {
                c4cConn.disconnect();
            }
        }
        return c4cVoucher;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getC4CSupplierList(final C4CListSuppliersResult result) {
        JKiosk3.getBusy().showBusy("Getting Provider List");

        final Task<List<Supplier>> taskC4CSupplier = new Task<List<Supplier>>() {
            @Override
            protected List<Supplier> call() throws Exception {
                return getC4CSuppliersList();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.c4cListSuppliersResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Chat 4 Change Provider Error",
                        "Unable to retrieve Provider List", State.CANCELLED, errorMsg, null);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Chat 4 Change Provider Error",
                        "Unable to retrieve Provider List", State.FAILED, errorMsg, null);
            }
        };

        new Thread(taskC4CSupplier).start();
        JKiosk3.getBusy().startCountdown(taskC4CSupplier, countdownTime);
    }

    public static void getC4CVoucher(final VDVoucherReq req, final C4CVoucherResult result) {
        JKiosk3.getBusy().showBusy("Getting Chat 4 Change Voucher");

        final Task<VDVoucherResp> taskC4CVoucher = new Task<VDVoucherResp>() {
            @Override
            protected VDVoucherResp call() throws Exception {
                return getC4CVoucher(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.c4cVoucherResult(getValue());
            }

            @Override
            protected void cancelled() {
                if (isAuthenticated) {
                    taskutil.taskSaleCancelFailLogout("Chat 4 Change Voucher Error", "Unable to retrieve Voucher", State.CANCELLED, errorMsg);
                } else {
                    taskutil.taskSaleCancelFailLogout("Chat 4 Change Login Error", "Unable to retrieve Voucher", State.CANCELLED, errorMsg);
                }
            }

            @Override
            protected void failed() {
                if (isAuthenticated) {
                    taskutil.taskSaleCancelFailLogout("Chat 4 Change Voucher Error", "Unable to retrieve Voucher", State.FAILED, errorMsg);
                } else {
                    taskutil.taskSaleCancelFailLogout("Chat 4 Change Login Error", "Unable to retrieve Voucher", State.FAILED, errorMsg);
                }
            }
        };
        new Thread(taskC4CVoucher).start();
        JKiosk3.getBusy().startCountdown(taskC4CVoucher, countdownTime);
    }

    public static abstract class C4CSupplierResult {

        public abstract void c4cSupplierListResult(VDVSupplierListResp c4cSupplierList);
    }

    public static abstract class C4CVoucherResult {

        public abstract void c4cVoucherResult(VDVoucherResp c4cVoucher);
    }

    public static abstract class C4CListSuppliersResult {

        public abstract void c4cListSuppliersResult(List<Supplier> listSuppliers);
    }
}
