package jkiosk3.sales.electricity.eskom;

import aeonelectricity.EskomFault;
import aeonelectricity.EskomFaultReq;
import aeonelectricity.EskomFaultType;

import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.PrintUtil;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.electricity.ElecShareBtnsLessMore;
import jkiosk3.sales.electricity.ElecShareGridLessMore;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.store.JKOptions;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.users.UserUtil;

/**
 * @author valerie
 */
public class ElecLogFault extends Region {

    private final ElectricityProvider provider;
    private List<EskomFaultType> listFaultTypes;
    private final String transType;
    private EskomFaultType selectedFault;
    private ElecShareBtnsLessMore btnsLessMore;
    private ElecShareGridLessMore gridLessMore;
    private VBox vbMore;
    private TextField txtMeter;
    private TextField txtCellNum;
    private TextField txtName;
    private TextField txtAddress;

    public ElecLogFault(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;
        transType = "FaultReport";
        selectedFault = null;
        ElectricityUtil.getListEskomFaults (transType, new ElectricityUtil.EskomFaultListResult () {
            @Override
            public void eskomFaultList(List<EskomFaultType> eskomFaultTypes) {
                if (eskomFaultTypes == null || eskomFaultTypes.isEmpty ()) {
                    JKiosk3.getMsgBox ().showMsgBox ("List Fault Types", "Unable to retrieve Fault Type List.", null);
                } else {
                    listFaultTypes = eskomFaultTypes;
                    getChildren ().add (getLogFaultLayout ());
                }
            }
        });
    }

    private VBox getLogFaultLayout() {
        VBox vbFault = JKLayout.getVBox (0, JKLayout.spNum);
        vbFault.getChildren ().add (getLogFaultEntry ());
        vbFault.getChildren ().add (getElecSaleCtrls ());
        return vbFault;
    }

    private VBox getLogFaultEntry() {

        vbMore = JKLayout.getVBoxContent (JKLayout.spNum);

        Label lblUpdate = JKText.getLblDk ("Electricity Log Fault - " + provider.getDisplayName (), JKText.FONT_B_XSM);

        Label lblMeter = JKText.getLblDk ("Meter Number", JKText.FONT_B_XSM);
        Label lblCellNum = JKText.getLblDk ("Customer Cell Number", JKText.FONT_B_XSM);
        Label lblName = JKText.getLblDk ("Customer Name", JKText.FONT_B_XSM);
        Label lblAddress = JKText.getLblDk ("Customer Address", JKText.FONT_B_XSM);
        Label lblFaultCode = JKText.getLblDk ("Fault Select", JKText.FONT_B_XSM);

        txtMeter = new TextField ();
        txtMeter.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getKeyboard ().showKeyboard (txtMeter, "Enter Meter Number", "", true);
                }
            }
        });

        txtCellNum = new TextField ();
        txtCellNum.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtCellNum, "Cell Number", "");
                }
            }
        });

        txtName = new TextField ();
        txtName.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getKeyboard ().showKeyboard (txtName, "Enter Customer Name", "", true);
                }
            }
        });

        txtAddress = new TextField ();
        txtAddress.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getKeyboard ().showKeyboard (txtAddress, "Enter Customer Address", "", true);
                }
            }
        });

        ComboBox cmbFaultList = new ComboBox ();
        cmbFaultList.setPrefWidth ((JKLayout.contentW - (2 * JKLayout.sp)) / 2);
        cmbFaultList.setVisibleRowCount (15);
        ObservableList<EskomFaultType> listFaults = FXCollections.observableArrayList (listFaultTypes);
        cmbFaultList.setItems (listFaults);
        cmbFaultList.getSelectionModel ().selectedItemProperty ().addListener (new ChangeListener () {
            @Override
            public void changed(ObservableValue ov, Object t, Object newSelection) {
                selectedFault = (EskomFaultType) newSelection;
            }
        });

        GridPane grid = JKLayout.getContentGridInner2Col (0.5, 0.5);

        grid.add (lblUpdate, 0, 0, 2, 1);
        grid.add (JKNode.createGridSpanSep (2), 0, 1);

        grid.addRow (2, lblMeter, txtMeter);
        grid.addRow (3, lblCellNum, txtCellNum);
        grid.addRow (4, lblName, txtName);
        grid.addRow (5, lblAddress, txtAddress);
        grid.addRow (6, lblFaultCode, cmbFaultList);

        gridLessMore = new ElecShareGridLessMore (ElectricityUtil.ELEC_FAULT_REPORT);
        gridLessMore.setMaxWidth (JKLayout.contentW - (2 * JKLayout.sp));
        gridLessMore.setMinWidth (JKLayout.contentW - (2 * JKLayout.sp));

        vbMore.getChildren ().addAll (grid);

        return vbMore;
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        btnsLessMore = new ElecShareBtnsLessMore ();

        if (provider.getDisplayName ().contains ("Eskom")
                || provider.getDisplayName ().contains ("Universal")) {
            btnsLessMore.getBtnLess ().setVisible (true);
            btnsLessMore.getBtnLess ().setOnMouseReleased (new EventHandler () {
                @Override
                public void handle(Event arg0) {
                    getLessMoreAction (btnsLessMore.getBtnLess ());
                }
            });
            btnsLessMore.getBtnMore ().setVisible (true);
            btnsLessMore.getBtnMore ().setOnMouseReleased (new EventHandler () {
                @Override
                public void handle(Event arg0) {
                    getLessMoreAction (btnsLessMore.getBtnMore ());
                }
            });
        }

        btnsLessMore.getBtnAccept ().setDisable (false);
        btnsLessMore.getBtnAccept ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                if (validateInput ()) {
                    createAndLogFault ();
                }
            }
        });
        btnsLessMore.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });
        return btnsLessMore;
    }

    private void getLessMoreAction(Button b) {
        switch (b.getText ()) {
            case "Less...":
                vbMore.getChildren ().remove (gridLessMore);
                btnsLessMore.getBtnLess ().setDisable (true);
                btnsLessMore.getBtnMore ().setDisable (false);
                btnsLessMore.getBtnAccept ().setDisable (true);
                break;
            case "More...":
                vbMore.getChildren ().add (1, gridLessMore);
                btnsLessMore.getBtnLess ().setDisable (false);
                btnsLessMore.getBtnMore ().setDisable (true);
                btnsLessMore.getBtnAccept ().setDisable (false);
                break;
            default:
                vbMore.getChildren ().remove (gridLessMore);
                break;
        }
    }

    private void createAndLogFault() {
        EskomFaultReq req = new EskomFaultReq ();
        String meterNum = txtMeter.getText ();
        req.setMeterNum (meterNum);
        req.setCellNum (txtCellNum.getText ());
        req.setCustomerName (txtName.getText ());
        req.setCustomerAddress (txtAddress.getText ());
        req.setFaultCode (selectedFault.getFaultCode ());
        req.setSgc (gridLessMore.getTxtSGC ().getText ());
        req.setTt (gridLessMore.getTxtTT ().getText ());
        req.setTi (gridLessMore.getTxtTi ().getText ());
        req.setKrn (gridLessMore.getTxtKrn ().getText ());
        req.setAt (gridLessMore.getTxtAlg ().getText ());

        ElectricityUtil.logEskomFault (transType, req, new ElectricityUtil.EskomFaultLogged () {
            @Override
            public void eskomFaultLogged(EskomFault eskomFault) {
                if (eskomFault.isSuccess ()) {
                    if (JKPrintOptions.getPrintOptions ().isPrintPreview ()) {
                        JKiosk3.getPrintPreview ().showPrintPreview ("Eskom Fault Log", eskomFault.getPrintJob (),
                                PrintPreview.PRN_OK_CANCEL, new PrintPreviewResult () {
                                    @Override
                                    public void onOk() {
                                        //
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    } else {
                        PrintUtil.sendToPrinter (eskomFault.getPrintJob ());
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Log Fault Error", !eskomFault.getAeonErrorMsg ().isEmpty () ?
                            "A" + eskomFault.getAeonErrorCode () + " - " + eskomFault.getAeonErrorMsg () :
                            "B" + eskomFault.getErrorCode () + " - " + eskomFault.getErrorMsg (), null);
                }
                ElectricityUtil.resetElectricity ();
            }
        });
    }

    private boolean validateInput() {
        if (selectedFault == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Fault Type", "Please select a Fault Type from the list", null);
            return false;
        }
        return true;
    }
}
