package jkiosk3.sales.ticketpro.collect;

import aeonprinting.AeonPrintJob;
import aeonticketpros.TicketProsPrintReq;
import aeonticketpros.TicketProsPrintResp;
import aeonticketpros.TicketProsTicket;

import java.io.File;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.PrintUtil;
//import jkiosk3.printing.print_layouts.PrintTicketPro;
import jkiosk3.printing.print_layouts.PrintTicketPro;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.ticketpro.TicketProUtil;
import jkiosk3.store.JKOptions;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.store.JKPrinterTickets;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.UserUtil;
import jkiosk3.utilities.DownloadUtil;

public class TicketProCollect extends Region {

    private final static Logger logger = Logger.getLogger (TicketProCollect.class.getName ());
    private TextField txtBookingRef;
    private String bookingRef;
    private TicketProsPrintResp printResp;
    private List<TicketProsTicket> listPrintTickets;
    private int currentPrintJob;

    public TicketProCollect() {
        CurrentUser.setSalesUser (CurrentUser.getUser ());
        VBox vbReprint = JKLayout.getVBox (0, JKLayout.spNum);
        vbReprint.getChildren ().add (getCollectEntry ());
        vbReprint.getChildren ().add (getControlButtons ());
        getChildren ().add (vbReprint);
    }

    private GridPane getCollectEntry() {
        Label lblTicketsCollect = JKText.getLblContentHead ("TicketPro - Collection");

        Label lblReference = JKText.getLblDk ("Booking Reference", JKText.FONT_B_XSM);

        txtBookingRef = new TextField ();
        txtBookingRef.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getKeyboard ().showKeyboard (txtBookingRef, "Enter Booking Reference", "",
                            false, false, new KeyboardResult () {
                                @Override
                                public void onDone(String value) {
                                    txtBookingRef.setText (value.toUpperCase (Locale.ENGLISH));
                                }
                            });
                }
            }
        });

        GridPane grid = JKLayout.getGridContent2Col (0.5, 0.5);

        grid.add (lblTicketsCollect, 0, 0, 2, 1);
        grid.add (JKNode.createGridSpanSep (2), 0, 1);
        grid.addRow (3, lblReference, txtBookingRef);

        return grid;
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons ();

        ctrlBtns.getBtnAccept ().setDisable (false);
        ctrlBtns.getBtnAccept ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (isValidEntry ()) {
                    requestTickets ();
                }
            }
        });
        ctrlBtns.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndShowFavourites ();
            }
        });

        return ctrlBtns;
    }

    private void requestTickets() {
        logger.info (("TicketPro Booking Ref entered for Collection : ").concat (bookingRef));

        final TicketProsPrintReq collectRequest = new TicketProsPrintReq ();
        collectRequest.setTransactionId (bookingRef);
        if (JKPrinterTickets.getPrinterTickets ().isUseDefaultPrinter ()) {
            collectRequest.setFormat ("xml");
        } else if (JKPrinterTickets.getPrinterTickets ().isUseSerialPrinter ()) {
            collectRequest.setFormat ("ezpl");
        }
        collectRequest.setCardId ("");
        collectRequest.setReprint (false);

        TicketProUtil.getTicketCollection (1, collectRequest, new TicketProUtil.TicketProPrintResult () {

            @Override
            public void tpPrintResult(TicketProsPrintResp tpPrintResp) {
                if (tpPrintResp.isSuccess ()) {

                    if (collectRequest.getFormat ().equalsIgnoreCase ("xml")) {
                        if (!tpPrintResp.getListTickets ().isEmpty ()) {
                            printResp = tpPrintResp;
                            listPrintTickets = printResp.getListTickets ();
                            printTickets ();
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("TicketPro - Tickets Not Printed",
                                    "\nPlease refer the Customer to\n\nTicketPro Customer Services\n\n" +
                                            JK3Config.getInfoTicketProCustomerServicesTelNum ()
                                            + "\n\nMon - Fri : 08h00 - 16h00"
                                            + "\n\nand quote Reference number printed on Sales Receipt",
                                    null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK,
                                    new MessageBoxResult () {

                                        @Override
                                        public void onOk() {
                                            SceneSales.clearAndShowFavourites ();
                                        }

                                        @Override
                                        public void onCancel() {
                                            //
                                        }
                                    });
                        }
                    } else if (collectRequest.getFormat ().equalsIgnoreCase ("ezpl")) {
                        final File printFile = DownloadUtil.downloadRemoteFile (tpPrintResp.getTickets (), JK3Config.getTicketPrint ());
                        if (printFile != null) {
                            JKiosk3.getMsgBox ().showMsgBox ("TicketPro Collection", "Tickets will be printed on TicketPrinter",
                                    null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                        @Override
                                        public void onOk() {
                                            PrintHandler.writeFileContentToPrinterPort (printFile);
                                        }

                                        @Override
                                        public void onCancel() {
                                            //
                                        }
                                    });
                        } else {
                            JKiosk3.getMsgBox ().showMsgBox ("TicketPro - Tickets Not Received from TicketPro",
                                    "\nPlease refer the Customer to\n\nTicketPro Customer Services\n\n" +
                                            JK3Config.getInfoTicketProCustomerServicesTelNum ()
                                            + "\n\nMon - Fri : 08h00 - 16h00"
                                            + "\n\nand quote Reference number printed on Sales Receipt", null);
                        }
                    }
                    SceneSales.clearAndShowFavourites ();

                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Collection Error", !tpPrintResp.getAeonErrorText ().isEmpty () ?
                            "A" + tpPrintResp.getAeonErrorCode () + " - " + tpPrintResp.getAeonErrorText () :
                            "B" + tpPrintResp.getErrorCode () + " - " + tpPrintResp.getErrorText (), null);
                    logger.info (("TicketPro Collect failed  :  ").concat (!tpPrintResp.getAeonErrorText ().isEmpty () ?
                            "A" + tpPrintResp.getAeonErrorCode () + " - " + tpPrintResp.getAeonErrorText () :
                            "B" + tpPrintResp.getErrorCode () + " - " + tpPrintResp.getErrorText ()));
                }
            }
        });
    }

    private void printTickets() {
        /* COLLECT must always print immediately - do NOT add to print queue. */
        /* This is ESSENTIAL to stop from trying to 'Set Printed' with a ticket Serial Number, which will of course fail. */
        if (JKPrintOptions.getPrintOptions ().isPrintPreview ()) {
            currentPrintJob = 0;
            printTicketsPreviewed ();
        } else {
            for (TicketProsTicket t : listPrintTickets) {
                AeonPrintJob apj = PrintTicketPro.getTicketProTicketPrint (printResp, t);
//                AeonPrintJob apj = t.getAeonPrintJob();
                PrintUtil.sendToPrinter (apj);
            }
        }
        UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
    }

    private void printTicketsPreviewed() {
        AeonPrintJob apj = PrintTicketPro.getTicketProTicketPrint (printResp, listPrintTickets.get (currentPrintJob));
//        AeonPrintJob apj = listPrintTickets.get(currentPrintJob).getAeonPrintJob();
        JKiosk3.getPrintPreview ().showPrintPreview ("TicketPro", apj, PrintPreview.PRN_OK, new PrintPreviewResult () {
            @Override
            public void onOk() {
                currentPrintJob++;
                if (currentPrintJob < listPrintTickets.size ()) {
                    printTicketsPreviewed ();
                }
            }

            @Override
            public void onCancel() {
                //
            }
        });
    }

    private boolean isValidEntry() {
        if (!txtBookingRef.getText ().trim ().isEmpty ()) {
            if (txtBookingRef.getText ().trim ().matches ("\\w{10}")) {
                bookingRef = txtBookingRef.getText ().trim ();
            } else {
                JKiosk3.getMsgBox ().showMsgBox ("Booking Reference", "Please enter a valid 10-character Booking Reference", null);
                return false;
            }
        } else {
            JKiosk3.getMsgBox ().showMsgBox ("Booking Reference", "Please enter a Booking Reference", null);
            return false;
        }
        return true;
    }
}
