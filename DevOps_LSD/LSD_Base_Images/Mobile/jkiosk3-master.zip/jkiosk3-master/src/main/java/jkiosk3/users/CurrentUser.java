package jkiosk3.users;

import aeonusers.User;

/**
 *
 * @author Val
 */
public class CurrentUser {

    private static User user;
    private static User salesUser;
    private static boolean loggedInOnline;

    public static User getUser() {
        return user;
    }

    public static void setUser(User user) {
        CurrentUser.user = user;
    }

    public static User getSalesUser() {
        return salesUser;
    }

    public static void setSalesUser(User salesUser) {
        CurrentUser.salesUser = salesUser;
    }

    public static boolean isLoggedInOnline() {
        return loggedInOnline;
    }

    public static void setLoggedInOnline(boolean loggedInOnline) {
        CurrentUser.loggedInOnline = loggedInOnline;
    }
}
