package jkiosk3.sales._favourites.nfc;

import com.sun.jersey.api.client.*;
import com.sun.jersey.api.client.filter.ClientFilter;

//import org.slf4j.Logger;//
//import org.slf4j.LoggerFactory;

import java.io.*;

public class LoggingFilter extends ClientFilter {

//    private static final Logger LOG = LoggerFactory.getLogger(LoggingFilter.class);

    private static final int maxEntitySize = 10240;


    @Override
    public ClientResponse handle(ClientRequest request) throws ClientHandlerException {
        this.logRequest(request);
        ClientResponse response = this.getNext().handle(request);
        this.logResponse(response);
        return response;
    }

    private void logRequest(ClientRequest request) {
        StringBuilder b = new StringBuilder();
        this.includeUrlInLog(request, b);
        this.includeRequestHeadersInLog(request, b);
        if (request.getEntity() != null) {
            request.setAdapter(new LoggingFilter.Adapter(request.getAdapter(), b));
        } else {
            this.logOutbound(b);
        }
    }

    private void includeUrlInLog(ClientRequest request, StringBuilder sb) {
        sb.append(request.getURI().toString());
        sb.append(System.lineSeparator());
    }

    private void includeRequestHeadersInLog(ClientRequest request, StringBuilder sb) {
        for (String headerName : request.getHeaders().keySet()) {
            for (Object headerValue : request.getHeaders().get(headerName)) {
                sb.append(String.format("%32s : %s%n", headerName, headerValue));
            }
        }
        if (!request.getHeaders().isEmpty()) {
            sb.append(System.lineSeparator());
        }
    }

    private void logResponse(ClientResponse response) {
        StringBuilder b = new StringBuilder();
        this.includeStatusInLog(response, b);
        this.includeResponseHeadersInLog(response, b);

        Object stream = response.getEntityInputStream();

        try {
            if (!response.getEntityInputStream().markSupported()) {
                stream = new BufferedInputStream((InputStream) stream);
                response.setEntityInputStream((InputStream) stream);
            }

            ((InputStream) stream).mark(maxEntitySize + 1);
            byte[] entity = new byte[maxEntitySize + 1];
            int entitySize = ((InputStream) stream).read(entity);

            if (entitySize > 0) {
                b.append(new String(entity, 0, Math.min(entitySize, maxEntitySize)));
                if (entitySize > maxEntitySize) {
                    b.append("...more...");
                }
                b.append('\n');
                ((InputStream) stream).reset();
            }
        } catch (IOException var8) {
            throw new ClientHandlerException(var8);
        }

        this.logInbound(b);
    }

    private void includeStatusInLog(ClientResponse response, StringBuilder sb) {
        sb.append("Status: ");
        sb.append(response.getStatusInfo().getStatusCode());
        sb.append(" (");
        sb.append(response.getStatusInfo().getReasonPhrase());
        sb.append(")");
        sb.append(System.lineSeparator());
    }

    private void includeResponseHeadersInLog(ClientResponse response, StringBuilder sb) {
        for (String headerName : response.getHeaders().keySet()) {
            for (String headerValue : response.getHeaders().get(headerName)) {
                sb.append(String.format("%32s : %s%n", headerName, headerValue));
            }
        }

        if (!response.getHeaders().isEmpty()) {
            sb.append(System.lineSeparator());
        }
    }

    private void logOutbound(StringBuilder b) {
//        LOG.trace("(Outbound ReST Message)\n" + b.toString());
        System.out.println("(Outbound ReST Message)\n" + b.toString());
    }

    private void logInbound(StringBuilder b) {
//        LOG.trace("(Inbound ReST Message)\n" + b.toString());
        System.out.println("(Inbound ReST Message)\n" + b.toString());
    }

    private void printEntity(StringBuilder b, byte[] entity) {
        if (entity.length != 0) {
            b.append(new String(entity)).append("\n");
        }
    }

    private final class LoggingOutputStream extends OutputStream {
        private final OutputStream out;
        private final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        private final StringBuilder b;

        LoggingOutputStream(OutputStream out, StringBuilder b) {
            this.out = out;
            this.b = b;
        }

        public void write(byte[] b) throws IOException {
            this.baos.write(b);
            this.out.write(b);
        }

        public void write(byte[] b, int off, int len) throws IOException {
            this.baos.write(b, off, len);
            this.out.write(b, off, len);
        }

        public void write(int b) throws IOException {
            this.baos.write(b);
            this.out.write(b);
        }

        public void close() throws IOException {
            LoggingFilter.this.printEntity(this.b, this.baos.toByteArray());
            LoggingFilter.this.logOutbound(this.b);
            this.out.close();
        }
    }

    private final class Adapter extends AbstractClientRequestAdapter {

        private final StringBuilder b;

        Adapter(ClientRequestAdapter cra, StringBuilder b) {
            super(cra);
            this.b = b;
        }

        public OutputStream adapt(ClientRequest request, OutputStream out) throws IOException {
            return LoggingFilter.this.new LoggingOutputStream(this.getAdapter().adapt(request, out), this.b);
        }
    }
}