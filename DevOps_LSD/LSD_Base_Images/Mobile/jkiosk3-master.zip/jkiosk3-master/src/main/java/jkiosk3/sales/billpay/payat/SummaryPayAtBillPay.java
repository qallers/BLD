package jkiosk3.sales.billpay.payat;

import aeonbillpayments.payat.PayAtAccPayReq;
import aeonbillpayments.payat.PayAtAccPayResp;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3.sales._common.JKTenderToggles;

public class SummaryPayAtBillPay extends Region {

    private final PayAtAccPayResp resp1;
    private final PayAtAccPayReq req2;
    private final PayAtAccPayResp resp2;
    private final String tendered;

    public SummaryPayAtBillPay(PayAtAccPayResp rs1, PayAtAccPayReq rq2, PayAtAccPayResp rs2, String tenderType) {
        this.resp1 = rs1;
        this.req2 = rq2;
        this.resp2 = rs2;
        this.tendered = tenderType;
        getChildren().add(getSummaryGrid());
    }

    private GridPane getSummaryGrid() {

        Label lblPaying = JKText.getLblDk("Account Number", JKText.FONT_B_XSM);
        Label lblClientName = JKText.getLblDk("Client Name", JKText.FONT_B_XSM);
        Label lblContactNum = JKText.getLblDk("Contact Number", JKText.FONT_B_XSM);
        Label lblClientAddress = JKText.getLblDk("Client Address", JKText.FONT_B_XSM);
        Label lblTenderType = JKText.getLblDk("Tender Type", JKText.FONT_B_XSM);
        Label lblFullAmountDue = JKText.getLblDk("Full Amount Due", JKText.FONT_B_XSM);
        Label lblAmount = JKText.getLblDk("Amount Paid", JKText.FONT_B_XSM);
        Label lblConvenienceFee = JKText.getLblDk("Convenience Fee", JKText.FONT_B_XSM);
        Label lblTotalPayable = JKText.getLblDk("Total Payable", JKText.FONT_B_XSM);
//        Label lblBalance = JKText.getLblDk("Balance after payment", JKText.FONT_B_XSM);

        // filled-in fields
        Text txtAccNum = JKText.getTxtDk(req2.getAccountNo(), JKText.FONT_B_SM);

        String txtClientNameDisplay = "";
        if (resp2.getFirstName().equalsIgnoreCase(resp2.getLastName())) {
            txtClientNameDisplay = resp2.getLastName();
        } else {
            txtClientNameDisplay = resp2.getFirstName() + " " + resp2.getLastName();
        }
        Text txtClientName = JKText.getTxtDk(txtClientNameDisplay, JKText.FONT_B_XSM);
        txtClientName.setWrappingWidth((MessageBox.getMsgWidth() - (6 * JKLayout.sp)) * 0.6);
        txtClientName.setTextAlignment(TextAlignment.RIGHT);

        String strContact = "";
        if (resp2.getContactNumber().matches("\\d{10}")) {
            strContact = JKText.getCellNumFormatted(resp2.getContactNumber());
        } else {
            strContact = resp2.getContactNumber();
        }

        Text txtContactNum = JKText.getTxtDk(strContact, JKText.FONT_B_XSM);

        Text txtClientAddress = JKText.getTxtDk(resp2.getAddress(), JKText.FONT_B_XSM);
        txtClientAddress.setWrappingWidth((MessageBox.getMsgWidth() - (6 * JKLayout.sp)) * 0.6);
        txtClientAddress.setTextAlignment(TextAlignment.RIGHT);

        String txtTender = JKTenderToggles.getTxtForTender(tendered);
        Text txtTenderType = JKText.getTxtDk(txtTender, JKText.FONT_B_XSM);

//        Text txtFullAmountDue = JKText.getTxtDk(JKText.getDeciFormat(resp.getAmountDue()), JKText.FONT_B_XSM);
        Text txtFullAmountDue = JKText.getTxtDk(JKText.getDeciFormat(resp1.getAmountDue()), JKText.FONT_B_XSM);
        Text txtAmount = JKText.getTxtDk(JKText.getDeciFormat(req2.getAmountDue()), JKText.FONT_B_XSM);
        Text txtConvenienceFee = JKText.getTxtDk(JKText.getDeciFormat(resp2.getConvenienceFee()), JKText.FONT_B_XSM);
        double totalPayable = req2.getAmountDue() + resp2.getConvenienceFee();
        Text txtTotalPayable = JKText.getTxtDk(JKText.getDeciFormat(totalPayable), JKText.FONT_B_SM);
//        double balance = resp.getAmountDue() - req.getAmountDue();
//        Text txtBalance = JKText.getTxtDk(JKText.getDeciFormat(balance), JKText.FONT_B_XSM);

        GridPane grid = JKLayout.getSummaryGrid2Col(0.4, 0.6);
        grid.setTranslateX(-JKLayout.sp);

        grid.addRow(0, lblPaying, txtAccNum);
        grid.addRow(1, lblClientName, txtClientName);
        grid.addRow(2, lblContactNum, txtContactNum);
        grid.addRow(3, lblClientAddress, txtClientAddress);
        grid.addRow(4, lblTenderType, txtTenderType);
        grid.addRow(5, lblFullAmountDue, txtFullAmountDue);
        grid.addRow(6, lblAmount, txtAmount);
        grid.addRow(7, lblConvenienceFee, txtConvenienceFee);
        grid.addRow(8, lblTotalPayable, txtTotalPayable);
//        grid.addRow(9, lblBalance, txtBalance);

        return grid;
    }
}
