package jkiosk3.store;

import aeonprinting.AeonPrintJob;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Val
 */
public class JKReprint {

    private static List<StoreJKReprint> reprintList;

    public static void loadReprintList() {
        if ((reprintList == null) || (reprintList.isEmpty())) {
            reprintList = (ArrayList<StoreJKReprint>) Store.loadObject(JKReprint.class.getSimpleName());
        }
        if (reprintList == null) {
            reprintList = new ArrayList();
        }
    }

    public static boolean hasReprints() {
        loadReprintList();
        return reprintList.size() > 0;
    }

    public static void saveReprint(String ref, Date date, String type, String descript, AeonPrintJob apj) {
        loadReprintList();

        StoreJKReprint reprint = new StoreJKReprint();
        reprint.setVoucherReference(ref);
        reprint.setDate(date);
        reprint.setType(type);
        reprint.setDescription(descript);
        reprint.setApj(apj);
        reprintList.add(reprint);

        Collections.sort(reprintList, new Comparator<StoreJKReprint>() {
            @Override
            public int compare(StoreJKReprint item1, StoreJKReprint item2) {
                return (item1.getDate().compareTo(item2.getDate()));
            }
        });
        Collections.reverse(reprintList);

        int reprintCount = JKOptions.getOptions().getReprintNumber();

        if (reprintList.size() > reprintCount) {
            while (reprintList.size() > reprintCount) {
                reprintList.remove(reprintList.size() - 1);
            }
        }

        Store.saveObject(JKReprint.class.getSimpleName(), reprintList);
    }

    public static void removeReprint(StoreJKReprint reprint) {
        loadReprintList();
        reprintList.remove(reprint);
        Store.saveObject(JKReprint.class.getSimpleName(), reprintList);
    }

    public static List<StoreJKReprint> getReprintList() {
        loadReprintList();
        return reprintList;
    }
}
