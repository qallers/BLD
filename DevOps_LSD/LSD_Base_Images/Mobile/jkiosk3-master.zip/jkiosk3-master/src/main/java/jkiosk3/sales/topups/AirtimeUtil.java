package jkiosk3.sales.topups;

import aeontopup.*;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.concurrent.Task;
import jkiosk3.JKiosk3;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesItems;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.store.cache.CacheListTopupBundles;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

public class AirtimeUtil {

    private final static Logger logger = Logger.getLogger(AirtimeUtil.class.getName());
    private static TopupConnection tc;
    private static boolean isAuthenticated = false;
    //
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 60;

    private AirtimeUtil() {
    }

    public static TopupConnection getTopupConnect() {
        TopupConnection topupConnect = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            topupConnect = new TopupConnection(server, port, secureConnect);
            topupConnect.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
//        } finally {
//            if (topupConnect == null) {
//                JKiosk3.returnToLogin();
//                System.out.println("topup connection is null, return to login...");                
//            }
        }
        return topupConnect;
    }

    private static boolean isLoggedIn(String pin, String network) throws RuntimeException {
        String loyaltyProfileId = "";
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            loyaltyProfileId = ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId();
        }
        boolean loggedIn = false;
        tc = getTopupConnect();
        int deviceId = JKSystem.getSystemConfig().getDeviceId();
        String serial = JKSystem.getSystemConfig().getSerial();

        try {
            if (tc != null) {
                loggedIn = tc.login(pin, deviceId, serial, network, loyaltyProfileId);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    public static List<TopupProvider> getListTopupProvidersToShow(SaleType saleType) {
        List<TopupProvider> listTopupProvidersShow = new ArrayList<>();
        final List<TopupProvider> listTopupProvDataTmp = new ArrayList<>();
        final List<TopupProvider> listTopupProvSmsTmp = new ArrayList<>();

        if (CacheListTopupBundles.hasItems()) {
            List<TopupProvider> listProviders = CacheListTopupBundles.getListTopupProviders();
            for (TopupProvider p : listProviders) {
                if (!p.getListBundles().getlistCategories().isEmpty()) {
                    for (TopupBundleCategory c : p.getListBundles().getlistCategories()) {
                        if (c.getName().contains("DATA")) {
                            if (!c.getListProducts().isEmpty()) {
                                listTopupProvDataTmp.add(p);
                            }
                        } else if (c.getName().contains("SMS")) {
                            if (!c.getListProducts().isEmpty()) {
                                listTopupProvSmsTmp.add(p);
                            }
                        }
                    }
                }
            }
        }
        switch (saleType) {
            case TOPUP_BUNDLE_DATA:
                listTopupProvidersShow = listTopupProvDataTmp;
                break;
            case TOPUP_BUNDLE_SMS:
                listTopupProvidersShow = listTopupProvSmsTmp;
                break;
            default:
                break;
        }
        return listTopupProvidersShow;
    }

    public static List<TopupProvider> getTopupProviderAirtimeList() {
        return SalesItems.getListTopupProvidersAirtime();
    }

    public static List<TopupProvider> getTopupProviderBundlesList() {
        return SalesItems.getListTopupProvidersBundles();
    }

    private static TopupBundleProductList getOnlineTopupBundleProductList(TopupProvider provider) throws RuntimeException {
        TopupBundleProductList topupBundleList = new TopupBundleProductList();
        String userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin, provider.getName())) {
                topupBundleList = tc.getTopupBundleProductList(provider.getName());
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Topup Bundle Products Error", t);
        } finally {
            if (tc != null) {
                tc.disconnect();
            }
        }

        return topupBundleList;
    }

    private static TopupBundleProductList getTopupBundleProductList(TopupProvider provider) throws RuntimeException {
        TopupBundleProductList topupBundleList = new TopupBundleProductList();

        if (CacheListTopupBundles.hasItems()) {
            List<TopupProvider> listProviders = CacheListTopupBundles.getListTopupProviders();
            TopupProvider selectedProvider = null;
            for (TopupProvider p : listProviders) {
                if (p.getName().equalsIgnoreCase(provider.getName())) {
                    selectedProvider = p;
                    topupBundleList = p.getListBundles();
                    break;
                }
            }
            if (selectedProvider == null) {
                topupBundleList = getOnlineTopupBundleProductList(provider);
            }
        } else {
            topupBundleList = getOnlineTopupBundleProductList(provider);
        }

        return topupBundleList;
    }

    private static TopupVoucher getTopupVoucher(TopupAirtimeReq req) throws RuntimeException {
        TopupVoucher voucher = null;
        String userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin, req.getSupplierName())) {
                isAuthenticated = true;
                voucher = tc.getTopupAirtime(req);
            } else {
                isAuthenticated = false;
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Topup Voucher Error", t);
            // DO NOT disconnect here
//        } finally {
//            tc.disconnect();
        }
        return voucher;
    }

    private static TopupBundleResp getBundleTopup(TopupBundleReq req) throws RuntimeException {
        TopupBundleResp bundleResponse = new TopupBundleResp();
        String userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin, req.getSupplierName())) {
                isAuthenticated = true;
                bundleResponse = tc.getBundleTopup(req);
            } else {
                isAuthenticated = false;
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Topup Bundle Error", t);
            // DO NOT disconnect here
//        } finally {
//            tc.disconnect();
        }
        return bundleResponse;
    }

    private static TopupWalletResp getWalletTopup(TopupWalletReq req) throws RuntimeException {
        TopupWalletResp topupWalletResp = new TopupWalletResp();
        String userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin, req.getSupplierName())) {
                isAuthenticated = true;
                topupWalletResp = tc.getWalletTopup(req);
            } else {
                isAuthenticated = false;
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Topup Wallet Error", t);
            // DO NOT disconnect here
//        } finally {
//            tc.disconnect();
        }
        return topupWalletResp;
    }

    private static boolean isConfirmTopup(final TopupVoucher vouch) throws RuntimeException {
        boolean confirm = false;
        try {
            confirm = vouch.isSuccess();
            if (confirm) {
                tc.setSold(vouch.getTransRef(), vouch.getReference());
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Topup Confirm Error", t);
        } finally {
            if (tc != null) {
                tc.disconnect();
            }
        }
        return confirm;
    }

    public static String getProviderStyleName(TopupProvider prov) {
        String providerStyleName = "";
        Pattern pattern = Pattern.compile("(Bundles)");
        String provName = prov.getName();
        Matcher matcher = pattern.matcher(provName);
        while (matcher.find()) {
            providerStyleName = provName.substring(0, matcher.start());
        }
        return providerStyleName;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getListTopupProvidersToShow(final SaleType saleType, final TopupBundleProviderListResult result) {
        JKiosk3.getBusy().showBusy("Getting Topup Providers List");

        final Task<List<TopupProvider>> taskBundleProductList = new Task<List<TopupProvider>>() {
            @Override
            protected List<TopupProvider> call() throws Exception {
                return getListTopupProvidersToShow(saleType);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();

                System.out.println(getValue() + "--- what is get value");
                result.topupBundleProviderListResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Topup Bundle Providers",
                        "Error retrieving Topup Bundle Providers", State.CANCELLED, errorMsg, new MenuTopups());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Topup Bundle Providers",
                        "Error retrieving Topup Bundle Providers", State.FAILED, errorMsg, new MenuTopups());
            }
        };

        new Thread(taskBundleProductList).start();
        JKiosk3.getBusy().startCountdown(taskBundleProductList, countdownTime);
    }

    public static void getTopupBundleProductList(final TopupProvider provider, final TopupBundleProductListResult result) {
        JKiosk3.getBusy().showBusy("Getting Data Bundle List");

        final Task<TopupBundleProductList> taskBundleProductList = new Task<TopupBundleProductList>() {
            @Override
            protected TopupBundleProductList call() throws Exception {
                return getTopupBundleProductList(provider);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                System.out.println(getValue() + "--- what is get value");
                result.topupBundleProductListResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Topup Bundle",
                        "Error retrieving Topup Bundle Products", State.CANCELLED, errorMsg, new MenuTopups());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Topup Bundle",
                        "Error retrieving Topup Bundle Products", State.FAILED, errorMsg, new MenuTopups());
            }
        };

        new Thread(taskBundleProductList).start();
        JKiosk3.getBusy().startCountdown(taskBundleProductList, countdownTime);
    }

    public static void getBundleTopup(final TopupBundleReq req, final TopupBundleRespResult result) {
        JKiosk3.getBusy().showBusy("Getting Bundle Topup");

        final Task<TopupBundleResp> taskTopupBundleResp = new Task<TopupBundleResp>() {
            @Override
            protected TopupBundleResp call() throws Exception {
                return getBundleTopup(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.topupBundleRespResult(getValue());
            }

            @Override
            protected void cancelled() {
                if (isAuthenticated) {
                    taskutil.taskSaleCancelFailLogout("Topup Bundle Error", "Error Processing Topup Purchase", State.CANCELLED, errorMsg);
                } else {
                    taskutil.taskSaleCancelFailLogout("Topup Login Error", "Error Processing Topup Purchase", State.CANCELLED, errorMsg);
                }
            }

            @Override
            protected void failed() {
                if (isAuthenticated) {
                    taskutil.taskSaleCancelFailLogout("Topup Bundle Error", "Error Processing Topup Purchase", State.FAILED, errorMsg);
                } else {
                    taskutil.taskSaleCancelFailLogout("Topup Login Error", "Error Processing Topup Purchase", State.FAILED, errorMsg);
                }
            }
        };

        new Thread(taskTopupBundleResp).start();
        JKiosk3.getBusy().startCountdown(taskTopupBundleResp, countdownTime);
    }

    public static void getTopupVoucher(final TopupAirtimeReq req, final TopupResult result) {
        JKiosk3.getBusy().showBusy("Getting Topup Voucher");

        final Task<TopupVoucher> taskTopup = new Task<TopupVoucher>() {
            @Override
            protected TopupVoucher call() throws Exception {
                return getTopupVoucher(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.topupResult(getValue());
            }

            @Override
            protected void cancelled() {
                if (isAuthenticated) {
                    taskutil.taskSaleCancelFailLogout("Topup Airtime Error", "Error Processing Topup Purchase", State.CANCELLED, errorMsg);
                } else {
                    taskutil.taskSaleCancelFailLogout("Topup Login Error", "Error Processing Topup Purchase", State.CANCELLED, errorMsg);
                }
            }

            @Override
            protected void failed() {
                if (isAuthenticated) {
                    taskutil.taskSaleCancelFailLogout("Topup Airtime Error", "Error Processing Topup Purchase", State.FAILED, errorMsg);
                } else {
                    taskutil.taskSaleCancelFailLogout("Topup Login Error", "Error Processing Topup Purchase", State.FAILED, errorMsg);
                }
            }
        };

        new Thread(taskTopup).start();
        JKiosk3.getBusy().startCountdown(taskTopup, countdownTime);
    }

    public static void getWalletTopup(final TopupWalletReq req, final TopupWalletRespResult result) {
        JKiosk3.getBusy().showBusy("Getting Wallet Topup");

        final Task<TopupWalletResp> taskTopupWalletResp = new Task<TopupWalletResp>() {
            @Override
            protected TopupWalletResp call() throws Exception {
                return getWalletTopup(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.topupWalletRespResult(getValue());
            }

            @Override
            protected void cancelled() {
                if (isAuthenticated) {
                    taskutil.taskSaleCancelFailLogout("Topup Wallet Error", "Error Processing Topup Purchase", State.CANCELLED, errorMsg);
                } else {
                    taskutil.taskSaleCancelFailLogout("Topup Login Error", "Error Processing Topup Purchase", State.CANCELLED, errorMsg);
                }
            }

            @Override
            protected void failed() {
                if (isAuthenticated) {
                    taskutil.taskSaleCancelFailLogout("Topup Wallet Error", "Error Processing Topup Purchase", State.FAILED, errorMsg);
                } else {
                    taskutil.taskSaleCancelFailLogout("Topup Login Error", "Error Processing Topup Purchase", State.FAILED, errorMsg);
                }
            }
        };

        new Thread(taskTopupWalletResp).start();
        JKiosk3.getBusy().startCountdown(taskTopupWalletResp, countdownTime);
    }

    public static void isConfirmTopup(final TopupVoucher vouch, final TopupConfirmResult result) {
        JKiosk3.getBusy().showBusy("Confirming Topup");

        final Task<Boolean> taskConfirm = new Task<Boolean>() {
            @Override
            protected Boolean call() throws Exception {
                return isConfirmTopup(vouch);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.topupConfirmResult(getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Topup Airtime",
                        "Error Confirming Topup Purchase", State.CANCELLED, errorMsg, new MenuTopups());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Topup Airtime",
                        "Error Confirming Topup Purchase", State.FAILED, errorMsg, new MenuTopups());
            }
        };

        new Thread(taskConfirm).start();
        JKiosk3.getBusy().startCountdown(taskConfirm, countdownTime);
    }

    public abstract static class TopupBundleProviderListResult {

        public abstract void topupBundleProviderListResult(List<TopupProvider> providerList);
    }

    public abstract static class TopupBundleProductListResult {

        public abstract void topupBundleProductListResult(TopupBundleProductList productList);
    }

    public abstract static class TopupResult {

        public abstract void topupResult(TopupVoucher voucher);
    }

    public abstract static class TopupBundleRespResult {

        public abstract void topupBundleRespResult(TopupBundleResp topupBundleResponse);
    }

    public abstract static class TopupConfirmResult {

        public abstract void topupConfirmResult(boolean topupConfirmResult);
    }

    public abstract static class TopupWalletRespResult {
        public abstract void topupWalletRespResult(TopupWalletResp topupWalletResp);
    }
}
