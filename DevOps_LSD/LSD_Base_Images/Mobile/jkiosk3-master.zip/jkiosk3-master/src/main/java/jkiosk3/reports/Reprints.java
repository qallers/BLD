package jkiosk3.reports;

import aeonprinting.AeonPrintJob;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.KeyboardResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3._components.ControlSearch;
import jkiosk3.sales.SaleType;
import jkiosk3.store.JKReprint;
import jkiosk3.store.StoreJKReprint;

public class Reprints extends Region {

    private final static Logger logger = Logger.getLogger(Reprints.class.getName());
    private StackPane stack;
    private ControlSearch searchCtrl;
    private List<StoreJKReprint> reprints;
    private List<Node> listReprintItems;
    private final static int pageSize = 10;
    private AeonPrintJob apj;
    private static List<ScheduledExecutorService> listSched;
    private long delayMins = 1L;
    private long delayMillis = 1L;

    public Reprints() {
        if (listSched != null && !listSched.isEmpty()) {
            for (ScheduledExecutorService s : listSched) {
                s.shutdown();
                System.out.println("shutting down ScheduledExecutorService : " + s.isShutdown());
            }
            listSched.clear();
        }
        listSched = Collections.synchronizedList(new LinkedList<ScheduledExecutorService>());

        delayMins = 10L;
        delayMillis = delayMins * 60L * 1000L;
        setSearchControlActions();

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getReprintReportGroup());
        vb.getChildren().add(getPrintControl());

        getChildren().addAll(vb);
    }

    private void setSearchControlActions() {
        searchCtrl = new ControlSearch();
        searchCtrl.getBtnSearch().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard().showKeyboard(new TextField(), "Enter search text", "", false,
                        false, new KeyboardResult() {
                            @Override
                            public void onDone(String value) {
                                getReprints(value.toLowerCase(Locale.ENGLISH));
                            }
                        });
            }
        });
        searchCtrl.getBtnClear().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                stack.getChildren().clear();
                getReprints();
            }
        });
    }

    private Group getReprintReportGroup() {

        Label lblHead = JKText.getLblDk("Reprint Voucher - "
                        + new SimpleDateFormat("dd MMM yyyy").format(new java.util.Date()),
                JKText.FONT_B_SM);

        VBox vbHead = JKNode.getPageDblHeadVB(0, lblHead, searchCtrl);

        stack = new StackPane();
        stack.setMaxHeight(495);
        stack.setMinHeight(495);

        getReprints();

        VBox vb = JKLayout.getVBox(JKLayout.sp, JKLayout.spNum);
        vb.setMaxWidth(JKLayout.contentW);

        vb.getChildren().addAll(vbHead, stack);

        Group grp = JKNode.getContentGroup(vb);

        return grp;
    }

    private void getReprints() {
        reprints = JKReprint.getReprintList();
        listReprintItems = getReprintRadios(reprints);
        createPagedReprints();
    }

    private void getReprints(String searchTerm) {
        stack.getChildren().clear();
        reprints = JKReprint.getReprintList();
        if (searchTerm != null) {
            List<StoreJKReprint> srchReprints = reprints;
            List<StoreJKReprint> srchReprintsTmp = new ArrayList<>();
            for (StoreJKReprint reprint : srchReprints) {
                if (reprint.toString().toLowerCase(Locale.ENGLISH).contains(searchTerm)) {
                    srchReprintsTmp.add(reprint);
                }
            }
            reprints = srchReprintsTmp;
            if (reprints.size() > 0) {
                listReprintItems = getReprintRadios(reprints);
                createPagedReprints();
            } else {
                JKiosk3.getMsgBox().showMsgBox("Search Results", "No items found.  "
                        + "\n\nSearch again, or click 'clear' to see all items", null);
            }
        }
    }

    private List<Node> getReprintRadios(final List<StoreJKReprint> reprintList) {
        List<Node> listRadios = new ArrayList<>();

        ToggleGroup tgReprint = new ToggleGroup();

        for (final StoreJKReprint r : reprintList) {
            final RadioButton btnReprint = new RadioButton(r.toString());
            btnReprint.setStyle("-fx-font-size: 17px; -fx-font-weight: bold;");
            btnReprint.setToggleGroup(tgReprint);
            btnReprint.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    if (btnReprint.isSelected()) {
                        apj = r.getApj();
                    } else {
                        apj = reprintList.get(0).getApj();
                    }
                }
            });
            if (r.getType().equalsIgnoreCase(SaleType.BUSTICKETS.getDisplay())
                    || r.getType().equalsIgnoreCase(SaleType.COACHTICKETS.getDisplay())) {
                if (isAddScheduler(r)) {
                    addRadioTimeout(r, btnReprint);
                } else {
                    btnReprint.setDisable(true);
                }
            }
            listRadios.add(btnReprint);
        }
        return listRadios;
    }

    private boolean isAddScheduler(StoreJKReprint r) {
        long timeSale = r.getDate().getTime();
        long timeList = System.currentTimeMillis();

        if ((timeList - timeSale) > delayMillis) {
            return false;
        } else {
            return true;
        }
    }

    private void addRadioTimeout(final StoreJKReprint r, final RadioButton btnReprint) {
        logger.info(("Starting scheduled timer for Bus Ticket reprint timeout : ").concat(r.getVoucherReference()));
        final ScheduledExecutorService scheduledTimeout = Executors.newSingleThreadScheduledExecutor();
        scheduledTimeout.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                long timeSale = r.getDate().getTime();
                long timeList = System.currentTimeMillis();
                System.out.println("time for Bus Tickets is updating..." + r.getDate()
                        + " : time passed in min = " + (((float) (timeList - timeSale) / 1000F) / 60F)
                        + " : Thread = " + Thread.currentThread().getName());
                if ((timeList - timeSale) > delayMillis) {
                    btnReprint.setDisable(true);
                    scheduledTimeout.shutdown();
                    listSched.remove(scheduledTimeout);
                    apj = null;
                }
            }
        }, 0, 15, TimeUnit.SECONDS);
        listSched.add(scheduledTimeout);
    }

    private void createPagedReprints() {
        int numPgs = 0;
        if (listReprintItems.isEmpty()) {
            numPgs = 1;
        } else if ((listReprintItems.size() % pageSize) == 0) {
            numPgs = listReprintItems.size() / pageSize;
        } else {
            numPgs = (listReprintItems.size() / pageSize) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedVBox(pg, listReprintItems, pageSize);
            }
        });
        stack.getChildren().clear();
        stack.getChildren().add(pages);
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                if (apj != null) {
                    showReprintReport();
                } else {
                    if (!listReprintItems.get(0).isDisabled()) {
                        apj = reprints.get(0).getApj();
                        showReprintReport();
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Invalid Selection", "Please select an item from the list", null);
                    }
                }
            }
        };
    }

    private void showReprintReport() {
        PrintHandler.handlePrintRequestReport("Reprint", apj);
    }

    public static List<ScheduledExecutorService> getListSched() {
        return listSched;
    }
}
