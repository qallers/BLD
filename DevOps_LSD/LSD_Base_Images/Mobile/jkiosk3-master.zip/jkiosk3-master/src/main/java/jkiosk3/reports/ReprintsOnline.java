package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.Reprint;
import aeonreports.ReprintList;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlSearch;
import jkiosk3._components.KeyboardResult;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.PrintHandler;

/**
 *
 * @author valeriew
 */
public class ReprintsOnline extends Region {

    /* primitives */
    private final static int SORT_BY_DATE_ASC = 1;
    private final static int SORT_BY_DATE_DESC = 2;
    private final static int SORT_BY_AMOUNT_ASC = 3;
    private final static int SORT_BY_AMOUNT_DESC = 4;
    private final static int pageSize = 10;
    /* Java and JavaFX classes */
    private StackPane stack;
    private List<Node> listReprintItems;
    /* Custom classes */
    private ControlSearch searchCtrl;
    private final ReprintList reprints;
    private final List<Reprint> listReprints;
    private List<Reprint> listCurrent;
    private Reprint reprintSelected;

    public ReprintsOnline(ReprintList reprintList) {
        this.reprints = reprintList;
        this.listReprints = reprints.getReprints();
        setSearchControlActions();

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getReprintsView());
        vb.getChildren().add(getSortAndPrintControl());

        getChildren().addAll(vb);
    }

    private VBox getReprintsView() {

        Label lblHead = JKText.getLblDk("Reprints Online - "
                + new SimpleDateFormat("dd MMM yyyy").format(new java.util.Date()),
                JKText.FONT_B_SM);

        VBox vbHead = JKNode.getPageDblHeadVB(0, lblHead, searchCtrl);

        stack = new StackPane();
        stack.setMaxHeight(495);
        stack.setMinHeight(495);

        getReprints();

        VBox vb = JKLayout.getVBoxContent(JKLayout.spNum);
        vb.setMaxWidth(JKLayout.contentW);

        vb.getChildren().addAll(vbHead, stack);

        return vb;
    }

    private HBox getSortAndPrintControl() {

        Button btnSortDateAsc = getBtnSort("Sort By\nDate\nAscending", SORT_BY_DATE_ASC);

        Button btnSortDateDesc = getBtnSort("Sort By\nDate\nDescending", SORT_BY_DATE_DESC);

        Button btnSortAmtAsc = getBtnSort("Sort By\nAmount\nAscending", SORT_BY_AMOUNT_ASC);

        Button btnSortAmtDesc = getBtnSort("Sort By\nAmount\nDescending", SORT_BY_AMOUNT_DESC);

        Button btnPrint = JKNode.getBtnSm("Print");
        btnPrint.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (reprintSelected != null) {
                    getPrintSelected(reprintSelected);
                } else {
                    JKiosk3.getMsgBox().showMsgBox("No Reprint Selected", "Please select an item to Print", null);
                }
            }
        });

        HBox hbControls = JKLayout.getHBoxContent(JKLayout.sp);
        hbControls.getChildren().addAll(btnSortDateAsc, btnSortDateDesc, btnSortAmtAsc, btnSortAmtDesc, btnPrint);
        return hbControls;
    }

    private List<Node> getReprintRadios(final List<Reprint> reprintList) {
        List<Node> listRadios = new ArrayList<>();

        ToggleGroup tgReprint = new ToggleGroup();

        for (final Reprint r : reprintList) {
            String PRINT_LAYOUT = "%-16s" + "%-4s" + "%9s" + "%-30s";
            String rDetail = String.format(PRINT_LAYOUT, new SimpleDateFormat("yyyy-MM-dd HH:mm").format(r.getDate()),
                    " - R", JKText.getDeciFormat(r.getAmount()), " - " + r.getReference());
            final RadioButton btnReprint = new RadioButton(rDetail);
            btnReprint.setId(r.getId());
//            btnReprint.setFont(JKText.FONT_CONSOLAS_MID);
            btnReprint.setStyle("-fx-font-size: 17px; -fx-font-weight: bold;");
            btnReprint.setToggleGroup(tgReprint);
            btnReprint.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    if (btnReprint.isSelected()) {
                        reprintSelected = r;
                    } else {
                        reprintSelected = reprintList.get(0);
                    }
                }
            });
            listRadios.add(btnReprint);
        }
        return listRadios;
    }

    private void createPagedReprints() {
        int numPgs = 0;
        if (listReprintItems.isEmpty()) {
            numPgs = 1;
        } else if ((listReprintItems.size() % pageSize) == 0) {
            numPgs = listReprintItems.size() / pageSize;
        } else {
            numPgs = (listReprintItems.size() / pageSize) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedVBox(pg, listReprintItems, pageSize);
            }
        });
        stack.getChildren().clear();
        stack.getChildren().add(pages);
    }

    private Button getBtnSort(String btnText, final int sortBy) {
        Button btnSort = JKNode.getBtnSm(btnText);
        btnSort.setMaxWidth((JKLayout.contentW - (JKLayout.btnSmW + (6 * JKLayout.sp))) / 4);
        btnSort.setMinWidth((JKLayout.contentW - (JKLayout.btnSmW + (6 * JKLayout.sp))) / 4);
        btnSort.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");
        btnSort.setWrapText(true);
        btnSort.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                reprintSelected = null;
                getSortedList(sortBy);
            }
        });
        return btnSort;
    }

    /* ************************  */
    /* above - mostly view       */
    /* below - mostly processing */
    /* ************************  */
    private void setSearchControlActions() {
        searchCtrl = new ControlSearch();
        searchCtrl.getBtnSearch().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                reprintSelected = null;
                JKiosk3.getKeyboard().showKeyboard(new TextField(), "Enter search text", "", false, false, new KeyboardResult() {
                    @Override
                    public void onDone(String value) {
                        getReprints(value.toLowerCase(Locale.ENGLISH));
                    }
                });
            }
        });
        searchCtrl.getBtnClear().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                reprintSelected = null;
                Collections.sort(listReprints, new Comparator<Reprint>() {
                    @Override
                    public int compare(Reprint r1, Reprint r2) {
                        return r2.getId().compareTo(r1.getId());
                    }
                });
                stack.getChildren().clear();
                getReprints();
            }
        });
    }

    private void getReprints() {
        listCurrent = listReprints;
        listReprintItems = getReprintRadios(listCurrent);
        createPagedReprints();
    }

    private void getReprints(String searchTerm) {
        stack.getChildren().clear();
        if (searchTerm != null) {
            List<Reprint> srchReprints = listReprints;
            List<Reprint> srchReprintsTmp = new ArrayList<>();
            for (Reprint r : srchReprints) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                String reprintString = sdf.format(r.getDate()) + " - R" + Double.toString(r.getAmount()) + " - " + r.getReference();
                if (reprintString.toLowerCase(Locale.ENGLISH).contains(searchTerm)) {
                    srchReprintsTmp.add(r);
                }
            }
            List<Reprint> listReprintsSearch = srchReprintsTmp;
            listCurrent = listReprintsSearch;
            if (listReprintsSearch.size() > 0) {
                listReprintItems = getReprintRadios(listCurrent);
                createPagedReprints();
            } else {
                JKiosk3.getMsgBox().showMsgBox("Search Results", "No items found.  "
                        + "\n\nSearch again, or click 'clear' to see all items", null);
            }
        }
    }

    private void getSortedList(int sortBy) {
        List<Reprint> listReprintsSorted = listCurrent;
        switch (sortBy) {
            case SORT_BY_DATE_ASC:
                Collections.sort(listReprintsSorted, new Comparator<Reprint>() {
                    @Override
                    public int compare(Reprint r1, Reprint r2) {
                        return r1.getDate().compareTo(r2.getDate());
                    }
                });
                listReprintItems = getReprintRadios(listReprintsSorted);
                createPagedReprints();
                break;
            case SORT_BY_DATE_DESC:
                Collections.sort(listReprintsSorted, new Comparator<Reprint>() {
                    @Override
                    public int compare(Reprint r1, Reprint r2) {
                        return r2.getDate().compareTo(r1.getDate());
                    }
                });
                listReprintItems = getReprintRadios(listReprintsSorted);
                createPagedReprints();
                break;
            case SORT_BY_AMOUNT_ASC:
                Collections.sort(listReprintsSorted, new Comparator<Reprint>() {
                    @Override
                    public int compare(Reprint r1, Reprint r2) {
                        return Double.compare((r1.getAmount() * 100), (r2.getAmount() * 100));
                    }
                });
                listReprintItems = getReprintRadios(listReprintsSorted);
                createPagedReprints();
                break;
            case SORT_BY_AMOUNT_DESC:
                Collections.sort(listReprintsSorted, new Comparator<Reprint>() {
                    @Override
                    public int compare(Reprint r1, Reprint r2) {
                        return Double.compare((r2.getAmount() * 100), (r1.getAmount() * 100));
                    }
                });
                listReprintItems = getReprintRadios(listReprintsSorted);
                createPagedReprints();
                break;
            default:
                searchCtrl.getBtnClear().getOnMouseReleased();
                break;
        }
    }

    private void getPrintSelected(Reprint reprintSelected) {
        ReprintUtil.getReprintSelected(reprintSelected.getId(), new ReprintUtil.AeonPrintJobResult() {

            @Override
            public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                if (aeonPrintJob != null) {
                    PrintHandler.handlePrintRequestReport("Reprint", aeonPrintJob);
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Reprint Error", "Error retrieving Reprint", null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    SceneReports.clearAndChangeContent(new ReprintsOnlineSelect());
                                }

                                @Override
                                public void onCancel() {
                                }
                            });
                }
            }
        });
    }
}
