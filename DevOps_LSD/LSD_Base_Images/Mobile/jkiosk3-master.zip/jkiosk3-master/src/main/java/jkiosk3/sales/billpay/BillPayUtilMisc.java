package jkiosk3.sales.billpay;

import javafx.geometry.HPos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SceneSales;
import jkiosk3.store.JKTransactionLimits;
import jkiosk3.users.UserUtil;

public class BillPayUtilMisc {

    public final static String BLU_BILL_PAY = "Blu Bill Payment";
    public final static String PAYAT_BILL_PAY = "Pay@ Account Payment";
    public final static String PAYAT_INSURANCE = "Pay@ Insurance Payment";
    public final static String PAYAT_TRAFFIC_FINES = "Pay@ Fine Payment";
    public final static String SYNTELL_BILL_PAY = "Syntell Account Payment";
    public final static String SYNTELL_TRAFFIC_FINES = "Syntell Traffic Fines";
    public final static String SAPO_BILL_PAY = "SAPO Account Payment";
    public final static String BLU_M2M_TRANSFER = "MerchantTransfer";
    //
    public final static String TYPE_BILL_PAY = "Bill Payment";
    public final static String TYPE_INSURE_PAY = "Insurance Policy";
    public final static String TYPE_TRAFFIC_FINE = "Traffic Fine";
    public final static String TYPE_M2M_TRANSFER = "Merchant Transfer";
    //
    public final static String INSURE_PAYMENT = "Policy Payment";
    public final static String INSURE_REGISTER = "Policy Registration";
    //
    public final static String CALL_BY_CANCEL = "call by cancel";
    public final static String CALL_BY_MSG = "call by message";
    public final static String CALL_BY_TENDER = "call by tender";

    //


    //
    private final static double imageWidth = 65;

    // utilities used in Bill Payment classes
    public static void resetBillPayView() {
//        SceneSales.clearAndChangeContent(new BillPaymentMenu());
        SceneSales.clearAndShowFavourites();
    }

    // images for buttons    
    public static ImageView getImageViewBillPay(String imgName) {
        ImageView imgViewBP = JKNode.getJKImageViewProvider(imgName);
        imgViewBP.setFitWidth(imageWidth);
        imgViewBP.setPreserveRatio(true);
        return imgViewBP;
    }

    public static GridPane getGridBillPayDetail(double amountDue, double convenienceFee, String acceptPartPay,
            String paymentOf) {

        String strAmtDue;
        String strTotal;
        double total = amountDue + convenienceFee;

//        if (paymentOf.equals(SYNTELL_BILL_PAY)) {
        if (paymentOf.equals(BPTransType.BILLPAY_SYNTELL_ACCOUNT.getDisplayName())) {
            strAmtDue = " - ";
            strTotal = " - ";
        } else {
            strAmtDue = "R " + JKText.getDeciFormat(amountDue);
            strTotal = "R " + JKText.getDeciFormat(total);
        }

        Label lblAmtDue = JKText.getLblDk("Amount Due", JKText.FONT_B_XSM);
        Text txtAmtDue = JKText.getTxtDk(strAmtDue, JKText.FONT_B_XSM);

        Label lblConvenienceFee = JKText.getLblDk("Convenience Fee", JKText.FONT_B_XSM);
        Text txtConvenienceFee = JKText.getTxtDk("R " + JKText.getDeciFormat(convenienceFee), JKText.FONT_B_XSM);

        Label lblTotal = JKText.getLblDk("Total Payable", JKText.FONT_B_SM);
        Text txtTotal = JKText.getTxtDk(strTotal, JKText.FONT_B_SM);

        Label lblAcceptPart = JKText.getLblDk("Accept Part Payment?", JKText.FONT_B_XSM);
        Text txtAcceptPart = JKText.getTxtDk(acceptPartPay, JKText.FONT_B_XSM);

        Label lblReview = JKText.getLblDk("Please review all details before continuing!", JKText.FONT_B_SM);

        GridPane gridDetail = JKLayout.getContentGridInner2Col(0.5, 0.5, HPos.RIGHT);

        switch (paymentOf) {
            case BLU_M2M_TRANSFER:
                gridDetail.addRow(1, lblConvenienceFee, txtConvenienceFee);
                break;
            default:
                gridDetail.addRow(0, lblAmtDue, txtAmtDue);
                gridDetail.addRow(1, lblConvenienceFee, txtConvenienceFee);
                gridDetail.addRow(2, lblTotal, txtTotal);
                if (acceptPartPay != null) {
                    gridDetail.addRow(3, lblAcceptPart, txtAcceptPart);
                    gridDetail.add(lblReview, 0, 5, 2, 1);
                } else {
                    gridDetail.add(lblReview, 0, 4, 2, 1);
                }
                break;
        }

        return gridDetail;
    }

    public static void getSupervisorOverride(final double amount, final UserUtil.SupervisorOverride supervisorOverride, final TextField... txt) {
        JKiosk3.getMsgBox().showMsgBox("Amount Too High", "\n\n"
                + "R " + JKText.getDeciFormat(amount) + "\n\n"
                + "The Amount entered exceeds the allowed limit of\n\n"
                + "R " + JKText.getDeciFormat(JKTransactionLimits.getTransactionLimits().getTransLimitBillPay()) + "\n\n"
                + "Please call a Supervisor to authorise this Amount,\n\n"
                + "or press 'Cancel' to enter a new Amount",
                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL,
                new MessageBoxResult() {

            @Override
            public void onOk() {
                UserUtil.getSupervisorOverride(new UserUtil.SupervisorOverride() {

                    @Override
                    public void supervisorOverrideResult(Boolean isSupervisor) {
                        if (isSupervisor) {
                            supervisorOverride.supervisorOverrideResult(Boolean.TRUE);
                        } else {
                            supervisorOverride.supervisorOverrideResult(Boolean.FALSE);
                        }
                    }
                });
            }

            @Override
            public void onCancel() {
                // Clear TextField items, ready for re-entry
                for (TextField t : txt) {
                    t.clear();
                }
            }
        });
    }
}
