package jkiosk3.store.cache;

import java.util.Collections;
import java.util.List;
import jkiosk3.sales.topups.TopupProvider;
import jkiosk3.store.Store;

/**
 *
 * @author valeriew
 */
public class CacheListTopupBundles {

    private static volatile ListTopupBundles listTopupBundles;

    private static ListTopupBundles getListTopupBundles() {
        if (listTopupBundles == null) {
            listTopupBundles = ((ListTopupBundles) Store.loadObject(CacheListTopupBundles.class.getSimpleName()));
        }
        if (listTopupBundles == null) {
            listTopupBundles = new ListTopupBundles();
        }
        return listTopupBundles;
    }

    private static void saveListTopupBundles(ListTopupBundles listTopBun) {
        Store.saveObject(CacheListTopupBundles.class.getSimpleName(), listTopBun);
    }

    public static void saveListTopupBundleProviders(List<TopupProvider> listProviders) {
        getListTopupBundles();
        listTopupBundles.getListTopupProviders().clear();
        listTopupBundles.getListTopupProviders().addAll(listProviders);
        saveListTopupBundles(listTopupBundles);
    }

    public static boolean hasItems() {
        getListTopupBundles();
        return !listTopupBundles.getListTopupProviders().isEmpty();
    }

    public static List<TopupProvider> getListTopupProviders() {
        getListTopupBundles();
        return Collections.unmodifiableList(listTopupBundles.getListTopupProviders());
    }

    public static void deleteCacheTopupProviders() {
        Store.deleteObject(CacheListTopupBundles.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheListTopupBundles.class.getSimpleName());
    }

}
