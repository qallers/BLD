package jkiosk3.sales.ticketpro.cache;

import aeonticketpros.TicketProsCategoryList;
import aeonticketpros.TicketProsEventList;

import java.io.Serializable;

public class TPCatAndEvent implements Serializable {

    private final static long serialVersionUID = 10111L;

    private TicketProsCategoryList listTPCategories = new TicketProsCategoryList();
    private TicketProsEventList listTPEvents = new TicketProsEventList();

    public TicketProsCategoryList getListTPCategories() {
        return listTPCategories;
    }

    public void setListTPCategories(TicketProsCategoryList listTPCategories) {
        this.listTPCategories = listTPCategories;
    }

    public TicketProsEventList getListTPEvents() {
        return listTPEvents;
    }

    public void setListTPEvents(TicketProsEventList listTPEvents) {
        this.listTPEvents = listTPEvents;
    }
}
