package jkiosk3.sales.vouchers;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SceneSales;

public class MenuVouchers extends Region {

    public MenuVouchers() {
        getChildren().add(getVoucherTypes());
    }

    private VBox getVoucherTypes() {

        VBox vbHead = JKNode.getPageHeadVB("Voucher Menu");

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getMenuButtons());

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private List<Button> getMenuButtons() {
        List<Button> btnList = new ArrayList<>();

        List<SaleType> btnLabels = new ArrayList<>();
        btnLabels.add(SaleType.VOUCHER_AIRTIME);
        btnLabels.add(SaleType.VOUCHER_DATA);
        btnLabels.add(SaleType.VOUCHER_ELEC);
        btnLabels.add(SaleType.VOUCHER_OTHER);

        for (final SaleType s : btnLabels) {
            final Button btn = JKNode.getBtnSmDbl(s.getDisplay());
            btn.setId(s.name());
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(s);
                }
            });
            btnList.add(btn);
        }

        return btnList;
    }

    /**
     * This will signify the start of a new Voucher Sale, so the VoucherSale and MerchantCopy should be reset and the
     * Sale Type set here, to be used when needed later in the Sale process.
     *
     * @param voucherType this will be the Sale Type as indicated on the button label.
     */
    private void getMenuAction(SaleType voucherType) {
        VoucherSale.resetVoucherSale();
        VoucherSale.getInstance().setSaleType(voucherType);
        SceneSales.clearAndChangeContent(new Vouchers());
    }
}
