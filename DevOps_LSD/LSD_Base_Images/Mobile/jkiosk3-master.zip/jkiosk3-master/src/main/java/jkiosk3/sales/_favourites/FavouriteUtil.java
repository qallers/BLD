package jkiosk3.sales._favourites;

import aeonfavourites.FavouriteItem;
import aeonfavourites.FavouritesConnection;
import aeonfavourites.FavouritesListReq;
import aeonfavourites.FavouritesListResp;
import javafx.application.Platform;
import javafx.concurrent.Task;
import jkiosk3.JKiosk3;
import jkiosk3.admin.favourites.fav_cache.CacheFavouriteCustomStore;
import jkiosk3.admin.favourites.fav_cache.CacheFavouriteDefaultStore;
import jkiosk3.admin.favourites.fav_cache.JKFavouriteSetup;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FavouriteUtil {

    private final static Logger logger = Logger.getLogger(FavouriteUtil.class.getName());

    private final static TaskUtil TASK_UTIL = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int COUNTDOWN_TIME = 60;

    private static FavouritesConnection getFavouritesConnect() {
        FavouritesConnection favConnect = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            favConnect = new FavouritesConnection(server, port, secureConnect);
            favConnect.setTimeout(COUNTDOWN_TIME);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            logger.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            logger.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            logger.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return favConnect;
    }

    private static List<FavouriteItem> getListFavouriteProducts(boolean isUpdateRequest) {
        List<FavouriteItem> favouritesListResp = null;
        if (isUpdateRequest) {
            favouritesListResp = getListFavouriteProductsOnline();
        } else {
            if (JKFavouriteSetup.getFavouriteSetupStore().isUseDefaultFavourites()) {
                if (CacheFavouriteDefaultStore.hasFavouriteStoreItems()) {
                    favouritesListResp = CacheFavouriteDefaultStore.getListFavouriteItems();
                } else {
                    favouritesListResp = getListFavouriteProductsOnline();
                }
            } else {
                if (CacheFavouriteCustomStore.hasFavouriteStoreItems()) {
                    favouritesListResp = CacheFavouriteCustomStore.getListFavouriteItems();
                } else {
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            JKiosk3.getMsgBox().showMsgBox("No Custom Favourites",
                                    "Create list of Custom Favourites in Main Menu", null);
                        }
                    });
                }
            }
        }

        return favouritesListResp;
    }

    private static List<FavouriteItem> getListFavouriteProductsOnline() throws RuntimeException {
        List<FavouriteItem> listFavItems = null;
        FavouritesConnection favCon = getFavouritesConnect();

        FavouritesListReq req = new FavouritesListReq();
        req.setUserPin(CurrentUser.getUser().getUserPin());
        req.setDeviceId(Integer.toString(JKSystem.getSystemConfig().getDeviceId()));
        req.setDeviceSer(JKSystem.getSystemConfig().getSerial());

        try {
            FavouritesListResp favListResp = favCon.getFavouritesList(req);
            if (favListResp.isSuccess()) {
                listFavItems = favListResp.getListFavouriteItems();

                CacheFavouriteDefaultStore.saveFavouriteStore(listFavItems);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Favourite Products List Error", t);
        } finally {
            if (favCon != null) {
                favCon.disconnect();
            }
        }

        return listFavItems;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getListFavouriteProducts(final boolean isUpdateRequest, final FavouriteProductsResult result) {
        JKiosk3.getBusy().showBusy("Getting Favourite Products List");

        final Task<List<FavouriteItem>> taskFavsList = new Task<List<FavouriteItem>>() {
            @Override
            protected List<FavouriteItem> call() throws Exception {
                return getListFavouriteProducts(isUpdateRequest);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.favouriteProductsResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskAdminCancelFail("Favourite Product List Error",
                        "Error Getting Favourite Product List", FavouriteUtil.class, State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskAdminCancelFail("Favourite Product List Error",
                        "Error Getting Favourite Product List", FavouriteUtil.class, State.FAILED, errorMsg);
            }
        };
        new Thread(taskFavsList).start();
        JKiosk3.getBusy().startCountdown(taskFavsList, COUNTDOWN_TIME);
    }

    public abstract static class FavouriteProductsResult {

        public abstract void favouriteProductsResult(List<FavouriteItem> favListResp);
    }
}
