package jkiosk3.sales.chat4change;

import aeonvarivouchers.Supplier;

public class Chat4ChangeSale {

    private Supplier supplier;
    private double amount;
    //
    private static Chat4ChangeSale instance;

    private static Chat4ChangeSale newInstance() {
        instance = new Chat4ChangeSale();
        return instance;
    }

    public static Chat4ChangeSale getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    public static void resetChat4ChangeSale() {
        instance = null;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
