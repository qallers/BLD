package jkiosk3._components;

public abstract class StageNFCInputResult {

    public abstract void onDone(String value);
}
