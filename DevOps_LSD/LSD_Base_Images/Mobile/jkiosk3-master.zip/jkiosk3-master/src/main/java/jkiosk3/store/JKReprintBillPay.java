package jkiosk3.store;

import aeonprinting.AeonPrintJob;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import jkiosk3.Version;

/**
 *
 * @author valeriew
 */
public class JKReprintBillPay {

    private static List<StoreJKReprintBillPay> reprintList;

    public static void loadReprintList() {
        if ((reprintList == null) || (reprintList.isEmpty())) {
            reprintList = (ArrayList<StoreJKReprintBillPay>) Store.loadObject(JKReprintBillPay.class.getSimpleName());
        }
        if (reprintList == null) {
            reprintList = new ArrayList();
        }
    }

    public static boolean hasReprints() {
        loadReprintList();
        return reprintList.size() > 0;
    }

    public static void saveReprint(int ref, Date date, String type, String descript, AeonPrintJob apj) {
        loadReprintList();

        StoreJKReprintBillPay reprint = new StoreJKReprintBillPay();
        reprint.setVoucherReference(ref);
        reprint.setDate(date);
        reprint.setType(type);
        reprint.setDescription(descript);
        reprint.setApj(apj);
        reprintList.add(reprint);

        Collections.sort(reprintList, new Comparator<StoreJKReprintBillPay>() {
            @Override
            public int compare(StoreJKReprintBillPay item1, StoreJKReprintBillPay item2) {
                return (item1.getDate().compareTo(item2.getDate()));
            }
        });
        Collections.reverse(reprintList);

        // WILL NOT BE DETERMINED BY COUNT
        // USE DATE
        long timeNow = System.currentTimeMillis();
        // delete items older than 30 days
        //             millis * seconds * minutes * hours * days
        //              1000 * 60 * 60 * 24 * 30
        long timeBack = 0L;
        // SET 5 MINS FOR TESTING
//        long timeBack = 1000L * 60L * 5L;        
//        if (Version.isLive()) {
//            // 30 days
            timeBack = 1000L * 60L * 60L * 24L * 30L;
//        } else {
//            // 2 days
//            timeBack = 1000L * 60L * 60L * 24L * 2L;
//        }
        List<StoreJKReprintBillPay> listTemp = new ArrayList<>();
        System.out.println("timeNow              = " + timeNow);
        System.out.println("timeBack             =    " + timeBack);
        System.out.println("(timeNow - timeBack) = " + (timeNow - timeBack));
        for (StoreJKReprintBillPay r : reprintList) {
            long timeReprint = r.getDate().getTime();
            System.out.println("timeReprint          = " + timeReprint);
            if (timeReprint < (timeNow - timeBack)) {
                listTemp.add(r);
            }
        }
        reprintList.removeAll(listTemp);
        Store.saveObject(JKReprintBillPay.class.getSimpleName(), reprintList);
    }

    public static void removeReprint(StoreJKReprintBillPay reprint) {
        loadReprintList();
        reprintList.remove(reprint);
        Store.saveObject(JKReprintBillPay.class.getSimpleName(), reprintList);
    }

    public static List<StoreJKReprintBillPay> getReprintList() {
        loadReprintList();
        return reprintList;
    }
}
