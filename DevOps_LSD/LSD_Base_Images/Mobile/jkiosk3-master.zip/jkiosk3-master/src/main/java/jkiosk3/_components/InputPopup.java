package jkiosk3._components;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;

/**
 *
 * @author Valerie
 */
public class InputPopup extends Region {

    private final static double msgWidth = 650;
    private Label lblHead;
    private Button btnSave;
    private Button btnOK;
    private Button btnCancel;
    private HBox hbBtns;
    private VBox vboxContent;
    private StackPane paneContent;
    private InputPopupResult result;
    public final static byte MSG_OK = 1;
    public final static byte MSG_OK_CANCEL = 2;
    public boolean isUseSave = true;

    public InputPopup() {
        getChildren().add(getInputBoxStack());
    }

    private StackPane getInputBoxStack() {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getInputBoxGrp());

        return stack;
    }

    private Group getInputBoxGrp() {
        Group grp = new Group();

        Rectangle rec = new Rectangle();
        rec.setWidth(msgWidth);

        lblHead = JKText.getLblDk("An Input Box", JKText.FONT_B_SM);
        lblHead.setMaxWidth(msgWidth - (2 * JKLayout.sp));
        lblHead.setAlignment(Pos.CENTER);
        lblHead.setTextAlignment(TextAlignment.CENTER);
        lblHead.setWrapText(true);

        paneContent = new StackPane();
        paneContent.setMaxWidth(msgWidth - (2 * JKLayout.sp));
        paneContent.setMinWidth(msgWidth - (2 * JKLayout.sp));
        paneContent.setPadding(new Insets(JKLayout.sp));

        btnSave = JKNode.getBtnMsgBox("Save");
        btnSave.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onSaveBtnEvent();
            }
        });

        btnOK = JKNode.getBtnMsgBox("OK");
        btnOK.setDisable(true);
        btnOK.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onOkBtnEvent();
            }
        });

        btnCancel = JKNode.getBtnMsgBox("Cancel");
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                onCancelBtnEvent();
            }
        });

        hbBtns = JKLayout.getHBox(0, (2 * JKLayout.sp));
        hbBtns.setMaxWidth(msgWidth - (2 * JKLayout.sp));
        hbBtns.setMinWidth(msgWidth - (2 * JKLayout.sp));
        hbBtns.getChildren().addAll(btnSave, btnOK, btnCancel);

        vboxContent = JKLayout.getVBox(JKLayout.sp, (JKLayout.sp / 2));
        vboxContent.setPrefWidth(msgWidth);
        vboxContent.getChildren().addAll(lblHead, getSep(), paneContent, getSep(), hbBtns);

        rec.heightProperty().bind(vboxContent.heightProperty());

        grp.getChildren().addAll(rec, vboxContent);

        return grp;
    }

    private Separator getSep() {
        Separator sep = new Separator();
        sep.setMaxWidth(msgWidth - (2 * JKLayout.sp));
        sep.setMinWidth(msgWidth - (2 * JKLayout.sp));
        return sep;
    }

    private void onSaveBtnEvent() {
        if (result != null) {
            result.onSave();
        }
    }

    private void onOkBtnEvent() {
        if (isUseSave) {
            clearContents();
            setVisible(false);
            toBack();
        } else {
            if (result != null) {
                result.onOk();
                clearContents();
                setVisible(false);
                toBack();
            }
        }
        // previous code, works pre-CR-2154 Electricity Encode Token
//        clearContents();
//        setVisible(false);
//        toBack();
    }

    private void onCancelBtnEvent() {
        clearContents();
        setVisible(false);
        toBack();
        if (result != null) {
            result.onCancel();
        }
    }

    private void clearContents() {
        lblHead.setText("");
        paneContent.getChildren().clear();
    }

    public void showInputBox(String head, Node node, InputPopupResult res) {
        lblHead.setText(head);
        this.isUseSave = true;
        this.result = res;
        btnSave.setDisable(false);
        btnOK.setDisable(true);
        btnCancel.setDisable(false);

        if (node != null) {
            paneContent.getChildren().clear();
            paneContent.getChildren().add(node);
        } else {
            paneContent.getChildren().clear();
        }

        this.setVisible(true);
        this.toFront();
    }

    public void showInputBox(byte btnsShow, boolean isSaveContents,  String head, Node node, InputPopupResult res) {
        this.isUseSave = isSaveContents;
        this.lblHead.setText(head);
        this.result = res;

        if (btnsShow == MSG_OK) {
            hbBtns.getChildren().clear();
            hbBtns.getChildren().addAll(btnOK);
            btnOK.setDisable(false);
        } else if (btnsShow == MSG_OK_CANCEL) {
            hbBtns.getChildren().clear();
            hbBtns.getChildren().addAll(btnOK, btnCancel);
            btnOK.setDisable(false);
            btnCancel.setDisable(false);
        } else {
            hbBtns.getChildren().clear();
            hbBtns.getChildren().addAll(btnSave, btnOK, btnCancel);
            btnSave.setDisable(false);
            btnOK.setDisable(true);
            btnCancel.setDisable(false);
        }

        if (node != null) {
            paneContent.getChildren().clear();
            paneContent.getChildren().add(node);
        } else {
            paneContent.getChildren().clear();
        }

        this.setVisible(true);
        this.toFront();
    }

    public void btnsDisable(boolean disableBtnSave, boolean disableBtnOk, boolean disableBtnCancel) {
        btnSave.setDisable(disableBtnSave);
        btnOK.setDisable(disableBtnOk);
        btnCancel.setDisable(disableBtnCancel);
    }
}
