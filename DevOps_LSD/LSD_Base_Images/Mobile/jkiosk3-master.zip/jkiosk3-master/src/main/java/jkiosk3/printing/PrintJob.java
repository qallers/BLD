package jkiosk3.printing;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import aeonprinting.AeonPrintFormat;
import javafx.scene.text.Font;
import jkiosk3.store.JKPrinter;

/**
 * @author Val
 */
public class PrintJob implements Serializable {

    private final static Logger logger = Logger.getLogger (PrintJob.class.getName ());
    private final List<String> printLines;
    private final int pageWidth;

    public enum PrintAlign {

        LEFT (""),
        CENTER ("C"),
        RIGHT ("R");

        private final String align;

        private PrintAlign(String a) {
            align = a;
        }

        public String getAlign() {
            return align;
        }
    }
//    public enum PrintFormat {
//
////        NORMAL(""), BOLD("E"), BIG("B"), HIGH("H"), WIDE("W"),
////        BAR_EAN("M"), BAR_93("O"), BAR_39("P"), BAR_INT2OF5("R"),
////        BAR_128B("S"), BAR_128C("T"), BAR_128A("U"), BAR_PDF417("V"),
////        HEADER_IMAGE("J"), SENOR_IMG("I"), LOGO("L");
//        //
//        NORMAL(""), BOLD("E"), BIG("B"), HIGH("H"), WIDE("W"),
//        BAR_EAN("P"), BAR_93("O"), BAR_39("Q"), BAR_INT2OF5("R"),
//        BAR_128A("X"), BAR_128B("S"), BAR_128C("T"), BAR_INT2OF5L("U"), BAR_PDF417("V"),
//        HEADER_IMAGE("J"), SENOR_IMG("I"), LOGO("L");
//
//        private final String format;
//
//        private PrintFormat(String f) {
//            format = f;
//        }
//
//        public String getFormat() {
//            return format;
//        }
//    }

    public PrintJob(int pageWidth) {
        this.pageWidth = pageWidth;
        printLines = new ArrayList<> ();
    }

    public void addLine(String line, PrintAlign align, AeonPrintFormat format) {
        String newFormat = format.getFormat();
        if (align.equals(PrintAlign.CENTER) && format.equals(AeonPrintFormat.CENTER_BOLD)) {
            if (PrintUtil.isPinFormat(line)){
                newFormat = "PF";
            }
        }
        printLines.add(makeFormat(align.getAlign(), newFormat) + line);
    }

    public void addBreak() {
        String s = "-";
        while (s.length () < pageWidth) {
            s += "-";
        }
        addLine (s, PrintAlign.CENTER, AeonPrintFormat.NORMAL);
    }

    private String makeFormat(String f1, String f2) {
        String f = f1 + f2 + "|";
        while (f.length () < 5) {
            f = " " + f;
        }
        return f;
    }


    @Override
    public String toString() {
        return printLines.toString ();
    }

//    public List<String> getPrintLines() {
//        return printLines;
//    }

    public List<String> getEncodedPrintLines() {
        List<String> res = new ArrayList<> ();

        for (String s : printLines) {
            try {
                switch (JKPrinter.getPrinterConfig ().getPrintDriver ()) {
                    case PrintUtil.POS_STAR:
                        res.add (URLEncoder.encode (s.replaceAll ("%", ""), "UTF-8"));
                        break;
                    case PrintUtil.POS_EPSON:
                        res.add (URLEncoder.encode (s.replaceAll ("%", "\\%%").replaceAll ("[+]", "%+"), "UTF-8"));
                        break;
                    default:
                        res.add (URLEncoder.encode (s, "UTF-8"));
                        break;
                }
            } catch (Exception e) {
                logger.log (Level.SEVERE, e.getMessage (), e);
            }
        }

        return res;
    }
}
