package jkiosk3.users;

import aeonusers.User;

/**
 *
 * @author Valerie
 */
public class JKUserAddEdit {

    private String newOrEdit;
    private User aeonUser;
    //
    private static JKUserAddEdit instance;

    private static JKUserAddEdit newInstance() {
        instance = new JKUserAddEdit();
        return instance;
    }

    public static JKUserAddEdit getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    public static void resetJKUserAddEdit() {
        instance = null;
    }

    //
    // getters and setters    
    public String getNewOrEdit() {
        return newOrEdit;
    }

    public void setNewOrEdit(String newOrEdit) {
        this.newOrEdit = newOrEdit;
    }

    public User getAeonUser() {
        return aeonUser;
    }

    public void setAeonUser(User aeonUser) {
        this.aeonUser = aeonUser;
    }
}
