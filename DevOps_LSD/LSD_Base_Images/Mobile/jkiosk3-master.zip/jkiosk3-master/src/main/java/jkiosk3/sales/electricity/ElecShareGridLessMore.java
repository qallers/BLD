package jkiosk3.sales.electricity;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3.store.JKOptions;

/**
 *
 * @author Val
 */
public class ElecShareGridLessMore extends Region {

    private final String requestor;
    private TextField txtAmt;
    private TextField txtSGC;
    private TextField txtTT;
    private TextField txtTi;
    private TextField txtKrn;
    private TextField txtAlg;

    public ElecShareGridLessMore(String requestor) {
        this.requestor = requestor;
        getChildren().add(getGridLessMore());
    }

    private GridPane getGridLessMore() {

        GridPane grid = JKLayout.getGridContent2Col(0.5, 0.5);

        Label lblAmt = JKText.getLblDk("Amount", JKText.FONT_B_XSM);
        lblAmt.setMinWidth(JKLayout.btnSmW);

        Label lblSGC = JKText.getLblDk("SGC", JKText.FONT_B_XSM);
        Label lblTT = JKText.getLblDk("TT", JKText.FONT_B_XSM);
        Label lblTi = JKText.getLblDk("Ti", JKText.FONT_B_XSM);
        Label lblKrn = JKText.getLblDk("Krn", JKText.FONT_B_XSM);
        Label lblAlg = JKText.getLblDk("Alg", JKText.FONT_B_XSM);

        txtAmt = new TextField();
        txtAmt.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtAmt, "Enter Amount", "");
                }
            }
        });

        txtSGC = new TextField();
        txtSGC.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtSGC, "Enter SGC", "");
                }
            }
        });

        txtTT = new TextField();
        txtTT.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtTT, "Enter Token Tech", "");
                }
            }
        });

        txtTi = new TextField();
        txtTi.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtTi, "Enter Ti", "");
                }
            }
        });

        txtKrn = new TextField();
        txtKrn.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtKrn, "Enter Krn", "");
                }
            }
        });

        txtAlg = new TextField();
        txtAlg.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getNumPad().showNumPad(txtAlg, "Enter Alg", "");
                }
            }
        });

        int rowCount = 0;
        if (requestor.equalsIgnoreCase(ElectricityUtil.ELEC_TOKEN)
                || requestor.equalsIgnoreCase(ElectricityUtil.ELEC_TRIAL_VEND)) {
            grid.addRow(rowCount, lblAmt, txtAmt);
            rowCount++;
        }
        grid.addRow(rowCount, lblSGC, txtSGC);
        grid.addRow(++rowCount, lblTT, txtTT);
        grid.addRow(++rowCount, lblTi, txtTi);
        grid.addRow(++rowCount, lblKrn, txtKrn);
        grid.addRow(++rowCount, lblAlg, txtAlg);

        return grid;
    }

    public TextField getTxtAlg() {
        return txtAlg;
    }

    public TextField getTxtAmt() {
        return txtAmt;
    }

    public TextField getTxtKrn() {
        return txtKrn;
    }

    public TextField getTxtSGC() {
        return txtSGC;
    }

    public TextField getTxtTT() {
        return txtTT;
    }

    public TextField getTxtTi() {
        return txtTi;
    }
}
