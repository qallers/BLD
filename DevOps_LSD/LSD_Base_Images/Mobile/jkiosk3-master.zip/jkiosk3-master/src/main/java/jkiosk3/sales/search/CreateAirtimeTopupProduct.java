package jkiosk3.sales.search;

import jkiosk3.sales.SalesItems;
import jkiosk3.sales.topups.TopupProvider;

import java.util.ArrayList;
import java.util.List;

public class CreateAirtimeTopupProduct {

    public static List<SearchProduct> createAirtimeTopupProducts() {
        final String TOP_UP_AIRTIME = "Airtime Topup";

        List<SearchProduct> products = new ArrayList<>();
        for (TopupProvider topupProvider : SalesItems.getListTopupProvidersAirtime()) {
            SearchProduct networkProvider = new SearchProduct();

            String name = topupProvider.getName();
            if (name.toLowerCase().contains("cellc")) {
                name = "Cell C";
            } else if (name.toLowerCase().contains("mtn")) {
                name = "MTN";
            } else if (name.toLowerCase().contains("telkommobile")) {
                name = "Telkom Mobile";
            } else if (name.toLowerCase().contains("virgin")) {
                name = "Virgin Mobile";
            } else if (name.toLowerCase().contains("vodacom")) {
                name = "Vodacom";
            }

            networkProvider.setProvName(topupProvider.getName());
            networkProvider.setProdName(String.format("%s %s", name.startsWith("x") ? name.substring(1) : name, TOP_UP_AIRTIME));
            networkProvider.setSearchTransType(SearchTransType.AIRTIME_TOPUP);

            products.add(networkProvider);
        }
        return products;
    }

}
