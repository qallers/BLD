package jkiosk3.sales.rica;

import aeonrica.Registration;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;

/**
 *
 * @author Val
 */
public class RICAConfirm extends Region {

    private Registration reg;

    public RICAConfirm(Registration registration) {

        this.reg = registration;

        ScrollPane scroll = new ScrollPane();
        scroll.setPrefSize(JKLayout.contentW - (2 * JKLayout.sp), 450);
        scroll.getStyleClass().add("scrollWhite");
        scroll.setStyle("-fx-padding: 15px;");
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        VBox vbConfirm = JKLayout.getVBox(0, 5);

        switch (RICAUtil.getRegistrationType()) {
            case RICAUtil.NEW_REG:
                vbConfirm.getChildren().add(buildNewRegSummary());
                break;
            case RICAUtil.CHANGE_CELL_NUM:
                vbConfirm.getChildren().addAll(buildChOwnCellSummary(), buildNewRegSummary());
                break;
            case RICAUtil.CHANGE_SIM_SP:
                vbConfirm.getChildren().addAll(buildNewRegSummary());
        }

        scroll.setContent(vbConfirm);

        getChildren().add(scroll);
    }

    private GridPane buildChOwnCellSummary() {
        GridPane grid = JKLayout.getSummaryGridInScroll2Col(0.35, 0.65);

        Label lblCurrOwner = JKText.getLblDk("Current Owner", JKText.FONT_B_XSM);
        Label lblCurrIdType = JKText.getLblDk("ID Type", JKText.FONT_B_XXSM);
        Label lblCurrIdNum = JKText.getLblDk("ID / Passport Number", JKText.FONT_B_XXSM);
        Label lblCurrNationality = JKText.getLblDk("Nationality", JKText.FONT_B_XXSM);
        Label lblNewOwner = JKText.getLblDk("New Owner", JKText.FONT_B_XSM);

        String currIdType = "";
        if (reg.getCurrOwnIdtype() != null) {
            switch (reg.getCurrOwnIdtype()) {
                case "N":
                    currIdType = "ID Document";
                    break;
                case "P":
                    currIdType = "Passport";
                    break;
                case "B":
                    currIdType = "Business";
            }
        }

        Text txtCurrIdType = JKText.getTxtDk(currIdType, JKText.FONT_B_XSM);
        Text txtCurrIdNumber = JKText.getTxtDk(reg.getCurrOwnIdnumber(), JKText.FONT_B_XSM);
        Text txtCurrNationality = JKText.getTxtDk(reg.getCurrOwnNationality(), JKText.FONT_B_XSM);

        grid.add(lblCurrOwner, 0, 0);
        grid.add(lblCurrIdType, 0, 1);
        grid.add(lblCurrIdNum, 0, 2);
        grid.add(lblCurrNationality, 0, 3);
        grid.add(JKNode.createGridSpanSep(2), 0, 4);
        grid.add(lblNewOwner, 0, 5);

        grid.add(txtCurrIdType, 1, 1);
        grid.add(txtCurrIdNumber, 1, 2);
        grid.add(txtCurrNationality, 1, 3);

        return grid;
    }

    private GridPane buildNewRegSummary() {
        GridPane grid = JKLayout.getSummaryGridInScroll2Col(0.35, 0.65);

        Label lblNetwork = JKText.getLblDk("Network", JKText.FONT_B_XXSM);
        Label lblTitle = JKText.getLblDk("Title", JKText.FONT_B_XXSM);
        Label lblName = JKText.getLblDk("Subscriber Name", JKText.FONT_B_XXSM);
        Label lblIdType = JKText.getLblDk("ID Type", JKText.FONT_B_XXSM);
        Label lblIdNum = JKText.getLblDk("ID / Passport Number", JKText.FONT_B_XXSM);
        Label lblNationality = JKText.getLblDk("Nationality", JKText.FONT_B_XXSM);
        Label lblIdVerified = JKText.getLblDk("ID Verified", JKText.FONT_B_XXSM);
        Label lblAddr1 = JKText.getLblDk("Address 1", JKText.FONT_B_XXSM);
        Label lblAddr2 = JKText.getLblDk("Address 2", JKText.FONT_B_XXSM);
        Label lblAddrSuburb = JKText.getLblDk("Suburb", JKText.FONT_B_XXSM);
        Label lblAddrCity = JKText.getLblDk("City", JKText.FONT_B_XXSM);
        Label lblAddrRegion = JKText.getLblDk("Region", JKText.FONT_B_XXSM);
        Label lblAddrPostcode = JKText.getLblDk("Post Code", JKText.FONT_B_XXSM);
        Label lblAddrCountry = JKText.getLblDk("Country", JKText.FONT_B_XXSM);
        Label lblAddrVerified = JKText.getLblDk("Address Verified", JKText.FONT_B_XXSM);
        Label lblTelContact = JKText.getLblDk("Contact Number", JKText.FONT_B_XXSM);
        Label lblRefType = JKText.getLblDk("Register by...", JKText.FONT_B_XXSM);
        Label lblRefNumber = JKText.getLblDk("Reference Number", JKText.FONT_B_XXSM);
        Label lblL4Sim = JKText.getLblDk("Last 4 SIM Number", JKText.FONT_B_XXSM);

        Text txtNetwork = JKText.getTxtDk(reg.getNetwork(), JKText.FONT_B_XSM);

        Text txtTitle = JKText.getTxtDk(reg.getTitle(), JKText.FONT_B_XSM);
        Text txtName = JKText.getTxtDk(reg.getFirstname() + " " + reg.getLastname(), JKText.FONT_B_XSM);
        txtName.setWrappingWidth(MessageBox.getMsgWidth() - (6 * JKLayout.sp) * 0.65);
        txtName.setTextAlignment(TextAlignment.RIGHT);

        String idType = "";
        switch (reg.getIdtype()) {
            case "N":
                idType = "ID Document";
                break;
            case "P":
                idType = "Passport";
                break;
            case "B":
                idType = "Business";
        }
        Text txtIdType = JKText.getTxtDk(idType, JKText.FONT_B_XSM);
        Text txtIdNumber = JKText.getTxtDk(reg.getIdnumber(), JKText.FONT_B_XSM);
        Text txtNationality = JKText.getTxtDk(reg.getNationality(), JKText.FONT_B_XSM);

        String isIdVerifiedText;
        if (reg.isIdverify()) {
            isIdVerifiedText = "Yes";
        } else {
            isIdVerifiedText = "No";
        }
        Text txtIdVerified = JKText.getTxtDk(isIdVerifiedText, JKText.FONT_B_XSM);
        Text txtAddr1 = JKText.getTxtDk(reg.getAddr1(), JKText.FONT_B_XSM);
        Text txtAddr2 = JKText.getTxtDk(reg.getAddr2(), JKText.FONT_B_XSM);
        Text txtAddrSuburb = JKText.getTxtDk(reg.getAddrsuburb(), JKText.FONT_B_XSM);
        Text txtAddrCity = JKText.getTxtDk(reg.getAddrcity(), JKText.FONT_B_XSM);
        Text txtAddrRegion = JKText.getTxtDk(reg.getAddrregion(), JKText.FONT_B_XSM);
        Text txtAddrPostcode = JKText.getTxtDk(reg.getAddrpostcode(), JKText.FONT_B_XSM);
        Text txtAddrCountry = JKText.getTxtDk(reg.getAddrcountry(), JKText.FONT_B_XSM);

        String isAddrVerifiedText;
        if (reg.isProofaddr()) {
            isAddrVerifiedText = "Yes";
        } else {
            isAddrVerifiedText = "No";
        }
        Text txtAddrVerified = JKText.getTxtDk(isAddrVerifiedText, JKText.FONT_B_XSM);
        Text txtTelContact = JKText.getTxtDk(reg.getTelCountryCode() + " " + reg.getTelAreaCode() + " " + reg.getTelDialingNo(),
                JKText.FONT_B_XSM);

        String regBy = "";
        switch (reg.getReftype()) {
            case SubAll.REG_SUBMIT_CELL:
                regBy = SubAll.REG_TYPE_CELL;
                break;
            case SubAll.REG_SUBMIT_SP:
                regBy = SubAll.REG_TYPE_SP;
                break;
            case SubAll.REG_SUBMIT_SIM:
                regBy = SubAll.REG_TYPE_SIM;
        }
        Text txtRefType = JKText.getTxtDk(regBy, JKText.FONT_B_XSM);
        Text txtRefNumber = JKText.getTxtDk(reg.getRefnumber(), JKText.FONT_B_XSM);
        Text txtL4Sim = JKText.getTxtDk(reg.getLast4simdigs(), JKText.FONT_B_XSM);

        grid.add(lblNetwork, 0, 0);
        grid.add(lblTitle, 0, 1);
        grid.add(lblName, 0, 2);
        grid.add(lblIdType, 0, 3);
        grid.add(lblIdNum, 0, 4);
        grid.add(lblNationality, 0, 5);
        grid.add(lblIdVerified, 0, 6);
        grid.add(lblAddr1, 0, 7);
        grid.add(lblAddr2, 0, 8);
        grid.add(lblAddrSuburb, 0, 9);
        grid.add(lblAddrCity, 0, 10);
        grid.add(lblAddrRegion, 0, 11);
        grid.add(lblAddrPostcode, 0, 12);
        grid.add(lblAddrCountry, 0, 13);
        grid.add(lblAddrVerified, 0, 14);
        grid.add(lblTelContact, 0, 15);
        grid.add(lblRefType, 0, 16);
        grid.add(lblRefNumber, 0, 17);
        grid.add(lblL4Sim, 0, 18);

        grid.add(txtNetwork, 1, 0);
        grid.add(txtTitle, 1, 1);
        grid.add(txtName, 1, 2);
        grid.add(txtIdType, 1, 3);
        grid.add(txtIdNumber, 1, 4);
        grid.add(txtNationality, 1, 5);
        grid.add(txtIdVerified, 1, 6);
        grid.add(txtAddr1, 1, 7);
        grid.add(txtAddr2, 1, 8);
        grid.add(txtAddrSuburb, 1, 9);
        grid.add(txtAddrCity, 1, 10);
        grid.add(txtAddrRegion, 1, 11);
        grid.add(txtAddrPostcode, 1, 12);
        grid.add(txtAddrCountry, 1, 13);
        grid.add(txtAddrVerified, 1, 14);
        grid.add(txtTelContact, 1, 15);
        grid.add(txtRefType, 1, 16);
        grid.add(txtRefNumber, 1, 17);
        grid.add(txtL4Sim, 1, 18);

        return grid;
    }
}
