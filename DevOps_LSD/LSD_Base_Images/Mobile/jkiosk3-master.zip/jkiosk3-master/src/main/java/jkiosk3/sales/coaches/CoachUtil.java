package jkiosk3.sales.coaches;

import aeoncoach.*;
import javafx.concurrent.Task;
import jkiosk3.JKiosk3;
import jkiosk3.sales.TicketingMenu;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.store.cache.CacheListCoachCarriers;
import jkiosk3.store.cache.CacheListCoachCities;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CoachUtil {

    private final static Logger logger = Logger.getLogger(CoachUtil.class.getName());

    public final static String COACH_PG_HEAD = "Coach Ticket Booking";
    public final static String TRIP_DEPART = "Departure";
    public final static String TRIP_RETURN = "Return";

    public final static String LOCATION_BOARDING = "Board";
    public final static String LOCATION_DESTINATION = "Destination";

    private static CoachConnection coachConnection;

    private final static TaskUtil TASK_UTIL = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int COUNTDOWN_TIME = 60;

    public static CoachConnection getCoachConnection() {
        CoachConnection coachConnect = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = (JKSystem.getSystemConfig().getPort());
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            coachConnect = new CoachConnection(server, port, secureConnect);
            coachConnect.setTimeout(COUNTDOWN_TIME);
        } catch (Exception e) {
            // Exception will catch SocketException, SocketTimeoutException and ConnectException
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return coachConnect;
    }

    private static boolean isLoggedIn(String pin) throws RuntimeException {
        String loyaltyProfileId = "";
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            loyaltyProfileId = ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId();
        }

        boolean loggedIn = false;
        int deviceId = JKSystem.getSystemConfig().getDeviceId();
        String serial = JKSystem.getSystemConfig().getSerial();
        coachConnection = getCoachConnection();
        try {
            loggedIn = coachConnection.login(pin, deviceId, serial, loyaltyProfileId);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    private static CoachCarriersList getCoachCarriersList() throws RuntimeException {
        CoachCarriersList coachCarriersList = new CoachCarriersList();

        if (CacheListCoachCarriers.hasItems()) {
            logger.info("getting Coach Carriers list from cache");
            coachCarriersList = CacheListCoachCarriers.getListCoachCarriers();
        } else {
            logger.info("getting Coach Carriers list from server");
            coachCarriersList = getCoachCarriersListOnline();
        }

        return coachCarriersList;
    }

    private static CoachCarriersList getCoachCarriersListOnline() throws RuntimeException {
        CoachCarriersList carriersAllowed = new CoachCarriersList();

        try {
            if (isLoggedIn(CurrentUser.getUser().getUserPin())) {
                CoachCarriersList carrierList = coachConnection.getCoachCarrierList();

                List<String> userTransTypes = CurrentUser.getUser().getTransTypes();

                carriersAllowed.setSuccess(carrierList.isSuccess());
                carriersAllowed.setMediaUrl(carrierList.getMediaUrl());

                for (CoachCarrier c : carrierList.getListCarriers()) {
                    if (userTransTypes.contains(c.getCarrierTransType())) {
                        carriersAllowed.getListCarriers().add(c);
                    }
                }
                Collections.sort(carriersAllowed.getListCarriers(), new Comparator<CoachCarrier>() {
                    @Override
                    public int compare(CoachCarrier b1, CoachCarrier b2) {
                        return b1.getCarrierName().compareTo(b2.getCarrierName());
                    }
                });
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Coach Carriers List Error", t);
        } finally {
            if (coachConnection != null) {
                coachConnection.disconnect();
            }
        }
        return carriersAllowed;
    }

    private static CoachListItemResp getCityList() throws RuntimeException {
        CoachListItemResp coachCitiesList = new CoachListItemResp();

//        if (CacheListCoachCities.hasItems()) {
//            logger.info("getting Coach Cities list from cache");
//            coachCitiesList = CacheListCoachCities.getListCoachCities();
//        } else {
        logger.info("getting Coach Cities list from server");
        coachCitiesList = getCityListOnline();
//        }

        return coachCitiesList;
    }

    private static CoachListItemResp getCityListOnline() throws RuntimeException {
        CoachListItemResp cityList = new CoachListItemResp();
        try {
            if (isLoggedIn(CurrentUser.getSalesUser().getUserPin())) {
                cityList = coachConnection.getCoachCityList();
                if (!cityList.getListItems().isEmpty()) {
                    Collections.sort(cityList.getListItems(), new Comparator<CoachListItem>() {
                        @Override
                        public int compare(CoachListItem b1, CoachListItem b2) {
                            return b1.getName().compareTo(b2.getName());
                        }
                    });
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("City List Error", t);
        } finally {
            if (coachConnection != null) {
                coachConnection.disconnect();
            }
        }
        return cityList;
    }

    private static CoachAvailabilityResp getCoachAvailability(CoachAvailabilityReq availabilityReq) throws RuntimeException {
        CoachAvailabilityResp availabilityResp = new CoachAvailabilityResp();
        try {
            if (isLoggedIn(CurrentUser.getSalesUser().getUserPin())) {
                availabilityResp = coachConnection.getRouteAvailabilityExtended(availabilityReq);
                if (!availabilityResp.getRoutes().isEmpty()) {
                    Collections.sort(availabilityResp.getRoutes(), new Comparator<CoachRoute>() {
                        @Override
                        public int compare(CoachRoute b1, CoachRoute b2) {
                            return b1.getBoardingTime().compareTo(b2.getBoardingTime());
                        }
                    });
                }
                if (!availabilityResp.getReturnRoutes().isEmpty()) {
                    Collections.sort(availabilityResp.getReturnRoutes(), new Comparator<CoachRoute>() {
                        @Override
                        public int compare(CoachRoute b1, CoachRoute b2) {
                            return b1.getBoardingTime().compareTo(b2.getBoardingTime());
                        }
                    });
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("City List Error", t);
        } finally {
            if (coachConnection != null) {
                coachConnection.disconnect();
            }
        }
        return availabilityResp;
    }

    private static CoachPassengerTypeList getCoachPassengerTypeList() {
        CoachPassengerTypeList coachPassTypeList = null;
        try {
            if (isLoggedIn(CurrentUser.getSalesUser().getUserPin())) {
                coachPassTypeList = coachConnection.getCoachPassengerTypeList();
                if (!coachPassTypeList.getListCoachPassengerTypes().isEmpty()) {
                    Collections.sort(coachPassTypeList.getListCoachPassengerTypes(), new Comparator<CoachPassengerType>() {
                        @Override
                        public int compare(CoachPassengerType b1, CoachPassengerType b2) {
                            return b1.getName().compareTo(b2.getName());
                        }
                    });
                }
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Passenger Type List Error", t);
        } finally {
            if (coachConnection != null) {
                coachConnection.disconnect();
            }
        }
        return coachPassTypeList;
    }

    private static CoachReserveResp reserveCoachSeats(CoachReserveReq rReq) throws RuntimeException {
        CoachReserveResp reservation = new CoachReserveResp();

        try {
            if (isLoggedIn(CurrentUser.getSalesUser().getUserPin())) {
                reservation = coachConnection.reserveCoachSeats(rReq);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Reserve Seats Error", t);
        } finally {
            if (coachConnection != null) {
                coachConnection.disconnect();
            }
        }
        return reservation;
    }

    private static CoachCompleteResp completeCoachReservation(CoachCompleteReq cReq) throws RuntimeException {
        CoachCompleteResp completeReservation = new CoachCompleteResp();

        try {
            if (isLoggedIn(CurrentUser.getSalesUser().getUserPin())) {
                completeReservation = coachConnection.completeCoachReservation(cReq);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Reserve Seats Error", t);
        } finally {
            if (coachConnection != null) {
                coachConnection.disconnect();
            }
        }
        return completeReservation;
    }

    /*----------------------------------*/
    /* Busy Indicators - pause and wait */
    /*----------------------------------*/
    public static void getCoachCarriersList(final CoachCarriersListResult result) {
        JKiosk3.getBusy().showBusy("Getting Coach Carriers List");

        final Task<CoachCarriersList> taskCarriers = new Task<CoachCarriersList>() {
            @Override
            protected CoachCarriersList call() throws Exception {
                return getCoachCarriersList();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.coachCarriersListResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("Coach Carriers List Error",
                        "Unable to retrieve Coach Carriers List", State.CANCELLED, errorMsg, new TicketingMenu());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("Coach Carriers List Error",
                        "Unable to retrieve Coach Carriers List", State.FAILED, errorMsg, new TicketingMenu());
            }
        };

        new Thread(taskCarriers).start();
        JKiosk3.getBusy().startCountdown(taskCarriers, COUNTDOWN_TIME);
    }

    public static void getCityList(final CoachCityListResult result) {
        JKiosk3.getBusy().showBusy("Getting List of Cities");

        final Task<CoachListItemResp> taskCity = new Task<CoachListItemResp>() {
            @Override
            protected CoachListItemResp call() throws Exception {
                return getCityList();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.coachCityListResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("City List Error",
                        "Unable to retrieve Boarding City List", State.CANCELLED, errorMsg, new TicketingMenu());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("City List Error",
                        "Unable to retrieve Boarding City List", State.FAILED, errorMsg, new TicketingMenu());
            }
        };
        new Thread(taskCity).start();
        JKiosk3.getBusy().startCountdown(taskCity, COUNTDOWN_TIME);
    }

    public static void getCoachAvailability(final CoachAvailabilityReq availabilityReq, final CoachAvailabilityResult result) {
        JKiosk3.getBusy().showBusy("Getting Available Routes");

        final Task<CoachAvailabilityResp> taskAvailabilty = new Task<CoachAvailabilityResp>() {
            @Override
            protected CoachAvailabilityResp call() throws Exception {
                return getCoachAvailability(availabilityReq);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.coachAvailabilityResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("Coach Availability Error",
                        "Unable to retrieve Available Routes", State.CANCELLED, errorMsg, new TicketingMenu());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("Coach Availability Error",
                        "Unable to retrieve Available Routes", State.FAILED, errorMsg, new TicketingMenu());
            }
        };
        new Thread(taskAvailabilty).start();
        JKiosk3.getBusy().startCountdown(taskAvailabilty, COUNTDOWN_TIME);
    }

    public static void getCoachPassengerTypeList(final CoachPassengerTypeListResult result) {
        JKiosk3.getBusy().showBusy("Getting Passenger Types");

        final Task<CoachPassengerTypeList> taskPassTypes = new Task<CoachPassengerTypeList>() {
            @Override
            protected CoachPassengerTypeList call() throws Exception {
                return getCoachPassengerTypeList();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.coachPassengerTypeListResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("Coach Passenger Types",
                        "Unable to retrieve Passenger Types", State.CANCELLED, errorMsg, new TicketingMenu());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("Coach Passenger Types",
                        "Unable to retrieve Passenger Types", State.FAILED, errorMsg, new TicketingMenu());
            }
        };
        new Thread(taskPassTypes).start();
        JKiosk3.getBusy().startCountdown(taskPassTypes, COUNTDOWN_TIME);
    }

    public static void reserveCoachSeats(final CoachReserveReq rReq, final CoachReserveRespResult result) {
        JKiosk3.getBusy().showBusy("Reserving Seats");

        final Task<CoachReserveResp> taskReserve = new Task<CoachReserveResp>() {
            @Override
            protected CoachReserveResp call() throws Exception {
                return reserveCoachSeats(rReq);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.coachReserveRespResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("Coach Reserve Seats Error",
                        "Unable to Reserve Seats", State.CANCELLED, errorMsg, new TicketingMenu());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("Coach Reserve Seats Error",
                        "Unable to Reserve Seats", State.FAILED, errorMsg, new TicketingMenu());
            }
        };

        new Thread(taskReserve).start();
        JKiosk3.getBusy().startCountdown(taskReserve, COUNTDOWN_TIME);
    }

    public static void completeCoachReservation(final CoachCompleteReq cReq, final CoachCompleteRespResult result) {
        JKiosk3.getBusy().showBusy("Completing Reservation");

        final Task<CoachCompleteResp> taskReserve = new Task<CoachCompleteResp>() {
            @Override
            protected CoachCompleteResp call() throws Exception {
                return completeCoachReservation(cReq);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.coachCompleteRespResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("Coach Complete Reservation Error",
                        "Unable to Complete Reservation", State.CANCELLED, errorMsg, new TicketingMenu());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("Coach Complete Reservation Error",
                        "Unable to Complete Reservation", State.FAILED, errorMsg, new TicketingMenu());
            }
        };

        new Thread(taskReserve).start();
        JKiosk3.getBusy().startCountdown(taskReserve, COUNTDOWN_TIME);
    }

    public static abstract class CoachCarriersListResult {

        public abstract void coachCarriersListResult(CoachCarriersList coachCarriersListResult);
    }

    public static abstract class CoachCityListResult {

        public abstract void coachCityListResult(CoachListItemResp coachCityListResult);
    }

    public static abstract class CoachAvailabilityResult {
        public abstract void coachAvailabilityResult(CoachAvailabilityResp availabilityResp);
    }

    public static abstract class CoachPassengerTypeListResult {

        public abstract void coachPassengerTypeListResult(CoachPassengerTypeList coachPassengerTypeListResult);
    }

    public static abstract class CoachReserveRespResult {

        public abstract void coachReserveRespResult(CoachReserveResp coachReserveResp);
    }

    public static abstract class CoachCompleteRespResult {

        public abstract void coachCompleteRespResult(CoachCompleteResp coachCompleteResp);
    }

}
