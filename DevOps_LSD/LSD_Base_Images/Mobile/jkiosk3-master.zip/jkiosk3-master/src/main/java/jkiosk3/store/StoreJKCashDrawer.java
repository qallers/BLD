package jkiosk3.store;

import java.io.Serializable;
import jkiosk3.printing.cashdrawer.CashDrawerWindows;

/**
 *
 * @author Val
 */
public class StoreJKCashDrawer implements Serializable {

    private static final long serialVersionUID = 10002L;
    private String cashDrawerDirectOpos = "";
    private boolean cashDrawerDirect = true;
    private boolean cashDrawerOpos = false;
    private boolean cashDrawerIo = false;
    private String cashDrawerName = "PT6215CASHA";
    private String cashDrawerPort = "COM1";
    private int cashDrawerBaud = 9600;
    private boolean cashDrawerFlowControl = false;
    private CashDrawerWindows cdWindows = null;

    public int getCashDrawerBaud() {
        return cashDrawerBaud;
    }

    public void setCashDrawerBaud(int cashDrawerBaud) {
        this.cashDrawerBaud = cashDrawerBaud;
    }

    public boolean isCashDrawerDirect() {
        return cashDrawerDirect;
    }

    public void setCashDrawerDirect(boolean cashDrawerDirect) {
        this.cashDrawerDirect = cashDrawerDirect;
    }

    public boolean isCashDrawerIo() {
        return cashDrawerIo;
    }

    public void setCashDrawerIo(boolean cashDrawerIo) {
        this.cashDrawerIo = cashDrawerIo;
    }

    public boolean isCashDrawerOpos() {
        return cashDrawerOpos;
    }

    public void setCashDrawerOpos(boolean cashDrawerOpos) {
        this.cashDrawerOpos = cashDrawerOpos;
    }

    public String getCashDrawerDirectOpos() {
        return cashDrawerDirectOpos;
    }

    public void setCashDrawerDirectOpos(String cashDrawerDirectOpos) {
        this.cashDrawerDirectOpos = cashDrawerDirectOpos;
    }

    public boolean isCashDrawerFlowControl() {
        return cashDrawerFlowControl;
    }

    public void setCashDrawerFlowControl(boolean cashDrawerFlowControl) {
        this.cashDrawerFlowControl = cashDrawerFlowControl;
    }

    public String getCashDrawerName() {
        return cashDrawerName;
    }

    public void setCashDrawerName(String cashDrawerName) {
        this.cashDrawerName = cashDrawerName;
    }

    public String getCashDrawerPort() {
        return cashDrawerPort;
    }

    public void setCashDrawerPort(String cashDrawerPort) {
        this.cashDrawerPort = cashDrawerPort;
    }

    public CashDrawerWindows getCdWindows() {
        return cdWindows;
    }

    public void setCdWindows(CashDrawerWindows cdWindows) {
        this.cdWindows = cdWindows;
    }
}
