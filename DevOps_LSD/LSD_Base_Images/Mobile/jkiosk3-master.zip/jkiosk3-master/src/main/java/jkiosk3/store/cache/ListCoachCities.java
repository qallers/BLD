package jkiosk3.store.cache;

import aeoncoach.CoachListItemResp;

import java.io.Serializable;

public class ListCoachCities implements Serializable {

    // L(ist)  = 12 (1 + 2 = 3)
    // C(oach) = 3
    // C(ities) = 3
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 99133L;

    private CoachListItemResp coachCitiesList = new CoachListItemResp();

    public CoachListItemResp getCoachCitiesList() {
        return coachCitiesList;
    }

    public void setCoachCitiesList(CoachListItemResp coachCitiesList) {

        this.coachCitiesList = coachCitiesList;
    }
}
