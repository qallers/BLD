package jkiosk3.printing;

import aeonprinting.AeonPrintJob;
import aeonprinting.AeonPrintPane;
import aeonprinting.AeonPrintingConnection;
import aeonprinting.PrintResult;
import aeonusers.SetPrintedResponse;
import javafx.event.Event;
import javafx.event.EventHandler;
import jkiosk3.JKiosk3;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.MagCardPrompt;
import jkiosk3._components.MagCardPromptResult;
import jkiosk3.printing.print_layouts.PrintAssorted;
import jkiosk3.store.*;
import jkiosk3.users.UserUtil;

import javax.print.event.PrintJobEvent;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PrintUtil {

    private final static Logger LOG = Logger.getLogger(PrintUtil.class.getName());
    //
    public static final boolean PRINT_WIN = JKPrinter.getPrinterConfig().isPrintWin();
    public static final boolean PRINT_POS = !JKPrinter.getPrinterConfig().isPrintWin();
    //
    public static final String POS_EPSON = "Epson";
    public static final String POS_STAR = "Star";
    //
    private final PrintJobLayout printLayout = new PrintJobLayout();
    //
    private static int currentPrintQueueSize;
    private static List<String> listTransRefs = new ArrayList<>();
    private static int countSetPrinted;
    private static int countPrintJob = 0;
    private static boolean isFromQueue;
    //
    // 2019-11-05  -  PRODDEFECT-868
    private static StoreJKSetPrintedQueue jkSetPrintedQueue;
    private static List<String> listSetPrinted;
    private static int countSetItemPrinted;
    private static int countSetPrintedSubmit = 0;
    //
    private static String errorMsg = "An unknown error occurred";
    private final static int countdownTime = 60;

    private static AeonPrintingConnection getPrintConnect() {
        AeonPrintingConnection printConn = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();
        try {
            printConn = new AeonPrintingConnection(server, port, secureConnect);
            printConn.setTimeout(countdownTime);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            LOG.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            LOG.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            LOG.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            LOG.log(Level.SEVERE, e.getMessage(), e);
        }
        return printConn;
    }

    private void printJob(AeonPrintJob apj) {
        if (PRINT_POS) {
            LOG.info("PRINTING TO SERIAL PRINTER - unknown print job");
            PrintDevice d = new PrintDevice("Printer");
            PrintJob pj = printLayout.getPrintJobSer(apj);
            new PrintClient().print(pj, d);
        } else if (PRINT_WIN) {
            LOG.info("PRINTING TO WINDOWS PRINTER - unknown print job");
            AeonPrintPane ep = new AeonPrintPane();
            ep.setEditable(false);
            ep.setContentType("text/html");
            String printWin = printLayout.getPrintLinesWin(apj);
            ep.setText(printWin);
            ep.printPane();
        }

        // This should not be applicable here, and may cause an endless loop!
//        if (apj.getMerchantCopy() != null) {
//            printJob(apj.getMerchantCopy());
//        }
    }

    private void printJob(AeonPrintJob apj, final String transRef, boolean isQueued, boolean isPreview, boolean isForceBarcode) {
        PrintJobLayout printLayout = new PrintJobLayout(isForceBarcode);
        if (PRINT_POS) {
            LOG.info("PRINTING TO SERIAL PRINTER - TRANSACTION ID : " + transRef);
            PrintDevice d = new PrintDevice("Printer");
            PrintJob pj = printLayout.getPrintJobSer(apj);
            new PrintClient().print(pj, d);
        } else if (PRINT_WIN) {
            LOG.info("PRINTING TO WINDOWS PRINTER - TRANSACTION ID : " + transRef);
            AeonPrintPane ep = new AeonPrintPane();
            ep.setEditable(false);
            ep.setContentType("text/html");
            String printWin = printLayout.getPrintLinesWin(apj);
            ep.setText(printWin);
            ep.printPane(new PrintResult() {

                @Override
                public void onDone(PrintJobEvent event) {
                    switch (event.getPrintEventType()) {
                        case PrintJobEvent.DATA_TRANSFER_COMPLETE:
                            // 1 - print event result DATA_TRANSFER_COMPLETE : 106
                            LOG.info(("print event result DATA_TRANSFER_COMPLETE : ").concat(Integer.toString(PrintJobEvent.DATA_TRANSFER_COMPLETE)));
                            break;
                        case PrintJobEvent.JOB_COMPLETE:
                            // 2 - print event result JOB_COMPLETE : 102
                            LOG.info(("print event result JOB_COMPLETE : ").concat(Integer.toString(PrintJobEvent.JOB_COMPLETE)));
                            break;
                        case PrintJobEvent.JOB_CANCELED:
                            // 3 - print event result JOB_CANCELED : 101
                            LOG.info(("print event result JOB_CANCELED : ").concat(Integer.toString(PrintJobEvent.JOB_CANCELED)));
                            break;
                        case PrintJobEvent.JOB_FAILED:
                            // 4 - print event result JOB_FAILED : 103
                            LOG.info(("print event result JOB_FAILED : ").concat(Integer.toString(PrintJobEvent.JOB_FAILED)));
                            break;
                        case PrintJobEvent.NO_MORE_EVENTS:
                            // 5 - print event result NO_MORE_EVENTS : 105
                            LOG.info(("print event result NO_MORE_EVENTS : ").concat(Integer.toString(PrintJobEvent.NO_MORE_EVENTS)));
                            break;
                        case PrintJobEvent.REQUIRES_ATTENTION:
                            // 6 - print event result REQUIRES_ATTENTION : 104
                            LOG.info(("print event result REQUIRES_ATTENTION : ").concat(Integer.toString(PrintJobEvent.REQUIRES_ATTENTION)));
                            break;
                        default:
                            break;
                    }
                }
            });
        }

        if (apj.getMerchantCopy() != null) {
            printJob(apj.getMerchantCopy());
        }
        // 2019-11-05  -  PRODDEFECT-868  -  trying to resolve items not set printed.
        // add to relevant queues and only THEN set them as printed.
        if (!listTransRefs.contains(transRef)) {
            listTransRefs.add(transRef);
        }
        List<String> listFromSetPrinted = JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs();
        if (!listFromSetPrinted.contains(transRef)) {
            JKSetPrintedQueue.saveSetPrintedItem(transRef);
        }
        LOG.info(("\t\t\t").concat("JKSetPrintedQueue item count : ").concat(Integer.toString(JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs().size())));
        LOG.info("THESE ITEMS HAVE BEEN SENT TO THE PRINTER!!!");

    }

    public static void sendToPrinter(AeonPrintJob print) {
        try {
            if (print != null) {
                PrintUtil pu = new PrintUtil();
                pu.printJob(print);
            } else {
                JKiosk3.getMsgBox().showMsgBox("Print Error", "No Print Job available for printing", null);
            }
        } catch (Exception e) {
            JKiosk3.getMsgBox().showMsgBox("Printer Error", e.getMessage() + "\nIs the printer connected and switched on?", null);
            LOG.log(Level.SEVERE, e.getMessage(), e);
        }
    }

    public static void sendToPrinter(AeonPrintJob print, String transRef, boolean isForceBarcode) {
        // 2019-11-06  -  PRODDEFECT-868
        sendToPrinter(print, transRef, false, isForceBarcode);
    }

    public static void sendToPrinter(AeonPrintJob print, String transRef, boolean isPreviewed, boolean isForceBarcode) {
        try {
            if (print != null) {
                String trxId = transRef;
                if (trxId.contains("-")) {
                    int index = trxId.indexOf("-");
                    trxId = trxId.substring(0, index);
                }
                PrintUtil pu = new PrintUtil();
                LOG.info(("sending from queue = ").concat(Boolean.toString(isFromQueue).concat(" :: sending from preview = ").concat(Boolean.toString(isPreviewed))));
                if (isFromQueue) {
                    pu.printJob(print, trxId, true, isPreviewed, isForceBarcode);
                } else {
                    pu.printJob(print, trxId, false, isPreviewed, isForceBarcode);
                }
            } else {
                JKiosk3.getMsgBox().showMsgBox("Print Error", "No Print Job available for printing", null);
            }
        } catch (Exception e) {
            JKiosk3.getMsgBox().showMsgBox("Printer Error", e.getMessage() + "\nIs the printer connected and switched on?", null);
            LOG.log(Level.SEVERE, e.getMessage(), e);
        }
    }

    public static void writeMagCardUpdate(List<MagCardData> cardData, MagCardPromptResult result) {
        try {
            if (cardData.size() > 0) {
                LOG.info((" >>> writeMagCardUpdate() : track2 data = ").concat(cardData.get(0).getTrack2()));
                JKiosk3.getMagCardPrompt().showMagCodePromptBox(MagCardPrompt.CARD_METER, cardData, result, false);
            }
        } catch (Exception e) {
            LOG.log(Level.SEVERE, e.getMessage(), e);
            JKiosk3.getMsgBox().showMsgBox("Unable to write Mag Card",
                    e.getMessage() + "\nPlease check Mag Card Reader configuration", null);
            JKiosk3.getMagCardPrompt().stopMagEncoder();
        }
    }

    public static void writeMagCardUpdate(final List<MagCardData> cardUpdates, final List<MagCardData> magTokens, final boolean isWriteAll) {
        if (JKCardReader.getCardReaderConfig().isMagCardWrite()) {
            PrintUtil.writeMagCardUpdate(cardUpdates, new MagCardPromptResult() {
                @Override
                public void onDone() {
                    if (isWriteAll) {
                        PrintUtil.writeMagCardTokens(magTokens, null);
                    }
                }
            });
        } else {
            JKiosk3.getMsgBox().showMsgBox("Unable to write Mag Cards", "Mag Card Read/Write not configured in Setup", null);
        }
    }

    public static void writeMagCardTokens(List<MagCardData> cards, MagCardPromptResult result) {
        try {
            if (cards.size() > 0) {
                LOG.info((" >>> writeMagCards() : track2 data = ").concat(cards.get(0).getTrack2()));
                JKiosk3.getMagCardPrompt().showMagCodePromptBox(MagCardPrompt.CARD_TOKEN, cards, result, false);
            }
        } catch (Exception e) {
            LOG.log(Level.SEVERE, e.getMessage(), e);
            JKiosk3.getMsgBox().showMsgBox("Unable to write Mag Card",
                    e.getMessage() + "\nPlease check Mag Card Reader configuration", null);
            JKiosk3.getMagCardPrompt().stopMagEncoder();
        }
    }

    public static void writeMagCardTokenEncode(final String tokenNumber) {
        // 600727040516319865===0107100008101 : 00000000001207974400
        MagCardData magCardData = new MagCardData();
        magCardData.setTrack1("000");
        magCardData.setTrack2("0000000000000===00000000");
        magCardData.setTrack3(tokenNumber);
        List<MagCardData> magList = new ArrayList<>();
        magList.add(magCardData);
        // we will have a 'list-of-one', instead of changing the method that expects a list
        try {
            if (magList.size() > 0) {
                JKiosk3.getMagCardPrompt().showMagCodePromptBox(MagCardPrompt.CARD_TOKEN, magList, new MagCardPromptResult() {
                    @Override
                    public void onDone() {
                        AeonPrintJob apj = PrintAssorted.getPrintElectricityTokenEncoded(tokenNumber);
                        PrintUtil.sendToPrinter(apj);
                    }
                }, false);
                // Overwrite the default 'Done' button text and action
                JKiosk3.getMagCardPrompt().getBtnClose().setText("Cancel");
                JKiosk3.getMagCardPrompt().getBtnClose().setOnMouseReleased(new EventHandler<Event>() {
                    @Override
                    public void handle(Event e) {
                        System.out.println("user cancelled action");
                        JKiosk3.getMagCardPrompt().onCloseWithoutResult();
                    }
                });
            }
        } catch (Exception e) {
            JKiosk3.getMsgBox().showMsgBox("Unable to write Mag Card",
                    e.getMessage() + "\nPlease check Mag Card Reader configuration", null);
            JKiosk3.getMagCardPrompt().stopMagEncoder();
        }
    }

//    private void setTransactionPrinted(final String transRef) {
//        UserUtil.setTransactionPrinted(transRef, new SetPrintedResponseResult() {
//            @Override
//            public void setPrintedResponseResult(SetPrintedResponse result) {
//                if (result.isSuccess()) {
//                    JKSetPrintedQueue.removeSetPrintedItem(transRef);
//                    // continue - business as usual
//                    StringBuilder sb = new StringBuilder("\r\n");
//                    sb.append(("Set un-queued printed SUCCESS : transRef - ").concat(transRef)).append("\r\n");
//                    sb.append("   *   *   *   *   *   transaction complete   *   *   *   *   * ");
//                    LOG.info(sb.toString());
////                    LOG.info(("Set un-queued printed SUCCESS : transRef - ").concat(transRef));
//                } else {
//                    // LOG ErrorCode and ErrorText
//                    LOG.info(("Transaction not set as Printed : transRef - ").concat(transRef));
//                    LOG.info(("Print Error - ErrorCode : ").concat(Integer.toString(result.getErrorCode())).concat(" - ErrorText : ").concat(result.getErrorText()));
//                }
//            }
//        });
//    }

//    private static void setTransactionPrintedQueued(int printCount, final int printQueueSize, final PrintQueueResult queueResult) {
//        final String transRef = listTransRefs.get(printCount);
//        UserUtil.setTransactionPrinted(transRef, new SetPrintedResponseResult() {
//            @Override
//            public void setPrintedResponseResult(SetPrintedResponse result) {
//                if (result.isSuccess()) {
//                    JKSetPrintedQueue.removeSetPrintedItem(transRef);
//                    // continue - business as usual
//                    StringBuilder sb = new StringBuilder("\r\n");
//                    sb.append(("Set queued printed SUCCESS : transRef - ").concat(transRef)).append("\r\n");
//                    sb.append("   *   *   *   *   *   transaction complete   *   *   *   *   * ");
//                    LOG.info(sb.toString());
////                    LOG.info(("Set queued printed SUCCESS : transRef - ").concat(transRef));
//                    countSetPrinted++;
//                    if (countSetPrinted < printQueueSize) {
//                        setTransactionPrintedQueued(countSetPrinted, PrintUtil.currentPrintQueueSize, queueResult);
//                    } else {
//                        isFromQueue = false;
//                        PrintQueue.clearQueue();
//                        queueResult.onDone(true);
//                    }
//                } else {
//                    queueResult.onDone(false);
//                    // LOG ErrorCode and ErrorText
//                    LOG.info(("Set queued printed FAILED : transRef - ").concat(transRef));
//                    LOG.info(("Print Error - ErrorCode : ").concat(Integer.toString(result.getErrorCode())).concat(" - ErrorText : ").concat(result.getErrorText()));
//                }
//            }
//        });
//    }

    // start of unsubmitted set printed
    public static void processSetPrintedItems() {
        countSetItemPrinted = 0;
        // makes a NEW list every time we process items in the set printed queue
        listSetPrinted = new ArrayList<>();
        if (JKSetPrintedQueue.hasItems()) {
//            LOG.info(("Number of items in set printed list = ").concat(Integer.toString(JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs().size())));
            // We make a NEW Store so that items not set printed can be added to it for resubmit.
            jkSetPrintedQueue = new StoreJKSetPrintedQueue();
            // Don't touch the JKSetPrintedQueue - make a copy of the items in it.
            for (final String s : JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs()) {
                listSetPrinted.add(s);
            }
        }
        submitUnprocessedSetPrinted(countSetItemPrinted, listSetPrinted, new ResultCallback() {
            @Override
            public void onResult(boolean result) {
                updateOrClearUnsubmittedSetPrinted();
            }
        });
    }

    private static void submitUnprocessedSetPrinted(int count, List<String> listSetPrinted, ResultCallback finalRes) {
        String currentTransRef = listSetPrinted.get(count);
        String selectedTransRef = null;
        for (String s : JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs()) {
            if (s.equalsIgnoreCase(currentTransRef)) {
                selectedTransRef = s;
                break;
            }
        }
        submitSetPrinted(listSetPrinted, selectedTransRef, finalRes);
    }

    private static void submitSetPrinted(final List<String> listSetPrinted, final String transRef, final ResultCallback finalRes) {

        UserUtil.setTransactionPrinted(transRef, new UserUtil.SetPrintedResponseResult() {
            @Override
            public void setPrintedResponseResult(SetPrintedResponse result) {
                if (result != null) {
                    if (result.isSuccess()) {
                        LOG.info(("Set Printed item was submitted successfully - ").concat(transRef));
                        // Nothing to do  -  business as usual.
                    } else {
                        LOG.info(("Set Printed item was NOT submitted successfully - ").concat(transRef));
                        jkSetPrintedQueue.getListTransRefs().add(transRef);
                    }
                } else {
                    LOG.info(("Set Printed item result was null - ").concat(transRef));
                    jkSetPrintedQueue.getListTransRefs().add(transRef);
                }
                //
                countSetItemPrinted++;
                // continue submitting through list, or move on to next list
                if ((countSetItemPrinted) < JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs().size()) {
                    submitUnprocessedSetPrinted((countSetItemPrinted), listSetPrinted, finalRes);
                } else {
                    finalRes.onResult(true);
                }
            }
        });
    }

    private static void updateOrClearUnsubmittedSetPrinted() {
        if (!jkSetPrintedQueue.getListTransRefs().isEmpty()) {
            JKSetPrintedQueue.clearSetPrintedQueue();
            for (String s : jkSetPrintedQueue.getListTransRefs()) {
                JKSetPrintedQueue.saveSetPrintedItem(s);
            }
            LOG.info(("Size of outstanding set printed list : ").concat(Integer.toString(jkSetPrintedQueue.getListTransRefs().size())));
            countSetPrintedSubmit++;
            if (countSetPrintedSubmit <= 1) {        // Submits twice (0 and 1)  -  increase this ONLY IF Business requires it
                processSetPrintedItems();
            } else {
                JKiosk3.returnToLogin("Some items not set printed",
                        "\nYou will be returned to the login screen.\n\nPlease check your connection before continuing.");
            }
//            processSetPrintedItems();
        } else {
            for (String s : JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs()) {
                System.out.println("ITEM IN JKSetPrintedQueue : " + s);
            }
            JKSetPrintedQueue.clearSetPrintedQueue();
            LOG.info("Outstanding Set Printed Queue is empty");
        }
        StringBuilder sb = new StringBuilder("\r\n");
        sb.append("   *   *   *   *   *   transaction complete   *   *   *   *   * ");
        LOG.info(sb.toString());
    }
    // end of unsubmitt ed set printed

    public static boolean isPinFormat(String text) {
        if (text != null && !text.isEmpty()) {
            if (text.length() <= 4) {
                return text.matches("^[0-9]*$");
            } else {
                return text.matches("^(\\d{4}[ ]{1,}\\d{1}).*$");
            }
        }
        return false;
    }
}
