package jkiosk3.setup;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKOptions;
import jkiosk3.store.JKSystem;

import java.util.UUID;

/**
 *
 * @author Val
 */
public class SetupRicaConfig extends Region {

    private TextField txtServer;
    private TextField txtPort;
    private TextField txtServerNonSSL;
    private TextField txtPortNonSSL;
    private static boolean deviceChanged = false;

    public SetupRicaConfig() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getConfigEntry());
        getChildren().add(vb);
    }

    private GridPane getConfigEntry() {
        GridPane grid = JKLayout.getGridContent2Col(0.3, 0.65, HPos.LEFT);

        // VBox vbHead = JKNode.getPageHeadVB("Secure Config");

        Label header = JKText.getLblDk("Rica Config", JKText.FONT_B_XSM);
        Label lblServer = JKText.getLblDk("SSL Server", JKText.FONT_B_XSM);
        header.setMinWidth(JKLayout.btnLgW);
        lblServer.setMinWidth(JKLayout.btnLgW);
        Label lblPort = JKText.getLblDk("SSL Port", JKText.FONT_B_XSM);

        // VBox vbHeadNonSSL = JKNode.getPageHeadVB("Non-Secure Config");

        Label lblServerNonSSL = JKText.getLblDk("Non-SSL Server", JKText.FONT_B_XSM);
        lblServerNonSSL.setMinWidth(JKLayout.btnLgW);
        Label lblPortNonSSL = JKText.getLblDk("Non-SSL Port", JKText.FONT_B_XSM);

        txtServer = new TextField();
        txtServer.setText(JK3Config.getSSLRicaServer());
        txtServer.setDisable(true);

        txtServerNonSSL = new TextField();
        txtServerNonSSL.setText(JK3Config.getNonSSLRicaServer());
        txtServerNonSSL.setDisable(true);

/*        txtServer.setOnMouseReleased(   new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions().isKeyboard())) {
                    JKiosk3.getKeyboard().showKeyboard(txtServer, "Server IP Address", txtServer.getText(), false);
                }
            }
        });*/

        txtPort = new TextField();
        txtPort.setText(JK3Config.getSSLRicaPort());
        txtPort.setDisable(true);

        txtPortNonSSL = new TextField();
        txtPortNonSSL.setText(JK3Config.getNonSSLRicaPort());
        txtPortNonSSL.setDisable(true);

        grid.addRow(1, header);
        grid.addRow(2, lblServer, txtServer);
        grid.addRow(3, lblPort, txtPort);
        grid.add(JKNode.createGridSpanSep(2), 0, 4);
        grid.addRow(5, lblServerNonSSL, txtServerNonSSL);
        grid.addRow(6, lblPortNonSSL, txtPortNonSSL);

        return grid;
    }

    public static String getSerial() {
        String serial = JKSystem.getSystemConfig().getSerial();
        if (serial.equals("")) {
            serial = createSerial();
        }
        return serial;
    }

    public static String createSerial() {
        return UUID.randomUUID().toString();
    }

    public static boolean isDeviceChanged() {
        return deviceChanged;
    }
}
