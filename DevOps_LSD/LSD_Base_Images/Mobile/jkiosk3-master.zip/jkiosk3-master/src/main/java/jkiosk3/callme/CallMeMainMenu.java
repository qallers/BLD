package jkiosk3.callme;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.TextAlignment;
import javafx.scene.web.WebView;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3.StageJKiosk;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class CallMeMainMenu extends Region {

    private final double pageW = StageJKiosk.getSceneWidth();
    private StackPane paneContent;
    private StackPane stack;
    private WebView htmlContent;
    private String restResp;
    private String description = "";

    public CallMeMainMenu() {
        getChildren().add(getCallMePageStack());
    }

    private StackPane getCallMePageStack() {
        stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getCallMePageGrp());

        return stack;
    }

    private VBox getCallMePageGrp() {

        DownloadCategoryService pleaseCallMeUtil = new DownloadCategoryService();
        restResp = pleaseCallMeUtil.postData();

        VBox vbHead = JKNode.getPageCallMeHeadVB("Please Call Me");

        VBox vbox = JKLayout.getVBoxContent(JKLayout.spNum);
        vbox.setStyle("-fx-padding: 15px;");
        vbox.setPrefWidth(pageW - (2 * JKLayout.spNum));

        Button btnCancel = JKNode.getBtnMsgBox("Cancel");
        btnCancel.setMaxHeight(JKLayout.btnToggleH);
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.changeScene(new JKioskLogin());
            }
        });

        Image imgC = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/callme.png"));
        ImageView imgCallMe = new ImageView(imgC);
        imgCallMe.setFitHeight(50);
        imgCallMe.setPreserveRatio(true);

        final Button btnCallMe = JKNode.getBtnNum("");
        btnCallMe.setGraphic(imgCallMe);
        btnCallMe.getStyleClass().add("prov_mtn_fix");
        btnCallMe.setMaxHeight(100);

        HBox hbCallMe = JKLayout.getHBoxLeft(0, 0);
        hbCallMe.getStyleClass().add("prov_mtn_fix");
        hbCallMe.setMaxWidth(0.2);

        HBox hbCallMeText = JKLayout.getHBoxLeft(0, 0);
        hbCallMeText.setMaxWidth(0.2);

        HBox hbCallMeMessage = JKLayout.getHBoxLeft(0, 0);
        hbCallMeMessage.setAlignment(Pos.CENTER);
        hbCallMeMessage.setMaxWidth(0.2);

        HBox hbDesc = JKLayout.getHBoxLeft(0, 0);
        hbDesc.setAlignment(Pos.CENTER);

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, parseCategories(restResp));
        tile.setAlignment(Pos.CENTER);

        hbCallMeText.getChildren().add(new SloganPane().sloganGrid());

        hbCallMe.getChildren().add(btnCallMe);

        hbCallMeMessage.getChildren().add(new MessagePane().messageGrid());

        hbDesc.getChildren().add(descriptionPane(description));

        vbox.getChildren().addAll(vbHead, hbCallMeText, hbCallMe, hbCallMeMessage, JKNode.createContentSep(), tile, hbDesc/*, getContentPane()*//*, new Separator()*/, JKNode.createContentSep(), btnCancel);

        return vbox;
    }

    private StackPane getContentPane() {
        double h = StageJKiosk.getSceneHeight() - (6 * JKLayout.sp);

        paneContent = new StackPane();
        paneContent.setPrefWidth(pageW - (2 * JKLayout.spNum));

        htmlContent = new WebView();
        htmlContent.setPrefSize((pageW - (2 * JKLayout.spNum)), h);

        paneContent.getChildren().add(htmlContent);

        return paneContent;
    }

    private void onOkBtnEvent() {
        setVisible(false);
        toBack();
    }

    private GridPane descriptionPane(String message){
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);

        double gridW = 590;

        grid.setMaxWidth(gridW);
        grid.setMinWidth(gridW - 100);

        Label lblMessage1 = JKText.getLblDk(message, JKText.FONT_B_15);
        lblMessage1.setTextAlignment(TextAlignment.CENTER);

        grid.add(lblMessage1, 0, 0);

        return grid;
    }

    public List<Button> parseCategories(String output){

        List<Button> buttons = new ArrayList<>();

        JSONObject myResponse = new JSONObject (output);

        for(Object array: myResponse.getJSONArray ("menu")){

            JSONObject myResponse2 = new JSONObject (array.toString());
            final String id = myResponse2.get("id").toString();
            final String desc = myResponse2.get("desc").toString();

            final Button btn = JKNode.getBtnSmDbl("");

            btn.setText(id);
            btn.setGraphicTextGap(JKLayout.sp / 4);
            btn.getStyleClass().add("prov_VASSmTxt");
            btn.setStyle(JKNode.getBrandButton());
            btn.setFont(JKText.FONT_B_XXSM);
            btn.setAlignment(Pos.CENTER);
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event arg0) {
                    JKiosk3.changeScene(new CaptureNumberMenu(id, desc));
                }
            });
            buttons.add(btn);
        }

        return buttons;
    }
}
