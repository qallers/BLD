package jkiosk3.sales.rmcs;

import aeonmoneytransfer.MoneyTransferResponse;
import aeonprinting.AeonPrintJob;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.print_layouts.PrintAssorted;
import jkiosk3.sales.MerchantCopy;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._tender.TenderAmounts;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.UserUtil;

/**
 * @author val
 */
public class RmcsCashDeposit extends Region {

    private final static Logger logger = Logger.getLogger (RmcsCashDeposit.class.getName ());
    private String depositorMobileNum;
    private String depositorIDNum;
    private String recipientMobileNum;
    private double depositAmt;
    private double depositTotal;
    private CheckBox chkDepIDConfirm;
    private Label lblDepFee;
    private Label lblDepTotal;
    private TextField txtDepAmount;
    private TextField txtDepFee;
    private TextField txtDepTotal;
    private GridPane gridDeposit;
    private ControlButtons ctrlBtns;

    public RmcsCashDeposit() {
        VBox vbDeposit = JKLayout.getVBox (0, JKLayout.spNum);
        vbDeposit.getChildren ().add (getDepositEntry ());
        vbDeposit.getChildren ().add (getControlButtons ());
        getChildren ().add (vbDeposit);
    }

    private GridPane getDepositEntry() {
        double inset = 2 * JKLayout.sp;
        Label lblDepositMoney = JKText.getLblContentHead ("Money Transfer - " + RmcsUtil.MONEY_TRF_DEPOSIT);

        Label lblDepositor = JKText.getLblContentSubHead ("Depositor Details: ");
        Label lblRecipient = JKText.getLblContentSubHead ("Recipient Details: ");
        Label lblDeposit = JKText.getLblContentSubHead ("Deposit Details: ");

        // Depositor components
        Label lblDepMobileNum = JKText.getLblDk ("Mobile Number", JKText.FONT_B_XSM);
        lblDepMobileNum.setTranslateX (inset);
        Label lblDepIDNum = JKText.getLblDk ("ID Number", JKText.FONT_B_XSM);
        lblDepIDNum.setTranslateX (inset);
        Label lblDepIDConfirm = JKText.getLblDk ("ID Book present and ID Number confirmed", JKText.FONT_B_XSM);
        lblDepIDConfirm.setTranslateX (inset);
        final TextField txtDepMobileNum = new TextField ();
        txtDepMobileNum.getStyleClass ().add ("txtfld-right");
        txtDepMobileNum.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad ().showNumPad (txtDepMobileNum, "Mobile Number", "",
                        new NumberPadResult () {
                            @Override
                            public void onDone(String value) {
                                if (validateMobileNum (value)) {
                                    depositorMobileNum = value;
                                    txtDepMobileNum.setText (JKText.getCellNumFormatted (depositorMobileNum));
                                } else {
                                    txtDepMobileNum.clear ();
                                }
                            }
                        });
            }
        });

        final TextField txtDepIDNum = new TextField ();
        txtDepIDNum.getStyleClass ().add ("txtfld-right");
        txtDepIDNum.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad ().showNumPad (txtDepIDNum, "ID Number", "",
                        new NumberPadResult () {
                            @Override
                            public void onDone(String value) {
                                if (validateIDNum (value)) {
                                    depositorIDNum = value;
                                    txtDepIDNum.setText (JKText.getSAIDNumFormatted (depositorIDNum));
                                } else {
                                    txtDepIDNum.clear ();
                                }
                            }
                        });
            }
        });

        chkDepIDConfirm = new CheckBox ();
        chkDepIDConfirm.setSelected (false);

        HBox hbIDConf = JKLayout.getHBox (0, 0);
        hbIDConf.getChildren ().addAll (lblDepIDConfirm, JKNode.getHSpacer (), chkDepIDConfirm);

        // Recipient components
        Label lblRecMobileNum = JKText.getLblDk ("Mobile Number", JKText.FONT_B_XSM);
        lblRecMobileNum.setTranslateX (inset);

        final TextField txtRecMobileNum = new TextField ();
        txtRecMobileNum.getStyleClass ().add ("txtfld-right");
        txtRecMobileNum.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad ().showNumPad (txtRecMobileNum, "Mobile Number", "",
                        new NumberPadResult () {
                            @Override
                            public void onDone(String value) {
                                if (validateMobileNum (value)) {
                                    recipientMobileNum = value;
                                    txtRecMobileNum.setText (JKText.getCellNumFormatted (recipientMobileNum));
                                } else {
                                    txtRecMobileNum.clear ();
                                }
                            }
                        });
            }
        });
        // Deposit components
        Label lblDepAmount = JKText.getLblDk ("Amount", JKText.FONT_B_XSM);
        lblDepAmount.setTranslateX (inset);
        lblDepFee = JKText.getLblDk ("Fee", JKText.FONT_B_XSM);
        lblDepFee.setTranslateX (inset);
        lblDepFee.setDisable (true);
        lblDepTotal = JKText.getLblDk ("Total", JKText.FONT_B_XSM);
        lblDepTotal.setTranslateX (inset);
        lblDepTotal.setDisable (true);

        txtDepAmount = new TextField ();
        txtDepAmount.getStyleClass ().addAll ("txtfld-numeric", "txtfld-right");
        txtDepAmount.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad ().showNumPad (txtDepAmount, "Deposit Amount", "",
                        new NumberPadResult () {
                            @Override
                            public void onDone(String value) {
                                if (validateDepositAmt (value)) {
                                    txtDepAmount.setText (JKText.getDeciFormat (depositAmt));
                                } else {
                                    txtDepAmount.clear ();
                                }
                            }
                        });
            }
        });
        txtDepFee = new TextField ();
        txtDepFee.setDisable (true);
        txtDepFee.getStyleClass ().addAll ("txtfld-numeric", "txtfld-right");

        txtDepTotal = new TextField ();
        txtDepTotal.setDisable (true);
        txtDepTotal.getStyleClass ().addAll ("txtfld-numeric", "txtfld-right");

        gridDeposit = JKLayout.getGridContent2Col (0.5, 0.5);

        gridDeposit.add (lblDepositMoney, 0, 0, 2, 1);
        gridDeposit.add (JKNode.createGridSpanSep (2), 0, 1);

        gridDeposit.addRow (2, lblDepositor);
        gridDeposit.addRow (3, lblDepMobileNum, txtDepMobileNum);
        gridDeposit.addRow (4, lblDepIDNum, txtDepIDNum);
        gridDeposit.add (hbIDConf, 0, 5, 2, 1);
        gridDeposit.addRow (7, lblRecipient);
        gridDeposit.addRow (8, lblRecMobileNum, txtRecMobileNum);
        gridDeposit.addRow (10, lblDeposit);
        gridDeposit.addRow (11, lblDepAmount, txtDepAmount);

        return gridDeposit;
    }

    private ControlButtons getControlButtons() {
        ctrlBtns = new ControlButtons ();

        ctrlBtns.getBtnAccept ().setText ("Authorise");
        ctrlBtns.getBtnAccept ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                if (validateContinue ()) {
                    processRmcsPreAuth ();
                }
            }
        });
        ctrlBtns.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                onClickCancel ();
            }
        });

        return ctrlBtns;
    }

    private void onClickCancel() {
        switch (ctrlBtns.getBtnCancel ().getText ()) {
            case "Cancel":
                SceneSales.clearAndChangeContent (new MoneyTransferMenu ());
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                break;
            case "Decline":
                processRmcsDecline ();
                SceneSales.clearAndChangeContent (new MoneyTransferMenu ());
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                break;
            default:
                JKiosk3.getMsgBox ().showMsgBox ("Invalid Input", "Nothing selected", null);
                break;
        }
    }

    private void processRmcsPreAuth() {
        String ref = SalesUtil.getUniqueRef ();

        RmcsDeposit.getInstance ().getPreAuthReq ().setReference (ref);
        RmcsDeposit.getInstance ().getPreAuthReq ().setDepoMSISDN (depositorMobileNum);
        RmcsDeposit.getInstance ().getPreAuthReq ().setDepoID (depositorIDNum);
        RmcsDeposit.getInstance ().getPreAuthReq ().setRecipMSISDN (recipientMobileNum);
        RmcsDeposit.getInstance ().getPreAuthReq ().setAmount ((int) depositAmt);

        RmcsUtil.getMoneyTrfPreAuthResp (RmcsDeposit.getInstance ().getPreAuthReq (), new RmcsUtil.MoneyTransferPreAuthResponseResult () {
            @Override
            public void moneyTrfPreAuthRespResult(final MoneyTransferResponse moneyTrfPreAuthResp) {
                if (moneyTrfPreAuthResp.isSuccess ()) {
                    RmcsDeposit.getInstance ().setPreAuthResp (moneyTrfPreAuthResp);

                    RmcsCashDepositConfirm confirm = new RmcsCashDepositConfirm ();
                    String confirmMsg = "Please Ensure Details Are Correct\n"
                            + "and that you have received payment for the transaction\n "
                            + "before continuing\n"
                            + "Transaction cannot be CANCELLED once you press 'OK'";

                    JKiosk3.getMsgBox ().showMsgBox ("Pre-Authorisation Success", confirmMsg, confirm,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    processRmcsDeposit ();
                                }

                                @Override
                                public void onCancel() {
                                    processRmcsDecline ();
                                    SceneSales.clearAndChangeContent (new MoneyTransferMenu ());
                                    UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Authorisation Error", !moneyTrfPreAuthResp.getAeonErrorText ().isEmpty () ?
                                    "A" + moneyTrfPreAuthResp.getAeonErrorCode () + " - " + moneyTrfPreAuthResp.getAeonErrorText () :
                                    "B" + moneyTrfPreAuthResp.getErrorCode () + " - " + moneyTrfPreAuthResp.getErrorText ()
                                            + "\n\nPlease confirm that all details are correct.", null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL,
                            new MessageBoxResult () {

                                @Override
                                public void onOk() {
//                                    txtDepAmount.setDisable(false);
//                                    ctrlBtns.getBtnAccept().setDisable(true);
//                                    ctrlBtns.getBtnCancel().setText("Cancel");
                                }

                                @Override
                                public void onCancel() {
                                    UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                                    SceneSales.clearAndChangeContent (new MoneyTransferMenu ());
                                }

                            });
                }
            }
        });
    }

    private void processRmcsDeposit() {

        RmcsDeposit.getInstance ().getDepositReq ().setReference (RmcsDeposit.getInstance ().getPreAuthReq ().getReference ());
        RmcsDeposit.getInstance ().getDepositReq ().setDepoMSISDN (depositorMobileNum);
        RmcsDeposit.getInstance ().getDepositReq ().setDepoID (depositorIDNum);
        RmcsDeposit.getInstance ().getDepositReq ().setRecipMSISDN (recipientMobileNum);
        RmcsDeposit.getInstance ().getDepositReq ().setAmount ((int) depositAmt);

        RmcsUtil.getMoneyTrfDepositResp (RmcsDeposit.getInstance ().getDepositReq (), new RmcsUtil.MoneyTransferDepositResponseResult () {

            @Override
            public void moneyTrfDepRespResult(final MoneyTransferResponse moneyTrfDepResp) {
                if (moneyTrfDepResp.isSuccess ()) {
                    depositTotal = depositAmt + RmcsDeposit.getInstance ().getPreAuthResp ().getConvFees ();

                    RmcsDeposit.getInstance ().setDepositResp (moneyTrfDepResp);
                    RmcsDeposit.getInstance ().setAmtTotal (depositTotal);
                    RmcsDeposit.getInstance ().setDate (new Date ());

                    JKiosk3.getMsgBox ().showMsgBox (RmcsUtil.MONEY_TRF_DEPOSIT + " Successful", "", new RmcsCashDepositSummary (), MessageBox.CONTROLS_SHOW,
                            MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    String transRef = RmcsDeposit.getInstance ().getDepositResp ().getTrxId ();
                                    // Money Transfer is ALWAYS a CASH-ONLY transaction!
                                    TenderAmounts.addTenderAmount (TenderAmounts.TENDER_CASH, depositTotal);

                                    AeonPrintJob apj = moneyTrfDepResp.getPrintLines ();

                                    if (JKPrintOptions.getPrintOptions ().isPrintMerchantCopy ()) {
                                        MerchantCopy.getInstance ().setTransType (SaleType.MONEY_TRANSFER.getDisplay ());
                                        MerchantCopy.getInstance ().setDetails (RmcsDeposit.getInstance ().getDepositResp ().getShiftId (),
                                                RmcsDeposit.getInstance ().getDepositResp ().getTransSeq (),
                                                SaleType.MONEY_TRANSFER_DEPOSIT.getDisplay (), depositTotal, null, 0,
                                                transRef, RmcsDeposit.getInstance ().getDate (), CurrentUser.getSalesUser ().getUserName ());

                                        AeonPrintJob apjMC = PrintAssorted.getMerchantCopyPrint (MerchantCopy.getInstance ());
                                        apj.setMerchantCopy (apjMC);
                                    }

                                    SalesUtil.processSoldItem (transRef,
                                            SaleType.MONEY_TRANSFER.getDisplay (),
                                            SaleType.MONEY_TRANSFER_DEPOSIT.getDisplay () + " - R " + depositAmt,
                                            apj, depositTotal, false, "online",
                                            moneyTrfDepResp.getVoucherNum (), RmcsDeposit.getInstance ().getDate (), "", null);

                                    PrintHandler.handlePrintRequestSale (SaleType.MONEY_TRANSFER_DEPOSIT.getDisplay (),
                                            apj, transRef);
                                    SceneSales.clearAndChangeContent (new MoneyTransferMenu ());
                                }

                                @Override
                                public void onCancel() {
                                    //                                    
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Deposit Error", !moneyTrfDepResp.getAeonErrorText ().isEmpty () ?
                            "A" + moneyTrfDepResp.getAeonErrorCode () + " - " + moneyTrfDepResp.getAeonErrorText () :
                            "B" + moneyTrfDepResp.getErrorCode () + " - " + moneyTrfDepResp.getErrorText (), null);
                }
            }
        });
    }

    private void processRmcsDecline() {
        RmcsUtil.getMoneyTrfDepositDecline (true, new RmcsUtil.MoneyTransferDepositDeclineResult () {
            @Override
            public void moneyTrfDepDeclineResult(MoneyTransferResponse moneyTrfDepDeclineResult) {
                if (moneyTrfDepDeclineResult.isSuccess ()) {
                    RmcsDeposit.getInstance ().setDeclineResp (moneyTrfDepDeclineResult);
                    JKiosk3.getMsgBox ().showMsgBox ("Money Transfer Deposit", "Money Transfer Deposit Declined by Customer", null);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Money Transfer Deposit", !moneyTrfDepDeclineResult.getAeonErrorText ().isEmpty () ?
                            "A" + moneyTrfDepDeclineResult.getAeonErrorCode () + " - " + moneyTrfDepDeclineResult.getAeonErrorText () :
                            "B" + moneyTrfDepDeclineResult.getErrorCode () + "  -  " + moneyTrfDepDeclineResult.getErrorText (), null);
                }
            }
        });
    }

    private boolean validateMobileNum(String mobileNum) {
        if (!mobileNum.matches ("(^0[678][01234689]((\\d{7})|( |-)((\\d{3}))( |-)(\\d{4})|( |-)(\\d{7})))")) {
            JKiosk3.getMsgBox ().showMsgBox ("Mobile Number", "Please enter a valid Mobile Number", null);
            return false;
        }
        return true;
    }

    private boolean validateIDNum(String idNum) {
        if (!idNum.matches ("(\\d{13})")) {
            JKiosk3.getMsgBox ().showMsgBox ("ID Number", "Please enter a valid ID Number", null);
            return false;
        }
        return true;
    }

    private boolean validateDepositAmt(String amt) {
        try {
            depositAmt = Double.parseDouble (amt);
            double depCents = depositAmt * 100;
            if ((depCents % 100) > 0) {
                JKiosk3.getMsgBox ().showMsgBox ("Deposit Amount", "Deposit must be in Rand only, no Cents", null);
                return false;
            }
        } catch (NumberFormatException nfe) {
            logger.log (Level.SEVERE, nfe.getMessage (), nfe);
            JKiosk3.getMsgBox ().showMsgBox ("Deposit Amount", "Please enter a valid Deposit Amount", null);
            return false;
        }
        return true;
    }

    private boolean validateContinue() {
        if (depositorMobileNum == null || depositorIDNum == null || recipientMobileNum == null || depositAmt == 0d) {
            JKiosk3.getMsgBox ().showMsgBox ("Incomplete Details", "Please provide all details.", null);
            return false;
        }
        if (!chkDepIDConfirm.isSelected ()) {
            JKiosk3.getMsgBox ().showMsgBox ("Depositor ID", "Please verify the Depositor ID before continuing.", null);
            RmcsDeposit.getInstance ().setIdConfirmed (false);
            return false;
        } else {
            RmcsDeposit.getInstance ().setIdConfirmed (true);
        }
        return true;
    }
}
