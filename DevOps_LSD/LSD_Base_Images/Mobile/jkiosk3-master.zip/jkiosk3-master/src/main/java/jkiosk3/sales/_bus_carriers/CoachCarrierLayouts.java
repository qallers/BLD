package jkiosk3.sales._bus_carriers;

import Download.HttpUtils;
import aeoncoach.CoachCarrier;
import aeoncoach.CoachListItem;
import aeoncoach.CoachRoute;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JK3Config;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.StageComponents;
import jkiosk3.sales.coaches.CoachTicketSale;
import jkiosk3.store.cache.CacheListCoachCarriers;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CoachCarrierLayouts {

    private final static Logger logger = Logger.getLogger(CoachCarrierLayouts.class.getName());

    public final static double gridW = (JKLayout.contentW - (2 * JKLayout.sp));
    public final static double gridCoach = (JKLayout.contentW - (5 * JKLayout.sp));
    public final static double gridCarrierHt = 100.0D;
    public final static double COACH_PG_HT = 610.0D;
    public final static double pageHt = 440.0D;
    public final static int pageSize = 3;
    public final static SimpleDateFormat SDF = new SimpleDateFormat("dd MMM yyyy");
    public final static SimpleDateFormat STF = new SimpleDateFormat("HH:mm");

    public static ComboBox<Integer> getComboBoxList(ObservableList<Integer> listseats) {
        ComboBox<Integer> cblist = new ComboBox<>(listseats);
        cblist.getSelectionModel().selectFirst();
        cblist.setMaxSize(JKLayout.btnSmW, 32);
        cblist.setMinSize(JKLayout.btnSmW, 32);
        cblist.setVisibleRowCount(11);
        cblist.getStyleClass().add("coach-combo coach-combo-bold");
        GridPane.setHalignment(cblist, HPos.LEFT);
        cblist.setTranslateX(JKLayout.spNum);
        return cblist;
    }

    public static GridPane getGridTripsRequested(CoachListItem from, CoachListItem to, Date dateFrom, Date dateTo) {
        double gridW = (JKLayout.contentW - (2 * JKLayout.sp));

        GridPane grid = JKLayout.getGridPane4Col(gridW, 0.11, 0.50, 0.14, 0.25, 2, HPos.LEFT);
        grid.setHgap(0);

        Label lblDepart = JKText.getLblDk("From:", JKText.FONT_B_18);
        Label lblDepartDate = JKText.getLblDk("Depart:", JKText.FONT_B_18);
        Label lblDest = JKText.getLblDk("To:", JKText.FONT_B_18);
        Label lblReturnDate = JKText.getLblDk("Return:", JKText.FONT_B_18);

        String strFrom = from.getName();
        String strTo = to.getName();
        int strlen = 18;
        if (strFrom.length() > strlen) {
            strFrom = strFrom.substring(0, strlen);
        }
        if (strTo.length() > strlen) {
            strTo = strTo.substring(0, strlen);
        }
        Text txtDepart = JKText.getTxtDk(strFrom, JKText.FONT_B_20);
        Text txtDepartDate = JKText.getTxtDk(SDF.format(dateFrom), JKText.FONT_B_20);
        Text txtDest = JKText.getTxtDk(strTo, JKText.FONT_B_20);

        grid.addRow(0, lblDepart, txtDepart, lblDepartDate, txtDepartDate);
        if (dateTo != null) {
            Text txtReturnDate = JKText.getTxtDk(SDF.format(dateTo), JKText.FONT_B_20);
            grid.addRow(1, lblDest, txtDest, lblReturnDate, txtReturnDate);
        } else {
            grid.addRow(1, lblDest, txtDest);
        }

        return grid;
    }

    public static GridPane getGridTicketCosts() {
        double gridW2 = (gridW * 0.22);

        GridPane grid = new GridPane();
        grid.setMaxSize(gridW2, (gridCarrierHt - (2 * JKLayout.spNum)));
        grid.setMinSize(gridW2, (gridCarrierHt - (2 * JKLayout.spNum)));
        grid.setHgap(JKLayout.spNum);
        grid.setVgap(JKLayout.spNum);
        grid.setTranslateY(2 * JKLayout.spNum);

        ColumnConstraints col0 = new ColumnConstraints(gridW2 * 0.48);
        ColumnConstraints col1 = new ColumnConstraints(gridW2 * 0.52);
        col1.setHalignment(HPos.RIGHT);

        grid.getColumnConstraints().addAll(col0, col1);

        return grid;
    }

    public static GridPane getGridCoachCarrierTrip() {
        final GridPane grid = JKLayout.getGridPane4Col(gridW, 0.26, 0.36, 0.22, 0.16, 2, HPos.RIGHT);
        grid.setHgap(0);
        grid.getStyleClass().add("gridCoach");
        grid.setMaxHeight(gridCarrierHt);
        grid.setMinHeight(gridCarrierHt);

        RowConstraints row0 = new RowConstraints();
        row0.setValignment(VPos.TOP);

        grid.getRowConstraints().add(row0);
        return grid;
    }

    public static GridPane getGridTripsSelected() {
        CoachRoute routeDepart = CoachTicketSale.getInstance().getRouteDepart();
        CoachRoute routeReturn = CoachTicketSale.getInstance().getRouteReturn();

        double gridW = (JKLayout.contentW - (5 * JKLayout.sp));

        GridPane grid = JKLayout.getGridPane4Col(gridW, 0.22, 0.28, 0.22, 0.28, 2, HPos.LEFT);

        StackPane stackDepart = getStackCoachCarrierImage(CoachTicketSale.getInstance().getCoachCarrierDepart(),
                JKLayout.btnSmW - JKLayout.spNum, JKLayout.btnSmH - JKLayout.sp);

        Label lblDepart = JKText.getLblDk("Departure", JKText.FONT_B_22);
        Label lblReturn = JKText.getLblDk("Return", JKText.FONT_B_22);

        String strDepart = CoachTicketSale.getInstance().getDepartureLoc().getName();
        String strDest = CoachTicketSale.getInstance().getDestinationLoc().getName();
        String ellips = "...";
        int strlen = 15;

        if (strDepart.length() > strlen) {
            strDepart = strDepart.substring(0, strlen) + ellips;
        }
        if (strDest.length() > strlen) {
            strDest = strDest.substring(0, strlen) + ellips;
        }

//        Text txtDepart = JKText.getTxtDk(CoachTicketSale.getInstance().getDepartureLoc().getName(), JKText.FONT_B_18);
//        Text txtReturn = JKText.getTxtDk(CoachTicketSale.getInstance().getDestinationLoc().getName(), JKText.FONT_B_18);
        Text txtDepart = JKText.getTxtDk(strDepart, JKText.FONT_B_15);
        Text txtReturn = JKText.getTxtDk(strDest, JKText.FONT_B_15);

        Text txtDepartDate = JKText.getTxtMainLight(SDF.format(routeDepart.getBoardingTime()), JKText.FONT_B_15);
        Text txtDepartTime = JKText.getTxtMainLight(STF.format(routeDepart.getBoardingTime()), JKText.FONT_B_18);

        if (routeReturn != null) {
            StackPane stackReturn = getStackCoachCarrierImage(CoachTicketSale.getInstance().getCoachCarrierReturn(),
                    JKLayout.btnSmW - JKLayout.spNum, JKLayout.btnSmH - JKLayout.sp);

            Text txtReturnDate = JKText.getTxtMainLight(SDF.format(routeReturn.getBoardingTime()), JKText.FONT_B_15);
            Text txtReturnTime = JKText.getTxtMainLight(STF.format(routeReturn.getBoardingTime()), JKText.FONT_B_18);

            grid.addRow(0, lblDepart, txtDepart, lblReturn, txtReturn);
            grid.add(stackDepart, 0, 1, 1, 2);
            grid.add(stackReturn, 2, 1, 1, 2);
            grid.add(txtDepartDate, 1, 1);
            grid.add(txtReturnDate, 3, 1);
            grid.add(txtDepartTime, 1, 2);
            grid.add(txtReturnTime, 3, 2);
        } else {
            grid.addRow(0, lblDepart, txtDepart);
            grid.add(stackDepart, 0, 1, 1, 2);
            grid.add(txtDepartDate, 1, 1);
            grid.add(txtDepartTime, 1, 2);
        }
        grid.addRow(3, JKText.getLblDk(" ", JKText.FONT_B_12));
        grid.addRow(4, JKNode.createGridSpanSep(4));

        return grid;
    }

    public static HBox getHBoxCoachBook1(Node node1, Node node2) {
        HBox hbBook1 = JKLayout.getHBox(0, JKLayout.sp);
        hbBook1.getChildren().addAll(node1, node2);
        return hbBook1;
    }

    public static StackPane getStackCoachCarrierImage(CoachCarrier coachCarrier, double width, double height) {
        Image img = null;
        StackPane stackImg = new StackPane();
        try {

            String imgUrl = getCarrierLogoPath(coachCarrier, false);

            stackImg.getStyleClass().add("stackCoachCarrierImg");
            stackImg.setMaxSize(width, height);
            stackImg.setMinSize(width, height);
            GridPane.setValignment(stackImg, VPos.CENTER);

            if (imgUrl != null) {
                // Set background loading to false, to load all images before drawing screen, otherwise labels are shown instead.
                img = new Image(imgUrl, false);

                // If image height is greater than 0, then we know that the image loaded, otherwise show text label.
                if (img.heightProperty().doubleValue() > 0) {
                    ImageView imgView = new ImageView(img);
                    imgView.setFitWidth(width - (2 * JKLayout.spNum));
                    imgView.setPreserveRatio(true);
                    stackImg.getChildren().add(imgView);
                } else {
                    stackImg = getStackCoachCarrierLabel(coachCarrier, width, height);
                }
            } else {
                stackImg = getStackCoachCarrierLabel(coachCarrier, width, height);
            }
        } catch (IllegalArgumentException iae) {
            stackImg = getStackCoachCarrierLabel(coachCarrier, width, height);
            logger.log(Level.SEVERE, iae.getMessage(), iae);
        }

        return stackImg;
    }

    private static StackPane getStackCoachCarrierLabel(CoachCarrier coachCarrier, double width, double height) {
        StackPane stackImg = new StackPane();
        stackImg.setMaxSize(width, height);
        stackImg.setMinSize(width, height);
        GridPane.setValignment(stackImg, VPos.CENTER);
        Label lbl = JKText.getLblDk(coachCarrier.getCarrierDescription(), JKText.FONT_B_18);
        lbl.setMaxWidth(width);
        lbl.setMinWidth(width);
        lbl.setTextAlignment(TextAlignment.CENTER);
        lbl.setAlignment(Pos.CENTER);
        stackImg.getStyleClass().remove("stackCoachCarrierImg");
        stackImg.getStyleClass().add("stackCoachCarrierTxt");
        stackImg.getChildren().add(lbl);

        return stackImg;
    }

    public static StackPane getStackCoachCarriers() {
        StackPane stack = new StackPane();
        stack.setStyle("-fx-padding: 0px;");
        stack.setMaxHeight(pageHt);
        stack.setMinHeight(pageHt);
        return stack;
    }

    public static TextField getTextFieldCoachDateSelect() {
        final TextField txtDate = new TextField();
        txtDate.setEditable(false);
        txtDate.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                StageComponents.showStageCalendar(txtDate);
            }
        });
        return txtDate;
    }

    public static VBox getVBoxCoach() {
        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.setMaxSize(JKLayout.contentW, COACH_PG_HT);
        vb.setMinSize(JKLayout.contentW, COACH_PG_HT);
        return vb;
    }

    public static VBox getVBoxButtons() {
        VBox vbBtns = JKLayout.getVBox(0, 0);
        vbBtns.setMaxHeight(gridCarrierHt - (2 * JKLayout.spNum));
        vbBtns.setMinHeight(gridCarrierHt - (2 * JKLayout.spNum));
        vbBtns.setAlignment(Pos.CENTER_RIGHT);
        vbBtns.setStyle("-fx-padding: 0px 15px 5px 0px;");
        return vbBtns;
    }

    public static VBox getPassengerVBox(Node nodeLbl, Node nodeEntry) {
        VBox vb = JKLayout.getVBoxLeft(0, 0);
        vb.getChildren().addAll(nodeLbl, nodeEntry);
        return vb;
    }

    public static Label getPassengerLabel(String label) {
        Label lbl = JKText.getLblDk(label, JKText.FONT_B_18);
        return lbl;
    }

    public static String getCarrierLogoPath(CoachCarrier carrier, boolean isLogoForPrint) {
        String localImgPath = null;

        try {
            String fileLocal = JK3Config.getImagesTemp() + carrier.getCarrierCode() + ".png";
            if (isLogoForPrint) {
                fileLocal = JK3Config.getImagesTemp() + carrier.getCarrierCode() + ".gif";
            }
            Path imgPath = Paths.get(fileLocal);

            if (imgPath.toFile().exists()) {
                String filePath = imgPath.toString();
                localImgPath = Paths.get(filePath).toUri().toURL().toExternalForm();
                if (isLogoForPrint) {
                    localImgPath = filePath;
                }
            } else {
                String downloadedLogoPath = getDownloadedCarrierLogo(carrier, isLogoForPrint);
                localImgPath = Paths.get(downloadedLogoPath).toUri().toURL().toExternalForm();
                if (isLogoForPrint) {
                    localImgPath = downloadedLogoPath;
                }
            }

        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return localImgPath;
    }

    private static String getDownloadedCarrierLogo(CoachCarrier carrier, boolean isLogoForPrint) {
        String downloadedLogoPath = null;

        String fileRemote = CacheListCoachCarriers.getListCoachCarriers().getMediaUrl() + carrier.getCarrierCode() + ".png";
        String fileLocal = JK3Config.getImagesTemp() + carrier.getCarrierCode() + ".png";
        if (isLogoForPrint) {
            fileRemote = CacheListCoachCarriers.getListCoachCarriers().getMediaUrl() + carrier.getCarrierCode() + ".gif";
            fileLocal = JK3Config.getImagesTemp() + carrier.getCarrierCode() + ".gif";
        }

        if (HttpUtils.httpDownload(fileRemote, fileLocal, true, null)) {
            if (HttpUtils.isLocalFileComplete(fileRemote, fileLocal)) {
                Path imgPath = Paths.get(fileLocal);
                downloadedLogoPath = imgPath.toString();
            }
        }

        return downloadedLogoPath;
    }
}
