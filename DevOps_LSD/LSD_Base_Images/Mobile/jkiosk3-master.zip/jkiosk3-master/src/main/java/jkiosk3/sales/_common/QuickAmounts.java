package jkiosk3.sales._common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.store.JKBranding;

public class QuickAmounts extends Region {

    private final Logger logger = Logger.getLogger(QuickAmounts.class.getName());

    private VBox vbEntry;
    private final SaleType saleType;
    private final QuickAmountsResult result;
    private final String provider;
    private double amount;

    public QuickAmounts(SaleType saleType, String prov, QuickAmountsResult res) {
        this.saleType = saleType;
        this.result = res;

        String[] btnsElect = {"R 20", "R 30", "R 40", "R 50", "R 60", "R 100", "R 150", "R 200", "R 300", "R 400", "R 500", "R 1000"};
        String[] btnsOther = {"R 10", "R 20", "R 30", "R 50", "R 100", "R 200"};
        List<String> btnLabels;

        switch (saleType) {
            case ELECTRICITY:
                this.provider = JKBranding.getBranding().getMerchantGroup().getCode();
                btnLabels = Arrays.asList(btnsElect);
                break;
            default:
                this.provider = prov;
                btnLabels = Arrays.asList(btnsOther);
                break;
        }

        getChildren().add(getQuickAmts(provider, btnLabels));
    }

    private VBox getQuickAmts(String prov, List<String> btnLabels) {

        vbEntry = JKLayout.getVBoxContent(0);
        vbEntry.setDisable(false);

        List<Button> btnList = new ArrayList<>();

        for (String s : btnLabels) {
            final Button btn = JKNode.getBtnSm(s);
            btn.getStyleClass().add("prov_" + prov.replaceAll(" ", "").replaceAll("\n", ""));
            btn.setFont(JKText.FONT_B_MID);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    checkAmountAndContinue(btn.getText().substring(2), btn);
//                    amount = Double.parseDouble(btn.getText().substring(2));
//                    amountSelected(amount);
                }
            });
            btnList.add(btn);
        }

        Label lblAmtOther = JKText.getLblDk("Enter Amount", JKText.FONT_B_XSM);
        final TextField txtAmtOther = JKNode.getTextFieldRight();
        txtAmtOther.setMinWidth((2 * JKLayout.btnSmW) + JKLayout.sp);
        txtAmtOther.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event t) {
                JKiosk3.getNumPad().showNumPad(true, txtAmtOther, "Enter Amount", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        checkAmountAndContinue(value, txtAmtOther);
//                        amount = SalesUtil.getAmountAsDouble(value, txtAmtOther);
//                        amountSelected(amount);
                    }
                });
            }
        });

        HBox hbAmtOther = JKLayout.getHBox(0, 0);
        hbAmtOther.setMaxWidth(JKLayout.contentW - (2 * JKLayout.sp));
        hbAmtOther.setMinWidth(JKLayout.contentW - (2 * JKLayout.sp));
        hbAmtOther.setTranslateX(-JKLayout.spNum);
        hbAmtOther.getChildren().addAll(lblAmtOther, JKNode.getHSpacer(), txtAmtOther);

        final Button btnOther = JKNode.getBtnSmDbl("Other Amount");
        btnOther.getStyleClass().add("prov_" + prov.replaceAll(" ", "").replaceAll("\n", ""));
        btnOther.setFont(JKText.FONT_B_MID);
        btnOther.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(new TextField(), "Enter Amount", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        checkAmountAndContinue(value, btnOther);
//                        try {
//                            amount = Double.parseDouble(value);
//                            amountSelected(amount);
//                        } catch (NumberFormatException nfe) {
//                            JKiosk3.getMsgBox().showMsgBox("Amount", "Amount must be a numeric only value", null);
//                        }
                    }
                });
            }
        });
        if (saleType != SaleType.ELECTRICITY) {
            btnList.add(btnOther);
        }

        double w = JKLayout.contentW - JKLayout.sp;

        FlowPane flow = new FlowPane(JKLayout.sp, JKLayout.sp);
        flow.setMaxWidth(w);
        flow.setMinWidth(w);
        flow.setPrefWrapLength(w);
        flow.setStyle("-fx-padding: 0;");
        flow.getChildren().addAll(btnList);

        vbEntry.setStyle("-fx-padding: 15px 0px 15px 15px;");
        switch (saleType) {
            case ELECTRICITY:
                vbEntry.setSpacing(2 * JKLayout.sp);
                vbEntry.getChildren().addAll(flow, hbAmtOther);
                break;
            default:
                vbEntry.getChildren().add(flow);
                break;
        }

        return vbEntry;
    }

    private void checkAmountAndContinue(String value, Node node) {
        if (node instanceof TextField) {
            vbEntry.setDisable(true);
            amount = SalesUtil.getAmountAsDouble(value, (TextField) node);
            amountSelected(amount);
            System.out.println("amount in text field = " + amount);
        } else if (node instanceof Button) {
            try {
                vbEntry.setDisable(true);
                amount = Double.parseDouble(value);
                amountSelected(amount);
                System.out.println("amount on button = " + amount);
            } catch (NumberFormatException nfe) {
                vbEntry.setDisable(false);
                JKiosk3.getMsgBox().showMsgBox("Amount", "Amount must be a numeric only value", null);
                logger.log(Level.SEVERE, nfe.getMessage(), nfe);
            }
        }
    }

    private void amountSelected(double value) {
        if (result != null) {
            result.amountSelected(value);
        }
    }
}
