package jkiosk3.sales.billpay;

import jkiosk3.sales.search.SearchProduct;

import java.util.List;

/**
 * @author Val
 */
public class BillPayProduct extends SearchProduct {

    private int provId;
    private String provName;
    private int prodId;
    private String prodName;
    //    private ProviderType provType;
    private BPTransType bpTransType;
    private boolean verify;
    private boolean fullAmount;
    private int additionalFields;
    private double prodMaxAmount;
    private double prodMinAmount;
    private boolean enforceFullPayment;
    private String logoID;
    private List<String> tendersAllowed;
    private boolean reversalSupported;

    public int getProdId() {
        return prodId;
    }

    public void setProdId(int prodId) {
        this.prodId = prodId;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public int getProvId() {
        return provId;
    }

    public void setProvId(int provId) {
        this.provId = provId;
    }

    public String getProvName() {
        return provName;
    }

    public void setProvName(String provName) {
        this.provName = provName;
    }

//    public ProviderType getProvType() {
//        return provType;
//    }
//
//    public void setProvType(ProviderType provType) {
//        this.provType = provType;
//    }

    public BPTransType getBpTransType() {
        return bpTransType;
    }

    public void setBpTransType(BPTransType bpTransType) {
        this.bpTransType = bpTransType;
    }

    public int getAdditionalFields() {
        return additionalFields;
    }

    public void setAdditionalFields(int additionalFields) {
        this.additionalFields = additionalFields;
    }

    public boolean isFullAmount() {
        return fullAmount;
    }

    public void setFullAmount(boolean fullAmount) {
        this.fullAmount = fullAmount;
    }

    public boolean isVerify() {
        return verify;
    }

    public void setVerify(boolean verify) {
        this.verify = verify;
    }

    public double getProdMaxAmount() {
        return prodMaxAmount;
    }

    public void setProdMaxAmount(double prodMaxAmount) {
        this.prodMaxAmount = prodMaxAmount;
    }

    public double getProdMinAmount() {
        return prodMinAmount;
    }

    public void setProdMinAmount(double prodMinAmount) {
        this.prodMinAmount = prodMinAmount;
    }

    public boolean isEnforceFullPayment() {
        return enforceFullPayment;
    }

    public void setEnforceFullPayment(boolean enforceFullPayment) {
        this.enforceFullPayment = enforceFullPayment;
    }

    public String getLogoId() {
        return logoID;
    }

    public void setLogoId(String logoID) {
        this.logoID = logoID;
    }

    public List<String> getTendersAllowed() {
        return tendersAllowed;
    }

    public void setTendersAllowed(List<String> tendersAllowed) {
        this.tendersAllowed = tendersAllowed;
    }

    public boolean isReversalSupported() {
        return reversalSupported;
    }

    public void setReversalSupported(boolean reversalSupported) {
        this.reversalSupported = reversalSupported;
    }

    @Override
	public String toString() {
		return "BillPayProduct [provId=" + provId + ", provName=" + provName + ", prodId=" + prodId + ", prodName="
				+ prodName + ", bpTransType=" + bpTransType + ", verify=" + verify + ", fullAmount=" + fullAmount
				+ ", additionalFields=" + additionalFields + ", prodMaxAmount=" + prodMaxAmount + ", prodMinAmount="
				+ prodMinAmount + ", enforceFullPayment=" + enforceFullPayment + ", tendersAllowed=" + tendersAllowed
				+ ", reversalSupported=" + reversalSupported + "]";
	}
    
    
}
