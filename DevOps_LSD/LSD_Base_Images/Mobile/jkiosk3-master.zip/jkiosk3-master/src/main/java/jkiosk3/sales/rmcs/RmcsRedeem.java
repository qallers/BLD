package jkiosk3.sales.rmcs;

import aeonmoneytransfer.MoneyTransferRedeemReq;
import aeonmoneytransfer.MoneyTransferResponse;
import java.util.Date;

/**
 *
 *
 */
public class RmcsRedeem {

    private final MoneyTransferRedeemReq redeemReq = new MoneyTransferRedeemReq();
    private MoneyTransferResponse redeemResp = new MoneyTransferResponse();
    private Date date;

    private static volatile RmcsRedeem instance;

    public static RmcsRedeem getInstance() {
        return instance;
    }

    public static RmcsRedeem newInstance() {
        instance = new RmcsRedeem();
        return instance;
    }

    public static void resetRmcsCashRedeem() {
        instance = null;
    }

    // getters and setters    
    public MoneyTransferRedeemReq getRedeemReq() {
        return redeemReq;
    }

    public MoneyTransferResponse getRedeemResp() {
        return redeemResp;
    }

    public void setRedeemResp(MoneyTransferResponse redeemResp) {
        this.redeemResp = redeemResp;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
