package jkiosk3._components;

/**
 *
 * @author Val
 */
public abstract class NumberPadResult {
    
    public abstract void onDone(String value);
}
