package jkiosk3._components;

/**
 *
 * @author Valerie
 */
public abstract class InputPopupResult {
    
    public abstract void onSave();

    public abstract void onOk();

    public abstract void onCancel();

}
