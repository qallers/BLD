package jkiosk3.setup;

import javafx.geometry.HPos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.printing.PrintClient;
import jkiosk3.store.JKCashDrawer;
import jkiosk3.store.JKPrinter;
import jkiosk3.store.JKSalesOptions;

/**
 *
 * @author Val
 */
public class SetupSalesOptions extends Region {

    private CheckBox chkConfirmSale;
//    private CheckBox chkSendVouchToCell;
    private CheckBox chkEnterTender;
    private CheckBox chkUseCashDrawer;
    private CheckBox chkCashDrawerOpen;
    private CheckBox chkAcceptCash;
    private CheckBox chkAcceptCheque;
    private CheckBox chkAcceptCreditCard;
    private CheckBox chkAcceptDebitCard;

    public SetupSalesOptions() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getSalesOptionsEntry());
        vb.getChildren().add(getControls());
        
        updateTestBtnState();

        getChildren().add(vb);
    }

    private GridPane getSalesOptionsEntry() {

        GridPane grid = JKLayout.getGridContent2Col(1.0, 0, HPos.LEFT);

        VBox vbHead = JKNode.getPageHeadVB("Sales Options");

        Label lblPaymentTypes = JKText.getLblContentHead("Payment Types Accepted*");
        Label lblRestart = JKText.getLblDk("*Restart required", JKText.FONT_B_XXSM);

        chkConfirmSale = new CheckBox("Confirm Sale Details Before Proceeding");
        chkConfirmSale.setSelected(JKSalesOptions.getSalesOptions().isConfirmSale());

//        chkSendVouchToCell = new CheckBox("Send Voucher PIN to a Cell Number");
//        chkSendVouchToCell.setDisable(true);
//        chkSendVouchToCell.setSelected(JKSetup.getSystemSetup().isSendToCell());
        chkEnterTender = new CheckBox("Enter Amount Tendered and Calculate Change Due");
        chkEnterTender.setSelected(JKSalesOptions.getSalesOptions().isEnterTender());

        chkUseCashDrawer = new CheckBox("Use Cash Drawer");
        chkUseCashDrawer.setSelected(JKSalesOptions.getSalesOptions().isUseCashDrawer());

        chkCashDrawerOpen = new CheckBox("Open Cash Drawer on End Shift");
        chkCashDrawerOpen.setSelected(JKSalesOptions.getSalesOptions().isCashDrawerOpenOnEndShift());

        chkAcceptCash = new CheckBox("Accept Cash");
        chkAcceptCash.setSelected(JKSalesOptions.getSalesOptions().isAcceptCash());

        chkAcceptCheque = new CheckBox("Accept Cheque");
        chkAcceptCheque.setSelected(JKSalesOptions.getSalesOptions().isAcceptCheque());

        chkAcceptCreditCard = new CheckBox("Accept Credit Card");
        chkAcceptCreditCard.setSelected(JKSalesOptions.getSalesOptions().isAcceptCreditCard());

        chkAcceptDebitCard = new CheckBox("Accept Debit Card");
        chkAcceptDebitCard.setSelected(JKSalesOptions.getSalesOptions().isAcceptDebitCard());

        grid.add(vbHead, 0, 0, 2, 1);
        grid.add(chkConfirmSale, 0, 1);
//        grid.add(chkSendVouchToCell, 0, 3);
        grid.add(chkEnterTender, 0, 2);
        grid.add(chkUseCashDrawer, 0, 3);
        grid.add(chkCashDrawerOpen, 0, 4);
        grid.add(JKNode.createGridSpanSep(1), 0, 5);
        grid.add(lblPaymentTypes, 0, 6);
        grid.add(chkAcceptCash, 0, 7);
        grid.add(chkAcceptCheque, 0, 8);
        grid.add(chkAcceptCreditCard, 0, 9);
        grid.add(chkAcceptDebitCard, 0, 10);
        grid.add(lblRestart, 0, 11);

        return grid;
    }

    private SceneSetupControls getControls() {
        return new SceneSetupControls("Test Cash\nDrawer", true) {
            @Override
            public void onClickTest() {
                new PrintClient().cashDraw();
            }

            @Override
            public void onClickSave() {
                if (validateSelections()) {
                    if (checkCashDrawer()) {
                        saveSalesOptions();
                    }
                }
            }
        };
    }
    
    private void updateTestBtnState() {
        if (JKSalesOptions.getSalesOptions().isUseCashDrawer()) {
            SceneSetupControls.getBtnTest().setDisable(false);
        } else {
            SceneSetupControls.getBtnTest().setDisable(true);
        }
    }

    private boolean validateSelections() {
        boolean success = true;
        if (!chkAcceptCash.isSelected() && !chkAcceptCheque.isSelected()
                && !chkAcceptCreditCard.isSelected() && !chkAcceptDebitCard.isSelected()) {
            JKiosk3.getMsgBox().showMsgBox("Payment Types Accepted",
                    "At least ONE Payment Type must be selected", null);
            success = false;
        }
        return success;
    }
    
    private boolean checkCashDrawer() {
        if (chkUseCashDrawer.isSelected()) {
            if (JKCashDrawer.getCashDrawerConfig() == null) {
                JKiosk3.getMsgBox().showMsgBox("Cash Drawer", "Cash Drawer Config not available", null);
                return false;
            }
            if (JKPrinter.getPrinterConfig().isPrintWin()
                    && (JKCashDrawer.getCashDrawerConfig().getCdWindows() == null)) {
                String cdWin = "\nSETTINGS NOT SAVED!"
                        + "\n\nIf 'Use Cash Drawer' is selected here"
                        + "\n\nand 'Windows Printer' is selected in 'Printer Setup', "
                        + "\n\nthe settings for 'Cash Drawer' have to be saved FIRST.";
                JKiosk3.getMsgBox().showMsgBox("Cash Drawer", cdWin, null);
                chkUseCashDrawer.setSelected(false);
                return false;
            }
        }
        return true;
    }

    private void saveSalesOptions() {
        if (chkConfirmSale.isSelected()) {
            JKSalesOptions.getSalesOptions().setConfirmSale(true);
        } else {
            JKSalesOptions.getSalesOptions().setConfirmSale(false);
        }

//        if (chkSendVouchToCell.isSelected()) {
//            JKSetup.getSystemSetup().setSendToCell(true);
//        } else {
//            JKSetup.getSystemSetup().setSendToCell(false);
//        }
        if (chkEnterTender.isSelected()) {
            JKSalesOptions.getSalesOptions().setEnterTender(true);
        } else {
            JKSalesOptions.getSalesOptions().setEnterTender(false);
        }

        if (chkUseCashDrawer.isSelected()) {
            JKSalesOptions.getSalesOptions().setUseCashDrawer(true);
        } else {
            JKSalesOptions.getSalesOptions().setUseCashDrawer(false);
        }

        if (chkCashDrawerOpen.isSelected()) {
            JKSalesOptions.getSalesOptions().setCashDrawerOpenOnEndShift(true);
        } else {
            JKSalesOptions.getSalesOptions().setCashDrawerOpenOnEndShift(false);
        }

        if (chkAcceptCash.isSelected()) {
            JKSalesOptions.getSalesOptions().setAcceptCash(true);
        } else {
            JKSalesOptions.getSalesOptions().setAcceptCash(false);
        }

        if (chkAcceptCheque.isSelected()) {
            JKSalesOptions.getSalesOptions().setAcceptCheque(true);
        } else {
            JKSalesOptions.getSalesOptions().setAcceptCheque(false);
        }

        if (chkAcceptCreditCard.isSelected()) {
            JKSalesOptions.getSalesOptions().setAcceptCreditCard(true);
        } else {
            JKSalesOptions.getSalesOptions().setAcceptCreditCard(false);
        }

        if (chkAcceptDebitCard.isSelected()) {
            JKSalesOptions.getSalesOptions().setAcceptDebitCard(true);
        } else {
            JKSalesOptions.getSalesOptions().setAcceptDebitCard(false);
        }

        if (JKSalesOptions.saveSystemSetup()) {
            JKiosk3.getMsgBox().showMsgBox("Saved", "Sales options saved successfully", null);
            updateTestBtnState();
        } else {
            JKiosk3.getMsgBox().showMsgBox("NOT SAVED!", "Sales options not saved", null);
        }
    }
}
