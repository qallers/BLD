package jkiosk3.store;

import java.io.Serializable;

/**
 *
 * @author Valerie
 */
public class StoreJKOptions implements Serializable {

//    private final static long serialVersionUID = 100022L;
    // Options
    private String keyTouch = "";
    private boolean keyboard = false;
    private boolean autoLogout = false;
    private boolean salesPersonLogin = false;
    private boolean cashierEndShift = false;
    private int reprintNumber = 10;
    private boolean multipleMenuLogin = false;

    public String getKeyTouch() {
        return keyTouch;
    }

    public void setKeyTouch(String keyTouch) {
        this.keyTouch = keyTouch;
    }

    public boolean isKeyboard() {
        return keyboard;
    }

    public void setKeyboard(boolean keyboard) {
        this.keyboard = keyboard;
    }

    public boolean isAutoLogout() {
        return autoLogout;
    }

    public void setAutoLogout(boolean autoLogout) {
        this.autoLogout = autoLogout;
    }

    public boolean isSalesPersonLogin() {
        return salesPersonLogin;
    }

    public void setSalesPersonLogin(boolean salesPersonLogin) {
        this.salesPersonLogin = salesPersonLogin;
    }
   
    public boolean isCashierEndShift() {
        return cashierEndShift;
    }

    public void setCashierEndShift(boolean cashierEndShift) {
        this.cashierEndShift = cashierEndShift;
    }

    public int getReprintNumber() {
        return reprintNumber;
    }

    public void setReprintNumber(int reprintNumber) {
        this.reprintNumber = reprintNumber;
    }

    public boolean isMultipleMenuLogin() {
        return multipleMenuLogin;
    }

    public void setMultipleMenuLogin(boolean multipleMenuLogin) {
        this.multipleMenuLogin = multipleMenuLogin;
    }
}
