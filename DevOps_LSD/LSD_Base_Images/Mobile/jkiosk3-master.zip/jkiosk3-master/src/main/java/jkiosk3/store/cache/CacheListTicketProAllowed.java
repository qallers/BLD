package jkiosk3.store.cache;

import aeonticketpros.TicketProAllowedProdListResp;
import aeonticketpros.TicketProAllowedProduct;
import java.util.Collections;
import java.util.List;
import jkiosk3.store.Store;

public class CacheListTicketProAllowed {
    
    private static volatile ListTicketProAllowed listTProAllowed;

    private static ListTicketProAllowed getListTProAllowed() {
        if (listTProAllowed == null) {
            listTProAllowed = ((ListTicketProAllowed) Store.loadObject(CacheListTicketProAllowed.class.getSimpleName()));
        }
        if (listTProAllowed == null) {
            listTProAllowed = new ListTicketProAllowed();
        }
        return listTProAllowed;
    }

    private static void saveListTProAllowed(ListTicketProAllowed listTPAllow) {
        Store.saveObject(CacheListTicketProAllowed.class.getSimpleName(), listTPAllow);
    }
    
    public static void saveListTicketProAllowed(TicketProAllowedProdListResp listAllowed) {
        getListTProAllowed();
        listTProAllowed.getListTProAllowed().clear();
        listTProAllowed.getListTProAllowed().addAll(listAllowed.getListAllowedProducts());
        saveListTProAllowed(listTProAllowed);
    }

    public static boolean hasItems() {
        getListTProAllowed();
        return !listTProAllowed.getListTProAllowed().isEmpty();
    }
    
    public static List<TicketProAllowedProduct> getListTicketProAllowed() {
        getListTProAllowed();
        return Collections.unmodifiableList(listTProAllowed.getListTProAllowed());
    }

    public static void deleteCacheTicketProAllowed() {
        Store.deleteObject(CacheListTicketProAllowed.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheListTicketProAllowed.class.getSimpleName());
    }
    
}
