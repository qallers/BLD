package jkiosk3.accounts.banking;

import aeonreports.Account;
import java.util.List;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;

/**
 *
 * @author Valerie
 */
public class BankAccSelect extends Region {

    private final Account selectAcc;
    private final String selectedBank;
    private final AccountType accType;

    public BankAccSelect(Account selectedAccount, String selectedBank) {
        this.selectAcc = selectedAccount;
        this.selectedBank = selectedBank;
        accType = getBankDetailDisplay();
        getChildren().add(showBankAccSelect());
    }

    private AccountType getBankDetailDisplay() {
        List<AccountType> listDepAccounts = AccountDepositDetail.getAccountTypeList();
        AccountType selectAccType = null;
        for (AccountType at : listDepAccounts) {
            if (selectAcc.getAccountNo().substring(0, 3).equalsIgnoreCase(at.getAccountPrefix())) {
                selectAccType = at;
            }
        }
        return selectAccType;
    }

    private VBox showBankAccSelect() {

        Label lblSelected = JKText.getLblDk("Selected Account", JKText.FONT_B_SM);
        Label lblBank = JKText.getLblContentHead("Selected Bank");
        Text txtSelected = JKText.getTxtDk(selectAcc.getAccountNo(), JKText.FONT_B_SM);
        Text txtBank = JKText.getTxtDk(selectedBank, JKText.FONT_B_SM);
        GridPane gridHead = JKLayout.getContentGridInner2Col(0.45, 0.55);

        gridHead.addRow(0, lblSelected, txtSelected);
        gridHead.addRow(1, lblBank, txtBank);

        VBox vbAccDisplay = JKLayout.getVBoxContent(JKLayout.sp);
        vbAccDisplay.setAlignment(Pos.TOP_LEFT);

        vbAccDisplay.getChildren().addAll(gridHead, JKNode.createContentSep());

        vbAccDisplay.getChildren().add(getRefGrid());

        if (accType != null) {
            vbAccDisplay.getChildren().add(getGridBankAccounts());
        } else {
            Label lblNoDetail = JKText.getLblDk("No bank details for selected Account Type", JKText.FONT_B_XXSM);
            Label lblContact = JKText.getLblDk("Contact Support for information", JKText.FONT_B_XXSM);
            vbAccDisplay.getChildren().addAll(JKNode.createContentSep(), lblNoDetail, lblContact);
        }

        return vbAccDisplay;
    }

    private GridPane getRefGrid() {
        GridPane gridRef = JKLayout.getContentGridInner2Col(0.45, 0.55);

        Label lblCustomerRef = JKText.getLblDk("Deposit Reference", JKText.FONT_B_XXSM);
        lblCustomerRef.setTranslateX(JKLayout.sp);
        Text txtCustomerRef = JKText.getTxtDk(selectAcc.getAccountNo(), JKText.FONT_B_XSM);

        gridRef.addRow(0, lblCustomerRef, txtCustomerRef);

        return gridRef;
    }

    private GridPane getGridBankAccounts() {
        GridPane grid = JKLayout.getContentGridInner2Col(0.45, 0.55);

        int rowCount = -1;
        for (DepositType dt : accType.getListDepositTypes()) {
            Label lblType = JKText.getLblDk(dt.getType(), JKText.FONT_B_SM);
            grid.addRow(++rowCount, JKNode.createGridSpanSep(2));
            grid.addRow(++rowCount, lblType);
            for (Bank b : dt.getListBanks()) {
                if (b.getBankName().equalsIgnoreCase(selectedBank)) {
                    if (!b.getAccountNumber().equals("")) {
                        Label lblName = JKText.getLblDk("Account Holder", JKText.FONT_B_XXSM);
                        lblName.setTranslateX(JKLayout.sp);
                        Label lblBank = JKText.getLblDk("Bank", JKText.FONT_B_XXSM);
                        lblBank.setTranslateX(JKLayout.sp);
                        Label lblAccNo = JKText.getLblDk("Account Number", JKText.FONT_B_XXSM);
                        lblAccNo.setTranslateX(JKLayout.sp);
                        Label lblBranch = JKText.getLblDk("Branch Code", JKText.FONT_B_XXSM);
                        lblBranch.setTranslateX(JKLayout.sp);

                        Separator sep = JKNode.createGridSpanSep(2);
                        sep.setMaxWidth(JKLayout.contentW - (4 * JKLayout.sp));
                        sep.setTranslateX(JKLayout.sp);

                        Text txtName = JKText.getTxtDk(b.getAccountHolder(), JKText.FONT_B_XXSM);
                        Text txtBank = JKText.getTxtDk(b.getBankName(), JKText.FONT_B_XXSM);
                        Text txtAccNo = JKText.getTxtDk(b.getAccountNumber(), JKText.FONT_B_XXSM);
                        Text txtBranch = JKText.getTxtDk(b.getBranchCode(), JKText.FONT_B_XXSM);

                        grid.addRow(++rowCount, lblName, txtName);
                        grid.addRow(++rowCount, lblBank, txtBank);
                        grid.addRow(++rowCount, lblAccNo, txtAccNo);
                        grid.addRow(++rowCount, lblBranch, txtBranch);
                    } else {
                        Label lblNotAvailable = JKText.getLblDk(dt.getType() + " deposits not available for " + b.getBankName(),
                                JKText.FONT_B_XXSM);
                        lblNotAvailable.setTranslateX(JKLayout.sp);
                        grid.add(lblNotAvailable, 0, ++rowCount, 2, 1);
                    }
                }
            }
        }
        return grid;
    }
}
