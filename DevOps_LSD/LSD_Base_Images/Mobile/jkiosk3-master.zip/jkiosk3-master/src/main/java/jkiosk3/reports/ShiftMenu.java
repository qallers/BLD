package jkiosk3.reports;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.users.CurrentUser;

/**
 *
 * @author Val
 */
public class ShiftMenu extends Region {

    private final List<String> shiftMenusAllowed;

    public ShiftMenu() {
        shiftMenusAllowed = ReportUtilMenus.getUserShiftReportMenu(CurrentUser.getUser().getUserPin());
        getChildren().add(getShiftMenuGroup());
    }

    private HBox getShiftMenuGroup() {

        List<Button> btnList = new ArrayList<>();

        for (String s : shiftMenusAllowed) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 4, btnList);

        HBox hb = JKLayout.getHBoxContent(JKLayout.sp);
        hb.getChildren().add(tile);

        return hb;
    }

    private void getMenuAction(Button b) {
        int n = SceneReports.getVbReportContent().getChildren().size();
        if (n > 1) {
            SceneReports.getVbReportContent().getChildren().remove(1, n);
        }

        switch (b.getText()) {
            case ReportUtilMenus.REP_BTN_SHIFT_END:
                SceneReports.getVbReportContent().getChildren().add(1, new ShiftEnd());
                break;
            case ReportUtilMenus.REP_BTN_SHIFT_VIEW:
                SceneReports.getVbReportContent().getChildren().add(1, new ShiftView());
                break;
            case ReportUtilMenus.REP_BTN_DAILY_BATCH:
                SceneReports.getVbReportContent().getChildren().add(1, new DailyBatch());
                break;
            case ReportUtilMenus.REP_BTN_USER_CASHUP:
                SceneReports.getVbReportContent().getChildren().add(1, new UserCashupMenu());
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Shift Reports", "No Report Selected", null);
        }
    }
}
