package jkiosk3.store.cache;

import aeonticketpros.bus.TicketProBusLocation;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author valeriew
 */
public class ListPutcoLocations implements Serializable {

    private final static long serialVersionUID = 10001L;

    private final List<TicketProBusLocation> listPutcoLocations = new ArrayList<>();

    public List<TicketProBusLocation> getListPutcoLocations() {
        return listPutcoLocations;
    }
}
