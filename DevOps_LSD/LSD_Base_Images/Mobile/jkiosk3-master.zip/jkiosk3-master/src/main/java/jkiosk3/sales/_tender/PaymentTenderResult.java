package jkiosk3.sales._tender;

/**
 *
 * @author Val
 */
public abstract class PaymentTenderResult {
    
    public abstract void onOk();

    public abstract void onCancel();
}
