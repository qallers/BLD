package jkiosk3.sales.billpay._common;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._components.MessageBox;
import jkiosk3.sales.MerchantCopy;
import jkiosk3.sales.SalesMenu;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.m2m.InputM2M;
import jkiosk3.users.SalesUserLoginResult;
import jkiosk3.users.UserUtil;

/**
 *
 * @author Val
 */
public class BillPaymentMenu extends Region {

    public BillPaymentMenu() {
        getChildren().add(getBillPaymentProviders());
    }

    private VBox getBillPaymentProviders() {

        VBox vbHead = JKNode.getPageHeadVB("Bill Payment Options");

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getMenuButtons());

        VBox vbPay = JKLayout.getVBoxContent(JKLayout.sp);
        vbPay.getChildren().addAll(vbHead, tile);

        return vbPay;
    }

    private List<Button> getMenuButtons() {
        List<Button> btnList = new ArrayList<>();

        List<String> listBillPayMenu = SalesMenu.getListBillPayMenu();

        for (String s : listBillPayMenu) {
            final Button btn = JKNode.getBtnSmDbl(s);
            btn.setId(s);
            btn.getStyleClass().add("prov_VAS");
            btn.setStyle(JKNode.getBrandButton());
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        return btnList;
    }

    private void getMenuAction(Button b) {
        MerchantCopy.resetMerchantCopy();
        MerchantCopy.getInstance().setTransType(b.getId());
        switch (b.getId()) {
            case BillPayUtilMisc.TYPE_BILL_PAY:
                SceneSales.clearAndChangeContent(new BillPaymentSelect(
                        BillPayUtilMisc.TYPE_BILL_PAY + " Providers", BillPayUtilMisc.TYPE_BILL_PAY));
                break;
            case BillPayUtilMisc.TYPE_INSURE_PAY:
                SceneSales.clearAndChangeContent(new BillPayInsuranceMenu());
                break;
            case BillPayUtilMisc.TYPE_TRAFFIC_FINE:
                SceneSales.clearAndChangeContent(new BillPaymentSelect(
                        BillPayUtilMisc.TYPE_TRAFFIC_FINE + " Providers", BillPayUtilMisc.TYPE_TRAFFIC_FINE));
                break;
            case BillPayUtilMisc.TYPE_M2M_TRANSFER:
//                JKiosk3.getSalesUserLogin().showUserLogin(new PasswordField(), new SalesUserLoginResult() {
                JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
                    @Override
                    public void onDone() {
                        SceneSales.clearAndChangeContent(new InputM2M());
                    }
                });
//                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
//                getSupervisorLogin();
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Bill Payments", "Unable to find selected menu item", null,
                        MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, null);
                SceneSales.clearAndChangeContent(new BillPaymentMenu());
        }
    }

//    private void getSupervisorLogin() {
//        JKiosk3.getSalesUserLogin().showUserLogin(true, new SalesUserLoginResult() {
//            @Override
//            public void onDone() {
//                SceneSales.clearAndChangeContent(new InputM2M());
//            }
//        });
//    }
}
