package jkiosk3.utilities;

import aeontender.TenderType;
import aeontender.TenderTypeResponse;
import aeonticketpros.bus.TicketProBusAutoCancelReq;
import aeonticketpros.bus.TicketProBusAutoCancelResp;
import aeonusers.SetPrintedResponse;
import jkiosk3._common.ResultCallback;
import jkiosk3.printing.tickets.JKPutcoCancel;
import jkiosk3.printing.tickets.StoreJKPutcoCancel;
import jkiosk3.sales._tender.TenderUtil;
import jkiosk3.sales.ticketpro.TicketProUtilBus;
import jkiosk3.store.JKSetPrintedQueue;
import jkiosk3.store.JKTenders;
import jkiosk3.store.StoreJKSetPrintedQueue;
import jkiosk3.store.StoreJKTenders;
import jkiosk3.users.UserUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class ResubmitUtil {

    private final static Logger logger = Logger.getLogger(ResubmitUtil.class.getName());

    private static StoreJKSetPrintedQueue jkSetPrintedQueue;
    private static StoreJKTenders jkTenders;
    private static StoreJKPutcoCancel jkPutcoCancel;
    private static List<String> listSetPrinted;
    private static List<TenderType> listTenders;
    private static List<TicketProBusAutoCancelReq> listPutcoCancel;
    private static ResultCallback finalRes;

    public static void resubmitUnprocessedItems(final ResultCallback finalRes) {
        ResubmitUtil.finalRes = finalRes;

        listSetPrinted = new ArrayList<>();
        listTenders = new ArrayList<>();
        listPutcoCancel = new ArrayList<>();

        if (JKSetPrintedQueue.hasItems()) {
            logger.info(("Number of items in set printed list = ").concat(Integer.toString(JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs().size())));
            jkSetPrintedQueue = new StoreJKSetPrintedQueue();
            for (final String s : JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs()) {
                listSetPrinted.add(s);
            }
        }

        if (JKTenders.hasItems()) {
            logger.info(("Number of items in tender list = ").concat(Integer.toString(JKTenders.getJkTenders().getListTenderTypes().size())));
            jkTenders = new StoreJKTenders();
            for (final TenderType tt : JKTenders.getJkTenders().getListTenderTypes()) {
                listTenders.add(tt);
            }
        }
        if (JKPutcoCancel.hasItems()) {
            logger.info(("Number of items in auto-cancel list = ").concat(Integer.toString(JKPutcoCancel.getPutcoCancelList().getListAutoCancelReq().size())));
            jkPutcoCancel = new StoreJKPutcoCancel();
            for (final TicketProBusAutoCancelReq ac : JKPutcoCancel.getPutcoCancelList().getListAutoCancelReq()) {
                listPutcoCancel.add(ac);
            }
        }
        processUnsubmittedLists();
    }

    private static void processUnsubmittedLists() {
        /* If all lists are empty, return 'true' - no processing required */
        if (listSetPrinted.isEmpty() && listTenders.isEmpty() && listPutcoCancel.isEmpty()) {
            System.out.println("all lists are empty, return true");
            finalRes.onResult(true);
        } else {
            /* Start with items not set as printed */
            if (!listSetPrinted.isEmpty()) {
                System.out.println("unprocessed set printed items found...");
                submitUnprocessedSetPrinted(0, listSetPrinted);
            }
            /* First check and complete tenders... */
            System.out.println("start with unprocessed tenders...");
            if (!listTenders.isEmpty()) {
                System.out.println("unprocessed tenders found...");
                submitUnprocessedTenders(0, listTenders);
//                submitUnprocessedTenders(countSubmitTenders, listTenders);
            } else {
                /* ... and then continue to auto-cancels */
                System.out.println("no unprocessed tenders, move on to auto-cancel");
                if (!listPutcoCancel.isEmpty()) {
                    submitUnprocessedAutoCancel(0, listPutcoCancel);
                }
            }
        }
    }

    // start of unsubmitted set printed
    private static void submitUnprocessedSetPrinted(int count, List<String> listSetPrinted) {
        String currentTransRef = listSetPrinted.get(count);
        String selectedTransRef = null;
        for (String s : JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs()) {
            if (s.equalsIgnoreCase(currentTransRef)) {
                selectedTransRef = s;
                break;
            }
        }
        submitSetPrinted(count, listSetPrinted, selectedTransRef);
    }

    private static void submitSetPrinted(final int count, final List<String> listSetPrinted, final String transRef) {
        UserUtil.setTransactionPrinted(transRef, new UserUtil.SetPrintedResponseResult() {
            @Override
            public void setPrintedResponseResult(SetPrintedResponse result) {
                if (result != null) {
                    if (result.isSuccess()) {
                        logger.info(("Set Printed item was submitted successfully - ").concat(transRef));
                        // Nothing to do  -  business as usual.
                    } else {
                        jkSetPrintedQueue.getListTransRefs().add(transRef);
                    }
                } else {
                    jkSetPrintedQueue.getListTransRefs().add(transRef);
                }
                //
                // continue submitting through list, or move on to next list
                if ((count + 1) < JKSetPrintedQueue.getSetPrintedQueue().getListTransRefs().size()) {
                    submitUnprocessedSetPrinted((count + 1), listSetPrinted);
                } else {
                    updateOrClearUnsubmittedSetPrinted();
                    if (!listTenders.isEmpty() || !listPutcoCancel.isEmpty()) {
                        submitUnprocessedTenders(0, listTenders);
//                        submitUnprocessedTenders(countSubmitTenders, listTenders);
                    } else {
                        finalRes.onResult(true);
                    }
                }
            }
        });
    }
    // end of unsubmitted set printed

    // start of unsubmitted tenders
    private static void submitUnprocessedTenders(int count, List<TenderType> listTenders) {
        // TODO  -  resolve error 'ArrayIndexOutOfBounds'
        TenderType currentTender = listTenders.get(count);          // error happens here!
        TenderType selectedTender = null;
        for (TenderType tt : JKTenders.getJkTenders().getListTenderTypes()) {
            if (tt.getReference().equalsIgnoreCase(currentTender.getReference())) {
                selectedTender = tt;
                break;
            }
        }
        submitTender(count, listTenders, selectedTender);
    }

    private static void submitTender(final int count, final List<TenderType> listTenders, final TenderType tender) {
        TenderUtil.submitTenderSummary(tender, false, new TenderUtil.TenderSubmitResult() {

            @Override
            public void tenderSubmitResult(TenderTypeResponse tenderResponse) {
                if (tenderResponse != null) {
                    if (tenderResponse.isSuccess()) {
                        logger.info(("Tender was submitted successfully - ").concat(Double.toString(tender.getTotal())));
                        // Nothing to do  -  business as usual.
                    } else {
                        checkAndAddUnsubmittedTender(tender);
//                        jkTenders.getListTenderTypes().add(tender);
                        String msg = tenderResponse.getErrorCode() + " - " + tenderResponse.getErrorText();
                        logger.info(("Error - ").concat(msg));
                    }
                } else {
                    checkAndAddUnsubmittedTender(tender);
//                    jkTenders.getListTenderTypes().add(tender);
                }
                //
                // continue submitting through list, or move on to next list
                if ((count + 1) < listTenders.size()) {
                    System.out.println("count is still less than list : count = " + (count + 1) + " :: list size = " + listTenders.size());
                    submitUnprocessedTenders((count + 1), listTenders);
                } else {
                    updateOrClearUnsubmittedTenders();
                    if (!listPutcoCancel.isEmpty()) {
                        submitUnprocessedAutoCancel(0, listPutcoCancel);
                    } else {
                        finalRes.onResult(true);
                    }
                }
            }
        });
    }

    private static void checkAndAddUnsubmittedTender(TenderType tender) {
        if (jkTenders.getListTenderTypes().isEmpty()) {
            jkTenders.getListTenderTypes().add(tender);
        } else {
            List<String> listRefs = new ArrayList<>();
            for (TenderType t : jkTenders.getListTenderTypes()) {
                listRefs.add(t.getReference());
            }
            if (!listRefs.contains(tender.getReference())) {
                jkTenders.getListTenderTypes().add(tender);
            }
        }
    }
    // end of unsubmitted tenders


    // start of unsubmitted auto cancel
    private static void submitUnprocessedAutoCancel(int count, List<TicketProBusAutoCancelReq> listReqs) {
        TicketProBusAutoCancelReq currentReq = listReqs.get(count);
        TicketProBusAutoCancelReq selectedReq = null;
        for (TicketProBusAutoCancelReq req : JKPutcoCancel.getPutcoCancelList().getListAutoCancelReq()) {
            if (req.getTransactionRef().equalsIgnoreCase(currentReq.getTransactionRef())) {
                selectedReq = req;
                break;
            }
        }
        submitAutoCancel(count, listReqs, selectedReq);
    }

    private static void submitAutoCancel(final int count, final List<TicketProBusAutoCancelReq> listReqs, final TicketProBusAutoCancelReq cancelReq) {
        TicketProUtilBus.getTicketProBusAutoCancel(cancelReq, new TicketProUtilBus.TicketProPutcoAutoCancelResult() {
            @Override
            public void tpBusTicketAutoCancelResult(TicketProBusAutoCancelResp tpAutoCancelResp) {
                if (tpAutoCancelResp != null) {
                    if (tpAutoCancelResp.isSuccess()) {
                        logger.info(("Booking was cancelled successfully - ").concat(tpAutoCancelResp.getTicketReference()));
                        // Nothing to do  -  business as usual.
                    } else {
                        jkPutcoCancel.getListAutoCancelReq().add(cancelReq);
                        String msg = tpAutoCancelResp.getErrorCode() + " - " + tpAutoCancelResp.getErrorText();
                        logger.info(("Error cancelling Putco booking - ").concat(msg));
                    }
                } else {
                    jkPutcoCancel.getListAutoCancelReq().add(cancelReq);
                }
                //
                // continue submitting through list, or move on to save any failed items
                if ((count + 1) < JKPutcoCancel.getPutcoCancelList().getListAutoCancelReq().size()) {
                    submitUnprocessedAutoCancel((count + 1), listReqs);
                } else {
                    updateOrClearUnsubmittedPutcoAutoCancel();
                    finalRes.onResult(true);
                }
            }
        });
    }
    // end of unsubmitted auto cancel

    private static void updateOrClearUnsubmittedSetPrinted() {
        if (!jkSetPrintedQueue.getListTransRefs().isEmpty()) {
            JKSetPrintedQueue.clearSetPrintedQueue();
            for (String s : jkSetPrintedQueue.getListTransRefs()) {
                JKSetPrintedQueue.saveSetPrintedItem(s);
            }
            logger.info(("Size of outstanding set printed list : ").concat(Integer.toString(jkSetPrintedQueue.getListTransRefs().size())));
        } else {
            JKSetPrintedQueue.clearSetPrintedQueue();
            logger.info("Outstanding Set Printed Queue is empty");
        }
    }

    private static void updateOrClearUnsubmittedTenders() {
        System.out.println("updating tender type list : " + jkTenders.getListTenderTypes().size());
        if (!jkTenders.getListTenderTypes().isEmpty()) {
//            JKTenders.clearAndSaveTenders(jkTenders);
            JKTenders.clearTendersList();
            for (TenderType t : jkTenders.getListTenderTypes()) {
                JKTenders.saveTender(t);
            }
            logger.info(("Size of outstanding tender list : ").concat(Integer.toString(jkTenders.getListTenderTypes().size())));
        } else {
            JKTenders.clearTendersList();
            logger.info(("Outstanding tender list is empty"));
        }
    }

    private static void updateOrClearUnsubmittedPutcoAutoCancel() {
        if (!jkPutcoCancel.getListAutoCancelReq().isEmpty()) {
            JKPutcoCancel.clearAndSaveAutoCancelList(jkPutcoCancel);
            logger.info(("Size of outstanding AutoCancel list : ").concat(Integer.toString(jkPutcoCancel.getListAutoCancelReq().size())));
        } else {
            JKPutcoCancel.clearPutcoCancelList();
            logger.info(("Outstanding AutoCancel list is empty"));
        }
    }
}
