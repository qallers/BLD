package jkiosk3.store;

/**
 *
 * @author Valerie
 */
public class JKPrintOptions {
    
    private static StoreJKPrintOptions printOptions;

    public static StoreJKPrintOptions getPrintOptions() {
        if (printOptions == null) {
            printOptions = ((StoreJKPrintOptions) Store.loadObject(JKPrintOptions.class.getSimpleName()));
        }
        if (printOptions == null) {
            printOptions = new StoreJKPrintOptions();
        }
        return printOptions;
    }

    public static boolean savePrintOptions() {
        getPrintOptions();
        return Store.saveObject(JKPrintOptions.class.getSimpleName(), printOptions);
    }
    
}
