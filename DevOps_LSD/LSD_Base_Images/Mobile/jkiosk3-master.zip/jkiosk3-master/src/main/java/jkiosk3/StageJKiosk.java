package jkiosk3;

import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 *
 * @author Val
 */
public class StageJKiosk extends Stage {

    public StageJKiosk() {
        this.setTitle(Version.getVersion());
        if (Screen.getPrimary().getBounds().getWidth() > 1024) {
            setFullScreen(false);
        } else {
            setFullScreen(true);
        }
//        if (Version.isFullscreen()) {
//            setFullScreen(true);
//        } else {
//            setFullScreen(false);
//        }
    }

    public static double getSceneWidth() {
        double result = 0;
//        if (Version.isFullscreen()) {
//            result = Screen.getPrimary().getVisualBounds().getWidth();
//        } else {
            result = 1024;
//        }
        return result;
    }

    public static double getSceneHeight() {
        double result = 768;
//        if (Version.isFullscreen()) {
//            result = 768;
//        } else {
//            result = 768;
//        }
        return result;
    }
}
