package jkiosk3.sales.billpay.payat;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.payat.PayAtAccPayConfReq;
import aeonbillpayments.payat.PayAtAccPayConfResp;
import aeonbillpayments.payat.PayAtAccPayReq;
import aeonbillpayments.payat.PayAtFinePayResp;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.billpay.BPTransType;
import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.sales.billpay.BillPayUtilPayAt;
import jkiosk3.sales.billpay.BillPayUtilPayAt.PayAtTrafficFinePaymentResponse;
import jkiosk3.sales.billpay._common.BillPayEntry;
import jkiosk3.sales.billpay._common.BillPaymentSelect;
import jkiosk3.users.UserUtil;

public class InputPayAtTrafficFine extends Region {

    private BillPaymentConnection connection;
    private final BillPayProduct product;
    private final VBox vbContent;
    private BillPayEntry gridAcc;
    private GridPane gridAmtDetail;
    private JKioskNav nav;
    private String noticeNum;
    private double amountPaid;
    private JKTenderToggles tenders;
    private String tendered;
    private PayAtAccPayReq request1;
    private PayAtFinePayResp response1;
    private PayAtAccPayReq request2;
    private PayAtFinePayResp response2;
    private boolean showFavourites;
    private boolean showProductFavourite;

    public InputPayAtTrafficFine(BillPayProduct p, boolean isNFCFavourite, boolean isProductFavourite) {
        this.product = p;
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;

        vbContent = JKLayout.getVBoxContent (JKLayout.spNum);

        VBox vbLayout = JKLayout.getVBox (0, 5);
        vbLayout.getChildren ().add (getFineNumberEntry ());
        vbLayout.getChildren ().add (getNav ());

        getChildren ().add (vbLayout);
    }

    private VBox getFineNumberEntry() {

        ImageView img = BillPayUtilMisc.getImageViewBillPay ("prov_PayAt.png");

        gridAcc = new BillPayEntry ("Traffic Fine Payment", img, product, BillPayEntry.TYPE_TRAFFIC_FINE, showFavourites, showProductFavourite);
        gridAcc.getBtnDetail ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (vbContent.getChildren ().contains (gridAmtDetail)) {
                    vbContent.getChildren ().remove (gridAmtDetail);
                    getFineRequestQuery ();
                } else {
                    getFineRequestQuery ();
                }
            }
        });

        vbContent.getChildren ().add (gridAcc);

        return vbContent;
    }

    private GridPane getDetailAndAmountEntry() {

        GridPane gridDetail = BillPayUtilMisc.getGridBillPayDetail (response1.getFine ().getAmountDue (),
                response1.getConvenienceFee (), null, BPTransType.BILLPAY_PAYAT_TRAFFIC.getDisplayName ());
//                response1.getConvenienceFee(), null, BillPayUtilMisc.PAYAT_TRAFFIC_FINES);

        gridAmtDetail = JKLayout.getContentGridInner2Col (0.5, 0.5);

        gridAmtDetail.add (gridDetail, 0, 1, 2, 1);
        gridAmtDetail.addRow (3, getTenderTypes ());

        return gridAmtDetail;
    }

    private JKTenderToggles getTenderTypes() {
        tenders = new JKTenderToggles (SaleType.BILLPAYMENTS.getDisplay ());
        for (ToggleButton b : tenders.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(javafx.event.Event e) {
                    amountPaid = response1.getFine ().getAmountDue ();
                    tendered = tenders.getTenderTypeSelected ();
                    submitPayAtFinePaymentRollback (request1, response1, BillPayUtilMisc.CALL_BY_TENDER);
                }
            });
        }
        return tenders;
    }

    private JKioskNav getNav() {
        nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (gridAcc.getVbHead ().getChildren ().contains (gridAcc.getGridEnter ())) {
                    SceneSales.clearAndChangeContent (new BillPaymentSelect (
                            BillPayUtilMisc.TYPE_TRAFFIC_FINE + " Providers", BillPayUtilMisc.TYPE_TRAFFIC_FINE));
                } else {
                    SceneSales.clearAndChangeContent (new InputPayAtTrafficFine (product, showFavourites, showProductFavourite));
                }
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                BillPayUtilMisc.resetBillPayView ();
                if (request1 != null) {
                    submitPayAtFinePaymentRollback (request1, response1, BillPayUtilMisc.CALL_BY_CANCEL);
                }
            }
        });
        nav.getBtnNext ().setDisable (true);
        return nav;
    }

    private void showConfirmationSummary() {
        SummaryPayAtTrafficFine summary = new SummaryPayAtTrafficFine (request2, response2, tendered);

        JKiosk3.getMsgBox ().showMsgBox (BPTransType.BILLPAY_PAYAT_TRAFFIC.getDisplayName (), "Confirm all details before proceeding",
                summary, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        submitPayAtFinePaymentCommit (request2, response2);
                    }

                    @Override
                    public void onCancel() {
                        UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                        BillPayUtilMisc.resetBillPayView ();
                        submitPayAtFinePaymentRollback (request2, response2, BillPayUtilMisc.CALL_BY_CANCEL);
                    }
                });
    }

    //====================================
    // above - mostly view
    // below - mostly process
    //====================================
    private void getFineRequestQuery() {
        noticeNum = gridAcc.getAccountNumberConfirmed ();

        request1 = new PayAtAccPayReq ();
        request1.setProviderId (product.getProvId ());
        request1.setProductId (product.getProdId ());
        request1.setAccountNo (noticeNum);
        request1.setAmountDue (10.0);
        request1.setAdditionalAmount (0.0);
        request1.setPaymentRefNumber ("");
        request1.setStoreID ("");
        request1.setTillID ("");
        request1.setPaymentReceiptNo ("");
        request1.setEcho ("");
        request1.setRealTime (1);
        request1.setVerifyOnly (1);

        BillPayUtilPayAt.getPayAtTrafficFinePaymentResponse (request1, new PayAtTrafficFinePaymentResponse () {
            @Override
            public void payAtTrafficFinePayResp(BillPaymentConnection connect, PayAtFinePayResp resp) {
                connection = connect;

                if (resp.isSuccess ()) {
                    response1 = resp;
                    String vehicleReg = "";
                    if (resp.getFine ().getVehicleRegNumber () != null) {
                        vehicleReg = resp.getFine ().getVehicleRegNumber ();
                    } else {
                        vehicleReg = "Not Available";
                    }
                    gridAcc.getVbHead ().getChildren ().remove (gridAcc.getGridEnter ());
                    gridAcc.getVbHead ().getChildren ().add (gridAcc.getGridDetail (resp.getFine ().getNoticeNumber (),
                            vehicleReg));
                    gridAmtDetail = getDetailAndAmountEntry ();
                    vbContent.getChildren ().add (1, gridAmtDetail);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Detail Error", (!resp.getAeonErrorMessage ().isEmpty () ?
                            "A" + resp.getAeonErrorCode () + " - " + resp.getAeonErrorMessage () :
                            "B" + resp.getErrorCode () + " - " + resp.getErrorMessage ()), null);
                    BillPayUtilMisc.resetBillPayView ();
                }
            }
        });
    }

    private void getFineRequestPay() {
        request2 = new PayAtAccPayReq ();
        request2.setProviderId (product.getProvId ());
        request2.setProductId (product.getProdId ());
        request2.setAccountNo (noticeNum);
        request2.setAmountDue (amountPaid);
        request2.setAdditionalAmount (0.0);
        request2.setPaymentRefNumber ("");
        request2.setStoreID ("");
        request2.setTillID ("");
        request2.setPaymentReceiptNo ("");
        request2.setEcho ("");
        request2.setRealTime (1);
        request2.setVerifyOnly (0);

        BillPayUtilPayAt.getPayAtTrafficFinePaymentResponse (request2, new PayAtTrafficFinePaymentResponse () {
            @Override
            public void payAtTrafficFinePayResp(BillPaymentConnection connect, PayAtFinePayResp resp) {
                connection = connect;

                if (resp.isSuccess ()) {
                    response2 = resp;
                    showConfirmationSummary ();
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Detail Error",
                            (!resp.getAeonErrorMessage ().isEmpty () ?
                                    "A" + resp.getAeonErrorCode () + " - " + resp.getAeonErrorMessage () :
                                    "B" + resp.getErrorCode () + " - " + resp.getErrorMessage ()), null);
                    BillPayUtilMisc.resetBillPayView ();
                }
            }
        });
    }

    private void submitPayAtFinePaymentCommit(PayAtAccPayReq reqCommit, PayAtFinePayResp respCommit) {
        PayAtAccPayConfReq confCommit = new PayAtAccPayConfReq ();

        confCommit.setProviderId (reqCommit.getProviderId ());
        confCommit.setProductId (reqCommit.getProductId ());
        confCommit.setConfirmType ("commit");
        confCommit.setTrxId (respCommit.getTransRef ());
        confCommit.setAmountDue (reqCommit.getAmountDue ());
        confCommit.setAdditionalAmount (reqCommit.getAdditionalAmount ());
        confCommit.setEcho ("");
        confCommit.setTenderType (tendered);
        confCommit.setWantPrintJob (true);

        BillPayUtilPayAt.getPayAtBillPaymentConfirm (connection, confCommit, new BillPayUtilPayAt.PayAtBillPaymentConfirm () {
            @Override
            public void payAtBillPayConf(final PayAtAccPayConfResp confResp) {
                if (confResp.isSuccess ()) {
                    double amtTotal = amountPaid + response2.getConvenienceFee ();
                    String descript = product.getProdName () + " - " + request2.getAccountNo ();

                    SalesUtil.processBillPayment (BPTransType.BILLPAY_PAYAT_TRAFFIC.getDisplayName (), response2.getTransRef (), descript, amtTotal,
                            tendered, confResp.getConfEventDescription (), confResp.getPrintLines (), confResp.getMerchantPrintLines ());

                } else if (!confResp.getAeonErrorCode ().isEmpty ()) {
                    JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Payment Error", "A" + confResp.getAeonErrorCode () + "  -  " + confResp.getAeonErrorMessage (), null);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Payment Error", "B" + confResp.getErrorCode () + "  -  " + confResp.getErrorMessage (), null);
                }
                BillPayUtilMisc.resetBillPayView ();
            }
        });
    }

    private void submitPayAtFinePaymentRollback(PayAtAccPayReq reqRollback, PayAtFinePayResp respRollback, final String calledBy) {
        PayAtAccPayConfReq confRollback = new PayAtAccPayConfReq ();

        confRollback.setProviderId (reqRollback.getProviderId ());
        confRollback.setProductId (reqRollback.getProductId ());
        confRollback.setConfirmType ("rollback");
        confRollback.setTrxId (respRollback.getTransRef ());
        confRollback.setAmountDue (reqRollback.getAmountDue ());
        confRollback.setAdditionalAmount (reqRollback.getAdditionalAmount ());
        confRollback.setEcho ("");
        if (tendered != null) {
            confRollback.setTenderType (tendered);
        } else {
            confRollback.setTenderType ("cash");
        }

        BillPayUtilPayAt.getPayAtBillPaymentConfirm (connection, confRollback, new BillPayUtilPayAt.PayAtBillPaymentConfirm () {
            @Override
            public void payAtBillPayConf(PayAtAccPayConfResp confResp) {
                if (confResp.isSuccess ()) {
                    switch (calledBy) {
                        case BillPayUtilMisc.CALL_BY_CANCEL:
                            JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Payment", "Transaction cancelled by User", null);
                            BillPayUtilMisc.resetBillPayView ();
                            break;
                        case BillPayUtilMisc.CALL_BY_TENDER:
                            getFineRequestPay ();
                            break;
                        default:
                            JKiosk3.getMsgBox ().showMsgBox ("Pay@ Traffic Fine Payment", "Unable to determine source of reset request", null);
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Traffic Fine Payment Rollback Error", (!confResp.getAeonErrorMessage ().isEmpty () ?
                            "A" + confResp.getAeonErrorCode () + " - " + confResp.getAeonErrorMessage () :
                            "B" + confResp.getErrorCode () + " - " + confResp.getErrorMessage ()), null);
                }
            }
        });
    }

//    private BillPaymentConnection connection;
//    private final BillPayProduct product;
//    private final VBox vbContent;
//    private BillPayEntry gridAcc;
//    private GridPane gridAmtDetail;
//    private JKioskNav nav;
//    private String noticeNum;
//    private double amountPaid;
//    private JKTenderToggles tenders;
//    private String tendered;
//    private PayAtAccPayReq request1;
//    private PayAtFinePayResp response1;
//    private PayAtAccPayReq request2;
//    private PayAtFinePayResp response2;
//    private boolean showFavourites;
//
//    public InputPayAtTrafficFine(BillPayProduct p, boolean isFavourite) {
//        this.product = p;
//        this.showFavourites = isFavourite;
//
//        vbContent = JKLayout.getVBoxContent(JKLayout.spNum);
//
//        VBox vbLayout = JKLayout.getVBox(0, 5);
//        vbLayout.getChildren().add(getFineNumberEntry());
//        vbLayout.getChildren().add(getNav());
//
//        getChildren().add(vbLayout);
//    }
//
//    private VBox getFineNumberEntry() {
//
//        ImageView img = BillPayUtilMisc.getImageViewBillPay("prov_PayAt.png");
//
//        gridAcc = new BillPayEntry("Traffic Fine Payment", img, product, BillPayEntry.TYPE_TRAFFIC_FINE, showFavourites);
//        gridAcc.getBtnDetail().setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                if (vbContent.getChildren().contains(gridAmtDetail)) {
//                    vbContent.getChildren().remove(gridAmtDetail);
//                    getFineRequestQuery();
//                } else {
//                    getFineRequestQuery();
//                }
//            }
//        });
//
//        vbContent.getChildren().add(gridAcc);
//
//        return vbContent;
//    }
//
//    private GridPane getDetailAndAmountEntry() {
//
//        GridPane gridDetail = BillPayUtilMisc.getGridBillPayDetail(response1.getFine().getAmountDue(),
//                response1.getConvenienceFee(), null, BPTransType.BILLPAY_PAYAT_TRAFFIC.getDisplayName());
////                response1.getConvenienceFee(), null, BillPayUtilMisc.PAYAT_TRAFFIC_FINES);
//
//        gridAmtDetail = JKLayout.getContentGridInner2Col(0.5, 0.5);
//
//        gridAmtDetail.add(gridDetail, 0, 1, 2, 1);
//        gridAmtDetail.addRow(3, getTenderTypes());
//
//        return gridAmtDetail;
//    }
//
//    private JKTenderToggles getTenderTypes() {
//        tenders = new JKTenderToggles(SaleType.BILLPAYMENTS.getDisplay());
//        for (ToggleButton b : tenders.getTenderToggleList()) {
//            b.setOnMouseReleased(new EventHandler() {
//                @Override
//                public void handle(javafx.event.Event e) {
//                    amountPaid = response1.getFine().getAmountDue();
//                    tendered = tenders.getTenderTypeSelected();
//                    submitPayAtFinePaymentRollback(request1, response1, BillPayUtilMisc.CALL_BY_TENDER);
//                }
//            });
//        }
//        return tenders;
//    }
//
//    private JKioskNav getNav() {
//        nav = new JKioskNav();
//        nav.getBtnBack().setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                if (gridAcc.getVbHead().getChildren().contains(gridAcc.getGridEnter())) {
//                    SceneSales.clearAndChangeContent(new BillPaymentSelect(
//                            BillPayUtilMisc.TYPE_TRAFFIC_FINE + " Providers", BillPayUtilMisc.TYPE_TRAFFIC_FINE));
//                } else {
//                    SceneSales.clearAndChangeContent(new InputPayAtTrafficFine(product, showFavourites));
//                }
//            }
//        });
//        nav.getBtnCancel().setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
//                BillPayUtilMisc.resetBillPayView();
//                if (request1 != null) {
//                    submitPayAtFinePaymentRollback(request1, response1, BillPayUtilMisc.CALL_BY_CANCEL);
//                }
//            }
//        });
//        nav.getBtnNext().setDisable(true);
//        return nav;
//    }
//
//    private void showConfirmationSummary() {
//        SummaryPayAtTrafficFine summary = new SummaryPayAtTrafficFine(request2, response2, tendered);
//
////        JKiosk3.getMsgBox().showMsgBox(BillPayUtilMisc.PAYAT_TRAFFIC_FINES, "Confirm all details before proceeding",
//        JKiosk3.getMsgBox().showMsgBox(BPTransType.BILLPAY_PAYAT_TRAFFIC.getDisplayName(), "Confirm all details before proceeding",
//                summary, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult() {
//                    @Override
//                    public void onOk() {
//                        submitPayAtFinePaymentCommit(request2, response2);
//                    }
//
//                    @Override
//                    public void onCancel() {
//                        UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
//                        BillPayUtilMisc.resetBillPayView();
//                        submitPayAtFinePaymentRollback(request2, response2, BillPayUtilMisc.CALL_BY_CANCEL);
//                    }
//                });
//    }
//
//    //====================================
//    // above - mostly view
//    // below - mostly process
//    //====================================
//    private void getFineRequestQuery() {
//        noticeNum = gridAcc.getAccountNumberConfirmed();
//
//        request1 = new PayAtAccPayReq();
//        request1.setProviderId(product.getProvId());
//        request1.setProductId(product.getProdId());
//        request1.setAccountNo(noticeNum);
//        request1.setAmountDue(10.0);
//        request1.setAdditionalAmount(0.0);
//        request1.setPaymentRefNumber("");
//        request1.setStoreID("");
//        request1.setTillID("");
//        request1.setPaymentReceiptNo("");
//        request1.setEcho("");
//        request1.setRealTime(1);
//        request1.setVerifyOnly(1);
//
//        BillPayUtilPayAt.getPayAtTrafficFinePaymentResponse(request1, new PayAtTrafficFinePaymentResponse() {
//            @Override
//            public void payAtTrafficFinePayResp(BillPaymentConnection connect, PayAtFinePayResp resp) {
//                connection = connect;
//
//                if (resp.isSuccess()) {
//                    response1 = resp;
//                    String vehicleReg = "";
//                    if (resp.getFine().getVehicleRegNumber() != null) {
//                        vehicleReg = resp.getFine().getVehicleRegNumber();
//                    } else {
//                        vehicleReg = "Not Available";
//                    }
//                    gridAcc.getVbHead().getChildren().remove(gridAcc.getGridEnter());
//                    gridAcc.getVbHead().getChildren().add(gridAcc.getGridDetail(resp.getFine().getNoticeNumber(),
//                            vehicleReg));
//                    gridAmtDetail = getDetailAndAmountEntry();
//                    vbContent.getChildren().add(1, gridAmtDetail);
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Traffic Fine Detail Error",
//                            resp.getErrorCode() + " - " + resp.getErrorMessage(), null);
//                    BillPayUtilMisc.resetBillPayView();
//                }
//            }
//        });
//    }
//
//    private void getFineRequestPay() {
//        request2 = new PayAtAccPayReq();
//        request2.setProviderId(product.getProvId());
//        request2.setProductId(product.getProdId());
//        request2.setAccountNo(noticeNum);
//        request2.setAmountDue(amountPaid);
//        request2.setAdditionalAmount(0.0);
//        request2.setPaymentRefNumber("");
//        request2.setStoreID("");
//        request2.setTillID("");
//        request2.setPaymentReceiptNo("");
//        request2.setEcho("");
//        request2.setRealTime(1);
//        request2.setVerifyOnly(0);
//
//        BillPayUtilPayAt.getPayAtTrafficFinePaymentResponse(request2, new PayAtTrafficFinePaymentResponse() {
//            @Override
//            public void payAtTrafficFinePayResp(BillPaymentConnection connect, PayAtFinePayResp resp) {
//                connection = connect;
//
//                if (resp.isSuccess()) {
//                    response2 = resp;
//                    showConfirmationSummary();
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Traffic Fine Detail Error",
//                            resp.getErrorCode() + " - " + resp.getErrorMessage(), null);
//                    BillPayUtilMisc.resetBillPayView();
//                }
//            }
//        });
//    }
//
//    private void submitPayAtFinePaymentCommit(PayAtAccPayReq reqCommit, PayAtFinePayResp respCommit) {
//        PayAtAccPayConfReq confCommit = new PayAtAccPayConfReq();
//
//        confCommit.setProviderId(reqCommit.getProviderId());
//        confCommit.setProductId(reqCommit.getProductId());
//        confCommit.setConfirmType("commit");
//        confCommit.setTrxId(respCommit.getTransRef());
//        confCommit.setAmountDue(reqCommit.getAmountDue());
//        confCommit.setAdditionalAmount(reqCommit.getAdditionalAmount());
//        confCommit.setEcho("");
//        confCommit.setTenderType(tendered);
//        confCommit.setWantPrintJob(true);
//
//        BillPayUtilPayAt.getPayAtBillPaymentConfirm(connection, confCommit, new BillPayUtilPayAt.PayAtBillPaymentConfirm() {
//            @Override
//            public void payAtBillPayConf(final PayAtAccPayConfResp confResp) {
//                if (confResp.isSuccess()) {
//                    double amtTotal = amountPaid + response2.getConvenienceFee();
//                    String descript = product.getProdName() + " - " + request2.getAccountNo();
//
////                    SalesUtil.processBillPayment(BillPayUtilMisc.PAYAT_TRAFFIC_FINES, response2.getTransRef(), descript, amtTotal,
//                    SalesUtil.processBillPayment(BPTransType.BILLPAY_PAYAT_TRAFFIC.getDisplayName(), response2.getTransRef(), descript, amtTotal,
//                            tendered, confResp.getConfEventDescription(), confResp.getPrintLines(), confResp.getMerchantPrintLines());
//
//                } else if (confResp.getErrorCode().equals("1995")) {
//                    JKiosk3.getMsgBox().showMsgBox("Traffic Fine Payment Error", confResp.getErrorMessage(), null);
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Traffic Fine Payment", confResp.getErrorMessage(), null);
//                }
//                BillPayUtilMisc.resetBillPayView();
//            }
//        });
//    }
//
//    private void submitPayAtFinePaymentRollback(PayAtAccPayReq reqRollback, PayAtFinePayResp respRollback, final String calledBy) {
//        PayAtAccPayConfReq confRollback = new PayAtAccPayConfReq();
//
//        confRollback.setProviderId(reqRollback.getProviderId());
//        confRollback.setProductId(reqRollback.getProductId());
//        confRollback.setConfirmType("rollback");
//        confRollback.setTrxId(respRollback.getTransRef());
//        confRollback.setAmountDue(reqRollback.getAmountDue());
//        confRollback.setAdditionalAmount(reqRollback.getAdditionalAmount());
//        confRollback.setEcho("");
//        if (tendered != null) {
//            confRollback.setTenderType(tendered);
//        } else {
//            confRollback.setTenderType("cash");
//        }
//
//        BillPayUtilPayAt.getPayAtBillPaymentConfirm(connection, confRollback, new BillPayUtilPayAt.PayAtBillPaymentConfirm() {
//            @Override
//            public void payAtBillPayConf(PayAtAccPayConfResp confResp) {
//                if (confResp.isSuccess()) {
//                    switch (calledBy) {
//                        case BillPayUtilMisc.CALL_BY_CANCEL:
//                            JKiosk3.getMsgBox().showMsgBox("Traffic Fine Payment", "Transaction cancelled by User", null);
//                            BillPayUtilMisc.resetBillPayView();
//                            break;
//                        case BillPayUtilMisc.CALL_BY_TENDER:
//                            getFineRequestPay();
//                            break;
//                        default:
//                            JKiosk3.getMsgBox().showMsgBox("Pay@ Traffic Fine Payment", "Unable to determine source of reset request", null);
//                    }
//                } else {
//                    JKiosk3.getMsgBox().showMsgBox("Traffic Fine Payment Rollback Error",
//                            confResp.getErrorCode() + confResp.getErrorMessage(), null);
//                }
//            }
//        });
//    }
}
