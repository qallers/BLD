package jkiosk3.sales.electricity;

/**
 *
 * 
 */
public abstract class ElecEnterMeterResult {

    public abstract void onDone();
}
