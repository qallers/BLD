package jkiosk3.sales.electricity.eskom;

import aeonelectricity.ElectricityCharge;
import aeonelectricity.ElectricityConfirmation;
import aeonelectricity.ElectricityConnection;
import aeonelectricity.ElectricityMeter;
import aeonelectricity.ElectricityToken;
import aeonelectricity.ElectricityVoucher;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.printing.MagCardData;
import jkiosk3.printing.PrintUtil;
import jkiosk3.reports.SceneReportControls;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.electricity.ElecConfirm;
import jkiosk3.sales.electricity.ElecEnterMeter;
import jkiosk3.sales.electricity.ElecEnterMeterResult;
import jkiosk3.sales.electricity.ElecShareBtnsLessMore;
import jkiosk3.sales.electricity.ElectricityProvider;
import jkiosk3.sales.electricity.ElectricityUtil;
import jkiosk3.sales.electricity.ElectricityUtil.EskomReprintListResult;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.users.UserUtil;

/**
 *
 */
public class ElecReprintList extends Region {

    private ElectricityConfirmation confirmation;
    private final ElectricityProvider provider;
    private final String transType;
    private String meterNum;
    private List<ElectricityVoucher> listReprints;
    private ElectricityVoucher selectedVoucher;
    private ElecEnterMeter gMeter;
    private ElecShareBtnsLessMore btnsLessMore;
    private final VBox vbReprints;
    private VBox vbRadios;

    public ElecReprintList(ElectricityProvider selectedProvider) {
        this.provider = selectedProvider;
        transType = provider.getTransactionType ();
        vbReprints = JKLayout.getVBox (0, JKLayout.spNum);
        getChildren ().add (getReprintListLayout ());
    }

    private VBox getReprintListLayout() {
        gMeter = new ElecEnterMeter (provider, ElectricityUtil.ELEC_REPRINT_LIST, new ElecEnterMeterResult () {
            @Override
            public void onDone() {
                if (gMeter.isMagEntry ()) {
                    System.out.println ("onDone : meter number entered : " + gMeter.getMeterNum ());
                    System.out.println ("onDone : did we read mag card? : " + gMeter.isMagEntry ());
                }
            }
        });
        vbReprints.getChildren ().addAll (gMeter, getElecSaleCtrls ());
        return vbReprints;
    }

    private ElecShareBtnsLessMore getElecSaleCtrls() {
        btnsLessMore = new ElecShareBtnsLessMore ();

        btnsLessMore.getBtnAccept ().setDisable (false);
        btnsLessMore.getBtnAccept ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                if (validateInput ()) {
                    getMeterConfirmation ();
                }
            }
        });
        btnsLessMore.getBtnCancel ().setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event arg0) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                ElectricityUtil.resetElectricity ();
            }
        });
        return btnsLessMore;
    }

    private void getMeterConfirmation() {
        final ElectricityMeter meter = new ElectricityMeter ();
        if (gMeter.isMagEntry ()) {
            meter.setTrack2data (meterNum);
        } else {
            meter.setMeterNum (meterNum);
        }

        ElectricityUtil.getElectricityConfirmation (transType, "OnlineReprint", meter, 0, new ElectricityUtil.ElectricityConfirm () {
            @Override
            public void electricityConfirm(ElectricityConnection connect, final ElectricityConfirmation confirm) {
                if (confirm.isSuccess ()) {
                    gMeter.getTxtMeterNum ().setDisable (true);
                    btnsLessMore.getBtnAccept ().setDisable (true);
                    confirmation = confirm;

                    ElecConfirm confirmGrid = new ElecConfirm (confirmation, meter, 0, ElectricityUtil.ELEC_REPRINT);

                    JKiosk3.getMsgBox ().showMsgBox ("Electricity Meter Confirmation",
                            "Please Confirm Meter Number Before Continuing", confirmGrid,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    // return to view, populate List of Reprints
                                    vbReprints.getChildren ().add (getReprintReportGroup ());
                                    vbReprints.getChildren ().add (getPrintControl ());
                                    getReprintListForMeter ();
                                }

                                @Override
                                public void onCancel() {
                                    gMeter.getTxtMeterNum ().setDisable (false);
                                    btnsLessMore.getBtnAccept ().setDisable (false);
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Unable to Confirm", !confirm.getAeonErrorText ().isEmpty () ?
                                    "A" + confirm.getAeonErrorCode () + " - " + confirm.getAeonErrorText () :
                                    "B" + confirm.getErrorCode () + " - " + confirm.getErrorText (),
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    ElectricityUtil.resetElectricity ();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });
    }

    private void getReprintListForMeter() {
        ElectricityUtil.getElectricityVoucherReprintList (transType, meterNum, "ref", new EskomReprintListResult () {

            @Override
            public void eskomReprintListResult(List<ElectricityVoucher> listReprint) {
                if (!listReprint.isEmpty ()) {
                    listReprints = listReprint;
                    vbRadios.getChildren ().addAll (getReprintRadios (listReprints));
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Electricity Reprint List", "No Reprints found for Meter Number", null);
                }
            }
        });
    }

    private VBox getReprintReportGroup() {
        Label lblReprintSelect = JKText.getLblContentSubHead ("Select Voucher to Reprint");

        vbRadios = JKLayout.getVBoxLeft (15, 15);

        StackPane stackRadios = new StackPane ();
        stackRadios.setMaxWidth (JKLayout.contentW);
        stackRadios.setMaxHeight (250);
        stackRadios.setMinHeight (250);
        stackRadios.getChildren ().addAll (vbRadios);

        VBox vb = JKLayout.getVBoxContent (JKLayout.spNum);
        vb.setMaxWidth (JKLayout.contentW);
        vb.getChildren ().addAll (lblReprintSelect, JKNode.createContentSep (), stackRadios);
        return vb;
    }

    private List<Node> getReprintRadios(final List<ElectricityVoucher> reprintList) {
        List<Node> listRadios = new ArrayList<> ();

        ToggleGroup tgReprint = new ToggleGroup ();

        for (final ElectricityVoucher r : reprintList) {
            String amtDisplay = "R " + new DecimalFormat ("#.00").format (getVoucherTotalAmount (r));
            String reprintDate = new SimpleDateFormat ("yyyy-MM-dd HH:mm").format (r.getDate ());
            String reprintMeterNum = r.getMeter ().getMeterNum ();
            String reprintReceiptNum = r.getReceiptNumber ();
            final RadioButton btnReprint = new RadioButton (amtDisplay + " - " + reprintDate + " - "
                    + reprintMeterNum + " - " + reprintReceiptNum);
            btnReprint.setStyle ("-fx-font-size: 18px; -fx-font-weight: bold;");
            btnReprint.setToggleGroup (tgReprint);
            btnReprint.setOnMouseReleased (new EventHandler () {
                @Override
                public void handle(Event e) {
                    if (btnReprint.isSelected ()) {
                        selectedVoucher = r;
                    }
                }
            });
            listRadios.add (btnReprint);
        }
        return listRadios;
    }

    private double getVoucherTotalAmount(ElectricityVoucher voucher) {
        double totalAmount = 0d;
        double debts = 0d;
        double fixed = 0d;
        double tokens = 0d;
        for (ElectricityCharge debt : voucher.getDebts ()) {
            debts += debt.getDebtAmount ();
        }
        for (ElectricityCharge fix : voucher.getFixedCosts ()) {
            fixed += fix.getFixedCostAmount ();
        }
        for (ElectricityToken token : voucher.getTokens ()) {
            tokens += token.getTokenAmount ();
        }
        totalAmount = debts + fixed + tokens;
        return totalAmount;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls () {
            @Override
            public void onClickPrint() {
                if (selectedVoucher != null) {
                    reprintSelectedVoucher ();
                } else {
                    selectedVoucher = listReprints.get (0);
                    reprintSelectedVoucher ();
                }
                ElectricityUtil.resetElectricity ();
            }
        };
    }

    private void reprintSelectedVoucher() {
        final List<MagCardData> magList = ElectricityUtil.getMagCardTokens (selectedVoucher);
        if (JKPrintOptions.getPrintOptions ().isPrintPreview ()) {
            JKiosk3.getPrintPreview ().showPrintPreview ("Electricity Voucher Reprint", selectedVoucher.getPrintLines (),
                    PrintPreview.PRN_OK_CANCEL, new PrintPreviewResult () {
                        @Override
                        public void onOk() {
                            PrintUtil.writeMagCardTokens (magList, null);
                        }

                        @Override
                        public void onCancel() {
                            //
                        }
                    });
        } else {
            PrintUtil.sendToPrinter (selectedVoucher.getPrintLines ());
            PrintUtil.writeMagCardTokens (magList, null);
        }
    }

    private boolean validateInput() {
        meterNum = gMeter.getMeterNum ().trim ();
        if (meterNum.equals ("") || meterNum == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Meter Number", "Meter Number cannot be blank.\n"
                    + "Please enter Meter Number.", null);
            return false;
        }
        return true;
    }

//    private List<ElectricityVoucher> getTestList() {
//        List<ElectricityVoucher> list = new ArrayList<>();
//
//        ElectricityVoucher ev1 = new ElectricityVoucher();
//        ElectricityMeter m1 = new ElectricityMeter();
//        m1.setMeterNum("12345789");
//        ev1.setDate(new Date());
//        ev1.setMeter(m1);
//        list.add(ev1);
//
//        ElectricityVoucher ev2 = new ElectricityVoucher();
//        ElectricityMeter m2 = new ElectricityMeter();
//        m2.setMeterNum("78946123");
//        ev2.setDate(new Date());
//        ev2.setMeter(m2);
//        list.add(ev2);
//
//        return list;
//    }
}
