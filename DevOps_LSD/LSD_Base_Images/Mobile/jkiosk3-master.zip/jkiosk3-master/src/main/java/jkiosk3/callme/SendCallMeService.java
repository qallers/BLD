package jkiosk3.callme;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import jkiosk3.JK3Config;
import jkiosk3.store.JKSystem;
import org.json.JSONObject;
import sun.misc.BASE64Encoder;

import java.util.logging.Logger;

public class SendCallMeService {
    private final static Logger logger = Logger.getLogger(SendCallMeService.class.getName());
    private String username;
    private String password;
    private String url;

    public SendCallMeService() {
        username = "bludroid";
        password = "7m2hu88qgpeb01ir89576rbq9o";
        url = JK3Config.getLoyaltyPath() + "/customer/support/help/v1/callme/bludroid";

        if (url.contains(".live.")) {
            logger.info("using PROD credentials");
            password = "437s5j5o6ac67qkjvamfiqo3hq";
        }
    }

    public String sendCallmeMessage(String contactNumber, String category){
        String authString = username + ":" + password;
        String authStringEnc = new BASE64Encoder().encode(authString.getBytes());
        Client restClient = Client.create();
        WebResource webResource = restClient.resource(url);
        int currentDeviceId = JKSystem.getSystemConfig().getDeviceId();

        String deviceSerialNumber = JKSystem.getSystemConfig().getSerial();
        String message = String.format("I have %s.", category.toLowerCase());

        String input = String.format("{\"deviceId\":\"%s\", \"deviceSerialNumber\":\"%s\", \"telephone\":\"%s\", \"message\":\"%s\"}",
                currentDeviceId, deviceSerialNumber, contactNumber, message);

        ClientResponse resp = webResource/*.accept("Content-Type", "text/plain", "application/json; charset=utf8")*/
                .type( "application/json; charset=utf8")
                .header("Authorization", "Basic " + authStringEnc)
                .post(ClientResponse.class, input);


        String response = "";

        if(resp.getStatus() == 202){
            JSONObject jsonObject = new JSONObject (resp.getEntity(String.class));
            response = jsonObject.get("message").toString();
        } else {
            logger.info("Unable to connect to the server........" + DownloadCategoryService.class.getName());
        }

        return response;
    }
}
