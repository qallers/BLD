package jkiosk3._components.update;

import java.io.File;
import java.util.logging.Logger;

import javafx.scene.Scene;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import javax.swing.JOptionPane;

import jkiosk3.JK3Config;
import jkiosk3._common.ResultCallback;

public class StageUpdates extends Stage {

    private final static Logger logger = Logger.getLogger(StageUpdates.class.getName());

    public final static String DOWNLOAD_LIB_FILES = "essential files";
    public final static String DOWNLOAD_APPLICATION_UPDATE = "application update";
    public final static String DOWNLOAD_AUTO_UPDATER = "auto-updater";
    public final static String DOWNLOAD_JK_FONTS = "fonts";
    public final static String DOWNLOAD_JK_IMAGES = "images";
    public final static String DOWNLOAD_PROV_LOGOS = "provider logos";
    public final static String DOWNLOAD_BANKING = "banking details";
    public final static String DOWNLOAD_BRANDING = "branding";
//    public final static String DOWNLOAD_BUS_CARRIER_DATA = "bus carrier data";
    public final static String DOWNLOAD_PRINT_CODES = "cash drawer codes";
    //
    public static String downloadConfig = "config settings";

    private StageDownload stageDownload;
    private static DownloadRegion rootRegion;
    private final ResultCallback finalResult;

    public StageUpdates(ResultCallback finalResult) {
        this.finalResult = finalResult;

        loadJKDownloadStage();
    }

    private void loadJKDownloadStage() {

        stageDownload = new StageDownload();

        StackPane root = new StackPane();
        root.getStyleClass().add("stackDownload");

        Scene scene = new Scene(root, StageDownload.STAGE_WIDTH, StageDownload.STAGE_HEIGHT);

        scene.getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/default.css").toExternalForm());
        scene.getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/stageupdate.css").toExternalForm());

        root.setPrefSize(scene.getWidth(), scene.getHeight());

        stageDownload.setScene(scene);
        stageDownload.show();

        rootRegion = new DownloadRegion();

        root.getChildren().add(rootRegion);

        downloadConfig();
    }

    private void downloadConfig() {
        downloadConfig = "config settings";

        changeScene(new JKDownloadRegion(new DownloadProperties(downloadConfig, JK3Config.getFileUpdatePath() + JK3Config.CONFIG_FILENAME,
                JK3Config.getAppInstallPath() + JK3Config.CONFIG_FILENAME, null), new ResultCallback() {

            @Override
            public void onResult(boolean result) {
                if (result) {
                    logger.info("found config file, about to build file paths...");
                    if (JK3Config.buildFilePaths()) {
                        logger.info("  > > > > > File paths successfully created");
//                        downloadLibFiles();
                        downloadAutoUpdater();
                    } else {
                        logger.info("  > > > failed to build file paths.");
                    }
                } else {
                    logger.info(("download error - ").concat(JK3Config.CONFIG_FILENAME));
                    finalResult.onResult(result);
                    JOptionPane.showMessageDialog(null, "Unable to load config file.  Application will not start.", "JKiosk Start",
                            JOptionPane.ERROR_MESSAGE);
                    System.exit(0);
                }
            }
        }));
    }

//    private void downloadLibFiles() {
//        changeScene(new JKDownloadRegion(new DownloadProperties(DOWNLOAD_LIB_FILES, JK3Config.getFileUpdatePath() + JK3Config.LIST_LIB_FILES,
//                JK3Config.getAppInstallPath() + JK3Config.LIST_LIB_FILES, null), new ResultCallback() {
//            @Override
//            public void onResult(boolean result) {
//                if (result) {
//                    LibFilesUpdate libFilesUpdate = new LibFilesUpdate();
//                    if (libFilesUpdate.doesLibFolderExist()) {
//                        if (libFilesUpdate.updateLibFiles()) {
//                            logger.info(("All lib files downloaded, can continue"));
//                            downloadAutoUpdater();
//                        } else {
//                            logger.info("Lib files failed to download, app will not run - exiting");
//                            System.exit(0);
//                        }
//                    }
//                } else {
//                    logger.info("Failed to download lib file list, app will not run - exiting");
//                    System.exit(0);
//                }
//            }
//        }));
//    }

    private void downloadAutoUpdater() {
        changeScene(new JKDownloadRegion(new DownloadProperties(DOWNLOAD_AUTO_UPDATER, JK3Config.getAutoUpdaterPath(),
                JK3Config.getAutoUpdater(), null),
                new ResultCallback() {

                    @Override
                    public void onResult(boolean result) {
                        if (result) {
                            downloadFonts();
                        } else {
                            logger.info(("failed to download : ").concat(DOWNLOAD_AUTO_UPDATER));
                            downloadFonts();
                        }
                    }
                }));
    }

    private void downloadFonts() {
        changeScene(new JKDownloadRegion(new DownloadProperties(DOWNLOAD_JK_FONTS, JK3Config.getFonts(),
                JK3Config.getMediaFonts() + JK3Config.getMediaFontsZip(), JK3Config.getMediaFonts()),
                new ResultCallback() {

                    @Override
                    public void onResult(boolean result) {
                        if (result) {
                            downloadImages();
                        } else {
                            logger.info(("failed to download : ").concat(DOWNLOAD_JK_FONTS));
                            downloadImages();
                        }
                    }
                }));
    }

    private void downloadImages() {
        changeScene(new JKDownloadRegion(new DownloadProperties(DOWNLOAD_JK_IMAGES, JK3Config.getImages(),
                JK3Config.getMediaImages() + JK3Config.getMediaImagesZip(), JK3Config.getMediaImages()),
                new ResultCallback() {

                    @Override
                    public void onResult(boolean result) {
                        if (result) {
                            downloadProviderLogos();
                        } else {
                            logger.info(("failed to download : ").concat(DOWNLOAD_JK_IMAGES));
                            downloadProviderLogos();
                        }
                    }
                }));
    }

    private void downloadProviderLogos() {
        changeScene(new JKDownloadRegion(new DownloadProperties(DOWNLOAD_PROV_LOGOS, JK3Config.getLogos(),
                JK3Config.getMediaLogos() + JK3Config.getMediaLogosZip(), JK3Config.getMediaLogos()),
                new ResultCallback() {

                    @Override
                    public void onResult(boolean result) {
                        if (result) {
                            downloadBankingDetails();
                        } else {
                            logger.info(("failed to download : ").concat(DOWNLOAD_PROV_LOGOS));
                            downloadBankingDetails();
                        }
                    }
                }));
    }

    private void downloadBankingDetails() {
        changeScene(new JKDownloadRegion(new DownloadProperties(DOWNLOAD_BANKING, JK3Config.getBankAccounts(),
                JK3Config.getMediaBankingFile(), null),
                new ResultCallback() {

                    @Override
                    public void onResult(boolean result) {
                        if (result) {
                            downloadBranding();
                        } else {
                            logger.info(("failed to download : ").concat(DOWNLOAD_BANKING));
                            downloadBranding();
                        }
                    }
                }));
    }

    private void downloadBranding() {
        changeScene(new JKDownloadRegion(new DownloadProperties(DOWNLOAD_BRANDING, JK3Config.getBranding(),
                JK3Config.getMediaBranding() + JK3Config.getMediaBrandingZip(), JK3Config.getMediaBranding()),
                new ResultCallback() {

                    @Override
                    public void onResult(boolean result) {
                        if (result) {
//                            downloadBusCarrierData();
                            downloadPrinterData();
//                    next download...
                        } else {
                            logger.info(("failed to download : ").concat(DOWNLOAD_BRANDING));
//                            downloadBusCarrierData();
                            downloadPrinterData();
                        }
                    }
                }));
    }

    /*
     At the end of the FINAL download, return the final result to the calling class and close the Stage.
     */
    // 2019-11-12  -  No longer needed, was used for Carma Carriers.
    // Has been replaced by Universal Bus project (Coach Tickets in Ticketing menu).
//    private void downloadBusCarrierData() {
//        changeScene(new JKDownloadRegion(new DownloadProperties(DOWNLOAD_BUS_CARRIER_DATA, JK3Config.getBusCarrierData(),
//                JK3Config.getMediaBusCarrierData(), null), new ResultCallback() {
//            @Override
//            public void onResult(boolean result) {
//                if (result) {
//                    // next download...
//                    downloadPrinterData();
//                } else {
////                    finalResult.onResult(result);
//                    logger.info(("failed to download : ").concat(DOWNLOAD_BUS_CARRIER_DATA));
//                    // next download...
//                    downloadPrinterData();
//                }
////                finalResult.onResult(result);
////                stageDownload.close();
//            }
//        }));
//    }

    /*
     At the end of the FINAL download, return the final result to the calling class and close the Stage.
     */
    private void downloadPrinterData() {
         String INSTALL_PATH_PRINT = "printer\\";
        // if (HttpUtils.httpDownload(JK3Config.getPrintcodesDownloadPath(), INSTALL_PATH_PRINT + JK3Config.getPrintcodesFile(), true, null)) {
        //
        changeScene(new JKDownloadRegion(new DownloadProperties(DOWNLOAD_PRINT_CODES, JK3Config.getPrintcodesDownloadPath(),
                INSTALL_PATH_PRINT + JK3Config.getPrintcodesFile(), null), new ResultCallback() {
            @Override
            public void onResult(boolean result) {
                if (result) {
                    // next download...
                } else {
                    finalResult.onResult(result);
                    logger.info(("failed to download : ").concat(DOWNLOAD_PRINT_CODES));
                    // next download...
                }
                finalResult.onResult(result);
                stageDownload.close();
            }
        }));
    }

    public static void changeScene(Region newScene) {
        rootRegion.setContent(newScene);
    }
}
