package jkiosk3.store.cache;

import aeonbillpayments.Provider;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author valeriew
 */
public class ListBillPaymentProviders implements Serializable {
    
    // L(ist)  = 12 (1 + 2 = 3)
    // B(ill) = 2
    // P(ayment) = 16 (1 + 6 = 7)
    // P(roviders) = 16 (1 + 6 = 7)
    // (above details are used for serialVersionUID)
    private final static long serialVersionUID = 993277L;
    private final List<Provider> listBillPayProviders = new ArrayList<>();

    public List<Provider> getListBillPayProviders() {
        return listBillPayProviders;
    }
}
