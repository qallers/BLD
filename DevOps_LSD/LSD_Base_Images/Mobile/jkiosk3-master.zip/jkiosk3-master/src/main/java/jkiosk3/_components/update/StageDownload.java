package jkiosk3._components.update;

import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author valeriew
 */
public class StageDownload extends Stage {

    public final static double STAGE_WIDTH = 550;
    public final static double STAGE_HEIGHT = 550;

    public StageDownload() {
        this.setTitle("Updating files");
        this.initStyle(StageStyle.TRANSPARENT);
        this.initModality(Modality.APPLICATION_MODAL);
        setFullScreen(false);
        this.setWidth(STAGE_WIDTH);
        this.setHeight(STAGE_HEIGHT);
    }
}
