package jkiosk3.sales.topups.airtime;

import aeonairtime.RechargePlusTransaction;
import aeontopup.TopupAirtimeReq;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import jkiosk3._common.JKNode;
import jkiosk3._components.KeyboardResult;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.sales._favourites.nfc.NFCUtilFav;
import jkiosk3.sales._recharge_plus.RechargePlusUtil;
import jkiosk3.sales.topups.MenuTopups;
import jkiosk3.sales.topups.TopupProvider;
import jkiosk3.sales.topups.AirtimeUtil;
import aeontopup.TopupVoucher;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.QuickAmounts;
import jkiosk3.sales._common.QuickAmountsResult;
import jkiosk3.sales.topups.AirtimeUtil.TopupConfirmResult;
import jkiosk3.sales.topups.TopupSale;
import jkiosk3.store.JKOptions;
import jkiosk3.users.CurrentUser;

import java.util.List;

public class AirtimeRecharge extends Region {

    private final TopupProvider provider;
    private String cellNum;
    private double amount;
    private TextField txtCell;
    private TextField txtCellConfirm;
    private ComboBox cbCell;
    private VBox vbEntry;
    private QuickAmounts qAmts;
    private boolean showRechargePlus = false;
    private boolean isRechargePlus = false;
    private boolean showFavourites;
    private boolean showProductFavourite;
    private double inputW;


    public AirtimeRecharge(boolean isNFCFavourite, boolean isProductFavourite) {
        this.provider = TopupSale.getInstance ().getProvider ();
        this.showFavourites = isNFCFavourite;
        this.showProductFavourite = isProductFavourite;
        this.inputW = ((JKLayout.contentW - (3 * JKLayout.sp)) / 2);

        TopupSale.getInstance ().setRechargePlus (false);

        List<String> onlineTransTypes = CurrentUser.getUser ().getTransTypes ();
        if (onlineTransTypes.contains ("RechargePlus")) {
            if (provider.isRechargePlus ()) {
                showRechargePlus = true;
            } else {
                showRechargePlus = false;
            }
        }

        checkMobileNumFav ();

        getChildren ().add (getAirtimeRechargeEntry ());
    }

    private void checkMobileNumFav() {
        if (!NFCUtilFav.getTopAirMobileNumsFav ().isEmpty ()) {
            List<String> listMobileNums = NFCUtilFav.getTopAirMobileNumsFav ();
            cbCell = new ComboBox ();
            cbCell.setMaxWidth (inputW);
            cbCell.setMinWidth (inputW);
            cbCell.setEditable (true);
            cbCell.setItems (FXCollections.observableArrayList (listMobileNums));
            cbCell.getEditor ().setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event event) {
                    JKiosk3.getNumPad ().showNumPad (cbCell.getEditor (), "Mobile Number", "", new NumberPadResult () {
                        @Override
                        public void onDone(String value) {
                            txtCell.setText (value);
                            txtCellConfirm.setDisable (false);
                        }
                    });
                }
            });
            cbCell.getSelectionModel ().selectedItemProperty ().addListener (new ChangeListener<String> () {
                @Override
                public void changed(ObservableValue observable, String oldValue, String newValue) {
                    cellNum = newValue;
                    txtCell.setText (cellNum);
                    txtCellConfirm.setText (cellNum);
                }
            });
        }
    }

    private VBox getAirtimeRechargeEntry() {
        vbEntry = JKLayout.getVBox (0, JKLayout.spNum);

        GridPane gCell = getCellEntry ();

        qAmts = getQuickAmts ();

        vbEntry.getChildren ().addAll (gCell, qAmts);

        return vbEntry;
    }

    private GridPane getCellEntry() {

        Label lblTopupAir = JKText.getLblDk (TopupSale.getInstance ().getSaleType ().getDisplay (), JKText.FONT_B_SM);

        Button btnProvider = JKNode.getAirtimeProviderButton (TopupSale.getInstance ().getProvider ().getName (), null);

        VBox vbHead = JKNode.getPageDblHeadVB (0, lblTopupAir, btnProvider);
        GridPane.setColumnSpan (vbHead, 2);

        Label lblCell = JKText.getLblDk ("Mobile Number", JKText.FONT_B_XSM);
        lblCell.setMinWidth ((2 * JKLayout.btnSmW) + JKLayout.sp);

        final Label lblCellConf = JKText.getLblDk ("Confirm Mobile Number", JKText.FONT_B_XSM);

        Label lblRechargePlus = JKText.getLblDk (RechargePlusUtil.RECHARGE_PLUS_LBL, JKText.FONT_B_XSM);

        CheckBox chkRechargePlus = new CheckBox ();
        chkRechargePlus.selectedProperty ().addListener (new ChangeListener<Boolean> () {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean aBoolean, Boolean t1) {
                if (t1) {
                    isRechargePlus = true;
                } else {
                    isRechargePlus = false;
                }
            }
        });

        txtCell = new TextField ();
        txtCell.setMaxWidth (inputW);
        txtCell.setMinWidth (inputW);
        txtCell.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtCell, "Enter Cell Number", "", new NumberPadResult () {
                        @Override
                        public void onDone(String value) {
                            txtCellConfirm.setDisable (false);
                        }
                    });
                }
            }
        });

        txtCellConfirm = new TextField ();
        txtCellConfirm.setMaxWidth (inputW);
        txtCellConfirm.setMinWidth (inputW);
        txtCellConfirm.setDisable (true);
        txtCellConfirm.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                if (!(JKOptions.getOptions ().isKeyboard ())) {
                    JKiosk3.getNumPad ().showNumPad (txtCellConfirm, "Confirm Cell Number", "");
                }
            }
        });

        GridPane grid = JKLayout.getGridContent2Col (0.5, 0.5);

        if (showFavourites) {
            grid.addRow (0, vbHead);
            grid.addRow (1, lblCell, cbCell);
            grid.addRow (2, lblCellConf, txtCellConfirm);
        } else if (showProductFavourite) {
            grid.addRow (0, vbHead);
            grid.addRow (1, lblCell, txtCell);
            grid.addRow (2, lblCellConf, txtCellConfirm);
        } else {
            grid.addRow (0, lblCell, txtCell);
            grid.addRow (1, lblCellConf, txtCellConfirm);
        }

        if (showRechargePlus) {
            grid.addRow (3, lblRechargePlus, chkRechargePlus);
        }

        return grid;
    }

    private QuickAmounts getQuickAmts() {
        QuickAmounts quick = new QuickAmounts (SaleType.TOPUP_AIRTIME, provider.getName (), new QuickAmountsResult () {
            @Override
            public void amountSelected(double value) {
                amount = value;
                processEntry ();
            }
        });
        return quick;
    }

    private void resetQuickAmounts() {
        vbEntry.getChildren ().remove (qAmts);
        qAmts = getQuickAmts ();
        vbEntry.getChildren ().add (1, qAmts);
    }

    private void processEntry() {
        if (validateInput ()) {
            /* NOTE - With RechargePlus added, we need to show the summary regardless of the setting. */
            showSummary ();
        } else {
            resetQuickAmounts ();
        }
    }

    private boolean validateInput() {
        boolean validated;
        if (txtCell.getText ().equals ("") || txtCell.getText () == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Mobile Number", "Mobile Number field cannot be empty", null);
            validated = false;
        } else if (txtCellConfirm.getText ().equals ("") || txtCellConfirm.getText () == null) {
            JKiosk3.getMsgBox ().showMsgBox ("Confirm Mobile Number", "Please confirm Mobile Number before continuing", null);
            validated = false;
        } else if (!txtCell.getText ().equals (txtCellConfirm.getText ())) {
            JKiosk3.getMsgBox ().showMsgBox ("Mobile Number", "Mobile Number input fields do not match", null);
            validated = false;
        } else if (txtCell.getText ().matches ("\\d{10}") || txtCell.getText ().matches ("\\d{11}")) {
            cellNum = txtCell.getText ();
            validated = true;
        } else {
            JKiosk3.getMsgBox ().showMsgBox ("Invalid Mobile Number", "Please enter a valid Mobile Number", null);
            validated = false;
        }

        return validated;
    }

    private void showSummary() {
        GridPane grid = JKLayout.getSummaryGrid2Col (0.4, 0.6);

        double amtRechargePlus = RechargePlusUtil.getRechargePlusValue ();

        Label lblProv = JKText.getLblDk ("Provider", JKText.FONT_B_XSM);
        Label lblCell = JKText.getLblDk ("Mobile Number", JKText.FONT_B_XSM);
        Label lblAmt = JKText.getLblDk ("Topup Amount", JKText.FONT_B_XSM);

        Label lblAmtTotal = JKText.getLblDk ("Total Due", JKText.FONT_B_26);

        Text txtProv = JKText.getTxtDk (provider.getDisplayName (), JKText.FONT_B_SM);
        Text txtCellNum = JKText.getTxtDk (JKText.getCellNumFormatted (cellNum), JKText.FONT_B_SM);
        Text txtAmt = JKText.getTxtDk ("R " + JKText.getDeciFormat (amount), JKText.FONT_B_SM);
        Text txtAmtTotal = JKText.getTxtDk ("", JKText.FONT_B_26);

        grid.addRow (0, lblProv, txtProv);
        grid.addRow (1, lblCell, txtCellNum);
        grid.addRow (2, lblAmt, txtAmt);

        if (isRechargePlus) {
            Label lblAmtRchgPlus = JKText.getLblDk (RechargePlusUtil.RECHARGE_PLUS_LBL, JKText.FONT_B_XSM);
            Text txtAmtRchgPlus = JKText.getTxtDk ("R " + JKText.getDeciFormat (amtRechargePlus), JKText.FONT_B_SM);
            txtAmtTotal.setText ("R " + JKText.getDeciFormat (amount + amtRechargePlus));

            grid.addRow (3, lblAmtRchgPlus, txtAmtRchgPlus);
            grid.addRow (5, lblAmtTotal, txtAmtTotal);
        } else {
            txtAmtTotal.setText ("R " + JKText.getDeciFormat (amount));
            grid.addRow (5, lblAmtTotal, txtAmtTotal);
        }

        JKiosk3.getMsgBox ().showMsgBox (SaleType.TOPUP_AIRTIME.getDisplay (), "Are you sure you want to purchase this Topup?", grid,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        confirmTopupRequest ();
                    }

                    @Override
                    public void onCancel() {
                        resetQuickAmounts ();
                    }
                });
    }

    private void confirmTopupRequest() {
        JKiosk3.getMsgBox ().showMsgBox (SaleType.TOPUP_AIRTIME.getDisplay (), "Topups cannot be reversed.\n\n"
                        + "Please make sure that you get the money for this transaction before proceeding with the sale.",
                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult () {

                    @Override
                    public void onOk() {
                        buyAirtime ();
                    }

                    @Override
                    public void onCancel() {
                        SceneSales.clearAndShowFavourites ();
                    }
                });
    }

    private void buyAirtime() {
        final String ref = SalesUtil.getUniqueRef ();

        TopupAirtimeReq req = new TopupAirtimeReq ();
        req.setSupplierName (provider.getName ());
        req.setReference (ref);
        req.setMobileNumber (cellNum);
        req.setAmount (amount);
        req.setRechargePlus (isRechargePlus);
        req.setPrint (true);

        TopupSale.getInstance ().setCellNum (cellNum);
        TopupSale.getInstance ().setAmount (amount);
        TopupSale.getInstance ().setAirtimeReq (req);
        TopupSale.getInstance ().setRef (ref);
        TopupSale.getInstance ().setRechargePlus (isRechargePlus);

        AirtimeUtil.getTopupVoucher (req, new AirtimeUtil.TopupResult () {
            @Override
            public void topupResult(final TopupVoucher voucher) {
                if (voucher.isSuccess ()) {
                    AirtimeUtil.isConfirmTopup (voucher, new TopupConfirmResult () {
                        @Override
                        public void topupConfirmResult(boolean topupConfirmResult) {
                            if (topupConfirmResult) {
                                SalesUtil.processTopupAirtime (voucher);
                                SceneSales.clearAndShowFavourites ();
                            } else {
                                JKiosk3.getMsgBox ().showMsgBox ("Topup Confirmation Failed", !voucher.getAeonErrorText ().isEmpty () ?
                                                "A" + voucher.getAeonErrorCode () + " - " + voucher.getAeonErrorText () :
                                                "B" + voucher.getErrorCode () + " - " + voucher.getErrorText (), null,
                                        MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                            @Override
                                            public void onOk() {
                                                SceneSales.clearAndShowFavourites ();
                                            }

                                            @Override
                                            public void onCancel() {

                                            }
                                        });
                            }
                        }
                    });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Topup Transaction Failed",!voucher.getAeonErrorText ().isEmpty () ?
                                    "A" + voucher.getAeonErrorCode () + " - " + voucher.getAeonErrorText () :
                                    "B" + voucher.getErrorCode () + " - " + voucher.getErrorText (), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    SceneSales.clearAndShowFavourites ();
                                }

                                @Override
                                public void onCancel() {

                                }
                            });
                }
            }
        });
    }

}
