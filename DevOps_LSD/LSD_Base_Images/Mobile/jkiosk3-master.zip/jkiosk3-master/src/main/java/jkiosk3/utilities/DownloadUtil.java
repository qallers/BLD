package jkiosk3.utilities;

import Download.HttpUtils;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

import jkiosk3.JKiosk3;
import jkiosk3._common.JKMedia;

public class DownloadUtil {

    private final static Logger logger = Logger.getLogger(DownloadUtil.class.getName());

    public static File downloadRemoteFile(String printUrl, String destinationFolder) {
        File fileDownloaded = null;
        JKMedia.createMediaFolder(destinationFolder);
        sortAndRemove(destinationFolder);

        String remoteFile = printUrl;
        String[] imgPathSplit = remoteFile.split("/");

        String sourceFile = imgPathSplit[imgPathSplit.length - 1];

        String localFile = destinationFolder + sourceFile;

        if (HttpUtils.httpDownload(remoteFile, localFile, false, null)) {
            if (HttpUtils.isLocalFileComplete(remoteFile, localFile)) {
                logger.info(("DOWNLOADED FILE : ").concat(localFile));
                fileDownloaded = new File(localFile);
            } else {
                logger.info("File download incomplete, file sizes do not match");
            }
        } else {
            JKiosk3.getMsgBox().showMsgBox("File Download", "Unable to retrieve file : \n" + sourceFile, null);
        }
        return fileDownloaded;
    }

    private static void sortAndRemove(String destinationFolder) {
        File folder = new File(destinationFolder);
        List<File> listFiles = Arrays.asList(folder.listFiles());

        JKMedia.checkFolderSize(listFiles, destinationFolder, 10);
    }
}
