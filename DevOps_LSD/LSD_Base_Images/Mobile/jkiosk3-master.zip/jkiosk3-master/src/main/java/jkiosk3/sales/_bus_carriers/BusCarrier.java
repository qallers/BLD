package jkiosk3.sales._bus_carriers;

/**
 *
 * @author valeriew
 */
public class BusCarrier {

    private String carrierTransType;
    private String carrierCode;
    private String carrierName;
    private String carrierImage;
    private String carrierLogoCode;
    private String carrierWebsite;
    private String carrierCallCentre;
    
    public BusCarrier() {
        //
    }
    
    public BusCarrier(String carrierTransType, String carrierCode, String carrierName, String carrierImage, 
            String carrierLogoCode, String carrierWebsite, String carrierCallCentre) {
        this.carrierTransType = carrierTransType;
        this.carrierCode = carrierCode;
        this.carrierName = carrierName;
        this.carrierImage = carrierImage;
        this.carrierLogoCode = carrierLogoCode;
        this.carrierWebsite = carrierWebsite;
        this.carrierCallCentre = carrierCallCentre;
    }

    public String getCarrierTransType() {
        return carrierTransType;
    }

    public void setCarrierTransType(String carrierTransType) {
        this.carrierTransType = carrierTransType;
    }    
    
    public String getCarrierCode() {
        return carrierCode;
    }

    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getCarrierImage() {
        return carrierImage;
    }

    public void setCarrierImage(String carrierImage) {
        this.carrierImage = carrierImage;
    }
    
    public String getCarrierLogoCode() {
        return carrierLogoCode;
    }

    public void setCarrierLogoCode(String carrierLogoCode) {
        this.carrierLogoCode = carrierLogoCode;
    }

    public String getCarrierWebsite() {
        return carrierWebsite;
    }

    public void setCarrierWebsite(String carrierWebsite) {
        this.carrierWebsite = carrierWebsite;
    }

    public String getCarrierCallCentre() {
        return carrierCallCentre;
    }

    public void setCarrierCallCentre(String carrierCallCentre) {
        this.carrierCallCentre = carrierCallCentre;
    }
}
