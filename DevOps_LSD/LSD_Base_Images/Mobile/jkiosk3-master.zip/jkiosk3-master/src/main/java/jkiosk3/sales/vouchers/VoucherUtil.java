package jkiosk3.sales.vouchers;

import aeonairtime.*;

import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.concurrent.Task;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKText;
import jkiosk3.sales.SaleType;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.store.JKDevLocation;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.store.cache.CacheListAirtimeManufacturers;
import jkiosk3.users.CurrentUser;
import jkiosk3.utilities.DialupConnection;
import jkiosk3.utilities.TaskUtil;

public class VoucherUtil {

    private final static Logger LOG = Logger.getLogger(VoucherUtil.class.getName());
    private static AirtimeConnection ac;
    private static String userPin;
    private static List<AirtimeManufacturer> providers;
    //
    private final static TaskUtil TASK_UTIL = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private final static int COUNTDOWN_TIME = 60;

    /**
     * Private Constructor to hide implicit public one.
     */
    private VoucherUtil() {
    }

    public static AirtimeConnection getAirtimeConnect() {
        AirtimeConnection airConnect = null;
        String server = JKSystem.getSystemConfig().getServer();
        int port = JKSystem.getSystemConfig().getPort();
        boolean secureConnect = JKSystem.getSystemConfig().isSecureConn();

        if (JKDialup.getDialupConnect().isAutoConn()) {
            DialupConnection.getInstance().startConnection(JKDialup.getDialupConnect().getAutoConnName());
        }
        try {
            airConnect = new AirtimeConnection(server, port, secureConnect);
            airConnect.setTimeout(COUNTDOWN_TIME);
        } catch (ConnectException ce) {
            errorMsg = ce.getClass().getSimpleName() + " : " + ce.getMessage();
            LOG.log(Level.SEVERE, ce.getMessage(), ce);
        } catch (SocketException s) {
            errorMsg = s.getClass().getSimpleName() + " : " + s.getMessage();
            LOG.log(Level.SEVERE, s.getMessage(), s);
        } catch (SocketTimeoutException se) {
            errorMsg = se.getClass().getSimpleName() + " : " + se.getMessage();
            LOG.log(Level.SEVERE, se.getMessage(), se);
        } catch (Exception e) {
            errorMsg = e.getClass().getSimpleName() + " : " + e.getMessage();
            LOG.log(Level.SEVERE, e.getMessage(), e);
        }
        return airConnect;
    }

    private static boolean isLoggedIn(String pin) throws RuntimeException {
        String loyaltyProfileId = "";
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            loyaltyProfileId = ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId();
        }

        boolean loggedIn = false;
        try {
            ac = getAirtimeConnect();
        } catch (Exception e) {
            JKiosk3.getMsgBox().showMsgBox("Connection Error", "Airtime Connection Error\n" + e.getClass().getSimpleName(), null);
        }
        ac = getAirtimeConnect();
        userPin = pin;
        int deviceId = JKSystem.getSystemConfig().getDeviceId();
        String serial = JKSystem.getSystemConfig().getSerial();
        try {
            if (ac != null) {
                loggedIn = ac.login(userPin, deviceId, serial, CurrentUser.getUser().getTransTypes().contains("VoucherAMS"), loyaltyProfileId);
            }
        } catch (Throwable t) {
            errorMsg = "\n" + t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Login Error", t);
        }
        return loggedIn;
    }

    private static List<AirtimeManufacturer> getOnlineProdList() throws RuntimeException {
        List<AirtimeManufacturer> listProviders = new ArrayList<>();
        userPin = CurrentUser.getUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                listProviders = ac.getVoucherList();
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Product List Error", t);
        } finally {
            if (ac != null) {
                ac.disconnect();
            }
        }
        return listProviders;
    }

    public static List<AirtimeManufacturer> getVoucherProvidersList() throws RuntimeException {
        providers = new ArrayList<>();

        if (CacheListAirtimeManufacturers.hasItems()) {
            providers = CacheListAirtimeManufacturers.getListAirtimeManufacturers();
        } else {
            providers = getOnlineProdList();
        }
        int count = 0;
        for (AirtimeManufacturer m : providers) {
            count += m.getProducts().size();
        }
//        System.out.println("Voucher product count : " + count);
        // testing...
//        providers.add(getTestAM());

        return providers;
    }
    
    private static AirtimeManufacturer getTestAM() {
        String testMan = "BetFlash";
        double[] prods = {10, 20, 30};

        AirtimeManufacturer am = new AirtimeManufacturer();
        am.setName(testMan);
        am.setRechargePlus(false);
        for (double d : prods) {
            AirtimeProduct ap = new AirtimeProduct();
            ap.setProductID(9 + (int) d);
            ap.setName("R " + JKText.getDeciFormatNoDecimals(d) + " " + testMan);
            ap.setValue(d);
            ap.setCategoryId(4);
            ap.setCategoryDesc("Other");
            am.getProducts().add(ap);
        }
        return am;
    }

    /**
     * Sorts the previously retrieved 'providers' list of AirtimeManufacturer objects into the various Sale Types. This
     * results in only the relevant list being returned when selecting, for example, Airtime Vouchers.
     *
     * @param voucherType the voucher type selected for display.
     * @return a List of type AirtimeManufacturer.
     */
    public static List<AirtimeManufacturer> getProvidersShow(SaleType voucherType) {
        List<AirtimeManufacturer> listProv = new ArrayList<>();
        List<AirtimeManufacturer> listProvAir = new ArrayList<>();
        List<AirtimeManufacturer> listProvData = new ArrayList<>();
        List<AirtimeManufacturer> listProvElec = new ArrayList<>();
        List<AirtimeManufacturer> listProvOther = new ArrayList<>();
        AirtimeManufacturer provider;

        if (!providers.isEmpty()) {
            switch (voucherType) {
                case VOUCHER_AIRTIME:
                    for (AirtimeManufacturer manuf : providers) {
                        List<AirtimeProduct> listProductsAir = new ArrayList<>();
                        for (AirtimeProduct prod : manuf.getProducts()) {
                            if (prod.getCategoryId() == 1) {
                                listProductsAir.add(prod);
                            }
                        }
                        if (!listProductsAir.isEmpty()) {
                            provider = new AirtimeManufacturer();
                            provider.setName(manuf.getName());
                            provider.setRechargePlus(manuf.isRechargePlus());
                            provider.getProducts().addAll(listProductsAir);
                            listProvAir.add(provider);
                        }
                    }
                    listProv = listProvAir;
                    break;
                case VOUCHER_DATA:
                    for (AirtimeManufacturer manuf : providers) {
                        List<AirtimeProduct> listProductsData = new ArrayList<>();
                        for (AirtimeProduct prod : manuf.getProducts()) {
                            if (prod.getCategoryId() == 2) {
                                listProductsData.add(prod);
                            }
                        }
                        if (!listProductsData.isEmpty()) {
                            provider = new AirtimeManufacturer();
                            provider.setName(manuf.getName());
                            provider.setRechargePlus(manuf.isRechargePlus());
                            provider.getProducts().addAll(listProductsData);
                            listProvData.add(provider);
                        }
                    }
                    listProv = listProvData;
                    break;
                case VOUCHER_ELEC:
                    for (AirtimeManufacturer manuf : providers) {
                        List<AirtimeProduct> listProductsElec = new ArrayList<>();
                        for (AirtimeProduct prod : manuf.getProducts()) {
                            if (prod.getCategoryId() == 3) {
                                listProductsElec.add(prod);
                            }
                        }
                        if (!listProductsElec.isEmpty()) {
                            provider = new AirtimeManufacturer();
                            provider.setName(manuf.getName());
                            provider.setRechargePlus(manuf.isRechargePlus());
                            provider.getProducts().addAll(listProductsElec);
                            listProvElec.add(provider);
                        }
                    }
                    listProv = listProvElec;
                    break;
                case VOUCHER_OTHER:
                    for (AirtimeManufacturer manuf : providers) {
                        List<AirtimeProduct> listProductsOther = new ArrayList<>();
                        for (AirtimeProduct prod : manuf.getProducts()) {
                            if (prod.getCategoryId() == 4) {
                                listProductsOther.add(prod);
                            }
                        }
                        if (!listProductsOther.isEmpty()) {
                            provider = new AirtimeManufacturer();
                            provider.setName(manuf.getName());
                            provider.setRechargePlus(manuf.isRechargePlus());
                            provider.getProducts().addAll(listProductsOther);
                            listProvOther.add(provider);
                        }
                    }
                    listProv = listProvOther;
                    break;
                default:
                    JKiosk3.getMsgBox().showMsgBox("Voucher Type", "No Voucher Type selected", null);
            }
        } else {
            JKiosk3.getMsgBox().showMsgBox("Airtime Provider List",
                    "No Providers found.\n\nIs the computer connected to the network?", null);
        }

        return listProv;
    }

    private static AirtimeManufacturer getProvider(String id) {
        AirtimeManufacturer man = null;
        try {
            for (AirtimeManufacturer p : providers) {
                if (p.getId().equals(id)) {
                    man = p;
                    break;
                }
            }
        } catch (Exception e) {
            LOG.log(Level.SEVERE, e.getMessage(), e);
        }
        return man;
    }

    /**
     * Retrieves a List of AirtimeProduct objects for the Provider ID requested.
     *
     * @param saleType the products for the Sale Type (category) e.g. Airtime, Data, etc.
     * @param provId the Provider ID of the selected AirtimeManufacturer.
     * @return a List of AirtimeProduct for the selected AirtimeManufacturer.
     */
    public static List<AirtimeProduct> getProviderProducts(String saleType, String provId) {
        List<AirtimeProduct> provProds = new ArrayList<>();
        List<AirtimeProduct> listProdAir = new ArrayList<>();
        List<AirtimeProduct> listProdData = new ArrayList<>();
        List<AirtimeProduct> listProdOther = new ArrayList<>();
        List<AirtimeProduct> listProdElec = new ArrayList<>();

        AirtimeManufacturer man = getProvider(provId);

        if (!man.getProducts().isEmpty()) {
            switch (SaleType.valueOf(saleType)) {
                case VOUCHER_AIRTIME:
                    for (AirtimeProduct p : man.getProducts()) {
                        if (p.getCategoryId() == 1) {
                            listProdAir.add(p);
                        }
                    }
                    provProds = listProdAir;
                    break;
                case VOUCHER_DATA:
                    for (AirtimeProduct p : man.getProducts()) {
                        if (p.getCategoryId() == 2) {
                            listProdData.add(p);
                        }
                    }
                    provProds = listProdData;
                    break;
                case VOUCHER_ELEC:
                    for (AirtimeProduct p : man.getProducts()) {
                        if (p.getCategoryId() == 3) {
                            listProdElec.add(p);
                        }
                    }
                    provProds = listProdElec;
                    break;
                case VOUCHER_OTHER:
                    for (AirtimeProduct p : man.getProducts()) {
                        if (p.getCategoryId() == 4) {
                            listProdOther.add(p);
                        }
                    }
                    provProds = listProdOther;
                    break;
                default:
                    break;
            }
        }

        return provProds;
    }

    private static VoucherMultiResp getAirtimeVouchers(VoucherMultiReq req) throws RuntimeException {
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            System.out.println("active nfc subscriber not null, profile id = " + ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId());
            req.setLoyaltyProfileId(ActiveNFCSubscriber.getInstance().getConsumerProfile().getProfileId());
        }
//        if (JKDevLocation.getDeviceLocation().getFormattedLocation() != null) {
//            req.setDeviceLocation(JKDevLocation.getDeviceLocation().getFormattedLocation());
//        }
        VoucherMultiResp voucherMultiResp = new VoucherMultiResp();
        AirtimeConnection airconn = getAirtimeConnect();
        try {
            voucherMultiResp = airconn.getAirtimeVouchers(req);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Airtime or Data Vouchers Error", t);
        } finally {
            if (ac != null) {
                ac.disconnect();
            }
        }
        return voucherMultiResp;
    }

    private static Boolean cancelVoucherSale(String ref, String transRef) throws RuntimeException {
        boolean removed = false;
        userPin = CurrentUser.getSalesUser().getUserPin();
        try {
            if (isLoggedIn(userPin)) {
                removed = ac.doCancelVoucher(ref, transRef);
            }
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            LOG.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Cancel Voucher Error", t);
        } finally {
            if (ac != null) {
                ac.disconnect();
            }
        }
        return removed;
    }

    /*----------------*/
 /* Busy Indicator */
 /*----------------*/
    public static void getVoucherProvidersList(final AirtimeManufacturerResult result) {
        JKiosk3.getBusy().showBusy("Getting Product List");

        final Task<List<AirtimeManufacturer>> taskProdList = new Task<List<AirtimeManufacturer>>() {
            @Override
            protected List<AirtimeManufacturer> call() throws Exception {
                return getVoucherProvidersList();
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.airtimeManufacturerResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("Voucher Product List Error",
                        "Error Getting Voucher Product List", State.CANCELLED, errorMsg, new MenuVouchers());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("Voucher Product List Error",
                        "Error Getting Voucher Product List", State.FAILED, errorMsg, new MenuVouchers());
            }
        };
        new Thread(taskProdList).start();
        JKiosk3.getBusy().startCountdown(taskProdList, COUNTDOWN_TIME);
    }

    public static void getAirtimeVouchers(final VoucherMultiReq req, final AirtimeVouchersResult result) {
        String qtytxt = " Voucher";
        if (req.getQuantity() >  1) {
            qtytxt = " Vouchers";
        }
        JKiosk3.getBusy().showBusy("Getting " + req.getQuantity() + qtytxt);

        Task<VoucherMultiResp> taskVouchers = new Task<VoucherMultiResp>() {
            @Override
            protected VoucherMultiResp call() throws Exception {
                return getAirtimeVouchers(req);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.airtimeVoucherResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("Voucher Error",
                        "Error Getting Vouchers", State.CANCELLED, errorMsg, new MenuVouchers());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("Voucher Error",
                        "Error Getting Vouchers", State.FAILED, errorMsg, new MenuVouchers());
            }
        };
        new Thread(taskVouchers).start();
        JKiosk3.getBusy().startCountdown(taskVouchers, COUNTDOWN_TIME);
    }

    public static void cancelVoucherSale(final String ref, final String transRef, final VoucherCancelResult result) {
        JKiosk3.getBusy().showBusy("Cancelling Voucher");

        final Task<Boolean> taskVoucherCancel = new Task<Boolean>() {
            @Override
            protected Boolean call() throws Exception {
                return cancelVoucherSale(ref, transRef);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                result.voucherCancelResult(getValue());
            }

            @Override
            protected void cancelled() {
                TASK_UTIL.taskSaleCancelFail("Cancel Voucher",
                        "Error Cancelling Voucher", State.CANCELLED, errorMsg, new MenuVouchers());
            }

            @Override
            protected void failed() {
                TASK_UTIL.taskSaleCancelFail("Cancel Voucher",
                        "Error Cancelling Voucher", State.FAILED, errorMsg, new MenuVouchers());
            }
        };
        new Thread(taskVoucherCancel).start();
        JKiosk3.getBusy().startCountdown(taskVoucherCancel, COUNTDOWN_TIME);
    }

    public abstract static class AirtimeVouchersResult {
        public abstract void airtimeVoucherResult(VoucherMultiResp vouchers);
    }

    public abstract static class AirtimeManufacturerResult {

        public abstract void airtimeManufacturerResult(List<AirtimeManufacturer> manufacturerList);
    }

    public abstract static class VoucherCancelResult {

        public abstract void voucherCancelResult(Boolean cancelled);
    }
}
