package jkiosk3.sales;

//import aeonusers.Promotion;
//import aeonusers.UserTransactionType;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPadResult;
import jkiosk3.sales._common.SummaryTableView;
import jkiosk3.sales._favourites.Favourites;
import jkiosk3.sales._favourites.nfc.ActiveNFCSubscriber;
import jkiosk3.sales._tender.TenderAmounts;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.sales.chat4change.Chat4Change;
import jkiosk3.sales.chat4change.Chat4ChangeSale;
import jkiosk3.sales.electricity.ElectricitySupplierSelect;
import jkiosk3.sales.ithuba.lotto.LottoMenu;
import jkiosk3.sales.rica.RICALogin;
import jkiosk3.sales.rmcs.MoneyTransferMenu;
import jkiosk3.sales.search.SearchMenu;
import jkiosk3.sales.topups.MenuTopups;
import jkiosk3.sales.vouchers.MenuVouchers;
import jkiosk3.store.JKOptions;
import jkiosk3.store.JKPending;
import jkiosk3.store.JKSalesOptions;
import jkiosk3.store.StoreJKPending;
import jkiosk3.users.CurrentUser;
import jkiosk3.users.UserUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

public class SceneSales extends Region {

    private final static Logger LOG = Logger.getLogger(SceneSales.class.getName());
    private static VBox vbSalesContent;
    private static VBox vbSalesTable;
    private static Label lblSalesPerson;
    private static Text txtItemCount;
    private static Button btnAmtDue;
    private static Button btnRemove;
    private static Button btnMainMenu;
    private static Button btnOpenCashDraw;
    private static Button btnShiftEnd;
    private static Button btnLogout;
    private Button btnMenuSelection;
    private VBox vbAdmin;
    // field 'lblTime' may be needed in future if we re-implement a 'countdown' function
//    private static Label lblTime;
//    private final List<Promotion> listPromos;
//    private Promotion selectedPromo;

    public SceneSales(boolean loadFavourites) {
//        listPromos = PromoUtil.getListPromos();
////        listPromos.addAll(getListTestPromos());
//        if (!listPromos.isEmpty()) {
//            for (Promotion p : listPromos) {
//                System.out.println("promoId = " + p.getPromoId() + " : promoName = " + p.getName() + " : isEnabled = " + p.isEnabled());
//                for (UserTransactionType t : p.getListTransTypes()) {
//                    System.out.println("\t transtype = " + t.getType());
//                }
//            }
//        } else {
//            System.out.println("no promos currently running");
//        }
        AnchorPane anchor = getSalesLayout();
        checkPendingSale();

        getChildren().add(JKLayout.getSceneStack(anchor, this));
        if (loadFavourites) {
            clearAndChangeContent(new Favourites());
//            clearAndChangeContent(new FavouriteTabs());
        }
    }

    private void checkPendingSale() {
        TenderAmounts.resetTenderAmounts();
        if (JKPending.hasPendingItems()) {
            List<StoreJKPending> pendingTrans = JKPending.getPendingList();
            CurrentUser.setSalesUser(JKPending.getPendingList().get(0).getUser());
            if (JKPending.getPendingList().get(0).getUser() != null) {
                lblSalesPerson.setText(JKPending.getPendingList().get(0).getUser().getUserName());
            } else {
                CurrentUser.setSalesUser(CurrentUser.getUser());
                lblSalesPerson.setText(CurrentUser.getUser().getUserName());
            }

            LOG.info(("Pending items, rebuilding basket : ").concat(Integer.toString(JKPending.getPendingList().size())).concat(" items"));
            for (StoreJKPending p : pendingTrans) {
                StringBuilder sb = new StringBuilder();
                sb.append("sale type = ").append(p.getSaleType()).append("\r\n");
                sb.append("      amount    = ").append(p.getAmount()).append("\r\n");
                Date transDate = new Date();
                long trxDate = p.getDateTime();
                if (trxDate != 0) {
                    transDate = new Date(trxDate);
                    sb.append("      date      = ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(transDate)).append("\r\n");
                }

                SummaryTableView.addSalesItem(p.getDescription(), p.getAmount(), p.getTransReference(), p.isCanCancel(),
                        "online", "", transDate, p.getSerialNo(), p.getSaleType());
                if (p.getTenderType() != null) {
                    sb.append("      tender    = ").append(p.getTenderType()).append("\r\n");
                    String tenderLowerCase = p.getTenderType().toLowerCase(Locale.ENGLISH);
                    String tenderText = "";
                    switch (tenderLowerCase) {
                        case "cash":
                            tenderText = TenderAmounts.TENDER_CASH;
                            break;
                        case "cheque":
                            tenderText = TenderAmounts.TENDER_CHEQUE;
                            break;
                        case "creditcard":
                            tenderText = TenderAmounts.TENDER_CRED_CARD;
                            break;
                        case "debitcard":
                            tenderText = TenderAmounts.TENDER_DEB_CARD;
                            break;
                        default:
                            LOG.info("unable to determine tender type");
                    }
                    TenderAmounts.addTenderAmount(tenderText, p.getAmount());
                } else {
                    sb.append("      tender    = ").append("unknown").append("\r\n");
                }
                sb.append("      -------------------------------");
                LOG.info(sb.toString());

                /* **************************************************** */
                /* Add this here as a test run for the Forced Reprints. */
                /* Basket should be rebuilt, but what about Print Jobs? */
                /* **************************************************** */
//                PrintHandler.handlePrintRequestSale(p.getSaleType(), p.getAeonPrintJob(), p.getTransReference());
//                if (!JKPrintOptions.getPrintOptions().isPrintImmediately()) {
//                    List<StoreJKReprint> reprints = JKReprint.getReprintList();
//                    for (StoreJKReprint r : reprints) {
//                        if (p.getTransReference() == r.getVoucherReference()) {
//                            PrintQueue.addItem(Integer.toString(r.getVoucherReference()), r.getApj());
//                        }
//                    }                    
//                }
            }
        }
    }

    private AnchorPane getSalesLayout() {
        VBox menu = getSalesMenu();
        vbSalesContent = JKLayout.getVBox(0, JKLayout.spNum);

        VBox saleSumm = JKLayout.getSceneInfoBox(293, getSummaryTable());
        VBox controls = getGrpControls();
        VBox admin = getGrpAdmin();
        VBox logout = getGrpLogout();

        VBox vb = JKLayout.getVBox(0, 5);
        if (vbAdmin.getChildren().isEmpty()) {
            vb.getChildren().addAll(saleSumm, controls, logout);
        } else {
            vb.getChildren().addAll(saleSumm, controls, admin, logout);
        }

        AnchorPane ap = JKLayout.getSceneAnchor(menu, vbSalesContent, vb);

        ap.getChildren().addAll(menu, vbSalesContent, vb);

        return ap;
    }

    private VBox getSalesMenu() {
        List<SaleType> listSaleTypes = SalesMenu.getSalesMenu();
        List<Button> listBtns = new ArrayList<>();
        for (SaleType saleType : listSaleTypes) {
            final Button btn = JKNode.getBtnSm(saleType.getDisplay());
            btn.setId(saleType.name());
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    btnMenuSelection = btn;
                    onClickMenuBtn();
                }
            });
            listBtns.add(btn);
        }

        return JKLayout.getSceneMenuBtnGroup("sales", listBtns);
    }

    private VBox getSummaryTable() {
        vbSalesTable = JKLayout.getVBox(0, JKLayout.spNum);

        Label lblSaleBy = JKText.getLblDk("Sale by:", JKText.FONT_B_12);
        Label lblItemCount = JKText.getLblDk("Item count: ", JKText.FONT_B_10);

        lblSalesPerson = JKText.getLblDk("", JKText.FONT_B_12);
        if (CurrentUser.getSalesUser() == null) {
            lblSalesPerson.setText("");
        } else {
            lblSalesPerson.setText(CurrentUser.getSalesUser().getUserName());
        }

        txtItemCount = JKText.getTxtDk("0", JKText.FONT_B_10);

        /* Cashier (User) details */
        HBox hbUser = JKLayout.getHBox(0, JKLayout.spNum);
        hbUser.setPadding(new Insets(0, JKLayout.spNum, 0, 0));
        hbUser.setMaxWidth(JKLayout.sideW - JKLayout.spNum);
        hbUser.setMinWidth(JKLayout.sideW - JKLayout.spNum);
        hbUser.getChildren().addAll(lblSaleBy, JKNode.getHSpacer(), lblSalesPerson);

        /* Number of items (count) in sales table */
        HBox hbCount = JKLayout.getHBox(0, JKLayout.spNum);
        hbCount.setPadding(new Insets(0, JKLayout.spNum, 0, 0));
        hbCount.setMaxWidth(JKLayout.sideW - JKLayout.spNum);
        hbCount.setMinWidth(JKLayout.sideW - JKLayout.spNum);
        hbCount.getChildren().addAll(lblItemCount, JKNode.getHSpacer(), txtItemCount);

        /* Countdown was used for eqTickets, might be needed for other purpose */
//        Label lblCountdown = JKText.getLblDk("Countdown:", JKText.FONT_B_XXXSM);
//        lblTime = JKText.getLblDk(SummaryTableView.formatTime(SummaryTableView.STARTTIME), JKText.FONT_B_XXXSM);
//        HBox hbTime = JKLayout.getHBox(0, JKLayout.spNum);
//        hbTime.setPadding(new Insets(0, JKLayout.spNum, 0, 0));
//        hbTime.setMaxWidth(JKLayout.sideW - JKLayout.spNum);
//        hbTime.setMinWidth(JKLayout.sideW - JKLayout.spNum);
//        hbTime.getChildren().addAll(lblCountdown, JKNode.getHSpacer(), lblTime);
//
//        /* New SummaryTableView item */
//        SummaryTableView salesTable = new SummaryTableView();
//        salesTable.setMaxWidth(JKLayout.sideW);
//        salesTable.setMaxHeight(salesTable.getTableHeight());
//
//        vbSummary.getChildren().addAll(salesTable, hbUser, hbTime);
//        vbSummary.getChildren().addAll(salesTable, hbUser);
        vbSalesTable.getChildren().addAll(makeSummaryTable(), hbUser, hbCount);

        return vbSalesTable;
    }

    public static SummaryTableView makeSummaryTable() {
        /* New SummaryTableView item */
        SummaryTableView salesTable = new SummaryTableView();
        salesTable.setMaxWidth(JKLayout.sideW - 2);
        salesTable.setMaxHeight(salesTable.getTableHeight());
        return salesTable;
    }

    private VBox getGrpControls() {

        btnAmtDue = JKNode.getBtnSm("Amount Due\nR0.00");
        btnAmtDue.setFont(JKText.FONT_B_XXSM);
        btnAmtDue.setDisable(true);
        btnAmtDue.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SalesUtil.onSelectAmountDue();
            }
        });

        btnRemove = JKNode.getBtnMsgBox("Remove Item");
        btnRemove.setFont(JKText.FONT_B_XXSM);
        btnRemove.setDisable(true);
        btnRemove.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SummaryTableView.removeSalesItem();
            }
        });

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getStyleClass().clear();
        vb.getStyleClass().add("vbContent");
        vb.getChildren().addAll(btnAmtDue, btnRemove);

        return vb;
    }

    private VBox getGrpAdmin() {

        btnMainMenu = JKNode.getBtnMsgBox("Main Menu");
        btnMainMenu.setDisable(false);
        btnMainMenu.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                resetNFCSubscriber();
                final PasswordField pwd = new PasswordField();
                JKiosk3.getNumPad().showNumPad(pwd, "Enter User Pin", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        String userPin = pwd.getText();
                        SalesUtil.onSelectMainMenu(userPin);
                    }
                });
            }
        });

        btnOpenCashDraw = JKNode.getBtnMsgBox("Cash Drawer");
        btnOpenCashDraw.setDisable(false);
        btnOpenCashDraw.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                resetNFCSubscriber();
                final PasswordField pwd = new PasswordField();
                JKiosk3.getNumPad().showNumPad(pwd, "Enter User Pin", "", new NumberPadResult() {
                    @Override
                    public void onDone(String value) {
                        String userPin = pwd.getText();
                        SalesUtil.onSelectCashDrawer(userPin);
                    }
                });
            }
        });

        btnShiftEnd = JKNode.getBtnMsgBox("End Shift");
        btnShiftEnd.setDisable(false);
        btnShiftEnd.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                resetNFCSubscriber();
                if (CurrentUser.getSalesUser() == null) {
                    final PasswordField pwd = new PasswordField();
                    JKiosk3.getNumPad().showNumPad(pwd, "Enter User Pin", "", new NumberPadResult() {
                        @Override
                        public void onDone(String value) {
                            String userPin = pwd.getText();
                            SalesUtil.onSelectShiftEnd(userPin);
                        }
                    });
                } else {
                    JKiosk3.getMsgBox().showMsgBox("End Shift", "\nA Shift cannot be ended while a Sales Person is logged in."
                                    + "\n\nDo you want to clear the current sale and end the Shift?"
                                    + "\n\n\nClick 'Yes' to clear the current sale, \n\nor 'No' to continue the sale.", null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_YES_NO, new MessageBoxResult() {
                                @Override
                                public void onOk() {
                                    CurrentUser.setSalesUser(null);
                                    lblSalesPerson.setText("");
                                    vbSalesContent.getChildren().clear();
                                }

                                @Override
                                public void onCancel() {
                                    //
                                }
                            });
                }
            }
        });

        vbAdmin = JKLayout.getVBoxContent(JKLayout.sp);
        vbAdmin.getStyleClass().clear();
        vbAdmin.getStyleClass().add("vbContent");
        if (CurrentUser.getUser().getUserLevel() == 0) {                    /* Cashier */

            if (JKSalesOptions.getSalesOptions().isUseCashDrawer()) {
                vbAdmin.getChildren().add(btnOpenCashDraw);
            }
            if (JKOptions.getOptions().isCashierEndShift()) {
                vbAdmin.getChildren().add(btnShiftEnd);
            }
        } else if (CurrentUser.getUser().getUserLevel() == 1                /* Supervisor */
                || CurrentUser.getUser().getUserLevel() == 2) {             /* Cashier Plus */

            vbAdmin.getChildren().add(btnMainMenu);
            if (JKSalesOptions.getSalesOptions().isUseCashDrawer()) {
                vbAdmin.getChildren().add(btnOpenCashDraw);
            }
            if (JKOptions.getOptions().isCashierEndShift()) {
                vbAdmin.getChildren().add(btnShiftEnd);
            }
        }

        return vbAdmin;
    }

    private VBox getGrpLogout() {

        btnLogout = JKNode.getBtnMsgBox("Logout");
        btnLogout.setDisable(false);
        btnLogout.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                resetNFCSubscriber();
                CurrentUser.setUser(null);
                JKiosk3.changeScene(new JKioskLogin());
            }
        });

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getStyleClass().clear();
        vb.getStyleClass().add("vbContent");
        vb.getChildren().add(btnLogout);

        return vb;
    }

//    private void showPromo(final Promotion pro) {
//        if (pro != null) {
//            final PromoPopup promo = new PromoPopup(pro);
//            JKiosk3.getMsgBox().showMsgBox(pro.getName(), "",
//                    promo, MessageBox.CONTROLS_SHOW, MessageBox.MSG_YES_NO, new MessageBoxResult() {
//
//                @Override
//                public void onOk() {
//                    String mobileNum = promo.getMobileNum();
//                    if (isValidEntry(mobileNum)) {
//                        PromoSubmit.getInstance().setSubmit(true);
//                        PromoSubmit.getInstance().setPromoId(pro.getPromoId());
//                        PromoSubmit.getInstance().setName(pro.getName());
//                        PromoSubmit.getInstance().setMobileNumber(mobileNum);
//
//                        getMenuSelection();
//                    } else {
//                        PromoSubmit.getInstance().setSubmit(false);
//                        getMenuSelection();
//                    }
//                }
//
//                @Override
//                public void onCancel() {
//                    getMenuSelection();
//                }
//            });
//        } else {
//            getMenuSelection();
//        }
//    }

//    private boolean isValidEntry(String number) {
//        if (number == null || number.equals("")) {
//            JKiosk3.getMsgBox().showMsgBox("Customer Cell Number", "Please enter a valid Cell Number", null, MessageBox.CONTROLS_SHOW,
//                    MessageBox.MSG_OK, new MessageBoxResult() {
//
//                @Override
//                public void onOk() {
//                    showPromo(selectedPromo);
//                }
//
//                @Override
//                public void onCancel() {
//                    //
//                }
//            });
//
//            return false;
//        }
//        if (!number.matches("(^0[678][01234689]((\\d{7})|( |-)((\\d{3}))( |-)(\\d{4})|( |-)(\\d{7})))")) {
//            JKiosk3.getMsgBox().showMsgBox("Customer Cell Number", "Please enter a valid Cell Number", null, MessageBox.CONTROLS_SHOW,
//                    MessageBox.MSG_OK, new MessageBoxResult() {
//
//                @Override
//                public void onOk() {
//                    showPromo(selectedPromo);
//                }
//
//                @Override
//                public void onCancel() {
//                    //
//                }
//            });
//
//            return false;
//        }
//        return true;
//    }

    private void onClickMenuBtn() {
        /*
         * 2015-02-11  -  Val
         * We should be checking whether the Merchant has sufficient funds to make another sale.
         * Will need to check the Available Balance (ReportUtil perhaps?), less the value of current sales, available from
         * 'SummaryTableView.getTotalAmt()'
         * If insufficient funds are available, show message that selected sale cannot be processed.
         *
         * *** NB *** - If a Device has multiple Accounts linked to it, WHICH available balance do we check?????
         *
         * We should perhaps make a SINGLE call to the DB at start of sale (i.e. current sale total = R0.00)
         * and keep checking against THAT value until the sale is closed.  We do NOT want to have to make a connection
         * for every time a menu button is clicked.
         * BUT - keep in mind that sales might be processed to the same Account from other devices.  We might HAVE TO
         * check balance at each menu button selection.
         */
//        System.out.println("Total value of current sale : " + SummaryTableView.getTotalAmt());
        //
//        PromoSubmit.resetPromoSubmit();
        SaleType saleTypeSelected = null;
        for (SaleType type : SaleType.values()) {
            if (btnMenuSelection.getId().equalsIgnoreCase(type.name())) {
                saleTypeSelected = type;
                break;
            }
        }
        getMenuSelection();
//        selectedPromo = getSelectedPromo(saleTypeSelected);

//        if (selectedPromo != null) {
//            System.out.println("selectedPromo = " + selectedPromo.getPromoId());
//            showPromo(selectedPromo);
//        } else {
//            getMenuSelection();
//        }
    }

//    private Promotion getSelectedPromo(SaleType saleTypeSelected) {
//        selectedPromo = null;
//        if (!listPromos.isEmpty()) {
//            for (Promotion p : listPromos) {
//                System.out.println("promo id = " + p.getPromoId() + " : promo name = " + p.getName()
//                        + " : promo enabled = " + p.isEnabled());
//                if (!p.getListTransTypes().isEmpty()) {
//                    for (UserTransactionType t : p.getListTransTypes()) {
//                        if (p.isEnabled() && t.getType().equalsIgnoreCase(saleTypeSelected.getType())) {
//                            selectedPromo = p;
//                            break;
//                        } else {
//                            selectedPromo = null;
//                        }
//                    }
//                    // need to break here as well if already found active matched promo
//                    if (selectedPromo != null) {
//                        break;
//                    }
//                }
//            }
//        }
//
//        return selectedPromo;
//    }

    private void resetNFCSubscriber() {
        if (ActiveNFCSubscriber.getInstance().getConsumerProfile() != null) {
            ActiveNFCSubscriber.resetActiveNFCSubscriber();
        }
    }

    private void getMenuSelection() {
        UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);

        StringBuilder sb = new StringBuilder("\n");
        sb.append(" * * * * * * * * * transaction start * * * * * * * * * ").append("\n");
        sb.append(("\t\t>>>>> \tStarting sale from Menu  : \t\t").concat(SaleType.valueOf(btnMenuSelection.getId()).toString()));
        LOG.info(sb.toString());

        switch (SaleType.valueOf(btnMenuSelection.getId())) {
            case VOUCHERS:
                clearAndChangeContent(new MenuVouchers());
                break;
            case CHAT4CHANGE:
                MerchantCopy.resetMerchantCopy();
                MerchantCopy.getInstance().setTransType(btnMenuSelection.getText());
                Chat4ChangeSale.resetChat4ChangeSale();
                clearAndChangeContent(new Chat4Change(false));
                break;
            case TOPUP:
                clearAndChangeContent(new MenuTopups());
                break;
            case ELECTRICITY:
                clearAndChangeContent(new ElectricitySupplierSelect());
                break;
            case TICKETING:
                clearAndChangeContent(new TicketingMenu());
                break;
            case BILLPAYMENTS:
                clearAndChangeContent(new BillPaymentMenu());
                break;
            case RICA:
                clearAndChangeContent(new RICALogin());
                break;
            case MONEY_TRANSFER:
                clearAndChangeContent(new MoneyTransferMenu());
                break;
            case LOTTO:
                clearAndChangeContent(new LottoMenu());
                break;
            case SEARCH_PRODUCT:
                clearAndChangeContent(new SearchMenu());
                break;
            default:
                clearAndChangeContent(null);
                break;
        }
    }

    public static void clearAndChangeContent(Region newRegion) {
        vbSalesContent.getChildren().clear();
        if (newRegion != null) {
            vbSalesContent.getChildren().add(newRegion);
        }
    }

    public static void clearAndShowFavourites() {
        vbSalesContent.getChildren().clear();
        vbSalesContent.getChildren().add(new Favourites());
    }

    public static void refreshSalesTable() {
        if (SceneSales.getVbSalesTable().getChildren().size() > 1) {
            SceneSales.getVbSalesTable().getChildren().remove(0);
            SceneSales.getVbSalesTable().getChildren().add(0, SceneSales.makeSummaryTable());
        }
    }

    // getters and setters
    public static VBox getVbSalesTable() {
        return vbSalesTable;
    }

    public static Label getLblSalesPerson() {
        return lblSalesPerson;
    }

    public static Text getTxtItemCount() {
        return txtItemCount;
    }

    //    public static Label getLblTime() {
//        return lblTime;
//    }
    public static Button getBtnAmtDue() {
        return btnAmtDue;
    }

    public static Button getBtnRemove() {
        return btnRemove;
    }

    public static Button getBtnLogout() {
        return btnLogout;
    }

    public static Button getBtnMainMenu() {
        return btnMainMenu;
    }

    public static Button getBtnShiftEnd() {
        return btnShiftEnd;
    }

    public static Button getOpenCashDraw() {
        return btnOpenCashDraw;
    }

//    private List<Promotion> getListTestPromos() {
//        List<Promotion> listTest = new ArrayList<>();
//
//        Promotion promo1 = new Promotion();
//        promo1.setPromoId(2);
//        promo1.setName("First Test Promo");
//        promo1.setEnabled(false);
//        promo1.setTextscreen("Make up some stuff for First Test Promo");
//        List<UserTransactionType> listType1 = new ArrayList<>();
//        UserTransactionType type1 = new UserTransactionType();
//        type1.setType("Ticketxxxs");
//        UserTransactionType type4 = new UserTransactionType();
//        type4.setType("Tickets");
//
//        listType1.add(type1);
//        listType1.add(type4);
//        promo1.getListTransTypes().addAll(listType1);
//        listTest.add(promo1);
//
//        Promotion promo2 = new Promotion();
//        promo2.setPromoId(3);
//        promo2.setName("Second Test Promo");
//        promo2.setEnabled(true);
//        promo2.setTextscreen("Make up some stuff for Second Test Promo");
//        List<UserTransactionType> listType2 = new ArrayList<>();
//        UserTransactionType type2 = new UserTransactionType();
//        type2.setType("Bundles");
//        UserTransactionType type3 = new UserTransactionType();
//        type3.setType("Payments");
//
//        listType2.add(type2);
//        listType2.add(type3);
//        promo2.getListTransTypes().addAll(listType2);
//        listTest.add(promo2);
//
//        return listTest;
//    }
}
