package jkiosk3.store;

import java.io.Serializable;

/**
 *
 * @author Val
 */
public class StoreJKSetup implements Serializable {

    // Offline Options
    private boolean offlineSales = false;
    private boolean clearTransTypes = false;
    private boolean clearUserList = false;
    private String offlineIP = "127.0.0.1";
    private int offlinePort = 1562;

    public boolean isClearTransTypes() {
        return clearTransTypes;
    }

    public void setClearTransTypes(boolean clearTransTypes) {
        this.clearTransTypes = clearTransTypes;
    }

    public boolean isClearUserList() {
        return clearUserList;
    }

    public void setClearUserList(boolean clearUserList) {
        this.clearUserList = clearUserList;
    }

    public String getOfflineIP() {
        return offlineIP;
    }

    public void setOfflineIP(String offlineIP) {
        this.offlineIP = offlineIP;
    }

    public int getOfflinePort() {
        return offlinePort;
    }

    public void setOfflinePort(int offlinePort) {
        this.offlinePort = offlinePort;
    }

    public boolean isOfflineSales() {
        return offlineSales;
    }

    public void setOfflineSales(boolean offlineSales) {
        this.offlineSales = offlineSales;
    }
}
