package jkiosk3.sales;

import java.util.Date;

/**
 *
 * @author Valerie
 */
public class MerchantCopy {

    private String transType;
    private String product;
    private double amount;
    private int quantity;
    private double totalDue;
    private String serial;
    private int stockID;
    private String transRef;
    private Date date;
    private String cashier;
    private String tenderType;
    private int shiftNo;
    private int sequenceNo;

    private static volatile MerchantCopy instance;

    private static MerchantCopy newInstance() {
        instance = new MerchantCopy();
        return instance;
    }

    public static MerchantCopy getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    public static void resetMerchantCopy() {
        instance = null;
    }

    // getters and setters
    /**
     * Use for Sale Types for which the Tender Type is not yet known, i.e. Vouchers, Chat 4 Change, Topup and Electricity, and
     * which do not require a consolidated Merchant Copy.
     *
     * @param shiftNo the Shift Number retrieved in the server response
     * @param sequenceNo the Sequence Number retrieved in the server response
     * @param product the Product name or description
     * @param amount the amount payable for the transaction
     * @param serial the Serial Number of the Voucher, only applicable to Vouchers and Chat 4 Change
     * @param stockID if Sale Type is Vouchers, use the Stock ID instead of the Transaction Reference
     * @param transRef the Transaction Reference retrieved in the server response
     * @param date the transaction date and time
     * @param cashier the Cashier making the sale
     */
    public void setDetails(int shiftNo, int sequenceNo, String product, double amount, String serial, int stockID,
            String transRef, Date date, String cashier) {
        setDetails(shiftNo, sequenceNo, product, amount, serial, stockID, transRef, date, cashier, null, 0, 0);
    }

    /**
     * Use for Sale Types for which the Tender Type is already known, i.e. Ticketing and Bill Payments, and which do not require
     * a consolidated Merchant Copy.
     *
     * @param shiftNo the Shift Number retrieved in the server response
     * @param sequenceNo the Sequence Number retrieved in the server response
     * @param product the Product name or description
     * @param amount the amount payable for the transaction
     * @param serial the Serial Number of the Voucher, only applicable to Vouchers and Chat 4 Change
     * @param stockID if Sale Type is Vouchers, use the Stock ID instead of the Transaction Reference
     * @param transRef the Transaction Reference retrieved in the server response
     * @param date the transaction date and time
     * @param cashier the Cashier making the sale
     * @param tenderType the Tender Type used to pay for the transaction, not applicable to Vouchers, Chat 4 Change, Topup or
     * Electricity
     */
    public void setDetails(int shiftNo, int sequenceNo, String product, double amount, String serial, int stockID, String transRef,
            Date date, String cashier, String tenderType) {
        setDetails(shiftNo, sequenceNo, product, amount, serial, stockID, transRef, date, cashier, tenderType, 0, 0);
    }

    /**
     * Use for Sale Types for which the Tender Type is already known, i.e. Ticketing and Bill Payments, and which require a
     * consolidated Merchant Copy.
     *
     * @param shiftNo the Shift Number retrieved in the server response
     * @param sequenceNo the Sequence Number retrieved in the server response
     * @param product the Product name or description
     * @param amount the amount payable for the transaction
     * @param serial the Serial Number of the Voucher, only applicable to Vouchers and Chat 4 Change
     * @param stockID if Sale Type is Vouchers, use the Stock ID instead of the Transaction Reference
     * @param transRef the Transaction Reference retrieved in the server response
     * @param date the transaction date and time
     * @param cashier the Cashier making the sale
     * @param tenderType the Tender Type used to pay for the transaction, not applicable to Vouchers, Chat 4 Change, Topup or
     * Electricity
     * @param quantity use when selling multiple vouchers in one sale
     * @param totalDue the total due for the multiple voucher sale, i.e. quantity multiplied by amount
     */
    public void setDetails(int shiftNo, int sequenceNo, String product, double amount, String serial, int stockID, String transRef,
            Date date, String cashier, String tenderType, int quantity, double totalDue) {
        this.shiftNo = shiftNo;
        this.sequenceNo = sequenceNo;
        this.product = product;
        this.amount = amount;
        this.serial = serial;
        this.stockID = stockID;
        this.transRef = transRef;
        this.date = date;
        this.cashier = cashier;
        this.tenderType = tenderType;
        this.quantity = quantity;
        this.totalDue = totalDue;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getProduct() {
        return product;
    }

    public double getAmount() {
        return amount;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getTotalDue() {
        return totalDue;
    }

    public String getSerial() {
        return serial;
    }

    public int getStockID() {
        return stockID;
    }

    public String getTransRef() {
        return transRef;
    }

    public Date getDate() {
        return date;
    }

    public String getCashier() {
        return cashier;
    }

    public String getTenderType() {
        return tenderType;
    }

    public int getShiftNo() {
        return shiftNo;
    }

    public int getSequenceNo() {
        return sequenceNo;
    }
}
