package jkiosk3;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.management.ManagementFactory;
import java.nio.channels.FileLock;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

import javafx.stage.WindowEvent;
import jkiosk3._common.JKMedia;
import jkiosk3._common.JKText;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.BusyScene;
import jkiosk3._components.InputPopup;
import jkiosk3._components.Keyboard;
import jkiosk3._components.MagCardPrompt;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.NumberPad;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.WebPage;
import jkiosk3._components.update.StageUpdates;
import jkiosk3.reports.Reprints;
import jkiosk3.sales._tender.PaymentTender;
import jkiosk3.store.JKDevLocation;
import jkiosk3.store.JKDialup;
import jkiosk3.store.JKSystem;
import jkiosk3.store.cache.CacheController;
import jkiosk3.users.SalesUserLogin;
import jkiosk3.utilities.DialupConnection;

public class JKiosk3 extends Application {

    private final static Logger logger = Logger.getLogger(JKiosk3.class.getName());
    private static Stage mainStage;
    private static Scene scene;
    private final static List<Node> componentStack = new ArrayList<>();
    private static CoolRegion rootRegion;
    private static BusyScene busy;
    private static InputPopup inputPopup;
    private static Keyboard keyboard;
    private static MagCardPrompt magCardPrompt;
    private static MessageBox msgBox;
    private static NumberPad numPad;
    private static PaymentTender payTender;
    private static PrintPreview printPreview;
    private static SalesUserLogin salesUserLogin;
    private static WebPage webPage;
    private static CacheController cacheController;

    /**
     * The main() method is ignored in correctly deployed JavaFX application. main() serves only as fallback in case the
     * application can not be launched through deployment artifacts, e.g., in IDEs with limited FX support. NetBeans
     * ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            JK3Log.makeLogHandlers();
            StringBuilder sb = new StringBuilder("\r\n");
            sb.append(" - - - - - - - - - - - - - - - - -").append("\r\n");
            sb.append(" - - - LOG HANDLERS CREATED  - - -");
            logger.info(sb.toString());
        } catch (IOException ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }

        logger.info(" - - - CREATING UPDATE STAGE - - -");
        StageUpdates stageUpdates = new StageUpdates(new ResultCallback() {

            @Override
            public void onResult(boolean result) {
                if (result) {
                    loadJKiosk3();
                } else {
                    logger.info(" - - - UPDATES FAILED - PROGRAM MIGHT NOT RUN CORRECTLY - - -");
                    logger.info(" - - -                JKIOSK WILL CLOSE                 - - -");
                    System.exit(0);
                }
            }
        });
    }

    private void loadJKiosk3() {
        NumberFormat format = NumberFormat.getInstance();

        long diskSize = (((new File("/").getTotalSpace()) / 1024) / 1024) / 1024;       // KB / MB / GB
        long memorySize = ((com.sun.management.OperatingSystemMXBean) ManagementFactory
                .getOperatingSystemMXBean()).getTotalPhysicalMemorySize();
        double memGB = ((memorySize / 1024.0) / 1024.0) / 1024.0;
        String memStr = format.format(memGB);

        StringBuilder sb = new StringBuilder("\r\n");
        sb.append(" ================================================================= ").append("\r\n");
        sb.append(" >>>>>  OPERATING SYSTEM NAME        :  ").append(System.getProperty("os.name")).append("\r\n");
        sb.append(" >>>>>  OPERATING SYSTEM VERSION     :  ").append(System.getProperty("os.version")).append("\r\n");
        sb.append(" >>>>>  SYSTEM ARCHITECTURE          :  ").append(System.getProperty("os.arch")).append("\r\n");
        sb.append(" >>>>>  DISK SIZE                    :  ").append(diskSize).append(" GB").append("\r\n");
        sb.append(" >>>>>  TOTAL SYSTEM RAM             :  ").append(memStr).append(" GB").append("\r\n");
        sb.append(" >>>>>  JAVA JRE VERSION             :  ").append(System.getProperty("java.runtime.version")).append("\r\n");
        sb.append(" >>>>>  JAVA VIRTUAL MACHINE         :  ").append(System.getProperty("java.vm.name")).append("\r\n");
        sb.append(" >>>>>  JKIOSK3 APPLICATION VERSION  :  ").append(Version.getSoftwareVersion()).append(Version.getVersionNum()).append("\r\n");
        sb.append(" >>>>>  JKIOSK3 DEVICE ID            :  ").append(JKSystem.getSystemConfig().getDeviceId()).append("\r\n");
        if (JKDevLocation.getDeviceLocation().getDeviceAddress() != null) {
            sb.append(" >>>>>  JKIOSK3 DEVICE LOCATION      :  ").append(JKDevLocation.getDeviceLocation().getFormattedLocation()).append("\r\n");
            sb.append(" >>>>>  JKIOSK3 DEVICE ADDRESS       :  ").append(JKDevLocation.getDeviceLocation().getDeviceAddress()).append("\r\n");
        } else {
            sb.append(" >>>>>  JKIOSK3 DEVICE LOCATION      :  NOT AVAILABLE").append("\r\n");
        }
        sb.append(" ================================================================= ").append("\r\n");
        logger.info(sb.toString());

        if (!isApplicationAlreadyRunning()) {
            if (JOptionPane.showConfirmDialog(null,
                    "\nAnother instance of JKiosk is already running.\n\nPlease restore from Windows TaskBar\n",
                    "JKiosk is already running",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE) == 0) {
                System.exit(0);
            }
        }

        mainStage = new StageJKiosk();
        mainStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                closeJKiosk();
            }
        });
//        mainStage.setOnCloseRequest(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                closeJKiosk();
//            }
//        });

        StackPane root = new StackPane();

        scene = new Scene(root, StageJKiosk.getSceneWidth(), StageJKiosk.getSceneHeight());

        scene.getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/default.css").toExternalForm());

        String providerStyle = "file:media/providerStyle.css";
        if (JKMedia.isStylesheetDownload()) {
            scene.getStylesheets().add(providerStyle);
        } else {
            scene.getStylesheets().add(getClass().getClassLoader().getResource("jkiosk3/styles/providerStyle.css").toExternalForm());
        }
        Font.loadFont(JKText.fontConsolas, 10);

        root.setPrefSize(scene.getWidth(), scene.getHeight());

        cacheController = new CacheController();
        CacheController.setFirstLogin(true);

        buildComponentStack();

        mainStage.setScene(scene);
        mainStage.show();

        rootRegion = new CoolRegion();

        root.getChildren().add(rootRegion);

        changeScene(new SceneSplash());
    }

    private static void buildComponentStack() {
        busy = new BusyScene();
        busy.setVisible(false);
        componentStack.add(busy);

        inputPopup = new InputPopup();
        inputPopup.setVisible(false);
        componentStack.add(inputPopup);

        keyboard = new Keyboard();
        keyboard.setVisible(false);
        componentStack.add(keyboard);

        magCardPrompt = new MagCardPrompt();
        magCardPrompt.setVisible(false);
        componentStack.add(magCardPrompt);

        msgBox = new MessageBox();
        msgBox.setVisible(false);
        componentStack.add(msgBox);

        numPad = new NumberPad();
        numPad.setVisible(false);
        componentStack.add(numPad);

        payTender = new PaymentTender();
        payTender.setVisible(false);
        componentStack.add(payTender);

        printPreview = new PrintPreview();
        printPreview.setVisible(false);
        componentStack.add(printPreview);

        salesUserLogin = new SalesUserLogin();
        salesUserLogin.setVisible(false);
        componentStack.add(salesUserLogin);

        webPage = new WebPage();
        webPage.setVisible(false);
        componentStack.add(webPage);
    }

    private static boolean isApplicationAlreadyRunning() {
        try {
            final File file = new File("Instance.txt");
            final RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");
            final FileLock fileLock = randomAccessFile.getChannel().tryLock();

            if (fileLock != null) {
                Runtime.getRuntime().addShutdownHook(new Thread() {
                    @Override
                    public void run() {
                        try {
                            fileLock.release();
                            randomAccessFile.close();
                            file.delete();
                        } catch (IOException e) {
                            System.out.println("Unable to remove lock file.");
                            e.printStackTrace(System.out);
                        }
                    }
                });

                return true;
            }
        } catch (IOException e) {
            System.out.println("Unable to create and/or lock file.");
            e.printStackTrace(System.out);
        }

        return false;
    }

    public static void returnToLogin() {
//        Platform.runLater(new Runnable() {
//            @Override
//            public void run() {
//                JKiosk3.getBusy().hideBusy();
//                JKiosk3.getMsgBox().showMsgBox("Connection Error", "The connection was interrupted", null,
//                        MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
//                    @Override
//                    public void onOk() {
//                        JKiosk3.changeScene(new JKioskLogin());
//                    }
//
//                    @Override
//                    public void onCancel() {
//                        //
//                    }
//                });
//            }
//        });

        returnToLogin("Connection Error", "The connection was interrupted");
    }

    public static void returnToLogin(final String msgHead, final String msgBody) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                JKiosk3.getBusy().hideBusy();
                JKiosk3.getMsgBox().showMsgBox(msgHead, msgBody, null,
                        MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                            @Override
                            public void onOk() {
                                JKiosk3.changeScene(new JKioskLogin());
                            }

                            @Override
                            public void onCancel() {
                                //
                            }
                        });
            }
        });
    }

    public static void closeJKiosk() {
        if (JKioskLogin.getTrans() != null) {
            JKioskLogin.getTrans().stop();
        }

        if (JKDialup.getDialupConnect().isAutoConn()) {
            if (DialupConnection.getInstance().isConnected(JKDialup.getDialupConnect().getAutoConnName())) {
                if (JKDialup.getDialupConnect().isAutoDisconn()) {
                    DialupConnection.getInstance().closeConnection(JKDialup.getDialupConnect().getAutoConnName());
                }
            }
        }
        if (Reprints.getListSched() != null && !Reprints.getListSched().isEmpty()) {
            for (ScheduledExecutorService s : Reprints.getListSched()) {
                s.shutdown();
                logger.info(("shutting down list of ScheduledExecutorService items : ").concat(Boolean.toString(s.isShutdown())));
            }
            Reprints.getListSched().clear();
        }
        if (cacheController.getScheduledCacheExecutor() != null) {
            cacheController.getScheduledCacheExecutor().shutdown();
            logger.info("Shutdown ScheduledExecutorService for Product Caching on Application close.");
        }
        if (mainStage != null) {
            StringBuilder sb = new StringBuilder("\r\n");
            sb.append(" ===== Closing JKiosk3 Application =============================== ").append("\r\n");
            sb.append(" =================================================================");
            logger.info(sb.toString());
//            logger.info(("\r\n").concat(" ===== Closing JKiosk3 Application =============================== ").concat("\r\n"));
            mainStage.close();
            System.exit(0);
        }
    }

    public static void changeScene(Region newScene) {
        rootRegion.setContent(newScene);
    }

    // getters
    public static Stage getMainStage() {
        return mainStage;
    }

    public static Scene getScene() {
        return scene;
    }

    public static List<Node> getComponentStack() {
        return componentStack;
    }

    public static BusyScene getBusy() {
        return busy;
    }

    public static InputPopup getInputPopup() {
        return inputPopup;
    }

    public static Keyboard getKeyboard() {
        return keyboard;
    }

    public static MagCardPrompt getMagCardPrompt() {
        return magCardPrompt;
    }

    public static MessageBox getMsgBox() {
        return msgBox;
    }

    public static NumberPad getNumPad() {
        return numPad;
    }

    public static PaymentTender getPayTender() {
        return payTender;
    }

    public static PrintPreview getPrintPreview() {
        return printPreview;
    }

    public static SalesUserLogin getSalesUserLogin() {
        return salesUserLogin;
    }

    public static WebPage getWebPage() {
        return webPage;
    }

    public static CacheController getCacheController() {
        return cacheController;
    }

    // Region for changing views...
    private static class CoolRegion extends Region {

        public void setContent(Region content) {
            getChildren().clear();
            getChildren().add(content);
        }
    }

//    private void getSystemDetails() {
//        Runtime runtime = Runtime.getRuntime();
//
//        long memory = runtime.maxMemory();
//
//        long diskSize = new File("/").getTotalSpace();
//
//        long memorySize = ((com.sun.management.OperatingSystemMXBean) ManagementFactory
//                .getOperatingSystemMXBean()).getTotalPhysicalMemorySize();
//
////        OperatingSystemMXBean osMBean = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
////
////        RuntimeMXBean runtimeMBean = ManagementFactory.getRuntimeMXBean();
////
////        System.out.println("Operating system:\t" + osMBean.getName());
////        System.out.println("Architecture:\t\t" + osMBean.getArch());
////        System.out.println("Number of processors:\t" + osMBean.getAvailableProcessors());
////        System.out.println("Process CPU time:\t" + osMBean.getProcessCpuTime());
////        System.out.println("Total physical memory:\t" + osMBean.getTotalPhysicalMemorySize() / 1024 + " kB");
////        System.out.println("Free physical memory:\t" + osMBean.getFreePhysicalMemorySize() / 1024 + " kB");
////        System.out.println("Comm. virtual memory:\t" + osMBean.getProcessCpuTime() / 1024 + " kB");
////
////        System.out.println("Total swap space:\t" + osMBean.getTotalSwapSpaceSize() / 1024 + " kB");
////        System.out.println("Free swap space:\t" + osMBean.getFreeSwapSpaceSize() / 1024 + " kB");
//    }
}
