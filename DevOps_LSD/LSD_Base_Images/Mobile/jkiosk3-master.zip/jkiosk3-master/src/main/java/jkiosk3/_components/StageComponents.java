package jkiosk3._components;

import com.teamdev.jxmaps.MapViewOptions;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import jkiosk3.JKiosk3;
import jkiosk3.StageJKiosk;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import za.co.blt.jfxcalendar.JFXCalendar;
import za.co.blt.jfxnumberselector.JFXNumberSelector;
import za.co.blt.jfxnumberselector.JFXNumberSelectorResult;
import za.co.blt.jfxnumberselector.JFXNumbersRequired;

import java.awt.Dimension;

public class StageComponents {

    private final static Stage JK_STAGE = JKiosk3.getMainStage();
    private final static double SCENE_WIDTH = StageJKiosk.getSceneWidth();
    private final static double SCENE_HEIGHT = StageJKiosk.getSceneHeight();
    private final static Dimension DIM_SCENE = new Dimension((int) SCENE_WIDTH, (int) SCENE_HEIGHT);

    private static Stage getComponentStage() {
        Stage stage = new Stage(StageStyle.UNDECORATED);
//        Stage stage = new Stage(StageStyle.TRANSPARENT);
        stage.initOwner(JK_STAGE);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setX(JK_STAGE.getX() + 8d);
        stage.setY(JK_STAGE.getY() + 15d);
//        stage.setY(JK_STAGE.getY() + 25d);
        return stage;
    }

    private static Scene getComponentScene(Parent popupNode, String stylesheetName) {
        Scene scene = new Scene(popupNode);
        scene.getStylesheets().add(StageComponents.class.getClassLoader().getResource("jkiosk3/styles/" + stylesheetName).toExternalForm());
        return scene;
    }

    public static void showStageCalendar(TextField txtfield) {
        Stage stageCalendar = getComponentStage();

        Dimension dimCalendar = new Dimension(((int) (SCENE_WIDTH * 0.70)), ((int) (SCENE_HEIGHT * 0.65)));
        JFXCalendar cal = new JFXCalendar(stageCalendar, DIM_SCENE, dimCalendar, txtfield);

        stageCalendar.setScene(getComponentScene(cal, "jfxcalendar.css"));
        stageCalendar.showAndWait();
    }

    public static void showStageNumberSelector(JFXNumbersRequired required, Dimension stageDimensions, JFXNumberSelectorResult result) {
        Stage stageNumberSelector = getComponentStage();

        JFXNumberSelector num = new JFXNumberSelector(stageNumberSelector, DIM_SCENE,
                stageDimensions, required, result);

        stageNumberSelector.setScene(getComponentScene(num, "jfxnumberselector.css"));
        stageNumberSelector.showAndWait();
    }

    public static void showMapSelectStage(final Text txtAddress, final Text txtLatLng, final Text txtLatitude, final Text txtLongitude) {
        final Stage stageJxMaps = getComponentStage();
        stageJxMaps.setY(JK_STAGE.getY() + 4d);

        TextField searchField = new TextField();
        searchField.setMaxWidth(175);
        searchField.setStyle("-fx-font-size: 12pt;");

        // The only way to read the console messages is to enable logging.
        // You can enable logging by adding the -Djxmaps.logging.level=ALL to the VM parameters of your application.
        // Please note, that your API key will be visible in the logs, so we do not recommend to share them with third-party sources.
        MapViewOptions options = new MapViewOptions();
        options.setApiKey("AIzaSyCOJNglJDd3VwASwdPGJUijAFVh1m52Ay8");

        final WebViewJxMaps webViewJxMaps = new WebViewJxMaps(options, searchField);

        Label label = JKText.getLblDk("Is the correct address shown on the marker?  Click 'confirm', or zoom in and reselect", JKText.FONT_B_14);

        Button btnConfirm = JKNode.getBtnPopup("confirm");
        btnConfirm.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                String addressSelected = webViewJxMaps.getAddressSelected();
//                String latLngSelected = webViewJxMaps.getLatLngSelected();
                String latitudeSelected = webViewJxMaps.getLatitudeSelected();
                String longitudeSelected = webViewJxMaps.getLongitudeSelected();
                txtAddress.setText(addressSelected);
                txtLatitude.setText(latitudeSelected);
                txtLongitude.setText(longitudeSelected);
                txtLatLng.setText("[" + latitudeSelected + "," + longitudeSelected + "]");
                stageJxMaps.close();
                webViewJxMaps.closeMap();
            }
        });

        Button btnCancel = JKNode.getBtnPopup("cancel");
        btnCancel.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                stageJxMaps.close();
                webViewJxMaps.closeMap();
            }
        });

        HBox hBox = JKLayout.getHBox(0, JKLayout.sp);
        hBox.setStyle("-fx-padding: 5px 15px 5px 15px;");
        hBox.getChildren().addAll(searchField, label, JKNode.getHSpacer(), btnConfirm, btnCancel);

        // JxMap only seems to work in a StackPane
        StackPane stackPane = new StackPane();
        stackPane.setMaxSize(JK_STAGE.getWidth() - 15, JK_STAGE.getHeight() - 60);
        stackPane.setMinSize(JK_STAGE.getWidth() - 15, JK_STAGE.getHeight() - 60);
        stackPane.getChildren().add(webViewJxMaps);

        VBox vBox = new VBox(0);
        vBox.setPrefSize(JK_STAGE.getWidth() - 15, JK_STAGE.getHeight() - 15);
        vBox.getChildren().addAll(stackPane, hBox);

        stageJxMaps.setScene(getComponentScene(vBox, "default.css"));

        stageJxMaps.showAndWait();
    }

    public static void showStageTestPopup(String head, String info, String btnText, TextField txtFld) {
        Stage stageTestPopup = getComponentStage();

        NFCTapPrompt nfcTapPrompt = new NFCTapPrompt(head, info, btnText, txtFld, stageTestPopup);

        stageTestPopup.setScene(getComponentScene(nfcTapPrompt, "default.css"));
        stageTestPopup.showAndWait();
    }
    //
    // will need this in the future for Filterable list of items
    // *********************************************************
//    public static void showStageKeyboard(TextField txt, String info, String defaultText, boolean showExtended, 
//            List<String> list, JFXKeyboardResult res) {
//        Stage stageKeyboard = getComponentStage();
//
//        Dimension dim = new Dimension(((int) (DIM_SCENE.getWidth())), ((int) (DIM_SCENE.getHeight())));
//        JFXKeyboard kb = new JFXKeyboard(stageKeyboard, txt, dim, showExtended, list);
//        
//        stageKeyboard.setScene(getComponentScene(kb, "jfxkeyboard.css"));
//        if (res == null) {
//            kb.showKeyboard(txt, info, defaultText);
//        } else {
//            kb.showKeyboard(txt, info, defaultText, res);
//        }
//        stageKeyboard.showAndWait();
//    }    
}
