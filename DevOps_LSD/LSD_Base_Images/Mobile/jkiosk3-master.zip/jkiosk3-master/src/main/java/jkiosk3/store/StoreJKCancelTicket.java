package jkiosk3.store;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.Serializable;
import java.util.Date;

public class StoreJKCancelTicket implements Serializable, Comparable {
    private final static long serialVersionUID = 99139L;
    private Date transactionDate;   //use this to determine if transaction occurred in last 30 mins
    private String transRef;        //used for searching the cancel ticket cache and the request to aeon to cancel the booking
    private String transId;         //used for searching the cancel ticket cache
    private String transType;       //this is used in the auth request before cancelling the booking
    private String carrier;         //use the carrier code to display the carrier logo
    private String carrierName;     //used to display booking details to confirm before cancelling
    private int qty;                //used to display booking details to confirm before cancelling
    private String departure;       //used to display booking details to confirm before cancelling
    private String destination;     //used to display booking details to confirm before cancelling
    private String travelTime;      //used to display booking details to confirm before cancelling

    public StoreJKCancelTicket() {
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getCarrierName() {
        return carrierName;
    }

    public void setCarrierName(String carrierName) {
        this.carrierName = carrierName;
    }

    public String getTransRef() {
        return transRef;
    }

    public void setTransRef(String transRef) {
        this.transRef = transRef;
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getTravelTime() {
        return travelTime;
    }

    public void setTravelTime(String travelTime) {
        this.travelTime = travelTime;
    }

    @Override
    public String toString() {
        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").serializeNulls().create();
        return gson.toJson(this);
    }

    @Override
    public int compareTo(Object o) {
        if (o != null) {
            return transactionDate.compareTo(((StoreJKCancelTicket) o).getTransactionDate()) * -1;
        }
        return 0;
    }

}
