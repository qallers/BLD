package jkiosk3._components;

import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

/**
 *
 * @author Val
 */
public class ControlSearchAndCancel extends Region {

    private Button btnSearch;
    private Button btnCancel;

    public ControlSearchAndCancel() {
        getChildren().add(getBtnControls());
    }

    private HBox getBtnControls() {

        btnSearch = JKNode.getBtnSm("Search");
        btnSearch.setWrapText(true);

        btnCancel = JKNode.getBtnSm("Cancel");

        HBox hb = JKLayout.getControlsHBox();

        hb.getChildren().addAll(JKNode.getHSpacer(), btnSearch, btnCancel);

        return hb;
    }

    public Button getBtnSearch() {
        return btnSearch;
    }

    public Button getBtnCancel() {
        return btnCancel;
    }
}
