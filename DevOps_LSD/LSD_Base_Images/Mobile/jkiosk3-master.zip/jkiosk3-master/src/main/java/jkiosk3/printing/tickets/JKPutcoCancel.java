package jkiosk3.printing.tickets;

import aeonticketpros.bus.TicketProBusAutoCancelReq;
import jkiosk3.store.Store;

public class JKPutcoCancel {

    private static StoreJKPutcoCancel putcoCancelRequests;

    private static void loadPutcoCancel() {
        if ((putcoCancelRequests == null) || (putcoCancelRequests.getListAutoCancelReq().isEmpty())) {
            putcoCancelRequests = (StoreJKPutcoCancel) Store.loadObject(JKPutcoCancel.class.getSimpleName());
        }
        if (putcoCancelRequests == null) {
            putcoCancelRequests = new StoreJKPutcoCancel();
        }
    }

    public static boolean hasItems() {
        loadPutcoCancel();
        return putcoCancelRequests.getListAutoCancelReq().size() > 0;
    }

    public static void savePutcoCancelItem(TicketProBusAutoCancelReq autoCancelReq) {
        loadPutcoCancel();
        putcoCancelRequests.getListAutoCancelReq().add(autoCancelReq);
        Store.saveObject(JKPutcoCancel.class.getSimpleName(), putcoCancelRequests);
    }

    public static void removePutcoCancelItem(String transRef) {
        loadPutcoCancel();
        System.out.println("size of auto-cancel list before remove : " + putcoCancelRequests.getListAutoCancelReq().size());
        System.out.println("item transRef = " + transRef);
        for (TicketProBusAutoCancelReq i : putcoCancelRequests.getListAutoCancelReq()) {
            System.out.println("       i = " + i.getTransactionRef());
            if (i.getTransactionRef().equalsIgnoreCase(transRef)) {
                int index = putcoCancelRequests.getListAutoCancelReq().indexOf(i);
                System.out.println("   index = " + index);
                putcoCancelRequests.getListAutoCancelReq().remove(index);
                break;
            }
        }
        Store.saveObject(JKPutcoCancel.class.getSimpleName(), putcoCancelRequests);
        System.out.println("size of auto-cancel list after remove  : " + putcoCancelRequests.getListAutoCancelReq().size());
        checkForEmptyList();
    }

    private static void checkForEmptyList() {
        loadPutcoCancel();
        if (putcoCancelRequests.getListAutoCancelReq().isEmpty()) {
            clearPutcoCancelList();
        } else {
            Store.saveObject(JKPutcoCancel.class.getSimpleName(), putcoCancelRequests);
        }
    }

    public static void clearAndSaveAutoCancelList(StoreJKPutcoCancel autoCancelList) {
        clearPutcoCancelList();
        putcoCancelRequests = autoCancelList;
        Store.saveObject(JKPutcoCancel.class.getSimpleName(), putcoCancelRequests);
    }

    public static void clearPutcoCancelList() {
        if (putcoCancelRequests != null) {
            putcoCancelRequests.getListAutoCancelReq().clear();
        }
        Store.deleteObject(JKPutcoCancel.class.getSimpleName());
    }

    public static StoreJKPutcoCancel getPutcoCancelList() {
        loadPutcoCancel();
        return putcoCancelRequests;
    }
}
