package jkiosk3.sales;

import java.util.ArrayList;
import java.util.List;

import aeonusers.UserTransactionType;
import jkiosk3.sales.billpay.BillPayUtilMisc;
import jkiosk3.users.CurrentUser;

/**
 *
 * @author Val
 */
public class SalesMenu {

    private static boolean isEmergencyTopupAllowed = true;
    private static List<String> listBillPayMenu;

    private static List<SaleType> getAllowedSaleTypes() {
        List<SaleType> listSaleTypesAllowed = getSaleTypes();
        listBillPayMenu = new ArrayList<>();

        if (CurrentUser.isLoggedInOnline()) {
            List<String> onlineTransTypes = CurrentUser.getUser().getTransTypes();
            List<UserTransactionType> listUserTransTypes = CurrentUser.getUser().getUserTransactionTypes();
            /* This is a more efficient way of checking for items to be removed/included in Sales Menu. */
            /* This option ('type') did not exist when JKiosk was first developed. */
            List<String> listTransTypesType = new ArrayList<>();
            for (UserTransactionType utt : listUserTransTypes) {
                listTransTypesType.add(utt.getType());
            }

            if ((!onlineTransTypes.contains("Voucher")) && (!onlineTransTypes.contains("VoucherAMS"))) {
                listSaleTypesAllowed.remove(SaleType.VOUCHERS);
            }
            if (!onlineTransTypes.contains("C4C_Voucher")) {
                listSaleTypesAllowed.remove(SaleType.CHAT4CHANGE);
            }
            if ((!listTransTypesType.contains("Topup")) && (!listTransTypesType.contains("Bundles"))) {
                listSaleTypesAllowed.remove(SaleType.TOPUP);
            }
//            if ((!onlineTransTypes.contains("CellC")) && (!onlineTransTypes.contains("MTN"))
//                    && (!onlineTransTypes.contains("Neotel")) && (!onlineTransTypes.contains("TelkomMobile"))
//                    && (!onlineTransTypes.contains("Vodacom")) && (!onlineTransTypes.contains("TopupDemo"))) {
//                listSaleTypesAllowed.remove(SaleType.TOPUP);
//            }
            if (!onlineTransTypes.contains("Electricity")) {
                listSaleTypesAllowed.remove(SaleType.ELECTRICITY);
            }
            if (!listTransTypesType.contains("Tickets")) {
                listSaleTypesAllowed.remove(SaleType.TICKETING);
            }
//            if ((!onlineTransTypes.contains("CityToCity")) && (!onlineTransTypes.contains("Eldo"))
//                    /*&& (!onlineTransTypes.contains("SARoadLink"))*/ && (!onlineTransTypes.contains("Translux"))
//                    /*&& (!onlineTransTypes.contains("EQTickets"))*/
//                    && (!onlineTransTypes.contains("Intercape"))
//                    && (!onlineTransTypes.contains("TKP_TICKET"))) {
//                listSaleTypesAllowed.remove(SaleType.TICKETING);
//            }
            if ((!onlineTransTypes.contains("VASPayAtAccountPayment")) && (!onlineTransTypes.contains("VASPayAtBusTicket"))
                    && (!onlineTransTypes.contains("VASPayAtFinePayment")) && (!onlineTransTypes.contains("VASPayAtInsurance"))
                    && (!onlineTransTypes.contains("VASSAPOAccountPayment")) && (!onlineTransTypes.contains("VASSyntellAccountPayment"))
                    && (!onlineTransTypes.contains("VASSyntellFinePayment")) && (!onlineTransTypes.contains("Sanral"))
                    && (!onlineTransTypes.contains("BluBillPayment")) && (!onlineTransTypes.contains("MerchantTransfer"))) {
                listSaleTypesAllowed.remove(SaleType.BILLPAYMENTS);
            }
            // prepare Bill Payment menu items
            if (onlineTransTypes.contains("VASPayAtAccountPayment") || onlineTransTypes.contains("VASSAPOAccountPayment")
                    || onlineTransTypes.contains("VASSyntellAccountPayment") || onlineTransTypes.contains("BluBillPayment")) {
                listBillPayMenu.add(BillPayUtilMisc.TYPE_BILL_PAY);
            }
            if (onlineTransTypes.contains("VASPayAtFinePayment") || onlineTransTypes.contains("VASSyntellFinePayment")) {
                listBillPayMenu.add(BillPayUtilMisc.TYPE_TRAFFIC_FINE);
            }
            if (onlineTransTypes.contains("VASPayAtInsurance")) {
                listBillPayMenu.add(BillPayUtilMisc.TYPE_INSURE_PAY);
            }
            if (onlineTransTypes.contains("MerchantTransfer")) {
                listBillPayMenu.add(BillPayUtilMisc.TYPE_M2M_TRANSFER);
            }
            // end Bill Payment menu items
            if (!onlineTransTypes.contains("RICA")) {
                listSaleTypesAllowed.remove(SaleType.RICA);
            }
            if (!onlineTransTypes.contains("MoneyTransfer")) {
                listSaleTypesAllowed.remove(SaleType.MONEY_TRANSFER);
            }
            if (!onlineTransTypes.contains("Ithuba")) {
                listSaleTypesAllowed.remove(SaleType.LOTTO);
            }
            if (!onlineTransTypes.contains("EmergencyLoan")) {
                isEmergencyTopupAllowed = false;
            }
        }
        return listSaleTypesAllowed;
    }

    private static List<SaleType> getSaleTypes() {
        List<SaleType> listSaleTypes = new ArrayList<>();
        listSaleTypes.add(SaleType.VOUCHERS);
        listSaleTypes.add(SaleType.CHAT4CHANGE);
        listSaleTypes.add(SaleType.TOPUP);
        listSaleTypes.add(SaleType.ELECTRICITY);
        listSaleTypes.add(SaleType.TICKETING);
        listSaleTypes.add(SaleType.BILLPAYMENTS);
        listSaleTypes.add(SaleType.RICA);
        listSaleTypes.add(SaleType.MONEY_TRANSFER);
        listSaleTypes.add(SaleType.LOTTO);
        listSaleTypes.add(SaleType.SEARCH_PRODUCT);
        return listSaleTypes;
    }

    public static List<SaleType> getSalesMenu() {
        return getAllowedSaleTypes();
    }
    
    public static List<String> getListBillPayMenu() {
        return listBillPayMenu;
    }

    public static boolean isEmergencyTopupAllowed() {
        getAllowedSaleTypes();
        return isEmergencyTopupAllowed;
    }
}
