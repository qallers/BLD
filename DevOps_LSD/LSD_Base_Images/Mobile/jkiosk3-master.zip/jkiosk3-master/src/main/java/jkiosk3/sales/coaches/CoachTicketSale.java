package jkiosk3.sales.coaches;

import aeoncoach.*;
import aeonprinting.AeonPrintJob;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CoachTicketSale {

    private List<CoachCarrier> listCarriers = new ArrayList<>();
    private boolean returnTrip;
    private CoachListItem departureLoc;
    private CoachListItem destinationLoc;
    private Date dateDepart;
    private Date dateReturn;
    private int seats;
//    private int seatsAdult;
//    private int seatsChild;
//    private int seatsInfant;
    private CoachCarrier coachCarrierDepart;
    private CoachCarrier coachCarrierReturn;
    private CoachAvailabilityResp coachAvailabilityResp;
    private CoachRoute routeDepart;
    private CoachRoute routeReturn;
    private List<CoachPassenger> listPassengers = new ArrayList<>();
//    private List<CoachPassenger> listInfantsOnLap = new ArrayList<>();
    private String emergencyContactName;
    private String emergencyContactNum;
    private CoachReserveResp coachReserveResp;
    private List<CoachTicket> listCoachTickets = new ArrayList<>();
    private List<AeonPrintJob> listCoachTicketPrintJobs = new ArrayList<>();

    //
    private static CoachTicketSale instance;

    private static CoachTicketSale newInstance() {
        instance = new CoachTicketSale();
        return instance;
    }

    public static CoachTicketSale getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    public static void resetCoachTicketSale() {
        instance = null;
    }
    //

    public List<CoachCarrier> getListCarriers() {
        return listCarriers;
    }

    public boolean isReturnTrip() {
        return returnTrip;
    }

    public void setReturnTrip(boolean returnTrip) {
        this.returnTrip = returnTrip;
    }

    public CoachListItem getDepartureLoc() {
        return departureLoc;
    }

    public void setDepartureLoc(CoachListItem departureLoc) {
        this.departureLoc = departureLoc;
    }

    public CoachListItem getDestinationLoc() {
        return destinationLoc;
    }

    public void setDestinationLoc(CoachListItem destinationLoc) {
        this.destinationLoc = destinationLoc;
    }

    public Date getDateDepart() {
        return dateDepart;
    }

    public void setDateDepart(Date dateDepart) {
        this.dateDepart = dateDepart;
    }

    public Date getDateReturn() {
        return dateReturn;
    }

    public void setDateReturn(Date dateReturn) {
        this.dateReturn = dateReturn;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public CoachCarrier getCoachCarrierDepart() {
        return coachCarrierDepart;
    }

    public void setCoachCarrierDepart(CoachCarrier coachCarrierDepart) {
        this.coachCarrierDepart = coachCarrierDepart;
    }

    public CoachCarrier getCoachCarrierReturn() {
        return coachCarrierReturn;
    }

    public void setCoachCarrierReturn(CoachCarrier coachCarrierReturn) {
        this.coachCarrierReturn = coachCarrierReturn;
    }

    public CoachAvailabilityResp getCoachAvailabilityResp() {
        return coachAvailabilityResp;
    }

    public void setCoachAvailabilityResp(CoachAvailabilityResp coachAvailabilityResp) {
        this.coachAvailabilityResp = coachAvailabilityResp;
    }

    public CoachRoute getRouteDepart() {
        return routeDepart;
    }

    public void setRouteDepart(CoachRoute routeDepart) {
        this.routeDepart = routeDepart;
    }

    public CoachRoute getRouteReturn() {
        return routeReturn;
    }

    public void setRouteReturn(CoachRoute routeReturn) {
        this.routeReturn = routeReturn;
    }

    public List<CoachPassenger> getListPassengers() {
        return listPassengers;
    }

    public String getEmergencyContactName() {
        return emergencyContactName;
    }

    public void setEmergencyContactName(String emergencyContactName) {
        this.emergencyContactName = emergencyContactName;
    }

    public String getEmergencyContactNum() {
        return emergencyContactNum;
    }

    public void setEmergencyContactNum(String emergencyContactNum) {
        this.emergencyContactNum = emergencyContactNum;
    }

    public CoachReserveResp getCoachReserveResp() {
        return coachReserveResp;
    }

    public void setCoachReserveResp(CoachReserveResp coachReserveResp) {
        this.coachReserveResp = coachReserveResp;
    }

    public List<CoachTicket> getListCoachTickets() {
        return listCoachTickets;
    }

    public List<AeonPrintJob> getListCoachTicketPrintJobs() {
        return listCoachTicketPrintJobs;
    }
}
