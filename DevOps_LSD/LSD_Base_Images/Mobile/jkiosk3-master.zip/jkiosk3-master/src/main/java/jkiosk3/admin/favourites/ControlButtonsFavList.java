package jkiosk3.admin.favourites;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;

public class ControlButtonsFavList extends Region {

    private Button btnSave;
    private Button btnCancel;

    public ControlButtonsFavList() {
        getChildren().add(getBtnControls());
    }

    private HBox getBtnControls() {

        btnSave = JKNode.getBtnPopupDbl("Save");
        btnSave.setFont(JKText.FONT_B_20);

        btnCancel = JKNode.getBtnPopupDbl("Cancel");
        btnCancel.setFont(JKText.FONT_B_20);
        btnCancel.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneFavourites.clearAndChangeContent(null);
            }
        });

        HBox hBox = JKLayout.getHBox(0, JKLayout.sp);
        hBox.setMinWidth(JKLayout.contentW - (2 * JKLayout.sp));
        hBox.setAlignment(Pos.CENTER_RIGHT);
        hBox.setStyle("-fx-padding: 15px 0px 0px 0px;");
        hBox.getChildren().addAll(JKNode.getHSpacer(), btnSave, btnCancel);

        return hBox;
    }

    public Button getBtnSave() {
        return btnSave;
    }

    public Button getBtnCancel() {
        return btnCancel;
    }
}
