package jkiosk3.sales.rica;

import aeonrica.Registration;
import aeonrica.RicaResponse;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SceneSales;

/**
 *
 * @author Val
 */
public class SubChOwnSimSp extends Region {

    private static Registration ricaReg;
    //
    private static SubReg1 pg1;
    private static SubReg2 pg2;
    private static SubReg3 pg3;
    private static SubReg4 pg4;

    public SubChOwnSimSp() {

        pg1 = new SubReg1();
        pg2 = new SubReg2();
        pg3 = new SubReg3();
        pg4 = new SubReg4();
//        pg4.getComRegisterBy().getItems().remove(0);
//        pg4.getRadMSISDN().setDisable(true);
        pg4.getListRadios().get(0).setDisable(true);

        List<Region> pages = new ArrayList<>();

        pages.add(pg1);
        pages.add(pg2);
        pages.add(pg3);
        pages.add(pg4);

        SubAll registration = new SubAll(pages);
        SubAll.getLblSubAction().setText("Change Owner - SIM or SP Number");
        SubAll.getBtnBack().setDisable(true);

        getChildren().add(registration);
    }

    public static void onClickSubmit() {

        ricaReg = RICARegistration.getRicaRegistration(null, pg1, pg2, pg3, pg4);

        RICAConfirm summary = new RICAConfirm(ricaReg);

        JKiosk3.getMsgBox().showMsgBox("RICA Summary", "Please confirm all details before proceeding", summary,
                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK_CANCEL, new MessageBoxResult() {
            @Override
            public void onOk() {
                RICAUtil.submitRicaRegistration(ricaReg, new RICAUtil.RicaResponseResult() {
                    @Override
                    public void ricaResponseResult(final RicaResponse ricaResponse) {
                        JKiosk3.getMsgBox().showMsgBox(ricaResponse.getMessage(), ricaResponse.getMessageDetails(), null,
                                MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
                            @Override
                            public void onOk() {
                                if (ricaResponse.getErrorCode() == 0) {
                                    SceneSales.clearAndChangeContent(new RICAMenu());
                                }
                            }

                            @Override
                            public void onCancel() {
                                //
                            }
                        });
                    }
                });
            }

            @Override
            public void onCancel() {
                //
            }
        });
    }
}
