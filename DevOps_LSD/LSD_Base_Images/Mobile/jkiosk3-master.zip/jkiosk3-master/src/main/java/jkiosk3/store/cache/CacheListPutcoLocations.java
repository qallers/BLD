package jkiosk3.store.cache;

import aeonticketpros.bus.TicketProBusLocatListResp;
import aeonticketpros.bus.TicketProBusLocation;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import jkiosk3.store.Store;

/**
 *
 * @author valeriew
 */
public class CacheListPutcoLocations {

    private static volatile ListPutcoLocations listPutcoLocations;

    private static ListPutcoLocations getListPutcoLocat() {
        if (listPutcoLocations == null) {
            listPutcoLocations = ((ListPutcoLocations) Store.loadObject(CacheListPutcoLocations.class.getSimpleName()));
        }
        if (listPutcoLocations == null) {
            listPutcoLocations = new ListPutcoLocations();
        }
        return listPutcoLocations;
    }

    private static void saveListPutcoLocate(ListPutcoLocations listPutLocat) {
        Store.saveObject(CacheListPutcoLocations.class.getSimpleName(), listPutLocat);
    }

    public static void saveListPutcoLocations(TicketProBusLocatListResp listLocats) {
        getListPutcoLocat();
        listPutcoLocations.getListPutcoLocations().clear();
        listPutcoLocations.getListPutcoLocations().addAll(listLocats.getListBusLocations());
        saveListPutcoLocate(listPutcoLocations);
    }

    public static boolean hasItems() {
        getListPutcoLocat();
        return !listPutcoLocations.getListPutcoLocations().isEmpty();
    }

    public static List<TicketProBusLocation> getListPutcoLocations() {
        getListPutcoLocat();
        List<TicketProBusLocation> listLocats = listPutcoLocations.getListPutcoLocations();
        Collections.sort(listLocats, new Comparator<TicketProBusLocation>() {
            @Override
            public int compare(TicketProBusLocation o1, TicketProBusLocation o2) {
                return o1.getLocationName().compareTo(o2.getLocationName());
            }
        });
        return Collections.unmodifiableList(listLocats);
    }

    public static void deleteCachePutcoLocations() {
        Store.deleteObject(CacheListPutcoLocations.class.getSimpleName());
    }

    public static long checkFileTime() {
        return Store.getFileTimestamp(CacheListPutcoLocations.class.getSimpleName());
    }
}
