package jkiosk3._components;

import MagCard.LomaMR3;
import MagCard.MSRE206;
import MagCard.MagCard;
import MagCard.MagEncoders;
import MagCard.MagReadListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputControl;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.store.JKCardReader;

/**
 * @author Val
 */
public class Keyboard extends Region implements MagReadListener {

    private VBox vbLetters;
    private TilePane tileNumbers;
    private List<Button> btnsNum;
    private List<Button> btnsNumExtra;
    private final static double SPN = JKLayout.spNum;
    private final static double KBW = (12 * JKLayout.btnNumW) + (11 * JKLayout.spNum);
    private final static double NPW = (3 * JKLayout.btnNumW) + (2 * JKLayout.spNum);
    private Label lbl;
    private TextInputControl inputCtrl;
    private TextInputControl destination;
    private TextField txtFld;
    private PasswordField pwdFld;
    private List<Button> btnsLetters;
    private boolean isCaps = false;
    private KeyboardResult result;
    private MagCard cardRead;
    private boolean magEntry = false;
    private boolean useMagRead;

    public Keyboard() {
        StackPane stack = getKeyboardStack();
        getChildren().add(stack);
    }

    private StackPane getKeyboardStack() {
        StackPane stack = JKLayout.getComponentStackPane();
        stack.getChildren().addAll(getKeyboardGrp());

        return stack;
    }

    private Group getKeyboardGrp() {
        Group grp = new Group();

        double w = KBW + NPW + ((3 * JKLayout.sp));

        Rectangle rec = new Rectangle();
        rec.setWidth(w);

        VBox vbox = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
        vbox.setPrefWidth(w);

        lbl = JKText.getLblDk("Instruction", JKText.FONT_B_XSM);

        txtFld = new TextField();
        txtFld.setPrefWidth(w - (2 * JKLayout.sp));
        txtFld.setPromptText("enter text or number");
        txtFld.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent e) {
                if (e.getCode() == KeyCode.ENTER) {
                    getEnterBtnEvent();
                }
            }
        });

        pwdFld = new PasswordField();
        pwdFld.setPrefWidth(w - (2 * JKLayout.sp));
        pwdFld.setPromptText("enter password");
        pwdFld.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent e) {
                if (e.getCode() == KeyCode.ENTER) {
                    getEnterBtnEvent();
                }
            }
        });

        StackPane stack = new StackPane();
        stack.getChildren().addAll(txtFld, pwdFld);

        Image imgX = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/cross.png"));
        Image imgTick = new Image(getClass().getClassLoader().getResourceAsStream("jkiosk3/images/tick.png"));
        ImageView imgCancel = new ImageView(imgX);
        ImageView imgEnter = new ImageView(imgTick);

        Button btnClear = JKNode.getBtnNum("Clear");
        btnClear.setFont(JKText.FONT_B_XXSM);
        btnClear.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                inputCtrl.setText("");
                inputCtrl.setDisable(false);
                destination.setText("");
                if (useMagRead) {
                    if (cardRead != null) {
                        cardRead.stop();
                        initialiseMagReader();
                    } else {
                        initialiseMagReader();
                    }
                }
            }
        });

        Button btnCancel = new Button("Cancel");
        btnCancel.setFont(JKText.FONT_B_XSM);
        btnCancel.setGraphic(imgCancel);
        btnCancel.setPrefSize(((3 * JKLayout.btnNumW) + (2 * SPN)), JKLayout.btnNumH);
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                closeKeyboard();
            }
        });

        Button btnEnter = new Button("Enter");
        btnEnter.setFont(JKText.FONT_B_XSM);
        btnEnter.setGraphic(imgEnter);
        btnEnter.setPrefSize(((3 * JKLayout.btnNumW) + (2 * SPN)), JKLayout.btnNumH);
        btnEnter.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                getEnterBtnEvent();
            }
        });

        HBox hb = JKLayout.getHBox(0, JKLayout.sp);
        hb.setMaxWidth(w - (2 * JKLayout.sp));
        hb.setMinWidth(w - (2 * JKLayout.sp));
        hb.getChildren().addAll(lbl, JKNode.getHSpacer(), btnClear, btnCancel, btnEnter);

        HBox hbKeys = JKLayout.getHBox(0, JKLayout.sp);
        hbKeys.setMaxWidth(w - (2 * JKLayout.sp));
        hbKeys.setMinWidth(w - (2 * JKLayout.sp));
        hbKeys.setTranslateX(SPN);
        hbKeys.getChildren().addAll(getLetters(), getNums());

        vbox.getChildren().addAll(hb, stack, new Separator(), hbKeys);

        rec.heightProperty().bind(vbox.heightProperty());

        grp.getChildren().addAll(rec, vbox);

        return grp;
    }

    private TilePane getNums() {
        tileNumbers = JKLayout.getTile(0, SPN, SPN, 3);
        tileNumbers.setMaxWidth(NPW + (2 * SPN));
        tileNumbers.setMinWidth(NPW + (2 * SPN));

        btnsNum = new ArrayList<>();
        String[] nums = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "00", "."};
        for (String s : nums) {
            Button btn = JKNode.getBtnNum(s);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    if (!inputCtrl.isDisabled()) {
                        inputCtrl.appendText(((Button) e.getSource()).getText());
                    }
                }
            });
            btnsNum.add(btn);
        }

        btnsNumExtra = new ArrayList<>();
        String[] extras = {"*", "-", "+"};
        for (String s : extras) {
            Button btnEx = JKNode.getBtnNum(s);
            btnEx.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    if (!inputCtrl.isDisabled()) {
                        inputCtrl.appendText(((Button) e.getSource()).getText());
                    }
                }
            });
            btnsNumExtra.add(btnEx);
        }

        return tileNumbers;
    }

    private VBox getLetters() {
        vbLetters = JKLayout.getVBoxLeft(0, SPN);
        vbLetters.setMaxWidth(KBW);
        vbLetters.setMinWidth(KBW);

        btnsLetters = getLetterButtons();

        return vbLetters;
    }

    private List<Button> getLetterButtons() {
        List<Button> btnsL = new ArrayList<>();

        String[] strL = {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p",
                "a", "s", "d", "f", "g", "h", "j", "k", "l", ";", ":",
                "z", "x", "c", "v", "b", "n", "m", ",", ".", "'", "/"};
        for (String s : strL) {
            Button btn = JKNode.getBtnNum(s);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event event) {
                    if (!inputCtrl.isDisabled()) {
                        inputCtrl.appendText(((Button) event.getSource()).getText());
                    }
                }
            });
            btnsL.add(btn);
        }

        return btnsL;
    }

    private HBox getQ() {
        HBox hbq = JKLayout.getHBoxLeft(0, JKLayout.spNum);
        hbq.setMaxWidth(KBW);

        Button btnBackSp = JKNode.getBtnNum("← Backspace");
        btnBackSp.setFont(JKText.FONT_LUCIDA_UNI_MID);
//        btnBackSp.setPrefSize(((2 * JKLayout.btnNumW) + (1 * SPN)), JKLayout.btnNumH);
        btnBackSp.setMaxSize(((2 * JKLayout.btnNumW) + (1 * SPN)), JKLayout.btnNumH);
        btnBackSp.setMinSize(((2 * JKLayout.btnNumW) + (1 * SPN)), JKLayout.btnNumH);
        btnBackSp.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                if (!inputCtrl.isDisabled()) {
                    int end = inputCtrl.getText().length() - 1;
                    if (end >= 0) {
                        inputCtrl.setText(inputCtrl.getText(0, end));
                    }
                }
            }
        });

        hbq.getChildren().addAll(btnsLetters.subList(0, 10));
        hbq.getChildren().add(btnBackSp);
        return hbq;
    }

    private HBox getA() {
        HBox hba = JKLayout.getHBox(0, JKLayout.spNum);
        hba.setTranslateX(JKLayout.btnNumW / 2);
        hba.getChildren().addAll(btnsLetters.subList(10, 21));
        hba.getChildren().add(JKNode.getHSpacer());
        return hba;
    }

    private HBox getZ() {
        HBox hbz = JKLayout.getHBox(0, JKLayout.spNum);
        hbz.setTranslateX(JKLayout.btnNumW + SPN);
        hbz.getChildren().addAll(btnsLetters.subList(21, 32));
        hbz.getChildren().add(JKNode.getHSpacer());
        return hbz;
    }

    private HBox getExtended() {
        HBox hb = JKLayout.getHBox(0, JKLayout.spNum);
        hb.setMinWidth(KBW);

        List<Button> btnsExt = new ArrayList<>();

        String[] strExt = {"!", "@", "#", "$", "%", "^", "&", "(", ")", "_"};
        for (String s : strExt) {
            Button btnEx = JKNode.getBtnNum(s);
            btnEx.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event event) {
                    if (!inputCtrl.isDisabled()) {
                        inputCtrl.appendText(((Button) event.getSource()).getText());
                    }
                }
            });
            btnsExt.add(btnEx);
        }
        btnsLetters.addAll(btnsExt);

        Button btnCoZa = JKNode.getBtnNum(".co.za");
        btnCoZa.setFont(JKText.FONT_B_XSM);
        btnCoZa.setPrefSize(((2 * JKLayout.btnNumW) + (1 * SPN)), JKLayout.btnNumH);
        btnCoZa.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                if (!inputCtrl.isDisabled()) {
                    inputCtrl.appendText(((Button) event.getSource()).getText());
                }
            }
        });
        btnsLetters.add(btnCoZa);

        hb.getChildren().addAll(btnsExt);
        hb.getChildren().add(btnCoZa);

        return hb;
    }

    private HBox getSp() {
        HBox hb = JKLayout.getHBox(0, JKLayout.spNum);

        Button btnCaps = JKNode.getBtnNum("Caps Lock");
        btnCaps.setFont(JKText.FONT_B_XXSM);
//        btnCaps.setPrefSize(((2 * JKLayout.btnNumW) + (1 * SPN)), JKLayout.btnNumH);
        btnCaps.setMaxSize(((2 * JKLayout.btnNumW) + (1 * SPN)), JKLayout.btnNumH);
        btnCaps.setMinSize(((2 * JKLayout.btnNumW) + (1 * SPN)), JKLayout.btnNumH);
        btnCaps.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (!isCaps) {
                    isCaps = true;
                    for (Button b : btnsLetters) {
                        b.setText(b.getText().toUpperCase(Locale.ENGLISH));
                    }
                } else if (isCaps) {
                    isCaps = false;
                    for (Button b : btnsLetters) {
                        b.setText(b.getText().toLowerCase(Locale.ENGLISH));
                    }
                }
            }
        });

        Button btnSpace = new Button("Space");
        btnSpace.setFont(JKText.FONT_B_XSM);
        btnSpace.setPrefSize(((6 * JKLayout.btnNumW) + (5 * SPN)), JKLayout.btnNumH);
        btnSpace.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                if (!inputCtrl.isDisabled()) {
                    inputCtrl.appendText(" ");
                }
            }
        });

        Button btnHome = JKNode.getBtnNum("Home");
        btnHome.setFont(JKText.FONT_B_XXSM);
        btnHome.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                int end = inputCtrl.getText().length() - 1;
                if (end >= 0) {
                    inputCtrl.requestFocus();
                    getHome();
                }
            }
        });

        Button btnEnd = JKNode.getBtnNum("End");
        btnEnd.setFont(JKText.FONT_B_XXSM);
        btnEnd.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                int end = inputCtrl.getText().length() - 1;
                if (end >= 0) {
                    inputCtrl.requestFocus();
                    getEnd();
                }
            }
        });

        Button btnMoveBack = JKNode.getBtnNum("←");
        btnMoveBack.setFont(JKText.FONT_LUCIDA_UNI_LG);
        btnMoveBack.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
//                int end = inputCtrl.getText().length() - 1;
//                if (end >= 0) {
////                    inputCtrl.requestFocus();
////                    getMoveBack();
//                    inputCtrl.setText(inputCtrl.getText(0, end));
//                }
            }
        });
        Button btnMoveForward = JKNode.getBtnNum("→");
        btnMoveForward.setFont(JKText.FONT_LUCIDA_UNI_LG);

        hb.getChildren().addAll(btnCaps, btnSpace, btnHome, btnEnd, btnMoveBack, btnMoveForward);

        return hb;
    }

    /*
     Keep this here for future - would like to implement 'insert' for keyboard
     */
//    private void addText(final Event event) {
//        Platform.runLater(new Runnable() {
//            @Override
//            public void run() {
//                int position = inputCtrl.getCaretPosition();
//                System.out.println("caret position = " + position);
//                inputCtrl.insertText(position, ((Button) event.getSource()).getText());
//            }
//        });
//    }
    private void getHome() {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                inputCtrl.positionCaret(0);
            }
        });
    }

    private void getEnd() {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                inputCtrl.positionCaret(inputCtrl.getText().length());
            }
        });
    }

    /*
     Keep this here for future - would like to implement 'move caret back' for keyboard
     */
//    private void getMoveBack() {
//        Platform.runLater(new Runnable() {
//            @Override
//            public void run() {
//                int len = inputCtrl.getText().length();
//                int pos = inputCtrl.getCaretPosition();
//                System.out.println("text length = " + len);
//                System.out.println("pos = " + pos);
////                inputCtrl.positionCaret(pos - 1);
////                for (int i = inputCtrl.getCaretPosition(); i < txt.length(); i++) {
////                    inputCtrl.positionCaret(i);
////                }
//            }
//        });
//    }
    private void getEnterBtnEvent() {
        destination.setText(inputCtrl.getText());
        if (result != null) {
            result.onDone(inputCtrl.getText());
        }
        closeKeyboard();
    }

    private void setInputControl(TextInputControl control) {
        this.inputCtrl = control;
        if (control instanceof PasswordField) {
            inputCtrl = pwdFld;
            pwdFld.setVisible(true);
            txtFld.setVisible(false);
        } else if (control instanceof TextField) {
            inputCtrl = txtFld;
            pwdFld.setVisible(false);
            txtFld.setVisible(true);
        }
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                inputCtrl.requestFocus();
            }
        });
    }

    public void showKeyboard(TextInputControl inputFld, String label, String defTxt, boolean useMagRead,
                             boolean useExtended) {
        showKeyboard(inputFld, label, defTxt, useMagRead, useExtended, null);
    }

    public void showKeyboard(TextInputControl inputFld, String label, String defTxt, boolean useMagRead) {
        showKeyboard(inputFld, label, defTxt, useMagRead, false, null);
    }

    public void showKeyboard(TextInputControl inputFld, String label, String defTxt, boolean useMagRead,
                             boolean useExtended, KeyboardResult res) {
        this.result = res;
        this.useMagRead = useMagRead;
        destination = inputFld;
        setInputControl(inputFld);
        lbl.setText(label);
        inputCtrl.setText(defTxt);
        inputCtrl.setDisable(false);
        magEntry = false;
        this.setVisible(true);
        this.toFront();

        if (this.useMagRead) {
            initialiseMagReader();
//            if (JKCardReader.getCardReaderConfig().isMagCardRead()) {
//                MagEncoders selectedEncoder = JKCardReader.getCardReaderConfig().getMagCardType();
//                switch (selectedEncoder) {
//                    case LOMAMR3:
//                        cardRead = new LomaMR3();
//                        break;
//                    case MSRE206:
//                        cardRead = new MSRE206();
//                        break;
//                    default:
//                        JKiosk3.getMsgBox().showMsgBox("Mag Card Reader", "Unable to initialise Mag Card Reader\n\n"
//                                + "Check settings in 'Setup'", null);
//                }
//                try {
//                    cardRead.connect(JKCardReader.getCardReaderConfig().getMagCardPort(),
//                            JKCardReader.getCardReaderConfig().getMagCardBaud());
//                    cardRead.setReadListener(this);
//                    cardRead.readCard();
//                } catch (Exception ex) {
//                    JKiosk3.getMsgBox().showMsgBox("Error", ex.getMessage()
//                            + "\nPlease check Mag Reader configuration settings", null);
//                }
//            }
        }

        vbLetters.getChildren().clear();
        tileNumbers.getChildren().clear();
        if (useExtended) {
            vbLetters.getChildren().addAll(getExtended(), getQ(), getA(), getZ(), getSp());
            tileNumbers.getChildren().addAll(btnsNumExtra);
            tileNumbers.getChildren().addAll(btnsNum);
        } else {
            vbLetters.getChildren().addAll(getQ(), getA(), getZ(), getSp());
            tileNumbers.getChildren().addAll(btnsNum);
        }
    }

    private void closeKeyboard() {
        setVisible(false);
        toBack();
        if (cardRead != null) {
            cardRead.stop();
            cardRead = null;
        }
    }

    private void initialiseMagReader() {
        magEntry = false;
        if (JKCardReader.getCardReaderConfig().isMagCardRead()) {
            MagEncoders selectedEncoder = JKCardReader.getCardReaderConfig().getMagCardType();
            switch (selectedEncoder) {
                case LOMAMR3:
                    cardRead = new LomaMR3();
                    break;
                case MSRE206:
                    cardRead = new MSRE206();
                    break;
                default:
                    JKiosk3.getMsgBox().showMsgBox("Mag Card Reader", "Unable to initialise Mag Card Reader\n\n"
                            + "Check settings in 'Setup'", null);
            }
            try {
                cardRead.connect(JKCardReader.getCardReaderConfig().getMagCardPort(),
                        JKCardReader.getCardReaderConfig().getMagCardBaud());
                cardRead.setReadListener(this);
                cardRead.readCard();
            } catch (Exception ex) {
                JKiosk3.getMsgBox().showMsgBox("Error", ex.getMessage()
                        + "\nPlease check Mag Reader configuration settings", null);
            }
        }
    }

    @Override
    public void readMagCard(boolean success, String track1, String track2, String track3) {
        if (success) {
            System.out.println("readMagCard() is TRUE");
            this.inputCtrl.setText(track2);
            this.inputCtrl.setDisable(true);
            magEntry = true;
            if (cardRead != null) {
                cardRead.stop();
            }
        } else {
            System.out.println("readMagCard() is FALSE");
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    JKiosk3.getMsgBox().showMsgBox("Error Reading Card", "Reading Failed", null);
                    closeKeyboard();
                }
            });
        }
    }

    public boolean isMagEntry() {
        return magEntry;
    }
}
