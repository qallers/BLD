package jkiosk3.sales.search;

import aeonairtime.AirtimeManufacturer;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.vouchers.VoucherUtil;

import java.util.ArrayList;
import java.util.List;

public class CreateAirtimeVoucherProduct {

    public static List<SearchProduct> createAirtimeVoucherProducts() {
        final String VOUCHER_AIRTIME = "Airtime Voucher";
        // populate vouchers
        VoucherUtil.getVoucherProvidersList();

        List<SearchProduct> products = new ArrayList<>();
        for (AirtimeManufacturer airtimeManufacturer : VoucherUtil.getProvidersShow(SaleType.VOUCHER_AIRTIME)) {
            SearchProduct networkProvider = new SearchProduct();

            networkProvider.setProvName(airtimeManufacturer.getId());
            String airtimeName = airtimeManufacturer.getName();

            networkProvider.setProdName(String.format("%s %s", airtimeName.startsWith("x") ? airtimeName.substring(1) : airtimeName, VOUCHER_AIRTIME));
            networkProvider.setSearchTransType(SearchTransType.AIRTIME_VOUCHER);

            products.add(networkProvider);
        }

        return products;
    }
}
