package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.Shift;
import aeonreports.ShiftList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.printing.PrintHandler;
import jkiosk3.reports.ReportUtil.AeonPrintJobResult;
import jkiosk3.reports.ReportUtil.ShiftListResult;

/**
 *
 * @author Val
 */
public class ShiftView extends Region {

    private final static Logger logger = Logger.getLogger(ShiftView.class.getName());
    private int shiftId;

    public ShiftView() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getShiftsGrid());
        vb.getChildren().add(getPrintControl());

        getChildren().addAll(vb);
    }

    private GridPane getShiftsGrid() {
        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);

        VBox vbHead = JKNode.getReportHeadVB("View Shifts");

        Label lblShift = JKText.getLblDk("Select Shift", JKText.FONT_B_XSM);
        lblShift.setMinWidth(JKLayout.btnSmW);

        final ComboBox comShift = new ComboBox();
        comShift.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.75), 35);

        ReportUtil.getShiftList(new ShiftListResult() {
            @Override
            public void shiftListResult(ShiftList shiftList) {
                if (shiftList != null) {
                    for (Shift s : shiftList.getShifts()) {
                        comShift.getItems().add(s);
                    }
                }
                comShift.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
                    @Override
                    public void changed(ObservableValue arg0, Object oldShift, Object newShift) {
                        if (newShift != null) {
                            shiftId = ((Shift) newShift).getShiftId();
                        }
                    }
                });
            }
        });

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblShift, comShift);

        return grid;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                showShiftViewReport();
            }
        };
    }

    private void showShiftViewReport() {
        try {
            ReportUtil.getPrintReport(ReportUtil.REP_SHIFT, 0, shiftId, new AeonPrintJobResult() {
                @Override
                public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                    PrintHandler.handlePrintRequestReport("Print Shift", aeonPrintJob);
                }
            });
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
    }
}
