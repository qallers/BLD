package jkiosk3.sales.ticketpro.sale;

import aeonticketpros.TicketProsCartClearReq;
import aeonticketpros.TicketProsCartClearResp;
import aeonticketpros.TicketProsSeat;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import static jkiosk3._common.JKLayout.sp;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.ticketpro.TicketProCustomerReg;
import jkiosk3.sales.ticketpro.TicketProSale;
import jkiosk3.sales.ticketpro.TicketProUtil;
import jkiosk3.users.UserUtil;

public class TicketProViewCart extends Region {

    private List<TicketProsSeat> listSeats;
    private GridPane gridSeats;
    private ScrollPane scrollSeats;
    private final static double gridWidth = (JKLayout.contentW - (4 * sp));

    public TicketProViewCart() {
        listSeats = TicketProSale.getInstance().getSelectedSeats();
        getChildren().add(getSeatsLayout());
    }

    private VBox getSeatsLayout() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().add(getConfirmDetailsGroup());
        vb.getChildren().add(getNav());
        return vb;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav();
        nav.getBtnBack().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(javafx.event.Event e) {
                SceneSales.clearAndChangeContent(new TicketProTickets());
            }
        });
        nav.getBtnCancel().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(javafx.event.Event e) {
                UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndShowFavourites();
            }
        });
        nav.getBtnNext().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(javafx.event.Event e) {
                if (TicketProSale.getInstance().getSelectedSeats().size() > 0) {
                    SceneSales.clearAndChangeContent(new TicketProCustomerReg());
                } else {
                    JKiosk3.getMsgBox().showMsgBox("No Tickets in Cart", "Please use 'back' button to go back and add Tickets", null);
                }
            }
        });
        return nav;
    }

    private VBox getConfirmDetailsGroup() {

        Label lblEvt = JKText.getLblContentHead("Event - " + TicketProSale.getInstance().getSelectedEventDetail().getName());
        Label lblDate = JKText.getLblDk("Event Date - "
                + JKText.getDateDisplayMin(TicketProSale.getInstance().getSelectedEventDetail().getStartDate()), JKText.FONT_B_XSM);

        Button btnClearCart = JKNode.getBtnPopup("clear\ncart");
        btnClearCart.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                removeAllSeatsFromSale();
            }
        });

        HBox hbClear = JKLayout.getHBox(0, 0);
        hbClear.setPrefWidth(JKLayout.contentW - (2 * JKLayout.sp));
        hbClear.getChildren().addAll(lblDate, JKNode.getHSpacer(), btnClearCart);

        gridSeats = getSeatSummary(listSeats);

        scrollSeats = new ScrollPane();
        scrollSeats.setMaxSize(JKLayout.contentW - (2 * JKLayout.sp), 465);
        scrollSeats.setMinSize(JKLayout.contentW - (2 * JKLayout.sp), 465);
        scrollSeats.getStyleClass().add("scroll-invisible");
        scrollSeats.setContent(gridSeats);

//        VBox vbSummary = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
        VBox vbSummary = JKLayout.getVBoxContent(JKLayout.sp);
        vbSummary.getChildren().addAll(lblEvt, hbClear, JKNode.createContentSep(), scrollSeats);

//        return JKNode.getContentGroup(vbSummary);
        return vbSummary;
    }

    private GridPane getSeatSummary(List<TicketProsSeat> seats) {
        Label lblSeatCat = JKText.getLblDk("Seat Category", JKText.FONT_B_XSM);
        Label lblSeatSect = JKText.getLblDk("Seat Section", JKText.FONT_B_XSM);
        Label lblSeatPrice = JKText.getLblDk("Seat Price", JKText.FONT_B_XSM);

        GridPane grid = getTicketPriceGrid();
        grid.addRow(0, lblSeatCat, lblSeatSect, lblSeatPrice);
        int rowCount = 1;
        double amtDue = 0;

        for (final TicketProsSeat s : seats) {
            Text txtSeatCat = JKText.getTxtDk(s.getSeatCatName(), JKText.FONT_B_XXSM);
            txtSeatCat.setWrappingWidth((gridWidth - (3 * JKLayout.sp)) * 0.30);
            Text txtSeatSect = JKText.getTxtDk(s.getSectionName(), JKText.FONT_B_XXSM);
            txtSeatSect.setWrappingWidth((gridWidth - (3 * JKLayout.sp)) * 0.35);
            Text txtSeatPrice = JKText.getTxtDk(JKText.getDeciFormat(s.getPrice()), JKText.FONT_B_XXSM);

            Button btnRemove = JKNode.getBtnPopup("remove");
            btnRemove.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    removeSeatFromSale(s);
                }
            });
            amtDue += s.getPrice();
            grid.addRow(rowCount, txtSeatCat, txtSeatSect, txtSeatPrice, btnRemove);
            rowCount++;
        }
        Label lblAmtDue = JKText.getLblDk("Total Due", JKText.FONT_B_XSM);
        Text txtTotal = JKText.getTxtDk(JKText.getDeciFormat(amtDue), JKText.FONT_B_SM);
        grid.addRow(rowCount, new Label(""), lblAmtDue, txtTotal);

        return grid;
    }

    private void removeSeatFromSale(TicketProsSeat seat) {
        TicketProsCartClearReq req = new TicketProsCartClearReq();
        req.setCartId(TicketProSale.getInstance().getSaleCart().getCartId());
        req.setInventoryId(seat.getInventoryId());
        TicketProUtil.clearCart(req, new TicketProUtil.TicketProClearCartResult() {
            @Override
            public void tpClearCartResult(TicketProsCartClearResp tpClearCartResp) {
                if (tpClearCartResp.isSuccess()) {
                    listSeats = tpClearCartResp.getSeats();
                    TicketProSale.getInstance().setSelectedSeats(listSeats);
                    scrollSeats.setContent(null);

                    gridSeats = getSeatSummary(listSeats);
                    scrollSeats.setContent(gridSeats);
                }
            }
        });
    }

    private void removeAllSeatsFromSale() {
        TicketProsCartClearReq req = new TicketProsCartClearReq();
        req.setCartId(TicketProSale.getInstance().getSaleCart().getCartId());
        req.setInventoryId("");
        TicketProUtil.clearCart(req, new TicketProUtil.TicketProClearCartResult() {
            @Override
            public void tpClearCartResult(TicketProsCartClearResp tpClearCartResp) {
                if (tpClearCartResp.isSuccess()) {
                    listSeats = tpClearCartResp.getSeats();
                    TicketProSale.getInstance().setSelectedSeats(listSeats);
                    scrollSeats.setContent(null);

                    gridSeats = getSeatSummary(listSeats);
                    scrollSeats.setContent(gridSeats);
                }
            }
        });
    }

    private GridPane getTicketPriceGrid() {
        GridPane grid = JKLayout.getContentGridInScroll();

        double gridGap = (1 * JKLayout.sp);

        ColumnConstraints col0 = new ColumnConstraints();
        col0.setMaxWidth((gridWidth - gridGap) * 0.30);
        col0.setMinWidth((gridWidth - gridGap) * 0.30);
        col0.setHalignment(HPos.LEFT);
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setMaxWidth((gridWidth - gridGap) * 0.35);
        col1.setMinWidth((gridWidth - gridGap) * 0.35);
        col1.setHalignment(HPos.LEFT);
        ColumnConstraints col2 = new ColumnConstraints();
        col2.setMaxWidth((gridWidth - gridGap) * 0.20);
        col2.setMinWidth((gridWidth - gridGap) * 0.20);
        col2.setHalignment(HPos.RIGHT);
        ColumnConstraints col3 = new ColumnConstraints();
        col3.setMaxWidth((gridWidth - gridGap) * 0.15);
        col3.setMinWidth((gridWidth - gridGap) * 0.15);
        col3.setHalignment(HPos.RIGHT);

        grid.getColumnConstraints().addAll(col0, col1, col2, col3);

        return grid;
    }
}
