package jkiosk3.sales.ticketpro.sale;

import aeonprinting.AeonPrintJob;
import aeonticketpros.TicketProsCheckoutResp;
import aeonticketpros.TicketProsPaymentReq;
import aeonticketpros.TicketProsPaymentResp;
import aeonticketpros.TicketProsPrintReq;
import aeonticketpros.TicketProsPrintResp;
import aeonticketpros.TicketProsTicket;

import java.io.File;
import java.util.*;

import javafx.application.Platform;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._common.ResultCallback;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.PrintHandler;
import jkiosk3.printing.PrintUtil;
import jkiosk3.printing.print_layouts.PrintTicketPro;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._tender.TenderAmounts;
import jkiosk3.sales._common.JKTenderToggles;
import jkiosk3.sales.ticketpro.TicketProMenu;
import jkiosk3.sales.ticketpro.TicketProSale;
import jkiosk3.sales.ticketpro.TicketProUtil;
import jkiosk3.store.JKPrinterTickets;
import jkiosk3.utilities.DownloadUtil;

public class TicketProPayment extends Region {

    private final TicketProsCheckoutResp checkoutResponse;
    private TicketProsPaymentResp paymentResponse;
    private TicketProsPrintResp printResp;
    private List<TicketProsTicket> listPrintTickets;
    private JKTenderToggles tenderTypes;
    private String tenderSelected;
//    private int currentPrintJob;

    public TicketProPayment() {
        checkoutResponse = TicketProSale.getInstance ().getCheckoutResponse ();

        getChildren ().add (getSaleReferenceGroup ());
    }

    private GridPane getSaleReferenceGroup() {
        Label lblConfirmation = JKText.getLblContentHead ("TicketPro");
        Label lblPayment = JKText.getLblContentSubHead ("Booking Confirmation and Payment");

        Label lblRef = JKText.getLblDk ("Booking Reference", JKText.FONT_B_XSM);
        Label lblAmtDue = JKText.getLblDk ("Balance Due", JKText.FONT_B_XSM);

        Text txtRef = JKText.getTxtDk (checkoutResponse.getReference (), JKText.FONT_B_XSM);
        Text txtAmtDue = JKText.getTxtDk (JKText.getDeciFormat (checkoutResponse.getBalance ()), JKText.FONT_B_XSM);

        GridPane grid = JKLayout.getGridContent2Col (0.5, 0.5);

        grid.add (lblConfirmation, 0, 0, 2, 1);
        grid.add (lblPayment, 0, 1, 2, 1);
        grid.addRow (2, JKNode.createGridSpanSep (2));
        grid.addRow (4, lblRef, txtRef);
        grid.addRow (5, lblAmtDue, txtAmtDue);
        grid.addRow (7, getTenderTypes ());

        return grid;
    }

    private JKTenderToggles getTenderTypes() {
        tenderTypes = new JKTenderToggles (SaleType.TICKETPRO.getDisplay ());
        for (ToggleButton b : tenderTypes.getTenderToggleList ()) {
            b.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(javafx.event.Event e) {
                    tenderSelected = tenderTypes.getTenderTypeSelected ();
                    TicketProSale.getInstance ().setTenderType (tenderSelected);
                    TicketProSale.getInstance ().setTenderText (tenderTypes.getTenderText ());
                    makePayment ();
                }
            });
        }
        return tenderTypes;
    }

    private void makePayment() {
        TicketProsPaymentReq req = new TicketProsPaymentReq ();
        req.setTransactionId (checkoutResponse.getTransactionId ());
        req.setAmount (checkoutResponse.getBalance ());
        req.setPaymentMethod (tenderSelected);

        TicketProUtil.getTicketProPaymentResponse (1, req, new TicketProUtil.TicketProPaymentResult () {
            @Override
            public void tpPaymentResult(TicketProsPaymentResp tpPaymentResp) {
                if (tpPaymentResp.isSuccess ()) {
                    paymentResponse = tpPaymentResp;
                    GridPane gridSumm = showPaymentResponseGrid ();
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Booking Success", "", gridSumm, MessageBox.CONTROLS_SHOW,
                            MessageBox.MSG_OK, new MessageBoxResult () {
                                @Override
                                public void onOk() {
                                    String printAdvice = "";
                                    if (JKPrinterTickets.getPrinterTickets ().isUseDefaultPrinter ()) {
                                        printAdvice = "Tickets will be printed on Slip Printer.";
                                    } else if (JKPrinterTickets.getPrinterTickets ().isUseSerialPrinter ()) {
                                        printAdvice = "Tickets will be printed on Ticket Printer.";
                                    }
                                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro", printAdvice, null, MessageBox.CONTROLS_SHOW,
                                            MessageBox.MSG_OK, new MessageBoxResult () {

                                                @Override
                                                public void onOk() {
                                                    printTicketProTickets ();
                                                    SceneSales.clearAndChangeContent (null);
                                                }

                                                @Override
                                                public void onCancel() {
                                                }
                                            });
                                }

                                @Override
                                public void onCancel() {
                                }
                            });
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Payment Error", !tpPaymentResp.getAeonErrorText ().isEmpty () ?
                                    "A" + tpPaymentResp.getAeonErrorCode () + " - " + tpPaymentResp.getAeonErrorText () :
                                    "B" + tpPaymentResp.getErrorCode () + " - " + tpPaymentResp.getErrorText (), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    SceneSales.clearAndChangeContent (new TicketProMenu ());
                                }

                                @Override
                                public void onCancel() {
                                }
                            });
                }
            }
        });
    }

    private GridPane showPaymentResponseGrid() {
        GridPane grid = JKLayout.getSummaryGrid2Col (0.5, 0.5);
        Label lblRef = JKText.getLblDk ("Booking Reference", JKText.FONT_B_XSM);

        Text txtRef = JKText.getTxtDk (paymentResponse.getReference (), JKText.FONT_B_XSM);

        grid.addRow (0, lblRef, txtRef);

        return grid;
    }

    private void printTicketProTickets() {
        final TicketProsPrintReq printRequest = new TicketProsPrintReq ();
        printRequest.setTransactionId (paymentResponse.getTransactionId ());
        if (JKPrinterTickets.getPrinterTickets ().isUseDefaultPrinter ()) {
            printRequest.setFormat ("xml");
        } else if (JKPrinterTickets.getPrinterTickets ().isUseSerialPrinter ()) {
            printRequest.setFormat ("ezpl");
        }
        printRequest.setCardId ("");
        printRequest.setReprint (false);

        TicketProUtil.getTicketProPrint (1, printRequest, new TicketProUtil.TicketProPrintResult () {
            @Override
            public void tpPrintResult(TicketProsPrintResp tpPrintResp) {
                if (tpPrintResp.isSuccess ()) {
                    if (printRequest.getFormat ().equalsIgnoreCase ("xml")) {
                        if (!tpPrintResp.getListTickets ().isEmpty ()) {
                            printResp = tpPrintResp;
                            listPrintTickets = printResp.getListTickets ();

                            // sale should only go into basket if tickets are received from TicketPro
                            processSale ();
                            PrintHandler.handleMerchantCopyPrint (tpPrintResp.getMerchantCopyPrint ());

                            printTickets ();
                        } else {
                            showTicketPrintError ();
                        }
                    } else if (printRequest.getFormat ().equalsIgnoreCase ("ezpl")) {
                        File printFile = DownloadUtil.downloadRemoteFile (tpPrintResp.getTickets (), JK3Config.getTicketPrint ());

                        if (printFile != null) {

                            printTickets (printFile);

                            PrintHandler.handleMerchantCopyPrint (tpPrintResp.getMerchantCopyPrint ());

                        } else {
                            showTicketPrintError ();
                        }
                    }
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Print Error", !tpPrintResp.getAeonErrorText ().isEmpty () ?
                            "A" + tpPrintResp.getAeonErrorCode () + " - " + tpPrintResp.getAeonErrorText () :
                            "B" + tpPrintResp.getErrorCode () + " - " + tpPrintResp.getErrorText (), null);
                    SceneSales.clearAndShowFavourites ();
                }
            }
        });
    }

    private void printTickets(final File printFile) {
        // This is a 'working' Putco ticket received from TicketPro, use only for testing!!!
//        String branchPath = "C:\\_projects\\BLT\\SouthAfrica\\Roodepoort\\AEON\\Clients\\Applications\\JKiosk3\\branches\\";
//        final File testFile = new File(branchPath + "JK3-SlipOpt-4\\media\\printFiles\\test-x4.ezpl");
        Platform.runLater (new Runnable () {
            @Override
            public void run() {
                PrintHandler.writeFileContentToPrinterPort (printFile, new ResultCallback () {
                    @Override
                    public void onResult(boolean result) {
                        if (result) {
                            processSale ();
                        } else {
                            // cancel ticket sale
                        }
                    }
                });
            }
        });
    }

    private void processSale() {
        boolean canCancel = false;
        String transRef = paymentResponse.getTransRef ();
        String desc = TicketProSale.getInstance ().getSelectedEvent ().getName ();
        String bookingRef = paymentResponse.getReference ();
        double amtPaid = checkoutResponse.getBalance ();

        TenderAmounts.addTenderAmount (tenderTypes.getTenderText (), amtPaid);

        SalesUtil.processSoldItem (transRef, SaleType.TICKETPRO.getDisplay (), desc + " " + bookingRef,
                null, amtPaid, canCancel, "online", bookingRef, new Date (), null, tenderSelected);

        SceneSales.clearAndShowFavourites ();
    }

    private void showTicketPrintError() {
        String msgReason = "TicketPro - Tickets Not Received from TicketPro";
        msgReason += "\n\nPlease phone TicketPro Customer Services to cancel this sale";

        JKiosk3.getMsgBox ().showMsgBox ("TicketPro Print", msgReason,
                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {
                    @Override
                    public void onOk() {
                        PrintTicketPro print = new PrintTicketPro ();
                        AeonPrintJob apj = print.getTicketProCancelRequestPrint ();
                        PrintUtil.sendToPrinter (apj);
                        SceneSales.clearAndShowFavourites ();
                    }

                    @Override
                    public void onCancel() {
                    }
                });
    }

    private void printTickets() {
        int ticketCount = 0;
        List<String> listTransRefs = new ArrayList<> ();
        Map<String, AeonPrintJob> mapPrintJobs = new HashMap<> ();

        for (TicketProsTicket t : listPrintTickets) {
            String transRef = paymentResponse.getTransRef () + "-" + (ticketCount);
//            AeonPrintJob apj = t.getAeonPrintJob();
            AeonPrintJob apj = PrintTicketPro.getTicketProTicketPrint (printResp, t);
            listTransRefs.add (transRef);
            mapPrintJobs.put (transRef, apj);
            ticketCount++;
        }
        PrintHandler.handlePrintRequestSaleFromMaps (SaleType.TICKETPRO.getDisplay (), listTransRefs, mapPrintJobs,
                true, true);

//        SceneSales.clearAndShowFavourites();

        // 2019-11-07  -  PRODDEFECT-868
        // Print immediately or later is now handled in PrintHandler
        // Print preview or not is now handled in PrintHandler
//        if (JKPrintOptions.getPrintOptions().isPrintImmediately()) {
//            if (JKPrintOptions.getPrintOptions().isPrintPreview()) {
//                currentPrintJob = 0;
//                printTicketsPreviewed();
//            } else {
//                int ticketCount = 0;
//                for (TicketProsTicket t : listPrintTickets) {
////                    ticketCount++;
//                    String transRef = paymentResponse.getTransRef() + "-" + (ticketCount);
////                    AeonPrintJob apj = PrintTicketPro.getTicketProTicketPrint(printResp, t);
//                    AeonPrintJob apj = t.getAeonPrintJob();
//                    PrintHandler.handlePrintRequestSale(SaleType.TICKETPRO.getDisplay(), apj, transRef);
////                    PrintUtil.sendToPrinter(apj, transRef, false);
//                    ticketCount++;
//                }
//            }
//        } else {
//            int ticketCount = 0;
//            for (TicketProsTicket t : listPrintTickets) {
//                ticketCount++;
//                String transRef = paymentResponse.getTransRef() + "-" + Integer.toString(ticketCount);
////                PrintQueue.addItem(transRef, PrintTicketPro.getTicketProTicketPrint(printResp, t));
//                PrintQueue.addItem(transRef, t.getAeonPrintJob());
//            }
//        }
    }

}
