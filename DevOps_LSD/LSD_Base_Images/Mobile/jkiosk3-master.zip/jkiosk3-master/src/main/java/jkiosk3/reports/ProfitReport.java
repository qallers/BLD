package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.Account;
import aeonreports.AccountList;
import aeonreports.Shift;
import aeonreports.ShiftList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.printing.PrintHandler;
import jkiosk3.reports.ReportUtil.AeonPrintJobResult;
import jkiosk3.reports.ReportUtil.ShiftListResult;

/**
 *
 * @author Val
 */
public class ProfitReport extends Region {

    private final static Logger logger = Logger.getLogger(ProfitReport.class.getName());
    private AccountList listAccounts;
    private ComboBox comAcc;
    private ComboBox comShift;
    private TextField txtDays;
    private int accountId;
    private int shiftId;
    private int profitDays;

    public ProfitReport() {
        listAccounts = new AccountList();
        ReportUtil.getAccountList(new ReportUtil.AccountListResult() {
            @Override
            public void accountListResult(final AccountList accountList) {
                if (accountList.isSuccess()) {
                    listAccounts = accountList;
                    VBox vb = JKLayout.getVBox(0, 5);

                    vb.getChildren().add(getProfitGrid());
                    vb.getChildren().add(getPrintControl());

                    getChildren().addAll(vb);
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Accounts List", "Unable to retrieve List of Accounts", null);
                }
            }
        });
    }

    private GridPane getProfitGrid() {
        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);

        VBox vbHead = JKNode.getReportHeadVB("Profit Report");

        Label lblAccNo = JKText.getLblDk("Account", JKText.FONT_B_XSM);
        lblAccNo.setMinWidth(JKLayout.btnSmW);

        Label lblDays = JKText.getLblDk("No of Days", JKText.FONT_B_XSM);

        Label lblOr = JKText.getLblDk("or : ", JKText.FONT_B_XSM);
        GridPane.setHalignment(lblOr, HPos.RIGHT);

        Label lblShift = JKText.getLblDk("Select Shift", JKText.FONT_B_XSM);

        comAcc = new ComboBox();
        comAcc.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.75), 35);

        for (Account a : listAccounts.getAccounts()) {
            comAcc.getItems().add(a.getAccountNo());
        }
        comAcc.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue arg0, Object oldValue, Object newValue) {
                for (Account selected : listAccounts.getAccounts()) {
                    if (selected.getAccountNo().equals(newValue)) {
                        accountId = selected.getAccountId();
                    }
                }
            }
        });

        txtDays = new TextField();
        txtDays.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event arg0) {
                JKiosk3.getNumPad().showNumPad(txtDays, "Enter Days", "");
            }
        });

        comShift = new ComboBox();
        comShift.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.75), 35);

        ReportUtil.getShiftList(new ShiftListResult() {
            @Override
            public void shiftListResult(ShiftList shiftList) {
                if (shiftList != null) {
                    for (Shift s : shiftList.getShifts()) {
                        comShift.getItems().add(s);
                    }
                }
                comShift.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
                    @Override
                    public void changed(ObservableValue arg0, Object oldShift, Object newShift) {
                        if (newShift != null) {
                            shiftId = ((Shift) newShift).getShiftId();
                        }
                    }
                });
            }
        });

        grid.add(vbHead, 0, 0, 2, 1);
        grid.addRow(1, lblAccNo, comAcc);
        grid.add(JKNode.createGridSpanSep(2), 0, 2);
        grid.addRow(3, lblDays, txtDays);
        grid.add(lblOr, 0, 4);
        grid.addRow(5, lblShift, comShift);

        return grid;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                showProfitReport();
            }
        };
    }

    private void showProfitReport() {
        if (inputValidation()) {
            try {
                if (isUseDays()) {
                    ReportUtil.getPrintReport(ReportUtil.REP_PROFIT, accountId, profitDays, new AeonPrintJobResult() {
                        @Override
                        public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                            PrintHandler.handlePrintRequestReport("Profit Report for " + profitDays + " days", aeonPrintJob);
                        }
                    });
                } else if (isUseShift()) {
                    ReportUtil.getPrintReport(ReportUtil.REP_PROFIT_SHIFT, accountId, shiftId, new AeonPrintJobResult() {
                        @Override
                        public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                            if (shiftId == 0) {
                                PrintHandler.handlePrintRequestReport("Profit Report for Current Shift", aeonPrintJob);
                            } else {
                                PrintHandler.handlePrintRequestReport("Profit Report for Shift " + shiftId, aeonPrintJob);
                            }
                        }
                    });
                }
            } catch (Exception e) {
                logger.log(Level.SEVERE, e.getMessage(), e);
            }
            resetForm();
        }
    }

    private boolean inputValidation() {
        boolean validated = false;

        if (isAccountValid()) {
            if ((!txtDays.getText().equals("")) && (comShift.getSelectionModel().selectedItemProperty().getValue() != null)) {
                JKiosk3.getMsgBox().showMsgBox("Days Or Shifts", "Either Days or Shifts must be selected, not both", null);
                txtDays.setText("");
                comShift.getSelectionModel().clearSelection();
                validated = false;
            } else if ((txtDays.getText().equals("")) && (comShift.getSelectionModel().selectedItemProperty().getValue() == null)) {
                JKiosk3.getMsgBox().showMsgBox("Days Or Shifts", "Either Days or Shifts must be selected", null);
                validated = false;
            } else if (isUseDays() || isUseShift()) {
                validated = true;
            }
        }

        return validated;
    }

    private boolean isAccountValid() {
        boolean validAccount = false;

        if (comAcc.getSelectionModel().selectedItemProperty().getValue() == null) {
            JKiosk3.getMsgBox().showMsgBox("Account Selection", "Please select an Account from the list", null);
        } else {
            validAccount = true;
        }
        return validAccount;
    }

    private boolean isUseDays() {
        boolean useDays = false;

        if ((!txtDays.getText().equals("")) && (comShift.getSelectionModel().selectedItemProperty().getValue() == null)) {
            try {
                profitDays = Integer.parseInt(txtDays.getText());
                useDays = true;
            } catch (NumberFormatException nfe) {
                JKiosk3.getMsgBox().showMsgBox("Days", "Number of days must be entered correctly", null);
                logger.log(Level.SEVERE, nfe.getMessage(), nfe);
            }
        }

        return useDays;
    }

    private boolean isUseShift() {
        boolean useShift = false;

        if ((txtDays.getText().equals("")) && (comShift.getSelectionModel().selectedItemProperty().getValue() != null)) {
            useShift = true;
        }

        return useShift;
    }

    private void resetForm() {
        int n = SceneReports.getVbReportContent().getChildren().size();
        if (n > 1) {
            SceneReports.getVbReportContent().getChildren().remove(1, n);
        }
    }
}
