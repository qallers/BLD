package jkiosk3.sales._common;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Region;
import javafx.util.Callback;
import javafx.util.Duration;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.printing.PrintQueue;
import jkiosk3.sales.SaleSummary;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.vouchers.VoucherUtil;
import jkiosk3.store.JKPending;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.store.JKReprint;
import jkiosk3.store.StoreJKPending;
import jkiosk3.store.StoreJKReprint;

public class SummaryTableView extends Region {

    private final static Logger LOG = Logger.getLogger(SummaryTableView.class.getName());

    private static TableView<SaleSummary> salesTable;
    private static ObservableList<SaleSummary> summaryRows;
    private static double totalAmt;
    private static double printTendered;
    private static double printChange;
    public static final Double STARTTIME = (15.0 * 60.0); // 15 * 60 (minutes * seconds)
    //    private static Double timeSeconds = STARTTIME;  // keep this in case countdown is needed again
//    private final static double tableHeight = 265;  // if countdown is ever needed again, set this to 245 - no time = 265
    private final static double tableHeight = 247;  // 2019-10-31 - adding item count

    public SummaryTableView() {
        getChildren().add(createTableView());
    }

    private TableView createTableView() {
        salesTable = new TableView<>();
        salesTable.setMaxWidth(JKLayout.sideW - 2);
        salesTable.setMaxHeight(tableHeight);
        salesTable.setTranslateY(-2);
        salesTable.getStyleClass().add("sales-table");

        summaryRows = FXCollections.observableArrayList();
        summaryRows.addListener(new ListChangeListener<SaleSummary>() {
            @Override
            public void onChanged(Change arg0) {
                updateTableAndButtonView(summaryRows);
//                updateTime();
            }
        });

        salesTable.getColumns().addAll(createSummaryTableColumns());

        return salesTable;
    }

    private List<TableColumn<SaleSummary, ?>> createSummaryTableColumns() {
        List<TableColumn<SaleSummary, ?>> columns = new ArrayList<>();

        TableColumn<SaleSummary, String> colItem = new TableColumn<>("Description");
        colItem.setMaxWidth(109);
        colItem.setMinWidth(109);
        colItem.setResizable(false);
//        colItem.setStyle("-fx-border-color: transparent #002349 transparent transparent; -fx-border-width: 0.5px;");
        colItem.setStyle("-fx-background-radius: 7.5px 0px 0px 0px; -fx-border-radius: 7.5px 0px 0px 0px; " +
                "-fx-border-color: transparent #002349 transparent transparent; -fx-border-width: 0.5px;");
        colItem.setCellValueFactory(new PropertyValueFactory<SaleSummary, String>("itemName"));

        TableColumn<SaleSummary, Double> colAmt = new TableColumn<>("Amt");
        colAmt.setMaxWidth(52);
        colAmt.setMinWidth(52);
        colAmt.setResizable(false);
        colAmt.setCellValueFactory(new PropertyValueFactory<SaleSummary, Double>("amount"));
        colAmt.setCellFactory(new Callback<TableColumn<SaleSummary, Double>, TableCell<SaleSummary, Double>>() {
            @Override
            public TableCell<SaleSummary, Double> call(TableColumn<SaleSummary, Double> col0) {
                TableCell cell = new TableCell() {
                    @Override
                    public void updateItem(Object item, boolean empty) {
                        if (item != null) {
                            setText(JKText.getDeciFormat((Double) item));
                            setStyle("-fx-padding: 0px 8px 0px 0px;");
                        }
                    }
                };
                cell.setAlignment(Pos.CENTER_RIGHT);
                return cell;
            }
        });

        TableColumn<SaleSummary, Integer> colRef = new TableColumn<>("Ref");
        colRef.setVisible(false);
        colRef.setCellValueFactory(new PropertyValueFactory<SaleSummary, Integer>("reference"));

        TableColumn<SaleSummary, Boolean> colCancel = new TableColumn<>("CanCancel");
        colCancel.setVisible(false);
        colCancel.setCellValueFactory(new PropertyValueFactory<SaleSummary, Boolean>("canCancel"));

        TableColumn<SaleSummary, String> colOffline = new TableColumn<>("Off-Online");
        colOffline.setVisible(false);
        colOffline.setCellValueFactory(new PropertyValueFactory<SaleSummary, String>("offOn"));

        TableColumn<SaleSummary, String> colAddRef = new TableColumn<>("AddRef");
        colAddRef.setVisible(false);
        colAddRef.setCellValueFactory(new PropertyValueFactory<SaleSummary, String>("addRef"));

        TableColumn<SaleSummary, Date> colDate = new TableColumn<>("Date");
        colDate.setVisible(false);
        colDate.setCellValueFactory(new PropertyValueFactory<SaleSummary, Date>("dateTime"));

        TableColumn<SaleSummary, String> colSerial = new TableColumn<>("Serial");
        colSerial.setVisible(false);
        colSerial.setCellValueFactory(new PropertyValueFactory<SaleSummary, String>("serialNo"));

        TableColumn<SaleSummary, String> colSaleType = new TableColumn<>("SaleType");
        colSaleType.setVisible(false);
        colSaleType.setCellValueFactory(new PropertyValueFactory<SaleSummary, String>("saleType"));

        columns.add(colItem);
        columns.add(colAmt);
        columns.add(colRef);
        columns.add(colCancel);
        columns.add(colOffline);
        columns.add(colAddRef);
        columns.add(colDate);
        columns.add(colSerial);
        columns.add(colSaleType);

        return columns;
    }

    public static void addSalesItem(String desc, double amt, String ref, boolean canCancel, String offOn,
                                    String addRef, Date date, String serial, String saleType) {
        String descTrimmed = desc.trim();
        SaleSummary sale = new SaleSummary(descTrimmed, amt, ref, canCancel, offOn, addRef, date, serial, saleType);
        summaryRows.add(sale);
    }

    private static double getTotalAmt(ObservableList<SaleSummary> summaryRows) {
        double salesTotal = 0.0;

        for (int r = 0; r < summaryRows.size(); r++) {
            double rowAmt = summaryRows.get(r).getAmount();
            salesTotal += rowAmt;
        }

        return salesTotal;
    }

    private static void updateTableAndButtonView(final ObservableList<SaleSummary> rows) {
        salesTable.setItems(rows);
//        salesTable.refresh();       // Java 8 and above

        totalAmt = getTotalAmt(rows);

        SceneSales.getTxtItemCount().setText(Integer.toString(rows.size()));
        SceneSales.getBtnAmtDue().setText("Amount Due\nR " + JKText.getDeciFormat(totalAmt));
        if (!salesTable.getItems().isEmpty()) {
            /* Sale is still in progress */
            setButtonStates(false);

            /* Disable the button... */
            SceneSales.getBtnRemove().setDisable(true);
            /* ... then check each item in the table. */
            for (SaleSummary s : salesTable.getItems()) {
                /* If even a single item CAN be removed, enable the "Remove Item" button. */
                if (s.getCanCancel()) {
                    SceneSales.getBtnRemove().setDisable(false);
                    break;
                }
            }
        } else {
            /* Sale complete - enable relevant buttons */
            SceneSales.getBtnRemove().setDisable(true);
            setButtonStates(true);
            SceneSales.getTxtItemCount().setText("0");
        }
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                // Without the Java 8 "refresh" method, we need to set the number of rows at which to move down.
                // Found that if we do not set row count, first item will RANDOMLY not be displayed,
                // although the amount on the button updates, and the voucher is printed if PrintQueue is used.
                if (summaryRows.size() > 8) {
                    salesTable.scrollTo(rows.size() - 1);
                }
            }
        });
    }

    private static void setButtonStates(boolean isSaleComplete) {
        SceneSales.getBtnAmtDue().setDisable(isSaleComplete);
        SceneSales.getBtnMainMenu().setDisable(!isSaleComplete);
        SceneSales.getOpenCashDraw().setDisable(!isSaleComplete);
        SceneSales.getBtnShiftEnd().setDisable(!isSaleComplete);
        SceneSales.getBtnLogout().setDisable(!isSaleComplete);
    }

    //    private void updateTime() {
//        long timeNow = System.currentTimeMillis();
////        System.out.println("timeNow = " + Long.toString(timeNow));
//
//        if (salesTable.getItems().size() == 0) {
//            SceneSales.getLblTime().textProperty().unbind();
//            SceneSales.getLblTime().setText(formatTime(STARTTIME));
////        } else if (salesTable.getItems().size() == 1) {
//        } else if (salesTable.getItems().size() > 0) {
////            if (at least one item is a TicketPro sale) {
//            final StringProperty timeString = new SimpleStringProperty("0.00");
//            SceneSales.getLblTime().textProperty().bind(timeString);
//            final Timeline timeline = new Timeline();
//            timeline.setCycleCount(Timeline.INDEFINITE);
//            timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(1), new EventHandler() {
//                @Override
//                public void handle(Event evt) {
//                    timeSeconds--;
//                    timeString.setValue(formatTime(timeSeconds));
//                    if (timeSeconds <= 0) {
//                        timeline.stop();
//                    }
//                }
//            }));
//            timeline.play();
////        }
//        }
//    }
//    public static String formatTime(Double time) {
//        String timeView = "";
//        double minutes = Math.floor(time / 60);
//        double seconds = Math.floor(time - (minutes * 60));
//        timeView = String.format("%01.0f:%02.0f", minutes, seconds);
//        return timeView;
//    }
    private static boolean canRemoveSelected() {
        boolean result = false;

        if (!JKPrintOptions.getPrintOptions().isPrintImmediately()) {
            if (salesTable.getSelectionModel().getSelectedIndex() > -1) {
                result = salesTable.getSelectionModel().getSelectedItem().getCanCancel();
            }
        } else {
            result = false;
        }
        return result;
    }

//    public static void removeSalesItem(SaleSummary saleItem) {
//        String selectedVoucherId = saleItem.getReference();
//        removeAndUpdate("item", selectedVoucherId);
//    }

    public static void removeSalesItem() {
        if (canRemoveSelected()) {
            final String selectedVoucherId = salesTable.getSelectionModel().getSelectedItem().getReference();
            if (salesTable.getSelectionModel().getSelectedItem().getSaleType().equals(SaleType.BUSTICKETS.getDisplay())) {
                removeAndUpdate("index", selectedVoucherId);
            } else {
                LOG.info(("ABOUT TO CANCEL VOUCHER with ID : ").concat(selectedVoucherId));
                VoucherUtil.cancelVoucherSale("", selectedVoucherId, new VoucherUtil.VoucherCancelResult() {

                    @Override
                    public void voucherCancelResult(Boolean cancelled) {
                        if (cancelled) {
                            LOG.info(("SUCCESSFULLY CANCELLED VOUCHER with ID : ").concat(selectedVoucherId));
                            removeAndUpdate("index", selectedVoucherId);
                        } else {
                            JKiosk3.getMsgBox().showMsgBox("Item not removed", "This item was not removed from the Sale", null);
                        }
                    }
                });
            }
        } else {
            JKiosk3.getMsgBox().showMsgBox("Unable To Remove Item", "This item cannot be removed from the sale", null);
        }
    }

    private static void removeAndUpdate(String itemOrIndex, final String voucherId) {
        if (itemOrIndex.equalsIgnoreCase("index")) {
            summaryRows.remove(salesTable.getSelectionModel().getSelectedIndex());
            updateTableAndButtonView(summaryRows);
        } else if (itemOrIndex.equalsIgnoreCase("item")) {
            List<SaleSummary> listRem = new ArrayList<>();
            for (SaleSummary s : summaryRows) {
                if (s.getReference().equalsIgnoreCase(voucherId)) {
                    listRem.add(s);
                }
            }
            for (SaleSummary r : listRem) {
                summaryRows.remove(r);
                updateTableAndButtonView(summaryRows);
            }
        }

        if (!JKPrintOptions.getPrintOptions().isPrintImmediately()) {
            if (PrintQueue.getPrintQueue().size() > 0) {
                PrintQueue.removeItem(voucherId);
            }

            for (StoreJKReprint r : JKReprint.getReprintList()) {
                if (voucherId == r.getVoucherReference()) {
                    JKReprint.removeReprint(r);
                    break;
                }
            }
        }

        if (JKPending.hasPendingItems()) {
            List<StoreJKPending> pendingList = JKPending.getPendingList();
            StoreJKPending pendingItem = null;
            for (StoreJKPending s : pendingList) {
                if (voucherId == s.getTransReference()) {
                    pendingItem = s;
                }
            }
            JKPending.removePendingItem(pendingItem);
        }
    }

    public static void clearSummaryTable() {
        if (salesTable.getItems().size() > 0) {
            salesTable.getItems().clear();
            summaryRows.clear();
        }

        updateTableAndButtonView(summaryRows);

        totalAmt = 0.0;
    }

    public static double getTotalAmt() {
        return totalAmt;
    }

    public static ObservableList<SaleSummary> getSummaryRows() {
        return summaryRows;
    }

    public static double getPrintChange() {
        return printChange;
    }

    public static void setPrintChange(double printChange) {
        SummaryTableView.printChange = printChange;
    }

    public static double getPrintTendered() {
        return printTendered;
    }

    public static void setPrintTendered(double printTendered) {
        SummaryTableView.printTendered = printTendered;
    }

    public double getTableHeight() {
        return tableHeight;
    }
}
