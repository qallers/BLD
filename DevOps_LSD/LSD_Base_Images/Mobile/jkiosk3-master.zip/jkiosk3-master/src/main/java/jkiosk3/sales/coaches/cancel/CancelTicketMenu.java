package jkiosk3.sales.coaches.cancel;

import aeoncoach.CoachCancelBookingReq;
import aeoncoach.CoachCancelBookingResp;
import aeoncoach.CoachConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.Group;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlConfirmAndCancel;
import jkiosk3.printing.PrintHandler;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.coaches.CancelCoachTicket;
import jkiosk3.store.*;
import jkiosk3.users.CurrentUser;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

public class CancelTicketMenu extends Region {

    private final static Logger logger = Logger.getLogger(CancelTicketMenu.class.getName());
    private StackPane stack;
    private StoreJKCancelTicket storeJKCancelTicket;
    private String cancelReason;

    public CancelTicketMenu() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getCancelTicketGroup());
        vb.getChildren().add(getPrintControl());

        getChildren().addAll(vb);

        getCancelTicket();
    }

    public CancelTicketMenu(StoreJKCancelTicket storeJKCancelTicket) {
        this();
        this.storeJKCancelTicket = storeJKCancelTicket;
        getCancelTicket();
    }

    private GridPane getContentGrid() {
        GridPane grid = JKLayout.getContentGridInner2ColInScroll(0.5, 0.5, HPos.RIGHT);

        Label lblReason = JKText.getLblDk("Cancellation Reason:", JKText.FONT_B_XSM);

        ObservableList<String> bookReasons = FXCollections.observableArrayList("Incorrectly Booked", "Change of mind", "No payment", "Other");

        final ComboBox<String> comReason = new ComboBox(bookReasons);
        comReason.setPromptText("Select Reason");

        // Create action event
        EventHandler<ActionEvent> event =
                new EventHandler<ActionEvent>() {
                    public void handle(ActionEvent e) {
                        cancelReason = (String) comReason.getValue();
                    }
                };

        // Set on action
        comReason.setOnAction(event);
        comReason.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.55), 35);

        grid.addRow(0, lblReason, comReason);

        return grid;
    }

    private Group getCancelTicketGroup() {
        VBox vbHead = JKNode.getPageHeadVB("Cancel Coach Ticket");

        stack = new StackPane();
        stack.setMaxHeight(480);
        stack.setMinHeight(200);

        VBox vb = JKLayout.getVBox(JKLayout.sp, JKLayout.spNum);
        vb.setMaxWidth(JKLayout.contentW);

        vb.getChildren().addAll(vbHead, getContentGrid(), stack);

        Group grp = JKNode.getContentGroup(vb);

        return grp;
    }

    private void getCancelTicket() {
        stack.getChildren().clear();

        if(storeJKCancelTicket != null) {
            final String carrier = storeJKCancelTicket.getCarrierName();
            ImageView imgView = JKNode.getJKImageViewProvider("prov_" + carrier.replaceAll(" ", "").replaceAll("\n", "") + ".png");

            Label lblDepartureTxt = JKText.getLblDk("Departure: ", JKText.FONT_B_20);
            Label lblDepartureValue = JKText.getLblDk(storeJKCancelTicket.getDeparture(), JKText.FONT_B_XXSM);

            Label lblDestTxt = JKText.getLblDk("Destination: ", JKText.FONT_B_20);
            Label lblDestValue = JKText.getLblDk(storeJKCancelTicket.getDestination(), JKText.FONT_B_XXSM);

            Label lblDepartureDateTxt = JKText.getLblDk("Departure date: ", JKText.FONT_B_20);
            Label lblDepartureDateValue = JKText.getLblDk(storeJKCancelTicket.getTravelTime(), JKText.FONT_B_XXSM);

            Label lblNumberOfTicketsTxt = JKText.getLblDk("Number of tickets: ", JKText.FONT_B_20);
            Label lblNumberOfTicketsValue = JKText.getLblDk(String.valueOf(storeJKCancelTicket.getQty()), JKText.FONT_B_XXSM);

            Label lblTransDateTxt = JKText.getLblDk("Transaction date: ", JKText.FONT_B_20);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            String date = sdf.format(storeJKCancelTicket.getTransactionDate());
            Label lblTransDateValue = JKText.getLblDk(date, JKText.FONT_B_XXSM);

            Label lblTransRefTxt = JKText.getLblDk("Transaction Ref.: ", JKText.FONT_B_20);
            Label lblTransRefValue = JKText.getLblDk(storeJKCancelTicket.getTransRef(), JKText.FONT_B_XXSM);

            GridPane grid = JKLayout.getContentGridInner2ColInScroll(0.5, 0.5, HPos.RIGHT);

            grid.addRow(1, new Separator(), new Separator());
            grid.addRow(2, imgView);
            grid.addRow(3, new Separator(), new Separator());
            grid.addRow(4, lblDepartureTxt, lblDepartureValue);
            grid.addRow(5, lblDestTxt, lblDestValue);
            grid.addRow(6, lblDepartureDateTxt, lblDepartureDateValue);
            grid.addRow(7, lblNumberOfTicketsTxt, lblNumberOfTicketsValue);
            grid.addRow(8, lblTransDateTxt, lblTransDateValue);
            grid.addRow(9, lblTransRefTxt, lblTransRefValue);

            stack.getChildren().add(grid);
        }

    }

    private ControlConfirmAndCancel getPrintControl() {
        final ControlConfirmAndCancel controlConfirmAndCancel = new ControlConfirmAndCancel();

        controlConfirmAndCancel.getBtnBack().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new CancelCoachTicket());
            }
        });

        controlConfirmAndCancel.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndShowFavourites();
            }
        });

        controlConfirmAndCancel.getBtnConfirm().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                cancelTicketOnAEON(controlConfirmAndCancel);
            }
        });

        return controlConfirmAndCancel;
    }

    public void cancelTicketOnAEON(ControlConfirmAndCancel controlConfirmAndCancel) {
        if (cancelReason != null) {
            controlConfirmAndCancel.getBtnConfirm().setDisable(true);

            String host = JKSystem.getSystemConfig().getServer();
            int port = JKSystem.getSystemConfig().getPort();
            boolean ssl = JKSystem.getSystemConfig().isSecureConn();

            try {
                CoachConnection coachConnection = new CoachConnection(host, port, ssl);

                String user = CurrentUser.getUser().getUserPin();
                int deviceID = JKSystem.getSystemConfig().getDeviceId();
                String deviceSer = JKSystem.getSystemConfig().getSerial();

                CoachConnection.setCurrentTransType(storeJKCancelTicket.getTransType());
                coachConnection.login(user, deviceID, deviceSer, "");

                CoachCancelBookingReq coachCancelBookingReq = new CoachCancelBookingReq();
                coachCancelBookingReq.setAeonTransactionReference(storeJKCancelTicket.getTransRef());
                coachCancelBookingReq.setCancellationReason(cancelReason);

                CoachCancelBookingResp coachCancelBookingResp = coachConnection.cancelCoachBooking(coachCancelBookingReq); // this returns cache connection......

                if (coachCancelBookingResp.isSuccess()) {
                    logger.info("Transaction successfully cancelled: " + storeJKCancelTicket + " with reason: " + cancelReason);

                    JKCancelTicket.removeCancelTicket(storeJKCancelTicket);

                    JKiosk3.getMsgBox().showMsgBox("Cancellation confirmation", "Transaction has been cancelled successfully R "
                            + coachCancelBookingResp.getReversedAmount() + " has been reserved. ", null);

                    PrintHandler.handleMerchantCopyPrint(coachCancelBookingResp.getMerchantCopyPrint());
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Unable to cancel ticket", "Ticket was not successfully cancelled. \nPlease try again later", null);
                }
            } catch (Exception e) {
                logger.severe(String.valueOf(e.getStackTrace()));
                JKiosk3.getMsgBox().showMsgBox("Oops! something went wrong", "System unable to cancel the ticket. \nPlease try again later", null);
            }
        } else {
            JKiosk3.getMsgBox().showMsgBox("Cancellation reason not selected", "Please select ticket cancellation reason", null);
        }
    }

}
