package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.printing.PrintHandler;
import jkiosk3.reports.ReportUtil.AeonPrintJobResult;

/**
 *
 * @author Val
 */
public class Transactions extends Region {

    private final static Logger logger = Logger.getLogger(Transactions.class.getName());
    private TextField txtDays;
    private int days;

    public Transactions() {
        VBox vb = JKLayout.getVBox(0, 5);

        vb.getChildren().add(getTransactsGroup());
        vb.getChildren().add(getPrintControl());

        getChildren().addAll(vb);
    }

    private GridPane getTransactsGroup() {
        GridPane grid = JKLayout.getGridContent2Col(0.25, 0.75);

        VBox vbHead = JKNode.getReportHeadVB("Transaction List");

        Label lblSelect = JKText.getLblDk("Days", JKText.FONT_B_XSM);
        lblSelect.setMinWidth(JKLayout.btnSmW);

        txtDays = new TextField();
        txtDays.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad().showNumPad(txtDays, "Enter Days", "");
            }
        });

        grid.add(vbHead, 0, 0, 2, 1);

        grid.addRow(1, lblSelect, txtDays);

        return grid;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls() {
            @Override
            public void onClickPrint() {
                showTransactionReport();
            }
        };
    }

    private void showTransactionReport() {
        if (inputValidation()) {
            try {
                ReportUtil.getPrintReport(ReportUtil.REP_TRANS_LIST, 0, days, new AeonPrintJobResult() {
                    @Override
                    public void aeonPrintJobResult(AeonPrintJob aeonPrintJob) {
                        PrintHandler.handlePrintRequestReport("Transaction List", aeonPrintJob);
                    }
                });
            } catch (Exception e) {
                logger.log(Level.SEVERE, e.getMessage(), e);
            }
            resetForm();
        }
    }

    private boolean inputValidation() {
        boolean validated = false;
        try {
            days = Integer.parseInt(txtDays.getText());
            validated = true;
        } catch (NumberFormatException nfe) {
            JKiosk3.getMsgBox().showMsgBox("Days", "Number of days must be a whole integer number", null);
        }
        return validated;
    }

    private void resetForm() {
        SceneReports.clearAndChangeContent(new Transactions());
    }
}
