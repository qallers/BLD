package jkiosk3.accounts.banking;

import aeonreports.Account;
import aeonreports.AccountList;

import java.util.ArrayList;
import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.TextAlignment;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3.SceneMenu;
import jkiosk3._common.JKLayout;

import static jkiosk3._common.JKLayout.sp;

import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.reports.ReportUtil;

public class SceneBanking extends Region {

    public final static String BANK_ABSA = "ABSA";
    public final static String BANK_FNB = "First National Bank";
    public final static String BANK_NEDBANK = "Nedbank";
    public final static String BANK_STANDARD = "Standard Bank";

    private static VBox vbBankAccContent;
    private VBox vbBtns;
    private AccountList listAccounts;
    private final static double infoHeight = 425;

    public SceneBanking() {
        StackPane stack = JKLayout.getSceneStack(getBankingSceneLayout(), this);
        getChildren().add(stack);
        getLinkedAccounts();
    }

    private AnchorPane getBankingSceneLayout() {
        Group menu = getMenuGroup();
        vbBankAccContent = JKLayout.getVBox(0, JKLayout.spNum);
        VBox grpInfo = JKLayout.getSceneInfoBox(infoHeight, getSceneInfo());
        VBox grpClose = JKLayout.getMainMenuBtn(new SceneMenu());

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(grpInfo, grpClose);

        AnchorPane ap = JKLayout.getSceneAnchor(menu, vbBankAccContent, vb);
        ap.getChildren().addAll(menu, vbBankAccContent, vb);

        return ap;
    }

    private Group getMenuGroup() {
        Group grp = new Group();
        Rectangle rec = new Rectangle(JKLayout.sideW, JKLayout.menuH);
        vbBtns = JKLayout.getVBox(sp, sp);

        grp.getChildren().addAll(rec, vbBtns);

        return grp;
    }

    private void getLinkedAccounts() {
        ReportUtil.getAccountList(new ReportUtil.AccountListResult() {
            @Override
            public void accountListResult(AccountList accountList) {
                if (accountList.isSuccess()) {
                    if (!accountList.getAccounts().isEmpty()) {
                        listAccounts = accountList;
                        getAccountsMenu();
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Accounts", "No Accounts were found linked to this Device",
                                null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                    @Override
                                    public void onOk() {
                                        JKiosk3.changeScene(new SceneMenu());
                                    }

                                    @Override
                                    public void onCancel() {
                                        //
                                    }
                                });
                    }
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Accounts", "Unable to retrieve list of Accounts\n\n" + accountList.getErrorText(), null);
                    JKiosk3.changeScene(new SceneMenu());
                }
            }
        });
    }

    private void getAccountsMenu() {

        List<Button> btnList = new ArrayList<>();

        if (listAccounts != null) {
            for (final Account a : listAccounts.getAccounts()) {
                final Button btn = JKNode.getBtnSm(a.getAccountNo());
                btn.setOnMouseReleased(new EventHandler<Event>() {
                    @Override
                    public void handle(Event e) {
                        onSelectAccount(a);
                    }
                });
                btnList.add(btn);
            }
        }

        vbBtns.getChildren().addAll(btnList);
    }

    private VBox getSceneInfo() {

        VBox vb = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
        vb.setMaxSize(JKLayout.sideW, infoHeight);
        vb.setMinSize(JKLayout.sideW, infoHeight);

        Label lblAdvice = JKText.getLblDk("To facilitate prompt allocation of Deposit, please ensure Deposit to", JKText.FONT_B_XXSM);
        lblAdvice.setTextAlignment(TextAlignment.CENTER);
        lblAdvice.setWrapText(true);

        Label lblAcc = JKText.getLblDk("CORRECT\nBANK ACCOUNT", JKText.FONT_B_XXSM);
        lblAcc.setStyle("-fx-text-fill: #FF0000;");
        lblAcc.setTextAlignment(TextAlignment.CENTER);

        Label lblWith = JKText.getLblDk("with", JKText.FONT_B_XXSM);

        Label lblRef = JKText.getLblDk("CORRECT\nREFERENCE", JKText.FONT_B_XXSM);
        lblRef.setStyle("-fx-text-fill: #FF0000;");
        lblRef.setTextAlignment(TextAlignment.CENTER);

        Label lblSep = JKText.getLblDk("* * *", JKText.FONT_B_12);

        Label lblSupport = JKText.getLblDk("Support", JKText.FONT_B_XXSM);

        Label lblNumber = JKText.getLblDk(JK3Config.getInfoHelpDeskTelNum(), JKText.FONT_B_XXSM);

        vb.getChildren().addAll(lblAdvice, lblAcc, lblWith, lblRef, lblSep, lblSupport, lblNumber);

        return vb;
    }

    private void onSelectAccount(Account accSelected) {
        vbBankAccContent.getChildren().clear();
        vbBankAccContent.getChildren().add(new BankSelect(accSelected));
    }

    public static VBox getVbBankAccContent() {
        return vbBankAccContent;
    }
}
