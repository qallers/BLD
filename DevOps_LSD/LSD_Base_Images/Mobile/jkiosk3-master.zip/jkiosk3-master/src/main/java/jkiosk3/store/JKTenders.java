package jkiosk3.store;

import aeontender.TenderType;

public class JKTenders {

    private static StoreJKTenders jkTenders;

    private static void loadTenders() {
        if ((jkTenders == null) || jkTenders.getListTenderTypes().isEmpty()) {
            jkTenders = (StoreJKTenders) Store.loadObject(JKTenders.class.getSimpleName());
        }
        if (jkTenders == null) {
            jkTenders = new StoreJKTenders();
        }
    }

    public static boolean hasItems() {
        loadTenders();
        return jkTenders.getListTenderTypes().size() > 0;
    }

    public static void saveTender(TenderType tender) {
        loadTenders();
        jkTenders.getListTenderTypes().add(tender);
        Store.saveObject(JKTenders.class.getSimpleName(), jkTenders);
    }
    
    public static void clearAndSaveTenders(StoreJKTenders tenders) {
        clearTendersList();
        jkTenders = tenders;
        Store.saveObject(JKTenders.class.getSimpleName(), jkTenders);
    }
    
    public static void removeTender(TenderType tender) {
        loadTenders();
        String tenderRef = tender.getReference();
        for (TenderType tt : jkTenders.getListTenderTypes()) {
            if (tt.getReference().equalsIgnoreCase(tenderRef)) {
                jkTenders.getListTenderTypes().remove(tt);
                break;
            }
        }
        Store.saveObject(JKTenders.class.getSimpleName(), jkTenders);
        checkForEmptyList();
    }
    
    private static void checkForEmptyList() {
        loadTenders();
        if (jkTenders.getListTenderTypes().isEmpty()) {
            clearTendersList();
        } else {
            Store.saveObject(JKTenders.class.getSimpleName(), jkTenders);
        }
    }

    public static void clearTendersList() {
        if (jkTenders != null) {
            jkTenders.getListTenderTypes().clear();
        }
        Store.deleteObject(JKTenders.class.getSimpleName());
    }

    public static StoreJKTenders getJkTenders() {
        loadTenders();
        return jkTenders;
    }
}
