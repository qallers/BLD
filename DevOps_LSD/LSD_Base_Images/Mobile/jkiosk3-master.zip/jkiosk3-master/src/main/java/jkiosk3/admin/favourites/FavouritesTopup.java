package jkiosk3.admin.favourites;

import aeonfavourites.FavouriteItem;
import aeontopup.TopupBundleCategory;
import aeontopup.TopupBundleProduct;
import aeontopup.TopupBundleProductList;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.admin.favourites.fav_cache.CacheFavouriteCustomStore;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.topups.AirtimeUtil;
import jkiosk3.sales.topups.TopupProvider;

import java.util.ArrayList;
import java.util.List;

public class FavouritesTopup extends Region {

    private List<FavouriteItem> listFavouriteCache;
    private List<FavouriteItem> listFavouriteTemp;
    private SaleType saleTypeSelected;
    private TopupProvider topupProviderSelected;
    private List<TopupBundleProduct> listProdData;
    private List<TopupBundleProduct> listProdSMS;
    private StackPane stackPane;
    private final double innerWidth = (JKLayout.contentW - (2 * JKLayout.sp));
    private final static double PG_HT = 430;
    private final static int PG_SIZE = 8;

    public FavouritesTopup() {
        this.listFavouriteCache = CacheFavouriteCustomStore.getListFavouriteItems();
        this.listFavouriteTemp = new ArrayList<>();
        for (FavouriteItem f : listFavouriteCache) {
            listFavouriteTemp.add(f);
        }
        this.stackPane = JKLayout.getStackFavouriteSelect(PG_HT);

        getChildren().addAll(getFavouriteTopupLayout());
    }

    private VBox getFavouriteTopupLayout() {
        VBox vbContent = JKLayout.getVBoxContent(JKLayout.spNum);
        VBox vbHead = JKNode.getPageHeadVB("Select Topup Favourites");
        vbContent.getChildren().addAll(vbHead, getSelectTopupFavs());

        VBox vbPage = JKLayout.getVBox(0, JKLayout.spNum);
        vbPage.getChildren().addAll(vbContent, getBtnControls());

        return vbPage;
    }

    private ControlButtonsFav getBtnControls() {
        ControlButtonsFav ctrl = new ControlButtonsFav();
        ctrl.getBtnSave().setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                saveUpdatedFavourites();
            }
        });
        return ctrl;
    }

    private VBox getSelectTopupFavs() {

        Label lblSelect = JKText.getLblDk("Select Topup Type", JKText.FONT_B_XSM);
        lblSelect.setMinWidth(JKLayout.btnSmW);

        List<SaleType> listTopupTypes = new ArrayList<>();
//        listTopupTypes.add(SaleType.TOPUP_AIRTIME);
        listTopupTypes.add(SaleType.TOPUP_BUNDLE_DATA);
//        listTopupTypes.add(SaleType.TOPUP_BUNDLE_SMS);

        final ObservableList<SaleType> listTopType = FXCollections.observableArrayList(listTopupTypes);

        final ObservableList<TopupProvider> listTopProv = FXCollections.observableArrayList();

        final ComboBox comTopTypeSelect = new ComboBox();
        comTopTypeSelect.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.5), 35);
        comTopTypeSelect.setItems(listTopType);

        final Label lblProv = JKText.getLblDk("Select Bundle Provider", JKText.FONT_B_XSM);
        lblProv.setDisable(true);

        final ComboBox comTopProvSelect = new ComboBox();
        comTopProvSelect.setDisable(true);
        comTopProvSelect.setPrefSize(((JKLayout.contentW - (2 * JKLayout.sp)) * 0.5), 35);

        comTopTypeSelect.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                saleTypeSelected = (SaleType) newValue;
                topupProviderSelected = null;
                stackPane.getChildren().clear();

                if (saleTypeSelected == SaleType.TOPUP_AIRTIME) {
                    lblProv.setDisable(true);
                    comTopProvSelect.setDisable(true);
                    getPageContents();
                } else {
                    lblProv.setDisable(false);
                    comTopProvSelect.setDisable(false);
                    comTopProvSelect.getItems().clear();
                    listTopProv.clear();
                    AirtimeUtil.getListTopupProvidersToShow(saleTypeSelected, new AirtimeUtil.TopupBundleProviderListResult() {
                        @Override
                        public void topupBundleProviderListResult(List<TopupProvider> providerList) {
                            if (!providerList.isEmpty()) {
                                listTopProv.addAll(providerList);
                                comTopProvSelect.setItems(listTopProv);
                            }
                        }
                    });
                }
            }
        });

        comTopProvSelect.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                topupProviderSelected = (TopupProvider) newValue;
                if (topupProviderSelected != null) {
                    AirtimeUtil.getTopupBundleProductList(topupProviderSelected, new AirtimeUtil.TopupBundleProductListResult() {
                        @Override
                        public void topupBundleProductListResult(TopupBundleProductList productList) {
                            if (productList.isSuccess() && !productList.getlistCategories().isEmpty()) {
                                makeBundleLists(productList);
                            }
                        }
                    });
                }
            }
        });

        HBox hbType = JKLayout.getHBox(0, 0);
        hbType.setMaxWidth(innerWidth);
        hbType.setMinWidth(innerWidth);
        hbType.getChildren().addAll(lblSelect, JKNode.getHSpacer(), comTopTypeSelect);

        HBox hbProv = JKLayout.getHBox(0, 0);
        hbProv.setMaxWidth(innerWidth);
        hbProv.setMinWidth(innerWidth);
        hbProv.getChildren().addAll(lblProv, JKNode.getHSpacer(), comTopProvSelect);

        VBox vbContent = JKLayout.getVBoxLeft(0, JKLayout.spNum);
        vbContent.getChildren().addAll(hbType, JKNode.createContentSep(), hbProv, JKNode.createContentSep(), stackPane);

        return vbContent;
    }

    private void makeBundleLists(TopupBundleProductList productList) {
        List<TopupBundleProduct> listDataTmp = new ArrayList<>();
        List<TopupBundleProduct> listSMSTmp = new ArrayList<>();
        for (TopupBundleCategory cat : productList.getlistCategories()) {
            if (cat.getType().contains("DATA")) {
                for (TopupBundleProduct p : cat.getListProducts()) {
                    listDataTmp.add(p);
                }

            } else if (cat.getType().contains("SMS")) {
                for (TopupBundleProduct p : cat.getListProducts()) {
                    listSMSTmp.add(p);
                }
            }
        }
        listProdData = listDataTmp;
        listProdSMS = listSMSTmp;

        getPageContents();
    }

    private void getPageContents() {
        stackPane.getChildren().clear();

        List<Node> listNodes = new ArrayList<>();
        switch (saleTypeSelected) {
            case TOPUP_AIRTIME:
                List<TopupProvider> listTopProv = AirtimeUtil.getTopupProviderAirtimeList();
                listNodes = getTopupAirSelectionList(listTopProv);
                break;
            case TOPUP_BUNDLE_DATA:
                listNodes = getTopupBundleSelectionList(listProdData);
                break;
            case TOPUP_BUNDLE_SMS:
                listNodes = getTopupBundleSelectionList(listProdSMS);
                break;
            default:
                break;
        }
        createPagedItems(listNodes);
    }

    private void createPagedItems(final List<Node> listNodes) {

        int numPgs = 0;
        if (listNodes.isEmpty()) {
            numPgs = 1;
        } else if (listNodes.size() % PG_SIZE == 0) {
            numPgs = listNodes.size() / PG_SIZE;
        } else {
            numPgs = (listNodes.size() / PG_SIZE) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedVBox(pg, listNodes, PG_SIZE, PG_HT);
            }
        });

        stackPane.getChildren().add(pages);
    }

    private List<Node> getTopupAirSelectionList(List<TopupProvider> listTopProvs) {
        List<Node> listChks = new ArrayList<>();
        for (final TopupProvider p : listTopProvs) {
            final CheckBox chk = new CheckBox(p.getDisplayName());
            for (FavouriteItem i : listFavouriteCache) {
                if (i.getTrxGroup().equalsIgnoreCase("Topup")
                        && i.getTrxType().equals(p.getName())) {
                    chk.setSelected(true);
                    break;
                }
            }
            chk.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    if (chk.isSelected()) {
                        addProductTopAir(p);
                    } else if (!chk.isSelected()) {
                        removeProductTopAir(p);
                    }
                }
            });
            listChks.add(chk);
        }
        return listChks;
    }

    private List<Node> getTopupBundleSelectionList(List<TopupBundleProduct> listTopBundles) {
        List<Node> listChks = new ArrayList<>();
        for (final TopupBundleProduct prod : listTopBundles) {
            final CheckBox chk = new CheckBox(prod.getDescription());
            for (FavouriteItem i : listFavouriteCache) {
                if (i.getTrxGroup().equalsIgnoreCase("Bundles")
                        && i.getTrxType().equals(topupProviderSelected.getName())
                        && i.getProductId().equals(Integer.toString(prod.getProductCode()))) {
                    chk.setSelected(true);
                    break;
                }
            }
            chk.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    if (chk.isSelected()) {
                        addProductTopBundle(prod);
                    } else if (!chk.isSelected()) {
                        removeProductTopBundle(prod);
                    }
                }
            });
            listChks.add(chk);
        }
        return listChks;
    }

    private void addProductTopAir(TopupProvider prov) {
        if (!isProductInListTopAir(prov)) {
            FavouriteItem favouriteItem = new FavouriteItem();
            favouriteItem.setTrxGroup("Topup");
            favouriteItem.setTrxType(prov.getName());
            favouriteItem.setProductId(""); // no product id for Topup Airtime providers
            listFavouriteTemp.add(favouriteItem);
        }
    }

    private void removeProductTopAir(TopupProvider prov) {
        if (isProductInListTopAir(prov)) {
            for (FavouriteItem f : listFavouriteTemp) {
                if (f.getTrxGroup().equalsIgnoreCase("Topup")
                        && f.getTrxType().equals(prov.getName())) {
                    listFavouriteTemp.remove(f);
                    break;
                }
            }
        }
    }

    private boolean isProductInListTopAir(TopupProvider prov) {
        FavouriteItem favItem = null;
        for (FavouriteItem f : listFavouriteTemp) {
            if (f.getTrxGroup().equalsIgnoreCase("Topup")
                    && f.getTrxType().equals(prov.getName())) {
                favItem = f;
                break;
            }
        }
        if (favItem != null) {
            return true;
        } else {
            return false;
        }
    }

    private void addProductTopBundle(TopupBundleProduct prod) {
        if (!isProductInListTopBundle(prod)) {
            FavouriteItem favouriteItem = new FavouriteItem();
            favouriteItem.setTrxGroup("Bundles");
            favouriteItem.setTrxType(topupProviderSelected.getName());
            favouriteItem.setProductId(Integer.toString(prod.getProductCode()));
            listFavouriteTemp.add(favouriteItem);
        }
    }

    private void removeProductTopBundle(TopupBundleProduct prod) {
        if (isProductInListTopBundle(prod)) {
            for (FavouriteItem f : listFavouriteTemp) {
                if (f.getTrxGroup().equalsIgnoreCase("Bundles")
                        && f.getTrxType().equals(topupProviderSelected.getName())
                        && f.getProductId().equals(Integer.toString(prod.getProductCode()))) {
                    listFavouriteTemp.remove(f);
                    break;
                }
            }
        }
    }

    private boolean isProductInListTopBundle(TopupBundleProduct prod) {
        FavouriteItem favItem = null;
        for (FavouriteItem f : listFavouriteTemp) {
            if (f.getTrxGroup().equalsIgnoreCase("Bundles")
                    && f.getTrxType().equals(topupProviderSelected.getName())
                    && f.getProductId().equals(Integer.toString(prod.getProductCode()))) {
                favItem = f;
                break;
            }
        }
        if (favItem != null) {
            return true;
        } else {
            return false;
        }
    }

    private void saveUpdatedFavourites() {
        if (!listFavouriteTemp.isEmpty()) {
            listFavouriteCache = listFavouriteTemp;
            if (CacheFavouriteCustomStore.saveFavouriteStore(listFavouriteCache)) {
                SceneFavourites.clearAndChangeContent(new FavouritesTopup());
            }
        } else {
            JKiosk3.getMsgBox().showMsgBox("Custom Favourites", "Please add at least 1 product to the list", null);
        }
    }
}
