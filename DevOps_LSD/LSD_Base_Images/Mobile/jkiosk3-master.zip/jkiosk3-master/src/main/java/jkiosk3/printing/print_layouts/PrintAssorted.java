package jkiosk3.printing.print_layouts;

import aeonprinting.AeonPrintJob;
import aeonprinting.AeonPrintLine;
import aeontender.Item;
import aeontender.TenderType;
import aeonusers.User;
import javafx.collections.ObservableList;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKText;
import jkiosk3.printing.BarcodeHandler;
import jkiosk3.sales.MerchantCopy;
import jkiosk3.sales.SaleSummary;
import jkiosk3.sales._common.SummaryTableView;
import jkiosk3.store.JKPrintOptions;
import jkiosk3.store.JKSystem;
import jkiosk3.users.CurrentUser;

import java.util.List;

public class PrintAssorted {

    private final static String PRINT_LAYOUT_01 = "%-14s" + "%-2s" + "%20s";
    private final static String PRINT_LAYOUT_02 = "%-16s" + "%20s";
    private final static String PRINT_DONE = "- Print Done -";

    /**
     * Private Constructor created to hide implicit public one.
     */
    private PrintAssorted() {
    }

    public static AeonPrintJob addMerchantHeader() {
        AeonPrintJob apj = new AeonPrintJob();

        List<String> storeName = apj.wordWrap(JKPrintOptions.getPrintOptions().getStoreName(), 36);
        for (String line : storeName) {
            apj.addCentreBold(line);
        }
        List<String> storeAddress = apj.wordWrap(JKPrintOptions.getPrintOptions().getStoreAddress(), 36);
        for (String line : storeAddress) {
            apj.addCentre(line);
        }
        if (!JKPrintOptions.getPrintOptions().getStoreVatReg().equals("")) {
            apj.addCentre("VAT Reg No: " + JKPrintOptions.getPrintOptions().getStoreVatReg());
        }
        return apj;
    }

    public static AeonPrintJob getTestPrint() {
        AeonPrintJob apj = new AeonPrintJob();

        apj.addLogo("0");
        apj.addBreak();
        apj.addCentreBold("Test Print");
        apj.addBreak();
        apj.addCentre(String.format(PRINT_LAYOUT_01, "Date", ":", JKText.getDateDisplaySec(new java.util.Date())));
        apj.addBreak();
        apj.addCentre("");
        apj.addCentreBold("Test print successful");
        apj.addCentreBold(PRINT_DONE);

        return apj;
    }

    /**
     * Constructs an AeonPrintJob to test the selected printer's barcode
     * printing capabilities.
     *
     * @param format the barcode format to be printed.
     * @param data   the data to be encoded in the barcode.
     * @return an AeonPrintJob, ready to be displayed and/or printed.
     */
    public static AeonPrintJob getTestBarcodePrint(String format, String data) {
        AeonPrintJob apj = new AeonPrintJob();

        apj.addLogo("0");
        apj.addBreak();
        apj.addCentreBold("Test Barcode Print");
        apj.addBreak();
        apj.addCentre(String.format(PRINT_LAYOUT_01, "Date", ":", JKText.getDateDisplaySec(new java.util.Date())));
        apj.addBreak();
        apj.addCentre("");
        apj.addCentre("Barcode Format : " + format);

        switch (format) {
            case BarcodeHandler.BARCODE_128A:
                apj.addBarcode128A(data);
                break;
            case BarcodeHandler.BARCODE_128B:
                apj.addBarcode128B(data);
                break;
            case BarcodeHandler.BARCODE_128C:
                apj.addBarcode128C(data);
                break;
            case BarcodeHandler.BARCODE_PDF417:
                apj.addBarcodePDF417(data);
                break;
            case "P":
                apj.addBarcodeEan(data);
                break;
            default:
                apj.addBarcodeEan("6006986000601");
        }
        apj.addCentre("");
        apj.addCentreBold("Test Barcode print successful");
        apj.addCentreBold(PRINT_DONE);

        return apj;
    }

    /**
     * Constructs an AeonPrintJob for a summary of Sales items in the 'basket'.
     *
     * @param tenderTypes the tender types received in payment for the amount
     *                    due.
     * @return an AeonPrintJob, ready to be displayed and/or printed.
     */
    public static AeonPrintJob getSalesReceipt(TenderType tenderTypes) {
        final String PRINT_LAYOUT_ITEMS = "%-26s" + "%10s";
        ObservableList<SaleSummary> summaryRows = SummaryTableView.getSummaryRows();
        double totalAmt = SummaryTableView.getTotalAmt();
        double printChange = SummaryTableView.getPrintChange();

        AeonPrintJob apj = new AeonPrintJob();

        apj.addLogo("0");

        for (AeonPrintLine line : addMerchantHeader().getLines()) {
            apj.getLines().add(line);
        }

        apj.addBreak();
        apj.addCentreBold("Sales Receipt");
        apj.addBreak();
        apj.addCentre(String.format(PRINT_LAYOUT_01, "Date", ":", JKText.getDateDisplaySec(new java.util.Date())));
        apj.addCentre(String.format(PRINT_LAYOUT_01, "Cashier", ":", CurrentUser.getSalesUser().getUserName()));
        apj.addBreak();
        apj.addCentreBold("Sales Summary");
        apj.addCentreBold(String.format(PRINT_LAYOUT_02, "Item", "Price"));

        for (SaleSummary row : summaryRows) {
            String itemTrimmed = row.getItemName().trim();
            if (itemTrimmed.length() > 26) {
                List<String> itemName = apj.wordWrap(itemTrimmed, 26);
                for (int i = 0; i < itemName.size(); i++) {
                    if (i == 0) {
                        apj.addCentre(String.format(PRINT_LAYOUT_ITEMS, itemName.get(i).trim(), JKText.getDeciFormat(row.getAmount())));
                    } else {
                        apj.addCentre(String.format(PRINT_LAYOUT_ITEMS, " " + itemName.get(i), ""));
                    }
                }
            } else {
                apj.addCentre(String.format(PRINT_LAYOUT_ITEMS, itemTrimmed, JKText.getDeciFormat(row.getAmount())));
            }
            if (row.getSerialNo() != null) {
                if (!row.getSerialNo().trim().isEmpty()) {
                    apj.addCentre(String.format(PRINT_LAYOUT_ITEMS, "   " + row.getSerialNo(), ""));
                }
            }
        }

        apj.addCentre(" ");
        apj.addCentreBold(String.format("%-20s" + "%16s", "Total Due (VAT Incl)", JKText.getDeciFormat(totalAmt)));
        apj.addBreak();
        apj.addCentreBold("Tendered");
        // add check for Settings... Sales Options... Enter Amount Tendered etc.
//        if (JKSalesOptions.getSalesOptions().isEnterTender()) {

        if (tenderTypes.getCash() > 0) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Cash", JKText.getDeciFormat(tenderTypes.getCash())));
        }
        if (tenderTypes.getCheque() > 0) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Cheque", JKText.getDeciFormat(tenderTypes.getCheque())));
        }
        if (tenderTypes.getCreditcard() > 0) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Credit Card", JKText.getDeciFormat(tenderTypes.getCreditcard())));
        }
        if (tenderTypes.getDebitcard() > 0) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Debit Card", JKText.getDeciFormat(tenderTypes.getDebitcard())));
        }
        apj.addCentre(String.format(PRINT_LAYOUT_02, "Change", JKText.getDeciFormat(printChange)));
//        } else {
//            apj.addCentre("Tender Not Recorded");
//        }

        apj.addCentre(" ");
        apj.addCentreBold("Thank you - Please call again");
        apj.addCentreBold(PRINT_DONE);
        apj.addCentre(" ");

        return apj;
    }

    public static AeonPrintJob getPrintTenderSubmitFail(TenderType tenderTypes) {
        AeonPrintJob apj = new AeonPrintJob();

        for (AeonPrintLine line : addMerchantHeader().getLines()) {
            apj.getLines().add(line);
        }

        apj.addBreak();
        apj.addCentreBold("Tender Submit Failure");
        apj.addBreak();
        apj.addCentre(String.format(PRINT_LAYOUT_01, "Date", ":", JKText.getDateDisplaySec(new java.util.Date())));
        if (CurrentUser.getSalesUser() != null) {
            apj.addCentre(String.format(PRINT_LAYOUT_01, "Cashier", ":", CurrentUser.getSalesUser().getUserName()));
        } else {
            apj.addCentre(String.format(PRINT_LAYOUT_01, "Cashier", ":", "Unknown"));
        }
//        apj.addCentre(String.format(PRINT_LAYOUT_01, "Cashier", ":", CurrentUser.getSalesUser().getUserName()));
        apj.addBreak();

        List<Item> listItems = tenderTypes.getItemList();
        for (Item i : listItems) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Trans Ref", i.getTransRef()));
        }
        apj.addCentre("");

        apj.addCentre("");
        apj.addCentreBold(String.format("%-22s" + "%14s", "Sale Total (VAT Incl)", JKText.getDeciFormat(tenderTypes.getTotal())));

        if (tenderTypes.getCash() > 0) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Cash", JKText.getDeciFormat(tenderTypes.getCash())));
        }
        if (tenderTypes.getCheque() > 0) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Cheque", JKText.getDeciFormat(tenderTypes.getCheque())));
        }
        if (tenderTypes.getCreditcard() > 0) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Credit Card", JKText.getDeciFormat(tenderTypes.getCreditcard())));
        }
        if (tenderTypes.getDebitcard() > 0) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Debit Card", JKText.getDeciFormat(tenderTypes.getDebitcard())));
        }
        if (tenderTypes.getOther() > 0) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Other", JKText.getDeciFormat(tenderTypes.getOther())));
        }
        if (tenderTypes.getChange() > 0) {
            apj.addCentre(String.format(PRINT_LAYOUT_02, "Change Given", JKText.getDeciFormat(tenderTypes.getChange())));
        }

        apj.addBreak();

        apj.addCentre(
                "");
        apj.addCentreBold(PRINT_DONE);

        apj.addCentre(
                "");

        return apj;
    }

    /**
     * Constructs an AeonPrintJob for an abbreviated copy of details for an item
     * sold. Used by certain Merchants as a means to help them balance Shifts.
     *
     * @param merchantCopy a MerchantCopy holding all the information necessary
     *                     for construction of the print.
     * @return an AeonPrintJob, ready to be displayed and/or printed.
     */
    public static AeonPrintJob getMerchantCopyPrint(MerchantCopy merchantCopy) {
        final String PRINT_LAYOUT = "%-12s" + "%-1s" + "%23s";
        AeonPrintJob apj = new AeonPrintJob();

        apj.addCentre("");
        apj.addCentreBold("Merchant Copy");

        apj.addBreak();

        // Mac ID of device
        // relevant shift number
        // time sold
        // voucher details (vodacom r5)
        // sequence number - 1, 2, 3, 4, 5 - this can start at 1 on a new shift
        apj.addCentre(String.format(PRINT_LAYOUT, "Device ID", ":", JKSystem.getSystemConfig().getDeviceId()));
        apj.addCentre(String.format(PRINT_LAYOUT, "Shift No.", ":", merchantCopy.getShiftNo()));
        apj.addCentre(String.format(PRINT_LAYOUT, "Sequence No.", ":", merchantCopy.getSequenceNo()));

        // http://jira.bltelecoms.net:8080/browse/PRODDEFECT-11
        // add - transType
        apj.addCentre(String.format(PRINT_LAYOUT, "Trans Type", ":", merchantCopy.getTransType()));

        if (merchantCopy.getProduct().length() > 23) {
            List<String> productWrap = apj.wordWrap(merchantCopy.getProduct(), 23);
            for (int i = 0; i < productWrap.size(); i++) {
                if (i == 0) {
                    apj.addCentre(String.format(PRINT_LAYOUT, "Product", ":", productWrap.get(i)));
                } else {
                    apj.addCentre(String.format(PRINT_LAYOUT, " ", ":", productWrap.get(i)));
                }
            }
        } else {
            apj.addCentre(String.format(PRINT_LAYOUT, "Product", ":", merchantCopy.getProduct()));
        }

        apj.addCentre(String.format(PRINT_LAYOUT, "Amount", ":", JKText.getDeciFormat(merchantCopy.getAmount())));

        // http://jira.bltelecoms.net:8080/browse/PRODDEFECT-11
        // add - serial number
        if (merchantCopy.getSerial() != null) {
            apj.addCentre(String.format(PRINT_LAYOUT, "Serial No.", ":", merchantCopy.getSerial()));
        }
        // http://jira.bltelecoms.net:8080/browse/PRODDEFECT-11
        // add - ref
        if (merchantCopy.getStockID() != 0) {
            apj.addCentre(String.format(PRINT_LAYOUT, "Ref No.", ":", merchantCopy.getStockID()));
        }
        // http://jira.bltelecoms.net:8080/browse/PRODDEFECT-11
        // add - transRef
        if (!merchantCopy.getTransRef().equalsIgnoreCase("0")) {
            apj.addCentre(String.format(PRINT_LAYOUT, "Trans Ref", ":", merchantCopy.getTransRef()));
        }

        apj.addCentre(String.format(PRINT_LAYOUT, "Date", ":", JKText.getDateDisplaySec(merchantCopy.getDate())));
        apj.addCentre(String.format(PRINT_LAYOUT, "Cashier", ":", merchantCopy.getCashier()));
        if (merchantCopy.getTenderType() != null) {
            apj.addCentre(String.format(PRINT_LAYOUT, "Tender Type", ":", merchantCopy.getTenderType()));
        }

        apj.addBreak();

        apj.addCentreBold(PRINT_DONE);

        return apj;
    }

    /**
     * Constructs an AeonPrintJob for a Reprint of an item sold. Uses the
     * original AeonPrintJob, and adds the word * REPRINT * above and below the
     * print content.
     *
     * @param print the original AeonPrintJob from which the Reprint must be
     *              constructed.
     * @return an AeonPrintJob, ready to be displayed and/or printed.
     */
    public static AeonPrintJob getReprintLayout(AeonPrintJob print) {
        AeonPrintJob apj = new AeonPrintJob();

        apj.addBreak();
        apj.addCentre("* REPRINT *");
        apj.addBreak();
        for (AeonPrintLine line : print.getLines()) {
            apj.getLines().add(line);
        }
        apj.addBreak();
        apj.addCentre("* REPRINT *");
        apj.addBreak();
        return apj;
    }

    /**
     * Constructs an AeonPrintJob for the List of User details for the Device on
     * which the print is requested.
     *
     * @param listUsers the List of User objects to be printed.
     * @return an AeonPrintJob, ready to be displayed and/or printed.
     */
    public static AeonPrintJob getPrintUserList(List<User> listUsers) {
        AeonPrintJob apj = new AeonPrintJob();

        apj.addCentre("");
        apj.addCentreBold("User List");
        apj.addBreak();
        apj.addCentre(String.format(PRINT_LAYOUT_01, "Date", ":", JKText.getDateDisplaySec(new java.util.Date())));
        apj.addCentre(String.format(PRINT_LAYOUT_01, "Printed By", ":", CurrentUser.getSalesUser().getUserName()));
        apj.addBreak();

        apj.addCentre(String.format(PRINT_LAYOUT_01, "Cashier", ":", "Type  C"));
        apj.addCentre(String.format(PRINT_LAYOUT_01, "Supervisor", ":", "Type  S"));
        apj.addCentre(String.format(PRINT_LAYOUT_01, "Cashier Plus", ":", "Type CP"));

        apj.addBreak();

        apj.addBold(String.format("%-5s" + "%-26s" + "%5s", "Num", "Name", "Type"));
        for (User user : listUsers) {
            String userLvl = "";
            switch (user.getUserLevel()) {
                case 0:                 // Cashier
                    userLvl = "C";
                    break;
                case 1:                 // Supervisor
                    userLvl = "S";
                    break;
                case 2:                 // Cashier Plus
                    userLvl = "CP";
                    break;
                default:
                    JKiosk3.getMsgBox().showMsgBox("Error", "Invalid User Level found in data", null);
                    return null;
            }
            String showPin = user.getUserPin().substring(0, 2);
//            if (!showPin.equals("01")) {
            apj.addCentre(String.format("%-5s" + "%-26s" + "%5s", showPin, user.getUserName(), userLvl));
//            }
        }

        apj.addBreak();

        apj.addCentre("");
        apj.addCentreBold(PRINT_DONE);

        return apj;
    }

    public static AeonPrintJob getPrintElectricityTokenEncoded(String tokenNumber) {
        StringBuilder sb = new StringBuilder(tokenNumber);
        int idx = 0;

        while (idx < (sb.length() - 1)) {
            sb.insert(idx + 4, " ");
            idx = idx + 5;
        }
        System.out.println(sb.toString());

        String tokenFormatted = sb.toString();

        AeonPrintJob apj = new AeonPrintJob();

        apj.addLogo("0");
        apj.addBreak();
        apj.addCentreBold("Blu Approved");
        apj.addCentreBold("the Power of Prepaid");
        apj.addBreak();
        apj.addCentre(String.format(PRINT_LAYOUT_01, "Date", ":", JKText.getDateDisplaySec(new java.util.Date())));
        apj.addBreak();
        apj.addCentre("Encoded Token");
        apj.addBreak();
        apj.addCentreBold(tokenFormatted);
        apj.addBreak();
        apj.addCentreBold(PRINT_DONE);

        return apj;
    }
}
