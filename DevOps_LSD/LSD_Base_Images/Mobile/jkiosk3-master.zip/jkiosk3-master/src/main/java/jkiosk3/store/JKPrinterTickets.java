package jkiosk3.store;

/**
 *
 * @author valerie
 */
public class JKPrinterTickets {

    private static StoreJKPrinterTickets printerTickets;

    public static StoreJKPrinterTickets getPrinterTickets() {
        if (printerTickets == null) {
            printerTickets = ((StoreJKPrinterTickets) Store.loadObject(JKPrinterTickets.class.getSimpleName()));
        }
        if (printerTickets == null) {
            printerTickets = new StoreJKPrinterTickets();
        }
        return printerTickets;
    }

    public static boolean savePrinterTickets() {
        getPrinterTickets();
        return Store.saveObject(JKPrinterTickets.class.getSimpleName(), printerTickets);
    }
}
