package jkiosk3.sales.topups;

import java.util.ArrayList;
import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SalesItems;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales.topups.airtime.Airtime;
import jkiosk3.sales.topups.bundles.BundleProvidersDataOrSMS;
import jkiosk3.sales.topups.wallets.WalletProviders;

public class MenuTopups extends Region {

    public MenuTopups() {

        getChildren().add(getTopupTypes());
    }

    private VBox getTopupTypes() {

        VBox vbHead = JKNode.getPageHeadVB("Topup Menu");

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getMenuButtons());

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(vbHead, tile);

        return vb;
    }

    private List<Button> getMenuButtons() {

        List<Button> btnList = new ArrayList<>();

        List<SaleType> listSaleTypes = new ArrayList<>();
        listSaleTypes.add(SaleType.TOPUP_AIRTIME);
        listSaleTypes.add(SaleType.TOPUP_BUNDLE_DATA);
        listSaleTypes.add(SaleType.TOPUP_BUNDLE_SMS);
        if (!SalesItems.getListTopupProvidersOther().isEmpty()) {
            listSaleTypes.add(SaleType.TOPUP_WALLET);
        }

        for (final SaleType s : listSaleTypes) {
            final Button btn = JKNode.getBtnSmDbl(s.getDisplay());
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(s);
                }
            });
            btnList.add(btn);
        }

        return btnList;
    }

    private void getMenuAction(final SaleType topupType) {
        TopupSale.resetTopupSale();
        TopupSale.getInstance().setSaleType(topupType);

        switch (topupType) {
            case TOPUP_AIRTIME:
                SceneSales.clearAndChangeContent(new Airtime());
                break;
            case TOPUP_BUNDLE_DATA:
            case TOPUP_BUNDLE_SMS:
                SceneSales.clearAndChangeContent(new BundleProvidersDataOrSMS());
                break;
            case TOPUP_WALLET:
                SceneSales.clearAndChangeContent(new WalletProviders());
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Topup", "No Topup type selected", null);
                break;
        }
    }
}
