package jkiosk3.store;

import aeonprinting.AeonPrintJob;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author valeriew
 */
public class StoreJKReprintBillPay implements Serializable {
    
    private static final long serialVersionUID = 12002L;
    private int voucherReference;
    private Date date;
    private String type;
    private String description;
    private AeonPrintJob apj;

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            return sdf.format(date) + " - " + description;
    }

    public AeonPrintJob getApj() {
        return apj;
    }

    public void setApj(AeonPrintJob apj) {
        this.apj = apj;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getVoucherReference() {
        return voucherReference;
    }

    public void setVoucherReference(int voucherReference) {
        this.voucherReference = voucherReference;
    }
    
}
