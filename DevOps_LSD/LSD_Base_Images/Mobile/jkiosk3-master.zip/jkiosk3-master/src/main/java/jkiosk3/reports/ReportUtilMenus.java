package jkiosk3.reports;

import java.util.ArrayList;
import java.util.List;
import jkiosk3.JKiosk3;
import jkiosk3.sales.SalesMenu;
import jkiosk3.users.UserUtil;

/**
 *
 * @author Valerie
 */
public class ReportUtilMenus {

    public final static String REP_BTN_SHIFTS = "Shifts";
    public final static String REP_BTN_ACCS = "Accounts";
    public final static String REP_BTN_TRANS = "Transaction List";
    public final static String REP_BTN_REPRINT = "Reprints Offline";
    public final static String REP_BTN_REPRINT_ONLINE = "Reprints Online";
    public final static String REP_BTN_SHIFT_END = "End Shift";
    public final static String REP_BTN_SHIFT_VIEW = "View Shifts";
    public final static String REP_BTN_DAILY_BATCH = "Daily Batch Report";
    public final static String REP_BTN_USER_CASHUP = "User Cashup Report";
    public final static String REP_BTN_USER_CASHUP_CURRENT = "End Current Cashup";
    public final static String REP_BTN_USER_CASHUP_HISTORY = "Cashup History";
    public final static String REP_BTN_ACC_STAT = "Account Status";
    public final static String REP_BTN_ACC_PROF = "Profit Report";
    public final static String REP_BTN_ACC_STMNT = "Statements";
    public final static String REP_BTN_ACC_INV = "Invoices";
    public final static String REP_BTN_EMERG_TOP_TRANS = "Emergency Topup Transactions";
    public final static String REP_BTN_EMERG_TOP_REPRINT = "Reprint Emergency Topup";

    public static List<String> getUserMainReportMenu(String userPin) {
//        String userPermString = UserUtil.getPermissionString(userPin);
        List<String> userPermString = UserUtil.getUserPermissionsAsList(userPin);
        List<String> userAllowedMainMenu = new ArrayList<>();
        int userLevel = UserUtil.getUserLevel();
        switch (userLevel) {
            case 1:
                userAllowedMainMenu.add(REP_BTN_SHIFTS);
                userAllowedMainMenu.add(REP_BTN_ACCS);
                userAllowedMainMenu.add(REP_BTN_TRANS);
                userAllowedMainMenu.add(REP_BTN_REPRINT);
                userAllowedMainMenu.add(REP_BTN_REPRINT_ONLINE);
                if (SalesMenu.isEmergencyTopupAllowed()) {
                    userAllowedMainMenu.add(REP_BTN_EMERG_TOP_TRANS);
                    userAllowedMainMenu.add(REP_BTN_EMERG_TOP_REPRINT);
                }
                break;
            case 2:
//                if (userPermString != null) {
                if (!userPermString.isEmpty()) {
                    if (userPermString.contains("3")
                            || userPermString.contains("8")
                            || userPermString.contains("10")) {
                        userAllowedMainMenu.add(REP_BTN_SHIFTS);
                    }
                    if (userPermString.contains("4")
                            || userPermString.contains("6")
                            || userPermString.contains("7")
                            || userPermString.contains("5")) {
                        userAllowedMainMenu.add(REP_BTN_ACCS);
                    }
                    if (userPermString.contains("2")) {
                        userAllowedMainMenu.add(REP_BTN_TRANS);
                    }
                    if (userPermString.contains("1")) {
                        userAllowedMainMenu.add(REP_BTN_REPRINT);
                        userAllowedMainMenu.add(REP_BTN_REPRINT_ONLINE);
                    }
                    if (SalesMenu.isEmergencyTopupAllowed()) {
                        if (userPermString.contains("9")) {
                            userAllowedMainMenu.add(REP_BTN_EMERG_TOP_TRANS);
                            userAllowedMainMenu.add(REP_BTN_EMERG_TOP_REPRINT);
                        }
                    }
                }
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("User Permissions", "No User Permissions found for this User", null);
        }

        return userAllowedMainMenu;
    }

    public static List<String> getUserShiftReportMenu(String userPin) {
//        String userPermString = UserUtil.getPermissionString(userPin);
        List<String> userPermString = UserUtil.getUserPermissionsAsList(userPin);
        List<String> userAllowedShiftMenu = new ArrayList<>();
        int userLevel = UserUtil.getUserLevel();
        switch (userLevel) {
            case 1:
                userAllowedShiftMenu.add(REP_BTN_SHIFT_END);
                userAllowedShiftMenu.add(REP_BTN_SHIFT_VIEW);
                userAllowedShiftMenu.add(REP_BTN_DAILY_BATCH);
                userAllowedShiftMenu.add(REP_BTN_USER_CASHUP);
                break;
            case 2:
//                if (userPermString != null) {
                if (!userPermString.isEmpty()) {
                    if (userPermString.contains("3")) {
                        userAllowedShiftMenu.add(REP_BTN_SHIFT_END);
                    }
                    if (userPermString.contains("8")) {
                        userAllowedShiftMenu.add(REP_BTN_SHIFT_VIEW);
                    }
                    if (userPermString.contains("10")) {
                        userAllowedShiftMenu.add(REP_BTN_DAILY_BATCH);
                    }
                    /* This is not included in the "3" above to ensure that the 
                     Cashier Plus order of buttons corresponds with the Supervisor order. */
                    if (userPermString.contains("3")) {
                        userAllowedShiftMenu.add(REP_BTN_USER_CASHUP);
                    }
                }
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("User Permissions", "No User Permissions found for this User", null);
        }

        return userAllowedShiftMenu;
    }

    public static List<String> getUserAccountReportMenu(String userPin) {
//        String userPermString = UserUtil.getPermissionString(userPin);
        List<String> userPermString = UserUtil.getUserPermissionsAsList(userPin);
        List<String> userAllowedAccountMenu = new ArrayList<>();
        int userLevel = UserUtil.getUserLevel();
        switch (userLevel) {
            case 1:
                userAllowedAccountMenu.add(REP_BTN_ACC_STAT);
                userAllowedAccountMenu.add(REP_BTN_ACC_PROF);
                userAllowedAccountMenu.add(REP_BTN_ACC_STMNT);
                userAllowedAccountMenu.add(REP_BTN_ACC_INV);
                break;
            case 2:
//                if (userPermString != null) {
                if (!userPermString.isEmpty()) {
                    if (userPermString.contains("4")) {
                        userAllowedAccountMenu.add(REP_BTN_ACC_STAT);
                    }
                    if (userPermString.contains("6")) {
                        userAllowedAccountMenu.add(REP_BTN_ACC_PROF);
                    }
                    if (userPermString.contains("7")) {
                        userAllowedAccountMenu.add(REP_BTN_ACC_STMNT);
                    }
                    if (userPermString.contains("5")) {
                        userAllowedAccountMenu.add(REP_BTN_ACC_INV);
                    }
                }
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("User Permissions", "No User Permissions found for this User", null);
        }

        return userAllowedAccountMenu;
    }

    public static List<String> getUserCashupReportMenu(String userPin) {
        List<String> userAllowedCashupMenu = new ArrayList<>();
        int userLevel = UserUtil.getUserLevel();
        switch (userLevel) {
            case 1:
            case 2:
                userAllowedCashupMenu.add(REP_BTN_USER_CASHUP_CURRENT);
                userAllowedCashupMenu.add(REP_BTN_USER_CASHUP_HISTORY);
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("User Permissions", "No User Permissions found for this User", null);
        }

        return userAllowedCashupMenu;
    }
}
