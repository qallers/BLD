package jkiosk3.store;

/**
 *
 * @author Val
 */
public class JKSystem {

    private static StoreJKSystem systemConfig;

    public static StoreJKSystem getSystemConfig() {
        if (systemConfig == null) {
            systemConfig = ((StoreJKSystem) Store.loadObject(JKSystem.class.getSimpleName()));
        }
        if (systemConfig == null) {
            systemConfig = new StoreJKSystem();
        }
        return systemConfig;
    }

    public static boolean saveSystemConfig() {
        getSystemConfig();
        return Store.saveObject(JKSystem.class.getSimpleName(), systemConfig);
    }
}
