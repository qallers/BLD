package jkiosk3.printing;

import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Transparency;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import jkiosk3.JK3Config;
import jkiosk3.JKiosk3;
import jkiosk3.store.JKPrinter;
import jkiosk3.utilities.DownloadUtil;

/**
 * <p>
 * This class downloads an external image from a specified URL and then rotates and saves it in a specified format,
 * depending on what kind of printer (Windows or Serial) is being used.</p>
 *
 * <p>
 * Currently, the images are only those provided by TicketPro for logo printing on a till slip. This may change in the
 * future. If that happens, this class should be used for any further requirements for images.</p>
 *
 * @author Valerie
 */
public class ImageHandler {

    private final static Logger logger = Logger.getLogger(ImageHandler.class.getName());

    public ImageHandler() {
        //
    }

    /**
     * Gets the image file name that will be needed to retrieve an image for printing Coach Tickets.
     *
     * @param url the URL from which to download the image.
     * @return the file name of the image once it has been saved on the local machine.
     */
    public String getHeaderImagePathCoach(String url) {
        String imagePath = getImagePath(url, false);
        if (imagePath != null) {
            return imagePath;
        } else {
            logger.info("No Image Available");
            JKiosk3.getMsgBox().showMsgBox("Header Image", "No Image Available", null);
            return null;
        }
    }

    private String getImagePath(String url, boolean rotate) {
        File file = DownloadUtil.downloadRemoteFile(url, JK3Config.getImagesTemp());
        String imagePath = null;
        if (file != null) {
            try {
                BufferedImage imageWrite = null;
                BufferedImage image = ImageIO.read(file);
                if (rotate) {
                    imageWrite = rotateImage(image, -1.575);
                } else {
                    imageWrite = image;
                }
                File writeFile = new File(JK3Config.getImagesTemp() + file.getName());
                boolean isWriteGif = ImageIO.write(imageWrite, "gif", writeFile);
                if (JKPrinter.getPrinterConfig().isPrintWin()) {
                    if (isWriteGif) {
                        imagePath = writeFile.getName();
                    }
                }
            } catch (IOException | IndexOutOfBoundsException ex) {
                logger.log(Level.SEVERE, ex.getMessage(), ex);
            }
        }
        if (imagePath != null) {
            return imagePath;
        } else {
            logger.info("No Image Available");
            JKiosk3.getMsgBox().showMsgBox("Header Image", "No Image Available", null);
            return null;
        }
    }

    /**
     * Rotates a provided BufferedImage by the specified angle, and returns a new, rotated BufferedImage.
     *
     * @param srcimg the source BufferedImage to be rotated.
     * @param angle the angle by which the image should be rotated.
     * @return the BufferedImage created by the above operation.
     */
    private BufferedImage rotateImage(BufferedImage srcimg, double angle) {
        double sin = Math.abs(Math.sin(angle));
        double cos = Math.abs(Math.cos(angle));
        int w = srcimg.getWidth();
        int h = srcimg.getHeight();
        int neww = (int) Math.floor(w * cos + h * sin);
        int newh = (int) Math.floor(h * cos + w * sin);
        int type = BufferedImage.TYPE_INT_RGB;
        System.out.println("w = " + w + " : h = " + h);
        System.out.println("neww = " + neww + " : newh = " + newh);

        GraphicsConfiguration gc = getDefaultConfiguration();

        BufferedImage result = gc.createCompatibleImage(neww, newh, Transparency.TRANSLUCENT);
        Graphics2D g = result.createGraphics();
        g.translate((neww - w) / 2d, (newh - h) / 2d);
        g.rotate(angle, w / 2d, h / 2d);
        g.drawRenderedImage(srcimg, null);
        g.dispose();
        return result;
    }

    /**
     * Get the GraphicsConfiguration required to render a BufferedImage.
     *
     * @return the required GraphicsConfiguration.
     */
    private GraphicsConfiguration getDefaultConfiguration() {
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice[] gs = ge.getScreenDevices();
        GraphicsDevice gd = gs[0];
        GraphicsConfiguration gc = gd.getDefaultConfiguration();
        return gc;
    }
}
