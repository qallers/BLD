package jkiosk3.setup;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3.JKioskLogin;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.users.CurrentUser;

public class SceneSetup extends Region {

    private final static String MENU_CONFIG = "Config";
    private final static String MENU_PRINTERS = "Printer Setup";
    private final static String MENU_CASH_DRAWER = "Cash Drawer";
    private final static String MENU_CARD_READERS = "Card Readers";
    private final static String MENU_BRANDING = "Branding";
    private final static String MENU_PRINT_OPT = "Print Options";
    private final static String MENU_OPTIONS = "Options";
    public final static String MENU_SALES_OPT = "Sales Options";
    public final static String SETUP_BTN_STYLE = "-fx-padding: 0px 5px 0px 5px;";

    private static VBox vbSetupContent;
    static String userPin;

    public SceneSetup(String pin) {
        this.userPin = pin;
        getChildren().add(JKLayout.getSceneStack(getSetupLayout(), this));
    }

    private AnchorPane getSetupLayout() {
        VBox menu = getSetupMenu();
        vbSetupContent = JKLayout.getVBox(0, JKLayout.spNum);
        VBox grpInfo = JKLayout.getSceneInfoBox(265, null);
        VBox grpClose = getCloseGroup();

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);
        vb.getChildren().addAll(grpInfo, grpClose);

        AnchorPane ap = JKLayout.getSceneAnchor(menu, vbSetupContent, vb);

        ap.getChildren().addAll(menu, vbSetupContent, vb);

        return ap;
    }

    private VBox getSetupMenu() {
        List<String> btnLabelsAdmin = new ArrayList<>();
        btnLabelsAdmin.add(MENU_CONFIG);
        btnLabelsAdmin.add(MENU_PRINTERS);
        btnLabelsAdmin.add(MENU_CASH_DRAWER);
        btnLabelsAdmin.add(MENU_CARD_READERS);
        btnLabelsAdmin.add(MENU_BRANDING);

        List<Button> btnListAdmin = new ArrayList<>();

        for (String s : btnLabelsAdmin) {
            final Button btnAdmin = JKNode.getBtnSm(s);
            btnAdmin.setWrapText(true);
            btnAdmin.setStyle(SETUP_BTN_STYLE);
            btnAdmin.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuSelection(btnAdmin);
                }
            });
            btnListAdmin.add(btnAdmin);
        }

        List<String> btnLabelsUser = new ArrayList<>();
        btnLabelsUser.add(MENU_PRINT_OPT);
        btnLabelsUser.add(MENU_OPTIONS);
        btnLabelsUser.add(MENU_SALES_OPT);

        List<Button> btnList = new ArrayList<>();

        for (String s : btnLabelsUser) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setStyle(SETUP_BTN_STYLE);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuSelection(btn);
                }
            });
            btnList.add(btn);
        }

        List<Button> listBtnsDisplay = new ArrayList<>();

        if (userPin.equals("2596")) {
            listBtnsDisplay.addAll(btnListAdmin);
            listBtnsDisplay.addAll(btnList);
        } else {
            listBtnsDisplay.addAll(btnList);
        }

        return JKLayout.getSceneMenuBtnGroup("", listBtnsDisplay);
    }

    private static VBox getCloseGroup() {

        Button btn = JKNode.getBtnSm("Close Setup");
        btn.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                if (CurrentUser.getUser() != null) {
                    CurrentUser.setUser(null);
                    System.out.println("user set to null");
                }
                JKiosk3.changeScene(new JKioskLogin());
            }
        });

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().add(btn);

        return vb;
    }

    private void getMenuSelection(Button b) {
        switch (b.getText()) {
            case MENU_CONFIG:
//                clearAndChangeContent(new SetupConfig());
                clearAndChangeContent(new SetupConfigMenu());
                break;
            case MENU_PRINTERS:
                clearAndChangeContent(new SetupPrintersMenu());
                break;
            case MENU_CASH_DRAWER:
                clearAndChangeContent(new SetupCashDrawer());
                break;
            case MENU_CARD_READERS:
                clearAndChangeContent(new SetupCardReadersMenu());
                break;
            case MENU_BRANDING:
                clearAndChangeContent(new SetupBranding());
                break;
            case MENU_PRINT_OPT:
                clearAndChangeContent(new SetupPrintOptions());
                break;
            case MENU_OPTIONS:
                clearAndChangeContent(new SetupOptions());
                break;
            case MENU_SALES_OPT:
                System.out.println("need to have a valid USER before Cache can be used.");
                if (CurrentUser.getUser() != null) {
                    clearAndChangeContent(new SetupSalesOptMenu());
                } else {
                    clearAndChangeContent(new SetupSalesOptions());
                }
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Setup", "No Menu Item Selected", null);
        }
    }

    public static void clearAndChangeContent(Region newRegion) {
        vbSetupContent.getChildren().clear();
        vbSetupContent.getChildren().add(newRegion);
    }

    public static VBox getVbSetupContent() {
        return vbSetupContent;
    }
}
