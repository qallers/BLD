package jkiosk3.reports;

import aeonprinting.AeonPrintJob;
import aeonreports.TransListReq;
import aeonreports.TransListResp;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.StageComponents;
import jkiosk3.printing.PrintHandler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TransactByDate extends Region {

    private final static Logger logger = Logger.getLogger(TransactByDate.class.getName());
    private final static String FROM = "from";
    private final static String TO = "to";
    private TextField txtDateFrom;
    private TextField txtDateTo;
    private long dateInMillisFrom;
    private long dateInMillisTo;
    private long hoursMillisFrom;
    private long hoursMillisTo;
    private List<TimeItem> listHrsFrom;
    private List<TimeItem> listHrsTo;

    public TransactByDate() {
        listHrsFrom = getListHours(FROM);
        listHrsTo = getListHours(TO);

        VBox vb = JKLayout.getVBox(0, 5);

        vb.getChildren().add(getTransactByDateInput());
        vb.getChildren().add(getPrintControl());

        getChildren().addAll(vb);
    }

    private GridPane getTransactByDateInput() {
        double gridW = JKLayout.contentW - (5 * JKLayout.sp);
        VBox vbHead = JKNode.getReportHeadVB("Transaction List");

        Label lblNote = JKText.getLblDk("Please Note: ", JKText.FONT_B_24);

        Label lblInfo = JKText.getLblDk("If no Time is selected, all Transactions from Dates selected \nwill be shown", JKText.FONT_B_18);

        Label lblDateFrom = JKText.getLblDk("Date From :", JKText.FONT_B_XSM);
        Label lblTimeFrom = JKText.getLblDk("Time :", JKText.FONT_B_XSM);
        lblTimeFrom.setTranslateX((1 * JKLayout.sp));

        Label lblDateTo = JKText.getLblDk("Date To :", JKText.FONT_B_XSM);
        Label lblTimeTo = JKText.getLblDk("Time :", JKText.FONT_B_XSM);
        lblTimeTo.setTranslateX((1 * JKLayout.sp));

        txtDateFrom = new TextField();
        txtDateFrom.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                StageComponents.showStageCalendar(txtDateFrom);
            }
        });

        txtDateTo = new TextField();
        txtDateTo.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                StageComponents.showStageCalendar(txtDateTo);
            }
        });

        GridPane grid = JKLayout.getGridContent2Col(0.5, 0.5);
        GridPane gridinner = JKLayout.getGridPane4Col(gridW, 0.25, 0.30, 0.15, 0.30, 2, HPos.LEFT);
        gridinner.setVgap(2 * JKLayout.sp);

        grid.add(vbHead, 0, 0, 2, 1);
//        grid.add(lblNote, 0, 1, 2, 1);
//        grid.add(lblInfo, 0, 2, 2, 1);
        gridinner.addRow(0, lblDateFrom, txtDateFrom, lblTimeFrom, getHBIncreaseDecrease(FROM));
        gridinner.addRow(1, lblDateTo, txtDateTo, lblTimeTo, getHBIncreaseDecrease(TO));
//        grid.addRow(4, gridinner);
        grid.addRow(2, gridinner);
        // KEEP THIS in case we cannot get 'time' working in time!!!  pun...
//        grid.addRow(2, lblDateFrom, txtDateFrom);
//        grid.addRow(4, lblDateTo, txtDateTo);

        return grid;
    }

    private SceneReportControls getPrintControl() {
        return new SceneReportControls("View") {
            @Override
            public void onClickPrint() {
                if (isValidEntry()) {
                    showTransactionReport();
                }
            }
        };
    }

    private void showTransactionReport() {
        // if "time to" has not been changed, we need to manually calculate a full 24 hours less 1 second
        if (hoursMillisTo == 0) {
            hoursMillisTo = (1000L * 60L * 60L * 24L) - (1000L * 1L);
        }

        long millisTotalFrom = dateInMillisFrom + hoursMillisFrom;
        long millisTotalTo = dateInMillisTo + hoursMillisTo;
        TransListReq req = new TransListReq();
        req.setStartDate(millisTotalFrom);
        req.setEndDate(millisTotalTo);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        logger.info(("SELECTED DATE FROM = ").concat(sdf.format(new Date(millisTotalFrom))));
        logger.info(("SELECTED DATE TO   = ").concat(sdf.format(new Date(millisTotalTo))));

        try {
            ReportUtil.getTransactionListByDate(req, new ReportUtil.TransactListResult() {
                @Override
                public void transactListResult(TransListResp transListResp) {
                    if (transListResp.isSuccess()) {
                        AeonPrintJob apj = transListResp.getAeonPrintJob();
                        PrintHandler.handlePrintRequestReport(ReportUtil.REP_TRANS_LIST, apj);
                    } else {
                        JKiosk3.getMsgBox().showMsgBox("Transaction List",
                                transListResp.getErrorCode() + " - " + transListResp.getErrorText(), null);
                        SceneReports.clearAndChangeContent(new TransactByDate());
                    }
                }
            });
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        SceneReports.clearAndChangeContent(new TransactByDate());
    }

    private boolean isValidEntry() {
        if (txtDateFrom.getText().isEmpty() || txtDateTo.getText().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Select Dates", "Please select Dates for Transactions", null);
            return false;
        }

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            long todayInMillis = System.currentTimeMillis();

            dateInMillisFrom = sdf.parse(txtDateFrom.getText()).getTime();

            dateInMillisTo = sdf.parse(txtDateTo.getText()).getTime();

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH, -3);        // 'add' -3 months = 3 months ago

            if (dateInMillisFrom < cal.getTimeInMillis()) {
                JKiosk3.getMsgBox().showMsgBox("Invalid Date", "'Date From' cannot be older than 3 months", null);
                return false;
            }

            if (dateInMillisFrom > todayInMillis || dateInMillisTo > todayInMillis) {
                JKiosk3.getMsgBox().showMsgBox("Invalid Date", "Selected Date(s) cannot be after today", null);
                return false;
            }

            if (dateInMillisFrom > dateInMillisTo) {
                JKiosk3.getMsgBox().showMsgBox("Invalid Date", "'Date From' cannot be after 'Date To'", null);
                return false;
            }

        } catch (ParseException pe) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Date Format", "Please enter date in format 'dd/MM/yyyy'", null);
            return false;
        }

        return true;
    }

    private HBox getHBIncreaseDecrease(String fromOrTo) {
        HBox hBox = JKLayout.getHBox(0, JKLayout.spNum);
        String timeStr = "00:00";
        switch (fromOrTo) {
            case FROM:
                timeStr = "00:00";
                break;
            case TO:
                timeStr = "23:59";
                break;
            default:
                break;
        }

        TextField textField = new TextField(timeStr);
        textField.setAlignment(Pos.CENTER);
        textField.setMinWidth(50);
        textField.setEditable(false);

        hBox.getChildren().addAll(getStackDecInc(fromOrTo, JKNode.DECREASE, textField), textField, getStackDecInc(fromOrTo, JKNode.INCREASE, textField));

        return hBox;
    }

    private StackPane getStackDecInc(final String fromOrTo, final String decOrInc, final TextField textField) {
        StackPane stackDec = JKNode.createArrowStack(decOrInc, 0.0D);

        stackDec.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event event) {
                        TimeItem newTimeHrs = getUpdateHour(fromOrTo, decOrInc, textField);
                        textField.setText(newTimeHrs.getTimeText());
                        setMillisToAdd(fromOrTo, newTimeHrs);
            }
        });

        return stackDec;
    }

    private void setMillisToAdd(String fromOrTo, TimeItem timeItem) {
        switch (fromOrTo) {
            case FROM:
                hoursMillisFrom = timeItem.getTimeMillis();
                break;
            case TO:
                hoursMillisTo = timeItem.getTimeMillis();
                break;
            default:
                break;
        }
    }

    private TimeItem getUpdateHour(String fromOrTo, String incOrDec, TextField textField) {
        List<TimeItem> listHrs = new ArrayList<>();
        switch (fromOrTo) {
            case FROM:
                listHrs = listHrsFrom;
                break;
            case TO:
                listHrs = listHrsTo;
                break;
            default:
                break;
        }

        TimeItem updateHrs = null;
        for (TimeItem ti : listHrs) {
            if (textField.getText().equalsIgnoreCase(ti.getTimeText())) {
                int indexHrs = listHrs.indexOf(ti);
                switch (incOrDec) {
                    case JKNode.INCREASE:
                        if (indexHrs != (listHrs.size() - 1)) {
                            updateHrs = listHrs.get(indexHrs + 1);
                        } else {
                            updateHrs = listHrs.get(indexHrs);
                        }
                        break;
                    case JKNode.DECREASE:
                        if (indexHrs != 0) {
                            updateHrs = listHrs.get(indexHrs - 1);
                        } else {
                            updateHrs = listHrs.get(indexHrs);
                        }
                        break;
                    default:
                        break;
                }
                break;
            }
        }
        return updateHrs;
    }

    private List<TimeItem> getListHours(String fromOrTo) {
        List<TimeItem> listTimeHrs = new ArrayList<>();

        String min = ":00";
        switch (fromOrTo) {
            case FROM:
                min = ":00";
                break;
            case TO:
                min = ":59";
                break;
            default:
                break;
        }

        String[] strs = {"00" + min, "01" + min, "02" + min, "03" + min, "04" + min, "05" + min,
                "06" + min, "07" + min, "08" + min, "09" + min, "10" + min, "11" + min,
                "12" + min, "13" + min, "14" + min, "15" + min, "16" + min, "17" + min,
                "18" + min, "19" + min, "20" + min, "21" + min, "22" + min, "23" + min};
        List<String> listkeys = Arrays.asList(strs);

        List<Long> listvalues = new ArrayList<>();
        switch (fromOrTo) {
            case FROM:
                for (int i = 0; i < (listkeys.size() * 60); i += 60) {
                    Long value = 1000L * 60L * i;
                    listvalues.add(value);
                }
                for (int j = 0; j < listkeys.size(); j++) {
                    TimeItem timeItem = new TimeItem(listkeys.get(j), listvalues.get(j));
                    listTimeHrs.add(timeItem);
                }
                break;
            case TO:
                for (int i = 0; i < (listkeys.size() * 60); i += 60) {
                    Long value = (1000L * 60L * i) + ((1000L * 60L * 60L * 1) - (1000L * 1L));
                    listvalues.add(value);
                }
                for (int j = 0; j < listkeys.size(); j++) {
                    TimeItem timeItem = new TimeItem(listkeys.get(j), listvalues.get(j));
                    listTimeHrs.add(timeItem);
                }
                break;
            default:
                break;
        }

        return listTimeHrs;
    }

    private class TimeItem {

        private String timeText;
        private Long timeMillis;

        public TimeItem(String timeText, Long timeMillis) {
            this.timeText = timeText;
            this.timeMillis = timeMillis;
        }

        @Override
        public String toString() {
            return timeText;
        }

        public String getTimeText() {
            return timeText;
        }

        public Long getTimeMillis() {
            return timeMillis;
        }
    }
}

//    private StackPane getStackIncrease(final String fromOrTo, final TextField textField, final String hrsOrMin) {
//        StackPane stackInc = createArrowStack("inc", 0.0D);
//
//        stackInc.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event event) {
//                switch (hrsOrMin) {
//                    case "hrs":
//                        TimeItem newTimeHrs = getUpdateHour(fromOrTo, textField, "inc");
//                        textField.setText(newTimeHrs.getTimeText());
//                        setMillisToAdd(hrsOrMin, fromOrTo, newTimeHrs);
//                        break;
////                    case "min":
////                        TimeItem newTimeMin = getUpdateMins(textField, "inc");
////                        textField.setText(newTimeMin.getTimeText());
////                        setMillisToAdd(hrsOrMin, fromOrTo, newTimeMin);
////                        break;
//                    default:
//                        textField.setText("00:00");
//                }
//            }
//        });
//
//        return stackInc;
//    }

//    private StackPane getStackDecrease(final String fromOrTo, final TextField textField, final String hrsOrMin) {
//        StackPane stackDec = createArrowStack("dec", 0.0D);
//
//        stackDec.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event event) {
//                switch (hrsOrMin) {
//                    case "hrs":
//                        TimeItem newTimeHrs = getUpdateHour(fromOrTo, textField, "dec");
//                        textField.setText(newTimeHrs.getTimeText());
//                        setMillisToAdd(hrsOrMin, fromOrTo, newTimeHrs);
//                        break;
////                    case "min":
////                        TimeItem newTimeMin = getUpdateMins(textField, "dec");
////                        textField.setText(newTimeMin.getTimeText());
////                        setMillisToAdd(hrsOrMin, fromOrTo, newTimeMin);
////                        break;
//                    default:
//                        textField.setText("00:00");
//                }
//            }
//        });
//
//        return stackDec;
//    }

//    private StackPane getStackDecrease(final String fromOrTo, final TextField textField, final String hrsOrMin) {
////        StackPane stackDec = createArrowStack("dec", 90.0D);
//        StackPane stackDec = createArrowStack("dec", 0.0D);
////        StackPane stackPane = new StackPane();
////        stackPane.setMaxSize(35, 35);
////        stackPane.setMinSize(35, 35);
////        stackPane.setStyle("-fx-background-color: #a7a7a7;");
//
//        stackDec.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event event) {
//                switch (hrsOrMin) {
//                    case "hrs":
//                        TimeItem newTimeHrs = getUpdateHour(textField, "dec");
//                        textField.setText(newTimeHrs.getTimeText());
//                        setMillisToAdd(hrsOrMin, fromOrTo, newTimeHrs);
//                        break;
////                    case "min":
////                        TimeItem newTimeMin = getUpdateMins(textField, "dec");
////                        textField.setText(newTimeMin.getTimeText());
////                        setMillisToAdd(hrsOrMin, fromOrTo, newTimeMin);
////                        break;
//                    default:
//                        textField.setText("00:00");
//                }
//            }
//        });
//
////        Label lblInc = JKText.getLblDk("-", JKText.FONT_LUCIDA_UNI_LG);
////        stackPane.getChildren().add(lblInc);
//
////        return stackPane;
//        return stackDec;
//    }

//    private StackPane getStackIncrease(final String fromOrTo, final TextField textField, final String hrsOrMin) {
////        StackPane stackInc = createArrowStack("inc", 90.0D);
//        StackPane stackInc = createArrowStack("inc", 0.0D);
////        StackPane stackPane = new StackPane();
////        stackPane.setMaxSize(35, 35);
////        stackPane.setMinSize(35, 35);
////        stackPane.setStyle("-fx-background-color: #a7a7a7;");
//
//        stackInc.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event event) {
//                switch (hrsOrMin) {
//                    case "hrs":
//                        TimeItem newTimeHrs = getUpdateHour(textField, "inc");
//                        textField.setText(newTimeHrs.getTimeText());
//                        setMillisToAdd(hrsOrMin, fromOrTo, newTimeHrs);
//                        break;
////                    case "min":
////                        TimeItem newTimeMin = getUpdateMins(textField, "inc");
////                        textField.setText(newTimeMin.getTimeText());
////                        setMillisToAdd(hrsOrMin, fromOrTo, newTimeMin);
////                        break;
//                    default:
//                        textField.setText("00:00");
//                }
//            }
//        });
//
////        Label lblInc = JKText.getLblDk("+", JKText.FONT_LUCIDA_UNI_LG);
////        stackPane.getChildren().add(lblInc);
////
////        return stackPane;
//        return stackInc;
//    }


//    private TimeItem getUpdateMins(TextField textField, String incOrDec) {
//        final List<TimeItem> listMins = getListMins();
//
//        TimeItem updateMin = null;
//        for (TimeItem ti : listMins) {
//            if (textField.getText().equalsIgnoreCase(ti.getTimeText())) {
//                int indexMin = listMins.indexOf(ti);
//                System.out.println("current index mins = " + indexMin);
//                switch (incOrDec) {
//                    case "inc":
//                        if (indexMin != (listMins.size() - 1)) {
//                            updateMin = listMins.get(indexMin + 1);
//                        } else {
//                            updateMin = listMins.get(indexMin);
//                        }
//                        break;
//                    case "dec":
//                        if (indexMin != 0) {
//                            updateMin = listMins.get(indexMin - 1);
//                        } else {
//                            updateMin = listMins.get(indexMin);
//                        }
//                        break;
//                    default:
//                        break;
//                }
//                System.out.println("updated mins = " + updateMin.getTimeText());
//                break;
//            }
//        }
//        return updateMin;
//    }


//    private VBox getVBIncreaseDecrease(String fromOrTo, String hrsOrMin) {
//        VBox vBox = new VBox(5);
//        vBox.setAlignment(Pos.TOP_CENTER);
//        vBox.setMaxWidth(55);
//        vBox.setMinWidth(55);
//
//        TextField textField = new TextField("00");
//        textField.setAlignment(Pos.CENTER);
//        textField.setMinWidth(50);
//        textField.setEditable(false);
//
//        vBox.getChildren().addAll(getStackIncrease(fromOrTo, textField, hrsOrMin), textField, getStackDecrease(fromOrTo, textField, hrsOrMin));
//
//        return vBox;
//    }

//    private HBox getHBTime(String fromOrTo) {
//        Label lbltime = JKText.getLblDk(" : ", JKText.FONT_B_SM);
//        VBox timeHrs = getVBIncreaseDecrease(fromOrTo, "hrs");
//        VBox timeMin = getVBIncreaseDecrease(fromOrTo, "min");
//
//        HBox hbtime = JKLayout.getHBox(0, JKLayout.spNum);
//        hbtime.getChildren().addAll(timeHrs, lbltime, timeMin);
//
//        return hbtime;
//    }

//    private List<TimeItem> getListMins() {
//        List<TimeItem> listTimeMin = new ArrayList<>();
//
//        String[] strs = {"00", "15", "30", "45"};
//        List<String> listkeys = Arrays.asList(strs);
//
//        List<Long> listvalues = new ArrayList<>();
//        for (int i = 0; i < (listkeys.size() * 15); i += 15) {
//            Long value = 1000L * 60L * i;
//            listvalues.add(value);
//        }
//        for (int j = 0; j < listkeys.size(); j++) {
//            TimeItem timeItem = new TimeItem(listkeys.get(j), listvalues.get(j));
//            listTimeMin.add(timeItem);
//        }
//
//        return listTimeMin;
//    }

//        ObservableList<TimeItem> listTimesTo = FXCollections.observableArrayList(getListTimeItems());
//        ComboBox comTimeTo = new ComboBox(listTimesTo);
//        comTimeTo.setMinWidth(gridW * 0.25);
////        comTimeTo.getItems().addAll(listTimesTo);
//        comTimeTo.setVisibleRowCount(12);
//        comTimeTo.getSelectionModel().selectFirst();
//        comTimeTo.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
//            @Override
//            public void changed(ObservableValue observableValue, Object o, Object t1) {
//                if (t1 != null) {
//                    TimeItem ti = (TimeItem) t1;
//                    System.out.println("key : " + ti.getTimeText() + "  -  value : " + ti.getTimeMillis());
//                }
//            }
//        });

//        ObservableList<TimeItem> listTimesFrom = FXCollections.observableArrayList(getListTimeItems());
//        ComboBox comTimeFrom = new ComboBox(listTimesFrom);
//        comTimeFrom.setMinWidth(gridW * 0.25);
////        comTimeFrom.getItems().addAll(listTimesFrom);
//        comTimeFrom.setVisibleRowCount(12);
//        comTimeFrom.getSelectionModel().selectFirst();
//        comTimeFrom.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
//            @Override
//            public void changed(ObservableValue observableValue, Object o, Object t1) {
//                if (t1 != null) {
//                    TimeItem ti = (TimeItem) t1;
//                    System.out.println("key : " + ti.getTimeText() + "  -  value : " + ti.getTimeMillis());
//                }
//            }
//        });

//    private Map<String, Long> getTimeList() {
//        String[] strs = {"00:00", "01:00", "02:00", "03:00", "04:00", "05:00", "06:00", "07:00", "08:00", "09:00", "10:00", "11:00", "12:00",
//                "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00", "23:00", "24:00"};
//        List<String> listkeys = Arrays.asList(strs);
//
//        List<Long> listvalues = new ArrayList<>();
//        for (int i = 0; i < ((listkeys.size()) * 60); i += 60) {
//            Long value = 1000L * 60L * i;
//            listvalues.add(value);
//        }
//        Map<String, Long> maptime = new LinkedHashMap<>();
//        for (int j = 0; j < listkeys.size(); j++) {
//            maptime.put(listkeys.get(j), listvalues.get(j));
//        }
//        for (String ss : maptime.keySet()) {
//            System.out.println("key : " + ss + "  - value : " + maptime.get(ss));
//        }
//        return maptime;
//    }