package jkiosk3.sales._favourites.nfc;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.SalesUtil;
import jkiosk3.users.SalesUserLoginResult;
import jkiosk3.users.UserUtil;

import java.util.ArrayList;
import java.util.List;

public class NFCMenu extends Region {

    private Pane panePageContent;
    private List<Button> btnList;

    public NFCMenu() {

        UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);

        panePageContent = new Pane();

        getChildren().add(getNFCOptions());
    }

    private VBox getNFCOptions() {

        VBox nfcHead = JKNode.getNFCpgHead("NFC Menu");

        TilePane tile = JKLayout.getTiledBtns(0, JKLayout.sp, JKLayout.sp, 2, getMenuButtons());

        panePageContent.getChildren().add(new NFCExisting());

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.getChildren().addAll(nfcHead, tile, panePageContent);

        return vb;
    }

    private List<Button> getMenuButtons() {
        btnList = new ArrayList<>();

        String[] btnLbls = {NFCUtil.NFC_EXISTING, NFCUtil.NFC_NEW};

        for (String s : btnLbls) {
            final Button btn = JKNode.getBtnSmDbl(s);
            btn.getStyleClass().add("btnNFC");
            btn.setId(s);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event evt) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
            if (btn.getId().equals(NFCUtil.NFC_EXISTING)) {
                resetButtonStyle(btn);
            }
        }

        return btnList;
    }

    private void resetButtonStyle(Button btn) {
        for (Button b : btnList) {
            b.getStyleClass().removeAll("btnNFC", "btnNFCactive");
            if (b.getId().equals(btn.getId())) {
                b.getStyleClass().add("btnNFCactive");
            } else {
                b.getStyleClass().add("btnNFC");
            }
        }
    }

    private void getMenuAction(Button b) {
        UserUtil.resetSalesUser(SalesUtil.SRC_BTN_CANCEL);

        resetButtonStyle(b);

        switch (b.getId()) {
            case NFCUtil.NFC_EXISTING:
                panePageContent.getChildren().clear();
                panePageContent.getChildren().add(new NFCExisting());
                break;
            case NFCUtil.NFC_NEW:
                JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
                    @Override
                    public void onDone() {
                        panePageContent.getChildren().clear();
                        panePageContent.getChildren().add(new NFCNewRegistration());
                    }
                });
                break;
            default:
                NFCUtil.resetNFCView();
        }
    }
}
