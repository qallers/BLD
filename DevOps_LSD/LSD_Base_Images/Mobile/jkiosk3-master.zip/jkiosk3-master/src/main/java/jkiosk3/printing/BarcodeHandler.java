package jkiosk3.printing;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.oned.Code128Writer;
import com.google.zxing.oned.Code39Writer;
import com.google.zxing.oned.EAN13Writer;
import com.google.zxing.oned.ITFWriter;
import com.google.zxing.pdf417.PDF417Writer;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

import jkiosk3.JK3Config;
import jkiosk3._common.JKMedia;

/**
 * <p>
 * This class generates a barcode image from a given input String, and saves it in a specified format (currently
 * using .PDF format, but could be changed depending on requirements and printer support).</p>
 * <p>
 * <p>
 * Currently, not all barcode types are defined, but this class should be added to for any further requirements for
 * barcodes.</p>
 *
 */
public class BarcodeHandler {

    private final static Logger logger = Logger.getLogger(BarcodeHandler.class.getName());
    public static final String BARCODE_128A = "128A";
    public static final String BARCODE_128B = "128B";
    public static final String BARCODE_128C = "128C";
    public static final String BARCODE_CODE39 = "Code39";
    public static final String BARCODE_EAN13 = "EAN13";
    public static final String BARCODE_ITF = "ITF";
    public static final String BARCODE_PDF417 = "PDF417";
    private static final int BC_HT = 15;
    private final Map bcHintMap;
    private final String bcFiletype;

    public BarcodeHandler() {
        JKMedia.createMediaFolder(JK3Config.getBarcodes());
        listFilesAndCheckFolder();
        this.bcHintMap = new HashMap();
        bcHintMap.put(EncodeHintType.MARGIN, 5);
        this.bcFiletype = "png";
    }

    public String createBarcode(String data, String barcodeFormat) {
        String filename = System.currentTimeMillis() + "-" + barcodeFormat + "." + bcFiletype;
        BitMatrix bitMatrix = null;
        try {
            switch (barcodeFormat) {
                case BARCODE_128A:
                case BARCODE_128B:
                case BARCODE_128C:
                    Code128Writer code128 = new Code128Writer();
                    bitMatrix = code128.encode(new String(data.getBytes("UTF-8")), BarcodeFormat.CODE_128, 0, BC_HT, bcHintMap);
                    break;
                case BARCODE_CODE39:
                    Code39Writer code39 = new Code39Writer();
                    bitMatrix = code39.encode(new String(data.getBytes("UTF-8")), BarcodeFormat.CODE_39, 0, BC_HT, bcHintMap);
                    break;
                case BARCODE_EAN13:
                    EAN13Writer codeEan13 = new EAN13Writer();
                    bitMatrix = codeEan13.encode(new String(data.getBytes("UTF-8")), BarcodeFormat.EAN_13, 0, BC_HT, bcHintMap);
                    break;
                case BARCODE_ITF:
                    ITFWriter codeITF = new ITFWriter();
                    bitMatrix = codeITF.encode(new String(data.getBytes("UTF-8")), BarcodeFormat.ITF, 0, BC_HT, bcHintMap);
                    break;
                case BARCODE_PDF417:
                    bcHintMap.put(EncodeHintType.MARGIN, 10);
                    PDF417Writer pdf417 = new PDF417Writer();
                    bitMatrix = pdf417.encode(new String(data.getBytes("UTF-8")), BarcodeFormat.PDF_417, 150, BC_HT, bcHintMap);
                    break;
                default:
                    break;
            }

            if (createBarcodeFile(bitMatrix, filename)) {
                return filename;
            } else {
                return null;
            }

        } catch (IllegalArgumentException | UnsupportedEncodingException | WriterException e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
            return null;
        }
    }

    /**
     * Creates the graphics and saves the BitMatrix data as an image, ready to be used where required.
     *
     * @param bits     the BitMatrix image data to be saved as a graphical representation of the barcode.
     * @param filename the filename to be used for the saved image.
     * @return - true if the file is successfully created, false if not.
     */
    private boolean createBarcodeFile(BitMatrix bits, String filename) {
        try {
            int imgwidth = bits.getWidth();
            int imgheight = bits.getHeight();
            BufferedImage image = new BufferedImage(imgwidth, imgheight, BufferedImage.TYPE_INT_RGB);
            image.createGraphics();
            Graphics2D graphics = (Graphics2D) image.getGraphics();
            graphics.setColor(Color.WHITE);
            graphics.fillRect(0, 0, imgwidth, imgheight);
            graphics.setColor(Color.BLACK);
            for (int i = 0; i < imgwidth; i++) {
                for (int j = 0; j < imgheight; j++) {
                    if (bits.get(i, j)) {
                        graphics.fillRect(i, j, 1, 1);
                    }
                }
            }
            return ImageIO.write(image, bcFiletype, new File(JK3Config.getBarcodes() + filename));
        } catch (IOException ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
            return false;
        }
    }

    private static void listFilesAndCheckFolder() {
        String filePath = JK3Config.getBarcodes();
        File folder = new File(filePath);
        List<File> listFiles = Arrays.asList(folder.listFiles());

        JKMedia.checkFolderSize(listFiles, filePath, 15);
    }

    public String processBarcode128B(String barcode) {
        // Received as follows from Carma
        // example : "43,85,79,100,90,82,74,58,75,92,76,63,125,47,39,47"
        // pre-processed 128B  = 43,85,79,100,90,82,74,58,75,92,76,63,125,47,39,47
        // post-processed 128B = +UOdZRJ:K\L?}/'/
        String[] tmp = barcode.split(",");
        StringBuilder ret = new StringBuilder();

        if (tmp.length == 16) {
            for (String value : tmp) {
                ret.append((char) Integer.parseInt(value));
            }

            return ret.toString();
        } else {
            return null;
        }
    }

    public String processBarcode128cPDF417(String barcode) {
        // Received as follows from TicketPro
        // example : "30303038343730363134393939393930303232353632"
        // pre-processed 128C  = 30303038343730363134393939393930303232353632
        // post-processed 128C = 0008470614999990022562
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < barcode.length(); i += 2) {
            String str = barcode.substring(i, i + 2);
            output.append((char) Integer.parseInt(str, 16));
        }
        return output.toString();
    }

    public StringBuilder processBarcodeTextToPrint(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c > 127 || c == '<' || c == '>' || c == '&') {
                sb.append("&#");
                sb.append((int) c);
                sb.append(";");
            } else {
                sb.append(c);
            }
        }
        return sb;
    }
}
