package jkiosk3.printing;

import java.util.logging.Level;
import java.util.logging.Logger;
import jkiosk3.store.JKPrinter;
import org.json.JSONObject;

/**
 *
 * @author Val
 */
public class PrintDevice {

    private final static Logger logger = Logger.getLogger(PrintDevice.class.getName());
    private final String description;

    public PrintDevice(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public JSONObject printerDetails() {
        JSONObject res = new JSONObject();
        try {
            res.put("Id", 0);
            res.put("Description", getDescription());
            res.put("DevPort", JKPrinter.getPrinterConfig().getPrintPort());
            res.put("Driver", JKPrinter.getPrinterConfig().getPrintDriver());
            res.put("FlowControl", JKPrinter.getPrinterConfig().isPrintFlowControl() ? 1 : 0);
            res.put("Baud", JKPrinter.getPrinterConfig().getPrintBaud());
        } catch (Exception e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }
        return res;
    }
}
