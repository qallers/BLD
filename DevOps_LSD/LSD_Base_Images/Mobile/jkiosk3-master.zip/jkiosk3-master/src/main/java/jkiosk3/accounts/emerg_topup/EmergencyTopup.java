package jkiosk3.accounts.emerg_topup;

import aeonemergencytopup.Account;
import aeonemergencytopup.LoanApplicationReq;
import aeonemergencytopup.LoanApplicationResp;
import aeonemergencytopup.LoanConfirmReq;
import aeonemergencytopup.LoanConfirmResp;
import aeonusers.User;

/**
 *
 * @author Valerie
 */
public class EmergencyTopup {

    private Account account;
    private User user;
    private LoanApplicationReq loanReq;
    private LoanApplicationResp loanResp;
    private LoanConfirmReq confReq;
    private LoanConfirmResp confResp;
    //
    private static volatile EmergencyTopup instance;

    private static EmergencyTopup newInstance() {
        instance = new EmergencyTopup();
        return instance;
    }

    public static EmergencyTopup getInstance() {
        if (instance == null) {
            instance = newInstance();
        }
        return instance;
    }

    public static void resetEmergencyTopup() {
        instance = null;
    }

    // getters and setters
    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public LoanApplicationReq getLoanReq() {
        return loanReq;
    }

    public void setLoanReq(LoanApplicationReq loanReq) {
        this.loanReq = loanReq;
    }

    public LoanApplicationResp getLoanResp() {
        return loanResp;
    }

    public void setLoanResp(LoanApplicationResp loanResp) {
        this.loanResp = loanResp;
    }

    public LoanConfirmReq getConfReq() {
        return confReq;
    }

    public void setConfReq(LoanConfirmReq confReq) {
        this.confReq = confReq;
    }

    public LoanConfirmResp getConfResp() {
        return confResp;
    }

    public void setConfResp(LoanConfirmResp confResp) {
        this.confResp = confResp;
    }
}
