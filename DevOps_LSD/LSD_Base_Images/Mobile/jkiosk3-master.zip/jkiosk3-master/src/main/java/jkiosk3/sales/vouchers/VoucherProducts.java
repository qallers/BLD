package jkiosk3.sales.vouchers;

import aeonairtime.AirtimeManufacturer;
import aeonairtime.AirtimeProduct;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Pagination;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3.sales.SaleType;
import jkiosk3.sales.SceneSales;
import jkiosk3.users.SalesUserLoginResult;

public class VoucherProducts extends Region {

    private final static Logger logger = Logger.getLogger(VoucherProducts.class.getName());
    private AirtimeManufacturer prov = null;
    private SaleType voucherType = null;
    private AnchorPane anchor;
    private List<Button> listProductButtons;
    private final static int pageSize = 12;

    public VoucherProducts() {
        if (VoucherSale.getInstance().getProvider() != null && VoucherSale.getInstance().getSaleType() != null) {
            this.prov = VoucherSale.getInstance().getProvider();
            this.voucherType = VoucherSale.getInstance().getSaleType();
        } else {
            JKiosk3.getMsgBox().showMsgBox("Voucher Products", "Voucher Type or Voucher Provider has not been selected", null);
            SceneSales.clearAndChangeContent(new MenuVouchers());
        }

        getChildren().add(getProductsGroup());
    }

    private VBox getProductsGroup() {
        Button btnBack = JKNode.getBtnPopup("back");
        btnBack.setOnMouseReleased(new EventHandler<Event>() {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent(new Vouchers());
            }
        });

        Button btnProvider = JKNode.getAirtimeProviderButton(prov.getId(), null);

        VBox vbHead = JKNode.getPageDblHeadVB(JKLayout.sp, btnBack, btnProvider);

        anchor = new AnchorPane();

        getProductItems();

        VBox vb = JKLayout.getVBoxContent(0);
        vb.setStyle("-fx-padding: 0px 0px 15px 0px;");
        vb.getChildren().addAll(vbHead, anchor);

        return vb;
    }

    private void getProductItems() {
        listProductButtons = getProductButtons();
        createPagedProducts();
    }

    private List<Button> getProductButtons() {
        List<Button> btnList = new ArrayList<>();
        List<AirtimeProduct> products = VoucherUtil.getProviderProducts(voucherType.name(), prov.getId());

        for (final AirtimeProduct p : products) {
            final Button btn = JKNode.getBtnSmDbl(p.getName());
            if (prov.getId().equalsIgnoreCase("TelkomMobile") && voucherType.equals(SaleType.VOUCHER_DATA)) {
                btn.getStyleClass().add("prov_" + prov.getId() + "Data");
            } else {
                btn.getStyleClass().add("prov_" + prov.getId());
            }
            btn.setWrapText(true);
            btn.setOnMouseReleased(new EventHandler<Event>() {
                @Override
                public void handle(Event e) {
                    VoucherSale.getInstance().setProduct(p);
                    onSelectProductButton();
                }
            });
            btnList.add(btn);
        }

        return btnList;
    }

    private void createPagedProducts() {
        int numPgs = 0;
        if (listProductButtons.isEmpty()) {
            numPgs = 1;
        } else if ((listProductButtons.size() % pageSize) == 0) {
            numPgs = listProductButtons.size() / pageSize;
        } else {
            numPgs = (listProductButtons.size() / pageSize) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                return JKNode.createPagedTile(pg, 475, 2, pageSize, listProductButtons);
            }
        });
        anchor.getChildren().add(pages);
    }

    private void onSelectProductButton() {
        JKiosk3.getSalesUserLogin().showUserLogin(new SalesUserLoginResult() {
            @Override
            public void onDone() {
                SceneSales.clearAndChangeContent(new VoucherQuantity(false));
            }
        });
    }
}
