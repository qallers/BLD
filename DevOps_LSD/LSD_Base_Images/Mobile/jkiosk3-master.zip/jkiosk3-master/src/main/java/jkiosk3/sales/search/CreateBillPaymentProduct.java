package jkiosk3.sales.search;

import jkiosk3.sales.billpay.BillPayProduct;
import jkiosk3.sales.billpay.BillPayUtilConnect;

import java.util.ArrayList;
import java.util.List;

public class CreateBillPaymentProduct {

    private static SearchProduct billPayProductToSearchProduct(BillPayProduct product) {
        SearchProduct searchProduct = new SearchProduct();
        searchProduct.setProvId(product.getProvId());
        searchProduct.setProvName(product.getProvName());
        searchProduct.setProdId(product.getProdId());
        searchProduct.setProdName(product.getProdName());
        searchProduct.setBpTransType(product.getBpTransType());
        searchProduct.setVerify(product.isVerify());
        searchProduct.setFullAmount(product.isFullAmount());
        searchProduct.setAdditionalFields(product.getAdditionalFields());
        searchProduct.setProdMaxAmount(product.getProdMaxAmount());
        searchProduct.setProdMinAmount(product.getProdMinAmount());
        searchProduct.setEnforceFullPayment(product.isEnforceFullPayment());
        searchProduct.setTendersAllowed(product.getTendersAllowed());
        searchProduct.setReversalSupported(product.isReversalSupported());
        searchProduct.setSearchTransType(SearchTransType.BILL_PAYMENT);
        searchProduct.setLogoId(product.getLogoId());
        return searchProduct;
    }

    public static List<SearchProduct> createBillPayProducts() {
        List<SearchProduct> products = new ArrayList<>();
        for (BillPayProduct billPayProduct : BillPayUtilConnect.getBillPayList()) {
            products.add(billPayProductToSearchProduct(billPayProduct));
        }
        return products;
    }

    public static List<SearchProduct> createInsurePayProducts() {
        List<SearchProduct> products = new ArrayList<>();
        for (BillPayProduct billPayProduct : BillPayUtilConnect.getInsurePayList()) {
            products.add(billPayProductToSearchProduct(billPayProduct));
        }
        return products;
    }

    public static List<SearchProduct> createTrafficFineProducts() {
        List<SearchProduct> products = new ArrayList<>();
        for (BillPayProduct billPayProduct : BillPayUtilConnect.getTrafFineList()) {
            products.add(billPayProductToSearchProduct(billPayProduct));
        }
        return products;
    }

}
