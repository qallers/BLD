package jkiosk3.reports;

import aeonreports.ReprintList;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3._components.StageComponents;
//import jkiosk3._components.StageComponents;

/**
 *
 * @author valeriew
 */
public class ReprintsOnlineSelect extends Region {

    private final static Logger logger = Logger.getLogger(ReprintsOnlineSelect.class.getName());
    private TextField txtDateFrom;
    private TextField txtDateTo;
    private long dateInMillisFrom;
    private long dateInMillisTo;

    public ReprintsOnlineSelect() {
        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().add(getReprintsSelect());
        vb.getChildren().add(getPrintControl());

        getChildren().addAll(vb);
    }

    private GridPane getReprintsSelect() {

        VBox vbHead = JKNode.getReportHeadVB("Reprints Online");

        Label lblDateFrom = JKText.getLblDk("Date From :", JKText.FONT_B_XSM);

        Label lblDateTo = JKText.getLblDk("Date To :", JKText.FONT_B_XSM);

        txtDateFrom = new TextField();
        txtDateFrom.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                StageComponents.showStageCalendar(txtDateFrom);
//                JKiosk3.getCalendarPickerX().showCalendarPickerX(txtDateFrom);
            }
        });

        txtDateTo = new TextField();
        txtDateTo.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                StageComponents.showStageCalendar(txtDateTo);
//                JKiosk3.getCalendarPickerX().showCalendarPickerX(txtDateTo);
            }
        });

        GridPane grid = JKLayout.getGridContent2Col(0.5, 0.5);

        grid.add(vbHead, 0, 0, 2, 1);
        grid.addRow(2, lblDateFrom, txtDateFrom);
        grid.addRow(4, lblDateTo, txtDateTo);

        return grid;
    }

    /* This unused method allows for selection of both Date and Time. */
    /* Maybe keep it here, commented out, in case Time is required in the future...? */
    /* ----------------------------------------------------------------------------- */
//    private GridPane getReprintsSelect() {
//
//        VBox vbHead = JKNode.getReportHeadVB("Reprints Online");
//
//        Label lblFrom = JKText.getLblDk("From :", JKText.FONT_B_SM);
//        Label lblTo = JKText.getLblDk("To :", JKText.FONT_B_SM);
//
//        Label lblDateFrom = JKText.getLblDk("Date", JKText.FONT_B_XSM);
//        lblDateFrom.setMinWidth(JKLayout.btnSmW - (2 * JKLayout.sp));
//        lblDateFrom.setTranslateX(2 * JKLayout.sp);
//        Label lblTimeFrom = JKText.getLblDk("Time", JKText.FONT_B_XSM);
//        lblTimeFrom.setMinWidth(JKLayout.btnSmW - (2 * JKLayout.sp));
//        lblTimeFrom.setTranslateX(2 * JKLayout.sp);
//
//        Label lblDateTo = JKText.getLblDk("Date", JKText.FONT_B_XSM);
//        lblDateTo.setMinWidth(JKLayout.btnSmW - (2 * JKLayout.sp));
//        lblDateTo.setTranslateX(2 * JKLayout.sp);
//        Label lblTimeTo = JKText.getLblDk("Time", JKText.FONT_B_XSM);
//        lblTimeTo.setMinWidth(JKLayout.btnSmW - (2 * JKLayout.sp));
//        lblTimeTo.setTranslateX(2 * JKLayout.sp);
//
//        final TextField txtDateFrom = new TextField();
//        txtDateFrom.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getCalendarPickerX().showCalendarPickerX(txtDateFrom);
//            }
//        });
//        final TextField txtTimeFromHrs = new TextField();
//        txtTimeFromHrs.setPromptText("HH");
//        txtTimeFromHrs.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getNumPad().showNumPad(txtTimeFromHrs, "Hours", "", new NumberPadResult() {
//
//                    @Override
//                    public void onDone(String value) {
//                        //
//                    }
//                });
//            }
//        });
//        final TextField txtTimeFromMin = new TextField();
//        txtTimeFromMin.setPromptText("mm");
//        txtTimeFromMin.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getNumPad().showNumPad(txtTimeFromMin, "Minutes", "", new NumberPadResult() {
//
//                    @Override
//                    public void onDone(String value) {
//                        //
//                    }
//                });
//            }
//        });
//
//        final TextField txtDateTo = new TextField();
//        txtDateTo.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getCalendarPickerX().showCalendarPickerX(txtDateTo);
//            }
//        });
//        final TextField txtTimeToHrs = new TextField();
//        txtTimeToHrs.setPromptText("HH");
//        txtTimeToHrs.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getNumPad().showNumPad(txtTimeToHrs, "Hours", "", new NumberPadResult() {
//
//                    @Override
//                    public void onDone(String value) {
//                        //
//                    }
//                });
//            }
//        });
//        final TextField txtTimeToMin = new TextField();
//        txtTimeToMin.setPromptText("mm");
//        txtTimeToMin.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getNumPad().showNumPad(txtTimeToMin, "Minutes", "", new NumberPadResult() {
//
//                    @Override
//                    public void onDone(String value) {
//                        //
//                    }
//                });
//            }
//        });
//
//        HBox hbDateFrom = JKLayout.getHBox(0, JKLayout.sp);
//        hbDateFrom.getChildren().addAll(lblDateFrom, txtDateFrom);
//        HBox hbTimeFrom = JKLayout.getHBox(0, JKLayout.sp);
//        hbTimeFrom.getChildren().addAll(lblTimeFrom, txtTimeFromHrs, txtTimeFromMin);
//
//        HBox hbDateTo = JKLayout.getHBox(0, JKLayout.sp);
//        hbDateTo.getChildren().addAll(lblDateTo, txtDateTo);
//        HBox hbTimeTo = JKLayout.getHBox(0, JKLayout.sp);
//        hbTimeTo.getChildren().addAll(lblTimeTo, txtTimeToHrs, txtTimeToMin);
//
//        GridPane grid = JKLayout.getGridContent2Col(0.5, 0.5);
//
//        grid.add(vbHead, 0, 0, 2, 1);
//        grid.add(lblFrom, 0, 1, 2, 1);
//        grid.addRow(2, hbDateFrom, hbTimeFrom);
//        grid.add(lblTo, 0, 3, 2, 1);
//        grid.addRow(4, hbDateTo, hbTimeTo);
//
//        return grid;
//    }
    private SceneReportControls getPrintControl() {
        return new SceneReportControls("View") {
            @Override
            public void onClickPrint() {
                if (isValidEntry()) {
                    getReprintListByDate();
                }
            }
        };
    }

    private void getReprintListByDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        StringBuilder sb = new StringBuilder();
        sb.append("\r\n");
        sb.append(" >>> Reprint range selected : ").append("\r\n");
        sb.append(" >>>    Date from : ").append(sdf.format(new Date(dateInMillisFrom))).append("\r\n");
        sb.append(" >>>    Date to   : ").append(sdf.format(new Date(dateInMillisTo)));
        logger.info(sb.toString());
        ReprintUtil.getReprintListByDate(dateInMillisFrom, dateInMillisTo, new ReprintUtil.ReprintListResult() {

            @Override
            public void reprintListResult(final ReprintList reprintList) {
                if (reprintList.isSuccess() && reprintList.getReprints().size() > 0) {
                    logger.info(("Reprints in list : ").concat(Integer.toString(reprintList.getReprints().size())));
                    SceneReports.clearAndChangeContent(new ReprintsOnline(reprintList));
                } else if (reprintList.isSuccess() && reprintList.getReprints().size() <= 0) {
                    JKiosk3.getMsgBox().showMsgBox("No Reprints Available", "Please select new Dates", null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    clearInputFields();
                                }

                                @Override
                                public void onCancel() {
                                }
                            });
                } else {
                    JKiosk3.getMsgBox().showMsgBox("Reprint List Error", reprintList.getErrorText(), null,
                            MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {

                                @Override
                                public void onOk() {
                                    clearInputFields();
                                }

                                @Override
                                public void onCancel() {
                                }
                            });
                }
            }
        });
    }

    private void clearInputFields() {
        txtDateFrom.clear();
        txtDateTo.clear();
        dateInMillisFrom = 0L;
        dateInMillisTo = 0L;
    }

    private boolean isValidEntry() {
        if (txtDateFrom.getText().isEmpty() || txtDateTo.getText().isEmpty()) {
            JKiosk3.getMsgBox().showMsgBox("Select Dates", "Please select Dates for Reprints", null);
            return false;
        }

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date today = new Date();

            Date dateRequiredFrom = sdf.parse(txtDateFrom.getText());
            dateInMillisFrom = dateRequiredFrom.getTime();

            Date dateRequiredTo = sdf.parse(txtDateTo.getText());
            dateInMillisTo = dateRequiredTo.getTime();

            if (dateRequiredFrom.after(today) || dateRequiredTo.after(today)) {
                JKiosk3.getMsgBox().showMsgBox("Invalid Date", "Selected Date(s) cannot be after today", null);
                return false;
            }

            if (dateRequiredFrom.after(dateRequiredTo)) {
                JKiosk3.getMsgBox().showMsgBox("Invalid Date", "'Date From' cannot be after 'Date To'", null);
                return false;
            }

        } catch (ParseException pe) {
            JKiosk3.getMsgBox().showMsgBox("Invalid Date Format", "Please enter date in format 'dd/MM/yyyy'", null);
            return false;
        }

        return true;
    }
}
