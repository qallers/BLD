package jkiosk3.setup;

import java.util.ArrayList;
import java.util.List;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;

public class SetupSalesOptMenu extends Region {

    private final static String MENU_CACHE = "Caching Options";
    private final static String MENU_TRANS_LIMIT = "Transaction Limits";

    public SetupSalesOptMenu() {
        getChildren().add(getSalesOptMenuGroup());
    }

    private HBox getSalesOptMenuGroup() {

        List<String> btnLabelsSales = new ArrayList<>();
        btnLabelsSales.add(SceneSetup.MENU_SALES_OPT);
        btnLabelsSales.add(MENU_CACHE);
        btnLabelsSales.add(MENU_TRANS_LIMIT);

        List<Button> btnList = new ArrayList<>();

        for (String s : btnLabelsSales) {
            final Button btn = JKNode.getBtnSm(s);
            btn.setWrapText(true);
            btn.setStyle(SceneSetup.SETUP_BTN_STYLE);
            btn.setOnMouseReleased(new EventHandler() {
                @Override
                public void handle(Event e) {
                    getMenuAction(btn);
                }
            });
            btnList.add(btn);
        }

        HBox hb = JKLayout.getControlsHBox();
        hb.setAlignment(Pos.CENTER_LEFT);
        hb.getChildren().addAll(btnList);
        hb.getChildren().add(JKNode.getHSpacer());

        return hb;
    }

    private void getMenuAction(Button b) {

        switch (b.getText()) {
            case SceneSetup.MENU_SALES_OPT:
                SceneSetup.clearAndChangeContent(new SetupSalesOptions());
                break;
            case MENU_CACHE:
                SceneSetup.clearAndChangeContent(new SetupCacheOptions());
                break;
            case MENU_TRANS_LIMIT:
                SceneSetup.clearAndChangeContent(new SetupTransactionLimits());
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Sales Options Menu", "No Menu Item Selected!", null);
        }
    }
}
