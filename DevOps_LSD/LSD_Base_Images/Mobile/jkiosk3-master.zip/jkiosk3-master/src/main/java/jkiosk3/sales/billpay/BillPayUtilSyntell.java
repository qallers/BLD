package jkiosk3.sales.billpay;

import aeonbillpayments.BillPaymentConnection;
import aeonbillpayments.syntell.SyntellAccPayConfReq;
import aeonbillpayments.syntell.SyntellAccPayConfResp;
import aeonbillpayments.syntell.SyntellAccPayReq;
import aeonbillpayments.syntell.SyntellAccPayResp;
import aeonbillpayments.syntell.SyntellFinePayConfReq;
import aeonbillpayments.syntell.SyntellFinePayConfResp;
import aeonbillpayments.syntell.SyntellFinePayReq;
import aeonbillpayments.syntell.SyntellFinePayResp;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.concurrent.Worker.State;
import jkiosk3.JKiosk3;
import jkiosk3.sales.billpay._common.BillPaymentMenu;
import jkiosk3.utilities.TaskUtil;

/**
 *
 * @author Val
 */
public class BillPayUtilSyntell {

    private final static Logger logger = Logger.getLogger(BillPayUtilSyntell.class.getName());
    private final static TaskUtil taskutil = new TaskUtil();
    private static String errorMsg = "An unknown error occurred";
    private static BillPaymentConnection bpc = null;

    private static SyntellAccPayConfResp getSyntellBillPaymentConfirm(BillPaymentConnection conn, SyntellAccPayConfReq r)
            throws RuntimeException {
        SyntellAccPayConfResp resp = new SyntellAccPayConfResp();

        try {
            resp = conn.getSyntellAccountPaymentConfirmation(r);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Payment Confirm Error", t);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return resp;
    }

    private static SyntellFinePayConfResp getSyntellFinePaymentConfirm(BillPaymentConnection conn, SyntellFinePayConfReq r)
            throws RuntimeException {
        SyntellFinePayConfResp resp = new SyntellFinePayConfResp();

        try {
            resp = conn.getSyntellFinePaymentConfirmation(r);
        } catch (Throwable t) {
            errorMsg = t.getClass().getSimpleName() + " : " + t.getMessage();
            logger.log(Level.SEVERE, t.getMessage(), t);
            throw new RuntimeException("Payment Confirm Error", t);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return resp;
    }

    /*----------------*/
    /* Busy Indicator */
    /*----------------*/
    public static void getSyntellTrafficPaymentResponse(final SyntellFinePayReq r, final SyntellFinePaymentResponse resp) {
        JKiosk3.getBusy().showBusy("Confirming Traffic Fine Details");

        final Task<BillPaymentConnection> taskConnect = new Task() {
            @Override
            protected BillPaymentConnection call() throws Exception {
                bpc = BillPayUtilConnect.getBpc();
                return bpc;
            }
        };

        final Task<SyntellFinePayResp> taskTrafResp = new Task() {
            @Override
            protected SyntellFinePayResp call() throws Exception {
                SyntellFinePayResp res = null;
                if (BillPayUtilConnect.isLoggedIn(BillPaymentConnection.BILLPAY_SYNTELL_FINE)) {
                    res = bpc.getSyntellFinePayment(r);
                }
                return res;
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                resp.syntellFinePayResp(taskConnect.getValue(), (SyntellFinePayResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Traffic Fine Details", State.CANCELLED, errorMsg, new BillPaymentMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Traffic Fine Details", State.FAILED, errorMsg, new BillPaymentMenu());
            }
        };

        taskConnect.stateProperty().addListener(new ChangeListener<State>() {
            @Override
            public void changed(ObservableValue<? extends State> observable, State oldValue, State newState) {
                if (newState == State.SUCCEEDED) {
                    if (taskConnect.getValue() != null) {
                        new Thread(taskTrafResp).start();
                        JKiosk3.getBusy().startCountdown(taskTrafResp, BillPayUtilConnect.COUNTDOWN_TIME);
                    } else {
                        errorMsg = "Unable to establish connection";
                        taskutil.taskConnectNull(errorMsg, new BillPaymentMenu());
                    }
                } else if (newState == State.CANCELLED || newState == State.FAILED) {
                    taskutil.taskConnectCancelFail(newState, errorMsg, new BillPaymentMenu());
                }
            }
        });

        new Thread(taskConnect).start();
    }

    public static void getSyntellFinePaymentConfirm(final BillPaymentConnection conn, final SyntellFinePayConfReq r,
            final SyntellFinePaymentConfirm conf) {

        JKiosk3.getBusy().showBusy("Confirming Payment");

        final Task<SyntellFinePayConfResp> taskTrafConf = new Task() {
            @Override
            protected SyntellFinePayConfResp call() throws Exception {
                return getSyntellFinePaymentConfirm(conn, r);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                conf.syntellFinePayConf((SyntellFinePayConfResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.FAILED, errorMsg);
            }
        };

        new Thread(taskTrafConf).start();
        JKiosk3.getBusy().startCountdown(taskTrafConf, BillPayUtilConnect.COUNTDOWN_TIME);
    }

    public static void getSyntellBillPaymentResponse(final SyntellAccPayReq r, final SyntellBillPaymentResponse resp) {

        JKiosk3.getBusy().showBusy("Confirming Account Detail");

        final Task<BillPaymentConnection> taskConnect = new Task() {
            @Override
            protected BillPaymentConnection call() throws Exception {
                bpc = BillPayUtilConnect.getBpc();
                return bpc;
            }
        };

        final Task<SyntellAccPayResp> taskAccResp = new Task() {
            @Override
            protected SyntellAccPayResp call() throws Exception {
                SyntellAccPayResp res = null;
                if (BillPayUtilConnect.isLoggedIn(BillPaymentConnection.BILLPAY_SYNTELL_ACCOUNT)) {
                    res = bpc.getSyntellAccountPayment(r);
                }
                return res;
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                resp.syntellBillPayResp(taskConnect.getValue(), (SyntellAccPayResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Account Details", State.CANCELLED, errorMsg, new BillPaymentMenu());
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFail("Confirmation Error",
                        "Unable to Confirm Account Details", State.FAILED, errorMsg, new BillPaymentMenu());
            }
        };

        taskConnect.stateProperty().addListener(new ChangeListener<State>() {
            @Override
            public void changed(ObservableValue<? extends State> observable, State oldValue, State newState) {
                if (newState == State.SUCCEEDED) {
                    if (taskConnect.getValue() != null) {
                        new Thread(taskAccResp).start();
                        JKiosk3.getBusy().startCountdown(taskAccResp, BillPayUtilConnect.COUNTDOWN_TIME);
                    } else {
                        errorMsg = "Unable to establish connection";
                        taskutil.taskConnectNull(errorMsg, new BillPaymentMenu());
                    }
                } else if (newState == State.CANCELLED || newState == State.FAILED) {
                    taskutil.taskConnectCancelFail(newState, errorMsg, new BillPaymentMenu());
                }
            }
        });

        new Thread(taskConnect).start();
    }

    public static void getSyntellBillPaymentConfirm(final BillPaymentConnection conn, final SyntellAccPayConfReq r,
            final SyntellBillPaymentConfirm conf) {

        JKiosk3.getBusy().showBusy("Confirming Payment");

        final Task<SyntellAccPayConfResp> taskAccConf = new Task() {
            @Override
            protected SyntellAccPayConfResp call() throws Exception {
                return getSyntellBillPaymentConfirm(conn, r);
            }

            @Override
            protected void succeeded() {
                JKiosk3.getBusy().hideBusy();
                conf.syntellBillPayConf((SyntellAccPayConfResp) getValue());
            }

            @Override
            protected void cancelled() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.CANCELLED, errorMsg);
            }

            @Override
            protected void failed() {
                taskutil.taskSaleCancelFailLogout("Confirmation Error", "Unable to Confirm Payment", State.FAILED, errorMsg);
            }
        };

        new Thread(taskAccConf).start();
        JKiosk3.getBusy().startCountdown(taskAccConf, BillPayUtilConnect.COUNTDOWN_TIME);
    }

    public abstract static class SyntellFinePaymentConfirm {

        public abstract void syntellFinePayConf(SyntellFinePayConfResp bpConfResp);
    }

    public abstract static class SyntellFinePaymentResponse {

        public abstract void syntellFinePayResp(BillPaymentConnection connect, SyntellFinePayResp resp);
    }

    public abstract static class SyntellBillPaymentConfirm {

        public abstract void syntellBillPayConf(SyntellAccPayConfResp bpConfResp);
    }

    public abstract static class SyntellBillPaymentResponse {

        public abstract void syntellBillPayResp(BillPaymentConnection connect, SyntellAccPayResp resp);
    }
}
