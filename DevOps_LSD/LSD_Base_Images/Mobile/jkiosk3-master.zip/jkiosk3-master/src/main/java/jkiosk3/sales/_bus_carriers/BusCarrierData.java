package jkiosk3.sales._bus_carriers;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import jkiosk3.JK3Config;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author valeriew
 */
public class BusCarrierData {

    private final static Logger logger = Logger.getLogger(BusCarrierData.class.getName());

    public static List<BusCarrier> getBusCarrierDataList() {
        List<BusCarrier> listCarriers = new ArrayList<>();

        try {
            File file = new File(JK3Config.getMediaBusCarrierData());
            Element listElements = new SAXBuilder().build(file).getRootElement().getChild("carriers");
            for (Object o : listElements.getChildren("carrier")) {
                Element carrier = (Element) o;

                BusCarrier busCarrier = new BusCarrier();
                if (carrier.getChild("transType") != null) {
                    busCarrier.setCarrierTransType(carrier.getChildTextTrim("transType"));
                }
                busCarrier.setCarrierCode(carrier.getChildTextTrim("code"));
                busCarrier.setCarrierName(carrier.getChildTextTrim("name"));
                if (carrier.getChild("image") != null) {
                    busCarrier.setCarrierImage(carrier.getChildTextTrim("image"));
                }
                busCarrier.setCarrierLogoCode(carrier.getChildTextTrim("logoCode"));
                busCarrier.setCarrierWebsite(carrier.getChildTextTrim("website"));
                busCarrier.setCarrierCallCentre(carrier.getChildTextTrim("callcentre"));

                listCarriers.add(busCarrier);
            }
        } catch (JDOMException | IOException e) {
            logger.log(Level.SEVERE, e.getMessage(), e);
        }

        return listCarriers;
    }
}
