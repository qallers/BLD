package jkiosk3.accounts.emerg_topup;

import aeonemergencytopup.LoanConfirmResp;
import aeonprinting.AeonPrintJob;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.Group;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import jkiosk3.JKiosk3;
import jkiosk3.SceneMenu;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;
import jkiosk3._components.PrintPreview;
import jkiosk3._components.PrintPreviewResult;
import jkiosk3.accounts.emerg_topup.EmergencyTopupUtil.LoanConfirmationResult;
import jkiosk3.printing.print_layouts.PrintEmergTop;

/**
 *
 * @author Valerie
 */
public class EmergencyTopupConfirm extends Region {

    private CheckBox chkTandC;
    private ControlButtons ctrlBtns;

    public EmergencyTopupConfirm() {
        getChildren().add(getConfirmLayout());
    }

    private VBox getConfirmLayout() {
        VBox vbConf = JKLayout.getVBox(0, JKLayout.spNum);
        vbConf.getChildren().add(getConfirmGroup());
        vbConf.getChildren().add(getControlButtons());
        return vbConf;
    }

    private Group getConfirmGroup() {

        Label lblSummaryHead = JKText.getLblContentHead("Confirm all details before continuing");

        VBox vb = JKLayout.getVBox(JKLayout.sp, JKLayout.sp);
        vb.getChildren().addAll(lblSummaryHead, JKNode.createContentSep());
        vb.getChildren().add(getSummaryGrid());
        vb.getChildren().add(JKNode.createContentSep());
        vb.getChildren().add(getTandCGrid());

        Group grp = JKNode.getContentGroup(vb);
        return grp;
    }

    private ControlButtons getControlButtons() {
        ctrlBtns = new ControlButtons();

        ctrlBtns.getBtnAccept().setDisable(true);
        ctrlBtns.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                EmergencyTopupUtil.getLoanConfirmation(EmergencyTopup.getInstance().getConfReq(), new LoanConfirmationResult() {

                    @Override
                    public void loanConfirmationResult(LoanConfirmResp loanConfirmation) {
                        if (loanConfirmation.isSuccess()) {
                            printAndClose(loanConfirmation);
                        } else {
                            JKiosk3.getMsgBox().showMsgBox("Emergency Topup Error",
                                    loanConfirmation.getErrorCode() + " - " + loanConfirmation.getErrorText(), null);
                        }
                    }
                });
            }
        });
        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneEmergencyTopup.getVbEmergTopContent().getChildren().clear();
            }
        });

        return ctrlBtns;
    }

    private GridPane getSummaryGrid() {
        GridPane gridSumm = JKLayout.getContentGridInner2Col(0.5, 0.5, HPos.RIGHT);

        Label lblAccount = JKText.getLblDk("Account to be credited", JKText.FONT_B_XSM);
        Label lblAvailable = JKText.getLblDk("Amount Available", JKText.FONT_B_XSM);
        Label lblRequested = JKText.getLblDk("Amount Requested", JKText.FONT_B_XSM);
        Label lblBalance = JKText.getLblDk("Balance", JKText.FONT_B_XSM);

        double amtReq = EmergencyTopup.getInstance().getConfReq().getAmountRequested();
        double amtBalance = EmergencyTopup.getInstance().getLoanResp().getQualifyAmount() - amtReq;
        Text txtAccount = JKText.getTxtDk(EmergencyTopup.getInstance().getAccount().getAccountNumber(), JKText.FONT_B_XSM);
        Text txtAvailable = JKText.getTxtDk(JKText.getDeciFormat(EmergencyTopup.getInstance().getLoanResp().getQualifyAmount()), JKText.FONT_B_XSM);
        Text txtRequested = JKText.getTxtDk(JKText.getDeciFormat(amtReq), JKText.FONT_B_XSM);
        Text txtBalance = JKText.getTxtDk(JKText.getDeciFormat(amtBalance), JKText.FONT_B_XSM);

        gridSumm.addRow(0, lblAccount, txtAccount);
        gridSumm.addRow(1, lblAvailable, txtAvailable);
        gridSumm.addRow(2, lblRequested, txtRequested);
        gridSumm.addRow(4, lblBalance, txtBalance);

        return gridSumm;
    }

    private GridPane getTandCGrid() {
        GridPane gridTandC = JKLayout.getContentGridInner2Col(0.75, 0.25, HPos.RIGHT);

        Label lblTandC = JKText.getLblDk("You must accept the Terms and Conditions before continuing", JKText.FONT_B_XXSM);
        lblTandC.setWrapText(true);

        chkTandC = new CheckBox();
        chkTandC.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event t) {
                if (chkTandC.isSelected()) {
                    ctrlBtns.getBtnAccept().setDisable(false);
                } else {
                    ctrlBtns.getBtnAccept().setDisable(true);
                }
            }
        });

//        Button btnTandC = JKNode.getBtnMsgBox("T & C");
//        btnTandC.setOnMouseReleased(new EventHandler() {
//            @Override
//            public void handle(Event e) {
//                JKiosk3.getMsgBox().showMsgBox("Terms and Conditions", "Terms and Conditions will be available soon", null, 
//                        MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult() {
//
//                    @Override
//                    public void onOk() {
//                        ctrlBtns.getBtnAccept().setDisable(false);
//                    }
//
//                    @Override
//                    public void onCancel() {
//                        //
//                    }
//                
//                });
////                JKiosk3.getWebPage().showWebPage("http://www.bluelabeltelecoms.co.za/index_corporate.php");
////                ctrlBtns.getBtnAccept().setDisable(false);
//            }
//        });
        gridTandC.addRow(0, lblTandC, chkTandC);

        return gridTandC;
    }

    private void printAndClose(LoanConfirmResp loanConfirm) {
        EmergencyTopup.getInstance().setConfResp(loanConfirm);
        String accNum = EmergencyTopup.getInstance().getAccount().getAccountNumber();
//        AeonPrintJob apj = PrintEmergTop.getEmergencyTopupConfirmationReceipt(accNum, loanConfirm, false);
        AeonPrintJob apj = loanConfirm.getAeonPrintJob();
        JKiosk3.getPrintPreview().showPrintPreview("Emergency Topup Confirmation", apj, PrintPreview.PRN_OK_CANCEL,
                new PrintPreviewResult() {
                    @Override
                    public void onOk() {
                        JKiosk3.changeScene(new SceneMenu());
                    }

                    @Override
                    public void onCancel() {
                        JKiosk3.changeScene(new SceneMenu());
                    }
                });
    }
}
