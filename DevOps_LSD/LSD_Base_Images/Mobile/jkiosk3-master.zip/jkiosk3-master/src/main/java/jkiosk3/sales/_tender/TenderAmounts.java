package jkiosk3.sales._tender;

import jkiosk3.JKiosk3;

/**
 *
 * @author Val
 */
public class TenderAmounts {

    public final static String TENDER_CASH = "Cash";
    public final static String TENDER_CHEQUE = "Cheque";
    public final static String TENDER_CRED_CARD = "Credit Card";
    public final static String TENDER_DEB_CARD = "Debit Card";
    private static double tenderCash = 0.0;
    private static double tenderCheque = 0.0;
    private static double tenderCreditCard = 0.0;
    private static double tenderDebitCard = 0.0;

    public static void addTenderAmount(String tenderType, double amount) {
        switch (tenderType) {
            case TENDER_CASH:
                tenderCash = tenderCash + amount;
                break;
            case TENDER_CHEQUE:
                tenderCheque = tenderCheque + amount;
                break;
            case TENDER_CRED_CARD:
                tenderCreditCard = tenderCreditCard + amount;
                break;
            case TENDER_DEB_CARD:
                tenderDebitCard = tenderDebitCard + amount;
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Tender Type", "No Tender Type Selected", null);
        }
    }

    public static double getTenderCash() {
        return tenderCash;
    }

    public static double getTenderCheque() {
        return tenderCheque;
    }

    public static double getTenderCreditCard() {
        return tenderCreditCard;
    }

    public static double getTenderDebitCard() {
        return tenderDebitCard;
    }

    public static void resetTenderAmounts() {
        tenderCash = 0.0;
        tenderCheque = 0.0;
        tenderCreditCard = 0.0;
        tenderDebitCard = 0.0;
    }
}
