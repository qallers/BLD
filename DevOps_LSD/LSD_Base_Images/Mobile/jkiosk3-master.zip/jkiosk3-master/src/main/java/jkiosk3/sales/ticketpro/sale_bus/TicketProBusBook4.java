package jkiosk3.sales.ticketpro.sale_bus;

import aeonticketpros.TicketProsCheckoutReq;
import aeonticketpros.TicketProsCheckoutResp;

import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.ticketpro.TicketProBusSale;
import jkiosk3.sales.ticketpro.TicketProUtilBus;
import jkiosk3.users.UserUtil;

public class TicketProBusBook4 extends Region {

    /*
     * Checkout for TicketPro Bus Tickets
     */
    private final static Logger logger = Logger.getLogger (TicketProBusBook4.class.getName ());
    //
    private TextField txtCustomerFirstName;
    private TextField txtCustomerLastName;
    private TextField txtCustomerCellNum;

    public TicketProBusBook4() {
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (getCustomerRegLayout ());
        vb.getChildren ().add (getNav ());

        getChildren ().add (vb);
    }

    private GridPane getCustomerRegLayout() {

        VBox vbHead = JKNode.getPutcoHeader ("Bus Ticket Booking - Step 4");

        Label lblCustomerReg = JKText.getLblContentSubHead ("Customer Registration");

        Label lblCustomerFirstName = JKText.getLblDk ("First Name", JKText.FONT_B_XSM);
        Label lblCustomerLastName = JKText.getLblDk ("Last Name", JKText.FONT_B_XSM);
        Label lblCustomerCellNum = JKText.getLblDk ("Cell Number", JKText.FONT_B_XSM);

        txtCustomerFirstName = new TextField ();
        txtCustomerFirstName.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (txtCustomerFirstName, "Enter Customer First Name", "", false);
            }
        });
        txtCustomerLastName = new TextField ();
        txtCustomerLastName.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getKeyboard ().showKeyboard (txtCustomerLastName, "Enter Customer Last Name", "", false);
            }
        });
        txtCustomerCellNum = new TextField ();
        txtCustomerCellNum.setPromptText ("do not use spaces, dashes, etc.");
        txtCustomerCellNum.setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                JKiosk3.getNumPad ().showNumPad (txtCustomerCellNum, "Enter Cell Number", "");
            }
        });

        GridPane grid = JKLayout.getGridContent2Col (0.25, 0.75);

        grid.add (vbHead, 0, 0, 2, 1);
        grid.add (lblCustomerReg, 0, 1, 2, 1);
        grid.addRow (3, lblCustomerFirstName, txtCustomerFirstName);
        grid.addRow (4, lblCustomerLastName, txtCustomerLastName);
        grid.addRow (5, lblCustomerCellNum, txtCustomerCellNum);

        return grid;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                SceneSales.clearAndChangeContent (new TicketProBusBook3 ());
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndShowFavourites ();
            }
        });
        nav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                TicketProBusSale.getInstance ().setCustomerName (txtCustomerFirstName.getText ().trim ());
                TicketProBusSale.getInstance ().setCustomerSurname (txtCustomerLastName.getText ().trim ());
                TicketProBusSale.getInstance ().setCustomerMobilePhone (txtCustomerCellNum.getText ().trim ());
                checkoutTickets ();
            }
        });
        return nav;
    }

    private void checkoutTickets() {

        TicketProsCheckoutReq req = new TicketProsCheckoutReq ();

        req.setCartId (TicketProBusSale.getInstance ().getBusSaleCart ().getCartId ());
        req.setMobilePhone (TicketProBusSale.getInstance ().getCustomerMobilePhone ());
        req.setName (TicketProBusSale.getInstance ().getCustomerName ());
        req.setSurname (TicketProBusSale.getInstance ().getCustomerSurname ());

        TicketProUtilBus.checkoutTicketProBus (req, new TicketProUtilBus.TicketProBusCheckoutResult () {

            @Override
            public void tpCheckoutBusResult(TicketProsCheckoutResp tpCheckoutBusResp) {
                if (tpCheckoutBusResp.isSuccess ()) {
                    TicketProBusSale.getInstance ().setCheckoutResponse (tpCheckoutBusResp);
                    StringBuilder sb = new StringBuilder ();
                    sb.append ("\r\n").append ("  >>>   Checkout response received   >>>");
                    sb.append ("\r\n").append ("Transaction ID : ").append (tpCheckoutBusResp.getTransactionId ());
                    sb.append ("\r\n").append ("Reference      : ").append (tpCheckoutBusResp.getReference ());
                    sb.append ("\r\n").append ("Balance        : ").append (tpCheckoutBusResp.getBalance ());
                    sb.append ("\r\n").append ("-----------------------------------------------------");
                    logger.info (sb.toString ());
                    SceneSales.clearAndChangeContent (new TicketProBusBook5 ());
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("TicketPro Checkout Error",
                            !tpCheckoutBusResp.getAeonErrorText ().isEmpty () ?
                                    "A" + tpCheckoutBusResp.getAeonErrorCode () + " - " + tpCheckoutBusResp.getAeonErrorText () :
                                    "B" + tpCheckoutBusResp.getErrorCode () + " - " + tpCheckoutBusResp.getErrorText ()
                                            + "\n\nClick 'OK' to return to current view, or 'Cancel' to cancel booking and return to start.",
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    // what to do if checkout fails
                                }

                                @Override
                                public void onCancel() {
                                    SceneSales.clearAndChangeContent (new TicketProBusBook1 ());
                                }
                            });
                }
            }
        });
    }
}
