package jkiosk3.users;

import aeonusers.UserPermission;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Pagination;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.ControlButtons;

/**
 *
 * @author Valerie
 */
public class UserPermissions extends Region {

    private List<String> listUserPerms;
    private List<CheckBox> listChkBoxes;
    private StackPane stack;
    private final static int PG_SIZE = 8;
    private final static double PG_HT = 445;

    public UserPermissions() {

        VBox vb = JKLayout.getVBox(0, JKLayout.spNum);

        vb.getChildren().addAll(getUserPermissionEntry(), getControlButtons());

        getChildren().add(vb);
    }

    private VBox getUserPermissionEntry() {

        Label lblHead = JKText.getLblDk("Report Permissions for : ", JKText.FONT_B_SM);
        Label lblUserName = JKText.getLblDk(JKUserAddEdit.getInstance().getAeonUser().getUserName(), JKText.FONT_B_SM);
        HBox hbHead = JKLayout.getHBox(0, 0);
        hbHead.getChildren().addAll(lblHead, JKNode.getHSpacer(), lblUserName);
        Label lblSubHead = JKText.getLblContentSubHead("Tick all items to which this Cashier Plus may have access");

        stack = new StackPane();
        stack.setMaxHeight(PG_HT);
        stack.setMinHeight(PG_HT);
        stack.setTranslateX(2 * JKLayout.sp);

        getListPermissions();

        VBox vb = JKLayout.getVBoxContent(JKLayout.sp);
        vb.setMaxWidth(JKLayout.contentW);

        vb.getChildren().addAll(hbHead, lblSubHead, JKNode.createContentSep());
        vb.getChildren().add(stack);

        return vb;
    }

    private void getListPermissions() {
        List<UserPermission> listPermissions = UserUtil.getListUserPermissions(CurrentUser.getUser().getUserPin());
        listUserPerms = new ArrayList<>();
        if (JKUserAddEdit.getInstance().getAeonUser().getUserPermissionString() != null) {
            String userPermString = JKUserAddEdit.getInstance().getAeonUser().getUserPermissionString();
            listUserPerms = Arrays.asList(userPermString.split(","));
        }
        System.out.println("permission string for " + JKUserAddEdit.getInstance().getAeonUser().getUserName() + " : "
                + JKUserAddEdit.getInstance().getAeonUser().getUserPermissionString());
        for (String s : listUserPerms) {
            System.out.println("permission as String in ArrayList = " + s);
        }
        listChkBoxes = getPermissionChkBoxes(listPermissions);
        createPagedPermissions();
    }

    private List<CheckBox> getPermissionChkBoxes(final List<UserPermission> listPerms) {
        List<CheckBox> listChkBox = new ArrayList<>();

        for (UserPermission p : listPerms) {
            CheckBox chkPerm = new CheckBox(p.getPermissionName());
            chkPerm.setId(Integer.toString(p.getPermissionId()));
            if (!listUserPerms.isEmpty()) {
                if (listUserPerms.contains(Integer.toString(p.getPermissionId()))) {
                    chkPerm.setSelected(true);
                } else {
                    chkPerm.setSelected(false);
                }
            }
            listChkBox.add(chkPerm);
        }
        return listChkBox;
    }

    private void createPagedPermissions() {
        int numPgs = 0;
        if (listChkBoxes.isEmpty()) {
            numPgs = 1;
        } else if ((listChkBoxes.size() % PG_SIZE) == 0) {
            numPgs = listChkBoxes.size() / PG_SIZE;
        } else {
            numPgs = (listChkBoxes.size() / PG_SIZE) + 1;
        }
        Pagination pages = new Pagination(numPgs);
        pages.setPageFactory(new Callback<Integer, Node>() {
            @Override
            public Node call(Integer pg) {
                List<Node> listnode = new ArrayList<>();
                listnode.addAll(listChkBoxes);
                return JKNode.createPagedVBox(pg, listnode, PG_SIZE, PG_HT);
            }
        });
        stack.getChildren().clear();
        stack.getChildren().add(pages);
    }

    private ControlButtons getControlButtons() {
        ControlButtons ctrlBtns = new ControlButtons();

        ctrlBtns.getBtnAccept().setText("Save");
        ctrlBtns.getBtnAccept().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                setCashierPlusPermissions();
            }
        });
        ctrlBtns.getBtnCancel().setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                SceneUsers.getVbUsersContent().getChildren().clear();
            }
        });

        return ctrlBtns;
    }

    private void setCashierPlusPermissions() {
        List<UserPermission> listAllowedPermissions = new ArrayList<>();
        for (CheckBox box : listChkBoxes) {
            if (box.isSelected()) {
                UserPermission perm = new UserPermission(Integer.parseInt(box.getId()), box.getText());
                listAllowedPermissions.add(perm);
            }
        }
        JKUserAddEdit.getInstance().getAeonUser().getUserPermissions().addAll(listAllowedPermissions);
        switch (JKUserAddEdit.getInstance().getNewOrEdit()) {
            case UserUtil.USER_NEW:
                UserUtil.saveNewUser(JKUserAddEdit.getInstance().getAeonUser());
                break;
            case UserUtil.USER_EDIT:
                UserUtil.saveEditUser(JKUserAddEdit.getInstance().getAeonUser(), false);
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("User Permissions", "No Permissions set for Cashier Plus", null);
        }
    }
}
