package jkiosk3.sales._common;

import java.util.ArrayList;
import java.util.List;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3.sales.SaleType;
import jkiosk3.sales._tender.TenderAmounts;
import jkiosk3.store.JKSalesOptions;

/**
 *
 * @author Val
 */
public class JKTenderToggles extends Region {

    private final String saleType;
    private final List<String> listTendersAccepted;
    private ToggleGroup toggleTenderGroup;
    private ToggleButton toggleCash;
    private ToggleButton toggleCheque;
    private ToggleButton toggleCreditCard;
    private ToggleButton toggleDebitCard;
    private List<ToggleButton> tenderToggleList;
    private String tenderTypeSelected;
    private String tenderText;
    private int tenderTypeCode;

    public JKTenderToggles(String saleType) {
        this.saleType = saleType;
        this.listTendersAccepted = setListTendersAccepted();

        HBox hb = makeContentHBox();

        setEnableTenderTypes();

        getChildren().add(hb);
    }
    
    public JKTenderToggles(String saleType, List<String> listTendersAccepted) {
        this.saleType = saleType;
        
        List<String> listTendersSetup = setListTendersAccepted();
        List<String> listTendersTmp = new ArrayList<>();
        for (String s : listTendersSetup) {
            System.out.println("tender accepted in Setup : " + s);
            if (listTendersAccepted.contains(s)) {
                System.out.println("tender accepted for this product : " + s);
                listTendersTmp.add(s);
            }
        }        
//        this.listTendersAccepted = listTendersAccepted;
        this.listTendersAccepted = listTendersTmp;

        HBox hb = makeContentHBox();

        setEnableTenderTypes();

        getChildren().add(hb);
    }
    
    private HBox makeContentHBox() {
        HBox hbox = JKLayout.getHBox(0, JKLayout.sp);
        hbox.setPrefWidth(JKLayout.contentW - (2 * JKLayout.sp));
        hbox.setMaxHeight(JKLayout.btnSmH + (2 * JKLayout.sp));
        hbox.getChildren().addAll(getTenderTypes());
        return hbox;
    }
    
    private List<String> setListTendersAccepted() {
        List<String> listTenders = new ArrayList<>();
        if (JKSalesOptions.getSalesOptions().isAcceptCash()) {
            listTenders.add(TenderAmounts.TENDER_CASH.replace(" ", "").toLowerCase());
        }
        if (JKSalesOptions.getSalesOptions().isAcceptCheque()) {
            listTenders.add(TenderAmounts.TENDER_CHEQUE.replace(" ", "").toLowerCase());
        }
        if (JKSalesOptions.getSalesOptions().isAcceptCreditCard()) {
            listTenders.add(TenderAmounts.TENDER_CRED_CARD.replace(" ", "").toLowerCase());
        }
        if (JKSalesOptions.getSalesOptions().isAcceptDebitCard()) {
            listTenders.add(TenderAmounts.TENDER_DEB_CARD.replace(" ", "").toLowerCase());
        }
        return listTenders;
    }

    private List<ToggleButton> getTenderTypes() {
        tenderToggleList = new ArrayList<>();

        toggleTenderGroup = new ToggleGroup();

        toggleCash = JKNode.getToggleSm(TenderAmounts.TENDER_CASH);
        toggleCash.setSelected(true);
        toggleCash.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                getToggleSelection();
            }
        });
        tenderToggleList.add(toggleCash);

        toggleCheque = JKNode.getToggleSm(TenderAmounts.TENDER_CHEQUE);
        toggleCheque.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                getToggleSelection();
            }
        });
        tenderToggleList.add(toggleCheque);

        toggleCreditCard = JKNode.getToggleSm(TenderAmounts.TENDER_CRED_CARD.replace(" ", "\n"));
        toggleCreditCard.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                getToggleSelection();
            }
        });
        tenderToggleList.add(toggleCreditCard);

        toggleDebitCard = JKNode.getToggleSm(TenderAmounts.TENDER_DEB_CARD.replace(" ", "\n"));
        toggleDebitCard.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                getToggleSelection();
            }
        });
        tenderToggleList.add(toggleDebitCard);
        for (ToggleButton t : tenderToggleList) {
            t.setToggleGroup(toggleTenderGroup);
            t.setFont(JKText.FONT_B_XXSM);
        }

        return tenderToggleList;
    }

    private void getToggleSelection() {
        if (toggleTenderGroup.getSelectedToggle() == null) {
            toggleTenderGroup.selectToggle(toggleCash);
        }
    }

    public List<ToggleButton> getTenderToggleList() {
        return tenderToggleList;
    }

    public int getTenderTypeCode() {
        getToggleSelection();
        if (toggleTenderGroup.getSelectedToggle().equals(toggleCash)) {
            tenderText = TenderAmounts.TENDER_CASH;
            tenderTypeSelected = "cash";
            tenderTypeCode = 1;
        } else if (toggleTenderGroup.getSelectedToggle().equals(toggleCheque)) {
            tenderText = TenderAmounts.TENDER_CHEQUE;
            tenderTypeSelected = "cheque";
            tenderTypeCode = 4;
        } else if (toggleTenderGroup.getSelectedToggle().equals(toggleCreditCard)) {
            tenderText = TenderAmounts.TENDER_CRED_CARD;
            tenderTypeSelected = "creditCard";
            tenderTypeCode = 2;
        } else if (toggleTenderGroup.getSelectedToggle().equals(toggleDebitCard)) {
            tenderText = TenderAmounts.TENDER_DEB_CARD;
            tenderTypeSelected = "debitCard";
            tenderTypeCode = 3;
        }
        return tenderTypeCode;
    }

    public String getTenderTypeSelected() {
        getToggleSelection();
        getTenderTypeCode();
        return tenderTypeSelected;
    }

    public int getTenderCodeSelected() {
        getToggleSelection();
        getTenderTypeCode();
        return tenderTypeCode;
    }

    public String getTenderText() {
        getToggleSelection();
        getTenderTypeCode();
        return tenderText;
    }

    public static String getTxtForTender(String tendered) {
        String txtTender = "";
        switch (tendered) {
            case "cash":
                txtTender = "Cash";
                break;
            case "cheque":
                txtTender = "Cheque";
                break;
            case "creditCard":
                txtTender = "Credit Card";
                break;
            case "debitCard":
                txtTender = "Debit Card";
                break;
            default:
                JKiosk3.getMsgBox().showMsgBox("Tender Type", "No Tender Type Selected", null);
        }
        return txtTender;
    }

    private void setEnableTenderTypes() {
        for (ToggleButton b : tenderToggleList) {
            String btnText = b.getText().replace("\n", "").toLowerCase();
            if (!listTendersAccepted.contains(btnText)) {
                b.setDisable(true);
            }
            // Bus Carriers do not accept Cheque - this must always be disabled.
            if (saleType.equalsIgnoreCase(SaleType.BUSTICKETS.getDisplay())
                    || saleType.equalsIgnoreCase(SaleType.COACHTICKETS.getDisplay())) {
                if (btnText.equalsIgnoreCase(TenderAmounts.TENDER_CHEQUE.replace("\n", "").toLowerCase())) {
                    b.setDisable(true);
                }
            }

//            switch (b.getText().replace("\n", " ")) {
//                case TenderAmounts.TENDER_CASH:
//                    b.setDisable(!JKSalesOptions.getSalesOptions().isAcceptCash());
//                    break;
//                case TenderAmounts.TENDER_CHEQUE:
//                    if (saleType.equalsIgnoreCase(SaleType.BUSTICKETS.getDisplay())
//                            || saleType.equalsIgnoreCase(SaleType.WEBTICKETS.getDisplay())) {
//                        // Bus Carriers and WebTickets do not accept Cheque - this must always be disabled.
//                        // Add other Sale Types as needed.
//                        b.setDisable(true);
//                    } else {
//                        b.setDisable(!JKSalesOptions.getSalesOptions().isAcceptCheque());
//                    }
//                    break;
//                case TenderAmounts.TENDER_CRED_CARD:
//                    b.setDisable(!JKSalesOptions.getSalesOptions().isAcceptCreditCard());
//                    break;
//                case TenderAmounts.TENDER_DEB_CARD:
//                    b.setDisable(!JKSalesOptions.getSalesOptions().isAcceptDebitCard());
//                    break;
//                default:
//                    JKiosk3.getMsgBox().showMsgBox("Tender Type", "No Tender Type Selected", null);
//            }
        }
    }

    public void resetTenderType() {
        toggleTenderGroup.selectToggle(null);
    }
}
