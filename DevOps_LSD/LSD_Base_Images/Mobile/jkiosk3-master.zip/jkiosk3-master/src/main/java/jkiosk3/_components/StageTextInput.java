package jkiosk3._components;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import jkiosk3._common.JKLayout;
import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;

import java.awt.*;

public class StageTextInput extends Region {

    private Stage stageParent;
    private Dimension stageDimensions;
    private String head;
    private TextField textField;
    private NumberPad numberPad;
    private StageTextInputResult result;

    public StageTextInput(Stage stageParent, Dimension stageDimensions, String head, TextField textField, StageTextInputResult result) {
        this.stageParent = stageParent;
        this.stageDimensions = stageDimensions;
        this.head = head;
        this.textField = textField;
        this.result = result;
        numberPad = new NumberPad();
        numberPad.setVisible(false);

        getChildren().add(getLayoutStack());
    }

    private StackPane getLayoutStack() {
        double popupWidth = 350;

        Label label = JKText.getLblDk(head, JKText.FONT_B_24);

        final TextField txtfld = new TextField();
        txtfld.setMaxWidth(popupWidth - (6 * JKLayout.sp));
        txtfld.setMinWidth(popupWidth - (6 * JKLayout.sp));
        txtfld.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                numberPad.showNumPad(txtfld, "OTP", "");
            }
        });

        Button btnOK = JKNode.getBtnMsgBox("OK");
        btnOK.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                String entered = txtfld.getText();
                textField.setText(entered);
                result.onDone(entered);
                stageParent.close();
            }
        });

        Button btnCancel = JKNode.getBtnMsgBox("Cancel");
        btnCancel.setOnMouseReleased(new EventHandler() {
            @Override
            public void handle(Event e) {
                stageParent.close();
            }
        });

        HBox hBox = JKLayout.getHBox(0, JKLayout.sp);
        hBox.setPrefWidth(popupWidth - (2 * JKLayout.sp));
        hBox.getChildren().addAll(btnOK, btnCancel);

        VBox vBox = JKLayout.getVBoxContent(JKLayout.sp);
        vBox.setMaxSize(popupWidth, 225);
        vBox.setMinSize(popupWidth, 225);
        vBox.getChildren().addAll(label, new Separator(), txtfld, new Separator(), hBox);

        StackPane stack = new StackPane();
        stack.setPrefSize(stageDimensions.getWidth(), stageDimensions.getHeight());
        stack.getChildren().addAll(numberPad, vBox);

        return stack;
    }
}
