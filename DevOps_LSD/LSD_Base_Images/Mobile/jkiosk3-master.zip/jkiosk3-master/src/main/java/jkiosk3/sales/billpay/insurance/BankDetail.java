package jkiosk3.sales.billpay.insurance;

/**
 *
 * @author Valerie
 */
public class BankDetail {

    private int bankId;
    private String bankName;

    public int getBankId() {
        return bankId;
    }

    public void setBankId(int bankId) {
        this.bankId = bankId;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }
}
