package jkiosk3.sales.billpay.insurance;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author Valerie
 */
public class BankList {

    public final static String INSTALL_PATH_BANK = "media\\bank_list_ins\\";
    public final static String FILENAME_BANK = "BankListIns.xml";

    public static List<BankDetail> getBankList() {
        List<BankDetail> listBanks = new ArrayList<>();

        try {
            File file = new File(INSTALL_PATH_BANK + FILENAME_BANK);
            Element listAccounts = new SAXBuilder().build(file).getRootElement().getChild("banks");
            for (Object acc : listAccounts.getChildren("bank")) {
                Element accType = (Element) acc;

                BankDetail bank = new BankDetail();
                bank.setBankId(Integer.parseInt(accType.getAttributeValue("id")));
                bank.setBankName(accType.getTextTrim());

                listBanks.add(bank);
            }
        } catch (JDOMException | IOException e) {
            e.printStackTrace();
        }

        return listBanks;
    }
}
