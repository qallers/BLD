package jkiosk3.sales.ticketpro.sale_bus;

import aeonticketpros.TicketProsCartClearReq;
import aeonticketpros.bus.TicketProBusCartClearResp;
import aeonticketpros.bus.TicketProBusRouteBookResp;
import aeonticketpros.bus.TicketProBusSeat;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Logger;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import jkiosk3.JKiosk3;
import jkiosk3._common.JKLayout;

import static jkiosk3._common.JKLayout.sp;

import jkiosk3._common.JKNode;
import jkiosk3._common.JKText;
import jkiosk3._components.MessageBox;
import jkiosk3._components.MessageBoxResult;
import jkiosk3.sales.SalesUtil;
import jkiosk3.sales.SceneSales;
import jkiosk3.sales._common.JKioskNav;
import jkiosk3.sales.ticketpro.TicketProBusSale;
import jkiosk3.sales.ticketpro.TicketProUtilBus;
import jkiosk3.users.UserUtil;

public class TicketProBusBook3 extends Region {

    /*
     * View Cart for TicketPro Bus Tickets.
     */
    private final static Logger logger = Logger.getLogger (TicketProBusBook3.class.getName ());
    //
    private final TicketProBusRouteBookResp tpBusRouteBooked;
    private List<TicketProBusSeat> listSeats;
    private GridPane gridSeats;
    private ScrollPane scrollSeats;
    private final static double gridWidth = (JKLayout.contentW - (4 * sp));

    public TicketProBusBook3() {
        this.tpBusRouteBooked = TicketProBusSale.getInstance ().getTicketProBusRouteBooking ();
        this.listSeats = tpBusRouteBooked.getListSeats ();
        StringBuilder sb = new StringBuilder ();
        sb.append ("\r\n").append ("  >>>  Number of seats in booking >>> ").append (tpBusRouteBooked.getQuantity ());
        for (TicketProBusSeat s : listSeats) {
            sb.append ("\r\n").append ("  >>>  seatId (inventoryId) = ").append (s.getInventoryId ());
            sb.append ("\r\n").append ("  >>>  seat price           = ").append (s.getPrice ());
        }
        logger.info (sb.toString ());
        getChildren ().add (getSeatsBookedLayout ());
    }

    private VBox getSeatsBookedLayout() {
        VBox vb = JKLayout.getVBox (0, JKLayout.spNum);
        vb.getChildren ().add (getCartPreviewGrid ());
        vb.getChildren ().add (getNav ());
        return vb;
    }

    private GridPane getCartPreviewGrid() {

        VBox vbHead = JKNode.getPutcoHeader ("Bus Ticket Booking - Step 3");

        String routeCode = TicketProBusSale.getInstance ().getSelectedRouteCode ().getRouteCode ();
        Label lblRoute = JKText.getLblDk (routeCode, JKText.FONT_B_SM);

        String route = listSeats.get (0).getEventName ();
        Text txtRoute = JKText.getTxtDk (route, JKText.FONT_B_XXSM);
        txtRoute.setWrappingWidth (475);
        txtRoute.setTextAlignment (TextAlignment.RIGHT);

        HBox hbRoute = JKLayout.getHBox (0, 0);
        hbRoute.getChildren ().addAll (lblRoute, JKNode.getHSpacer (), txtRoute);

        Button btnClearCart = JKNode.getBtnPopup ("clear\ncart");
        btnClearCart.setOnMouseReleased (new EventHandler () {
            @Override
            public void handle(Event e) {
                removeAllSeatsFromSale ();
            }
        });
        HBox hbClear = JKLayout.getHBox (0, 0);
        hbClear.getChildren ().addAll (JKNode.getHSpacer (), btnClearCart);

        gridSeats = getSeatSummary (listSeats);

        scrollSeats = new ScrollPane ();
        scrollSeats.setMaxSize (JKLayout.contentW - (2 * JKLayout.sp), 395);
        scrollSeats.setMinSize (JKLayout.contentW - (2 * JKLayout.sp), 395);
        scrollSeats.getStyleClass ().add ("scroll-invisible");
        scrollSeats.setContent (gridSeats);

        GridPane grid = JKLayout.getGridContent2Col (0.25, 0.75, HPos.RIGHT);

        grid.add (vbHead, 0, 0, 2, 1);
        grid.add (hbRoute, 0, 1, 2, 1);
        grid.add (hbClear, 1, 2);
        grid.add (JKNode.createGridSpanSep (2), 0, 3, 2, 1);
        grid.add (scrollSeats, 0, 4, 2, 1);

        return grid;
    }

    private JKioskNav getNav() {
        JKioskNav nav = new JKioskNav ();
        nav.getBtnBack ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                removeAllSeatsFromSale ();
                SceneSales.clearAndChangeContent (new TicketProBusBook2 ());
            }
        });
        nav.getBtnCancel ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                UserUtil.resetSalesUser (SalesUtil.SRC_BTN_CANCEL);
                SceneSales.clearAndShowFavourites ();
            }
        });
        nav.getBtnNext ().setOnMouseReleased (new EventHandler<Event> () {
            @Override
            public void handle(Event e) {
                TicketProBusSale.getInstance ().setSelectedBusSeats (listSeats);
                logger.info (("Final number of Seats in Cart = ").concat (Integer.toString (listSeats.size ())));
                if (TicketProBusSale.getInstance ().getSelectedBusSeats ().size () > 0) {
                    SceneSales.clearAndChangeContent (new TicketProBusBook4 ());
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("No Tickets in Cart", "Please use 'back' button to go back and add Tickets", null);
                }
            }
        });
        return nav;
    }

    private GridPane getSeatSummary(List<TicketProBusSeat> seats) {

        Collections.sort (seats, new Comparator<TicketProBusSeat> () {

            @Override
            public int compare(TicketProBusSeat o1, TicketProBusSeat o2) {
                return Double.compare (o1.getPrice (), o2.getPrice ());
            }
        });

        Label lblSeatCat = JKText.getLblDk ("Ticket", JKText.FONT_B_XSM);
        Label lblSeatPrice = JKText.getLblDk ("Seat Price", JKText.FONT_B_XSM);

        GridPane grid = getTicketPriceGrid ();

        grid.addRow (0, lblSeatCat, lblSeatPrice);
        int rowCount = 1;
        double amtDue = 0;

        for (final TicketProBusSeat s : seats) {
            Text txtSeatCat = JKText.getTxtDk (s.getSectionName (), JKText.FONT_B_XXSM);
            txtSeatCat.setWrappingWidth ((gridWidth - (3 * JKLayout.sp)) * 0.50);
            txtSeatCat.setTranslateX (sp);
            Text txtSeatPrice = JKText.getTxtDk (JKText.getDeciFormat (s.getPrice ()), JKText.FONT_B_XXSM);

            Button btnRemove = JKNode.getBtnPopup ("remove");
            btnRemove.setOnMouseReleased (new EventHandler<Event> () {
                @Override
                public void handle(Event e) {
                    removeSeatFromSale (s);
                }
            });
            amtDue += s.getPrice ();
            grid.addRow (rowCount, txtSeatCat, txtSeatPrice, btnRemove);
            rowCount++;
        }

        Label lblAmtDue = JKText.getLblDk ("Total Due", JKText.FONT_B_XSM);
        Text txtTotal = JKText.getTxtDk (JKText.getDeciFormat (amtDue), JKText.FONT_B_SM);
        grid.addRow (rowCount, lblAmtDue, txtTotal);

        return grid;
    }

    private GridPane getTicketPriceGrid() {
        GridPane grid = JKLayout.getContentGridInScroll ();

        double gridGap = (1 * JKLayout.sp);

        ColumnConstraints col0 = new ColumnConstraints ();
        col0.setMaxWidth ((gridWidth - gridGap) * 0.55);
        col0.setMinWidth ((gridWidth - gridGap) * 0.55);
        col0.setHalignment (HPos.LEFT);
        ColumnConstraints col2 = new ColumnConstraints ();
        col2.setMaxWidth ((gridWidth - gridGap) * 0.25);
        col2.setMinWidth ((gridWidth - gridGap) * 0.25);
        col2.setHalignment (HPos.RIGHT);
        ColumnConstraints col3 = new ColumnConstraints ();
        col3.setMaxWidth ((gridWidth - gridGap) * 0.20);
        col3.setMinWidth ((gridWidth - gridGap) * 0.20);
        col3.setHalignment (HPos.RIGHT);

        grid.getColumnConstraints ().addAll (col0, col2, col3);

        return grid;
    }

    private void removeSeatFromSale(TicketProBusSeat seat) {
        logger.info (("Removing seat from cart : ").concat (seat.getInventoryId ()));
        TicketProsCartClearReq req = new TicketProsCartClearReq ();
        req.setCartId (TicketProBusSale.getInstance ().getBusSaleCart ().getCartId ());
        req.setInventoryId (seat.getInventoryId ());
        TicketProUtilBus.clearBusCart (req, new TicketProUtilBus.TicketProBusClearCartResult () {

            @Override
            public void tpClearBusCartResult(TicketProBusCartClearResp tpClearBusCartResp) {
                if (tpClearBusCartResp.isSuccess ()) {
                    updateTicketProBusSale (tpClearBusCartResp);

                    StringBuilder sb = new StringBuilder ();
                    sb.append ("\r\n").append ("Seats remaining in booking after removal");
                    for (TicketProBusSeat s : tpClearBusCartResp.getSeats ()) {
                        sb.append ("\r\n").append (s.getInventoryId ());
                        sb.append ("\r\n").append (s.getPrice ());
                    }
                    sb.append ("\r\n").append ("- - - - - - - - - - - - - - - - - - -");
                    logger.info (sb.toString ());
                    listSeats = tpClearBusCartResp.getSeats ();
                    if (listSeats.size () > 0) {
                        TicketProBusSale.getInstance ().setSelectedBusSeats (listSeats);
                    } else {
                        TicketProBusSale.getInstance ().setSelectedBusSeats (null);
                    }

                    scrollSeats.setContent (null);
                    gridSeats = getSeatSummary (listSeats);
                    scrollSeats.setContent (gridSeats);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Putco Error", !tpClearBusCartResp.getAeonErrorText ().isEmpty () ?
                                    "A" + tpClearBusCartResp.getAeonErrorCode () + " - " + tpClearBusCartResp.getAeonErrorText () :
                                    "B" + tpClearBusCartResp.getErrorCode () + " - " + tpClearBusCartResp.getErrorText ()
                                            + "\n\nClick 'OK' to return to current view, or 'Cancel' to cancel booking and return to start.",
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    // what to do if seat cannot be removed
                                }

                                @Override
                                public void onCancel() {
                                    SceneSales.clearAndChangeContent (new TicketProBusBook1 ());
                                }
                            });
                }
            }
        });
    }

    private void removeAllSeatsFromSale() {
        TicketProsCartClearReq req = new TicketProsCartClearReq ();
        req.setCartId (TicketProBusSale.getInstance ().getBusSaleCart ().getCartId ());
        req.setInventoryId ("");
        TicketProUtilBus.clearBusCart (req, new TicketProUtilBus.TicketProBusClearCartResult () {

            @Override
            public void tpClearBusCartResult(TicketProBusCartClearResp tpClearBusCartResp) {
                if (tpClearBusCartResp.isSuccess ()) {
                    updateTicketProBusSale (tpClearBusCartResp);

                    listSeats = tpClearBusCartResp.getSeats ();
                    if (listSeats.size () > 0) {
                        TicketProBusSale.getInstance ().setSelectedBusSeats (listSeats);
                    } else {
                        TicketProBusSale.getInstance ().setSelectedBusSeats (null);
                    }

                    scrollSeats.setContent (null);
                    gridSeats = getSeatSummary (listSeats);
                    scrollSeats.setContent (gridSeats);
                } else {
                    JKiosk3.getMsgBox ().showMsgBox ("Putco Error", !tpClearBusCartResp.getAeonErrorText ().isEmpty () ?
                                    "A" + tpClearBusCartResp.getAeonErrorCode () + " - " + tpClearBusCartResp.getAeonErrorText () :
                                    "B" + tpClearBusCartResp.getErrorCode () + " - " + tpClearBusCartResp.getErrorText ()
                                            + "\n\nClick 'OK' to return to current view, or 'Cancel' to cancel booking and return to start.",
                            null, MessageBox.CONTROLS_SHOW, MessageBox.MSG_OK, new MessageBoxResult () {

                                @Override
                                public void onOk() {
                                    // what to do if cart cannot be cleared
                                }

                                @Override
                                public void onCancel() {
                                    SceneSales.clearAndChangeContent (new TicketProBusBook1 ());
                                }
                            });
                }
            }
        });
    }

    private void updateTicketProBusSale(TicketProBusCartClearResp cartResp) {
        TicketProBusRouteBookResp tpBooking = new TicketProBusRouteBookResp ();
        tpBooking.setCartId (cartResp.getCartId ());
        tpBooking.setQuantity (cartResp.getQuantity ());
        int count = cartResp.getSeats ().size ();
        for (int i = 0; i < count; i++) {
            TicketProBusSeat seat = new TicketProBusSeat ();
            seat.setInventoryId (cartResp.getSeats ().get (i).getInventoryId ());
            seat.setRouteId (cartResp.getSeats ().get (i).getRouteId ());
            seat.setEventName (cartResp.getSeats ().get (i).getEventName ());
            seat.setStartDate (cartResp.getSeats ().get (i).getStartDate ());
            seat.setStartTime (cartResp.getSeats ().get (i).getStartTime ());
            seat.setVenue (cartResp.getSeats ().get (i).getVenue ());
            seat.setSectionName (cartResp.getSeats ().get (i).getSectionName ());
            seat.setSectionId (cartResp.getSeats ().get (i).getSectionId ());
            seat.setPrice (cartResp.getSeats ().get (i).getPrice ());
            tpBooking.getListSeats ().add (seat);
        }
        TicketProBusSale.getInstance ().setTicketProBusRouteBooking (tpBooking);
    }
}
