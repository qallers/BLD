
# react-native-device-lib-nfc

## Installing the library
Add the Device library to your package.json dependencies as follows:
```json
"dependencies": {
    "react-native-device-lib-nfc": "git+https://gitlab.qa.bltelecoms.net/digital-mobile/rndevicelibnfc.git",
},
```
The above will pull the latest version from the master branch.  

Then run "npm install" in your project root folder to download and install the library into your node_modules folder.

You can then import the library into your project as follows:
```javascript
import {DeviceLibNfc} from "react-native-device-lib-nfc";
````

# NFC

## Initialize
Initializes the NFC service.  This method must be executed to make use of NFC hardware.  
Note also that the service must also be terminated, so that the hardware is released and can be reused. 
```javascript
DeviceLibNfc.nfcInit();
```

## Read Card UID
Read the 4-byte card UID in hex format
```javascript
DeviceLibNfc.nfcReadUid()
	.then(jsonResponse => console.log('Success: ' + jsonResponse))
	.catch(jsonResponse => console.log('Error: ' + jsonResponse));
```
Response format
```json
{
  "status": "SUCCESS" //or "INVALID_CARD", "INVALID_COMMAND", "ERROR",
  "operation": "UID",
  "card": {
    "uid": "DC6C8DC4",  //4-byte hex
    "sectors": [],
    "blocks": []
  }
}
```

## Check Card
Checks if the auth key provided allows authentication to the specified sectors

```javascript
DeviceLibNfc.nfcCheckCard(jsonCommandString)
	.then(jsonResponse => console.log('Success: ' + jsonResponse))
	.catch(jsonResponse => console.log('Error: ' + jsonResponse));
```
Command format
```json
{
  "uid": "", //if uid is specified, the tapped card must match, or INVALID_CARD is returned
  "key": {  //specify the key details to check the card against
    "index": "A",
    "value": "FFFFFFFFFFFF"  //6-byte hex
  },
  "sectors": [ //specify list of sectors that need to be checked
    0,
    1,
    2,
  ]
}
```
Response format
```json
{
  "status": "SUCCESS",
  "operation": "CHECK",
  "card": {
    "uid": "DC6C8DC4",
    "sectors": [0, 1, 2],
    "blocks": []
  }
}
```

## Read Card
Reads the data from the specified blocks, using the auth key provided

```javascript
DeviceLibNfc.nfcReadCard(jsonCommandString)
	.then(jsonResponse => console.log('Success: ' + jsonResponse))
	.catch(jsonResponse => console.log('Error: ' + jsonResponse));
```
Command format
```json
{
  "uid": "",
  "key": { 
    "index": "A",
    "value": "FFFFFFFFFFFF"
  },
  "blocks": [ //specify list of blocks to be read
    0,
    1,
    2,
  ]
}
```
Response format
```json
{
  "status": "SUCCESS",
  "operation": "READ",
  "card": {
    "uid": "DC6C8DC4",
    "sectors": [],
    "blocks": [{
      "num": 0, //block number
      "data": "DC6C8DC4F908040002B1189F866E601D" //16-byte hex value
    }, {
      "num": 1,
      "data": "00000000000000000000000000000000"
    }, {
      "num": 2,
      "data": "00000000000000000000000000000000"
    }]
  }
}
```

## Write Card
Writes the data provided to the specified blocks, using the auth key provided

```javascript
DeviceLibNfc.nfcWriteCard(jsonCommandString)
	.then(jsonResponse => console.log('Success: ' + jsonResponse))
	.catch(jsonResponse => console.log('Error: ' + jsonResponse));
```
Command format
```json
{
  "uid": "",
  "key": {
    "index": "A",
    "value": "FFFFFFFFFFFF"
  },
  "blocks": [ //specify list of blocks to write to and provide the value to write
    {
      "num": 1,
      "value": "00112233445566778899AABBCCDDEEFF" //16-byte hex
    },
    {
      "num": 2,
      "value": "00112233445566778899AABBCCDDEEFF"
    }
  ]
}
```
Response format
```json
{
  "status": "SUCCESS",
  "operation": "WRITE",
  "card": {
    "uid": "DC6C8DC4",
    "sectors": [],
    "blocks": [{
      "num": 1,
      "data": "00112233445566778899AABBCCDDEEFF"
    }, {
      "num": 2,
      "data": "00112233445566778899AABBCCDDEEFF"
    }]
  }
}
```

## Format Card
Configures the trailer blocks of the specified sectors, according to the key A, key B and access bits provided.
Optionally will also write zeros to all the blocks specified to clear existing data.

```javascript
DeviceLibNfc.nfcFormatCard(jsonCommandString)
	.then(jsonResponse => console.log('Success: ' + jsonResponse))
	.catch(jsonResponse => console.log('Error: ' + jsonResponse));
```
Command format
```json
{
  "uid": "",
  "key": { //the key that these sectors are currently formatted with 
    "index": "A",
    "value": "FFFFFFFFFFFF"
  },
  "format": { //the configuration that the sectors should be formatted to
    "keyA": "f5f4d4db4c13",
    "keyB": "9ccd9ba37681",
    "access": "78778800"
  },
  "sectors": [ //the list of sectors to format
    0,
    1,
    2
  ]
}
```
Response format
```json
{
  "status": "SUCCESS",
  "operation": "FORMAT",
  "card": {
    "uid": "DC6C8DC4",
    "sectors": [],
    "blocks": []
  }
}
```

## Cancel Card Operation
Cancels any card operation pending or currently in progress. 
```javascript
DeviceLibNfc.nfcCancel();
```

## Terminate
Terminates the NFC service  
```javascript
DeviceLibNfc.nfcTerminate();
```
