import {NativeModules} from 'react-native';

const {RNDeviceLibNfc} = NativeModules;

export default RNDeviceLibNfc;

export class DeviceLibNfc {

    static nfcInit() {
        return RNDeviceLibNfc.nfcInit();
    }

    static async nfcReadUid() {
        return RNDeviceLibNfc.nfcReadUid();
    }

    static async nfcCheckCard(jsonString) {
        return RNDeviceLibNfc.nfcCheckCard(jsonString);
    }

    static async nfcReadCard(jsonString) {
        return RNDeviceLibNfc.nfcReadCard(jsonString)
    }

    static async nfcWriteCard(jsonString) {
        return RNDeviceLibNfc.nfcWriteCard(jsonString)
    }

    static async nfcFormatCard(jsonString) {
        return RNDeviceLibNfc.nfcFormatCard(jsonString)
    }

    static nfcCancel() {
        return RNDeviceLibNfc.nfcCancel();
    }

    static nfcTerminate() {
        return RNDeviceLibNfc.nfcTerminate();
    }

}
