export class DeviceLibNfc {

    static nfcInit(): void;

    static nfcReadUid(): Promise<{ result: any }>;

    static nfcCheckCard(jsonString: string): Promise<{ result: any }>;

    static nfcReadCard(jsonString: string): Promise<{ result: any }>;

    static nfcWriteCard(jsonString: string): Promise<{ result: any }>;

    static nfcFormatCard(jsonString: string): Promise<{ result: any }>;

    static nfcCancel(): void;

    static nfcTerminate(): void;

}
