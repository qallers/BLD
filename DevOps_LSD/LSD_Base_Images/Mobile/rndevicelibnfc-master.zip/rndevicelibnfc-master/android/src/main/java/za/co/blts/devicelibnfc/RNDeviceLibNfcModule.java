package za.co.blts.devicelibnfc;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import za.co.blts.devicelibnfc.nfc.NfcCitaq;
import za.co.blts.devicelibnfc.nfc.NfcNexgo;
import za.co.blts.devicelibnfc.nfc.NfcResult;
import za.co.blts.devicelibnfc.nfc.NfcResultable;
import za.co.blts.devicelibnfc.nfc.NfcSunmi;
import za.co.blts.devicelibnfc.nfc.NfcTappable;

public class RNDeviceLibNfcModule extends ReactContextBaseJavaModule implements NfcResultable {
    private final String TAG = this.getClass().getSimpleName();

    private final ReactApplicationContext reactContext;
    public static final String ERROR = "ERROR";

    private NfcTappable tappable;
    private Promise currentPromise;

    public RNDeviceLibNfcModule(ReactApplicationContext reactContext) {
        super(reactContext);
        this.reactContext = reactContext;

        if (Build.MODEL.startsWith("P1")) {
            tappable = new NfcSunmi(this);
        } else if (Build.MODEL.startsWith("N3")) {
            tappable = new NfcNexgo(this);
        } else if (Build.MODEL.startsWith("CITAQ")) {
            tappable = new NfcCitaq(this);
        }

    }

    public Context getContext(){
        return reactContext;
    }

    @Override
    public String getName() {
        return "RNDeviceLibNfc";
    }

    @Override
    public Map<String, Object> getConstants() {
        return new HashMap<>();
    }

    @ReactMethod
    public void nfcInit() {
        if (tappable != null) {
            tappable.init();
        }
    }

    @ReactMethod
    public void nfcReadUid(Promise promise) {
        try {
            if (tappable != null) {
                currentPromise = promise;
                tappable.readUid();
            } else {
                promise.reject(ERROR, "NFC not supported");
            }
        } catch (Exception e) {
            promise.reject(ERROR, e);
        }
    }

    @ReactMethod
    public void nfcCheckCard(String jsonCheck, Promise promise) {
        try {
            if (tappable != null) {
                currentPromise = promise;
                JSONObject instr = new JSONObject(jsonCheck);
                tappable.checkCard(instr);
            } else {
                promise.reject(ERROR, "NFC not supported");
            }
        } catch (Exception e) {
            promise.reject(ERROR, e);
        }
    }

    @ReactMethod
    public void nfcReadCard(String jsonRead, Promise promise) {
        try {
            if (tappable != null) {
                currentPromise = promise;
                JSONObject instr = new JSONObject(jsonRead);
                tappable.readCard(instr);
            } else {
                promise.reject(ERROR, "NFC not supported");
            }
        } catch (Exception e) {
            promise.reject(ERROR, e);
        }
    }

    @ReactMethod
    public void nfcWriteCard(String jsonWrite, Promise promise) {
        try {
            if (tappable != null) {
                currentPromise = promise;
                JSONObject instr = new JSONObject(jsonWrite);
                tappable.writeCard(instr);
            } else {
                promise.reject(ERROR, "NFC not supported");
            }
        } catch (Exception e) {
            promise.reject(ERROR, e);
        }
    }

    @ReactMethod
    public void nfcFormatCard(String jsonFormat, Promise promise) {
        try {
            if (tappable != null) {
                currentPromise = promise;
                JSONObject instr = new JSONObject(jsonFormat);
                tappable.formatCard(instr);
            } else {
                promise.reject(ERROR, "NFC not supported");
            }
        } catch (Exception e) {
            promise.reject(ERROR, e);
        }
    }

    @ReactMethod
    public void nfcCancel() {
        if (tappable != null){
            tappable.cancel();
        }
    }

    @ReactMethod
    public void nfcTerminate() {
        if (tappable != null){
            tappable.terminate();
        }
    }

    @Override
    public void handleNfcResult(NfcResult result) {
        if (currentPromise != null) {
            try {
                WritableMap resultMap = Utils.convertJsonToMap(new JSONObject(new Gson().toJson(result)));
                currentPromise.resolve(resultMap);
            } catch (Exception e){
                e.printStackTrace();
            }
        } else {
            Log.e(TAG, "currentPromise is null");
        }
    }
}
