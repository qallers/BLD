package za.co.blts.devicelibnfc.nfc;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.AsyncTask;
import android.util.Log;

import com.acs.smartcard.Reader;

import org.json.JSONObject;

import java.util.Locale;

import za.co.blts.devicelibnfc.Utils;

import static za.co.blts.devicelibnfc.nfc.NfcTappable.NfcStatus.ERROR;
import static za.co.blts.devicelibnfc.nfc.NfcTappable.NfcStatus.INVALID_CARD;
import static za.co.blts.devicelibnfc.nfc.NfcTappable.NfcStatus.INVALID_COMMAND;
import static za.co.blts.devicelibnfc.nfc.NfcTappable.NfcStatus.SUCCESS;

public class NfcCitaq implements NfcTappable {

    private final static String TAG = NfcCitaq.class.getSimpleName();
    private static final String ACTION_USB_PERMISSION = "za.co.nfclib.USB_PERMISSION";
    private static final boolean LOGGING = true;

    private final int KEY_NUMBER = 1;

    private static NfcCitaq instance;
    private static NfcResultable resultable;
    private static NfcCommand command;
    private JSONObject instruction;
    private String intendedCard;

    private UsbManager usbManager;
    private static Reader reader;
    private String deviceName;

    private String keyToUse;
    private boolean useKeyB;

    private String keyA, keyB, access;

    private NfcResult result;
    private int index, lastSectorAuthed;
    private boolean formatHasBlocks;

    private long operationStart;

    public NfcCitaq(NfcResultable resultable) {
        NfcCitaq.resultable = resultable;
        instance = this;
    }

    @Override
    public void init() {
        usbManager = (UsbManager) resultable.getContext().getSystemService(Context.USB_SERVICE);
        reader = new Reader(usbManager);
    }

    @Override
    public void readUid() {
        operationStart = System.currentTimeMillis();
        result = new NfcResult();
        result.setOperation(NfcOperation.UID);
        openReader();
    }

    @Override
    public void checkCard(JSONObject readInstr) {
        operationStart = System.currentTimeMillis();
        result = new NfcResult();
        result.setOperation(NfcOperation.CHECK);
        instruction = readInstr;
        try {
            keyToUse = readInstr.getJSONObject("key").getString("value");
            useKeyB = readInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            intendedCard = readInstr.getString("uid");
            openReader();
        } catch (Exception e) {
            result.setStatus(INVALID_COMMAND);
            returnResult();
        }
    }

    @Override
    public void readCard(JSONObject readInstr) {
        operationStart = System.currentTimeMillis();
        result = new NfcResult();
        result.setOperation(NfcOperation.READ);
        instruction = readInstr;
        try {
            keyToUse = readInstr.getJSONObject("key").getString("value");
            useKeyB = readInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            intendedCard = readInstr.getString("uid");
            openReader();
        } catch (Exception e) {
            result.setStatus(INVALID_COMMAND);
            returnResult();
        }
    }

    @Override
    public void writeCard(JSONObject writeInstr) {
        operationStart = System.currentTimeMillis();
        result = new NfcResult();
        result.setOperation(NfcOperation.WRITE);
        instruction = writeInstr;
        try {
            keyToUse = writeInstr.getJSONObject("key").getString("value");
            useKeyB = writeInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            intendedCard = writeInstr.getString("uid");
            openReader();
        } catch (Exception e) {
            result.setStatus(INVALID_COMMAND);
            returnResult();
        }
    }

    @Override
    public void formatCard(JSONObject writeInstr) {
        operationStart = System.currentTimeMillis();
        result = new NfcResult();
        result.setOperation(NfcOperation.FORMAT);
        instruction = writeInstr;
        try {
            keyToUse = writeInstr.getJSONObject("key").getString("value");
            useKeyB = writeInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            keyA = writeInstr.getJSONObject("format").getString("keyA");
            keyB = writeInstr.getJSONObject("format").getString("keyB");
            access = writeInstr.getJSONObject("format").getString("access");
            intendedCard = writeInstr.getString("uid");
            formatHasBlocks = writeInstr.has("blocks");
            openReader();
        } catch (Exception e) {
            result.setStatus(INVALID_COMMAND);
            returnResult();
        }
    }

    @Override
    public void cancel() {
        try {
            Log.d(TAG, "Closing reader...");
            reader.setOnStateChangeListener(null);
            resultable.getContext().unregisterReceiver(mReceiver);
            new NfcCitaq.CloseTask().execute();
        } catch (Exception ex) {
            Log.d(TAG, "closeReader: " + ex.getMessage());
        }
    }

    @Override
    public void terminate() {
        try {
            Log.d(TAG, "Closing reader...");
            reader.setOnStateChangeListener(null);
            resultable.getContext().unregisterReceiver(mReceiver);
            new NfcCitaq.CloseTask().execute();
        } catch (Exception ex) {
            Log.d(TAG, "closeReader: " + ex.getMessage());
        }
    }

    private void onResult(String response) {
        switch (result.getOperation()) {
            case UID:
                result.setStatus(SUCCESS);
                returnResult();
                break;

            case CHECK:
                handleCheckResult(response);
                break;

            case READ:
                handleReadResult(response);
                break;

            case WRITE:
                handleWriteResult(response);
                break;

            case FORMAT:
                if (formatHasBlocks) {
                    handleFormatResultToClear(response);
                } else {
                    handleFormatResult(response);
                }
                break;
        }
    }

    private void handleCheckResult(String response) {
        try {
            if (command == NfcCommand.READ_UID) {
                if (intendedCard.isEmpty() || intendedCard.equalsIgnoreCase(result.getCard().getUid())) {
                    index = 0;
                    loadKey(keyToUse, KEY_NUMBER);
                } else {
                    result.setStatus(INVALID_CARD);
                    returnResult();
                }
            } else if (command == NfcCommand.LOAD_KEY && response.equals("9000")) {
                int sector = ((int) instruction.getJSONArray("sectors").get(index));
                result.setStatus(SUCCESS);
                authToSector(sector, KEY_NUMBER, useKeyB);
            } else if (command == NfcCommand.AUTH) {
                if (response.equals("9000")) {
                    int sector = ((int) instruction.getJSONArray("sectors").get(index));
                    result.getCard().getSectors().add(sector);
                } else {
                    result.setStatus(ERROR);
                }
                int numSectors = instruction.getJSONArray("sectors").length();
                if (++index < numSectors) {
                    authToSector(((int) instruction.getJSONArray("sectors").get(index)), 0, useKeyB);
                } else {
                    returnResult();
                }
            } else {
                result.setStatus(ERROR);
                returnResult();
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.setStatus(ERROR);
            returnResult();
        }
    }

    private void handleReadResult(String response) {
        try {
            if (command == NfcCommand.READ_UID) {
                if (intendedCard.isEmpty() || intendedCard.equalsIgnoreCase(result.getCard().getUid())) {
                    index = 0;
                    loadKey(keyToUse, KEY_NUMBER);
                } else {
                    result.setStatus(INVALID_CARD);
                    returnResult();
                }
            } else if (command == NfcCommand.LOAD_KEY && response.equals("9000")) {
                int block = (int) instruction.getJSONArray("blocks").get(index);
                lastSectorAuthed = block / 4;
                authToSector(lastSectorAuthed, KEY_NUMBER, useKeyB);
            } else if (command == NfcCommand.AUTH && response.equals("9000")) {
                int block = (int) instruction.getJSONArray("blocks").get(index);
                readDataBlock(block);
            } else if (command == NfcCommand.READ) {
                String readResult = response.length() > 3 ? response.substring(response.length() - 4) : "";
                if (readResult.equals("9000")) {
                    int block = (int) instruction.getJSONArray("blocks").get(index);
                    int numBlocks = (int) instruction.getJSONArray("blocks").length();
                    NfcBlock nfcblock = new NfcBlock(block, response.substring(0, response.length() - 4));
                    result.getCard().getBlocks().add(nfcblock);
                    if (++index < numBlocks) {
                        block = (int) instruction.getJSONArray("blocks").get(index);
                        if (lastSectorAuthed == block / 4) {
                            readDataBlock(block);
                        } else {
                            lastSectorAuthed = block / 4;
                            authToSector(lastSectorAuthed, KEY_NUMBER, useKeyB);
                        }
                    } else {
                        result.setStatus(SUCCESS);
                        returnResult();
                    }
                } else {
                    result.setStatus(ERROR);
                    returnResult();
                }
            } else {
                result.setStatus(ERROR);
                returnResult();
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.setStatus(ERROR);
            returnResult();
        }
    }

    private void handleWriteResult(String response) {
        try {
            if (command == NfcCommand.READ_UID) {
                if (intendedCard.isEmpty() || intendedCard.equalsIgnoreCase(result.getCard().getUid())) {
                    index = 0;
                    loadKey(keyToUse, KEY_NUMBER);
                } else {
                    result.setStatus(INVALID_CARD);
                    returnResult();
                }
            } else if (command == NfcCommand.LOAD_KEY && response.equals("9000")) {
                int block = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getInt("num");
                lastSectorAuthed = block / 4;
                authToSector(lastSectorAuthed, KEY_NUMBER, useKeyB);
            } else if (command == NfcCommand.AUTH && response.equals("9000")) {
                int block = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getInt("num");
                String data = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getString("value");
                writeDataBlock(block, data);
            } else if (command == NfcCommand.WRITE && response.equals("9000")) {
                int block = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getInt("num");
                String data = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getString("value");
                int numBlocks = (int) instruction.getJSONArray("blocks").length();
                NfcBlock nfcblock = new NfcBlock(block, data);
                result.getCard().getBlocks().add(nfcblock);
                if (++index < numBlocks) {
                    block = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getInt("num");
                    data = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getString("value");
                    if (lastSectorAuthed == block / 4) {
                        writeDataBlock(block, data);
                    } else {
                        lastSectorAuthed = block / 4;
                        authToSector(lastSectorAuthed, KEY_NUMBER, useKeyB);
                    }
                } else {
                    result.setStatus(SUCCESS);
                    returnResult();
                }
            } else {
                result.setStatus(ERROR);
                returnResult();
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.setStatus(ERROR);
            returnResult();
        }
    }

    private void handleFormatResultToClear(String response) {
        try {
            if (command == NfcCommand.READ_UID) {
                if (intendedCard.isEmpty() || intendedCard.equalsIgnoreCase(result.getCard().getUid())) {
                    index = 0;
                    loadKey(keyToUse, KEY_NUMBER);
                } else {
                    result.setStatus(INVALID_CARD);
                    returnResult();
                }
            } else if (command == NfcCommand.LOAD_KEY && response.equals("9000")) {
                int block = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getInt("num");
                lastSectorAuthed = block / 4;
                authToSector(lastSectorAuthed, KEY_NUMBER, useKeyB);
            } else if (command == NfcCommand.AUTH && response.equals("9000")) {
                int block = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getInt("num");
                String data = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getString("value");
                writeDataBlock(block, data);
            } else if (command == NfcCommand.WRITE && response.equals("9000")) {
                int numBlocks = (int) instruction.getJSONArray("blocks").length();
                if (++index < numBlocks) {
                    int block = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getInt("num");
                    String data = ((JSONObject) instruction.getJSONArray("blocks").get(index)).getString("value");
                    if (lastSectorAuthed == block / 4) {
                        writeDataBlock(block, data);
                    } else {
                        lastSectorAuthed = block / 4;
                        authToSector(lastSectorAuthed, KEY_NUMBER, useKeyB);
                    }
                } else {
                    formatHasBlocks = false;
                    index = 0;
                    lastSectorAuthed = ((int) instruction.getJSONArray("sectors").get(index));
                    authToSector(lastSectorAuthed, KEY_NUMBER, useKeyB);
                }
            } else {
                result.setStatus(ERROR);
                returnResult();
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.setStatus(ERROR);
            returnResult();
        }
    }

    private void handleFormatResult(String response) {
        try {
            if (command == NfcCommand.READ_UID) {
                if (intendedCard.isEmpty() || intendedCard.equalsIgnoreCase(result.getCard().getUid())) {
                    index = 0;
                    loadKey(keyToUse, KEY_NUMBER);
                } else {
                    result.setStatus(INVALID_CARD);
                    returnResult();
                }
            } else if (command == NfcCommand.LOAD_KEY && response.equals("9000")) {
                lastSectorAuthed = ((int) instruction.getJSONArray("sectors").get(index));
                authToSector(lastSectorAuthed, KEY_NUMBER, useKeyB);
            } else if (command == NfcCommand.AUTH && response.equals("9000")) {
                writeDataBlock(lastSectorAuthed * 4 + 3, keyA + access + keyB);
            } else if (command == NfcCommand.WRITE && response.equals("9000")) {
                int numSectors = instruction.getJSONArray("sectors").length();
                if (++index < numSectors) {
                    int sector = ((int) instruction.getJSONArray("sectors").get(index));
                    if (lastSectorAuthed == sector) {
                        writeDataBlock(lastSectorAuthed * 4 + 3, keyA + access + keyB);
                    } else {
                        lastSectorAuthed = sector;
                        authToSector(lastSectorAuthed, KEY_NUMBER, useKeyB);
                    }
                } else {
                    result.setStatus(SUCCESS);
                    returnResult();
                }
            } else {
                result.setStatus(ERROR);
                returnResult();
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.setStatus(ERROR);
            returnResult();
        }
    }

    private void returnResult() {
        long operationDuration = System.currentTimeMillis() - operationStart;
        Log.v(TAG, ">>>>> operation took " + operationDuration + "ms");
        resultable.handleNfcResult(result);
        cancel();
    }

    public void startListener() {
        reader.setOnStateChangeListener(new Reader.OnStateChangeListener() {
            @Override
            public void onStateChange(int slotNum, int prevState, int currState) {
                if (currState == Reader.CARD_PRESENT) {
                    Log.d(TAG, "card presented");
                    resetCard();
                }
            }
        });
    }

    public void openReader() {
        // Register receiver for USB permission
        PendingIntent permissionIntent = PendingIntent.getBroadcast(resultable.getContext(), 0, new Intent(ACTION_USB_PERMISSION), 0);
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_USB_PERMISSION);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        resultable.getContext().registerReceiver(mReceiver, filter);

        for (UsbDevice device : usbManager.getDeviceList().values()) {
            if (reader.isSupported(device)) {
                deviceName = device.getDeviceName();
                break;
            }
        }

        if (deviceName == null) {
            Log.i(TAG, "Error - no nfc device connected");
        }

        try {
            deviceName = null;
            for (UsbDevice device : usbManager.getDeviceList().values()) {
                if (reader.isSupported(device)) {
                    deviceName = device.getDeviceName();
                    break;
                }
            }
            boolean requested = false;
            if (deviceName != null) {
                // For each device
                for (UsbDevice device : usbManager.getDeviceList().values()) {
                    // If device name is found
                    if (deviceName.equals(device.getDeviceName())) {
                        // Request permission
                        Log.d(TAG, "Requesting USB permission");
                        usbManager.requestPermission(device, permissionIntent);
                        requested = true;
                        break;
                    }
                }
            }

            if (!requested) {
                Log.i(TAG, "Could not find device to open");
                result.setStatus(ERROR);
                returnResult();
            }

        } catch (Exception ex) {
            Log.d(TAG, "openReader: " + ex.getMessage());
        }
    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                Log.d(TAG, "USB permission receiver");
                synchronized (this) {
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (device != null) {
                            // Open reader
                            Log.d(TAG, "Opening reader: " + device.getDeviceName() + "...");
                            new OpenTask().execute(device);
                        }
                    } else {
                        Log.d(TAG, "Permission denied for device " + device.getDeviceName());
                        result.setStatus(ERROR);
                        returnResult();
                    }
                }

            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {

                synchronized (this) {
                    // Update reader list
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (device != null && device.equals(reader.getDevice())) {
                        // Close reader
                        Log.d(TAG, "Closing reader...");
                        new CloseTask().execute();
                    }
                }
            }
        }
    };

    private static class OpenTask extends AsyncTask<UsbDevice, Void, Exception> {

        @Override
        protected Exception doInBackground(UsbDevice... params) {
            Exception result = null;
            try {
                reader.open(params[0]);
            } catch (Exception e) {
                result = e;
            }
            return result;
        }

        @Override
        protected void onPostExecute(Exception result) {
            if (result != null) {
                Log.d(TAG, result.toString());
                instance.result.setStatus(ERROR);
                instance.returnResult();
            } else {
                if (LOGGING) Log.d(TAG, "Reader name: " + reader.getReaderName());
                int numSlots = reader.getNumSlots();
                if (LOGGING) Log.d(TAG, "Number of slots: " + numSlots);
//                delegate.onReady();
                instance.startListener();
            }
        }
    }

    private static class CloseTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {
            reader.close();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
        }
    }

    private static class PowerTask extends AsyncTask<PowerParams, Void, PowerResult> {

        @Override
        protected PowerResult doInBackground(PowerParams... params) {
            PowerResult result = new PowerResult();
            try {
                result.atr = reader.power(0, Reader.CARD_WARM_RESET);
            } catch (Exception e) {
                result.e = e;
            }
            return result;
        }

        @Override
        protected void onPostExecute(PowerResult result) {
            if (result.e != null) {
                Log.e(TAG, result.e.toString());
                instance.result.setStatus(ERROR);
                instance.returnResult();
            } else {
                // Show ATR
                if (result.atr != null) {
                    if (LOGGING) Log.d(TAG, "ATR:" + Utils.bytesToHex(result.atr));
                    setProtocol();
                } else {
                    if (LOGGING) Log.d(TAG, "ATR: None");
                }
            }
        }
    }

    private static class SetProtocolTask extends AsyncTask<SetProtocolParams, Void, SetProtocolResult> {

        @Override
        protected SetProtocolResult doInBackground(SetProtocolParams... params) {
            SetProtocolResult result = new SetProtocolResult();
            try {
                result.activeProtocol = reader.setProtocol(0, Reader.PROTOCOL_T0 | Reader.PROTOCOL_T1);
            } catch (Exception e) {
                result.e = e;
            }
            return result;
        }

        @Override
        protected void onPostExecute(SetProtocolResult result) {
            if (result.e != null) {
                Log.e(TAG, result.e.toString());
                instance.result.setStatus(ERROR);
                instance.returnResult();
            } else {
                String activeProtocolString = "Active Protocol: ";
                switch (result.activeProtocol) {
                    case Reader.PROTOCOL_T0:
                        activeProtocolString += "T=0";
                        break;
                    case Reader.PROTOCOL_T1:
                        activeProtocolString += "T=1";
                        break;
                    default:
                        activeProtocolString += "Unknown";
                        break;
                }
                // Show active protocol
                if (LOGGING) Log.d(TAG, activeProtocolString);
                readCardUid();
            }
        }
    }

    private static class TransmitTask extends AsyncTask<TransmitParams, TransmitProgress, Void> {

        @Override
        protected Void doInBackground(TransmitParams... params) {
            TransmitProgress progress;
            byte[] command;
            byte[] response;
            int responseLength;
            int foundIndex;
            int startIndex = 0;

            do {
                // Find carriage return
                foundIndex = params[0].commandString.indexOf('\n', startIndex);
                if (foundIndex >= 0) {
                    command = Utils.hexToBytes(params[0].commandString.substring(startIndex, foundIndex));
                } else {
                    command = Utils.hexToBytes(params[0].commandString.substring(startIndex));
                }

                // Set next start index
                startIndex = foundIndex + 1;
                response = new byte[300];
                progress = new TransmitProgress();
                progress.controlCode = params[0].controlCode;
                try {

                    if (params[0].controlCode < 0) {
                        // Transmit APDU
                        responseLength = reader.transmit(params[0].slotNum, command, command.length, response, response.length);

                    } else {
                        // Transmit control command
                        responseLength = reader.control(params[0].slotNum, params[0].controlCode, command, command.length, response, response.length);
                    }
                    progress.command = command;
                    progress.commandLength = command.length;
                    progress.response = response;
                    progress.responseLength = responseLength;
                    progress.e = null;
                } catch (Exception e) {
                    progress.command = null;
                    progress.commandLength = 0;
                    progress.response = null;
                    progress.responseLength = 0;
                    progress.e = e;
                }
                publishProgress(progress);
            } while (foundIndex >= 0);
            return null;
        }

        @Override
        protected void onProgressUpdate(final TransmitProgress... progress) {
            if (progress[0].e != null) {
                Log.i(TAG, progress[0].e.toString());
                instance.result.setStatus(ERROR);
                instance.returnResult();
            } else {
                if (LOGGING)
                    Log.d(TAG, "Command: " + Utils.bytesToHex(progress[0].command, progress[0].commandLength));
                if (LOGGING)
                    Log.d(TAG, "Response: " + Utils.bytesToHex(progress[0].response, progress[0].responseLength));
                if (command == NfcCommand.READ_UID) {
                    instance.result.getCard().setUid(Utils.bytesToHex(progress[0].response, 4));
                }

                instance.onResult(Utils.bytesToHex(progress[0].response, progress[0].responseLength));
            }
        }
    }

    private void resetCard() {
        if (LOGGING) Log.d(TAG, "Slot 0: Warm Reset...");
        new PowerTask().execute();
    }

    private static void setProtocol() {
        // Set protocol
        if (LOGGING) Log.d(TAG, "Slot 0: Setting protocol to T0/T1...");
        new SetProtocolTask().execute();
    }

    private static void readCardUid() {
        command = NfcCommand.READ_UID;
        if (LOGGING) Log.d(TAG, "Slot 0: Get Card UID...");
        // Get slot number
        int slotNum = 0;

        // Set parameters
        TransmitParams params = new TransmitParams();
        params.slotNum = slotNum;
        params.controlCode = -1;
        params.commandString = "FFCA000000";
        // Transmit APDU
        if (LOGGING) Log.d(TAG, "Slot " + slotNum + ": Transmitting APDU...");
        new TransmitTask().execute(params);
    }

    private static void loadKey(String key, int keyNumber) {
        command = NfcCommand.LOAD_KEY;
        if (LOGGING) Log.d(TAG, "Slot 0: Load key " + keyNumber + "...");
        // Get slot number
        int slotNum = 0;

        // Set parameters
        TransmitParams params = new TransmitParams();
        params.slotNum = slotNum;
        params.controlCode = -1;
        params.commandString = "FF8200"
                + String.format(Locale.US, "%02d", keyNumber)
                + "06"
                + key;
        // Transmit APDU
        if (LOGGING) Log.d(TAG, "Slot " + slotNum + ": Transmitting APDU...");
        new TransmitTask().execute(params);
    }

    private static void authToSector(int sector, int keyNumber, boolean useKeyB) {
        int block = sector * 4 + 3;
        command = NfcCommand.AUTH;
        if (LOGGING) Log.d(TAG, "Slot 0: Auth sector:" + sector + " block:" + block + "...");
        int slotNum = 0;

        // Set parameters
        TransmitParams params = new TransmitParams();
        params.slotNum = slotNum;
        params.controlCode = -1;
        params.commandString = "FF860000050100"
                + String.format(Locale.US, "%02X", block)
                + (useKeyB ? "61" : "60")
                + String.format(Locale.US, "%02X", keyNumber);
        // Transmit APDU
        if (LOGGING) Log.d(TAG, "Slot " + slotNum + ": Transmitting APDU...");
        new TransmitTask().execute(params);
    }

    private static void readDataBlock(int block) {
        command = NfcCommand.READ;
        if (LOGGING) Log.d(TAG, "Slot 0: Read block " + block + "...");
        int slotNum = 0;

        // Set parameters
        TransmitParams params = new TransmitParams();
        params.slotNum = slotNum;
        params.controlCode = -1;
        params.commandString = "FFB000"
                + String.format(Locale.US, "%02X", block)
                + "10";
        // Transmit APDU
        if (LOGGING) Log.d(TAG, "Slot " + slotNum + ": Transmitting APDU...");
        new TransmitTask().execute(params);
    }

    private static void writeDataBlock(int block, String data) {
        command = NfcCommand.WRITE;
        if (LOGGING) Log.d(TAG, "Slot 0: Write block " + block + "...");
        int slotNum = 0;

        // Set parameters
        TransmitParams params = new TransmitParams();
        params.slotNum = slotNum;
        params.controlCode = -1;
        params.commandString = "FFD600"
                + String.format(Locale.US, "%02X", block)
                + "10"
                + data;
        // Transmit APDU
        if (LOGGING) Log.d(TAG, "Slot " + slotNum + ": Transmitting APDU...");
        new TransmitTask().execute(params);
    }

    @SuppressWarnings("unused")
    private class PowerParams {
        public int slotNum;
        public int action;
    }

    @SuppressWarnings("unused")
    private static class PowerResult {
        byte[] atr;
        Exception e;
    }


    @SuppressWarnings("unused")
    private class SetProtocolParams {
        public int slotNum;
        public int preferredProtocols;
    }

    @SuppressWarnings("unused")
    private static class SetProtocolResult {
        int activeProtocol;
        Exception e;
    }

    @SuppressWarnings("unused")
    private static class TransmitParams {
        int slotNum;
        int controlCode;
        String commandString;
    }

    @SuppressWarnings({"unused"})
    private static class TransmitProgress {
        int controlCode;
        byte[] command;
        int commandLength;
        byte[] response;
        int responseLength;
        Exception e;
    }

    enum NfcCommand {
        READ_UID(0),
        LOAD_KEY(1),
        AUTH(2),
        READ(3),
        WRITE(4),
        ;

        private int value;

        NfcCommand(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }
}
