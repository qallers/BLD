package za.co.blts.devicelibnfc.nfc;

public class NfcResult {
    private NfcTappable.NfcStatus status;
    private NfcTappable.NfcOperation operation;
    private NfcCard card;

    public NfcResult() {
        card = new NfcCard();
    }

    public NfcTappable.NfcStatus getStatus() {
        return status;
    }

    public void setStatus(NfcTappable.NfcStatus status) {
        this.status = status;
    }

    public NfcTappable.NfcOperation getOperation() {
        return operation;
    }

    public void setOperation(NfcTappable.NfcOperation operation) {
        this.operation = operation;
    }

    public NfcCard getCard() {
        return card;
    }

    public void setCard(NfcCard card) {
        this.card = card;
    }
}
