package za.co.blts.devicelibnfc.nfc;

import android.util.Log;

import com.nexgo.oaf.apiv3.DeviceEngine;
import com.nexgo.oaf.apiv3.card.mifare.AuthEntity;
import com.nexgo.oaf.apiv3.card.mifare.BlockEntity;
import com.nexgo.oaf.apiv3.card.mifare.M1CardHandler;
import com.nexgo.oaf.apiv3.card.mifare.M1KeyTypeEnum;
import com.nexgo.oaf.apiv3.device.reader.CardInfoEntity;
import com.nexgo.oaf.apiv3.device.reader.CardReader;
import com.nexgo.oaf.apiv3.device.reader.CardSlotTypeEnum;
import com.nexgo.oaf.apiv3.device.reader.OnCardInfoListener;
import com.nexgo.oaf.apiv3.device.reader.TypeAInfoEntity;

import org.json.JSONObject;

import java.util.HashSet;
import java.util.Locale;

import za.co.blts.devicelibnfc.Utils;

import static com.nexgo.oaf.apiv3.APIProxy.getDeviceEngine;
import static za.co.blts.devicelibnfc.nfc.NfcTappable.NfcStatus.ERROR;
import static za.co.blts.devicelibnfc.nfc.NfcTappable.NfcStatus.INVALID_CARD;
import static za.co.blts.devicelibnfc.nfc.NfcTappable.NfcStatus.INVALID_COMMAND;
import static za.co.blts.devicelibnfc.nfc.NfcTappable.NfcStatus.SUCCESS;

public class NfcNexgo implements NfcTappable {

    private final static String TAG = NfcNexgo.class.getSimpleName();

    private NfcResultable resultable;
    private NfcOperation operation;
    private JSONObject instruction;

    private CardReader cardReader;
    private M1CardHandler cardHandler;

    private String keyToUse;
    private boolean useKeyB;

    private String keyA, keyB, access;

    public NfcNexgo(NfcResultable resultable) {
        this.resultable = resultable;
    }

    @Override
    public void init() {
        DeviceEngine deviceEngine = getDeviceEngine();
        cardReader = deviceEngine.getCardReader();
        cardHandler = deviceEngine.getM1CardHandler();
    }

    @Override
    public void readUid() {
        Log.v(TAG, "readUid");
        operation = NfcOperation.UID;
        startListener();
    }

    @Override
    public void checkCard(JSONObject readInstr) {
        try {
            operation = NfcOperation.CHECK;
            keyToUse = readInstr.getJSONObject("key").getString("value");
            useKeyB = readInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            instruction = readInstr;
            startListener();
        } catch (Exception e) {
            NfcResult result = new NfcResult();
            result.setStatus(INVALID_COMMAND);
            result.setOperation(NfcOperation.READ);
            resultable.handleNfcResult(result);
        }
    }

    @Override
    public void readCard(JSONObject readInstr) {
        try {
            operation = NfcOperation.READ;
            keyToUse = readInstr.getJSONObject("key").getString("value");
            useKeyB = readInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            instruction = readInstr;
            startListener();
        } catch (Exception e) {
            NfcResult result = new NfcResult();
            result.setStatus(INVALID_COMMAND);
            result.setOperation(NfcOperation.READ);
            resultable.handleNfcResult(result);
        }
    }

    @Override
    public void writeCard(JSONObject writeInstr) {
        try {
            operation = NfcOperation.WRITE;
            keyToUse = writeInstr.getJSONObject("key").getString("value");
            useKeyB = writeInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            instruction = writeInstr;
            startListener();
        } catch (Exception e) {
            NfcResult result = new NfcResult();
            result.setStatus(INVALID_COMMAND);
            result.setOperation(NfcOperation.WRITE);
            resultable.handleNfcResult(result);
        }
    }

    @Override
    public void formatCard(JSONObject writeInstr) {
        try {
            operation = NfcOperation.FORMAT;
            keyToUse = writeInstr.getJSONObject("key").getString("value");
            useKeyB = writeInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            keyA = writeInstr.getJSONObject("format").getString("keyA");
            keyB = writeInstr.getJSONObject("format").getString("keyB");
            access = writeInstr.getJSONObject("format").getString("access");
            instruction = writeInstr;
            startListener();
        } catch (Exception e) {
            NfcResult result = new NfcResult();
            result.setStatus(INVALID_COMMAND);
            result.setOperation(NfcOperation.WRITE);
            resultable.handleNfcResult(result);
        }
    }

    @Override
    public void cancel() {
        try {
            cardReader.stopSearch();
        } catch (Exception ignore) {
        }
    }

    @Override
    public void terminate() {
        try {
            cardReader.stopSearch();
        } catch (Exception ignore) {
        }
    }

    private void startListener() {
        Log.v(TAG, "startListener for operation " + operation);
        try {
            HashSet<CardSlotTypeEnum> slotTypes = new HashSet<>();
            slotTypes.add(CardSlotTypeEnum.RF);
            cardReader.searchCard(slotTypes, 10000, onCardInfoListener);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private OnCardInfoListener onCardInfoListener = new OnCardInfoListener() {
        @Override
        public void onCardInfo(int retCode, CardInfoEntity cardInfo) {
            Log.d(TAG, "onCardInfo retcode:" + retCode + " cardInfo:" + cardInfo);
            String uid = getUid(cardInfo);
            NfcResult result = new NfcResult();
            result.setOperation(operation);
            result.getCard().setUid(uid);

            switch (operation) {
                case UID:
                    result.setStatus(uid != null && !uid.isEmpty() ? SUCCESS : ERROR);
                    break;

                case CHECK:
                    result.setStatus(check(result.getCard()));
                    break;

                case READ:
                    result.setStatus(read(result.getCard()));
                    break;

                case WRITE:
                    result.setStatus(write(result.getCard()));
                    break;

                case FORMAT:
                    result.setStatus(format(result.getCard()));
                    break;
            }

            resultable.handleNfcResult(result);
            cancel();

        }

        @Override
        public void onSwipeIncorrect() {

        }

        @Override
        public void onMultipleCards() {

        }
    };

    private String getUid(CardInfoEntity cardInfo) {
        String uid = null;
        if (cardInfo != null) {
            TypeAInfoEntity entity = new TypeAInfoEntity();
            int result = cardReader.getRfCardInfo(entity);
            Log.d(TAG, "result:" + result + " entity:" + entity);
            if (entity.getUid() != null) {
                uid = Utils.bytesToHex(entity.getUid());
                Log.d(TAG, "entity.uid:" + Utils.bytesToHex(entity.getUid()));
            }
        }
        return uid;
    }

    private NfcStatus check(NfcCard card) {
        try {
            String uid = instruction.getString("uid");
            if (uid.isEmpty() || uid.equalsIgnoreCase(card.getUid())) {
                int numSectors = instruction.getJSONArray("sectors").length();
                NfcStatus result = SUCCESS;
                for (int idx = 0; idx < numSectors; idx++) {
                    int sector = ((int) instruction.getJSONArray("sectors").get(idx));
                    int auth = authToSector(card.getUid(), sector, keyToUse, useKeyB);
                    if (auth != 0) {
                        Log.e(TAG, "auth failed to sector " + sector + " : " + auth);
                        result = ERROR;
                    } else {
                        card.getSectors().add(sector);
                        String str = String.format(Locale.US, "check: %2d %d", auth, sector * 4 + 3);
                        Log.d(TAG, str);
                    }
                }
                return result;
            } else {
                Log.e(TAG, "uid error.  expected:" + uid + " found:" + card.getUid());
                return INVALID_CARD;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ERROR;
    }

    private NfcStatus read(NfcCard card) {
        try {
            String uid = instruction.getString("uid");
            if (uid.isEmpty() || uid.equalsIgnoreCase(card.getUid())) {
                int lastSectorAuthed = -1;

                int numBlocks = instruction.getJSONArray("blocks").length();
                for (int idx = 0; idx < numBlocks; idx++) {
                    int block = (int) instruction.getJSONArray("blocks").get(idx);
                    int sector = block / 4;
                    if (sector != lastSectorAuthed) {
                        int auth = authToSector(card.getUid(), sector, keyToUse, useKeyB);
                        if (auth != 0) {
                            Log.e(TAG, "auth failed to sector " + sector + " : " + auth);
                            return ERROR;
                        }
                        lastSectorAuthed = sector;
                    }
                    StringBuilder data = new StringBuilder();
                    int bytesRead = readBlock(block, data);
                    if (bytesRead != 16) {
                        Log.e(TAG, "read failed to " + sector + "-" + block + " : " + bytesRead);
                        return ERROR;
                    } else {
                        NfcBlock nfcblock = new NfcBlock(block, data.toString());
                        card.getBlocks().add(nfcblock);
                        String str = String.format(Locale.US, "read: %2d %d %s", sector, block, data);
                        Log.d(TAG, str);
                    }
                }
                return SUCCESS;
            } else {
                Log.e(TAG, "uid error.  expected:" + uid + " found:" + card.getUid());
                return INVALID_CARD;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ERROR;
    }

    private NfcStatus write(NfcCard card) {
        try {
            String uid = instruction.getString("uid");
            if (uid.isEmpty() || uid.equalsIgnoreCase(card.getUid())) {
                int lastSectorAuthed = -1;

                int numBlocks = instruction.getJSONArray("blocks").length();
                for (int idx = 0; idx < numBlocks; idx++) {
                    int block = ((JSONObject) instruction.getJSONArray("blocks").get(idx)).getInt("num");
                    String data = ((JSONObject) instruction.getJSONArray("blocks").get(idx)).getString("value");
                    int sector = block / 4;
                    if (sector != lastSectorAuthed) {
                        int auth = authToSector(card.getUid(), sector, keyToUse, useKeyB);
                        if (auth != 0) {
                            Log.e(TAG, "auth failed to sector " + sector + " : " + auth);
                            return ERROR;
                        }
                        lastSectorAuthed = sector;
                    }
                    int write = writeBlock(block, data);
                    if (write != 0) {
                        Log.e(TAG, "write failed to " + sector + "-" + block + " : " + write);
                        return ERROR;
                    } else {
                        NfcBlock nfcblock = new NfcBlock(block, data);
                        card.getBlocks().add(nfcblock);
                        String str = String.format(Locale.US, "write: %2d %d %s", sector, block, data);
                        Log.d(TAG, str);
                    }
                }
                return SUCCESS;
            } else {
                Log.e(TAG, "uid error.  expected:" + uid + " found:" + card.getUid());
                return INVALID_CARD;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ERROR;
    }

    private NfcStatus format(NfcCard card) {
        try {
            String uid = instruction.getString("uid");
            if (uid.isEmpty() || uid.equalsIgnoreCase(card.getUid())) {

                if (instruction.has("blocks")) {
                    int lastSectorAuthed = -1;
                    int numBlocks = instruction.getJSONArray("blocks").length();
                    for (int idx = 0; idx < numBlocks; idx++) {
                        int block = ((JSONObject) instruction.getJSONArray("blocks").get(idx)).getInt("num");
                        String data = ((JSONObject) instruction.getJSONArray("blocks").get(idx)).getString("value");
                        int sector = block / 4;
                        if (sector != lastSectorAuthed) {
                            int auth = authToSector(card.getUid(), sector, keyToUse, useKeyB);
                            if (auth != 0) {
                                Log.e(TAG, "auth failed to sector " + sector + " : " + auth);
                                return ERROR;
                            }
                            lastSectorAuthed = sector;
                        }
                        int write = writeBlock(block, data);
                        if (write != 0) {
                            Log.e(TAG, "write failed to " + sector + "-" + block + " : " + write);
                            return ERROR;
                        } else {
                            String str = String.format(Locale.US, "write: %2d %d %s", sector, block, data);
                            Log.d(TAG, str);
                        }
                    }
                }

                int numSectors = instruction.getJSONArray("sectors").length();
                String sectorTrailer = keyA + access + keyB;
                for (int idx = 0; idx < numSectors; idx++) {
                    int sector = ((int) instruction.getJSONArray("sectors").get(idx));
                    int auth = authToSector(card.getUid(), sector, keyToUse, useKeyB);
                    if (auth != 0) {
                        Log.e(TAG, "auth failed to sector " + sector + " : " + auth);
                        return ERROR;
                    }
                    int write = writeBlock(sector * 4 + 3, sectorTrailer);
                    if (write != 0) {
                        Log.e(TAG, "write failed to " + sector + "-" + (sector * 4 + 3) + " : " + write);
                        return ERROR;
                    } else {
                        String str = String.format(Locale.US, "format: %2d %d", sector, sector * 4 + 3);
                        Log.d(TAG, str);
                    }
                }

                return SUCCESS;
            } else {
                Log.e(TAG, "uid error.  expected:" + uid + " found:" + card.getUid());
                return INVALID_CARD;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ERROR;
    }

    private int authToSector(String uid, int sector, String key, boolean useKeyB) {
        AuthEntity auth = new AuthEntity();
        auth.setBlkNo(sector * 4 + 3);
        auth.setKeyType(useKeyB ? M1KeyTypeEnum.KEYTYPE_B : M1KeyTypeEnum.KEYTYPE_A);
        auth.setPwd(Utils.hexToBytes(key));
        auth.setUid(uid);
        int res = cardHandler.authority(auth);
        Log.d(TAG, "authToSector res = " + res);
        return res == 0 ? 0 : -1;
    }

    private int readBlock(int block, StringBuilder data) {
        BlockEntity blockEntity = new BlockEntity();
        blockEntity.setBlkNo(block);
        int res = cardHandler.readBlock(blockEntity);
        Log.d(TAG, "read block:" + block + " res:" + res + " data:" + Utils.bytesToHex(blockEntity.getBlkData()));
        if (res == 0) {
            String cardData = Utils.bytesToHex(blockEntity.getBlkData());
            data.append(cardData);
            return blockEntity.getBlkData().length;
        }
        return res;
    }

    private int writeBlock(int block, String data) {
        BlockEntity blockEntity = new BlockEntity();
        blockEntity.setBlkNo(block);
        blockEntity.setBlkData(Utils.hexToBytes(data));
        int res = cardHandler.writeBlock(blockEntity);
        Log.d(TAG, "write block:" + block + " res:" + res + " data:" + Utils.bytesToHex(blockEntity.getBlkData()));
        return res;
    }
}
