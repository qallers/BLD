package za.co.blts.devicelibnfc.nfc;

public class NfcBlock {
    private int num;
    private String data;

    public NfcBlock() {
    }

    public NfcBlock(int num, String data) {
        this.num = num;
        this.data = data;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
