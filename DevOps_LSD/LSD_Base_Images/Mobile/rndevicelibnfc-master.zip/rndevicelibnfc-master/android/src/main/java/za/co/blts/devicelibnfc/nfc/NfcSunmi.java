package za.co.blts.devicelibnfc.nfc;

import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;

import com.sunmi.pay.hardware.aidl.AidlConstants;
import com.sunmi.pay.hardware.aidlv2.readcard.CheckCardCallbackV2;
import com.sunmi.pay.hardware.aidlv2.readcard.ReadCardOptV2;

import org.json.JSONObject;

import java.util.Locale;

import sunmi.paylib.SunmiPayKernel;
import za.co.blts.devicelibnfc.Utils;

import static za.co.blts.devicelibnfc.nfc.NfcTappable.NfcStatus.ERROR;
import static za.co.blts.devicelibnfc.nfc.NfcTappable.NfcStatus.SUCCESS;

public class NfcSunmi implements NfcTappable {

    private final static String TAG = NfcSunmi.class.getSimpleName();

    private NfcResultable resultable;
    private ReadCardOptV2 readCardOpt;
    private SunmiPayKernel mSMPayKernel = null;
    private NfcTappable.NfcOperation operation;
    private JSONObject instruction;

    private String keyToUse;
    private boolean useKeyB;

    private String keyA, keyB, access;

    public NfcSunmi(NfcResultable resultable) {
        this.resultable = resultable;
    }

    @Override
    public void init() {
        mSMPayKernel = SunmiPayKernel.getInstance();
        mSMPayKernel.initPaySDK(resultable.getContext(), mConnectCallback);
    }

    @Override
    public void readUid() {
        operation = NfcOperation.UID;
        startListener(operation);
    }

    @Override
    public void checkCard(JSONObject readInstr) {
        try {
            operation = NfcOperation.CHECK;
            keyToUse = readInstr.getJSONObject("key").getString("value");
            useKeyB = readInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            instruction = readInstr;
            startListener(operation);
        } catch (Exception e) {
            NfcResult result = new NfcResult();
            result.setStatus(NfcStatus.INVALID_COMMAND);
            result.setOperation(NfcOperation.READ);
            resultable.handleNfcResult(result);
        }
    }

    @Override
    public void readCard(JSONObject readInstr) {
        try {
            operation = NfcOperation.READ;
            keyToUse = readInstr.getJSONObject("key").getString("value");
            useKeyB = readInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            instruction = readInstr;
            startListener(operation);
        } catch (Exception e) {
            NfcResult result = new NfcResult();
            result.setStatus(NfcStatus.INVALID_COMMAND);
            result.setOperation(NfcOperation.READ);
            resultable.handleNfcResult(result);
        }
    }

    @Override
    public void writeCard(JSONObject writeInstr) {
        try {
            operation = NfcOperation.WRITE;
            keyToUse = writeInstr.getJSONObject("key").getString("value");
            useKeyB = writeInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            instruction = writeInstr;
            startListener(operation);
        } catch (Exception e) {
            NfcResult result = new NfcResult();
            result.setStatus(NfcStatus.INVALID_COMMAND);
            result.setOperation(NfcOperation.WRITE);
            resultable.handleNfcResult(result);
        }
    }

    @Override
    public void formatCard(JSONObject writeInstr) {
        try {
            operation = NfcOperation.FORMAT;
            keyToUse = writeInstr.getJSONObject("key").getString("value");
            useKeyB = writeInstr.getJSONObject("key").getString("index").equalsIgnoreCase("B");
            keyA = writeInstr.getJSONObject("format").getString("keyA");
            keyB = writeInstr.getJSONObject("format").getString("keyB");
            access = writeInstr.getJSONObject("format").getString("access");
            instruction = writeInstr;
            startListener(operation);
        } catch (Exception e) {
            NfcResult result = new NfcResult();
            result.setStatus(NfcStatus.INVALID_COMMAND);
            result.setOperation(NfcOperation.WRITE);
            resultable.handleNfcResult(result);
        }
    }

    @Override
    public void cancel() {
        try {
            readCardOpt.cancelCheckCard();
        } catch (Exception ignore) {
        }
    }

    @Override
    public void terminate() {
        try {
            readCardOpt.cancelCheckCard();
            readCardOpt = null;
            mSMPayKernel.destroyPaySDK();
        } catch (Exception ignore) {
        }
    }

    private void startListener(NfcTappable.NfcOperation operation, Object... args) {
        try {
            Log.d(TAG, "startListener " + operation + " : args " + (args == null ? "null" : args.length));
            final int timeOut = 10000;
            this.operation = operation;
            int allType = AidlConstants.CardType.MIFARE.getValue();
            readCardOpt.checkCard(allType, mCheckCardCallback, timeOut);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private SunmiPayKernel.ConnectCallback mConnectCallback = new SunmiPayKernel.ConnectCallback() {

        @Override
        public void onConnectPaySDK() {
            try {
                readCardOpt = mSMPayKernel.mReadCardOptV2;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onDisconnectPaySDK() {
        }
    };

    private CheckCardCallbackV2 mCheckCardCallback = new CheckCardCallbackV2.Stub() {

        @Override
        public void findMagCard(Bundle bundle) {

        }

        @Override
        public void findICCard(String atr) {

        }

        @Override
        public void findICCardEx(Bundle bundle) {
        }

        @Override
        public void findRFCardEx(Bundle bundle) {
        }

        @Override
        public void onErrorEx(Bundle bundle) {

        }

        @Override
        public void findRFCard(String uid) {
            Log.i(TAG, "detected cardNo " + uid + " for command " + operation);
            NfcResult result = new NfcResult();
            result.setOperation(operation);
            result.getCard().setUid(uid);

            switch (operation) {
                case UID:
                    result.setStatus(uid != null && !uid.isEmpty() ? SUCCESS : ERROR);
                    break;

                case CHECK:
                    result.setStatus(check(result.getCard()));
                    break;

                case READ:
                    result.setStatus(read(result.getCard()));
                    break;

                case WRITE:
                    result.setStatus(write(result.getCard()));
                    break;

                case FORMAT:
                    result.setStatus(format(result.getCard()));
                    break;
            }

            resultable.handleNfcResult(result);
        }

        @Override
        public void onError(int code, String message) {
            Log.d(TAG, "onError code=" + code + " message=" + message);
        }

    };

    private NfcStatus check(NfcCard card) {
        try {
            String uid = instruction.getString("uid");
            if (uid.isEmpty() || uid.equalsIgnoreCase(card.getUid())) {
                int numSectors = instruction.getJSONArray("sectors").length();
                NfcStatus result = NfcStatus.SUCCESS;
                for (int idx = 0; idx < numSectors; idx++) {
                    int sector = ((int) instruction.getJSONArray("sectors").get(idx));
                    int auth = authToSector(sector, keyToUse, useKeyB);
                    if (auth != 0) {
                        Log.e(TAG, "auth failed to sector " + sector + " : " + auth);
                        result = NfcStatus.ERROR;
                    } else {
                        card.getSectors().add(sector);
                        String str = String.format(Locale.US, "check: %2d %d", auth, sector * 4 + 3);
                        Log.d(TAG, str);
                    }
                }
                return result;
            } else {
                Log.e(TAG, "uid error.  expected:" + uid + " found:" + card.getUid());
                return NfcStatus.INVALID_CARD;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return NfcStatus.ERROR;
    }

    private NfcStatus read(NfcCard card) {
        try {
            String uid = instruction.getString("uid");
            if (uid.isEmpty() || uid.equalsIgnoreCase(card.getUid())) {
                int lastSectorAuthed = -1;

                int numBlocks = instruction.getJSONArray("blocks").length();
                for (int idx = 0; idx < numBlocks; idx++) {
                    int block = (int) instruction.getJSONArray("blocks").get(idx);
                    int sector = block / 4;
                    if (sector != lastSectorAuthed) {
                        int auth = authToSector(sector, keyToUse, useKeyB);
                        if (auth != 0) {
                            Log.e(TAG, "auth failed to sector " + sector + " : " + auth);
                            return NfcStatus.ERROR;
                        }
                        lastSectorAuthed = sector;
                    }
                    StringBuilder data = new StringBuilder();
                    int bytesRead = readBlock(block, data);
                    if (bytesRead != 16) {
                        Log.e(TAG, "read failed to " + sector + "-" + block + " : " + bytesRead);
                        return NfcStatus.ERROR;
                    } else {
                        NfcBlock nfcblock = new NfcBlock(block, data.toString());
                        card.getBlocks().add(nfcblock);
                        String str = String.format(Locale.US, "read: %2d %d %s", sector, block, data);
                        Log.d(TAG, str);
                    }
                }
                return NfcStatus.SUCCESS;
            } else {
                Log.e(TAG, "uid error.  expected:" + uid + " found:" + card.getUid());
                return NfcStatus.INVALID_CARD;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return NfcStatus.ERROR;
    }

    private NfcStatus write(NfcCard card) {
        try {
            String uid = instruction.getString("uid");
            if (uid.isEmpty() || uid.equalsIgnoreCase(card.getUid())) {
                int lastSectorAuthed = -1;

                int numBlocks = instruction.getJSONArray("blocks").length();
                for (int idx = 0; idx < numBlocks; idx++) {
                    int block = ((JSONObject) instruction.getJSONArray("blocks").get(idx)).getInt("num");
                    String data = ((JSONObject) instruction.getJSONArray("blocks").get(idx)).getString("value");
                    int sector = block / 4;
                    if (sector != lastSectorAuthed) {
                        int auth = authToSector(sector, keyToUse, useKeyB);
                        if (auth != 0) {
                            Log.e(TAG, "auth failed to sector " + sector + " : " + auth);
                            return NfcStatus.ERROR;
                        }
                        lastSectorAuthed = sector;
                    }
                    int write = writeBlock(block, data);
                    if (write != 0) {
                        Log.e(TAG, "write failed to " + sector + "-" + block + " : " + write);
                        return NfcStatus.ERROR;
                    } else {
                        NfcBlock nfcblock = new NfcBlock(block, data);
                        card.getBlocks().add(nfcblock);
                        String str = String.format(Locale.US, "write: %2d %d %s", sector, block, data);
                        Log.d(TAG, str);
                    }
                }
                return NfcStatus.SUCCESS;
            } else {
                Log.e(TAG, "uid error.  expected:" + uid + " found:" + card.getUid());
                return NfcStatus.INVALID_CARD;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return NfcStatus.ERROR;
    }

    private NfcStatus format(NfcCard card) {
        try {
            String uid = instruction.getString("uid");
            if (uid.isEmpty() || uid.equalsIgnoreCase(card.getUid())) {

                if (instruction.has("blocks")) {
                    int lastSectorAuthed = -1;
                    int numBlocks = instruction.getJSONArray("blocks").length();
                    for (int idx = 0; idx < numBlocks; idx++) {
                        int block = ((JSONObject) instruction.getJSONArray("blocks").get(idx)).getInt("num");
                        String data = ((JSONObject) instruction.getJSONArray("blocks").get(idx)).getString("value");
                        int sector = block / 4;
                        if (sector != lastSectorAuthed) {
                            int auth = authToSector(sector, keyToUse, useKeyB);
                            if (auth != 0) {
                                Log.e(TAG, "auth failed to sector " + sector + " : " + auth);
                                return NfcStatus.ERROR;
                            }
                            lastSectorAuthed = sector;
                        }
                        int write = writeBlock(block, data);
                        if (write != 0) {
                            Log.e(TAG, "write failed to " + sector + "-" + block + " : " + write);
                            return NfcStatus.ERROR;
                        } else {
                            String str = String.format(Locale.US, "write: %2d %d %s", sector, block, data);
                            Log.d(TAG, str);
                        }
                    }
                }

                int numSectors = instruction.getJSONArray("sectors").length();
                String sectorTrailer = keyA + access + keyB;
                for (int idx = 0; idx < numSectors; idx++) {
                    int sector = ((int) instruction.getJSONArray("sectors").get(idx));
                    int auth = authToSector(sector, keyToUse, useKeyB);
                    if (auth != 0) {
                        Log.e(TAG, "auth failed to sector " + sector + " : " + auth);
                        return NfcStatus.ERROR;
                    }
                    int write = writeBlock(sector * 4 + 3, sectorTrailer);
                    if (write != 0) {
                        Log.e(TAG, "write failed to " + sector + "-" + (sector * 4 + 3) + " : " + write);
                        return NfcStatus.ERROR;
                    } else {
                        String str = String.format(Locale.US, "format: %2d %d", sector, sector * 4 + 3);
                        Log.d(TAG, str);
                    }
                }

                return NfcStatus.SUCCESS;
            } else {
                Log.e(TAG, "uid error.  expected:" + uid + " found:" + card.getUid());
                return NfcStatus.INVALID_CARD;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return NfcStatus.ERROR;
    }

    private int authToSector(int sector, String key, boolean useKeyB) {
        try {
            Log.v(TAG, "auth to sector " + sector);
            return readCardOpt.mifareAuth(useKeyB ? 1 : 0, sector * 4, Utils.hexToBytes(key));
        } catch (RemoteException re) {
            re.printStackTrace();
            return -1;
        }
    }

    private int readBlock(int block, StringBuilder data) {
        try {
            Log.v(TAG, "readBlock " + block);
            byte[] dataBytes = new byte[16];
            int val = readCardOpt.mifareReadBlock(block, dataBytes);
            data.append(Utils.bytesToHex(dataBytes));
            return val;
        } catch (RemoteException re) {
            re.printStackTrace();
            return -1;
        }
    }

    private int writeBlock(int block, String data) {
        try {
            return readCardOpt.mifareWriteBlock(block, Utils.hexToBytes(data));
        } catch (RemoteException re) {
            re.printStackTrace();
            return -1;
        }
    }
}
