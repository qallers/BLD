package za.co.blts.devicelibnfc.nfc;

import android.content.Context;

public interface NfcResultable {
    Context getContext();
    void handleNfcResult(NfcResult result);
}
