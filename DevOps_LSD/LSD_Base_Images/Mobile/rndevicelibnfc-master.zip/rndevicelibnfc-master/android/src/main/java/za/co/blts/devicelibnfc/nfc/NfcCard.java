package za.co.blts.devicelibnfc.nfc;

import java.util.ArrayList;
import java.util.List;

public class NfcCard {
    private String uid;
    private List<Integer> sectors;
    private List<NfcBlock> blocks;

    public NfcCard() {
        sectors = new ArrayList<>();
        blocks = new ArrayList<>();
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public List<Integer> getSectors() {
        return sectors;
    }

    public void setSectors(List<Integer> sectors) {
        this.sectors = sectors;
    }

    public List<NfcBlock> getBlocks() {
        return blocks;
    }

    public void setBlocks(List<NfcBlock> blocks) {
        this.blocks = blocks;
    }
}
