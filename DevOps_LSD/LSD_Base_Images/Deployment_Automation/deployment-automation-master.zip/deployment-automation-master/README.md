# LSDautomate

# Deployment Automation 

This role/playbook was written for AWX

You have to have the following Extra Variable configured when you launch the job

```
---
image_registry: "registry.apps.k8s-01.prod.bluelabel.co.za"
image_context: "/group/repository/"
image_name: "imagename"
image_tag: "1.0.0"
```

Image registry credentials are sourced from an vault.yml

Look at vars/main.yml for variables and formatting options
